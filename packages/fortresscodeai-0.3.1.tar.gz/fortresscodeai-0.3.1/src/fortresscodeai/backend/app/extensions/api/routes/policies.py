from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.db import get_storage
from backend.models.agents import Policy
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/policies", tags=["policies"])

class PolicyCreate(BaseModel):
    name: str
    severity: str
    dsl: str

class PolicyOut(BaseModel):
    id: int
    name: str
    severity: str
    dsl: str

    class Config:
        orm_mode = True

@router.get("/", response_model=List[PolicyOut])
def list_policies(db: Session = Depends(get_storage)):
    return db.list(Policy).all()

@router.post("/", response_model=PolicyOut)
def create_policy(payload: PolicyCreate, db: Session = Depends(get_storage)):
    policy = Policy(name=payload.name, severity=payload.severity, dsl=payload.dsl)
    db.set(policy)
    db# commit removed (storage is atomic)
)
    db.refresh(policy)
    return policy
