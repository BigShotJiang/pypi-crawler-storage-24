from fastapi import APIRouter
from services.trust_service import (
    evaluate_trust,
    get_trust_signals,
    get_trust_timeline
)

router = APIRouter()

@router.get("/")
async def trust_root():
    return await evaluate_trust()

@router.get("/signals")
async def trust_signals():
    return await get_trust_signals()

@router.get("/timeline")
async def trust_timeline():
    return await get_trust_timeline()
