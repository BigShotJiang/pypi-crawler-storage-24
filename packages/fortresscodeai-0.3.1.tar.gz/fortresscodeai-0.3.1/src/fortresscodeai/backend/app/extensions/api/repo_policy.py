from fastapi import APIRouter, Depends, Request

from ...storage import get_storage
from ..platform.models_repo_policy import RepoConnection, PolicyConfig
from ...services.rbac import require_permission

router = APIRouter(prefix="/org", tags=["org"])


@router.get("/repos")
def list_repos(request: Request, storage=Depends(get_storage)):
    user = request.state.user
    require_permission(user, "use_product")

    repos = storage.list(
        "repo_connections",
        filter_fn=lambda r: r["org_id"] == user.org_id,
    )
    return repos


@router.post("/repos")
def add_repo(request: Request, payload: dict, storage=Depends(get_storage)):
    user = request.state.user
    require_permission(user, "use_product")

    conn = {
        "id": f"{user.org_id}:{payload['repo']}",
        "org_id": user.org_id,
        "provider": payload["provider"],
        "repo": payload["repo"],
        "config": payload.get("config", {}),
    }

    storage.set("repo_connections", conn["id"], conn)
    return conn


@router.get("/policies")
def get_policies(request: Request, storage=Depends(get_storage)):
    user = request.state.user
    require_permission(user, "use_product")

    cfgs = storage.list(
        "policy_configs",
        filter_fn=lambda c: c["org_id"] == user.org_id,
    )
    return cfgs[0]["rules"] if cfgs else {}


@router.post("/policies")
def update_policies(request: Request, payload: dict, storage=Depends(get_storage)):
    user = request.state.user
    require_permission(user, "use_product")

    cfgs = storage.list(
        "policy_configs",
        filter_fn=lambda c: c["org_id"] == user.org_id,
    )

    if cfgs:
        cfg = cfgs[0]
        cfg["rules"] = payload
    else:
        cfg = {
            "id": f"{user.org_id}:policy",
            "org_id": user.org_id,
            "rules": payload,
        }

    storage.set("policy_configs", cfg["id"], cfg)
    return cfg["rules"]
