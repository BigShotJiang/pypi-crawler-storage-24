from fastapi import APIRouter
from services.risk_service import (
    evaluate_risk,
    get_risk_map,
    get_risk_matrix,
    get_risk_rules
)

router = APIRouter()

@router.get("/")
async def risk_root():
    return await evaluate_risk()

@router.get("/map")
async def risk_map():
    return await get_risk_map()

@router.get("/matrix")
async def risk_matrix():
    return await get_risk_matrix()

@router.get("/rules")
async def risk_rules():
    return await get_risk_rules()
