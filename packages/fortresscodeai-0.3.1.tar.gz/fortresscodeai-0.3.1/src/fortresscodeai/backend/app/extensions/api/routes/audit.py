from fastapi import APIRouter
from backend.Modules.audit_logging_engine import (
    collect_audit_data,
    get_audit_logs,
    get_policy_violations,
    get_evidence_bundle
)

router = APIRouter()

@router.get("/")
async def audit_root():
    return await collect_audit_data()

@router.get("/logs")
async def audit_logs():
    return await get_audit_logs()

@router.get("/violations")
async def audit_violations():
    return await get_policy_violations()

@router.get("/evidence")
async def audit_evidence():
    return await get_evidence_bundle()