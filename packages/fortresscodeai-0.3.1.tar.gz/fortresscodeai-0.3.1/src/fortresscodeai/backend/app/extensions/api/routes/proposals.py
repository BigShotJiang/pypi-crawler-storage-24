from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.db import get_storage
from backend.models.agents import Proposal, ProposalOutcome, AgentStat
from pydantic import BaseModel
from typing import List, Dict, Any

router = APIRouter(prefix="/proposals", tags=["proposals"])

class ProposalOut(BaseModel):
    id: int
    task_id: int
    repo_id: int
    title: str
    diff: str
    status: str
    risk_score: int
    policy_report: Dict[str, Any]

    class Config:
        orm_mode = True

@router.get("/", response_model=List[ProposalOut])
def list_proposals(db: Session = Depends(get_storage)):
    return db.list(Proposal).all()

class ProposalDecision(BaseModel):
    decision: str  # "approved" | "rejected"
    feedback: str | None = None

@router.post("/{proposal_id}/decision")
def decide_proposal(proposal_id: int, payload: ProposalDecision, db: Session = Depends(get_storage)):
    proposal = db.list(Proposal).filter(Proposal.id == proposal_id).first()
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")

    proposal.status = payload.decision
    db.set(proposal)

    outcome = ProposalOutcome(
        proposal_id=proposal.id,
        final_decision=payload.decision,
        human_feedback=payload.feedback,
    )
    db.set(outcome)

    # update agent stats
    report = proposal.policy_report or {}
    agents = report.get("agents", [])
    for a in agents:
        name = a.get("name")
        verdict = a.get("verdict")
        if not name or not verdict:
            continue

        stat = db.list(AgentStat).filter(AgentStat.name == name).first()
        if not stat:
            continue

        stat.total_votes += 1
        aligned = (
            (payload.decision == "approved" and verdict == "approve") or
            (payload.decision == "rejected" and verdict == "reject")
        )
        if aligned:
            stat.correct_votes += 1

        # simple learning rule: adjust weight slightly toward accuracy
        accuracy = stat.correct_votes / max(1, stat.total_votes)
        # keep weights in [0.5, 2.0]
        stat.weight = max(0.5, min(2.0, 0.5 + accuracy * 1.5))

        db.set(stat)

    db# commit removed (storage is atomic)
)
    return {"status": "ok"}
