from typing import Any, Dict, Optional, List
from pydantic import BaseModel
from datetime import datetime


class AuditLogEntry(BaseModel):
    id: str
    timestamp: datetime
    actor: str
    action: str
    resource: Optional[str] = None
    details: Dict[str, Any]
    correlation_id: Optional[str] = None
    tags: List[str] = []


class AuditBundle(BaseModel):
    bundle_id: str
    created_at: datetime
    correlation_id: str
    entries: List[AuditLogEntry]
