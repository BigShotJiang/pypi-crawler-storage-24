from pydantic import BaseModel
from typing import Any, Dict, List


class EvidenceItem(BaseModel):
    type: str
    source: str
    payload: Dict[str, Any]


class EvidenceBundle(BaseModel):
    items: List[EvidenceItem]
    summary: Dict[str, Any]
