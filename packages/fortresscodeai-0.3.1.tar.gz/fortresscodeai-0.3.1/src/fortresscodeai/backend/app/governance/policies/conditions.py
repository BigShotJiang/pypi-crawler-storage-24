from __future__ import annotations
from typing import Any, Dict, Callable, List

from .schema import ConditionModel


def _get_nested_value(data: Dict[str, Any], path: str) -> Any:
    parts = path.split(".")
    current: Any = data
    for p in parts:
        if not isinstance(current, dict) or p not in current:
            return None
        current = current[p]
    return current


def op_eq(a, b) -> bool:
    return a == b


def op_ne(a, b) -> bool:
    return a != b


def op_gt(a, b) -> bool:
    try:
        return a > b
    except TypeError:
        return False


def op_lt(a, b) -> bool:
    try:
        return a < b
    except TypeError:
        return False


def op_gte(a, b) -> bool:
    try:
        return a >= b
    except TypeError:
        return False


def op_lte(a, b) -> bool:
    try:
        return a <= b
    except TypeError:
        return False


def op_in(a, b) -> bool:
    try:
        return a in b
    except TypeError:
        return False


def op_contains(a, b) -> bool:
    try:
        return b in a
    except TypeError:
        return False


OPERATORS: Dict[str, Callable[[Any, Any], bool]] = {
    "==": op_eq,
    "!=": op_ne,
    ">": op_gt,
    "<": op_lt,
    ">=": op_gte,
    "<=": op_lte,
    "in": op_in,
    "contains": op_contains,
}


def evaluate_condition(condition: ConditionModel, context: Dict[str, Any]) -> bool:
    value = _get_nested_value(context, condition.field)
    op = OPERATORS.get(condition.operator)
    if op is None:
        return False
    return op(value, condition.value)


def evaluate_conditions(conditions: List[ConditionModel], context: Dict[str, Any]) -> bool:
    if not conditions:
        return True
    return all(evaluate_condition(c, context) for c in conditions)
