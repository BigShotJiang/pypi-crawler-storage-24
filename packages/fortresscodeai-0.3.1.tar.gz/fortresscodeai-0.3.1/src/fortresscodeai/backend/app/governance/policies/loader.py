from __future__ import annotations
import os
import glob
from typing import Dict, Any

import yaml

from .dsl import policy_from_dict
from .registry import PolicyRegistry
from .schema import Policy


class PolicyLoader:
    def __init__(self, base_dir: str, registry: PolicyRegistry) -> None:
        self.base_dir = base_dir
        self.registry = registry

    def load_all(self) -> None:
        pattern = os.path.join(self.base_dir, "*.yaml")
        for path in glob.glob(pattern):
            self.load_file(path)

    def load_file(self, path: str) -> Policy:
        with open(path, "r", encoding="utf-8") as f:
            raw: Dict[str, Any] = yaml.safe_load(f)

        policy = policy_from_dict(raw)
        self.registry.register_policy(policy, enabled=raw.get("enabled", True))
        return policy
