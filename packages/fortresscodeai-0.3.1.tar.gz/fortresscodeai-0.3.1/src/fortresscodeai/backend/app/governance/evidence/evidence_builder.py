from typing import List, Dict, Any
from .evidence_models import EvidenceBundle, EvidenceItem


def build_evidence_bundle(logs: List[Dict[str, Any]], violations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Builds a governance evidence bundle from logs and violations.
    """

    items: List[EvidenceItem] = []

    for log in logs:
        items.append(EvidenceItem(
            type="audit_log",
            source="audit_logs.json",
            payload=log
        ))

    for v in violations:
        items.append(EvidenceItem(
            type="violation",
            source="violations.json",
            payload=v
        ))

    summary = {
        "totalLogs": len(logs),
        "totalViolations": len(violations),
        "severityBreakdown": _severity_breakdown(violations)
    }

    bundle = EvidenceBundle(items=items, summary=summary)
    return bundle.model_dump()


def _severity_breakdown(violations: List[Dict[str, Any]]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for v in violations:
        sev = v.get("severity", "unknown")
        counts[sev] = counts.get(sev, 0) + 1
    return counts
