from __future__ import annotations
from typing import Dict, Any, List

from .registry import PolicyRegistry
from .schema import PolicyResult, Trigger
from .conditions import evaluate_conditions
from .actions import execute_actions


class PolicyEvaluator:
    def __init__(self, registry: PolicyRegistry) -> None:
        self.registry = registry

    def evaluate(self, trigger: Trigger, context: Dict[str, Any]) -> List[PolicyResult]:
        """
        context should include at least:
        - task metadata
        - user info
        - risk score
        - output (for post)
        """
        results: List[PolicyResult] = []
        policies = self.registry.get_policies_for_trigger(trigger)

        for policy in policies:
            if evaluate_conditions(policy.conditions, context):
                result = execute_actions(policy, policy.actions, context)
                results.append(result)

        return results
