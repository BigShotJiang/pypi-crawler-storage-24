# src/fortresscodeai/backend/app/governance/governance_manager.py

from datetime import datetime
from typing import Any, Dict, List, Optional

from app.policies.policy_engine import PolicyEngine
from app.audit.audit_logging_engine import AuditLogger
from app.security.security_events import SecurityEventRecorder
from app.risk.risk_engine import RiskEngine
from app.traceability.lineage import LineageTracker
from app.hitl.hitl_queue import HITLQueue


class GovernanceDecision:
    def __init__(
        self,
        allowed: bool,
        reason: str,
        risk_score: float,
        violated_policies: Optional[List[str]] = None,
        audit_id: Optional[str] = None,
        explainability: Optional[Dict[str, Any]] = None,
        next_action: Optional[str] = None,
    ):
        self.allowed = allowed
        self.reason = reason
        self.risk_score = risk_score
        self.violated_policies = violated_policies or []
        self.audit_id = audit_id
        self.explainability = explainability or {}
        self.next_action = next_action


class GovernanceManager:
    def __init__(self):
        self.policy_engine = PolicyEngine()
        self.audit = AuditLogger()
        self.security = SecurityEventRecorder()
        self.risk = RiskEngine()
        self.lineage = LineageTracker()
        self.hitl = HITLQueue()

    def evaluate(
        self,
        workflow_id: str,
        step_name: str,
        user_id: str,
        agent_context: Dict[str, Any],
        input_data: Dict[str, Any],
    ) -> GovernanceDecision:

        timestamp = datetime.utcnow()

        risk_score = self.risk.score(workflow_id, step_name, input_data)

        policy_result = self.policy_engine.evaluate(
            workflow_id=workflow_id,
            step_name=step_name,
            user_id=user_id,
            agent_context=agent_context,
            input_data=input_data,
            risk_score=risk_score,
        )

        audit_id = self.audit.record_event(
            workflow_id=workflow_id,
            step_name=step_name,
            user_id=user_id,
            agent_context=agent_context,
            input_data=input_data,
            policy_result=policy_result,
            risk_score=risk_score,
            timestamp=timestamp,
        )

        explainability = self.lineage.record_step(
            workflow_id=workflow_id,
            step_name=step_name,
            input_data=input_data,
            policy_result=policy_result,
            risk_score=risk_score,
            timestamp=timestamp,
        )

        if not policy_result.allowed:
            self.security.record_violation(
                workflow_id=workflow_id,
                step_name=step_name,
                user_id=user_id,
                violated_policies=policy_result.violated_policies,
                risk_score=risk_score,
                timestamp=timestamp,
            )

            if policy_result.requires_hitl:
                self.hitl.enqueue(
                    workflow_id=workflow_id,
                    step_name=step_name,
                    user_id=user_id,
                    context=input_data,
                    reason="Policy violation requiring human review",
                )
                next_action = "HITL_REVIEW"
            else:
                next_action = "DENY"

            return GovernanceDecision(
                allowed=False,
                reason=policy_result.reason,
                risk_score=risk_score,
                violated_policies=policy_result.violated_policies,
                audit_id=audit_id,
                explainability=explainability,
                next_action=next_action,
            )

        return GovernanceDecision(
            allowed=True,
            reason="All policies satisfied",
            risk_score=self.risk.score(workflow_id, step_name, input_data),
            violated_policies=[],
            audit_id=audit_id,
            explainability=explainability,
            next_action="PROCEED",
        )
        