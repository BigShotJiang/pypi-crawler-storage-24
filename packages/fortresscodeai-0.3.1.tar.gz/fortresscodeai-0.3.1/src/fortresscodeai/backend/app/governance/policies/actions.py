from __future__ import annotations
from typing import Any, Dict, List

from .schema import ActionModel, PolicyResult, Policy


def execute_actions(
    policy: Policy,
    actions: List[ActionModel],
    context: Dict[str, Any],
) -> PolicyResult:
    """
    For now, we assume a single dominant action per policy.
    Later you can fan this out into multiple effects.
    """
    chosen_action: ActionModel | None = actions[0] if actions else None

    result = PolicyResult(
        policy_id=policy.id,
        version=policy.version,
        triggered=True,
        severity=policy.severity,
        action=chosen_action.type if chosen_action else None,
        reason=chosen_action.reason if chosen_action else None,
        metadata={
            "policy_name": policy.name,
            "trigger": policy.trigger,
            "context_snapshot": context,
            "actions": [a.dict() for a in actions],
        },
    )

    # Here is where you later:
    # - enqueue HITL
    # - emit security events
    # - adjust risk score
    # - send notifications
    # For now, we just return the result.
    return result
