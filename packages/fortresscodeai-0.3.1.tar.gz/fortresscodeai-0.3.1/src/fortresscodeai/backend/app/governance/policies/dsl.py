from __future__ import annotations
from typing import Any, Dict

from .schema import Policy, ConditionModel, ActionModel
from datetime import datetime


def policy_from_dict(data: Dict[str, Any]) -> Policy:
    """
    Normalize raw dict (from YAML/JSON) into a Policy model.
    """
    now = datetime.utcnow()

    conditions = [ConditionModel(**c) for c in data.get("conditions", [])]
    actions = [ActionModel(**a) for a in data.get("actions", [])]

    return Policy(
        id=data["id"],
        name=data["name"],
        description=data.get("description", ""),
        version=data.get("version", "1.0.0"),
        severity=data.get("severity", "medium"),
        trigger=data.get("trigger", "pre"),
        conditions=conditions,
        actions=actions,
        metadata=data.get("metadata", {}),
        created_at=data.get("created_at", now),
        updated_at=data.get("updated_at", now),
        created_by=data.get("created_by", "system"),
    )
