from __future__ import annotations
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, validator


Severity = Literal["low", "medium", "high", "critical"]
Trigger = Literal["pre", "post", "both"]


class ConditionModel(BaseModel):
    field: str
    operator: str
    value: Any


class ActionModel(BaseModel):
    type: str
    reason: Optional[str] = None
    target: Optional[str] = None
    params: Dict[str, Any] = Field(default_factory=dict)


class Policy(BaseModel):
    id: str
    name: str
    description: str
    version: str
    severity: Severity
    trigger: Trigger
    conditions: List[ConditionModel]
    actions: List[ActionModel]
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    updated_at: datetime
    created_by: str

    @validator("severity", pre=True)
    def normalize_severity(cls, v: str) -> str:
        return v.lower()

    @validator("trigger", pre=True)
    def normalize_trigger(cls, v: str) -> str:
        return v.lower()

    @validator("version")
    def validate_version(cls, v: str) -> str:
        parts = v.split(".")
        if len(parts) != 3 or not all(p.isdigit() for p in parts):
            raise ValueError("version must be semantic: X.Y.Z")
        return v


class PolicyVersion(BaseModel):
    policy_id: str
    version: str
    data: Dict[str, Any]
    created_at: datetime
    created_by: str


class PolicyResult(BaseModel):
    policy_id: str
    version: str
    triggered: bool
    severity: Severity
    action: Optional[str]
    reason: Optional[str]
    metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
