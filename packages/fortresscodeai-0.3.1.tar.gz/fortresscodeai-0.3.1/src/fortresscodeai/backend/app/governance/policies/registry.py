from __future__ import annotations
from typing import Dict, List

from .schema import Policy, Trigger


class PolicyRegistry:
    def __init__(self) -> None:
        self.active: Dict[str, Policy] = {}
        self.disabled: Dict[str, Policy] = {}
        self.versions: Dict[str, List[str]] = {}  # policy_id -> [version strings]

    def register_policy(self, policy: Policy, enabled: bool = True) -> None:
        if enabled:
            self.active[policy.id] = policy
        else:
            self.disabled[policy.id] = policy

        self.versions.setdefault(policy.id, [])
        if policy.version not in self.versions[policy.id]:
            self.versions[policy.id].append(policy.version)

    def disable_policy(self, policy_id: str) -> None:
        if policy_id in self.active:
            policy = self.active.pop(policy_id)
            self.disabled[policy_id] = policy

    def enable_policy(self, policy_id: str) -> None:
        if policy_id in self.disabled:
            policy = self.disabled.pop(policy_id)
            self.active[policy_id] = policy

    def get_policy(self, policy_id: str) -> Policy | None:
        return self.active.get(policy_id) or self.disabled.get(policy_id)

    def get_policies_for_trigger(self, trigger: Trigger) -> List[Policy]:
        result: List[Policy] = []
        for p in self.active.values():
            if p.trigger == trigger or p.trigger == "both":
                result.append(p)
        return result
