from typing import Dict, Any

from backend.services.audit_service import AuditService
from backend.services.policy.policy_engine import PolicyEngine
from backend.services.hitl_service import HITLService
from backend.Modules.dispute_resolution_system.backend.services.disputes_service import DisputesService


class GovernancePipeline:
    def __init__(
        self,
        audit: AuditService,
        policy: PolicyEngine,
        hitl: HITLService,
        disputes: DisputesService,
    ):
        self.audit = audit
        self.policy = policy
        self.hitl = hitl
        self.disputes = disputes

    def process_action(self, actor: str, action: str, context: Dict[str, Any], correlation_id: str):
        self.audit.log_event(
            actor=actor,
            action=action,
            details=context,
            correlation_id=correlation_id,
        )

        violations = self.policy.evaluate(context)
        # you can route violations to HITL, autobuilder, etc. here
        return violations
