from typing import Optional
from datetime import datetime
import uuid

from backend.models.disputes import DisputeCase, DisputeStatus
from backend.Modules.audit_logging_engine import AuditService


class DisputesService:
    def __init__(self, store, audit: AuditService):
        self.store = store
        self.audit = audit

    def open_dispute(
        self,
        opened_by: str,
        correlation_id: str,
        subject: str,
        description: str,
    ) -> DisputeCase:
        case = DisputeCase(
            id=str(uuid.uuid4()),
            created_at=datetime.utcnow(),
            opened_by=opened_by,
            correlation_id=correlation_id,
            subject=subject,
            description=description,
        )
        self.store.save_dispute_case(case)
        self.audit.log_event(
            actor=opened_by,
            action="dispute_opened",
            resource=f"dispute:{case.id}",
            details={"subject": subject},
            correlation_id=correlation_id,
        )
        return case

    def attach_evidence_bundle(self, case_id: str, bundle_id: str) -> DisputeCase:
        case = self.store.get_dispute_case(case_id)
        case.evidence_bundle_id = bundle_id
        self.store.update_dispute_case(case)
        self.audit.log_event(
            actor="system",
            action="dispute_evidence_attached",
            resource=f"dispute:{case.id}",
            details={"bundle_id": bundle_id},
            correlation_id=case.correlation_id,
        )
        return case

    def resolve_dispute(self, case_id: str, resolution: str) -> DisputeCase:
        case = self.store.get_dispute_case(case_id)
        case.status = DisputeStatus.RESOLVED
        case.resolution = resolution
        case.resolved_at = datetime.utcnow()
        self.store.update_dispute_case(case)
        self.audit.log_event(
            actor="system",
            action="dispute_resolved",
            resource=f"dispute:{case.id}",
            details={"resolution": resolution},
            correlation_id=case.correlation_id,
        )
        return case
