from typing import List, Dict, Any, Optional
from datetime import datetime
import uuid

from backend.models.audit import AuditLogEntry, AuditBundle


class AuditService:
    def __init__(self, store):
        self.store = store  # e.g. DB adapter, message bus, etc.

    def log_event(
        self,
        actor: str,
        action: str,
        resource: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> AuditLogEntry:
        entry = AuditLogEntry(
            id=str(uuid.uuid4()),
            timestamp=datetime.utcnow(),
            actor=actor,
            action=action,
            resource=resource,
            details=details or {},
            correlation_id=correlation_id,
            tags=tags or [],
        )
        self.store.save_audit_entry(entry)
        return entry

    def get_entries_by_correlation(self, correlation_id: str) -> List[AuditLogEntry]:
        return self.store.get_entries_by_correlation(correlation_id)

    def create_bundle(self, correlation_id: str) -> AuditBundle:
        entries = self.get_entries_by_correlation(correlation_id)
        bundle = AuditBundle(
            bundle_id=str(uuid.uuid4()),
            created_at=datetime.utcnow(),
            correlation_id=correlation_id,
            entries=entries,
        )
        self.store.save_audit_bundle(bundle)
        return bundle
