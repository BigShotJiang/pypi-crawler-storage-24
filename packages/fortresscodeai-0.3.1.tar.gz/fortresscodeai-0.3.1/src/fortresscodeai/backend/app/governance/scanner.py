from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Any, Iterable, Optional


class IssueSeverity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class IssueType(str, Enum):
    STATIC_CODE = "STATIC_CODE"
    DEPENDENCY = "DEPENDENCY"
    POLICY = "POLICY"


@dataclass
class GovernanceIssue:
    file: str
    line: int
    severity: IssueSeverity
    issue_type: IssueType
    code: str
    message: str
    context: Optional[str] = None


@dataclass
class GovernanceReport:
    issues: List[GovernanceIssue]

    @property
    def has_blocking_issues(self) -> bool:
        return any(i.severity in {IssueSeverity.HIGH, IssueSeverity.CRITICAL} for i in self.issues)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "issues": [
                {
                    "file": i.file,
                    "line": i.line,
                    "severity": i.severity.value,
                    "issue_type": i.issue_type.value,
                    "code": i.code,
                    "message": i.message,
                    "context": i.context,
                }
                for i in self.issues
            ]
        }


class HybridGovernanceScanner:
    """
    Hybrid governance scanner:
    - static-ish code checks
    - dependency checks
    - simple policy checks
    """

    def __init__(
        self,
        root_paths: Iterable[str],
        include_ext: Iterable[str] = (".py", ".txt", ".md", ".json", ".yaml", ".yml"),
    ):
        self.root_paths = list(root_paths)
        self.include_ext = set(include_ext)

    # ---------- Public API ----------

    def run(self) -> GovernanceReport:
        issues: List[GovernanceIssue] = []
        for path in self._iter_files():
            if path.endswith(".py"):
                issues.extend(self._scan_python_file(path))
            if os.path.basename(path) in ("requirements.txt", "pyproject.toml"):
                issues.extend(self._scan_dependencies(path))
            issues.extend(self._scan_policy(path))

        return GovernanceReport(issues=issues)

    # ---------- File iteration ----------

    def _iter_files(self) -> Iterable[str]:
        for root in self.root_paths:
            if os.path.isfile(root):
                if self._should_include(root):
                    yield root
                continue
            for dirpath, _, filenames in os.walk(root):
                for fname in filenames:
                    full = os.path.join(dirpath, fname)
                    if self._should_include(full):
                        yield full

    def _should_include(self, path: str) -> bool:
        _, ext = os.path.splitext(path)
        return ext in self.include_ext or os.path.basename(path) in (
            "requirements.txt",
            "pyproject.toml",
        )

    # ---------- Static-ish code checks ----------

    def _scan_python_file(self, path: str) -> List[GovernanceIssue]:
        issues: List[GovernanceIssue] = []
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
        except OSError:
            return issues

        secret_patterns = [
            (re.compile(r"AKIA[0-9A-Z]{16}"), "AWS_ACCESS_KEY"),
            (re.compile(r"(?i)api[_-]?key\s*=\s*['\"]"), "GENERIC_API_KEY"),
            (re.compile(r"(?i)secret\s*=\s*['\"]"), "GENERIC_SECRET"),
        ]

        for idx, line in enumerate(lines, start=1):
            stripped = line.strip()

            if "eval(" in stripped or "exec(" in stripped:
                issues.append(
                    GovernanceIssue(
                        file=path,
                        line=idx,
                        severity=IssueSeverity.HIGH,
                        issue_type=IssueType.STATIC_CODE,
                        code="UNSAFE_EVAL_EXEC",
                        message="Use of eval/exec detected. This is discouraged in governed environments.",
                        context=stripped[:200],
                    )
                )

            if "TODO" in stripped or "FIXME" in stripped:
                issues.append(
                    GovernanceIssue(
                        file=path,
                        line=idx,
                        severity=IssueSeverity.LOW,
                        issue_type=IssueType.STATIC_CODE,
                        code="TODO_FIXME",
                        message="TODO/FIXME comment present. Ensure this is tracked or resolved.",
                        context=stripped[:200],
                    )
                )

            for pattern, code in secret_patterns:
                if pattern.search(stripped):
                    issues.append(
                        GovernanceIssue(
                            file=path,
                            line=idx,
                            severity=IssueSeverity.CRITICAL,
                            issue_type=IssueType.STATIC_CODE,
                            code=f"HARDCODED_{code}",
                            message="Potential hardcoded secret detected.",
                            context=stripped[:200],
                        )
                    )

        return issues

    # ---------- Dependency checks ----------

    def _scan_dependencies(self, path: str) -> List[GovernanceIssue]:
        issues: List[GovernanceIssue] = []
        risky_packages = {
            "paramiko": "Known SSH-related library; ensure keys and hosts are governed.",
            "boto3": "AWS SDK; ensure credentials are managed via environment/roles, not hardcoded.",
            "requests": "Network access; ensure outbound calls are governed and logged.",
        }

        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except OSError:
            return issues

        for pkg, msg in risky_packages.items():
            if pkg in content:
                issues.append(
                    GovernanceIssue(
                        file=path,
                        line=1,
                        severity=IssueSeverity.MEDIUM,
                        issue_type=IssueType.DEPENDENCY,
                        code=f"RISKY_DEP_{pkg.upper()}",
                        message=f"Dependency '{pkg}' detected. {msg}",
                        context=None,
                    )
                )

        return issues

    # ---------- Policy checks ----------

    def _scan_policy(self, path: str) -> List[GovernanceIssue]:
        issues: List[GovernanceIssue] = []
        basename = os.path.basename(path)

        # Example: ensure no .env files are committed
        if basename.startswith(".env"):
            issues.append(
                GovernanceIssue(
                    file=path,
                    line=1,
                    severity=IssueSeverity.CRITICAL,
                    issue_type=IssueType.POLICY,
                    code="DOT_ENV_COMMITTED",
                    message=".env file detected in repository. Secrets should not be committed.",
                    context=None,
                )
            )

        # Example: simple JSON sanity check for policy/config files
        if basename.endswith(".json") and "policy" in basename.lower():
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    json.load(f)
            except Exception:
                issues.append(
                    GovernanceIssue(
                        file=path,
                        line=1,
                        severity=IssueSeverity.MEDIUM,
                        issue_type=IssueType.POLICY,
                        code="INVALID_POLICY_JSON",
                        message="Policy JSON file is invalid or unreadable.",
                        context=None,
                    )
                )

        return issues
