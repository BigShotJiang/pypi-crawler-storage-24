from __future__ import annotations
from datetime import datetime
from typing import Dict, List, Any

from .schema import PolicyVersion, Policy


class PolicyVersionStore:
    """
    Simple in-memory version store.
    Swap this for DB or file-backed storage later.
    """

    def __init__(self) -> None:
        self._versions: Dict[str, List[PolicyVersion]] = {}

    def add_version(self, policy: Policy, raw_data: Dict[str, Any]) -> None:
        pv = PolicyVersion(
            policy_id=policy.id,
            version=policy.version,
            data=raw_data,
            created_at=datetime.utcnow(),
            created_by=policy.created_by,
        )
        self._versions.setdefault(policy.id, [])
        self._versions[policy.id].append(pv)

    def get_versions(self, policy_id: str) -> List[PolicyVersion]:
        return self._versions.get(policy_id, [])

    def get_version(self, policy_id: str, version: str) -> PolicyVersion | None:
        for pv in self._versions.get(policy_id, []):
            if pv.version == version:
                return pv
        return None
