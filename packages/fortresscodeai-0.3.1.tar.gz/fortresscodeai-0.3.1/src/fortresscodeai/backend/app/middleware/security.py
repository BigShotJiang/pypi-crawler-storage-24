import time
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
import logging

logger = logging.getLogger("fortress.security.middleware")


class SecurityMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        path = request.url.path

        # Example: block obvious scanning attempts
        if any(p in path for p in ["..", "//", "/etc/passwd", "/.git"]):
            logger.warning(f"[SECURITY] Blocked suspicious path: {path}")
            return JSONResponse({"error": "forbidden"}, status_code=403)

        start = time.time()
        response = await call_next(request)
        duration = time.time() - start

        logger.info(f"[REQ] {request.method} {path} {response.status_code} {duration:.4f}s")

        return response
