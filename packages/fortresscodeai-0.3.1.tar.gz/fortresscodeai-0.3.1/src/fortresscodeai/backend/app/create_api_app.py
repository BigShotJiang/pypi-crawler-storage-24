from __future__ import annotations

import logging
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# -----------------------------
# Security Middleware
# -----------------------------
from fortresscodeai.backend.app.security.middleware import RBACMiddleware
from fortresscodeai.backend.app.middleware.security import SecurityMiddleware

# -----------------------------
# Orchestrator Services
# -----------------------------
from fortresscodeai.backend.app.orchestrator.policy_engine import PolicyEngine
from fortresscodeai.backend.app.orchestrator.hitl_manager import HITLManager
from fortresscodeai.backend.app.orchestrator.audit_trail import AuditTrail
from fortresscodeai.backend.app.orchestrator.security_events import SecurityEvents
from fortresscodeai.backend.app.orchestrator.secrets_manager import SecretsManager
from fortresscodeai.backend.app.orchestrator.execution_backend import ExecutionBackend
from fortresscodeai.backend.app.orchestrator.orchestrator import AutobuilderOrchestrator

# -----------------------------
# Governance Policies
# -----------------------------
from fortresscodeai.backend.app.governance.policies.registry import PolicyRegistry
from fortresscodeai.backend.app.governance.policies.loader import PolicyLoader
from fortresscodeai.backend.app.governance.policies.evaluator import PolicyEvaluator
from fortresscodeai.backend.app.governance.policies.versioning import PolicyVersionStore

# -----------------------------
# Workflow Engine + Storage
# -----------------------------
from fortresscodeai.backend.app.storage import Storage
from fortresscodeai.backend.app.workflows.workflow_engine import InMemoryDB, WorkflowEngine
from fortresscodeai.backend.app.workers.job_queue import JobQueue

# -----------------------------
# API Routers
# -----------------------------
from fortresscodeai.backend.app.api.workers.routes import router as workers_router
from fortresscodeai.backend.app.api.workers.events import worker_events_ws, worker_logs_ws
from fortresscodeai.backend.app.api.policies import router as policies_router
from fortresscodeai.backend.app.api.hitl import router as hitl_router
from fortresscodeai.backend.app.api.workflows import router as workflows_router
from fortresscodeai.backend.app.api.audit import router as audit_router
from fortresscodeai.backend.app.api.security import router as security_events_router
from fortresscodeai.backend.app.api.governance import router as governance_router

# -----------------------------
# Plugin System
# -----------------------------
from fortresscodeai.backend.app.plugins.plugin_registry import plugin_registry
from fortresscodeai.backend.app.plugins.plugin_loader import load_plugins

# -----------------------------
# Settings
# -----------------------------
from fortresscodeai.backend.app.api.dependencies.dependencies import get_settings


logger = logging.getLogger("fortress.api")
logger.setLevel(logging.INFO)


def create_api_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(title="FortressCodeAI Platform")

    # -----------------------------
    # Global Exception Handler
    # -----------------------------
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.exception("Unhandled error")
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error"},
        )

    # -----------------------------
    # Core Runtime Services
    # -----------------------------
    storage = Storage()
    workflow_db = InMemoryDB
    workflow_engine = WorkflowEngine(
        db=workflow_db,
        storage=storage,
        logger=logger.info,
    )
    job_queue = JobQueue()

    app.state.storage = storage
    app.state.workflow_db = workflow_db
    app.state.workflow_engine = workflow_engine
    app.state.job_queue = job_queue

    # -----------------------------
    # Security Middleware (must come BEFORE routers)
    # -----------------------------
    app.add_middleware(RBACMiddleware)
    app.add_middleware(SecurityMiddleware)

    # -----------------------------
    # CORS (strict in production)
    # -----------------------------
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOW_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
    )

    # -----------------------------
    # Workers API + WebSockets
    # -----------------------------
    app.include_router(workers_router, prefix="/api/workers", tags=["workers"])
    app.add_api_websocket_route("/ws/workers/events", worker_events_ws)
    app.add_api_websocket_route("/ws/workers/logs", worker_logs_ws)

    # -----------------------------
    # Orchestrator Services
    # -----------------------------
    policy_engine = PolicyEngine()
    hitl_manager = HITLManager()
    audit_trail = AuditTrail()
    security_events = SecurityEvents()
    secrets_manager = SecretsManager()
    execution_backend = ExecutionBackend()

    registry = PolicyRegistry()
    versions = PolicyVersionStore()
    loader = PolicyLoader(
        base_dir="backend/app/governance/policies/storage/policies",
        registry=registry,
    )
    evaluator = PolicyEvaluator(registry)

    orchestrator = AutobuilderOrchestrator(
        policy_engine=policy_engine,
        hitl_manager=hitl_manager,
        audit_trail=audit_trail,
        security_events=security_events,
        secrets_manager=secrets_manager,
        execution_backend=execution_backend,
    )

    app.state.orchestrator = orchestrator
    app.state.plugin_registry = plugin_registry
    app.state.audit_trail = audit_trail
    app.state.security_events = security_events

    # -----------------------------
    # Inject Governance Services into Routers
    # -----------------------------
    policies_router.registry = registry
    policies_router.loader = loader
    policies_router.evaluator = evaluator
    policies_router.versions = versions
    policies_router.audit_trail = audit_trail

    governance_router.evaluator = evaluator

    # -----------------------------
    # API Routers
    # -----------------------------
    app.include_router(workflows_router)
    app.include_router(audit_router)
    app.include_router(security_events_router)
    app.include_router(hitl_router)
    app.include_router(governance_router)
    app.include_router(policies_router)

    # -----------------------------
    # UI + Static Assets
    # -----------------------------
    app.mount("/static", StaticFiles(directory="backend/app/static"), name="static")
    app.mount("/ui", StaticFiles(directory="backend/app/ui"), name="ui")

    @app.get("/", include_in_schema=False)
    async def root():
        return FileResponse("backend/app/ui/app-shell/index.html")

    # -----------------------------
    # Load Policies
    # -----------------------------
    loader.load_all()

    # -----------------------------
    # Load Plugins
    # -----------------------------
    plugins_path = Path(settings.PLUGINS_PATH)
    loaded_plugins = load_plugins(plugins_path)

    for plugin in loaded_plugins:
        plugin_registry.register(plugin)

    for plugin in plugin_registry.plugins:
        if hasattr(plugin, "router"):
            app.include_router(plugin.router)

    # -----------------------------
    # Startup Hook
    # -----------------------------
    @app.on_event("startup")
    async def startup_event():
        logger.info("FortressCodeAI API Starting Up...")
        _ = secrets_manager.get_secret("platform_boot")
        logger.info("Secrets loaded")
        logger.info("Orchestrator ready")
        logger.info("Plugin registry initialized")

    return app
