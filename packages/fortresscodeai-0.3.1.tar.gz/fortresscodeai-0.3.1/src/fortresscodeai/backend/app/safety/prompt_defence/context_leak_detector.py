# src/safety_layer/prompt_defense/context_leak_detector.py

import re
from typing import List, Dict

LEAK_PATTERNS = [
    r"(?:previous|prior)\s+(?:response|answer|output)",
    r"(?:you said|you mentioned|you told me)",
    r"(?:as we discussed|as discussed earlier)",
    r"(?:in the last message|in the earlier prompt)",
    r"(?:remember when|remember that)",
    r"(?:continue from|pick up where we left off)",
]

def detect_context_leaks(prompt: str) -> List[str]:
    """Returns a list of matched leak patterns in the prompt."""
    leaks = []
    for pattern in LEAK_PATTERNS:
        if re.search(pattern, prompt, re.IGNORECASE):
            leaks.append(pattern)
    return leaks

def has_context_leak(prompt: str) -> bool:
    """Returns True if any context leak pattern is detected."""
    return len(detect_context_leaks(prompt)) > 0

def explain_leaks(prompt: str) -> Dict[str, List[str]]:
    """Returns a dictionary with matched patterns and examples."""
    matches = detect_context_leaks(prompt)
    return {
        "leak_patterns": matches,
        "example_snippets": [re.findall(pattern, prompt, re.IGNORECASE) for pattern in matches]
    }
