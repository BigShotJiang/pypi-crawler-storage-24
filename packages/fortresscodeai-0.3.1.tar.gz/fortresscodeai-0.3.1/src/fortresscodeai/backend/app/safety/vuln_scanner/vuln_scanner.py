# vuln_scanner.py
import re

def scan_diff(diff_text: str) -> list:
    issues = []
    if "eval(" in diff_text:
        issues.append({"type": "insecure_eval", "severity": "high", "line": find_line(diff_text, "eval(")})
    if re.search(r'os\.system\([^)]+\)', diff_text):
        issues.append({"type": "shell_injection", "severity": "medium"})
    if "open(" in diff_text and "'w'" in diff_text:
        issues.append({"type": "file_write", "severity": "low"})
    return issues

def find_line(text, pattern):
    for i, line in enumerate(text.splitlines()):
        if pattern in line:
            return i + 1
    return -1
