from typing import Dict, Any
from .engine import SafetyRule


def no_unapproved_model_access(context: Dict[str, Any]) -> bool:
    model = context.get("model")
    approved = context.get("approved_models", [])
    return model in approved


def no_sensitive_data_exfiltration(context: Dict[str, Any]) -> bool:
    payload = context.get("request_body", "")
    forbidden = ["SSN", "passport", "credit_card"]
    return not any(term in payload for term in forbidden)


SAFETY_RULES = [
    SafetyRule(
        name="no_unapproved_model_access",
        description="Agents may only use models approved by governance.",
        check_fn=no_unapproved_model_access,
    ),
    SafetyRule(
        name="no_sensitive_data_exfiltration",
        description="Requests must not contain sensitive identifiers.",
        check_fn=no_sensitive_data_exfiltration,
    ),
]
