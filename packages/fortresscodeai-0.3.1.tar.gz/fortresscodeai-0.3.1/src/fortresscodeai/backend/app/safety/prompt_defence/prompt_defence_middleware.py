# src/safety_layer/prompt_defense/prompt_defense_middleware.py

from .context_leak_detector import has_context_leak, explain_leaks
from .sanitizer import sanitize_prompt, contains_sensitive_data

class PromptDefenseResult:
    def __init__(self, prompt: str, modified: bool, blocked: bool, reason: str = ""):
        self.prompt = prompt
        self.modified = modified
        self.blocked = blocked
        self.reason = reason

    def to_dict(self):
        return {
            "prompt": self.prompt,
            "modified": self.modified,
            "blocked": self.blocked,
            "reason": self.reason
        }

def enforce_prompt_defense(raw_prompt: str) -> PromptDefenseResult:
    # Step 1: Detect context leaks
    if has_context_leak(raw_prompt):
        return PromptDefenseResult(
            prompt=raw_prompt,
            modified=False,
            blocked=True,
            reason="Context leak detected. Prompt references prior model output."
        )

    # Step 2: Sanitize sensitive content
    sanitized_prompt, modified = sanitize_prompt(raw_prompt)

    # Step 3: Final check for residual sensitive data
    if contains_sensitive_data(sanitized_prompt):
        return PromptDefenseResult(
            prompt=sanitized_prompt,
            modified=True,
            blocked=True,
            reason="Sanitized prompt still contains sensitive data."
        )

    return PromptDefenseResult(
        prompt=sanitized_prompt,
        modified=modified,
        blocked=False
    )
