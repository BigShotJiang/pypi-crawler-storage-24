# semantic_analyzer.py
import ast

def extract_data_flows(code: str):
    tree = ast.parse(code)
    flows = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func_name = None
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                func_name = node.func.attr
            if func_name:
                flows.append({"function": func_name, "line": node.lineno})
    return flows

