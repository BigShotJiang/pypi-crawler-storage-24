# src/safety_layer/prompt_defense/sanitizer.py

import re
from typing import Tuple

SENSITIVE_PATTERNS = {
    "api_keys": r"(?:api[_-]?key\s*[:=]\s*)[\"']?[A-Za-z0-9_\-]{16,}[\"']?",
    "emails": r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",
    "tokens": r"(?:bearer\s+)?[A-Za-z0-9\-_]{20,}\.[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}",
    "file_paths": r"(?:[A-Za-z]:)?(?:/|\\)[\w\-/\\\.]+",
    "secrets": r"(?:password|secret|token)[\"']?\s*[:=]\s*[\"']?.+?[\"']?",
}

REDACTION = "[REDACTED]"

def sanitize_prompt(prompt: str) -> Tuple[str, bool]:
    """Sanitizes sensitive content in the prompt and returns the cleaned version."""
    modified = False
    for label, pattern in SENSITIVE_PATTERNS.items():
        if re.search(pattern, prompt, re.IGNORECASE):
            prompt = re.sub(pattern, REDACTION, prompt, flags=re.IGNORECASE)
            modified = True
    return prompt, modified

def contains_sensitive_data(prompt: str) -> bool:
    """Checks if the prompt contains any sensitive patterns."""
    return any(re.search(p, prompt, re.IGNORECASE) for p in SENSITIVE_PATTERNS.values())
