# license_checker.py
import re

def detect_license_violations(code: str):
    if "GPL" in code or "GNU General Public License" in code:
        return [{"type": "license_violation", "license": "GPL", "severity": "high"}]
    return []
