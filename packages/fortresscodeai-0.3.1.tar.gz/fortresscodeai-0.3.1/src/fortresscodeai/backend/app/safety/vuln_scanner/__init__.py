from ....governance.scanner import SecurityScanner
from .semantic_analyzer import extract_data_flows
from .license_checker import detect_license_violations
