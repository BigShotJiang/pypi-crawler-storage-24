from typing import Dict, Any, List


class SafetyRuleViolation(Exception):
    pass


class SafetyRule:
    def __init__(self, name: str, description: str, check_fn):
        self.name = name
        self.description = description
        self.check_fn = check_fn

    def evaluate(self, context: Dict[str, Any]) -> Dict[str, Any]:
        result = self.check_fn(context)
        return {
            "rule": self.name,
            "description": self.description,
            "passed": result is True,
        }


class SafetyPolicyEngine:
    """
    Evaluates safety-layer rules that define what must NEVER occur.
    These rules are absolute constraints.
    """

    def __init__(self):
        self.rules: List[SafetyRule] = []

    def register_rule(self, rule: SafetyRule):
        self.rules.append(rule)

    def evaluate(self, context: Dict[str, Any]) -> Dict[str, Any]:
        results = []
        blocked = False

        for rule in self.rules:
            outcome = rule.evaluate(context)
            results.append(outcome)
            if not outcome["passed"]:
                blocked = True

        return {
            "blocked": blocked,
            "results": results,
        }
