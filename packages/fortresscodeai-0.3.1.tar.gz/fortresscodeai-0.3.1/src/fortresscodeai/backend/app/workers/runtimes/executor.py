from __future__ import annotations

import asyncio
from typing import Any, Dict

from ...models.task import Task, OutputType
from ..worker_registry import WORKER_REGISTRY
from ..prompt_renderer import build_worker_prompt


async def run_in_sandbox(task: Task, prompt: str) -> Dict[str, Any]:
    """
    Execute code or actions in a sandboxed environment.

    This is where you integrate your real execution backend:
    - containers
    - subprocess
    - remote runner
    - etc.
    """
    # Placeholder structure; replace with real sandbox integration.
    # Keep the shape stable so the rest of the system can rely on it.
    await asyncio.sleep(0)  # keep function async
    return {
        "stdout": "",
        "stderr": "Sandbox execution not yet implemented.",
        "exit_code": 1,
        "metadata": {
            "sandbox": "not_implemented",
        },
    }


async def executor_runtime(task: Task) -> Any:
    """
    Execution worker runtime.

    Uses the task + prompt to drive sandboxed execution.
    """
    cfg = WORKER_REGISTRY["executor"]
    prompt = build_worker_prompt(cfg, task)

    result = await run_in_sandbox(task, prompt)

    if task.output_format.type == OutputType.JSON:
        return result
    return str(result)
