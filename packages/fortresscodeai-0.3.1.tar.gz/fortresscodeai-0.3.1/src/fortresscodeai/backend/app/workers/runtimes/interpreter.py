from __future__ import annotations

from typing import Any, List, Dict

from ...models.task import Task
from ..worker_registry import WORKER_REGISTRY
from .base_runtime import call_llm, parse_llm_output
from ..prompt_renderer import build_worker_prompt


async def interpreter_runtime(task: Task) -> Any:
    """
    Interpreter worker runtime.

    Expects the LLM to return a JSON array of subtask specifications,
    each of which can be instantiated as a Task.
    """
    cfg = WORKER_REGISTRY["interpreter"]
    prompt = build_worker_prompt(cfg, task)
    raw = await call_llm(prompt)
    result = parse_llm_output(task, raw)

    if not isinstance(result, list):
        raise ValueError("Interpreter must return a JSON array of subtask specifications")

    # Basic structural sanity check
    for idx, sub in enumerate(result):
        if not isinstance(sub, dict):
            raise ValueError(f"Subtask at index {idx} is not a JSON object")

    return result
