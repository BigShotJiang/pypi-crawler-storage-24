from __future__ import annotations

import json
from typing import Any

from ...models.task import OutputType, Task
from ..prompt_renderer import build_worker_prompt


# You should implement this to call your actual LLM backend.
async def call_llm(prompt: str) -> str:
    """
    Call your LLM backend with the given prompt and return the raw string response.

    Replace this implementation with your real LLM client.
    """
    raise NotImplementedError("call_llm must be implemented with your LLM backend")


def parse_llm_output(task: Task, raw: str) -> Any:
    """
    Parse LLM output according to the task's output_format.
    """
    if task.output_format.type == OutputType.JSON:
        return json.loads(raw)
    if task.output_format.type in {OutputType.CODE, OutputType.MARKDOWN, OutputType.TEXT}:
        return raw
    return raw
