import logging
from backend.app.workers.runtime import create_worker_runtime

logger = logging.getLogger("fortress.worker")
logger.setLevel(logging.INFO)


def main():
    runtime = create_worker_runtime()
    worker = runtime["worker"]

    logger.info("🧵 Starting FortressCodeAI worker runtime...")
    worker.start()


if __name__ == "__main__":
    main()
