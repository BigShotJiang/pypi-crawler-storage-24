from __future__ import annotations

from typing import Any

from ...models.task import Task
from ..worker_registry import WORKER_REGISTRY
from .base_runtime import call_llm, parse_llm_output
from ..prompt_renderer import build_worker_prompt


async def researcher_runtime(task: Task) -> Any:
    """
    Research worker runtime.

    Expects the LLM to return structured research output matching the task's output_format.
    """
    cfg = WORKER_REGISTRY["researcher"]
    prompt = build_worker_prompt(cfg, task)
    raw = await call_llm(prompt)
    return parse_llm_output(task, raw)
