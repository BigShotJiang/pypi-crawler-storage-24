from __future__ import annotations

from typing import Dict, List, Literal, TypedDict, Optional

from ..models.task import TaskType


class WorkerConfig(TypedDict, total=True):
    id: str
    name: str
    role: str
    task_types: List[TaskType]
    policies: List[str]
    requires_hitl: bool
    max_concurrency: int
    timeout_seconds: int
    runtime: Literal["llm", "code", "hybrid"]
    enabled: bool
    tags: List[str]
    description: str
    version: str
    owner: str
    risk_profile: Literal["low", "medium", "high"]


WORKER_REGISTRY: Dict[str, WorkerConfig] = {
    "interpreter": {
        "id": "interpreter",
        "name": "Interpreter Worker",
        "role": (
            "Decompose complex tasks into smaller subtasks, "
            "propose routing, and never perform side‑effectful actions."
        ),
        "task_types": [TaskType.PLAN, TaskType.ROUTE],
        "policies": ["GOV-P1"],
        "requires_hitl": False,
        "max_concurrency": 8,
        "timeout_seconds": 30,
        "runtime": "llm",
        "enabled": True,
        "tags": ["orchestration", "planning", "routing"],
        "description": "High‑level planner and router; no direct execution.",
        "version": "1.0.0",
        "owner": "platform",
        "risk_profile": "low",
    },
    "researcher": {
        "id": "researcher",
        "name": "Research Worker",
        "role": (
            "Search, read, and synthesize information from allowed sources. "
            "No code execution or side effects."
        ),
        "task_types": [TaskType.RESEARCH],
        "policies": ["GOV-P1"],
        "requires_hitl": False,
        "max_concurrency": 16,
        "timeout_seconds": 60,
        "runtime": "llm",
        "enabled": True,
        "tags": ["research", "synthesis"],
        "description": "Retrieval and synthesis worker for knowledge tasks.",
        "version": "1.0.0",
        "owner": "platform",
        "risk_profile": "low",
    },
    "codegen": {
        "id": "codegen",
        "name": "Code Generation Worker",
        "role": (
            "Generate, refactor, and document code. "
            "Never execute code; produce safe, reviewable artifacts."
        ),
        "task_types": [TaskType.CODE, TaskType.REFACTOR],
        "policies": ["GOV-P1", "GOV-P3"],
        "requires_hitl": False,
        "max_concurrency": 8,
        "timeout_seconds": 90,
        "runtime": "llm",
        "enabled": True,
        "tags": ["code", "refactor", "documentation"],
        "description": "Specialized in code authoring and refactoring.",
        "version": "1.0.0",
        "owner": "devex",
        "risk_profile": "medium",
    },
    "executor": {
        "id": "executor",
        "name": "Execution Worker",
        "role": (
            "Execute code, run scripts, and call external APIs in a sandboxed environment. "
            "Always respect HITL and policy constraints."
        ),
        "task_types": [TaskType.EXECUTE],
        "policies": ["GOV-P3"],
        "requires_hitl": True,
        "max_concurrency": 4,
        "timeout_seconds": 120,
        "runtime": "code",
        "enabled": True,
        "tags": ["execution", "runtime", "sandbox"],
        "description": "Side‑effectful executor with strict governance controls.",
        "version": "1.0.0",
        "owner": "platform",
        "risk_profile": "high",
    },
    "validator": {
        "id": "validator",
        "name": "Validation Worker",
        "role": (
            "Validate outputs for correctness, safety, and policy compliance. "
            "Does not perform side effects."
        ),
        "task_types": [TaskType.VALIDATE],
        "policies": ["GOV-P1"],
        "requires_hitl": False,
        "max_concurrency": 16,
        "timeout_seconds": 45,
        "runtime": "llm",
        "enabled": True,
        "tags": ["validation", "compliance", "quality"],
        "description": "Cross‑checks worker outputs before they are returned or executed.",
        "version": "1.0.0",
        "owner": "platform",
        "risk_profile": "low",
    },
}


def get_worker_config(worker_id: str) -> Optional[WorkerConfig]:
    return WORKER_REGISTRY.get(worker_id)


def select_workers_for_task_type(task_type: TaskType) -> List[WorkerConfig]:
    """
    Return all workers capable of handling the given task_type and currently enabled.
    """
    return [
        cfg
        for cfg in WORKER_REGISTRY.values()
        if cfg["enabled"] and task_type in cfg["task_types"]
    ]
