"""
worker.py

Background worker for FortressCodeAI.

Responsibilities:
- Continuously pull jobs from the JobQueue
- Execute workflow runs via WorkflowEngine
- Log all actions for auditability
- Prevent crashes from propagating
"""

from __future__ import annotations

import threading
import traceback
from typing import Callable, Dict, Any

from backend.app.workflow_engine import WorkflowEngine
from backend.app.workers.job_queue import JobQueue


class Worker:
    """
    Long-running worker process.

    Each worker:
    - Runs in its own thread
    - Processes jobs sequentially
    - Can be scaled horizontally (multiple workers)
    """

    def __init__(
        self,
        job_queue: JobQueue,
        engine: WorkflowEngine,
        logger: Callable[[str], None],
    ):
        self.job_queue = job_queue
        self.engine = engine
        self.logger = logger
        self._stop_flag = False

    # --------------------------------------------------------
    # Worker lifecycle
    # --------------------------------------------------------

    def start(self) -> None:
        """
        Start the worker loop in a background thread.
        """
        t = threading.Thread(target=self._loop, daemon=True)
        t.start()
        self.logger("[worker] started")

    def stop(self) -> None:
        """
        Signal the worker to stop after the current job.
        """
        self._stop_flag = True
        self.logger("[worker] stop requested")

    # --------------------------------------------------------
    # Main loop
    # --------------------------------------------------------

    def _loop(self) -> None:
        while not self._stop_flag:
            job = self.job_queue.dequeue()
            try:
                self._process_job(job)
            except Exception as e:
                self.logger(f"[worker] job failed: {e}")
                traceback.print_exc()
            finally:
                self.job_queue.task_done()

    # --------------------------------------------------------
    # Job processing
    # --------------------------------------------------------

    def _process_job(self, job: Dict[str, Any]) -> None:
        job_type = job.get("type")

        if job_type == "workflow_run":
            run_id = job["run_id"]
            self.logger(f"[worker] processing workflow_run {run_id}")
            self.engine.execute_run(run_id)
            return

        raise ValueError(f"Unknown job type: {job_type}")
