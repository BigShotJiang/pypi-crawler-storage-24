from __future__ import annotations

from typing import Any, Dict

from ...models.task import Task, OutputType
from ..worker_registry import WORKER_REGISTRY
from .base_runtime import call_llm
from ..prompt_renderer import build_worker_prompt


async def validator_runtime(task: Task) -> Dict[str, Any]:
    """
    Validation worker runtime.

    Expects the LLM to return a JSON object:
    {
      "passed": bool,
      "reasons": [str, ...]
    }
    """
    cfg = WORKER_REGISTRY["validator"]
    prompt = build_worker_prompt(cfg, task)
    raw = await call_llm(prompt)

    if task.output_format.type != OutputType.JSON:
        raise ValueError("Validator tasks must use JSON output_format")

    import json

    data = json.loads(raw)

    if not isinstance(data, dict):
        raise ValueError("Validator must return a JSON object")

    if "passed" not in data or "reasons" not in data:
        raise ValueError("Validator output must contain 'passed' and 'reasons'")

    if not isinstance(data["passed"], bool):
        raise ValueError("'passed' must be a boolean")

    if not isinstance(data["reasons"], list):
        raise ValueError("'reasons' must be a list of strings")

    return data
