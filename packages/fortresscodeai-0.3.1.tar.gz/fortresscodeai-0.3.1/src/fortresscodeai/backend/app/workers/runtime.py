import logging

from backend.app.storage import Storage
from backend.app.workflow_engine import InMemoryDB, WorkflowEngine
from backend.app.workers.job_queue import JobQueue
from backend.app.workers.worker import Worker

logger = logging.getLogger("fortress.worker")
logger.setLevel(logging.INFO)


def create_worker_runtime():
    """
    Build an isolated worker runtime.

    Storage/JobQueue should be configured (via settings/env) to talk to
    the same backing services the API uses (e.g., Redis, DB, etc.).
    """
    storage = Storage()
    workflow_db = InMemoryDB
    workflow_engine = WorkflowEngine(
        db=workflow_db,
        storage=storage,
        logger=logger.info,
    )
    job_queue = JobQueue()
    worker = Worker(
        job_queue=job_queue,
        engine=workflow_engine,
        logger=logger.info,
    )

    return {
        "storage": storage,
        "workflow_db": workflow_db,
        "workflow_engine": workflow_engine,
        "job_queue": job_queue,
        "worker": worker,
    }
