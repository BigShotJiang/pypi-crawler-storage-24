from __future__ import annotations

from typing import Any

from ...models.task import Task
from ..worker_registry import WORKER_REGISTRY
from .base_runtime import call_llm, parse_llm_output
from ..prompt_renderer import build_worker_prompt


async def codegen_runtime(task: Task) -> Any:
    """
    Code generation worker runtime.

    Expects the LLM to return code or structured code artifacts
    matching the task's output_format.
    """
    cfg = WORKER_REGISTRY["codegen"]
    prompt = build_worker_prompt(cfg, task)
    raw = await call_llm(prompt)
    return parse_llm_output(task, raw)
