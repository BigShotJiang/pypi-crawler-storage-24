from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any

PROMPT_DIR = Path(__file__).parent / "prompts"


def load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"Prompt file not found: {path}")
    return path.read_text(encoding="utf-8")


def render_prompt(template: str, variables: Dict[str, Any]) -> str:
    """
    Simple variable substitution using {VAR_NAME} placeholders.
    """
    for key, value in variables.items():
        if isinstance(value, (dict, list)):
            value = json.dumps(value, indent=2)
        template = template.replace(f"{{{key}}}", str(value))
    return template


def build_worker_prompt(worker_cfg: Dict[str, Any], task: Any) -> str:
    """
    Build the final prompt for a worker by combining:
    - base worker prompt
    - worker-specific overlay
    - task JSON
    """
    base = load_prompt("worker_prompt.txt")
    overlay = load_prompt(f"{worker_cfg['id']}_overlay.txt")

    variables = {
        "WORKER_NAME": worker_cfg["name"],
        "WORKER_ROLE": worker_cfg["role"],
        "WORKER_TASK_TYPES": [t.value for t in worker_cfg["task_types"]],
        "GOVERNANCE_POLICIES": task.governance.policies,
        "TASK_OBJECTIVE": task.objective,
        "CONTEXT_BUSINESS": task.context.business or "",
        "CONTEXT_TECHNICAL": task.context.technical or "",
        "CONTEXT_CONSTRAINTS": task.context.constraints,
        "INPUTS": task.inputs.dict(),
        "REQUIREMENTS_MUST": task.requirements.must,
        "REQUIREMENTS_MUST_NOT": task.requirements.must_not,
        "QUALITY_BAR": task.requirements.quality_bar or "",
        "OUTPUT_FORMAT_SCHEMA": task.output_format.schema,
        "OUTPUT_FORMAT_TYPE": task.output_format.type.value,
        "TASK_JSON": task.to_worker_payload(),
        "WORKER_OVERLAY": overlay,
    }

    return render_prompt(base, variables)
