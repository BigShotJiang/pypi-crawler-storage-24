"""
job_queue.py

Simple, swappable job queue abstraction for FortressCodeAI.

This implementation uses an in-memory queue for local development.
In production, you can replace this with Redis, SQS, or any other backend
without changing the worker logic.
"""

from __future__ import annotations

import queue
from typing import Any, Dict


class JobQueue:
    """
    Minimal job queue with a blocking get().

    In production:
    - Replace enqueue() with a Redis LPUSH
    - Replace dequeue() with a Redis BRPOP
    """

    def __init__(self):
        self._q = queue.Queue()

    def enqueue(self, job: Dict[str, Any]) -> None:
        self._q.put(job)

    def dequeue(self) -> Dict[str, Any]:
        return self._q.get()

    def task_done(self) -> None:
        self._q.task_done()

    def join(self) -> None:
        self._q.join()
