from app.domain.policy import Policy, PolicyUpdate


class PolicyService:
    def list_policies(self) -> list[Policy]:
        return [
            Policy(
                id="pol-1",
                name="No PII in logs",
                description="Prevents logging of PII",
                enabled=True,
                tags=["privacy", "logging"],
            )
        ]

    def get_policy(self, policy_id: str) -> Policy:
        return self.list_policies()[0]

    def update_policy(self, policy_id: str, update: PolicyUpdate) -> Policy:
        base = self.get_policy(policy_id)
        data = base.dict()
        for k, v in update.dict(exclude_unset=True).items():
            data[k] = v
        return Policy(**data)
