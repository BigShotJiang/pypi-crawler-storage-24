from datetime import datetime

from app.domain.audit import AuditEntry


class AuditService:
    def list_entries(self, limit: int = 50) -> list[AuditEntry]:
        return [
            AuditEntry(
                id="audit-1",
                workflow_id="wf-1",
                step_name="analyze",
                user_id="user-1",
                timestamp=datetime.utcnow(),
                decision="ALLOW",
                risk_score=0.3,
                metadata={"source": "governance_manager"},
            )
        ]
