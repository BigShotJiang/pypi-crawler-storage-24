from datetime import datetime

from app.domain.security import SecurityEvent


class SecurityService:
    def list_events(self) -> list[SecurityEvent]:
        return [
            SecurityEvent(
                id="sec-1",
                workflow_id="wf-1",
                step_name="analyze",
                severity="high",
                category="policy_violation",
                message="Example security event",
                timestamp=datetime.utcnow(),
            )
        ]
