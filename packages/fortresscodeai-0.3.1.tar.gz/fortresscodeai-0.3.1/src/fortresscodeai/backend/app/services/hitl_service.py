from datetime import datetime

from app.domain.hitl import HITLItem


class HITLService:
    def list_items(self) -> list[HITLItem]:
        return [
            HITLItem(
                id="hitl-1",
                workflow_id="wf-1",
                step_name="analyze",
                user_id="user-1",
                reason="High risk score",
                created_at=datetime.utcnow(),
                context={"input": "example"},
            )
        ]
