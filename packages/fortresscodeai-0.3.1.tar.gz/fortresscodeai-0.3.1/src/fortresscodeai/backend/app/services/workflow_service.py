from datetime import datetime

from app.domain.workflow import WorkflowInstance, WorkflowStep


class WorkflowService:
    def list_recent(self) -> list[WorkflowInstance]:
        return [
            WorkflowInstance(
                id="wf-1",
                name="Demo Workflow",
                status="running",
                started_at=datetime.utcnow(),
                steps=[
                    WorkflowStep(name="ingest", status="completed"),
                    WorkflowStep(name="analyze", status="running", risk_score=0.3),
                ],
            )
        ]

    def get_trace(self, workflow_id: str) -> WorkflowInstance:
        return self.list_recent()[0]
