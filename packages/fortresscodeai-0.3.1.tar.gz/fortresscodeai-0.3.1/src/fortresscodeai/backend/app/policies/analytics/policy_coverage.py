def compute_policy_coverage(policies):
    """
    Computes how many policies apply to the workspace.
    """

    total = len(policies)
    applied = sum(1 for p in policies if p.get("rule"))

    coverage = (applied / total * 100) if total > 0 else 0

    return {
        "coverage": coverage,
        "policiesApplied": applied,
        "filesEvaluated": 0  # filled by real file scanning later
    }
