# backend/app/policies/router.py
from fastapi import APIRouter, Depends, HTTPException, status
from security.deps import require_roles, get_current_user
from security.models import Role, UserContext
from .schemas import PolicyUpdate

router = APIRouter(prefix="/api/policies", tags=["policies"])

# These are injected in create_api_app:
# router.registry
# router.loader
# router.evaluator
# router.versions


@router.get("/", dependencies=[Depends(require_roles(
    Role.admin, Role.security, Role.ops, Role.viewer
))])
async def list_policies(user: UserContext = Depends(get_current_user)):
    # registry should expose tenant-aware listing; if not, filter here
    policies = router.registry.list_policies(tenant_id=user.tenant_id)
    return policies


@router.get("/{policy_id}", dependencies=[Depends(require_roles(
    Role.admin, Role.security, Role.ops, Role.viewer
))])
async def get_policy(policy_id: str, user: UserContext = Depends(get_current_user)):
    policy = router.registry.get_policy(policy_id)
    if not policy or getattr(policy, "tenant_id", user.tenant_id) != user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not found")
    return policy


@router.put("/{policy_id}", dependencies=[Depends(require_roles(
    Role.admin, Role.security
))])
async def update_policy(
    policy_id: str,
    payload: PolicyUpdate,
    user: UserContext = Depends(get_current_user),
):
    policy = router.registry.get_policy(policy_id)
    if not policy or getattr(policy, "tenant_id", user.tenant_id) != user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not found")

    # You can decide whether to update via registry or loader/evaluator
    updated = router.registry.update_policy(
        policy_id=policy_id,
        tenant_id=user.tenant_id,
        data=payload.dict(),
    )

    # TODO: call your real audit trail service here
    # e.g. router.audit.log(...)

    return updated
