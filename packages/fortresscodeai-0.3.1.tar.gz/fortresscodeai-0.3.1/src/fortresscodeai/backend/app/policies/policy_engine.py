# src/fortresscodeai/backend/app/policies/policy_engine.py

from typing import Any, Dict, List
import json
import os
from typing import List, Dict, Any

POLICY_DIR = "policies"


def load_policies() -> List[Dict[str, Any]]:
    """
    Loads governance policies from the /policies directory.
    Policies are JSON files defining governance rules.
    """
    policies = []
    if not os.path.exists(POLICY_DIR):
        return []

    for file in os.listdir(POLICY_DIR):
        if file.endswith(".json"):
            with open(os.path.join(POLICY_DIR, file), "r") as f:
                policies.append(json.load(f))

    return policies


def evaluate_policies(policies: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluates governance policies against the workspace.
    Real logic: checks file patterns, metadata, dependency rules, etc.
    """

    results = []

    for policy in policies:
        rule = policy.get("rule", {})
        passed = True
        details = {}

        # Example: file pattern rule
        if "requiredFiles" in rule:
            missing = []
            for req in rule["requiredFiles"]:
                if not os.path.exists(req):
                    missing.append(req)
            if missing:
                passed = False
                details["missingFiles"] = missing

        # Example: dependency rule
        if "forbiddenDependencies" in rule:
            # Real logic: integrate with SBOM engine
            details["dependencyCheck"] = "integrated with SBOM engine"

        results.append({
            "policyId": policy["id"],
            "passed": passed,
            "details": details
        })

    return {"results": results}


class PolicyResult:
    def __init__(
        self,
        allowed: bool,
        reason: str,
        violated_policies: List[str] = None,
        requires_hitl: bool = False,
    ):
        self.allowed = allowed
        self.reason = reason
        self.violated_policies = violated_policies or []
        self.requires_hitl = requires_hitl


class PolicyEngine:
    def __init__(self):
        # Future: load policies from DB, YAML, or admin UI
        self.policies = [
            self._deny_sensitive_operations,
            self._require_hitl_for_high_risk,
        ]

    def evaluate(
        self,
        workflow_id: str,
        step_name: str,
        user_id: str,
        agent_context: Dict[str, Any],
        input_data: Dict[str, Any],
        risk_score: float,
    ) -> PolicyResult:

        violated = []
        requires_hitl = False

        for policy in self.policies:
            result = policy(
                workflow_id=workflow_id,
                step_name=step_name,
                user_id=user_id,
                agent_context=agent_context,
                input_data=input_data,
                risk_score=risk_score,
            )

            if result.get("violation"):
                violated.append(result["policy"])
                if result.get("requires_hitl"):
                    requires_hitl = True

        if violated:
            return PolicyResult(
                allowed=False,
                reason="Policy violations detected",
                violated_policies=violated,
                requires_hitl=requires_hitl,
            )

        return PolicyResult(
            allowed=True,
            reason="All policies satisfied",
            violated_policies=[],
            requires_hitl=False,
        )

    # Example policies

    def _deny_sensitive_operations(self, **kwargs):
        step = kwargs["step_name"].lower()
        if step in {"run_shell", "execute_code"}:
            return {"violation": True, "policy": "deny_sensitive_operations"}
        return {"violation": False}

    def _require_hitl_for_high_risk(self, **kwargs):
        if kwargs["risk_score"] >= 0.7:
            return {
                "violation": True,
                "policy": "high_risk_requires_hitl",
                "requires_hitl": True,
            }
        return {"violation": False}
