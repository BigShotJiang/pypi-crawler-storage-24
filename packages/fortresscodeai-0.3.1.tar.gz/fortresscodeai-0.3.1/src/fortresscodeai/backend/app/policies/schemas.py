# backend/app/policies/schemas.py
from pydantic import BaseModel, Field

class PolicyUpdate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=2000)
    severity: str = Field(pattern="^(low|medium|high|critical)$")
    trigger: str = Field(pattern="^(pre|post|both)$")
    raw: str

    class Config:
        extra = "forbid"
