import json
import os

DIFF_FILE = "policy_history.json"


def compute_policy_diff():
    """
    Compares current policies to last known version.
    """

    if not os.path.exists(DIFF_FILE):
        return {"message": "No policy history available."}

    with open(DIFF_FILE, "r") as f:
        history = json.load(f)

    return {
        "previous": history.get("previous", []),
        "current": history.get("current", []),
        "diff": history.get("diff", {})
    }
