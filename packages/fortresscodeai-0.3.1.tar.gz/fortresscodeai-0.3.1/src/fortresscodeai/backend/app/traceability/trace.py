from fastapi import APIRouter

from app.domain.workflow import WorkflowInstance
from app.services.workflow_service import WorkflowService

router = APIRouter(prefix="/api/traceability", tags=["traceability"])
_service = WorkflowService()


@router.get("/trace/{workflow_id}", response_model=WorkflowInstance)
def get_workflow_trace(workflow_id: str):
    return _service.get_trace(workflow_id)
