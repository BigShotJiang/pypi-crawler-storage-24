# src/fortresscodeai/backend/app/traceability/lineage.py

from datetime import datetime
from typing import Any, Dict


class LineageTracker:
    def __init__(self):
        # Future: store lineage in DB or object storage
        pass

    def record_step(
        self,
        workflow_id: str,
        step_name: str,
        input_data: Dict[str, Any],
        policy_result: Any,
        risk_score: float,
        timestamp: datetime,
    ) -> Dict[str, Any]:
        """
        Return explainability metadata for this workflow step.
        """

        return {
            "workflow_id": workflow_id,
            "step_name": step_name,
            "timestamp": timestamp.isoformat(),
            "input_summary": self._summarize_input(input_data),
            "risk_score": risk_score,
            "policy_decision": {
                "allowed": policy_result.allowed,
                "reason": policy_result.reason,
                "violated_policies": policy_result.violated_policies,
            },
        }

    def _summarize_input(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Summarize input data for explainability without exposing sensitive fields.
        """

        redacted = {}
        for key, value in input_data.items():
            if key.lower() in {"password", "ssn", "credit_card", "api_key"}:
                redacted[key] = "***REDACTED***"
            else:
                redacted[key] = value

        return redacted
