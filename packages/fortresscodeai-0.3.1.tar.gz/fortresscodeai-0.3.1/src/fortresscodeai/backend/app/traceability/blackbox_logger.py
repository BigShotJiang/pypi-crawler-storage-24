import json
import os
import threading
from datetime import datetime
from typing import Any, Dict, Optional

LOG_DIR = os.path.join(os.path.dirname(__file__), '../../logs')
LOG_FILE = os.path.join(LOG_DIR, 'blackbox.log')
_lock = threading.Lock()


def ensure_log_directory():
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)


def log_event(event_type: str, payload: Dict[str, Any], user_id: Optional[str] = None):
    """
    Logs a structured blackbox event to disk.

    Args:
        event_type (str): A short identifier for the event (e.g., 'policy_eval', 'auth_failure').
        payload (dict): Arbitrary structured data related to the event.
        user_id (str, optional): ID of the user associated with the event.
    """
    ensure_log_directory()

    entry = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "event_type": event_type,
        "user_id": user_id or "anonymous",
        "payload": payload
    }

    line = json.dumps(entry)

    with _lock:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(line + '\n')


def read_logs(limit: int = 100) -> list[Dict[str, Any]]:
    """
    Reads the most recent blackbox log entries.

    Args:
        limit (int): Maximum number of entries to return.

    Returns:
        List of parsed log entries.
    """
    if not os.path.exists(LOG_FILE):
        return []

    with _lock:
        with open(LOG_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()

    return [json.loads(line) for line in lines[-limit:]]
