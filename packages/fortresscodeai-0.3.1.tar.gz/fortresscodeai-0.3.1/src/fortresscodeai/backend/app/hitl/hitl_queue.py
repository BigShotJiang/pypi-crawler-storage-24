from typing import Any, Dict, List, Optional
from datetime import datetime
from .storage import storage
from .dependencies import get_settings


class HITLQueue:
    def __init__(self):
        self.settings = get_settings()
        self.namespace = f"{self.settings.STORAGE_NAMESPACE}_hitl"

    def enqueue(self, item: Dict[str, Any]) -> Dict[str, Any]:
        item.setdefault("status", "pending")
        item.setdefault("created_at", datetime.utcnow().isoformat())
        return storage.save(self.namespace, "queue", item)

    def list(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        items = storage.list(self.namespace, "queue")
        if status:
            items = [i for i in items if i.get("status") == status]
        return items

    def update_status(self, id_: str, status: str, operator: Optional[str] = None) -> None:
        item = storage.get(self.namespace, "queue", id_)
        if not item:
            return
        item["status"] = status
        if operator:
            item["operator"] = operator
        item["updated_at"] = datetime.utcnow().isoformat()
        storage.save(self.namespace, "queue", item)


hitl_queue = HITLQueue()
