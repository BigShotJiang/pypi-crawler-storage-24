from fastapi import APIRouter

from app.domain.hitl import HITLItem
from app.services.hitl_service import HITLService

router = APIRouter(prefix="/api/hitl", tags=["hitl"])
_service = HITLService()


@router.get("/queue", response_model=list[HITLItem])
def get_hitl_queue():
    return _service.list_items()
