WORKFLOW_READ = "workflow:read"
WORKFLOW_RUN = "workflow:run"
WORKFLOW_MANAGE = "workflow:manage"

HITL_APPROVE = "hitl:approve"

AUDIT_READ = "audit:read"
SECURITY_READ = "security:read"

GOVERNANCE_READ = "governance:read"
IMPACT_READ = "impact:read"
