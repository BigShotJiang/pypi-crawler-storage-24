from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, List

from jinja2 import Environment, FileSystemLoader, select_autoescape
import os

from .enrichment import LeadProfile
from .insights import LeadInsights


@dataclass
class LeadIntelligencePacket:
    markdown: str
    audit_log: Dict[str, Any]


def _create_env() -> Environment:
    """
    Create a Jinja2 environment pointing to the shared templates directory.
    """
    base_dir = os.path.dirname(os.path.dirname(__file__))  # fortress/autobuilder
    templates_dir = os.path.join(base_dir, "shared", "templates")

    env = Environment(
        loader=FileSystemLoader(templates_dir),
        autoescape=select_autoescape(enabled_extensions=("html", "xml")),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    return env


def render_packet(
    profile: LeadProfile,
    insights: LeadInsights,
    outreach: str,
    audit_log: Dict[str, Any],
) -> LeadIntelligencePacket:
    """
    Render the Lead Intelligence Packet markdown using the Jinja2 template.
    """
    env = _create_env()
    template = env.get_template("lead_packet.md.j2")

    profile_summary = _build_profile_summary(profile)
    suggested_next_steps: List[str] = [
        "Send initial outreach email.",
        "If no response in 5–7 days, send a gentle follow-up.",
        "If interest is shown, schedule a short call or async walkthrough.",
    ]

    markdown = template.render(
        profile=profile,
        insights=insights,
        outreach=outreach,
        audit=audit_log,
        profile_summary=profile_summary,
        suggested_next_steps=suggested_next_steps,
    )

    return LeadIntelligencePacket(markdown=markdown, audit_log=audit_log)


def _build_profile_summary(profile: LeadProfile) -> str:
    """
    Build a concise 3–4 sentence profile summary.
    """
    parts = []

    if profile.name:
        parts.append(f"{profile.name} is a key stakeholder")
        if profile.role:
            parts[-1] += f" in the role of {profile.role}"
        if profile.company:
            parts[-1] += f" at {profile.company}."
        else:
            parts[-1] += "."
    elif profile.company:
        parts.append(f"This lead is associated with {profile.company}.")
    else:
        parts.append("This lead has limited available profile information.")

    if profile.industry:
        parts.append(f"The company operates in the {profile.industry} space.")
    if profile.description:
        parts.append(f"Current focus: {profile.description}.")
    if profile.recent_activity:
        parts.append("Recent activity suggests ongoing initiatives or interest in operational efficiency and automation.")

    if not parts:
        parts.append("Basic profile information is limited; treat this as an exploratory outreach opportunity.")

    return " ".join(parts)
