"""
Autobuilder package entrypoint.

Houses internal, governance-first autobuild modules (lead enrichment, workflows, docs, etc.).
"""
