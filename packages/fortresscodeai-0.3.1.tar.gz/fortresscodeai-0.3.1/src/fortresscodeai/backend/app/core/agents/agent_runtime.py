"""
agent_runtime.py

Secure, policy-driven agent runtime for FortressCodeAI.

Responsibilities:
- Enforce tenant isolation and sandboxing
- Load and apply agent policies (tools, limits, network)
- Build a controlled toolset for the agent
- Orchestrate LLM calls (currently via a pluggable client)
- Log all significant actions for auditability

This runtime is the core of your "agent sandboxing" story for pen-tests.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable

from .dependencies import get_settings
from .storage import Storage
from .tools import build_tools, ToolError, ToolSecurityError


# ------------------------------------------------------------
# Agent policy and definition
# ------------------------------------------------------------

@dataclass
class AgentPolicy:
    """
    Policy envelope for an agent.

    Controls:
    - Which tools are allowed
    - Max tokens per call
    - Max steps per run
    - Whether network access is allowed
    - Optional network allowlist
    """

    allowed_tools: List[str] = field(default_factory=list)
    max_tokens: int = 4096
    max_steps: int = 4
    allow_network: bool = False
    network_allowlist: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentPolicy":
        return cls(
            allowed_tools=data.get("allowed_tools", []),
            max_tokens=int(data.get("max_tokens", 4096)),
            max_steps=int(data.get("max_steps", 4)),
            allow_network=bool(data.get("allow_network", False)),
            network_allowlist=list(data.get("network_allowlist", [])),
        )


@dataclass
class AgentDefinition:
    """
    Canonical agent definition.

    Expected shape of your "agents" table / config:
    - id: unique identifier
    - name: human-readable name
    - prompt: system prompt / instructions
    - policy: dict -> AgentPolicy
    """

    id: str
    name: str
    prompt: str
    policy: AgentPolicy

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentDefinition":
        policy = AgentPolicy.from_dict(data.get("policy", {}))
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            prompt=data.get("prompt", "You are an agent."),
            policy=policy,
        )


# ------------------------------------------------------------
# LLM client abstraction (fake implementation for now)
# ------------------------------------------------------------

class LLMClient:
    """
    Pluggable LLM client abstraction.

    For now, this is a fake implementation that echoes back the payload.
    Later, you can replace this with a real provider (OpenAI, Azure, etc.)
    without changing the AgentRuntime.
    """

    def __init__(self, logger: Callable[[str], None]):
        self.logger = logger

    def call(
        self,
        system_prompt: str,
        task_payload: Dict[str, Any],
        tools: Dict[str, Callable],
        max_tokens: int,
    ) -> Dict[str, Any]:
        """
        Fake LLM call.

        A real implementation would:
        - Serialize tools as function definitions
        - Call the provider with tool support
        - Execute tool calls as requested
        - Return the final structured result
        """
        self.logger("[llm] fake call invoked (replace with real provider)")

        # For now, just echo back the payload and list tools.
        return {
            "summary": "Fake LLM response. Replace LLMClient.call() with a real implementation.",
            "task_payload": task_payload,
            "available_tools": list(tools.keys()),
            "max_tokens_used": min(max_tokens, 512),
        }


# ------------------------------------------------------------
# Agent runtime
# ------------------------------------------------------------

class AgentRuntime:
    """
    Secure execution environment for a single agent run.

    Lifecycle:
    - Initialize with tenant_id, agent_def, workflow context, storage, logger
    - Create a per-run sandbox directory
    - Build a policy-bound toolset
    - Call the LLM client with the system prompt + task payload + tools
    - Return a structured result

    This class is the core of your "agent sandboxing" story.
    """

    def __init__(
        self,
        tenant_id: str,
        agent_def: Dict[str, Any],
        workflow_ctx: Dict[str, Any],
        storage: Storage,
        logger: Callable[[str], None],
    ):
        self.tenant_id = tenant_id
        self.agent = AgentDefinition.from_dict(agent_def)
        self.workflow_ctx = workflow_ctx
        self.storage = storage
        self.logger = logger

        settings = get_settings()
        self.sandbox_root = Path(getattr(settings, "AGENT_SANDBOX_PATH", "./workspaces")).resolve()

        self.policy = self.agent.policy
        self.sandbox_path = self._init_sandbox()
        self.tools = self._build_tools()
        self.llm_client = LLMClient(logger=self._log)

    # --------------------------------------------------------
    # Internal helpers
    # --------------------------------------------------------

    def _log(self, message: str) -> None:
        self.logger(f"[agent:{self.agent.id}] {message}")

    def _init_sandbox(self) -> Path:
        """
        Create a per-run sandbox directory for this agent execution.
        """
        run_id = str(uuid.uuid4())
        path = self.sandbox_root / self.tenant_id / run_id
        path.mkdir(parents=True, exist_ok=True)
        self._log(f"sandbox created at {path}")
        return path.resolve()

    def _build_tools(self) -> Dict[str, Callable]:
        """
        Build the policy-bound toolset for this agent.
        """
        network_allowlist: Optional[List[str]] = None
        if self.policy.allow_network:
            network_allowlist = self.policy.network_allowlist

        tools = build_tools(
            tenant_id=self.tenant_id,
            sandbox_path=self.sandbox_path,
            storage=self.storage,
            logger=self._log,
            allowed_tools=self.policy.allowed_tools,
            network_allowlist=network_allowlist,
        )

        self._log(f"tools enabled: {list(tools.keys())}")
        return tools

    def _build_system_prompt(self) -> str:
        """
        Build the final system prompt for the agent.
        You can enrich this with tenant/workflow context if desired.
        """
        base = self.agent.prompt
        # You can inject governance / safety instructions here if you want.
        safety_suffix = (
            "\n\n"
            "You must strictly follow the provided tools and never attempt to access resources "
            "outside the sandbox or tenant context. If a requested action is not possible with "
            "the available tools, explain that clearly."
        )
        return base + safety_suffix

    # --------------------------------------------------------
    # Public API
    # --------------------------------------------------------

    def run(self, task_payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the agent with the given task payload.

        Returns a structured result that can be stored in workflow context.
        """
        self._log(
            f"run started for tenant={self.tenant_id}, "
            f"agent={self.agent.name}, "
            f"max_tokens={self.policy.max_tokens}, "
            f"max_steps={self.policy.max_steps}"
        )

        system_prompt = self._build_system_prompt()

        try:
            result = self.llm_client.call(
                system_prompt=system_prompt,
                task_payload=task_payload,
                tools=self.tools,
                max_tokens=self.policy.max_tokens,
            )
        except (ToolError, ToolSecurityError) as e:
            self._log(f"tool error: {e}")
            return {
                "status": "error",
                "error_type": "tool_error",
                "message": str(e),
            }
        except Exception as e:
            self._log(f"runtime error: {e}")
            return {
                "status": "error",
                "error_type": "runtime_error",
                "message": str(e),
            }

        self._log("run completed successfully")

        return {
            "status": "ok",
            "agent_id": self.agent.id,
            "agent_name": self.agent.name,
            "sandbox_path": str(self.sandbox_path),
            "result": result,
        }
