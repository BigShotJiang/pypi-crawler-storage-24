from fastapi import HTTPException, status

from ...app.models.models import RoleEnum, User


def can_perform(role: RoleEnum, permission: str) -> bool:
    hierarchy = [RoleEnum.viewer, RoleEnum.member, RoleEnum.admin, RoleEnum.owner]

    def at_least(r: RoleEnum, target: RoleEnum) -> bool:
        return hierarchy.index(r) >= hierarchy.index(target)

    if permission == "use_product":
        return at_least(role, RoleEnum.viewer)
    if permission == "view_audit":
        return at_least(role, RoleEnum.admin)
    if permission == "manage_users":
        return at_least(role, RoleEnum.admin)
    if permission == "manage_billing":
        return at_least(role, RoleEnum.owner)
    return False


def require_permission(user: User | None, permission: str):
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="UNAUTHENTICATED",
        )
    if not can_perform(user.role, permission):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="FORBIDDEN",
        )
