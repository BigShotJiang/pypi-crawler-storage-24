import logging
import json
import os
from datetime import datetime


class JsonFormatter(logging.Formatter):
    def format(self, record):
        payload = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload)


class HumanFormatter(logging.Formatter):
    def __init__(self):
        super().__init__(
            fmt="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )


def setup_logging():
    env = os.getenv("FORTRESS_ENV", "development").lower()

    root = logging.getLogger()
    root.setLevel(logging.INFO)

    handler = logging.StreamHandler()

    if env == "production":
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(HumanFormatter())

    root.handlers.clear()
    root.addHandler(handler)


setup_logging()
logger = logging.getLogger("fortress")
