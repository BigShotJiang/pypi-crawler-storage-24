from __future__ import annotations

from typing import Dict, Any

from .normalization import normalize_input
from .enrichment import enrich_lead
from .insights import generate_insights
from .outreach import draft_outreach
from .audit import build_audit_log
from .renderer import render_packet, LeadIntelligencePacket


def build_lead_packet(raw_input: Dict[str, Any]) -> LeadIntelligencePacket:
    """
    Main entrypoint for the lead autobuilder.

    - Normalizes input
    - Enriches lead profile
    - Generates insights
    - Drafts outreach
    - Builds audit log
    - Renders markdown packet
    """
    normalized = normalize_input(raw_input)
    profile = enrich_lead(normalized)
    insights = generate_insights(profile)
    outreach = draft_outreach(profile, insights)
    audit_log = build_audit_log(normalized, profile, insights)
    packet = render_packet(profile, insights, outreach, audit_log)
    return packet
