from typing import Any, Dict, List, Optional
from pydantic import BaseModel
from datetime import datetime
from enum import Enum


class BuildStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    FAILED = "failed"
    COMPLETED = "completed"
    BLOCKED_HITL = "blocked_hitl"


class BuildRequest(BaseModel):
    id: str
    created_at: datetime
    requested_by: str
    blueprint: Dict[str, Any]
    correlation_id: str


class BuildArtifact(BaseModel):
    id: str
    build_id: str
    created_at: datetime
    artifact_type: str  # e.g. "agent", "workflow", "test_suite"
    content: Dict[str, Any]
