from backend.src.domain.platform.models_repo_policy import RepoConnection, PolicyConfig
from backend.src.domain.models.user import User
from backend.src.domain.models.audit_event import AuditEvent
from backend.src.domain.workers.models_settings import ModelSettings
from backend.src.platform.models_repo_policy import RepoPolicyModel

MODEL_COLLECTION_MAP = {
    RepoConnection: "repo_connections",
    PolicyConfig: "policy_configs",
    User: "users",
    AuditEvent: "audit_events",
    ModelSettings: "model_settings",
    RepoPolicyModel: "repo_policy",
}

def get_collection_for_model(model_cls):
    return MODEL_COLLECTION_MAP.get(model_cls)
