from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from ...app.models.models import AuditEvent, User


class AuditLogger:
    def __init__(self, db: Session):
        self.db = db

    def log(
        self,
        *,
        org_id=None,
        user: User | None = None,
        type: str,
        entity_type: str,
        entity_id=None,
        metadata: dict[str, Any] | None = None,
        version: int | None = None,
    ) -> AuditEvent:
        event = AuditEvent(
            org_id=org_id,
            user_id=user.id if user else None,
            type=type,
            entity_type=entity_type,
            entity_id=entity_id,
            metadata=metadata or {},
            version=version,
        )
        self.db.add(event)
        self.db.commit()
        self.db.refresh(event)
        return event

    def history(self, entity_type: str, entity_id) -> list[AuditEvent]:
        return (
            self.db.query(AuditEvent)
            .filter(
                AuditEvent.entity_type == entity_type,
                AuditEvent.entity_id == entity_id,
            )
            .order_by(AuditEvent.created_at.asc())
            .all()
        )


class VersioningService:
    def __init__(self, audit: AuditLogger):
        self.audit = audit

    def record_version(
        self,
        *,
        entity_type: str,
        entity,
        org_id=None,
        user: User | None = None,
        version: int,
        diff: dict[str, Any] | None = None,
    ):
        self.audit.log(
            org_id=org_id,
            user=user,
            type="version_update",
            entity_type=entity_type,
            entity_id=getattr(entity, "id"),
            metadata={"diff": diff or {}},
            version=version,
        )
