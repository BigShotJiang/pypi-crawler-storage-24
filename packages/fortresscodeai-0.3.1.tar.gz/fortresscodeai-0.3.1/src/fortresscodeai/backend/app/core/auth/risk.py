from backend.app.core.auth.user import User
from backend.app.core.auth.context import RequestContext


def compute_risk_score(user: User, ctx: RequestContext) -> float:
    """
    Compute a contextual risk score for this request.

    This is intentionally simple but structured so you can
    tune weights and add more factors over time.
    """
    score = 0.0

    # Privileged roles start with higher baseline risk
    if user.role in {"security", "operations_manager"}:
        score += 1.0

    # Example: non-internal IPs considered higher risk (placeholder logic)
    if not ctx.ip.startswith("10."):
        score += 2.0

    # Sensitive paths
    if ctx.path.startswith("/security") or ctx.path.startswith("/audit"):
        score += 1.5

    # Suspicious user agents (curl, unknown tools, etc.)
    if "curl" in ctx.user_agent.lower():
        score += 1.0

    return score
