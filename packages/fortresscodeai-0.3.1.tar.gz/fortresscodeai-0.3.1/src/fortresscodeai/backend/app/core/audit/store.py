import json
import os
from datetime import datetime
from typing import Dict, List, Any

# Path to the audit log file (append-only JSONL)
AUDIT_LOG_PATH = "backend/app/data/audit.log"


def _ensure_log_exists():
    """Ensure the audit log file and directory exist."""
    os.makedirs(os.path.dirname(AUDIT_LOG_PATH), exist_ok=True)
    if not os.path.exists(AUDIT_LOG_PATH):
        with open(AUDIT_LOG_PATH, "w", encoding="utf-8") as f:
            f.write("")


def write_event(event_type: str, actor: str, details: Dict[str, Any]):
    """
    Append a new audit event to the ledger.
    Each event is immutable and stored as a JSON line.
    """
    _ensure_log_exists()

    record = {
        "id": f"audit-{int(datetime.utcnow().timestamp() * 1000)}",
        "event_type": event_type,
        "actor": actor,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "details": details,
    }

    with open(AUDIT_LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

    return record


def read_events(limit: int = 200) -> List[Dict[str, Any]]:
    """
    Read the most recent audit events from the ledger.
    """
    _ensure_log_exists()

    events: List[Dict[str, Any]] = []

    with open(AUDIT_LOG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    return events[-limit:]
