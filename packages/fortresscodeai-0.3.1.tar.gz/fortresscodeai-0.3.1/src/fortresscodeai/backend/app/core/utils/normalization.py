from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class NormalizedLeadInput:
    """
    Normalized representation of a lead, regardless of how it was originally provided.
    """
    name: Optional[str] = None
    company: Optional[str] = None
    linkedin_url: Optional[str] = None
    email_domain: Optional[str] = None
    raw_input: Dict[str, Any] = field(default_factory=dict)
    confidence: Dict[str, float] = field(default_factory=dict)


def normalize_input(raw: Dict[str, Any]) -> NormalizedLeadInput:
    """
    Normalize raw lead input into a consistent structure.

    Accepts:
    - linkedin_url
    - name
    - company
    - email_domain
    """
    name = raw.get("name")
    company = raw.get("company")
    linkedin_url = raw.get("linkedin_url")
    email_domain = raw.get("email_domain")

    confidence: Dict[str, float] = {}

    if name:
        confidence["name"] = 0.9
    if company:
        confidence["company"] = 0.8
    if linkedin_url:
        confidence["linkedin_url"] = 1.0
    if email_domain:
        confidence["email_domain"] = 0.7

    return NormalizedLeadInput(
        name=name,
        company=company,
        linkedin_url=linkedin_url,
        email_domain=email_domain,
        raw_input=raw,
        confidence=confidence,
    )
