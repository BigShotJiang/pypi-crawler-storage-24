from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from .normalization import NormalizedLeadInput


@dataclass
class LeadProfile:
    name: Optional[str] = None
    role: Optional[str] = None
    seniority: Optional[str] = None
    company: Optional[str] = None
    industry: Optional[str] = None
    size: Optional[str] = None
    description: Optional[str] = None
    recent_activity: List[str] = field(default_factory=list)
    funding_stage: Optional[str] = None


def enrich_lead(normalized: NormalizedLeadInput) -> LeadProfile:
    """
    Enrich lead with basic, heuristic data.

    In production, this is where you'd:
    - call external APIs
    - query internal knowledge
    - use LLMs to infer role/seniority from title, etc.
    """
    # For now, we infer minimal things heuristically.
    company = normalized.company
    name = normalized.name

    # Very naive heuristics; replace with real logic later.
    industry = None
    size = None
    description = None
    funding_stage = None
    recent_activity: list[str] = []

    role = None
    seniority = None

    if name:
        # Example: "Head of Engineering", "CTO", etc. could be parsed later.
        role = normalized.raw_input.get("role") or None

    return LeadProfile(
        name=name,
        role=role,
        seniority=seniority,
        company=company,
        industry=industry,
        size=size,
        description=description,
        recent_activity=recent_activity,
        funding_stage=funding_stage,
    )
