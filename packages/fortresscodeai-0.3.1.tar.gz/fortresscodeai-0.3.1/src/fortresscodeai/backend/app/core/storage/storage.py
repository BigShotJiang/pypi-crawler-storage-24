from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from cryptography.fernet import Fernet, InvalidToken  # pip install cryptography

from .dependencies import get_settings


# ------------------------------------------------------------
# Exceptions
# ------------------------------------------------------------

class StorageError(Exception):
    """Base class for storage-related errors."""


class StorageNotFound(StorageError):
    """Raised when a key does not exist."""


class StorageSecurityError(StorageError):
    """Raised when a security invariant is violated."""


# ------------------------------------------------------------
# Encryption configuration
# ------------------------------------------------------------

@dataclass
class EncryptionConfig:
    enabled: bool
    key: Optional[str] = None  # base64-encoded Fernet key

    @classmethod
    def from_settings(cls) -> "EncryptionConfig":
        settings = get_settings()
        enabled = getattr(settings, "STORAGE_ENCRYPTION", False)
        key = getattr(settings, "STORAGE_ENCRYPTION_KEY", None)

        if enabled and not key:
            raise StorageSecurityError(
                "Encryption enabled but STORAGE_ENCRYPTION_KEY is not set."
            )

        return cls(enabled=enabled, key=key)

    def build_cipher(self) -> Optional[Fernet]:
        if not self.enabled:
            return None
        try:
            return Fernet(self.key.encode("utf-8"))
        except Exception as e:
            raise StorageSecurityError(f"Invalid encryption key: {e}") from e


# ------------------------------------------------------------
# Storage backend (local filesystem)
# ------------------------------------------------------------

class LocalFilesystemBackend:
    """
    Local filesystem backend with strict path validation.
    """

    def __init__(self, root_dir: Path):
        self.root_dir = root_dir.resolve()
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _resolve(self, physical_path: str) -> Path:
        p = (self.root_dir / physical_path).resolve()
        if not str(p).startswith(str(self.root_dir)):
            raise StorageSecurityError("Attempted path traversal outside storage root")
        return p

    def write_bytes(self, physical_path: str, data: bytes) -> None:
        path = self._resolve(physical_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)

    def read_bytes(self, physical_path: str) -> bytes:
        path = self._resolve(physical_path)
        if not path.exists():
            raise StorageNotFound(f"Key not found: {physical_path}")
        return path.read_bytes()

    def delete(self, physical_path: str) -> None:
        path = self._resolve(physical_path)
        if path.exists():
            path.unlink()

    def list_keys(self, physical_prefix: str) -> List[str]:
        base = self._resolve(physical_prefix)
        if not base.exists():
            return []
        results = []
        for p in base.rglob("*.json"):
            rel = p.relative_to(self.root_dir)
            results.append(str(rel))
        return results


# ------------------------------------------------------------
# Main Storage abstraction
# ------------------------------------------------------------

class Storage:
    """
    Governance-first storage abstraction.

    - Tenant-safe namespacing
    - Optional encryption at rest
    - Strict path validation
    - JSON-based collections
    """

    def __init__(self, base_path: Optional[Path] = None):
        settings = get_settings()
        root = base_path or Path(settings.STORAGE_PATH)
        self.backend = LocalFilesystemBackend(root_dir=root)
        self.encryption_cfg = EncryptionConfig.from_settings()
        self.cipher = self.encryption_cfg.build_cipher()

    # -------------------------
    # Internal helpers
    # -------------------------

    def _validate(self, value: str, label: str) -> None:
        if not value or "/" in value or ".." in value:
            raise StorageSecurityError(f"Invalid {label}: {value}")

    def _physical_path(self, namespace: str, collection: str, id_: str) -> str:
        self._validate(namespace, "namespace")
        self._validate(collection, "collection")
        self._validate(id_, "id")
        return f"{namespace}/{collection}/{id_}.json"

    def _encrypt(self, data: bytes) -> bytes:
        if not self.cipher:
            return data
        return self.cipher.encrypt(data)

    def _decrypt(self, data: bytes) -> bytes:
        if not self.cipher:
            return data
        try:
            return self.cipher.decrypt(data)
        except InvalidToken as e:
            raise StorageSecurityError("Failed to decrypt stored data") from e

    # -------------------------
    # Public API
    # -------------------------

    def list(self, namespace: str, collection: str) -> List[Dict[str, Any]]:
        self._validate(namespace, "namespace")
        self._validate(collection, "collection")

        prefix = f"{namespace}/{collection}"
        keys = self.backend.list_keys(prefix)

        items = []
        for k in keys:
            try:
                raw = self.backend.read_bytes(k)
                data = self._decrypt(raw)
                items.append(json.loads(data.decode("utf-8")))
            except Exception:
                continue
        return items

    def get(self, namespace: str, collection: str, id_: str) -> Optional[Dict[str, Any]]:
        physical = self._physical_path(namespace, collection, id_)
        try:
            raw = self.backend.read_bytes(physical)
            data = self._decrypt(raw)
            return json.loads(data.decode("utf-8"))
        except StorageNotFound:
            return None

    def save(self, namespace: str, collection: str, data: Dict[str, Any]) -> Dict[str, Any]:
        id_ = data.get("id") or str(uuid.uuid4())
        data["id"] = id_

        physical = self._physical_path(namespace, collection, id_)
        encoded = json.dumps(data, indent=2, default=str).encode("utf-8")
        encrypted = self._encrypt(encoded)

        self.backend.write_bytes(physical, encrypted)
        return data

    def delete(self, namespace: str, collection: str, id_: str) -> None:
        physical = self._physical_path(namespace, collection, id_)
        self.backend.delete(physical)


# Singleton instance
storage = Storage()
