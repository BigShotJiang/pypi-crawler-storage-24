from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .enrichment import LeadProfile


@dataclass
class LeadInsights:
    pain_points: List[str]
    ai_comfort: str
    ai_comfort_reason: str
    worker_first_angle: str
    recommended_positioning: str


def _infer_ai_comfort(profile: LeadProfile) -> tuple[str, str]:
    """
    Heuristic AI comfort estimation.
    """
    # You can expand this with real logic later.
    if profile.role and any(k in profile.role.lower() for k in ["cto", "head of engineering", "vp engineering"]):
        return "High", "Technical leadership role likely familiar with AI and automation trends."
    return "Medium", "No explicit technical leadership signal; assume moderate familiarity but some caution."


def _infer_pain_points(profile: LeadProfile) -> list[str]:
    """
    Heuristic pain point inference based on role/company.
    """
    pains: list[str] = []

    if profile.company:
        pains.append(f"Difficulty scaling workflows and processes at {profile.company} without burning out the team.")
    else:
        pains.append("Difficulty scaling workflows and processes without burning out the team.")

    pains.append("Manual coordination, follow-ups, and documentation consuming time that could be spent on higher-value work.")
    pains.append("Fear of adopting AI tools that feel like 'black boxes' or threaten existing roles.")

    return pains


def _build_worker_first_angle(profile: LeadProfile) -> str:
    """
    Describe how FortressCodeAI helps workers, not replaces them.
    """
    company_part = f" at {profile.company}" if profile.company else ""
    return (
        f"Position FortressCodeAI as a governance-first co-pilot that removes repetitive, low-value tasks for the team{company_part}, "
        "while keeping humans in control of decisions. Emphasize human-in-the-loop workflows, explainability, and auditability."
    )


def _build_positioning(profile: LeadProfile) -> str:
    """
    Recommend which value proposition to lead with.
    """
    return (
        "Lead with 'worker-augmenting, governance-first automation'—a system that makes existing teams faster and safer, "
        "rather than replacing them. Highlight audit logs, human approvals, and explainable AI as core differentiators."
    )


def generate_insights(profile: LeadProfile) -> LeadInsights:
    """
    Generate pain points, AI comfort, worker-first angle, and positioning.
    """
    pain_points = _infer_pain_points(profile)
    ai_comfort, ai_reason = _infer_ai_comfort(profile)
    worker_first_angle = _build_worker_first_angle(profile)
    positioning = _build_positioning(profile)

    return LeadInsights(
        pain_points=pain_points,
        ai_comfort=ai_comfort,
        ai_comfort_reason=ai_reason,
        worker_first_angle=worker_first_angle,
        recommended_positioning=positioning,
    )
