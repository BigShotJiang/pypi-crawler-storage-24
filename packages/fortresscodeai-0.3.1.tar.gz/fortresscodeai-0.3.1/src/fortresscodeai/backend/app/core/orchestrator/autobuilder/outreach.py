from __future__ import annotations

from .enrichment import LeadProfile
from .insights import LeadInsights


def draft_outreach(profile: LeadProfile, insights: LeadInsights) -> str:
    """
    Draft a worker-first, non-threatening outreach message.
    """
    name = profile.name or "there"
    company = profile.company

    company_line = f" at {company}" if company else ""
    pain = insights.pain_points[0] if insights.pain_points else "the overhead of manual coordination and follow-ups"

    msg_lines = [
        f"Hi {name},",
        "",
        f"I’ve been thinking a lot about how teams{company_line} handle {pain.lower()}.",
        "I’m building FortressCodeAI, a governance-first automation co-pilot that’s designed to help workers, not replace them—",
        "it focuses on removing repetitive, low-value tasks while keeping humans in full control of decisions.",
        "",
        "If you’re open to it, I’d love to share a quick example of how we’re using it internally to reduce overload without adding risk or threatening roles.",
        "No pitch deck, just a concrete workflow and what it changed for us.",
        "",
        "Would a short async walkthrough or a quick call be more useful for you?",
        "",
        "Best,",
        "James",
    ]

    return "\n".join(msg_lines)
