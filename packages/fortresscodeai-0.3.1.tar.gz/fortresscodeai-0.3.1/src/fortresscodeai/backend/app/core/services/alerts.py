from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from ...app.models.models import UsageRecord, Alert, AlertSeverityEnum


class AnomalyDetector:
    def __init__(self, db: Session):
        self.db = db

    def detect_usage_spike(
        self,
        *,
        org_id,
        metric: str,
        window_minutes: int,
        baseline_factor: int = 24,
        threshold_ratio: float = 3.0,
    ) -> dict | None:
        now = datetime.utcnow()
        window_start = now - timedelta(minutes=window_minutes)
        baseline_start = window_start - timedelta(minutes=window_minutes * baseline_factor)

        current_total = (
            self.db.query(UsageRecord)
            .filter(
                UsageRecord.org_id == org_id,
                UsageRecord.metric == metric,
                UsageRecord.occurred_at >= window_start,
                UsageRecord.occurred_at < now,
            )
            .with_entities(UsageRecord.quantity)
            .all()
        )
        current = sum(r.quantity for r in current_total)

        baseline_total = (
            self.db.query(UsageRecord)
            .filter(
                UsageRecord.org_id == org_id,
                UsageRecord.metric == metric,
                UsageRecord.occurred_at >= baseline_start,
                UsageRecord.occurred_at < window_start,
            )
            .with_entities(UsageRecord.quantity)
            .all()
        )
        baseline_sum = sum(r.quantity for r in baseline_total)
        if baseline_factor == 0:
            return None
        baseline_avg = baseline_sum / baseline_factor if baseline_factor else 0
        if baseline_avg == 0:
            return None

        ratio = current / baseline_avg
        if ratio >= threshold_ratio:
            return {
                "metric": metric,
                "expected": baseline_avg,
                "actual": current,
                "deviation_ratio": ratio,
            }
        return None


class AlertService:
    def __init__(self, db: Session, email_sender):
        self.db = db
        self.email_sender = email_sender  # async or sync callable

    def create_alert(self, *, org_id, type: str, severity: AlertSeverityEnum, message: str) -> Alert:
        alert = Alert(
            org_id=org_id,
            type=type,
            severity=severity,
            message=message,
        )
        self.db.add(alert)
        self.db.commit()
        self.db.refresh(alert)

        # TODO: look up recipients by org_id
        recipients = ["owner@example.com"]
        subject = f"[{severity.value.upper()}] {type}"
        for to in recipients:
            self.email_sender(to=to, subject=subject, body=message)

        return alert

    def list_org_alerts(self, org_id, limit: int = 50) -> list[Alert]:
        return (
            self.db.query(Alert)
            .filter(Alert.org_id == org_id)
            .order_by(Alert.created_at.desc())
            .limit(limit)
            .all()
        )
