from typing import List
from backend.app.core.auth.user import User
from backend.app.core.auth.context import RequestContext
from backend.app.core.auth.risk import compute_risk_score
from backend.app.core.auth.policies import (
    PolicyResult,
    Decision,
    SENSITIVE_PATH_SCOPES,
)


RISK_THRESHOLD_HARD_DENY = 5.0
RISK_THRESHOLD_CHALLENGE = 3.0


def evaluate_policies(user: User, ctx: RequestContext) -> PolicyResult:
    """
    Evaluate contextual policies for this request, returning a structured decision.
    """
    risk = compute_risk_score(user, ctx)
    reasons: List[str] = []
    required_scopes: List[str] = []

    # Path-based scope requirements
    for prefix, scope in SENSITIVE_PATH_SCOPES.items():
        if ctx.path.startswith(prefix):
            required_scopes.append(scope)
            reasons.append(f"path_requires_scope:{scope}")

    # Risk-based decisions
    if risk >= RISK_THRESHOLD_HARD_DENY:
        return PolicyResult(
            decision=Decision.DENY,
            reasons=reasons + [f"risk>={RISK_THRESHOLD_HARD_DENY}"],
            risk_score=risk,
            required_scopes=required_scopes,
        )

    if risk >= RISK_THRESHOLD_CHALLENGE:
        return PolicyResult(
            decision=Decision.CHALLENGE,
            reasons=reasons + [f"risk>={RISK_THRESHOLD_CHALLENGE}"],
            risk_score=risk,
            required_scopes=required_scopes,
        )

    return PolicyResult(
        decision=Decision.ALLOW,
        reasons=reasons,
        risk_score=risk,
        required_scopes=required_scopes,
    )
