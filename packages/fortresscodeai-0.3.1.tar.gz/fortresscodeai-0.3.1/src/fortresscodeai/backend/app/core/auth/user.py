# backend/app/core/auth/user.py

from pydantic import BaseModel
from typing import List, Dict

class User(BaseModel):
    id: str
    role: str
    groups: List[str] = []
    attributes: Dict[str, str] = {}
