from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware

from backend.app.core.auth.roles import ROLES
from backend.app.core.auth.user import User
from backend.app.core.auth.context import RequestContext
from backend.app.core.auth.engine import evaluate_policies
from backend.app.core.auth.policies import Decision, PolicyResult


class RBACMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # 1) Basic role extraction
        role = request.headers.get("x-role")
        if not role:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing role header",
            )

        if role not in ROLES:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Invalid role: {role}",
            )

        user = User(
            id="placeholder",  # swap with real identity later
            role=role,
            groups=[],
            attributes={},
        )

        # 2) Build request context
        ctx = RequestContext(
            ip=request.client.host if request.client else "unknown",
            user_agent=request.headers.get("user-agent", ""),
            path=request.url.path,
            method=request.method,
            headers=dict(request.headers),
        )

        # 3) Evaluate policies
        policy_result: PolicyResult = evaluate_policies(user, ctx)

        if policy_result.decision == Decision.DENY:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "message": "Access denied by policy engine",
                    "reasons": policy_result.reasons,
                    "risk_score": policy_result.risk_score,
                },
            )

        if policy_result.decision == Decision.CHALLENGE:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "message": "Additional verification required",
                    "reasons": policy_result.reasons,
                    "risk_score": policy_result.risk_score,
                },
            )

        # 4) Attach user + policy to request for downstream handlers
        request.state.user = user
        request.state.policy = policy_result

        return await call_next(request)
