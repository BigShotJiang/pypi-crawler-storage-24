# backend/app/core/auth/context.py

from pydantic import BaseModel
from typing import Dict

class RequestContext(BaseModel):
    ip: str
    user_agent: str
    path: str
    method: str
    headers: Dict[str, str]
