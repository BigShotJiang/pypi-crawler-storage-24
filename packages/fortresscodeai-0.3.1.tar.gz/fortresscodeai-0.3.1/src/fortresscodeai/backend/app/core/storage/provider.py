import json
import time
import threading
from pathlib import Path
from typing import Callable, Any, Dict, List, Type

from .model_mapping import get_collection_for_model
from .model_adapter import orm_to_dict, dict_to_model

_lock = threading.Lock()


class JsonStorageProvider:
    def __init__(self, root: str = "./data", namespace: str = "core"):
        self.root = Path(root) / namespace
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, collection: str) -> Path:
        return self.root / f"{collection}.json"

    def _read(self, collection: str) -> Dict[str, Any]:
        path = self._path(collection)
        if not path.exists():
            return {}
        return json.loads(path.read_text())

    def _write(self, collection: str, data: Dict[str, Any]) -> None:
        path = self._path(collection)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2))
        tmp.replace(path)

    # ---------- Generic model operations ----------

    def list(self, model_cls: Type, filter_fn: Callable[[Any], bool] | None = None) -> List[Any]:
        collection = get_collection_for_model(model_cls)
        raw = self._read(collection)
        items = [dict_to_model(model_cls, v) for v in raw.values()]
        if filter_fn:
            items = [i for i in items if filter_fn(i)]
        return items

    def get(self, model_cls: Type, key: str) -> Any | None:
        collection = get_collection_for_model(model_cls)
        raw = self._read(collection)
        data = raw.get(key)
        return dict_to_model(model_cls, data) if data else None

    def set(self, obj: Any) -> None:
        model_cls = obj.__class__
        collection = get_collection_for_model(model_cls)
        raw = self._read(collection)
        key = getattr(obj, "id", None)
        if not key:
            raise ValueError(f"Object {obj} has no id field")
        raw[key] = orm_to_dict(obj)
        with _lock:
            self._write(collection, raw)

    def delete(self, model_cls: Type, key: str) -> None:
        collection = get_collection_for_model(model_cls)
        raw = self._read(collection)
        if key in raw:
            del raw[key]
            with _lock:
                self._write(collection, raw)

    # ---------- Append-only logs (audit, traceability) ----------

    def append_log(self, collection: str, event: Dict[str, Any]) -> None:
        path = self._path(collection)
        line = json.dumps(event)
        with _lock:
            with path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")

    def read_log(self, collection: str) -> List[Dict[str, Any]]:
        path = self._path(collection)
        if not path.exists():
            return []
        with path.open("r", encoding="utf-8") as f:
            return [json.loads(line) for line in f if line.strip()]
