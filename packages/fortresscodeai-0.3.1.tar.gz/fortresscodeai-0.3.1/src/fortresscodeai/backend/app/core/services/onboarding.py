from typing import Literal

from sqlalchemy.orm import Session

from ...app.models.models import OnboardingState, Org, Plan, User, RoleEnum

OnboardingStep = Literal[
    "create_org",
    "invite_team",
    "connect_repo",
    "configure_policies",
    "complete",
]

ORDER: list[OnboardingStep] = [
    "create_org",
    "invite_team",
    "connect_repo",
    "configure_policies",
    "complete",
]


class OnboardingService:
    def __init__(self, db: Session):
        self.db = db

    def start_onboarding(self, owner: User, org_name: str, initial_plan_id) -> Org:
        plan = self.db.query(Plan).filter(Plan.id == initial_plan_id).first()
        if not plan:
            raise ValueError("PLAN_NOT_FOUND")

        org = Org(name=org_name, plan_id=initial_plan_id)
        self.db.add(org)
        self.db.flush()

        owner.org_id = org.id
        owner.role = RoleEnum.owner

        state = OnboardingState(
            org_id=org.id,
            current_step="invite_team",
            completed_steps=["create_org"],
        )
        self.db.add(state)
        self.db.commit()
        self.db.refresh(org)
        return org

    def get_state(self, org_id) -> OnboardingState | None:
        return (
            self.db.query(OnboardingState)
            .filter(OnboardingState.org_id == org_id)
            .first()
        )

    def advance(self, org_id, completed_step: OnboardingStep) -> OnboardingState:
        state = self.get_state(org_id)
        if not state:
            state = OnboardingState(
                org_id=org_id,
                current_step="create_org",
                completed_steps=[],
            )
            self.db.add(state)

        if completed_step not in state.completed_steps:
            state.completed_steps.append(completed_step)

        max_index = max(ORDER.index(s) for s in state.completed_steps)
        next_index = min(max_index + 1, len(ORDER) - 1)
        state.current_step = ORDER[next_index]

        self.db.commit()
        self.db.refresh(state)
        return state
