from datetime import datetime
from typing import Tuple

from sqlalchemy.orm import Session

from ...app.models.models import Org, Plan, UsageRecord


class PricingService:
    def __init__(self, db: Session):
        self.db = db

    def list_plans(self):
        return self.db.query(Plan).all()

    def get_plan(self, plan_id) -> Plan | None:
        return self.db.query(Plan).filter(Plan.id == plan_id).first()

    def change_org_plan(self, org_id, plan_id) -> None:
        plan = self.get_plan(plan_id)
        if not plan:
            raise ValueError("PLAN_NOT_FOUND")
        org = self.db.query(Org).filter(Org.id == org_id).first()
        if not org:
            raise ValueError("ORG_NOT_FOUND")
        org.plan_id = plan_id
        self.db.commit()

    def estimate_monthly_charge(
        self,
        org: Org,
        metric: str,
        start: datetime,
        end: datetime,
    ) -> dict:
        plan = self.get_plan(org.plan_id)
        if not plan:
            raise ValueError("PLAN_NOT_FOUND")

        usage_units = (
            self.db.query(UsageRecord)
            .filter(
                UsageRecord.org_id == org.id,
                UsageRecord.metric == metric,
                UsageRecord.occurred_at >= start,
                UsageRecord.occurred_at < end,
            )
            .with_entities(
                (UsageRecord.quantity).label("qty")
            )
            .all()
        )
        total_units = sum(r.qty for r in usage_units)

        overage_units = max(0, total_units - plan.included_units)
        overage_cost = overage_units * plan.overage_price_per_unit_cents
        total_cents = plan.monthly_base_price_cents + overage_cost

        return {
            "plan": {
                "id": str(plan.id),
                "name": plan.name,
                "tier": plan.tier.value,
            },
            "estimated_cents": total_cents,
            "usage_units": total_units,
        }


class UsageMeter:
    def __init__(self, db: Session):
        self.db = db

    def record_usage(self, org_id, metric: str, quantity: int, occurred_at: datetime | None = None) -> UsageRecord:
        if quantity <= 0:
            raise ValueError("INVALID_QUANTITY")
        record = UsageRecord(
            org_id=org_id,
            metric=metric,
            quantity=quantity,
            occurred_at=occurred_at or datetime.utcnow(),
        )
        self.db.add(record)
        self.db.commit()
        self.db.refresh(record)
        return record
