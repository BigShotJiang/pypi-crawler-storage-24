"""
tools.py

Governance-first capability layer for FortressCodeAI's agent runtime.

This module defines the safe, policy-bound tools that agents may use.
All tools enforce:
- Tenant isolation
- Sandbox filesystem restrictions
- No path traversal
- No arbitrary shell execution
- Optional network allowlisting
- Full logging of all tool invocations

Agents never receive direct access to Python APIs, OS commands, or the real filesystem.
They only receive these controlled capabilities.
"""

from __future__ import annotations

import subprocess
import shlex
import json
from pathlib import Path
from typing import Any, Dict, Callable, Optional, List
import requests

from .storage import Storage, StorageSecurityError


# ------------------------------------------------------------
# Exceptions
# ------------------------------------------------------------

class ToolError(Exception):
    """Base class for tool-related errors."""


class ToolSecurityError(ToolError):
    """Raised when a tool detects a security violation."""


class ToolExecutionError(ToolError):
    """Raised when a tool fails during execution."""


# ------------------------------------------------------------
# Tooling class
# ------------------------------------------------------------

class Tooling:
    """
    Safe capability layer for agents.

    Each tool:
    - Validates inputs
    - Enforces sandbox boundaries
    - Logs usage
    - Never exposes raw OS or Python APIs to the agent
    """

    def __init__(
        self,
        tenant_id: str,
        sandbox_path: Path,
        storage: Storage,
        logger: Callable[[str], None],
        network_allowlist: Optional[List[str]] = None,
    ):
        self.tenant_id = tenant_id
        self.sandbox_path = sandbox_path.resolve()
        self.storage = storage
        self.logger = logger
        self.network_allowlist = network_allowlist or []

    # ------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------

    def _safe_path(self, relative_path: str) -> Path:
        """
        Validate and resolve a path inside the sandbox.
        Prevents absolute paths and traversal attacks.
        """
        rel = Path(relative_path)

        if rel.is_absolute():
            raise ToolSecurityError("Absolute paths are not allowed")

        if ".." in rel.parts:
            raise ToolSecurityError("Path traversal detected")

        resolved = (self.sandbox_path / rel).resolve()

        if not str(resolved).startswith(str(self.sandbox_path)):
            raise ToolSecurityError("Attempted escape from sandbox")

        return resolved

    def _log(self, message: str) -> None:
        self.logger(f"[tool] {message}")

    # ------------------------------------------------------------
    # Filesystem tools
    # ------------------------------------------------------------

    def read_file(self, relative_path: str) -> str:
        """
        Read a file inside the sandbox.
        """
        path = self._safe_path(relative_path)
        if not path.exists():
            raise ToolError(f"File not found: {relative_path}")

        self._log(f"read_file: {relative_path}")
        return path.read_text(encoding="utf-8")

    def write_file(self, relative_path: str, content: str) -> None:
        """
        Write a file inside the sandbox.
        """
        path = self._safe_path(relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

        self._log(f"write_file: {relative_path}")

    def list_files(self, relative_dir: str = ".") -> List[str]:
        """
        List files inside a sandbox directory.
        """
        path = self._safe_path(relative_dir)
        if not path.exists():
            return []

        self._log(f"list_files: {relative_dir}")

        return [
            str(p.relative_to(self.sandbox_path))
            for p in path.rglob("*")
            if p.is_file()
        ]

    # ------------------------------------------------------------
    # Storage tools (tenant-scoped)
    # ------------------------------------------------------------

    def storage_read_json(self, key: str) -> Dict[str, Any]:
        """
        Read a JSON object from tenant-scoped storage.
        """
        self._log(f"storage_read_json: {key}")
        return self.storage.read_json(self.tenant_id, key)

    def storage_write_json(self, key: str, obj: Dict[str, Any]) -> None:
        """
        Write a JSON object to tenant-scoped storage.
        """
        self._log(f"storage_write_json: {key}")
        self.storage.write_json(self.tenant_id, key, obj)

    # ------------------------------------------------------------
    # Code execution tools (safe, controlled)
    # ------------------------------------------------------------

    def run_tests(self, selector: Optional[str] = None) -> Dict[str, Any]:
        """
        Run pytest inside the sandbox with strict controls.
        """
        cmd = ["pytest"]
        if selector:
            cmd.append(selector)

        self._log(f"run_tests: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.sandbox_path),
                capture_output=True,
                text=True,
                timeout=60,
            )
            return {
                "returncode": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        except subprocess.TimeoutExpired:
            raise ToolExecutionError("Tests timed out")

    # ------------------------------------------------------------
    # Network tools (allowlisted only)
    # ------------------------------------------------------------

    def http_get(self, url: str) -> str:
        """
        Perform an HTTP GET request to an allowlisted domain.
        """
        if not any(url.startswith(prefix) for prefix in self.network_allowlist):
            raise ToolSecurityError(f"URL not allowed: {url}")

        self._log(f"http_get: {url}")

        try:
            resp = requests.get(url, timeout=10)
            resp.raise_for_status()
            return resp.text
        except Exception as e:
            raise ToolExecutionError(f"HTTP GET failed: {e}") from e


# ------------------------------------------------------------
# Tool registry builder
# ------------------------------------------------------------

def build_tools(
    tenant_id: str,
    sandbox_path: Path,
    storage: Storage,
    logger: Callable[[str], None],
    allowed_tools: List[str],
    network_allowlist: Optional[List[str]] = None,
) -> Dict[str, Callable]:
    """
    Build a dict of tool name -> callable, filtered by allowed_tools.
    """
    t = Tooling(
        tenant_id=tenant_id,
        sandbox_path=sandbox_path,
        storage=storage,
        logger=logger,
        network_allowlist=network_allowlist,
    )

    all_tools = {
        "read_file": t.read_file,
        "write_file": t.write_file,
        "list_files": t.list_files,
        "storage_read_json": t.storage_read_json,
        "storage_write_json": t.storage_write_json,
        "run_tests": t.run_tests,
        "http_get": t.http_get,
    }

    return {name: fn for name, fn in all_tools.items() if name in allowed_tools}
