from enum import Enum
from pydantic import BaseModel
from typing import List
from backend.app.core.auth.scopes import (
    WORKFLOW_MANAGE,
    AUDIT_READ,
    SECURITY_READ,
    HITL_APPROVE,
)


class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    CHALLENGE = "challenge"


class PolicyResult(BaseModel):
    decision: Decision
    reasons: List[str]
    risk_score: float
    required_scopes: List[str]


SENSITIVE_PATH_SCOPES = {
    "/workflows": WORKFLOW_MANAGE,
    "/audit": AUDIT_READ,
    "/security": SECURITY_READ,
    "/hitl": HITL_APPROVE,
}
