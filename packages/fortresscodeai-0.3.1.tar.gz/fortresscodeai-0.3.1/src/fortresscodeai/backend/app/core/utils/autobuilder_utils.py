from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict


def to_dict(obj: Any) -> Dict[str, Any]:
    """
    Safely convert dataclass or simple objects to dict.
    """
    try:
        return asdict(obj)
    except TypeError:
        if isinstance(obj, dict):
            return obj
        return dict(obj)
