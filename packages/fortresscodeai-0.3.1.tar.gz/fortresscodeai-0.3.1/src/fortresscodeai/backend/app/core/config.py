from pydantic_settings import BaseSettings


class Settings(BaseSettings):
  cors_allow_origins: list[str] = ["*"]
  redis_url: str = "redis://localhost:6379/0"
  environment: str = "local"

  class Config:
    env_file = ".env"


settings = Settings()
