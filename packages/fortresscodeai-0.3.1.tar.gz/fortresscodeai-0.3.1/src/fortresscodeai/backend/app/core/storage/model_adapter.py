from pydantic import BaseModel

def orm_to_dict(obj):
    if isinstance(obj, BaseModel):
        return obj.model_dump()

    data = {}
    for attr in dir(obj):
        if attr.startswith("_"):
            continue
        try:
            value = getattr(obj, attr)
            if callable(value):
                continue
            data[attr] = value
        except Exception:
            pass
    return data


def dict_to_model(model_cls, data: dict):
    try:
        return model_cls(**data)
    except Exception:
        # fallback for non-pydantic ORM-like classes
        obj = model_cls.__new__(model_cls)
        for k, v in data.items():
            setattr(obj, k, v)
        return obj
