from backend.app.core.auth import scopes

ROLES = {
    "security": {
        scopes.WORKFLOW_READ,
        scopes.HITL_APPROVE,
        scopes.AUDIT_READ,
        scopes.SECURITY_READ,
        scopes.GOVERNANCE_READ,
        scopes.IMPACT_READ,
    },
    "sales": {
        scopes.WORKFLOW_RUN,
        scopes.IMPACT_READ,
    },
    "operations_manager": {
        scopes.WORKFLOW_READ,
        scopes.WORKFLOW_MANAGE,
        scopes.HITL_APPROVE,
        scopes.AUDIT_READ,
        scopes.GOVERNANCE_READ,
        scopes.IMPACT_READ,
    },
    "design_partner": {
        scopes.GOVERNANCE_READ,
        scopes.IMPACT_READ,
    },
}
