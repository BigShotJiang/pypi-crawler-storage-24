"""
Audit subsystem: append-only ledger for compliance and governance.
"""
