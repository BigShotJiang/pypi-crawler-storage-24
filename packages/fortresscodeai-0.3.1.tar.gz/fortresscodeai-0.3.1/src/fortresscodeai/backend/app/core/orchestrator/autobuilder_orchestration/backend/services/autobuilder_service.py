from typing import Dict, Any
from datetime import datetime
import uuid

from backend.Modules.autobuilder_orchestration.backend.models.autobuilder import BuildRequest, BuildArtifact, BuildStatus
from backend.models.policy import PolicyViolation
from backend.services.policy.policy_engine import PolicyEngine
from backend.services.hitl_service import HITLService
from backend.Modules.audit_logging_engine import AuditService



class AutobuilderService:
    def __init__(self, store, policy_engine: PolicyEngine, hitl: HITLService, audit: AuditService):
        self.store = store
        self.policy_engine = policy_engine
        self.hitl = hitl
        self.audit = audit

    def submit_build(self, requested_by: str, blueprint: Dict[str, Any]) -> BuildRequest:
        correlation_id = str(uuid.uuid4())
        build_request = BuildRequest(
            id=str(uuid.uuid4()),
            created_at=datetime.utcnow(),
            requested_by=requested_by,
            blueprint=blueprint,
            correlation_id=correlation_id,
        )
        self.store.save_build_request(build_request)
        self.audit.log_event(
            actor=requested_by,
            action="build_submitted",
            resource=f"build:{build_request.id}",
            details={"blueprint": blueprint},
            correlation_id=correlation_id,
        )
        return build_request

    def run_build(self, build_request: BuildRequest) -> BuildArtifact:
        context = {"blueprint": build_request.blueprint, "requested_by": build_request.requested_by}
        violations = self.policy_engine.evaluate(context)

        if any(v.severity in ("high", "critical") for v in violations):
            # create HITL task and block
            self.hitl.create_review_task(
                correlation_id=build_request.correlation_id,
                actor="autobuilder",
                payload={"build_request_id": build_request.id, "violations": [v.dict() for v in violations]},
            )
            self.audit.log_event(
                actor="autobuilder",
                action="build_blocked_hitl",
                resource=f"build:{build_request.id}",
                details={"violations": [v.dict() for v in violations]},
                correlation_id=build_request.correlation_id,
            )
            # you might persist status as BLOCKED_HITL here
            raise RuntimeError("Build blocked pending human review")

        # TODO: actual generation logic
        artifact = BuildArtifact(
            id=str(uuid.uuid4()),
            build_id=build_request.id,
            created_at=datetime.utcnow(),
            artifact_type="agent",
            content={"generated": True, "blueprint": build_request.blueprint},
        )
        self.store.save_build_artifact(artifact)
        self.audit.log_event(
            actor="autobuilder",
            action="build_completed",
            resource=f"build:{build_request.id}",
            details={"artifact_id": artifact.id},
            correlation_id=build_request.correlation_id,
        )
        return artifact
