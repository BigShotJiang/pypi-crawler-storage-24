# app/types.py

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class RiskLevel(str, Enum):
    low = "low"
    medium = "medium"
    high = "high"


class GovernanceDecision(str, Enum):
    allow = "allow"
    deny = "deny"
    require_approval = "require_approval"
    require_second_review = "require_second_review"


class GovernanceContext(BaseModel):
    user_id: str
    repo_id: str
    branch: str
    environment: str  # "dev" | "stage" | "prod"
    risk_level: RiskLevel
    policies: List[str] = []


class FileChange(BaseModel):
    file_path: str
    before: Optional[str] = None
    after: str


class AgentRequest(BaseModel):
    agent_id: str  # "code_assistant" | "repo_architect" | "governance" | "autobuilder" | "auto"
    task_type: str
    input: Any
    context: Dict[str, Any]
    governance: Optional[Dict[str, Any]] = None


class AgentStatus(str, Enum):
    ok = "ok"
    needs_approval = "needs_approval"
    rejected = "rejected"
    error = "error"


class AgentResponse(BaseModel):
    status: AgentStatus
    summary: str
    proposed_changes: Optional[List[FileChange]] = None
    sub_tasks: Optional[List[AgentRequest]] = None
    governance_findings: Optional[Dict[str, Any]] = None
    audit_ref: str
    error: Optional[str] = None
