from datetime import datetime, timedelta
from typing import Any

from sqlalchemy.orm import Session

from ...app.models.models import UsageRecord


class UsageAnalyticsService:
    def __init__(self, db: Session):
        self.db = db

    def get_org_usage_summary(
        self,
        *,
        org_id,
        start: datetime,
        end: datetime,
        bucket_minutes: int = 60,
    ) -> list[dict[str, Any]]:
        records = (
            self.db.query(UsageRecord)
            .filter(
                UsageRecord.org_id == org_id,
                UsageRecord.occurred_at >= start,
                UsageRecord.occurred_at < end,
            )
            .all()
        )

        by_metric: dict[str, list[UsageRecord]] = {}
        for r in records:
            by_metric.setdefault(r.metric, []).append(r)

        summaries: list[dict[str, Any]] = []
        bucket_ms = bucket_minutes * 60 * 1000

        for metric, recs in by_metric.items():
            buckets: dict[str, int] = {}
            total = 0
            for r in recs:
                total += r.quantity
                ts = r.occurred_at
                epoch_ms = int(ts.timestamp() * 1000)
                bucket_start_ms = (epoch_ms // bucket_ms) * bucket_ms
                bucket_start = datetime.utcfromtimestamp(bucket_start_ms / 1000)
                key = bucket_start.isoformat() + "Z"
                buckets[key] = buckets.get(key, 0) + r.quantity

            timeseries = [
                {"timestamp": k, "value": v}
                for k, v in sorted(buckets.items(), key=lambda x: x[0])
            ]
            summaries.append(
                {
                    "metric": metric,
                    "total": total,
                    "timeseries": timeseries,
                }
            )

        return summaries
