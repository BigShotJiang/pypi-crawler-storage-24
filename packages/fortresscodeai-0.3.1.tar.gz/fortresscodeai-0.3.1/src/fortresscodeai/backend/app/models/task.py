from __future__ import annotations

import enum
import uuid
from typing import List, Optional, Dict, Any

from pydantic import BaseModel, Field, model_validator


class TaskType(str, enum.Enum):
    RESEARCH = "research"
    CODE = "code"
    REFACTOR = "refactor"
    EXECUTE = "execute"
    VALIDATE = "validate"
    PLAN = "plan"
    ROUTE = "route"


class AuditLevel(str, enum.Enum):
    FULL = "full"
    SUMMARY = "summary"
    NONE = "none"


class OutputType(str, enum.Enum):
    JSON = "json"
    CODE = "code"
    MARKDOWN = "markdown"
    TEXT = "text"


class ContextModel(BaseModel):
    business: Optional[str] = None
    technical: Optional[str] = None
    constraints: List[str] = []
    examples: List[str] = []


class InputsModel(BaseModel):
    files: List[str] = []
    data: Optional[Any] = None
    user_request: Optional[str] = None


class RequirementsModel(BaseModel):
    must: List[str] = []
    must_not: List[str] = []
    quality_bar: Optional[str] = None


class OutputFormatModel(BaseModel):
    type: OutputType
    structure: Dict[str, Any] = Field(default_factory=dict)


class GovernanceModel(BaseModel):
    policies: List[str] = []
    hitl_required: bool = False
    audit_level: AuditLevel = AuditLevel.FULL
    risk_score: int = Field(default=0, ge=0, le=100)


class RoutingModel(BaseModel):
    preferred_workers: List[str] = []
    max_depth: int = Field(default=3, ge=0, le=10)
    max_fanout: int = Field(default=5, ge=0, le=50)


class Task(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    parent_task_id: Optional[str] = None

    task_type: TaskType
    objective: str

    context: ContextModel = Field(default_factory=ContextModel)
    inputs: InputsModel = Field(default_factory=InputsModel)
    requirements: RequirementsModel = Field(default_factory=RequirementsModel)
    output_format: OutputFormatModel
    governance: GovernanceModel = Field(default_factory=GovernanceModel)
    routing: RoutingModel = Field(default_factory=RoutingModel)

    metadata: Dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_objective(self):
        if not self.objective or not self.objective.strip():
            raise ValueError("objective must be a non-empty string")
        return self

    @model_validator(mode="after")
    def validate_governance(self):
        if self.task_type == TaskType.EXECUTE:
            if self.governance.audit_level == AuditLevel.NONE:
                raise ValueError("EXECUTE tasks cannot have audit_level=NONE")
            if self.governance.risk_score < 50:
                self.governance.risk_score = 50

        if self.task_type in {TaskType.PLAN, TaskType.ROUTE}:
            if self.governance.hitl_required:
                raise ValueError("PLAN/ROUTE tasks cannot require HITL")

        return self

    @model_validator(mode="after")
    def validate_output_format(self):
        if self.output_format.type == OutputType.JSON:
            if not self.output_format.structure:
                raise ValueError("JSON output_format requires a non-empty structure")
        return self

    def to_worker_payload(self) -> Dict[str, Any]:
        data = self.model_dump()
        data.pop("metadata", None)
        return data

    def to_audit_record(self, action: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        record = {
            "task_id": self.task_id,
            "parent_task_id": self.parent_task_id,
            "task_type": self.task_type.value,
            "objective": self.objective,
            "governance": self.governance.model_dump(),
            "routing": self.routing.model_dump(),
            "action": action,
        }
        if extra:
            record["extra"] = extra
        return record
