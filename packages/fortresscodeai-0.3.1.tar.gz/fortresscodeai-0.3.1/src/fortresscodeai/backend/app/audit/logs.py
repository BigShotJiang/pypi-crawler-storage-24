import json
import os
from datetime import datetime

AUDIT_LOG_FILE = "audit_logs.json"


def load_audit_logs():
    """
    Loads audit logs from disk.
    """

    if not os.path.exists(AUDIT_LOG_FILE):
        return []

    with open(AUDIT_LOG_FILE, "r") as f:
        try:
            return json.load(f)
        except Exception:
            return []


def append_audit_log(actor: str, action: str, details: dict | None = None):
    """
    Appends a new audit log entry.
    """

    logs = load_audit_logs()
    logs.append({
        "timestamp": datetime.utcnow().isoformat(),
        "actor": actor,
        "action": action,
        "details": details or {}
    })

    with open(AUDIT_LOG_FILE, "w") as f:
        json.dump(logs, f, indent=2)
