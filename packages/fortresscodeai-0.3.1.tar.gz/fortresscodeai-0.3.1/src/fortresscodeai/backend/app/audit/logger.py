from typing import Any, Dict, Optional
import time
import json
import uuid
import traceback

from .logger import get_logger

logger = get_logger("audit")


def _safe_json(data: Any) -> Any:
    """Ensure metadata is JSON‑serializable."""
    try:
        json.dumps(data)
        return data
    except Exception:
        return str(data)


def _base_payload(
    *,
    action: str,
    actor: Optional[str],
    target: Optional[str],
    metadata: Optional[Dict[str, Any]],
    stage: str,
    status: str,
    correlation_id: Optional[str] = None,
    workflow: Optional[str] = None,
    agent: Optional[str] = None,
    error: Optional[str] = None,
    tb: Optional[str] = None,
) -> Dict[str, Any]:
    """Unified audit envelope for all events."""
    return {
        "type": "audit",
        "timestamp": time.time(),
        "correlation_id": correlation_id or str(uuid.uuid4()),
        "action": action,
        "stage": stage,  # pre, post, exception
        "status": status,  # attempt, success, failure
        "actor": actor,
        "target": target,
        "workflow": workflow,
        "agent": agent,
        "metadata": _safe_json(metadata or {}),
        "error": error,
        "traceback": tb,
    }


def audit_event(
    *,
    action: str,
    actor: Optional[str] = None,
    target: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    stage: str = "event",
    status: str = "info",
    correlation_id: Optional[str] = None,
    workflow: Optional[str] = None,
    agent: Optional[str] = None,
    error: Optional[str] = None,
    tb: Optional[str] = None,
) -> str:
    """
    Core audit emitter.
    Returns correlation_id so callers can chain events.
    """
    cid = correlation_id or str(uuid.uuid4())

    payload = _base_payload(
        action=action,
        actor=actor,
        target=target,
        metadata=metadata,
        stage=stage,
        status=status,
        correlation_id=cid,
        workflow=workflow,
        agent=agent,
        error=error,
        tb=tb,
    )

    logger.info(json.dumps(payload))
    return cid


# ---------------------------------------------------------
# HIGH‑LEVEL EVENT HELPERS
# ---------------------------------------------------------

def audit_pre_transition(
    *,
    action: str,
    actor: Optional[str],
    target: Optional[str],
    metadata: Dict[str, Any],
    workflow: Optional[str] = None,
    agent: Optional[str] = None,
    correlation_id: Optional[str] = None,
) -> str:
    return audit_event(
        action=action,
        actor=actor,
        target=target,
        metadata=metadata,
        stage="pre",
        status="attempt",
        workflow=workflow,
        agent=agent,
        correlation_id=correlation_id,
    )


def audit_post_transition(
    *,
    action: str,
    actor: Optional[str],
    target: Optional[str],
    metadata: Dict[str, Any],
    workflow: Optional[str] = None,
    agent: Optional[str] = None,
    correlation_id: Optional[str],
    success: bool,
) -> str:
    return audit_event(
        action=action,
        actor=actor,
        target=target,
        metadata=metadata,
        stage="post",
        status="success" if success else "error",
        workflow=workflow,
        agent=agent,
        correlation_id=correlation_id,
    )


def audit_exception(
    *,
    action: str,
    actor: Optional[str],
    target: Optional[str],
    exc: Exception,
    workflow: Optional[str] = None,
    agent: Optional[str] = None,
    correlation_id: Optional[str],
    metadata: Optional[Dict[str, Any]] = None,
) -> str:
    return audit_event(
        action=action,
        actor=actor,
        target=target,
        metadata=metadata,
        stage="exception",
        status="failure",
        workflow=workflow,
        agent=agent,
        correlation_id=correlation_id,
        error=str(exc),
        tb=traceback.format_exc(),
    )


# ---------------------------------------------------------
# DOMAIN‑SPECIFIC SHORTCUTS
# ---------------------------------------------------------

def audit_dev_console_access(
    user: Optional[str],
    success: bool,
    reason: str = "",
    correlation_id: Optional[str] = None,
):
    return audit_event(
        action="dev_console_access",
        actor=user,
        target="dev_console",
        metadata={"success": success, "reason": reason},
        stage="post",
        status="success" if success else "error",
        correlation_id=correlation_id,
    )


def audit_ai_fix(
    *,
    file_path: str,
    violation_code: str,
    actor: Optional[str],
    success: bool = True,
    message: str = "",
    correlation_id: Optional[str] = None,
):
    return audit_event(
        action="ai_fix",
        actor=actor,
        target=file_path,
        metadata={
            "violation_code": violation_code,
            "success": success,
            "message": message,
        },
        stage="post",
        status="success" if success else "error",
        correlation_id=correlation_id,
    )
