from __future__ import annotations

from typing import Dict, Any

from .normalization import NormalizedLeadInput
from .enrichment import LeadProfile
from .insights import LeadInsights
from ..shared.utils import to_dict


def build_audit_log(
    normalized: NormalizedLeadInput,
    profile: LeadProfile,
    insights: LeadInsights,
    template_version: str = "lead_packet_v1",
) -> Dict[str, Any]:
    """
    Build a governance-grade audit log for the autobuild process.
    """
    return {
        "input_provided": normalized.raw_input,
        "signals_used": {
            "profile": to_dict(profile),
            "insights": to_dict(insights),
        },
        "confidence_levels": normalized.confidence,
        "template_version": template_version,
    }
