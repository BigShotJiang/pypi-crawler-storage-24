import random

def build_trust_signals():
    """
    Generates trust signals based on workspace behavior.
    Real logic would analyze:
    - code quality
    - governance alignment
    - dependency hygiene
    - agent performance
    - audit logs
    """

    return [
        {
            "name": "Governance Alignment",
            "value": random.uniform(0, 10),
            "description": "How closely the workspace follows governance rules."
        },
        {
            "name": "Dependency Hygiene",
            "value": random.uniform(0, 10),
            "description": "Quality and safety of dependencies."
        },
        {
            "name": "Agent Reliability",
            "value": random.uniform(0, 10),
            "description": "Stability and correctness of agent actions."
        },
        {
            "name": "Audit Cleanliness",
            "value": random.uniform(0, 10),
            "description": "Frequency and severity of audit findings."
        }
    ]
