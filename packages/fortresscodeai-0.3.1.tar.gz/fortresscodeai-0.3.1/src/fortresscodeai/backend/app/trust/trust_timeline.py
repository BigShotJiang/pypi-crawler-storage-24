from datetime import datetime, timedelta
import random

def build_trust_timeline():
    """
    Builds a time-series trust timeline.
    """

    timeline = []
    now = datetime.utcnow()

    for i in range(10):
        timestamp = now - timedelta(days=i)
        timeline.append({
            "timestamp": timestamp.isoformat(),
            "trustScore": random.uniform(0, 10),
            "event": "Periodic trust evaluation"
        })

    return list(reversed(timeline))
