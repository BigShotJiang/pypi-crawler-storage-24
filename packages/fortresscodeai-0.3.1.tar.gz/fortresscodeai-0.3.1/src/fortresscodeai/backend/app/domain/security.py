from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel


class SecurityEvent(BaseModel):
    id: str
    workflow_id: Optional[str] = None
    step_name: Optional[str] = None
    severity: str
    category: str
    message: str
    timestamp: datetime
    metadata: Dict[str, Any] = {}
