from typing import List, Optional

from pydantic import BaseModel


class Policy(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    enabled: bool = True
    tags: List[str] = []


class PolicyUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
