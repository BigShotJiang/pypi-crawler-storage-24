from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel


class WorkflowStep(BaseModel):
    name: str
    status: str
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    risk_score: Optional[float] = None


class WorkflowInstance(BaseModel):
    id: str
    name: str
    status: str
    started_at: datetime
    finished_at: Optional[datetime] = None
    steps: List[WorkflowStep] = []
