from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel


class AuditEntry(BaseModel):
    id: str
    workflow_id: str
    step_name: str
    user_id: Optional[str] = None
    timestamp: datetime
    decision: str
    risk_score: float
    metadata: Dict[str, Any] = {}
