from datetime import datetime
from typing import Any, Dict

from pydantic import BaseModel


class HITLItem(BaseModel):
    id: str
    workflow_id: str
    step_name: str
    user_id: str
    reason: str
    created_at: datetime
    context: Dict[str, Any] = {}
    status: str = "PENDING"
