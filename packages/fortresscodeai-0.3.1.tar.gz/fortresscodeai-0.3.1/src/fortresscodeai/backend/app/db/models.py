# app/models.py

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel
from .types import FileChange, RiskLevel


class ChangeSetStatus(str, Enum):
    proposed = "proposed"
    approved = "approved"
    rejected = "rejected"
    applied = "applied"
    rolled_back = "rolled_back"


class ChangeSet(BaseModel):
    id: str
    repo_id: str
    branch: str
    created_by_user_id: str
    created_at: datetime
    status: ChangeSetStatus
    file_changes: List[FileChange]
    risk_level: RiskLevel
    audit_ref: str
    hitl_required: bool
    hitl_approved_by_user_id: Optional[str] = None
    hitl_approved_at: Optional[datetime] = None
    hitl_comment: Optional[str] = None


class RunStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    awaiting_approval = "awaiting_approval"


class Run(BaseModel):
    id: str
    agent_id: str
    task_type: str
    user_id: str
    repo_id: str
    branch: str
    created_at: datetime
    updated_at: datetime
    status: RunStatus
    risk_level: RiskLevel
    audit_ref: str
    metadata: Optional[Dict[str, Any]] = None
