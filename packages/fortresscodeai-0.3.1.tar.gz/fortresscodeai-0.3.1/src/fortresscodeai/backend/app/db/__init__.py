import logging

from backend.app.storage import Storage

logger = logging.getLogger("fortress.db")
logger.setLevel(logging.INFO)


def main():
    logger.info("📦 Initializing FortressCodeAI storage backend...")

    storage = Storage()

    if hasattr(storage, "initialize"):
        logger.info("→ Running storage.initialize()")
        storage.initialize()

    if hasattr(storage, "run_migrations"):
        logger.info("→ Running storage.run_migrations()")
        storage.run_migrations()

    if hasattr(storage, "seed_defaults"):
        logger.info("→ Running storage.seed_defaults()")
        storage.seed_defaults()

    logger.info("✅ Storage initialization complete.")


if __name__ == "__main__":
    main()
