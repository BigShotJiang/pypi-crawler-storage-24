import time
import psutil
from typing import List, Dict, Any
from backend.app.celery_app import celery_app, WORKER_LOGS
from backend.app.api.workers.models import WorkerSummary, WorkerDetail, WorkerTask, WorkerMetrics

def get_workers() -> List[WorkerSummary]:
    inspect = celery_app.control.inspect()

    stats = inspect.stats() or {}
    active = inspect.active() or {}
    reserved = inspect.reserved() or {}
    queues = inspect.active_queues() or {}

    workers = []

    for worker_id, info in stats.items():
        workers.append(
            WorkerSummary(
                id=worker_id,
                name=worker_id,
                status="online",
                queues=[q["name"] for q in queues.get(worker_id, [])],
                active_tasks=len(active.get(worker_id, [])),
                reserved_tasks=len(reserved.get(worker_id, [])),
            )
        )

    return workers

def get_worker_detail(worker_id: str) -> WorkerDetail:
    inspect = celery_app.control.inspect()

    stats = inspect.stats() or {}
    active = inspect.active() or {}
    reserved = inspect.reserved() or {}
    queues = inspect.active_queues() or {}

    info = stats.get(worker_id)
    if not info:
        return WorkerDetail(
            id=worker_id,
            name=worker_id,
            status="offline",
            hostname=None,
            pid=None,
            concurrency=None,
            uptime=None,
            queues=[],
            recent_tasks=[],
            metrics=None,
        )

    # Build recent tasks
    recent_tasks = []
    for t in active.get(worker_id, []):
        recent_tasks.append(
            WorkerTask(
                id=t.get("id"),
                name=t.get("name"),
                status="running",
                started_at=t.get("time_start"),
                duration_ms=int((time.time() - t.get("time_start", 0)) * 1000),
            )
        )

    # System metrics
    pid = info.get("pid")
    metrics = None
    if pid:
        try:
            p = psutil.Process(pid)
            metrics = WorkerMetrics(
                cpu_percent=p.cpu_percent(interval=0.1),
                memory_percent=p.memory_percent(),
                load_avg=sum(psutil.getloadavg()) / 3,
                throughput_per_min=None,
                failures_per_min=None,
                retries_per_min=None,
            )
        except Exception:
            pass

    return WorkerDetail(
        id=worker_id,
        name=worker_id,
        status="online",
        hostname=info.get("hostname"),
        pid=pid,
        concurrency=info.get("pool", {}).get("max-concurrency"),
        uptime=str(info.get("uptime")),
        queues=[q["name"] for q in queues.get(worker_id, [])],
        recent_tasks=recent_tasks,
        metrics=metrics,
    )

def get_worker_logs(worker_id: str, limit: int = 200):
    logs = WORKER_LOGS.get(worker_id, [])
    return list(logs)[-limit:]
