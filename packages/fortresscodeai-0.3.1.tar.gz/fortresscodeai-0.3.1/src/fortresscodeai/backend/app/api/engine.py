# backend/app/core/auth/engine.py

from typing import List
from backend.app.core.auth.user import User
from backend.app.core.auth.context import RequestContext
from backend.app.core.auth.risk import compute_risk_score
from backend.app.core.auth.policies import PolicyResult, Decision
from backend.app.core.auth.scopes import (
    WORKFLOW_MANAGE, AUDIT_READ, SECURITY_READ, HITL_APPROVE,
)

RISK_THRESHOLD_HARD_DENY = 5.0
RISK_THRESHOLD_CHALLENGE = 3.0

def evaluate_policies(user: User, ctx: RequestContext) -> PolicyResult:
    risk = compute_risk_score(user, ctx)
    reasons: List[str] = []
    required_scopes: List[str] = []

    # Example: high-risk paths require specific scopes
    if ctx.path.startswith("/workflows"):
        required_scopes.append(WORKFLOW_MANAGE)
        reasons.append("workflow_management")

    if ctx.path.startswith("/audit"):
        required_scopes.append(AUDIT_READ)
        reasons.append("audit_access")

    if ctx.path.startswith("/security"):
        required_scopes.append(SECURITY_READ)
        reasons.append("security_access")

    if ctx.path.startswith("/hitl"):
        required_scopes.append(HITL_APPROVE)
        reasons.append("hitl_approval")

    # Risk-based decision
    if risk >= RISK_THRESHOLD_HARD_DENY:
        return PolicyResult(
            decision=Decision.DENY,
            reasons=reasons + [f"risk>={RISK_THRESHOLD_HARD_DENY}"],
            risk_score=risk,
            required_scopes=required_scopes,
        )

    if risk >= RISK_THRESHOLD_CHALLENGE:
        return PolicyResult(
            decision=Decision.CHALLENGE,
            reasons=reasons + [f"risk>={RISK_THRESHOLD_CHALLENGE}"],
            risk_score=risk,
            required_scopes=required_scopes,
        )

    return PolicyResult(
        decision=Decision.ALLOW,
        reasons=reasons,
        risk_score=risk,
        required_scopes=required_scopes,
    )
