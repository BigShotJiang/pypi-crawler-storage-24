# backend/app/core/auth/risk.py

from backend.app.core.auth.user import User
from backend.app.core.auth.context import RequestContext

def compute_risk_score(user: User, ctx: RequestContext) -> float:
    score = 0.0

    # Example: privileged roles start higher
    if user.role in {"security", "operations_manager"}:
        score += 1.0

    # Example: suspicious IP ranges (placeholder)
    if ctx.ip.startswith("10.") is False:
        score += 2.0

    # Example: sensitive paths
    if ctx.path.startswith("/security") or ctx.path.startswith("/audit"):
        score += 1.5

    # Example: unknown user agent
    if "curl" in ctx.user_agent.lower():
        score += 1.0

    return score
