from fastapi import APIRouter, HTTPException, Request

router = APIRouter(tags=["plugins"])


@router.get("/")
async def list_plugins(request: Request):
    registry = getattr(request.app.state, "plugin_registry", None)
    if registry is None:
        return {"plugins": []}
    return {"plugins": registry.list_plugins()}


@router.post("/{plugin_name}/run")
async def run_plugin(plugin_name: str, payload: dict, request: Request):
    registry = getattr(request.app.state, "plugin_registry", None)
    if registry is None:
        raise HTTPException(status_code=404, detail="Plugin system not initialized")

    plugin = registry.get_plugin(plugin_name)
    if not plugin:
        raise HTTPException(status_code=404, detail="Plugin not found")

    if not hasattr(plugin, "run"):
        raise HTTPException(status_code=400, detail="Plugin does not define run()")

    return await plugin.run(payload)
