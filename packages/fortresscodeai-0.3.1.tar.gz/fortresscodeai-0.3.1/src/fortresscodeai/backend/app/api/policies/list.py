from fastapi import APIRouter

from app.domain.policy import Policy
from app.services.policy_service import PolicyService

router = APIRouter(prefix="/api/policies", tags=["policies"])
_service = PolicyService()


@router.get("/", response_model=list[Policy])
def list_policies():
    return _service.list_policies()
