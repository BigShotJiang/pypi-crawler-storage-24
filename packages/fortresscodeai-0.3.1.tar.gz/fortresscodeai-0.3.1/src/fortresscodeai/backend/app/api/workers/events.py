import asyncio
from typing import Dict, Any
from fastapi import WebSocket, WebSocketDisconnect

# Simple in-memory event bus
_worker_events_queue: "asyncio.Queue[Dict[str, Any]]" = asyncio.Queue()
_worker_logs_queue: "asyncio.Queue[Dict[str, Any]]" = asyncio.Queue()

async def publish_event(event: Dict[str, Any]) -> None:
    """Called from Celery signals later."""
    await _worker_events_queue.put(event)

async def publish_log(log: Dict[str, Any]) -> None:
    """Optional: push logs as events instead of polling."""
    await _worker_logs_queue.put(log)

async def worker_events_ws(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            event = await _worker_events_queue.get()
            await ws.send_json(event)
    except WebSocketDisconnect:
        return

async def worker_logs_ws(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            log = await _worker_logs_queue.get()
            await ws.send_json(log)
    except WebSocketDisconnect:
        return
