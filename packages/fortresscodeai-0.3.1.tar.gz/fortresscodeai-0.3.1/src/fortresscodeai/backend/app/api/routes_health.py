from fastapi import APIRouter

router = APIRouter(prefix="/health", tags=["health"])


@router.get("/")
async def get_system_health():
    return {
        "api_status": "OK",
        "workers_status": "Idle",
        "queues_status": "Clear",
        "errors_last_hour": 0,
    }


@router.get("/security/events")
async def get_security_events(limit: int = 100):
    return []
