from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class WorkerSummary(BaseModel):
    id: str
    name: str
    status: str
    queues: List[str]
    active_tasks: int
    reserved_tasks: int

class WorkerTask(BaseModel):
    id: str
    name: str
    status: str
    started_at: Optional[float]
    duration_ms: Optional[int]

class WorkerMetrics(BaseModel):
    cpu_percent: Optional[float]
    memory_percent: Optional[float]
    load_avg: Optional[float]
    throughput_per_min: Optional[int]
    failures_per_min: Optional[int]
    retries_per_min: Optional[int]

class WorkerDetail(BaseModel):
    id: str
    name: str
    status: str
    hostname: Optional[str]
    pid: Optional[int]
    concurrency: Optional[int]
    uptime: Optional[str]
    queues: List[str]
    recent_tasks: List[WorkerTask]
    metrics: Optional[WorkerMetrics]
