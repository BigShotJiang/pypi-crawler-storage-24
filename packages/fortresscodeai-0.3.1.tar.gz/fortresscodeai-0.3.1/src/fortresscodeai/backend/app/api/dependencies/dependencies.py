from functools import lru_cache
from pydantic_settings import BaseSettings
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "FortressCodeAI"

    # Storage
    STORAGE_ENCRYPTION: bool = True
    STORAGE_ENCRYPTION_KEY: str | None = None
    STORAGE_PATH: str = "./data"

    # Database
    DATABASE_URL: str = "sqlite:///./fortress.db"

    # Security
    SECRET_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Agent Runtime
    AGENT_SANDBOX_PATH: str = "./workspaces"
    AGENT_MAX_TOKENS: int = 4096
    AGENT_MAX_STEPS: int = 8

    # Logging
    LOG_LEVEL: str = "INFO"

    # LLM Provider
    LLM_PROVIDER: str = "openai"
    OPENAI_API_KEY: str | None = None

    # CORS
    ALLOW_ORIGINS: list[str] = ["*"]
    ENV: str = "development"
    DEBUG: bool = True

    ALLOW_ORIGINS: list[str] = ["*"]

    PLUGINS_PATH: str = "plugins"

    STORAGE_PATH: str = "storage"
    STORAGE_NAMESPACE: str = "fortress"
    class Config:
        env_file = ".env"
        extra = "ignore"
        env_file_encoding = "utf-8"
    

        


@lru_cache()
def get_settings() -> Settings:
    return Settings()
