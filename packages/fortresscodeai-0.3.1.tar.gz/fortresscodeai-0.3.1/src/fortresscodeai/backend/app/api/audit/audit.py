from fastapi import APIRouter, Request, HTTPException, status
from backend.app.core.auth.roles import ROLES
from backend.app.core.auth.scopes import AUDIT_READ
from backend.app.core.auth.policies import PolicyResult
from backend.app.core.audit.store import read_events, write_event

router = APIRouter(prefix="/audit", tags=["Audit"])


@router.get("")
async def list_audit_events(request: Request):
    """
    Return the most recent audit events.
    Requires audit:read scope.
    """
    user = request.state.user

    if AUDIT_READ not in ROLES[user.role]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Role lacks audit:read scope",
        )

    events = read_events(limit=200)
    return {"events": events}


@router.post("/record")
async def record_audit_event(request: Request):
    """
    Record a new audit event.
    Automatically includes risk score and policy reasons.
    """
    user = request.state.user
    policy: PolicyResult = request.state.policy

    body = await request.json()
    event_type = body.get("event_type")
    details = body.get("details", {})

    if not event_type:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing event_type",
        )

    record = write_event(
        event_type=event_type,
        actor=user.role,
        details={
            **details,
            "risk_score": policy.risk_score,
            "policy_reasons": policy.reasons,
        },
    )

    return {"recorded": record}
