from fastapi import APIRouter

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


@router.get("/console")
def get_task_console():
    return {
        "summary": {
            "pending": 3,
            "running": 1,
            "failed": 0,
            "completed": 12,
        }
    }
