from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from sqlalchemy.orm import Session

from ...storage.db import SessionLocal
from ...app.models.models import User


class AuthMiddleware(BaseHTTPMiddleware):
    """
    Extracts user/org from Authorization header (JWT or session token).
    Replace `decode_token` with your real implementation.
    """

    async def dispatch(self, request: Request, call_next):
        token = request.headers.get("Authorization")
        if token and token.startswith("Bearer "):
            token = token.replace("Bearer ", "").strip()
        else:
            request.state.user = None
            request.state.org_id = None
            return await call_next(request)

        db: Session = SessionLocal()
        try:
            payload = self.decode_token(token)
            user_id = payload.get("sub")
            if not user_id:
                raise HTTPException(status_code=401, detail="INVALID_TOKEN")

            user = db.query(User).filter(User.id == user_id).first()
            if not user:
                raise HTTPException(status_code=401, detail="USER_NOT_FOUND")

            request.state.user = user
            request.state.org_id = user.org_id

        except Exception:
            request.state.user = None
            request.state.org_id = None

        finally:
            db.close()

        return await call_next(request)

    def decode_token(self, token: str) -> dict:
        # TODO: Replace with real JWT decode
        # Example: return jwt.decode(token, SECRET, algorithms=["HS256"])
        return {"sub": token}  # TEMP: treat token as user_id
