from fastapi import APIRouter

from app.domain.policy import Policy, PolicyUpdate
from app.services.policy_service import PolicyService

router = APIRouter(prefix="/api/policies", tags=["policies-editor"])
_service = PolicyService()


@router.get("/{policy_id}", response_model=Policy)
def get_policy(policy_id: str):
    return _service.get_policy(policy_id)


@router.put("/{policy_id}", response_model=Policy)
def update_policy(policy_id: str, update: PolicyUpdate):
    return _service.update_policy(policy_id, update)
