from fastapi import APIRouter
from backend.app.api.workers.service import (
    get_workers,
    get_worker_detail,
    get_worker_logs,
)

router = APIRouter()

@router.get("/")
def list_workers():
    return get_workers()

@router.get("/{worker_id}")
def worker_detail(worker_id: str):
    return get_worker_detail(worker_id)

@router.get("/{worker_id}/logs")
def worker_logs(worker_id: str, limit: int = 200):
    return get_worker_logs(worker_id, limit)
