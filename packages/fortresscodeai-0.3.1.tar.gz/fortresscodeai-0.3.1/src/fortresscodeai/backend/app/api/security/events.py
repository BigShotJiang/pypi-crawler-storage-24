from fastapi import APIRouter

from app.domain.security import SecurityEvent
from fortresscodeai.backend.app.security.security_events import SecurityService

router = APIRouter(prefix="/api/security", tags=["security"])
_service = SecurityService()


@router.get("/events", response_model=list[SecurityEvent])
def get_security_events():
    return _service.list_events()
