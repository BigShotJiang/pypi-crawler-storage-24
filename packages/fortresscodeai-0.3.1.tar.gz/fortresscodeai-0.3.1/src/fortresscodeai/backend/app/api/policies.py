from fastapi import APIRouter, HTTPException
from typing import Dict, Any

from backend.app.governance.policies.registry import PolicyRegistry
from backend.app.governance.policies.loader import PolicyLoader
from backend.app.governance.policies.evaluator import PolicyEvaluator
from backend.app.governance.policies.versioning import PolicyVersionStore

from enum import Enum
from pydantic import BaseModel
from typing import List, Dict, Callable
from backend.app.core.auth.user import User
from backend.app.core.auth.context import RequestContext
from backend.app.core.auth.scopes import (
    WORKFLOW_MANAGE, AUDIT_READ, SECURITY_READ, HITL_APPROVE,
)

router = APIRouter(prefix="/policies", tags=["policies"])

# Injected singletons (you will initialize these in main.py)
registry: PolicyRegistry = None
loader: PolicyLoader = None
evaluator: PolicyEvaluator = None
versions: PolicyVersionStore = None


@router.get("/")
def list_policies():
    return {
        "active": list(registry.active.values()),
        "disabled": list(registry.disabled.values()),
    }


@router.get("/{policy_id}")
def get_policy(policy_id: str):
    policy = registry.get_policy(policy_id)
    if not policy:
        raise HTTPException(404, "Policy not found")
    return policy


@router.post("/reload")
def reload_policies():
    registry.active.clear()
    registry.disabled.clear()
    loader.load_all()
    return {"status": "reloaded", "count": len(registry.active)}


@router.post("/{policy_id}/simulate")
def simulate_policy(policy_id: str, context: Dict[str, Any]):
    policy = registry.get_policy(policy_id)
    if not policy:
        raise HTTPException(404, "Policy not found")

    results = evaluator.evaluate(policy.trigger, context)
    return {"results": results}


@router.get("/{policy_id}/versions")
def get_policy_versions(policy_id: str):
    return versions.get_versions(policy_id)

class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    CHALLENGE = "challenge"

class PolicyResult(BaseModel):
    decision: Decision
    reasons: List[str]
    risk_score: float
    required_scopes: List[str]

PolicyFn = Callable[[User, RequestContext, float], PolicyResult]
