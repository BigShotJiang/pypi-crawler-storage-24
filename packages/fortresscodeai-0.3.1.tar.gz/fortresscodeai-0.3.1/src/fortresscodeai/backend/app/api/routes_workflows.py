from fastapi import APIRouter, Request, HTTPException
from datetime import datetime

router = APIRouter(prefix="/workflows", tags=["workflows"])


# ---------------------------------------------------------
# List recent workflow runs (UI-friendly)
# ---------------------------------------------------------
@router.get("/recent")
async def get_recent_workflows(request: Request, limit: int = 50):
    db = request.app.state.workflow_db

    # Sort runs by creation time (if stored) or by ID fallback
    runs = list(db.runs.values())
    runs = sorted(runs, key=lambda r: r.id, reverse=True)[:limit]

    return [
        {
            "id": r.id,
            "workflow_id": r.workflow_id,
            "tenant_id": r.tenant_id,
            "status": r.status,
            "context_keys": list(r.context.keys()),
        }
        for r in runs
    ]


# ---------------------------------------------------------
# Trigger a workflow run
# ---------------------------------------------------------
@router.post("/{workflow_id}/runs")
async def trigger_workflow_run(workflow_id: str, payload: dict, request: Request):
    engine = request.app.state.workflow_engine
    job_queue = request.app.state.job_queue

    tenant_id = payload.get("tenant_id")
    if not tenant_id:
        raise HTTPException(status_code=400, detail="tenant_id is required")

    initial_context = payload.get("context", {})

    try:
        run = engine.create_run(
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            initial_context=initial_context,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Enqueue the run for background execution
    job_queue.enqueue({"type": "workflow_run", "run_id": run.id})

    return {
        "run_id": run.id,
        "status": "queued",
        "workflow_id": workflow_id,
        "tenant_id": tenant_id,
    }


# ---------------------------------------------------------
# Get workflow run details (UI panel)
# ---------------------------------------------------------
@router.get("/runs/{run_id}")
async def get_workflow_run(run_id: str, request: Request):
    db = request.app.state.workflow_db

    run = db.runs.get(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")

    # UI-friendly structure
    return {
        "id": run.id,
        "workflow_id": run.workflow_id,
        "tenant_id": run.tenant_id,
        "status": run.status,
        "context": run.context,
    }


# ---------------------------------------------------------
# Get workflow definition (optional)
# ---------------------------------------------------------
@router.get("/{workflow_id}")
async def get_workflow_detail(workflow_id: str, request: Request):
    db = request.app.state.workflow_db

    wf = db.workflows.get(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    return {
        "id": wf.id,
        "tenant_id": wf.tenant_id,
        "name": wf.name,
        "steps": [
            {
                "step_index": s.step_index,
                "agent_id": s.agent_id,
                "input_key": s.input_key,
                "output_key": s.output_key,
            }
            for s in wf.steps
        ],
    }
