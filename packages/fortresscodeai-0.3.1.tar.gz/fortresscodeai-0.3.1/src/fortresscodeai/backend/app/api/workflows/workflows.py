# backend/app/api/workflows.py

from fastapi import APIRouter, Request
from backend.app.core.auth.policies import PolicyResult
from backend.app.core.auth.scopes import WORKFLOW_MANAGE
from backend.app.core.auth.roles import ROLES
from fastapi import HTTPException, status

router = APIRouter(prefix="/workflows", tags=["Workflows"])

@router.post("/run")
async def run_workflow(request: Request):
    user = request.state.user
    policy: PolicyResult = request.state.policy

    if WORKFLOW_MANAGE not in ROLES[user.role]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Role lacks workflow:manage scope",
        )

    return {
        "status": "accepted",
        "requested_by": user.role,
        "risk_score": policy.risk_score,
        "policy_reasons": policy.reasons,
    }
