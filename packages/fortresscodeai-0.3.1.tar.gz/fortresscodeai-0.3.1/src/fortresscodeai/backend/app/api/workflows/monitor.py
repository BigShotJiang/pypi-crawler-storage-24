from fastapi import APIRouter

from app.domain.workflow import WorkflowInstance
from app.services.workflow_service import WorkflowService

router = APIRouter(prefix="/api/workflows", tags=["workflows"])
_service = WorkflowService()


@router.get("/monitor", response_model=list[WorkflowInstance])
def get_workflow_monitor():
    return _service.list_recent()
