from fastapi import APIRouter
from datetime import datetime

router = APIRouter(prefix="/metrics", tags=["metrics"])


@router.get("/overview")
async def get_metrics_overview():
    now = datetime.utcnow().isoformat() + "Z"
    return {
        "active_workflows": 0,
        "tasks_per_minute": 0,
        "queue_depth": 0,
        "worker_utilization": 0,
        "recent_events": [
            {
                "type": "system_boot",
                "workflow_id": None,
                "timestamp": now,
                "summary": "FortressCodeAI orchestrator initialized.",
            }
        ],
    }


@router.get("/events")
async def get_metrics_events(limit: int = 20):
    return []


@router.get("/queues")
async def get_metrics_queues():
    return [
        {
            "name": "default",
            "pending": 0,
            "active": 0,
            "rate_per_min": 0,
        }
    ]
