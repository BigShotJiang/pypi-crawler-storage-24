from fastapi import APIRouter, Request
import platform
import time

router = APIRouter(tags=["devtools"])


@router.get("/info")
async def dev_info():
    return {
        "python": platform.python_version(),
        "system": platform.system(),
        "release": platform.release(),
        "timestamp": time.time(),
    }


@router.get("/orchestrator")
async def orchestrator_state(request: Request):
    orch = getattr(request.app.state, "orchestrator", None)
    if not orch:
        return {"orchestrator": "not_initialized"}

    return {
        "executions": list(orch._executions.keys()),
        "pending": {
            k: list(v.keys()) for k, v in orch.hitl_manager._pending.items()
        },
        "approved": {
            k: list(v.keys()) for k, v in orch.hitl_manager._approved.items()
        },
    }
