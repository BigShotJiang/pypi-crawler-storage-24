from fastapi import APIRouter

from .routes_health import router as health_router
from .routes_plugins import router as plugins_router
from .routes_workflows import router as workflows_router
from .routes_devtools import router as devtools_router
from .routes_metrics import router as metrics_router

api_router = APIRouter()

api_router.include_router(health_router, prefix="/health")
api_router.include_router(plugins_router, prefix="/plugins")
api_router.include_router(workflows_router, prefix="/workflows")
api_router.include_router(devtools_router, prefix="/devtools")
api_router.include_router(metrics_router, prefix="/metrics")

__all__ = ["api_router"]
