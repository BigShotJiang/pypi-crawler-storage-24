from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

from ...storage.db import SessionLocal
from ..services.audit import AuditLogger


class AuditRouteMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, *, type: str, entity_type: str):
        super().__init__(app)
        self.type = type
        self.entity_type = entity_type

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)

        if 200 <= response.status_code < 400:
            db = SessionLocal()
            try:
                logger = AuditLogger(db)
                logger.log(
                    org_id=getattr(request.state, "org_id", None),
                    user=getattr(request.state, "user", None),
                    type=self.type,
                    entity_type=self.entity_type,
                    entity_id=getattr(request.state, "entity_id", None),
                    metadata={
                        "path": request.url.path,
                        "method": request.method,
                        "status": response.status_code,
                    },
                )
            finally:
                db.close()

        return response
