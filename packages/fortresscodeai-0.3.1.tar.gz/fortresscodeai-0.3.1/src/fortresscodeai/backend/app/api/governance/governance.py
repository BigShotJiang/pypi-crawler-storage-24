# src/fortresscodeai/backend/app/api/governance/governance.py

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Any, Dict

from fortresscodeai.backend.app.governance.governance_manager import GovernanceManager

router = APIRouter()
governance = GovernanceManager()


class GovernanceRequest(BaseModel):
    workflow_id: str
    step_name: str
    user_id: str
    agent_context: Dict[str, Any]
    input_data: Dict[str, Any]


class GovernanceResponse(BaseModel):
    allowed: bool
    reason: str
    risk_score: float
    violated_policies: list[str]
    audit_id: str | None
    explainability: Dict[str, Any]
    next_action: str


@router.post("/evaluate", response_model=GovernanceResponse)
async def evaluate_governance(request: GovernanceRequest):
    decision = governance.evaluate(
        workflow_id=request.workflow_id,
        step_name=request.step_name,
        user_id=request.user_id,
        agent_context=request.agent_context,
        input_data=request.input_data,
    )

    return GovernanceResponse(
        allowed=decision.allowed,
        reason=decision.reason,
        risk_score=decision.risk_score,
        violated_policies=decision.violated_policies,
        audit_id=decision.audit_id,
        explainability=decision.explainability,
        next_action=decision.next_action,
    )
