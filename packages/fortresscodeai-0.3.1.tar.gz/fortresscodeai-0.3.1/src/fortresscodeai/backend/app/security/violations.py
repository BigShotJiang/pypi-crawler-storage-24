import json
import os

VIOLATIONS_FILE = "violations.json"


def load_policy_violations():
    """
    Loads policy violations from disk.
    """

    if not os.path.exists(VIOLATIONS_FILE):
        return []

    with open(VIOLATIONS_FILE, "r") as f:
        try:
            return json.load(f)
        except Exception:
            return []
