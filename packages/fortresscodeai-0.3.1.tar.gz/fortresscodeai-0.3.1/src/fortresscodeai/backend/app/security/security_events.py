from __future__ import annotations

import logging
import time
from typing import Optional, Dict, Any


# ---------------------------------------------------------
# Logger Setup
# ---------------------------------------------------------

logger = logging.getLogger("fortress.security")
logger.setLevel(logging.INFO)


# ---------------------------------------------------------
# Security Event Model (simple, auditable)
# ---------------------------------------------------------

class SecurityEvents:
    """
    Centralized security event sink for the orchestration engine.
    This module is intentionally minimal and governance‑first:
    - No external calls
    - No async side effects
    - No persistence assumptions
    - No hidden behavior

    It is safe to extend later with:
    - SIEM forwarding
    - Webhook alerts
    - Email/SMS notifications
    - Audit log persistence
    """

    def alert(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """
        Record a high‑severity security event.

        Parameters:
            message: Human‑readable description of the event.
            context: Optional structured metadata (workflow_id, step_id, user, etc.)
        """
        event = {
            "ts": time.time(),
            "message": message,
            "context": context or {},
        }

        logger.warning(f"[SECURITY_ALERT] {event}")

    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """
        Record a low‑severity informational security event.
        """
        event = {
            "ts": time.time(),
            "message": message,
            "context": context or {},
        }

        logger.info(f"[SECURITY_EVENT] {event}")

    def critical(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """
        Record a critical‑severity event that may require immediate attention.
        """
        event = {
            "ts": time.time(),
            "message": message,
            "context": context or {},
        }

        logger.error(f"[SECURITY_CRITICAL] {event}")
