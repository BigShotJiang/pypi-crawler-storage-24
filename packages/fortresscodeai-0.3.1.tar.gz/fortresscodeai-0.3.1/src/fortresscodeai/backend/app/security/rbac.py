# security/rbac.py
from typing import Iterable
from .models import Role


def has_any_role(user_roles: Iterable[Role], allowed: Iterable[Role]) -> bool:
    return any(r in user_roles for r in allowed)
