# security/models.py
from enum import Enum
from pydantic import BaseModel


class Role(str, Enum):
    admin = "admin"
    security = "security"
    ops = "ops"
    developer = "developer"
    viewer = "viewer"


class UserContext(BaseModel):
    user_id: str
    tenant_id: str
    roles: list[Role]
