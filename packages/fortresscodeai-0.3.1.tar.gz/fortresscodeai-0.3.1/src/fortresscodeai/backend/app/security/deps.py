# security/deps.py
from fastapi import Depends, HTTPException, status, Request
from .models import UserContext, Role
from .rbac import has_any_role


async def get_current_user(request: Request) -> UserContext:
    # Example: decode JWT from cookie/header and build UserContext
    token = request.cookies.get("access_token") or request.headers.get("Authorization")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    # TODO: replace with real decode/lookup
    # This is a stub to show structure.
    payload = {
        "sub": "user-123",
        "tenant_id": "tenant-abc",
        "roles": ["admin"],
    }

    return UserContext(
        user_id=payload["sub"],
        tenant_id=payload["tenant_id"],
        roles=[Role(r) for r in payload["roles"]],
    )


def require_roles(*allowed: Role):
    async def dep(user: UserContext = Depends(get_current_user)) -> UserContext:
        if not has_any_role(user.roles, allowed):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
        return user
    return dep
