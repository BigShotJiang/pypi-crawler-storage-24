from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from .deps import get_current_user

class RBACMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Skip static assets and UI
        if request.url.path.startswith("/static") or request.url.path.startswith("/ui"):
            return await call_next(request)

        # Skip health checks or public endpoints if you have any
        if request.url.path in {"/health", "/"}:
            return await call_next(request)

        try:
            # Force authentication early
            await get_current_user(request)
        except HTTPException as exc:
            return JSONResponse(status_code=exc.status_code, content={"error": exc.detail})

        return await call_next(request)
