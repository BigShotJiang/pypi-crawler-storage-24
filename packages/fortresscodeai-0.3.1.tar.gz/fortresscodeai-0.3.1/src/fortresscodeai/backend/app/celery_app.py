# backend/app/celery_app.py

import os
import socket
import logging
from collections import deque
from celery import Celery
from celery.signals import worker_init, worker_process_init, after_setup_logger

# -------------------------------------------------------------------
# Celery Configuration
# -------------------------------------------------------------------

BROKER_URL = os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0")
RESULT_BACKEND = os.getenv("CELERY_RESULT_BACKEND", "redis://localhost:6379/1")

celery_app = Celery(
    "fortresscodeai",
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
    include=[
        "backend.app.tasks",          # if you have a tasks module
        "backend.app.services.tasks", # optional
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    worker_send_task_events=True,
    task_send_sent_event=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_track_started=True,
)

# -------------------------------------------------------------------
# Worker Identification
# -------------------------------------------------------------------

HOSTNAME = socket.gethostname()

def get_worker_id():
    return f"{HOSTNAME}-{os.getpid()}"

# -------------------------------------------------------------------
# In-Memory Log Buffers (for Worker Panel)
# -------------------------------------------------------------------

WORKER_LOGS = {}  # {worker_id: deque(maxlen=5000)}

def get_log_buffer(worker_id):
    if worker_id not in WORKER_LOGS:
        WORKER_LOGS[worker_id] = deque(maxlen=5000)
    return WORKER_LOGS[worker_id]

# -------------------------------------------------------------------
# Custom Logging Handler
# -------------------------------------------------------------------

class CeleryWorkerLogHandler(logging.Handler):
    def emit(self, record):
        worker_id = get_worker_id()
        buffer = get_log_buffer(worker_id)

        entry = {
            "timestamp": record.created,
            "level": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "worker": worker_id,
        }

        buffer.append(entry)

# -------------------------------------------------------------------
# Attach Logging Handler on Worker Startup
# -------------------------------------------------------------------

@after_setup_logger.connect
def setup_worker_logging(logger, *args, **kwargs):
    handler = CeleryWorkerLogHandler()
    logger.addHandler(handler)

# -------------------------------------------------------------------
# Worker Initialization Hooks
# -------------------------------------------------------------------

@worker_init.connect
def on_worker_init(**kwargs):
    worker_id = get_worker_id()
    get_log_buffer(worker_id)  # ensure buffer exists

@worker_process_init.connect
def on_worker_process_init(**kwargs):
    worker_id = get_worker_id()
    get_log_buffer(worker_id)

# -------------------------------------------------------------------
# Optional: Example Task
# -------------------------------------------------------------------

@celery_app.task(name="fortress.example_task")
def example_task(x, y):
    logger = logging.getLogger("fortress.worker")
    logger.info(f"Running example_task({x}, {y})")
    return x + y
