from __future__ import annotations

import click

# Lifecycle commands
from backend.cli.commands.setup import setup_cmd
from backend.cli.commands.up import up_cmd
from backend.cli.commands.down import down_cmd

# Operational commands
from backend.cli.commands.status import status_cmd
from backend.cli.commands.logs import logs_cmd
from backend.cli.commands.doctor import doctor_cmd

# Project creation command
from backend.cli.commands.create import create_cmd


@click.group(
    help=(
        "FortressCodeAI CLI\n"
        "Governance-first automation platform for engineering teams, agencies, and enterprises.\n\n"
        "Use `fortress create <project>` to scaffold a new Fortress project.\n"
        "Use `fortress setup` inside a project to install and initialize the platform."
    )
)
def cli() -> None:
    """Root FortressCodeAI CLI entrypoint."""
    pass


# Project creation
cli.add_command(create_cmd, "create")

# Primary lifecycle
cli.add_command(setup_cmd, "setup")
cli.add_command(up_cmd, "up")
cli.add_command(down_cmd, "down")

# Operational tools
cli.add_command(status_cmd, "status")
cli.add_command(logs_cmd, "logs")
cli.add_command(doctor_cmd, "doctor")
