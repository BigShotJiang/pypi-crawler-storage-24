from __future__ import annotations

import click

from backend.cli.runtime.api_launcher import is_api_running
from backend.cli.runtime.worker_launcher import is_worker_running


@click.command(name="status", help="Show FortressCodeAI service status.")
def status_cmd() -> None:
    api = "running" if is_api_running() else "stopped"
    worker = "running" if is_worker_running() else "stopped"

    click.echo("FortressCodeAI Status")
    click.echo("─────────────────────")
    click.echo(f"API:    {api}")
    click.echo(f"Worker: {worker}")
