from __future__ import annotations

import json
import os
from typing import Any, Dict

import requests


def _get_base_url() -> str:
    return os.environ.get("FCAI_BASE_URL", "http://localhost:8000")


def _post(path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    url = _get_base_url().rstrip("/") + path
    resp = requests.post(url, json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json()


def handle_replay(args) -> int:
    # For now, this is a stub that just documents intent.
    # Later you can add a /api/workflows/{id}/replay endpoint.
    print(
        "[fcx] replay is not yet wired to an API endpoint.\n"
        "      Expected: POST /api/workflows/{execution_id}/replay"
    )
    if args.dry_run:
        print(f"[fcx] would replay execution {args.execution_id} (dry-run).")
    else:
        print(f"[fcx] would replay execution {args.execution_id}.")
    return 0
