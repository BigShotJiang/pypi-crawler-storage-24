from __future__ import annotations

import json
import os
from typing import Any, Dict

import requests


def _get_base_url() -> str:
    return os.environ.get("FCAI_BASE_URL", "http://localhost:8000")


def _get(path: str) -> Dict[str, Any]:
    url = _get_base_url().rstrip("/") + path
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    return resp.json()


def handle_inspect(args) -> int:
    if args.execution_id:
        try:
            data = _get(f"/api/workflows/{args.execution_id}")
        except Exception as e:
            print(f"[fcx] failed to inspect execution: {e}")
            return 1
        print(json.dumps(data, indent=2))
        return 0

    if args.workflow_id:
        # placeholder – you can later add a /api/workflows/definition/{id} endpoint
        print("[fcx] workflow-id inspection not yet implemented (needs API support).")
        return 1

    print("[fcx] provide --execution-id or --workflow-id")
    return 1
