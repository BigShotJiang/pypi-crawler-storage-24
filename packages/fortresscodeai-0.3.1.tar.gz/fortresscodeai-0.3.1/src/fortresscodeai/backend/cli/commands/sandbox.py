from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

import requests
import yaml


def _get_base_url() -> str:
    return os.environ.get("FCAI_BASE_URL", "http://localhost:8000")


def _post(path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    url = _get_base_url().rstrip("/") + path
    resp = requests.post(url, json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json()


def _load_workflow(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() in {".yml", ".yaml"}:
        return yaml.safe_load(text)
    return json.loads(text)


def handle_sandbox(args) -> int:
    try:
        wf = _load_workflow(args.workflow_file)
    except Exception as e:
        print(f"[fcx] failed to load workflow: {e}")
        return 1

    if args.print_plan:
        print(json.dumps(wf, indent=2))
        return 0

    try:
        result = _post("/api/workflows/submit", wf)
    except Exception as e:
        print(f"[fcx] failed to submit workflow: {e}")
        return 1

    print(json.dumps(result, indent=2))
    return 0
