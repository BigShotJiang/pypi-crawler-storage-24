from __future__ import annotations

import os
import signal
import click

from backend.cli.runtime.paths import API_PID, WORKER_PID


@click.command(name="down", help="Stop FortressCodeAI services.")
def down_cmd() -> None:
    click.echo("Stopping FortressCodeAI services")
    click.echo("────────────────────────────────")

    _stop("API", API_PID)
    _stop("Worker", WORKER_PID)

    click.echo()
    click.echo("FortressCodeAI services stopped.")


def _stop(name: str, pid_file) -> None:
    if not pid_file.exists():
        click.echo(f"• {name}: no PID file, assuming not running.")
        return

    try:
        pid = int(pid_file.read_text().strip())
    except ValueError:
        click.echo(f"• {name}: invalid PID file.")
        pid_file.unlink(missing_ok=True)
        return

    try:
        os.kill(pid, signal.SIGTERM)
        click.echo(f"• {name}: sent SIGTERM to PID {pid}.")
    except OSError:
        click.echo(f"• {name}: process not running.")

    pid_file.unlink(missing_ok=True)
