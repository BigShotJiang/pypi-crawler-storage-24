from __future__ import annotations

import json
import os
import platform
import requests


def _base() -> str:
    return os.environ.get("FCAI_BASE_URL", "http://localhost:8000")


def _get(path: str):
    url = _base().rstrip("/") + path
    resp = requests.get(url, timeout=5)
    resp.raise_for_status()
    return resp.json()


def handle_dev(args):
    if args.info:
        info = {
            "python": platform.python_version(),
            "system": platform.system(),
            "release": platform.release(),
            "base_url": _base(),
        }
        print(json.dumps(info, indent=2))
        return 0

    if args.orchestrator:
        try:
            data = _get("/api/devtools/orchestrator")
        except Exception as e:
            print(f"[fortress] failed to query orchestrator: {e}")
            return 1
        print(json.dumps(data, indent=2))
        return 0

    print("[fortress] no dev flag provided; use --info or --orchestrator")
    return 1


def handle_dev_up(args):
    import uvicorn
    print("[fortress] starting development server with reload enabled...")
    uvicorn.run(
        "backend.app.main:app",
        host=args.host,
        port=int(args.port),
        reload=True,
    )
    return 0
