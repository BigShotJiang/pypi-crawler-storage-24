from __future__ import annotations

import click
from shutil import which
import socket


@click.command(name="doctor", help="Run environment diagnostics for FortressCodeAI.")
def doctor_cmd() -> None:
    click.echo("FortressCodeAI Diagnostics")
    click.echo("──────────────────────────")

    _check_cmd("python")
    _check_cmd("node")
    _check_cmd("git")

    _check_port(8000, "API")
    _check_port(5173, "Dashboard")

    click.echo("✓ Diagnostics complete.")


def _check_cmd(cmd: str) -> None:
    if which(cmd):
        click.echo(f"✓ {cmd} found")
    else:
        click.echo(f"✗ {cmd} NOT found")


def _check_port(port: int, name: str) -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(0.3)
    try:
        sock.connect(("127.0.0.1", port))
        click.echo(f"✓ {name} port {port} reachable")
    except OSError:
        click.echo(f"• {name} port {port} not reachable")
    finally:
        sock.close()
