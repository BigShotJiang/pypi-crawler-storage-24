from __future__ import annotations

import click

from backend.cli.runtime.paths import API_LOG, WORKER_LOG


@click.command(name="logs", help="Show logs for API or worker.")
@click.argument("service", type=click.Choice(["api", "worker"]))
def logs_cmd(service: str) -> None:
    log_file = API_LOG if service == "api" else WORKER_LOG

    if not log_file.exists():
        raise click.ClickException(f"No log file found for {service}.")

    click.echo_via_pager(log_file.read_text())
