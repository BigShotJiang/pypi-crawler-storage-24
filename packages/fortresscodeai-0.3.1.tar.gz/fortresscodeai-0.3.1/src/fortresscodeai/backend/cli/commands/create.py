from __future__ import annotations

import os
from pathlib import Path
import shutil

import click


@click.command(name="create", help="Create a new FortressCodeAI project.")
@click.argument("project_name")
def create_cmd(project_name: str) -> None:
    target = Path(project_name).resolve()

    click.echo("Creating FortressCodeAI project")
    click.echo("──────────────────────────────")

    if target.exists() and any(target.iterdir()):
        raise click.ClickException(
            f"Directory '{project_name}' already exists and is not empty."
        )

    _create_directory(target)
    _scaffold_backend(target)
    _write_fortress_yaml(target)

    click.echo()
    click.echo(f"Project '{project_name}' created.")
    click.echo(f"Next steps:")
    click.echo(f"  cd {project_name}")
    click.echo(f"  fortress setup")


def _create_directory(target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    (target / ".fortress").mkdir(exist_ok=True)
    (target / ".fortress" / "logs").mkdir(parents=True, exist_ok=True)
    (target / ".fortress" / "pids").mkdir(parents=True, exist_ok=True)
    (target / ".fortress" / "config").mkdir(parents=True, exist_ok=True)


def _scaffold_backend(target: Path) -> None:
    backend = target / "backend" / "app"
    (backend / "api").mkdir(parents=True, exist_ok=True)
    (backend / "workers").mkdir(parents=True, exist_ok=True)
    (backend / "db").mkdir(parents=True, exist_ok=True)
    (backend / "ui").mkdir(parents=True, exist_ok=True)

    # Minimal API entrypoint
    (backend / "api" / "main.py").write_text(
        "from backend.app.create_app import create_api_app\n\n"
        "def main():\n"
        "    import uvicorn\n"
        "    app = create_api_app()\n"
        "    uvicorn.run(app, host='0.0.0.0', port=8000)\n\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )

    # Minimal worker entrypoint
    (backend / "workers" / "start.py").write_text(
        "from backend.app.workers.runtime import create_worker_runtime\n\n"
        "def main():\n"
        "    runtime = create_worker_runtime()\n"
        "    worker = runtime['worker']\n"
        "    worker.start()\n\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )

    # Minimal storage init
    (backend / "db" / "init.py").write_text(
        "from backend.app.storage import Storage\n\n"
        "def main():\n"
        "    storage = Storage()\n"
        "    if hasattr(storage, 'initialize'):\n"
        "        storage.initialize()\n"
        "    if hasattr(storage, 'run_migrations'):\n"
        "        storage.run_migrations()\n"
        "    if hasattr(storage, 'seed_defaults'):\n"
        "        storage.seed_defaults()\n\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )


def _write_fortress_yaml(target: Path) -> None:
    config = target / "fortress.yml"
    config.write_text(
        "project:\n"
        f"  name: {target.name}\n"
        "  version: 0.1.0\n\n"
        "runtime:\n"
        "  api_port: 8000\n"
        "  dashboard_port: 5173\n"
        "  storage_backend: filesystem\n\n"
        "paths:\n"
        "  policies: backend/app/governance/policies\n"
        "  plugins: backend/app/plugins\n"
    )
