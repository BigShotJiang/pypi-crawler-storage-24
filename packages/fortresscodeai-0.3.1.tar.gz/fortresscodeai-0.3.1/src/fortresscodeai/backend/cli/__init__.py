from fortresscodeai.cli import setup_cmd
from fortresscodeai.cli import cli

cli.add_command(setup_cmd, "setup")
