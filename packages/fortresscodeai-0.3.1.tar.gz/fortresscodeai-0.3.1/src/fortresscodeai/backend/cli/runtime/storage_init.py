from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from backend.cli.runtime.paths import PROJECT_ROOT, VENV_DIR, BACKEND_SRC, DASHBOARD_SRC


def _python_executable() -> Path:
    if sys.platform == "win32":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def init_storage() -> None:
    """
    Run the FortressCodeAI storage initialization script, if present.
    """
    db_init = PROJECT_ROOT / "backend" / "app" / "db" / "init.py"
    if not db_init.exists():
        return

    python = _python_executable()
    subprocess.check_call([str(python), str(db_init)], cwd=PROJECT_ROOT)
