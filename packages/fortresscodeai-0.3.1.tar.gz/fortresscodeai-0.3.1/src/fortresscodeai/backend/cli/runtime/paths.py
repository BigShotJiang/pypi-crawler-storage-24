from __future__ import annotations

import os
from pathlib import Path


# ------------------------------------------------------------
# 1. Determine the global Fortress runtime directory
# ------------------------------------------------------------

def _resolve_fortress_root() -> Path:
    """
    Determine where FortressCodeAI stores its runtime files.
    Windows → %APPDATA%\FortressCodeAI
    macOS   → ~/Library/Application Support/FortressCodeAI
    Linux   → ~/.fortresscodeai
    """
    if os.name == "nt":
        base = Path(os.getenv("APPDATA")) / "FortressCodeAI"
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "FortressCodeAI"
    else:
        base = Path.home() / ".fortresscodeai"

    base.mkdir(parents=True, exist_ok=True)
    return base


FORTRESS_ROOT: Path = _resolve_fortress_root()


# ------------------------------------------------------------
# 2. Virtual environment directory
# ------------------------------------------------------------

VENV_DIR: Path = FORTRESS_ROOT / "venv"


# ------------------------------------------------------------
# 3. Backend + dashboard source locations (inside the package)
# ------------------------------------------------------------

PACKAGE_ROOT = Path(__file__).resolve().parent.parent

BACKEND_SRC: Path = PACKAGE_ROOT / "backend"
DASHBOARD_SRC: Path = PACKAGE_ROOT / "dashboard"


# ------------------------------------------------------------
# 4. Runtime subdirectories
# ------------------------------------------------------------

LOGS_DIR: Path = FORTRESS_ROOT / "logs"
PIDS_DIR: Path = FORTRESS_ROOT / "pids"
CONFIG_PATH: Path = FORTRESS_ROOT / "config.yaml"


# Ensure directories exist
LOGS_DIR.mkdir(exist_ok=True)
PIDS_DIR.mkdir(exist_ok=True)
