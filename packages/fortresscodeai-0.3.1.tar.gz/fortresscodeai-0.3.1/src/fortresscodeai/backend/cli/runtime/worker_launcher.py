from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from .paths import FORTRESS_ROOT, VENV_DIR, PIDS_DIR


WORKER_PID_FILE = PIDS_DIR / "worker.pid"


def is_worker_running() -> bool:
    """Return True if the worker process is running."""
    if not WORKER_PID_FILE.exists():
        return False

    try:
        pid = int(WORKER_PID_FILE.read_text().strip())
    except ValueError:
        return False

    return _pid_exists(pid)


def start_worker() -> int:
    """Start the worker service in a detached background process."""
    python_path = (
        VENV_DIR / "Scripts" / "python.exe"
        if os.name == "nt"
        else VENV_DIR / "bin" / "python"
    )

    worker_script = FORTRESS_ROOT / "backend" / "worker.py"

    if not worker_script.exists():
        raise RuntimeError(f"Worker entrypoint not found: {worker_script}")

    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS

    process = subprocess.Popen(
        [str(python_path), str(worker_script)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        creationflags=creationflags,
        close_fds=True,
    )

    WORKER_PID_FILE.write_text(str(process.pid))
    return process.pid


def _pid_exists(pid: int) -> bool:
    """Check if a process with the given PID exists."""
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True
