from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from .paths import FORTRESS_ROOT, VENV_DIR, PIDS_DIR


API_PID_FILE = PIDS_DIR / "api.pid"


def is_api_running() -> bool:
    """Return True if the API process is running."""
    if not API_PID_FILE.exists():
        return False

    try:
        pid = int(API_PID_FILE.read_text().strip())
    except ValueError:
        return False

    return _pid_exists(pid)


def start_api() -> int:
    """Start the API service in a detached background process."""
    python_path = (
        VENV_DIR / "Scripts" / "python.exe"
        if os.name == "nt"
        else VENV_DIR / "bin" / "python"
    )

    api_script = FORTRESS_ROOT / "backend" / "main.py"

    if not api_script.exists():
        raise RuntimeError(f"API entrypoint not found: {api_script}")

    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS

    process = subprocess.Popen(
        [str(python_path), str(api_script)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        creationflags=creationflags,
        close_fds=True,
    )

    API_PID_FILE.write_text(str(process.pid))
    return process.pid


def wait_for_api(timeout: float = 10.0) -> bool:
    """Wait for the API to respond on port 8000."""
    import time
    import socket

    start = time.time()

    while time.time() - start < timeout:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.5)
            try:
                sock.connect(("127.0.0.1", 8000))
                return True
            except OSError:
                pass
        time.sleep(0.2)

    return False


def _pid_exists(pid: int) -> bool:
    """Check if a process with the given PID exists."""
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True
