from __future__ import annotations

import os
import sys
import shutil
import subprocess
from pathlib import Path

from .paths import (
    FORTRESS_ROOT,
    VENV_DIR,
    BACKEND_SRC,
    DASHBOARD_SRC,
    LOGS_DIR,
    PIDS_DIR,
    CONFIG_PATH,
)


def ensure_bootstrap() -> None:
    """
    Ensure the Fortress runtime is fully initialized before starting services.
    This is called automatically by `fortress up`.
    """
    if is_initialized():
        return

    print("FortressCodeAI is not initialized. Preparing environment...")
    bootstrap_runtime()
    print("✓ FortressCodeAI runtime initialized.\n")


def is_initialized() -> bool:
    """
    Check if the runtime has already been initialized.
    """
    return (FORTRESS_ROOT / ".initialized").exists()


def bootstrap_runtime() -> None:
    """
    Create the full Fortress runtime environment:
    - runtime directory
    - virtual environment
    - dependency installation
    - backend + dashboard extraction
    - config generation
    - logs + PID directories
    """
    # 1. Ensure root directory exists
    FORTRESS_ROOT.mkdir(parents=True, exist_ok=True)

    # 2. Create virtual environment if missing
    if not VENV_DIR.exists():
        print("• Creating virtual environment...")
        subprocess.run([sys.executable, "-m", "venv", str(VENV_DIR)], check=True)

    # 3. Install dependencies inside venv
    pip_path = (
        VENV_DIR / "Scripts" / "pip.exe"
        if os.name == "nt"
        else VENV_DIR / "bin" / "pip"
    )

    print("• Installing backend dependencies...")
    backend_requirements = BACKEND_SRC / "requirements.txt"
    if backend_requirements.exists():
        subprocess.run([str(pip_path), "install", "-r", str(backend_requirements)], check=True)

    print("• Installing worker dependencies...")
    worker_requirements = BACKEND_SRC / "worker-requirements.txt"
    if worker_requirements.exists():
        subprocess.run([str(pip_path), "install", "-r", str(worker_requirements)], check=True)

    # 4. Copy backend + dashboard runtime files
    print("• Copying backend files...")
    shutil.copytree(BACKEND_SRC, FORTRESS_ROOT / "backend", dirs_exist_ok=True)

    print("• Copying dashboard files...")
    shutil.copytree(DASHBOARD_SRC, FORTRESS_ROOT / "dashboard", dirs_exist_ok=True)

    # 5. Ensure logs + PID directories exist
    LOGS_DIR.mkdir(exist_ok=True)
    PIDS_DIR.mkdir(exist_ok=True)

    # 6. Write default config if missing
    if not CONFIG_PATH.exists():
        print("• Writing default config...")
        CONFIG_PATH.write_text("default_config: true\n")

    # 7. Mark initialization complete
    (FORTRESS_ROOT / ".initialized").write_text("ok")
