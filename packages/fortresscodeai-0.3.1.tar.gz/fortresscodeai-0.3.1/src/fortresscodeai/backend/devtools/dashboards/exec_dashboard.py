from pathlib import Path
from datetime import datetime, timedelta
from typing import Any, Dict, List

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

BASE_DIR = Path(__file__).resolve().parents[2] / "app"
templates = Jinja2Templates(directory=str(BASE_DIR / "templates" / "exec"))

router = APIRouter(prefix="/dev/exec")


def get_overview() -> Dict[str, Any]:
    return {
        "total_executions": 42,
        "running": 3,
        "pending_hitl": 2,
        "security_incidents_24h": 1,
        "policy_blocks_24h": 2,
    }


def get_security_metrics() -> Dict[str, Any]:
    return {
        "auth_failures_24h": 5,
        "suspicious_logins_24h": 1,
        "lockouts_24h": 0,
        "security_incidents": [
            {"severity": "low", "count": 3},
            {"severity": "medium", "count": 1},
            {"severity": "high", "count": 0},
        ],
    }


def get_security_events() -> List[Dict[str, Any]]:
    now = datetime.utcnow()
    return [
        {
            "type": "alert",
            "message": "Suspicious login attempt detected.",
            "ts": (now - timedelta(minutes=5)).isoformat(),
        },
        {
            "type": "info",
            "message": "RBAC change: new role added.",
            "ts": (now - timedelta(hours=1)).isoformat(),
        },
    ]


@router.get("", response_class=HTMLResponse)
async def exec_root(request: Request):
    overview = get_overview()
    return templates.TemplateResponse(
        "exec_superdashboard.html",
        {
            "request": request,
            "overview": overview,
            "active_tab": "system",
            "title": "System Overview • FortressCodeAI",
        },
    )


@router.get("/tab/system", response_class=HTMLResponse)
async def exec_tab_system(request: Request):
    return templates.TemplateResponse(
        "tabs/system.html",
        {
            "request": request,
            "active_tab": "system",
            "title": "System • FortressCodeAI",
        },
    )


@router.get("/tab/governance", response_class=HTMLResponse)
async def exec_tab_governance(request: Request):
    return templates.TemplateResponse(
        "tabs/governance.html",
        {
            "request": request,
            "active_tab": "governance",
            "title": "Governance • FortressCodeAI",
        },
    )


@router.get("/tab/hitl", response_class=HTMLResponse)
async def exec_tab_hitl(request: Request):
    return templates.TemplateResponse(
        "tabs/hitl.html",
        {
            "request": request,
            "active_tab": "hitl",
            "title": "HITL • FortressCodeAI",
        },
    )


@router.get("/tab/security", response_class=HTMLResponse)
async def exec_tab_security(request: Request):
    metrics = get_security_metrics()
    events = get_security_events()
    return templates.TemplateResponse(
        "tabs/security.html",
        {
            "request": request,
            "sec": metrics,
            "events": events,
            "active_tab": "security",
            "title": "Security • FortressCodeAI",
        },
    )


@router.get("/tab/workforce", response_class=HTMLResponse)
async def exec_tab_workforce(request: Request):
    return templates.TemplateResponse(
        "tabs/workforce.html",
        {
            "request": request,
            "active_tab": "workforce",
            "title": "Workforce • FortressCodeAI",
        },
    )


@router.get("/tab/activity", response_class=HTMLResponse)
async def exec_tab_activity(request: Request):
    return templates.TemplateResponse(
        "tabs/activity.html",
        {
            "request": request,
            "active_tab": "activity",
            "title": "Activity • FortressCodeAI",
        },
    )


@router.get("/tab/metrics", response_class=HTMLResponse)
async def exec_tab_metrics(request: Request):
    return templates.TemplateResponse(
        "tabs/metrics.html",
        {
            "request": request,
            "active_tab": "metrics",
            "title": "Metrics • FortressCodeAI",
        },
    )


@router.get("/tab/devtools", response_class=HTMLResponse)
async def exec_tab_devtools(request: Request):
    return templates.TemplateResponse(
        "tabs/devtools.html",
        {
            "request": request,
            "active_tab": "devtools",
            "title": "Devtools • FortressCodeAI",
        },
    )


@router.get("/tab/plugins", response_class=HTMLResponse)
async def exec_tab_plugins(request: Request):
    return templates.TemplateResponse(
        "tabs/plugins.html",
        {
            "request": request,
            "active_tab": "plugins",
            "title": "Plugins • FortressCodeAI",
        },
    )
    @router.get("/api/system/overview")
    async def api_system_overview():
        return await storage.get_system_overview()
