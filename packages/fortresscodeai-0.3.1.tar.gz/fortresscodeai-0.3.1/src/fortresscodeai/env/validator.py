import sys
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path

REQUIRED_PYTHON = (3, 10)
REQUIRED_PACKAGES = [
    "fastapi",
    "uvicorn",
    "pydantic",
    "click",
    "requests",
    "PyYAML",
    "jinja2"
]

def validate_environment():
    # Python version
    if sys.version_info < REQUIRED_PYTHON:
        raise RuntimeError(f"Python {REQUIRED_PYTHON[0]}.{REQUIRED_PYTHON[1]}+ required.")

    # Package checks
    for pkg in REQUIRED_PACKAGES:
        try:
            version(pkg)
        except PackageNotFoundError:
            raise RuntimeError(f"Missing dependency: {pkg}")

    # Project structure check
    if not Path("src/fortresscodeai").exists():
        raise RuntimeError("Project structure invalid: src/fortresscodeai not found.")

    return True
