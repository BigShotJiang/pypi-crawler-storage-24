from .cli import cli

# Running `python -m fortresscodeai` will execute the CLI
if __name__ == "__main__":
    cli()
