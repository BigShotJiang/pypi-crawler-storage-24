from pathlib import Path

from src.services.codegraph.search import CodeGraphIndex, build_symbols_for_file


def test_build_symbols_for_file(tmp_path: Path):
    file = tmp_path / "example.py"
    file.write_text(
        "def foo():\n    pass\n\nclass Bar:\n    def baz(self):\n        pass\n",
        encoding="utf-8",
    )

    symbols = build_symbols_for_file(str(file))
    names = {s.name for s in symbols}
    assert "foo" in names
    assert "Bar" in names


def test_index_roundtrip(tmp_path: Path):
    root = tmp_path
    index = CodeGraphIndex(root=str(root))

    file = root / "example.py"
    file.write_text("def foo():\n    pass\n", encoding="utf-8")
    symbols = build_symbols_for_file(str(file))

    index.update_file(str(file), symbols)
    result = index.search_text("foo")
    assert len(result.matches) >= 1
