# tests/test_security.py
import pytest
from jose import JWTError, ExpiredSignatureError
from datetime import timedelta, datetime
from src.security import create_access_token, decode_access_token
from src.config import settings

# Override expiration for testing
def create_short_lived_token(data: dict, seconds: int):
    expire = datetime.utcnow() + timedelta(seconds=seconds)
    data.update({"exp": expire})
    return create_access_token(data)

def test_token_creation_and_decoding():
    data = {"sub": "test-user"}
    token = create_access_token(data)
    decoded = decode_access_token(token)
    assert decoded["sub"] == "test-user"

def test_token_contains_expiration():
    data = {"sub": "test-user"}
    token = create_access_token(data)
    decoded = decode_access_token(token)
    assert "exp" in decoded

def test_invalid_token_raises_jwt_error():
    with pytest.raises(JWTError):
        decode_access_token("this.is.not.a.valid.token")

def test_expired_token_raises_error():
    token = create_short_lived_token({"sub": "expired-user"}, seconds=-1)
    with pytest.raises(ExpiredSignatureError):
        decode_access_token(token)

def test_missing_sub_claim():
    token = create_access_token({})
    decoded = decode_access_token(token)
    assert "sub" not in decoded  # Should not raise, but sub is missing

def test_custom_claims():
    data = {"sub": "user123", "role": "admin"}
    token = create_access_token(data)
    decoded = decode_access_token(token)
    assert decoded["role"] == "admin"
