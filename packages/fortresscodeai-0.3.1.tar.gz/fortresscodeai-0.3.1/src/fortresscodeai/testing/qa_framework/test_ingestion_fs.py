from pathlib import Path

from src.services.ingestion.file_system_ingestion import ingest_workspace
from src.services.codegraph.search import CodeGraphIndex


def test_ingest_workspace(tmp_path: Path, monkeypatch):
    root = tmp_path
    src = root / "src"
    src.mkdir()
    f = src / "example.py"
    f.write_text("def foo():\n    pass\n", encoding="utf-8")

    monkeypatch.setenv("FORTRESS_WORKSPACE_ROOT", str(root))
    ingest_workspace(root=str(root))

    index = CodeGraphIndex(root=str(root))
    result = index.search_text("foo")
    assert len(result.matches) >= 1
