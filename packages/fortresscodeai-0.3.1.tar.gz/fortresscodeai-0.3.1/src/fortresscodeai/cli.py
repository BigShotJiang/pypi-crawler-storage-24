import click
import uvicorn

@click.group()
def cli():
    """FortressCodeAI command-line interface."""
    pass


@cli.command()
@click.option("--host", default="127.0.0.1", help="Host interface to bind the server.")
@click.option("--port", default=8000, help="Port to run the server on.")
@click.option("--reload", is_flag=True, default=True, help="Enable auto-reload for development.")
def up(host, port, reload):
    """Start the FortressCodeAI platform."""
    uvicorn.run(
        "fortresscodeai.backend.main:app",
        host=host,
        port=port,
        reload=reload
    )
