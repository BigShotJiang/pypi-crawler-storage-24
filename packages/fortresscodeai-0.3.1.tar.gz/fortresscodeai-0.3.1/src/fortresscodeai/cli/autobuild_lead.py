import argparse
import json
from fortress.autobuilder.lead.service import build_lead_packet


def main():
    parser = argparse.ArgumentParser(description="Autobuild Lead Intelligence Packet")
    parser.add_argument("--name", type=str, help="Lead name")
    parser.add_argument("--company", type=str, help="Lead company")
    parser.add_argument("--linkedin_url", type=str, help="LinkedIn URL")
    parser.add_argument("--email_domain", type=str, help="Email domain")
    parser.add_argument("--input", type=str, help="Path to JSON file with lead data")

    args = parser.parse_args()

    if args.input:
        with open(args.input, "r") as f:
            raw_input = json.load(f)
    else:
        raw_input = {
            "name": args.name,
            "company": args.company,
            "linkedin_url": args.linkedin_url,
            "email_domain": args.email_domain,
        }

    packet = build_lead_packet(raw_input)

    print("\n=== Lead Intelligence Packet ===\n")
    print(packet.markdown)
    print("\n=== Audit Log ===\n")
    print(json.dumps(packet.audit_log, indent=2))


if __name__ == "__main__":
    main()
