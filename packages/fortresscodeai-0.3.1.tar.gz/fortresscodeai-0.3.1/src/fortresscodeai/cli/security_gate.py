import argparse
import json
import logging
import sys
from typing import List

from fortresscodeai.src.governance import HybridGovernanceScanner, GovernanceReport, IssueSeverity


def setup_logging(level=logging.INFO):
    logging.basicConfig(
        level=level,
        format="[%(asctime)s] [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def _print_report(report: GovernanceReport, as_json: bool) -> int:
    if as_json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        if not report.issues:
            logging.info("No governance issues found.")
            return 0

        logging.warning("Governance issues detected:")
        for issue in report.issues:
            logging.warning(
                f"{issue.file}:{issue.line} "
                f"[{issue.severity.value}/{issue.issue_type.value}] "
                f"{issue.code} - {issue.message}"
            )

    # Exit code: 0 if no blocking issues, 1 otherwise
    return 1 if report.has_blocking_issues else 0


def main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="FortressCodeAI Hybrid Governance Scanner")
    parser.add_argument("paths", nargs="+", help="Paths (files or directories) to scan.")
    parser.add_argument("--json", action="store_true", help="Output report as JSON.")
    parser.add_argument(
        "--fail-on",
        choices=[s.value for s in IssueSeverity],
        default=IssueSeverity.HIGH.value,
        help="Minimum severity that should be treated as blocking (default: HIGH).",
    )

    args = parser.parse_args(argv)

    setup_logging()

    scanner = HybridGovernanceScanner(args.paths)
    report = scanner.run()

    # Optionally adjust blocking threshold (for now we keep has_blocking_issues simple)
    exit_code = _print_report(report, as_json=args.json)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
