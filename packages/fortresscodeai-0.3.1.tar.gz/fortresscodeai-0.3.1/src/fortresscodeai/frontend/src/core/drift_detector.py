# src/observability/drift_monitoring/drift_detector.py

import json
import os
from typing import Dict
from importlib import import_module

BASELINE_PATH = os.path.join(os.path.dirname(__file__), 'patterns_baselines.json')

def load_baselines() -> Dict:
    with open(BASELINE_PATH, 'r') as f:
        return json.load(f)

def detect_drift(live_metrics: Dict[str, float]):
    baselines = load_baselines()
    alerts = []

    for policy_id, metrics in live_metrics.items():
        if policy_id not in baselines:
            continue

        for metric, live_value in metrics.items():
            baseline = baselines[policy_id].get(metric)
            if baseline is None:
                continue

            delta = abs(live_value - baseline)
            if delta > 0.2:
                alerts.append((policy_id, metric, delta))

    return alerts
