from fastapi import APIRouter, Depends, Request
from ...db import get_db
from ..services.onboarding import OnboardingService

router = APIRouter(prefix="/onboarding", tags=["onboarding"])


@router.get("/state")
def get_state(request: Request, db=Depends(get_db)):
    org_id = request.state.org_id
    return OnboardingService(db).get_state(org_id)


@router.post("/advance/{step}")
def advance(step: str, request: Request, db=Depends(get_db)):
    org_id = request.state.org_id
    return OnboardingService(db).advance(org_id, step)
