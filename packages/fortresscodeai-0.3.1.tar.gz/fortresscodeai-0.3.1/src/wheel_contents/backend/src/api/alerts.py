from fastapi import APIRouter, Depends, Request
from ...db import get_db
from ..services.alerts import AlertService

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("/")
def list_alerts(request: Request, db=Depends(get_db)):
    org_id = request.state.org_id
    return AlertService(db, email_sender=lambda **k: None).list_org_alerts(org_id)
