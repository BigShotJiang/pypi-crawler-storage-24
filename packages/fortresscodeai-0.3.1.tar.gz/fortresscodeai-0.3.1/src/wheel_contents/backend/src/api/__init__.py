from fastapi import APIRouter

from .analytics import router as analytics_router
from .billing import router as billing_router
from .onboarding import router as onboarding_router
from .alerts import router as alerts_router
from .settings import router as settings_router
from .audit import router as audit_router
from .repo_policy import router as repo_policy_router

router = APIRouter()

router.include_router(analytics_router)
router.include_router(billing_router)
router.include_router(onboarding_router)
router.include_router(alerts_router)
router.include_router(settings_router)
router.include_router(audit_router)
router.include_router(repo_policy_router)
