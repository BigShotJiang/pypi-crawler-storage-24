from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from ...db import get_db
from ..models_repo_policy import RepoConnection, PolicyConfig
from ..services.rbac import require_permission

router = APIRouter(prefix="/org", tags=["org"])


@router.get("/repos")
def list_repos(request: Request, db: Session = Depends(get_db)):
    user = request.state.user
    require_permission(user, "use_product")

    return (
        db.query(RepoConnection)
        .filter(RepoConnection.org_id == user.org_id)
        .all()
    )


@router.post("/repos")
def add_repo(
    request: Request,
    payload: dict,
    db: Session = Depends(get_db),
):
    user = request.state.user
    require_permission(user, "use_product")

    conn = RepoConnection(
        org_id=user.org_id,
        provider=payload["provider"],
        repo=payload["repo"],
        config=payload.get("config", {}),
    )
    db.add(conn)
    db.commit()
    db.refresh(conn)
    return conn


@router.get("/policies")
def get_policies(request: Request, db: Session = Depends(get_db)):
    user = request.state.user
    require_permission(user, "use_product")

    cfg = (
        db.query(PolicyConfig)
        .filter(PolicyConfig.org_id == user.org_id)
        .first()
    )
    return cfg.rules if cfg else {}


@router.post("/policies")
def update_policies(
    request: Request,
    payload: dict,
    db: Session = Depends(get_db),
):
    user = request.state.user
    require_permission(user, "use_product")

    cfg = (
        db.query(PolicyConfig)
        .filter(PolicyConfig.org_id == user.org_id)
        .first()
    )
    if not cfg:
        cfg = PolicyConfig(org_id=user.org_id, rules=payload)
        db.add(cfg)
    else:
        cfg.rules = payload
    db.commit()
    db.refresh(cfg)
    return cfg.rules
