from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from ...db import get_db
from ...models import AuditEvent
from ..services.rbac import require_permission

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("/")
def list_audit(
    request: Request,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    user = request.state.user
    require_permission(user, "view_audit")

    events = (
        db.query(AuditEvent)
        .filter(AuditEvent.org_id == user.org_id)
        .order_by(AuditEvent.created_at.desc())
        .limit(limit)
        .all()
    )
    return events
