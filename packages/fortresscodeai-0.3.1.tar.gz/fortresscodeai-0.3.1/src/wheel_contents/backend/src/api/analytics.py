from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Request

from ...db import get_db
from ..services.analytics import UsageAnalyticsService

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/usage")
def get_usage(
    request: Request,
    days: int = 7,
    db=Depends(get_db),
):
    org_id = getattr(request.state, "org_id", None)
    if not org_id:
        # you can enforce auth here
        raise HTTPException(status_code=400, detail="ORG_REQUIRED")

    end = datetime.utcnow()
    start = end - timedelta(days=days)
    service = UsageAnalyticsService(db)
    return service.get_org_usage_summary(org_id=org_id, start=start, end=end)
