from __future__ import annotations

import click

from backend.cli.commands.setup import setup_cmd
from backend.cli.commands.up import up_cmd
from backend.cli.commands.down import down_cmd
from backend.cli.commands.status import status_cmd
from backend.cli.commands.logs import logs_cmd
from backend.cli.commands.doctor import doctor_cmd


@click.group(
    help=(
        "FortressCodeAI CLI\n"
        "Governance-first automation platform for teams, agencies, and engineering orgs."
    )
)
def cli() -> None:
    """Root FortressCodeAI CLI entrypoint."""
    pass


# Primary lifecycle commands
cli.add_command(setup_cmd, "setup")
cli.add_command(up_cmd, "up")
cli.add_command(down_cmd, "down")

# Operational commands
cli.add_command(status_cmd, "status")
cli.add_command(logs_cmd, "logs")
cli.add_command(doctor_cmd, "doctor")
