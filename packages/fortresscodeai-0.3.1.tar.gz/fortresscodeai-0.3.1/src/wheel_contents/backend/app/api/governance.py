from fastapi import APIRouter
from typing import Dict, Any

from backend.app.governance.policies.evaluator import PolicyEvaluator

router = APIRouter(prefix="/governance", tags=["governance"])

evaluator: PolicyEvaluator = None  # injected in main.py


@router.post("/evaluate/{trigger}")
def evaluate(trigger: str, context: Dict[str, Any]):
    results = evaluator.evaluate(trigger, context)
    return {"results": results}
