from typing import Any, Dict
from datetime import datetime
from .storage import storage
from .dependencies import get_settings
from .policy_engine import policy_engine
from .hitl_queue import hitl_queue


class WorkflowOrchestrator:
    def __init__(self):
        self.settings = get_settings()
        self.namespace = f"{self.settings.STORAGE_NAMESPACE}_workflows"

    def start_workflow(self, name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        ctx = {
            "name": name,
            "payload": payload,
            "status": "running",
            "started_at": datetime.utcnow().isoformat(),
        }
        ctx = storage.save(self.namespace, "executions", ctx)

        decision = policy_engine.evaluate({"workflow": name, "payload": payload})
        if not decision.allowed:
            ctx["status"] = "blocked"
            ctx["policy_reasons"] = decision.reasons
            storage.save(self.namespace, "executions", ctx)
            hitl_queue.enqueue(
                {
                    "workflow_id": ctx["id"],
                    "workflow_name": name,
                    "reason": "policy_conflict",
                    "details": {"reasons": decision.reasons},
                }
            )
        else:
            ctx["status"] = "completed"
            ctx["completed_at"] = datetime.utcnow().isoformat()
            storage.save(self.namespace, "executions", ctx)

        return ctx


orchestrator = WorkflowOrchestrator()
