from typing import Any, Dict, List, Tuple
from .storage import storage
from .dependencies import get_settings


class PolicyDecision:
    def __init__(self, allowed: bool, reasons: List[str]):
        self.allowed = allowed
        self.reasons = reasons


class PolicyEngine:
    def __init__(self):
        self.settings = get_settings()
        self.namespace = f"{self.settings.STORAGE_NAMESPACE}_policies"

    def list_policies(self) -> List[Dict[str, Any]]:
        return storage.list(self.namespace, "policies")

    def save_policy(self, policy: Dict[str, Any]) -> Dict[str, Any]:
        return storage.save(self.namespace, "policies", policy)

    def evaluate(self, context: Dict[str, Any]) -> PolicyDecision:
        # Stub: always allow, but record a “compliant” decision
        reasons = ["Stub policy engine: allowed by default."]
        return PolicyDecision(allowed=True, reasons=reasons)

    def simulate(self, context: Dict[str, Any]) -> Tuple[bool, List[str]]:
        decision = self.evaluate(context)
        return decision.allowed, decision.reasons


policy_engine = PolicyEngine()
