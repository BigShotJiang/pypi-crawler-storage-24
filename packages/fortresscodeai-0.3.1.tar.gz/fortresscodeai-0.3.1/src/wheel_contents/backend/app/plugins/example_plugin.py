from fastapi import APIRouter
from app.workflow_orchestrator import orchestrator


class Plugin:
    name = "sample_plugin"
    version = "0.1.0"

    def __init__(self):
        self.router = APIRouter(prefix="/api/sample", tags=["sample"])

        @self.router.post("/run")
        async def run_sample_workflow(payload: dict):
            result = orchestrator.start_workflow("Sample Workflow", payload)
            return {"status": "ok", "workflow": result}
