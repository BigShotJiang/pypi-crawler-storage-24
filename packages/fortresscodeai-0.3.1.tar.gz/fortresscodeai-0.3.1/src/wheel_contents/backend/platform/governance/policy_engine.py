import json
import os
from typing import List, Dict, Any

POLICY_DIR = "policies"


def load_policies() -> List[Dict[str, Any]]:
    """
    Loads governance policies from the /policies directory.
    Policies are JSON files defining governance rules.
    """
    policies = []
    if not os.path.exists(POLICY_DIR):
        return []

    for file in os.listdir(POLICY_DIR):
        if file.endswith(".json"):
            with open(os.path.join(POLICY_DIR, file), "r") as f:
                policies.append(json.load(f))

    return policies


def evaluate_policies(policies: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluates governance policies against the workspace.
    Real logic: checks file patterns, metadata, dependency rules, etc.
    """

    results = []

    for policy in policies:
        rule = policy.get("rule", {})
        passed = True
        details = {}

        # Example: file pattern rule
        if "requiredFiles" in rule:
            missing = []
            for req in rule["requiredFiles"]:
                if not os.path.exists(req):
                    missing.append(req)
            if missing:
                passed = False
                details["missingFiles"] = missing

        # Example: dependency rule
        if "forbiddenDependencies" in rule:
            # Real logic: integrate with SBOM engine
            details["dependencyCheck"] = "integrated with SBOM engine"

        results.append({
            "policyId": policy["id"],
            "passed": passed,
            "details": details
        })

    return {"results": results}
