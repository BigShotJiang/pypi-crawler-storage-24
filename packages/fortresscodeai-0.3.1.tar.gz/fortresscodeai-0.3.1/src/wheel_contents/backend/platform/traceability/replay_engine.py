import json
import os
from typing import Callable, Dict, List, Optional, Any
from datetime import datetime

LOG_FILE = os.path.join(os.path.dirname(__file__), '../../logs/blackbox.log')


class ReplayEngine:
    def __init__(self, log_file: str = LOG_FILE):
        self.log_file = log_file
        self.events: List[Dict[str, Any]] = []

    def load_events(self, event_type: Optional[str] = None, user_id: Optional[str] = None) -> None:
        """
        Loads and filters events from the blackbox log.

        Args:
            event_type (str, optional): Filter by event type.
            user_id (str, optional): Filter by user ID.
        """
        if not os.path.exists(self.log_file):
            raise FileNotFoundError(f"Log file not found: {self.log_file}")

        with open(self.log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        self.events = []
        for line in lines:
            try:
                entry = json.loads(line)
                if event_type and entry.get("event_type") != event_type:
                    continue
                if user_id and entry.get("user_id") != user_id:
                    continue
                self.events.append(entry)
            except json.JSONDecodeError:
                continue

    def replay(self, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        Replays loaded events through a custom handler.

        Args:
            handler (Callable): Function to process each event.
        """
        for event in self.events:
            handler(event)

    def summarize(self) -> Dict[str, int]:
        """
        Returns a summary count of events by type.

        Returns:
            Dict[str, int]: Mapping of event_type to count.
        """
        summary: Dict[str, int] = {}
        for event in self.events:
            etype = event.get("event_type", "unknown")
            summary[etype] = summary.get(etype, 0) + 1
        return summary

    def print_summary(self) -> None:
        summary = self.summarize()
        print("Event Summary:")
        for etype, count in summary.items():
            print(f"  {etype}: {count}")
