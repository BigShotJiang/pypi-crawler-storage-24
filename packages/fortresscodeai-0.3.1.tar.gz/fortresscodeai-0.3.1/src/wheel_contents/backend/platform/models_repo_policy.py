from sqlalchemy import Column, String, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID
from .db import Base


class RepoConnection(Base):
    __tablename__ = "repo_connections"

    id = Column(UUID(as_uuid=True), primary_key=True)
    org_id = Column(UUID(as_uuid=True), ForeignKey("orgs.id"), nullable=False)
    provider = Column(String, nullable=False)  # "github", "gitlab"
    repo = Column(String, nullable=False)      # "owner/name"
    config = Column(JSON, nullable=False, default=dict)


class PolicyConfig(Base):
    __tablename__ = "policy_configs"

    org_id = Column(UUID(as_uuid=True), ForeignKey("orgs.id"), primary_key=True)
    rules = Column(JSON, nullable=False, default=dict)
