from __future__ import annotations

import subprocess
import sys
from pathlib import Path
import secrets

import click

from backend.cli.runtime.paths import (
    FORTRESS_ROOT,
    VENV_DIR,
    LOGS_DIR,
    PIDS_DIR,
    CONFIG_DIR,
    ENV_FILE,
    SETUP_LOG,
)
from backend.cli.runtime.storage_init import init_storage
from backend.cli.runtime.api_launcher import start_api, wait_for_api
from backend.cli.runtime.worker_launcher import start_worker


@click.command(name="setup", help="First-time installation and startup of FortressCodeAI.")
def setup_cmd() -> None:
    click.echo("FortressCodeAI Setup")
    click.echo("────────────────────")

    _ensure_directories()
    _preflight_checks()
    _create_venv()
    _install_dependencies()
    _build_ui()
    _generate_env()
    _initialize_storage()
    _start_services()

    click.echo()
    click.echo("FortressCodeAI is now running.")
    click.echo("Dashboard: http://localhost:5173")
    click.echo("API:       http://localhost:8000")


def _ensure_directories() -> None:
    for d in (FORTRESS_ROOT, VENV_DIR, LOGS_DIR, PIDS_DIR, CONFIG_DIR):
        d.mkdir(parents=True, exist_ok=True)
    SETUP_LOG.touch(exist_ok=True)


def _preflight_checks() -> None:
    for cmd in ("python", "node", "git"):
        if not _which(cmd):
            raise click.ClickException(f"Required command '{cmd}' not found in PATH")
    click.echo("• Environment validated.")


def _create_venv() -> None:
    if VENV_DIR.exists():
        click.echo("• Virtual environment already exists.")
        return
    click.echo("• Creating virtual environment...")
    subprocess.check_call([sys.executable, "-m", "venv", str(VENV_DIR)])


def _python_in_venv() -> Path:
    if sys.platform == "win32":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def _install_dependencies() -> None:
    project_root = Path.cwd()
    req_lock = project_root / "requirements.lock"
    python = _python_in_venv()

    click.echo("• Installing Python dependencies...")
    subprocess.check_call([str(python), "-m", "pip", "install", "--upgrade", "pip"])

    if req_lock.exists():
        subprocess.check_call([str(python), "-m", "pip", "install", "-r", str(req_lock)])
    else:
        click.echo("  ! requirements.lock not found, skipping pinned install.")


def _build_ui() -> None:
    project_root = Path.cwd()
    ui_dir = project_root / "backend" / "app" / "ui"
    pkg = ui_dir / "package.json"

    if not pkg.exists():
        click.echo("• UI not found, skipping UI build.")
        return

    click.echo("• Building UI dashboard...")
    subprocess.check_call(["npm", "ci"], cwd=ui_dir)
    subprocess.check_call(["npm", "run", "build"], cwd=ui_dir)


def _generate_env() -> None:
    project_root = Path.cwd()
    if ENV_FILE.exists():
        click.echo("• .env already exists, leaving as-is.")
        return

    click.echo("• Generating .env...")
    template_path = project_root / "fortresscodeai" / "templates" / "env_template"
    if not template_path.exists():
        raise click.ClickException(f"env_template not found at {template_path}")

    content = template_path.read_text()
    content = content.replace("{{JWT_SECRET}}", secrets.token_hex(32))
    content = content.replace("{{ENCRYPTION_KEY}}", secrets.token_hex(32))
    ENV_FILE.write_text(content)


def _initialize_storage() -> None:
    click.echo("• Initializing storage...")
    init_storage()


def _start_services() -> None:
    click.echo("• Starting API service...")
    api_pid = start_api()
    click.echo(f"  → API PID: {api_pid}")

    if wait_for_api():
        click.echo("  ✓ API is reachable.")
    else:
        click.echo("  ! API did not respond on port 8000 within timeout.")

    click.echo("• Starting worker service...")
    worker_pid = start_worker()
    click.echo(f"  → Worker PID: {worker_pid}")


def _which(cmd: str) -> bool:
    from shutil import which
    return which(cmd) is not None
