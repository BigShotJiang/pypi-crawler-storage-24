from __future__ import annotations

import click

from backend.cli.runtime.api_launcher import start_api, is_api_running, wait_for_api
from backend.cli.runtime.worker_launcher import start_worker, is_worker_running
from backend.cli.runtime.paths import FORTRESS_ROOT, VENV_DIR


@click.command(name="up", help="Start FortressCodeAI services.")
def up_cmd() -> None:
    if not FORTRESS_ROOT.exists() or not VENV_DIR.exists():
        raise click.ClickException(
            "Fortress is not set up yet. Run `fortress setup` first."
        )

    click.echo("Starting FortressCodeAI services")
    click.echo("────────────────────────────────")

    if not is_api_running():
        click.echo("• Starting API service...")
        pid = start_api()
        click.echo(f"  → API PID: {pid}")
        if wait_for_api():
            click.echo("  ✓ API is reachable.")
        else:
            click.echo("  ! API did not respond on port 8000 within timeout.")
    else:
        click.echo("• API already running.")

    if not is_worker_running():
        click.echo("• Starting worker service...")
        pid = start_worker()
        click.echo(f"  → Worker PID: {pid}")
    else:
        click.echo("• Worker already running.")

    click.echo()
    click.echo("FortressCodeAI is up.")
    click.echo("Dashboard: http://localhost:5173")
    click.echo("API:       http://localhost:8000")
