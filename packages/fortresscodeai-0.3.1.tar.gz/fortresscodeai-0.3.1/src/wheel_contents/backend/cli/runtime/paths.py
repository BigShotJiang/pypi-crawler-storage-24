from __future__ import annotations

from pathlib import Path


FORTRESS_MARKERS = {
    "backend/app",     # canonical Fortress platform code
    ".fortress",       # initialized Fortress runtime
    "fortress.yml",    # future config file
}


def _is_fortress_root(path: Path) -> bool:
    """Return True if this path contains any Fortress project markers."""
    for marker in FORTRESS_MARKERS:
        if (path / marker).exists():
            return True
    return False


def _project_root() -> Path:
    """
    Auto-detect the Fortress project root by walking upward from cwd.
    Stops when it finds a directory containing any Fortress markers.
    Falls back to cwd if nothing is found.
    """
    current = Path.cwd().resolve()

    # Safety: never walk above the user's home directory
    home = Path.home().resolve()

    for path in [current, *current.parents]:
        if _is_fortress_root(path):
            return path

        # Stop if we reached above home directory
        if path == home or path == path.parent:
            break

    # Fallback: assume cwd is the project root
    return current


PROJECT_ROOT: Path = _project_root()
FORTRESS_ROOT: Path = PROJECT_ROOT / ".fortress"

VENV_DIR: Path = FORTRESS_ROOT / ".venv"
LOGS_DIR: Path = FORTRESS_ROOT / "logs"
PIDS_DIR: Path = FORTRESS_ROOT / "pids"
CONFIG_DIR: Path = FORTRESS_ROOT / "config"

ENV_FILE: Path = FORTRESS_ROOT / ".env"

API_PID: Path = PIDS_DIR / "api.pid"
WORKER_PID: Path = PIDS_DIR / "worker.pid"

API_LOG: Path = LOGS_DIR / "api.log"
WORKER_LOG: Path = LOGS_DIR / "worker.log"
SETUP_LOG: Path = LOGS_DIR / "setup.log"
