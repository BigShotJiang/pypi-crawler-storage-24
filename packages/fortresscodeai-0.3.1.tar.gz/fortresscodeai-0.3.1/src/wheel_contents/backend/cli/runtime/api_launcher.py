from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import socket

from .paths import (
    PROJECT_ROOT,
    VENV_DIR,
    API_LOG,
    API_PID,
)


def _python_executable() -> Path:
    if sys.platform == "win32":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def _api_entrypoint() -> Path:
    return PROJECT_ROOT / "backend" / "app" / "api" / "main.py"


def start_api(detach: bool = True) -> int:
    """
    Start the FortressCodeAI API service.

    Returns the PID of the started process.
    """
    python = _python_executable()
    api_main = _api_entrypoint()

    if not api_main.exists():
        raise RuntimeError(f"API entrypoint not found at {api_main}")

    API_LOG.parent.mkdir(parents=True, exist_ok=True)
    API_PID.parent.mkdir(parents=True, exist_ok=True)

    stdout = open(API_LOG, "a", buffering=1, encoding="utf-8")

    cmd = [str(python), str(api_main)]

    if detach:
        proc = subprocess.Popen(
            cmd,
            stdout=stdout,
            stderr=subprocess.STDOUT,
            cwd=PROJECT_ROOT,
        )
        pid = proc.pid
    else:
        proc = subprocess.Popen(
            cmd,
            cwd=PROJECT_ROOT,
        )
        pid = proc.pid

    API_PID.write_text(str(pid))
    return pid


def _read_pid(pid_file: Path) -> Optional[int]:
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text().strip())
    except ValueError:
        return None


def is_api_running() -> bool:
    pid = _read_pid(API_PID)
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def stop_api() -> None:
    pid = _read_pid(API_PID)
    if pid is None:
        return
    try:
        os.kill(pid, getattr(signal, "SIGTERM", 15))  # type: ignore[name-defined]
    except OSError:
        pass
    try:
        API_PID.unlink()
    except FileNotFoundError:
        pass


def wait_for_api(port: int = 8000, timeout: float = 15.0) -> bool:
    """
    Wait for the API port to accept connections.

    Returns True if the API becomes reachable within timeout, else False.
    """
    start = time.time()
    while time.time() - start < timeout:
        if _is_port_open("127.0.0.1", port):
            return True
        time.sleep(0.5)
    return False


def _is_port_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        try:
            sock.connect((host, port))
            return True
        except OSError:
            return False
