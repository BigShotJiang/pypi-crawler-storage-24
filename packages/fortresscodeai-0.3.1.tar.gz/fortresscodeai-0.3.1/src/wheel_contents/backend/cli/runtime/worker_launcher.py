from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

from .paths import (
    PROJECT_ROOT,
    VENV_DIR,
    WORKER_LOG,
    WORKER_PID,
)


def _python_executable() -> Path:
    if sys.platform == "win32":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def _worker_entrypoint() -> Path:
    return PROJECT_ROOT / "backend" / "app" / "workers" / "start.py"


def start_worker(detach: bool = True) -> int:
    """
    Start the FortressCodeAI worker service.

    Returns the PID of the started process.
    """
    python = _python_executable()
    worker_main = _worker_entrypoint()

    if not worker_main.exists():
        raise RuntimeError(f"Worker entrypoint not found at {worker_main}")

    WORKER_LOG.parent.mkdir(parents=True, exist_ok=True)
    WORKER_PID.parent.mkdir(parents=True, exist_ok=True)

    stdout = open(WORKER_LOG, "a", buffering=1, encoding="utf-8")

    cmd = [str(python), str(worker_main)]

    if detach:
        proc = subprocess.Popen(
            cmd,
            stdout=stdout,
            stderr=subprocess.STDOUT,
            cwd=PROJECT_ROOT,
        )
        pid = proc.pid
    else:
        proc = subprocess.Popen(
            cmd,
            cwd=PROJECT_ROOT,
        )
        pid = proc.pid

    WORKER_PID.write_text(str(pid))
    return pid


def _read_pid(pid_file: Path) -> Optional[int]:
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text().strip())
    except ValueError:
        return None


def is_worker_running() -> bool:
    pid = _read_pid(WORKER_PID)
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False
