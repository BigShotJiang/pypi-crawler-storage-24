# try to get version from package (if installed)
try:
    import pkg_resources
except ImportError:
    # pkg_resources not available in Python 3.14+
    from importlib import metadata as importlib_metadata

    class pkg_resources:
        """Minimal pkg_resources compatibility shim"""

        class DistributionNotFound(Exception):
            pass

        @staticmethod
        def require(package_name):
            try:
                version = importlib_metadata.version(package_name)
                class Package:
                    def __init__(self, name, ver):
                        self.project_name = name
                        self.version = ver
                return [Package(package_name, version)]
            except importlib_metadata.PackageNotFoundError:
                raise pkg_resources.DistributionNotFound(package_name)

# author hardcoded here
AUTHOR = 'Andrew Leech <andrew@alelec.net>, Simon Pamies <spamsch@gmail.com>'
