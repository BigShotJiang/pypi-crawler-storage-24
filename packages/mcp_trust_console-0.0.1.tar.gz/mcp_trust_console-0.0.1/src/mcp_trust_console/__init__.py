"""mcp-trust-console — Centralized control plane for MCP trust — fleet-wide visibility, policy management, and audit dashboard."""
__version__ = "0.0.1"
