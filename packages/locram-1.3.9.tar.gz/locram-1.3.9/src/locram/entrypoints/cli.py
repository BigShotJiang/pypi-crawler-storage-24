"""CLI composition root."""
import json
import sys
from pathlib import Path

import click

from locram.adapters.db import init_db
from locram.adapters.embed_run_state import EmbeddingRunState
from locram.adapters.ollama_provider import OllamaEmbeddingProvider
from locram.adapters.sqlite_embedding_store import SqliteEmbeddingStore
from locram.adapters.sqlite_page_repo import SqlitePageRepository
from locram.config import (
    DB_PATH,
    LOCRAM_EMBED_AUTO_ENABLED,
    LOCRAM_EMBED_BATCH_SIZE,
    LOCRAM_EMBED_MODEL,
    LOCRAM_EMBED_PROVIDER,
    LOCRAM_EMBED_QUIET_SECONDS,
    LOCRAM_EMBED_URL,
    VAULT_PATH,
)
from locram.entrypoints.server import main as _serve
from locram.interfaces.embedding_provider import EmbeddingProvider
from locram.services.embedding_service import EmbeddingService
from locram.services.link_service import LinkService
from locram.services.page_service import PageService
from locram.services.search_service import SearchService
from locram.vault.watcher import (
    install_embed_runner,
    install_watcher,
    uninstall_embed_runner,
    uninstall_watcher,
)
from locram.vault.writer import ObsidianVaultStore

_ALL_PAGES_LIMIT = 100_000
_EMBED_LOCK_MAX_AGE_SECONDS = 600


def make_services() -> tuple[
    SqlitePageRepository, ObsidianVaultStore, PageService, LinkService, SearchService
]:
    repo = SqlitePageRepository()
    vault = ObsidianVaultStore()
    return repo, vault, PageService(repo, vault), LinkService(repo, vault), SearchService(repo)


def out(data: object) -> None:
    click.echo(json.dumps(data, ensure_ascii=False, indent=2))


def embedding_provider_is_configured() -> bool:
    return LOCRAM_EMBED_PROVIDER.lower() == "ollama" and bool(LOCRAM_EMBED_MODEL)


def make_embedding_service() -> EmbeddingService:
    provider: EmbeddingProvider = OllamaEmbeddingProvider(
        base_url=LOCRAM_EMBED_URL, model=LOCRAM_EMBED_MODEL
    )
    embedding_store = SqliteEmbeddingStore()
    repo = SqlitePageRepository()
    return EmbeddingService(repo, embedding_store, provider)


@click.group()
def main() -> None:
    """locram — local Zettelkasten for LLM agents."""


@main.command()
def serve() -> None:
    """Start the MCP stdio server."""
    _serve()


@main.command()
def init() -> None:
    """Create DB, vault directories, and Obsidian config."""
    init_db()
    vault = ObsidianVaultStore()
    vault.setup_obsidian()
    click.echo("locram initialised.")
    click.echo(f"  DB:    {vault.db_path}")
    click.echo(f"  Vault: {vault.vault_path}")
    click.echo()
    if sys.platform == "darwin":
        click.echo("Obsidian → DB sync requires the watcher:")
        click.echo("    locram watch-install   (macOS launchd, runs automatically)")
        click.echo("    locram embed-auto-install   (optional periodic auto-embed runner)")
        click.echo("    locram sync            (manual, works everywhere)")
    else:
        click.echo("Obsidian → DB sync is manual on this platform:")
        click.echo("    locram sync            (run after editing in Obsidian)")


@main.command()
@click.option("--file", "file_path", default=None, help="Sync a single .md file.")
def sync(file_path: str | None) -> None:
    """Sync vault → DB. Full-vault reconcile by default (used by launchd watcher)."""
    init_db()
    vault = ObsidianVaultStore()
    path = Path(file_path) if file_path else None
    stats = vault.sync(path)
    if LOCRAM_EMBED_AUTO_ENABLED and (stats["inserted"] > 0 or stats["updated"] > 0):
        EmbeddingRunState().touch_pending()
    out(stats)


@main.command("vault-rebuild")
def vault_rebuild() -> None:
    """Rebuild all .md files from DB (DB → vault)."""
    init_db()
    repo, vault, pages_svc, _, _ = make_services()
    records = repo.list_pages(status="active", limit=10000)
    count = 0
    for r in records:
        page = pages_svc.get_page(r["id"])
        if page:
            vault.write(page)
            count += 1
    click.echo(f"Rebuilt {count} notes.")


@main.command("watch-install")
def watch_install() -> None:
    """Install macOS launchd watcher (WatchPaths → debounced full sync)."""
    path = install_watcher()
    click.echo(f"Watcher installed: {path}")


@main.command("watch-uninstall")
def watch_uninstall() -> None:
    """Remove macOS launchd watcher."""
    uninstall_watcher()
    click.echo("Watcher removed.")


@main.command("embed-auto-install")
def embed_auto_install() -> None:
    """Install periodic macOS launchd runner for auto-embedding."""
    path = install_embed_runner()
    click.echo(f"Embed runner installed: {path}")


@main.command("embed-auto-uninstall")
def embed_auto_uninstall() -> None:
    """Remove periodic macOS launchd runner for auto-embedding."""
    uninstall_embed_runner()
    click.echo("Embed runner removed.")


@main.command()
@click.option("--title", required=True)
@click.option("--content", default="")
@click.option("--type", "page_type", default="fleeting")
@click.option("--subject", multiple=True)
@click.option("--tag", multiple=True)
def create(
    title: str, content: str, page_type: str, subject: tuple[str, ...], tag: tuple[str, ...]
) -> None:
    """Create a note."""
    init_db()
    _, _, pages_svc, _, _ = make_services()
    page = pages_svc.create_page(
        title=title, content=content, type=page_type,
        subject=list(subject), tags=list(tag),
    )
    out({"id": page.id, "title": page.title, "type": page.type.value})


@main.command()
@click.argument("page_id")
def get(page_id: str) -> None:
    """Get a note by ID."""
    init_db()
    _, _, pages_svc, _, _ = make_services()
    page = pages_svc.get_page(page_id)
    if page is None:
        click.echo(f"Not found: {page_id}", err=True)
        sys.exit(1)
    out({
        "id": page.id, "title": page.title, "type": page.type.value,
        "status": page.status.value, "content": page.content,
        "connected_to": page.connected_to, "sub_items": page.sub_items,
    })


@main.command()
@click.argument("query")
@click.option("--limit", default=20)
def search(query: str, limit: int) -> None:
    """FTS5 full-text search."""
    init_db()
    _, _, _, _, search_svc = make_services()
    out(search_svc.search(query, limit=limit))


@main.command("list")
@click.option("--type", "page_type", default=None)
@click.option("--status", default=None)
@click.option("--limit", default=50)
def list_cmd(page_type: str | None, status: str | None, limit: int) -> None:
    """List notes."""
    init_db()
    repo, _, _, _, _ = make_services()
    out(repo.list_pages(type=page_type, status=status, limit=limit))


@main.command()
@click.argument("source_id")
@click.argument("target_id")
@click.option("--type", "link_type", default="related")
def link(source_id: str, target_id: str, link_type: str) -> None:
    """Create a typed link between two notes."""
    init_db()
    _, _, _, links_svc, _ = make_services()
    out(links_svc.link_pages(source_id, target_id, link_type))


@main.command()
@click.option("--limit", default=200, help="Max stale pages per run (ignored with --force).")
@click.option("--force", is_flag=True, help="Re-embed all active notes (up to 100k).")
def embed(limit: int, force: bool) -> None:
    """Generate and store embeddings for stale or missing notes.

    Requires LOCRAM_EMBED_PROVIDER=ollama, LOCRAM_EMBED_URL, LOCRAM_EMBED_MODEL.
    Use --force to re-embed all active notes after a model switch.
    """
    init_db()

    if not embedding_provider_is_configured():
        out({
            "error": (
                "Embedding provider not configured. "
                "Set LOCRAM_EMBED_PROVIDER=ollama, LOCRAM_EMBED_URL, LOCRAM_EMBED_MODEL."
            )
        })
        sys.exit(1)

    service = make_embedding_service()
    result = service.embed_all(limit=_ALL_PAGES_LIMIT) if force else service.embed_stale(limit)
    out(result)


@main.command("embed-auto-run")
def embed_auto_run() -> None:
    """Run one auto-embed maintenance pass after quiet-period gating."""
    init_db()
    state = EmbeddingRunState()

    if not LOCRAM_EMBED_AUTO_ENABLED:
        out({"ran": False, "reason": "auto embedding disabled"})
        return

    if not embedding_provider_is_configured():
        out({"ran": False, "reason": "embedding provider not configured"})
        return

    if not state.pending_exists():
        out({"ran": False, "reason": "no pending embedding work"})
        return

    pending_age = state.pending_age_seconds()
    if pending_age is None:
        out({"ran": False, "reason": "no pending embedding work"})
        return

    if pending_age < LOCRAM_EMBED_QUIET_SECONDS:
        out({"ran": False, "reason": "quiet period not reached"})
        return

    if not state.acquire_lock(_EMBED_LOCK_MAX_AGE_SECONDS):
        out({"ran": False, "reason": "embed runner already active"})
        return

    try:
        service = make_embedding_service()
        result = service.embed_stale(LOCRAM_EMBED_BATCH_SIZE)
        stale_remaining = service.has_stale()
        if result["failed"] == 0 and not stale_remaining:
            state.clear_pending()
        out({"ran": True, "reason": None, **result})
    finally:
        state.release_lock()


@main.command()
def reset() -> None:
    """DELETE ALL DATA and recreate DB + vault from scratch."""
    click.confirm(
        "This will DELETE all notes, links, and vault files. Continue?",
        abort=True,
    )

    if DB_PATH.exists():
        DB_PATH.unlink()
        click.echo(f"Deleted {DB_PATH}")

    for f in VAULT_PATH.glob("*.md"):
        f.unlink()
    click.echo("Cleared vault .md files")

    init_db()
    vault = ObsidianVaultStore()
    vault.setup_obsidian()
    click.echo("locram reset complete.")


if __name__ == "__main__":
    main()
