# tests/test_internal_helpers.py
from io import StringIO
from receptus import Receptus, UserQuit
from receptus.receptus import _RETRY

def _mk(with_buf=True):
    buf = StringIO()
    r = Receptus(force_no_color=True, output=buf)
    return r, buf

def test_handle_quit_and_help_paths(monkeypatch):
    r, _ = _mk()
    # help -> _RETRY
    out = r._handle_quit_and_help("help", "quit", "help", lambda: None, False, "Are you sure?")
    assert out is _RETRY
    # quit with confirm False -> USER_QUIT
    out = r._handle_quit_and_help("quit", "quit", "help", None, False, "Are you sure?")
    assert isinstance(out, UserQuit)
    # quit with confirm True but decline -> _RETRY
    r2, _ = _mk()
    monkeypatch.setattr(r2, "_get_confirmation", lambda _: False)
    out = r2._handle_quit_and_help("quit", "quit", "help", None, True, "Are you sure?")
    assert out is _RETRY

def test_get_input_quit_without_confirm(monkeypatch):
    r = Receptus(force_no_color=True)
    monkeypatch.setattr("builtins.input", lambda _ : "quit")
    res = r.get_input(options={"a": "Alpha"}, confirm=False)
    assert isinstance(res, UserQuit)

def test_help_word_invokes_callback(monkeypatch):
    called = {"v": False}
    def cb(): called["v"] = True

    r = Receptus(output=StringIO(), force_no_color=True)
    seq = iter(["help", "a"])  # first help → retry, then pick 'a'
    monkeypatch.setattr("builtins.input", lambda _ : next(seq))

    res = r.get_input(options={"a": "Alpha"}, help_callback=cb)
    assert called["v"] is True
    assert res == "a"

def test_userquit_repr():
    assert repr(UserQuit()) == "<UserQuit>"

def test_userquit_is_exception():
    assert issubclass(UserQuit, Exception)

def test_raise_on_quit_raises_userquit(monkeypatch):
    import pytest
    r = Receptus(force_no_color=True, output=StringIO())
    monkeypatch.setattr("builtins.input", lambda _: "quit")
    with pytest.raises(UserQuit):
        r.get_input(options={"a": "Alpha"}, raise_on_quit=True)

def test_raise_on_quit_false_returns_sentinel(monkeypatch):
    r = Receptus(force_no_color=True, output=StringIO())
    monkeypatch.setattr("builtins.input", lambda _: "quit")
    res = r.get_input(options={"a": "Alpha"}, raise_on_quit=False)
    assert isinstance(res, UserQuit)