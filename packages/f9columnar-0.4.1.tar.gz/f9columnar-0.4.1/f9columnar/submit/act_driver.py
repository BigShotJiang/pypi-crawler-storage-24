from __future__ import annotations

import copy
import datetime
import glob
import logging
import os
import random
import shutil
import subprocess
import tarfile
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import StringIO

import pandas as pd

from f9columnar.utils.loggers import get_progress

ACT_CLUSTERS = {
    "pikolit": "https://pikolit.ijs.si/batch",
    "rebula": "https://rebula.ijs.si/batch",
    "nsc": "https://nsc.ijs.si/gridlong",
    "arnes": "https://hpc.arnes.si/all",
    "vega01": "https://arc01.vega.izum.si/cpu",
    "vega02": "https://arc02.vega.izum.si/cpu",
}


class ActInterface:
    def __init__(self, submit_dir: str, job_name: str) -> None:
        job_submit_dir = os.path.join(submit_dir, job_name)

        self.jobs_dir = os.path.join(job_submit_dir, "jobs")
        self.job_name = job_name

        self.output_dir = os.path.join(job_submit_dir, "out")
        os.makedirs(self.output_dir, exist_ok=True)

        self._state: pd.DataFrame | None = None

    def get_jobs(self) -> list[str]:
        return glob.glob(f"{self.jobs_dir}/*.xrsl")

    def get_out_jobs(self) -> list[str]:
        return glob.glob(f"{self.output_dir}/f9col_*")

    def get_downloaded(self, basename: bool = False) -> list[str]:
        downloaded_dirs = glob.glob(f"{self.output_dir}/*")

        if basename:
            downloaded_dirs = [os.path.basename(downloaded_dir) for downloaded_dir in downloaded_dirs]

        return downloaded_dirs

    def read_state(self) -> pd.DataFrame | str:
        try:
            result = subprocess.run(
                ["act", "stat", "-a"],
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.returncode != 0:
                logging.info(f"act stat failed with return code: {result.returncode}")
                logging.info(f"stderr: {result.stderr}")
                return "error"

            state = pd.read_csv(StringIO(result.stdout), delimiter=r"\s+").iloc[1:]
            state = state[state["jobname"].str.contains(rf"{self.job_name}_\d+", regex=True)]

            self._state = state

        except subprocess.TimeoutExpired:
            logging.info("act stat timed out.")
            self._state = None
            return "error"
        except pd.errors.EmptyDataError:
            self._state = None
            return "valid"
        except Exception as e:
            logging.info(f"Unexpected error in act stat: {e}.")
            self._state = None
            return "error"

        return state

    @property
    def state(self) -> pd.DataFrame | str:
        return self._state


class ActBatchSubmitter(ActInterface):
    def __init__(self, submit_dir: str, job_name: str, cluster_names: list[str] | None = None) -> None:
        super().__init__(submit_dir, job_name)

        if cluster_names is None:
            cluster_names = list(ACT_CLUSTERS.keys())

        cluster_lst = [ACT_CLUSTERS[cluster_name] for cluster_name in cluster_names]

        logging.info(f"Submitting to clusters: {', '.join(cluster_names)}")

        self.cluster_lst = ",".join(cluster_lst) if cluster_lst is not None else None

    def submit(
        self,
        jobs_lst: list[str] | None = None,
        exclude_downloaded: bool = False,
        exclude_jobs_lst: list[str] | None = None,
    ) -> ActBatchSubmitter | None:
        if jobs_lst is None:
            jobs_lst = self.get_jobs()

        if exclude_downloaded:
            downloaded_jobs = self.get_downloaded(basename=True)
            downloaded_jobs = [f"{self.jobs_dir}/{j}.xrsl" for j in downloaded_jobs]
            jobs_lst = list(set(jobs_lst) - set(downloaded_jobs))

        if exclude_jobs_lst is not None:
            jobs_lst = list(set(jobs_lst) - set(exclude_jobs_lst))

        if len(jobs_lst) == 0:
            return None

        logging.info(f"[green]Submitting {len(jobs_lst)} jobs.[/green]")

        batch_size = 100
        total_bathces = (len(jobs_lst) + batch_size - 1) // batch_size
        for i in range(0, len(jobs_lst), batch_size):
            batch = jobs_lst[i : i + batch_size]
            jobs = " ".join(batch)
            logging.info(f"Submitting batch {i // batch_size + 1}/{total_bathces} ({len(batch)} jobs).")
            os.system(f"act sub {jobs} --clusterlist {self.cluster_lst} >/dev/null 2>&1")
            time.sleep(0.25)

        return self


class ActBatchGetter(ActInterface):
    def __init__(
        self,
        submit_dir: str,
        job_name: str,
        download_threads: int = 4,
        download_batch_size: int = 10,
    ) -> None:
        super().__init__(submit_dir, job_name)
        self.download_threads = download_threads
        self.download_batch_size = download_batch_size

    def get(self, ids_lst: list[str] | None = None, clean: bool = False) -> ActBatchGetter | None:
        if ids_lst is None:
            df = self.read_state()

            if isinstance(df, str):
                return None

            ids_lst = df[(df["State"] == "Finished") & (df["arcstate"] == "done")]["id"].values.tolist()

        if len(ids_lst) == 0:
            return None

        ids = ",".join(ids_lst)

        existing_dirs = set(os.listdir(self.output_dir))

        random.shuffle(ids_lst)
        batches = [ids_lst[i : i + self.download_batch_size] for i in range(0, len(ids_lst), self.download_batch_size)]

        def download_batch(batch: list[str]) -> None:
            batch_ids = ",".join(batch)
            subprocess.run(
                ["act", "get", "--use-jobname", "--noclean", "--id", batch_ids],
                capture_output=True,
                cwd=self.output_dir,
            )

        logging.info(f"[green]Downloading {len(ids_lst)} jobs.[/green]")

        with get_progress(transient=True) as progress:
            task = progress.add_task(f"Downloading {len(batches)} job batches", total=len(batches))
            with ThreadPoolExecutor(max_workers=self.download_threads) as executor:
                futures = [executor.submit(download_batch, batch) for batch in batches]
                for future in as_completed(futures):
                    future.result()
                    progress.advance(task)

        if clean:
            logging.info("Cleaning up downloaded jobs.")
            subprocess.run(["act", "clean", "--id", ids], capture_output=True)

        logging.info("Extracting downloaded outputs.")

        new_dirs = []
        for dir_name in set(os.listdir(self.output_dir)) - existing_dirs:
            if os.path.exists(os.path.join(self.output_dir, dir_name, "out.tar.gz")):
                new_dirs.append(dir_name)

        with get_progress(transient=True) as progress:
            task = progress.add_task("Extracting outputs", total=len(new_dirs))
            for dir_name in new_dirs:
                out_tar = os.path.join(self.output_dir, dir_name, "out.tar.gz")

                with tempfile.TemporaryDirectory() as tmp_dir:
                    with tarfile.open(out_tar, "r:gz") as tar:
                        tar.extractall(path=tmp_dir)

                    for item in os.scandir(tmp_dir):
                        dst = os.path.join(self.output_dir, dir_name, item.name)
                        if os.path.isdir(dst):
                            shutil.rmtree(dst)
                        elif os.path.exists(dst):
                            os.remove(dst)
                        shutil.move(item.path, dst)

                os.remove(out_tar)
                progress.advance(task)

        return self


class ActDriver(ActInterface):
    def __init__(
        self,
        submit_dir: str,
        job_name: str,
        cluster_names: list[str] | None = None,
        max_resub: int = 3,
        refresh_time: int = 5,
        download_threads: int = 4,
        download_batch_size: int = 10,
    ) -> None:
        super().__init__(submit_dir, job_name)
        logging.info(f"[green][bold]Activating act driver for {self.job_name}![/bold][/green]")

        self.max_resub = max_resub
        self.refresh_time = refresh_time

        self.submitter = ActBatchSubmitter(submit_dir, job_name, cluster_names)
        self.getter = ActBatchGetter(submit_dir, job_name, download_threads, download_batch_size)

        self.all_jobs = self.get_jobs()
        self.all_jobs_dct = {".".join(os.path.basename(job).split(".")[:-1]): job for job in self.all_jobs}

        self.max_resub_dct = {job: 0 for job in self.all_jobs_dct.keys()}

    def _get_missing(self, remove: bool = False) -> list[str]:
        downloaded_dirs = self.get_downloaded()

        missing = []
        for dir_name in downloaded_dirs:
            if os.path.isfile(dir_name):
                continue

            if os.path.basename(dir_name) not in self.all_jobs_dct:
                continue

            if not os.path.isfile(f"{dir_name}/arc/output"):
                missing.append(os.path.basename(dir_name))
                if remove:
                    os.system(f"rm -rf {dir_name}")
                continue

            with open(f"{dir_name}/arc/output", "r") as f:
                log_output = f.read().splitlines()

            log_output = list(set([line[1:] for line in log_output]))
            log_output = [line.split("/")[0] for line in log_output]

            output = glob.glob(f"{dir_name}/*")
            output = [os.path.basename(out) for out in output]

            if "out.tar.gz" in log_output and "out" in output:
                log_output = [f for f in log_output if f != "out.tar.gz"]

            if len(list(set(log_output) - set(output))) != 0:
                missing.append(os.path.basename(dir_name))

                if remove:
                    os.system(f"rm -rf {dir_name}")

        return missing

    def _resub_missing(self, missing: list[str]) -> ActDriver:
        resub_missing = copy.deepcopy(missing)

        for m in missing:
            if self.max_resub_dct[m] >= self.max_resub:
                logging.warning(f"Missing job {m} resubmitted {self.max_resub} times. Skipping.")
                resub_missing.remove(m)
            else:
                logging.info(f"Resubmitting missing job {m}.")
                self.max_resub_dct[m] += 1

        resub_missing = [self.all_jobs_dct[m] for m in resub_missing]

        self.submitter.submit(jobs_lst=resub_missing)

        return self

    def _get(self, df: pd.DataFrame) -> ActDriver:
        done_df = df[(df["State"] == "Finished") & (df["arcstate"] == "done")]
        done_ids, done_names = done_df["id"], done_df["jobname"]

        downloaded_names = self.get_downloaded(basename=True)

        to_download_names = list(set(done_names) - set(downloaded_names))
        to_download_ids = done_ids[done_names.isin(to_download_names)]

        self.getter.get(ids_lst=list(to_download_ids), clean=True)

        return self

    def _get_failed(self, df: pd.DataFrame) -> pd.DataFrame | None:
        failed_df = df[(df["State"] == "Failed") & (df["arcstate"] == "failed")]
        failed_names = failed_df["jobname"].values.tolist()
        failed_ids = failed_df["id"].values.tolist()

        n_failed = len(failed_names)

        if n_failed != 0:
            logging.warning(f"[yellow][bold]{n_failed} failed jobs![/bold][/yellow]")
        else:
            return None

        to_resub_names, to_clean_ids = [], []
        for failed_name, failed_id in zip(failed_names, failed_ids):
            resub_count = self.max_resub_dct[failed_name]

            if resub_count < self.max_resub:
                logging.info(f"Resubmitting failed job {failed_name}, resub count: {resub_count + 1}/{self.max_resub}.")

                to_resub_names.append(failed_name)
                to_clean_ids.append(str(failed_id))

                self.max_resub_dct[failed_name] += 1

        if len(to_resub_names) != 0:
            clean_ids = ",".join(to_clean_ids)
            os.system(f"act clean --id {clean_ids} >/dev/null 2>&1")

            resub_jobs = [self.all_jobs_dct[job_name] for job_name in to_resub_names]
            self.submitter.submit(jobs_lst=resub_jobs)

            return None

        if self.max_resub != 0:
            logging.warning("[yellow][bold]All failed jobs reached max resubmissions![/bold][/yellow]")

        return failed_df

    def _submit(self, df: pd.DataFrame) -> ActDriver:
        job_names = list(self.all_jobs_dct.keys())
        present_job_names = list(set(df["jobname"].values.tolist()))

        downloaded_jobs = self.get_downloaded(basename=True)

        submit_job_names = list(set(job_names) - set(present_job_names) - set(downloaded_jobs))
        submit_jobs = [self.all_jobs_dct[job] for job in submit_job_names]

        self.submitter.submit(jobs_lst=submit_jobs)

        return self

    def _get_states(self, run_df: pd.DataFrame) -> tuple[str, str]:
        state, arc_state = run_df["State"].value_counts().to_dict(), run_df["arcstate"].value_counts().to_dict()

        state_str = ", ".join([f"{k.lower()}: {v}" for k, v in state.items()])
        arc_state_str = ", ".join([f"{k.lower()}: {v}" for k, v in arc_state.items()])

        return state_str, arc_state_str

    def _run(self, run_df: pd.DataFrame) -> ActDriver | None:
        self._submit(run_df)

        self._get(run_df)
        failed_df = self._get_failed(run_df)

        if failed_df is not None and len(run_df) == len(failed_df):
            logging.warning("[yellow][bold]Only have failed jobs![/bold][/yellow]")
            return None

        missing = self._get_missing(remove=True)
        self._resub_missing(missing)

        return self

    def run(self) -> ActDriver | None:
        logging.info(f"Starting act driver for {self.job_name}!")
        start_time = time.perf_counter()

        all_jobs = [os.path.basename(j).split(".")[0] for j in self.get_jobs()]
        out_jobs = [os.path.basename(j) for j in self.get_out_jobs()]

        n_all_jobs, n_out_jobs, n_steps = len(all_jobs), len(out_jobs), 0

        if n_all_jobs == n_out_jobs:
            logging.info("[green][bold]All jobs already downloaded![/bold][/green]")
            return self

        if n_out_jobs > n_all_jobs:
            raise RuntimeError(
                f"More output jobs {n_out_jobs} than submitted jobs {n_all_jobs} found! "
                f"Are there any duplicate job names: {list(set(out_jobs) - set(all_jobs))}?"
            )

        logging.info(f"Total jobs to process: {n_all_jobs}.")

        while True:
            state = self.read_state()
            is_str_state = isinstance(state, str)

            if is_str_state and n_steps == 0:
                self.submitter.submit(exclude_downloaded=True)
                time.sleep(self.refresh_time)
                n_steps += 1
                continue

            if is_str_state and state == "valid" and n_steps != 0:
                if len(self.get_out_jobs()) >= n_all_jobs:
                    logging.info("[green][bold]Done with all jobs![/bold][/green]")
                    break

                logging.info("No matching jobs in act stat yet, waiting...")
                time.sleep(self.refresh_time)
                n_steps += 1
                continue

            if is_str_state and state == "error":
                time.sleep(self.refresh_time)
                n_steps += 1
                continue

            if not isinstance(state, pd.DataFrame):
                raise RuntimeError("Unexpected state type returned from read_state()!")

            if len(state) == 0 and n_steps != 0:
                if len(self.get_out_jobs()) >= n_all_jobs:
                    logging.info("[green][bold]Done with all jobs![/bold][/green]")
                    break
                logging.info("No matching jobs in act stat yet, waiting...")
                time.sleep(self.refresh_time)
                n_steps += 1
                continue

            state_str, arc_state_str = self._get_states(state)
            logging.info(f"[bold]Job[/bold] - {self.job_name}")
            logging.info(f"[bold]State[/bold] - {state_str} | [bold]Arcstate[/bold] - {arc_state_str}")

            if n_steps != 0:
                finished_jobs = n_all_jobs - len(state)
                logging.info(f"[bold]Progress:[/bold] {finished_jobs}/{n_all_jobs} | {finished_jobs / n_all_jobs:.2%}")

            run_return = self._run(state)

            if run_return is None:
                return None

            elapsed = time.perf_counter() - start_time
            logging.info(f"[bold]Elapsed:[/bold] {str(datetime.timedelta(seconds=int(elapsed)))} - {n_steps} updates.")

            time.sleep(self.refresh_time)
            n_steps += 1

        return self
