import argparse

from f9columnar.submit.act_handler import ActBatchRunner
from f9columnar.utils.loggers import setup_logger


def main() -> None:
    setup_logger()

    parser = argparse.ArgumentParser(description="aCT batch runner.")

    parser.add_argument(
        "-n",
        "--job_name",
        required=True,
        type=str,
        help="Job name of the aCT batch job.",
    )
    parser.add_argument(
        "-s",
        "--save_path",
        required=False,
        type=str,
        default="out",
        help="Save path where to store output files.",
    )
    parser.add_argument(
        "-d",
        "--data_dir",
        required=False,
        type=str,
        default=".",
        help="Directory where data files are located.",
    )
    parser.add_argument(
        "-c",
        "--cut_flow",
        type=str,
        choices=["0", "1"],
        default="0",
        help="Whether to use cut and time flow for monitoring.",
    )
    args = parser.parse_args()

    batch_run = ActBatchRunner(
        args.job_name,
        data_dir=args.data_dir,
        cut_flow=(args.cut_flow == "1"),
        save_path=args.save_path,
    )
    batch_run.init()
    batch_run.run()


if __name__ == "__main__":
    main()
