import argparse
import logging
import os

from f9columnar.analysis.config import AnalysisConfigBuilder
from f9columnar.submit.act_driver import ActDriver
from f9columnar.submit.act_merger import ActMerger
from f9columnar.utils.loggers import setup_logger


def main() -> None:
    parser = argparse.ArgumentParser(description="Submit batch jobs with aCT and merge outputs.")

    parser.add_argument(
        "-c",
        "--config-path",
        required=False,
        type=str,
        default=None,
        help="Path to analysis configuration YAML file. If not provided, will use COLUMNAR_CONFIG_PATH.",
    )
    parser.add_argument(
        "-j",
        "--job-name",
        required=False,
        type=str,
        default=None,
        help="Name of the job. If not provided, will use the job_name from the configuration.",
    )
    parser.add_argument(
        "-m",
        "--merge-only",
        action="store_true",
        help="If provided, only merge the outputs and skip submission.",
    )
    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Delete intermediate files after merging. "
        "Use with caution, as this will remove all files in the submit directory after merging!",
    )
    args = parser.parse_args()

    setup_logger()

    if args.config_path is None:
        config_path = os.environ.get("COLUMNAR_CONFIG_PATH", None)
        if config_path is None:
            raise ValueError("No configuration path provided and COLUMNAR_CONFIG_PATH is not set!")
    else:
        config_path = args.config_path

    analysis_config_builder = AnalysisConfigBuilder(config_path)
    analysis_config = analysis_config_builder.build()

    if args.job_name is None:
        job_name = analysis_config.submit.job_name
    else:
        job_name = args.job_name

    if not args.merge_only:
        act_driver = ActDriver(
            analysis_config.submit.submit_dir,
            job_name,
            cluster_names=analysis_config.submit.act_config.clusters,
            max_resub=analysis_config.submit.act_config.max_resub,
            refresh_time=analysis_config.submit.act_config.refresh_time,
        )
        finished = act_driver.run()

    if not args.merge_only:
        if finished is None:
            logging.warning("aCT driver returned None, some jobs were not completed!")
        else:
            logging.info("aCT driver finished successfully!")

    act_merger = ActMerger(analysis_config.submit.submit_dir, job_name, cleanup=args.cleanup)
    act_merger.merge()


if __name__ == "__main__":
    main()
