from __future__ import annotations

import argparse
import base64
import glob
import logging
import os
import re
import subprocess
import threading
import time
from io import BytesIO, StringIO

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mplhep
import pandas as pd
from flask import Flask, render_template_string

from f9columnar.analysis.config import AnalysisConfigBuilder
from f9columnar.submit.act_driver import ActDriver
from f9columnar.submit.act_merger import ActMerger
from f9columnar.utils.loggers import setup_logger
from f9columnar.utils.regex_helpers import extract_process_name as _extract_process_name

plt.style.use(mplhep.style.ATLAS)
plt.rcParams.update(
    {
        "figure.facecolor": "none",
        "axes.facecolor": "none",
        "savefig.facecolor": "none",
        "svg.fonttype": "none",
        "axes.formatter.use_mathtext": False,
    }
)

STATE_COLORS = {
    "Downloaded": "#059669",
    "Finished": "#10b981",
    "Finishing": "#34d399",
    "Running": "#fb923c",
    "Started": "#38bdf8",
    "Queuing": "#60a5fa",
    "Preparing": "#818cf8",
    "Accepted": "#a78bfa",
    "Submitted": "#c084fc",
    "Other": "#94a3b8",
    "Failed": "#ef4444",
}

DONE_FIRST_ORDER = [
    "Downloaded",
    "Finished",
    "Finishing",
    "Running",
    "Queuing",
    "Preparing",
    "Accepted",
    "Submitted",
    "Started",
    "Other",
    "Failed",
]

PLOT_FORMAT = "svg"


def _fig_to_base64(fig: plt.Figure) -> str:
    buf = BytesIO()
    fig.savefig(buf, format=PLOT_FORMAT, bbox_inches="tight", facecolor="none", transparent=True)
    buf.seek(0)
    img_str = base64.b64encode(buf.read()).decode("utf-8")
    plt.close(fig)
    return img_str


class ActMonitor:
    def __init__(self, submit_dir: str, job_names: list[str] | None = None) -> None:
        self.submit_dir = submit_dir
        self.drivers: dict[str, ActDriver] = {}

        if job_names:
            self.job_names = job_names
        else:
            self.job_names = self._discover_job_names()

    def _discover_job_names(self) -> list[str]:
        job_names: list[str] = []
        if not os.path.isdir(self.submit_dir):
            return job_names

        for entry in os.scandir(self.submit_dir):
            if entry.is_dir() and os.path.isdir(os.path.join(entry.path, "jobs")):
                job_names.append(entry.name)

        return sorted(job_names)

    @staticmethod
    def _read_act_state() -> pd.DataFrame | None:
        try:
            result = subprocess.run(
                ["act", "stat", "-a"],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                return None

            df = pd.read_csv(StringIO(result.stdout), delimiter=r"\s+").iloc[1:]
            return df

        except (subprocess.TimeoutExpired, pd.errors.EmptyDataError, Exception):
            return None

    def get_all_state(self) -> pd.DataFrame | None:
        if self.drivers:
            frames = []
            for driver in self.drivers.values():
                state = driver.state
                if isinstance(state, pd.DataFrame) and not state.empty:
                    frames.append(state)
            if not frames:
                return pd.DataFrame()
            return pd.concat(frames, ignore_index=True)

        return self._read_act_state()

    def get_job_state(self, all_state: pd.DataFrame | None, job_name: str) -> pd.DataFrame | None:
        if all_state is None or all_state.empty:
            return None

        mask = all_state["jobname"].str.contains(rf"{job_name}_\d+", regex=True)
        filtered = all_state[mask]

        return filtered if not filtered.empty else None

    def get_total_jobs(self, job_name: str) -> int:
        jobs_dir = os.path.join(self.submit_dir, job_name, "jobs")
        return len(glob.glob(f"{jobs_dir}/*.xrsl"))

    def get_downloaded_jobs(self, job_name: str) -> list[str]:
        output_dir = os.path.join(self.submit_dir, job_name, "out")
        if not os.path.isdir(output_dir):
            return []
        return [d for d in os.listdir(output_dir) if os.path.isdir(os.path.join(output_dir, d))]

    @staticmethod
    def extract_process_name(jobname: str, job_name: str) -> str:
        return _extract_process_name(jobname, job_name)

    def get_job_summary(self, job_name: str, all_state: pd.DataFrame | None) -> dict:
        total = self.get_total_jobs(job_name)
        downloaded = self.get_downloaded_jobs(job_name)
        n_downloaded = len(downloaded)

        state_df = self.get_job_state(all_state, job_name)

        state_counts: dict[str, int] = {}
        if state_df is not None and not state_df.empty:
            # exclude jobs already downloaded to avoid double-counting
            downloaded_set = set(downloaded)
            state_df = state_df[~state_df["jobname"].isin(downloaded_set)]
            state_counts = state_df["State"].value_counts().to_dict() if not state_df.empty else {}

        tracked = sum(state_counts.values()) + n_downloaded
        n_queuing = max(0, total - tracked)
        if n_queuing > 0:
            state_counts["Started"] = state_counts.get("Started", 0) + n_queuing

        progress = (n_downloaded / total * 100) if total > 0 else 0

        return {
            "job_name": job_name,
            "total": total,
            "downloaded": n_downloaded,
            "progress": progress,
            "state_counts": state_counts,
            "state_df": state_df,
        }

    def make_state_chart(self, state_counts: dict, title: str = "") -> str | None:
        if not state_counts:
            return None

        labels = list(state_counts.keys())
        sizes = list(state_counts.values())
        colors = [STATE_COLORS.get(label, STATE_COLORS["Other"]) for label in labels]

        fig, ax = plt.subplots(figsize=(9, 8))
        pie_result = ax.pie(
            sizes,
            labels=None,
            colors=colors,
            autopct=lambda p: f"{p:.0f}%\n({int(p * sum(sizes) / 100)})",
            startangle=90,
            pctdistance=0.75,
            wedgeprops={"linewidth": 2, "edgecolor": "white"},
        )
        wedges = pie_result[0]
        autotexts = pie_result[2]  # type: ignore[misc]
        for t in autotexts:
            t.set_fontsize(9)
            t.set_fontweight("bold")

        ax.legend(wedges, labels, loc="center left", bbox_to_anchor=(1, 0.5), frameon=False)
        ax.set_title(title)
        fig.subplots_adjust(right=0.75)

        return _fig_to_base64(fig)

    def make_process_chart(
        self, state_df: pd.DataFrame, job_name: str, downloaded_names: list[str] | None = None
    ) -> str | None:
        if (state_df is None or state_df.empty) and not downloaded_names:
            return None

        pivot = pd.DataFrame()

        if state_df is not None and not state_df.empty:
            df = state_df.copy()
            df["process"] = df["jobname"].apply(lambda x: self.extract_process_name(x, job_name))
            pivot = pd.crosstab(df["process"], df["State"])

        if downloaded_names:
            dl_procs = [self.extract_process_name(d, job_name) for d in downloaded_names]
            dl_counts = pd.Series(dl_procs).value_counts()
            dl_df = pd.DataFrame({"Downloaded": dl_counts})
            pivot = pivot.join(dl_df, how="outer").fillna(0).astype(int)

        ordered_cols = [c for c in DONE_FIRST_ORDER if c in pivot.columns] + [
            c for c in pivot.columns if c not in DONE_FIRST_ORDER
        ]
        pivot = pivot[ordered_cols]

        colors = [STATE_COLORS.get(col, STATE_COLORS["Other"]) for col in pivot.columns]

        n_procs = len(pivot)
        fig, ax = plt.subplots(figsize=(max(7, n_procs * 0.7), max(4, n_procs * 0.5)))
        pivot.plot(kind="barh", stacked=True, ax=ax, color=colors, edgecolor="white", linewidth=0.5)
        ax.set_xlabel("Number of jobs")
        ax.set_ylabel("")
        ax.set_title(f"Per-process breakdown: {job_name}")
        ax.legend(loc="lower right", framealpha=0.9, edgecolor="#cccccc")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        for container in ax.containers:
            bar_container = container  # type: ignore[arg-type]
            ax.bar_label(
                bar_container,  # type: ignore[arg-type]
                label_type="center",
                fontsize=8,
                color="white",
                fontweight="bold",
                fmt=lambda x: f"{int(x)}" if x > 0 else "",
            )

        plt.tight_layout()

        return _fig_to_base64(fig)

    def make_progress_chart(self, summaries: list[dict]) -> str | None:
        if not summaries:
            return None

        names = [s["job_name"] for s in summaries]

        all_states_set: set[str] = set()
        for s in summaries:
            all_states_set.update(s["state_counts"].keys())
            if s["downloaded"] > 0:
                all_states_set.add("Downloaded")

        unknown_states = sorted(all_states_set - set(STATE_COLORS))

        state_order = [st for st in DONE_FIRST_ORDER if st in all_states_set] + [
            st for st in unknown_states if st not in DONE_FIRST_ORDER
        ]

        data: dict[str, list[int]] = {state: [] for state in state_order}
        for s in summaries:
            for state in state_order:
                if state == "Downloaded":
                    data[state].append(s["downloaded"])
                else:
                    data[state].append(s["state_counts"].get(state, 0))

        fig, ax = plt.subplots(figsize=(max(10, len(names) * 1.2), max(4, len(names) * 0.7)))
        ax.invert_yaxis()

        left = [0] * len(names)
        for state in state_order:
            values = data[state]
            color = STATE_COLORS.get(state, STATE_COLORS["Other"])
            ax.barh(names, values, left=left, color=color, label=state, edgecolor="white", linewidth=0.5)
            left = [l + v for l, v in zip(left, values)]

        for container in ax.containers:
            ax.bar_label(
                container,  # type: ignore[arg-type]
                label_type="center",
                fontsize=8,
                color="black",
                fontweight="bold",
                fmt=lambda x: f"{int(x)}" if x > 0 else "",
            )

        ax.set_xlabel("Number of jobs", fontsize=18)
        ax.set_title("Job progress", fontsize=18)
        _, labels = ax.get_legend_handles_labels()
        if labels:
            ax.legend(loc="upper left", bbox_to_anchor=(1, 1), frameon=False)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        fig.subplots_adjust(right=0.85)

        return _fig_to_base64(fig)


app = Flask(__name__)


DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>aCT Job Monitor</title>
    <meta http-equiv="refresh" content="{{ refresh }}">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f0f2f5; color: #333; padding: 20px; }
        h1 { margin-bottom: 5px; color: #2c3e50; }
        .header { margin-bottom: 20px; }
        .header small { color: #7f8c8d; }
        .cards { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 25px; }
        .card {
            background: white; border-radius: 8px; padding: 18px; min-width: 150px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;
        }
        .card .value { font-size: 28px; font-weight: bold; }
        .card .label { font-size: 12px; color: #7f8c8d; text-transform: uppercase; margin-top: 4px; }
        .card.blue .value { color: #3498db; }
        .card.green .value { color: #2ecc71; }
        .card.orange .value { color: #f39c12; }
        .card.red .value { color: #e74c3c; }
        table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 25px; }
        th { background: #2c3e50; color: white; padding: 10px 15px; text-align: left; font-size: 13px; }
        td { padding: 10px 15px; border-bottom: 1px solid #ecf0f1; font-size: 13px; }
        tr:hover { background: #f8f9fa; }
        a { color: #3498db; text-decoration: none; font-weight: 500; }
        a:hover { text-decoration: underline; }
        .progress-bar { background: #ecf0f1; border-radius: 10px; height: 20px; overflow: hidden; }
        .progress-fill { height: 100%; background: #2ecc71; border-radius: 10px; transition: width 0.3s; }
        .chart-row { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 25px; justify-content: center; }
        .chart-row img { max-width: 100%; height: auto; }
        .status-badge {
            display: inline-block; padding: 2px 10px; border-radius: 12px;
            font-size: 11px; font-weight: 600; color: white;
        }
        .badge-Submitted { background: #3498db; }
        .badge-Running { background: #f39c12; }
        .badge-Finishing { background: #27ae60; }
        .badge-Finished { background: #2ecc71; }
        .badge-Failed { background: #e74c3c; }
        .section { margin-bottom: 25px; }
        .section h2 { color: #2c3e50; margin-bottom: 10px; font-size: 18px; }
        .error-box { background: #fdedec; border: 1px solid #e74c3c; border-radius: 8px; padding: 15px; margin-bottom: 20px; }
        .watermark {
            text-align: right; padding: 20px 20px 10px;
            font-size: 14px; font-weight: 700; color: rgba(44,62,80,0.25);
            letter-spacing: 2px; pointer-events: none;
            user-select: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>aCT Job Monitor</h1>
        <small>Auto-refresh every {{ refresh }}s &middot; submit_dir: {{ submit_dir }}</small>
    </div>

    {% if act_error %}
    <div class="error-box">Could not reach aCT (act stat -a failed). Showing file-based info only.</div>
    {% endif %}

    {% if summaries %}
    <div class="cards">
        <div class="card"><div class="value">{{ totals.total }}</div><div class="label">Total</div></div>
        <div class="card green"><div class="value">{{ totals.downloaded }}</div><div class="label">Downloaded</div></div>
        <div class="card blue"><div class="value">{{ totals.submitted }}</div><div class="label">Submitted</div></div>
        <div class="card orange"><div class="value">{{ totals.running }}</div><div class="label">Running</div></div>
        <div class="card"><div class="value">{{ totals.finished }}</div><div class="label">Finished</div></div>
        <div class="card red"><div class="value">{{ totals.failed }}</div><div class="label">Failed</div></div>
    </div>

    {% if progress_chart %}
    <div class="section">
        <h2>Download Progress</h2>
        <div class="chart-row"><img src="data:image/svg+xml;base64,{{ progress_chart }}" alt="Progress chart"></div>
    </div>
    {% endif %}

    <!-- Per job_name table -->
    <div class="section">
        <h2>Job Batches</h2>
        <table>
            <tr>
                <th>Job Name</th>
                <th>Total</th>
                <th>Downloaded</th>
                <th>Progress</th>
                <th>Submitted</th>
                <th>Running</th>
                <th>Finished</th>
                <th>Failed</th>
            </tr>
            {% for s in summaries %}
            <tr>
                <td><a href="/job/{{ s.job_name }}">{{ s.job_name }}</a></td>
                <td>{{ s.total }}</td>
                <td>{{ s.downloaded }}</td>
                <td>
                    <div class="progress-bar" style="width:120px;">
                        <div class="progress-fill" style="width:{{ s.progress }}%;"></div>
                    </div>
                    <small>{{ "%.1f" | format(s.progress) }}%</small>
                </td>
                <td>{{ s.state_counts.get('Submitted', 0) }}</td>
                <td>{{ s.state_counts.get('Running', 0) }}</td>
                <td>{{ s.state_counts.get('Finished', 0) }}</td>
                <td>{{ s.state_counts.get('Failed', 0) }}</td>
            </tr>
            {% endfor %}
        </table>
    </div>
    {% else %}
    <p>No job batches found in {{ submit_dir }}.</p>
    {% endif %}
    <div class="watermark">F9Columnar</div>
</body>
</html>
"""

JOB_DETAIL_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>{{ job_name }} - aCT Monitor</title>
    <meta http-equiv="refresh" content="{{ refresh }}">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #f0f2f5; color: #333; padding: 20px; }
        h1 { margin-bottom: 5px; color: #2c3e50; }
        .header { margin-bottom: 20px; }
        .header small { color: #7f8c8d; }
        a { color: #3498db; text-decoration: none; font-weight: 500; }
        a:hover { text-decoration: underline; }
        .cards { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 25px; }
        .card {
            background: white; border-radius: 8px; padding: 18px; min-width: 130px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center;
        }
        .card .value { font-size: 28px; font-weight: bold; }
        .card .label { font-size: 12px; color: #7f8c8d; text-transform: uppercase; margin-top: 4px; }
        .card.blue .value { color: #3498db; }
        .card.green .value { color: #2ecc71; }
        .card.orange .value { color: #f39c12; }
        .card.red .value { color: #e74c3c; }
        table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 25px; }
        th { background: #2c3e50; color: white; padding: 10px 15px; text-align: left; font-size: 13px; }
        td { padding: 8px 15px; border-bottom: 1px solid #ecf0f1; font-size: 13px; }
        tr:hover { background: #f8f9fa; }
        .progress-bar { background: #ecf0f1; border-radius: 10px; height: 20px; overflow: hidden; }
        .progress-fill { height: 100%; background: #2ecc71; border-radius: 10px; }
        .chart-row { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 25px; align-items: flex-start; }
        .chart-row img { max-width: 100%; height: auto; }
        .status-badge {
            display: inline-block; padding: 2px 10px; border-radius: 12px;
            font-size: 11px; font-weight: 600; color: white;
        }
        .badge-Submitted { background: #3498db; }
        .badge-Running { background: #f39c12; }
        .badge-Finishing { background: #27ae60; }
        .badge-Finished { background: #2ecc71; }
        .badge-Failed { background: #e74c3c; }
        .section { margin-bottom: 25px; }
        .section h2 { color: #2c3e50; margin-bottom: 10px; font-size: 18px; }
        .error-box { background: #fdedec; border: 1px solid #e74c3c; border-radius: 8px; padding: 15px; margin-bottom: 20px; }
        .watermark {
            text-align: right; padding: 20px 20px 10px;
            font-size: 14px; font-weight: 700; color: rgba(44,62,80,0.25);
            letter-spacing: 2px; pointer-events: none;
            user-select: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ job_name }}</h1>
        <small><a href="/">&larr; Back to dashboard</a> &middot; Auto-refresh every {{ refresh }}s</small>
    </div>

    {% if act_error %}
    <div class="error-box">Could not reach aCT (act stat -a failed). Showing file-based info only.</div>
    {% endif %}

    <!-- Summary cards -->
    <div class="cards">
        <div class="card blue"><div class="value">{{ summary.total }}</div><div class="label">Total</div></div>
        <div class="card green"><div class="value">{{ summary.downloaded }}</div><div class="label">Downloaded</div></div>
        <div class="card"><div class="value">{{ summary.state_counts.get('Submitted', 0) }}</div><div class="label">Submitted</div></div>
        <div class="card orange"><div class="value">{{ summary.state_counts.get('Running', 0) }}</div><div class="label">Running</div></div>
        <div class="card"><div class="value">{{ summary.state_counts.get('Finished', 0) }}</div><div class="label">Finished</div></div>
        <div class="card red"><div class="value">{{ summary.state_counts.get('Failed', 0) }}</div><div class="label">Failed</div></div>
    </div>

    <!-- Progress -->
    <div class="section">
        <h2>Progress: {{ "%.1f" | format(summary.progress) }}%</h2>
        <div class="progress-bar" style="width:100%; max-width:500px;">
            <div class="progress-fill" style="width:{{ summary.progress }}%;"></div>
        </div>
    </div>

    <!-- Charts -->
    {% if state_chart %}
    <div class="section">
        <h2>State Distribution</h2>
        <div class="chart-row" style="justify-content: center;">
            <img src="data:image/svg+xml;base64,{{ state_chart }}" alt="State distribution">
        </div>
    </div>
    {% endif %}

    {% if process_chart %}
    <div class="section">
        <h2>Per-Process Breakdown</h2>
        <div class="chart-row" style="justify-content: center;">
            <img src="data:image/svg+xml;base64,{{ process_chart }}" alt="Process breakdown">
        </div>
    </div>
    {% endif %}

    <!-- Per-process summary table -->
    {% if process_summary %}
    <div class="section">
        <h2>Per-Process Summary</h2>
        <table>
            <tr>
                <th>Process</th>
                <th>Total</th>
                {% for state_name in all_states %}
                <th>{{ state_name }}</th>
                {% endfor %}
            </tr>
            {% for proc in process_summary %}
            <tr>
                <td>{{ proc.name }}</td>
                <td>{{ proc.total }}</td>
                {% for state_name in all_states %}
                <td>{{ proc.states.get(state_name, 0) }}</td>
                {% endfor %}
            </tr>
            {% endfor %}
        </table>
    </div>
    {% endif %}

    <!-- Individual jobs table -->
    {% if jobs_list %}
    <div class="section">
        <h2>Individual Jobs ({{ jobs_list | length }})</h2>
        <table>
            <tr>
                <th>Job Name</th>
                <th>Process</th>
                <th>State</th>
                <th>Arc State</th>
                <th>ID</th>
            </tr>
            {% for job in jobs_list %}
            <tr>
                <td>{{ job.jobname }}</td>
                <td>{{ job.process }}</td>
                <td><span class="status-badge badge-{{ job.State }}">{{ job.State }}</span></td>
                <td>{{ job.arcstate }}</td>
                <td>{{ job.id }}</td>
            </tr>
            {% endfor %}
        </table>
    </div>
    {% endif %}

    <!-- Downloaded jobs -->
    {% if downloaded_list %}
    <div class="section">
        <h2>Downloaded Jobs ({{ downloaded_list | length }})</h2>
        <table>
            <tr><th>Job Name</th><th>Process</th></tr>
            {% for d in downloaded_list %}
            <tr>
                <td>{{ d.name }}</td>
                <td>{{ d.process }}</td>
            </tr>
            {% endfor %}
        </table>
    </div>
    {% endif %}
    <div class="watermark">F9Columnar</div>
</body>
</html>
"""


@app.route("/")
def dashboard() -> str:
    monitor: ActMonitor = app.config["monitor"]
    refresh = app.config["refresh_interval"]

    all_state = monitor.get_all_state()
    act_error = all_state is None

    summaries = []
    for job_name in monitor.job_names:
        summary = monitor.get_job_summary(job_name, all_state)
        summaries.append(summary)

    totals = {
        "total": sum(s["total"] for s in summaries),
        "downloaded": sum(s["downloaded"] for s in summaries),
        "submitted": sum(s["state_counts"].get("Submitted", 0) for s in summaries),
        "running": sum(s["state_counts"].get("Running", 0) for s in summaries),
        "finished": sum(s["state_counts"].get("Finished", 0) for s in summaries),
        "failed": sum(s["state_counts"].get("Failed", 0) for s in summaries),
    }

    progress_chart = monitor.make_progress_chart(summaries) if len(summaries) > 0 else None

    return render_template_string(
        DASHBOARD_TEMPLATE,
        summaries=summaries,
        totals=totals,
        progress_chart=progress_chart,
        refresh=refresh,
        submit_dir=monitor.submit_dir,
        act_error=act_error,
    )


@app.route("/job/<job_name>")
def job_detail(job_name) -> str | tuple[str, int]:
    monitor: ActMonitor = app.config["monitor"]
    refresh = app.config["refresh_interval"]

    if job_name not in monitor.job_names:
        return f"Job '{job_name}' not found.", 404

    all_state = monitor.get_all_state()
    act_error = all_state is None

    summary = monitor.get_job_summary(job_name, all_state)
    state_df = summary["state_df"]
    downloaded_names = monitor.get_downloaded_jobs(job_name)

    chart_state_counts = dict(summary["state_counts"])
    if summary["downloaded"] > 0:
        chart_state_counts["Downloaded"] = summary["downloaded"]

    state_chart = monitor.make_state_chart(chart_state_counts, title="State distribution")
    process_chart = monitor.make_process_chart(state_df, job_name, downloaded_names)

    process_summary = []
    jobs_list = []
    all_states = []

    if state_df is not None and not state_df.empty:
        df = state_df.copy()
        df["process"] = df["jobname"].apply(lambda x: monitor.extract_process_name(x, job_name))

        all_states = sorted(df["State"].unique())

        for process_name, group in df.groupby("process"):
            state_counts = group["State"].value_counts().to_dict()
            process_summary.append({"name": process_name, "total": len(group), "states": state_counts})

        process_summary.sort(key=lambda x: x["name"])

        for _, row in df.iterrows():
            jobs_list.append(
                {
                    "jobname": row["jobname"],
                    "process": row.get("process", ""),
                    "State": row["State"],
                    "arcstate": row["arcstate"],
                    "id": row["id"],
                }
            )

    if downloaded_names:
        dl_by_proc: dict[str, int] = {}
        for d in downloaded_names:
            proc = monitor.extract_process_name(d, job_name)
            dl_by_proc[proc] = dl_by_proc.get(proc, 0) + 1

        existing = {p["name"]: p for p in process_summary}
        for proc, count in dl_by_proc.items():
            if proc in existing:
                existing[proc]["states"]["Downloaded"] = count
                existing[proc]["total"] += count
            else:
                process_summary.append({"name": proc, "total": count, "states": {"Downloaded": count}})

        process_summary.sort(key=lambda x: x["name"])
        if "Downloaded" not in all_states:
            all_states.append("Downloaded")

    downloaded_list = [
        {"name": d, "process": monitor.extract_process_name(d, job_name)} for d in sorted(downloaded_names)
    ]

    return render_template_string(
        JOB_DETAIL_TEMPLATE,
        job_name=job_name,
        summary=summary,
        state_chart=state_chart,
        process_chart=process_chart,
        process_summary=process_summary,
        all_states=all_states,
        jobs_list=jobs_list,
        downloaded_list=downloaded_list,
        refresh=refresh,
        act_error=act_error,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Web-based aCT job monitor.")
    parser.add_argument(
        "-c",
        "--config-path",
        required=False,
        type=str,
        default=None,
        help="Path to analysis configuration YAML file. If not provided, will use COLUMNAR_CONFIG_PATH.",
    )
    parser.add_argument(
        "-s",
        "--submit-dir",
        required=False,
        type=str,
        default=None,
        help="Path to the submission directory. If not provided, will use submit_dir from the configuration.",
    )
    parser.add_argument(
        "-j",
        "--job-names",
        required=False,
        type=str,
        nargs="+",
        default=None,
        help="Job names to monitor. If not provided, will use the job_name from the configuration.",
    )
    parser.add_argument(
        "-p",
        "--port",
        required=False,
        type=int,
        default=5000,
        help="Port to run the web server on (default: 5000).",
    )
    parser.add_argument(
        "--host",
        required=False,
        type=str,
        default="0.0.0.0",
        help="Host to bind the web server to (default: 0.0.0.0).",
    )
    parser.add_argument(
        "-r",
        "--refresh",
        required=False,
        type=int,
        default=None,
        help="Auto-refresh interval in seconds. Defaults to refresh_time from config.",
    )
    parser.add_argument(
        "-d",
        "--drive",
        action="store_true",
        help="Launch an ActDriver per job name in background threads.",
    )
    parser.add_argument(
        "-m",
        "--merge-only",
        action="store_true",
        help="If provided, only merge the outputs and skip monitoring.",
    )
    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Delete intermediate files after merging. "
        "Use with caution, as this will remove all files in the submit directory after merging!",
    )
    args = parser.parse_args()

    setup_logger()

    if args.config_path is None:
        config_path = os.environ.get("COLUMNAR_CONFIG_PATH", None)
        if config_path is None:
            raise ValueError("No configuration path provided and COLUMNAR_CONFIG_PATH is not set!")
    else:
        config_path = args.config_path

    analysis_config_builder = AnalysisConfigBuilder(config_path)
    analysis_config = analysis_config_builder.build()

    submit_dir = args.submit_dir if args.submit_dir is not None else analysis_config.submit.submit_dir
    job_names = args.job_names if args.job_names is not None else [analysis_config.submit.job_name]
    refresh = args.refresh if args.refresh is not None else analysis_config.submit.act_config.refresh_time

    monitor = ActMonitor(submit_dir, job_names if any(job_names) else None)

    if args.merge_only:
        for job_name in monitor.job_names:
            logging.info(f"Merging outputs for '{job_name}'...")
            merger = ActMerger(submit_dir, job_name, cleanup=args.cleanup)
            merger.merge()
        logging.info("Merge complete.")
        return None

    app.config["monitor"] = monitor
    app.config["refresh_interval"] = refresh

    logging.info(f"Starting aCT Job Monitor on http://{args.host}:{args.port}")
    logging.info(f"Monitoring submit_dir: {submit_dir}")
    logging.info(f"Job names: {', '.join(monitor.job_names) if monitor.job_names else 'none found'}")
    logging.info(f"Auto-refresh: {refresh}s")

    if args.drive:
        act_config = analysis_config.submit.act_config
        for job_name in monitor.job_names:
            driver = ActDriver(
                submit_dir,
                job_name,
                cluster_names=act_config.clusters,
                max_resub=act_config.max_resub,
                refresh_time=act_config.refresh_time,
            )
            monitor.drivers[job_name] = driver

            def _run_driver(d: ActDriver, name: str) -> None:
                result = d.run()
                if result is None:
                    logging.warning(f"Driver for '{name}' stopped (returned None). Removing from monitor.")
                    monitor.drivers.pop(name, None)
                else:
                    logging.info(f"Driver for '{name}' finished. Merging outputs.")
                    merger = ActMerger(submit_dir, name, cleanup=args.cleanup)
                    merger.merge()
                    logging.info(f"Merge complete for '{name}'.")

            thread = threading.Thread(
                target=_run_driver,
                args=(driver, job_name),
                name=f"driver-{job_name}",
                daemon=True,
            )

            thread.start()
            logging.info(f"Launched driver thread for '{job_name}'.")
            time.sleep(1)

    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
