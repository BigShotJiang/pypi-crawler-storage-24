import glob
import logging
import os
import subprocess
from typing import Any, Self

from f9columnar.dataset_builder import NtupleDatasetBuilder, NtuplePhysicsDataset
from f9columnar.processors import PostprocessorsGraph, ProcessorsGraph
from f9columnar.run import ColumnarEventLoop
from f9columnar.utils.helpers import create_tar_file, dump_pickle, load_pickle
from f9columnar.utils.loggers import get_progress


def job_template(
    executable: str,
    input_files: str,
    output_files: str,
    job_name: str,
    cpu_time: int = 20,
    wall_time: int = 20,
    memory: int = 4096,
    thread_count: int = 1,
) -> str:
    return f"""&
(executable="{executable}")
(executables="{executable}")
(inputFiles={input_files})
(outputFiles={output_files})
(jobName="{job_name}")
(stdout="run.out")
(join=yes)
(gmlog="arc")
(cpuTime="{cpu_time}")
(wallTime="{wall_time}")
(memory="{memory}")
(count="{thread_count}")
(runtimeenvironment="ENV/SINGULARITY" "f9columnar.sif")"""


class ActBatchHandler:
    def __init__(
        self,
        submit_dir: str,
        code_dir: str,
        dataset_builder: NtupleDatasetBuilder,
        processors: ProcessorsGraph,
        dcache_user: str,
        job_name: str | None = None,
        postprocessors: PostprocessorsGraph | None = None,
        input_files: list[str] | None = None,
        output_files: list[str] | None = None,
        cut_flow: bool = False,
        job_spec: dict[str, Any] | None = None,
    ) -> None:
        """Prepare and configure ARC batch job submissions for columnar analysis.

        This class handles the entire preparation workflow for submitting jobs to ARC
        computing resources. It creates xRSL job description files, packages code and
        dependencies, configures input/output files, and manages dataset serialization
        for distributed processing of physics data.

        Parameters
        ----------
        submit_dir : str
            Base directory where submission files will be created. A subdirectory named
            after `job_name` will be created within this directory.
        code_dir : str
            Path to the source code directory to be packaged and transferred to compute
            nodes. This directory will be tarred and extracted on the worker nodes.
        dataset_builder : NtupleDatasetBuilder
            Dataset builder containing MC and data datasets to be processed. Datasets
            will be serialized and transferred to compute nodes.
        processors : ProcessorsGraph
            Graph of processors to be applied to the datasets. These will be embedded
            into the serialized datasets.
        dcache_user : str
            dCache user identifier for transferring files from dCache storage.
        job_name : str, optional
            Name identifier for this batch submission. Used for organizing submission
            files and job naming. If None, defaults to "f9columnar" with a warning.
        postprocessors : PostprocessorsGraph, optional
            Graph of postprocessors to be applied after dataset processing. If provided,
            these will be embedded into the serialized datasets. Default is None.
        input_files : list of str, optional
            Additional input files to transfer to compute nodes, specified as xRSL tuples
            in the format '("destination" "source")'. Default is None (empty list).
        output_files : list of str, optional
            Additional output files to retrieve from compute nodes, specified as xRSL
            tuples in the format '("source" "destination")'. Default is None (empty list).
        job_spec : dict, optional
            Additional job specifications to customize resource requests. Default is None.
            It can include keys: 'cpu_time', 'wall_time', 'memory', and 'thread_count'.

        Attributes
        ----------
        submit_job_dir : str
            Full path to the job-specific submission directory where all submission
            files are stored.
        tar_file : str
            Path to the source code tarball that will be transferred to compute nodes.
        executable_file : str
            Path to the shell script that will be executed on compute nodes.

        Notes
        -----
        - The class automatically handles Rucio files
        - Processors and postprocessors are serialized (pickled) into dataset objects
          to ensure consistency between submission and execution environments.
        - Output files are collected in an 'out/' directory on compute nodes and
          retrieved after job completion.
        - The prepare() method must be called to finalize submission file creation.

        References
        ----------
        .. [1] Advanced Resource Connector (ARC): https://www.nordugrid.org/arc/arc6/
        .. [2] Nordugrid ARC job submission and management: https://doc.vega.izum.si/arc/

        """
        self.code_dir = code_dir
        self.dataset_builder = dataset_builder
        self.processors = processors
        self.dcache_user = dcache_user
        self.postprocessors = postprocessors
        self.cut_flow = cut_flow

        self.job_spec = {} if job_spec is None else job_spec

        self.code_folder = os.path.basename(code_dir)

        self.input_files = [] if input_files is None else input_files
        self.output_files = [] if output_files is None else output_files

        if job_name is None:
            job_name = "f9columnar"
            logging.warning(f"Job name is not provided, using default: {job_name}")

        self.job_name = job_name
        self.submit_job_dir = os.path.join(submit_dir, job_name)

        os.makedirs(self.submit_job_dir, exist_ok=True)

        self._tar_name = "source.tar"
        self._script_name = "act_run.sh"

        self.tar_file = os.path.join(self.submit_job_dir, self._tar_name)
        self.executable_file = os.path.join(self.submit_job_dir, self._script_name)

        self._dcache_base = "davs://dcache.sling.si:2880/atlas"

        self.input_files.append(f'("{self._tar_name}" "{self._dcache_path(self._tar_name)}" "cache=check")')
        self.input_files.append(f'("{self._script_name}" "{self.executable_file}")')
        self.input_files.append(f'("f9columnar.sif" "{self._dcache_path("f9columnar.sif", False)}" "cache=invariant")')

        self.output_files.append('("out.tar.gz" "")')

    def _dcache_path(self, file_name: str, is_user: bool = True) -> str:
        if is_user:
            return os.path.join(self._dcache_base, self.dcache_user, "columnar", self.job_name, file_name)

        return os.path.join(self._dcache_base, "columnar", file_name)

    def _add_processor_input_files(self) -> None:
        for processor in self.processors.processors.values():
            for input_file in processor.input_files:
                self.input_files.append(f'("processor_inputs/{os.path.basename(input_file)}" "{input_file}")')

        if self.postprocessors is not None:
            for postprocessor in self.postprocessors.processors.values():
                for input_file in postprocessor.input_files:
                    self.input_files.append(f'("postprocessor_inputs/{os.path.basename(input_file)}" "{input_file}")')

    def _make_submission_script(self, export_dct: dict[str, Any]) -> None:
        logging.info("Making act run file.")

        file_path = f"{os.path.dirname(os.path.abspath(__file__))}/{self._script_name}"

        result = subprocess.run(
            ["cp", file_path, self.submit_job_dir],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to copy script file: {result.stderr}")

        envs = "#!/bin/bash\n"
        envs += "set -e\n\n"
        for k, v in export_dct.items():
            envs += f'export {k}="{v}"\n'

        envs += "\n"

        with open(f"{self.submit_job_dir}/{self._script_name}", "r") as f:
            data = f.read()

        with open(f"{self.submit_job_dir}/{self._script_name}", "w") as f:
            f.write(envs + data)

    def _dump(self, file_name: str, obj: Any) -> None:
        dump_pickle(file_name, obj, recurse=True)

    def _configure_rucio_files(self) -> dict[str, list[list[str]]]:
        logging.info("Configuring rucio files.")

        datasets = self.dataset_builder.mc_datasets + self.dataset_builder.data_datasets
        input_files: dict[str, list[list[str]]] = {"mc": [], "data": []}

        for dataset in datasets:
            root_files, dataset_input_files = [], []

            for rucio_root_file in dataset.dataset_selection["root_file"].tolist():  # type: ignore[call-overload]
                root_file = os.path.basename(rucio_root_file)

                root_files.append(root_file)
                dataset_input_files.append(f'("rucio_inputs/{root_file}" "{rucio_root_file}" "cache=invariant")')

            if dataset.is_data:
                input_files["data"].append(dataset_input_files)
            else:
                input_files["mc"].append(dataset_input_files)

            dataset.dataset_selection["root_file"] = root_files  # type: ignore[call-overload]

        return input_files

    @staticmethod
    def _fmt_size(path: str) -> str:
        size = float(os.path.getsize(path))
        for unit in ("B", "KB", "MB", "GB"):
            if size < 1024:
                return f"{size:.2f} {unit}"
            size = size / 1024

        return f"{size:.2f} TB"

    def _save_datasets(self) -> dict[str, list[str]]:
        logging.info(f"Saving datasets to {self.submit_job_dir}.")

        os.makedirs(f"{self.submit_job_dir}/datasets", exist_ok=True)

        # save processors and postprocessors once as shared files
        logging.info("Saving shared processors.")

        processors_path = f"{self.submit_job_dir}/datasets/processors.p"
        self._dump(processors_path, self.processors)

        logging.info(f"Processors file size: {self._fmt_size(processors_path)}")

        self.input_files.append(f'("datasets/processors.p" "{self._dcache_path("processors.p")}" "cache=invariant")')

        logging.info("Copying processors to dCache.")
        result = subprocess.run(
            ["arccp", "-f", processors_path, self._dcache_path("processors.p")],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Failed to copy processors to dCache: {result.stderr}")

        if self.postprocessors is not None:
            logging.info("Saving shared postprocessors.")

            postprocessors_path = f"{self.submit_job_dir}/datasets/postprocessors.p"
            self._dump(postprocessors_path, self.postprocessors)

            logging.info(f"Postprocessors file size: {self._fmt_size(postprocessors_path)}")

            self.input_files.append(
                f'("datasets/postprocessors.p" "{self._dcache_path("postprocessors.p")}" "cache=invariant")'
            )

            logging.info("Copying postprocessors to dCache.")
            result = subprocess.run(
                ["arccp", "-f", postprocessors_path, self._dcache_path("postprocessors.p")],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                raise RuntimeError(f"Failed to copy postprocessors to dCache: {result.stderr}")

        datasets = self.dataset_builder.mc_datasets + self.dataset_builder.data_datasets
        saved_datasets: dict[str, list[str]] = {"mc": [], "data": []}

        data_count, mc_count = 0, 0
        with get_progress() as progress:
            task = progress.add_task("Saving datasets", total=len(datasets))
            for dataset in datasets:
                if dataset.is_data:
                    name = f"{dataset.name}_{self.job_name}_{data_count}"
                    data_count += 1
                else:
                    name = f"{dataset.name}_{self.job_name}_{mc_count}"
                    mc_count += 1

                ds_name = f"{name}_ds.p"
                ds_path = f"{self.submit_job_dir}/datasets/{ds_name}"

                self._dump(ds_path, dataset)

                if dataset.is_data:
                    saved_datasets["data"].append(f'("datasets/{ds_name}" "{ds_path}")')
                else:
                    saved_datasets["mc"].append(f'("datasets/{ds_name}" "{ds_path}")')

                progress.advance(task)

        return saved_datasets

    def _save_job(self, job_name: str, job_str: str) -> None:
        with open(f"{self.submit_job_dir}/jobs/{job_name}.xrsl", "w") as f:
            f.write(job_str)

    def _make_submission_xrsl(
        self, input_files: dict[str, list[list[str]]], saved_datasets: dict[str, list[str]]
    ) -> Self:
        logging.info("Making submission xrsl files.")

        os.makedirs(f"{self.submit_job_dir}/jobs", exist_ok=True)

        for file in glob.glob(f"{self.submit_job_dir}/jobs/*"):
            os.remove(file)

        for i, (mc_input_files, mc_saved_dataset) in enumerate(zip(input_files["mc"], saved_datasets["mc"])):
            mc_dataset = self.dataset_builder.mc_datasets[i]

            job_input_files = "".join(self.input_files) + mc_saved_dataset + "".join(mc_input_files)
            job_output_files = "".join(self.output_files)

            job_name = f"f9col_{mc_dataset.name}_{self.job_name}_{i}"

            job = job_template(
                self._script_name,
                job_input_files,
                job_output_files,
                job_name,
                **self.job_spec,
            )

            self._save_job(job_name, job)

        logging.info(f"Created {len(input_files['mc'])} MC jobs.")

        for i, (data_input_files, data_saved_dataset) in enumerate(zip(input_files["data"], saved_datasets["data"])):
            data_dataset = self.dataset_builder.data_datasets[i]

            job_input_files = "".join(self.input_files) + data_saved_dataset + "".join(data_input_files)
            job_output_files = "".join(self.output_files)

            job_name = f"f9col_{data_dataset.name}_{self.job_name}_{i}"

            job = job_template(
                self._script_name,
                job_input_files,
                job_output_files,
                job_name,
                **self.job_spec,
            )

            self._save_job(job_name, job)

        logging.info(f"Created {len(input_files['data'])} data jobs.")

        return self

    def _make_code_tar(self) -> None:
        logging.info(f"Making {self._tar_name} file.")
        create_tar_file(
            source_dir=self.code_dir,
            output_tar=self.tar_file,
            exclude=[
                "__pycache__",
                ".git",
                ".mypy_cache",
                ".pytest_cache",
                ".ipynb_checkpoints",
                "*.pyc",
                "docs",
                "tests",
            ],
        )

        logging.info("Copying tar file to dCache.")

        result = subprocess.run(
            ["arccp", "-f", self.tar_file, self._dcache_path(self._tar_name)],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            raise RuntimeError(f"Failed to copy tar file to dCache: {result.stderr}")

    def prepare(self) -> None:
        logging.info("[red][bold]Preparing batch submission![/bold][/red]")

        self._add_processor_input_files()

        self._make_submission_script(
            export_dct={
                "JOB_NAME": self.job_name,
                "TAR_NAME": self._tar_name,
                "THREAD_COUNT": str(self.job_spec.get("thread_count", 1)),
                "CODE_FOLDER": self.code_folder,
                "CUT_FLOW": "1" if self.cut_flow else "0",
            }
        )

        input_files = self._configure_rucio_files()
        saved_datasets = self._save_datasets()

        self._make_submission_xrsl(input_files, saved_datasets)
        self._make_code_tar()

        logging.info("[green][bold]Batch submission prepared! Use act_submit to submit the jobs.[/bold][/green]")


class ActBatchRunner:
    def __init__(self, job_name: str, data_dir: str = ".", cut_flow: bool = False, save_path: str = "out") -> None:
        """Class for running batch jobs. Runs ColumnarEventLoop using pickled datasets.

        Parameters
        ----------
        job_name : str
            Name of the current job.
        data_dir : str, optional
            Directory where data files are located, by default ".".
        cut_flow : bool, optional
            Whether to use cut and time flow for monitoring, by default False.
        save_path : str, optional
            Name of the directory with outputs, by default "out".
        """
        self.job_name = job_name
        self.data_dir = data_dir
        self.cut_flow = cut_flow
        self.save_path = save_path

        self.mc_datasets: list[NtuplePhysicsDataset] = []
        self.data_datasets: list[NtuplePhysicsDataset] = []

        self.postprocessors: PostprocessorsGraph | None = None

    def _load(self, file_name: str) -> Any:
        return load_pickle(file_name)

    def init(self) -> Self:
        dataset_files = glob.glob(f"{self.data_dir}/datasets/*_ds.p")

        if len(dataset_files) == 0:
            raise FileNotFoundError(f"No dataset files found in {self.data_dir} for job: {self.job_name}")

        # load shared processors/postprocessors saved once alongside datasets
        processors_path = f"{self.data_dir}/datasets/processors.p"
        processors: ProcessorsGraph | None = None
        if os.path.exists(processors_path):
            processors = self._load(processors_path)

        postprocessors_path = f"{self.data_dir}/datasets/postprocessors.p"
        if os.path.exists(postprocessors_path):
            self.postprocessors = self._load(postprocessors_path)

        # load datasets and configure their dataloaders with the loaded processors
        for dataset_file in dataset_files:
            dataset = self._load(dataset_file)

            dataset.set_root_files_path(f"{self.data_dir}/rucio_inputs")
            dataset.init_dataloader(processors=processors)

            if dataset.is_data:
                self.data_datasets.append(dataset)
            else:
                self.mc_datasets.append(dataset)

        # configure processor I/O paths once (shared across all datasets)
        if processors is not None:
            for proc in processors.processors.values():
                proc.set_input_files_path(f"{self.data_dir}/processor_inputs")
                proc.set_output_files_path(self.save_path)

        if self.postprocessors is not None:
            for proc in self.postprocessors.processors.values():
                proc.set_input_files_path(f"{self.data_dir}/postprocessor_inputs")
                proc.set_output_files_path(self.save_path)

        return self

    def run(self) -> Self:
        event_loop = ColumnarEventLoop(
            mc_datasets=self.mc_datasets if len(self.mc_datasets) > 0 else None,
            data_datasets=self.data_datasets if len(self.data_datasets) > 0 else None,
            postprocessors_graph=self.postprocessors,
            fit_postprocessors=True if self.postprocessors is not None else False,
            cut_flow=self.cut_flow,
            no_plot_cut_flow=True,
            disable_rich=True,
            save_path=self.save_path,
        )

        if len(self.mc_datasets) == 0 and len(self.data_datasets) == 0:
            raise ValueError("No datasets available to process")

        if len(self.mc_datasets) == 0:
            data_only = True
        else:
            data_only = False

        if len(self.data_datasets) == 0:
            mc_only = True
        else:
            mc_only = False

        event_loop.run(mc_only=mc_only, data_only=data_only)

        return self
