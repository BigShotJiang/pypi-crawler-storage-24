from __future__ import annotations

import logging

import numpy as np
import torch
import torch.multiprocessing as mp
import torch.utils.data

_registries: dict[str, dict] = {}

_SHUTDOWN = "___SHUTDOWN___"


def _server_loop(
    request_queue: mp.Queue,
    response_queues: dict[int, mp.Queue],
    default_response_queue: mp.Queue,
    models: dict[str, torch.nn.Module],
    device: str,
) -> None:
    """Main loop running in the GPU server process."""
    torch.cuda.set_device(device)

    for key, model in models.items():
        models[key] = model.to(device).eval()

    with torch.inference_mode():
        while True:
            item = request_queue.get()

            if item == _SHUTDOWN:
                break

            worker_id: int | None
            request_id: int
            features: np.ndarray
            model_key: str
            worker_id, request_id, features, model_key = item

            if model_key not in models:
                raise KeyError(f"Model key '{model_key}' not found. Available: {list(models.keys())}")

            tensor = torch.from_numpy(features).to(device)
            output = models[model_key](tensor).cpu().numpy()

            response_q = response_queues.get(worker_id) if worker_id is not None else None
            if response_q is None:
                response_q = default_response_queue

            response_q.put((request_id, output))

    logging.info(f"Inference server on {device.split(':')[0]} shut down.")


class InferenceServer:
    def __init__(
        self,
        models: dict[str, torch.nn.Module],
        device: str = "cuda:0",
        num_workers: int = 0,
        server_id: str = "default",
    ) -> None:
        """GPU inference server for multiprocessing environments.

        Provides a dedicated GPU process that serves model inference requests from
        forked DataLoader workers via multiprocessing queues. Workers never touch
        CUDA directly — they send numpy arrays and receive numpy results.

        Usage
        -----
        1. Start the server before the DataLoader workers:
            server = InferenceServer(models={"my_model_name": my_model}, device="cuda:0")
            server.start()

        2. Pass `server` into processors via `global_attributes`:
            graph.global_attributes = {"inference_server": server}

        3. Inside a processor's `run` method:
            result = self.inference_server.infer(features_np, model_key="my_model_name")

        4. Shut down after processing:
            server.shutdown()

        Parameters
        ----------
        models : dict[str, torch.nn.Module]
            Models to serve, keyed by name (e.g. `"my_model_name"`).
            Moved to *device* automatically in the server process.
        device : str
            CUDA device string, e.g. `"cuda:0"`.
        num_workers : int
            Number of DataLoader workers that will send requests.
        server_id : str
            Unique identifier for this server instance in the module-level registry.

        """
        self._models = models
        self._device = device
        self._num_workers = num_workers
        self._server_id = server_id

        # store queues in the module-level registry so that:
        #  1. Forked workers inherit them via fork (globals are copied).
        #  2. Pickling this object never touches Queue objects.
        _registries[server_id] = {
            "request": mp.Queue(),
            "responses": {i: mp.Queue() for i in range(num_workers)},
            "default_response": mp.Queue(),
        }

        self._process: mp.Process | None = None

    @property
    def _queues(self) -> dict:
        return _registries[self._server_id]

    def start(self) -> None:
        """Start the GPU server process."""
        queues = self._queues
        self._process = mp.Process(
            target=_server_loop,
            args=(
                queues["request"],
                queues["responses"],
                queues["default_response"],
                self._models,
                self._device,
            ),
            daemon=True,
        )
        self._process.start()
        logging.info(
            f"Inference server '{self._server_id}' started "
            f"(pid={self._process.pid}, device={self._device.split(':')[0]})."
        )

    @staticmethod
    def _get_worker_id() -> int | None:
        """Get the current DataLoader worker id, or None if in main process."""
        info = torch.utils.data.get_worker_info()
        return info.id if info is not None else None

    def infer(self, features: np.ndarray, model_key: str, worker_id: int | None = None) -> np.ndarray:
        """Send a numpy feature array to the GPU and block until the result is ready.

        Parameters
        ----------
        features : np.ndarray
            Input features for the model.
        model_key : str
            Which model to run, e.g. `"my_model_name"`.
        worker_id : int or None
            DataLoader worker id. Auto-detected from DataLoader context if None.

        Returns
        -------
        np.ndarray
            Model output.

        """
        if worker_id is None:
            worker_id = self._get_worker_id()

        queues = self._queues

        queues["request"].put((worker_id, 0, features, model_key))

        response_q = queues["responses"].get(worker_id) if worker_id is not None else None
        if response_q is None:
            response_q = queues["default_response"]

        _, result = response_q.get()
        return result

    def shutdown(self) -> None:
        """Send shutdown signal and wait for the server process to exit."""
        if self._process is not None and self._process.is_alive():
            self._queues["request"].put(_SHUTDOWN)
            self._process.join(timeout=10)

            if self._process.is_alive():
                logging.warning("Inference server did not exit cleanly, terminating.")
                self._process.terminate()

            self._process = None
            logging.info(f"Inference server '{self._server_id}' shut down.")

    def __getstate__(self) -> dict:
        """Pickle-safe: only store the server_id, not queues or process."""
        return {"_server_id": self._server_id}

    def __setstate__(self, state: dict) -> None:
        """Restore from pickle — reconnects to inherited module-level queues."""
        self._server_id = state["_server_id"]
        self._process = None
        self._models = None  # type: ignore[assignment]
        self._device = None  # type: ignore[assignment]
        self._num_workers = 0

    def __deepcopy__(self, memo: dict) -> InferenceServer:
        return self

    def __del__(self) -> None:
        self.shutdown()
