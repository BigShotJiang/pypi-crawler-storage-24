from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

import numpy as np
import torch
from torch.utils.data import DataLoader

from f9columnar.hdf5_dataloader import (
    Hdf5Iterator,
    get_hdf5_dataloader,
)
from f9columnar.ml.dataloader_helpers import (
    ColumnSelection,
    column_stack_structured_array,
    get_column_selection,
    padding_mask,
)
from f9columnar.ml.imbalanced_sampler import ImbalancedSampler
from f9columnar.ml.scalers import CategoricalFeatureScaler, NumericalFeatureScaler

BatchType = tuple[torch.Tensor | None, ...]
WeightedBatchType = tuple[*BatchType, dict[str, Any]]
FullWeightedBatchType = tuple[dict[str, BatchType], dict[str, Any]]


@dataclass(frozen=True, slots=True, repr=False, eq=False)
class StackedDataset:
    """Container for a stacked dataset created from a structured array.

    Attributes
    ----------
    X : np.ndarray
        Feature matrix, typically a 2D or 3D numpy array. If 2D, it is assumed to be of shape (n_samples, n_features).
        If 3D, it is assumed to be of shape (n_samples, n_objects, n_features).
    categ_idx : np.ndarray | None, optional
        Indices of categorical features in the last dimension of X, by default None.
    numer_idx : np.ndarray | None, optional
        Indices of numerical features in the last dimension of X, by default None.
    extra : dict[str, np.ndarray] | None, optional
        Additional data associated with the dataset, such as weights or labels, by default None.
        The keys of the dictionary should be strings, and the values should be numpy arrays.
        If provided, this data can be accessed using the `get_extra` method.
    """

    X: np.ndarray
    categ_idx: np.ndarray | None = None
    numer_idx: np.ndarray | None = None
    extra: dict[str, np.ndarray] | None = field(default_factory=dict)

    @property
    def features(self) -> np.ndarray:
        return self.X

    @property
    def is_empty(self) -> bool:
        return self.X.shape[0] == 0

    @property
    def numer_features(self) -> np.ndarray | None:
        if self.numer_idx is None:
            return None

        return self.X[..., self.numer_idx]

    @property
    def categ_features(self) -> np.ndarray | None:
        if self.categ_idx is None:
            return None

        return self.X[..., self.categ_idx]

    def get_extra(self, name: str, default: Any | None = None) -> np.ndarray | None:
        if self.extra is None or name not in self.extra:
            return default

        return self.extra[name]


@dataclass(frozen=True, slots=True, repr=False, eq=False)
class StackedDatasets:
    """Collection of stacked datasets.

    This class allows you to store multiple `StackedDataset` instances, each identified by a unique key (string).
    You can access datasets by their keys, add new datasets, and retrieve the list of available datasets.

    Attributes
    ----------
    _datasets : dict[str, StackedDataset]
        A dictionary that maps dataset names (keys) to their corresponding `StackedDataset` instances (values).
    """

    _datasets: dict[str, StackedDataset] = field(default_factory=dict)

    def keys(self) -> list[str]:
        return list(self._datasets.keys())

    def __setitem__(self, key: str, value: StackedDataset) -> None:
        if not isinstance(value, StackedDataset):
            raise TypeError(f"Value must be an instance of StackedDataset, got {type(value)} instead.")

        self._datasets[key] = value

    def __getitem__(self, item: str) -> StackedDataset:
        return self._datasets[item]

    def get(self, item: str, default: Any | None = None) -> StackedDataset | None:
        if item not in self._datasets:
            return default

        return self._datasets[item]

    def __len__(self) -> int:
        return len(self._datasets)

    def __iter__(self):
        return iter(self._datasets.values())

    def items(self) -> Iterable[tuple[str, StackedDataset]]:
        return self._datasets.items()

    def __repr__(self) -> str:
        return f"StackedDatasets({self.keys()})"

    def __str__(self) -> str:
        return f"StackedDatasets with datasets: {self.keys()}"


class WeightedBatch:
    """Container for a weighted batch of data.

    All parameters can be either numpy arrays or PyTorch tensors. If numpy arrays are provided, they will be
    converted to PyTorch tensors.

    `X` is the required feature tensor. `y`, `w`, and `y_aux` are standard optional fields.
    Additional tensors can be passed as keyword arguments and accessed as attributes (e.g., `batch.x1`).

    Parameters
    ----------
    X : np.ndarray | torch.Tensor
        Feature matrix (required).
    y : np.ndarray | torch.Tensor | None
        Labels for the data.
    w : np.ndarray | torch.Tensor | None
        Weights for the data.
    y_aux : np.ndarray | torch.Tensor | None
        Auxiliary labels for the data, e.g., signal type or label type.
    **extra : np.ndarray | torch.Tensor | None
        Additional named tensors (e.g., x1, x2). Accessible as attributes.
    """

    def __init__(
        self,
        X: np.ndarray | torch.Tensor,
        y: np.ndarray | torch.Tensor | None = None,
        w: np.ndarray | torch.Tensor | None = None,
        y_aux: np.ndarray | torch.Tensor | None = None,
        **extra: np.ndarray | torch.Tensor | None,
    ) -> None:
        if isinstance(X, np.ndarray):
            self.X = torch.from_numpy(X)
        else:
            self.X = X

        self.y = self._to_tensor(y)
        self.w = self._to_tensor(w)
        self.y_aux = self._to_tensor(y_aux)

        self._extra_keys: tuple[str, ...] = tuple(extra.keys())
        for k, v in extra.items():
            setattr(self, k, self._to_tensor(v))

        n_samples = self.X.shape[0]
        for name, val in self._iter_optional():
            if val is not None and val.shape[0] != n_samples:
                raise RuntimeError(f"X and {name} must have the same first dimension!")

    @staticmethod
    def _to_tensor(val: np.ndarray | torch.Tensor | None) -> torch.Tensor | None:
        if isinstance(val, np.ndarray):
            return torch.from_numpy(val)
        return val

    def _iter_optional(self) -> Iterable[tuple[str, torch.Tensor | None]]:
        """Iterate over all optional tensor fields (fixed + extra)."""
        yield "y", self.y
        yield "w", self.w
        yield "y_aux", self.y_aux
        for name in self._extra_keys:
            yield name, getattr(self, name)

    def _iter_all(self) -> Iterable[tuple[str, torch.Tensor | None]]:
        """Iterate over all tensor fields including X."""
        yield "X", self.X
        yield from self._iter_optional()

    @property
    def extra_keys(self) -> tuple[str, ...]:
        return self._extra_keys

    @property
    def feature_shape(self) -> tuple[int, ...]:
        return tuple(self.X.shape)

    def make_batch(self) -> tuple[torch.Tensor | None, ...]:
        return tuple(val for _, val in self._iter_all())

    def _apply(self, indexer: np.ndarray | torch.Tensor | slice) -> WeightedBatch:
        if isinstance(indexer, np.ndarray):
            indexer = torch.from_numpy(indexer)

        kwargs: dict[str, torch.Tensor | None] = {}
        for name, val in self._iter_all():
            kwargs[name] = val[indexer] if val is not None else None

        return self.__class__(**kwargs)  # type: ignore[arg-type]

    def mask(self, mask: np.ndarray | torch.Tensor) -> WeightedBatch:
        return self._apply(mask)

    def __len__(self) -> int:
        return self.X.shape[0]

    def __getitem__(self, value: slice) -> WeightedBatch:
        return self._apply(value)


@dataclass(frozen=True, slots=True, repr=False, eq=False)
class WeightedDatasetBatch:
    """Collection of weighted batches.

    This class allows you to store multiple `WeightedBatch` instances, each identified by a unique key (string).
    You can access batches by their keys, add new batches, and retrieve the list of available batches.

    Attributes
    ----------
    _datasets : dict[str, WeightedBatch]
        A dictionary that maps dataset names (keys) to their corresponding `WeightedBatch` instances (values).
    """

    _datasets: dict[str, WeightedBatch] = field(default_factory=dict)

    def __setitem__(self, key: str, value: WeightedBatch) -> None:
        self._datasets[key] = value

    def __getitem__(self, args: str | tuple[str, slice]) -> WeightedBatch:
        if type(args) is str:
            return self._datasets[args]
        elif type(args) is tuple and len(args) == 2:
            return self._datasets[args[0]][args[1]]
        else:
            raise ValueError(f"Invalid arguments for __getitem__: {args}")

    def __len__(self) -> int:
        return len(self._datasets)

    def keys(self) -> list[str]:
        return list(self._datasets.keys())

    @property
    def feature_shape(self):
        return {k: v.X.shape for k, v in self._datasets.items()}

    @property
    def dim(self) -> int:
        shapes = [v.X.shape[0] for v in self._datasets.values()]

        if len(shapes) == 0:
            raise RuntimeError("No datasets in WeightedDatasetBatch to determine dimension.")

        if len(set(shapes)) != 1:
            raise RuntimeError("All datasets in WeightedDatasetBatch must have the same first dimension.")

        return shapes[0]

    def mask(self, mask: np.ndarray | torch.Tensor, dataset: str | None = None) -> WeightedDatasetBatch:
        if isinstance(mask, np.ndarray):
            mask = torch.from_numpy(mask)

        _masked_datasets = {}
        for key, w_batch in self._datasets.items():
            if dataset is None or key == dataset:
                _masked_datasets[key] = w_batch.mask(mask)
            else:
                _masked_datasets[key] = w_batch

        return self.__class__(_masked_datasets)

    def make_batch(self) -> dict[str, BatchType]:
        batch = {}
        for key, ds_batch in self._datasets.items():
            batch[key] = ds_batch.make_batch()
        return batch

    def __repr__(self) -> str:
        return f"WeightedDatasetBatch({self.keys()})"

    def __str__(self) -> str:
        return f"WeightedDatasetBatch with datasets: {self.keys()}"


class NumerCategDatasetScaler:
    def __init__(
        self,
        selection: ColumnSelection,
        numer_scaler_type: str | None = None,
        categ_scaler_type: str | None = None,
        scaler_path: str | None = None,
        extra_hash: str = "",
    ) -> None:
        """Handles numerical and categorical feature scaling for multiple datasets.

        Parameters
        ----------
        selection : ColumnSelection
            Column selection mapping dataset names to their column specifications.
        numer_scaler_type : str | None
            Type of numerical scaler (e.g., 'standard', 'minmax'), or None to disable.
        categ_scaler_type : str | None
            Type of categorical scaler, or None to disable.
        scaler_path : str | None
            Path to load pre-fitted scalers from.
        extra_hash : str
            Extra hash string for scaler file identification.
        """
        self.selection = selection
        self.disable_numer_scaling = numer_scaler_type is None
        self.disable_categ_scaling = categ_scaler_type is None

        self.numer_feature_scaler_dct: dict[str, NumericalFeatureScaler | None] = {}
        self.categ_feature_scaler_dct: dict[str, CategoricalFeatureScaler | None] = {}

        self._setup_scalers(numer_scaler_type, categ_scaler_type, scaler_path, extra_hash)

    def _setup_scalers(
        self,
        numer_scaler_type: str | None,
        categ_scaler_type: str | None,
        scaler_path: str | None,
        extra_hash: str = "",
    ) -> None:
        for dataset_name in self.selection.keys():
            numer_feature_scaler, categ_feature_scaler = self._setup_dataset_scaler(
                scaler_path,
                numer_scaler_type,
                categ_scaler_type,
                dataset_name,
                postfix=dataset_name,
                extra_hash=extra_hash,
            )
            self.numer_feature_scaler_dct[dataset_name] = numer_feature_scaler
            self.categ_feature_scaler_dct[dataset_name] = categ_feature_scaler

    def _setup_dataset_scaler(
        self,
        scaler_path: str | None,
        numer_scaler_type: str | None,
        categ_scaler_type: str | None,
        dataset_name: str,
        postfix: str | None = None,
        extra_hash: str = "",
    ) -> tuple[NumericalFeatureScaler | None, CategoricalFeatureScaler | None]:
        if scaler_path is None or (numer_scaler_type is None and categ_scaler_type is None):
            return None, None

        numer_feature_scaler: NumericalFeatureScaler | None
        categ_feature_scaler: CategoricalFeatureScaler | None

        numer_column_names = self.selection[dataset_name].numer_columns
        categ_column_names = self.selection[dataset_name].categ_columns

        if len(numer_column_names) != 0 and not self.disable_numer_scaling:
            numer_feature_scaler = NumericalFeatureScaler(numer_scaler_type, save_path=scaler_path)
            numer_feature_scaler = numer_feature_scaler.load(numer_column_names, postfix, extra_hash=extra_hash)

            if numer_feature_scaler is None:
                raise RuntimeError("Failed to load numerical feature scaler!")
        else:
            numer_feature_scaler = None

        if len(categ_column_names) != 0 and not self.disable_categ_scaling:
            categ_feature_scaler = CategoricalFeatureScaler(categ_scaler_type, save_path=scaler_path)
            categ_feature_scaler = categ_feature_scaler.load(categ_column_names, postfix, extra_hash=extra_hash)

            if categ_feature_scaler is None:
                raise RuntimeError("Failed to load categorical feature scaler!")
        else:
            categ_feature_scaler = None

        return numer_feature_scaler, categ_feature_scaler

    def _scale(self, X: np.ndarray, dataset_name: str, is_numer: bool) -> np.ndarray:
        scaler: NumericalFeatureScaler | CategoricalFeatureScaler | None

        if is_numer:
            scaler = self.numer_feature_scaler_dct[dataset_name]
        else:
            scaler = self.categ_feature_scaler_dct[dataset_name]

        n_objects = self.selection[dataset_name].n_objects

        if n_objects == 1:
            if scaler is not None:
                X = scaler.transform(X)
        else:
            X = X.reshape(-1, X.shape[-1])  # (n_samples * n_objects, n_features)
            if scaler is not None:
                pad_value = self.selection[dataset_name].pad_value

                if pad_value is not None:
                    mask = padding_mask(X, pad_value)

                    X_full = np.full_like(X, pad_value)
                    X_full[mask] = scaler.transform(X[mask])

                    X = X_full
                else:
                    X = scaler.transform(X)

            X = X.reshape(-1, n_objects, X.shape[-1])  # (n_samples, n_objects, n_features)

        return X

    def scale(
        self, X_numer: np.ndarray | None = None, X_categ: np.ndarray | None = None, dataset_name: str = "events"
    ) -> tuple[np.ndarray | None, np.ndarray | None]:
        if X_numer is not None and not self.disable_numer_scaling:
            X_numer = self._scale(X_numer, dataset_name, is_numer=True)

        if X_categ is not None and not self.disable_categ_scaling:
            X_categ = self._scale(X_categ, dataset_name, is_numer=False)

        return X_numer, X_categ


class MLHdf5Iterator(Hdf5Iterator):
    def __init__(
        self,
        file: str,
        dataset_names: list[str],
        chunk_size: int | None,
        start_entry: int,
        stop_entry: int,
        shuffle: bool = False,
        load_column_names_dct: dict[str, list[str]] | None = None,
        dataset_kwargs: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            file=file,
            dataset_names=dataset_names,
            chunk_size=chunk_size,
            start_entry=start_entry,
            stop_entry=stop_entry,
            shuffle=shuffle,
            load_column_names_dct=load_column_names_dct,
            dataset_kwargs=dataset_kwargs,
            filter_dataset_kwargs=False,
        )
        if len(self.dataset_kwargs) == 0:
            raise ValueError("dataset_kwargs must be provided!")

        if "batch_size" not in self.dataset_kwargs:
            raise ValueError("Batch size must be provided in dataset_kwargs!")

        if not self.combined_dataset:
            raise ValueError("MLHdf5Iterator is designed to work with combined datasets only!")

        # batch setup
        self.batch_size = self.dataset_kwargs["batch_size"]

        if self.batch_size is None:
            self.batch_size = self.chunk_size

        self.drop_last = self.dataset_kwargs.get("drop_last", False)

        self.setup_func: Callable[[StackedDatasets, MLHdf5Iterator], WeightedDatasetBatch | None]

        if "setup_func" not in self.dataset_kwargs:
            self.setup_func = default_setup_func
        else:
            self.setup_func = self.dataset_kwargs["setup_func"]

        # setup imbalanced class sampling
        self.imbalanced_sampler: ImbalancedSampler | None

        self.used_imbalanced_sampler = self.dataset_kwargs.get("imbalanced_sampler", None)

        if self.used_imbalanced_sampler is not None:
            imbalanced_sampler_kwargs = self.dataset_kwargs.get("imbalanced_sampler_kwargs", {})
            class_labels = self.dataset_kwargs.get("class_labels", None)
            self.imbalanced_sampler = ImbalancedSampler(
                self.used_imbalanced_sampler, imbalanced_sampler_kwargs, class_labels=class_labels
            )
        else:
            self.imbalanced_sampler = None

        # setup column selection
        self.selection: ColumnSelection = self.dataset_kwargs["selection"]

        # feature scaling setup
        self.dataset_scaler = NumerCategDatasetScaler(
            selection=self.selection,
            numer_scaler_type=self.dataset_kwargs.get("numer_scaler_type", None),
            categ_scaler_type=self.dataset_kwargs.get("categ_scaler_type", None),
            scaler_path=self.dataset_kwargs.get("scaler_path", None),
            extra_hash=self.dataset_kwargs.get("scalers_extra_hash", ""),
        )

        self.save_numer_unscaled_jagged = self.dataset_kwargs.get("save_numer_unscaled_jagged_features", False)
        self.save_categ_unscaled_jagged = self.dataset_kwargs.get("save_categ_unscaled_jagged_features", False)

        self._save_unscaled_jagged = self.save_numer_unscaled_jagged or self.save_categ_unscaled_jagged

        # remove unnecessary dataset kwargs for lighter reports
        self._filter_dataset_kwargs()

        # internal setup
        self.total, self.current = 0, 0

        # internal data types
        self.weighted_dataset_batch: WeightedDatasetBatch

    def split_and_feature_scale(self, dataset_arrays_dct: dict[str, np.ndarray]) -> StackedDatasets:
        stacked_datasets = StackedDatasets()

        for dataset_name, arrays in dataset_arrays_dct.items():
            numer_names = self.selection[dataset_name].numer_columns
            categ_names = self.selection[dataset_name].categ_columns

            extra_names = self.selection[dataset_name].extra_columns
            if len(extra_names) != 0:
                extra = {name: arrays[name].copy() for name in extra_names}
            else:
                extra = None

            if len(numer_names) != 0:
                X_numer_dataset_stack = column_stack_structured_array(arrays, numer_names)
                numer_shape = X_numer_dataset_stack.shape
            else:
                X_numer_dataset_stack = None

            if len(categ_names) != 0:
                X_categ_dataset_stack = column_stack_structured_array(arrays, categ_names)
                categ_shape = X_categ_dataset_stack.shape
            else:
                X_categ_dataset_stack = None

            if self._save_unscaled_jagged and dataset_name != "events":
                if extra is None:
                    extra = {}

                if self.save_numer_unscaled_jagged and X_numer_dataset_stack is not None:
                    extra["X_numer_unscaled"] = X_numer_dataset_stack.copy()
                else:
                    extra["X_numer_unscaled"] = None

                if self.save_categ_unscaled_jagged and X_categ_dataset_stack is not None:
                    extra["X_categ_unscaled"] = X_categ_dataset_stack.copy()
                else:
                    extra["X_categ_unscaled"] = None

            X_numer_dataset_stack, X_categ_dataset_stack = self.dataset_scaler.scale(
                X_numer_dataset_stack, X_categ_dataset_stack, dataset_name
            )

            if X_numer_dataset_stack is not None and X_categ_dataset_stack is not None:
                X_dataset_stack = np.concatenate([X_numer_dataset_stack, X_categ_dataset_stack], axis=-1)
                numer_idx = np.arange(numer_shape[-1])
                categ_idx = np.arange(numer_shape[-1], numer_shape[-1] + categ_shape[-1])

            elif X_numer_dataset_stack is not None:
                X_dataset_stack = X_numer_dataset_stack
                categ_idx, numer_idx = None, np.arange(numer_shape[-1])

            elif X_categ_dataset_stack is not None:
                X_dataset_stack = X_categ_dataset_stack
                categ_idx, numer_idx = np.arange(categ_shape[-1]), None

            else:
                X_dataset_stack = np.array([])
                categ_idx, numer_idx = None, None

            stacked_datasets[dataset_name] = StackedDataset(
                X=X_dataset_stack,
                categ_idx=categ_idx,
                numer_idx=numer_idx,
                extra=extra,
            )

        return stacked_datasets

    def on_iter_start_setup(self) -> bool:
        dataset_arrays_dct: dict[str, np.ndarray] = {}

        for dataset_name in self.dataset_names:
            array = self._get_dataset_array(dataset_name)
            dataset_arrays_dct[dataset_name] = array

        stacked_datasets = self.split_and_feature_scale(dataset_arrays_dct)

        setup_func_return = self.setup_func(stacked_datasets, self)

        if setup_func_return is None:
            return False

        self.weighted_dataset_batch = setup_func_return

        if set(self.dataset_names) != set(self.weighted_dataset_batch.keys()):
            logging.critical(f"Expected: {self.dataset_names}, have: {self.weighted_dataset_batch.keys()}!")
            raise RuntimeError("Dataset names mismatch!")

        self.total = self.weighted_dataset_batch.dim

        if self.batch_size > self.total:
            self.batch_size = self.total

        return True

    def make_report(self) -> dict[str, Any]:
        report = super().make_report()
        extra_report = {
            "batch_current": self.current,
            "batch_total": self.total,
            "batch_size": self.batch_size,
            "drop_last": self.drop_last,
            "used_imbalanced_sampler": self.used_imbalanced_sampler,
            "numer_feature_scaler_dct": self.dataset_scaler.numer_feature_scaler_dct,
            "categ_feature_scaler_dct": self.dataset_scaler.categ_feature_scaler_dct,
        }
        return report | extra_report

    def close(self) -> None:
        self.handle.close()

    def __iter__(self) -> MLHdf5Iterator:
        return self

    def __next__(self) -> tuple[WeightedDatasetBatch, dict[str, Any]]:
        if self.current == 0:
            start_status = self.on_iter_start_setup()
            if not start_status:
                raise StopIteration

        if self.current == self.total:
            self.close()
            raise StopIteration

        next_current = self.current + self.batch_size
        if next_current >= self.total:
            next_current = self.total

        if self.drop_last:
            if next_current - self.current < self.batch_size:
                self.close()
                raise StopIteration

        iter_weighted_dataset_batch = WeightedDatasetBatch()

        for ds_name in self.weighted_dataset_batch.keys():
            iter_weighted_dataset_batch[ds_name] = self.weighted_dataset_batch[ds_name, self.current : next_current]

        self.current = next_current

        reports = self.make_report()

        return iter_weighted_dataset_batch, reports


def remap_labels_lookup(y: np.ndarray, max_label: int, remap_labels: dict[int, int]) -> tuple[np.ndarray, np.ndarray]:
    lookup = np.full(max_label + 1, -1)

    for old_label, new_label in remap_labels.items():
        lookup[old_label] = new_label

    y = lookup[y]

    mask_unmapped = y != -1

    return y[mask_unmapped], mask_unmapped


def events_collate_fn(batch: tuple[WeightedDatasetBatch, dict[str, Any]]) -> WeightedBatchType:
    ds, reports = batch[0]["events"], batch[1]

    numer_feature_scaler_dct = reports.pop("numer_feature_scaler_dct")
    categ_feature_scaler_dct = reports.pop("categ_feature_scaler_dct")

    reports["numer_scaler"] = numer_feature_scaler_dct["events"]
    reports["categ_scaler"] = categ_feature_scaler_dct["events"]

    return ds.X, ds.y, ds.w, ds.y_aux, reports


def full_collate_fn(batch: tuple[WeightedDatasetBatch, dict[str, Any]]) -> FullWeightedBatchType:
    datasets_batch, reports = batch[0].make_batch(), batch[1]
    return datasets_batch, reports


def default_setup_func(stacked_datasets: StackedDatasets, ml_iterator: MLHdf5Iterator) -> WeightedDatasetBatch | None:
    weighted_datase_batch = WeightedDatasetBatch()

    dataset_keys = stacked_datasets.keys()
    if "events" in dataset_keys:
        dataset_keys.remove("events")
        dataset_keys.insert(0, "events")

    mask_unmapped: np.ndarray | None = None

    for ds_name in dataset_keys:
        ds = stacked_datasets[ds_name]

        X = ds.X.astype(np.float32) if not ds.is_empty else None
        y = ds.get_extra("label_type", None)
        w = ds.get_extra("weights", None)
        y_aux = None

        if y is not None:
            remap_labels: dict[int, int] | None = ml_iterator.dataset_kwargs.get("remap_labels", None)
            if remap_labels is not None:
                max_label = ml_iterator.dataset_kwargs["max_label"]
                y, mask_unmapped = remap_labels_lookup(y, max_label, remap_labels)

            if y.shape[0] == 0:
                return None

        if mask_unmapped is not None:
            if X is not None:
                X = X[mask_unmapped]
            if w is not None:
                w = w[mask_unmapped]

        if X is None:
            n_samples = y.shape[0] if y is not None else (w.shape[0] if w is not None else 0)
            X = np.empty((n_samples, 0), dtype=np.float32)

        weighted_datase_batch[ds_name] = WeightedBatch(X, y, w, y_aux)

    return weighted_datase_batch


def get_ml_hdf5_dataloader(
    name: str,
    files: str | list[str],
    column_names: list[str],
    num_workers: int | None = None,
    stage_split_piles: dict[str, list[int] | int] | None = None,
    stage: str | None = None,
    shuffle: bool = False,
    collate_fn: Callable[[tuple[WeightedDatasetBatch, dict[str, Any]]], Any] | None = None,
    dataset_kwargs: dict[str, Any] | None = None,
    dataloader_kwargs: dict[str, Any] | None = None,
) -> tuple[DataLoader, ColumnSelection, int]:
    if type(files) is str and files.endswith("*"):
        use_piles = False
    else:
        use_piles = True

    selection = get_column_selection(files, column_names)

    if dataset_kwargs is None:
        dataset_kwargs = {}

    if type(dataset_kwargs) is not dict:
        raise TypeError(f"dataset_kwargs must be a dict, got {type(dataset_kwargs)} instead.")

    dataset_kwargs["selection"] = selection

    if dataloader_kwargs is not None:
        if "batch_size" not in dataset_kwargs and "batch_size" in dataloader_kwargs:
            dataset_kwargs["batch_size"] = dataloader_kwargs.pop("batch_size")
            logging.info(f"Set batch size to {dataset_kwargs['batch_size']}.")

    dl, num_entries = get_hdf5_dataloader(
        name,
        files,
        dataset_names=selection.keys(),
        num_workers=num_workers,
        chunk_size=None,
        use_piles=use_piles,
        stage_split_piles=stage_split_piles,
        stage=stage,
        shuffle=shuffle,
        hdf5_files_desc_dct=None,
        processors=None,
        combine_datasets=True,
        allow_carrying_over=False,
        iterator_class=MLHdf5Iterator,
        collate_fn=collate_fn,
        dataset_kwargs=dataset_kwargs,
        dataloader_kwargs=dataloader_kwargs,
    )

    return dl, selection, num_entries
