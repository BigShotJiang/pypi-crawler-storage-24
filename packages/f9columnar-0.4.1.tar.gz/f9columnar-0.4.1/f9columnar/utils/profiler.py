import cProfile
import logging
import os
import pstats
from functools import wraps
from typing import Any, Callable


def profile_processor(filename: str | None = None) -> Callable:
    """Decorator to profile run method and save results to file.

    Filename priority:
        1. Explicit filename argument
        2. COLUMNAR_PROFILE_FILE environment variable
        3. Default: "profile_{processor_name}.txt"

    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            processor_name = "unknown"
            if args and hasattr(args[0], "name"):
                processor_name = args[0].name

            if filename is not None:
                actual_filename = filename
            elif (env_file := os.environ.get("COLUMNAR_PROFILE_FILE")) is not None:
                actual_filename = env_file
            else:
                actual_filename = f"profile_{processor_name}.txt"

            if processor_name not in actual_filename and processor_name != "unknown":
                base, ext = os.path.splitext(actual_filename)
                actual_filename = os.path.join(base, f"{processor_name}{ext}.txt")

            profiler = cProfile.Profile()
            profiler.enable()
            result = func(*args, **kwargs)
            profiler.disable()

            with open(actual_filename, "w") as f:
                stats = pstats.Stats(profiler, stream=f)
                stats.sort_stats("cumulative")
                stats.print_stats(100)

            logging.info(f"Profile saved to: {actual_filename}")
            return result

        return wrapper

    if callable(filename):
        func = filename  # type: ignore[unreachable]
        filename = None
        return decorator(func)

    return decorator
