from typing import Any

import awkward as ak
import numpy as np


def check_numpy_type(array: ak.Array | np.ndarray | Any, check_1d: bool = True) -> bool:
    if type(array) is ak.Array and type(array.type.content) is ak.types.NumpyType:
        return True
    elif type(array) is np.ndarray:
        if check_1d and array.ndim != 1:
            raise ValueError("Array should be 1D.")
        return True
    else:
        return False


def check_list_type(array: ak.Array | Any) -> bool:
    return bool(type(array) is ak.Array and type(array.type.content) is ak.types.ListType)


def format_ak_array(arr: ak.Array, n: int | None = 10, precision: int = 3, name: str = "") -> str:
    """Format contents of a jagged/awkward array as a string.

    Parameters:
    -----------
    arr : awkward.Array
        The jagged array to format.
    n : int, optional
        Number of sub-arrays to display. If None, shows all, by default 10.
    precision : int
        Number of decimal places for floats, by default 3.

    Returns:
    --------
    str
        Formatted string representation
    """
    arr_list = arr.to_list()
    total = len(arr_list)

    if n is None:
        n = total
    n = min(n, total)

    lines = []
    lines.append(f"Type: {arr.type}")
    lines.append(f"Length: {total} (showing {n})")
    lines.append(f"Name: {name}" if name else "Array contents:")
    lines.append("")

    for i in range(n):
        sub = arr_list[i]
        if isinstance(sub, list):
            vals = ", ".join(f"{x:.{precision}f}" if isinstance(x, float) else str(x) for x in sub)
            formatted = f"[{vals}]"
        else:
            formatted = str(sub)

        lines.append(f"  [{i:4d}] {formatted}")

    if n < total:
        lines.append(f"  ... ({total - n} more sub-arrays)")

    return "\n".join(lines)
