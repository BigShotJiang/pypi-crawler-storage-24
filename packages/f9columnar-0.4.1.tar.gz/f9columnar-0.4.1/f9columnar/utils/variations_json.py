import argparse
import json
import logging
import os
import re
from typing import Any

import uproot

from f9columnar.utils.loggers import setup_logger


def _get_root_branches(root_file: str, key: str) -> list[str]:
    if not os.path.isfile(root_file):
        raise FileNotFoundError(f"Provided ROOT file {root_file} does not exist.")

    base_name = os.path.basename(root_file)
    if "metadata" in base_name.lower():
        raise ValueError("Metadata file provided, please provide a valid ROOT file.")

    if "data" in base_name.lower():
        raise ValueError("Data file provided, please provide a MC ROOT file.")

    with uproot.open(root_file) as f:
        f_data = f[key]  # type: ignore[index]

    branches_lst = f_data.keys()  # type: ignore[attr-defined]

    return branches_lst


def _parse_objects(branches_lst: list[str], key: str, save_dir: str | None) -> dict[str, list[str]]:
    branches: dict[str, list[str]] = {
        "el": [],
        "mu": [],
        "tau": [],
        "jet": [],
        "met": [],
        "weight": [],
        "trig": [],
        "other": [],
        "truth": [],
    }

    for b in branches_lst:
        first_split = b.split("_")[0]
        if "trig" in first_split:
            first_split = "trig"

        if first_split not in branches.keys():
            branches["other"].append(b)
        else:
            branches[first_split].append(b)

    sums = 0
    for k, v in branches.items():
        branches[k] = sorted(v)
        sums += len(v)
        logging.debug(f"Found {len(v)} branches for object {k}")

    logging.debug(f"Total branches parsed: {sums}")

    if save_dir is not None:
        save_file = os.path.join(save_dir, f"branches_{key}.json")

        logging.debug(f"Saving parsed branches to {save_file}")
        with open(save_file, "w") as f:
            json.dump(branches, f, indent=4)

    return branches


def _parse_sys_objects(branches_lst: list[str]) -> dict[str, list[str]]:
    branches_sys: dict[str, list[str]] = {"nominal": [], "up": [], "down": [], "nosys": []}

    for b in branches_lst:
        e = b.split("_")[-1]
        if e == "NOSYS":
            branches_sys["nosys"].append(b)
        elif e == "1up":
            branches_sys["up"].append(b)
        elif e == "1down":
            branches_sys["down"].append(b)
        else:
            branches_sys["nominal"].append(b)

    branches_sys = {k: sorted(v) for k, v in branches_sys.items()}

    return branches_sys


def _get_variations(branches_sys: dict[str, list[str]]) -> tuple[dict[str, list[str]], list[str]]:
    base_variations: dict[str, list[str]] = {}

    nosys = branches_sys["nosys"]
    var_up = branches_sys["up"]
    no_var = branches_sys["nominal"]

    # sort bases by length (longest first) to match most specific base first
    sorted_nosys = sorted(nosys, key=lambda x: len(x), reverse=True)
    used_variations = set()

    for b in sorted_nosys:
        base = "_".join(b.split("_")[:-1])
        base_variations[base] = []
        for up in var_up:
            if up in used_variations:
                continue
            if up.startswith(base + "_"):
                match = re.match(rf"^{base}_(.*)__1up$", up)
                if match:
                    matched = match.group(1)

                    if matched.startswith("taus") or matched.startswith("taus_anti") or matched.startswith("anti"):
                        continue

                    if matched.startswith("phi") or matched.startswith("significance") or matched.startswith("sumet"):
                        continue

                    base_variations[base].append(matched)
                    used_variations.add(up)

    base_variations = {k: sorted(v) for k, v in base_variations.items()}

    return base_variations, sorted(no_var)


def get_variations_json(representative_file: str, key: str, save_dir: str | None = None) -> dict[str, Any]:
    branches_lst = _get_root_branches(representative_file, key)
    branches_obj = _parse_objects(branches_lst, key, save_dir)

    vars_objects: dict[str, dict[str, list[str]]] = {}
    no_var_objects: dict[str, list[str]] = {}

    for k in branches_obj.keys():
        branches_sys = _parse_sys_objects(branches_obj[k])

        variations, no_variations = _get_variations(branches_sys)

        if len(variations) != 0:
            vars_objects[k] = variations

        if len(no_variations) != 0:
            no_var_objects[k] = no_variations

        logging.debug(f"{k}: {len(variations)} variations and {len(no_variations)} no variations")

    dump_dct = {"variations": vars_objects, "no_variations": no_var_objects}

    if save_dir is not None:
        save_file = os.path.join(save_dir, f"variations_{key}.json")

        logging.debug(f"Saving variations map to {save_file}")
        with open(save_file, "w") as f:
            json.dump(dump_dct, f, indent=4)

    return dump_dct


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Parse systematics variations from ROOT ntuple branches and make a JSON map."
    )
    parser.add_argument(
        "-f",
        "--representative_file",
        type=str,
        required=True,
        help="Path to a representative ROOT file.",
    )
    parser.add_argument(
        "-k",
        "--key",
        type=str,
        default="physics",
        help="Key inside the ROOT file to read branches from.",
    )
    parser.add_argument(
        "-s",
        "--save_dir",
        type=str,
        default=".",
        help="Directory to save the output JSON file.",
    )
    args = parser.parse_args()

    get_variations_json(args.representative_file, args.key, args.save_dir)


if __name__ == "__main__":
    setup_logger()

    main()
