from __future__ import annotations

from typing import TYPE_CHECKING, Any

import networkx as nx

if TYPE_CHECKING:
    from f9columnar.processors import Processor

_FILL_PALETTE = [
    "#EEF2F7",  # neutral gray-blue
    "#DDEEF9",  # soft blue
    "#FBE5DC",  # soft peach
    "#DBF0DB",  # soft sage
    "#EDE3F5",  # soft lavender
    "#FCEFCF",  # soft amber
    "#D9EEF0",  # soft sky
    "#F5E6EB",  # soft rose
    "#F0E6D6",  # soft tan
    "#D6ECE6",  # soft mint
    "#E6E6F5",  # soft periwinkle
    "#F5ECD6",  # soft cream
    "#DCE8E8",  # soft seafoam
    "#F2E0F0",  # soft mauve
    "#E0ECD6",  # soft lime
    "#F5DDE6",  # soft pink
    "#E8E0D0",  # soft khaki
    "#D0E8E0",  # soft jade
    "#E0D8F0",  # soft iris
    "#F0E8D0",  # soft wheat
    "#D8E0E8",  # soft steel
    "#F0D8E0",  # soft blush
    "#D8F0D8",  # soft fern
    "#E8D8E8",  # soft plum
    "#F0F0D8",  # soft lemon
    "#D8E8F0",  # soft ice
    "#E8D0D8",  # soft coral
    "#D0F0E8",  # soft aqua
    "#E8E8D0",  # soft sand
    "#D0D8F0",  # soft cornflower
    "#F0D8D0",  # soft salmon
    "#D0F0D8",  # soft pistachio
]

_BORDER_PALETTE = [
    "#8A9BB5",  # muted slate
    "#6A9FCA",  # muted blue
    "#C48E76",  # muted terracotta
    "#72AB72",  # muted sage
    "#9A80B8",  # muted lavender
    "#C4A84E",  # muted amber
    "#6AABB2",  # muted teal
    "#B87A8E",  # muted rose
    "#B09870",  # muted tan
    "#5EA08A",  # muted mint
    "#7878B0",  # muted periwinkle
    "#B8A050",  # muted cream
    "#6A9898",  # muted seafoam
    "#A868A0",  # muted mauve
    "#7EA060",  # muted lime
    "#C06888",  # muted pink
    "#9A8A6A",  # muted khaki
    "#5A9A7A",  # muted jade
    "#7A68A8",  # muted iris
    "#B0A058",  # muted wheat
    "#6A7A98",  # muted steel
    "#B06A7A",  # muted blush
    "#58A058",  # muted fern
    "#8A5888",  # muted plum
    "#A0A058",  # muted lemon
    "#5878A8",  # muted ice
    "#A85868",  # muted coral
    "#48A898",  # muted aqua
    "#98985A",  # muted sand
    "#5A68B0",  # muted cornflower
    "#C07058",  # muted salmon
    "#58A868",  # muted pistachio
]


def draw_graph(
    graph: nx.DiGraph,
    processors: dict[str, Processor],
    file_path: str,
    fontsize: float = 10.0,
    jupyter: bool = False,
    **kwargs: Any,
) -> str:
    P = nx.nx_pydot.to_pydot(graph)

    graph_attrs: dict[str, Any] = {
        "fontsize": fontsize,
        "rankdir": "TB",
        "ranksep": "0.6",
        "nodesep": "0.4",
        "bgcolor": "white",
    }
    graph_attrs.update(kwargs)
    for k, v in graph_attrs.items():
        P.set(k, v)

    node_defaults = {
        "shape": "box",
        "style": '"rounded,filled"',
        "fillcolor": "#E8F4FD",
        "color": "#4A90D9",
        "fontname": "Helvetica",
        "fontsize": str(fontsize),
        "margin": '"0.15,0.08"',
        "penwidth": "1.5",
    }

    edge_defaults = {
        "color": "#666666",
        "arrowsize": "0.8",
        "penwidth": "1.2",
    }

    # auto-color nodes by subgraph identifier
    identifiers: set[str] = set()
    for name in graph.nodes:
        proc = processors.get(name)
        if proc:
            identifiers.add(proc._graph_identifier)

    non_empty = sorted(ident for ident in identifiers if ident)
    fill_map: dict[str, str] = {"": _FILL_PALETTE[0]}
    border_map: dict[str, str] = {"": _BORDER_PALETTE[0]}
    for i, ident in enumerate(non_empty):
        fill_map[ident] = _FILL_PALETTE[(i + 1) % len(_FILL_PALETTE)]
        border_map[ident] = _BORDER_PALETTE[(i + 1) % len(_BORDER_PALETTE)]

    auto_color = len(non_empty) > 0

    # apply defaults + per-node coloring directly on each node
    node_map = {n.get_name(): n for n in P.get_node_list()}
    for node_name_raw, nx_attrs in graph.nodes(data=True):
        node = node_map.get(node_name_raw) or node_map.get(f'"{node_name_raw}"')
        if node is None:
            continue

        for k, v in node_defaults.items():
            node.set(k, v)

        if auto_color:
            proc = processors.get(node_name_raw)
            if proc:
                ident = proc._graph_identifier
                node.set("fillcolor", fill_map.get(ident, _FILL_PALETTE[0]))
                node.set("color", border_map.get(ident, _BORDER_PALETTE[0]))

        # explicit style_graph overrides take priority
        if "fillcolor" in nx_attrs:
            node.set("fillcolor", nx_attrs["fillcolor"])
        if "style" in nx_attrs:
            node.set("style", f'"rounded,{nx_attrs["style"]}"')

    # apply defaults on each edge
    for edge in P.get_edge_list():
        for k, v in edge_defaults.items():
            edge.set(k, v)

    fmt = file_path.rsplit(".", 1)[-1] if "." in file_path else "pdf"
    raw = P.create(format=fmt, prog="dot")

    with open(file_path, "wb") as f:
        f.write(raw)

    if jupyter:
        from IPython.display import SVG, display  # type: ignore[reportMissingImports]

        display(SVG(file_path))

    return P.to_string()
