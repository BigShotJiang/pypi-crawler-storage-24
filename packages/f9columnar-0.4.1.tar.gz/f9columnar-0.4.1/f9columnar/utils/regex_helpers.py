import re
from dataclasses import dataclass
from pathlib import Path

from f9columnar.analysis.utils import get_year_from_campaign

_DATASET_PATTERN = re.compile(r"f9col_(?:(?P<dataset>.+?)_)?(?P<campaign>MC\d{2}[a-z]|Data_\d{2})_.+?_\d+_.*")


def extract_dsid_from_file(file_name: str) -> int | None:
    match = re.search(r"user\.[^.]+\.(\d{6})(?!\d)", file_name)

    if match:
        dsid = int(match.group(1))
    else:
        dsid = None

    return dsid


def extract_campaign_from_file(file_name: str) -> str | None:
    match = re.search(r"MC\d{2}[a-zA-Z]", file_name)

    if match:
        campaign = match.group(0)
    else:
        campaign = None

    return campaign


def extract_year_from_file(file_name: str) -> int | None:
    match = re.search(r"Data_\d{2}", file_name)

    if match:
        year = int(match.group(0)[-2:])
    else:
        year = None

    return year


def extract_user_from_file(file_name: str) -> str | None:
    match = re.search(r"user\.([^.]+)\.", file_name)

    if match:
        user = match.group(1)
    else:
        user = None

    return user


def extract_process_name(name: str, job_name: str) -> str:
    match = re.search(rf"f9col_(.*?)_{re.escape(job_name)}", name)
    if match:
        return match.group(1)

    return "unknown"


@dataclass(frozen=True)
class ParsedJobDatasetInfo:
    dataset: str
    is_data: bool
    year: int
    campaign: str | None

    @property
    def name(self) -> str:
        return f"{self.dataset}_{self.campaign}" if self.campaign else self.dataset


def extract_dataset_from_job(file_name: str) -> ParsedJobDatasetInfo | None:
    match = _DATASET_PATTERN.search(Path(file_name).name)

    if match:
        dataset = match.group("dataset")
        campaign = match.group("campaign")

        if campaign is None:
            return None

        is_data = "data" in campaign.lower()
        year = extract_year_from_file(campaign)
        campaign_name = extract_campaign_from_file(campaign)

        if year is None:
            if campaign_name is None:
                raise RuntimeError(f"Could not extract campaign or year from file name: {file_name}.")

            year = get_year_from_campaign(campaign_name)

        if dataset is None:
            dataset = f"Data_{year}"

        return ParsedJobDatasetInfo(dataset=dataset, is_data=is_data, year=year, campaign=campaign_name)

    return None
