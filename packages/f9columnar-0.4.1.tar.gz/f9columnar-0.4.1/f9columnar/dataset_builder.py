from __future__ import annotations

import glob
import logging
import os
from abc import ABC, abstractmethod
from typing import Any

import numpy as np
import pandas as pd
from torch.utils.data import DataLoader

from f9columnar.analysis.config import SamplesConfig, XsecConfig, apply_sample_config_selection
from f9columnar.analysis.rucio import RucioDB, make_rucio_url
from f9columnar.analysis.utils import get_luminosity, get_year_from_campaign
from f9columnar.hdf5_dataloader import get_hdf5_dataloader
from f9columnar.processors import ProcessorsGraph
from f9columnar.root_dataloader import get_root_dataloader
from f9columnar.utils.helpers import dump_pickle, load_pickle, split_by_chunk


class PhysicsDataset(ABC):
    def __init__(self, name: str, is_data: bool) -> None:
        self.name = name
        self.is_data = is_data

        self.file_desc_dct: dict[str, Any] | None = None
        self.dataloader_config: dict[str, Any]
        self.dataloader: DataLoader
        self.num_entries: int

    @abstractmethod
    def _setup_file_desc_dct(self) -> dict[str, Any]:
        exclude_attrs = {"dataloader", "num_entries", "file_desc_dct"}

        return {k: v for k, v in self.__dict__.items() if k not in exclude_attrs}

    @abstractmethod
    def setup_dataloader(self, **kwargs: Any):
        pass

    @abstractmethod
    def init_dataloader(self, processors: ProcessorsGraph | None = None):
        pass


class RootPhysicsDataset(PhysicsDataset):
    def __init__(
        self,
        name: str,
        root_files: list[str] | str,
        is_data: bool,
        extra_desc_dct: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(name, is_data=is_data)

        self.extra_desc_dct = {} if extra_desc_dct is None else extra_desc_dct

        if type(root_files) is list:
            self.root_files = root_files
        elif type(root_files) is str:
            self.root_files = [root_files]
        else:
            raise TypeError("root_files should be a list of strings or a string!")

    def __add__(self, other: str | list[str] | RootPhysicsDataset) -> RootPhysicsDataset:
        if type(other) is str:
            other = [other]
        elif type(other) is RootPhysicsDataset:
            other = other.root_files
        elif type(other) is list:
            pass
        else:
            raise TypeError("Other should be a RootPhysicsDataset, file name or a list of file names!")

        self.root_files += other

        return self

    def _setup_file_desc_dct(self) -> dict[str, Any]:
        exclude_attrs = {"root_files", "dataloader", "num_entries", "file_desc_dct", "extra_desc_dct"}
        base_dct = {k: v for k, v in self.__dict__.items() if k not in exclude_attrs}
        base_dct.update(self.extra_desc_dct)
        return {os.path.basename(root_file): base_dct.copy() for root_file in self.root_files}

    def setup_dataloader(self, **kwargs: Any) -> RootPhysicsDataset:
        if "processors" in kwargs:
            raise ValueError("Processors should not be passed in setup_dataloader!")

        self.dataloader_config = kwargs

        if self.file_desc_dct is None:
            self.file_desc_dct = self._setup_file_desc_dct()
        else:
            if set(self.root_files) != set(self.file_desc_dct.keys()):
                raise ValueError("Root files and file_desc_dct keys do not match!")

        return self

    def init_dataloader(self, processors: ProcessorsGraph | None = None) -> RootPhysicsDataset:
        self.dataloader, self.num_entries, _ = get_root_dataloader(
            self.name,
            self.root_files,
            key=self.dataloader_config.pop("key"),
            step_size=self.dataloader_config.pop("step_size"),
            num_workers=self.dataloader_config.pop("num_workers", 1),
            processors=processors,
            filter_name=self.dataloader_config.pop("filter_name", None),
            root_files_desc_dct=self.file_desc_dct,
            dataloader_kwargs=self.dataloader_config,
        )

        return self


class Hdf5PhysicsDataset(PhysicsDataset):
    def __init__(
        self,
        name: str,
        hdf5_files: str | list[str],
        is_data: bool,
        dataset_names: str | list[str] | None,
    ) -> None:
        super().__init__(name, is_data=is_data)
        self.hdf5_files = hdf5_files

        self.dataset_names: str | list[str]

        if dataset_names is None:
            self.dataset_names = "data" if is_data else "mc"
        else:
            self.dataset_names = dataset_names

    def _setup_file_desc_dct(self) -> dict[str, Any]:
        exclude_attrs = {"hdf5_files", "dataloader", "num_entries", "file_desc_dct"}
        base_dct = {k: v for k, v in self.__dict__.items() if k not in exclude_attrs}
        return {os.path.basename(hdf5_file): base_dct.copy() for hdf5_file in self.hdf5_files}

    def setup_dataloader(self, **kwargs: Any) -> Hdf5PhysicsDataset:
        if "processors" in kwargs:
            raise ValueError("Processors should not be passed in setup_dataloader!")

        if "dataset_names" in kwargs:
            raise ValueError("Dataset names should not be passed in setup_dataloader!")

        self.dataloader_config = kwargs

        self.file_desc_dct = self._setup_file_desc_dct()

        return self

    def init_dataloader(self, processors: ProcessorsGraph | None = None) -> Hdf5PhysicsDataset:
        self.dataloader, self.num_entries = get_hdf5_dataloader(
            self.name,
            files=self.hdf5_files,
            dataset_names=self.dataset_names,
            processors=processors,
            hdf5_files_desc_dct=self.file_desc_dct,
            **self.dataloader_config,
        )
        return self


class NtuplePhysicsDataset(PhysicsDataset):
    def __init__(self, name: str, is_data: bool, dataset_selection: pd.DataFrame, use_weights: bool = False) -> None:
        super().__init__(name, is_data=is_data)
        self.dataset_selection = dataset_selection

        self.use_weights = use_weights
        self.sample_weights: dict[str, float] | None = None

    def _to_base_root_file(self, root_file: str) -> str:
        return os.path.basename(root_file).replace(".tree.root", "").replace(".tree_metadata.root", "")

    def _setup_file_desc_dct(self) -> dict[str, Any]:
        exclude_attrs = {
            "dataloader",
            "dataloader_config",
            "sample_weights",
            "num_entries",
            "file_desc_dct",
            "dataset_selection",
        }
        base_dct = {k: v for k, v in self.__dict__.items() if k not in exclude_attrs}
        root_files = self.dataset_selection["root_file"]

        file_desc_dct = {}
        for root_file in root_files:
            base_root_file = self._to_base_root_file(root_file)
            file_info_row = self.dataset_selection[self.dataset_selection["full_file_name"] == base_root_file]

            if len(file_info_row) == 0:
                raise ValueError(f"No matching entry in dataset selection for file {base_root_file}!")

            year = file_info_row["year"].values[0]
            if pd.isna(year):
                year = None

            dsid = file_info_row["dsid"].values[0]
            if pd.isna(dsid):
                dsid = None
            else:
                dsid = int(dsid)

            campaign = file_info_row["campaign"].values[0]
            if pd.isna(campaign):
                campaign = None

            user = file_info_row["user"].values[0]
            if pd.isna(user):
                user = None

            if year is None:
                year = get_year_from_campaign(campaign)

            if year in {15, 16, 1516, 17, 18}:
                run_name = 2
            elif year in {22, 23, 24}:
                run_name = 3
            else:
                raise RuntimeError(f"Unrecognized year '{year}'!")

            extra_info = {
                "year": year,
                "dsid": dsid,
                "run_name": run_name,
                "campaign": campaign,
                "user": user,
                "is_ntuples": True,
            }

            if self.sample_weights is not None:
                extra_info["sample_weight"] = self.sample_weights[base_root_file]

            file_desc_dct[base_root_file] = base_dct.copy() | extra_info

        return file_desc_dct

    def setup_dataloader(self, **kwargs: Any) -> NtuplePhysicsDataset:
        if "processors" in kwargs:
            raise ValueError("Processors should not be passed in setup_dataloader!")

        self.dataloader_config = kwargs

        if self.file_desc_dct is None:
            self.file_desc_dct = self._setup_file_desc_dct()

        return self

    def set_root_files_path(self, base_file_path: str) -> None:
        root_files = self.dataset_selection["root_file"].tolist()
        new_root_files = [os.path.join(base_file_path, os.path.basename(f)) for f in root_files]
        self.dataset_selection["root_file"] = new_root_files

    def init_dataloader(self, processors: ProcessorsGraph | None = None) -> NtuplePhysicsDataset:
        root_files = self.dataset_selection["root_file"].tolist()

        column_values = self.dataset_selection.columns.values.tolist()
        if "start" in column_values and "stop" in column_values:
            root_file_ranges = {
                row["root_file"]: (row["start"], row["stop"]) for _, row in self.dataset_selection.iterrows()
            }
        else:
            root_file_ranges = None

        self.dataloader, self.num_entries, _ = get_root_dataloader(
            self.name,
            root_files,
            key=self.dataloader_config.pop("key"),
            step_size=self.dataloader_config.pop("step_size"),
            num_workers=self.dataloader_config.pop("num_workers", 1),
            processors=processors,
            filter_name=self.dataloader_config.pop("filter_name", None),
            root_files_desc_dct=self.file_desc_dct,
            file_entry_ranges=root_file_ranges,
            dataloader_kwargs=self.dataloader_config,
        )

        return self


class NtupleMCDataset(NtuplePhysicsDataset):
    def __init__(self, name: str, dataset_selection: pd.DataFrame, use_weights: bool = False) -> None:
        super().__init__(name=name, dataset_selection=dataset_selection, is_data=False, use_weights=use_weights)
        if self.use_weights:
            self.sample_weights = self._setup_weights()

    def _setup_weights(self) -> dict[str, float]:
        root_files = self.dataset_selection["root_file"]
        campaigns = self.dataset_selection["campaign"]

        eff_xsecs = self.dataset_selection["eff_xsec"]
        sows = self.dataset_selection["initial_sow"]

        sample_weights: dict[str, float] = {}
        for root_file, campaign, eff_xsec, sow in zip(root_files, campaigns, eff_xsecs, sows):
            base_root_file = self._to_base_root_file(root_file)

            luminosity = get_luminosity(campaign)
            sample_weights[base_root_file] = luminosity * eff_xsec / sow

        return sample_weights

    def __str__(self) -> str:
        return f"NtupleMCDataset(name={self.name})"


class NtupleDataDataset(NtuplePhysicsDataset):
    def __init__(self, name: str, dataset_selection: pd.DataFrame) -> None:
        super().__init__(name=name, dataset_selection=dataset_selection, is_data=True)

    def __str__(self) -> str:
        return f"NtupleDataDataset(name={self.name})"


class NtupleMergedPhysicsDataset:
    def __init__(self, name: str, datasets: list[NtupleDataDataset] | list[NtupleMCDataset], is_data: bool) -> None:
        self.name = name
        self.datasets = datasets
        self.is_data = is_data

        self.dataset_selection: list[pd.DataFrame] = []
        self.file_desc_dct: dict[str, Any] = {}

        self.dataloader_config: dict[str, Any]
        self.dataloader: DataLoader
        self.num_entries: int

    def merge(self) -> NtupleMergedPhysicsDataset:
        dataloader_configs = []

        for dataset in self.datasets:
            dataloader_configs.append(dataset.dataloader_config)
            self.dataset_selection.append(dataset.dataset_selection)

            self.file_desc_dct.update(dataset.file_desc_dct)  # type: ignore[arg-type]

        logging.info(f"[green]Merged {len(self.datasets)} datasets into {self.name} dataset![/green]")

        self.dataloader_config = dataloader_configs[0]
        logging.info("Using first dataloader config.")

        return self

    def setup_dataloader(self, **kwargs: Any) -> NtupleMergedPhysicsDataset:
        logging.warning("setup_dataloader should already be called on datasets!")
        return self

    def init_dataloader(self, processors: ProcessorsGraph | None = None) -> NtupleMergedPhysicsDataset:
        dataset_selection = pd.concat(self.dataset_selection)
        root_files = dataset_selection["root_file"].tolist()

        self.dataloader, self.num_entries, _ = get_root_dataloader(
            self.name,
            root_files,
            key=self.dataloader_config.pop("key"),
            step_size=self.dataloader_config.pop("step_size"),
            num_workers=self.dataloader_config.pop("num_workers", 1),
            processors=processors,
            filter_name=self.dataloader_config.pop("filter_name", None),
            root_files_desc_dct=self.file_desc_dct,
            dataloader_kwargs=self.dataloader_config,
        )

        return self


class DatasetBuilder(ABC):
    def __init__(self, data_path: str | None = None, metadata_path: str | None = None) -> None:
        self.data_path = data_path
        self.metadata_path = metadata_path if metadata_path is not None else data_path

    @abstractmethod
    def build_mc_datasets(self):
        """Build MC datasets. Returns a list of MCDataset instances."""
        pass

    @abstractmethod
    def build_data_datasets(self):
        """Build data datasets. Returns a list of DataDataset instances."""
        pass

    @abstractmethod
    def setup_dataloaders(self, dataloader_config: dict[str, Any] | None = None):
        """Setup dataloaders for MC and data datasets."""
        pass

    @abstractmethod
    def init_dataloaders(self, processors: ProcessorsGraph | None = None):
        """Initialize dataloaders for MC and data datasets."""
        pass

    @abstractmethod
    def build(self, dataloader_config: dict[str, Any] | None = None):
        """Build datasets, setup dataloaders and initialize dataloaders."""
        pass

    @abstractmethod
    def init(self, processors: ProcessorsGraph | None = None) -> tuple[list[NtupleMCDataset], list[NtupleDataDataset]]:
        """Initialize dataloaders."""
        pass


class NtupleDatasetBuilder(DatasetBuilder):
    def __init__(
        self,
        samples_config: SamplesConfig | None = None,
        xsec_config: XsecConfig | None = None,
        data_path: str | None = None,
        metadata_path: str | None = None,
        ntuple_location: str | None = None,
        max_root_files: int | None = None,
        events_per_job: int | None = None,
        df_id: str = "hists",
        pickle_path: str | None = None,
    ) -> None:
        super().__init__(data_path, metadata_path)

        if max_root_files is not None and events_per_job is not None:
            raise ValueError("Only one of max_root_files and events_per_job can be set!")

        self.ntuple_location = ntuple_location
        self.max_root_files = max_root_files
        self.events_per_job = events_per_job
        self.df_id = df_id
        self.pickle_path = pickle_path

        build_mode = False
        if samples_config is not None and xsec_config is not None:
            build_mode = True

        if build_mode:
            logging.info("DatasetBuilder initialized in build mode.")

            if self.max_root_files is not None:
                logging.info(f"Max root files per dataset set to {self.max_root_files}.")

            if self.events_per_job is not None:
                logging.info(f"Events per job set to {self.events_per_job}.")

            if samples_config is None:
                raise ValueError("samples_config should be provided in build mode!")

            if xsec_config is None:
                raise ValueError("xsec_config should be provided in build mode!")

            self._build_obj(samples_config, xsec_config)
        else:
            logging.info("DatasetBuilder initialized in load mode.")

    def _build_obj(self, samples_config: SamplesConfig, xsec_config: XsecConfig) -> None:
        if self.ntuple_location is None:
            env_ntuple_location = os.environ.get("COLUMNAR_NTUPLE_LOCATION", None)

            if env_ntuple_location is None:
                raise ValueError("COLUMNAR_NTUPLE_LOCATION environment variable not set!")

            self.ntuple_location = env_ntuple_location

        rucio_df = RucioDB(self.data_path, self.metadata_path).to_dataframe(self.df_id)
        self.rucio_df = apply_sample_config_selection(samples_config, rucio_df)

        self.xsec_config = xsec_config

        self.mc_datasets: list[NtupleMCDataset] | list[NtupleMergedPhysicsDataset] = []
        self.data_datasets: list[NtupleDataDataset] | list[NtupleMergedPhysicsDataset] = []

        self._merged: bool = False

        if self.pickle_path is not None:
            logging.info("Saving DatasetBuilder object to pickle file.")
            pickle_dct = {
                "rucio_df": self.rucio_df,
                "xsec_config": self.xsec_config.to_dict(),
                "ntuple_location": self.ntuple_location,
                "max_root_files": self.max_root_files,
                "df_id": self.df_id,
            }
            dump_pickle(self.pickle_path, pickle_dct)

    def load(self, pickle_path: str, data_path: str | None = None) -> NtupleDatasetBuilder:
        pickle_dct = load_pickle(pickle_path)

        self.rucio_df = pickle_dct["rucio_df"]
        self.xsec_config = XsecConfig().from_dict(pickle_dct["xsec_config"])
        self.ntuple_location = pickle_dct["ntuple_location"]
        self.max_root_files = pickle_dct["max_root_files"]
        self.df_id = pickle_dct["df_id"]
        self.data_path = data_path
        self.metadata_path = pickle_dct["metadata_path"]

        return self

    def _make_root_files(
        self,
        files: list[str],
        users: list[str] | None = None,
        return_base_files: bool = False,
    ) -> tuple[list[str], list[str]] | list[str]:
        root_base_files = [f"{f}.tree.root" for f in files]

        if self.ntuple_location == "rucio":
            if users is None:
                raise ValueError("Users should be provided if rucio location!")

            root_files = []
            for user, root_file in zip(users, root_base_files):
                root_files.append(make_rucio_url(user, root_file))
        else:
            if self.ntuple_location is None:
                raise ValueError("ntuple_location should be set!")

            root_files = [os.path.join(self.ntuple_location, root_file) for root_file in root_base_files]

        if return_base_files:
            return root_files, root_base_files
        else:
            return root_files

    def _split_for_max_root_files(self, df: pd.DataFrame) -> list[pd.DataFrame]:
        if self.max_root_files is None:
            raise ValueError("max_root_files should be set!")

        split_df = []

        for i in range(len(df) // self.max_root_files + 1):
            split = df[i * self.max_root_files : (i + 1) * self.max_root_files]
            if len(split) != 0:
                split_df.append(split)

        return split_df

    def _split_events_per_job(self, df: pd.DataFrame) -> list[pd.DataFrame]:
        if self.events_per_job is None:
            raise ValueError("events_per_job is not set!")

        total_events = int(df["n_events"].sum())
        parts = split_by_chunk(total_events, self.events_per_job)
        parts_ranges = list(zip([0] + np.cumsum(parts[:-1]).tolist(), np.cumsum(parts).tolist()))

        result_dfs = []
        current_part_idx = 0
        current_part_start, current_part_end = parts_ranges[current_part_idx]
        current_df_rows = []
        cumulative_events = 0

        for _, row in df.iterrows():
            row_events = int(row["n_events"])
            row_start = cumulative_events
            row_end = cumulative_events + row_events

            # check if this row spans multiple parts
            while row_end > current_part_end and current_part_idx < len(parts_ranges):
                # calculate how many events fit in current part
                events_in_current_part = current_part_end - max(row_start, current_part_start)

                if events_in_current_part > 0:
                    # add portion of this row to current part with start/stop
                    row_copy = row.copy()
                    row_copy["start"] = max(0, current_part_start - row_start)
                    row_copy["stop"] = row_copy["start"] + events_in_current_part
                    current_df_rows.append(row_copy)

                # save current part
                if current_df_rows:
                    result_dfs.append(pd.DataFrame(current_df_rows))
                    current_df_rows = []

                # move to next part
                current_part_idx += 1
                if current_part_idx < len(parts_ranges):
                    current_part_start, current_part_end = parts_ranges[current_part_idx]
                else:
                    break

            # add row to current part if it fits or partially fits
            if current_part_idx < len(parts_ranges):
                if row_end <= current_part_end:
                    # entire row fits in current part
                    row_copy = row.copy()
                    row_copy["start"] = max(0, current_part_start - row_start)
                    row_copy["stop"] = row_events
                    current_df_rows.append(row_copy)
                else:
                    # remaining portion of row
                    row_copy = row.copy()
                    row_copy["start"] = max(0, current_part_start - row_start)
                    row_copy["stop"] = row_copy["start"] + (current_part_end - max(row_start, current_part_start))
                    current_df_rows.append(row_copy)

            cumulative_events += row_events

        # add remaining rows
        if current_df_rows:
            result_dfs.append(pd.DataFrame(current_df_rows))

        return result_dfs if result_dfs else [df]

    def build_mc_datasets(self) -> list[NtupleMCDataset]:
        logging.info("[green]Building MC datasets![/green]")

        mc_df = self.rucio_df[self.rucio_df["is_data"] == False]

        dataset_names = mc_df["dataset_name"].unique()

        filter_local = False
        if self.ntuple_location != "rucio":
            filter_local = True
            local_files = glob.glob(f"{self.ntuple_location}/*.tree.root")
            present_base_files = {os.path.basename(f).replace(".tree.root", "") for f in local_files}

        mc_datasets = []
        for dataset_name in dataset_names:
            dataset_selection = mc_df[mc_df["dataset_name"] == dataset_name].copy()

            if filter_local:
                dataset_selection = dataset_selection[
                    dataset_selection["full_file_name"].apply(lambda x: x in present_base_files)
                ]
                logging.info(f"{len(dataset_selection)} files found for dataset {dataset_name}.")

            full_file_names = dataset_selection["full_file_name"]
            users = dataset_selection["user"]

            dataset_selection["root_file"] = self._make_root_files(full_file_names, users)

            dsids = dataset_selection["dsid"].astype(int).tolist()
            campaigns = dataset_selection["campaign"].astype(str).tolist()

            eff_xsecs = []
            for dsid, campaign in zip(dsids, campaigns):
                run_period = "Run3" if "mc23" in campaign.lower() else "Run2"

                eff_xsec = self.xsec_config.get(run_period, dsid)
                eff_xsecs.append(eff_xsec)

            dataset_selection["eff_xsec"] = eff_xsecs

            if self.max_root_files is not None:
                dataset_selection = self._split_for_max_root_files(dataset_selection)
            elif self.events_per_job is not None:
                dataset_selection = self._split_events_per_job(dataset_selection)
            else:
                dataset_selection = [dataset_selection]

            for df in dataset_selection:
                mc_datasets.append(NtupleMCDataset(dataset_name, df, use_weights=True))

        return mc_datasets

    def build_data_datasets(self) -> list[NtupleDataDataset]:
        logging.info("[green]Building data datasets![/green]")

        data_df = self.rucio_df[self.rucio_df["is_data"] == True]

        filter_local = False
        if self.ntuple_location != "rucio":
            filter_local = True
            local_files = glob.glob(f"{self.ntuple_location}/*.tree.root")
            present_base_files = {os.path.basename(f).replace(".tree.root", "") for f in local_files}

        dataset_names = data_df["dataset_name"].unique()

        data_datasets = []
        for dataset_name in dataset_names:
            dataset_selection = data_df[data_df["dataset_name"] == dataset_name].copy()

            if filter_local:
                dataset_selection = dataset_selection[
                    dataset_selection["full_file_name"].apply(lambda x: x in present_base_files)
                ]
                logging.info(f"{len(dataset_selection)} files found for dataset {dataset_name}.")

            full_file_names = dataset_selection["full_file_name"]
            users = dataset_selection["user"]

            dataset_selection["root_file"] = self._make_root_files(full_file_names, users)

            if self.max_root_files is not None:
                dataset_selection = self._split_for_max_root_files(dataset_selection)
            elif self.events_per_job is not None:
                dataset_selection = self._split_events_per_job(dataset_selection)
            else:
                dataset_selection = [dataset_selection]

            for df in dataset_selection:
                data_datasets.append(NtupleDataDataset(dataset_name, df))

        return data_datasets

    def setup_dataloaders(self, dataloader_config: dict[str, Any] | None = None) -> NtupleDatasetBuilder:
        if dataloader_config is None:
            dataloader_config = {}

        logging.info("[green]Setting up MC dataloaders![/green]")
        for mc in self.mc_datasets:
            mc.setup_dataloader(**dataloader_config)

        logging.info("[green]Setting up data dataloaders![/green]")
        for data in self.data_datasets:
            data.setup_dataloader(**dataloader_config)

        return self

    def init_dataloaders(self, processors: ProcessorsGraph | None = None) -> NtupleDatasetBuilder:
        logging.info("[green]Initializing MC dataloaders![/green]")
        for mc in self.mc_datasets:
            mc.init_dataloader(processors=processors)

        logging.info("[green]Initializing data dataloaders![/green]")
        for data in self.data_datasets:
            data.init_dataloader(processors=processors)

        return self

    def _build(self, dataloader_config: dict[str, Any] | None = None, merge: bool = False) -> NtupleDatasetBuilder:
        self.mc_datasets = self.build_mc_datasets()
        self.data_datasets = self.build_data_datasets()

        self.setup_dataloaders(dataloader_config)

        if merge:
            self._merged = True

            if len(self.mc_datasets) != 0:
                self.mc_datasets = [NtupleMergedPhysicsDataset("MC", self.mc_datasets, is_data=False).merge()]
            else:
                logging.warning("No MC datasets to merge!")

            if len(self.data_datasets) != 0:
                self.data_datasets = [NtupleMergedPhysicsDataset("Data", self.data_datasets, is_data=True).merge()]
            else:
                logging.warning("No data datasets to merge!")

        return self

    def build_merged(self, dataloader_config: dict[str, Any] | None = None) -> NtupleDatasetBuilder:
        return self._build(dataloader_config=dataloader_config, merge=True)

    def build(self, dataloader_config: dict[str, Any] | None = None) -> NtupleDatasetBuilder:
        return self._build(dataloader_config=dataloader_config, merge=False)

    def init_merged(
        self, processors: ProcessorsGraph | None = None
    ) -> tuple[list[NtupleMergedPhysicsDataset], list[NtupleMergedPhysicsDataset]]:
        if not self._merged:
            raise ValueError("Datasets are not merged! Call build_merged() before init_merged()!")

        self.init_dataloaders(processors=processors)

        if len(self.mc_datasets) > 0 and not isinstance(self.mc_datasets[0], NtupleMergedPhysicsDataset):
            raise TypeError("MC datasets are not merged!")

        if len(self.data_datasets) > 0 and not isinstance(self.data_datasets[0], NtupleMergedPhysicsDataset):
            raise TypeError("Data datasets are not merged!")

        return self.mc_datasets, self.data_datasets  # type: ignore[return-value]

    def init(self, processors: ProcessorsGraph | None = None) -> tuple[list[NtupleMCDataset], list[NtupleDataDataset]]:
        self.init_dataloaders(processors=processors)

        if len(self.mc_datasets) > 0 and not isinstance(self.mc_datasets[0], NtupleMCDataset):
            raise TypeError("MC datasets are not NtupleMCDataset!")

        if len(self.data_datasets) > 0 and not isinstance(self.data_datasets[0], NtupleDataDataset):
            raise TypeError("Data datasets are not NtupleDataDataset!")

        return self.mc_datasets, self.data_datasets  # type: ignore[return-value]
