import logging
import os
from pathlib import Path

import hist
import numpy as np
import uncertainties.unumpy as unp

from f9columnar.analysis.config.analysis_config import AnalysisConfig
from f9columnar.analysis.utils import get_campaign_from_year, get_year_from_campaign
from f9columnar.submit.act_merger import ActMerger
from f9columnar.utils.helpers import dump_pickle, load_pickle


def calculate_binned_fake_factors(hists_dct: dict[str, hist.Hist]) -> tuple[unp.uarray, dict[str, np.ndarray]]:
    data_tight_h, data_loose_h = hists_dct["data_tight"], hists_dct["data_loose"]
    mc_tight_h, mc_loose_h = hists_dct["mc_tight"], hists_dct["mc_loose"]

    data_tight_val, data_loose_val = data_tight_h.values(), data_loose_h.values()
    mc_tight_val, mc_loose_val = mc_tight_h.values(), mc_loose_h.values()

    data_tight_std, data_loose_std = np.sqrt(data_tight_h.variances()), np.sqrt(data_loose_h.variances())  # type: ignore[arg-type]
    mc_tight_std, mc_loose_std = np.sqrt(mc_tight_h.variances()), np.sqrt(mc_loose_h.variances())  # type: ignore[arg-type]

    data_tight_unp = unp.uarray(data_tight_val, data_tight_std)
    data_loose_unp = unp.uarray(data_loose_val, data_loose_std)

    mc_tight_unp = unp.uarray(mc_tight_val, mc_tight_std)
    mc_loose_unp = unp.uarray(mc_loose_val, mc_loose_std)

    num = data_tight_unp - mc_tight_unp
    denom = data_loose_unp - mc_loose_unp

    ff = np.zeros_like(num)
    mask = unp.nominal_values(denom) != 0.0
    ff[mask] = num[mask] / denom[mask]

    bins = {
        "pt": data_tight_h.axes["pt"].edges,
        "abs_eta": data_tight_h.axes["abs_eta"].edges,
        "met": data_tight_h.axes["met"].edges,
    }

    return ff, bins


class BinnedFakeFactorIndexer:
    def __init__(self, ff: unp.uarray, bins: dict[str, np.ndarray]):
        self.ff_nom = unp.nominal_values(ff).astype(np.float64)
        self.ff_std = unp.std_devs(ff).astype(np.float64)
        self.bins = bins

    def get_bin_indices(
        self, pt: np.ndarray, abs_eta: np.ndarray, met: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        pt_idx = np.clip(np.digitize(pt, self.bins["pt"]) - 1, 0, len(self.bins["pt"]) - 2)
        abs_eta_idx = np.clip(np.digitize(abs_eta, self.bins["abs_eta"]) - 1, 0, len(self.bins["abs_eta"]) - 2)
        met_idx = np.clip(np.digitize(met, self.bins["met"]) - 1, 0, len(self.bins["met"]) - 2)
        return pt_idx, abs_eta_idx, met_idx

    def get(self, pt: np.ndarray, abs_eta: np.ndarray, met: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        pt_idx, abs_eta_idx, met_idx = self.get_bin_indices(pt, abs_eta, met)
        return self.ff_nom[pt_idx, abs_eta_idx, met_idx], self.ff_std[pt_idx, abs_eta_idx, met_idx]


class FakesHistExtractor:
    # year -> {e/mu -> {var -> Hist}}
    LooseByYear = dict[str, dict[str, dict[str, hist.Hist]]]

    def __init__(self, analysis_config: AnalysisConfig) -> None:
        """Extract fakes histograms from merged closure histograms.

        Computes the data-driven fakes estimate per year/campaign as
        `fakes = data_loose + mc_loose`, where MC loose already carries
        negative weights (applied during histogram filling).

        Reads merged closure histograms, splits them by data/MC and year,
        builds the fakes estimate, and saves the result as a pickle file
        in the format `{fakes_{campaign}: {emu_group: {nominal: {tight_emu_var: Hist}}}}`.

        Variables are inferred automatically from histogram keys matching
        the `loose_{emu}_*` pattern.

        Parameters
        ----------
        analysis_config : AnalysisConfig
            Analysis configuration containing results path and submit settings.

        Attributes
        ----------
        data_loose : dict
            Accumulated loose histograms from data, keyed by year -> el/mu -> variable.
        mc_loose : dict
            Accumulated loose histograms from MC, keyed by year -> el/mu -> variable.
        """
        self.analysis_config = analysis_config
        self.data_loose: FakesHistExtractor.LooseByYear = {}
        self.mc_loose: FakesHistExtractor.LooseByYear = {}
        self.group_keys: dict[str, str] = {}

    def _extract_loose_hists(
        self, hists_dct: dict[str, dict[str, dict[str, hist.Hist]]]
    ) -> dict[str, dict[str, hist.Hist]]:
        loose_hists: dict[str, dict[str, hist.Hist]] = {"el": {}, "mu": {}}

        for emu in {"el", "mu"}:
            hists_dct_keys = list(hists_dct.keys())
            for k in hists_dct_keys:
                if k.startswith(emu):
                    self.group_keys[emu] = k
                    break

            hists_ff_dct: dict[str, hist.Hist] = hists_dct[self.group_keys[emu]]["nominal"]
            prefix = f"loose_{emu}_"
            for key, h in hists_ff_dct.items():
                if key.startswith(prefix):
                    var = key[len(prefix) :]
                    loose_hists[emu][var] = h.copy()

        return loose_hists

    @staticmethod
    def _add_hists(
        target: dict[str, dict[str, hist.Hist]],
        source: dict[str, dict[str, hist.Hist]],
    ) -> None:
        for emu in {"el", "mu"}:
            for var, h in source[emu].items():
                if var not in target[emu]:
                    target[emu][var] = h.copy()
                else:
                    target[emu][var] += h

    def _split_by_year(self, merged_hists: dict[str, dict[str, dict[str, dict[str, hist.Hist]]]]) -> None:
        for process_name, hists_dct in merged_hists.items():
            is_data = process_name.startswith("Data")

            if is_data:
                data_year = int(process_name.split("_")[-1])
                campaign = get_campaign_from_year(data_year)
            else:
                campaign = process_name.split("_")[-1]

            year = str(get_year_from_campaign(campaign))

            loose = self._extract_loose_hists(hists_dct)

            if is_data:
                if year not in self.data_loose:
                    self.data_loose[year] = {"el": {}, "mu": {}}
                self._add_hists(self.data_loose[year], loose)
            else:
                if year not in self.mc_loose:
                    self.mc_loose[year] = {"el": {}, "mu": {}}
                self._add_hists(self.mc_loose[year], loose)

    @staticmethod
    def _rename_axis(h: hist.Hist, new_name: str) -> hist.Hist:
        old_ax = h.axes[0]

        new_ax: hist.axis.Regular | hist.axis.Variable
        if isinstance(old_ax, hist.axis.Regular):
            new_ax = hist.axis.Regular(
                old_ax.size,
                old_ax.edges[0],
                old_ax.edges[-1],
                underflow=old_ax.traits.underflow,
                overflow=old_ax.traits.overflow,
                name=new_name,
            )
        elif isinstance(old_ax, hist.axis.Variable):
            new_ax = hist.axis.Variable(
                old_ax.edges,
                underflow=old_ax.traits.underflow,
                overflow=old_ax.traits.overflow,
                name=new_name,
            )
        else:
            raise RuntimeError(f"Unsupported axis type: {type(old_ax)}")

        new_h = hist.Hist(new_ax, storage=hist.storage.Weight())
        new_h.view(flow=True)[...] = h.view(flow=True)[...]
        return new_h

    def _build_fakes(self) -> dict[str, dict[str, dict[str, dict[str, hist.Hist]]]]:
        fakes_merged_hists: dict[str, dict[str, dict[str, dict[str, hist.Hist]]]] = {}

        for year in self.data_loose:
            fakes_by_ff: dict[str, dict[str, dict[str, hist.Hist]]] = {}
            for emu in {"el", "mu"}:
                nominal: dict[str, hist.Hist] = {}
                for var, h in self.data_loose[year][emu].items():
                    key = f"tight_{emu}_{var}"
                    nominal[key] = h.copy()
                    if year in self.mc_loose and var in self.mc_loose[year][emu]:
                        nominal[key] += self.mc_loose[year][emu][var]
                    nominal[key] = self._rename_axis(nominal[key], key)
                fakes_by_ff[self.group_keys[emu]] = {"nominal": nominal}

            campaign = get_campaign_from_year(int(year))
            fakes_merged_hists[f"fakes_{campaign}"] = fakes_by_ff

        return fakes_merged_hists

    def run(self) -> None:
        logging.info("Extracting fakes histograms from merged closure hists.")

        merger = ActMerger(submit_dir=self.analysis_config.common.results_path, job_name="closure_hists")
        merger.merge()

        merged_dir = os.path.join(merger.merged_dir, "closure_hists_merged_hists.p")
        merged_hists = load_pickle(merged_dir)

        self._split_by_year(merged_hists)
        fakes_merged_hists = self._build_fakes()

        fakes_save_file = os.path.join(
            str(Path(self.analysis_config.common.results_path).parent), "fakes", "ff", "fakes_hists.p"
        )
        os.makedirs(os.path.dirname(fakes_save_file), exist_ok=True)

        dump_pickle(fakes_save_file, fakes_merged_hists)
        logging.info(f"Fakes histograms saved to {fakes_save_file}.")
