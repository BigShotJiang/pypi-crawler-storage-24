class TriggerLookup:
    def __init__(self) -> None:
        """Class for trigger name <-> integer ID mapping.

        This class provides a lookup table for converting between
        trigger names (strings) and integer IDs, with support for both
        numpy and awkward arrays.

        """
        self._build_trigger_mapping()

    def _build_trigger_mapping(self) -> None:
        trigger_names: list[str] = []

        muon_triggers = [
            "mu50",
            "mu50_L1MU14FCH",
            "mu40",
            "mu26_imedium",
            "mu26_imedium_OR_mu40",
            "mu26_imedium_OR_mu50",
            "mu26_ivarmedium",
            "mu26_ivarmedium_L1MU14FCH",
            "mu26_ivarmedium_OR_mu40",
            "mu26_ivarmedium_OR_mu50",
            "mu26_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH",
            "mu24_iloose_L1MU15",
            "mu24_iloose_L1MU15_OR_mu40",
            "mu24_iloose_L1MU15_OR_mu50",
            "mu24_iloose_L1MU15_OR_mu24_iloose",
            "mu24_iloose_L1MU15_OR_mu24_iloose_OR_mu40",
            "mu24_iloose_L1MU15_OR_mu24_iloose_OR_mu50",
            "mu24_imedium",
            "mu24_imedium_OR_mu40",
            "mu24_imedium_OR_mu50",
            "mu24_ivarmedium",
            "mu24_ivarmedium_L1MU14FCH",
            "mu24_ivarmedium_OR_mu40",
            "mu24_ivarmedium_OR_mu50",
            "mu24_ivarmedium_L1MU14FCH_OR_mu50_L1MU14FCH",
            "mu26",
            "mu26_L1MU14FCH",  # fakes
            "mu24",
            "mu24_L1MU14FCH",
            "mu22",
            "mu22_L1MU14FCH",
            "mu20_ivarmedium_L1MU14FCH",
            "mu20_iloose_L1MU15_OR_mu50",
            "mu20_iloose_L1MU15_OR_mu40",
            "mu20_iloose_L1MU15",
            "mu20",
            "mu20_L1MU14FCH",
            "mu18",
            "mu18noL1",
            "mu15",
            "mu15noL1",
            "mu14",
            "mu14_L1MU8F",
            "mu8noL1_L1MU14FCH",  # to be aliased
            "mu14_L1EM15VH_MU8F",  # to be aliased
            "mu14_L1eEM18L_MU8F",  # to be aliased
            "mu14_ivarloose",
            "mu14_ivarloose_L1MU8F",
            "mu10",
            "mu10_L1MU8F",
            "mu10_l2mt_L1MU10BOM",  # fakes
            "mu10_ivarmedium_L1MU8F",
            "mu8noL1",
            "mu8noL1_FSNOSEED",
            "mu6",
            "mu6_L1MU5VF",
            "mu4",
            "mu4_L1MU3V",
            "mu4noL1",
            "mu2noL1",
        ]

        electron_triggers = [
            "e300_etcut_L1eEM26M",
            "e140_lhloose_nod0",
            "e140_lhloose_L1EM22VHI",
            "e140_dnnloose_nogsf_L1EM22VHI",
            "e140_lhloose_L1eEM26M",
            "e120_lhloose",
            "e60_lhmedium",
            "e60_lhmedium_nod0",
            "e60_lhmedium_L1EM22VHI",
            "e60_dnnmedium_nogsf_L1EM22VHI",
            "e60_lhmedium_L1eEM26M",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M",
            "e26_lhtight_ivarloose_L1eEM26M_OR_e60_lhmedium_L1eEM26M_OR_e140_lhloose_L1eEM26M_OR_e300_etcut_L1eEM26M",
            "e26_dnntight_ivarloose_L1EM22VHI",
            "e26_dnntight_ivarloose_L1EM22VHI_OR_e60_dnnmedium_nogsf_L1EM22VHI_OR_e140_dnnloose_nogsf_L1EM22VHI",
            "e26_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "e26_lhtight_ivarloose_L1EM22VHI_OR_e60_lhmedium_L1EM22VHI_OR_e140_lhloose_L1EM22VHI",
            "e26_lhtight_nod0_ivarloose",
            "e26_lhtight_ivarloose_L1EM22VHI",
            "e26_lhmedium_nod0",
            "e26_lhmedium_nod0_L1EM22VHI",
            "e26_lhmedium_L1EM22VHI",
            "e26_lhmedium_L1eEM26M",
            "e26_lhtight_ivarloose_L1eEM26M",
            "e24_lhtight_nod0_ivarloose_OR_e60_lhmedium_nod0_OR_e140_lhloose_nod0",
            "e24_lhtight_nod0_ivarloose",
            "e24_lhmedium_L1EM20VH_OR_e60_lhmedium_OR_e120_lhloose",
            "e24_lhmedium_L1EM20VH",
            "e24_lhmedium_nod0_L1EM20VH",
            "e24_lhmedium_L1EM15VH",
            "e24_lhmedium_L1EM20VHI",
            "e24_lhmedium_nod0_L1EM20VHI",
            "e24_lhmedium_nod0_L1EM15VH",
            "e24_lhvloose_nod0_L1EM20VH",
            "e24_lhvloose_nod0",  # to be aliased
            "e24_lhvloose_L1EM20VH",
            "e24_lhvloose_L12EM20VH",  # to be aliased
            "e24_lhvloose_L1eEM24L",
            "e24_lhvloose_L12eEM24L",  # to be aliased
            "e20_lhmedium_nod0",
            "e20_lhmedium",
            "e17_lhvloose_L1eEM18M",
            "e17_lhvloose_L12eEM18M",  # to be aliased
            "e17_lhloose",
            "e17_lhloose_nod0",
            "e17_lhloose_L1EM15VH",
            "e17_lhloose_L1eEM18L",
            "e17_lhvloose_nod0",
            "e17_lhvloose_nod0_L1EM15VHI",
            "e17_lhvloose_nod0_L12EM15VHI",  # to be aliased
            "e17_lhvloose_L1EM15VHI",
            "e17_lhvloose_L12EM15VHI",  # to be aliased
            "e17_lhloose_nod0_L1EM15VH",
            "e17_lhmedium_nod0_L1EM15HI",
            "e17_lhmedium_nod0_AND_e17_lhvloose_nod0_L1EM15VHI",
            "e15_lhvloose_nod0_L1EM13VH",
            "e12_lhloose",
            "e12_lhloose_nod0",
            "e12_lhloose_L1EM10VH",
            "e12_lhloose_L12EM10VH",
            "e12_lhloose_L1EM8VH",
            "e12_lhloose_L1eEM10L",
            "e12_lhvloose_nod0_L1EM10VH",
            "e12_lhvloose_L1EM10VH",
            "e12_lhvloose_L1eEM12L",
            "e10_lhloose_nod0_L1EM8VH",
            "e9_lhloose",
            "e9_lhloose_nod0",
            "e9_lhvloose",
            "e17_lhmedium_nod0",  # to be aliased
            "e17_lhmedium_nod0_ivarloose",  # to be aliased
            "e7_lhmedium_nod0",
            "e7_lhmedium",
            "e7_lhmedium_L1eEM5",
        ]

        tau_triggers = [
            "tau20_mediumRNN_tracktwoMVA",
            "tau25_medium1_tracktwo",
            "tau25_medium1_tracktwoEF",
            "tau25_medium1_tracktwo_L1TAU20IM_2TAU12IM",
            "tau25_medium1_tracktwo_L1DR_TAU20ITAU12I_J25",
            "tau25_medium1_tracktwoEF_L1DR_TAU20ITAU12I_J25",
            "tau25_mediumRNN_tracktwoMVA",
            "tau25_mediumRNN_tracktwoMVA_L1DR_TAU20ITAU12I_J25",
            "tau35_medium1_tracktwo",
            "tau35_medium1_tracktwoEF",
            "tau35_medium1_tracktwoEF_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I",
            "tau35_medium1_tracktwo_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I",
            "tau35_mediumRNN_tracktwoMVA",
            "tau35_mediumRNN_tracktwoMVA_L1TAU12IM_L1TAU60_DR_TAU20ITAU12I",
            "tau40_mediumRNN_tracktwoMVA",
            "tau50_medium1_tracktwo_L1TAU12",
            "tau60_medium1_tracktwo_L1TAU40",
            "tau60_medium1_tracktwoEF_L1TAU40",
            "tau60_mediumRNN_tracktwoMVA",
            "tau60_mediumRNN_tracktwoMVA_L1TAU40",
            "tau80_medium1_tracktwo_L1TAU60",
            "tau80_medium1_tracktwoEF_L1TAU60",
            "tau80_mediumRNN_tracktwoMVA",
            "tau80_mediumRNN_tracktwoMVA_L1TAU60",
            "tau50L1TAU12_medium1_tracktwo",  # to be aliased
            "tau80L1TAU60_medium1_tracktwo",  # to be aliased
            "tau80L1TAU60_medium1_tracktwoEF",  # to be aliased
        ]

        photon_triggers = [
            "g300_etcut_L1eEM26M",
            "g300_etcut_L1EM22VHI",
            "g300_etcut",
            "g200_etcut",
            "g140_loose",
            "g140_loose_L1EM22VHI",
            "g140_loose_L1eEM26M",
            "g120_loose",
            "g50_loose_L1EM20VH",
            "g50_loose_L1eEM24L",
            "g35_tight_icalotight_L1EM24VHI",
            "g35_medium_L1EM20VH",
            "g35_medium_L1eEM24L",
            "g35_loose_L1EM24VHI",
            "g35_loose_L1EM22VHI",
            "g35_loose",
            "g35_loose_L1EM15",
            "g25_medium_L1EM20VH",
            "g25_medium_L1eEM24L",
            "g25_medium",
            "g25_loose",
            "g25_loose_L1EM15",
            "g22_tight_L1EM15VHI",
            "g22_tight_L1eEM18M",
            "g22_tight",
            "g20_tight_icalovloose_L1EM15VHI",
            "g20_tight_icaloloose_L1eEM18M",
            "g20_tight",
            "g20_loose",
            "g15_loose",
            "g12_loose",
            "g10_loose",
        ]

        fakes_electron_triggers = [
            "e5_lhvloose",
            "e10_lhvloose_L1EM7",
            "e12_lhvloose_L1EM10VH",  # already added
            "e15_lhvloose_L1EM13VH",
            "e17_lhvloose",
            "e20_lhvloose",
            "e26_lhvloose_nod0_L1EM20VH",
            "e60_lhvloose_nod0",
            "e200_etcut",
            "e5_lhvloose_nod0",
            "e12_lhvloose_nod0_L1EM10VH",  # already added
            "e17_lhvloose_nod0",  # already added
            "e20_lhvloose_nod0",
            "e24_lhvloose_nod0_L1EM18VH",
            "e28_lhvloose_nod0_L1EM20VH",
            "e120_lhvloose_nod0",
            "e300_etcut",
            "e140_lhvloose_nod0",
            "e160_lhvloose_nod0",
            "e10_lhvloose_nod0_L1EM7",
            "e15_lhvloose_nod0_L1EM7",
            "e28_lhvloose_nod0_L1EM22VH",
            "e70_lhvloose_nod0",
            "e80_lhvloose_nod0",
            "e100_lhvloose_nod0",
            "e20_lhvloose_L1EM15VH",
            "e30_lhvloose_L1EM22VHI",
            "e40_lhvloose_L1EM22VHI",
            "e60_lhvloose_L1EM22VHI",
            "e80_lhvloose_L1EM22VHI",
            "e100_lhvloose_L1EM22VHI",
            "e120_lhvloose_L1EM22VHI",
            "e10_lhvloose_L1eEM9",
            "e20_lhvloose_L1eEM18L",
            "e30_lhvloose_L1eEM26M",
            "e40_lhvloose_L1eEM26M",
            "e60_lhvloose_L1eEM26M",
            "e80_lhvloose_L1eEM26M",
            "e100_lhvloose_L1eEM26M",
            "e120_lhvloose_L1eEM26M",
        ]

        trigger_names = muon_triggers + electron_triggers + tau_triggers + photon_triggers + fakes_electron_triggers

        # reserve ID 0 for "no trigger" / None
        self.name_to_id: dict[str, int] = {"": 0}
        self.id_to_name: dict[int, str] = {0: ""}

        # assign IDs starting from 1
        for idx, name in enumerate(sorted(set(trigger_names)), start=1):
            self.name_to_id[name] = idx
            self.id_to_name[idx] = name

        # store None separately (not in the dicts above)
        self.none_id = -1

        # aliases for certain trigger names
        self._leg_aliases = {
            "e24_lhvloose_nod0": "e24_lhvloose_nod0_L1EM20VH",
            "e17_lhvloose_nod0_L12EM15VHI": "e17_lhvloose_nod0_L1EM15VHI",
            "e24_lhvloose_L12EM20VH": "e24_lhvloose_L1EM20VH",
            "e17_lhvloose_L12EM15VHI": "e17_lhvloose_L1EM15VHI",
            "mu8noL1_L1MU14FCH": "mu8noL1_FSNOSEED",
            "mu14_L12MU8F": "mu14_L1MU8F",
            "mu14_L1EM15VH_MU8F": "mu14_L1MU8F",
            "e24_lhvloose_L12eEM24L": "e24_lhvloose_L1eEM24L",
            "e17_lhvloose_L12eEM18M": "e17_lhvloose_L1eEM18M",
            "mu14_L1eEM18L_MU8F": "mu14_L1MU8F",
            "tau50L1TAU12_medium1_tracktwo": "tau50_medium1_tracktwo_L1TAU12",
            "tau80L1TAU60_medium1_tracktwo": "tau80_medium1_tracktwo_L1TAU60",
            "tau80L1TAU60_medium1_tracktwoEF": "tau80_medium1_tracktwoEF_L1TAU60",
            "e17_lhmedium_nod0_ivarloose": "e17_lhmedium_nod0_L1EM15HI",
            "e17_lhmedium_nod0": "e17_lhmedium_nod0_L1EM15HI",
        }

    @property
    def leg_aliases(self) -> dict[str, str]:
        return self._leg_aliases

    def get_id(self, name: str | None) -> int:
        """Convert trigger name to integer ID.

        Parameters
        ----------
        name : str or None
            Trigger name string, or None.

        Returns
        -------
        int
            Integer ID for the trigger (0 for "", -1 for None, >0 for actual triggers).

        Raises
        ------
        KeyError
            If trigger name is not found in the lookup table.
        """
        if name is None:
            return self.none_id
        return self.name_to_id[name]

    def get_name(self, trigger_id: int) -> str | None:
        """Convert integer ID back to trigger name.

        Parameters
        ----------
        trigger_id : int
            Integer ID for the trigger.

        Returns
        -------
        str or None
            Trigger name string, or None if ID is -1.

        Raises
        ------
        KeyError
            If trigger ID is not found in the lookup table.
        """
        if trigger_id == self.none_id:
            return None
        return self.id_to_name[trigger_id]

    @property
    def num_triggers(self) -> int:
        """Total number of triggers (excluding None and empty string).

        Returns
        -------
        int
            The number of triggers in the lookup table.
        """
        return len(self.name_to_id) - 1  # subtract 1 for the empty string at ID 0
