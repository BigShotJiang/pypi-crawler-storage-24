import enum

import awkward as ak

from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor


class TruthMode(enum.IntEnum):
    NOMINAL = 0
    ALLMC = 1
    FAKEONLY = 2


class LeptonTruthMatching(Processor):
    """Combined electron, muon, and tau truth matching.

    Parameters
    ----------
    mctc : bool, optional
        Use MCTruthClassifier `isPrompt` branch when True, or IFF truth
        classification when False. Default is True.
    charge_flip_fallback : bool, optional
        When `mctc=True`, also accept electrons with
        `IFF::ChargeFlipIsoElectron` (type 3) as prompt. Default is False.
    truth_mode : str, optional
        Truth matching mode. One of:
          - `nominal` (default) - Veto the entire event if any selected lepton
            (electron or muon) is non-prompt.
          - `allmc` - No truth matching applied. All MC leptons kept.
          - `fakeonly` - Keep only events containing at least one fake lepton.
    sel_tau : bool, optional
        Include taus in truth matching. Default is False.
    prefix : str, optional
        Prefix for the processor name.

    References
    ----------
    .. [1] MCTruthClassifier definitions:
       https://gitlab.cern.ch/atlas/athena/-/blob/21.2/PhysicsAnalysis/MCTruthClassifier/MCTruthClassifier/MCTruthClassifierDefs.h
    .. [2] IFF TruthClassification:
       https://gitlab.cern.ch/atlas/athena/-/tree/21.2/PhysicsAnalysis/AnalysisCommon/TruthClassification#truthclassification

    """

    def __init__(
        self,
        mctc: bool = True,
        charge_flip_fallback: bool = False,
        truth_mode: str = "nominal",
        sel_tau: bool = False,
        prefix: str = "",
    ) -> None:
        super().__init__(name=f"{prefix}leptonTruthMatching", disable_variations=True)
        self.mctc = mctc
        self.charge_flip_fallback = charge_flip_fallback
        self.sel_tau = sel_tau

        self.truth_mode = TruthMode[truth_mode.upper()]

        # electron branches
        if self.mctc:
            self._el_prompt_branch = "el_truth_isPrompt"
            if self.charge_flip_fallback:
                self._el_classification_branch = "el_truth_classification"
                self.attach_branch(self._el_classification_branch, is_varied=False, overwrite=True)
        else:
            self._el_prompt_branch = "el_truth_classification"

        self.attach_branch(self._el_prompt_branch, is_varied=False, overwrite=True)

        # muon branches
        if self.mctc:
            self._mu_prompt_branch = "mu_truth_isPrompt"
        else:
            self._mu_prompt_branch = "mu_truth_classification"

        self.attach_branch(self._mu_prompt_branch, is_varied=False, overwrite=True)

        # tau branches
        if self.sel_tau:
            if not self.mctc:
                raise ValueError("Can only use tau truth matching with MCTC!")

            self._tau_prompt_branch = "tau_truth_isPrompt"
            self.attach_branch(self._tau_prompt_branch, is_varied=False, overwrite=True)

    def _el_is_prompt(self, arrays: GroupArrays) -> ak.Array:
        if self.mctc:
            is_prompt = arrays[self._el_prompt_branch] == 1
            if self.charge_flip_fallback:
                # IFF::Type::ChargeFlipIsoElectron = 3
                is_prompt = is_prompt | (arrays[self._el_classification_branch] == 3)
            return is_prompt

        # IFF::Type::IsoElectron = 2, ChargeFlipIsoElectron = 3
        return (arrays[self._el_prompt_branch] == 2) | (arrays[self._el_prompt_branch] == 3)

    def _mu_is_prompt(self, arrays: GroupArrays) -> ak.Array:
        if self.mctc:
            return arrays[self._mu_prompt_branch] == 1

        # IFF::Type::PromptMuon = 4
        return arrays[self._mu_prompt_branch] == 4

    def _tau_is_prompt(self, arrays: GroupArrays) -> ak.Array:
        return arrays[self._tau_prompt_branch] == 1

    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.is_data or self.truth_mode == TruthMode.ALLMC:
            return {"arrays": arrays}

        el_is_prompt = self._el_is_prompt(arrays)
        mu_is_prompt = self._mu_is_prompt(arrays)
        tau_is_prompt = self._tau_is_prompt(arrays) if self.sel_tau else None

        if self.truth_mode == TruthMode.FAKEONLY:
            # keep all leptons, but veto events that have NO fakes at all
            # only events with >=1 fake tight lepton survive
            el_has_fake = ak.any(~el_is_prompt, axis=1)
            mu_has_fake = ak.any(~mu_is_prompt, axis=1)
            has_any_fake = el_has_fake | mu_has_fake

            if tau_is_prompt is not None:
                tau_has_fake = ak.any(~tau_is_prompt, axis=1)
                has_any_fake = has_any_fake | tau_has_fake

            # for events without fakes, empty the lepton lists
            # the event fails the downstream lepton count requirement
            el_keep = (el_is_prompt | ~el_is_prompt) & has_any_fake
            mu_keep = (mu_is_prompt | ~mu_is_prompt) & has_any_fake

            arrays["el"] = arrays["el"][el_keep]
            arrays["mu"] = arrays["mu"][mu_keep]

            if tau_is_prompt is not None:
                tau_keep = (tau_is_prompt | ~tau_is_prompt) & has_any_fake
                arrays["tau"] = arrays["tau"][tau_keep]

            return {"arrays": arrays}

        # nominal: veto entire event if any lepton is non-prompt
        el_all_prompt = ak.all(el_is_prompt, axis=1)
        mu_all_prompt = ak.all(mu_is_prompt, axis=1)
        all_prompt = el_all_prompt & mu_all_prompt

        if tau_is_prompt is not None:
            tau_all_prompt = ak.all(tau_is_prompt, axis=1)
            all_prompt = all_prompt & tau_all_prompt

        arrays["el"] = arrays["el"][el_is_prompt & all_prompt]
        arrays["mu"] = arrays["mu"][mu_is_prompt & all_prompt]

        if tau_is_prompt is not None:
            arrays["tau"] = arrays["tau"][tau_is_prompt & all_prompt]

        return {"arrays": arrays}
