import re
import tempfile
from functools import partial
from multiprocessing import Pool
from pathlib import Path

import uproot

from f9columnar.utils.loggers import get_progress


def _clean_metadata_root_file(root_file: str, patterns: list[str]) -> None:
    regexes = [re.compile(pattern) for pattern in patterns]

    keys_and_objects = []
    with uproot.open(root_file) as f:
        all_keys = list(f)

        keys_to_keep = [k for k in all_keys if not any(regex.search(k) for regex in regexes)]
        if len(keys_to_keep) == len(all_keys):
            return None

        for key in keys_to_keep:
            obj = f[key]
            is_ttree = hasattr(obj, "arrays") and hasattr(obj, "classname") and obj.classname.startswith("TTree")
            if is_ttree:
                data = obj.arrays(library="ak")
                keys_and_objects.append((key, data))
            else:
                keys_and_objects.append((key, obj))

    root_file_dir = Path(root_file).parent
    with tempfile.NamedTemporaryFile(
        mode="wb",
        delete=False,
        suffix=".root",
        dir=root_file_dir,
    ) as tmp:
        tmp_path = tmp.name

    with uproot.recreate(tmp_path) as out:
        for key, obj in keys_and_objects:
            try:
                out[key] = obj
            except Exception:
                pass

    Path(tmp_path).replace(root_file)


def clean_metadata_root_files(dir_or_file: str, patterns: list[str], num_workers: int = 1) -> None:
    if dir_or_file.endswith(".root"):
        _clean_metadata_root_file(dir_or_file, patterns)
        return None

    root_files = [str(p) for p in Path(dir_or_file).rglob("*.root")]

    if num_workers <= 1:
        with get_progress() as progress:
            task = progress.add_task("Cleaning metadata", total=len(root_files))
            for root_file in root_files:
                _clean_metadata_root_file(root_file, patterns)
                progress.advance(task)
    else:
        worker = partial(_clean_metadata_root_file, patterns=patterns)
        with Pool(processes=num_workers) as pool:
            with get_progress() as progress:
                task = progress.add_task("Cleaning metadata", total=len(root_files))
                for _ in pool.imap_unordered(worker, root_files):
                    progress.advance(task)
