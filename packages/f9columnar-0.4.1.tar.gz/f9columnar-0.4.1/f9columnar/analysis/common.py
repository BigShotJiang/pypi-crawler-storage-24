import os
from typing import Any

import awkward as ak
import numpy as np

from f9columnar.analysis.utils import get_year_from_campaign
from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.processors_collection import decorate_branches
from f9columnar.utils.regex_helpers import (
    extract_campaign_from_file,
    extract_dsid_from_file,
    extract_user_from_file,
    extract_year_from_file,
)
from f9columnar.variations import vary

SELECTED_BRANCHES = [
    ("el_selected_NOSYS", "el_selected"),
    ("mu_selected_NOSYS", "mu_selected"),
    ("tau_selected_NOSYS", "tau_selected"),
]


@decorate_branches("randomRunNumber", "runNumber")
class RunNumberProcessor(Processor):
    def __init__(self) -> None:
        super().__init__(name="runNumber", disable_variations=True)
        self.attach_branch(("tau_pt_NOSYS", "tau_pt"), is_varied=True)

    def _run_groups(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if not self.is_data:
            run_number = arrays["randomRunNumber"]
            del arrays["randomRunNumber"]
            del arrays["runNumber"]
            arrays["runNumber"] = run_number

        return {"arrays": arrays}

    def _run_arrays(self, arrays: ak.Array) -> dict[str, ak.Array]:
        if self.is_data:
            arrays = ak.without_field(arrays, "randomRunNumber")
        else:
            run_number = arrays["randomRunNumber"]
            arrays["runNumber"] = run_number
            arrays = ak.without_fields(arrays, "randomRunNumber")

        return {"arrays": arrays}

    def run(self, arrays: Any) -> dict[str, Any]:
        if isinstance(arrays, GroupArrays):
            return self._run_groups(arrays)
        else:
            return self._run_arrays(arrays)


class SampleInfoProcessor(Processor):
    def __init__(self) -> None:
        super().__init__(name="sampleInfo", disable_variations=True)
        self._sample_info: dict[str, Any] = {}

        self._is_set: bool = False

    def run(self, arrays: Any) -> dict[str, Any]:
        if not self._is_set:
            if self.reports is None:
                raise RuntimeError("Reports data is not available for SampleInfoProcessor.")

            if self.reports.get("is_ntuples", False):
                self._sample_info = {
                    "dsid": self.reports["dsid"],
                    "campaign": self.reports["campaign"],
                    "year": self.reports["year"],
                    "user": self.reports["user"],
                }
                self._is_set = True

                return {"arrays": arrays}

            file_name = os.path.basename(self.reports["file_path"])

            campaign = extract_campaign_from_file(file_name)
            year = extract_year_from_file(file_name)

            if campaign is not None:
                if year is not None:
                    raise RuntimeError("Both campaign and year were extracted from the file name!")

                year = get_year_from_campaign(campaign)

            self._sample_info = {
                "dsid": extract_dsid_from_file(file_name),
                "campaign": extract_campaign_from_file(file_name),
                "year": year,
                "user": extract_user_from_file(file_name),
            }

            self._is_set = True

        return {"arrays": arrays}


@decorate_branches(
    ("weight_mc_NOSYS", "weight_mc"),
    ("weight_pileup_NOSYS", "weight_pileup"),
    "weight_beamspot",
)
class FinalEventWeight(Processor):
    weight_mc: str
    weight_pileup: str
    weight_beamspot: str

    def __init__(self, prescale_data: bool = False, wz_jets_kfactor: bool = False, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}weightProcessor")
        self.prescale_data = prescale_data
        self.wz_jets_kfactor = wz_jets_kfactor

        self.attach_branch(("weight_final_NOSYS", "weight_final"), is_varied=True, is_created=True)

    def _make_weight(self, arrays: GroupArrays) -> ak.Array:
        if self.reports is None:
            raise RuntimeError("Reports not available for weight calculation!")

        if self.reports["use_weights"]:
            sample_weight = self.reports["sample_weight"]
        else:
            sample_weight = 1.0

        if self.wz_jets_kfactor:
            if "zjets" in self.reports["name"].lower():
                sample_weight = sample_weight * 0.95

            if "wjets" in self.reports["name"].lower():
                sample_weight = sample_weight * 0.95

        total_weight = arrays["other", "total_weight"]

        weight_pileup = arrays["weight", self.weight_pileup]
        weight_pileup = ak.where((np.abs(weight_pileup) > 1000.0) | (weight_pileup == 0.0), 1.0, weight_pileup)

        prod = arrays["weight", self.weight_mc] * total_weight * weight_pileup * sample_weight

        if self.weight_beamspot in arrays.fields:
            prod = prod * arrays["weight", self.weight_beamspot]

        return prod

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, ak.Array]:
        if self.is_data:
            if self.prescale_data:
                if "weight_prescale" not in arrays.fields:
                    raise RuntimeError("Prescale weight requested but not found in arrays!")
                weight = arrays["weight_prescale"]
            else:
                weight = ak.ones_like(arrays["runNumber"], dtype=np.float64)

            arrays["weight_final_NOSYS"] = weight
            return {"arrays": arrays}

        weight = self._make_weight(arrays)

        arrays.add_varied_array(
            weight,
            "weight_final",
            variation="nominal" if self.current_variation is None else self.current_variation,
            variation_map=self.variation_map,
            group="weight",
        )

        return {"arrays": arrays}
