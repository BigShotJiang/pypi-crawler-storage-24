import enum

import awkward as ak

from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor
from f9columnar.variations import vary


class RegionsMode(enum.IntEnum):
    TIGHT = 0
    LOOSE = 1
    STRICTLYLOOSE = 2


class ElectronType(Processor):
    lh_wp: str
    iso_wp: str

    def __init__(self, lh_wp: str, iso_wp: str, prefix: str = "") -> None:
        """Classify electrons into loose and tight types.

        Parameters
        ----------
        lh_wp : str
            Likelihood working point. Options are "Medium" and "Tight".
        iso_wp : str
            Isolation working point. Options are "Loose_VarRad" and "Tight_VarRad".
        prefix : str, optional
            Prefix for the processor name, by default "".

        """
        super().__init__(name=f"{prefix}electronType")
        lh_wps = {
            "Medium": "el_likelihood_Medium",
            "Tight": "el_likelihood_Tight",
        }
        iso_wps = {
            "Loose_VarRad": "el_isIsolated_Loose_VarRad_NOSYS",
            "Tight_VarRad": "el_isIsolated_Tight_VarRad_NOSYS",
        }

        lh_wp, iso_wp = lh_wps[lh_wp], iso_wps[iso_wp]

        self.attach_branch((lh_wp, "lh_wp"), is_varied=False)
        self.attach_branch((iso_wp, "iso_wp"), is_varied=True)

        self.attach_branch(("el_type_NOSYS", "el_type"), is_varied=True, is_created=True)

        self.tight_idx, self.strictly_loose_idx = int(RegionsMode.TIGHT), int(RegionsMode.STRICTLYLOOSE)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        lh_wp_mask = ak.values_astype(arrays[self.lh_wp], bool)
        iso_wp_mask = ak.values_astype(arrays[self.iso_wp], bool)

        type_mask = lh_wp_mask & iso_wp_mask

        if self.tight_idx == 0:
            el_type = ak.zeros_like(type_mask, dtype=int)
        else:
            el_type = ak.ones_like(type_mask, dtype=int) * self.tight_idx

        el_type = ak.where(~type_mask, self.strictly_loose_idx, el_type)

        arrays.add_varied_array(
            el_type,
            "el_type",
            variation="nominal" if self.current_variation is None else self.current_variation,
            variation_map=self.variation_map,
        )

        return {"arrays": arrays}


class MuonType(Processor):
    iso_wp: str

    def __init__(self, iso_wp: str, prefix: str = "") -> None:
        """Classify muons into loose and tight types based on isolation.

        Bad muon quality is handled upstream by BadMuonVeto (event-level veto),
        so only isolation determines the tight/loose classification here.

        Parameters
        ----------
        iso_wp : str
            Isolation working point. Options are "Loose_VarRad", "Tight_VarRad",
            "PflowLoose_VarRad", and "PflowTight_VarRad".
        prefix : str, optional
            Prefix for the processor name, by default "".

        """
        super().__init__(name=f"{prefix}muonType")
        iso_wps = {
            "Loose_VarRad": "mu_isIsolated_Loose_VarRad_NOSYS",
            "Tight_VarRad": "mu_isIsolated_Tight_VarRad_NOSYS",
            "PflowLoose_VarRad": "mu_isIsolated_PflowLoose_VarRad_NOSYS",
            "PflowTight_VarRad": "mu_isIsolated_PflowTight_VarRad_NOSYS",
        }

        self.attach_branch((iso_wps[iso_wp], "iso_wp"), is_varied=True)
        self.attach_branch(("mu_type_NOSYS", "mu_type"), is_varied=True, is_created=True)

        self.tight_idx, self.strictly_loose_idx = int(RegionsMode.TIGHT), int(RegionsMode.STRICTLYLOOSE)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        iso_wp_mask = ak.values_astype(arrays[self.iso_wp], bool)

        if self.tight_idx == 0:
            mu_type = ak.zeros_like(iso_wp_mask, dtype=int)
        else:
            mu_type = ak.ones_like(iso_wp_mask, dtype=int) * self.tight_idx

        mu_type = ak.where(~iso_wp_mask, self.strictly_loose_idx, mu_type)

        arrays.add_varied_array(
            mu_type,
            "mu_type",
            variation="nominal" if self.current_variation is None else self.current_variation,
            variation_map=self.variation_map,
        )

        return {"arrays": arrays}


class TauType(Processor):
    id_wp: str
    eveto: str

    def __init__(self, id_wp: str, use_eveto: bool = False, prefix: str = "") -> None:
        """Classify taus into tight and strictly loose (anti-tau) types.

        Tight taus pass the tau ID working point and electron veto.
        Strictly loose (anti-tau) taus fail either requirement.

        Parameters
        ----------
        id_wp : str
            Tau ID working point. Options are "Loose", "Medium", and "Tight".
        use_eveto : bool, optional
            Require electron veto for tight classification. Default is False.
        prefix : str, optional
            Prefix for the processor name, by default "".

        """
        super().__init__(name=f"{prefix}tauType")
        id_wps = {
            "Loose": "tau_isLoose_NOSYS",
            "Medium": "tau_isMedium_NOSYS",
            "Tight": "tau_isTight_NOSYS",
        }

        self.use_eveto = use_eveto

        self.attach_branch((id_wps[id_wp], "id_wp"), is_varied=True)

        if self.use_eveto:
            self.attach_branch(("tau_eVeto_NOSYS", "eveto"), is_varied=True)

        self.attach_branch(("tau_type_NOSYS", "tau_type"), is_varied=True, is_created=True)

        self.tight_idx, self.strictly_loose_idx = int(RegionsMode.TIGHT), int(RegionsMode.STRICTLYLOOSE)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        id_wp_mask = ak.values_astype(arrays[self.id_wp], bool)

        if self.use_eveto:
            eveto_mask = ak.values_astype(arrays[self.eveto], bool)
            type_mask = id_wp_mask & eveto_mask
        else:
            type_mask = id_wp_mask

        if self.tight_idx == 0:
            tau_type = ak.zeros_like(type_mask, dtype=int)
        else:
            tau_type = ak.ones_like(type_mask, dtype=int) * self.tight_idx

        tau_type = ak.where(~type_mask, self.strictly_loose_idx, tau_type)

        arrays.add_varied_array(
            tau_type,
            "tau_type",
            variation="nominal" if self.current_variation is None else self.current_variation,
            variation_map=self.variation_map,
        )

        return {"arrays": arrays}


class SelectRegion(Processor):
    type_branch: str

    def __init__(self, group_name: str, select_region: str, prefix: str = "") -> None:
        super().__init__(name=f"{prefix}selectRegion")
        self.group_name = group_name
        self.region_idx = int(RegionsMode[select_region.replace("_", "").upper()])

        self.attach_branch((f"{group_name}_type_NOSYS", "type_branch"), is_varied=True)

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        mask = arrays[self.type_branch] == self.region_idx
        arrays = arrays[self.group_name, mask]
        return {"arrays": arrays}
