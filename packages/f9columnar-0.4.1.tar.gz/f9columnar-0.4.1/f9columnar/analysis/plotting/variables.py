from dataclasses import dataclass

import numpy as np


def get_log_binning(x_min: float, x_max: float, nbins: int) -> np.ndarray:
    return np.logspace(np.log(x_min), np.log(x_max), nbins, base=np.e)


def bin_edges_from_centers(bin_centers: np.ndarray) -> np.ndarray:
    bin_width = bin_centers[1] - bin_centers[0]
    bin_edges = np.concatenate(([bin_centers[0] - bin_width / 2], bin_centers + bin_width / 2))
    return bin_edges


@dataclass
class AnalysisVariable:
    name: str
    latex_name: str | None = None
    unit: str | None = None

    def __post_init__(self) -> None:
        if self.latex_name is not None and self.unit is not None:
            self.latex_name = f"{self.latex_name} [{self.unit}]"


def get_variable(
    name: str,
    latex_name: str | None = None,
    unit: str | None = None,
) -> AnalysisVariable:
    variable = switch_on_variable(name)

    if latex_name is not None:
        variable.latex_name = latex_name

    if unit is not None:
        variable.unit = unit

    return variable


def switch_on_variable(name: str) -> AnalysisVariable:
    match name:
        case "pt":
            return AnalysisVariable(
                name=name,
                latex_name=r"$p_\mathrm{T}$",
                unit="GeV",
            )
        case "ptl1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading lepton $p_\mathrm{T}$",
                unit="GeV",
            )
        case "ptl2":
            return AnalysisVariable(
                name=name,
                latex_name=r"Subleading lepton $p_\mathrm{T}$",
                unit="GeV",
            )
        case "eta":
            return AnalysisVariable(
                name=name,
                latex_name=r"$\eta$",
            )
        case "etal1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading lepton $\eta$",
            )
        case "etal2":
            return AnalysisVariable(
                name=name,
                latex_name=r"Subleading $\eta$",
            )
        case "phill":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading lepton $\phi$",
            )
        case "phil1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading lepton $\phi$",
            )
        case "phil2":
            return AnalysisVariable(
                name=name,
                latex_name=r"Subleading lepton $\phi$",
            )
        case "pt2l":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-lepton $p_\mathrm{T}$",
                unit="GeV",
            )
        case "pt2lSS1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-lepton $p_\mathrm{T}$ SS lead. pair",
                unit="GeV",
            )
        case "pt2lOS1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-lepton $p_\mathrm{T}$ SS lead. pair",
                unit="GeV",
            )
        case "eta2l":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-lepton $\eta$",
            )
        case "phi2l":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-lepton $\phi$",
            )
        case "mll":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-lepton invariant mass $m_{\ell\ell}$",
                unit="GeV",
            )
        case "mll_ee":
            return AnalysisVariable(
                name=name,
                latex_name=r"Di-electron invariant mass $m_{ee}$",
                unit="GeV",
            )
        case "mllSS1":
            return AnalysisVariable(
                name=name,
                latex_name=r"$m_{\ell\ell}$ SS lead. pair",
                unit="GeV",
            )
        case "mllOS1":
            return AnalysisVariable(
                name=name,
                latex_name=r"$m_{\ell\ell}$ OS lead. pair",
                unit="GeV",
            )
        case "dR2l12":
            return AnalysisVariable(
                name=name,
                latex_name=r"$\Delta R(\mathrm{lead. lep.}, \mathrm{sublead. lep.})$",
            )
        case "dR2lOS1":
            return AnalysisVariable(
                name=name,
                latex_name=r"$\Delta R(\mathrm{lead. lep.}, \mathrm{sublead. lep.})$ OS lead. pair",
            )
        case "deta2l12":
            return AnalysisVariable(
                name=name,
                latex_name=r"$\Delta \eta(\mathrm{lead. lep.}, \mathrm{sublead. lep.})$",
            )
        case "dphi2l12":
            return AnalysisVariable(
                name=name,
                latex_name=r"$\Delta \phi(\mathrm{lead. lep.}, \mathrm{sublead. lep.})$",
            )
        case "met":
            return AnalysisVariable(
                name=name,
                latex_name=r"Missing $E_\mathrm{T}$",
                unit="GeV",
            )
        case "metphi":
            return AnalysisVariable(
                name=name,
                latex_name=r"Missing $E_\mathrm{T}$ $\phi$",
            )
        case "metsig":
            return AnalysisVariable(
                name=name,
                latex_name=r"$E_\mathrm{T}^\mathrm{miss}$ significance",
            )
        case "htmet":
            return AnalysisVariable(
                name=name,
                latex_name=r"$H_\mathrm{T} + E_\mathrm{T}^\mathrm{miss}$",
                unit="GeV",
            )
        case "htlepmet":
            return AnalysisVariable(
                name=name,
                latex_name=r"Lepton $H_\mathrm{T} + E_\mathrm{T}^\mathrm{miss}$",
                unit="GeV",
            )
        case "ht":
            return AnalysisVariable(
                name=name,
                latex_name=r"$H_\mathrm{T}$",
                unit="GeV",
            )
        case "htlep":
            return AnalysisVariable(
                name=name,
                latex_name=r"Lepton $H_\mathrm{T}$",
                unit="GeV",
            )
        case "ptj1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading light jet $p_\mathrm{T}$",
                unit="GeV",
            )
        case "ptj2":
            return AnalysisVariable(
                name=name,
                latex_name=r"Subleading light jet $p_\mathrm{T}$",
                unit="GeV",
            )
        case "ptj3":
            return AnalysisVariable(
                name=name,
                latex_name=r"Third light jet $p_\mathrm{T}$",
                unit="GeV",
            )
        case "etaj1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading light jet $\eta$",
            )
        case "etaj2":
            return AnalysisVariable(
                name=name,
                latex_name=r"Subleading light jet $\eta$",
            )
        case "etaj3":
            return AnalysisVariable(
                name=name,
                latex_name=r"Third light jet $\eta$",
            )
        case "phij1":
            return AnalysisVariable(
                name=name,
                latex_name=r"Leading light jet $\phi$",
            )
        case "phij2":
            return AnalysisVariable(
                name=name,
                latex_name=r"Subleading light jet $\phi$",
            )
        case "phij3":
            return AnalysisVariable(
                name=name,
                latex_name=r"Third light jet $\phi$",
            )
        case "pt2j":
            return AnalysisVariable(
                name=name,
                latex_name=r"Light di-jet $p_\mathrm{T}$",
                unit="GeV",
            )
        case "eta2j":
            return AnalysisVariable(
                name=name,
                latex_name=r"Light di-jet $\eta$",
            )
        case "phi2j":
            return AnalysisVariable(
                name=name,
                latex_name=r"Light di-jet $\phi$",
            )
        case "mjj":
            return AnalysisVariable(
                name=name,
                latex_name=r"Light di-jet invariant mass $m_{jj}$",
                unit="GeV",
            )
        case "ht2j":
            return AnalysisVariable(
                name=name,
                latex_name=r"Light di-jet $H_\mathrm{T}$",
                unit="GeV",
            )
        case "m2j2l":
            return AnalysisVariable(
                name=name,
                latex_name=r"$m_{jjll}$",
                unit="GeV",
            )
        case "m2jll":
            return AnalysisVariable(
                name=name,
                latex_name=r"$m_{jjl_\mathrm{lead}}$",
                unit="GeV",
            )
        case "m2jsl":
            return AnalysisVariable(
                name=name,
                latex_name=r"$m_{jjl_\mathrm{sublead}}$",
                unit="GeV",
            )
        case "mt":
            return AnalysisVariable(
                name=name,
                latex_name=r"Transverse mass $m_T$",
                unit="GeV",
            )
        case "m_t":
            return AnalysisVariable(
                name=name,
                latex_name=r"Transverse mass $m_T$",
                unit="GeV",
            )
        case "mtlep":
            return AnalysisVariable(
                name=name,
                latex_name=r"Lepton transverse mass $m_T$",
                unit="GeV",
            )
        case "njets_light":
            return AnalysisVariable(
                name=name,
                latex_name="Number of light jets",
            )
        case "njets":
            return AnalysisVariable(
                name=name,
                latex_name="Number of jets",
            )
        case "nbjets":
            return AnalysisVariable(
                name=name,
                latex_name="Number of b-jets",
            )
        case "nwbosons":
            return AnalysisVariable(
                name=name,
                latex_name=r"$W$ boson multiplicity",
            )
        case "mlmass":
            return AnalysisVariable(
                name=name,
                latex_name="ML mass",
                unit="GeV",
            )
        case "secondary_mlmass":
            return AnalysisVariable(
                name=name,
                latex_name="Secondary ML mass",
                unit="GeV",
            )
        case "mva_score":
            return AnalysisVariable(
                name=name,
                latex_name="MVA binary score",
            )
        case "el_pt":
            return AnalysisVariable(
                name=name,
                latex_name=r"Electron $p_\mathrm{T}$",
                unit="GeV",
            )
        case "el_abs_caloCluster_eta":
            return AnalysisVariable(
                name=name,
                latex_name=r"Electron |$\eta$|",
            )
        case "el_caloCluster_eta":
            return AnalysisVariable(
                name=name,
                latex_name=r"Electron $\eta$",
            )
        case "el_eta":
            return AnalysisVariable(
                name=name,
                latex_name=r"Electron $\eta$",
            )
        case "el_phi":
            return AnalysisVariable(
                name=name,
                latex_name=r"Electron $\phi$",
            )
        case "el_charge":
            return AnalysisVariable(
                name=name,
                latex_name=r"Electron charge",
            )
        case "mu_pt":
            return AnalysisVariable(
                name=name,
                latex_name=r"Muon $p_\mathrm{T}$",
                unit="GeV",
            )
        case "mu_eta":
            return AnalysisVariable(
                name=name,
                latex_name=r"Muon $\eta$",
            )
        case "mu_abs_eta":
            return AnalysisVariable(
                name=name,
                latex_name=r"Muon |$\eta$|",
            )
        case "mu_phi":
            return AnalysisVariable(
                name=name,
                latex_name=r"Muon $\phi$",
            )
        case "mu_charge":
            return AnalysisVariable(
                name=name,
                latex_name=r"Muon charge",
            )
        case "toy_pt":
            return AnalysisVariable(
                name=name,
                latex_name=r"Toy $p_\mathrm{T}$",
                unit="GeV",
            )
        case _:
            return AnalysisVariable(name=name, latex_name=name)
