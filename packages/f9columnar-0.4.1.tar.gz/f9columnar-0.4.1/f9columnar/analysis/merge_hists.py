import copy
import re

import hist
import numpy as np
from rich.console import Console
from rich.table import Table

from f9columnar.analysis.config.samples import DatasetHandler
from f9columnar.analysis.utils import get_luminosity
from f9columnar.utils.helpers import load_pickle


class MergedHistsBuilder:
    def __init__(
        self,
        saved_hists_path: str,
        sample_datasets: dict[str, list[str]] | None = None,
    ) -> None:
        if not saved_hists_path.endswith(".p"):
            raise ValueError("The saved_hists_path must point to a .p file.")

        self.merged_hists = load_pickle(saved_hists_path)
        self.ds_handler = DatasetHandler(sample_datasets=sample_datasets)

    def print_summary(self) -> None:
        console = Console()

        groups: dict[str, dict] = {}
        for dataset, group_hists in sorted(self.merged_hists.items()):
            if not isinstance(group_hists, dict):
                entry = groups.setdefault("_ungrouped", {"datasets": [], "variations": set(), "variables": set()})
                entry["datasets"].append(dataset)
                continue
            for group_key, variations in sorted(group_hists.items()):
                entry = groups.setdefault(group_key, {"datasets": [], "variations": set(), "variables": set()})
                entry["datasets"].append(dataset)
                if not isinstance(variations, dict):
                    continue
                entry["variations"].update(variations.keys())
                first_val = next(iter(variations.values()))
                if isinstance(first_val, dict):
                    entry["variables"].update(first_val.keys())

        for group_key, info in groups.items():
            table = Table(title=f"Group key — {group_key}", show_lines=True)
            table.add_column("Datasets", style="cyan")
            table.add_column("Variations", style="yellow")
            table.add_column("Variables", style="magenta")
            datasets_str = "\n".join(info["datasets"])
            var_names = sorted(info["variations"])
            n_var = len(var_names)
            var_str = "\n".join(var_names[:5])
            if n_var > 5:
                var_str += f"\n... ({n_var} total)"
            variables_str = "\n".join(sorted(info["variables"]))
            table.add_row(datasets_str, var_str, variables_str)
            console.print(table)
            console.print()

    @staticmethod
    def transform_hist(
        h: hist.Hist,
        hist_range: tuple[float, float] | None = None,
        hist_bins: int | None = None,
        hist_edges: list[float] | np.ndarray | None = None,
    ) -> hist.Hist:
        # adjust plotting range
        if hist_range is not None:
            h = h[hist.loc(hist_range[0]) : hist.loc(hist_range[1])]  # type: ignore[assignment, misc]

        # rebin to N bins (uniform)
        if hist_bins is not None:
            axis_edges = h.axes[0].edges
            hist_range_width = axis_edges[-1] - axis_edges[0]
            new_bin_width = hist_range_width / hist_bins
            rebin = max(1, int(new_bin_width / h.axes[0].widths[0]))
            h = h[hist.rebin(rebin)]  # type: ignore[call-overload]

        # rebin to custom edges
        if hist_edges is not None:
            edges = np.asarray(hist_edges)
            old_edges = h.axes[0].edges
            old_values = h.values()
            old_variances = h.variances()

            # create new histogram with custom edges and appropriate storage
            if old_variances is not None:
                new_hist = hist.Hist(hist.axis.Variable(edges), storage=hist.storage.Weight())
            else:
                new_hist = hist.Hist(hist.axis.Variable(edges))

            # assign each old bin to a new bin based on its center
            old_centers = (old_edges[:-1] + old_edges[1:]) / 2
            bin_indices = np.searchsorted(edges, old_centers, side="right") - 1

            for i in range(len(edges) - 1):
                mask = bin_indices == i

                if old_variances is not None:
                    new_hist.view().value[i] = np.sum(old_values[mask])
                    new_hist.view().variance[i] = np.sum(old_variances[mask])
                else:
                    new_hist.view()[i] = np.sum(old_values[mask])

            h = new_hist

        return h

    def apply_hist_transformations(
        self,
        data_hists: dict[str, hist.Hist],
        mc_hists: list[hist.Hist],
        signals_hists: dict[str, hist.Hist],
        hist_range: tuple[float, float] | None = None,
        hist_bins: int | None = None,
        hist_edges: list[float] | np.ndarray | None = None,
    ) -> None:
        # apply transformations to all histogram collections
        for hists_dict in [data_hists, signals_hists]:
            for key in hists_dict:
                hists_dict[key] = self.transform_hist(hists_dict[key], hist_range, hist_bins, hist_edges)

        for i in range(len(mc_hists)):
            mc_hists[i] = self.transform_hist(mc_hists[i], hist_range, hist_bins, hist_edges)

    def get_dataset_hists(
        self,
        variable: str,
        datasets: list[str] | None,
        years: list[int] | None,
        campaigns: list[str] | None,
        variation: str,
        group_key: str | None = None,
    ) -> dict[str, hist.Hist]:
        available_datasets = list(self.merged_hists.keys())
        if group_key is not None:
            available_datasets = [ds for ds in available_datasets if group_key in self.merged_hists[ds]]

        if datasets is None:
            plot_datasets = available_datasets
        else:
            plot_datasets = []
            for pattern in datasets:
                regex = re.compile(pattern)
                plot_datasets.extend([ds for ds in available_datasets if regex.search(ds)])

            plot_datasets = list(set(plot_datasets))

        filtered_datasets = []
        for ds in plot_datasets:
            if ds.lower().startswith("data"):
                if years is not None:
                    ds_year = int(ds.split("_")[1])
                    if ds_year in years:
                        filtered_datasets.append(ds)
            else:
                filtered_datasets.append(ds)

        plot_datasets = filtered_datasets

        filtered_datasets = []
        for ds in plot_datasets:
            if ds.lower().startswith("data") or ds.lower().startswith("signal_"):
                filtered_datasets.append(ds)
            else:
                if campaigns is not None:
                    ds_campaign = ds.split("_")[-1]
                    if ds_campaign in campaigns:
                        filtered_datasets.append(ds)

        plot_datasets = filtered_datasets

        if len(plot_datasets) == 0:
            raise ValueError("No valid datasets found to merge!")

        dataset_hists: dict[str, hist.Hist] = {}
        for dataset in plot_datasets:
            ds_hists = self.merged_hists[dataset][group_key] if group_key is not None else self.merged_hists[dataset]

            if variation not in ds_hists:
                raise ValueError(f"Variation '{variation}' not found for variable '{variable}' in dataset '{dataset}'.")

            if variable not in ds_hists[variation]:
                raise ValueError(
                    f"Variable '{variable}' not found in dataset '{dataset}'. Have: {list(ds_hists[variation].keys())}."
                )

            dataset_hists[dataset] = ds_hists[variation][variable]

        return dataset_hists

    @staticmethod
    def merge_requested_hists(
        dataset_hists: dict[str, hist.Hist],
        plot_signals: list[str] | None = None,
    ) -> tuple[dict[str, hist.Hist], dict[str, hist.Hist], dict[str, hist.Hist]]:
        grouped_data_hists: dict[str, hist.Hist] = {}
        grouped_samples_hists: dict[str, hist.Hist] = {}
        grouped_signals_hists: dict[str, hist.Hist] = {}

        for ds_name, ds_hist in dataset_hists.items():
            if ds_name.lower().startswith("signal_"):
                is_signal = True
            else:
                is_signal = False

            if plot_signals is None and is_signal:
                continue

            if ds_name.lower().startswith("data"):
                is_data = True
            else:
                is_data = False

            if plot_signals is not None and is_signal:
                signal_name = ds_name.split("_MC")[0]

                if signal_name not in plot_signals:
                    continue

                if signal_name not in grouped_signals_hists:
                    grouped_signals_hists[signal_name] = copy.deepcopy(ds_hist)
                else:
                    grouped_signals_hists[signal_name] += ds_hist

            elif is_data:
                if "data" not in grouped_data_hists:
                    grouped_data_hists["data"] = copy.deepcopy(ds_hist)
                else:
                    grouped_data_hists["data"] += ds_hist

            else:
                ds_mc_name = ds_name.split("_MC")[0]

                if ds_mc_name not in grouped_samples_hists:
                    grouped_samples_hists[ds_mc_name] = copy.deepcopy(ds_hist)
                else:
                    grouped_samples_hists[ds_mc_name] += ds_hist

        return grouped_data_hists, grouped_samples_hists, grouped_signals_hists

    def group_hists_by_dataset(self, samples_hists: dict[str, hist.Hist]) -> dict[str, hist.Hist]:
        # first, build a mapping of dataset -> required samples
        dataset_to_samples: dict[str, set[str]] = {}
        for sample_name in samples_hists.keys():
            datasets = self.ds_handler.dataset_from_sample(sample_name)
            for dataset in datasets:
                if dataset.dataset_name not in dataset_to_samples:
                    dataset_to_samples[dataset.dataset_name] = set(dataset.samples)

        # check which datasets have all their required samples present
        valid_datasets: set[str] = set()
        for dataset_name, required_samples in dataset_to_samples.items():
            if required_samples.issubset(samples_hists.keys()):
                valid_datasets.add(dataset_name)

        # now group only the valid datasets
        grouped_hists: dict[str, hist.Hist] = {}
        for sample_name, sample_hist in samples_hists.items():
            datasets = self.ds_handler.dataset_from_sample(sample_name)

            for dataset in datasets:
                if dataset.dataset_name in valid_datasets:
                    if dataset.dataset_name not in grouped_hists:
                        grouped_hists[dataset.dataset_name] = copy.deepcopy(sample_hist)
                    else:
                        grouped_hists[dataset.dataset_name] += sample_hist

        return grouped_hists

    @staticmethod
    def get_total_luminosity_from_mc(campaigns: list[str]) -> float:
        total_luminosity = 0.0

        for campaign in campaigns:
            total_luminosity += get_luminosity(campaign=campaign)

        return total_luminosity / 1000.0  # convert from pb^-1 to fb^-1

    @staticmethod
    def get_total_luminosity_from_data(years: list[int]) -> float:
        total_luminosity = 0.0

        for year in years:
            total_luminosity += get_luminosity(year=year)

        return total_luminosity / 1000.0  # convert from pb^-1 to fb^-1

    def merge_and_group(
        self,
        variable: str,
        datasets: list[str] | None = None,
        years: list[int] | None = None,
        campaigns: list[str] | None = None,
        variation: str = "nominal",
        plot_signals: list[str] | None = None,
        group_key: str | None = None,
    ) -> tuple[dict[str, hist.Hist], dict[str, hist.Hist], dict[str, hist.Hist]]:
        dataset_hists = self.get_dataset_hists(variable, datasets, years, campaigns, variation, group_key=group_key)

        data_hists, samples_hists, signals_hists = self.merge_requested_hists(dataset_hists, plot_signals=plot_signals)
        grouped_samples_hists = self.group_hists_by_dataset(samples_hists)

        return data_hists, grouped_samples_hists, signals_hists
