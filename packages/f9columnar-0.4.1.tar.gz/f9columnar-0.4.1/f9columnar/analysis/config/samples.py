from dataclasses import dataclass

from f9columnar.analysis.plotting.labels import switch_on_label

DEFAULT_SAMPLE_DATASETS = {
    "VH": [
        "VH",
    ],
    "diboson": [
        "diboson",
    ],
    "dijet": [
        "dijet",
    ],
    "Wjets": [
        "Wjets",
    ],
    "Zjets": [
        "Zjets",
        "Zjets_light",
    ],
    "singletop_dilepton_DR": [
        "singletop_dilepton_Wt_DR_dyn",
        "singletop_inclusive_noWt",
    ],
    "singletop_dilepton_DS": [
        "singletop_dilepton_Wt_DS_dyn",
    ],
    "singletop_inclusive_DR": [
        "singletop_inclusive_Wt_DR_dyn",
        "singletop_inclusive_noWt",
    ],
    "singletop_inclusive_DS": [
        "singletop_inclusive_Wt_DS_dyn",
    ],
    "othertop": [
        "ttH",
        "ttH_cc",
        "ttW",
        "ttZ",
        "raretop",
    ],
    "ttbar_inclusive_sliced": [
        "ttbar_inclusive",
        "ttbar_inclusive_sliced_HT",
        "ttbar_inclusive_sliced_MET",
    ],
    "ttbar_dilepton": [
        "ttbar_dilepton",
    ],
}


@dataclass
class SamplesDataset:
    dataset_name: str
    samples: list[str]

    def __post_init__(self):
        self._label = switch_on_label(self.dataset_name)

    @property
    def label(self):
        return self._label

    def __contains__(self, sample_name: str) -> bool:
        return sample_name in self.samples


class DatasetHandler:
    def __init__(self, sample_datasets: dict[str, list[str]] | None = None) -> None:
        self.datasets: dict[str, SamplesDataset] = {}

        if sample_datasets is None:
            sample_datasets = DEFAULT_SAMPLE_DATASETS

        for ds_name, ds_samples in sample_datasets.items():
            self.datasets[ds_name] = SamplesDataset(ds_name, ds_samples)

    def samples_from_dataset(self, dataset_name: str) -> SamplesDataset:
        """Given a dataset name, return the corresponding SamplesDataset object."""
        return self.datasets.get(dataset_name, SamplesDataset(dataset_name, [dataset_name]))

    def dataset_from_sample(self, sample_name: str) -> list[SamplesDataset]:
        """Given a sample name, return all datasets that contain this sample."""
        matching_datasets: list[SamplesDataset] = []

        for dataset in self.datasets.values():
            if sample_name in dataset:
                matching_datasets.append(dataset)

        if not matching_datasets:
            matching_datasets = [SamplesDataset(sample_name, [sample_name])]

        return matching_datasets
