from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Type

from f9columnar.analysis.utils import VALID_VARIATIONS, VALID_VARIATIONS_SORTED
from f9columnar.processors import Processor


def decorate_branches(*branch_mappings: tuple[str, str] | str, varied: bool | str = "auto") -> Callable:
    """Decorator to attach branches to Processor classes.

    This decorator automatically attaches specified branches to a Processor instance
    during initialization. It can handle both simple branch names and branch-alias
    mappings, with automatic or explicit control over systematic variation handling.

    Parameters
    ----------
    *branch_mappings : tuple[str, str] | str
        Variable-length list of branch specifications. Each can be either:
          - A string: the branch name (e.g., "lepton_pt")
          - A tuple: (branch_name, branch_alias) for renaming (e.g., ("mu_pt", "lepton_pt"))
    varied : bool | str, optional
        Controls whether branches are treated as varied systematics:
          - "auto" (default): Infers from branch name. Branches ending with "_NOSYS"
            are marked as varied (True), others as non-varied (False).
          - True: All branches are marked as varied systematics.
          - False: All branches are marked as non-varied (nominal).

    Returns
    -------
    Callable
        Decorator function that modifies the Processor class.

    Examples
    --------
    Attach simple branches with automatic variation detection:

    >>> @decorate_branches("el_eta", "el_pt_NOSYS")
    ... class MyProcessor(Processor):
    ...     pass

    Attach branches with aliases:

    >>> @decorate_branches(
    ...     "el_eta",
    ...     "el_phi",
    ...     ("el_pt_NOSYS", "lepton_pt"),
    ...     ("el_eta", "lepton_eta")
    ... )
    ... class MyProcessor(Processor):
    ...     pass

    Force all branches to not be varied:

    >>> @decorate_branches("el_pt_NOSYS", "mu_pt_NOSYS", varied=False)
    ... class MyProcessor(Processor):
    ...     pass

    Notes
    -----
      - The decorator wraps the class's __init__ method to call attach_branch()
        for each specified branch before calling post_init().
      - Branch naming convention; "_NOSYS" suffix indicates systematic variations
        when using varied="auto".
      - Internally, branches are managed by the BranchCollection class within the Processor.
      - Systematics are handled by the vary() decorator.

    """

    def decorator(processor_class: Type) -> Type:
        original_init = processor_class.__init__

        @wraps(original_init)
        def new_init(obj: Processor, *args: Any, **kwargs: Any) -> None:
            original_init(obj, *args, **kwargs)
            for branch in branch_mappings:
                if varied == "auto":
                    if type(branch) is tuple:
                        is_varied = True if "_NOSYS" in branch[0] else False
                    elif type(branch) is str:
                        is_varied = True if "_NOSYS" in branch else False
                    else:
                        raise TypeError(f"Unsupported type {type(branch)} for branch!")
                elif type(varied) is bool:
                    is_varied = varied
                else:
                    raise TypeError(f"Unsupported type {type(varied)} for is_varied!")

                obj.attach_branch(branch, is_varied=is_varied)

            obj.post_init()

        processor_class.__init__ = new_init
        return processor_class

    return decorator


class BranchFilter:
    def __init__(self, nominal_only: bool = True, filter_out: list[str] | None = None) -> None:
        self.nominal_only = nominal_only

        if filter_out is not None:
            invalid_vars = [v for v in filter_out if v not in VALID_VARIATIONS]
            if len(invalid_vars) > 0:
                raise ValueError(f"Invalid variations in filter_out: {invalid_vars}!")

        self.filter_out_set = set(filter_out) if filter_out else None

        self.branches_set: set[str] = set()
        self.varied_branches: list[tuple[str, int]] = []  # store (prefix, length)

    def add_branch(self, branch: str, is_varied: bool = False) -> BranchFilter:
        if is_varied:
            if not branch.endswith("_NOSYS"):
                raise ValueError(f"Varied branch {branch} must end with _NOSYS!")

            self.branches_set.add(branch)

            prefix = branch.replace("_NOSYS", "_")
            prefix_with_len = (prefix, len(prefix))

            if prefix_with_len not in self.varied_branches:
                self.varied_branches.append(prefix_with_len)
        else:
            self.branches_set.add(branch)

        return self

    def __call__(self, branch: str) -> bool:
        if branch in self.branches_set:
            return True

        if self.nominal_only or "__" not in branch:
            return False

        branch_len = len(branch)

        for prefix, prefix_len in self.varied_branches:
            if not branch.startswith(prefix):
                continue

            if branch_len <= prefix_len:
                continue

            suffix = branch[prefix_len:]

            variation_type = None
            for v in VALID_VARIATIONS_SORTED:
                if v in suffix:
                    variation_type = v
                    break

            if variation_type is None:
                return False

            if not suffix.startswith(variation_type):
                return False

            if self.filter_out_set is None:
                return True

            if any(v in suffix for v in self.filter_out_set):
                return False

            return True

        return False


class ProcessorsCollection:
    def __init__(
        self,
        collection_name: str,
        *objects: Processor,
        nominal_only: bool = True,
        filter_out_variations: list[str] | None = None,
    ) -> None:
        self.collection_name = collection_name
        self.nominal_only = nominal_only

        self.objects: dict[str, Processor] = {}

        for obj in objects:
            if obj.name in self.objects:
                raise ValueError(f"{obj.name} already exists in the {self.collection_name} collection!")
            else:
                self.objects[obj.name] = obj

        self.branch_filter = BranchFilter(nominal_only, filter_out_variations)
        self._get_branch_names()

    def __getitem__(self, name: str) -> Processor:
        return self.objects[name]

    def _add_processor(self, processor: Processor) -> None:
        # check if processor being added is unique
        if processor in self.objects.values():
            raise ValueError(f"{processor.name} already exists in the {self.collection_name} collection!")

        # check if name of unique processor being added is unique
        if processor.name in self.objects:
            raise ValueError(
                f'Processor with name "{processor.name}" already exists in the {self.collection_name} collection! Choose a unique name.'
            )

        self.objects[processor.name] = processor

    def add(self, *objs: Processor | ProcessorsCollection) -> ProcessorsCollection:
        for obj in objs:
            if isinstance(obj, ProcessorsCollection):
                for v in obj.objects.values():
                    self._add_processor(v)
                    self._get_branch_names(v)
            elif isinstance(obj, Processor):
                self._add_processor(obj)
                self._get_branch_names(obj)
            else:
                raise ValueError(f"Invalid object type {type(obj)}!")

        return self

    def __add__(self, other: list | Processor | ProcessorsCollection) -> ProcessorsCollection:
        if type(other) is list:
            return self.add(*other)
        elif isinstance(other, Processor) or isinstance(other, ProcessorsCollection):
            return self.add(other)
        else:
            raise ValueError(f"Invalid object type {type(other)}!")

    def _get_branch_names(self, object_proc: Processor | None = None) -> ProcessorsCollection:
        if object_proc is None:
            object_values = list(self.objects.values())
        else:
            object_values = [object_proc]

        # legacy support for branch_name and branch_names attributes
        for v in object_values:
            if not hasattr(v, "branch_name") and not hasattr(v, "branch_names"):
                continue

            attr_branch_name = getattr(v, "branch_name", None)
            attr_branch_names = getattr(v, "branch_names", None)

            if attr_branch_name is not None and attr_branch_names is not None:
                raise ValueError(f"Both branch_name and branch_names are defined for {v.name}!")

            if attr_branch_name is not None:
                v.attach_branch(attr_branch_name)
                self.branch_filter.add_branch(attr_branch_name, is_varied=False)

            if attr_branch_names is not None:
                for br in attr_branch_names:
                    v.attach_branch(br)
                    self.branch_filter.add_branch(br, is_varied=False)

            v.post_init()  # decorator also runs post_init

        # decorator support for branches
        for v in object_values:
            branch_names = v.branches

            if len(branch_names) == 0:
                continue

            for br in branch_names:
                self.branch_filter.add_branch(br, is_varied=False)

        # decorator support for varied branches
        for v in object_values:
            var_branch_names = v.varied_branches

            if len(var_branch_names) == 0:
                continue

            for br in var_branch_names:
                self.branch_filter.add_branch(br, is_varied=True if not self.nominal_only else False)

        return self

    def get_branch_name_filter(self) -> BranchFilter:
        return self.branch_filter

    def as_list(self) -> list[Processor]:
        return list(self.objects.values())

    def __str__(self) -> str:
        str_output = f"Object Collection\n{17 * '-'}\n"

        for name, obj in self.objects.items():
            str_output += f"{name}: {str(obj)}\n"

        return str_output[:-1]
