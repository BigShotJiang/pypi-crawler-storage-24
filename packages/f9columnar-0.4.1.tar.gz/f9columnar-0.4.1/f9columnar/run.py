from __future__ import annotations

import gc
import logging
import os
import shutil
import time
from pathlib import Path
from typing import Sequence

from torch.utils.data import DataLoader

from f9columnar.dataset_builder import PhysicsDataset
from f9columnar.processors import PostprocessorsGraph, Processor, ProcessorsGraph
from f9columnar.utils.cut_flow import CutFlow, TimeFlow
from f9columnar.utils.loggers import Progress, get_progress_events, timeit


class ColumnarEventLoop:
    def __init__(
        self,
        mc_datasets: Sequence[PhysicsDataset] | None = None,
        data_datasets: Sequence[PhysicsDataset] | None = None,
        postprocessors_graph: PostprocessorsGraph | None = None,
        fit_postprocessors: bool = False,
        cut_flow: bool = False,
        no_plot_cut_flow: bool = False,
        disable_rich: bool = False,
        local_job_name: str | None = None,
        save_path: str | None = None,
    ) -> None:
        """Event processing pipeline for physics datasets with fitted processors and postprocessors.

        The event loop processes datasets in parallel using PyTorch DataLoaders, applies transformations
        through processor graphs, and can optionally track performance metrics and selection efficiency.
        Results can be saved to disk for later analysis or visualization.

        Parameters
        ----------
        mc_datasets : Sequence[PhysicsDataset] | None, optional
            MC datasets to process. Each dataset should contain a configured DataLoader
            and metadata. Default is None.
        data_datasets : Sequence[PhysicsDataset] | None, optional
            Data datasets to process. Each dataset should contain a configured DataLoader
            and metadata. Default is None.
        postprocessors_graph : PostprocessorsGraph | None, optional
            Graph of postprocessors to fit and execute after processing. Runs single threaded.
            Default is None.
        fit_postprocessors : bool, optional
            Whether to fit postprocessors during event loop execution. If False, the loop returns
            fitted processors for MC and data separately without running postprocessors. Default is False.
        cut_flow : bool, optional
            Enable cut flow and time flow monitoring. When True, tracks the number of events passing
            each selection cut and the execution time of each processor. Can be globally disabled
            via the COLUMNAR_DISABLE_CUT_FLOW environment variable. Default is False.
        no_plot_cut_flow : bool, optional
            Suppress automatic cut flow plotting after each dataset while still updating internal
            state. Useful for batch processing where plots are only needed at the end. Default is False.
        disable_rich : bool, optional
            Disable the rich progress bar visualization. Useful for non-interactive environments
            or logging to files. Default is False.
        local_job_name : str | None, optional
            Optional name for the local job, used for organizing output directories.
        save_path : str | None, optional
            Directory path where fitted processors and postprocessor results will be saved.
            If None, no results are saved to disk. The directory will be created if it doesn't exist.
            Default is None.

        Attributes
        ----------
        use_cut_flow : bool
            Internal flag indicating whether cut/time flow tracking is active.
        cut_flow : CutFlow
            Cut flow tracker instance (only if `use_cut_flow` is True).
        time_flow : TimeFlow
            Time flow tracker instance (only if `use_cut_flow` is True).

        Methods
        -------
        run(mc_only=False, data_only=False)
            Execute the event loop on configured datasets.
        """
        self.mc_datasets = mc_datasets
        self.data_datasets = data_datasets
        self.postprocessors_graph = postprocessors_graph
        self.fit_postprocessors = fit_postprocessors
        self.save_path = save_path

        if cut_flow and not os.environ.get("COLUMNAR_DISABLE_CUT_FLOW", "0") == "1":
            logging.info("[yellow]Cut flow enabled![/yellow]")
            self.use_cut_flow = True
            self.cut_flow, self.time_flow = CutFlow(save_path), TimeFlow(save_path)
        else:
            self.use_cut_flow = False

        self.no_plot_cut_flow = no_plot_cut_flow
        self.disable_rich = disable_rich
        self.local_job_name = local_job_name

        if self.local_job_name is not None and self.save_path is not None:
            out_path = Path(self.save_path) / "out"

            shutil.rmtree(out_path, ignore_errors=True)
            out_path.mkdir(parents=True, exist_ok=True)

    def _fit_postprocessors(self, fitted_processors: dict[str, Processor], is_data: bool) -> None:
        if self.postprocessors_graph is None:
            return None

        self.postprocessors_graph.fit(fitted_processors, is_data=is_data)

    def _run_on_completed(
        self, fitted_processors: dict[str, Processor], is_data: bool, dataset_name: str, worker_id: int
    ) -> None:
        if self.save_path is not None:
            os.makedirs(self.save_path, exist_ok=True)

            if is_data:
                save_name = f"ds_{dataset_name}_id_{worker_id}"
            else:
                save_name = f"ds_{dataset_name}_id_{worker_id}"

            if self.local_job_name is not None:
                i = 0
                while True:
                    local_save_dir = f"f9col_{dataset_name}_{self.local_job_name}_{i}"
                    save_path = os.path.join(self.save_path, "out", local_save_dir, "out")
                    if not os.path.exists(save_path):
                        os.makedirs(save_path, exist_ok=True)
                        break
                    i += 1
            else:
                save_path = self.save_path

            for proc in fitted_processors.values():
                proc.save(save_path=save_path, save_name=f"proc_{proc.name}_{save_name}")

        for proc in fitted_processors.values():
            proc.finalize()

    def _iterate_processors(
        self,
        dataloader: DataLoader,
        num_entries: int,
        is_data: bool,
        dataset_name: str,
        progress: Progress | None = None,
    ) -> int:
        if progress is not None:
            dl_bar = progress.add_task(f"Iterating dataloader for {dataset_name}", total=num_entries)

        total = 0
        fitted_graphs: dict[int, ProcessorsGraph] = {}

        for fitted_graph in dataloader:
            fitted_processors = fitted_graph.processors

            fitted_graphs[fitted_graph.worker_id] = fitted_graph

            if self.fit_postprocessors:
                self._fit_postprocessors(fitted_processors, is_data)

            if "input" in fitted_processors:
                n_events = fitted_processors["input"].n_events

                if progress is not None:
                    progress.update(dl_bar, advance=n_events)

                total += n_events

        for worker_id, completed_graph in fitted_graphs.items():
            completed_processors = completed_graph.processors

            if self.use_cut_flow:
                self.cut_flow.update(completed_processors, is_data)
                self.time_flow.update(completed_processors, is_data)

            self._run_on_completed(completed_processors, is_data, dataset_name, worker_id)

        if progress is not None:
            progress.remove_task(dl_bar)

        return total

    def _iterate_dataloaders(self, datasets: Sequence[PhysicsDataset], is_data: bool) -> ColumnarEventLoop:
        if not self.disable_rich:
            progress = get_progress_events()
            progress.start()
            ds_bar = progress.add_task("Iterating datasets", total=len(datasets), unit="")
        else:
            progress = None

        iter_total = 0

        for dataset in datasets:
            start_time = time.time()
            total = self._iterate_processors(dataset.dataloader, dataset.num_entries, is_data, dataset.name, progress)

            total_time = time.time() - start_time
            iter_total += total

            if progress is not None:
                progress.update(ds_bar, advance=1)

            if self.use_cut_flow:
                only_dump = self.no_plot_cut_flow
                self.time_flow.plot(is_data, dataset.name, total, total_time, only_dump).reset()
                self.cut_flow.plot(is_data, dataset.name, only_dump).reset()

            dataset.dataloader, dataset.file_desc_dct = None, None  # type: ignore[assignment]
            gc.collect()

        if progress is not None:
            progress.stop()

        logging.info(f"Total number of events processed: {iter_total}")

        return self

    @timeit(unit="s")
    def run(self, mc_only: bool = False, data_only: bool = False) -> ColumnarEventLoop:
        if mc_only and data_only:
            raise ValueError("Cannot run both MC and data only!")

        logging.info("[red][bold]Running columnar event loop![/bold][red]")

        if mc_only:
            if self.mc_datasets is None:
                raise ValueError("No MC datasets found!")

            self._iterate_dataloaders(self.mc_datasets, is_data=False)
        elif data_only:
            if self.data_datasets is None:
                raise ValueError("No data datasets found!")

            self._iterate_dataloaders(self.data_datasets, is_data=True)
        else:
            if self.mc_datasets is None or self.data_datasets is None:
                raise ValueError("No MC or data datasets found!")

            self._iterate_dataloaders(self.mc_datasets, is_data=False)
            self._iterate_dataloaders(self.data_datasets, is_data=True)

        logging.info("[red][bold]Done running columnar event loop![/bold][red]")

        if self.fit_postprocessors:
            if self.postprocessors_graph is None:
                raise ValueError("No postprocessors found!")

            for postprocessor in self.postprocessors_graph.processors.values():
                if self.save_path is not None:
                    postprocessor.save(save_path=self.save_path, save_name="postprocessor_result")

                postprocessor.finalize()

        return self
