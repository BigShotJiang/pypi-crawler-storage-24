from __future__ import annotations

import copy
import os
from dataclasses import dataclass
from functools import wraps
from typing import Any, Callable

import awkward as ak
import numpy as np

from f9columnar.analysis.utils import VALID_BRANCH_GROUPS, VALID_VARIATIONS, find_variation_in_branch
from f9columnar.arrays import GroupArrays
from f9columnar.processors import Processor, count_events
from f9columnar.utils.helpers import load_json
from f9columnar.utils.variations_json import get_variations_json


@dataclass
class Nominal:
    nominal: str
    systs: set[str]
    is_theory: bool = False


@dataclass
class Variation:
    variation_name: str
    effects: set[str]
    is_theory: bool = False

    def __add__(self, other: Variation) -> Variation:
        if self.variation_name != other.variation_name:
            raise ValueError("Cannot add variations with different names!")

        combined_effects = self.effects | other.effects
        self.effects = combined_effects

        return self


class VariationMap:
    def __init__(
        self, sys_map_path: str = "", filter_out: list[str] | None = None, loaded_json_map: dict[str, Any] | None = None
    ) -> None:
        """Variation map for systematic variations.

        JSON file should have the following structure:
        "variations": {
            "physics_object_1": {
                "nominal_branch_1": ["syst_1", "syst_2", ...],
                "nominal_branch_2": ["syst_1", "syst_2", ...],
                ...
            },
            "physics_object_2": {
                "nominal_branch_1": ["syst_1", "syst_2", ...],
                ...
            },
            ...
        }

        Parameters
        ----------
        sys_map_path : str
            Path to systematic variation map JSON file.
        filter_out : list[str] | None
            List of substrings to filter out systematic variations. If any of these substrings are found in a variation
            name, that variation will be excluded from the map.
        loaded_json_map : dict[str, Any] | None
            Pre-loaded JSON map dictionary. If provided, sys_map_path will be ignored.

        """
        if filter_out is None:
            self.filtered = []
        else:
            for f in filter_out:
                if f not in VALID_VARIATIONS:
                    raise ValueError(f"Invalid filter_out variation type '{f}', must be one of {VALID_VARIATIONS}!")

            self.filtered = filter_out

        if loaded_json_map is not None:
            json_dct = loaded_json_map
        else:
            json_dct = load_json(sys_map_path)

        sys_map: dict[str, dict[str, list[str]]] = json_dct["variations"]
        sys_theory_lst: list[str] = json_dct["no_variations"].get("weight", [])

        sys_map["weight"].pop("weight_mc", None)

        for theory_sys in copy.deepcopy(sys_theory_lst):
            if not theory_sys.startswith("weight_mc_"):
                sys_theory_lst.remove(theory_sys)

        self._build_nominal_map(sys_map, sys_theory_lst)
        self._build_variation_map(sys_map, sys_theory_lst)

        self._group_variations()

    def _filter_systs(self, systs: list[str]) -> list[str]:
        filtered_systs = []
        for syst in systs:
            valid = True
            for f in self.filtered:
                if f in syst:
                    valid = False
                    break
            if valid:
                filtered_systs.append(syst)

        return filtered_systs

    def _build_nominal_map(self, sys_map: dict[str, dict[str, list[str]]], sys_theory_lst: list[str]) -> None:
        self.nominals: dict[str, Nominal] = {}

        if "GEN" not in self.filtered:
            self.nominals["weight_mc"] = Nominal("weight_mc", systs=set(sys_theory_lst), is_theory=True)
        else:
            self.nominals["weight_mc"] = Nominal("weight_mc", systs=set(), is_theory=True)

        for var_dct in sys_map.values():
            for nominal, systs in var_dct.items():
                systs = self._filter_systs(systs)
                nom = Nominal(nominal, systs=set(systs))
                self.nominals[nominal] = nom

    def _build_variation_map(self, sys_map: dict[str, dict[str, list[str]]], sys_theory_lst: list[str]) -> None:
        inverted_sys_map = self._invert_sys_map(sys_map)

        self.variations: dict[str, Variation] = {}

        if "GEN" not in self.filtered:
            for theory_sys in sys_theory_lst:
                self.variations[theory_sys] = Variation(theory_sys, effects={"weight_mc"}, is_theory=True)

        for var_dct in inverted_sys_map.values():
            for variation, nominals in var_dct.items():
                sys_var = Variation(variation, set(nominals))
                if variation not in self.variations:
                    self.variations[variation] = sys_var
                else:
                    self.variations[variation] += sys_var

    def _invert_sys_map(self, sys_map: dict[str, dict[str, list[str]]]) -> dict[str, dict[str, list[str]]]:
        inverted_map: dict[str, dict[str, list[str]]] = {}

        for key, var_dct in sys_map.items():
            inverted_map[key] = {}
            for nominal, systs in var_dct.items():
                systs = self._filter_systs(systs)
                for syst in systs:
                    if syst not in inverted_map[key]:
                        inverted_map[key][syst] = []

                    if nominal not in inverted_map[key][syst]:
                        inverted_map[key][syst].append(nominal)

        return inverted_map

    def _group_variations(self) -> None:
        self.variation_groups: dict[str, set[str]] = {group: set() for group in VALID_BRANCH_GROUPS}

        for nominal_branch, systs in self.nominals.items():
            if nominal_branch == "weight_mc":
                if "gen" not in self.variation_groups:
                    self.variation_groups["gen"] = set()

                for syst in systs.systs:
                    self.variation_groups["gen"].add(syst)

                continue

            for group in VALID_BRANCH_GROUPS:
                if nominal_branch.startswith(f"{group}_"):
                    for syst in systs.systs:
                        self.variation_groups[group].add(syst)

    def from_nominal(self, nominal: str, variation: str | None = None, add_to_map: bool = False) -> Nominal | None:
        if nominal.endswith("_NOSYS"):
            nominal = nominal.split("_NOSYS")[0]

        if variation is not None and add_to_map:
            self._add_to_map(nominal, variation)

        if nominal not in self.nominals:
            return None

        return self.nominals[nominal]

    def from_variation(self, variation: str) -> Variation:
        if variation not in self.variations:
            raise KeyError(f"Variation {variation} not found in VariationMap!")

        return self.variations[variation]

    def _add_to_map(self, nominal: str, syst: str, is_theory: bool = False) -> None:
        if syst == "nominal":
            return None

        if nominal not in self.nominals:
            self.nominals[nominal] = Nominal(nominal, systs=set(), is_theory=is_theory)

        if syst in self.nominals[nominal].systs:
            return None

        self.nominals[nominal].systs.add(syst)

        if syst not in self.variations:
            self.variations[syst] = Variation(syst, effects=set(), is_theory=is_theory)

        self.variations[syst].effects.add(nominal)

    def __str__(self) -> str:
        return f"VariationMap(N_nominal={len(self.nominals)}, N_variation={len(self.variations)})"

    def __repr__(self) -> str:
        return self.__str__()


class VariedArrays:
    def __init__(self) -> None:
        self.arrays: dict[str, dict[str, GroupArrays]] = {}
        self.variations_set: set[str] = set()

        self.count_events: bool = True

    def add_arrays(self, variation: str, arrays: GroupArrays, variation_type: str = "nominal") -> None:
        if variation_type not in ["nominal", "1up", "1down"]:
            raise ValueError(f"Invalid variation_type '{variation_type}.")

        if variation_type not in self.arrays:
            self.arrays[variation_type] = {}

        self.arrays[variation_type][variation] = arrays

        self.variations_set.add(variation)

    def get_variation(self, variation: str, variation_type: str = "nominal") -> GroupArrays:
        if variation not in self.arrays:
            raise KeyError(f"Variation '{variation}' not found in VariedArrays.")

        if variation_type not in ["nominal", "1up", "1down"]:
            raise ValueError(f"Invalid variation_type '{variation_type}.")

        return self.arrays[variation_type][variation]

    def __contains__(self, variation: str) -> bool:
        return variation in self.variations_set

    def __len__(self) -> int:
        key_1 = list(self.arrays.keys())[0]
        key_2 = list(self.arrays[key_1].keys())[0]

        group = self.arrays[key_1][key_2].groups[0]

        return len(self.arrays[key_1][key_2][group])


def _build_varied_arrays(arrays: GroupArrays, nominal_only: bool = False) -> VariedArrays:
    """Helper function to build VariedArrays from GroupArrays.

    Parameters
    ----------
    arrays : GroupArrays
        Input GroupArrays containing all branches.
    nominal_only : bool, optional
        If True, only the nominal variation is included. Default is False.

    Returns
    -------
    VariedArrays
        A VariedArrays object containing the nominal and varied arrays.

    """

    varied_arrays = VariedArrays()

    varied_arrays.add_arrays("nominal", arrays.deepcopy(variation="nominal"), variation_type="nominal")

    if nominal_only:
        return varied_arrays

    all_variations: set[str] = set()

    for branch in arrays.fields:
        variation = find_variation_in_branch(branch)
        if variation is not None:
            all_variations.add(variation)

    for variation in sorted(all_variations):
        for variation_type in ["1up", "1down"]:
            varied_arrays.add_arrays(variation, arrays.deepcopy(variation=variation), variation_type=variation_type)

    return varied_arrays


def _run_vary_func(
    func: Callable,
    obj: Processor,
    group_arrays: GroupArrays,
    varied_arrays: VariedArrays,
    return_key: str,
    variation_type: str,
    variation: str = "nominal",
) -> None:
    # before processing, record event counts
    if varied_arrays.count_events and not obj._skip_auto_count:
        start_event_n = len(group_arrays)
        start_groups_n = group_arrays.count_group_particles()

    # apply the original function to each GroupArrays
    result = func(obj, group_arrays)

    # after processing, record event counts
    if varied_arrays.count_events and not obj._skip_auto_count:
        obj.set_event_count(start_event_n, len(result[return_key]), group="event")
        end_groups_n = result[return_key].count_group_particles()

        for group in group_arrays.groups:
            if group not in start_groups_n or group not in end_groups_n:
                continue

            if group == "other":
                continue

            obj.set_event_count(start_groups_n[group], end_groups_n[group], group=group)

    # store the result in the VariedArrays
    varied_arrays.add_arrays(variation, result[return_key], variation_type=variation_type)


def vary(
    return_key: str = "arrays", extra_filter: tuple[str, ...] | None = None, disable_count_events: bool = False
) -> Callable:
    """Decorator that unwraps VariedArrays, applies the function to each variation, and repackages the results.

    This decorator enables systematic variation processing by automatically handling the iteration over
    different systematic variations and their corresponding branches. It takes either VariedArrays or
    GroupArrays as input, processes each variation through the decorated function, and returns the
    results packaged back into a VariedArrays object.

    Parameters
    ----------
    return_key : str, optional
        The dictionary key for the return value in the decorated function's output
        dictionary, by default "arrays".
    extra_filter : tuple[str, ...] | None, optional
        Additional substrings to filter variations. Only branches NOT containing any of these
        variation substrings will get a current variation assigned, by default None.
    disable_count_events : bool, optional
        If True, disables counting events (cut flow) during variation processing, by default False.

    Returns
    -------
    Callable
        A decorator function that wraps the target processor method.

    Notes
    -----
    - If the input is GroupArrays, it first builds a VariedArrays structure using the processor's
      variation map and nominal_only setting.
    - If the input is already VariedArrays, it processes it directly.
    - For each non-nominal variation, the decorator:
        * Sets the processor's current variation context
        * Applies branch variations according to the variation map
        * Executes the decorated function
        * Stores the result in the output VariedArrays
    - The nominal variation is preserved without modification.

    Raises
    ------
    TypeError
        If the input arrays are neither GroupArrays nor VariedArrays.
    RuntimeError
        If the processor's variation_map is not initialized.

    Examples
    --------
    >>> @vary("arrays")
    ... def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
    ...     # Process arrays
    ...     return {"arrays": processed_arrays}

    See Also
    --------
    VariedArrays : Container for storing arrays across multiple variations
    GroupArrays : Container for storing arrays grouped by particle type
    VariationMap : Maps nominal branches to their systematic variations

    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(obj: Processor, arrays: VariedArrays | GroupArrays) -> dict[str, VariedArrays]:
            variation_map: VariationMap | None = obj.variation_map

            if variation_map is None or obj.disable_variations:
                return count_events(func, disable=disable_count_events or obj._skip_auto_count)(obj, arrays)
            elif isinstance(arrays, GroupArrays):
                varied_arrays = _build_varied_arrays(arrays, nominal_only=obj.nominal_only)
                is_setup = True
            elif isinstance(arrays, VariedArrays):
                varied_arrays = arrays
                is_setup = False
            else:
                raise TypeError("Wrong type passed to vary decorator!")

            if is_setup:
                if os.environ.get("COLUMNAR_DISABLE_CUT_FLOW", "0") == "1":
                    varied_arrays.count_events = False
                else:
                    varied_arrays.count_events = not disable_count_events

            # loop over all variations
            for variation_type, varied_group_arrays in varied_arrays.arrays.items():
                for variation, group_arrays in varied_group_arrays.items():
                    if variation_type == "nominal":
                        obj.current_variation = "nominal"

                        _run_vary_func(func, obj, group_arrays, varied_arrays, return_key, variation_type, variation)
                        continue

                    if extra_filter is not None and any(f in variation for f in extra_filter):
                        continue

                    current_variation = f"{variation}__{variation_type}"

                    obj.current_variation = current_variation

                    for branch in obj.varied_branches:
                        if branch in obj.branches_by_processor:  # new branch added by processor
                            new_branch_group = branch.split("_")[0]

                            if variation not in variation_map.variation_groups[new_branch_group]:
                                add_to_map = False
                            else:
                                # should be added to map because it was newly created
                                add_to_map = True
                        else:
                            add_to_map = False

                        branch_nominals = variation_map.from_nominal(branch, variation=variation, add_to_map=add_to_map)

                        if branch_nominals is None:
                            continue

                        if variation in branch_nominals.systs:
                            obj.vary_branch(branch, current_variation)

                    _run_vary_func(func, obj, group_arrays, varied_arrays, return_key, variation_type, variation)

                    # reset branches to nominal after processing
                    for branch in obj.varied_branches:
                        obj.reset_branch_variation(branch)

            return {return_key: varied_arrays}

        wrapper._applied_vary_decorator = True  # type: ignore[attr-defined]
        return wrapper

    return decorator


class VariationsProcessor(Processor):
    def __init__(self, nominal_only: bool = True, filter_out: list[str] | None = None, key="physics") -> None:
        """Processor for initializing and managing systematic variations in the analysis workflow.

        This processor sets up the variation map that defines how nominal branches map to their
        systematic variations. It extracts variation information from the input file's metadata
        and creates a VariationMap object that can be used by downstream processors to handle
        systematic uncertainties.

        Parameters
        ----------
        nominal_only : bool, optional
            If True, only process nominal (central value) data without variations. If False, load and process
            all systematic variations. Default is True.
        filter_out : list[str] or None, optional
            List of variation types to exclude from processing. Useful for filtering out
            specific systematic uncertainty categories. Default is None (no filtering).
        key : str, optional
            The key used to access variation metadata in the input file. Default is "physics".

        Attributes
        ----------
        _variation_map : VariationMap or None
            The variation map object containing nominal-to-systematic branch mappings.
            Initialized on first run if nominal_only is False, otherwise remains None.

        Notes
        -----
        - The processor does not modify the input arrays; it only initializes the variation map.
        - The variation map is loaded lazily on the first call to run(), using the file path
          from the processor reports.
        - If nominal_only is True, no variation map is created, and downstream processors
          will only process nominal data.
        - The variation map can be accessed by other processors that need to apply systematic
          variations to branches.

        Returns
        -------
        dict[str, ak.Array]
            Dictionary with a single key "arrays" containing the unmodified input arrays.

        """
        super().__init__(name="variations", disable_variations=True)
        self._nominal_only = nominal_only
        self.filter_out = filter_out
        self.key = key

        self._variation_map: VariationMap | None = None

    def run(self, arrays: ak.Array) -> dict[str, ak.Array]:
        if self._variation_map is None and not self._nominal_only:
            current_file_path = self.reports["file_path"]  # type: ignore[index]
            json_map = get_variations_json(current_file_path, key=self.key)
            self._variation_map = VariationMap(filter_out=self.filter_out, loaded_json_map=json_map)

        return {"arrays": arrays}


class StartVariations(Processor):
    def __init__(self, add_event_weights: bool = False, ones_like_key: str = "runNumber", prefix: str = "") -> None:
        """First processor in the variations chain to initialize event weights if needed.

        Parameters
        ----------
        add_event_weights : bool, optional
            If True, adds an event weight array of ones to the 'other' group in the arrays, by default False.
        ones_like_key : str, optional
            The key in the arrays to use as a template for the shape of the event weights array, by default "runNumber".
        prefix : str, optional
            Prefix for the processor name, by default "".

        Note
        ----
        This processor is typically used at the start of a processing chain to ensure that
        an event weight array is available for further processing, especially when systematic
        variations are being applied. After this processor runs, subsequent processors should
        all have the vary decorator applied to handle variations correctly. If not using
        the vary decorator in later processors, the return will be VarriedArrays instead of
        GroupArrays.

        """
        super().__init__(name=f"{prefix}startVariations")
        self.add_event_weights = add_event_weights
        self.ones_like_key = ones_like_key

    @vary("arrays")
    def run(self, arrays: GroupArrays) -> dict[str, GroupArrays]:
        if self.add_event_weights:
            weights = ak.ones_like(arrays[self.ones_like_key], dtype=np.float64)
            arrays["other", "total_weight"] = weights

        return {"arrays": arrays}
