"""
Validation manifest generator for the VectorShift mypy plugin.

Reads pipeline_node.toml and generates _validation_manifest.json
which the mypy plugin uses to validate node constructor calls.

Usage:
    python -m vectorshift.pipeline.manifest_generator
"""

import json
import os
from typing import Any, Optional

from vectorshift.pipeline.stub_generator import (
    _load_toml,
    _load_dropdown_options,
    _to_class_name,
    _is_dynamic_node,
    _is_generic_field,
    _classify_params,
    _classify_params_by_output_impact,
    _enumerate_sig_param_combos,
    _compute_merged_inputs,
    _compute_required_and_causal,
    _extract_all_param_values,
    _get_type_alias_for_input,
    _matches_config_key,
)
from vectorshift.pipeline.interface_type_generator import (
    collect_interface_types,
    _canonical_key,
)
from vectorshift.pipeline.type_compatibility import (
    _BASE_TYPE_VALUES,
    is_vec,
    is_map,
    is_stream,
    is_enum,
    is_integration,
    is_interface,
)
from vectorshift.pipeline.node_generator import _NODE_CONFIG_OBJECTS

# Human-readable display names for VectorShift base types
_VS_TYPE_DISPLAY: dict[str, str] = {
    "string": "str",
    "int32": "int",
    "int64": "int",
    "float": "float",
    "bool": "bool",
    "json": "dict",
    "bytes": "bytes",
    "file": "file",
    "image": "image",
    "audio": "audio",
    "bucket_key": "str",
    "timestamp": "str",
    "path": "str",
    "any": "any",
    "dataframe": "dataframe",
    "table": "table",
    "chart": "chart",
    "knowledge_base": "KnowledgeBase",
    "pipeline": "Pipeline",
    "agent": "Agent",
    "transformation": "Transformation",
    "integration": "Integration",
    "null": "None",
    "stream": "stream",
    "variable_set": "VariableSet",
    "portal": "Portal",
    "project": "Project",
    "mcp_server": "any",
}


def _get_vs_base_type(toml_type: str) -> str:
    """Extract the VectorShift base type from a TOML type string."""
    if not toml_type or toml_type == "any":
        return "any"
    if toml_type in _BASE_TYPE_VALUES:
        return toml_type
    if is_vec(toml_type):
        return _get_vs_base_type(toml_type[4:-1])
    if is_enum(toml_type):
        return _get_vs_base_type(toml_type[5:-1])
    if is_stream(toml_type):
        return "stream"
    if is_map(toml_type) or is_interface(toml_type):
        return "json"
    if is_integration(toml_type):
        return "integration"
    return "any"


def _get_field_type_info(
    toml_type: str,
    interface_map: dict[tuple[tuple[str, str], ...], str] | None = None,
) -> dict[str, str]:
    """Build the {display, accepts, vs_type, toml_type} dict for a field."""
    vs_type = _get_vs_base_type(toml_type)
    display = _VS_TYPE_DISPLAY.get(vs_type, "any")

    # Get accepts alias from stub generator
    alias = _get_type_alias_for_input(toml_type)
    if alias:
        accepts = alias.removeprefix("vst.")
    else:
        accepts = "AcceptsAny"

    # Special display for compound types
    result: dict[str, Any] = {
        "display": display,
        "accepts": accepts,
        "vs_type": vs_type,
        "toml_type": toml_type,
    }
    if is_vec(toml_type):
        result["display"] = "list"
        result["is_list"] = True
        # Resolve inner interface type to TypedDict name for error messages
        if interface_map:
            inner = toml_type[4:-1]  # strip vec< >
            if inner.startswith("interface{") and inner.endswith("}"):
                canonical = _canonical_key(inner)
                td_name = interface_map.get(canonical)
                if td_name:
                    result["elem_type_name"] = td_name
    if is_map(toml_type) or is_interface(toml_type):
        result["display"] = "dict"
        result["is_dict"] = True

    return result


def _find_input_affecting_params(
    sig_params: list[str],
    params_list: list[str],
    defaults: dict,
    configs: dict,
    node_required: list[str],
) -> set[str]:
    """Find sig params that change required fields or available inputs."""
    affecting: set[str] = set()

    for p_idx, param in enumerate(sig_params):
        # Collect (required_fields, input_fields) for each value of this param
        signatures: set[tuple[frozenset[str], frozenset[str]]] = set()

        for config_key, config_data in configs.items():
            if not isinstance(config_data, dict):
                continue
            parts = config_key.split("**")
            full_p_idx = params_list.index(param) if param in params_list else -1
            if full_p_idx < 0 or full_p_idx >= len(parts):
                continue
            part = parts[full_p_idx]
            if (
                part == "(*)"
                or (part.startswith("(") and part.endswith(")"))
                or part.startswith("[<")
                or part.startswith("<")
            ):
                continue

            # Build param dict for this specific value
            test_params: dict[str, str] = {param: part}
            for p in params_list:
                if p not in test_params:
                    test_params[p] = "__wildcard__"

            merged = _compute_merged_inputs(test_params, defaults, configs, params_list)
            fields = frozenset(
                inp.get("field", "")
                for inp in merged
                if isinstance(inp, dict)
                and inp.get("field")
                and not _is_generic_field(inp.get("field", ""))
            )

            # Compute required
            config_req: set[str] = set()
            for ck, cd in configs.items():
                if not isinstance(cd, dict):
                    continue
                if _matches_config_key(ck, test_params, params_list):
                    cr = cd.get("required", [])
                    if isinstance(cr, list):
                        config_req.update(cr)
            all_req = frozenset(set(node_required) | config_req)

            signatures.add((all_req, fields))

        if len(signatures) > 1:
            affecting.add(param)

    return affecting


def _compute_conditional_fields(
    sig_params: list[str],
    params_list: list[str],
    defaults: dict,
    configs: dict,
    node_required: list[str],
    non_input_fields: set[str],
) -> dict[str, dict[str, dict]]:
    """Compute which non-sig params conditionally add/remove/require fields.

    Returns a mapping like:
        {"use_personal_api_key": {
            "param_default": "false",
            "true": {"adds": ["api_key"], "requires": ["api_key"]},
            "false": {"removes": ["api_key"]}
        }}
    """
    non_sig_params = [p for p in params_list if p not in sig_params]
    result: dict[str, dict[str, Any]] = {}

    # Fields with meaningful defaults — these shouldn't be marked as conditionally
    # required since the runtime will use their default values.
    # Exclude empty string defaults (value="") as those are placeholders.
    fields_with_defaults: set[str] = set()
    for input_def in defaults.get("inputs", []):
        if isinstance(input_def, dict):
            field = input_def.get("field", "")
            val = input_def.get("value")
            if field and val is not None and val != "":
                fields_with_defaults.add(field)
    for _ck, cd in configs.items():
        if not isinstance(cd, dict):
            continue
        for input_def in cd.get("inputs", []):
            if isinstance(input_def, dict):
                field = input_def.get("field", "")
                val = input_def.get("value")
                if field and val is not None and val != "":
                    fields_with_defaults.add(field)

    for param in non_sig_params:
        p_idx = params_list.index(param)

        # Collect explicit values for this param from config keys
        values: set[str] = set()
        for config_key in configs:
            parts = config_key.split("**")
            if p_idx >= len(parts):
                continue
            part = parts[p_idx]
            if (
                part == "(*)"
                or (part.startswith("(") and part.endswith(")"))
                or part.startswith("[<")
                or part.startswith("<")
            ):
                continue
            values.add(part)

        # For boolean params with only one explicit value, infer the complement.
        # e.g., if only "true" appears in config keys, add "false" as default.
        if len(values) == 1:
            v = next(iter(values))
            if v.lower() in ("true", "false"):
                complement = "false" if v.lower() == "true" else "true"
                values.add(complement)

        if len(values) < 2:
            continue  # No conditional effect with only one value

        # For each combination of other parameter values, determine which fields
        # are conditionally present based on this parameter. This captures conditional
        # logic that depends on interactions between multiple parameters.
        # Example: api_key is required only when use_personal_api_key is true for provider=openai,
        # but always required for provider=custom.
        other_params = [p for p in params_list if p != param]
        other_combos = _enumerate_sig_param_combos(other_params, params_list, configs)

        # Per-combo, per-value field sets
        combo_value_fields: dict[int, dict[str, set[str]]] = {}
        for ci, other_combo in enumerate(other_combos):
            combo_value_fields[ci] = {}
            for val in values:
                test_params: dict[str, str] = dict(other_combo)
                test_params[param] = val
                for p in params_list:
                    if p not in test_params:
                        test_params[p] = "__wildcard__"

                merged = _compute_merged_inputs(
                    test_params, defaults, configs, params_list
                )
                fields: set[str] = set()
                for inp in merged:
                    if not isinstance(inp, dict):
                        continue
                    field = inp.get("field", "")
                    if (
                        field
                        and not _is_generic_field(field)
                        and field not in non_input_fields
                    ):
                        fields.add(field)
                combo_value_fields[ci][val] = fields

        # Find fields that are conditional: differ between values in at least
        # one other-param context
        conditional_adds: dict[str, set[str]] = {val: set() for val in values}

        for ci in combo_value_fields:
            per_val = combo_value_fields[ci]
            all_vals = list(values)
            for val in all_vals:
                others_union = set()
                for other_val in all_vals:
                    if other_val != val:
                        others_union |= per_val.get(other_val, set())
                # Fields in this value but not in any other value for this combo
                unique_to_val = per_val.get(val, set()) - others_union
                conditional_adds[val] |= unique_to_val

        # Compute required across all combos
        value_required: dict[str, set[str]] = {val: set() for val in values}
        for ci, other_combo in enumerate(other_combos):
            for val in values:
                test_params = dict(other_combo)
                test_params[param] = val
                for p in params_list:
                    if p not in test_params:
                        test_params[p] = "__wildcard__"
                config_req: set[str] = set()
                for ck, cd in configs.items():
                    if not isinstance(cd, dict):
                        continue
                    if _matches_config_key(ck, test_params, params_list):
                        cr = cd.get("required", [])
                        if isinstance(cr, list):
                            config_req.update(cr)
                combo_fields = combo_value_fields[ci].get(val, set())
                value_required[val] |= (set(node_required) | config_req) & combo_fields

        # Union conditional adds to get overall conditional set
        all_conditional = set()
        for val in values:
            all_conditional |= conditional_adds[val]

        if not all_conditional:
            continue  # This param doesn't affect input fields

        # Extract default value for this param from TOML defaults
        param_default: Optional[str] = None
        for input_def in defaults.get("inputs", []):
            if isinstance(input_def, dict) and input_def.get("field") == param:
                raw = input_def.get("value")
                if raw is not None:
                    param_default = str(raw).lower()
                break

        param_rules: dict[str, Any] = {}
        if param_default is not None:
            param_rules["param_default"] = param_default

        for val in values:
            adds = conditional_adds[val]
            removes = all_conditional - conditional_adds[val]
            requires = (value_required[val] & adds) - fields_with_defaults

            rule: dict[str, list[str]] = {}
            if adds:
                rule["adds"] = sorted(adds)
            if requires:
                rule["requires"] = sorted(requires)
            if removes:
                rule["removes"] = sorted(removes)
            if rule:
                param_rules[val] = rule

        if len(param_rules) > (1 if param_default is not None else 0):
            result[param] = param_rules

    return result


def _build_node_manifest(
    node_type: str,
    node_config: dict[str, Any],
    dropdown_options: dict[str, list[str]],
    interface_map: dict[tuple[tuple[str, str], ...], str] | None = None,
) -> Optional[dict[str, Any]]:
    """Build manifest entry for a single node type. Returns None to skip."""
    params_list: list[str] = node_config.get("params", [])
    configs: dict = node_config.get("configs", {})
    defaults: dict = node_config.get("defaults", {})
    node_required: list[str] = node_config.get("required", [])
    if not isinstance(node_required, list):
        node_required = []

    # Skip dynamic nodes
    if _is_dynamic_node(configs):
        return None

    # Classify params — use _classify_params_for_manifest to find params
    # that actually change required fields or input availability
    all_sig_params, _ = _classify_params(params_list, configs, node_required)
    output_affecting, _ = _classify_params_by_output_impact(
        params_list, configs, defaults
    )

    # For the manifest, we care about params that affect INPUTS
    # (required fields, available fields, field types).
    # Compute which params are "input-affecting" by checking if
    # different values produce different required/input sets.
    input_affecting = _find_input_affecting_params(
        all_sig_params, params_list, defaults, configs, node_required
    )

    # Manifest sig_params: params that affect inputs OR outputs
    sig_params = [
        p for p in all_sig_params if p in input_affecting or p in output_affecting
    ]
    primary_sig_params = [p for p in sig_params if p in output_affecting]
    if not primary_sig_params and sig_params:
        primary_sig_params = sig_params[:1]

    # Extract valid values for sig params
    all_param_values = _extract_all_param_values(
        params_list, configs, defaults, dropdown_options
    )
    valid_sig_values: dict[str, list[str]] = {}
    for p in sig_params:
        vals = [v for v in all_param_values.get(p, []) if v]  # filter empty strings
        if vals:
            valid_sig_values[p] = vals

    # Compute default values for sig params
    sig_defaults: dict[str, str] = {}
    for input_def in defaults.get("inputs", []):
        if not isinstance(input_def, dict):
            continue
        field = input_def.get("field", "")
        if field in sig_params and input_def.get("value") is not None:
            val = str(input_def["value"])
            if val:  # Don't store empty string as default
                sig_defaults[field] = val

    # Non-input fields (system fields + params + dependencies + config objects)
    config_obj_names = {cfg[0] for cfg in _NODE_CONFIG_OBJECTS.get(node_type, [])}
    non_input_fields = sorted(
        {"id", "node_name", "execution_mode", "dependencies"}
        | set(params_list)
        | config_obj_names
    )

    # Enumerate variant combos using manifest sig_params
    combos = _enumerate_sig_param_combos(sig_params, params_list, configs)

    # Build variants
    variants: dict[str, dict] = {}
    for combo in combos:
        # Build full param dict
        full_params: dict[str, str] = dict(combo)
        for p in params_list:
            if p not in full_params:
                full_params[p] = "__wildcard__"

        # Build variant key — convert __wildcard__ to (*)
        if sig_params:
            variant_key = "**".join(
                "(*)" if combo.get(p, "__wildcard__") == "__wildcard__" else combo[p]
                for p in sig_params
            )
        else:
            variant_key = ""

        # Skip if we already have this variant key
        if variant_key in variants:
            continue

        # Compute merged inputs
        merged_inputs_list = _compute_merged_inputs(
            full_params, defaults, configs, params_list
        )

        # Compute required fields
        required_fields, _ = _compute_required_and_causal(
            combo,
            full_params,
            sig_params,
            params_list,
            defaults,
            configs,
            node_required,
        )

        # Build field_types, required, optional
        field_types: dict[str, dict] = {}
        required: list[str] = []
        optional: list[str] = []

        for input_def in merged_inputs_list:
            if not isinstance(input_def, dict):
                continue
            field = input_def.get("field", "")
            if not field or _is_generic_field(field):
                continue
            if field in non_input_fields:
                continue

            toml_type = input_def.get("type", "any")
            field_types[field] = _get_field_type_info(toml_type, interface_map)

            if field in required_fields:
                required.append(field)
            else:
                optional.append(field)

        variants[variant_key] = {
            "required": sorted(required),
            "optional": sorted(optional),
            "field_types": field_types,
        }

    # Skip nodes with no variants (shouldn't happen, but safety check)
    if not variants:
        return None

    # Collect ALL possible input field names across ALL param combos
    # (not just sig_param combos). This captures conditional fields like
    # default_value (only present when use_default_value=True) that don't
    # appear in any sig_param-keyed variant.
    all_fields: set[str] = set()
    for _vk, vr in variants.items():
        all_fields.update(vr.get("required", []))
        all_fields.update(vr.get("optional", []))
        all_fields.update(vr.get("field_types", {}).keys())
    # Also enumerate all-params combos to find conditional fields
    all_param_combos = _enumerate_sig_param_combos(params_list, params_list, configs)
    for combo in all_param_combos:
        full_params_all: dict[str, str] = dict(combo)
        for p in params_list:
            if p not in full_params_all:
                full_params_all[p] = "__wildcard__"
        merged = _compute_merged_inputs(full_params_all, defaults, configs, params_list)
        for input_def in merged:
            if isinstance(input_def, dict):
                field = input_def.get("field", "")
                if (
                    field
                    and not _is_generic_field(field)
                    and field not in non_input_fields
                ):
                    all_fields.add(field)

    # Compute conditional fields — non-sig params that add/remove/require fields
    conditional_fields = _compute_conditional_fields(
        sig_params,
        params_list,
        defaults,
        configs,
        node_required,
        set(non_input_fields),
    )

    result: dict[str, Any] = {
        "sig_params": sig_params,
        "primary_sig_params": primary_sig_params,
        "defaults": sig_defaults,
        "valid_sig_values": valid_sig_values,
        "non_input_fields": non_input_fields,
        "all_fields": sorted(all_fields),
        "variants": variants,
    }
    if conditional_fields:
        result["conditional_fields"] = conditional_fields
    return result


def _load_compatibility_toml(path: str) -> dict[str, dict[str, str]]:
    """Load data_type.toml and extract the compatibility table.

    Returns {source_type: {target_type: "full"|"partial"}} for all non-"none" entries.
    """
    raw = _load_toml(path)
    compat_section = raw.get("compatibility", {})
    table: dict[str, dict[str, str]] = {}
    for source, targets in compat_section.items():
        if not isinstance(targets, dict):
            continue
        filtered = {t: v for t, v in targets.items() if v in ("full", "partial")}
        if filtered:
            table[source] = filtered
    return table


def generate_manifest(
    node_config_path: str,
    dropdown_options_path: str,
    output_path: str,
    data_type_toml_path: Optional[str] = None,
    skip_nodes: Optional[set[str]] = None,
) -> None:
    """Generate the validation manifest JSON from pipeline_node.toml."""
    node_config = _load_toml(node_config_path)
    dropdown_options = _load_dropdown_options(dropdown_options_path)

    # Build interface type map for resolving TypedDict names in list fields
    interface_map = collect_interface_types(node_config)

    if skip_nodes:
        node_config = {k: v for k, v in node_config.items() if k not in skip_nodes}

    manifest: dict[str, Any] = {}
    for node_type, config in node_config.items():
        if not isinstance(config, dict):
            continue
        entry = _build_node_manifest(node_type, config, dropdown_options, interface_map)
        if entry is not None:
            class_name = _to_class_name(node_type)
            manifest[class_name] = entry

    # Embed canonical compatibility table from data_type.toml
    if data_type_toml_path and os.path.exists(data_type_toml_path):
        manifest["__compatibility__"] = _load_compatibility_toml(data_type_toml_path)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, separators=(",", ":"), sort_keys=False)
        f.write("\n")

    print(f"Generated manifest with {len(manifest)} nodes → {output_path}")


if __name__ == "__main__":
    # Auto-find config paths relative to SDK root
    sdk_root = os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    config_root = os.environ.get(
        "VS_CONFIG_ROOT",
        os.path.join(sdk_root, "..", "..", "vectorshift", "config"),
    )

    node_config_path = os.path.join(config_root, "pipeline_node.toml")
    dropdown_options_path = os.path.join(config_root, "dropdown_options.toml")
    data_type_toml_path = os.path.join(config_root, "data_type.toml")
    output_path = os.path.join(
        sdk_root, "vectorshift", "pipeline", "nodes", "_validation_manifest.json"
    )

    if not os.path.exists(node_config_path):
        print(f"ERROR: pipeline_node.toml not found at {node_config_path}")
        print(
            "Set VS_CONFIG_ROOT env var to the directory containing pipeline_node.toml"
        )
        raise SystemExit(1)

    generate_manifest(
        node_config_path=node_config_path,
        dropdown_options_path=dropdown_options_path,
        output_path=output_path,
        data_type_toml_path=data_type_toml_path,
        skip_nodes={"condition"},
    )
