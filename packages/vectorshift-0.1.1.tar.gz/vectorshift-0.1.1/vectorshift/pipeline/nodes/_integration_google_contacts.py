"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import ContactRecord


@Node.register_node_type("integration_google_contacts")
class IntegrationGoogleContactsNode(Node):
    """
    Google Contacts

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### get_contacts
        query: Search query to filter contacts
        limit: Maximum number of contacts to retrieve
    ### delete_contact
        contact_id: Google Contacts resource ID to delete
    ### read_contact
        contact_id: Google Contacts resource ID to delete
    ### update_contact
        contact_id: Google Contacts resource ID to delete
        email: Email address of the contact
        family_name: Last name of the contact
        given_name: First name of the contact
        organization: Organization name of the contact
        phone: Phone number of the contact
    ### create_contact
        email: Email address of the contact
        family_name: Last name of the contact
        given_name: First name of the contact
        organization: Organization name of the contact
        phone: Phone number of the contact

    ## Outputs
    ### read_contact
        contact_data: Contact information as structured data
        contact_id: Google Contacts resource ID
        contact_name: Contact's full display name
        display_name: Contact's display name
        email: Contact's primary email address
        etag: ETag for the contact resource
        family_name: Contact's last name
        full_name: Contact's full name
        given_name: Contact's first name
        organization: Contact's organization name
        phone: Contact's primary phone number
        raw_data: Raw contact data with all fields
        resource_name: Google Contacts resource name
    ### update_contact
        contact_data: Updated contact information as structured data
        contact_id: Google Contacts resource ID
        contact_name: Contact's full display name
        display_name: Contact's display name
        email: Contact's primary email address
        etag: ETag for the contact resource
        family_name: Contact's last name
        full_name: Contact's full name
        given_name: Contact's first name
        organization: Contact's organization name
        phone: Contact's primary phone number
        raw_data: Raw contact data with all fields
        resource_name: Google Contacts resource name
    ### create_contact
        contact_id: Google Contacts resource ID
        success: Success status of the operation
    ### get_contacts
        contact_ids: Array of contact IDs
        contacts: List of contacts as structured data
        display_names: Array of display names
        emails: Array of email addresses
        family_names: Array of family names
        given_names: Array of given names
        phones: Array of phone numbers
        total_count: Total number of contacts found
    ### delete_contact
        message: Confirmation message
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Contacts>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_contact": {
            "inputs": [
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "label": "Given Name",
                    "placeholder": "John",
                    "helper_text": "First name of the contact",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "label": "Family Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@example.com",
                    "helper_text": "Email address of the contact",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Phone number of the contact",
                },
                {
                    "field": "organization",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "placeholder": "Acme Corp",
                    "helper_text": "Organization name of the contact",
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Google Contacts resource ID",
                },
                {
                    "field": "success",
                    "type": "string",
                    "helper_text": "Success status of the operation",
                },
            ],
            "name": "create_contact",
            "task_name": "tasks.google_contacts.create_contact",
            "description": "Create a new contact",
            "label": "Create Contact",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "given_name",
                "family_name",
                "email",
                "phone",
                "organization",
            ],
            "required": ["given_name"],
        },
        "delete_contact": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact",
                    "placeholder": "people/c123456789",
                    "helper_text": "Google Contacts resource ID to delete",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Confirmation message",
                }
            ],
            "name": "delete_contact",
            "task_name": "tasks.google_contacts.delete_contact",
            "description": "Delete an existing contact",
            "label": "Delete Contact",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "contact_id"],
            "required": ["contact_id"],
        },
        "read_contact": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact",
                    "placeholder": "people/c123456789",
                    "helper_text": "Google Contacts resource ID to retrieve",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "contact_data",
                    "type": "vec<interface{contact_id: string, given_name: string, family_name: string, display_name: string, contact_name: string, full_name: string, email: string, phone: string, organization: string, etag: string}>",
                    "helper_text": "Contact information as structured data",
                },
                {
                    "field": "resource_name",
                    "type": "string",
                    "helper_text": "Google Contacts resource name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Google Contacts resource ID",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "helper_text": "Contact's first name",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "helper_text": "Contact's last name",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Contact's display name",
                },
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Contact's full display name",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "helper_text": "Contact's full name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Contact's primary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Contact's primary phone number",
                },
                {
                    "field": "organization",
                    "type": "string",
                    "helper_text": "Contact's organization name",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "ETag for the contact resource",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw contact data with all fields",
                },
            ],
            "name": "read_contact",
            "task_name": "tasks.google_contacts.read_contact",
            "description": "Read details of a specific contact",
            "label": "Get Contact",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "contact_id"],
            "required": ["contact_id"],
        },
        "get_contacts": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "string",
                    "value": "",
                    "label": "Limit",
                    "placeholder": "100",
                    "helper_text": "Maximum number of contacts to retrieve",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "john",
                    "helper_text": "Search query to filter contacts",
                },
            ],
            "outputs": [
                {
                    "field": "contacts",
                    "type": "vec<interface{contact_id: string, given_name: string, family_name: string, display_name: string, contact_name: string, full_name: string, email: string, phone: string, organization: string, etag: string}>",
                    "helper_text": "List of contacts as structured data",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total number of contacts found",
                },
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of contact IDs",
                },
                {
                    "field": "given_names",
                    "type": "vec<string>",
                    "helper_text": "Array of given names",
                },
                {
                    "field": "family_names",
                    "type": "vec<string>",
                    "helper_text": "Array of family names",
                },
                {
                    "field": "display_names",
                    "type": "vec<string>",
                    "helper_text": "Array of display names",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "Array of email addresses",
                },
                {
                    "field": "phones",
                    "type": "vec<string>",
                    "helper_text": "Array of phone numbers",
                },
            ],
            "name": "get_contacts",
            "task_name": "tasks.google_contacts.get_contacts",
            "description": "Get multiple contacts",
            "label": "List Contacts",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "limit", "query"],
        },
        "update_contact": {
            "inputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact",
                    "placeholder": "people/c123456789",
                    "helper_text": "Google Contacts resource ID to update",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=contact_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "label": "Given Name",
                    "placeholder": "John",
                    "helper_text": "Updated first name of the contact",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "label": "Family Name",
                    "placeholder": "Doe",
                    "helper_text": "Updated last name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@example.com",
                    "helper_text": "Updated email address of the contact",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Updated phone number of the contact",
                },
                {
                    "field": "organization",
                    "type": "string",
                    "value": "",
                    "label": "Organization",
                    "placeholder": "Acme Corp",
                    "helper_text": "Updated organization name of the contact",
                },
            ],
            "outputs": [
                {
                    "field": "contact_data",
                    "type": "string",
                    "helper_text": "Updated contact information as structured data",
                },
                {
                    "field": "resource_name",
                    "type": "string",
                    "helper_text": "Google Contacts resource name",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "Google Contacts resource ID",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "helper_text": "Contact's first name",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "helper_text": "Contact's last name",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Contact's display name",
                },
                {
                    "field": "contact_name",
                    "type": "string",
                    "helper_text": "Contact's full display name",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "helper_text": "Contact's full name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Contact's primary email address",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Contact's primary phone number",
                },
                {
                    "field": "organization",
                    "type": "string",
                    "helper_text": "Contact's organization name",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "ETag for the contact resource",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw contact data with all fields",
                },
            ],
            "name": "update_contact",
            "task_name": "tasks.google_contacts.update_contact",
            "description": "Update an existing contact",
            "label": "Update Contact",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "contact_id",
                "given_name",
                "family_name",
                "email",
                "phone",
                "organization",
            ],
            "required": ["contact_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        contact_id: str = "",
        email: str = "",
        family_name: str = "",
        given_name: str = "",
        limit: str = "",
        organization: str = "",
        phone: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_contacts",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if given_name is not None:
            self.inputs["given_name"] = given_name
        if family_name is not None:
            self.inputs["family_name"] = family_name
        if email is not None:
            self.inputs["email"] = email
        if phone is not None:
            self.inputs["phone"] = phone
        if organization is not None:
            self.inputs["organization"] = organization
        if contact_id is not None:
            self.inputs["contact_id"] = contact_id
        if limit is not None:
            self.inputs["limit"] = limit
        if query is not None:
            self.inputs["query"] = query
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleContactsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
