"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("google_alert_rss_reader")
class GoogleAlertRssReaderNode(Node):
    """
    Read the contents from an RSS feed created from a Google Alert: https://www.google.com/alerts

    ## Inputs
    ### Common Inputs
        feed_link: The link of the Google Alert RSS feed you want to read
        timeframe: The publish dates of the items in the feed to read

    ## Outputs
    ### Common Outputs
        dates: The publish dates of the Google Alert RSS feed items
        links: The links of the Google Alert RSS feed items
        snippets: The snippets of the Google Alert RSS feed items
        titles: The titles of the Google Alert RSS feed items
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "feed_link",
            "helper_text": "The link of the Google Alert RSS feed you want to read",
            "value": "",
            "type": "string",
        },
        {
            "field": "timeframe",
            "helper_text": "The publish dates of the items in the feed to read",
            "value": "all",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "dates",
            "helper_text": "The publish dates of the Google Alert RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "links",
            "helper_text": "The links of the Google Alert RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "snippets",
            "helper_text": "The snippets of the Google Alert RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "titles",
            "helper_text": "The titles of the Google Alert RSS feed items",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["feed_link"]

    def __init__(
        self,
        feed_link: str = "",
        timeframe: str = "all",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="google_alert_rss_reader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if feed_link is not None:
            self.inputs["feed_link"] = feed_link
        if timeframe is not None:
            self.inputs["timeframe"] = timeframe
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "GoogleAlertRssReaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
