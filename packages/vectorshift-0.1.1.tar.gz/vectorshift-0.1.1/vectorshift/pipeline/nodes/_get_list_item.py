"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("get_list_item")
class GetListItemNode(Node):
    """
    Get a value from a list given an index. The first item in the list is index 0.

    ## Inputs
    ### Common Inputs
        index: The index of the item to retrieve
        type: The type of the list
    ### <T>
        list: The list to retrieve the item from

    ## Outputs
    ### <T>
        output: The item retrieved from the list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "index",
            "helper_text": "The index of the item to retrieve",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "type",
            "helper_text": "The type of the list",
            "value": "string",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "<T>": {
            "inputs": [
                {
                    "field": "list",
                    "label": "List",
                    "type": "vec<<T>>",
                    "value": "",
                    "helper_text": "The list to retrieve the item from",
                }
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "<T>",
                    "helper_text": "The item retrieved from the list",
                }
            ],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["list", "index"]

    def __init__(
        self,
        type: str = "string",
        index: int = 0,
        list: List[Any] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["type"] = type

        super().__init__(
            node_type="get_list_item",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if type is not None:
            self.inputs["type"] = type
        if index is not None:
            self.inputs["index"] = index
        if list is not None:
            self.inputs["list"] = list
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "GetListItemNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
