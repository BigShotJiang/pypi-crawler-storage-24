"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("csv_query")
class CsvQueryNode(Node):
    """
    Utilizes an LLM agent to query CSV(s). Delimeter for the CSV must be commas.

    ## Inputs
    ### Common Inputs
        query: The question you want to be answered by the CSV
        csv: The CSV to be queried (file must be a CSV). Note: Ensure connecting node is of type File not text
        stream: Whether to stream the results of the query

    ## Outputs
    ### Common Outputs
        output: The answer to the Query based on the CSV
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "The question you want to be answered by the CSV",
            "value": "",
            "type": "string",
        },
        {
            "field": "csv",
            "helper_text": "The CSV to be queried (file must be a CSV). Note: Ensure connecting node is of type File not text",
            "value": None,
            "type": "file",
        },
        {
            "field": "stream",
            "helper_text": "Whether to stream the results of the query",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "The answer to the Query based on the CSV",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["csv", "query"]

    def __init__(
        self,
        query: str = "",
        csv: Optional[str] = None,
        stream: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="csv_query",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if csv is not None:
            self.inputs["csv"] = csv
        if query is not None:
            self.inputs["query"] = query
        if stream is not None:
            self.inputs["stream"] = stream
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CsvQueryNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
