"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("scorer")
class ScorerNode(Node):
    """
    Assign a numerical score based on predefined criteria to quantitatively assess a given entity.

    ## Inputs
    ### Common Inputs
        model: The specific model for scoring
        text: The text that will be scored
        additional_context: Provide any additional context or instructions
        criteria: The criteria that the text will be scored
        justification: Include the AI's justification for its score
        provider: The model provider

    ## Outputs
    ### Common Outputs
        score: The score of the text based on the criteria
    ### When justification = True
        justification: The AI justification
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for scoring",
            "value": "",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The text that will be scored",
            "value": "",
            "type": "string",
        },
        {
            "field": "additional_context",
            "helper_text": "Provide any additional context or instructions",
            "value": "",
            "type": "string",
        },
        {
            "field": "criteria",
            "helper_text": "The criteria that the text will be scored",
            "value": "",
            "type": "string",
        },
        {
            "field": "justification",
            "helper_text": "Include the AI's justification for its score",
            "value": False,
            "type": "bool",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "score",
            "helper_text": "The score of the text based on the criteria",
            "type": "float",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "justification",
                    "type": "string",
                    "helper_text": "The AI justification",
                }
            ],
        },
        "false**(*)": {"inputs": [], "outputs": []},
        "(*)**openai": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**google": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**xai": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**cohere": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**together": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**bedrock": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**azure": {
            "inputs": [
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "label": "LLM Model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for scoring",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["justification", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text", "criteria"]

    def __init__(
        self,
        justification: bool = False,
        provider: str = "openai",
        model: str = "",
        text: str = "",
        additional_context: str = "",
        criteria: str = "",
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["justification"] = justification
        params["provider"] = provider

        super().__init__(
            node_type="scorer",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if justification is not None:
            self.inputs["justification"] = justification
        if text is not None:
            self.inputs["text"] = text
        if criteria is not None:
            self.inputs["criteria"] = criteria
        if additional_context is not None:
            self.inputs["additional_context"] = additional_context
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ScorerNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
