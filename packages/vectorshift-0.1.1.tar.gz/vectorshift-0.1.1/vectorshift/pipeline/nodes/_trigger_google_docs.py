"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_google_docs")
class TriggerGoogleDocsNode(Node):
    """
    Google Docs Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        trigger_enabled: Enable/Disable Automation
    ### new_document_in_folder
        item_id: Select the folder to watch for new documents
    ### updated_document_in_folder
        item_id: Select the folder to watch for new documents

    ## Outputs
    ### new_document_in_folder
        created_time: When the document was created
        document_id: Unique identifier of the document
        document_name: Name of the document
        event_type: Type of event (document_created)
        last_modifying_user_email: Email of the last person who modified the document
        last_modifying_user_name: Name of the last person who modified the document
        mime_type: MIME type of the document
        modified_time: When the document was last modified
        owner_email: Email of the document owner
        owner_name: Name of the document owner
        parent_folder_id: ID of the parent folder
        raw_data: Complete webhook payload as JSON
        size: Size of the document in bytes
        trigger_timestamp: Timestamp when this trigger was activated
        web_content_link: Link to download the document
        web_view_link: Link to view the document in browser
    ### updated_document_in_folder
        created_time: When the document was created
        document_id: Unique identifier of the document
        document_name: Name of the document
        event_type: Type of event (updated_document_in_folder)
        last_modifying_user_email: Email of the last person who modified the document
        last_modifying_user_name: Name of the last person who modified the document
        mime_type: MIME type of the document
        modified_time: When the document was last modified
        owner_email: Email of the document owner
        owner_name: Name of the document owner
        parent_folder_id: ID of the parent folder
        raw_data: Complete webhook payload as JSON
        size: Size of the document in bytes
        trigger_timestamp: Timestamp when this trigger was activated
        web_content_link: Link to download the document
        web_view_link: Link to view the document in browser
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Google Docs>",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_document_in_folder": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select the folder to watch for new documents",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the document",
                },
                {
                    "field": "document_name",
                    "type": "string",
                    "helper_text": "Name of the document",
                },
                {
                    "field": "event_type",
                    "type": "string",
                    "helper_text": "Type of event (document_created)",
                },
                {
                    "field": "web_view_link",
                    "type": "string",
                    "helper_text": "Link to view the document in browser",
                },
                {
                    "field": "web_content_link",
                    "type": "string",
                    "helper_text": "Link to download the document",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the document was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the document was last modified",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the document",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "Size of the document in bytes",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the document owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the document owner",
                },
                {
                    "field": "last_modifying_user_name",
                    "type": "string",
                    "helper_text": "Name of the last person who modified the document",
                },
                {
                    "field": "last_modifying_user_email",
                    "type": "string",
                    "helper_text": "Email of the last person who modified the document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete webhook payload as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp when this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_document_in_folder",
            "task_name": "tasks.google_docs.new_document_in_folder",
            "description": "Triggers when a new Google Doc is created in the specified folder (but not its subfolders)",
            "label": "New Document in Folder",
        },
        "updated_document_in_folder": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Document",
                    "helper_text": "Select the document to watch",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the document",
                },
                {
                    "field": "document_name",
                    "type": "string",
                    "helper_text": "Name of the document",
                },
                {
                    "field": "event_type",
                    "type": "string",
                    "helper_text": "Type of event (updated_document_in_folder)",
                },
                {
                    "field": "web_view_link",
                    "type": "string",
                    "helper_text": "Link to view the document in browser",
                },
                {
                    "field": "web_content_link",
                    "type": "string",
                    "helper_text": "Link to download the document",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the document was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the document was last modified",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the document",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "Size of the document in bytes",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "owner_name",
                    "type": "string",
                    "helper_text": "Name of the document owner",
                },
                {
                    "field": "owner_email",
                    "type": "string",
                    "helper_text": "Email of the document owner",
                },
                {
                    "field": "last_modifying_user_name",
                    "type": "string",
                    "helper_text": "Name of the last person who modified the document",
                },
                {
                    "field": "last_modifying_user_email",
                    "type": "string",
                    "helper_text": "Email of the last person who modified the document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete webhook payload as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp when this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_document_in_folder",
            "task_name": "tasks.google_docs.updated_document_in_folder",
            "description": "Triggers when a document is updated in a selected folder",
            "label": "Updated Document in Folder",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Folder"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_google_docs",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerGoogleDocsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
