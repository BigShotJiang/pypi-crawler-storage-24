"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_google_drive")
class IntegrationGoogleDriveNode(Node):
    """
    Google Drive

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'get_files'
        query: Search query for filtering files (see Drive API documentation for syntax)
        corpora: Scope to search in: 'user' (files owned/shared to user) or 'domain' (files shared to user's domain)
        drive_id: ID of the shared drive to search
        fields: Comma-separated list of fields to include in the response
        include_items_from_all_drives: Whether to include items from all drives, including shared drives
        include_labels: Comma-separated list of label IDs to include in the response
        include_permissions_for_view: Additional view's permissions to include (only 'published' supported)
        order_by: Sort order for files (e.g., 'folder,name,modifiedTime desc')
        recursive: When enabled, fetches all files from nested folders recursively. Folders will be traversed and only files will be returned.
        spaces: Comma-separated list of spaces to search ('drive', 'appDataFolder')
        supports_all_drives: Whether the application supports both My Drives and shared drives
        use_date: Toggle to use dates
    ### When action = 'get_shared_drives'
        query: Search query for filtering files (see Drive API documentation for syntax)
        limit: Maximum number of shared drives to return (when not returning all)
        return_all: Whether to return all shared drives or limit the results
        use_domain_admin_access: Whether to use domain admin access
    ### When action = 'update_file'
        change_file_content: Whether to update the file content
        content_type: MIME type of the file content
        description: Description for the file
        file_data: New file content (when changing content)
        file_id: Select the file to read
        file_name: New name for the file
        starred: Whether to star the file
        trashed: Whether to trash the file
    ### When action = 'create_shared_drive'
        color_rgb: Color for the shared drive (hex code)
        hidden: Whether the shared drive is hidden
        name: Name of the file to create
    ### When action = 'update_shared_drive'
        color_rgb: Color for the shared drive (hex code)
        drive_id: ID of the shared drive to search
        name: Name of the file to create
    ### When action = 'create_file_from_text'
        content: Text content for the file
        description: Description for the file
        name: Name of the file to create
        parent_folder_id: Select the folder to create the file in
    ### When action = 'copy_file'
        copy_requires_writer_permission: Whether the copy requires writer permission
        description: Description for the file
        file_id: Select the file to read
        name: Name of the file to create
        parent_folder_id: Select the folder to create the file in
        same_folder: Keep the copy in the same folder as the original
    ### When action = 'get_files' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'delete_file'
        delete_permanently: Whether to delete the file permanently or move to trash
        file_id: Select the file to read
    ### When action = 'delete_folder'
        delete_permanently: Whether to delete the file permanently or move to trash
        folder_id: Select the folder within your Google Drive to save the file
    ### When action = 'create_folder'
        description: Description for the file
        folder_color: Color for the folder (hex code)
        name: Name of the file to create
        parent_folder_id: Select the folder to create the file in
    ### When action = 'share_file'
        domain: Domain for domain permissions
        email_address: Email address for user/group permissions
        email_message: Custom message for the notification email
        file_id: Select the file to read
        role: Role for the permission (reader, writer, commenter, owner)
        send_notification_email: Whether to send notification email
        type: Type of permission (user, group, domain, anyone)
    ### When action = 'share_folder'
        domain: Domain for domain permissions
        email_address: Email address for user/group permissions
        email_message: Custom message for the notification email
        folder_id: Select the folder within your Google Drive to save the file
        role: Role for the permission (reader, writer, commenter, owner)
        send_notification_email: Whether to send notification email
        type: Type of permission (user, group, domain, anyone)
    ### When action = 'read_file_url'
        drive_file_url: The URL of the drive file to read.
    ### When action = 'read_shared_drive'
        drive_id: ID of the shared drive to search
        use_domain_admin_access: Whether to use domain admin access
    ### When action = 'delete_shared_drive'
        drive_id: ID of the shared drive to search
    ### When action = 'get_files' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'save_drive'
        file: Select or Upload a file
        folder_id: Select the folder within your Google Drive to save the file
    ### When action = 'read_drive'
        file_id: Select the file to read
    ### When action = 'move_file'
        file_id: Select the file to read
        parent_folder_id: Select the folder to create the file in
    ### When action = 'get_files' and use_date = False
        num_messages: Specify the number of files to fetch
    ### When action = 'get_files' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_shared_drive'
        capabilities: Capabilities of the shared drive
        color_rgb: Color of the shared drive
        created_time: Creation time of the shared drive
        drive_id: ID of the shared drive
        drive_name: Name of the shared drive
        hidden: Whether the shared drive is hidden
        message: Success or error message
        raw_data: Raw response data from Google Drive API
        restrictions: Restrictions of the shared drive
    ### When action = 'update_shared_drive'
        color_rgb: Color of the updated shared drive
        drive_id: ID of the updated shared drive
        drive_name: Name of the updated shared drive
        message: Success or error message
        raw_data: Raw response data from Google Drive API
    ### When action = 'get_files'
        created_at: Creation timestamps of the retrieved files (RFC3339 format)
        file_ids: IDs of the retrieved files
        file_names: Names of the retrieved files
        file_paths: Full paths of the retrieved files (e.g., 'folder1/subfolder/file.txt')
        file_types: MIME types of the retrieved files
        files: The retrieved files (only actual files, no folders)
        modified_at: Modification timestamps of the retrieved files (RFC3339 format)
        raw_data: Raw JSON response data from the API
        web_view_links: Web view links for the retrieved files
    ### When action = 'save_drive'
        created_time: Creation timestamp
        file_id: ID of the uploaded file
        file_name: Name of the uploaded file
        file_size: Size of the file in bytes
        mime_type: MIME type of the file
        modified_time: Last modification timestamp
        raw_data: Complete response from the API
        web_content_link: Link to download the file content
        web_view_link: Link to view the file in browser
    ### When action = 'copy_file'
        created_time: Creation time of the copied file
        file_id: ID of the copied file
        file_name: Name of the copied file
        file_url: URL of the copied file
        message: Success or error message
        raw_data: Raw response data from Google Drive API
    ### When action = 'create_folder'
        created_time: Creation time of the folder
        folder_id: ID of the created folder
        folder_name: Name of the created folder
        folder_url: URL of the created folder
        message: Success or error message
        raw_data: Raw response data from Google Drive API
    ### When action = 'create_shared_drive'
        created_time: Creation time of the shared drive
        drive_id: ID of the created shared drive
        drive_name: Name of the created shared drive
        message: Success or error message
        raw_data: Raw response data from Google Drive API
    ### When action = 'share_file'
        display_name: Display name of the permission
        email_address: Email address of the permission
        file_id: ID of the shared file
        message: Success or error message
        permission_id: ID of the created permission
        raw_data: Raw response data from Google Drive API
        role: Role of the permission
        type: Type of the permission
    ### When action = 'share_folder'
        display_name: Display name of the permission
        email_address: Email address of the permission
        folder_id: ID of the shared folder
        message: Success or error message
        permission_id: ID of the created permission
        raw_data: Raw response data from Google Drive API
        role: Role of the permission
        type: Type of the permission
    ### When action = 'get_shared_drives'
        drive_colors: List of shared drive colors
        drive_created_times: List of shared drive creation times
        drive_hidden: List of shared drive hidden status
        drive_ids: List of shared drive IDs
        drive_names: List of shared drive names
        message: Success or error message
        raw_data: Raw response data from Google Drive API
        total_count: Total number of shared drives retrieved
    ### When action = 'delete_shared_drive'
        drive_id: ID of the deleted shared drive
        message: Success or error message
    ### When action = 'read_drive'
        file: Downloadable file
        file_name: Name of the file
        file_type: MIME type of the file
    ### When action = 'read_file_url'
        file: The file fetched from the URL.
        file_name: Name of the file
        file_type: MIME type of the file
    ### When action = 'create_file_from_text'
        file_id: ID of the created file
        file_name: Name of the created file
        message: Success or error message
        raw_data: Raw response data from Google Drive API
    ### When action = 'move_file'
        file_id: ID of the moved file
        file_name: Name of the moved file
        file_url: URL of the moved file
        message: Success or error message
        parent_folders: List of parent folder IDs
        raw_data: Raw response data from Google Drive API
    ### When action = 'update_file'
        file_id: ID of the updated file
        file_name: Name of the updated file
        file_url: URL of the updated file
        message: Success or error message
        mime_type: MIME type of the file
        modified_time: Last modified time
        raw_data: Raw response data from Google Drive API
        size: Size of the file
    ### When action = 'delete_file'
        file_id: ID of the deleted file
        message: Success or error message
    ### When action = 'delete_folder'
        folder_id: ID of the deleted folder
        message: Success or error message
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Drive>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_file_nodes",
        },
        "create_file_from_text**(*)**(*)": {
            "inputs": [
                {
                    "field": "content",
                    "type": "string",
                    "value": "",
                    "label": "Content",
                    "helper_text": "Text content for the file",
                    "placeholder": "Enter text content",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "File Name",
                    "helper_text": "Name of the file to create",
                    "placeholder": "Enter file name",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Folder",
                    "helper_text": "Select the folder to create the file in",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description for the file",
                    "placeholder": "Enter description",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the created file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the created file",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "create_file_from_text",
            "task_name": "tasks.google_drive.create_file_from_text",
            "description": "Create a file from text content",
            "label": "Create File from Text",
            "ui_sort_order": [
                "integration",
                "action",
                "content",
                "name",
                "parent_folder_id",
                "description",
            ],
            "required": ["content", "name"],
        },
        "save_drive**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder within your Google Drive to save the file",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "label": "File",
                    "placeholder": "Select a file",
                    "helper_text": "Select or Upload a file",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the uploaded file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "web_view_link",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "web_content_link",
                    "type": "string",
                    "helper_text": "Link to download the file content",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "save_drive",
            "task_name": "tasks.google_drive.save_drive",
            "description": "Save a file to Google Drive",
            "label": "Save file",
            "ui_sort_order": ["integration", "action", "folder_id", "file"],
            "required": ["file"],
        },
        "read_drive**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to read",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file",
                    "type": "file",
                    "label": "File",
                    "helper_text": "Downloadable file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
            ],
            "name": "read_drive",
            "task_name": "tasks.google_drive.read_drive",
            "description": "Read details of a specific file",
            "label": "Get File",
            "inputs_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "read_file_url**(*)**(*)": {
            "inputs": [
                {
                    "field": "drive_file_url",
                    "type": "string",
                    "value": "",
                    "helper_text": "The URL of the drive file to read.",
                    "label": "File URL",
                    "placeholder": "Enter the URL of the drive file to read.",
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [
                {
                    "field": "file",
                    "type": "file",
                    "label": "File",
                    "helper_text": "The file fetched from the URL.",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
            ],
            "variant": "default_integration_nodes",
            "banner_text": 'Ensure that the Google Drive\'s permissions is set to "Anyone with the Link"',
            "name": "read_file_url",
            "task_name": "tasks.google_drive.read_file_url",
            "description": "Read details of a specific file from URL",
            "label": "Get File from URL",
            "inputs_sort_order": ["integration", "action", "drive_file_url"],
            "required": ["drive_file_url"],
        },
        "get_files**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "order": 4,
                },
                {
                    "field": "recursive",
                    "type": "bool",
                    "value": False,
                    "label": "Recursive",
                    "helper_text": "When enabled, fetches all files from nested folders recursively. Folders will be traversed and only files will be returned.",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "helper_text": "Search query for filtering files (see Drive API documentation for syntax)",
                    "placeholder": "",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "helper_text": "Sort order for files (e.g., 'folder,name,modifiedTime desc')",
                    "placeholder": "",
                },
                {
                    "field": "corpora",
                    "type": "string",
                    "value": "",
                    "label": "Search Scope",
                    "helper_text": "Scope to search in: 'user' (files owned/shared to user) or 'domain' (files shared to user's domain)",
                    "placeholder": "Eg. User or Domain",
                },
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "label": "Drive ID",
                    "helper_text": "ID of the shared drive to search",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields to Include",
                    "helper_text": "Comma-separated list of fields to include in the response",
                    "placeholder": "Eg. name, id, size, etc.",
                },
                {
                    "field": "include_items_from_all_drives",
                    "type": "bool",
                    "value": True,
                    "label": "Include All Drives",
                    "helper_text": "Whether to include items from all drives, including shared drives",
                },
                {
                    "field": "include_labels",
                    "type": "string",
                    "value": "",
                    "label": "Include Labels",
                    "helper_text": "Comma-separated list of label IDs to include in the response",
                    "placeholder": "",
                },
                {
                    "field": "spaces",
                    "type": "string",
                    "value": "",
                    "label": "Spaces",
                    "helper_text": "Comma-separated list of spaces to search ('drive', 'appDataFolder')",
                    "placeholder": "Eg. drive, appDataFolder",
                },
                {
                    "field": "supports_all_drives",
                    "type": "bool",
                    "value": True,
                    "label": "Supports All Drives",
                    "helper_text": "Whether the application supports both My Drives and shared drives",
                    "placeholder": "",
                },
                {
                    "field": "include_permissions_for_view",
                    "type": "string",
                    "value": "",
                    "label": "Include Permissions View",
                    "helper_text": "Additional view's permissions to include (only 'published' supported)",
                    "placeholder": "",
                },
            ],
            "outputs": [
                {
                    "field": "files",
                    "type": "vec<file>",
                    "helper_text": "The retrieved files (only actual files, no folders)",
                    "label": "Files",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Names of the retrieved files",
                },
                {
                    "field": "file_paths",
                    "type": "vec<string>",
                    "helper_text": "Full paths of the retrieved files (e.g., 'folder1/subfolder/file.txt')",
                },
                {
                    "field": "file_types",
                    "type": "vec<string>",
                    "helper_text": "MIME types of the retrieved files",
                },
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the retrieved files",
                },
                {
                    "field": "created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Creation timestamps of the retrieved files (RFC3339 format)",
                },
                {
                    "field": "modified_at",
                    "type": "vec<timestamp>",
                    "helper_text": "Modification timestamps of the retrieved files (RFC3339 format)",
                },
                {
                    "field": "web_view_links",
                    "type": "vec<string>",
                    "helper_text": "Web view links for the retrieved files",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response data from the API",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_files",
            "task_name": "tasks.google_drive.get_files",
            "description": "Get multiple files",
            "label": "List Files",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "query",
                "order_by",
                "corpora",
                "drive_id",
                "fields",
                "include_items_from_all_drives",
                "include_labels",
                "spaces",
                "supports_all_drives",
                "include_permissions_for_view",
            ],
            "required": ["num_messages"],
        },
        "get_files**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Files",
                    "helper_text": "Specify the number of files to fetch",
                }
            ],
            "outputs": [],
        },
        "get_files**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_files**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "label": "Date range",
                    "component": {"type": "date_range"},
                    "order": 6,
                }
            ],
            "outputs": [],
        },
        "get_files**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "label": "Exact date",
                    "component": {"type": "date_range"},
                    "order": 7,
                }
            ],
            "outputs": [],
        },
        "copy_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to copy",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "New File Name",
                    "helper_text": "Name for the copied file (optional)",
                    "placeholder": "Enter new file name",
                },
                {
                    "field": "same_folder",
                    "type": "bool",
                    "value": False,
                    "label": "Same Folder",
                    "helper_text": "Keep the copy in the same folder as the original",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Folder",
                    "helper_text": "Select the folder to copy the file to (if not same folder)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "copy_requires_writer_permission",
                    "type": "bool",
                    "value": False,
                    "label": "Copy Requires Writer Permission",
                    "helper_text": "Whether the copy requires writer permission",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description for the copied file",
                    "placeholder": "Enter description",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the copied file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the copied file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the copied file",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the copied file",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "copy_file",
            "task_name": "tasks.google_drive.copy_file",
            "description": "Copy a file in Google Drive",
            "label": "Copy File",
            "ui_sort_order": [
                "integration",
                "action",
                "file_id",
                "name",
                "same_folder",
                "parent_folder_id",
                "copy_requires_writer_permission",
                "description",
            ],
            "required": ["file_id"],
        },
        "move_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to move",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Target Folder",
                    "helper_text": "Select the folder to move the file to",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the moved file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the moved file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the moved file",
                },
                {
                    "field": "parent_folders",
                    "type": "vec<string>",
                    "helper_text": "List of parent folder IDs",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "move_file",
            "task_name": "tasks.google_drive.move_file",
            "description": "Move a file to a different folder",
            "label": "Move File",
            "ui_sort_order": ["integration", "action", "file_id", "parent_folder_id"],
            "required": ["file_id", "parent_folder_id"],
        },
        "share_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to share",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "role",
                    "type": "string",
                    "value": "",
                    "label": "Role",
                    "helper_text": "Role for the permission (reader, writer, commenter, owner)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Reader", "value": "reader"},
                            {"label": "Writer", "value": "writer"},
                            {"label": "Commenter", "value": "commenter"},
                            {"label": "Owner", "value": "owner"},
                        ],
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "label": "Type",
                    "helper_text": "Type of permission (user, group, domain, anyone)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "User", "value": "user"},
                            {"label": "Group", "value": "group"},
                            {"label": "Domain", "value": "domain"},
                            {"label": "Anyone", "value": "anyone"},
                        ],
                    },
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "helper_text": "Email address for user/group permissions",
                    "placeholder": "Enter email address",
                },
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "helper_text": "Domain for domain permissions",
                    "placeholder": "Enter domain",
                },
                {
                    "field": "send_notification_email",
                    "type": "bool",
                    "value": False,
                    "label": "Send Notification Email",
                    "helper_text": "Whether to send notification email",
                },
                {
                    "field": "email_message",
                    "type": "string",
                    "value": "",
                    "label": "Email Message",
                    "helper_text": "Custom message for the notification email",
                    "placeholder": "Enter custom message",
                },
            ],
            "outputs": [
                {
                    "field": "permission_id",
                    "type": "string",
                    "helper_text": "ID of the created permission",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the permission",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Type of the permission",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "Email address of the permission",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Display name of the permission",
                },
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the shared file",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "share_file",
            "hidden": True,
            "task_name": "tasks.google_drive.share_file",
            "description": "Share a file with users or groups",
            "label": "Share File",
            "ui_sort_order": [
                "integration",
                "action",
                "file_id",
                "role",
                "type",
                "email_address",
                "domain",
                "send_notification_email",
                "email_message",
            ],
            "required": ["file_id", "role", "type"],
        },
        "update_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to update",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "label": "File Name",
                    "helper_text": "New name for the file",
                    "placeholder": "Enter new file name",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "New description for the file",
                    "placeholder": "Enter description",
                },
                {
                    "field": "starred",
                    "type": "bool",
                    "value": False,
                    "label": "Starred",
                    "helper_text": "Whether to star the file",
                },
                {
                    "field": "trashed",
                    "type": "bool",
                    "value": False,
                    "label": "Trashed",
                    "helper_text": "Whether to trash the file",
                },
                {
                    "field": "change_file_content",
                    "type": "bool",
                    "value": False,
                    "label": "Change File Content",
                    "helper_text": "Whether to update the file content",
                },
                {
                    "field": "file_data",
                    "type": "string",
                    "value": "",
                    "label": "File Data",
                    "helper_text": "New file content (when changing content)",
                    "placeholder": "Enter file content",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "",
                    "label": "Content Type",
                    "helper_text": "MIME type of the file content",
                    "placeholder": "Enter MIME type (e.g., text/plain)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text/plain"},
                            {"label": "HTML", "value": "text/html"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the updated file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the updated file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the updated file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "Last modified time",
                },
                {"field": "size", "type": "string", "helper_text": "Size of the file"},
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "update_file",
            "task_name": "tasks.google_drive.update_file",
            "description": "Update file metadata and content",
            "label": "Update File",
            "ui_sort_order": [
                "integration",
                "action",
                "file_id",
                "file_name",
                "description",
                "starred",
                "trashed",
                "change_file_content",
                "file_data",
                "content_type",
            ],
            "required": ["file_id"],
        },
        "delete_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "delete_permanently",
                    "type": "bool",
                    "value": False,
                    "label": "Delete Permanently",
                    "helper_text": "Whether to delete the file permanently or move to trash",
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the deleted file",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
            ],
            "name": "delete_file",
            "hidden": True,
            "task_name": "tasks.google_drive.delete_file",
            "description": "Delete a file from Google Drive",
            "label": "Delete File",
            "ui_sort_order": ["integration", "action", "file_id", "delete_permanently"],
            "required": ["file_id"],
        },
        "create_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "Untitled",
                    "label": "Folder Name",
                    "helper_text": "Name of the folder to create",
                    "placeholder": "Enter folder name",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Parent Folder",
                    "helper_text": "Select the parent folder",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "Description for the folder",
                    "placeholder": "Enter description",
                },
                {
                    "field": "folder_color",
                    "type": "string",
                    "value": "",
                    "label": "Folder Color",
                    "helper_text": "Color for the folder (hex code)",
                    "placeholder": "Enter hex color (e.g., #FF0000)",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the created folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the created folder",
                },
                {
                    "field": "folder_url",
                    "type": "string",
                    "helper_text": "URL of the created folder",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the folder",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.google_drive.create_folder",
            "description": "Create a new folder in Google Drive",
            "label": "Create Folder",
            "ui_sort_order": [
                "integration",
                "action",
                "name",
                "parent_folder_id",
                "description",
                "folder_color",
            ],
            "required": ["name"],
        },
        "delete_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "delete_permanently",
                    "type": "bool",
                    "value": False,
                    "label": "Delete Permanently",
                    "helper_text": "Whether to delete the folder permanently or move to trash",
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the deleted folder",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
            ],
            "name": "delete_folder",
            "hidden": True,
            "task_name": "tasks.google_drive.delete_folder",
            "description": "Delete a folder from Google Drive",
            "label": "Delete Folder",
            "ui_sort_order": [
                "integration",
                "action",
                "folder_id",
                "delete_permanently",
            ],
            "required": ["folder_id"],
        },
        "share_folder**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder to share",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "role",
                    "type": "string",
                    "value": "",
                    "label": "Role",
                    "helper_text": "Role for the permission (reader, writer, commenter, owner)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Reader", "value": "reader"},
                            {"label": "Writer", "value": "writer"},
                            {"label": "Commenter", "value": "commenter"},
                            {"label": "Owner", "value": "owner"},
                        ],
                    },
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "label": "Type",
                    "helper_text": "Type of permission (user, group, domain, anyone)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "User", "value": "user"},
                            {"label": "Group", "value": "group"},
                            {"label": "Domain", "value": "domain"},
                            {"label": "Anyone", "value": "anyone"},
                        ],
                    },
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "value": "",
                    "label": "Email Address",
                    "helper_text": "Email address for user/group permissions",
                    "placeholder": "Enter email address",
                },
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "helper_text": "Domain for domain permissions",
                    "placeholder": "Enter domain",
                },
                {
                    "field": "send_notification_email",
                    "type": "bool",
                    "value": False,
                    "label": "Send Notification Email",
                    "helper_text": "Whether to send notification email",
                },
                {
                    "field": "email_message",
                    "type": "string",
                    "value": "",
                    "label": "Email Message",
                    "helper_text": "Custom message for the notification email",
                    "placeholder": "Enter custom message",
                },
            ],
            "outputs": [
                {
                    "field": "permission_id",
                    "type": "string",
                    "helper_text": "ID of the created permission",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "Role of the permission",
                },
                {
                    "field": "type",
                    "type": "string",
                    "helper_text": "Type of the permission",
                },
                {
                    "field": "email_address",
                    "type": "string",
                    "helper_text": "Email address of the permission",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Display name of the permission",
                },
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the shared folder",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "share_folder",
            "hidden": True,
            "task_name": "tasks.google_drive.share_folder",
            "description": "Share a folder with users or groups",
            "label": "Share Folder",
            "ui_sort_order": [
                "integration",
                "action",
                "folder_id",
                "role",
                "type",
                "email_address",
                "domain",
                "send_notification_email",
                "email_message",
            ],
            "required": ["folder_id", "role", "type"],
        },
        "create_shared_drive**(*)**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Drive Name",
                    "helper_text": "Name of the shared drive to create",
                    "placeholder": "Enter shared drive name",
                },
                {
                    "field": "color_rgb",
                    "type": "string",
                    "value": "",
                    "label": "Color RGB",
                    "helper_text": "Color for the shared drive (hex code)",
                    "placeholder": "Enter hex color (e.g., #FF0000)",
                },
                {
                    "field": "hidden",
                    "type": "bool",
                    "value": False,
                    "label": "Hidden",
                    "helper_text": "Whether the shared drive is hidden",
                },
            ],
            "outputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the created shared drive",
                },
                {
                    "field": "drive_name",
                    "type": "string",
                    "helper_text": "Name of the created shared drive",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the shared drive",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "create_shared_drive",
            "variant": "default_integration_nodes",
            "hidden": True,
            "task_name": "tasks.google_drive.create_shared_drive",
            "description": "Create a new shared drive",
            "label": "Create Shared Drive",
            "ui_sort_order": ["integration", "action", "name", "color_rgb", "hidden"],
            "required": ["name"],
        },
        "read_shared_drive**(*)**(*)": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "label": "Drive ID",
                    "helper_text": "ID of the shared drive to read",
                    "placeholder": "Enter shared drive ID",
                },
                {
                    "field": "use_domain_admin_access",
                    "type": "bool",
                    "value": False,
                    "label": "Use Domain Admin Access",
                    "helper_text": "Whether to use domain admin access",
                },
            ],
            "outputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the shared drive",
                },
                {
                    "field": "drive_name",
                    "type": "string",
                    "helper_text": "Name of the shared drive",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the shared drive",
                },
                {
                    "field": "capabilities",
                    "type": "string",
                    "helper_text": "Capabilities of the shared drive",
                },
                {
                    "field": "restrictions",
                    "type": "string",
                    "helper_text": "Restrictions of the shared drive",
                },
                {
                    "field": "color_rgb",
                    "type": "string",
                    "helper_text": "Color of the shared drive",
                },
                {
                    "field": "hidden",
                    "type": "bool",
                    "helper_text": "Whether the shared drive is hidden",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "read_shared_drive",
            "variant": "default_integration_nodes",
            "task_name": "tasks.google_drive.read_shared_drive",
            "description": "Read details of a specific shared drive",
            "label": "Get Shared Drive",
            "inputs_sort_order": [
                "integration",
                "action",
                "drive_id",
                "use_domain_admin_access",
            ],
            "required": ["drive_id"],
        },
        "get_shared_drives**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all shared drives or limit the results",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of shared drives to return (when not returning all)",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "helper_text": "Search query to filter shared drives",
                    "placeholder": "Enter search query",
                },
                {
                    "field": "use_domain_admin_access",
                    "type": "bool",
                    "value": False,
                    "label": "Use Domain Admin Access",
                    "helper_text": "Whether to use domain admin access",
                },
            ],
            "outputs": [
                {
                    "field": "drive_ids",
                    "type": "vec<string>",
                    "helper_text": "List of shared drive IDs",
                },
                {
                    "field": "drive_names",
                    "type": "vec<string>",
                    "helper_text": "List of shared drive names",
                },
                {
                    "field": "drive_created_times",
                    "type": "vec<string>",
                    "helper_text": "List of shared drive creation times",
                },
                {
                    "field": "drive_colors",
                    "type": "vec<string>",
                    "helper_text": "List of shared drive colors",
                },
                {
                    "field": "drive_hidden",
                    "type": "vec<string>",
                    "helper_text": "List of shared drive hidden status",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of shared drives retrieved",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "get_shared_drives",
            "variant": "default_integration_nodes",
            "task_name": "tasks.google_drive.get_shared_drives",
            "description": "Get multiple shared drives",
            "label": "List Shared Drives",
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "query",
                "use_domain_admin_access",
            ],
            "required": ["limit"],
        },
        "update_shared_drive**(*)**(*)": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "label": "Drive ID",
                    "helper_text": "ID of the shared drive to update",
                    "placeholder": "Enter shared drive ID",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Drive Name",
                    "helper_text": "New name for the shared drive",
                    "placeholder": "Enter new drive name",
                },
                {
                    "field": "color_rgb",
                    "type": "string",
                    "value": "",
                    "label": "Color RGB",
                    "helper_text": "New color for the shared drive (hex code)",
                    "placeholder": "Enter hex color (e.g., #FF0000)",
                },
            ],
            "outputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the updated shared drive",
                },
                {
                    "field": "drive_name",
                    "type": "string",
                    "helper_text": "Name of the updated shared drive",
                },
                {
                    "field": "color_rgb",
                    "type": "string",
                    "helper_text": "Color of the updated shared drive",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data from Google Drive API",
                },
            ],
            "name": "update_shared_drive",
            "variant": "default_integration_nodes",
            "hidden": True,
            "task_name": "tasks.google_drive.update_shared_drive",
            "description": "Update shared drive properties",
            "label": "Update Shared Drive",
            "ui_sort_order": ["integration", "action", "drive_id", "name", "color_rgb"],
            "required": ["drive_id"],
        },
        "delete_shared_drive**(*)**(*)": {
            "inputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "value": "",
                    "label": "Drive ID",
                    "helper_text": "ID of the shared drive to delete",
                    "placeholder": "Enter shared drive ID",
                }
            ],
            "outputs": [
                {
                    "field": "drive_id",
                    "type": "string",
                    "helper_text": "ID of the deleted shared drive",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                },
            ],
            "name": "delete_shared_drive",
            "variant": "default_integration_nodes",
            "hidden": True,
            "task_name": "tasks.google_drive.delete_shared_drive",
            "description": "Delete a shared drive",
            "label": "Delete Shared Drive",
            "ui_sort_order": ["integration", "action", "drive_id"],
            "required": ["drive_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        change_file_content: bool = False,
        color_rgb: str = "",
        content: str = "",
        content_type: str = "",
        copy_requires_writer_permission: bool = False,
        corpora: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        delete_permanently: bool = False,
        description: str = "",
        domain: str = "",
        drive_file_url: str = "",
        drive_id: str = "",
        email_address: str = "",
        email_message: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        fields: str = "",
        file: str = "",
        file_data: str = "",
        file_id: str = "",
        file_name: str = "",
        folder_color: str = "",
        folder_id: str = "",
        hidden: bool = False,
        include_items_from_all_drives: bool = True,
        include_labels: str = "",
        include_permissions_for_view: str = "",
        limit: int = 10,
        name: str = "",
        num_messages: int = 10,
        order_by: str = "",
        parent_folder_id: str = "",
        recursive: bool = False,
        return_all: bool = False,
        role: str = "",
        same_folder: bool = False,
        send_notification_email: bool = False,
        spaces: str = "",
        starred: bool = False,
        supports_all_drives: bool = True,
        trashed: bool = False,
        type: str = "",
        use_domain_admin_access: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_google_drive",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if content is not None:
            self.inputs["content"] = content
        if name is not None:
            self.inputs["name"] = name
        if parent_folder_id is not None:
            self.inputs["parent_folder_id"] = parent_folder_id
        if description is not None:
            self.inputs["description"] = description
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if file is not None:
            self.inputs["file"] = file
        if file_id is not None:
            self.inputs["file_id"] = file_id
        if drive_file_url is not None:
            self.inputs["drive_file_url"] = drive_file_url
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if recursive is not None:
            self.inputs["recursive"] = recursive
        if query is not None:
            self.inputs["query"] = query
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if corpora is not None:
            self.inputs["corpora"] = corpora
        if drive_id is not None:
            self.inputs["drive_id"] = drive_id
        if fields is not None:
            self.inputs["fields"] = fields
        if include_items_from_all_drives is not None:
            self.inputs["include_items_from_all_drives"] = include_items_from_all_drives
        if include_labels is not None:
            self.inputs["include_labels"] = include_labels
        if spaces is not None:
            self.inputs["spaces"] = spaces
        if supports_all_drives is not None:
            self.inputs["supports_all_drives"] = supports_all_drives
        if include_permissions_for_view is not None:
            self.inputs["include_permissions_for_view"] = include_permissions_for_view
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if same_folder is not None:
            self.inputs["same_folder"] = same_folder
        if copy_requires_writer_permission is not None:
            self.inputs["copy_requires_writer_permission"] = (
                copy_requires_writer_permission
            )
        if role is not None:
            self.inputs["role"] = role
        if type is not None:
            self.inputs["type"] = type
        if email_address is not None:
            self.inputs["email_address"] = email_address
        if domain is not None:
            self.inputs["domain"] = domain
        if send_notification_email is not None:
            self.inputs["send_notification_email"] = send_notification_email
        if email_message is not None:
            self.inputs["email_message"] = email_message
        if file_name is not None:
            self.inputs["file_name"] = file_name
        if starred is not None:
            self.inputs["starred"] = starred
        if trashed is not None:
            self.inputs["trashed"] = trashed
        if change_file_content is not None:
            self.inputs["change_file_content"] = change_file_content
        if file_data is not None:
            self.inputs["file_data"] = file_data
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if delete_permanently is not None:
            self.inputs["delete_permanently"] = delete_permanently
        if folder_color is not None:
            self.inputs["folder_color"] = folder_color
        if color_rgb is not None:
            self.inputs["color_rgb"] = color_rgb
        if hidden is not None:
            self.inputs["hidden"] = hidden
        if use_domain_admin_access is not None:
            self.inputs["use_domain_admin_access"] = use_domain_admin_access
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleDriveNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
