"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_bland_ai")
class IntegrationBlandAiNode(Node):
    """
    Bland AI

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### call_a_number
        model: LLM model that the AI should use
        temperature: A value between 0 and 1 that controls the randomness of the LLM. 0 will cause more deterministic outputs while 1 will cause more random
        first_sentence: The first sentence the AI should speak during the call
        pathway_id: This is the pathway ID for the pathway you have created on your dev portal.
        phone_number: The phone number of the contact you want to call
        task: The objective you want the AI to accomplish during the call
        transfer_number: A phone number that the agent can transfer to under specific conditions - such as being asked to speak to a human or supervisor
        wait_for_greeting: When checked, the agent will wait for the call recipient to speak first before responding

    ## Outputs
    ### Common Outputs
        answered_by: Possible values: Human: The call was answered by a human, Voicemail: The call was sent to voicemail, Unknown: There was not enough audio at the start of the call to make a determination, No-answer: The call was not answered, Null: Not enabled, or still processing the result
        transcript: The transcript of the call
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Bland AI>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "answered_by",
            "helper_text": "Possible values: Human: The call was answered by a human, Voicemail: The call was sent to voicemail, Unknown: There was not enough audio at the start of the call to make a determination, No-answer: The call was not answered, Null: Not enabled, or still processing the result",
            "type": "string",
        },
        {
            "field": "transcript",
            "helper_text": "The transcript of the call",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "call_a_number": {
            "inputs": [
                {
                    "field": "phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Phone Number",
                    "placeholder": "+1 6173149183",
                    "helper_text": "The phone number of the contact you want to call",
                },
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task",
                    "placeholder": "Get the user's name and email",
                    "helper_text": "The objective you want the AI to accomplish during the call",
                },
                {
                    "field": "first_sentence",
                    "type": "string",
                    "value": "",
                    "label": "Enter First Sentence (Optional)",
                    "placeholder": "Hello, this is...",
                    "helper_text": "The first sentence the AI should speak during the call",
                },
                {
                    "field": "model",
                    "type": "string",
                    "value": "enhanced",
                    "label": "Select Model",
                    "placeholder": "enhanced",
                    "helper_text": "LLM model that the AI should use",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "pathway_id",
                    "type": "string",
                    "value": "",
                    "label": "Enter Pathway ID (Optional)",
                    "placeholder": "pathway_123",
                    "helper_text": "This is the pathway ID for the pathway you have created on your dev portal.",
                },
                {
                    "field": "temperature",
                    "type": "string",
                    "value": "",
                    "label": "Enter Temperature",
                    "placeholder": "0.7",
                    "helper_text": "A value between 0 and 1 that controls the randomness of the LLM. 0 will cause more deterministic outputs while 1 will cause more random",
                },
                {
                    "field": "transfer_number",
                    "type": "string",
                    "value": "",
                    "label": "Enter Transfer Number (Optional)",
                    "placeholder": "+12223334444",
                    "helper_text": "A phone number that the agent can transfer to under specific conditions - such as being asked to speak to a human or supervisor",
                },
                {
                    "field": "wait_for_greeting",
                    "type": "bool",
                    "value": False,
                    "label": "Select Wait for Greeting",
                    "placeholder": False,
                    "helper_text": "When checked, the agent will wait for the call recipient to speak first before responding",
                },
            ],
            "outputs": [],
            "name": "call_a_number",
            "task_name": "tasks.bland_ai.call_a_number",
            "description": "Call a number using AI phone caller",
            "label": "Call a number",
            "variant": "bland_ai",
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        model: str = "enhanced",
        temperature: str = "",
        first_sentence: str = "",
        pathway_id: str = "",
        phone_number: str = "",
        task: str = "",
        transfer_number: str = "",
        wait_for_greeting: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_bland_ai",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if phone_number is not None:
            self.inputs["phone_number"] = phone_number
        if task is not None:
            self.inputs["task"] = task
        if first_sentence is not None:
            self.inputs["first_sentence"] = first_sentence
        if model is not None:
            self.inputs["model"] = model
        if pathway_id is not None:
            self.inputs["pathway_id"] = pathway_id
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if transfer_number is not None:
            self.inputs["transfer_number"] = transfer_number
        if wait_for_greeting is not None:
            self.inputs["wait_for_greeting"] = wait_for_greeting
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationBlandAiNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
