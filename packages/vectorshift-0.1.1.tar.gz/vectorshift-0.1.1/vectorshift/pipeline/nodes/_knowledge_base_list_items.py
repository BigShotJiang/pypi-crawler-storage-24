"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("knowledge_base_list_items")
class KnowledgeBaseListItemsNode(Node):
    """
    List items (documents and folders) from a knowledge base with pagination support

    ## Inputs
    ### Common Inputs
        knowledge_base: Select an existing knowledge base
        limit: Maximum number of items to return
        list_all_items: If true, list all items in the knowledge base. If false, list only root items.
        offset: Number of items to skip for pagination

    ## Outputs
    ### Common Outputs
        has_more: Whether there are more items available
        kb_items: JSON serialized knowledge base items
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "knowledge_base",
            "helper_text": "Select an existing knowledge base",
            "value": {"object_type": 1, "object_id": ""},
            "type": "knowledge_base",
        },
        {
            "field": "limit",
            "helper_text": "Maximum number of items to return",
            "value": 50,
            "type": "int32",
        },
        {
            "field": "list_all_items",
            "helper_text": "If true, list all items in the knowledge base. If false, list only root items.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "offset",
            "helper_text": "Number of items to skip for pagination",
            "value": 0,
            "type": "int32",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "has_more",
            "helper_text": "Whether there are more items available",
            "type": "bool",
        },
        {
            "field": "kb_items",
            "helper_text": "JSON serialized knowledge base items",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["knowledge_base"]

    def __init__(
        self,
        knowledge_base: "KnowledgeBase" = "",
        limit: int = 50,
        list_all_items: bool = False,
        offset: int = 0,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="knowledge_base_list_items",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if knowledge_base is not None:
            self.inputs["knowledge_base"] = knowledge_base
        if limit is not None:
            self.inputs["limit"] = limit
        if offset is not None:
            self.inputs["offset"] = offset
        if list_all_items is not None:
            self.inputs["list_all_items"] = list_all_items
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseListItemsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
