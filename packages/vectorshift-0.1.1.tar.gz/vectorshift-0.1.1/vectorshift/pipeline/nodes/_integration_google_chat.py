"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_chat")
class IntegrationGoogleChatNode(Node):
    """
    Integrate with Google Chat to send messages, manage spaces, and handle memberships

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### get_spaces
        filter: Filter for spaces
        page_size: The number of memberships to return
    ### read_membership
        membership_id: The ID of the membership
        space_id: The ID of the space
    ### delete_message
        message_id: The ID of the message to delete
        space_id: The ID of the space
    ### read_message
        message_id: The ID of the message to delete
        space_id: The ID of the space
    ### update_message
        message_id: The ID of the message to delete
        message_text: The text of the message
        space_id: The ID of the space
        update_mask: Update mask for the message
    ### send_message
        message_text: The text of the message
        space_id: The ID of the space
        thread_key: Thread key for threaded messages
    ### get_memberships
        page_size: The number of memberships to return
        space_id: The ID of the space
    ### read_space
        space_id: The ID of the space

    ## Outputs
    ### read_membership
        created_time: The creation time of the membership
        member_display_name: The display name of the member
        member_info: Formatted member information
        member_name: The name of the member
        member_type: The type of the member
        membership_id: The ID of the membership
        membership_role: The role of the membership
        membership_state: The state of the membership
        raw_data: Raw membership data
    ### send_message
        created_time: Creation time of the message
        message_id: ID of the created message
        message_text: Text content of the message
        raw_data: Raw message data
        sender_display_name: Display name of the sender
        sender_name: Name of the sender
        sender_type: Type of the sender
        thread_key: Key of the thread
        thread_name: Name of the thread
        updated_time: Last update time of the message
    ### read_message
        created_time: Creation time of the message
        message_content: Content of the message (alias for message_text)
        message_id: ID of the message
        message_text: Text content of the message
        raw_data: Raw message data
        sender_display_name: Display name of the sender
        sender_name: Name of the sender
        sender_type: Type of the sender
        thread_key: Key of the thread
        thread_name: Name of the thread
        updated_time: Last update time of the message
    ### update_message
        created_time: Creation time of the message
        message_id: ID of the updated message
        message_text: Updated text content of the message
        raw_data: Raw updated message data
        sender_display_name: Display name of the sender
        sender_name: Name of the sender
        sender_type: Type of the sender
        thread_key: Key of the thread
        thread_name: Name of the thread
        updated_time: Last update time of the message
    ### read_space
        created_time: Creation time of the space
        modified_time: Last modified time of the space
        raw_data: Raw space data
        space_id: ID of the space
        space_info: Formatted space information
        space_name: Name of the space
        space_type: Type of the space
    ### get_memberships
        created_times: List of creation times
        member_display_names: List of member display names
        member_names: List of member names
        member_types: List of member types
        membership_count: Total number of memberships
        membership_ids: List of membership IDs
        membership_roles: List of membership roles
        membership_states: List of membership states
        memberships: List of membership objects
        raw_data: Raw memberships data
        total_count: Total count of memberships
    ### get_spaces
        created_times: List of creation times
        modified_times: List of modification times
        raw_data: Raw spaces data
        space_count: Total number of spaces
        space_ids: List of space IDs
        space_names: List of space names
        space_types: List of space types
        spaces: List of space objects
        total_count: Total count of spaces
    ### delete_message
        deleted_message_id: ID of the deleted message
        message: Success message
        raw_data: Raw delete operation data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Chat>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "read_membership": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "membership_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the membership",
                    "label": "Membership",
                    "placeholder": "Select membership",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=membership_id&space_id={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "membership_id",
                    "type": "string",
                    "helper_text": "The ID of the membership",
                },
                {
                    "field": "membership_state",
                    "type": "string",
                    "helper_text": "The state of the membership",
                },
                {
                    "field": "membership_role",
                    "type": "string",
                    "helper_text": "The role of the membership",
                },
                {
                    "field": "member_name",
                    "type": "string",
                    "helper_text": "The name of the member",
                },
                {
                    "field": "member_display_name",
                    "type": "string",
                    "helper_text": "The display name of the member",
                },
                {
                    "field": "member_type",
                    "type": "string",
                    "helper_text": "The type of the member",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "The creation time of the membership",
                },
                {
                    "field": "member_info",
                    "type": "string",
                    "helper_text": "Formatted member information",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw membership data",
                },
            ],
            "name": "read_membership",
            "task_name": "tasks.google_chat.read_membership",
            "description": "Read details of a specific membership",
            "label": "Get Membership",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "space_id", "membership_id"],
            "required": ["space_id", "membership_id"],
        },
        "get_memberships": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "page_size",
                    "type": "string",
                    "value": "",
                    "helper_text": "The number of memberships to return",
                    "label": "Page Size",
                    "placeholder": "100",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "memberships",
                    "type": "string",
                    "helper_text": "List of membership objects",
                },
                {
                    "field": "membership_count",
                    "type": "int32",
                    "helper_text": "Total number of memberships",
                },
                {
                    "field": "membership_ids",
                    "type": "vec<string>",
                    "helper_text": "List of membership IDs",
                },
                {
                    "field": "membership_states",
                    "type": "vec<string>",
                    "helper_text": "List of membership states",
                },
                {
                    "field": "membership_roles",
                    "type": "vec<string>",
                    "helper_text": "List of membership roles",
                },
                {
                    "field": "member_names",
                    "type": "vec<string>",
                    "helper_text": "List of member names",
                },
                {
                    "field": "member_display_names",
                    "type": "vec<string>",
                    "helper_text": "List of member display names",
                },
                {
                    "field": "member_types",
                    "type": "vec<string>",
                    "helper_text": "List of member types",
                },
                {
                    "field": "created_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation times",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total count of memberships",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw memberships data",
                },
            ],
            "name": "get_memberships",
            "task_name": "tasks.google_chat.get_memberships",
            "description": "Get multiple memberships",
            "label": "List Memberships",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "space_id", "page_size"],
            "required": ["space_id"],
        },
        "send_message": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "message_text",
                    "type": "string",
                    "value": "",
                    "helper_text": "The text of the message",
                    "label": "Message Text",
                    "placeholder": "Hello, this is a message",
                    "order": 4,
                },
                {
                    "field": "thread_key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Thread key for threaded messages",
                    "label": "Thread Key",
                    "placeholder": "Optional thread key",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the created message",
                },
                {
                    "field": "message_text",
                    "type": "string",
                    "helper_text": "Text content of the message",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the message",
                },
                {
                    "field": "updated_time",
                    "type": "timestamp",
                    "helper_text": "Last update time of the message",
                },
                {
                    "field": "thread_name",
                    "type": "string",
                    "helper_text": "Name of the thread",
                },
                {
                    "field": "thread_key",
                    "type": "string",
                    "helper_text": "Key of the thread",
                },
                {
                    "field": "sender_name",
                    "type": "string",
                    "helper_text": "Name of the sender",
                },
                {
                    "field": "sender_display_name",
                    "type": "string",
                    "helper_text": "Display name of the sender",
                },
                {
                    "field": "sender_type",
                    "type": "string",
                    "helper_text": "Type of the sender",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw message data",
                },
            ],
            "name": "send_message",
            "task_name": "tasks.google_chat.send_message",
            "description": "Send a message",
            "label": "Send Message",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "space_id",
                "message_text",
                "thread_key",
            ],
            "required": ["space_id", "message_text"],
        },
        "delete_message": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the message to delete",
                    "label": "Message",
                    "placeholder": "Select message",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=message_id&space_id={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "deleted_message_id",
                    "type": "string",
                    "helper_text": "ID of the deleted message",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw delete operation data",
                },
            ],
            "name": "delete_message",
            "task_name": "tasks.google_chat.delete_message",
            "description": "Delete a message",
            "label": "Delete Message",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "space_id", "message_id"],
            "required": ["space_id", "message_id"],
        },
        "read_message": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the message",
                    "label": "Message",
                    "placeholder": "Select message",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=message_id&space_id={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the message",
                },
                {
                    "field": "message_text",
                    "type": "string",
                    "helper_text": "Text content of the message",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the message",
                },
                {
                    "field": "updated_time",
                    "type": "timestamp",
                    "helper_text": "Last update time of the message",
                },
                {
                    "field": "thread_name",
                    "type": "string",
                    "helper_text": "Name of the thread",
                },
                {
                    "field": "thread_key",
                    "type": "string",
                    "helper_text": "Key of the thread",
                },
                {
                    "field": "sender_name",
                    "type": "string",
                    "helper_text": "Name of the sender",
                },
                {
                    "field": "sender_display_name",
                    "type": "string",
                    "helper_text": "Display name of the sender",
                },
                {
                    "field": "sender_type",
                    "type": "string",
                    "helper_text": "Type of the sender",
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "helper_text": "Content of the message (alias for message_text)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw message data",
                },
            ],
            "name": "read_message",
            "task_name": "tasks.google_chat.read_message",
            "description": "Read details of a specific message",
            "label": "Get Message",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "space_id", "message_id"],
            "required": ["space_id", "message_id"],
        },
        "update_message": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the message to update",
                    "label": "Message",
                    "placeholder": "Select message",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=message_id&space_id={inputs.space_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "message_text",
                    "type": "string",
                    "value": "",
                    "helper_text": "The new text of the message",
                    "label": "Message Text",
                    "placeholder": "Updated message text",
                    "order": 5,
                },
                {
                    "field": "update_mask",
                    "type": "string",
                    "value": "",
                    "helper_text": "Update mask for the message",
                    "label": "Update Mask",
                    "placeholder": "text",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the updated message",
                },
                {
                    "field": "message_text",
                    "type": "string",
                    "helper_text": "Updated text content of the message",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the message",
                },
                {
                    "field": "updated_time",
                    "type": "timestamp",
                    "helper_text": "Last update time of the message",
                },
                {
                    "field": "thread_name",
                    "type": "string",
                    "helper_text": "Name of the thread",
                },
                {
                    "field": "thread_key",
                    "type": "string",
                    "helper_text": "Key of the thread",
                },
                {
                    "field": "sender_name",
                    "type": "string",
                    "helper_text": "Name of the sender",
                },
                {
                    "field": "sender_display_name",
                    "type": "string",
                    "helper_text": "Display name of the sender",
                },
                {
                    "field": "sender_type",
                    "type": "string",
                    "helper_text": "Type of the sender",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw updated message data",
                },
            ],
            "name": "update_message",
            "task_name": "tasks.google_chat.update_message",
            "description": "Update a message",
            "label": "Update Message",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "space_id",
                "message_id",
                "message_text",
                "update_mask",
            ],
            "required": ["space_id", "message_id", "message_text"],
        },
        "read_space": {
            "inputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the space",
                    "label": "Space",
                    "placeholder": "Select space",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=space_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                }
            ],
            "outputs": [
                {
                    "field": "space_id",
                    "type": "string",
                    "helper_text": "ID of the space",
                },
                {
                    "field": "space_name",
                    "type": "string",
                    "helper_text": "Name of the space",
                },
                {
                    "field": "space_type",
                    "type": "string",
                    "helper_text": "Type of the space",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the space",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "Last modified time of the space",
                },
                {
                    "field": "space_info",
                    "type": "string",
                    "helper_text": "Formatted space information",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw space data",
                },
            ],
            "name": "read_space",
            "task_name": "tasks.google_chat.read_space",
            "description": "Read details of a specific space",
            "label": "Get Space",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "space_id"],
            "required": ["space_id"],
        },
        "get_spaces": {
            "inputs": [
                {
                    "field": "page_size",
                    "type": "string",
                    "value": "",
                    "helper_text": "The number of spaces to return",
                    "label": "Page Size",
                    "placeholder": "100",
                    "order": 3,
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter for spaces",
                    "label": "Filter",
                    "placeholder": "Optional filter",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "spaces",
                    "type": "string",
                    "helper_text": "List of space objects",
                },
                {
                    "field": "space_count",
                    "type": "int32",
                    "helper_text": "Total number of spaces",
                },
                {
                    "field": "space_ids",
                    "type": "vec<string>",
                    "helper_text": "List of space IDs",
                },
                {
                    "field": "space_names",
                    "type": "vec<string>",
                    "helper_text": "List of space names",
                },
                {
                    "field": "space_types",
                    "type": "vec<string>",
                    "helper_text": "List of space types",
                },
                {
                    "field": "created_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation times",
                },
                {
                    "field": "modified_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of modification times",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total count of spaces",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw spaces data",
                },
            ],
            "name": "get_spaces",
            "task_name": "tasks.google_chat.get_spaces",
            "description": "Get multiple spaces the caller is a member of",
            "label": "List Spaces",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "page_size", "filter"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        filter: str = "",
        membership_id: str = "",
        message_id: str = "",
        message_text: str = "",
        page_size: str = "",
        space_id: str = "",
        thread_key: str = "",
        update_mask: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_chat",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if integration is not None:
            self.inputs["integration"] = integration
        if action is not None:
            self.inputs["action"] = action
        if space_id is not None:
            self.inputs["space_id"] = space_id
        if membership_id is not None:
            self.inputs["membership_id"] = membership_id
        if page_size is not None:
            self.inputs["page_size"] = page_size
        if message_text is not None:
            self.inputs["message_text"] = message_text
        if thread_key is not None:
            self.inputs["thread_key"] = thread_key
        if message_id is not None:
            self.inputs["message_id"] = message_id
        if update_mask is not None:
            self.inputs["update_mask"] = update_mask
        if filter is not None:
            self.inputs["filter"] = filter
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleChatNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
