"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_powerbi")
class IntegrationPowerbiNode(Node):
    """
    Power BI

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Power BI account
    ### get_workspace_info
        artifact_users: Include users for each artifact
        dataset_expressions: Include M and DAX expressions
        dataset_schema: Include dataset schema
        datasource_details: Include datasource details
        lineage: Include lineage information
        workspace_id: Select a workspace (required)
    ### get_dashboard
        dashboard_id: Select the dashboard to retrieve (required)
        workspace_id: Select a workspace (required)
    ### get_dashboard_tiles
        dashboard_id: Select the dashboard to retrieve (required)
        workspace_id: Select a workspace (required)
    ### get_dataflow
        dataflow_id: Select the dataflow to retrieve (required)
        workspace_id: Select a workspace (required)
    ### get_dataflow_datasources
        dataflow_id: Select the dataflow to retrieve (required)
        workspace_id: Select a workspace (required)
    ### get_dataflow_transactions
        dataflow_id: Select the dataflow to retrieve (required)
        workspace_id: Select a workspace (required)
    ### refresh_dataflow
        dataflow_id: Select the dataflow to retrieve (required)
        notify_option: Notification option after refresh completes
        workspace_id: Select a workspace (required)
    ### add_rows
        dataset_id: Select the dataset (required)
        rows_data: JSON array of row objects to add
        table_name: Select the table to add rows to (required)
        workspace_id: Select a workspace (required)
    ### get_dataset
        dataset_id: Select the dataset (required)
        workspace_id: Select a workspace (required)
    ### get_tables
        dataset_id: Select the dataset (required)
        workspace_id: Select a workspace (required)
    ### get_refresh_history
        dataset_id: Select the dataset (required)
        top: Maximum number of refresh entries to return
        workspace_id: Select a workspace (required)
    ### execute_dax_query
        dataset_id: Select the dataset (required)
        dax_query: DAX query to execute (e.g., EVALUATE VALUES(TableName))
        impersonated_user: UPN of user to impersonate (for RLS)
        include_nulls: Whether to include null values in results
        workspace_id: Select a workspace (required)
    ### refresh_dataset
        dataset_id: Select the dataset (required)
        notify_option: Notification option after refresh completes
        workspace_id: Select a workspace (required)
    ### get_gateway_datasource
        datasource_id: Select the datasource to retrieve (required)
        gateway_id: Select the gateway to retrieve (required)
    ### get_datasource_status
        datasource_id: Select the datasource to retrieve (required)
        gateway_id: Select the gateway to retrieve (required)
    ### get_datasource_users
        datasource_id: Select the datasource to retrieve (required)
        gateway_id: Select the gateway to retrieve (required)
    ### export_report
        export_format: Format to export (PDF, PPTX, PNG)
        report_id: Select the report to retrieve (required)
        wait_for_completion: Wait for export to complete before returning
        workspace_id: Select a workspace (required)
    ### get_gateway
        gateway_id: Select the gateway to retrieve (required)
    ### get_gateway_datasources
        gateway_id: Select the gateway to retrieve (required)
    ### list_datasets
        limit: Maximum number of datasets to return
        workspace_id: Select a workspace (required)
    ### list_reports
        limit: Maximum number of datasets to return
        workspace_id: Select a workspace (required)
    ### list_dashboards
        limit: Maximum number of datasets to return
        workspace_id: Select a workspace (required)
    ### list_workspaces
        limit: Maximum number of datasets to return
    ### list_dataflows
        limit: Maximum number of datasets to return
        workspace_id: Select a workspace (required)
    ### list_gateways
        limit: Maximum number of datasets to return
    ### get_report
        report_id: Select the report to retrieve (required)
        workspace_id: Select a workspace (required)
    ### get_report_pages
        report_id: Select the report to retrieve (required)
        workspace_id: Select a workspace (required)
    ### get_scan_result
        scan_id: Select scan ID (initiates a new scan for the workspace)
        workspace_id: Select a workspace (required)
    ### get_workspace
        workspace_id: Select a workspace (required)
    ### get_workspace_reports
        workspace_id: Select a workspace (required)
    ### get_workspace_dashboards
        workspace_id: Select a workspace (required)
    ### get_workspace_datasets
        workspace_id: Select a workspace (required)

    ## Outputs
    ### get_dashboard
        app_id: The app_id output
        dashboard_id: The dashboard_id output
        dashboard_name: The dashboard_name output
        data_classification: The data_classification output
        embed_url: The embed_url output
        is_read_only: The is_read_only output
        raw_data: The raw_data output
        web_url: The web_url output
    ### get_workspace
        capacity_id: The capacity_id output
        description: The description output
        is_on_dedicated_capacity: The is_on_dedicated_capacity output
        is_read_only: The is_read_only output
        raw_data: The raw_data output
        state: The state output
        workspace_id: The workspace_id output
        workspace_name: The workspace_name output
    ### get_dataset
        configured_by: The configured_by output
        created_date: The created_date output
        dataset_id: The ID of the dataset
        dataset_name: The dataset_name output
        is_refreshable: The is_refreshable output
        raw_data: The raw_data output
        web_url: The web_url output
    ### get_dataflow
        configured_by: The configured_by output
        dataflow_id: The dataflow_id output
        dataflow_name: The dataflow_name output
        description: The description output
        model_url: The model_url output
        modified_by: The modified_by output
        modified_date_time: The modified_date_time output
        raw_data: The raw_data output
    ### get_gateway_datasource
        connection_details: The connection_details output
        credential_type: The credential_type output
        datasource_id: The datasource_id output
        datasource_name: The datasource_name output
        datasource_type: The datasource_type output
        raw_data: The raw_data output
    ### get_report
        created_by: The created_by output
        created_date_time: The created_date_time output
        dataset_id: The ID of the dataset
        description: The description output
        embed_url: The embed_url output
        modified_by: The modified_by output
        modified_date_time: The modified_date_time output
        raw_data: The raw_data output
        report_id: The report_id output
        report_name: The report_name output
        report_type: The report_type output
        web_url: The web_url output
    ### get_workspace_info
        created_date_time: The created_date_time output
        message: The message output
        raw_data: The raw_data output
        scan_id: The scan_id output
        status: The status output
        workspace_ids: The workspace_ids output
    ### list_dashboards
        dashboard_ids: The dashboard_ids output
        dashboard_names: The dashboard_names output
        dashboards: The dashboards output
        embed_urls: The embed_urls output
        raw_data: The raw_data output
        total_count: The total_count output
        web_urls: The web_urls output
    ### get_workspace_dashboards
        dashboard_ids: The dashboard_ids output
        dashboard_names: The dashboard_names output
        dashboards: The dashboards output
        raw_data: The raw_data output
        total_count: The total_count output
    ### list_dataflows
        dataflow_ids: The dataflow_ids output
        dataflow_names: The dataflow_names output
        dataflows: The dataflows output
        raw_data: The raw_data output
        total_count: The total_count output
    ### list_datasets
        dataset_ids: The dataset_ids output
        dataset_names: The dataset_names output
        datasets: The datasets output
        raw_data: The raw_data output
        total_count: The total_count output
    ### list_reports
        dataset_ids: The dataset_ids output
        raw_data: The raw_data output
        report_ids: The report_ids output
        report_names: The report_names output
        reports: The reports output
        total_count: The total_count output
        web_urls: The web_urls output
    ### get_dashboard_tiles
        dataset_ids: The dataset_ids output
        embed_urls: The embed_urls output
        raw_data: The raw_data output
        report_ids: The report_ids output
        tile_ids: The tile_ids output
        tile_titles: The tile_titles output
        tiles: The tiles output
        total_count: The total_count output
    ### get_workspace_datasets
        dataset_ids: The dataset_ids output
        dataset_names: The dataset_names output
        datasets: The datasets output
        raw_data: The raw_data output
        total_count: The total_count output
    ### get_dataflow_datasources
        datasource_ids: The datasource_ids output
        datasource_types: The datasource_types output
        datasources: The datasources output
        raw_data: The raw_data output
        total_count: The total_count output
    ### get_gateway_datasources
        datasource_ids: The datasource_ids output
        datasource_names: The datasource_names output
        datasources: The datasources output
        raw_data: The raw_data output
        total_count: The total_count output
    ### get_report_pages
        display_names: The display_names output
        page_names: The page_names output
        pages: The pages output
        raw_data: The raw_data output
        total_count: The total_count output
    ### get_refresh_history
        end_times: The end_times output
        raw_data: The raw_data output
        refresh_history: The refresh_history output
        refresh_statuses: The refresh_statuses output
        refresh_types: The refresh_types output
        start_times: The start_times output
        total_count: The total_count output
    ### export_report
        export_id: The export_id output
        file: The file output
        file_url: The file_url output
        raw_data: The raw_data output
        status: The status output
    ### get_gateway
        gateway_annotation: The gateway_annotation output
        gateway_id: The gateway_id output
        gateway_name: The gateway_name output
        gateway_type: The gateway_type output
        public_key: The public_key output
        raw_data: The raw_data output
    ### list_gateways
        gateway_ids: The gateway_ids output
        gateway_names: The gateway_names output
        gateways: The gateways output
        raw_data: The raw_data output
        total_count: The total_count output
    ### refresh_dataflow
        message: The message output
    ### add_rows
        raw_data: Raw API response data
    ### get_tables
        raw_data: The raw_data output
        table_names: The table_names output
        tables: The tables output
        total_count: The total_count output
    ### execute_dax_query
        raw_data: The raw_data output
        results: The results output
        row_count: The row_count output
    ### refresh_dataset
        raw_data: The raw_data output
        request_id: The request_id output
    ### get_workspace_reports
        raw_data: The raw_data output
        report_ids: The report_ids output
        report_names: The report_names output
        reports: The reports output
        total_count: The total_count output
    ### list_workspaces
        raw_data: The raw_data output
        total_count: The total_count output
        workspace_ids: The workspace_ids output
        workspace_names: The workspace_names output
        workspaces: The workspaces output
    ### get_dataflow_transactions
        raw_data: The raw_data output
        statuses: The statuses output
        total_count: The total_count output
        transaction_ids: The transaction_ids output
        transactions: The transactions output
    ### get_datasource_status
        raw_data: The raw_data output
        status: The status output
    ### get_datasource_users
        raw_data: The raw_data output
        total_count: The total_count output
        user_emails: The user_emails output
        user_ids: The user_ids output
        users: The users output
    ### get_scan_result
        raw_data: The raw_data output
        status: The status output
        total_dashboards: The total_dashboards output
        total_dataflows: The total_dataflows output
        total_datasets: The total_datasets output
        total_reports: The total_reports output
        total_workspaces: The total_workspaces output
        workspace_ids: The workspace_ids output
        workspace_names: The workspace_names output
        workspaces: The workspaces output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Power BI account",
            "value": None,
            "type": "integration<Powerbi>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "add_rows": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset",
                    "helper_text": "Select the dataset (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "helper_text": "Select the table to add rows to (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&workspace_id={inputs.workspace_id}&dataset_id={inputs.dataset_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "rows_data",
                    "type": "string",
                    "value": "",
                    "label": "Rows Data (JSON)",
                    "helper_text": "JSON array of row objects to add",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "add_rows",
            "task_name": "tasks.powerbi.add_rows",
            "description": "Add rows to a dataset table",
            "label": "Add Rows",
            "required": ["workspace_id", "dataset_id", "table_name", "rows_data"],
            "input_sort_order": [
                "workspace_id",
                "dataset_id",
                "table_name",
                "rows_data",
            ],
        },
        "get_dataset": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset",
                    "helper_text": "Select the dataset to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "dataset_id",
                    "type": "string",
                    "helper_text": "The ID of the dataset",
                },
                {"field": "dataset_name", "type": "string", "label": "Dataset Name"},
                {"field": "web_url", "type": "string", "label": "Web URL"},
                {"field": "is_refreshable", "type": "bool", "label": "Is Refreshable"},
                {"field": "configured_by", "type": "string", "label": "Configured By"},
                {"field": "created_date", "type": "timestamp", "label": "Created Date"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_dataset",
            "task_name": "tasks.powerbi.get_dataset",
            "description": "Read details of a specific dataset",
            "label": "Get Dataset",
            "required": ["workspace_id", "dataset_id"],
            "input_sort_order": ["workspace_id", "dataset_id"],
        },
        "get_tables": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset",
                    "helper_text": "Select the dataset (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "tables", "type": "vec<string>", "label": "Tables (JSON)"},
                {"field": "table_names", "type": "vec<string>", "label": "Table Names"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_tables",
            "task_name": "tasks.powerbi.get_tables",
            "description": "Read tables from a dataset",
            "label": "Get Tables",
            "required": ["workspace_id", "dataset_id"],
            "input_sort_order": ["workspace_id", "dataset_id"],
        },
        "get_refresh_history": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset",
                    "helper_text": "Select the dataset (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "top",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of refresh entries to return",
                },
            ],
            "outputs": [
                {
                    "field": "refresh_history",
                    "type": "vec<string>",
                    "label": "Refresh History (JSON)",
                },
                {
                    "field": "refresh_types",
                    "type": "vec<string>",
                    "label": "Refresh Types",
                },
                {
                    "field": "refresh_statuses",
                    "type": "vec<string>",
                    "label": "Refresh Statuses",
                },
                {"field": "start_times", "type": "vec<string>", "label": "Start Times"},
                {"field": "end_times", "type": "vec<string>", "label": "End Times"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_refresh_history",
            "task_name": "tasks.powerbi.get_refresh_history",
            "description": "Read refresh history of a dataset",
            "label": "Get Refresh History",
            "required": ["workspace_id", "dataset_id"],
            "input_sort_order": ["workspace_id", "dataset_id", "top"],
        },
        "execute_dax_query": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset",
                    "helper_text": "Select the dataset to query (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dax_query",
                    "type": "string",
                    "value": "",
                    "label": "DAX Query",
                    "helper_text": "DAX query to execute (e.g., EVALUATE VALUES(TableName))",
                },
                {
                    "field": "include_nulls",
                    "type": "bool",
                    "value": False,
                    "label": "Include Nulls",
                    "helper_text": "Whether to include null values in results",
                },
                {
                    "field": "impersonated_user",
                    "type": "string",
                    "value": "",
                    "label": "Impersonated User",
                    "helper_text": "UPN of user to impersonate (for RLS)",
                },
            ],
            "outputs": [
                {
                    "field": "results",
                    "type": "vec<string>",
                    "label": "Query Results (JSON)",
                },
                {"field": "row_count", "type": "string", "label": "Row Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "execute_dax_query",
            "task_name": "tasks.powerbi.execute_dax_query",
            "description": "Execute a DAX query on a dataset",
            "label": "Execute DAX Query",
            "required": ["workspace_id", "dataset_id", "dax_query"],
            "input_sort_order": [
                "workspace_id",
                "dataset_id",
                "dax_query",
                "include_nulls",
                "impersonated_user",
            ],
        },
        "list_datasets": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of datasets to return",
                },
            ],
            "outputs": [
                {
                    "field": "datasets",
                    "type": "vec<string>",
                    "label": "Datasets (JSON)",
                },
                {"field": "dataset_ids", "type": "vec<string>", "label": "Dataset IDs"},
                {
                    "field": "dataset_names",
                    "type": "vec<string>",
                    "label": "Dataset Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "list_datasets",
            "task_name": "tasks.powerbi.list_datasets",
            "description": "Get multiple datasets from a workspace",
            "label": "List Datasets",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id", "limit"],
        },
        "refresh_dataset": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataset_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataset",
                    "helper_text": "Select the dataset to refresh (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataset_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "notify_option",
                    "type": "string",
                    "value": "NoNotification",
                    "label": "Notify Option",
                    "helper_text": "Notification option after refresh completes",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Notification", "value": "NoNotification"},
                            {"label": "Mail On Failure", "value": "MailOnFailure"},
                            {
                                "label": "Mail On Completion",
                                "value": "MailOnCompletion",
                            },
                        ],
                    },
                },
            ],
            "outputs": [
                {"field": "request_id", "type": "string", "label": "Request ID"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "refresh_dataset",
            "task_name": "tasks.powerbi.refresh_dataset",
            "description": "Refresh a dataset",
            "label": "Refresh Dataset",
            "required": ["workspace_id", "dataset_id"],
            "input_sort_order": ["workspace_id", "dataset_id", "notify_option"],
        },
        "get_report": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "report_id",
                    "type": "string",
                    "value": "",
                    "label": "Report",
                    "helper_text": "Select the report to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=report_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "report_id", "type": "string", "label": "Report ID"},
                {"field": "report_name", "type": "string", "label": "Report Name"},
                {"field": "web_url", "type": "string", "label": "Web URL"},
                {"field": "embed_url", "type": "string", "label": "Embed URL"},
                {
                    "field": "dataset_id",
                    "type": "string",
                    "helper_text": "The ID of the dataset",
                },
                {"field": "report_type", "type": "string", "label": "Report Type"},
                {"field": "description", "type": "string", "label": "Description"},
                {
                    "field": "created_date_time",
                    "type": "timestamp",
                    "label": "Created Date Time",
                },
                {
                    "field": "modified_date_time",
                    "type": "timestamp",
                    "label": "Modified Date Time",
                },
                {"field": "modified_by", "type": "string", "label": "Modified By"},
                {"field": "created_by", "type": "string", "label": "Created By"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_report",
            "task_name": "tasks.powerbi.get_report",
            "description": "Read details of a specific report",
            "label": "Get Report",
            "required": ["workspace_id", "report_id"],
            "input_sort_order": ["workspace_id", "report_id"],
        },
        "get_report_pages": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "report_id",
                    "type": "string",
                    "value": "",
                    "label": "Report",
                    "helper_text": "Select the report (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=report_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "pages", "type": "vec<string>", "label": "Pages (JSON)"},
                {"field": "page_names", "type": "vec<string>", "label": "Page Names"},
                {
                    "field": "display_names",
                    "type": "vec<string>",
                    "label": "Display Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_report_pages",
            "task_name": "tasks.powerbi.get_report_pages",
            "description": "Read pages from a report",
            "label": "Get Report Pages",
            "required": ["workspace_id", "report_id"],
            "input_sort_order": ["workspace_id", "report_id"],
        },
        "list_reports": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of reports to return",
                },
            ],
            "outputs": [
                {"field": "reports", "type": "vec<string>", "label": "Reports (JSON)"},
                {"field": "report_ids", "type": "vec<string>", "label": "Report IDs"},
                {
                    "field": "report_names",
                    "type": "vec<string>",
                    "label": "Report Names",
                },
                {"field": "web_urls", "type": "vec<string>", "label": "Web URLs"},
                {"field": "dataset_ids", "type": "vec<string>", "label": "Dataset IDs"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "list_reports",
            "task_name": "tasks.powerbi.list_reports",
            "description": "Get multiple reports from a workspace",
            "label": "List Reports",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id", "limit"],
        },
        "export_report": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "report_id",
                    "type": "string",
                    "value": "",
                    "label": "Report",
                    "helper_text": "Select the report to export (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=report_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "export_format",
                    "type": "string",
                    "value": "PDF",
                    "label": "Export Format",
                    "helper_text": "Format to export (PDF, PPTX, PNG)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "PDF", "value": "PDF"},
                            {"label": "PowerPoint", "value": "PPTX"},
                            {"label": "PNG", "value": "PNG"},
                        ],
                    },
                },
                {
                    "field": "wait_for_completion",
                    "type": "bool",
                    "value": True,
                    "label": "Wait for Completion",
                    "helper_text": "Wait for export to complete before returning",
                },
            ],
            "outputs": [
                {"field": "export_id", "type": "string", "label": "Export ID"},
                {"field": "status", "type": "string", "label": "Status"},
                {"field": "file_url", "type": "string", "label": "File URL"},
                {"field": "file", "type": "file", "label": "Exported File"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "export_report",
            "task_name": "tasks.powerbi.export_report",
            "description": "Export a report to file format",
            "label": "Export Report",
            "required": ["workspace_id", "report_id"],
            "input_sort_order": [
                "workspace_id",
                "report_id",
                "export_format",
                "wait_for_completion",
            ],
        },
        "get_dashboard": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dashboard_id",
                    "type": "string",
                    "value": "",
                    "label": "Dashboard",
                    "helper_text": "Select the dashboard to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dashboard_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "dashboard_id", "type": "string", "label": "Dashboard ID"},
                {
                    "field": "dashboard_name",
                    "type": "string",
                    "label": "Dashboard Name",
                },
                {"field": "web_url", "type": "string", "label": "Web URL"},
                {"field": "embed_url", "type": "string", "label": "Embed URL"},
                {"field": "is_read_only", "type": "bool", "label": "Is Read Only"},
                {"field": "app_id", "type": "string", "label": "App ID"},
                {
                    "field": "data_classification",
                    "type": "string",
                    "label": "Data Classification",
                },
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_dashboard",
            "task_name": "tasks.powerbi.get_dashboard",
            "description": "Read details of a specific dashboard",
            "label": "Get Dashboard",
            "required": ["workspace_id", "dashboard_id"],
            "input_sort_order": ["workspace_id", "dashboard_id"],
        },
        "get_dashboard_tiles": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dashboard_id",
                    "type": "string",
                    "value": "",
                    "label": "Dashboard",
                    "helper_text": "Select the dashboard (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dashboard_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "tiles", "type": "vec<string>", "label": "Tiles (JSON)"},
                {"field": "tile_ids", "type": "vec<string>", "label": "Tile IDs"},
                {"field": "tile_titles", "type": "vec<string>", "label": "Tile Titles"},
                {"field": "report_ids", "type": "vec<string>", "label": "Report IDs"},
                {"field": "dataset_ids", "type": "vec<string>", "label": "Dataset IDs"},
                {"field": "embed_urls", "type": "vec<string>", "label": "Embed URLs"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_dashboard_tiles",
            "task_name": "tasks.powerbi.get_dashboard_tiles",
            "description": "Read tiles from a dashboard",
            "label": "Get Dashboard Tiles",
            "required": ["workspace_id", "dashboard_id"],
            "input_sort_order": ["workspace_id", "dashboard_id"],
        },
        "list_dashboards": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of dashboards to return",
                },
            ],
            "outputs": [
                {
                    "field": "dashboards",
                    "type": "vec<string>",
                    "label": "Dashboards (JSON)",
                },
                {
                    "field": "dashboard_ids",
                    "type": "vec<string>",
                    "label": "Dashboard IDs",
                },
                {
                    "field": "dashboard_names",
                    "type": "vec<string>",
                    "label": "Dashboard Names",
                },
                {"field": "web_urls", "type": "vec<string>", "label": "Web URLs"},
                {"field": "embed_urls", "type": "vec<string>", "label": "Embed URLs"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "list_dashboards",
            "task_name": "tasks.powerbi.list_dashboards",
            "description": "Get multiple dashboards from a workspace",
            "label": "List Dashboards",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id", "limit"],
        },
        "get_workspace": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select the workspace to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "workspace_id", "type": "string", "label": "Workspace ID"},
                {
                    "field": "workspace_name",
                    "type": "string",
                    "label": "Workspace Name",
                },
                {"field": "is_read_only", "type": "bool", "label": "Is Read Only"},
                {
                    "field": "is_on_dedicated_capacity",
                    "type": "bool",
                    "label": "Is On Dedicated Capacity",
                },
                {"field": "capacity_id", "type": "string", "label": "Capacity ID"},
                {"field": "description", "type": "string", "label": "Description"},
                {"field": "state", "type": "string", "label": "State"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_workspace",
            "task_name": "tasks.powerbi.get_workspace",
            "description": "Read details of a specific workspace",
            "label": "Get Workspace",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id"],
        },
        "get_workspace_reports": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select the workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "reports", "type": "vec<string>", "label": "Reports (JSON)"},
                {"field": "report_ids", "type": "vec<string>", "label": "Report IDs"},
                {
                    "field": "report_names",
                    "type": "vec<string>",
                    "label": "Report Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_workspace_reports",
            "task_name": "tasks.powerbi.get_workspace_reports",
            "description": "Read reports from a workspace",
            "label": "Get Workspace Reports",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id"],
        },
        "get_workspace_dashboards": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select the workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "dashboards",
                    "type": "vec<string>",
                    "label": "Dashboards (JSON)",
                },
                {
                    "field": "dashboard_ids",
                    "type": "vec<string>",
                    "label": "Dashboard IDs",
                },
                {
                    "field": "dashboard_names",
                    "type": "vec<string>",
                    "label": "Dashboard Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_workspace_dashboards",
            "task_name": "tasks.powerbi.get_workspace_dashboards",
            "description": "Read dashboards from a workspace",
            "label": "Get Workspace Dashboards",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id"],
        },
        "get_workspace_datasets": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select the workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "datasets",
                    "type": "vec<string>",
                    "label": "Datasets (JSON)",
                },
                {"field": "dataset_ids", "type": "vec<string>", "label": "Dataset IDs"},
                {
                    "field": "dataset_names",
                    "type": "vec<string>",
                    "label": "Dataset Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_workspace_datasets",
            "task_name": "tasks.powerbi.get_workspace_datasets",
            "description": "Read datasets from a workspace",
            "label": "Get Workspace Datasets",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id"],
        },
        "list_workspaces": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of workspaces to return",
                }
            ],
            "outputs": [
                {
                    "field": "workspaces",
                    "type": "vec<string>",
                    "label": "Workspaces (JSON)",
                },
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "label": "Workspace IDs",
                },
                {
                    "field": "workspace_names",
                    "type": "vec<string>",
                    "label": "Workspace Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "list_workspaces",
            "task_name": "tasks.powerbi.list_workspaces",
            "description": "Get multiple workspaces",
            "label": "List Workspaces",
            "input_sort_order": ["limit"],
        },
        "get_dataflow": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataflow_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataflow",
                    "helper_text": "Select the dataflow to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataflow_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "dataflow_id", "type": "string", "label": "Dataflow ID"},
                {"field": "dataflow_name", "type": "string", "label": "Dataflow Name"},
                {"field": "description", "type": "string", "label": "Description"},
                {"field": "configured_by", "type": "string", "label": "Configured By"},
                {"field": "modified_by", "type": "string", "label": "Modified By"},
                {
                    "field": "modified_date_time",
                    "type": "timestamp",
                    "label": "Modified Date Time",
                },
                {"field": "model_url", "type": "string", "label": "Model URL"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_dataflow",
            "task_name": "tasks.powerbi.get_dataflow",
            "description": "Read details of a specific dataflow",
            "label": "Get Dataflow",
            "required": ["workspace_id", "dataflow_id"],
            "input_sort_order": ["workspace_id", "dataflow_id"],
        },
        "get_dataflow_datasources": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataflow_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataflow",
                    "helper_text": "Select the dataflow (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataflow_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "datasources",
                    "type": "vec<string>",
                    "label": "Datasources (JSON)",
                },
                {
                    "field": "datasource_ids",
                    "type": "vec<string>",
                    "label": "Datasource IDs",
                },
                {
                    "field": "datasource_types",
                    "type": "vec<string>",
                    "label": "Datasource Types",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_dataflow_datasources",
            "task_name": "tasks.powerbi.get_dataflow_datasources",
            "description": "Read datasources from a dataflow",
            "label": "Get Dataflow Datasources",
            "required": ["workspace_id", "dataflow_id"],
            "input_sort_order": ["workspace_id", "dataflow_id"],
        },
        "get_dataflow_transactions": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataflow_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataflow",
                    "helper_text": "Select the dataflow (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataflow_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "transactions",
                    "type": "vec<string>",
                    "label": "Transactions (JSON)",
                },
                {
                    "field": "transaction_ids",
                    "type": "vec<string>",
                    "label": "Transaction IDs",
                },
                {"field": "statuses", "type": "vec<string>", "label": "Statuses"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_dataflow_transactions",
            "task_name": "tasks.powerbi.get_dataflow_transactions",
            "description": "Read refresh transactions from a dataflow",
            "label": "Get Dataflow Transactions",
            "required": ["workspace_id", "dataflow_id"],
            "input_sort_order": ["workspace_id", "dataflow_id"],
        },
        "list_dataflows": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of dataflows to return",
                },
            ],
            "outputs": [
                {
                    "field": "dataflows",
                    "type": "vec<string>",
                    "label": "Dataflows (JSON)",
                },
                {
                    "field": "dataflow_ids",
                    "type": "vec<string>",
                    "label": "Dataflow IDs",
                },
                {
                    "field": "dataflow_names",
                    "type": "vec<string>",
                    "label": "Dataflow Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "list_dataflows",
            "task_name": "tasks.powerbi.list_dataflows",
            "description": "Get multiple dataflows from a workspace",
            "label": "List Dataflows",
            "required": ["workspace_id"],
            "input_sort_order": ["workspace_id", "limit"],
        },
        "refresh_dataflow": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select a workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "dataflow_id",
                    "type": "string",
                    "value": "",
                    "label": "Dataflow",
                    "helper_text": "Select the dataflow to refresh (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=dataflow_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "notify_option",
                    "type": "string",
                    "value": "NoNotification",
                    "label": "Notify Option",
                    "helper_text": "Notification option after refresh completes",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No Notification", "value": "NoNotification"},
                            {"label": "Mail On Failure", "value": "MailOnFailure"},
                            {
                                "label": "Mail On Completion",
                                "value": "MailOnCompletion",
                            },
                        ],
                    },
                },
            ],
            "outputs": [{"field": "message", "type": "string", "label": "Message"}],
            "variant": "common_integration_nodes",
            "name": "refresh_dataflow",
            "task_name": "tasks.powerbi.refresh_dataflow",
            "description": "Refresh a dataflow",
            "label": "Refresh Dataflow",
            "required": ["workspace_id", "dataflow_id"],
            "input_sort_order": ["workspace_id", "dataflow_id", "notify_option"],
        },
        "get_gateway": {
            "inputs": [
                {
                    "field": "gateway_id",
                    "type": "string",
                    "value": "",
                    "label": "Gateway",
                    "helper_text": "Select the gateway to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=gateway_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "gateway_id", "type": "string", "label": "Gateway ID"},
                {"field": "gateway_name", "type": "string", "label": "Gateway Name"},
                {"field": "gateway_type", "type": "string", "label": "Gateway Type"},
                {"field": "public_key", "type": "string", "label": "Public Key"},
                {
                    "field": "gateway_annotation",
                    "type": "string",
                    "label": "Gateway Annotation",
                },
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_gateway",
            "task_name": "tasks.powerbi.get_gateway",
            "description": "Read details of a specific gateway",
            "label": "Get Gateway",
            "required": ["gateway_id"],
            "input_sort_order": ["gateway_id"],
        },
        "get_gateway_datasource": {
            "inputs": [
                {
                    "field": "gateway_id",
                    "type": "string",
                    "value": "",
                    "label": "Gateway",
                    "helper_text": "Select the gateway (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=gateway_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "datasource_id",
                    "type": "string",
                    "value": "",
                    "label": "Datasource",
                    "helper_text": "Select the datasource to retrieve (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=datasource_id&gateway_id={inputs.gateway_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "datasource_id", "type": "string", "label": "Datasource ID"},
                {
                    "field": "datasource_name",
                    "type": "string",
                    "label": "Datasource Name",
                },
                {
                    "field": "datasource_type",
                    "type": "string",
                    "label": "Datasource Type",
                },
                {
                    "field": "connection_details",
                    "type": "string",
                    "label": "Connection Details",
                },
                {
                    "field": "credential_type",
                    "type": "string",
                    "label": "Credential Type",
                },
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_gateway_datasource",
            "task_name": "tasks.powerbi.get_gateway_datasource",
            "description": "Read details of a specific gateway datasource",
            "label": "Get Gateway Datasource",
            "required": ["gateway_id", "datasource_id"],
            "input_sort_order": ["gateway_id", "datasource_id"],
        },
        "get_gateway_datasources": {
            "inputs": [
                {
                    "field": "gateway_id",
                    "type": "string",
                    "value": "",
                    "label": "Gateway",
                    "helper_text": "Select the gateway (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=gateway_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "datasources",
                    "type": "vec<string>",
                    "label": "Datasources (JSON)",
                },
                {
                    "field": "datasource_ids",
                    "type": "vec<string>",
                    "label": "Datasource IDs",
                },
                {
                    "field": "datasource_names",
                    "type": "vec<string>",
                    "label": "Datasource Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_gateway_datasources",
            "task_name": "tasks.powerbi.get_gateway_datasources",
            "description": "Read datasources from a gateway",
            "label": "Get Gateway Datasources",
            "required": ["gateway_id"],
            "input_sort_order": ["gateway_id"],
        },
        "get_datasource_status": {
            "inputs": [
                {
                    "field": "gateway_id",
                    "type": "string",
                    "value": "",
                    "label": "Gateway",
                    "helper_text": "Select the gateway (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=gateway_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "datasource_id",
                    "type": "string",
                    "value": "",
                    "label": "Datasource",
                    "helper_text": "Select the datasource (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=datasource_id&gateway_id={inputs.gateway_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "status", "type": "string", "label": "Status"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_datasource_status",
            "task_name": "tasks.powerbi.get_datasource_status",
            "description": "Read status of a gateway datasource",
            "label": "Get Datasource Status",
            "required": ["gateway_id", "datasource_id"],
            "input_sort_order": ["gateway_id", "datasource_id"],
        },
        "get_datasource_users": {
            "inputs": [
                {
                    "field": "gateway_id",
                    "type": "string",
                    "value": "",
                    "label": "Gateway",
                    "helper_text": "Select the gateway (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=gateway_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "datasource_id",
                    "type": "string",
                    "value": "",
                    "label": "Datasource",
                    "helper_text": "Select the datasource (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=datasource_id&gateway_id={inputs.gateway_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {"field": "users", "type": "vec<string>", "label": "Users (JSON)"},
                {"field": "user_ids", "type": "vec<string>", "label": "User IDs"},
                {"field": "user_emails", "type": "vec<string>", "label": "User Emails"},
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_datasource_users",
            "task_name": "tasks.powerbi.get_datasource_users",
            "description": "Read users from a gateway datasource",
            "label": "Get Datasource Users",
            "required": ["gateway_id", "datasource_id"],
            "input_sort_order": ["gateway_id", "datasource_id"],
        },
        "list_gateways": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of gateways to return",
                }
            ],
            "outputs": [
                {
                    "field": "gateways",
                    "type": "vec<string>",
                    "label": "Gateways (JSON)",
                },
                {"field": "gateway_ids", "type": "vec<string>", "label": "Gateway IDs"},
                {
                    "field": "gateway_names",
                    "type": "vec<string>",
                    "label": "Gateway Names",
                },
                {"field": "total_count", "type": "string", "label": "Total Count"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "list_gateways",
            "task_name": "tasks.powerbi.list_gateways",
            "description": "Get multiple gateways",
            "label": "List Gateways",
            "input_sort_order": ["limit"],
        },
        "get_workspace_info": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select the workspace (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "lineage",
                    "type": "bool",
                    "value": False,
                    "label": "Include Lineage",
                    "helper_text": "Include lineage information",
                },
                {
                    "field": "datasource_details",
                    "type": "bool",
                    "value": False,
                    "label": "Include Datasource Details",
                    "helper_text": "Include datasource details",
                },
                {
                    "field": "dataset_schema",
                    "type": "bool",
                    "value": False,
                    "label": "Include Dataset Schema",
                    "helper_text": "Include dataset schema",
                },
                {
                    "field": "dataset_expressions",
                    "type": "bool",
                    "value": False,
                    "label": "Include Dataset Expressions",
                    "helper_text": "Include M and DAX expressions",
                },
                {
                    "field": "artifact_users",
                    "type": "bool",
                    "value": False,
                    "label": "Include Artifact Users",
                    "helper_text": "Include users for each artifact",
                },
            ],
            "outputs": [
                {"field": "scan_id", "type": "string", "label": "Scan ID"},
                {"field": "status", "type": "string", "label": "Status"},
                {
                    "field": "created_date_time",
                    "type": "timestamp",
                    "label": "Created DateTime",
                },
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "label": "Workspace IDs",
                },
                {"field": "message", "type": "string", "label": "Message"},
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_workspace_info",
            "task_name": "tasks.powerbi.get_workspace_info",
            "description": "Initiate a workspace info scan",
            "label": "Get Workspace Info (Admin)",
            "required": ["workspace_id"],
            "input_sort_order": [
                "workspace_id",
                "lineage",
                "datasource_details",
                "dataset_schema",
                "dataset_expressions",
                "artifact_users",
            ],
        },
        "get_scan_result": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "helper_text": "Select the workspace to scan (required)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "scan_id",
                    "type": "string",
                    "value": "",
                    "label": "Scan ID",
                    "helper_text": "Select scan ID (initiates a new scan for the workspace)",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=scan_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "workspaces",
                    "type": "vec<string>",
                    "label": "Workspaces (JSON)",
                },
                {
                    "field": "workspace_ids",
                    "type": "vec<string>",
                    "label": "Workspace IDs",
                },
                {
                    "field": "workspace_names",
                    "type": "vec<string>",
                    "label": "Workspace Names",
                },
                {"field": "status", "type": "string", "label": "Status"},
                {
                    "field": "total_workspaces",
                    "type": "string",
                    "label": "Total Workspaces",
                },
                {
                    "field": "total_datasets",
                    "type": "string",
                    "label": "Total Datasets",
                },
                {"field": "total_reports", "type": "string", "label": "Total Reports"},
                {
                    "field": "total_dashboards",
                    "type": "string",
                    "label": "Total Dashboards",
                },
                {
                    "field": "total_dataflows",
                    "type": "string",
                    "label": "Total Dataflows",
                },
                {"field": "raw_data", "type": "string", "label": "Raw Response"},
            ],
            "variant": "common_integration_nodes",
            "name": "get_scan_result",
            "task_name": "tasks.powerbi.get_scan_result",
            "description": "Read detailed scan results from a workspace",
            "label": "Get Scan Result (Admin)",
            "required": ["workspace_id", "scan_id"],
            "input_sort_order": ["workspace_id", "scan_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        artifact_users: bool = False,
        dashboard_id: str = "",
        dataflow_id: str = "",
        dataset_expressions: bool = False,
        dataset_id: str = "",
        dataset_schema: bool = False,
        datasource_details: bool = False,
        datasource_id: str = "",
        dax_query: str = "",
        export_format: str = "PDF",
        gateway_id: str = "",
        impersonated_user: str = "",
        include_nulls: bool = False,
        limit: int = 10,
        lineage: bool = False,
        notify_option: str = "NoNotification",
        report_id: str = "",
        rows_data: str = "",
        scan_id: str = "",
        table_name: str = "",
        top: int = 10,
        wait_for_completion: bool = True,
        workspace_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_powerbi",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if workspace_id is not None:
            self.inputs["workspace_id"] = workspace_id
        if dataset_id is not None:
            self.inputs["dataset_id"] = dataset_id
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if rows_data is not None:
            self.inputs["rows_data"] = rows_data
        if top is not None:
            self.inputs["top"] = top
        if dax_query is not None:
            self.inputs["dax_query"] = dax_query
        if include_nulls is not None:
            self.inputs["include_nulls"] = include_nulls
        if impersonated_user is not None:
            self.inputs["impersonated_user"] = impersonated_user
        if limit is not None:
            self.inputs["limit"] = limit
        if notify_option is not None:
            self.inputs["notify_option"] = notify_option
        if report_id is not None:
            self.inputs["report_id"] = report_id
        if export_format is not None:
            self.inputs["export_format"] = export_format
        if wait_for_completion is not None:
            self.inputs["wait_for_completion"] = wait_for_completion
        if dashboard_id is not None:
            self.inputs["dashboard_id"] = dashboard_id
        if dataflow_id is not None:
            self.inputs["dataflow_id"] = dataflow_id
        if gateway_id is not None:
            self.inputs["gateway_id"] = gateway_id
        if datasource_id is not None:
            self.inputs["datasource_id"] = datasource_id
        if lineage is not None:
            self.inputs["lineage"] = lineage
        if datasource_details is not None:
            self.inputs["datasource_details"] = datasource_details
        if dataset_schema is not None:
            self.inputs["dataset_schema"] = dataset_schema
        if dataset_expressions is not None:
            self.inputs["dataset_expressions"] = dataset_expressions
        if artifact_users is not None:
            self.inputs["artifact_users"] = artifact_users
        if scan_id is not None:
            self.inputs["scan_id"] = scan_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationPowerbiNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
