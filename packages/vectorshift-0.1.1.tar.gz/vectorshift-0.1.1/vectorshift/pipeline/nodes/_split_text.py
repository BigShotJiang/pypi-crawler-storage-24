"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("split_text")
class SplitTextNode(Node):
    """
    Takes input text and separate it into a List of texts based on the delimiter.

    ## Inputs
    ### Common Inputs
        text: The text to split
        delimiter: The delimiter to split the text on
    ### character(s)
        character: The character(s) to split the text on

    ## Outputs
    ### Common Outputs
        processed_text: The text split into a list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "text",
            "helper_text": "The text to split",
            "value": "",
            "type": "string",
        },
        {
            "field": "delimiter",
            "helper_text": "The delimiter to split the text on",
            "value": "space",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "processed_text",
            "helper_text": "The text split into a list",
            "type": "vec<string>",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "character(s)": {
            "inputs": [
                {
                    "field": "character",
                    "label": "Character",
                    "type": "string",
                    "value": "",
                    "helper_text": "The character(s) to split the text on",
                }
            ],
            "outputs": [],
        },
        "space": {"inputs": [], "outputs": []},
        "newline": {"inputs": [], "outputs": []},
    }

    # List of parameters that affect configuration
    _PARAMS = ["delimiter"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["character", "text"]

    def __init__(
        self,
        delimiter: str = "space",
        text: str = "",
        character: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["delimiter"] = delimiter

        super().__init__(
            node_type="split_text",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if delimiter is not None:
            self.inputs["delimiter"] = delimiter
        if text is not None:
            self.inputs["text"] = text
        if character is not None:
            self.inputs["character"] = character
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "SplitTextNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
