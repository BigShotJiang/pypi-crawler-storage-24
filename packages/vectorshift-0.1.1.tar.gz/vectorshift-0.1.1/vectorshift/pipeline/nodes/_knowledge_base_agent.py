"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("knowledge_base_agent")
class KnowledgeBaseAgentNode(Node):
    """
    Query a knowledge base using an agentic approach with tools.

    ## Inputs
    ### Common Inputs
        model: Select the LLM model to be used by the agent
        query: The natural language query. The agent will use this to determine the best way to query the knowledge base. Include the key criteria needed to answer the query.
        accept_additional_context: If enabled, shows an additional context input to provide context to the agent
        knowledge_base: Select an existing knowledge base.
        mode: Controls the query effort: 'fast' for quick answers, 'focused' for balanced depth, 'deep' for thorough analysis
        provider: Select the LLM provider to be used by the agent
        return_answer: If enabled, generates a synthesized answer from the knowledge base
        return_context: If enabled, returns the relevant context/chunks used to generate the answer
    ### When accept_additional_context = True
        context: Optional additional context to help the agent understand the query better (e.g., conversation history, user preferences)

    ## Outputs
    ### Common Outputs
        answer: The answer synthesized by the agent from the knowledge base
    ### When return_context = True
        context: The formatted context/chunks used by the agent to generate the answer
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the LLM model to be used by the agent",
            "value": "gemini-3-flash-preview",
            "type": "enum<string>",
        },
        {
            "field": "query",
            "helper_text": "The natural language query. The agent will use this to determine the best way to query the knowledge base. Include the key criteria needed to answer the query.",
            "value": "",
            "type": "string",
        },
        {
            "field": "accept_additional_context",
            "helper_text": "If enabled, shows an additional context input to provide context to the agent",
            "value": False,
            "type": "bool",
        },
        {
            "field": "knowledge_base",
            "helper_text": "Select an existing knowledge base.",
            "value": {"object_type": 1, "object_id": ""},
            "type": "knowledge_base",
        },
        {
            "field": "mode",
            "helper_text": "Controls the query effort: 'fast' for quick answers, 'focused' for balanced depth, 'deep' for thorough analysis",
            "value": "focused",
            "type": "enum<string>",
        },
        {
            "field": "provider",
            "helper_text": "Select the LLM provider to be used by the agent",
            "value": "google",
            "type": "enum<string>",
        },
        {
            "field": "return_answer",
            "helper_text": "If enabled, generates a synthesized answer from the knowledge base",
            "value": True,
            "type": "bool",
        },
        {
            "field": "return_context",
            "helper_text": "If enabled, returns the relevant context/chunks used to generate the answer",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "answer",
            "helper_text": "The answer synthesized by the agent from the knowledge base",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**true**(*)": {
            "inputs": [
                {
                    "field": "context",
                    "label": "Additional Context",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional additional context to help the agent understand the query better (e.g., conversation history, user preferences)",
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**(*)**true": {
            "inputs": [],
            "outputs": [
                {
                    "field": "context",
                    "type": "string",
                    "helper_text": "The formatted context/chunks used by the agent to generate the answer",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["provider", "mode", "accept_additional_context", "return_context"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["knowledge_base", "query"]

    def __init__(
        self,
        provider: str = "google",
        mode: str = "focused",
        accept_additional_context: bool = False,
        return_context: bool = False,
        model: str = "gemini-3-flash-preview",
        query: str = "",
        context: str = "",
        knowledge_base: "KnowledgeBase" = "",
        return_answer: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["provider"] = provider
        params["mode"] = mode
        params["accept_additional_context"] = accept_additional_context
        params["return_context"] = return_context

        super().__init__(
            node_type="knowledge_base_agent",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if knowledge_base is not None:
            self.inputs["knowledge_base"] = knowledge_base
        if query is not None:
            self.inputs["query"] = query
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if mode is not None:
            self.inputs["mode"] = mode
        if return_answer is not None:
            self.inputs["return_answer"] = return_answer
        if return_context is not None:
            self.inputs["return_context"] = return_context
        if accept_additional_context is not None:
            self.inputs["accept_additional_context"] = accept_additional_context
        if context is not None:
            self.inputs["context"] = context
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseAgentNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
