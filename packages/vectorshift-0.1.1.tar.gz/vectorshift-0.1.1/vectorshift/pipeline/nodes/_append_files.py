"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("append_files")
class AppendFilesNode(Node):
    """
    Append files together in successive fashion

    ## Inputs
    ### Common Inputs
        file_type: The type of file to append.
        selected_files: The number of files to be appended. Files will be appended in successive fashion (e.g., file-1 first, then file-2, etc.).

    ## Outputs
    ### Common Outputs
        file: A file with all the files appended together.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "file_type",
            "helper_text": "The type of file to append.",
            "value": "PDF",
            "type": "string",
        },
        {
            "field": "selected_files",
            "helper_text": "The number of files to be appended. Files will be appended in successive fashion (e.g., file-1 first, then file-2, etc.).",
            "value": [""],
            "type": "vec<file>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "file",
            "helper_text": "A file with all the files appended together.",
            "type": "file",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    def __init__(
        self,
        file_type: str = "PDF",
        selected_files: List[str] = [""],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="append_files",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file_type is not None:
            self.inputs["file_type"] = file_type
        if selected_files is not None:
            self.inputs["selected_files"] = selected_files
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AppendFilesNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
