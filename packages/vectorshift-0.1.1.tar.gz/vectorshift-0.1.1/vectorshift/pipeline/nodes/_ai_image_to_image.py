"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("ai_image_to_image")
class AiImageToImageNode(Node):
    """
    Modify and edit images using AI by providing modification instructions

    ## Inputs
    ### Common Inputs
        model: Select the image-to-image model
        prompt: Tell the AI model how you would like it to modify the images. Be as specific as possible. For example, you can instruct the model to change colors, add elements, apply artistic styles, or blend multiple images. Must not be empty.
        aspect_ratio: Select the aspect ratio for the output image.
        images: Array of input images to modify. Provide 1-3 images for best results.
        provider: Select the model provider.
        use_personal_api_key: Use your personal API key
    ### When use_personal_api_key = True
        api_key: Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run

    ## Outputs
    ### Common Outputs
        image: The modified image.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the image-to-image model",
            "value": "gemini-2.5-flash-image",
            "type": "string",
        },
        {
            "field": "prompt",
            "helper_text": "Tell the AI model how you would like it to modify the images. Be as specific as possible. For example, you can instruct the model to change colors, add elements, apply artistic styles, or blend multiple images. Must not be empty.",
            "value": "",
            "type": "string",
        },
        {
            "field": "aspect_ratio",
            "helper_text": "Select the aspect ratio for the output image.",
            "value": "1:1",
            "type": "enum<string>",
        },
        {
            "field": "images",
            "helper_text": "Array of input images to modify. Provide 1-3 images for best results.",
            "value": None,
            "type": "vec<image>",
        },
        {
            "field": "provider",
            "helper_text": "Select the model provider.",
            "value": "google",
            "type": "string",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "Use your personal API key",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "image", "helper_text": "The modified image.", "type": "image"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "false**(*)": {"inputs": [], "outputs": []},
        "true**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "type": "string",
                    "value": "",
                    "label": "API Key",
                    "helper_text": "Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run",
                    "agent_field_type": "dynamic",
                    "disable_conversion": True,
                }
            ],
            "outputs": [],
        },
        "(*)**google": {"inputs": [], "outputs": [], "title": "Google Image to Image"},
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_personal_api_key", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["api_key"]

    def __init__(
        self,
        use_personal_api_key: bool = False,
        provider: str = "google",
        model: str = "gemini-2.5-flash-image",
        prompt: str = "",
        api_key: str = "",
        aspect_ratio: str = "1:1",
        images: List[Any] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["use_personal_api_key"] = use_personal_api_key
        params["provider"] = provider

        super().__init__(
            node_type="ai_image_to_image",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if images is not None:
            self.inputs["images"] = images
        if aspect_ratio is not None:
            self.inputs["aspect_ratio"] = aspect_ratio
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiImageToImageNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
