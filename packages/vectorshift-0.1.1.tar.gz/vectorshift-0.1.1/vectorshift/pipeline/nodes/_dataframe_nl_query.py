"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("dataframe_nl_query")
class DataframeNlQueryNode(Node):
    """
    Execute natural language queries on dataframes.

    ## Inputs
    ### Common Inputs
        dataframe: The dataframe to query using natural language
        dataframe_type: The type of dataframe to be used
        nlquery: Ask a question about your data in natural language. Example: What are the top 10 rows?

    ## Outputs
    ### Common Outputs
        result: The result of the natural language query
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "dataframe",
            "helper_text": "The dataframe to query using natural language",
            "value": {"object_info": {"object_id": "", "object_type": 3}},
            "type": "dataframe",
        },
        {
            "field": "dataframe_type",
            "helper_text": "The type of dataframe to be used",
            "value": "table",
            "type": "string",
        },
        {
            "field": "nlquery",
            "helper_text": "Ask a question about your data in natural language. Example: What are the top 10 rows?",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "result",
            "helper_text": "The result of the natural language query",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "table": {
            "inputs": [
                {
                    "field": "dataframe",
                    "type": "dataframe",
                    "value": {"object_info": {"object_id": "", "object_type": 3}},
                    "label": "Select Dataframe",
                    "helper_text": "The dataframe to query using natural language",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dataframe",
                        "decorators": {"hide": ["variable_switch"]},
                        "source": "dataframe_options",
                        "source_key": "dataframe_type",
                        "source_sub_key": "component.options",
                        "access_value_sub_key": "objectInfo",
                    },
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["dataframe_type"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "dataframe", "label": "Dataframe"},
        {"field": "dataframe_type", "label": "Dataframe Type"},
        {"field": "nlquery", "label": "Natural Language Query"},
    ]

    _REQUIRED_FIELDS = ["dataframe_type", "dataframe", "nlquery"]

    def __init__(
        self,
        dataframe_type: str = "table",
        dataframe: Any = "",
        nlquery: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["dataframe_type"] = dataframe_type

        super().__init__(
            node_type="dataframe_nl_query",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if dataframe_type is not None:
            self.inputs["dataframe_type"] = dataframe_type
        if dataframe is not None:
            self.inputs["dataframe"] = dataframe
        if nlquery is not None:
            self.inputs["nlquery"] = nlquery
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "DataframeNlQueryNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
