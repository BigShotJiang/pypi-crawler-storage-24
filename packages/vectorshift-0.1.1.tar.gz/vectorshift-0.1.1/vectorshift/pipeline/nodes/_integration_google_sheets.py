"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import ColumnEntry


@Node.register_node_type("integration_google_sheets")
class IntegrationGoogleSheetsNode(Node):
    """
    Google Sheets

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: The integration input
    ### When action = 'extract_to_table'
        model: The model to use for the Google Sheets integration
        add_columns_manually: Add data points for some columns manually instead of having them extracted by the AI model.
        additional_context: Additional context for the AI model to extract the table.
        extract_multiple_rows: If checked, it will extract multiple rows of data. If unchecked, it will extract a single row.
        provider: The provider to use for the Google Sheets integration
        sheet_id: Select the Sheet to read from
        text_for_extraction: The text to extract the table from
    ### When action = 'get_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'write_to_sheet' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'write_list_to_column' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'update_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'create_spreadsheet'
        auto_recalc: Frequency at which formulas should automatically recalculate
        locale: Locale (e.g., en_US)
        sheets: Comma (,) separated list of sheet names
        title: Title/name of the new sheet
    ### When action = 'get_rows'
        combine_filters: How to combine filter conditions
        range: Optional: Specify a range (e.g., A1:D10). Leave empty to read entire sheet
        return_first_match: Whether to return only the first matching row
        sheet_id: Select the Sheet to read from
    ### When action = 'update_rows'
        condition: Conditional Operator
        sheet_id: Select the Sheet to read from
    ### When action = 'create_sheet'
        hidden: Whether the sheet should be hidden
        index: Position index of the sheet (0 for end)
        right_to_left: Whether the sheet is RTL instead of LTR
        sheet_id_number: Specific sheet ID number (must be unique, 0 for auto-generate)
        spreadsheet_id: Select the Spreadsheet to create sheet in
        tab_color: Hex color code for sheet tab (e.g., #ff0000)
        title: Title/name of the new sheet
    ### When action = 'clear_sheet'
        keep_first_row: Whether to preserve the first row (only for whole sheet clearing)
        range: Optional: Specify a range (e.g., A1:D10). Leave empty to read entire sheet
        sheet_id: Select the Sheet to read from
    ### When action = 'extract_to_table' and add_columns_manually = True
        manual_columns: Pass in data to column names manually.
    ### When action = 'delete_rows_columns'
        num_columns: Number of columns to delete (required when deleting columns)
        num_rows: Number of rows to delete (required when deleting rows)
        sheet_id: Select the Sheet to read from
        start_column: Starting column letter (required when deleting columns)
        start_row: Starting row number (required when deleting rows)
    ### When action = 'read_sheet'
        sheet_id: Select the Sheet to read from
    ### When action = 'read_sheet_url'
        sheet_id: Select the Sheet to read from
        sheet_url: Enter the URL of your Google Spreadsheet
    ### When action = 'write_to_sheet'
        sheet_id: Select the Sheet to read from
    ### When action = 'write_list_to_column'
        sheet_id: Select the Sheet to read from
    ### When action = 'delete_sheet'
        sheet_id: Select the Sheet to read from
    ### When action = 'delete_spreadsheet'
        spreadsheet_id: Select the Spreadsheet to create sheet in
    ### When action = 'delete_spreadsheet_url'
        spreadsheet_url: Enter or map the full URL of the Google Spreadsheet to be deleted

    ## Outputs
    ### When action = 'read_sheet' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'read_sheet_url' and endpoint_1 = '[endpoint_1.<B>]'
        [<B>.outputs]: The [<B>.outputs] output
    ### When action = 'clear_sheet'
        cleared_range: The range that was cleared
        keep_first_row: Whether first row was preserved
        raw_data: Raw API response data
        sheet_name: Name of the sheet
        spreadsheet_id: ID of the spreadsheet
        status: Operation status
    ### When action = 'delete_spreadsheet'
        deleted_id: ID of the deleted spreadsheet
        raw_data: Raw API response data
        status: Operation status
    ### When action = 'delete_spreadsheet_url'
        deleted_id: ID of the deleted spreadsheet
        deleted_url: URL of the deleted spreadsheet
        raw_data: Raw API response data
        status: Operation status
    ### When action = 'delete_sheet'
        deleted_sheet_id: ID of the deleted sheet
        raw_data: Raw API response data
        spreadsheet_id: ID of the parent spreadsheet
        status: Operation status
    ### When action = 'delete_rows_columns'
        deleted_types: Type of deletion performed (rows or columns)
        end_index: Ending index (0-based)
        raw_data: Raw API response data
        sheet_id: ID of the sheet
        spreadsheet_id: ID of the spreadsheet
        start_index: Starting index (0-based)
        status: Operation status
    ### When action = 'create_sheet'
        raw_data: Raw API response data
        sheet_id: ID of the created sheet
        sheet_index: Index position of the sheet
        sheet_title: Title of the created sheet
        spreadsheet_id: ID of the parent spreadsheet
        status: Operation status
    ### When action = 'write_to_sheet'
        raw_data: Raw API response from Google Sheets
    ### When action = 'write_list_to_column'
        raw_data: Raw API response from Google Sheets
    ### When action = 'update_rows'
        raw_data: Raw API response from Google Sheets
        rows_updated: Number of rows that were updated
    ### When action = 'create_spreadsheet'
        raw_data: Raw API response data including all spreadsheet details
        spreadsheet_id: ID of the created spreadsheet
        spreadsheet_url: URL of the created spreadsheet
        status: Operation status
        title: Title of the spreadsheet
    ### When action = 'get_rows'
        rows: Array of row objects with column names as keys
    ### When action = 'extract_to_table'
        table: The table extracted from the text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Google Sheets>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_sheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "label": "Spreadsheet",
                    "helper_text": "Select the Spreadsheet to create sheet in",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Sheet Title",
                    "helper_text": "Title/name of the new sheet",
                    "placeholder": "My New Sheet",
                },
                {
                    "field": "hidden",
                    "type": "bool",
                    "value": False,
                    "label": "Hidden",
                    "helper_text": "Whether the sheet should be hidden",
                },
                {
                    "field": "right_to_left",
                    "type": "bool",
                    "value": False,
                    "label": "Right to Left",
                    "helper_text": "Whether the sheet is RTL instead of LTR",
                },
                {
                    "field": "sheet_id_number",
                    "type": "int32",
                    "value": 0,
                    "label": "Sheet ID Number",
                    "helper_text": "Specific sheet ID number (must be unique, 0 for auto-generate)",
                    "placeholder": "0",
                },
                {
                    "field": "index",
                    "type": "int32",
                    "value": 0,
                    "label": "Index",
                    "helper_text": "Position index of the sheet (0 for end)",
                    "placeholder": "0",
                },
                {
                    "field": "tab_color",
                    "type": "string",
                    "value": "",
                    "label": "Tab Color",
                    "helper_text": "Hex color code for sheet tab (e.g., #ff0000)",
                    "placeholder": "#ff0000",
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "sheet_id",
                    "type": "int32",
                    "helper_text": "ID of the created sheet",
                },
                {
                    "field": "sheet_title",
                    "type": "string",
                    "helper_text": "Title of the created sheet",
                },
                {
                    "field": "sheet_index",
                    "type": "int32",
                    "helper_text": "Index position of the sheet",
                },
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "helper_text": "ID of the parent spreadsheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_sheet",
            "task_name": "tasks.google_sheets.create_sheet",
            "description": "Create a new sheet in a spreadsheet",
            "label": "Create Sheet",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "spreadsheet_id",
                "title",
                "hidden",
                "right_to_left",
                "sheet_id_number",
                "index",
                "tab_color",
            ],
        },
        "read_sheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [],
            "name": "read_sheet",
            "task_name": "tasks.google_sheets.read_sheet",
            "description": "Read specified columns from the selected sheet",
            "label": "Read from Sheet",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "sheet_id"],
        },
        "read_sheet**(*)**[endpoint_0.<A>]**(*)": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "read_sheet_url**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_url",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "label": "Workbook URL",
                    "helper_text": "Enter the URL of your Google Spreadsheet",
                    "order": 3,
                },
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=read_sheet_url&parent_id={inputs.sheet_url}"
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [],
            "banner_text": 'Ensure that the Google Sheet\'s permissions is set to "Anyone with the Link"',
            "name": "read_sheet_url",
            "task_name": "tasks.google_sheets.read_sheet_url",
            "description": "Read specified columns from the provided sheet URL",
            "label": "Read from Sheet URL",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "sheet_url", "sheet_id"],
        },
        "read_sheet_url**(*)**(*)**[endpoint_1.<B>]": {
            "inputs": [],
            "outputs": [{"field": "[<B>.outputs]", "type": ""}],
        },
        "get_rows**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "range",
                    "type": "string",
                    "value": "",
                    "label": "Range",
                    "helper_text": "Optional: Specify a range (e.g., A1:D10). Leave empty to read entire sheet",
                    "placeholder": "",
                },
                {
                    "field": "combine_filters",
                    "type": "string",
                    "value": "OR",
                    "label": "Combine Filters",
                    "helper_text": "How to combine filter conditions",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "AND", "value": "AND"},
                            {"label": "OR", "value": "OR"},
                        ],
                    },
                },
                {
                    "field": "return_first_match",
                    "type": "bool",
                    "value": False,
                    "label": "Return Only First Matching Row",
                    "helper_text": "Whether to return only the first matching row",
                },
            ],
            "outputs": [
                {
                    "field": "rows",
                    "type": "vec<string>",
                    "helper_text": "Array of row objects with column names as keys",
                }
            ],
            "name": "get_rows",
            "task_name": "tasks.google_sheets.get_rows",
            "description": "Get rows from a sheet as JSON objects with optional filtering",
            "label": "Get Rows",
            "variant": "common_integration_file_nodes",
            "required": ["sheet_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "sheet_id",
                "range",
                "combine_filters",
                "return_first_match",
            ],
        },
        "get_rows**(*)**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "write_to_sheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response from Google Sheets",
                }
            ],
            "name": "write_to_sheet",
            "task_name": "tasks.google_sheets.write_to_sheet",
            "description": "Add a new row in the selected sheet",
            "label": "Add New Row",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "sheet_id"],
        },
        "write_to_sheet**(*)**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "write_list_to_column**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response from Google Sheets",
                }
            ],
            "name": "write_list_to_column",
            "task_name": "tasks.google_sheets.write_list_to_column",
            "description": "Fill specified columns with the input values (inputs can be list)",
            "label": "Column List Writer",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "sheet_id"],
        },
        "write_list_to_column**(*)**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "update_rows**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "agent_field_type": "dynamic",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "label": "Conditional Operator",
                    "placeholder": "",
                    "helper_text": "Conditional Operator",
                },
            ],
            "outputs": [
                {
                    "field": "rows_updated",
                    "type": "int32",
                    "helper_text": "Number of rows that were updated",
                },
                {
                    "field": "raw_data",
                    "type": "vec<string>",
                    "helper_text": "Raw API response from Google Sheets",
                },
            ],
            "name": "update_rows",
            "task_name": "tasks.google_sheets.update_rows",
            "description": "Update the rows matching the specified search values",
            "label": "Update Rows",
            "operation": "update",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "sheet_id", "condition"],
        },
        "update_rows**(*)**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "extract_to_table**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to read from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "provider",
                    "type": "string",
                    "value": "openai",
                    "label": "Provider",
                    "placeholder": "OpenAI",
                    "helper_text": "The provider to use for the Google Sheets integration",
                    "section": "advanced_settings",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "OpenAI", "value": "openai"},
                            {"label": "Anthropic", "value": "anthropic"},
                            {"label": "Cohere", "value": "cohere"},
                            {"label": "Perplexity", "value": "perplexity"},
                            {"label": "Google", "value": "google"},
                            {"label": "Open Source", "value": "together"},
                            {"label": "AWS", "value": "bedrock"},
                            {"label": "Azure", "value": "azure"},
                            {"label": "xAI", "value": "xai"},
                            {"label": "Custom", "value": "custom"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "gpt-4o",
                    "label": "LLM Model",
                    "placeholder": "GPT-4o",
                    "helper_text": "The model to use for the Google Sheets integration",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "llm_models",
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "text_for_extraction",
                    "type": "string",
                    "value": "",
                    "label": "Text for Extraction",
                    "placeholder": "Extract the table from the following text",
                    "helper_text": "The text to extract the table from",
                },
                {
                    "field": "extract_multiple_rows",
                    "type": "bool",
                    "value": True,
                    "label": "Extract Multiple Rows ?",
                    "helper_text": "If checked, it will extract multiple rows of data. If unchecked, it will extract a single row.",
                },
                {
                    "field": "add_columns_manually",
                    "type": "bool",
                    "value": False,
                    "label": "Add Columns Manually ?",
                    "helper_text": "Add data points for some columns manually instead of having them extracted by the AI model.",
                },
                {
                    "field": "additional_context",
                    "type": "string",
                    "value": "",
                    "label": "Additional Context",
                    "placeholder": "Additional context for the AI model to extract the table.",
                    "helper_text": "Additional context for the AI model to extract the table.",
                },
            ],
            "outputs": [
                {
                    "field": "table",
                    "type": "file",
                    "helper_text": "The table extracted from the text",
                }
            ],
            "name": "extract_to_table",
            "task_name": "tasks.google_sheets.extract_to_table",
            "description": "Extract data from text to a table with AI",
            "label": "Extract to Table",
            "variant": "google_sheet",
            "ui_sort_order": [
                "integration",
                "action",
                "sheet_id",
                "text_for_extraction",
                "additional_context",
                "extract_multiple_rows",
                "add_columns_manually",
                "manual_columns",
                "provider",
                "model",
            ],
        },
        "extract_to_table**false**(*)**(*)": {"inputs": [], "outputs": []},
        "extract_to_table**true**(*)**(*)": {
            "inputs": [
                {
                    "field": "manual_columns",
                    "type": "vec<interface{id: string, column_name: string, column_value: string}>",
                    "value": [{"column_name": "", "column_value": ""}],
                    "label": "Manual Columns",
                    "placeholder": "Manual Columns",
                    "helper_text": "Pass in data to column names manually.",
                    "component": {
                        "type": "table",
                        "table": {
                            "column_name": {"label": "Column Name"},
                            "column_value": {"label": "Column Value"},
                            "list_button_label": "Add Manual Column",
                        },
                    },
                }
            ],
            "outputs": [],
        },
        "delete_rows_columns**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to delete rows/columns from",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "start_row",
                    "type": "int32",
                    "value": "",
                    "label": "Start Row",
                    "helper_text": "Starting row number (required when deleting rows)",
                    "placeholder": "1",
                },
                {
                    "field": "num_rows",
                    "type": "int32",
                    "value": "",
                    "label": "Number of Rows",
                    "helper_text": "Number of rows to delete (required when deleting rows)",
                    "placeholder": "1",
                },
                {
                    "field": "start_column",
                    "type": "string",
                    "value": "",
                    "label": "Start Column",
                    "helper_text": "Starting column letter (required when deleting columns)",
                    "placeholder": "A",
                },
                {
                    "field": "num_columns",
                    "type": "int32",
                    "value": "",
                    "label": "Number of Columns",
                    "helper_text": "Number of columns to delete (required when deleting columns)",
                    "placeholder": "1",
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "start_index",
                    "type": "int32",
                    "helper_text": "Starting index (0-based)",
                },
                {
                    "field": "end_index",
                    "type": "int32",
                    "helper_text": "Ending index (0-based)",
                },
                {
                    "field": "deleted_types",
                    "type": "vec<string>",
                    "helper_text": "Type of deletion performed (rows or columns)",
                },
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "helper_text": "ID of the spreadsheet",
                },
                {
                    "field": "sheet_id",
                    "type": "string",
                    "helper_text": "ID of the sheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_rows_columns",
            "task_name": "tasks.google_sheets.delete_rows_columns",
            "description": "Delete rows and columns from a spreadsheet",
            "label": "Delete Rows and Columns",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "sheet_id",
                "start_row",
                "num_rows",
                "start_column",
                "num_columns",
            ],
        },
        "clear_sheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to clear",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "keep_first_row",
                    "type": "bool",
                    "value": False,
                    "label": "Keep First Row",
                    "helper_text": "Whether to preserve the first row (only for whole sheet clearing)",
                },
                {
                    "field": "range",
                    "type": "string",
                    "value": "",
                    "label": "Range",
                    "helper_text": "Custom range to clear (required for specific range)",
                    "placeholder": "A1:B10",
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "cleared_range",
                    "type": "string",
                    "helper_text": "The range that was cleared",
                },
                {
                    "field": "keep_first_row",
                    "type": "bool",
                    "helper_text": "Whether first row was preserved",
                },
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "helper_text": "ID of the spreadsheet",
                },
                {
                    "field": "sheet_name",
                    "type": "string",
                    "helper_text": "Name of the sheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "clear_sheet",
            "task_name": "tasks.google_sheets.clear_sheet",
            "description": "Clear a sheet from a spreadsheet",
            "label": "Clear Sheet",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "sheet_id",
                "keep_first_row",
                "range",
            ],
        },
        "delete_sheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "sheet_id",
                    "type": "string",
                    "value": "",
                    "agent_field_type": "dynamic",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the Sheet to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "deleted_sheet_id",
                    "type": "string",
                    "helper_text": "ID of the deleted sheet",
                },
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "helper_text": "ID of the parent spreadsheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_sheet",
            "task_name": "tasks.google_sheets.delete_sheet",
            "description": "Delete a sheet from a spreadsheet",
            "label": "Delete Sheet",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "sheet_id"],
        },
        "create_spreadsheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Spreadsheet Title",
                    "helper_text": "Title of the new spreadsheet",
                    "placeholder": "My New Spreadsheet",
                },
                {
                    "field": "locale",
                    "type": "string",
                    "value": "",
                    "label": "Locale",
                    "helper_text": "Locale (e.g., en_US)",
                    "placeholder": "en_US",
                },
                {
                    "field": "auto_recalc",
                    "type": "string",
                    "value": "ON_CHANGE",
                    "label": "Auto Recalculation",
                    "helper_text": "Frequency at which formulas should automatically recalculate",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "On Change", "value": "ON_CHANGE"},
                            {"label": "Every Minute", "value": "MINUTE"},
                            {"label": "Every Hour", "value": "HOUR"},
                        ],
                    },
                },
                {
                    "field": "sheets",
                    "type": "string",
                    "value": "",
                    "label": "Initial Sheets",
                    "helper_text": "Comma (,) separated list of sheet names",
                    "placeholder": "Sheet1, Sheet2, Sheet3",
                },
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "helper_text": "ID of the created spreadsheet",
                },
                {
                    "field": "spreadsheet_url",
                    "type": "string",
                    "helper_text": "URL of the created spreadsheet",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the spreadsheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data including all spreadsheet details",
                },
            ],
            "name": "create_spreadsheet",
            "task_name": "tasks.google_sheets.create_spreadsheet",
            "description": "Create a new spreadsheet",
            "label": "Create Spreadsheet",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "title",
                "locale",
                "auto_recalc",
                "sheets",
            ],
        },
        "delete_spreadsheet**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "spreadsheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Spreadsheet",
                    "helper_text": "Select the Spreadsheet to delete",
                    "placeholder": "Select Spreadsheet",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "deleted_id",
                    "type": "string",
                    "helper_text": "ID of the deleted spreadsheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_spreadsheet",
            "hidden": True,
            "task_name": "tasks.google_sheets.delete_spreadsheet",
            "description": "Delete a spreadsheet",
            "label": "Delete Spreadsheet",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "spreadsheet_id"],
        },
        "delete_spreadsheet_url**(*)**(*)**(*)": {
            "inputs": [
                {
                    "field": "spreadsheet_url",
                    "type": "string",
                    "value": "",
                    "label": "Spreadsheet URL",
                    "helper_text": "Enter or map the full URL of the Google Spreadsheet to be deleted",
                    "placeholder": "https://docs.google.com/spreadsheets/d/...",
                }
            ],
            "outputs": [
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "Operation status",
                },
                {
                    "field": "deleted_id",
                    "type": "string",
                    "helper_text": "ID of the deleted spreadsheet",
                },
                {
                    "field": "deleted_url",
                    "type": "string",
                    "helper_text": "URL of the deleted spreadsheet",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_spreadsheet_url",
            "hidden": True,
            "task_name": "tasks.google_sheets.delete_spreadsheet_url",
            "description": "Delete a spreadsheet by URL",
            "label": "Delete Spreadsheet by URL",
            "variant": "common_integration_nodes",
            "required": ["spreadsheet_url"],
            "inputs_sort_order": ["integration", "action", "spreadsheet_url"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "add_columns_manually", "endpoint_0", "endpoint_1"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "text_for_extraction",
        "sheet_url",
        "sheet_id",
        "spreadsheet_id",
        "title",
    ]

    def __init__(
        self,
        action: str = "",
        add_columns_manually: bool = False,
        model: str = "gpt-4o",
        additional_context: str = "",
        auto_recalc: str = "ON_CHANGE",
        combine_filters: str = "OR",
        condition: str = "",
        extract_multiple_rows: bool = True,
        hidden: bool = False,
        index: int = 0,
        keep_first_row: bool = False,
        locale: str = "",
        manual_columns: List[ColumnEntry] = [{"column_name": "", "column_value": ""}],
        num_columns: int = None,
        num_rows: int = None,
        provider: str = "openai",
        range: str = "",
        return_first_match: bool = False,
        right_to_left: bool = False,
        sheet_id: str = "",
        sheet_id_number: int = 0,
        sheet_url: str = "",
        sheets: str = "",
        spreadsheet_id: str = "",
        spreadsheet_url: str = "",
        start_column: str = "",
        start_row: int = None,
        tab_color: str = "",
        text_for_extraction: str = "",
        title: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["add_columns_manually"] = add_columns_manually

        super().__init__(
            node_type="integration_google_sheets",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if spreadsheet_id is not None:
            self.inputs["spreadsheet_id"] = spreadsheet_id
        if title is not None:
            self.inputs["title"] = title
        if hidden is not None:
            self.inputs["hidden"] = hidden
        if right_to_left is not None:
            self.inputs["right_to_left"] = right_to_left
        if sheet_id_number is not None:
            self.inputs["sheet_id_number"] = sheet_id_number
        if index is not None:
            self.inputs["index"] = index
        if tab_color is not None:
            self.inputs["tab_color"] = tab_color
        if sheet_id is not None:
            self.inputs["sheet_id"] = sheet_id
        if sheet_url is not None:
            self.inputs["sheet_url"] = sheet_url
        if range is not None:
            self.inputs["range"] = range
        if combine_filters is not None:
            self.inputs["combine_filters"] = combine_filters
        if return_first_match is not None:
            self.inputs["return_first_match"] = return_first_match
        if condition is not None:
            self.inputs["condition"] = condition
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if text_for_extraction is not None:
            self.inputs["text_for_extraction"] = text_for_extraction
        if extract_multiple_rows is not None:
            self.inputs["extract_multiple_rows"] = extract_multiple_rows
        if add_columns_manually is not None:
            self.inputs["add_columns_manually"] = add_columns_manually
        if additional_context is not None:
            self.inputs["additional_context"] = additional_context
        if manual_columns is not None:
            self.inputs["manual_columns"] = manual_columns
        if start_row is not None:
            self.inputs["start_row"] = start_row
        if num_rows is not None:
            self.inputs["num_rows"] = num_rows
        if start_column is not None:
            self.inputs["start_column"] = start_column
        if num_columns is not None:
            self.inputs["num_columns"] = num_columns
        if keep_first_row is not None:
            self.inputs["keep_first_row"] = keep_first_row
        if locale is not None:
            self.inputs["locale"] = locale
        if auto_recalc is not None:
            self.inputs["auto_recalc"] = auto_recalc
        if sheets is not None:
            self.inputs["sheets"] = sheets
        if spreadsheet_url is not None:
            self.inputs["spreadsheet_url"] = spreadsheet_url
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleSheetsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
