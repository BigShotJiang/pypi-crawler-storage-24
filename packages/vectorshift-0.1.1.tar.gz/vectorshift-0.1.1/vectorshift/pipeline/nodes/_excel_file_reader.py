"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("excel_file_reader")
class ExcelFileReaderNode(Node):
    """
    Read data from an Excel file.

    ## Inputs
    ### Common Inputs
        read_formatting: Whether to read the formatting of the cell.
        read_formula: Whether to read the formula of the cell.
        read_single_sheet: Whether to read a single sheet from the Excel file.
        selected_file: The file to read from.
    ### When read_single_sheet = True
        sheet: The sheet to read from.

    ## Outputs
    ### When read_single_sheet = True
        file_content: The text of the selected sheet in the Excel file
    ### When read_single_sheet = False
        file_content: The text of all sheets in the Excel file
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "read_formatting",
            "helper_text": "Whether to read the formatting of the cell.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "read_formula",
            "helper_text": "Whether to read the formula of the cell.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "read_single_sheet",
            "helper_text": "Whether to read a single sheet from the Excel file.",
            "value": True,
            "type": "bool",
        },
        {
            "field": "selected_file",
            "helper_text": "The file to read from.",
            "value": None,
            "type": "file",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true": {
            "inputs": [
                {
                    "field": "sheet",
                    "type": "string",
                    "value": "",
                    "helper_text": "The sheet to read from.",
                    "label": "Sheet",
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [
                {
                    "field": "file_content",
                    "type": "string",
                    "helper_text": "The text of the selected sheet in the Excel file",
                    "label": "Text",
                }
            ],
        },
        "false": {
            "inputs": [],
            "outputs": [
                {
                    "field": "file_content",
                    "type": "string",
                    "helper_text": "The text of all sheets in the Excel file",
                    "label": "Text",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["read_single_sheet"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["selected_file"]

    def __init__(
        self,
        read_single_sheet: bool = True,
        read_formatting: bool = False,
        read_formula: bool = False,
        selected_file: Optional[str] = None,
        sheet: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["read_single_sheet"] = read_single_sheet

        super().__init__(
            node_type="excel_file_reader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if selected_file is not None:
            self.inputs["selected_file"] = selected_file
        if read_single_sheet is not None:
            self.inputs["read_single_sheet"] = read_single_sheet
        if read_formatting is not None:
            self.inputs["read_formatting"] = read_formatting
        if read_formula is not None:
            self.inputs["read_formula"] = read_formula
        if sheet is not None:
            self.inputs["sheet"] = sheet
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ExcelFileReaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
