"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_oracle_database")
class IntegrationOracleDatabaseNode(Node):
    """
    Oracle Database

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Oracle Database account
    ### When action = 'update' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'upsert' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'insert'
        auto_commit: Automatically commit after each insert. If false, all inserts are wrapped in a transaction.
        data: JSON objects with column-value pairs to insert (one per row)
        schema: Choose the schema
        table_name: Choose the table to insert into
    ### When action = 'execute_query'
        bind_variable_placeholder_values: Comma-separated values for bind variables (:1, :2, etc.) in the query
        output_numbers_as_string: Convert numeric values to strings in the output
        sql_query: SQL query to execute (use :1, :2, etc. for parameters)
    ### When action = 'delete_table'
        delete_command: Delete command to execute (truncate, delete, or drop)
        schema: Choose the schema
        table_name: Choose the table to insert into
        where_clause: Optional WHERE condition (without WHERE keyword)
    ### When action = 'select' and return_all = False
        limit: Maximum number of rows to return
    ### When action = 'update'
        match_columns: Column(s) to match on for update (comma-separated). Rows matching these column values will be updated.
        schema: Choose the schema
        table_name: Choose the table to insert into
    ### When action = 'upsert'
        match_columns: Column(s) to match on for update (comma-separated). Rows matching these column values will be updated.
        schema: Choose the schema
        table_name: Choose the table to insert into
    ### When action = 'select'
        order_by: Optional ORDER BY clause
        output_numbers_as_string: Convert numeric values to strings in the output
        return_all: Return all rows (ignores limit)
        schema: Choose the schema
        table_name: Choose the table to insert into
        where_clause: Optional WHERE condition (without WHERE keyword)

    ## Outputs
    ### When action = 'insert'
        affected_rows: Number of rows inserted
        raw_data: Raw response data as JSON
    ### When action = 'update'
        affected_rows: Number of rows updated
        raw_data: Raw response data as JSON
    ### When action = 'upsert'
        affected_rows: Number of rows affected
        raw_data: Raw response data as JSON
    ### When action = 'delete_table'
        affected_rows: Number of rows deleted
        raw_data: Raw response data as JSON
        table_dropped: Whether the entire table was dropped
    ### When action = 'select'
        columns: Column names in the result set
        raw_data: Raw response data as JSON
        results: Selected data as JSON
        row_count: Number of rows returned
    ### When action = 'execute_query'
        columns: Column names in the result set
        execution_time: Query execution time in seconds
        raw_data: Raw response data as JSON
        results: Query results as JSON
        row_count: Number of rows returned
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Oracle Database account",
            "value": None,
            "type": "integration<Oracle Database>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "insert**(*)**(*)": {
            "inputs": [
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "placeholder": "Select schema",
                    "helper_text": "Choose the schema",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert into",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Data",
                    "placeholder": '{"NAME": "John", "EMAIL": "john@example.com"}',
                    "helper_text": "JSON objects with column-value pairs to insert (one per row)",
                },
                {
                    "field": "auto_commit",
                    "type": "bool",
                    "value": True,
                    "label": "Auto Commit",
                    "helper_text": "Automatically commit after each insert. If false, all inserts are wrapped in a transaction.",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows inserted",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data as JSON",
                },
            ],
            "name": "insert",
            "task_name": "tasks.oracle_database.insert",
            "description": "Insert rows in a table",
            "label": "Insert Rows",
            "variant": "common_integration_nodes",
            "required": ["schema", "table_name", "data"],
            "inputs_sort_order": [
                "integration",
                "action",
                "schema",
                "table_name",
                "data",
                "auto_commit",
            ],
        },
        "select**(*)**(*)": {
            "inputs": [
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "placeholder": "Select schema",
                    "helper_text": "Choose the schema",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to query",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "AGE > 21",
                    "helper_text": "Optional WHERE condition (without WHERE keyword)",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "ORDER BY",
                    "placeholder": "CREATED_AT DESC",
                    "helper_text": "Optional ORDER BY clause",
                },
                {
                    "field": "output_numbers_as_string",
                    "type": "bool",
                    "value": False,
                    "label": "Output Numbers As String",
                    "helper_text": "Convert numeric values to strings in the output",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": True,
                    "label": "Return All",
                    "helper_text": "Return all rows (ignores limit)",
                },
            ],
            "outputs": [
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Selected data as JSON",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names in the result set",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data as JSON",
                },
            ],
            "name": "select",
            "task_name": "tasks.oracle_database.select",
            "description": "Select rows from a table",
            "label": "Select",
            "variant": "common_integration_nodes",
            "required": ["schema", "table_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "schema",
                "table_name",
                "where_clause",
                "order_by",
                "return_all",
                "limit",
                "output_numbers_as_string",
            ],
        },
        "select**(*)**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return",
                }
            ],
            "outputs": [],
        },
        "update**(*)**(*)": {
            "inputs": [
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "placeholder": "Select schema",
                    "helper_text": "Choose the schema",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "match_columns",
                    "type": "string",
                    "value": "",
                    "label": "Match Columns",
                    "placeholder": "ID or ID,EMAIL",
                    "helper_text": "Column(s) to match on for update (comma-separated). Rows matching these column values will be updated.",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data as JSON",
                },
            ],
            "name": "update",
            "task_name": "tasks.oracle_database.update",
            "description": "Update rows in a table",
            "label": "Update Rows",
            "variant": "common_integration_nodes",
            "required": ["schema", "table_name", "match_columns"],
            "inputs_sort_order": [
                "integration",
                "action",
                "schema",
                "table_name",
                "match_columns",
            ],
        },
        "update**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "upsert**(*)**(*)": {
            "inputs": [
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "placeholder": "Select schema",
                    "helper_text": "Choose the schema",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert or update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "match_columns",
                    "type": "string",
                    "value": "",
                    "label": "Match Columns",
                    "placeholder": "ID or ID,EMAIL",
                    "helper_text": "Column(s) to match on for upsert (primary key or unique key). Use comma to separate multiple columns. If empty, will try to use table's primary key.",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows affected",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data as JSON",
                },
            ],
            "name": "upsert",
            "task_name": "tasks.oracle_database.upsert",
            "description": "Insert or update rows in a table (uses MERGE)",
            "label": "Insert or Update",
            "variant": "common_integration_nodes",
            "required": ["schema", "table_name", "match_columns"],
            "inputs_sort_order": [
                "integration",
                "action",
                "schema",
                "table_name",
                "match_columns",
            ],
        },
        "upsert**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "delete_table**(*)**(*)": {
            "inputs": [
                {
                    "field": "schema",
                    "type": "string",
                    "value": "",
                    "label": "Schema",
                    "placeholder": "Select schema",
                    "helper_text": "Choose the schema",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=schema&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&schema={inputs.schema}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "delete_command",
                    "type": "string",
                    "value": "delete",
                    "label": "Command",
                    "helper_text": "Delete command to execute (truncate, delete, or drop)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Delete", "value": "delete"},
                            {"label": "Truncate", "value": "truncate"},
                            {"label": "Drop", "value": "drop"},
                        ],
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "ID = 123",
                    "helper_text": "WHERE condition for delete command (not used for truncate/drop)",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows deleted",
                },
                {
                    "field": "table_dropped",
                    "type": "bool",
                    "helper_text": "Whether the entire table was dropped",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data as JSON",
                },
            ],
            "name": "delete_table",
            "task_name": "tasks.oracle_database.delete",
            "description": "Delete an entire table or rows in a table",
            "label": "Delete",
            "variant": "common_integration_nodes",
            "required": ["schema", "table_name", "delete_command"],
            "inputs_sort_order": [
                "integration",
                "action",
                "schema",
                "table_name",
                "delete_command",
                "where_clause",
            ],
        },
        "execute_query**(*)**(*)": {
            "inputs": [
                {
                    "field": "sql_query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "SELECT * FROM USERS WHERE AGE > :1",
                    "helper_text": "SQL query to execute (use :1, :2, etc. for parameters)",
                },
                {
                    "field": "bind_variable_placeholder_values",
                    "type": "string",
                    "value": "",
                    "label": "Bind Variable Placeholder Values",
                    "placeholder": "value1,value2,value3",
                    "helper_text": "Comma-separated values for bind variables (:1, :2, etc.) in the query",
                },
                {
                    "field": "output_numbers_as_string",
                    "type": "bool",
                    "value": False,
                    "label": "Output Numbers As String",
                    "helper_text": "Convert numeric values to strings in the output",
                },
            ],
            "outputs": [
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Query results as JSON",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names in the result set",
                },
                {
                    "field": "execution_time",
                    "type": "string",
                    "helper_text": "Query execution time in seconds",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data as JSON",
                },
            ],
            "name": "execute_query",
            "task_name": "tasks.oracle_database.execute_query",
            "description": "Execute a SQL query",
            "label": "Execute Query",
            "variant": "common_integration_nodes",
            "required": ["sql_query"],
            "inputs_sort_order": [
                "integration",
                "action",
                "sql_query",
                "bind_variable_placeholder_values",
                "output_numbers_as_string",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0", "return_all"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        return_all: bool = True,
        auto_commit: bool = True,
        bind_variable_placeholder_values: str = "",
        data: List[str] = [],
        delete_command: str = "delete",
        limit: int = 10,
        match_columns: str = "",
        order_by: str = "",
        output_numbers_as_string: bool = False,
        schema: str = "",
        sql_query: str = "",
        table_name: str = "",
        where_clause: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["return_all"] = return_all

        super().__init__(
            node_type="integration_oracle_database",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if schema is not None:
            self.inputs["schema"] = schema
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if data is not None:
            self.inputs["data"] = data
        if auto_commit is not None:
            self.inputs["auto_commit"] = auto_commit
        if where_clause is not None:
            self.inputs["where_clause"] = where_clause
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if output_numbers_as_string is not None:
            self.inputs["output_numbers_as_string"] = output_numbers_as_string
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if match_columns is not None:
            self.inputs["match_columns"] = match_columns
        if delete_command is not None:
            self.inputs["delete_command"] = delete_command
        if sql_query is not None:
            self.inputs["sql_query"] = sql_query
        if bind_variable_placeholder_values is not None:
            self.inputs["bind_variable_placeholder_values"] = (
                bind_variable_placeholder_values
            )
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationOracleDatabaseNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
