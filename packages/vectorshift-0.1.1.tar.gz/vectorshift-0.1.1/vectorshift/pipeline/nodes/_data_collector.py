"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import FieldDefinition


@Node.register_node_type("data_collector")
class DataCollectorNode(Node):
    """
    Allows a chatbot to collect information by asking the user to provide specific pieces of information (e.g., name, email, etc.).

    ## Inputs
    ### Common Inputs
        model: The specific model for question generation
        prompt: Specific instructions of how the LLM should collect the information
        query: The query to be analysed for data collection (passed to the LLM)
        auto_generate: If checked, the node will output questions in successive order until all fields are successfully collected. If unchecked, the node will output the data that is collected (often passed to an LLM with a prompt to ask successive questions to the user, along with specific instructions after all fields are collected) - e.g., {'Field1': 'Collected_Data', 'Field2': 'Collected_Data'}
        data_collector_node_id: The ID of the data collector node
        fields: The fields to be collected
        provider: The model provider

    ## Outputs
    ### When auto_generate = False
        collected_data: The data that is collected
    ### When auto_generate = True
        question: The question to be asked to the user
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for question generation",
            "value": "",
            "type": "string",
        },
        {
            "field": "prompt",
            "helper_text": "Specific instructions of how the LLM should collect the information",
            "value": "",
            "type": "string",
        },
        {
            "field": "query",
            "helper_text": "The query to be analysed for data collection (passed to the LLM)",
            "value": "",
            "type": "string",
        },
        {
            "field": "auto_generate",
            "helper_text": "If checked, the node will output questions in successive order until all fields are successfully collected. If unchecked, the node will output the data that is collected (often passed to an LLM with a prompt to ask successive questions to the user, along with specific instructions after all fields are collected) - e.g., {'Field1': 'Collected_Data', 'Field2': 'Collected_Data'}",
            "value": True,
            "type": "bool",
        },
        {
            "field": "data_collector_node_id",
            "helper_text": "The ID of the data collector node",
            "value": "",
            "type": "string",
        },
        {
            "field": "fields",
            "helper_text": "The fields to be collected",
            "value": [],
            "type": "vec<interface{id: string, field: string, description: string, example: string}>",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "question",
                    "type": "string",
                    "helper_text": "The question to be asked to the user",
                }
            ],
        },
        "false**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "collected_data",
                    "type": "string",
                    "helper_text": "The data that is collected",
                }
            ],
        },
        "true**openai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**google": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**xai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**cohere": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**together": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**bedrock": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**azure": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**groq": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "true**custom": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for question generation",
                    "component": {"type": "text"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["auto_generate", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["query"]

    def __init__(
        self,
        auto_generate: bool = True,
        provider: str = "openai",
        model: str = "",
        prompt: str = "",
        query: str = "",
        data_collector_node_id: str = "",
        fields: List[FieldDefinition] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["auto_generate"] = auto_generate
        params["provider"] = provider

        super().__init__(
            node_type="data_collector",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if query is not None:
            self.inputs["query"] = query
        if auto_generate is not None:
            self.inputs["auto_generate"] = auto_generate
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if fields is not None:
            self.inputs["fields"] = fields
        if data_collector_node_id is not None:
            self.inputs["data_collector_node_id"] = data_collector_node_id
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "DataCollectorNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
