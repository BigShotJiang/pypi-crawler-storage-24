"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_typeform")
class IntegrationTypeformNode(Node):
    """
    Typeform

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### get_responses
        form_id: Select the form from which to get the responses
        number_of_responses: The number of responses to fetch

    ## Outputs
    ### get_responses
        form_id: The form ID that was queried
        list_of_responses: The responses in list format
        page_count: Total number of pages
        raw_data: Full API response from Typeform
        total_items: Total number of responses available
        total_responses: Number of responses returned in this call
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Typeform>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_responses": {
            "inputs": [
                {
                    "field": "form_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Form",
                    "helper_text": "Select the form from which to get the responses",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "number_of_responses",
                    "type": "string",
                    "value": "",
                    "label": "Number of responses",
                    "placeholder": "10",
                    "helper_text": "The number of responses to fetch",
                },
            ],
            "outputs": [
                {
                    "field": "form_id",
                    "type": "string",
                    "helper_text": "The form ID that was queried",
                },
                {
                    "field": "list_of_responses",
                    "type": "vec<string>",
                    "helper_text": "The responses in list format",
                },
                {
                    "field": "total_items",
                    "type": "int32",
                    "helper_text": "Total number of responses available",
                },
                {
                    "field": "page_count",
                    "type": "int32",
                    "helper_text": "Total number of pages",
                },
                {
                    "field": "total_responses",
                    "type": "int32",
                    "helper_text": "Number of responses returned in this call",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full API response from Typeform",
                },
            ],
            "name": "get_responses",
            "task_name": "tasks.typeform.get_responses",
            "description": "Get multiple responses",
            "label": "List Form Responses",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "form_id",
                "number_of_responses",
            ],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "form_id", "number_of_responses"]

    def __init__(
        self,
        action: str = "",
        form_id: str = "",
        number_of_responses: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_typeform",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if form_id is not None:
            self.inputs["form_id"] = form_id
        if number_of_responses is not None:
            self.inputs["number_of_responses"] = number_of_responses
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationTypeformNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
