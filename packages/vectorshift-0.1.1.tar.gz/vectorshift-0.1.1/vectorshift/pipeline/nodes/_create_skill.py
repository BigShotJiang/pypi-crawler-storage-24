"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("create_skill")
class CreateSkillNode(Node):
    """
    Create a new skill with a name, description, and content

    ## Inputs
    ### Common Inputs
        content: The full content/instructions of the skill
        description: A brief description of what the skill does
        name: The name of the skill

    ## Outputs
    ### Common Outputs
        skill: The created skill
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "content",
            "helper_text": "The full content/instructions of the skill",
            "value": "",
            "type": "string",
        },
        {
            "field": "description",
            "helper_text": "A brief description of what the skill does",
            "value": "",
            "type": "string",
        },
        {
            "field": "name",
            "helper_text": "The name of the skill",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "skill", "helper_text": "The created skill", "type": "prompt"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["name", "content"]

    def __init__(
        self,
        content: str = "",
        description: str = "",
        name: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="create_skill",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if name is not None:
            self.inputs["name"] = name
        if description is not None:
            self.inputs["description"] = description
        if content is not None:
            self.inputs["content"] = content
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CreateSkillNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
