"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_slides")
class IntegrationGoogleSlidesNode(Node):
    """
    Google Slides

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### replace_text
        contains_text: The text to search for and replace
        match_case: Whether to match case when searching
        presentation_id: Select a presentation to read
        replace_text: The text to replace with
        revision_id: The revision ID of the presentation for version control. If specified, the request will only succeed if the presentation's current revision ID matches this value. Leave empty to apply changes without revision checking.
    ### read_thumbnail
        mime_type: Format of the thumbnail
        page_object_id: The object ID of the page/slide to read
        presentation_id: Select a presentation to read
        thumbnail_size: Size of the thumbnail
    ### read_page
        page_object_id: The object ID of the page/slide to read
        presentation_id: Select a presentation to read
    ### read_presentation
        presentation_id: Select a presentation to read
    ### get_slides
        presentation_id: Select a presentation to read
    ### create_presentation
        title: Title for the new presentation (defaults to 'Untitled Presentation')

    ## Outputs
    ### read_thumbnail
        file: The thumbnail image
        height: Height of the thumbnail
        page_id: The ID of the page
        presentation_id: The ID of the presentation
        raw_data: Raw API response data
        thumbnail_url: URL of the thumbnail image
        width: Width of the thumbnail
    ### read_page
        layout_properties: The layout properties
        notes_properties: The notes properties
        page_element_info: Information about page elements
        page_elements: The elements on the page
        page_id: The ID of the page
        presentation_id: The ID of the presentation
        raw_data: Raw API response data
        slide_content: The content of the slide
        slide_properties: The slide properties
        slide_title: The title of the slide
    ### read_presentation
        layouts: The layout slides
        locale: The locale of the presentation
        masters: The master slides
        page_size: The page size settings
        presentation_id: The ID of the presentation
        raw_data: Raw API response data
        slide_contents: The contents of the slides
        slide_info: Information about each slide
        slide_titles: The titles of the slides
        slides: The slides in the presentation
        title: The title of the presentation
    ### replace_text
        occurrences_changed: Number of occurrences that were replaced
        presentation_id: The ID of the presentation
        raw_data: Raw API response data
        replacement_text: The replacement text
        search_text: The text that was searched for
    ### create_presentation
        page_size: The page size settings of the presentation
        presentation_id: The ID of the created presentation
        raw_data: Raw API response data
        slides: The slides in the presentation
        title: The title of the presentation
    ### get_slides
        presentation_id: The ID of the presentation
        raw_data: Raw API response data
        slide_ids: The IDs of all slides
        slide_indexes: The indexes of all slides
        slides: All slides in the presentation
        total_slides: Total number of slides
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Slides>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_file_nodes",
        },
        "create_presentation": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Title",
                    "helper_text": "Title for the new presentation (defaults to 'Untitled Presentation')",
                    "placeholder": "Enter presentation title",
                }
            ],
            "outputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "helper_text": "The ID of the created presentation",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "The title of the presentation",
                },
                {
                    "field": "page_size",
                    "type": "string",
                    "helper_text": "The page size settings of the presentation",
                },
                {
                    "field": "slides",
                    "type": "vec<string>",
                    "helper_text": "The slides in the presentation",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "create_presentation",
            "task_name": "tasks.google_slides.create_presentation",
            "description": "Create a new Google Slides presentation",
            "label": "Create Presentation",
            "ui_sort_order": ["integration", "action", "title"],
        },
        "read_presentation": {
            "inputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Presentation",
                    "helper_text": "Select a presentation to read",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "helper_text": "The ID of the presentation",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "The title of the presentation",
                },
                {
                    "field": "page_size",
                    "type": "string",
                    "helper_text": "The page size settings",
                },
                {
                    "field": "slides",
                    "type": "vec<string>",
                    "helper_text": "The slides in the presentation",
                },
                {
                    "field": "slide_titles",
                    "type": "vec<string>",
                    "helper_text": "The titles of the slides",
                },
                {
                    "field": "slide_contents",
                    "type": "vec<string>",
                    "helper_text": "The contents of the slides",
                },
                {
                    "field": "masters",
                    "type": "vec<string>",
                    "helper_text": "The master slides",
                },
                {
                    "field": "layouts",
                    "type": "vec<string>",
                    "helper_text": "The layout slides",
                },
                {
                    "field": "locale",
                    "type": "string",
                    "helper_text": "The locale of the presentation",
                },
                {
                    "field": "slide_info",
                    "type": "vec<string>",
                    "helper_text": "Information about each slide",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_presentation",
            "task_name": "tasks.google_slides.read_presentation",
            "description": "Read details of a specific presentation",
            "label": "Get Presentation",
            "inputs_sort_order": ["integration", "action", "presentation_id"],
        },
        "get_slides": {
            "inputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Presentation",
                    "helper_text": "Select a presentation",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "helper_text": "The ID of the presentation",
                },
                {
                    "field": "slides",
                    "type": "vec<string>",
                    "helper_text": "All slides in the presentation",
                },
                {
                    "field": "slide_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of all slides",
                },
                {
                    "field": "slide_indexes",
                    "type": "vec<string>",
                    "helper_text": "The indexes of all slides",
                },
                {
                    "field": "total_slides",
                    "type": "string",
                    "helper_text": "Total number of slides",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_slides",
            "task_name": "tasks.google_slides.get_slides",
            "description": "Get multiple slides",
            "label": "List Slides",
            "inputs_sort_order": ["integration", "action", "presentation_id"],
        },
        "read_page": {
            "inputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Presentation",
                    "helper_text": "Select a presentation",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "page_object_id",
                    "type": "string",
                    "value": "",
                    "label": "Page Object ID",
                    "helper_text": "The object ID of the page/slide to read",
                    "placeholder": "Enter page object ID",
                },
            ],
            "outputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "helper_text": "The ID of the presentation",
                },
                {
                    "field": "page_id",
                    "type": "string",
                    "helper_text": "The ID of the page",
                },
                {
                    "field": "slide_title",
                    "type": "string",
                    "helper_text": "The title of the slide",
                },
                {
                    "field": "slide_content",
                    "type": "string",
                    "helper_text": "The content of the slide",
                },
                {
                    "field": "slide_properties",
                    "type": "string",
                    "helper_text": "The slide properties",
                },
                {
                    "field": "layout_properties",
                    "type": "string",
                    "helper_text": "The layout properties",
                },
                {
                    "field": "notes_properties",
                    "type": "string",
                    "helper_text": "The notes properties",
                },
                {
                    "field": "page_elements",
                    "type": "vec<string>",
                    "helper_text": "The elements on the page",
                },
                {
                    "field": "page_element_info",
                    "type": "vec<string>",
                    "helper_text": "Information about page elements",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_page",
            "task_name": "tasks.google_slides.read_page",
            "description": "Read details of a specific page",
            "label": "Get Page",
            "inputs_sort_order": [
                "integration",
                "action",
                "presentation_id",
                "page_object_id",
            ],
        },
        "read_thumbnail": {
            "inputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Presentation",
                    "helper_text": "Select a presentation",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "page_object_id",
                    "type": "string",
                    "value": "",
                    "label": "Page Object ID",
                    "helper_text": "The object ID of the page/slide",
                    "placeholder": "Enter page object ID",
                },
                {
                    "field": "thumbnail_size",
                    "type": "string",
                    "value": "MEDIUM",
                    "label": "Thumbnail Size",
                    "helper_text": "Size of the thumbnail",
                    "placeholder": "MEDIUM",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "SMALL", "label": "SMALL"},
                            {"value": "MEDIUM", "label": "MEDIUM"},
                            {"value": "LARGE", "label": "LARGE"},
                        ],
                    },
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "value": "PNG",
                    "label": "MIME Type",
                    "helper_text": "Format of the thumbnail",
                    "placeholder": "PNG",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "PNG", "label": "PNG"},
                            {"value": "JPG", "label": "JPG"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "helper_text": "The ID of the presentation",
                },
                {
                    "field": "page_id",
                    "type": "string",
                    "helper_text": "The ID of the page",
                },
                {"field": "file", "type": "file", "helper_text": "The thumbnail image"},
                {
                    "field": "thumbnail_url",
                    "type": "string",
                    "helper_text": "URL of the thumbnail image",
                },
                {
                    "field": "width",
                    "type": "string",
                    "helper_text": "Width of the thumbnail",
                },
                {
                    "field": "height",
                    "type": "string",
                    "helper_text": "Height of the thumbnail",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_thumbnail",
            "task_name": "tasks.google_slides.read_thumbnail",
            "description": "Read details of a specific thumbnail",
            "label": "Get Thumbnail",
            "inputs_sort_order": [
                "integration",
                "action",
                "presentation_id",
                "page_object_id",
                "thumbnail_size",
                "mime_type",
            ],
        },
        "replace_text": {
            "inputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Presentation",
                    "helper_text": "Select a presentation",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "contains_text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "helper_text": "The text to search for and replace",
                    "placeholder": "Enter text to find",
                },
                {
                    "field": "replace_text",
                    "type": "string",
                    "value": "",
                    "label": "Replace Text",
                    "helper_text": "The text to replace with",
                    "placeholder": "Enter replacement text",
                },
                {
                    "field": "match_case",
                    "type": "bool",
                    "value": False,
                    "label": "Match Case",
                    "helper_text": "Whether to match case when searching",
                },
                {
                    "field": "revision_id",
                    "type": "string",
                    "value": "",
                    "label": "Revision ID",
                    "helper_text": "The revision ID of the presentation for version control. If specified, the request will only succeed if the presentation's current revision ID matches this value. Leave empty to apply changes without revision checking.",
                    "placeholder": "e.g., ALm37WWtKjxPlJyAlpm37WWtKjxPlJyAl",
                },
            ],
            "outputs": [
                {
                    "field": "presentation_id",
                    "type": "string",
                    "helper_text": "The ID of the presentation",
                },
                {
                    "field": "search_text",
                    "type": "string",
                    "helper_text": "The text that was searched for",
                },
                {
                    "field": "replacement_text",
                    "type": "string",
                    "helper_text": "The replacement text",
                },
                {
                    "field": "occurrences_changed",
                    "type": "string",
                    "helper_text": "Number of occurrences that were replaced",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "replace_text",
            "task_name": "tasks.google_slides.replace_text",
            "description": "Replace all occurrences of text in a presentation",
            "label": "Replace Text",
            "ui_sort_order": [
                "integration",
                "action",
                "presentation_id",
                "contains_text",
                "replace_text",
                "match_case",
                "revision_id",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "presentation_id",
        "title",
        "page_object_id",
    ]

    def __init__(
        self,
        action: str = "",
        contains_text: str = "",
        match_case: bool = False,
        mime_type: str = "PNG",
        page_object_id: str = "",
        presentation_id: str = "",
        replace_text: str = "",
        revision_id: str = "",
        thumbnail_size: str = "MEDIUM",
        title: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_slides",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if title is not None:
            self.inputs["title"] = title
        if presentation_id is not None:
            self.inputs["presentation_id"] = presentation_id
        if page_object_id is not None:
            self.inputs["page_object_id"] = page_object_id
        if thumbnail_size is not None:
            self.inputs["thumbnail_size"] = thumbnail_size
        if mime_type is not None:
            self.inputs["mime_type"] = mime_type
        if contains_text is not None:
            self.inputs["contains_text"] = contains_text
        if replace_text is not None:
            self.inputs["replace_text"] = replace_text
        if match_case is not None:
            self.inputs["match_case"] = match_case
        if revision_id is not None:
            self.inputs["revision_id"] = revision_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleSlidesNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
