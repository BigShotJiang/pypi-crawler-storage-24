"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("ai_fill_pdf")
class AiFillPdfNode(Node):
    """
    Fill out a PDF with form fields using AI. The AI will understand and fill each field using provided context. To convert your PDF to have fillable input fields, use: https://www.sejda.com/pdf-forms

    ## Inputs
    ### Common Inputs
        model: The specific model for filling the PDF
        context: Context used by LLM to fill PDF fields
        file: The PDF with form fields to be filled
        provider: The model provider
        select_pages: Whether to select specific pages to fill
    ### When select_pages = True
        selected_pages: PDF page range

    ## Outputs
    ### Common Outputs
        filled_pdf: Filled PDF
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for filling the PDF",
            "value": "",
            "type": "string",
        },
        {
            "field": "context",
            "helper_text": "Context used by LLM to fill PDF fields",
            "value": "",
            "type": "string",
        },
        {
            "field": "file",
            "helper_text": "The PDF with form fields to be filled",
            "value": None,
            "type": "file",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "select_pages",
            "helper_text": "Whether to select specific pages to fill",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "filled_pdf", "helper_text": "Filled PDF", "type": "file"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [
                {
                    "field": "selected_pages",
                    "label": "Selected pages",
                    "type": "string",
                    "value": "",
                    "placeholder": "1-4, 6, 10-15",
                    "helper_text": "PDF page range",
                }
            ],
            "outputs": [],
        },
        "false**(*)": {"inputs": [], "outputs": []},
        "(*)**openai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**google": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**xai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**cohere": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**together": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**bedrock": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**azure": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filling the PDF",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["select_pages", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["file", "context"]

    def __init__(
        self,
        select_pages: bool = False,
        provider: str = "openai",
        model: str = "",
        context: str = "",
        file: Optional[str] = None,
        selected_pages: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["select_pages"] = select_pages
        params["provider"] = provider

        super().__init__(
            node_type="ai_fill_pdf",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if file is not None:
            self.inputs["file"] = file
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if select_pages is not None:
            self.inputs["select_pages"] = select_pages
        if context is not None:
            self.inputs["context"] = context
        if selected_pages is not None:
            self.inputs["selected_pages"] = selected_pages
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiFillPdfNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
