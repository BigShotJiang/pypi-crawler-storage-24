"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_microsoft")
class TriggerMicrosoftNode(Node):
    """
    OneDrive Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        trigger_enabled: Enable/Disable Automation
    ### new_file_direct
        item_id: Select a folder to watch for new files (direct children only)
    ### new_file_recursive
        item_id: Select a folder to watch for new files (direct children only)
    ### updated_file_direct
        item_id: Select a folder to watch for new files (direct children only)
    ### updated_file_recursive
        item_id: Select a folder to watch for new files (direct children only)
    ### updated_file_specific
        item_id: Select a folder to watch for new files (direct children only)
    ### new_folder_direct
        item_id: Select a folder to watch for new files (direct children only)
    ### new_folder_recursive
        item_id: Select a folder to watch for new files (direct children only)
    ### updated_folder_direct
        item_id: Select a folder to watch for new files (direct children only)
    ### updated_folder_recursive
        item_id: Select a folder to watch for new files (direct children only)

    ## Outputs
    ### new_file_direct
        created_by_email: Email of the user who created the file
        created_by_name: Name of the user who created the file
        created_time: When the file was created
        file_id: Unique identifier of the new file
        file_name: Name of the new file
        mime_type: MIME type of the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    ### new_file_recursive
        created_by_email: Email of the user who created the file
        created_by_name: Name of the user who created the file
        created_time: When the file was created
        file_id: Unique identifier of the new file
        file_name: Name of the new file
        mime_type: MIME type of the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    ### new_folder_direct
        created_by_email: Email of the user who created the folder
        created_by_name: Name of the user who created the folder
        created_time: When the folder was created
        folder_id: Unique identifier of the new folder
        folder_name: Name of the new folder
        modified_time: When the folder was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete folder data as JSON
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the folder in browser
    ### new_folder_recursive
        created_by_email: Email of the user who created the folder
        created_by_name: Name of the user who created the folder
        created_time: When the folder was created
        folder_id: Unique identifier of the new folder
        folder_name: Name of the new folder
        modified_time: When the folder was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete folder data as JSON
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the folder in browser
    ### updated_file_direct
        created_time: When the file was created
        file_id: Unique identifier of the updated file
        file_name: Name of the updated file
        mime_type: MIME type of the file
        modified_by_email: Email of the user who last modified the file
        modified_by_name: Name of the user who last modified the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    ### updated_file_recursive
        created_time: When the file was created
        file_id: Unique identifier of the updated file
        file_name: Name of the updated file
        mime_type: MIME type of the file
        modified_by_email: Email of the user who last modified the file
        modified_by_name: Name of the user who last modified the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    ### updated_file_specific
        created_time: When the file was created
        file_id: Unique identifier of the updated file
        file_name: Name of the updated file
        mime_type: MIME type of the file
        modified_by_email: Email of the user who last modified the file
        modified_by_name: Name of the user who last modified the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    ### updated_folder_direct
        created_time: When the folder was created
        folder_id: Unique identifier of the updated folder
        folder_name: Name of the updated folder
        modified_by_email: Email of the user who last modified the folder
        modified_by_name: Name of the user who last modified the folder
        modified_time: When the folder was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete folder data as JSON
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the folder in browser
    ### updated_folder_recursive
        created_time: When the folder was created
        folder_id: Unique identifier of the updated folder
        folder_name: Name of the updated folder
        modified_by_email: Email of the user who last modified the folder
        modified_by_name: Name of the user who last modified the folder
        modified_time: When the folder was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete folder data as JSON
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the folder in browser
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Microsoft>",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_file_direct": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for new files (direct children only)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the new file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "created_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the file",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_file_direct",
            "task_name": "tasks.onedrive.file_created_direct",
            "description": "Triggers when a new file is created directly inside the selected folder (not in subfolders)",
            "label": "New File (Direct)",
            "required": ["item_id"],
        },
        "new_file_recursive": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for new files (includes all subfolders)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the new file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "created_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the file",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_file_recursive",
            "task_name": "tasks.onedrive.file_created_recursive",
            "description": "Triggers when a new file is created anywhere inside the selected folder or its subfolders",
            "label": "New File (Recursive)",
            "required": ["item_id"],
        },
        "updated_file_direct": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for file updates (direct children only)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the updated file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "modified_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who last modified the file",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_file_direct",
            "task_name": "tasks.onedrive.file_updated_direct",
            "description": "Triggers when a file directly inside the selected folder is updated (not in subfolders)",
            "label": "Updated File (Direct)",
            "required": ["item_id"],
        },
        "updated_file_recursive": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for file updates (includes all subfolders)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the updated file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "modified_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who last modified the file",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_file_recursive",
            "task_name": "tasks.onedrive.file_updated_recursive",
            "description": "Triggers when a file anywhere inside the selected folder or its subfolders is updated",
            "label": "Updated File (Recursive)",
            "required": ["item_id"],
        },
        "updated_file_specific": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "File",
                    "helper_text": "Select a specific file to watch for updates",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the updated file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "modified_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who last modified the file",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_file_specific",
            "task_name": "tasks.onedrive.file_updated_specific",
            "description": "Triggers when a specific file is updated",
            "label": "Updated File (Specific File)",
            "required": ["item_id"],
        },
        "new_folder_direct": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for new subfolders (direct children only)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the new folder",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the folder in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "created_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the folder",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete folder data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_folder_direct",
            "task_name": "tasks.onedrive.folder_created_direct",
            "description": "Triggers when a new folder is created directly inside the selected folder (not in subfolders)",
            "label": "New Folder (Direct)",
            "required": ["item_id"],
        },
        "new_folder_recursive": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for new subfolders (includes all nested levels)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the new folder",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the folder in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "created_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the folder",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete folder data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_folder_recursive",
            "task_name": "tasks.onedrive.folder_created_recursive",
            "description": "Triggers when a new folder is created anywhere inside the selected folder or its subfolders",
            "label": "New Folder (Recursive)",
            "required": ["item_id"],
        },
        "updated_folder_direct": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for subfolder updates (direct children only)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the updated folder",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the folder in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "modified_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who last modified the folder",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete folder data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_folder_direct",
            "task_name": "tasks.onedrive.folder_updated_direct",
            "description": "Triggers when a folder directly inside the selected folder is updated (not in subfolders)",
            "label": "Updated Folder (Direct)",
            "required": ["item_id"],
        },
        "updated_folder_recursive": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Folder",
                    "helper_text": "Select a folder to watch for subfolder updates (includes all nested levels)",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the updated folder",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the folder was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the folder in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "modified_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who last modified the folder",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete folder data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_folder_recursive",
            "task_name": "tasks.onedrive.folder_updated_recursive",
            "description": "Triggers when a folder anywhere inside the selected folder or its subfolders is updated",
            "label": "Updated Folder (Recursive)",
            "required": ["item_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Folder"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_microsoft",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerMicrosoftNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
