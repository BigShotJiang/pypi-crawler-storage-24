"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_apollo")
class IntegrationApolloNode(Node):
    """
    Apollo

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### fetch_companies
        company_name: Name of the company to search
        keywords: Comma separated list of keywords the company should be associated with
        location: Location of the company headquarters
        max_size: Maximum number of employees in the company
        min_size: Minimum number of employees in the company
        num_results: Limit number of results
    ### enrich_contact
        company_name: Name of the company to search
        domain: Company domain
        first_name_input: Contact's first name
        last_name_input: Contact's last name
        linkedin_url_input: Contact's LinkedIn URL
    ### enrich_company
        domain: Company domain

    ## Outputs
    ### enrich_company
        annual_revenue: The company’s annual revenue e.g., 766400000000.0
        company_name: The company name e.g., Google
        country: The company’s headquartered country e.g., United States
        industry: The company’s industry e.g., information technology & services
        linkedin_url: The company’s Linkedin URL e.g., http://www.linkedin.com/company/google
        num_employees: The total number of employees e.g., 289000
        total_funding: The company’s total funding e.g., 3000000000000.0
        website: The company’s website e.g., http://www.google.com
    ### fetch_companies
        company_names: A list of company names e.g., ["VectorShift","VectorShift Studios"]
        domains: A list of domains e.g., ["vectorshift.ai","vectorshiftstudios.com"]
        linkedin_urls: A list of Linkedin URLs e.g., ["http://www.linkedin.com/company/vectorshift","http://www.linkedin.com/company/vectorshift-studios"]
        websites: A list of websites e.g., ["http://www.vectorshift.ai","http://www.vectorshiftstudios.com"]
    ### enrich_contact
        email: The person’s email address e.g., sundar@google.com
        first_name: The first name e.g., Sundar
        job_title: The person’s title e.g., CEO
        last_name: The last name e.g., Pichai
        linkedin_url: The person’s Linkedin e.g., https://www.linkedin.com/in/sundarpichai
        phone_number: The person’s phone number+10000000000
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Apollo>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "default_integration_nodes"},
        "fetch_companies": {
            "inputs": [
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "VectorShift",
                    "helper_text": "Name of the company to search",
                },
                {
                    "field": "keywords",
                    "type": "string",
                    "value": "",
                    "label": "Keywords",
                    "placeholder": "AI, automation",
                    "helper_text": "Comma separated list of keywords the company should be associated with",
                },
                {
                    "field": "min_size",
                    "type": "string",
                    "value": "",
                    "label": "Min Size",
                    "placeholder": "10",
                    "helper_text": "Minimum number of employees in the company",
                },
                {
                    "field": "max_size",
                    "type": "string",
                    "value": "",
                    "label": "Max Size",
                    "placeholder": "100",
                    "helper_text": "Maximum number of employees in the company",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "California, US",
                    "helper_text": "Location of the company headquarters",
                },
                {
                    "field": "num_results",
                    "type": "string",
                    "value": "",
                    "label": "Number of Results",
                    "placeholder": "10",
                    "helper_text": "Limit number of results",
                },
            ],
            "outputs": [
                {
                    "field": "company_names",
                    "type": "string",
                    "helper_text": 'A list of company names e.g., ["VectorShift","VectorShift Studios"]',
                },
                {
                    "field": "websites",
                    "type": "string",
                    "helper_text": 'A list of websites e.g., ["http://www.vectorshift.ai","http://www.vectorshiftstudios.com"]',
                },
                {
                    "field": "domains",
                    "type": "string",
                    "helper_text": 'A list of domains e.g., ["vectorshift.ai","vectorshiftstudios.com"]',
                },
                {
                    "field": "linkedin_urls",
                    "type": "string",
                    "helper_text": 'A list of Linkedin URLs e.g., ["http://www.linkedin.com/company/vectorshift","http://www.linkedin.com/company/vectorshift-studios"]',
                },
            ],
            "name": "fetch_companies",
            "task_name": "tasks.apollo.fetch_companies",
            "description": "Search for companies via Apollo api",
            "label": "Search Companies",
        },
        "enrich_company": {
            "inputs": [
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "placeholder": "google.com",
                    "helper_text": "Company domain",
                }
            ],
            "outputs": [
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "The company name e.g., Google",
                },
                {
                    "field": "country",
                    "type": "string",
                    "helper_text": "The company’s headquartered country e.g., United States",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "The company’s website e.g., http://www.google.com",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "helper_text": "The company’s industry e.g., information technology & services",
                },
                {
                    "field": "annual_revenue",
                    "type": "string",
                    "helper_text": "The company’s annual revenue e.g., 766400000000.0",
                },
                {
                    "field": "total_funding",
                    "type": "string",
                    "helper_text": "The company’s total funding e.g., 3000000000000.0",
                },
                {
                    "field": "num_employees",
                    "type": "string",
                    "helper_text": "The total number of employees e.g., 289000",
                },
                {
                    "field": "linkedin_url",
                    "type": "string",
                    "helper_text": "The company’s Linkedin URL e.g., http://www.linkedin.com/company/google",
                },
            ],
            "name": "enrich_company",
            "task_name": "tasks.apollo.enrich_company",
            "description": "Enrich company information via Apollo api",
            "label": "Enrich Company Information",
        },
        "enrich_contact": {
            "inputs": [
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "placeholder": "google.com",
                    "helper_text": "Contact's company domain",
                },
                {
                    "field": "first_name_input",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "Sundar",
                    "helper_text": "Contact's first name",
                },
                {
                    "field": "last_name_input",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Pichai",
                    "helper_text": "Contact's last name",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Google",
                    "helper_text": "Contact's company name",
                },
                {
                    "field": "linkedin_url_input",
                    "type": "string",
                    "value": "",
                    "label": "LinkedIn URL",
                    "placeholder": "https://www.linkedin.com/in/sundarpichai",
                    "helper_text": "Contact's LinkedIn URL",
                },
            ],
            "outputs": [
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "The first name e.g., Sundar",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "The last name e.g., Pichai",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "helper_text": "The person’s title e.g., CEO",
                },
                {
                    "field": "phone_number",
                    "type": "string",
                    "helper_text": "The person’s phone number+10000000000",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "The person’s email address e.g., sundar@google.com",
                },
                {
                    "field": "linkedin_url",
                    "type": "string",
                    "helper_text": "The person’s Linkedin e.g., https://www.linkedin.com/in/sundarpichai",
                },
            ],
            "name": "enrich_contact",
            "task_name": "tasks.apollo.enrich_contact",
            "description": "Enrich a contact via Apollo api",
            "label": "Enrich Contact Details",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        company_name: str = "",
        domain: str = "",
        first_name_input: str = "",
        keywords: str = "",
        last_name_input: str = "",
        linkedin_url_input: str = "",
        location: str = "",
        max_size: str = "",
        min_size: str = "",
        num_results: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_apollo",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if company_name is not None:
            self.inputs["company_name"] = company_name
        if keywords is not None:
            self.inputs["keywords"] = keywords
        if min_size is not None:
            self.inputs["min_size"] = min_size
        if max_size is not None:
            self.inputs["max_size"] = max_size
        if location is not None:
            self.inputs["location"] = location
        if num_results is not None:
            self.inputs["num_results"] = num_results
        if domain is not None:
            self.inputs["domain"] = domain
        if first_name_input is not None:
            self.inputs["first_name_input"] = first_name_input
        if last_name_input is not None:
            self.inputs["last_name_input"] = last_name_input
        if linkedin_url_input is not None:
            self.inputs["linkedin_url_input"] = linkedin_url_input
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationApolloNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
