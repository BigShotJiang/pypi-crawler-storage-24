"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("llm_google_vision")
class LlmGoogleVisionNode(Node):
    """


    ## Inputs
    ### Common Inputs
        model: The model input
        prompt: The prompt input
        temperature: The temperature input
        max_tokens: The max_tokens input
        top_p: The top_p input
        api_key: The api_key input
        image: The image input
        json_response: The json_response input
        provider: The provider input
        stream: The stream input

    ## Outputs
    ### Common Outputs
        response: The response output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The model input",
            "value": "gemini-pro-vision",
            "type": "string",
        },
        {
            "field": "prompt",
            "helper_text": "The prompt input",
            "value": "",
            "type": "string",
        },
        {
            "field": "temperature",
            "helper_text": "The temperature input",
            "value": 0.7,
            "type": "float",
        },
        {
            "field": "max_tokens",
            "helper_text": "The max_tokens input",
            "value": 32760,
            "type": "int32",
        },
        {
            "field": "top_p",
            "helper_text": "The top_p input",
            "value": 0.9,
            "type": "float",
        },
        {
            "field": "api_key",
            "helper_text": "The api_key input",
            "value": "",
            "type": "string",
        },
        {
            "field": "image",
            "helper_text": "The image input",
            "value": None,
            "type": "image",
        },
        {
            "field": "json_response",
            "helper_text": "The json_response input",
            "value": False,
            "type": "bool",
        },
        {
            "field": "provider",
            "helper_text": "The provider input",
            "value": "googleImageToText",
            "type": "string",
        },
        {
            "field": "stream",
            "helper_text": "The stream input",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "response", "helper_text": "The response output", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["image", "prompt", "api_key"]

    def __init__(
        self,
        model: str = "gemini-pro-vision",
        prompt: str = "",
        api_key: str = "",
        image: Optional[Any] = None,
        json_response: bool = False,
        provider: str = "googleImageToText",
        stream: bool = False,
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}

        super().__init__(
            node_type="llm_google_vision",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if stream is not None:
            self.inputs["stream"] = stream
        if json_response is not None:
            self.inputs["json_response"] = json_response
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if image is not None:
            self.inputs["image"] = image
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "LlmGoogleVisionNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
