"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_google_docs")
class IntegrationGoogleDocsNode(Node):
    """
    Google Docs

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Google Docs account
    ### When action = 'write_to_doc'
        text: The text that will be added to the File
        file_id: Select a File to read
    ### When action = 'get_documents'
        query: Search query to filter documents by name
        folder_id: ID of the folder to search in (optional)
        order_by: How to order the results
        shared_with_me: Include documents shared with me
        use_date: Toggle to use dates
    ### When action = 'create_document'
        content: Initial content for the document (optional)
        title: Title of the document
    ### When action = 'update_document'
        content: Initial content for the document (optional)
        file_id: Select a File to read
        operation: How to handle the content (replace, append, prepend)
        title: Title of the document
    ### When action = 'get_documents' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'read_doc_url'
        doc_url: Enter the public URL of the Google Doc
    ### When action = 'get_documents' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'read_doc'
        file_id: Select a File to read
    ### When action = 'delete_document'
        file_id: Select a File to read
    ### When action = 'get_document_info'
        file_id: Select a File to read
    ### When action = 'get_document_revisions'
        file_id: Select a File to read
    ### When action = 'get_documents' and use_date = False
        limit: Specify the number of documents to fetch
    ### When action = 'get_documents' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_doc_url'
        content: HTML body of the Google Doc
        raw_data: Raw HTML content of the Google Doc
    ### When action = 'update_document'
        content: Updated content of the document
        document_id: ID of the updated document
        document_title: Title of the updated document
        raw_data: Raw updated document data in JSON format
        revision_id: New revision ID of the document
    ### When action = 'create_document'
        created_time: Creation timestamp of the document
        document_id: ID of the created document
        document_title: Title of the created document
        document_url: URL of the created document
        raw_data: Raw document data in JSON format
    ### When action = 'get_document_info'
        created_time: Creation time of the document
        document_id: ID of the document
        document_title: Title of the document
        document_url: URL of the document
        modified_time: Last modification time of the document
        owners: Document owners in JSON format
        raw_data: Raw document info in JSON format
        shared: Whether the document is shared
    ### When action = 'get_documents'
        created_times: List of document creation times
        document_count: Number of documents found
        document_ids: List of document IDs
        document_titles: List of document titles
        document_urls: List of document URLs
        documents: Documents data in JSON format
        modified_times: List of document modification times
        raw_data: Raw API response data in JSON format
    ### When action = 'read_doc'
        document_id: ID of the document
        document_title: Title of the document
        raw_data: Raw document data in JSON format
        revision_id: Revision ID of the document
        text: The text content of the selected file
    ### When action = 'delete_document'
        message: Success message
        raw_data: Raw response data in JSON format
    ### When action = 'write_to_doc'
        raw_data: Raw API response data in JSON format
    ### When action = 'get_document_revisions'
        raw_data: Raw API response data in JSON format
        revision_ids: List of revision IDs
        revision_times: List of revision timestamps
        revisions: Document revisions in JSON format
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Google Docs account",
            "value": None,
            "type": "integration<Google Docs>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "read_doc**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select a File to read",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "The text content of the selected file",
                },
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the document",
                },
                {
                    "field": "document_title",
                    "type": "string",
                    "helper_text": "Title of the document",
                },
                {
                    "field": "revision_id",
                    "type": "string",
                    "helper_text": "Revision ID of the document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw document data in JSON format",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "read_doc",
            "task_name": "tasks.google_docs.read_doc",
            "description": "Read details of a specific document",
            "label": "Get Document",
            "inputs_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "write_to_doc**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select a File to append the text to",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Text",
                    "placeholder": "Hello World!",
                    "helper_text": "The text that will be added to the File",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                }
            ],
            "variant": "common_integration_file_nodes",
            "name": "write_to_doc",
            "task_name": "tasks.google_docs.write_to_doc",
            "description": "Append text to an existing document",
            "label": "Append Text to Document",
            "inputs_sort_order": ["integration", "action", "file_id", "text"],
            "required": ["file_id", "text"],
        },
        "read_doc_url**(*)**(*)": {
            "inputs": [
                {
                    "field": "doc_url",
                    "type": "string",
                    "value": "",
                    "label": "Google Doc URL",
                    "helper_text": "Enter the public URL of the Google Doc",
                    "placeholder": "Enter the public URL of the Google Doc",
                }
            ],
            "outputs": [
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "HTML body of the Google Doc",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw HTML content of the Google Doc",
                },
            ],
            "variant": "default_integration_nodes",
            "banner_text": 'Ensure that the Google Docs\'s permissions is set to "Anyone with the Link"',
            "name": "read_doc_url",
            "task_name": "tasks.google_docs.read_doc_url",
            "description": "Read details of a specific document from URL",
            "label": "Get Doc from URL",
            "inputs_sort_order": ["integration", "action", "doc_url"],
            "required": ["doc_url"],
        },
        "create_document**(*)**(*)": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the document",
                    "label": "Document Title",
                    "placeholder": "My New Document",
                },
                {
                    "field": "content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Initial content for the document (optional)",
                    "label": "Initial Content",
                    "placeholder": "Enter initial document content...",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the created document",
                },
                {
                    "field": "document_title",
                    "type": "string",
                    "helper_text": "Title of the created document",
                },
                {
                    "field": "document_url",
                    "type": "string",
                    "helper_text": "URL of the created document",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw document data in JSON format",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "create_document",
            "task_name": "tasks.google_docs.create_document",
            "description": "Create a new Google Docs document",
            "label": "Create Document",
            "inputs_sort_order": ["integration", "action", "title", "content"],
            "required": ["title"],
        },
        "update_document**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select a File to update",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the document",
                    "label": "Document Title",
                    "placeholder": "Updated document title",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "content",
                    "type": "string",
                    "value": "",
                    "helper_text": "New content for the document",
                    "label": "Document Content",
                    "placeholder": "Enter updated content...",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "operation",
                    "type": "string",
                    "value": "replace",
                    "helper_text": "How to handle the content (replace, append, prepend)",
                    "label": "Operation",
                    "placeholder": "replace",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Replace", "value": "replace"},
                            {"label": "Prepend", "value": "prepend"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the updated document",
                },
                {
                    "field": "document_title",
                    "type": "string",
                    "helper_text": "Title of the updated document",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "Updated content of the document",
                },
                {
                    "field": "revision_id",
                    "type": "string",
                    "helper_text": "New revision ID of the document",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw updated document data in JSON format",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_document",
            "task_name": "tasks.google_docs.update_document",
            "description": "Update the title and/or content of an existing Google Docs document",
            "label": "Update Document",
            "inputs_sort_order": [
                "integration",
                "action",
                "file_id",
                "title",
                "content",
                "operation",
            ],
            "required": ["file_id"],
        },
        "delete_document**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select a File to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data in JSON format",
                },
            ],
            "name": "delete_document",
            "task_name": "tasks.google_docs.delete_document",
            "description": "Delete an existing Google Docs document",
            "label": "Delete Document",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "get_documents**(*)**(*)": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the folder to search in (optional)",
                    "label": "Folder ID",
                    "placeholder": "1a2b3c4d5e6f7g8h9i",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter documents by name",
                    "label": "Search Query",
                    "placeholder": "document name",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "shared_with_me",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include documents shared with me",
                    "label": "Include Shared Documents",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "modifiedTime desc",
                    "helper_text": "How to order the results",
                    "label": "Order By",
                    "placeholder": "modifiedTime desc",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
            ],
            "outputs": [
                {
                    "field": "documents",
                    "type": "string",
                    "helper_text": "Documents data in JSON format",
                },
                {
                    "field": "document_count",
                    "type": "int32",
                    "helper_text": "Number of documents found",
                },
                {
                    "field": "document_ids",
                    "type": "vec<string>",
                    "helper_text": "List of document IDs",
                },
                {
                    "field": "document_titles",
                    "type": "vec<string>",
                    "helper_text": "List of document titles",
                },
                {
                    "field": "document_urls",
                    "type": "vec<string>",
                    "helper_text": "List of document URLs",
                },
                {
                    "field": "created_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of document creation times",
                },
                {
                    "field": "modified_times",
                    "type": "vec<string>",
                    "helper_text": "List of document modification times",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_documents",
            "task_name": "tasks.google_docs.get_documents",
            "description": "Get multiple documents",
            "label": "List Documents",
            "inputs_sort_order": [
                "integration",
                "action",
                "folder_id",
                "query",
                "shared_with_me",
                "order_by",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "limit",
            ],
            "required": ["limit"],
        },
        "get_documents**false**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 100,
                    "show_date_range": True,
                    "label": "Number of Documents",
                    "helper_text": "Specify the number of documents to fetch",
                }
            ],
            "outputs": [],
        },
        "get_documents**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_documents**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_documents**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_document_info**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select a File to get info for",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "document_id",
                    "type": "string",
                    "helper_text": "ID of the document",
                },
                {
                    "field": "document_title",
                    "type": "string",
                    "helper_text": "Title of the document",
                },
                {
                    "field": "document_url",
                    "type": "string",
                    "helper_text": "URL of the document",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Creation time of the document",
                },
                {
                    "field": "modified_time",
                    "type": "string",
                    "helper_text": "Last modification time of the document",
                },
                {
                    "field": "owners",
                    "type": "string",
                    "helper_text": "Document owners in JSON format",
                },
                {
                    "field": "shared",
                    "type": "bool",
                    "helper_text": "Whether the document is shared",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw document info in JSON format",
                },
            ],
            "name": "get_document_info",
            "task_name": "tasks.google_docs.get_document_info",
            "description": "Get detailed information about a Google Docs document",
            "label": "Get Document Info",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
        "get_document_revisions**(*)**(*)": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select a File to get revisions for",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "revisions",
                    "type": "string",
                    "helper_text": "Document revisions in JSON format",
                },
                {
                    "field": "revision_ids",
                    "type": "vec<string>",
                    "helper_text": "List of revision IDs",
                },
                {
                    "field": "revision_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of revision timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data in JSON format",
                },
            ],
            "name": "get_document_revisions",
            "task_name": "tasks.google_docs.get_document_revisions",
            "description": "Get multiple revisions",
            "label": "List Document Revisions",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": ["integration", "action", "file_id"],
            "required": ["file_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        text: str = "",
        query: str = "",
        content: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        doc_url: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        file_id: Optional[str] = None,
        folder_id: str = "",
        limit: int = 100,
        operation: str = "replace",
        order_by: str = "modifiedTime desc",
        shared_with_me: bool = False,
        title: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_google_docs",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if file_id is not None:
            self.inputs["file_id"] = file_id
        if text is not None:
            self.inputs["text"] = text
        if doc_url is not None:
            self.inputs["doc_url"] = doc_url
        if title is not None:
            self.inputs["title"] = title
        if content is not None:
            self.inputs["content"] = content
        if operation is not None:
            self.inputs["operation"] = operation
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if query is not None:
            self.inputs["query"] = query
        if shared_with_me is not None:
            self.inputs["shared_with_me"] = shared_with_me
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if limit is not None:
            self.inputs["limit"] = limit
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleDocsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
