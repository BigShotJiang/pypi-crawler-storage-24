"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_github")
class IntegrationGithubNode(Node):
    """
    Github

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'search_pull_requests'
        query: Search query for pull requests
        direction: Sort direction
        limit: Maximum number of pull requests to return
        owner: Owner of the repository
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        sort: Sort repositories by
        state: Issue state filter
    ### When action = 'get_repositories'
        affiliation: Affiliation filter
        direction: Sort direction
        owner: Owner of the repository
        return_all: Return all repositories, ignoring the number limit
        sort: Sort repositories by
        type: Repository type filter
        use_date: Toggle to use dates
        visibility: Visibility filter
    ### When action = 'get_issues'
        assignee: Assignee filter
        creator: Creator filter
        direction: Sort direction
        labels: Comma-separated list of labels
        mentioned: Mentioned user filter
        milestone: Milestone number
        owner: Owner of the repository
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        sort: Sort repositories by
        state: Issue state filter
        use_date: Toggle to use dates
    ### When action = 'create_issue'
        assignees: Comma-separated list of assignee usernames
        issue_body: Body content of the issue
        issue_title: Title of the issue
        labels: Comma-separated list of labels
        milestone: Milestone number
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'create_file'
        author_email: Email of the author
        author_name: Name of the author
        branch_name: Branch to create the file on
        commit_message: Message for the merge commit
        committer_email: Email of the committer
        committer_name: Name of the committer
        file_content: Content of the file
        file_path: Path where the file will be created
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'create_repository'
        auto_init: Initialize repository with a README
        gitignore_template: GitIgnore template to use
        homepage: Homepage URL for the repository
        is_private: Whether the repository should be private
        license_template: License template to use
        repository_description: Description of the repository
        repository_name: Name of the repository to create
    ### When action = 'create_pull_request'
        base: Base branch (target)
        draft: Create as draft pull request
        head: Head branch (source)
        maintainer_can_modify: Allow maintainer modifications
        owner: Owner of the repository
        pull_request_body: Body content of the pull request
        pull_request_title: Title of the pull request
        repository_name: Name of the repository to create
    ### When action = 'get_pull_requests'
        base: Base branch (target)
        direction: Sort direction
        head: Head branch (source)
        owner: Owner of the repository
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        sort: Sort repositories by
        state: Issue state filter
        use_date: Toggle to use dates
    ### When action = 'create_branch'
        branch_name: Branch to create the file on
        owner: Owner of the repository
        repository_name: Name of the repository to create
        source_branch: Source branch to create from
    ### When action = 'read_branch'
        branch_name: Branch to create the file on
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'delete_branch'
        branch_name: Branch to create the file on
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'create_issue_comment'
        comment_body: Body content of the comment
        issue_number: Number of the issue to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'update_issue_comment'
        comment_id: ID of the comment to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
        update_comment_body: New body for the comment
    ### When action = 'read_issue_comment'
        comment_id: ID of the comment to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'delete_issue_comment'
        comment_id: ID of the comment to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'merge_pull_request'
        commit_message: Message for the merge commit
        commit_title: Title for the merge commit
        merge_method: Merge method to use
        owner: Owner of the repository
        pull_request_number: Number of the pull request to update
        repository_name: Name of the repository to create
        sha: SHA that pull request head must match
    ### When action = 'create_webhook'
        content_type: Content type for webhook payloads
        insecure_ssl: Allow insecure SSL
        owner: Owner of the repository
        repository_name: Name of the repository to create
        webhook_active: Whether the webhook is active
        webhook_events: Events to trigger webhook (comma-separated)
        webhook_name: Name of the webhook
        webhook_secret: Secret key for webhook security
        webhook_url: URL to send webhook payloads to
    ### When action = 'get_repositories' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_issues' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_pull_requests' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_issue_comments' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_releases' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_branches' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_organization_members' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_webhooks' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'delete_file'
        delete_author_email: Email of the author
        delete_author_name: Name of the author
        delete_branch_name: Branch to delete the file from
        delete_commit_message: Commit message for the file deletion
        delete_committer_email: Email of the committer
        delete_committer_name: Name of the committer
        delete_file_sha: Current SHA of the file to delete
        file_path: Path where the file will be created
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'get_issue_comments'
        direction: Sort direction
        issue_number: Number of the issue to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        sort: Sort repositories by
        use_date: Toggle to use dates
    ### When action = 'create_release'
        draft: Create as draft pull request
        generate_release_notes: Auto-generate release notes
        owner: Owner of the repository
        prerelease: Mark as prerelease
        release_body: Description of the release
        release_name: Name of the release
        repository_name: Name of the repository to create
        tag_name: Name of the tag for the release
        target_commitish: Commitish value for the release
    ### When action = 'get_repositories' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_issues' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_pull_requests' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_issue_comments' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_releases' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_branches' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_organization_members' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_webhooks' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'update_file'
        file_path: Path where the file will be created
        file_sha: Current SHA of the file
        owner: Owner of the repository
        repository_name: Name of the repository to create
        update_author_email: Email of the author
        update_author_name: Name of the author
        update_branch_name: Branch to update the file on
        update_commit_message: Commit message for the file update
        update_committer_email: Email of the committer
        update_committer_name: Name of the committer
        update_file_content: New content of the file
    ### When action = 'read_file'
        file_path: Path where the file will be created
        owner: Owner of the repository
        ref: Branch, tag, or commit to read from
        repository_name: Name of the repository to create
    ### When action = 'get_organization_members'
        filter: Filter members by role
        organization: Name of the organization
        return_all: Return all repositories, ignoring the number limit
        role: Filter by member role
        use_date: Toggle to use dates
    ### When action = 'update_issue'
        issue_number: Number of the issue to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
        update_assignees: New assignees for the issue
        update_issue_body: New body for the issue
        update_issue_state: New state for the issue
        update_issue_title: New title for the issue
        update_labels: New labels for the issue
        update_milestone: New milestone for the issue
    ### When action = 'read_issue'
        issue_number: Number of the issue to update
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'get_repositories' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_issues' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_pull_requests' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_issue_comments' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_releases' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_branches' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_organization_members' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'get_webhooks' and use_date = False
        num_messages: Specify the number of repositories to fetch
    ### When action = 'update_repository'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        update_has_issues: Enable/disable issues
        update_has_projects: Enable/disable projects
        update_has_wiki: Enable/disable wiki
        update_homepage: New homepage URL
        update_is_private: Update privacy setting
        update_repository_description: New description for the repository
        update_repository_name: New name for the repository
    ### When action = 'read_repository'
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'delete_repository'
        owner: Owner of the repository
        repository_name: Name of the repository to create
    ### When action = 'update_pull_request'
        owner: Owner of the repository
        pull_request_number: Number of the pull request to update
        repository_name: Name of the repository to create
        update_base: New base branch
        update_maintainer_can_modify: Update maintainer modification permission
        update_pull_request_body: New body for the pull request
        update_pull_request_state: New state for the pull request
        update_pull_request_title: New title for the pull request
    ### When action = 'read_pull_request'
        owner: Owner of the repository
        pull_request_number: Number of the pull request to update
        repository_name: Name of the repository to create
    ### When action = 'update_release'
        owner: Owner of the repository
        release_id: ID of the release to update
        repository_name: Name of the repository to create
        update_draft: Update draft status
        update_prerelease: Update prerelease status
        update_release_body: New description for the release
        update_release_name: New name for the release
        update_tag_name: New tag name for the release
        update_target_commitish: New commitish value for the release
    ### When action = 'read_release'
        owner: Owner of the repository
        release_id: ID of the release to update
        repository_name: Name of the repository to create
    ### When action = 'get_releases'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        use_date: Toggle to use dates
    ### When action = 'delete_release'
        owner: Owner of the repository
        release_id: ID of the release to update
        repository_name: Name of the repository to create
    ### When action = 'get_branches'
        owner: Owner of the repository
        protected: Filter by protected status
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        use_date: Toggle to use dates
    ### When action = 'update_webhook'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        update_content_type: New content type
        update_insecure_ssl: Update insecure SSL setting
        update_webhook_active: Update webhook active status
        update_webhook_events: New events to trigger webhook
        update_webhook_secret: New secret key for webhook
        update_webhook_url: New URL for webhook payloads
        webhook_id: ID of the webhook to update
    ### When action = 'read_webhook'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        webhook_id: ID of the webhook to update
    ### When action = 'get_webhooks'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        return_all: Return all repositories, ignoring the number limit
        use_date: Toggle to use dates
    ### When action = 'delete_webhook'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        webhook_id: ID of the webhook to update
    ### When action = 'ping_webhook'
        owner: Owner of the repository
        repository_name: Name of the repository to create
        webhook_id: ID of the webhook to update
    ### When action = 'get_repositories' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_issues' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_pull_requests' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_issue_comments' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_releases' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_branches' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_organization_members' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_webhooks' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'read_user'
        username: Username to read information for

    ## Outputs
    ### When action = 'read_pull_request'
        additions_count: Number of additions
        assignees: List of assignees
        author: PR author details
        base_details: Base branch name
        changed_files_count: Number of changed files
        closed_at: Closure timestamp
        commits_count: Number of commits
        created_at: Creation timestamp
        deletions_count: Number of deletions
        draft: Whether the pull request is a draft
        head_details: Head branch name
        labels: List of labels
        mergeable: Whether the pull request is mergeable
        merged: Whether the pull request is merged
        merged_at: Merge timestamp
        milestone: Milestone details
        pull_request_body: Body of the pull request
        pull_request_details: Pull request details in JSON format
        pull_request_id: ID of the pull request
        pull_request_number: Number of the pull request
        pull_request_state: State of the pull request
        pull_request_title: Title of the pull request
        pull_request_url: URL of the pull request
        raw_data: Raw API response data
        requested_reviewers: List of requested reviewers
        reviewer_names: List of requested reviewer login names
        updated_at: Last update timestamp
    ### When action = 'get_pull_requests'
        additions_count: List of addition counts
        assignees_details: List of assignee details
        author_details: List of PR author details
        base_details: List of base branch names
        changed_files_count: List of changed file counts
        closed_dates: List of closure dates
        commits_counts: List of commit counts
        created_dates: List of creation dates
        deletions_count: List of deletion counts
        draft_flags: List of draft flags
        head_details: List of head branch names
        labels_details: List of label details
        mergeable_flags: List of mergeable flags
        merged_dates: List of merge dates
        merged_flags: List of merged flags
        milestone_details: List of milestone details
        pull_request_bodies: List of pull request bodies
        pull_request_details: Pull request details in JSON format
        pull_request_ids: List of pull request IDs
        pull_request_numbers: List of pull request numbers
        pull_request_states: List of pull request states
        pull_request_titles: List of pull request titles
        pull_request_urls: List of pull request URLs
        raw_data: Raw API response data
        requested_reviewers_details: List of requested reviewer details
        reviewer_names: List of requested reviewer login names
        updated_dates: List of update dates
    ### When action = 'read_release'
        assets_details: Release assets details
        author_details: Release author details
        created_at: Creation timestamp
        draft: Whether the release is a draft
        prerelease: Whether the release is a prerelease
        published_at: Publication timestamp
        release_body: Body of the release
        release_details: Release details in JSON format
        release_id: ID of the release
        release_name: Name of the release
        release_url: URL of the release
        tag_name: Tag name of the release
        tarball_url: Tarball download URL
        zipball_url: Zipball download URL
    ### When action = 'get_releases'
        assets_details: List of assets details
        author_details: List of author details
        created_dates: List of creation dates
        draft_flags: List of draft flags
        prerelease_flags: List of prerelease flags
        published_dates: List of publication dates
        raw_data: Raw API response data
        release_bodies: List of release bodies
        release_details: Release details in JSON format
        release_ids: List of release IDs
        release_names: List of release names
        release_urls: List of release URLs
        tag_names: List of tag names
        tarball_urls: List of tarball URLs
        zipball_urls: List of zipball URLs
    ### When action = 'create_issue'
        assignees: List of assignees
        created_at: Creation timestamp
        issue_details: Issue details in JSON format
        issue_id: ID of the created issue
        issue_number: Number of the created issue
        issue_state: State of the created issue
        issue_title: Title of the created issue
        issue_url: URL of the created issue
        labels: List of labels
        milestone: Milestone details
    ### When action = 'update_issue'
        assignees: List of assignees
        issue_details: Issue details in JSON format
        issue_id: ID of the updated issue
        issue_number: Number of the updated issue
        issue_state: State of the updated issue
        issue_title: Title of the updated issue
        issue_url: URL of the updated issue
        labels: List of labels
        milestone: Milestone details
        updated_at: Update timestamp
    ### When action = 'read_issue'
        assignees: List of assignees
        author: Issue author details
        closed_at: Closure timestamp
        comments_count: Number of comments
        created_at: Creation timestamp
        issue_body: Body of the issue
        issue_details: Issue details in JSON format
        issue_id: ID of the issue
        issue_number: Number of the issue
        issue_state: State of the issue
        issue_title: Title of the issue
        issue_url: URL of the issue
        labels: List of labels
        milestone: Milestone details
        updated_at: Last update timestamp
    ### When action = 'get_issues'
        assignees_details: List of assignee details
        author_details: List of author details
        closed_dates: List of closure dates
        comments_counts: List of comment counts
        created_dates: List of creation dates
        issue_bodies: List of issue bodies
        issue_details: Issue details in JSON format
        issue_ids: List of issue IDs
        issue_numbers: List of issue numbers
        issue_states: List of issue states
        issue_titles: List of issue titles
        issue_urls: List of issue URLs
        labels_details: List of label details
        milestone_details: List of milestone details
        raw_data: Raw API response data
        updated_dates: List of update dates
    ### When action = 'search_pull_requests'
        author_details: List of author details
        closed_dates: List of closure dates
        created_dates: List of creation dates
        draft_flags: List of draft flags
        labels_details: List of label details
        merged_dates: List of merge dates
        pull_request_bodies: List of pull request bodies
        pull_request_details: Pull request details in JSON format
        pull_request_ids: List of pull request IDs
        pull_request_numbers: List of pull request numbers
        pull_request_states: List of pull request states
        pull_request_titles: List of pull request titles
        pull_request_urls: List of pull request URLs
        raw_data: Raw API response data
        requested_reviewers_details: List of requested reviewer details
        reviewer_names: List of requested reviewer login names
        updated_dates: List of update dates
    ### When action = 'create_issue_comment'
        author_details: Comment author details
        comment_body: Body of the created comment
        comment_details: Comment details in JSON format
        comment_id: ID of the created comment
        comment_url: URL of the created comment
        created_at: Creation timestamp
    ### When action = 'update_issue_comment'
        author_details: Comment author details
        comment_body: Body of the updated comment
        comment_details: Comment details in JSON format
        comment_id: ID of the updated comment
        comment_url: URL of the updated comment
        updated_at: Update timestamp
    ### When action = 'read_issue_comment'
        author_details: Comment author details
        comment_body: Body of the comment
        comment_details: Comment details in JSON format
        comment_id: ID of the comment
        comment_url: URL of the comment
        created_at: Creation timestamp
        updated_at: Last update timestamp
    ### When action = 'get_issue_comments'
        author_details: List of comment author details
        comment_bodies: List of comment bodies
        comment_details: Comment details in JSON format
        comment_ids: List of comment IDs
        comment_urls: List of comment URLs
        created_dates: List of creation dates
        raw_data: Raw API response data
        updated_dates: List of update dates
    ### When action = 'read_user'
        avatar_url: Avatar URL of the user
        bio: Bio of the user
        blog: Blog URL of the user
        company: Company of the user
        html_url: Profile URL of the user
        location: Location of the user
        user_details: User details in JSON format
        user_email: Email of the user
        user_id: ID of the user
        user_name: Display name of the user
        username: Username of the user
    ### When action = 'get_organization_members'
        avatar_urls: List of avatar URLs
        html_urls: List of profile URLs
        member_roles: List of member roles
        raw_data: Raw API response data
        user_details: User details in JSON format
        user_emails: List of user emails
        user_ids: List of user IDs
        user_names: List of display names
        user_types: List of user types
        usernames: List of usernames
    ### When action = 'create_branch'
        branch_details: Branch details in JSON format
        branch_name: Name of the created branch
        ref: Reference of the branch
        sha: SHA of the branch
        url: URL of the branch
    ### When action = 'read_branch'
        branch_details: Branch details in JSON format
        branch_name: Name of the branch
        commit_author: Author of the latest commit
        commit_committer: Committer of the latest commit
        commit_date: Date of the latest commit
        commit_message: Message of the latest commit
        commit_url: URL of the latest commit
        protected: Whether the branch is protected
        sha: SHA of the latest commit
    ### When action = 'get_branches'
        branch_details: Branch details in JSON format
        branch_names: List of branch names
        commit_authors: List of commit authors
        commit_committers: List of commit committers
        commit_dates: List of commit dates
        commit_messages: List of commit messages
        commit_shas: List of commit SHAs
        commit_urls: List of commit URLs
        protected_flags: List of protection flags
        raw_data: Raw API response data
    ### When action = 'delete_branch'
        branch_name: Name of the deleted branch
        message: Success message
    ### When action = 'create_repository'
        clone_url: Clone URL for the repository
        created_at: Creation timestamp
        is_private: Whether the repository is private
        repository_details: Repository details in JSON format
        repository_full_name: Full name of the repository (owner/repo)
        repository_id: ID of the created repository
        repository_name: Name of the created repository
        repository_url: URL of the repository
        ssh_url: SSH URL for the repository
    ### When action = 'read_repository'
        clone_url: Clone URL for the repository
        created_at: Creation timestamp
        default_branch: Default branch name
        forks_count: Number of forks
        is_fork: Whether the repository is a fork
        is_private: Whether the repository is private
        language: Primary programming language
        open_issues_count: Number of open issues
        owner_details: Repository owner details
        pushed_at: Last push timestamp
        repository_description: Description of the repository
        repository_details: Repository details in JSON format
        repository_full_name: Full name of the repository
        repository_id: ID of the repository
        repository_name: Name of the repository
        repository_url: URL of the repository
        ssh_url: SSH URL for the repository
        stargazers_count: Number of stars
        updated_at: Last update timestamp
        watchers_count: Number of watchers
    ### When action = 'get_repositories'
        clone_urls: List of clone URLs
        created_dates: List of creation dates
        default_branches: List of default branch names
        forks_counts: List of fork counts
        is_private_flags: List of privacy flags
        languages: List of primary languages
        open_issues_counts: List of open issue counts
        owner_details: List of owner details
        pushed_dates: List of last push dates
        raw_data: Raw API response data
        repository_descriptions: List of repository descriptions
        repository_details: Repository details in JSON format
        repository_full_names: List of full repository names
        repository_ids: List of repository IDs
        repository_names: List of repository names
        repository_urls: List of repository URLs
        ssh_urls: List of SSH URLs
        stargazers_counts: List of star counts
        updated_dates: List of update dates
        watchers_counts: List of watcher counts
    ### When action = 'delete_issue_comment'
        comment_id: ID of the deleted comment
        message: Success message
    ### When action = 'create_file'
        commit_sha: SHA of the commit
        download_url: Download URL of the file
        file_details: File details in JSON format
        file_path: Path of the created file
        file_url: URL of the created file
        sha: SHA of the created file
    ### When action = 'update_file'
        commit_sha: SHA of the commit
        download_url: Download URL of the file
        file_details: File details in JSON format
        file_path: Path of the updated file
        file_url: URL of the updated file
        sha: New SHA of the updated file
    ### When action = 'delete_file'
        commit_sha: SHA of the commit
        file_path: Path of the deleted file
        message: Success message
    ### When action = 'create_pull_request'
        created_at: Creation timestamp
        draft: Whether the pull request is a draft
        pull_request_details: Pull request details in JSON format
        pull_request_id: ID of the created pull request
        pull_request_number: Number of the created pull request
        pull_request_state: State of the created pull request
        pull_request_title: Title of the created pull request
        pull_request_url: URL of the created pull request
    ### When action = 'create_release'
        created_at: Creation timestamp
        draft: Whether the release is a draft
        prerelease: Whether the release is a prerelease
        published_at: Publication timestamp
        release_details: Release details in JSON format
        release_id: ID of the created release
        release_name: Name of the created release
        release_url: URL of the created release
        tag_name: Tag name of the created release
        tarball_url: Tarball download URL
        zipball_url: Zipball download URL
    ### When action = 'create_webhook'
        created_at: Creation timestamp
        webhook_active: Whether the webhook is active
        webhook_details: Webhook details in JSON format
        webhook_events: List of webhook events
        webhook_id: ID of the created webhook
        webhook_name: Name of the created webhook
        webhook_url: URL of the created webhook
    ### When action = 'read_webhook'
        created_at: Creation timestamp
        ping_url: Ping URL for the webhook
        test_url: Test URL for the webhook
        updated_at: Last update timestamp
        webhook_active: Whether the webhook is active
        webhook_config: Webhook configuration details
        webhook_details: Webhook details in JSON format
        webhook_events: List of webhook events
        webhook_id: ID of the webhook
        webhook_name: Name of the webhook
        webhook_url: URL of the webhook
    ### When action = 'get_webhooks'
        created_dates: List of creation dates
        ping_urls: List of ping URLs
        raw_data: Raw API response data
        test_urls: List of test URLs
        updated_dates: List of update dates
        webhook_active_flags: List of webhook active flags
        webhook_configs: List of webhook configurations
        webhook_details: Webhook details in JSON format
        webhook_events: List of webhook events
        webhook_ids: List of webhook IDs
        webhook_names: List of webhook names
        webhook_urls: List of webhook URLs
    ### When action = 'ping_webhook'
        delivery_id: ID of the delivery
        message: Response message
        webhook_details: Webhook response details
    ### When action = 'read_file'
        download_url: Download URL of the file
        encoding: Encoding of the file
        file_content: Content of the file
        file_details: File details in JSON format
        file_name: Name of the file
        file_path: Path of the file
        file_sha: SHA of the file
        file_size: Size of the file in bytes
        file_type: Type of the file
        file_url: URL of the file
        git_url: Git URL of the file
        html_url: HTML URL of the file
    ### When action = 'merge_pull_request'
        merged: Whether the pull request was merged
        message: Merge result message
        pull_request_details: Updated pull request details
        sha: SHA of the merge commit
    ### When action = 'delete_repository'
        message: Success message
        repository_name: Name of the deleted repository
    ### When action = 'delete_release'
        message: Success message
        release_id: ID of the deleted release
    ### When action = 'delete_webhook'
        message: Success message
        webhook_id: ID of the deleted webhook
    ### When action = 'update_pull_request'
        pull_request_details: Pull request details in JSON format
        pull_request_id: ID of the updated pull request
        pull_request_number: Number of the updated pull request
        pull_request_state: State of the updated pull request
        pull_request_title: Title of the updated pull request
        pull_request_url: URL of the updated pull request
        updated_at: Update timestamp
    ### When action = 'update_release'
        release_details: Release details in JSON format
        release_id: ID of the updated release
        release_name: Name of the updated release
        release_url: URL of the updated release
        tag_name: Tag name of the updated release
        updated_at: Update timestamp
    ### When action = 'update_repository'
        repository_details: Repository details in JSON format
        repository_full_name: Full name of the repository
        repository_id: ID of the repository
        repository_name: Updated name of the repository
        repository_url: URL of the repository
        updated_at: Update timestamp
    ### When action = 'update_webhook'
        updated_at: Update timestamp
        webhook_active: Whether the webhook is active
        webhook_details: Webhook details in JSON format
        webhook_events: List of webhook events
        webhook_id: ID of the updated webhook
        webhook_name: Name of the updated webhook
        webhook_url: URL of the updated webhook
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Github>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_repository**(*)**(*)": {
            "inputs": [
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository to create",
                    "label": "Repository Name",
                    "placeholder": "my-awesome-repo",
                },
                {
                    "field": "repository_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the repository",
                    "label": "Description",
                    "placeholder": "This is an awesome repository",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the repository should be private",
                    "label": "Private Repository",
                },
                {
                    "field": "auto_init",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Initialize repository with a README",
                    "label": "Auto Initialize",
                },
                {
                    "field": "gitignore_template",
                    "type": "string",
                    "value": "",
                    "helper_text": "GitIgnore template to use",
                    "label": "GitIgnore Template",
                    "placeholder": "Node",
                },
                {
                    "field": "license_template",
                    "type": "string",
                    "value": "",
                    "helper_text": "License template to use",
                    "label": "License Template",
                    "placeholder": "mit",
                },
                {
                    "field": "homepage",
                    "type": "string",
                    "value": "",
                    "helper_text": "Homepage URL for the repository",
                    "label": "Homepage",
                    "placeholder": "https://example.com",
                },
            ],
            "outputs": [
                {
                    "field": "repository_id",
                    "type": "string",
                    "helper_text": "ID of the created repository",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Name of the created repository",
                },
                {
                    "field": "repository_full_name",
                    "type": "string",
                    "helper_text": "Full name of the repository (owner/repo)",
                },
                {
                    "field": "repository_url",
                    "type": "string",
                    "helper_text": "URL of the repository",
                },
                {
                    "field": "clone_url",
                    "type": "string",
                    "helper_text": "Clone URL for the repository",
                },
                {
                    "field": "ssh_url",
                    "type": "string",
                    "helper_text": "SSH URL for the repository",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "helper_text": "Whether the repository is private",
                },
                {
                    "field": "repository_details",
                    "type": "vec<string>",
                    "helper_text": "Repository details in JSON format",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "create_repository",
            "task_name": "tasks.github.create_repository",
            "description": "Create a new repository on GitHub",
            "label": "Create Repository",
            "required": ["repository_name"],
        },
        "update_repository**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository to update",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "update_repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the repository",
                    "label": "New Repository Name",
                    "placeholder": "new-repo-name",
                },
                {
                    "field": "update_repository_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the repository",
                    "label": "New Description",
                    "placeholder": "Updated description",
                },
                {
                    "field": "update_homepage",
                    "type": "string",
                    "value": "",
                    "helper_text": "New homepage URL",
                    "label": "New Homepage",
                    "placeholder": "https://newsite.com",
                },
                {
                    "field": "update_is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Update privacy setting",
                    "label": "Private Repository",
                },
                {
                    "field": "update_has_issues",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Enable/disable issues",
                    "label": "Has Issues",
                },
                {
                    "field": "update_has_projects",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Enable/disable projects",
                    "label": "Has Projects",
                },
                {
                    "field": "update_has_wiki",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Enable/disable wiki",
                    "label": "Has Wiki",
                },
            ],
            "outputs": [
                {
                    "field": "repository_id",
                    "type": "string",
                    "helper_text": "ID of the repository",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Updated name of the repository",
                },
                {
                    "field": "repository_full_name",
                    "type": "string",
                    "helper_text": "Full name of the repository",
                },
                {
                    "field": "repository_url",
                    "type": "string",
                    "helper_text": "URL of the repository",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Update timestamp",
                },
                {
                    "field": "repository_details",
                    "type": "vec<string>",
                    "helper_text": "Repository details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_repository",
            "task_name": "tasks.github.update_repository",
            "description": "Update an existing repository on GitHub",
            "label": "Update Repository",
            "required": ["owner", "repository_name"],
        },
        "read_repository**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository to read",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
            ],
            "outputs": [
                {
                    "field": "repository_id",
                    "type": "string",
                    "helper_text": "ID of the repository",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Name of the repository",
                },
                {
                    "field": "repository_full_name",
                    "type": "string",
                    "helper_text": "Full name of the repository",
                },
                {
                    "field": "repository_description",
                    "type": "string",
                    "helper_text": "Description of the repository",
                },
                {
                    "field": "repository_url",
                    "type": "string",
                    "helper_text": "URL of the repository",
                },
                {
                    "field": "clone_url",
                    "type": "string",
                    "helper_text": "Clone URL for the repository",
                },
                {
                    "field": "ssh_url",
                    "type": "string",
                    "helper_text": "SSH URL for the repository",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "pushed_at",
                    "type": "string",
                    "helper_text": "Last push timestamp",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "helper_text": "Whether the repository is private",
                },
                {
                    "field": "is_fork",
                    "type": "bool",
                    "helper_text": "Whether the repository is a fork",
                },
                {
                    "field": "language",
                    "type": "string",
                    "helper_text": "Primary programming language",
                },
                {
                    "field": "stargazers_count",
                    "type": "string",
                    "helper_text": "Number of stars",
                },
                {
                    "field": "watchers_count",
                    "type": "string",
                    "helper_text": "Number of watchers",
                },
                {
                    "field": "forks_count",
                    "type": "string",
                    "helper_text": "Number of forks",
                },
                {
                    "field": "open_issues_count",
                    "type": "string",
                    "helper_text": "Number of open issues",
                },
                {
                    "field": "default_branch",
                    "type": "string",
                    "helper_text": "Default branch name",
                },
                {
                    "field": "owner_details",
                    "type": "string",
                    "helper_text": "Repository owner details",
                },
                {
                    "field": "repository_details",
                    "type": "vec<string>",
                    "helper_text": "Repository details in JSON format",
                },
            ],
            "name": "read_repository",
            "task_name": "tasks.github.read_repository",
            "description": "Read details of a specific repository",
            "label": "Get Repository",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name"],
        },
        "get_repositories**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner username (optional - defaults to authenticated user)",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all repositories, ignoring the number limit",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Repository type filter",
                    "label": "Type",
                    "placeholder": "all",
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort repositories by",
                    "label": "Sort",
                    "placeholder": "created",
                },
                {
                    "field": "direction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort direction",
                    "label": "Direction",
                    "placeholder": "desc",
                },
                {
                    "field": "visibility",
                    "type": "string",
                    "value": "",
                    "helper_text": "Visibility filter",
                    "label": "Visibility",
                    "placeholder": "all",
                },
                {
                    "field": "affiliation",
                    "type": "string",
                    "value": "",
                    "helper_text": "Affiliation filter",
                    "label": "Affiliation",
                    "placeholder": "owner",
                },
            ],
            "outputs": [
                {
                    "field": "repository_ids",
                    "type": "vec<string>",
                    "helper_text": "List of repository IDs",
                },
                {
                    "field": "repository_names",
                    "type": "vec<string>",
                    "helper_text": "List of repository names",
                },
                {
                    "field": "repository_full_names",
                    "type": "vec<string>",
                    "helper_text": "List of full repository names",
                },
                {
                    "field": "repository_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of repository descriptions",
                },
                {
                    "field": "repository_urls",
                    "type": "vec<string>",
                    "helper_text": "List of repository URLs",
                },
                {
                    "field": "clone_urls",
                    "type": "vec<string>",
                    "helper_text": "List of clone URLs",
                },
                {
                    "field": "ssh_urls",
                    "type": "vec<string>",
                    "helper_text": "List of SSH URLs",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "pushed_dates",
                    "type": "vec<string>",
                    "helper_text": "List of last push dates",
                },
                {
                    "field": "is_private_flags",
                    "type": "vec<string>",
                    "helper_text": "List of privacy flags",
                },
                {
                    "field": "languages",
                    "type": "vec<string>",
                    "helper_text": "List of primary languages",
                },
                {
                    "field": "stargazers_counts",
                    "type": "vec<string>",
                    "helper_text": "List of star counts",
                },
                {
                    "field": "watchers_counts",
                    "type": "vec<string>",
                    "helper_text": "List of watcher counts",
                },
                {
                    "field": "forks_counts",
                    "type": "vec<string>",
                    "helper_text": "List of fork counts",
                },
                {
                    "field": "open_issues_counts",
                    "type": "vec<string>",
                    "helper_text": "List of open issue counts",
                },
                {
                    "field": "default_branches",
                    "type": "vec<string>",
                    "helper_text": "List of default branch names",
                },
                {
                    "field": "owner_details",
                    "type": "vec<string>",
                    "helper_text": "List of owner details",
                },
                {
                    "field": "repository_details",
                    "type": "vec<string>",
                    "helper_text": "Repository details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_repositories",
            "task_name": "tasks.github.get_repositories",
            "description": "Get multiple repositories",
            "label": "List Repositories",
            "required": ["num_messages"],
        },
        "get_repositories**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Repositories",
                    "helper_text": "Specify the number of repositories to fetch",
                }
            ],
            "outputs": [],
        },
        "get_repositories**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_repositories**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_repositories**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_repository**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository to delete",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Name of the deleted repository",
                },
            ],
            "name": "delete_repository",
            "task_name": "tasks.github.delete_repository",
            "description": "Delete a GitHub repository",
            "label": "Delete Repository",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name"],
        },
        "create_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the issue",
                    "label": "Issue Title",
                    "placeholder": "Bug: Something is broken",
                },
                {
                    "field": "issue_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Body content of the issue",
                    "label": "Issue Body",
                    "placeholder": "Detailed description of the issue",
                },
                {
                    "field": "assignees",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of assignee usernames",
                    "label": "Assignees",
                    "placeholder": "user1,user2",
                },
                {
                    "field": "milestone",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Milestone number",
                    "label": "Milestone",
                    "placeholder": "1",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of labels",
                    "label": "Labels",
                    "placeholder": "bug,critical",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the created issue",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Number of the created issue",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the created issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the created issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the created issue",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "milestone",
                    "type": "string",
                    "helper_text": "Milestone details",
                },
                {
                    "field": "issue_details",
                    "type": "vec<string>",
                    "helper_text": "Issue details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_issue",
            "task_name": "tasks.github.create_issue",
            "description": "Create a new issue on GitHub",
            "label": "Create Issue",
            "required": ["owner", "repository_name", "issue_title"],
        },
        "update_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "issue_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the issue to update",
                    "label": "Issue Number",
                    "placeholder": "123",
                },
                {
                    "field": "update_issue_title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the issue",
                    "label": "New Issue Title",
                    "placeholder": "Updated title",
                },
                {
                    "field": "update_issue_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "New body for the issue",
                    "label": "New Issue Body",
                    "placeholder": "Updated description",
                },
                {
                    "field": "update_issue_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "New state for the issue",
                    "label": "New State",
                    "placeholder": "closed",
                },
                {
                    "field": "update_assignees",
                    "type": "string",
                    "value": "",
                    "helper_text": "New assignees for the issue",
                    "label": "New Assignees",
                    "placeholder": "user1,user2",
                },
                {
                    "field": "update_milestone",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "New milestone for the issue",
                    "label": "New Milestone",
                    "placeholder": "2",
                },
                {
                    "field": "update_labels",
                    "type": "string",
                    "value": "",
                    "helper_text": "New labels for the issue",
                    "label": "New Labels",
                    "placeholder": "bug,fixed",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the updated issue",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Number of the updated issue",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the updated issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the updated issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the updated issue",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Update timestamp",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "milestone",
                    "type": "string",
                    "helper_text": "Milestone details",
                },
                {
                    "field": "issue_details",
                    "type": "vec<string>",
                    "helper_text": "Issue details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_issue",
            "task_name": "tasks.github.update_issue",
            "description": "Update an existing issue on GitHub",
            "label": "Update Issue",
            "required": ["owner", "repository_name", "issue_number"],
        },
        "read_issue**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "issue_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the issue to read",
                    "label": "Issue Number",
                    "placeholder": "123",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the issue",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Number of the issue",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "issue_body",
                    "type": "string",
                    "helper_text": "Body of the issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the issue",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "closed_at",
                    "type": "string",
                    "helper_text": "Closure timestamp",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "milestone",
                    "type": "string",
                    "helper_text": "Milestone details",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Issue author details",
                },
                {
                    "field": "comments_count",
                    "type": "string",
                    "helper_text": "Number of comments",
                },
                {
                    "field": "issue_details",
                    "type": "vec<string>",
                    "helper_text": "Issue details in JSON format",
                },
            ],
            "name": "read_issue",
            "task_name": "tasks.github.read_issue",
            "description": "Read details of a specific issue",
            "label": "Get Issue",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "issue_number"],
        },
        "get_issues**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all issues, ignoring the number limit",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Issue state filter",
                    "label": "State",
                    "placeholder": "open",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "helper_text": "Labels filter",
                    "label": "Labels",
                    "placeholder": "bug,enhancement",
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort issues by",
                    "label": "Sort",
                    "placeholder": "created",
                },
                {
                    "field": "direction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort direction",
                    "label": "Direction",
                    "placeholder": "desc",
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "helper_text": "Assignee filter",
                    "label": "Assignee",
                    "placeholder": "username",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "value": "",
                    "helper_text": "Creator filter",
                    "label": "Creator",
                    "placeholder": "username",
                },
                {
                    "field": "mentioned",
                    "type": "string",
                    "value": "",
                    "helper_text": "Mentioned user filter",
                    "label": "Mentioned",
                    "placeholder": "username",
                },
                {
                    "field": "milestone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Milestone filter",
                    "label": "Milestone",
                    "placeholder": "v1.0",
                },
            ],
            "outputs": [
                {
                    "field": "issue_ids",
                    "type": "vec<string>",
                    "helper_text": "List of issue IDs",
                },
                {
                    "field": "issue_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of issue numbers",
                },
                {
                    "field": "issue_titles",
                    "type": "vec<string>",
                    "helper_text": "List of issue titles",
                },
                {
                    "field": "issue_bodies",
                    "type": "vec<string>",
                    "helper_text": "List of issue bodies",
                },
                {
                    "field": "issue_urls",
                    "type": "vec<string>",
                    "helper_text": "List of issue URLs",
                },
                {
                    "field": "issue_states",
                    "type": "vec<string>",
                    "helper_text": "List of issue states",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "closed_dates",
                    "type": "vec<string>",
                    "helper_text": "List of closure dates",
                },
                {
                    "field": "assignees_details",
                    "type": "vec<string>",
                    "helper_text": "List of assignee details",
                },
                {
                    "field": "labels_details",
                    "type": "vec<string>",
                    "helper_text": "List of label details",
                },
                {
                    "field": "milestone_details",
                    "type": "vec<string>",
                    "helper_text": "List of milestone details",
                },
                {
                    "field": "author_details",
                    "type": "vec<string>",
                    "helper_text": "List of author details",
                },
                {
                    "field": "comments_counts",
                    "type": "vec<string>",
                    "helper_text": "List of comment counts",
                },
                {
                    "field": "issue_details",
                    "type": "vec<string>",
                    "helper_text": "Issue details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_issues",
            "task_name": "tasks.github.get_issues",
            "description": "Get multiple issues",
            "label": "List Issues",
            "required": ["owner", "repository_name", "num_messages"],
        },
        "get_issues**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Issues",
                    "helper_text": "Specify the number of issues to fetch",
                }
            ],
            "outputs": [],
        },
        "get_issues**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_issues**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_issues**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_pull_request**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "pull_request_title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the pull request",
                    "label": "Pull Request Title",
                    "placeholder": "Add new feature",
                },
                {
                    "field": "head",
                    "type": "string",
                    "value": "",
                    "helper_text": "Head branch (source)",
                    "label": "Head Branch",
                    "placeholder": "feature-branch",
                },
                {
                    "field": "base",
                    "type": "string",
                    "value": "",
                    "helper_text": "Base branch (target)",
                    "label": "Base Branch",
                    "placeholder": "main",
                },
                {
                    "field": "pull_request_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Body content of the pull request",
                    "label": "Pull Request Body",
                    "placeholder": "This PR adds a new feature",
                },
                {
                    "field": "draft",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Create as draft pull request",
                    "label": "Draft",
                },
                {
                    "field": "maintainer_can_modify",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Allow maintainer modifications",
                    "label": "Maintainer Can Modify",
                },
            ],
            "outputs": [
                {
                    "field": "pull_request_id",
                    "type": "string",
                    "helper_text": "ID of the created pull request",
                },
                {
                    "field": "pull_request_number",
                    "type": "string",
                    "helper_text": "Number of the created pull request",
                },
                {
                    "field": "pull_request_title",
                    "type": "string",
                    "helper_text": "Title of the created pull request",
                },
                {
                    "field": "pull_request_url",
                    "type": "string",
                    "helper_text": "URL of the created pull request",
                },
                {
                    "field": "pull_request_state",
                    "type": "string",
                    "helper_text": "State of the created pull request",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "draft",
                    "type": "bool",
                    "helper_text": "Whether the pull request is a draft",
                },
                {
                    "field": "pull_request_details",
                    "type": "vec<string>",
                    "helper_text": "Pull request details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_pull_request",
            "task_name": "tasks.github.create_pull_request",
            "description": "Create a new pull request on GitHub",
            "label": "Create Pull Request",
            "required": [
                "owner",
                "repository_name",
                "pull_request_title",
                "head",
                "base",
            ],
        },
        "update_pull_request**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "pull_request_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the pull request to update",
                    "label": "Pull Request Number",
                    "placeholder": "123",
                },
                {
                    "field": "update_pull_request_title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the pull request",
                    "label": "New Title",
                    "placeholder": "Updated title",
                },
                {
                    "field": "update_pull_request_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "New body for the pull request",
                    "label": "New Body",
                    "placeholder": "Updated description",
                },
                {
                    "field": "update_pull_request_state",
                    "type": "string",
                    "value": "",
                    "helper_text": "New state for the pull request",
                    "label": "New State",
                    "placeholder": "closed",
                },
                {
                    "field": "update_base",
                    "type": "string",
                    "value": "",
                    "helper_text": "New base branch",
                    "label": "New Base Branch",
                    "placeholder": "develop",
                },
                {
                    "field": "update_maintainer_can_modify",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Update maintainer modification permission",
                    "label": "Maintainer Can Modify",
                },
            ],
            "outputs": [
                {
                    "field": "pull_request_id",
                    "type": "string",
                    "helper_text": "ID of the updated pull request",
                },
                {
                    "field": "pull_request_number",
                    "type": "string",
                    "helper_text": "Number of the updated pull request",
                },
                {
                    "field": "pull_request_title",
                    "type": "string",
                    "helper_text": "Title of the updated pull request",
                },
                {
                    "field": "pull_request_url",
                    "type": "string",
                    "helper_text": "URL of the updated pull request",
                },
                {
                    "field": "pull_request_state",
                    "type": "string",
                    "helper_text": "State of the updated pull request",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Update timestamp",
                },
                {
                    "field": "pull_request_details",
                    "type": "vec<string>",
                    "helper_text": "Pull request details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_pull_request",
            "task_name": "tasks.github.update_pull_request",
            "description": "Update an existing pull request on GitHub",
            "label": "Update Pull Request",
            "required": ["owner", "repository_name", "pull_request_number"],
        },
        "read_pull_request**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "pull_request_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the pull request to read",
                    "label": "Pull Request Number",
                    "placeholder": "123",
                },
            ],
            "outputs": [
                {
                    "field": "pull_request_id",
                    "type": "string",
                    "helper_text": "ID of the pull request",
                },
                {
                    "field": "pull_request_number",
                    "type": "string",
                    "helper_text": "Number of the pull request",
                },
                {
                    "field": "pull_request_title",
                    "type": "string",
                    "helper_text": "Title of the pull request",
                },
                {
                    "field": "pull_request_body",
                    "type": "string",
                    "helper_text": "Body of the pull request",
                },
                {
                    "field": "pull_request_url",
                    "type": "string",
                    "helper_text": "URL of the pull request",
                },
                {
                    "field": "pull_request_state",
                    "type": "string",
                    "helper_text": "State of the pull request",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "closed_at",
                    "type": "string",
                    "helper_text": "Closure timestamp",
                },
                {
                    "field": "merged_at",
                    "type": "string",
                    "helper_text": "Merge timestamp",
                },
                {
                    "field": "head_details",
                    "type": "string",
                    "helper_text": "Head branch name",
                },
                {
                    "field": "base_details",
                    "type": "string",
                    "helper_text": "Base branch name",
                },
                {
                    "field": "draft",
                    "type": "bool",
                    "helper_text": "Whether the pull request is a draft",
                },
                {
                    "field": "merged",
                    "type": "bool",
                    "helper_text": "Whether the pull request is merged",
                },
                {
                    "field": "mergeable",
                    "type": "bool",
                    "helper_text": "Whether the pull request is mergeable",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "PR author details",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees",
                },
                {
                    "field": "requested_reviewers",
                    "type": "vec<string>",
                    "helper_text": "List of requested reviewers",
                },
                {
                    "field": "reviewer_names",
                    "type": "vec<string>",
                    "helper_text": "List of requested reviewer login names",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "milestone",
                    "type": "string",
                    "helper_text": "Milestone details",
                },
                {
                    "field": "commits_count",
                    "type": "string",
                    "helper_text": "Number of commits",
                },
                {
                    "field": "additions_count",
                    "type": "string",
                    "helper_text": "Number of additions",
                },
                {
                    "field": "deletions_count",
                    "type": "string",
                    "helper_text": "Number of deletions",
                },
                {
                    "field": "changed_files_count",
                    "type": "string",
                    "helper_text": "Number of changed files",
                },
                {
                    "field": "pull_request_details",
                    "type": "vec<string>",
                    "helper_text": "Pull request details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_pull_request",
            "task_name": "tasks.github.read_pull_request",
            "description": "Read details of a specific pull request",
            "label": "Get Pull Request",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "pull_request_number"],
        },
        "get_pull_requests**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all pull requests, ignoring the number limit",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "all",
                    "helper_text": "Filter by state",
                    "label": "State",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "all"},
                            {"label": "Open", "value": "open"},
                            {"label": "Closed", "value": "closed"},
                        ],
                    },
                },
                {
                    "field": "head",
                    "type": "string",
                    "value": "",
                    "helper_text": "Head branch filter",
                    "label": "Head Branch",
                    "placeholder": "feature-branch",
                },
                {
                    "field": "base",
                    "type": "string",
                    "value": "",
                    "helper_text": "Base branch filter",
                    "label": "Base Branch",
                    "placeholder": "main",
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "created",
                    "helper_text": "Sort pull requests by",
                    "label": "Sort",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Created", "value": "created"},
                            {"label": "Updated", "value": "updated"},
                            {"label": "Popularity", "value": "popularity"},
                        ],
                    },
                },
                {
                    "field": "direction",
                    "type": "string",
                    "value": "desc",
                    "helper_text": "Sort direction",
                    "label": "Direction",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Descending", "value": "desc"},
                            {"label": "Ascending", "value": "asc"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "pull_request_ids",
                    "type": "vec<string>",
                    "helper_text": "List of pull request IDs",
                },
                {
                    "field": "pull_request_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of pull request numbers",
                },
                {
                    "field": "pull_request_titles",
                    "type": "vec<string>",
                    "helper_text": "List of pull request titles",
                },
                {
                    "field": "pull_request_bodies",
                    "type": "vec<string>",
                    "helper_text": "List of pull request bodies",
                },
                {
                    "field": "pull_request_urls",
                    "type": "vec<string>",
                    "helper_text": "List of pull request URLs",
                },
                {
                    "field": "pull_request_states",
                    "type": "vec<string>",
                    "helper_text": "List of pull request states",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "closed_dates",
                    "type": "vec<string>",
                    "helper_text": "List of closure dates",
                },
                {
                    "field": "merged_dates",
                    "type": "vec<string>",
                    "helper_text": "List of merge dates",
                },
                {
                    "field": "draft_flags",
                    "type": "vec<string>",
                    "helper_text": "List of draft flags",
                },
                {
                    "field": "merged_flags",
                    "type": "vec<string>",
                    "helper_text": "List of merged flags",
                },
                {
                    "field": "mergeable_flags",
                    "type": "vec<string>",
                    "helper_text": "List of mergeable flags",
                },
                {
                    "field": "author_details",
                    "type": "vec<string>",
                    "helper_text": "List of PR author details",
                },
                {
                    "field": "assignees_details",
                    "type": "vec<string>",
                    "helper_text": "List of assignee details",
                },
                {
                    "field": "requested_reviewers_details",
                    "type": "vec<string>",
                    "helper_text": "List of requested reviewer details",
                },
                {
                    "field": "reviewer_names",
                    "type": "vec<string>",
                    "helper_text": "List of requested reviewer login names",
                },
                {
                    "field": "labels_details",
                    "type": "vec<string>",
                    "helper_text": "List of label details",
                },
                {
                    "field": "milestone_details",
                    "type": "vec<string>",
                    "helper_text": "List of milestone details",
                },
                {
                    "field": "head_details",
                    "type": "vec<string>",
                    "helper_text": "List of head branch names",
                },
                {
                    "field": "base_details",
                    "type": "vec<string>",
                    "helper_text": "List of base branch names",
                },
                {
                    "field": "commits_counts",
                    "type": "vec<string>",
                    "helper_text": "List of commit counts",
                },
                {
                    "field": "additions_count",
                    "type": "vec<string>",
                    "helper_text": "List of addition counts",
                },
                {
                    "field": "deletions_count",
                    "type": "vec<string>",
                    "helper_text": "List of deletion counts",
                },
                {
                    "field": "changed_files_count",
                    "type": "vec<string>",
                    "helper_text": "List of changed file counts",
                },
                {
                    "field": "pull_request_details",
                    "type": "vec<string>",
                    "helper_text": "Pull request details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_pull_requests",
            "task_name": "tasks.github.get_pull_requests",
            "description": "Get multiple pull requests",
            "label": "List Pull Requests",
            "required": ["owner", "repository_name", "num_messages"],
        },
        "get_pull_requests**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Pull Requests",
                    "helper_text": "Specify the number of pull requests to fetch",
                }
            ],
            "outputs": [],
        },
        "get_pull_requests**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_pull_requests**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_pull_requests**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "search_pull_requests**(*)**(*)": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query for pull requests",
                    "label": "Query",
                    "placeholder": "fix bug",
                },
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository (optional, narrows search scope)",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Repository name (optional, narrows search scope)",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by state",
                    "label": "State",
                    "section": "additional_fields_dropdown",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Open", "value": "open"},
                            {"label": "Closed", "value": "closed"},
                            {"label": "Merged", "value": "merged"},
                            {"label": "Draft", "value": "draft"},
                        ],
                    },
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort results by",
                    "label": "Sort",
                    "section": "additional_fields_dropdown",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Updated", "value": "updated"},
                            {"label": "Created", "value": "created"},
                            {"label": "Comments", "value": "comments"},
                            {"label": "Reactions", "value": "reactions"},
                            {"label": "Interactions", "value": "interactions"},
                        ],
                    },
                },
                {
                    "field": "direction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort direction",
                    "label": "Direction",
                    "section": "additional_fields_dropdown",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Descending", "value": "desc"},
                            {"label": "Ascending", "value": "asc"},
                        ],
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of pull requests to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all matching pull requests, ignoring the limit",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "pull_request_ids",
                    "type": "vec<string>",
                    "helper_text": "List of pull request IDs",
                },
                {
                    "field": "pull_request_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of pull request numbers",
                },
                {
                    "field": "pull_request_titles",
                    "type": "vec<string>",
                    "helper_text": "List of pull request titles",
                },
                {
                    "field": "pull_request_bodies",
                    "type": "vec<string>",
                    "helper_text": "List of pull request bodies",
                },
                {
                    "field": "pull_request_urls",
                    "type": "vec<string>",
                    "helper_text": "List of pull request URLs",
                },
                {
                    "field": "pull_request_states",
                    "type": "vec<string>",
                    "helper_text": "List of pull request states",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "closed_dates",
                    "type": "vec<string>",
                    "helper_text": "List of closure dates",
                },
                {
                    "field": "merged_dates",
                    "type": "vec<string>",
                    "helper_text": "List of merge dates",
                },
                {
                    "field": "draft_flags",
                    "type": "vec<string>",
                    "helper_text": "List of draft flags",
                },
                {
                    "field": "author_details",
                    "type": "vec<string>",
                    "helper_text": "List of author details",
                },
                {
                    "field": "labels_details",
                    "type": "vec<string>",
                    "helper_text": "List of label details",
                },
                {
                    "field": "requested_reviewers_details",
                    "type": "vec<string>",
                    "helper_text": "List of requested reviewer details",
                },
                {
                    "field": "reviewer_names",
                    "type": "vec<string>",
                    "helper_text": "List of requested reviewer login names",
                },
                {
                    "field": "pull_request_details",
                    "type": "vec<string>",
                    "helper_text": "Pull request details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "search_pull_requests",
            "task_name": "tasks.github.search_pull_requests",
            "description": "Search pull requests using GitHub's search API",
            "label": "Search Pull Requests",
            "variant": "common_integration_nodes",
            "required": ["query", "limit", "return_all"],
        },
        "merge_pull_request**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "pull_request_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the pull request to merge",
                    "label": "Pull Request Number",
                    "placeholder": "123",
                },
                {
                    "field": "commit_title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title for the merge commit",
                    "label": "Commit Title",
                    "placeholder": "Merge pull request",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "Message for the merge commit",
                    "label": "Commit Message",
                    "placeholder": "Merged feature branch",
                },
                {
                    "field": "sha",
                    "type": "string",
                    "value": "",
                    "helper_text": "SHA that pull request head must match",
                    "label": "SHA",
                    "placeholder": "abc123",
                },
                {
                    "field": "merge_method",
                    "type": "string",
                    "value": "",
                    "helper_text": "Merge method to use",
                    "label": "Merge Method",
                    "placeholder": "merge",
                },
            ],
            "outputs": [
                {
                    "field": "merged",
                    "type": "bool",
                    "helper_text": "Whether the pull request was merged",
                },
                {
                    "field": "sha",
                    "type": "string",
                    "helper_text": "SHA of the merge commit",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Merge result message",
                },
                {
                    "field": "pull_request_details",
                    "type": "vec<string>",
                    "helper_text": "Updated pull request details",
                },
            ],
            "name": "merge_pull_request",
            "task_name": "tasks.github.merge_pull_request",
            "description": "Merge a GitHub pull request",
            "label": "Merge Pull Request",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "pull_request_number"],
        },
        "create_issue_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "issue_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the issue to comment on",
                    "label": "Issue Number",
                    "placeholder": "123",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Body content of the comment",
                    "label": "Comment Body",
                    "placeholder": "This is a comment on the issue",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the created comment",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Body of the created comment",
                },
                {
                    "field": "comment_url",
                    "type": "string",
                    "helper_text": "URL of the created comment",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "author_details",
                    "type": "string",
                    "helper_text": "Comment author details",
                },
                {
                    "field": "comment_details",
                    "type": "vec<string>",
                    "helper_text": "Comment details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_issue_comment",
            "task_name": "tasks.github.create_issue_comment",
            "description": "Create a new comment on a GitHub issue",
            "label": "Create Issue Comment",
            "required": ["owner", "repository_name", "issue_number", "comment_body"],
        },
        "update_issue_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "comment_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the comment to update",
                    "label": "Comment ID",
                    "placeholder": "123456",
                },
                {
                    "field": "update_comment_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "New body for the comment",
                    "label": "New Comment Body",
                    "placeholder": "Updated comment content",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the updated comment",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Body of the updated comment",
                },
                {
                    "field": "comment_url",
                    "type": "string",
                    "helper_text": "URL of the updated comment",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Update timestamp",
                },
                {
                    "field": "author_details",
                    "type": "string",
                    "helper_text": "Comment author details",
                },
                {
                    "field": "comment_details",
                    "type": "vec<string>",
                    "helper_text": "Comment details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_issue_comment",
            "task_name": "tasks.github.update_issue_comment",
            "description": "Update an existing comment on a GitHub issue",
            "label": "Update Issue Comment",
            "required": [
                "owner",
                "repository_name",
                "comment_id",
                "update_comment_body",
            ],
        },
        "read_issue_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "comment_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the comment to read",
                    "label": "Comment ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the comment",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Body of the comment",
                },
                {
                    "field": "comment_url",
                    "type": "string",
                    "helper_text": "URL of the comment",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "author_details",
                    "type": "string",
                    "helper_text": "Comment author details",
                },
                {
                    "field": "comment_details",
                    "type": "vec<string>",
                    "helper_text": "Comment details in JSON format",
                },
            ],
            "name": "read_issue_comment",
            "task_name": "tasks.github.read_issue_comment",
            "description": "Read details of a specific issue comment",
            "label": "Get Issue Comment",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "comment_id"],
        },
        "get_issue_comments**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "issue_number",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Number of the issue to get comments from",
                    "label": "Issue Number",
                    "placeholder": "123",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all comments, ignoring the number limit",
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort comments by",
                    "label": "Sort",
                    "placeholder": "created",
                },
                {
                    "field": "direction",
                    "type": "string",
                    "value": "",
                    "helper_text": "Sort direction",
                    "label": "Direction",
                    "placeholder": "asc",
                },
            ],
            "outputs": [
                {
                    "field": "comment_ids",
                    "type": "vec<string>",
                    "helper_text": "List of comment IDs",
                },
                {
                    "field": "comment_bodies",
                    "type": "vec<string>",
                    "helper_text": "List of comment bodies",
                },
                {
                    "field": "comment_urls",
                    "type": "vec<string>",
                    "helper_text": "List of comment URLs",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "author_details",
                    "type": "vec<string>",
                    "helper_text": "List of comment author details",
                },
                {
                    "field": "comment_details",
                    "type": "vec<string>",
                    "helper_text": "Comment details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_issue_comments",
            "task_name": "tasks.github.get_issue_comments",
            "description": "Get multiple issue comments",
            "label": "List Issue Comments",
            "required": ["owner", "repository_name", "issue_number", "num_messages"],
        },
        "get_issue_comments**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Comments",
                    "helper_text": "Specify the number of comments to fetch",
                }
            ],
            "outputs": [],
        },
        "get_issue_comments**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_issue_comments**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_issue_comments**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_issue_comment**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "comment_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the comment to delete",
                    "label": "Comment ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the deleted comment",
                },
            ],
            "name": "delete_issue_comment",
            "task_name": "tasks.github.delete_issue_comment",
            "description": "Delete a GitHub issue comment",
            "label": "Delete Issue Comment",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "comment_id"],
        },
        "create_release**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the tag for the release",
                    "label": "Tag Name",
                    "placeholder": "v1.0.0",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the release",
                    "label": "Release Name",
                    "placeholder": "Version 1.0.0",
                },
                {
                    "field": "release_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the release",
                    "label": "Release Body",
                    "placeholder": "Release notes and changelog",
                },
                {
                    "field": "target_commitish",
                    "type": "string",
                    "value": "",
                    "helper_text": "Commitish value for the release",
                    "label": "Target Commitish",
                    "placeholder": "main",
                },
                {
                    "field": "draft",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Create as draft release",
                    "label": "Draft",
                },
                {
                    "field": "prerelease",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Mark as prerelease",
                    "label": "Prerelease",
                },
                {
                    "field": "generate_release_notes",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Auto-generate release notes",
                    "label": "Generate Release Notes",
                },
            ],
            "outputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "helper_text": "ID of the created release",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "Name of the created release",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the created release",
                },
                {
                    "field": "release_url",
                    "type": "string",
                    "helper_text": "URL of the created release",
                },
                {
                    "field": "tarball_url",
                    "type": "string",
                    "helper_text": "Tarball download URL",
                },
                {
                    "field": "zipball_url",
                    "type": "string",
                    "helper_text": "Zipball download URL",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "published_at",
                    "type": "string",
                    "helper_text": "Publication timestamp",
                },
                {
                    "field": "draft",
                    "type": "bool",
                    "helper_text": "Whether the release is a draft",
                },
                {
                    "field": "prerelease",
                    "type": "bool",
                    "helper_text": "Whether the release is a prerelease",
                },
                {
                    "field": "release_details",
                    "type": "vec<string>",
                    "helper_text": "Release details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_release",
            "task_name": "tasks.github.create_release",
            "description": "Create a new release on GitHub",
            "label": "Create Release",
            "required": ["owner", "repository_name", "tag_name"],
        },
        "update_release**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "release_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the release to update",
                    "label": "Release ID",
                    "placeholder": "123456",
                },
                {
                    "field": "update_tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New tag name for the release",
                    "label": "New Tag Name",
                    "placeholder": "v1.0.1",
                },
                {
                    "field": "update_release_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the release",
                    "label": "New Release Name",
                    "placeholder": "Version 1.0.1",
                },
                {
                    "field": "update_release_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the release",
                    "label": "New Release Body",
                    "placeholder": "Updated release notes",
                },
                {
                    "field": "update_target_commitish",
                    "type": "string",
                    "value": "",
                    "helper_text": "New commitish value for the release",
                    "label": "New Target Commitish",
                    "placeholder": "main",
                },
                {
                    "field": "update_draft",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Update draft status",
                    "label": "Draft",
                },
                {
                    "field": "update_prerelease",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Update prerelease status",
                    "label": "Prerelease",
                },
            ],
            "outputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "helper_text": "ID of the updated release",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "Name of the updated release",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the updated release",
                },
                {
                    "field": "release_url",
                    "type": "string",
                    "helper_text": "URL of the updated release",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Update timestamp",
                },
                {
                    "field": "release_details",
                    "type": "vec<string>",
                    "helper_text": "Release details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_release",
            "task_name": "tasks.github.update_release",
            "description": "Update an existing release on GitHub",
            "label": "Update Release",
            "required": ["owner", "repository_name", "release_id"],
        },
        "read_release**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "release_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the release to read",
                    "label": "Release ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "release_id",
                    "type": "string",
                    "helper_text": "ID of the release",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "Name of the release",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the release",
                },
                {
                    "field": "release_body",
                    "type": "string",
                    "helper_text": "Body of the release",
                },
                {
                    "field": "release_url",
                    "type": "string",
                    "helper_text": "URL of the release",
                },
                {
                    "field": "tarball_url",
                    "type": "string",
                    "helper_text": "Tarball download URL",
                },
                {
                    "field": "zipball_url",
                    "type": "string",
                    "helper_text": "Zipball download URL",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "published_at",
                    "type": "string",
                    "helper_text": "Publication timestamp",
                },
                {
                    "field": "draft",
                    "type": "bool",
                    "helper_text": "Whether the release is a draft",
                },
                {
                    "field": "prerelease",
                    "type": "bool",
                    "helper_text": "Whether the release is a prerelease",
                },
                {
                    "field": "author_details",
                    "type": "string",
                    "helper_text": "Release author details",
                },
                {
                    "field": "assets_details",
                    "type": "vec<string>",
                    "helper_text": "Release assets details",
                },
                {
                    "field": "release_details",
                    "type": "vec<string>",
                    "helper_text": "Release details in JSON format",
                },
            ],
            "name": "read_release",
            "task_name": "tasks.github.read_release",
            "description": "Read details of a specific release",
            "label": "Get Release",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "release_id"],
        },
        "get_releases**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all releases, ignoring the number limit",
                },
            ],
            "outputs": [
                {
                    "field": "release_ids",
                    "type": "vec<string>",
                    "helper_text": "List of release IDs",
                },
                {
                    "field": "release_names",
                    "type": "vec<string>",
                    "helper_text": "List of release names",
                },
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "release_bodies",
                    "type": "vec<string>",
                    "helper_text": "List of release bodies",
                },
                {
                    "field": "release_urls",
                    "type": "vec<string>",
                    "helper_text": "List of release URLs",
                },
                {
                    "field": "tarball_urls",
                    "type": "vec<string>",
                    "helper_text": "List of tarball URLs",
                },
                {
                    "field": "zipball_urls",
                    "type": "vec<string>",
                    "helper_text": "List of zipball URLs",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "published_dates",
                    "type": "vec<string>",
                    "helper_text": "List of publication dates",
                },
                {
                    "field": "draft_flags",
                    "type": "vec<string>",
                    "helper_text": "List of draft flags",
                },
                {
                    "field": "prerelease_flags",
                    "type": "vec<string>",
                    "helper_text": "List of prerelease flags",
                },
                {
                    "field": "author_details",
                    "type": "vec<string>",
                    "helper_text": "List of author details",
                },
                {
                    "field": "assets_details",
                    "type": "vec<string>",
                    "helper_text": "List of assets details",
                },
                {
                    "field": "release_details",
                    "type": "vec<string>",
                    "helper_text": "Release details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_releases",
            "task_name": "tasks.github.get_releases",
            "description": "Get multiple releases",
            "label": "List Releases",
            "required": ["owner", "repository_name", "num_messages"],
        },
        "get_releases**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Releases",
                    "helper_text": "Specify the number of releases to fetch",
                }
            ],
            "outputs": [],
        },
        "get_releases**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_releases**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_releases**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_release**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "release_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the release to delete",
                    "label": "Release ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "release_id",
                    "type": "string",
                    "helper_text": "ID of the deleted release",
                },
            ],
            "name": "delete_release",
            "task_name": "tasks.github.delete_release",
            "description": "Delete a GitHub release",
            "label": "Delete Release",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "release_id"],
        },
        "create_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path where the file will be created",
                    "label": "File Path",
                    "placeholder": "src/main.js",
                },
                {
                    "field": "file_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the file",
                    "label": "File Content",
                    "placeholder": "console.log('Hello World');",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "Commit message for the file creation",
                    "label": "Commit Message",
                    "placeholder": "Add new file",
                },
                {
                    "field": "branch_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Branch to create the file on",
                    "label": "Branch Name",
                    "placeholder": "main",
                },
                {
                    "field": "committer_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the committer",
                    "label": "Committer Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "committer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the committer",
                    "label": "Committer Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the author",
                    "label": "Author Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "author_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the author",
                    "label": "Author Email",
                    "placeholder": "john@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the created file",
                },
                {
                    "field": "sha",
                    "type": "string",
                    "helper_text": "SHA of the created file",
                },
                {
                    "field": "commit_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the created file",
                },
                {
                    "field": "download_url",
                    "type": "string",
                    "helper_text": "Download URL of the file",
                },
                {
                    "field": "file_details",
                    "type": "vec<string>",
                    "helper_text": "File details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_file",
            "task_name": "tasks.github.create_file",
            "description": "Create a new file in a GitHub repository",
            "label": "Create File",
            "required": [
                "owner",
                "repository_name",
                "file_path",
                "file_content",
                "commit_message",
            ],
        },
        "update_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the file to update",
                    "label": "File Path",
                    "placeholder": "src/main.js",
                },
                {
                    "field": "update_file_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "New content of the file",
                    "label": "New File Content",
                    "placeholder": "console.log('Updated Hello World');",
                },
                {
                    "field": "update_commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "Commit message for the file update",
                    "label": "Commit Message",
                    "placeholder": "Update file",
                },
                {
                    "field": "update_branch_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Branch to update the file on",
                    "label": "Branch Name",
                    "placeholder": "main",
                },
                {
                    "field": "file_sha",
                    "type": "string",
                    "value": "",
                    "helper_text": "Current SHA of the file",
                    "label": "File SHA",
                    "placeholder": "abc123",
                },
                {
                    "field": "update_committer_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the committer",
                    "label": "Committer Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "update_committer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the committer",
                    "label": "Committer Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "update_author_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the author",
                    "label": "Author Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "update_author_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the author",
                    "label": "Author Email",
                    "placeholder": "john@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the updated file",
                },
                {
                    "field": "sha",
                    "type": "string",
                    "helper_text": "New SHA of the updated file",
                },
                {
                    "field": "commit_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the updated file",
                },
                {
                    "field": "download_url",
                    "type": "string",
                    "helper_text": "Download URL of the file",
                },
                {
                    "field": "file_details",
                    "type": "vec<string>",
                    "helper_text": "File details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_file",
            "task_name": "tasks.github.update_file",
            "description": "Update an existing file in a GitHub repository",
            "label": "Update File",
            "required": [
                "owner",
                "repository_name",
                "file_path",
                "update_file_content",
                "update_commit_message",
                "file_sha",
            ],
        },
        "read_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the file to read",
                    "label": "File Path",
                    "placeholder": "src/main.js",
                },
                {
                    "field": "ref",
                    "type": "string",
                    "value": "",
                    "helper_text": "Branch, tag, or commit to read from",
                    "label": "Reference",
                    "placeholder": "main",
                },
            ],
            "outputs": [
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the file",
                },
                {
                    "field": "file_content",
                    "type": "string",
                    "helper_text": "Content of the file",
                },
                {
                    "field": "file_sha",
                    "type": "string",
                    "helper_text": "SHA of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the file",
                },
                {
                    "field": "download_url",
                    "type": "string",
                    "helper_text": "Download URL of the file",
                },
                {
                    "field": "git_url",
                    "type": "string",
                    "helper_text": "Git URL of the file",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "HTML URL of the file",
                },
                {
                    "field": "encoding",
                    "type": "string",
                    "helper_text": "Encoding of the file",
                },
                {
                    "field": "file_type",
                    "type": "string",
                    "helper_text": "Type of the file",
                },
                {
                    "field": "file_details",
                    "type": "vec<string>",
                    "helper_text": "File details in JSON format",
                },
            ],
            "name": "read_file",
            "task_name": "tasks.github.read_file",
            "description": "Read details of a specific file",
            "label": "Get File",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "file_path"],
        },
        "delete_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the file to delete",
                    "label": "File Path",
                    "placeholder": "src/main.js",
                },
                {
                    "field": "delete_commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "Commit message for the file deletion",
                    "label": "Commit Message",
                    "placeholder": "Delete file",
                },
                {
                    "field": "delete_branch_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Branch to delete the file from",
                    "label": "Branch Name",
                    "placeholder": "main",
                },
                {
                    "field": "delete_file_sha",
                    "type": "string",
                    "value": "",
                    "helper_text": "Current SHA of the file to delete",
                    "label": "File SHA",
                    "placeholder": "abc123",
                },
                {
                    "field": "delete_committer_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the committer",
                    "label": "Committer Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "delete_committer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the committer",
                    "label": "Committer Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "delete_author_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the author",
                    "label": "Author Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "delete_author_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the author",
                    "label": "Author Email",
                    "placeholder": "john@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "commit_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the deleted file",
                },
            ],
            "name": "delete_file",
            "task_name": "tasks.github.delete_file",
            "description": "Delete a file from a GitHub repository",
            "label": "Delete File",
            "variant": "common_integration_nodes",
            "required": [
                "owner",
                "repository_name",
                "file_path",
                "delete_commit_message",
                "delete_file_sha",
            ],
        },
        "create_branch**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "branch_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the new branch",
                    "label": "Branch Name",
                    "placeholder": "feature-branch",
                },
                {
                    "field": "source_branch",
                    "type": "string",
                    "value": "",
                    "helper_text": "Source branch to create from",
                    "label": "Source Branch",
                    "placeholder": "main",
                },
            ],
            "outputs": [
                {
                    "field": "branch_name",
                    "type": "string",
                    "helper_text": "Name of the created branch",
                },
                {"field": "sha", "type": "string", "helper_text": "SHA of the branch"},
                {
                    "field": "ref",
                    "type": "string",
                    "helper_text": "Reference of the branch",
                },
                {"field": "url", "type": "string", "helper_text": "URL of the branch"},
                {
                    "field": "branch_details",
                    "type": "vec<string>",
                    "helper_text": "Branch details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_branch",
            "task_name": "tasks.github.create_branch",
            "description": "Create a new branch in a GitHub repository",
            "label": "Create Branch",
            "required": ["owner", "repository_name", "branch_name"],
        },
        "read_branch**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "branch_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the branch to read",
                    "label": "Branch Name",
                    "placeholder": "feature-branch",
                },
            ],
            "outputs": [
                {
                    "field": "branch_name",
                    "type": "string",
                    "helper_text": "Name of the branch",
                },
                {
                    "field": "sha",
                    "type": "string",
                    "helper_text": "SHA of the latest commit",
                },
                {
                    "field": "commit_url",
                    "type": "string",
                    "helper_text": "URL of the latest commit",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "helper_text": "Message of the latest commit",
                },
                {
                    "field": "commit_author",
                    "type": "string",
                    "helper_text": "Author of the latest commit",
                },
                {
                    "field": "commit_committer",
                    "type": "string",
                    "helper_text": "Committer of the latest commit",
                },
                {
                    "field": "commit_date",
                    "type": "string",
                    "helper_text": "Date of the latest commit",
                },
                {
                    "field": "protected",
                    "type": "bool",
                    "helper_text": "Whether the branch is protected",
                },
                {
                    "field": "branch_details",
                    "type": "vec<string>",
                    "helper_text": "Branch details in JSON format",
                },
            ],
            "name": "read_branch",
            "task_name": "tasks.github.read_branch",
            "description": "Read details of a specific branch",
            "label": "Get Branch",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "branch_name"],
        },
        "get_branches**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all branches, ignoring the number limit",
                },
                {
                    "field": "protected",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Filter by protected status",
                    "label": "Protected Only",
                },
            ],
            "outputs": [
                {
                    "field": "branch_names",
                    "type": "vec<string>",
                    "helper_text": "List of branch names",
                },
                {
                    "field": "commit_shas",
                    "type": "vec<string>",
                    "helper_text": "List of commit SHAs",
                },
                {
                    "field": "commit_urls",
                    "type": "vec<string>",
                    "helper_text": "List of commit URLs",
                },
                {
                    "field": "commit_messages",
                    "type": "vec<string>",
                    "helper_text": "List of commit messages",
                },
                {
                    "field": "commit_authors",
                    "type": "vec<string>",
                    "helper_text": "List of commit authors",
                },
                {
                    "field": "commit_committers",
                    "type": "vec<string>",
                    "helper_text": "List of commit committers",
                },
                {
                    "field": "commit_dates",
                    "type": "vec<string>",
                    "helper_text": "List of commit dates",
                },
                {
                    "field": "protected_flags",
                    "type": "vec<string>",
                    "helper_text": "List of protection flags",
                },
                {
                    "field": "branch_details",
                    "type": "vec<string>",
                    "helper_text": "Branch details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_branches",
            "task_name": "tasks.github.get_branches",
            "description": "Get multiple branches",
            "label": "List Branches",
            "required": ["owner", "repository_name", "num_messages"],
        },
        "get_branches**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Branches",
                    "helper_text": "Specify the number of branches to fetch",
                }
            ],
            "outputs": [],
        },
        "get_branches**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_branches**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_branches**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_branch**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "branch_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the branch to delete",
                    "label": "Branch Name",
                    "placeholder": "feature-branch",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "branch_name",
                    "type": "string",
                    "helper_text": "Name of the deleted branch",
                },
            ],
            "name": "delete_branch",
            "task_name": "tasks.github.delete_branch",
            "description": "Delete a branch from a GitHub repository",
            "label": "Delete Branch",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "branch_name"],
        },
        "read_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "username",
                    "type": "string",
                    "value": "",
                    "helper_text": "Username to read information for",
                    "label": "Username",
                    "placeholder": "octocat",
                }
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {
                    "field": "username",
                    "type": "string",
                    "helper_text": "Username of the user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Display name of the user",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "avatar_url",
                    "type": "string",
                    "helper_text": "Avatar URL of the user",
                },
                {
                    "field": "html_url",
                    "type": "string",
                    "helper_text": "Profile URL of the user",
                },
                {"field": "bio", "type": "string", "helper_text": "Bio of the user"},
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "Location of the user",
                },
                {
                    "field": "company",
                    "type": "string",
                    "helper_text": "Company of the user",
                },
                {
                    "field": "blog",
                    "type": "string",
                    "helper_text": "Blog URL of the user",
                },
                {
                    "field": "user_details",
                    "type": "vec<string>",
                    "helper_text": "User details in JSON format",
                },
            ],
            "name": "read_user",
            "task_name": "tasks.github.read_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "variant": "default_integration_nodes",
            "required": ["username"],
        },
        "get_organization_members**(*)**(*)": {
            "inputs": [
                {
                    "field": "organization",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the organization",
                    "label": "Organization",
                    "placeholder": "mycompany",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all members, ignoring the number limit",
                },
                {
                    "field": "filter",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter members by role",
                    "label": "Filter",
                    "placeholder": "all",
                },
                {
                    "field": "role",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by member role",
                    "label": "Role",
                    "placeholder": "member",
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "usernames",
                    "type": "vec<string>",
                    "helper_text": "List of usernames",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of display names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user emails",
                },
                {
                    "field": "avatar_urls",
                    "type": "vec<string>",
                    "helper_text": "List of avatar URLs",
                },
                {
                    "field": "html_urls",
                    "type": "vec<string>",
                    "helper_text": "List of profile URLs",
                },
                {
                    "field": "user_types",
                    "type": "vec<string>",
                    "helper_text": "List of user types",
                },
                {
                    "field": "member_roles",
                    "type": "vec<string>",
                    "helper_text": "List of member roles",
                },
                {
                    "field": "user_details",
                    "type": "vec<string>",
                    "helper_text": "User details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_organization_members",
            "task_name": "tasks.github.get_organization_members",
            "description": "Get multiple organization members",
            "label": "List Organization Members",
            "required": ["organization", "num_messages"],
        },
        "get_organization_members**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Members",
                    "helper_text": "Specify the number of members to fetch",
                }
            ],
            "outputs": [],
        },
        "get_organization_members**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_organization_members**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_organization_members**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_webhook**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "webhook_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the webhook",
                    "label": "Webhook Name",
                    "placeholder": "web",
                },
                {
                    "field": "webhook_url",
                    "type": "string",
                    "value": "",
                    "helper_text": "URL to send webhook payloads to",
                    "label": "Webhook URL",
                    "placeholder": "https://example.com/webhook",
                },
                {
                    "field": "webhook_events",
                    "type": "string",
                    "value": "",
                    "helper_text": "Events to trigger webhook (comma-separated)",
                    "label": "Events",
                    "placeholder": "push,pull_request",
                },
                {
                    "field": "webhook_secret",
                    "type": "string",
                    "value": "",
                    "helper_text": "Secret key for webhook security",
                    "label": "Secret",
                    "placeholder": "mysecret",
                },
                {
                    "field": "webhook_active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the webhook is active",
                    "label": "Active",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content type for webhook payloads",
                    "label": "Content Type",
                    "placeholder": "json",
                },
                {
                    "field": "insecure_ssl",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Allow insecure SSL",
                    "label": "Insecure SSL",
                },
            ],
            "outputs": [
                {
                    "field": "webhook_id",
                    "type": "string",
                    "helper_text": "ID of the created webhook",
                },
                {
                    "field": "webhook_name",
                    "type": "string",
                    "helper_text": "Name of the created webhook",
                },
                {
                    "field": "webhook_url",
                    "type": "string",
                    "helper_text": "URL of the created webhook",
                },
                {
                    "field": "webhook_events",
                    "type": "vec<string>",
                    "helper_text": "List of webhook events",
                },
                {
                    "field": "webhook_active",
                    "type": "bool",
                    "helper_text": "Whether the webhook is active",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "webhook_details",
                    "type": "vec<string>",
                    "helper_text": "Webhook details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_webhook",
            "task_name": "tasks.github.create_webhook",
            "description": "Create a new webhook on GitHub",
            "label": "Create Webhook",
            "required": ["owner", "repository_name", "webhook_url"],
        },
        "update_webhook**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "webhook_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the webhook to update",
                    "label": "Webhook ID",
                    "placeholder": "123456",
                },
                {
                    "field": "update_webhook_url",
                    "type": "string",
                    "value": "",
                    "helper_text": "New URL for webhook payloads",
                    "label": "New Webhook URL",
                    "placeholder": "https://example.com/new-webhook",
                },
                {
                    "field": "update_webhook_events",
                    "type": "string",
                    "value": "",
                    "helper_text": "New events to trigger webhook",
                    "label": "New Events",
                    "placeholder": "push,issues",
                },
                {
                    "field": "update_webhook_secret",
                    "type": "string",
                    "value": "",
                    "helper_text": "New secret key for webhook",
                    "label": "New Secret",
                    "placeholder": "newsecret",
                },
                {
                    "field": "update_webhook_active",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Update webhook active status",
                    "label": "Active",
                },
                {
                    "field": "update_content_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "New content type",
                    "label": "New Content Type",
                    "placeholder": "form",
                },
                {
                    "field": "update_insecure_ssl",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Update insecure SSL setting",
                    "label": "Insecure SSL",
                },
            ],
            "outputs": [
                {
                    "field": "webhook_id",
                    "type": "string",
                    "helper_text": "ID of the updated webhook",
                },
                {
                    "field": "webhook_name",
                    "type": "string",
                    "helper_text": "Name of the updated webhook",
                },
                {
                    "field": "webhook_url",
                    "type": "string",
                    "helper_text": "URL of the updated webhook",
                },
                {
                    "field": "webhook_events",
                    "type": "vec<string>",
                    "helper_text": "List of webhook events",
                },
                {
                    "field": "webhook_active",
                    "type": "bool",
                    "helper_text": "Whether the webhook is active",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Update timestamp",
                },
                {
                    "field": "webhook_details",
                    "type": "vec<string>",
                    "helper_text": "Webhook details in JSON format",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_webhook",
            "task_name": "tasks.github.update_webhook",
            "description": "Update an existing webhook on GitHub",
            "label": "Update Webhook",
            "required": ["owner", "repository_name", "webhook_id"],
        },
        "read_webhook**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "webhook_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the webhook to read",
                    "label": "Webhook ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "webhook_id",
                    "type": "string",
                    "helper_text": "ID of the webhook",
                },
                {
                    "field": "webhook_name",
                    "type": "string",
                    "helper_text": "Name of the webhook",
                },
                {
                    "field": "webhook_url",
                    "type": "string",
                    "helper_text": "URL of the webhook",
                },
                {
                    "field": "webhook_events",
                    "type": "vec<string>",
                    "helper_text": "List of webhook events",
                },
                {
                    "field": "webhook_active",
                    "type": "bool",
                    "helper_text": "Whether the webhook is active",
                },
                {
                    "field": "webhook_config",
                    "type": "string",
                    "helper_text": "Webhook configuration details",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "ping_url",
                    "type": "string",
                    "helper_text": "Ping URL for the webhook",
                },
                {
                    "field": "test_url",
                    "type": "string",
                    "helper_text": "Test URL for the webhook",
                },
                {
                    "field": "webhook_details",
                    "type": "vec<string>",
                    "helper_text": "Webhook details in JSON format",
                },
            ],
            "name": "read_webhook",
            "task_name": "tasks.github.read_webhook",
            "description": "Read details of a specific webhook",
            "label": "Get Webhook",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "webhook_id"],
        },
        "get_webhooks**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Return all webhooks, ignoring the number limit",
                },
            ],
            "outputs": [
                {
                    "field": "webhook_ids",
                    "type": "vec<string>",
                    "helper_text": "List of webhook IDs",
                },
                {
                    "field": "webhook_names",
                    "type": "vec<string>",
                    "helper_text": "List of webhook names",
                },
                {
                    "field": "webhook_urls",
                    "type": "vec<string>",
                    "helper_text": "List of webhook URLs",
                },
                {
                    "field": "webhook_events",
                    "type": "vec<string>",
                    "helper_text": "List of webhook events",
                },
                {
                    "field": "webhook_active_flags",
                    "type": "vec<string>",
                    "helper_text": "List of webhook active flags",
                },
                {
                    "field": "webhook_configs",
                    "type": "vec<string>",
                    "helper_text": "List of webhook configurations",
                },
                {
                    "field": "created_dates",
                    "type": "vec<string>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<string>",
                    "helper_text": "List of update dates",
                },
                {
                    "field": "ping_urls",
                    "type": "vec<string>",
                    "helper_text": "List of ping URLs",
                },
                {
                    "field": "test_urls",
                    "type": "vec<string>",
                    "helper_text": "List of test URLs",
                },
                {
                    "field": "webhook_details",
                    "type": "vec<string>",
                    "helper_text": "Webhook details in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_webhooks",
            "task_name": "tasks.github.get_webhooks",
            "description": "Get multiple webhooks",
            "label": "List Webhooks",
            "required": ["owner", "repository_name", "num_messages"],
        },
        "get_webhooks**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Webhooks",
                    "helper_text": "Specify the number of webhooks to fetch",
                }
            ],
            "outputs": [],
        },
        "get_webhooks**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_webhooks**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_webhooks**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "delete_webhook**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "webhook_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the webhook to delete",
                    "label": "Webhook ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "webhook_id",
                    "type": "string",
                    "helper_text": "ID of the deleted webhook",
                },
            ],
            "name": "delete_webhook",
            "task_name": "tasks.github.delete_webhook",
            "description": "Delete a GitHub webhook",
            "label": "Delete Webhook",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "webhook_id"],
        },
        "ping_webhook**(*)**(*)": {
            "inputs": [
                {
                    "field": "owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Owner of the repository",
                    "label": "Owner",
                    "placeholder": "Select owner",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 1,
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the repository",
                    "label": "Repository Name",
                    "placeholder": "Select repository",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=repository_name&owner={inputs.owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 2,
                },
                {
                    "field": "webhook_id",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "ID of the webhook to ping",
                    "label": "Webhook ID",
                    "placeholder": "123456",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Response message",
                },
                {
                    "field": "delivery_id",
                    "type": "string",
                    "helper_text": "ID of the delivery",
                },
                {
                    "field": "webhook_details",
                    "type": "vec<string>",
                    "helper_text": "Webhook response details",
                },
            ],
            "name": "ping_webhook",
            "task_name": "tasks.github.ping_webhook",
            "description": "Ping a GitHub webhook",
            "label": "Ping Webhook",
            "variant": "common_integration_nodes",
            "required": ["owner", "repository_name", "webhook_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        affiliation: str = "",
        assignee: str = "",
        assignees: str = "",
        author_email: str = "",
        author_name: str = "",
        auto_init: bool = True,
        base: str = "",
        branch_name: str = "",
        comment_body: str = "",
        comment_id: int = 0,
        commit_message: str = "",
        commit_title: str = "",
        committer_email: str = "",
        committer_name: str = "",
        content_type: str = "",
        creator: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        delete_author_email: str = "",
        delete_author_name: str = "",
        delete_branch_name: str = "",
        delete_commit_message: str = "",
        delete_committer_email: str = "",
        delete_committer_name: str = "",
        delete_file_sha: str = "",
        direction: str = "",
        draft: bool = False,
        exact_date: TimeRange = {"start": "", "end": ""},
        file_content: str = "",
        file_path: str = "",
        file_sha: str = "",
        filter: str = "",
        generate_release_notes: bool = False,
        gitignore_template: str = "",
        head: str = "",
        homepage: str = "",
        insecure_ssl: bool = False,
        is_private: bool = False,
        issue_body: str = "",
        issue_number: int = 0,
        issue_title: str = "",
        labels: str = "",
        license_template: str = "",
        limit: int = 10,
        maintainer_can_modify: bool = True,
        mentioned: str = "",
        merge_method: str = "",
        milestone: int = 0,
        num_messages: int = 10,
        organization: str = "",
        owner: str = "",
        prerelease: bool = False,
        protected: bool = False,
        pull_request_body: str = "",
        pull_request_number: int = 0,
        pull_request_title: str = "",
        ref: str = "",
        release_body: str = "",
        release_id: int = 0,
        release_name: str = "",
        repository_description: str = "",
        repository_name: str = "",
        return_all: bool = False,
        role: str = "",
        sha: str = "",
        sort: str = "",
        source_branch: str = "",
        state: str = "",
        tag_name: str = "",
        target_commitish: str = "",
        type: str = "",
        update_assignees: str = "",
        update_author_email: str = "",
        update_author_name: str = "",
        update_base: str = "",
        update_branch_name: str = "",
        update_comment_body: str = "",
        update_commit_message: str = "",
        update_committer_email: str = "",
        update_committer_name: str = "",
        update_content_type: str = "",
        update_draft: bool = False,
        update_file_content: str = "",
        update_has_issues: bool = True,
        update_has_projects: bool = True,
        update_has_wiki: bool = True,
        update_homepage: str = "",
        update_insecure_ssl: bool = False,
        update_is_private: bool = False,
        update_issue_body: str = "",
        update_issue_state: str = "",
        update_issue_title: str = "",
        update_labels: str = "",
        update_maintainer_can_modify: bool = True,
        update_milestone: int = 0,
        update_prerelease: bool = False,
        update_pull_request_body: str = "",
        update_pull_request_state: str = "",
        update_pull_request_title: str = "",
        update_release_body: str = "",
        update_release_name: str = "",
        update_repository_description: str = "",
        update_repository_name: str = "",
        update_tag_name: str = "",
        update_target_commitish: str = "",
        update_webhook_active: bool = True,
        update_webhook_events: str = "",
        update_webhook_secret: str = "",
        update_webhook_url: str = "",
        username: str = "",
        visibility: str = "",
        webhook_active: bool = True,
        webhook_events: str = "",
        webhook_id: int = 0,
        webhook_name: str = "",
        webhook_secret: str = "",
        webhook_url: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_github",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if repository_name is not None:
            self.inputs["repository_name"] = repository_name
        if repository_description is not None:
            self.inputs["repository_description"] = repository_description
        if is_private is not None:
            self.inputs["is_private"] = is_private
        if auto_init is not None:
            self.inputs["auto_init"] = auto_init
        if gitignore_template is not None:
            self.inputs["gitignore_template"] = gitignore_template
        if license_template is not None:
            self.inputs["license_template"] = license_template
        if homepage is not None:
            self.inputs["homepage"] = homepage
        if owner is not None:
            self.inputs["owner"] = owner
        if update_repository_name is not None:
            self.inputs["update_repository_name"] = update_repository_name
        if update_repository_description is not None:
            self.inputs["update_repository_description"] = update_repository_description
        if update_homepage is not None:
            self.inputs["update_homepage"] = update_homepage
        if update_is_private is not None:
            self.inputs["update_is_private"] = update_is_private
        if update_has_issues is not None:
            self.inputs["update_has_issues"] = update_has_issues
        if update_has_projects is not None:
            self.inputs["update_has_projects"] = update_has_projects
        if update_has_wiki is not None:
            self.inputs["update_has_wiki"] = update_has_wiki
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if type is not None:
            self.inputs["type"] = type
        if sort is not None:
            self.inputs["sort"] = sort
        if direction is not None:
            self.inputs["direction"] = direction
        if visibility is not None:
            self.inputs["visibility"] = visibility
        if affiliation is not None:
            self.inputs["affiliation"] = affiliation
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if issue_title is not None:
            self.inputs["issue_title"] = issue_title
        if issue_body is not None:
            self.inputs["issue_body"] = issue_body
        if assignees is not None:
            self.inputs["assignees"] = assignees
        if milestone is not None:
            self.inputs["milestone"] = milestone
        if labels is not None:
            self.inputs["labels"] = labels
        if issue_number is not None:
            self.inputs["issue_number"] = issue_number
        if update_issue_title is not None:
            self.inputs["update_issue_title"] = update_issue_title
        if update_issue_body is not None:
            self.inputs["update_issue_body"] = update_issue_body
        if update_issue_state is not None:
            self.inputs["update_issue_state"] = update_issue_state
        if update_assignees is not None:
            self.inputs["update_assignees"] = update_assignees
        if update_milestone is not None:
            self.inputs["update_milestone"] = update_milestone
        if update_labels is not None:
            self.inputs["update_labels"] = update_labels
        if state is not None:
            self.inputs["state"] = state
        if assignee is not None:
            self.inputs["assignee"] = assignee
        if creator is not None:
            self.inputs["creator"] = creator
        if mentioned is not None:
            self.inputs["mentioned"] = mentioned
        if pull_request_title is not None:
            self.inputs["pull_request_title"] = pull_request_title
        if head is not None:
            self.inputs["head"] = head
        if base is not None:
            self.inputs["base"] = base
        if pull_request_body is not None:
            self.inputs["pull_request_body"] = pull_request_body
        if draft is not None:
            self.inputs["draft"] = draft
        if maintainer_can_modify is not None:
            self.inputs["maintainer_can_modify"] = maintainer_can_modify
        if pull_request_number is not None:
            self.inputs["pull_request_number"] = pull_request_number
        if update_pull_request_title is not None:
            self.inputs["update_pull_request_title"] = update_pull_request_title
        if update_pull_request_body is not None:
            self.inputs["update_pull_request_body"] = update_pull_request_body
        if update_pull_request_state is not None:
            self.inputs["update_pull_request_state"] = update_pull_request_state
        if update_base is not None:
            self.inputs["update_base"] = update_base
        if update_maintainer_can_modify is not None:
            self.inputs["update_maintainer_can_modify"] = update_maintainer_can_modify
        if query is not None:
            self.inputs["query"] = query
        if limit is not None:
            self.inputs["limit"] = limit
        if commit_title is not None:
            self.inputs["commit_title"] = commit_title
        if commit_message is not None:
            self.inputs["commit_message"] = commit_message
        if sha is not None:
            self.inputs["sha"] = sha
        if merge_method is not None:
            self.inputs["merge_method"] = merge_method
        if comment_body is not None:
            self.inputs["comment_body"] = comment_body
        if comment_id is not None:
            self.inputs["comment_id"] = comment_id
        if update_comment_body is not None:
            self.inputs["update_comment_body"] = update_comment_body
        if tag_name is not None:
            self.inputs["tag_name"] = tag_name
        if release_name is not None:
            self.inputs["release_name"] = release_name
        if release_body is not None:
            self.inputs["release_body"] = release_body
        if target_commitish is not None:
            self.inputs["target_commitish"] = target_commitish
        if prerelease is not None:
            self.inputs["prerelease"] = prerelease
        if generate_release_notes is not None:
            self.inputs["generate_release_notes"] = generate_release_notes
        if release_id is not None:
            self.inputs["release_id"] = release_id
        if update_tag_name is not None:
            self.inputs["update_tag_name"] = update_tag_name
        if update_release_name is not None:
            self.inputs["update_release_name"] = update_release_name
        if update_release_body is not None:
            self.inputs["update_release_body"] = update_release_body
        if update_target_commitish is not None:
            self.inputs["update_target_commitish"] = update_target_commitish
        if update_draft is not None:
            self.inputs["update_draft"] = update_draft
        if update_prerelease is not None:
            self.inputs["update_prerelease"] = update_prerelease
        if file_path is not None:
            self.inputs["file_path"] = file_path
        if file_content is not None:
            self.inputs["file_content"] = file_content
        if branch_name is not None:
            self.inputs["branch_name"] = branch_name
        if committer_name is not None:
            self.inputs["committer_name"] = committer_name
        if committer_email is not None:
            self.inputs["committer_email"] = committer_email
        if author_name is not None:
            self.inputs["author_name"] = author_name
        if author_email is not None:
            self.inputs["author_email"] = author_email
        if update_file_content is not None:
            self.inputs["update_file_content"] = update_file_content
        if update_commit_message is not None:
            self.inputs["update_commit_message"] = update_commit_message
        if update_branch_name is not None:
            self.inputs["update_branch_name"] = update_branch_name
        if file_sha is not None:
            self.inputs["file_sha"] = file_sha
        if update_committer_name is not None:
            self.inputs["update_committer_name"] = update_committer_name
        if update_committer_email is not None:
            self.inputs["update_committer_email"] = update_committer_email
        if update_author_name is not None:
            self.inputs["update_author_name"] = update_author_name
        if update_author_email is not None:
            self.inputs["update_author_email"] = update_author_email
        if ref is not None:
            self.inputs["ref"] = ref
        if delete_commit_message is not None:
            self.inputs["delete_commit_message"] = delete_commit_message
        if delete_branch_name is not None:
            self.inputs["delete_branch_name"] = delete_branch_name
        if delete_file_sha is not None:
            self.inputs["delete_file_sha"] = delete_file_sha
        if delete_committer_name is not None:
            self.inputs["delete_committer_name"] = delete_committer_name
        if delete_committer_email is not None:
            self.inputs["delete_committer_email"] = delete_committer_email
        if delete_author_name is not None:
            self.inputs["delete_author_name"] = delete_author_name
        if delete_author_email is not None:
            self.inputs["delete_author_email"] = delete_author_email
        if source_branch is not None:
            self.inputs["source_branch"] = source_branch
        if protected is not None:
            self.inputs["protected"] = protected
        if username is not None:
            self.inputs["username"] = username
        if organization is not None:
            self.inputs["organization"] = organization
        if filter is not None:
            self.inputs["filter"] = filter
        if role is not None:
            self.inputs["role"] = role
        if webhook_name is not None:
            self.inputs["webhook_name"] = webhook_name
        if webhook_url is not None:
            self.inputs["webhook_url"] = webhook_url
        if webhook_events is not None:
            self.inputs["webhook_events"] = webhook_events
        if webhook_secret is not None:
            self.inputs["webhook_secret"] = webhook_secret
        if webhook_active is not None:
            self.inputs["webhook_active"] = webhook_active
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if insecure_ssl is not None:
            self.inputs["insecure_ssl"] = insecure_ssl
        if webhook_id is not None:
            self.inputs["webhook_id"] = webhook_id
        if update_webhook_url is not None:
            self.inputs["update_webhook_url"] = update_webhook_url
        if update_webhook_events is not None:
            self.inputs["update_webhook_events"] = update_webhook_events
        if update_webhook_secret is not None:
            self.inputs["update_webhook_secret"] = update_webhook_secret
        if update_webhook_active is not None:
            self.inputs["update_webhook_active"] = update_webhook_active
        if update_content_type is not None:
            self.inputs["update_content_type"] = update_content_type
        if update_insecure_ssl is not None:
            self.inputs["update_insecure_ssl"] = update_insecure_ssl
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGithubNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
