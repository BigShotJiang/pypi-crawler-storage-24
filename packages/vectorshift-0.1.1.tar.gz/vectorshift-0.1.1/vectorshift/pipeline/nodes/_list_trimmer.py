"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("list_trimmer")
class ListTrimmerNode(Node):
    """
    Trim a list to just the sections you want. Enter enter the number of items or specify the section of the list that you want to keep.

    ## Inputs
    ### Common Inputs
        specify_section: Check this to specify a section of the list to keep. Leave unchecked to keep a specified number of items from the start.
        type: The type of the list
    ### When specify_section = True and type = '<T>'
        end_index: The ending index of the section to keep (exclusive).
        list: The list to trim
        start_index: The starting index of the section to keep (inclusive). The first item of the list is index 0.
    ### When specify_section = False and type = '<T>'
        item_to_keep: Check this to specify a section of the list to keep. Leave unchecked to keep a specified number of items.
        list: The list to trim

    ## Outputs
    ### When specify_section = False and type = '<T>'
        output: The trimmed list
    ### When specify_section = True and type = '<T>'
        output: The trimmed list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "specify_section",
            "helper_text": "Check this to specify a section of the list to keep. Leave unchecked to keep a specified number of items from the start.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "type",
            "helper_text": "The type of the list",
            "value": "string",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "false**<T>": {
            "inputs": [
                {
                    "field": "item_to_keep",
                    "label": "# of items To Keep",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Check this to specify a section of the list to keep. Leave unchecked to keep a specified number of items.",
                    "component": {"type": "number"},
                },
                {
                    "field": "list",
                    "label": "List",
                    "type": "vec<<T>>",
                    "value": "",
                    "helper_text": "The list to trim",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<<T>>",
                    "helper_text": "The trimmed list",
                }
            ],
        },
        "true**<T>": {
            "inputs": [
                {
                    "field": "start_index",
                    "label": "Start Index",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "The starting index of the section to keep (inclusive). The first item of the list is index 0.",
                    "component": {"type": "number"},
                },
                {
                    "field": "end_index",
                    "label": "End Index",
                    "type": "int32",
                    "value": 1,
                    "helper_text": "The ending index of the section to keep (exclusive).",
                    "component": {"type": "number"},
                },
                {
                    "field": "list",
                    "label": "List",
                    "type": "vec<<T>>",
                    "value": "",
                    "helper_text": "The list to trim",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<<T>>",
                    "helper_text": "The trimmed list",
                }
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["specify_section", "type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["list", "item_to_keep", "start_index", "end_index"]

    def __init__(
        self,
        specify_section: bool = False,
        type: str = "string",
        end_index: int = 1,
        item_to_keep: int = 0,
        list: List[Any] = [],
        start_index: int = 0,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["specify_section"] = specify_section
        params["type"] = type

        super().__init__(
            node_type="list_trimmer",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if type is not None:
            self.inputs["type"] = type
        if specify_section is not None:
            self.inputs["specify_section"] = specify_section
        if item_to_keep is not None:
            self.inputs["item_to_keep"] = item_to_keep
        if list is not None:
            self.inputs["list"] = list
        if start_index is not None:
            self.inputs["start_index"] = start_index
        if end_index is not None:
            self.inputs["end_index"] = end_index
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ListTrimmerNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
