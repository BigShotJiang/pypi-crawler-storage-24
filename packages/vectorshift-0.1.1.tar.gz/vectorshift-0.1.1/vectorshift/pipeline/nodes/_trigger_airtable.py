"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_airtable")
class TriggerAirtableNode(Node):
    """
    Airtable Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        trigger_enabled: Enable/Disable Automation
    ### new_row
        item_id: Select the table to watch for new rows
    ### updated_row
        item_id: Select the table to watch for new rows

    ## Outputs
    ### new_row
        created_time: When the record was created
        record_id: Unique identifier of the record
        row_data: Complete row data as JSON string
        table_id: ID of the table containing the record
        table_name: Name of the table
        trigger_timestamp: When this trigger was activated
    ### updated_row
        created_time: When the record was created
        record_id: Unique identifier of the record
        row_data: Complete row data as JSON string
        table_id: ID of the table containing the record
        table_name: Name of the table
        trigger_timestamp: When this trigger was activated
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Airtable>",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_row": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "helper_text": "Select the table to watch for new rows",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the record",
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "helper_text": "ID of the table containing the record",
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "Name of the table",
                },
                {
                    "field": "row_data",
                    "type": "string",
                    "helper_text": "Complete row data as JSON string",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the record was created",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_row",
            "task_name": "tasks.airtable.new_row",
            "description": "Triggers when a new row is added to the selected table",
            "label": "New Row",
        },
        "updated_row": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "helper_text": "Select the table to watch for updated rows",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the record",
                },
                {
                    "field": "table_id",
                    "type": "string",
                    "helper_text": "ID of the table containing the record",
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "Name of the table",
                },
                {
                    "field": "row_data",
                    "type": "string",
                    "helper_text": "Complete row data as JSON string",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the record was created",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_row",
            "task_name": "tasks.airtable.updated_row",
            "description": "Triggers when a row is updated in the selected table",
            "label": "Updated Row",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Table"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_airtable",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerAirtableNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
