"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_google_ads")
class IntegrationGoogleAdsNode(Node):
    """
    Google Ads

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'read_campaign'
        campaign_id: The campaign to retrieve details for
        customer_id: The Google Ads customer account
    ### When action = 'get_campaigns'
        campaign_status: Filter by campaign status (ENABLED, PAUSED, REMOVED)
        campaign_type: Filter by campaign type (SEARCH, DISPLAY, VIDEO, etc.)
        customer_id: The Google Ads customer account
        use_date: Toggle to use dates
    ### When action = 'get_campaigns' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_campaigns' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_campaigns' and use_date = False
        num_messages: Specify the number of campaigns to fetch
    ### When action = 'get_campaigns' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_campaign'
        campaign_id: The ID of the campaign
        campaign_name: The name of the campaign
        campaign_status: The status of the campaign
        campaign_type: The type of the campaign
        end_date: The end date of the campaign
        raw_data: The raw response data from Google Ads API
        start_date: The start date of the campaign
    ### When action = 'get_campaigns'
        campaign_ids: List of campaign IDs
        campaign_names: List of campaign names
        campaign_statuses: List of campaign statuses
        campaign_types: List of campaign types
        campaigns: Campaign details in JSON format
        raw_data: The raw response data from Google Ads API
        total_count: Total number of campaigns found
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Ads>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_campaigns**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "label": "Customer",
                    "placeholder": "Select customer",
                    "helper_text": "The Google Ads customer account",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "campaign_status",
                    "type": "string",
                    "value": "",
                    "label": "Campaign Status",
                    "placeholder": "Select status",
                    "helper_text": "Filter by campaign status (ENABLED, PAUSED, REMOVED)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_status&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "campaign_type",
                    "type": "string",
                    "value": "",
                    "label": "Campaign Type",
                    "placeholder": "Select type",
                    "helper_text": "Filter by campaign type (SEARCH, DISPLAY, VIDEO, etc.)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_type&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "campaigns",
                    "type": "string",
                    "helper_text": "Campaign details in JSON format",
                },
                {
                    "field": "campaign_ids",
                    "type": "vec<string>",
                    "helper_text": "List of campaign IDs",
                },
                {
                    "field": "campaign_names",
                    "type": "vec<string>",
                    "helper_text": "List of campaign names",
                },
                {
                    "field": "campaign_types",
                    "type": "vec<string>",
                    "helper_text": "List of campaign types",
                },
                {
                    "field": "campaign_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of campaign statuses",
                },
                {
                    "field": "total_count",
                    "type": "string",
                    "helper_text": "Total number of campaigns found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Google Ads API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_campaigns",
            "task_name": "tasks.google_ads.get_campaigns",
            "description": "Get multiple campaigns",
            "label": "List Campaigns",
            "inputs_sort_order": [
                "integration",
                "action",
                "customer_id",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "campaign_status",
                "campaign_type",
            ],
        },
        "get_campaigns**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Campaigns",
                    "helper_text": "Specify the number of campaigns to fetch",
                }
            ],
            "outputs": [],
        },
        "get_campaigns**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_campaigns**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_campaigns**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "read_campaign**(*)**(*)": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "label": "Customer",
                    "placeholder": "Select customer",
                    "helper_text": "The Google Ads customer account",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=customer_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "campaign_id",
                    "type": "string",
                    "value": "",
                    "label": "Campaign",
                    "placeholder": "Select campaign",
                    "helper_text": "The campaign to retrieve details for",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=campaign_id&page={}&page_size={dynamic_config.page_size}&q={}&customer_id={inputs.customer_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "campaign_id",
                    "type": "string",
                    "helper_text": "The ID of the campaign",
                },
                {
                    "field": "campaign_name",
                    "type": "string",
                    "helper_text": "The name of the campaign",
                },
                {
                    "field": "campaign_status",
                    "type": "string",
                    "helper_text": "The status of the campaign",
                },
                {
                    "field": "campaign_type",
                    "type": "string",
                    "helper_text": "The type of the campaign",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "The start date of the campaign",
                },
                {
                    "field": "end_date",
                    "type": "timestamp",
                    "helper_text": "The end date of the campaign",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw response data from Google Ads API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_campaign",
            "task_name": "tasks.google_ads.read_campaign",
            "description": "Read details of a specific campaign",
            "label": "Get Campaign",
            "inputs_sort_order": [
                "integration",
                "action",
                "customer_id",
                "campaign_id",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "customer_id",
        "campaign_id",
        "num_messages",
    ]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        campaign_id: str = "",
        campaign_status: str = "",
        campaign_type: str = "",
        customer_id: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        exact_date: TimeRange = {"start": "", "end": ""},
        num_messages: int = 10,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_google_ads",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if customer_id is not None:
            self.inputs["customer_id"] = customer_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if campaign_status is not None:
            self.inputs["campaign_status"] = campaign_status
        if campaign_type is not None:
            self.inputs["campaign_type"] = campaign_type
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if campaign_id is not None:
            self.inputs["campaign_id"] = campaign_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleAdsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
