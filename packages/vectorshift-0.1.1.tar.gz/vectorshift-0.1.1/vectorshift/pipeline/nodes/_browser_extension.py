"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("browser_extension")
class BrowserExtensionNode(Node):
    """
    Run a VectorShift workflow using the current page captured by the VectorShift chrome extension as input.

    ## Inputs
    ### Common Inputs
        page_content: The content of the page
        page_html: The HTML of the page
        page_urls: The URLs of the pages
        screenshot: The screenshot of the page
        show_chrome_extension: Deploy to chrome extension
        url: The URL of the page

    ## Outputs
    ### Common Outputs
        page_content: The content of the current page
        page_html: The HTML of the current page
        page_urls: The URLs on the current page
        screenshot: The screenshot of the current page
        url: The URL of the current page
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "page_content",
            "helper_text": "The content of the page",
            "value": "",
            "type": "string",
        },
        {
            "field": "page_html",
            "helper_text": "The HTML of the page",
            "value": "",
            "type": "string",
        },
        {
            "field": "page_urls",
            "helper_text": "The URLs of the pages",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "screenshot",
            "helper_text": "The screenshot of the page",
            "value": {},
            "type": "image",
        },
        {
            "field": "show_chrome_extension",
            "helper_text": "Deploy to chrome extension",
            "value": True,
            "type": "bool",
        },
        {
            "field": "url",
            "helper_text": "The URL of the page",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "page_content",
            "helper_text": "The content of the current page",
            "type": "string",
        },
        {
            "field": "page_html",
            "helper_text": "The HTML of the current page",
            "type": "string",
        },
        {
            "field": "page_urls",
            "helper_text": "The URLs on the current page",
            "type": "vec<string>",
        },
        {
            "field": "screenshot",
            "helper_text": "The screenshot of the current page",
            "type": "image",
        },
        {
            "field": "url",
            "helper_text": "The URL of the current page",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    def __init__(
        self,
        page_content: str = "",
        page_html: str = "",
        page_urls: List[str] = [],
        screenshot: Any = {},
        show_chrome_extension: bool = True,
        url: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="browser_extension",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if url is not None:
            self.inputs["url"] = url
        if page_urls is not None:
            self.inputs["page_urls"] = page_urls
        if page_content is not None:
            self.inputs["page_content"] = page_content
        if page_html is not None:
            self.inputs["page_html"] = page_html
        if screenshot is not None:
            self.inputs["screenshot"] = screenshot
        if show_chrome_extension is not None:
            self.inputs["show_chrome_extension"] = show_chrome_extension
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "BrowserExtensionNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
