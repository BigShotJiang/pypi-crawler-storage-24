"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("json_operations")
class JsonOperationsNode(Node):
    """
    Read, create, and update JSON data

    ## Inputs
    ### Common Inputs
        sub_type: The sub_type input

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "sub_type",
            "helper_text": "The sub_type input",
            "value": "",
            "type": "string",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    def __init__(
        self,
        sub_type: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="json_operations",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if sub_type is not None:
            self.inputs["sub_type"] = sub_type
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "JsonOperationsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
