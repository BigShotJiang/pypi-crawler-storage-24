"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_servicenow")
class IntegrationServicenowNode(Node):
    """
    ServiceNow

    ## Inputs
    ### Common Inputs
        action: Select the Servicenow operation to perform
        integration: Connect to your Servicenow account
    ### When action = 'list_table_records'
        query: An encoded query string to filter results (e.g., active=true^priority=1)
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
        table_name: Name of the ServiceNow table
    ### When action = 'create_user'
        active: Whether the user account should be active
        building: Building address
        city: City
        company: Company name
        country: Country
        department: User's department
        email: User's email address
        first_name: User's first name
        gender: User's gender
        home_phone: Home phone number
        last_name: User's last name
        location: User's work location
        manager: sys_id of the user's manager
        middle_name: User's middle name
        mobile_phone: User's mobile phone number
        password_needs_reset: Whether to require a password reset when the user logs in
        phone: User's phone number
        roles: Comma-separated list of role names or sys_ids
        source: Source of the user record
        state: State
        street: Street information separated by comma
        time_zone: User's time zone
        title: User's job title
        user_name: Unique username for the user (required)
        user_password: User's password
        zip: Zip code
    ### When action = 'update_user'
        active: Whether the user account should be active
        building: Building address
        city: City
        company: Company name
        country: Country
        department: User's department
        email: User's email address
        first_name: User's first name
        gender: User's gender
        home_phone: Home phone number
        last_name: User's last name
        location: User's work location
        manager: sys_id of the user's manager
        middle_name: User's middle name
        mobile_phone: User's mobile phone number
        password_needs_reset: Whether to require a password reset when the user logs in
        phone: User's phone number
        roles: Comma-separated list of role names or sys_ids
        source: Source of the user record
        state: State
        street: Street information separated by comma
        time_zone: User's time zone
        title: User's job title
        user_id: The sys_id of the user to fetch
        user_name: Unique username for the user (required)
        user_password: User's password
        zip: Zip code
    ### When action = 'create_incident'
        assigned_to: sys_id of the user to assign the incident to
        assignment_group: sys_id of the assignment group
        business_service: sys_id of the business service
        caller_id: sys_id of the incident caller
        category: Category of the incident
        close_code: Code for incident resolution
        close_notes: Notes for incident closure
        cmdb_ci: sys_id of the configuration item
        contact_type: How the incident was reported (phone, email, self-service, walk-in)
        description: Detailed description of the incident
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        impact: Impact level
        short_description: Short description of the incident
        state: State
        subcategory: Subcategory of the incident
        sysparm_display_value: Choose which values to return for reference fields
        urgency: Urgency level
    ### When action = 'update_incident'
        assigned_to: sys_id of the user to assign the incident to
        assignment_group: sys_id of the assignment group
        business_service: sys_id of the business service
        caller_id: sys_id of the incident caller
        category: Category of the incident
        close_code: Code for incident resolution
        close_notes: Notes for incident closure
        cmdb_ci: sys_id of the configuration item
        contact_type: How the incident was reported (phone, email, self-service, walk-in)
        description: Detailed description of the incident
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        impact: Impact level
        incident_id: The sys_id of the incident to retrieve
        short_description: Short description of the incident
        state: State
        subcategory: Subcategory of the incident
        sysparm_display_value: Choose which values to return for reference fields
        urgency: Urgency level
    ### When action = 'get_attachment'
        attachment_id: Sys_id value of the attachment to retrieve
        download: Whether to download the actual file content
    ### When action = 'delete_attachment'
        attachment_id: Sys_id value of the attachment to retrieve
    ### When action = 'upload_attachment'
        content_type: MIME type of the file
        file_content: File to upload
        file_name: Name to give the attachment
        table_name: Name of the ServiceNow table
        table_sys_id: Sys_id of the record in the table to attach the file to
    ### When action = 'create_table_record'
        data_json: JSON object with field-value pairs for the new record. Leave as {} for empty
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        sysparm_display_value: Choose which values to return for reference fields
        table_name: Name of the ServiceNow table
    ### When action = 'update_table_record'
        data_json: JSON object with field-value pairs for the new record. Leave as {} for empty
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        record_id: Sys ID of the record to retrieve
        sysparm_display_value: Choose which values to return for reference fields
        table_name: Name of the ServiceNow table
    ### When action = 'list_attachments'
        download: Whether to download the actual file content
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
        table_name: Name of the ServiceNow table
    ### When action = 'get_user'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        search_by: Choose whether to search by sys_id or username
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
    ### When action = 'list_users'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'get_incident'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        incident_id: The sys_id of the incident to retrieve
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
    ### When action = 'list_incidents'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'get_table_record'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        record_id: Sys ID of the record to retrieve
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        table_name: Name of the ServiceNow table
    ### When action = 'list_business_services'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'list_dictionary_entries'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'list_configuration_items'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'list_departments'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'list_user_groups'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'list_user_roles'
        exclude_reference_link: Exclude the reference link (URI) for reference fields
        limit: The maximum number of records to return. Ignored if Return All is enabled.
        return_all: If all results should be returned or only up to the limit
        sysparm_display_value: Choose which values to return for reference fields
        sysparm_fields: Comma-separated list of field names to return. Leave empty to return all fields.
        sysparm_query: An encoded query string to filter results (e.g., active=true^department=IT)
    ### When action = 'delete_incident'
        incident_id: The sys_id of the incident to retrieve
    ### When action = 'delete_table_record'
        record_id: Sys ID of the record to retrieve
        table_name: Name of the ServiceNow table
    ### When action = 'get_user' and search_by = 'sys_id'
        user_id: The sys_id of the user to fetch
    ### When action = 'delete_user'
        user_id: The sys_id of the user to fetch
    ### When action = 'get_user' and search_by = 'username'
        user_name: Unique username for the user (required)

    ## Outputs
    ### When action = 'create_user'
        active: Active status of the created user
        email: Email address of the created user
        raw_data: Raw JSON response from ServiceNow
        user_id: The unique sys_id of the created user
        user_name: Username of the created user
    ### When action = 'get_user'
        active: Whether the user is active
        email: Email address of the user
        raw_data: Raw JSON response from ServiceNow
        user_id: The unique sys_id of the user
        user_name: Username of the user
    ### When action = 'update_user'
        active: Active status of the updated user
        email: Email address of the updated user
        raw_data: Raw JSON response from ServiceNow
        user_id: The unique sys_id of the updated user
        user_name: Username of the updated user
    ### When action = 'upload_attachment'
        attachment_sys_id: The sys_id of the uploaded attachment
        content_type: MIME type of the file
        download_link: Download link for the attachment
        file_name: Name of the uploaded file
        raw_data: Raw JSON response from ServiceNow
        size_bytes: Size of the file in bytes
        table_name: Table the attachment is linked to
        table_sys_id: Sys_id of the table record
    ### When action = 'get_attachment'
        attachment_sys_id: The sys_id of the attachment
        content_type: MIME type of the file
        download_link: Download link for the attachment
        file: Downloaded file (if download=true)
        file_name: Name of the file
        raw_data: Raw JSON response from ServiceNow
        size_bytes: Size of the file in bytes
        table_name: Table the attachment is linked to
        table_sys_id: Sys_id of the table record
    ### When action = 'delete_attachment'
        attachment_sys_id: The sys_id of the deleted attachment
        raw_data: Raw JSON response from ServiceNow
    ### When action = 'list_attachments'
        attachment_sys_ids: Array of attachment sys_ids
        content_types: Array of content types
        count: Number of attachments returned
        created_by: Array of creators
        created_on: Array of creation dates
        download_links: Array of download links
        file_names: Array of file names
        raw_data: Raw JSON response from ServiceNow
        sizes_bytes: Array of file sizes
        table_names: Array of table names
        table_sys_ids: Array of table sys_ids
    ### When action = 'list_configuration_items'
        ci_names: Array of configuration item names
        ci_sys_ids: Array of configuration item sys_ids
        count: Number of configuration items returned
        raw_data: Raw JSON response from ServiceNow
    ### When action = 'list_users'
        count: Number of users returned
        emails: Array of email addresses
        raw_data: Raw JSON response from ServiceNow
        user_ids: Array of user sys_ids
        user_names: Array of usernames
    ### When action = 'list_incidents'
        count: Number of incidents returned
        incident_ids: Array of incident sys_ids
        incident_numbers: Array of incident numbers
        raw_data: Raw JSON response from ServiceNow
        states: Array of incident states
    ### When action = 'list_table_records'
        count: Number of records returned
        raw_data: Raw JSON response from ServiceNow
        record_ids: Array of record sys_ids
        records: Array of record objects (JSON)
        table_name: The name of the table
    ### When action = 'list_business_services'
        count: Number of business services returned
        raw_data: Raw JSON response from ServiceNow
        service_names: Array of business service names
        service_sys_ids: Array of business service sys_ids
    ### When action = 'list_dictionary_entries'
        count: Number of dictionary entries returned
        raw_data: Raw JSON response from ServiceNow
    ### When action = 'list_departments'
        count: Number of departments returned
        dept_names: Array of department names
        dept_sys_ids: Array of department sys_ids
        raw_data: Raw JSON response from ServiceNow
    ### When action = 'list_user_groups'
        count: Number of user groups returned
        group_names: Array of user group names
        group_sys_ids: Array of user group sys_ids
        raw_data: Raw JSON response from ServiceNow
    ### When action = 'list_user_roles'
        count: Number of user roles returned
        raw_data: Raw JSON response from ServiceNow
        role_names: Array of user role names
        role_sys_ids: Array of user role sys_ids
    ### When action = 'create_incident'
        incident_id: The unique sys_id of the created incident
        incident_number: The incident number
        raw_data: Raw JSON response from ServiceNow
        state: Current state of the incident
    ### When action = 'get_incident'
        incident_id: The unique sys_id of the incident
        incident_number: The incident number
        raw_data: Raw JSON response from ServiceNow
        short_description: Brief description of the incident
        state: Current state of the incident
    ### When action = 'update_incident'
        incident_id: The unique sys_id of the updated incident
        incident_number: The incident number
        raw_data: Raw JSON response from ServiceNow
        state: Current state of the incident
    ### When action = 'delete_incident'
        incident_id: The sys_id of the deleted incident
        raw_data: Raw JSON response from ServiceNow
    ### When action = 'delete_user'
        raw_data: Raw JSON response from ServiceNow
        user_id: The sys_id of the deleted user
    ### When action = 'create_table_record'
        raw_data: Raw JSON response from ServiceNow
        record: The complete created record object (JSON)
        record_id: The sys_id of the created record
        table_name: The name of the table
    ### When action = 'get_table_record'
        raw_data: Raw JSON response from ServiceNow
        record: The complete record object (JSON)
        record_id: The sys_id of the record
        table_name: The name of the table
    ### When action = 'update_table_record'
        raw_data: Raw JSON response from ServiceNow
        record: The complete updated record object (JSON)
        record_id: The sys_id of the updated record
        table_name: The name of the table
    ### When action = 'delete_table_record'
        raw_data: Raw JSON response from ServiceNow
        record_id: The sys_id of the deleted record
        table_name: The name of the table
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the Servicenow operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Servicenow account",
            "value": None,
            "type": "integration<Servicenow>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_user**(*)": {
            "inputs": [
                {
                    "field": "user_name",
                    "type": "string",
                    "value": "",
                    "label": "Username",
                    "placeholder": "john.doe",
                    "helper_text": "Unique username for the user (required)",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "User's first name",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "User's last name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john.doe@example.com",
                    "helper_text": "User's email address",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Software Engineer",
                    "helper_text": "User's job title",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Engineering",
                    "helper_text": "User's department",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "User's phone number",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-5678",
                    "helper_text": "User's mobile phone number",
                },
                {
                    "field": "middle_name",
                    "type": "string",
                    "value": "",
                    "label": "Middle Name",
                    "placeholder": "M",
                    "helper_text": "User's middle name",
                },
                {
                    "field": "gender",
                    "type": "string",
                    "value": "",
                    "label": "Gender",
                    "helper_text": "User's gender",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Male", "value": "Male"},
                            {"label": "Female", "value": "Female"},
                        ],
                    },
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "label": "Active",
                    "helper_text": "Whether the user account should be active",
                },
                {
                    "field": "user_password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "placeholder": "********",
                    "helper_text": "User's password",
                    "component": {"type": "password"},
                },
                {
                    "field": "password_needs_reset",
                    "type": "bool",
                    "value": False,
                    "label": "Password Needs Reset",
                    "helper_text": "Whether to require a password reset when the user logs in",
                },
                {
                    "field": "time_zone",
                    "type": "string",
                    "value": "",
                    "label": "Time Zone",
                    "placeholder": "America/New_York",
                    "helper_text": "User's time zone",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "building",
                    "type": "string",
                    "value": "",
                    "label": "Building",
                    "placeholder": "Building 1",
                    "helper_text": "Building address",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Street information separated by comma",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "New York",
                    "helper_text": "City",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "NY",
                    "helper_text": "State",
                },
                {
                    "field": "zip",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "10001",
                    "helper_text": "Zip code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Country",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "New York Office",
                    "helper_text": "User's work location",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                    "helper_text": "Company name",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1-555-9876",
                    "helper_text": "Home phone number",
                },
                {
                    "field": "manager",
                    "type": "string",
                    "value": "",
                    "label": "Manager ID",
                    "placeholder": "Manager's sys_id",
                    "helper_text": "sys_id of the user's manager",
                },
                {
                    "field": "roles",
                    "type": "string",
                    "value": "",
                    "label": "Roles",
                    "placeholder": "admin,itil",
                    "helper_text": "Comma-separated list of role names or sys_ids",
                },
                {
                    "field": "source",
                    "type": "string",
                    "value": "",
                    "label": "Source",
                    "placeholder": "",
                    "helper_text": "Source of the user record",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The unique sys_id of the created user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Username of the created user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the created user",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Active status of the created user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "create_user",
            "task_name": "tasks.servicenow.create_user",
            "description": "Create a user in Servicenow",
            "label": "Create User",
            "variant": "common_integration_nodes",
            "required": ["user_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "user_name",
                "first_name",
                "middle_name",
                "last_name",
                "email",
                "title",
                "department",
                "company",
                "phone",
                "mobile_phone",
                "home_phone",
                "gender",
                "active",
                "user_password",
                "password_needs_reset",
                "time_zone",
                "building",
                "street",
                "city",
                "state",
                "zip",
                "country",
                "location",
                "manager",
                "roles",
                "source",
            ],
        },
        "get_user**(*)": {
            "inputs": [
                {
                    "field": "search_by",
                    "type": "string",
                    "value": "sys_id",
                    "label": "Search By",
                    "helper_text": "Choose whether to search by sys_id or username",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sys ID", "value": "sys_id"},
                            {"label": "Username", "value": "username"},
                        ],
                    },
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "user_name,email,active,department",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The unique sys_id of the user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Username of the user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the user",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Whether the user is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "get_user",
            "task_name": "tasks.servicenow.get_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "required": ["search_by", "user_id", "user_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "search_by",
                "user_id",
                "user_name",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_display_value",
            ],
        },
        "get_user**sys_id": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User Sys ID",
                    "placeholder": "681ccaf9c0a8016400b98a06818d57c7",
                    "helper_text": "The sys_id of the user to fetch",
                }
            ],
            "outputs": [],
        },
        "get_user**username": {
            "inputs": [
                {
                    "field": "user_name",
                    "type": "string",
                    "value": "",
                    "label": "Username",
                    "placeholder": "john.doe",
                    "helper_text": "The username of the user to fetch",
                    "required": True,
                }
            ],
            "outputs": [],
        },
        "list_users**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "user_name,email,active,department",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "active=true^department=IT",
                    "helper_text": "An encoded query string to filter results (e.g., active=true^department=IT)",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of user sys_ids",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "Array of usernames",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "Array of email addresses",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of users returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_users",
            "task_name": "tasks.servicenow.list_users",
            "description": "Get multiple users from ServiceNow",
            "label": "List Users",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "update_user**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User Sys ID",
                    "placeholder": "Enter sys_user sys_id",
                    "helper_text": "sys_id of the user to update (required)",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "Update user's first name",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Update user's last name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john.doe@example.com",
                    "helper_text": "Update user's email address",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Senior Engineer",
                    "helper_text": "Update user's job title",
                },
                {
                    "field": "department",
                    "type": "string",
                    "value": "",
                    "label": "Department",
                    "placeholder": "Engineering",
                    "helper_text": "Update user's department",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-1234",
                    "helper_text": "Update user's phone number",
                },
                {
                    "field": "mobile_phone",
                    "type": "string",
                    "value": "",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-5678",
                    "helper_text": "Update user's mobile phone number",
                },
                {
                    "field": "middle_name",
                    "type": "string",
                    "value": "",
                    "label": "Middle Name",
                    "placeholder": "M",
                    "helper_text": "Update user's middle name",
                },
                {
                    "field": "gender",
                    "type": "string",
                    "value": "",
                    "label": "Gender",
                    "helper_text": "Update user's gender",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Male", "value": "Male"},
                            {"label": "Female", "value": "Female"},
                        ],
                    },
                },
                {
                    "field": "active",
                    "type": "bool",
                    "value": True,
                    "label": "Active",
                    "helper_text": "Update user's active status",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "value": "",
                    "label": "Username",
                    "placeholder": "john.doe",
                    "helper_text": "Update username",
                },
                {
                    "field": "user_password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "placeholder": "********",
                    "helper_text": "Update user's password",
                    "component": {"type": "password"},
                },
                {
                    "field": "password_needs_reset",
                    "type": "bool",
                    "value": False,
                    "label": "Password Needs Reset",
                    "helper_text": "Whether to require a password reset when the user logs in",
                },
                {
                    "field": "time_zone",
                    "type": "string",
                    "value": "",
                    "label": "Time Zone",
                    "placeholder": "America/New_York",
                    "helper_text": "Update user's time zone",
                    "component": {"type": "dropdown", "referenced_options": "timezone"},
                },
                {
                    "field": "building",
                    "type": "string",
                    "value": "",
                    "label": "Building",
                    "placeholder": "Building 1",
                    "helper_text": "Update building address",
                },
                {
                    "field": "street",
                    "type": "string",
                    "value": "",
                    "label": "Street",
                    "placeholder": "123 Main St",
                    "helper_text": "Update street information separated by comma",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "New York",
                    "helper_text": "Update city",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "NY",
                    "helper_text": "Update state",
                },
                {
                    "field": "zip",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "10001",
                    "helper_text": "Update zip code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "USA",
                    "helper_text": "Update country",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "New York Office",
                    "helper_text": "Update user's work location",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                    "helper_text": "Update company name",
                },
                {
                    "field": "home_phone",
                    "type": "string",
                    "value": "",
                    "label": "Home Phone",
                    "placeholder": "+1-555-9876",
                    "helper_text": "Update home phone number",
                },
                {
                    "field": "manager",
                    "type": "string",
                    "value": "",
                    "label": "Manager ID",
                    "placeholder": "Manager's sys_id",
                    "helper_text": "Update user's manager (sys_id)",
                },
                {
                    "field": "roles",
                    "type": "string",
                    "value": "",
                    "label": "Roles",
                    "placeholder": "admin,itil",
                    "helper_text": "Update comma-separated list of role names or sys_ids",
                },
                {
                    "field": "source",
                    "type": "string",
                    "value": "",
                    "label": "Source",
                    "placeholder": "",
                    "helper_text": "Update source of the user record",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The unique sys_id of the updated user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Username of the updated user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the updated user",
                },
                {
                    "field": "active",
                    "type": "bool",
                    "helper_text": "Active status of the updated user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "update_user",
            "task_name": "tasks.servicenow.update_user",
            "description": "Update a user in Servicenow",
            "label": "Update User",
            "variant": "common_integration_nodes",
            "required": ["user_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "user_id",
                "user_name",
                "first_name",
                "middle_name",
                "last_name",
                "email",
                "title",
                "department",
                "company",
                "phone",
                "mobile_phone",
                "home_phone",
                "gender",
                "active",
                "user_password",
                "password_needs_reset",
                "time_zone",
                "building",
                "street",
                "city",
                "state",
                "zip",
                "country",
                "location",
                "manager",
                "roles",
                "source",
            ],
        },
        "delete_user**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User Sys ID",
                    "placeholder": "Enter sys_user sys_id",
                    "helper_text": "sys_id of the user to delete",
                }
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The sys_id of the deleted user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "delete_user",
            "task_name": "tasks.servicenow.delete_user",
            "description": "Delete a user from Servicenow",
            "label": "Delete User",
            "variant": "common_integration_nodes",
            "required": ["user_id"],
            "ui_sort_order": ["integration", "action", "user_id"],
        },
        "create_incident**(*)": {
            "inputs": [
                {
                    "field": "short_description",
                    "type": "string",
                    "value": "",
                    "label": "Short Description",
                    "placeholder": "Brief description of the incident",
                    "helper_text": "Short description of the incident",
                    "required": True,
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Detailed description",
                    "helper_text": "Detailed description of the incident",
                    "component": {"type": "textarea"},
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "hardware",
                    "helper_text": "Category of the incident",
                },
                {
                    "field": "subcategory",
                    "type": "string",
                    "value": "",
                    "label": "Subcategory",
                    "placeholder": "printer",
                    "helper_text": "Subcategory of the incident",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "1",
                    "label": "State",
                    "helper_text": "State of the incident",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "New", "value": "1"},
                            {"label": "In Progress", "value": "2"},
                            {"label": "On Hold", "value": "3"},
                            {"label": "Resolved", "value": "6"},
                            {"label": "Closed", "value": "7"},
                        ],
                    },
                },
                {
                    "field": "impact",
                    "type": "string",
                    "value": "2",
                    "label": "Impact",
                    "helper_text": "Impact level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High", "value": "1"},
                            {"label": "Medium", "value": "2"},
                            {"label": "Low", "value": "3"},
                        ],
                    },
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "value": "2",
                    "label": "Urgency",
                    "helper_text": "Urgency level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High", "value": "1"},
                            {"label": "Medium", "value": "2"},
                            {"label": "Low", "value": "3"},
                        ],
                    },
                },
                {
                    "field": "assigned_to",
                    "type": "string",
                    "value": "",
                    "label": "Assigned To",
                    "placeholder": "User sys_id",
                    "helper_text": "sys_id of the user to assign the incident to",
                },
                {
                    "field": "assignment_group",
                    "type": "string",
                    "value": "",
                    "label": "Assignment Group",
                    "placeholder": "Group sys_id",
                    "helper_text": "sys_id of the assignment group",
                },
                {
                    "field": "caller_id",
                    "type": "string",
                    "value": "",
                    "label": "Caller ID",
                    "placeholder": "User sys_id",
                    "helper_text": "sys_id of the incident caller",
                },
                {
                    "field": "contact_type",
                    "type": "string",
                    "value": "",
                    "label": "Contact Type",
                    "placeholder": "phone",
                    "helper_text": "How the incident was reported (phone, email, self-service, walk-in)",
                },
                {
                    "field": "business_service",
                    "type": "string",
                    "value": "",
                    "label": "Business Service",
                    "placeholder": "Service sys_id",
                    "helper_text": "sys_id of the business service",
                },
                {
                    "field": "cmdb_ci",
                    "type": "string",
                    "value": "",
                    "label": "Configuration Item",
                    "placeholder": "CI sys_id",
                    "helper_text": "sys_id of the configuration item",
                },
                {
                    "field": "close_code",
                    "type": "string",
                    "value": "",
                    "label": "Resolution Code",
                    "placeholder": "Solved (Work Around)",
                    "helper_text": "Code for incident resolution",
                },
                {
                    "field": "close_notes",
                    "type": "string",
                    "value": "",
                    "label": "Close Notes",
                    "placeholder": "Resolution notes",
                    "helper_text": "Notes for incident closure",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The unique sys_id of the created incident",
                },
                {
                    "field": "incident_number",
                    "type": "string",
                    "helper_text": "The incident number",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the incident",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "create_incident",
            "task_name": "tasks.servicenow.create_incident",
            "description": "Create an incident in ServiceNow",
            "label": "Create Incident",
            "variant": "common_integration_nodes",
            "required": ["short_description"],
            "ui_sort_order": [
                "integration",
                "action",
                "short_description",
                "description",
                "category",
                "subcategory",
                "state",
                "impact",
                "urgency",
                "assigned_to",
                "assignment_group",
                "caller_id",
                "contact_type",
                "business_service",
                "cmdb_ci",
                "close_code",
                "close_notes",
                "exclude_reference_link",
                "sysparm_display_value",
            ],
        },
        "get_incident**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident ID",
                    "placeholder": "sys_id of the incident",
                    "helper_text": "The sys_id of the incident to retrieve",
                    "required": True,
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "short_description,state,assigned_to",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The unique sys_id of the incident",
                },
                {
                    "field": "incident_number",
                    "type": "string",
                    "helper_text": "The incident number",
                },
                {
                    "field": "short_description",
                    "type": "string",
                    "helper_text": "Brief description of the incident",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the incident",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "get_incident",
            "task_name": "tasks.servicenow.get_incident",
            "description": "Get details of a specific incident from ServiceNow",
            "label": "Get Incident",
            "variant": "common_integration_nodes",
            "required": ["incident_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "incident_id",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_display_value",
            ],
        },
        "list_incidents**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "number,short_description,state,assigned_to",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "state=1^impact=1",
                    "helper_text": "An encoded query string to filter results (e.g., state=1^impact=1 for new high-impact incidents)",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "incident_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of incident sys_ids",
                },
                {
                    "field": "incident_numbers",
                    "type": "vec<string>",
                    "helper_text": "Array of incident numbers",
                },
                {
                    "field": "states",
                    "type": "vec<string>",
                    "helper_text": "Array of incident states",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of incidents returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_incidents",
            "task_name": "tasks.servicenow.list_incidents",
            "description": "Get multiple incidents from ServiceNow",
            "label": "List Incidents",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "update_incident**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident ID",
                    "placeholder": "sys_id of the incident",
                    "helper_text": "The sys_id of the incident to update",
                    "required": True,
                },
                {
                    "field": "short_description",
                    "type": "string",
                    "value": "",
                    "label": "Short Description",
                    "placeholder": "Brief description of the incident",
                    "helper_text": "Short description of the incident",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Detailed description",
                    "helper_text": "Detailed description of the incident",
                    "component": {"type": "textarea"},
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "hardware",
                    "helper_text": "Category of the incident",
                },
                {
                    "field": "subcategory",
                    "type": "string",
                    "value": "",
                    "label": "Subcategory",
                    "placeholder": "printer",
                    "helper_text": "Subcategory of the incident",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "1",
                    "label": "State",
                    "helper_text": "State of the incident",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "New", "value": "1"},
                            {"label": "In Progress", "value": "2"},
                            {"label": "On Hold", "value": "3"},
                            {"label": "Resolved", "value": "6"},
                            {"label": "Closed", "value": "7"},
                        ],
                    },
                },
                {
                    "field": "impact",
                    "type": "string",
                    "value": "2",
                    "label": "Impact",
                    "helper_text": "Impact level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High", "value": "1"},
                            {"label": "Medium", "value": "2"},
                            {"label": "Low", "value": "3"},
                        ],
                    },
                },
                {
                    "field": "urgency",
                    "type": "string",
                    "value": "2",
                    "label": "Urgency",
                    "helper_text": "Urgency level",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "High", "value": "1"},
                            {"label": "Medium", "value": "2"},
                            {"label": "Low", "value": "3"},
                        ],
                    },
                },
                {
                    "field": "assigned_to",
                    "type": "string",
                    "value": "",
                    "label": "Assigned To",
                    "placeholder": "User sys_id",
                    "helper_text": "sys_id of the user to assign the incident to",
                },
                {
                    "field": "assignment_group",
                    "type": "string",
                    "value": "",
                    "label": "Assignment Group",
                    "placeholder": "Group sys_id",
                    "helper_text": "sys_id of the assignment group",
                },
                {
                    "field": "caller_id",
                    "type": "string",
                    "value": "",
                    "label": "Caller ID",
                    "placeholder": "User sys_id",
                    "helper_text": "sys_id of the incident caller",
                },
                {
                    "field": "contact_type",
                    "type": "string",
                    "value": "",
                    "label": "Contact Type",
                    "placeholder": "phone",
                    "helper_text": "How the incident was reported (phone, email, self-service, walk-in)",
                },
                {
                    "field": "business_service",
                    "type": "string",
                    "value": "",
                    "label": "Business Service",
                    "placeholder": "Service sys_id",
                    "helper_text": "sys_id of the business service",
                },
                {
                    "field": "cmdb_ci",
                    "type": "string",
                    "value": "",
                    "label": "Configuration Item",
                    "placeholder": "CI sys_id",
                    "helper_text": "sys_id of the configuration item",
                },
                {
                    "field": "close_code",
                    "type": "string",
                    "value": "",
                    "label": "Resolution Code",
                    "placeholder": "Solved (Work Around)",
                    "helper_text": "Code for incident resolution",
                },
                {
                    "field": "close_notes",
                    "type": "string",
                    "value": "",
                    "label": "Close Notes",
                    "placeholder": "Resolution notes",
                    "helper_text": "Notes for incident closure",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The unique sys_id of the updated incident",
                },
                {
                    "field": "incident_number",
                    "type": "string",
                    "helper_text": "The incident number",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the incident",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "update_incident",
            "task_name": "tasks.servicenow.update_incident",
            "description": "Update an incident in ServiceNow",
            "label": "Update Incident",
            "variant": "common_integration_nodes",
            "required": ["incident_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "incident_id",
                "short_description",
                "description",
                "category",
                "subcategory",
                "state",
                "impact",
                "urgency",
                "assigned_to",
                "assignment_group",
                "caller_id",
                "contact_type",
                "business_service",
                "cmdb_ci",
                "close_code",
                "close_notes",
                "exclude_reference_link",
                "sysparm_display_value",
            ],
        },
        "delete_incident**(*)": {
            "inputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "value": "",
                    "label": "Incident ID",
                    "placeholder": "sys_id of the incident",
                    "helper_text": "The sys_id of the incident to delete",
                    "required": True,
                }
            ],
            "outputs": [
                {
                    "field": "incident_id",
                    "type": "string",
                    "helper_text": "The sys_id of the deleted incident",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "delete_incident",
            "task_name": "tasks.servicenow.delete_incident",
            "description": "Delete an incident from ServiceNow",
            "label": "Delete Incident",
            "variant": "common_integration_nodes",
            "required": ["incident_id"],
            "ui_sort_order": ["integration", "action", "incident_id"],
        },
        "create_table_record**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data_json",
                    "type": "string",
                    "value": "{}",
                    "label": "Data (JSON)",
                    "placeholder": '{"short_description": "Test", "priority": "3"}',
                    "helper_text": "JSON object with field-value pairs for the new record. Leave as {} for empty",
                    "component": {"type": "textarea"},
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sys IDs", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
            ],
            "outputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "The name of the table",
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "The sys_id of the created record",
                },
                {
                    "field": "record",
                    "type": "string",
                    "helper_text": "The complete created record object (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "create_table_record",
            "task_name": "tasks.servicenow.create_table_record",
            "description": "Create a record in any ServiceNow table",
            "label": "Create Table Record",
            "variant": "common_integration_nodes",
            "required": ["table_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "data_json",
                "sysparm_display_value",
                "exclude_reference_link",
            ],
        },
        "get_table_record**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "label": "Record ID",
                    "placeholder": "sys_id",
                    "helper_text": "Sys ID of the record to retrieve",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names",
                    "placeholder": "number,short_description,state",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sys IDs", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
            ],
            "outputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "The name of the table",
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "The sys_id of the record",
                },
                {
                    "field": "record",
                    "type": "string",
                    "helper_text": "The complete record object (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "get_table_record",
            "task_name": "tasks.servicenow.get_table_record",
            "description": "Get a single record from any ServiceNow table",
            "label": "Get Table Record",
            "variant": "common_integration_nodes",
            "required": ["table_name", "record_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "record_id",
                "sysparm_fields",
                "sysparm_display_value",
                "exclude_reference_link",
            ],
        },
        "list_table_records**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "active=true^priority=1",
                    "helper_text": "An encoded query string to filter results (e.g., active=true^priority=1)",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names",
                    "placeholder": "number,short_description,state",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "active=true^priority=1",
                    "helper_text": "An encoded query string to filter results (alternative to Query field)",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sys IDs", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
            ],
            "outputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "The name of the table",
                },
                {
                    "field": "record_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of record sys_ids",
                },
                {
                    "field": "records",
                    "type": "string",
                    "helper_text": "Array of record objects (JSON)",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of records returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_table_records",
            "task_name": "tasks.servicenow.list_table_records",
            "description": "Get multiple records from any ServiceNow table",
            "label": "List Table Records",
            "variant": "common_integration_nodes",
            "required": ["table_name", "return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "return_all",
                "limit",
                "query",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
                "exclude_reference_link",
            ],
        },
        "update_table_record**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "label": "Record ID",
                    "placeholder": "sys_id",
                    "helper_text": "Sys ID of the record to update",
                },
                {
                    "field": "data_json",
                    "type": "string",
                    "value": "{}",
                    "label": "Data (JSON)",
                    "placeholder": '{"state": "2", "priority": "2"}',
                    "helper_text": "JSON object with field-value pairs to update. Leave as {} for no changes",
                    "component": {"type": "textarea"},
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sys IDs", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
            ],
            "outputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "The name of the table",
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "The sys_id of the updated record",
                },
                {
                    "field": "record",
                    "type": "string",
                    "helper_text": "The complete updated record object (JSON)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "update_table_record",
            "task_name": "tasks.servicenow.update_table_record",
            "description": "Update a record in any ServiceNow table",
            "label": "Update Table Record",
            "variant": "common_integration_nodes",
            "required": ["table_name", "record_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "record_id",
                "data_json",
                "sysparm_display_value",
                "exclude_reference_link",
            ],
        },
        "delete_table_record**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "value": "",
                    "label": "Record ID",
                    "placeholder": "sys_id",
                    "helper_text": "Sys ID of the record to delete",
                },
            ],
            "outputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "The name of the table",
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "The sys_id of the deleted record",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "delete_table_record",
            "task_name": "tasks.servicenow.delete_table_record",
            "description": "Delete a record from any ServiceNow table",
            "label": "Delete Table Record",
            "variant": "common_integration_nodes",
            "required": ["table_name", "record_id"],
            "ui_sort_order": ["integration", "action", "table_name", "record_id"],
        },
        "upload_attachment**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "table_sys_id",
                    "type": "string",
                    "value": "",
                    "label": "Table Record ID",
                    "placeholder": "sys_id",
                    "helper_text": "Sys_id of the record in the table to attach the file to",
                },
                {
                    "field": "file_content",
                    "type": "file",
                    "value": "",
                    "label": "File Content",
                    "helper_text": "File to upload",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "label": "File Name",
                    "placeholder": "document.pdf",
                    "helper_text": "Name to give the attachment",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "application/octet-stream",
                    "label": "Content Type",
                    "placeholder": "application/pdf",
                    "helper_text": "MIME type of the file",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_sys_id",
                    "type": "string",
                    "helper_text": "The sys_id of the uploaded attachment",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "Table the attachment is linked to",
                },
                {
                    "field": "table_sys_id",
                    "type": "string",
                    "helper_text": "Sys_id of the table record",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size_bytes",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "download_link",
                    "type": "string",
                    "helper_text": "Download link for the attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "upload_attachment",
            "task_name": "tasks.servicenow.upload_attachment",
            "description": "Upload an attachment to a ServiceNow table record",
            "label": "Upload Attachment",
            "variant": "common_integration_nodes",
            "required": ["table_name", "table_sys_id", "file_content"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "table_sys_id",
                "file_content",
                "file_name",
                "content_type",
            ],
        },
        "get_attachment**(*)": {
            "inputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "placeholder": "sys_id",
                    "helper_text": "Sys_id value of the attachment to retrieve",
                },
                {
                    "field": "download",
                    "type": "bool",
                    "value": False,
                    "label": "Download Content",
                    "helper_text": "Whether to download the actual file content",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_sys_id",
                    "type": "string",
                    "helper_text": "The sys_id of the attachment",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "table_name",
                    "type": "string",
                    "helper_text": "Table the attachment is linked to",
                },
                {
                    "field": "table_sys_id",
                    "type": "string",
                    "helper_text": "Sys_id of the table record",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size_bytes",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "download_link",
                    "type": "string",
                    "helper_text": "Download link for the attachment",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "Downloaded file (if download=true)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "get_attachment",
            "task_name": "tasks.servicenow.get_attachment",
            "description": "Get details of a specific attachment from ServiceNow",
            "label": "Get Attachment",
            "variant": "common_integration_nodes",
            "required": ["attachment_id"],
            "ui_sort_order": ["integration", "action", "attachment_id", "download"],
        },
        "list_attachments**(*)": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "incident",
                    "helper_text": "Name of the ServiceNow table to get attachments from",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names",
                    "placeholder": "sys_id,file_name,size_bytes",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "file_name=report.pdf",
                    "helper_text": "An encoded query string to filter results",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
                {
                    "field": "download",
                    "type": "bool",
                    "value": False,
                    "label": "Download Metadata",
                    "helper_text": "Whether to include download metadata for each attachment",
                },
            ],
            "outputs": [
                {
                    "field": "attachment_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of attachment sys_ids",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Array of file names",
                },
                {
                    "field": "table_names",
                    "type": "vec<string>",
                    "helper_text": "Array of table names",
                },
                {
                    "field": "table_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of table sys_ids",
                },
                {
                    "field": "content_types",
                    "type": "vec<string>",
                    "helper_text": "Array of content types",
                },
                {
                    "field": "sizes_bytes",
                    "type": "vec<string>",
                    "helper_text": "Array of file sizes",
                },
                {
                    "field": "download_links",
                    "type": "vec<string>",
                    "helper_text": "Array of download links",
                },
                {
                    "field": "created_by",
                    "type": "vec<string>",
                    "helper_text": "Array of creators",
                },
                {
                    "field": "created_on",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of creation dates",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of attachments returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_attachments",
            "task_name": "tasks.servicenow.list_attachments",
            "description": "Get multiple attachments from a ServiceNow table",
            "label": "List Attachments",
            "variant": "common_integration_nodes",
            "required": ["table_name", "return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
                "download",
            ],
        },
        "delete_attachment**(*)": {
            "inputs": [
                {
                    "field": "attachment_id",
                    "type": "string",
                    "value": "",
                    "label": "Attachment ID",
                    "placeholder": "sys_id",
                    "helper_text": "Sys_id value of the attachment to delete",
                }
            ],
            "outputs": [
                {
                    "field": "attachment_sys_id",
                    "type": "string",
                    "helper_text": "The sys_id of the deleted attachment",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "delete_attachment",
            "task_name": "tasks.servicenow.delete_attachment",
            "description": "Delete an attachment from ServiceNow",
            "label": "Delete Attachment",
            "variant": "common_integration_nodes",
            "required": ["attachment_id"],
            "ui_sort_order": ["integration", "action", "attachment_id"],
        },
        "list_business_services**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "name,sys_id,operational_status",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "active=true^operational_status=1",
                    "helper_text": "An encoded query string to filter results (e.g., active=true^operational_status=1)",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "service_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of business service sys_ids",
                },
                {
                    "field": "service_names",
                    "type": "vec<string>",
                    "helper_text": "Array of business service names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of business services returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_business_services",
            "task_name": "tasks.servicenow.list_business_services",
            "description": "Get multiple business services from ServiceNow",
            "label": "List Business Services",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "list_dictionary_entries**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "element,column_label,name",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "name=incident^element=priority",
                    "helper_text": "An encoded query string to filter results (e.g., name=incident^element=priority)",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of dictionary entries returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_dictionary_entries",
            "task_name": "tasks.servicenow.list_dictionary_entries",
            "description": "Get multiple dictionary entries from ServiceNow",
            "label": "List Dictionary Entries",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "list_configuration_items**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "name,sys_class_name,asset_tag,serial_number",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "sys_class_name=cmdb_ci_server^operational_status=1",
                    "helper_text": "An encoded query string to filter results (e.g., sys_class_name=cmdb_ci_server for servers only)",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "ci_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of configuration item sys_ids",
                },
                {
                    "field": "ci_names",
                    "type": "vec<string>",
                    "helper_text": "Array of configuration item names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of configuration items returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_configuration_items",
            "task_name": "tasks.servicenow.list_configuration_items",
            "description": "Get multiple configuration items from ServiceNow CMDB",
            "label": "List Configuration Items",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "list_departments**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "name,id,description,dept_head",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "name=Sales",
                    "helper_text": "An encoded query string to filter results",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "dept_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of department sys_ids",
                },
                {
                    "field": "dept_names",
                    "type": "vec<string>",
                    "helper_text": "Array of department names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of departments returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_departments",
            "task_name": "tasks.servicenow.list_departments",
            "description": "Get multiple departments from ServiceNow",
            "label": "List Departments",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "list_user_groups**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "name,description,manager,active",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "active=true",
                    "helper_text": "An encoded query string to filter results",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "group_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of user group sys_ids",
                },
                {
                    "field": "group_names",
                    "type": "vec<string>",
                    "helper_text": "Array of user group names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of user groups returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_user_groups",
            "task_name": "tasks.servicenow.list_user_groups",
            "description": "Get multiple user groups from ServiceNow",
            "label": "List User Groups",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
        "list_user_roles**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If all results should be returned or only up to the limit",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "The maximum number of records to return. Ignored if Return All is enabled.",
                },
                {
                    "field": "exclude_reference_link",
                    "type": "bool",
                    "value": False,
                    "label": "Exclude Reference Link",
                    "helper_text": "Exclude the reference link (URI) for reference fields",
                },
                {
                    "field": "sysparm_fields",
                    "type": "string",
                    "value": "",
                    "label": "Field Names or IDs",
                    "placeholder": "name,description,active,elevated_privilege",
                    "helper_text": "Comma-separated list of field names to return. Leave empty to return all fields.",
                },
                {
                    "field": "sysparm_query",
                    "type": "string",
                    "value": "",
                    "label": "Filter",
                    "placeholder": "active=true^elevated_privilege=false",
                    "helper_text": "An encoded query string to filter results",
                },
                {
                    "field": "sysparm_display_value",
                    "type": "string",
                    "value": "false",
                    "label": "Return Values",
                    "helper_text": "Choose which values to return for reference fields",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Actual Values", "value": "false"},
                            {"label": "Display Values", "value": "true"},
                            {"label": "Both", "value": "all"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "role_sys_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of user role sys_ids",
                },
                {
                    "field": "role_names",
                    "type": "vec<string>",
                    "helper_text": "Array of user role names",
                },
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Number of user roles returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from ServiceNow",
                },
            ],
            "name": "list_user_roles",
            "task_name": "tasks.servicenow.list_user_roles",
            "description": "Get multiple user roles from ServiceNow",
            "label": "List User Roles",
            "variant": "common_integration_nodes",
            "required": ["return_all"],
            "ui_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "exclude_reference_link",
                "sysparm_fields",
                "sysparm_query",
                "sysparm_display_value",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "search_by"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        search_by: str = "sys_id",
        query: str = "",
        active: bool = True,
        assigned_to: str = "",
        assignment_group: str = "",
        attachment_id: str = "",
        building: str = "",
        business_service: str = "",
        caller_id: str = "",
        category: str = "",
        city: str = "",
        close_code: str = "",
        close_notes: str = "",
        cmdb_ci: str = "",
        company: str = "",
        contact_type: str = "",
        content_type: str = "application/octet-stream",
        country: str = "",
        data_json: str = "{}",
        department: str = "",
        description: str = "",
        download: bool = False,
        email: str = "",
        exclude_reference_link: bool = False,
        file_content: str = "",
        file_name: str = "",
        first_name: str = "",
        gender: str = "",
        home_phone: str = "",
        impact: str = "2",
        incident_id: str = "",
        last_name: str = "",
        limit: int = 10,
        location: str = "",
        manager: str = "",
        middle_name: str = "",
        mobile_phone: str = "",
        password_needs_reset: bool = False,
        phone: str = "",
        record_id: str = "",
        return_all: bool = False,
        roles: str = "",
        short_description: str = "",
        source: str = "",
        state: str = "",
        street: str = "",
        subcategory: str = "",
        sysparm_display_value: str = "false",
        sysparm_fields: str = "",
        sysparm_query: str = "",
        table_name: str = "",
        table_sys_id: str = "",
        time_zone: str = "",
        title: str = "",
        urgency: str = "2",
        user_id: str = "",
        user_name: str = "",
        user_password: str = "",
        zip: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["search_by"] = search_by

        super().__init__(
            node_type="integration_servicenow",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if user_name is not None:
            self.inputs["user_name"] = user_name
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if email is not None:
            self.inputs["email"] = email
        if title is not None:
            self.inputs["title"] = title
        if department is not None:
            self.inputs["department"] = department
        if phone is not None:
            self.inputs["phone"] = phone
        if mobile_phone is not None:
            self.inputs["mobile_phone"] = mobile_phone
        if middle_name is not None:
            self.inputs["middle_name"] = middle_name
        if gender is not None:
            self.inputs["gender"] = gender
        if active is not None:
            self.inputs["active"] = active
        if user_password is not None:
            self.inputs["user_password"] = user_password
        if password_needs_reset is not None:
            self.inputs["password_needs_reset"] = password_needs_reset
        if time_zone is not None:
            self.inputs["time_zone"] = time_zone
        if building is not None:
            self.inputs["building"] = building
        if street is not None:
            self.inputs["street"] = street
        if city is not None:
            self.inputs["city"] = city
        if state is not None:
            self.inputs["state"] = state
        if zip is not None:
            self.inputs["zip"] = zip
        if country is not None:
            self.inputs["country"] = country
        if location is not None:
            self.inputs["location"] = location
        if company is not None:
            self.inputs["company"] = company
        if home_phone is not None:
            self.inputs["home_phone"] = home_phone
        if manager is not None:
            self.inputs["manager"] = manager
        if roles is not None:
            self.inputs["roles"] = roles
        if source is not None:
            self.inputs["source"] = source
        if search_by is not None:
            self.inputs["search_by"] = search_by
        if exclude_reference_link is not None:
            self.inputs["exclude_reference_link"] = exclude_reference_link
        if sysparm_fields is not None:
            self.inputs["sysparm_fields"] = sysparm_fields
        if sysparm_display_value is not None:
            self.inputs["sysparm_display_value"] = sysparm_display_value
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if sysparm_query is not None:
            self.inputs["sysparm_query"] = sysparm_query
        if short_description is not None:
            self.inputs["short_description"] = short_description
        if description is not None:
            self.inputs["description"] = description
        if category is not None:
            self.inputs["category"] = category
        if subcategory is not None:
            self.inputs["subcategory"] = subcategory
        if impact is not None:
            self.inputs["impact"] = impact
        if urgency is not None:
            self.inputs["urgency"] = urgency
        if assigned_to is not None:
            self.inputs["assigned_to"] = assigned_to
        if assignment_group is not None:
            self.inputs["assignment_group"] = assignment_group
        if caller_id is not None:
            self.inputs["caller_id"] = caller_id
        if contact_type is not None:
            self.inputs["contact_type"] = contact_type
        if business_service is not None:
            self.inputs["business_service"] = business_service
        if cmdb_ci is not None:
            self.inputs["cmdb_ci"] = cmdb_ci
        if close_code is not None:
            self.inputs["close_code"] = close_code
        if close_notes is not None:
            self.inputs["close_notes"] = close_notes
        if incident_id is not None:
            self.inputs["incident_id"] = incident_id
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if data_json is not None:
            self.inputs["data_json"] = data_json
        if record_id is not None:
            self.inputs["record_id"] = record_id
        if query is not None:
            self.inputs["query"] = query
        if table_sys_id is not None:
            self.inputs["table_sys_id"] = table_sys_id
        if file_content is not None:
            self.inputs["file_content"] = file_content
        if file_name is not None:
            self.inputs["file_name"] = file_name
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if attachment_id is not None:
            self.inputs["attachment_id"] = attachment_id
        if download is not None:
            self.inputs["download"] = download
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationServicenowNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
