"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("set_variable")
class SetVariableNode(Node):
    """
    Set a variable to a new value

    ## Inputs
    ### Common Inputs
        scope: The scope of the variable
        value: The new value to set the variable to
        variable_id: The ID of the variable to set
        variable_set: The ID of the variable set

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "scope",
            "helper_text": "The scope of the variable",
            "value": "",
            "type": "string",
        },
        {
            "field": "value",
            "helper_text": "The new value to set the variable to",
            "value": "",
            "type": "string",
        },
        {
            "field": "variable_id",
            "helper_text": "The ID of the variable to set",
            "value": "",
            "type": "string",
        },
        {
            "field": "variable_set",
            "helper_text": "The ID of the variable set",
            "value": {"object_type": 23, "object_id": ""},
            "type": "variable_set",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "[<variable_set>]**<scope>**<variable_id>": {
            "inputs": [
                {
                    "field": "value",
                    "label": "Set To",
                    "type": "{<variable_set>.variables.<scope>.<variable_id>.data_type}",
                    "helper_text": "The new value to set the variable to",
                    "value": "",
                    "visibility": {
                        "logic": "and",
                        "conditions": [
                            {"field": "variable_set", "operator": "exists"},
                            {"field": "variable_id", "operator": "exists"},
                        ],
                    },
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["variable_set", "scope", "variable_id"]

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = ["variable_set", "variable_id", "scope", "value"]

    def __init__(
        self,
        variable_set: Any = "",
        scope: str = "",
        variable_id: str = "",
        value: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["variable_set"] = variable_set
        params["scope"] = scope
        params["variable_id"] = variable_id

        super().__init__(
            node_type="set_variable",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if variable_set is not None:
            self.inputs["variable_set"] = variable_set
        if variable_id is not None:
            self.inputs["variable_id"] = variable_id
        if scope is not None:
            self.inputs["scope"] = scope
        if value is not None:
            self.inputs["value"] = value
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "SetVariableNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
