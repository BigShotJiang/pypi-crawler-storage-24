"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("google_search")
class GoogleSearchNode(Node):
    """
    Query the Google Search search API

    ## Inputs
    ### Common Inputs
        query: The Google search query
        location: The location of the search
        num_results: The number of results to return
        search_type: Select the search type: Web, Image, Hotels, Events, or News

    ## Outputs
    ### Common Outputs
        snippets: The snippets of the Google search results
        urls: The URLs of the Google search results
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "The Google search query",
            "value": "",
            "type": "string",
        },
        {
            "field": "location",
            "helper_text": "The location of the search",
            "value": "us",
            "type": "string",
        },
        {
            "field": "num_results",
            "helper_text": "The number of results to return",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "search_type",
            "helper_text": "Select the search type: Web, Image, Hotels, Events, or News",
            "value": "web",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "snippets",
            "helper_text": "The snippets of the Google search results",
            "type": "vec<string>",
        },
        {
            "field": "urls",
            "helper_text": "The URLs of the Google search results",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "location"},
        {"field": "query"},
        {"field": "search_type"},
    ]

    _REQUIRED_FIELDS = ["query"]

    def __init__(
        self,
        query: str = "",
        location: str = "us",
        num_results: int = 10,
        search_type: str = "web",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="google_search",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if query is not None:
            self.inputs["query"] = query
        if num_results is not None:
            self.inputs["num_results"] = num_results
        if search_type is not None:
            self.inputs["search_type"] = search_type
        if location is not None:
            self.inputs["location"] = location
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "GoogleSearchNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
