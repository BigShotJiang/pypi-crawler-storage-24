"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_slack")
class IntegrationSlackNode(Node):
    """
    Slack

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'search_messages'
        query: Search query
        highlight: Highlight search terms
        sort: Sort by (score or timestamp)
        sort_dir: Sort direction (asc or desc)
        use_date: Toggle to use dates
    ### When action = 'update_message'
        as_user: Update as user
        blocks: Block kit blocks (JSON)
        channel: The channel to kick user from
        message: The message text to send
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'delete_message'
        as_user: Update as user
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'send_message'
        attachments: Attachments to be appended.
        auto_invite_bot: Automatically invite the bot to the channel if it is not already a member. Disable if you do not want the bot to be added automatically.
        channel: The channel to kick user from
        message: The message text to send
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'send_message_to_user'
        attachments: Attachments to be appended.
        message: The message text to send
        team_id: The team workspace
        user_ids: Select user or enter comma-separated user IDs (e.g., U123,U456)
    ### When action = 'send_message_as_user'
        attachments: Attachments to be appended.
        message: The message text to send
        team_id: The team workspace
        user_ids: Select user or enter comma-separated user IDs (e.g., U123,U456)
    ### When action = 'kick_from_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        user: The user to kick from the channel
    ### When action = 'join_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'read_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'get_channel_history'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        use_date: Toggle to use dates
    ### When action = 'invite_to_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        users: Select user or enter comma-separated user IDs (e.g., U123,U456) to invite
    ### When action = 'leave_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'get_channel_members'
        channel: The channel to kick user from
        limit: Maximum number of channels to return
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'close_dm'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'rename_channel'
        channel: The channel to kick user from
        name: Name of the channel to create
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'get_channel_replies'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        thread_ts: Timestamp of the parent message(ISO 8601 or Unix timestamp)
        use_date: Toggle to use dates
    ### When action = 'set_channel_purpose'
        channel: The channel to kick user from
        purpose: Purpose for the channel
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'set_channel_topic'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        topic: Topic for the channel
    ### When action = 'archive_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'unarchive_channel'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'read_message'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        use_date: Toggle to use dates
    ### When action = 'get_message_permalink'
        channel: The channel to kick user from
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'add_reaction'
        channel: The channel to kick user from
        name: Name of the channel to create
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'remove_reaction'
        channel: The channel to kick user from
        name: Name of the channel to create
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'read_reactions'
        channel: The channel to kick user from
        full: Get full reaction details
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'add_star'
        channel: The channel to kick user from
        file: File ID (if target is file)
        file_comment: File comment ID
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'remove_star'
        channel: The channel to kick user from
        file: File ID (if target is file)
        file_comment: File comment ID
        team: The team workspace (optional, only needed for Enterprise Grid)
        timestamp: Timestamp of the message to update(ISO 8601 or timestamp)
    ### When action = 'get_files'
        channel: The channel to kick user from
        show_files_hidden_by_limit: Show files hidden by limit
        team: The team workspace (optional, only needed for Enterprise Grid)
        ts_from: Files created after this timestamp(ISO 8601 or Unix timestamp)
        ts_to: Files created before this timestamp(ISO 8601 or Unix timestamp)
        types: Types of channels to include (comma-separated)
        use_date: Toggle to use dates
        user: The user to kick from the channel
    ### When action = 'create_user_group'
        channel: The channel to kick user from
        description: Description of the user group
        handle: Handle for the user group
        include_count: Include member count
        name: Name of the channel to create
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'update_user_group'
        channel: The channel to kick user from
        description: Description of the user group
        handle: Handle for the user group
        include_count: Include member count
        name: Name of the channel to create
        team: The team workspace (optional, only needed for Enterprise Grid)
        usergroup: User group ID to enable
    ### When action = 'read_file'
        count: Number of comments to include
        file: File ID (if target is file)
        page: Page of comments
    ### When action = 'get_channel_history' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_channel_replies' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'read_message' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'search_messages' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_files' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_channel_history' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_channel_replies' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'read_message' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'search_messages' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_files' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_channels'
        exclude_archived: Exclude archived channels
        limit: Maximum number of channels to return
        types: Types of channels to include (comma-separated)
    ### When action = 'upload_file'
        filename: Name for the uploaded file
        files: File to upload
        initial_comment: Initial comment for the file
        select_team: The team workspace (for filtering channels)
        share_file_with_channels: Comma separated list of channel IDs to share with
        thread_ts: Timestamp of the parent message(ISO 8601 or Unix timestamp)
        title: Title for the file
    ### When action = 'enable_user_group'
        include_count: Include member count
        usergroup: User group ID to enable
    ### When action = 'disable_user_group'
        include_count: Include member count
        usergroup: User group ID to enable
    ### When action = 'get_user_groups'
        include_count: Include member count
        include_disabled: Include disabled user groups
        include_users: Include user list
    ### When action = 'get_user_profile'
        include_labels: Include field labels
        team: The team workspace (optional, only needed for Enterprise Grid)
        user: The user to kick from the channel
    ### When action = 'get_users'
        include_locale: Include locale information for users
        limit: Maximum number of channels to return
        team_id: The team workspace
    ### When action = 'create_channel'
        is_private: Whether the channel should be private
        name: Name of the channel to create
        team: The team workspace (optional, only needed for Enterprise Grid)
    ### When action = 'get_stars'
        limit: Maximum number of channels to return
    ### When action = 'update_user_profile'
        name: Name of the channel to create
        profile: Profile fields to update (JSON)
        team: The team workspace (optional, only needed for Enterprise Grid)
        user: The user to kick from the channel
        value: Value for single field update
    ### When action = 'get_channel_history' and use_date = False
        num_messages: Specify the number of messages to fetch
    ### When action = 'get_channel_replies' and use_date = False
        num_messages: Specify the number of messages to fetch
    ### When action = 'read_message' and use_date = False
        num_messages: Specify the number of messages to fetch
    ### When action = 'search_messages' and use_date = False
        num_messages: Specify the number of messages to fetch
    ### When action = 'get_files' and use_date = False
        num_messages: Specify the number of messages to fetch
    ### When action = 'open_dm'
        return_im: Return IM channel
        users: Select user or enter comma-separated user IDs (e.g., U123,U456) to invite
    ### When action = 'read_user'
        team: The team workspace (optional, only needed for Enterprise Grid)
        user: The user to kick from the channel
    ### When action = 'get_channel_history' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_channel_replies' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'read_message' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'search_messages' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_files' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_message'
        attachment_names: List of attachment names
        message: List of message texts
        message_details: List of detailed message objects
        sender_id: List of sender IDs
        thread_id: List of thread IDs
        thread_link: List of thread links
        total: Total number of messages
    ### When action = 'get_user_profile'
        avatar_hash: User avatar hash
        display_name: Display name
        email: Email address
        fields: Fields
        phone: Phone number
        raw_data: Raw API response data
        real_name: Real name
        skype: Skype
        status_emoji: Status emoji
        status_expiration: Status expiration
        status_text: Status text
        title: Job title
    ### When action = 'update_message'
        channel: Channel ID
        raw_data: Raw API response data
        text: Updated message text
        timestamp: Timestamp of the updated message
    ### When action = 'delete_message'
        channel: Channel ID
        raw_data: Raw API response data
        timestamp: Timestamp of the deleted message
    ### When action = 'get_message_permalink'
        channel: Channel ID
        permalink: Permalink to the message
        raw_data: Raw API response data
    ### When action = 'create_channel'
        channel_id: ID of the created channel
        channel_name: Name of the created channel
        raw_data: Raw API response data
    ### When action = 'join_channel'
        channel_id: ID of the joined channel
        channel_name: Name of the joined channel
        raw_data: Raw API response data
    ### When action = 'read_channel'
        channel_id: ID of the channel
        channel_name: Name of the channel
        created: When the channel was created
        creator: Who created the channel
        is_archived: Whether the channel is archived
        is_channel: Whether this is a channel
        is_general: Whether this is the general channel
        is_member: Whether you are a member
        is_private: Whether the channel is private
        purpose: Channel purpose
        raw_data: Raw API response data
        topic: Channel topic
    ### When action = 'invite_to_channel'
        channel_id: ID of the channel
        channel_name: Name of the channel
        raw_data: Raw API response data
    ### When action = 'open_dm'
        channel_id: ID of the opened DM channel
        raw_data: Raw API response data
    ### When action = 'rename_channel'
        channel_id: ID of the renamed channel
        channel_name: New name of the channel
        raw_data: Raw API response data
    ### When action = 'set_channel_purpose'
        channel_id: ID of the channel
        purpose: Purpose that was set
        raw_data: Raw API response data
    ### When action = 'set_channel_topic'
        channel_id: ID of the channel
        raw_data: Raw API response data
        topic: Topic that was set
    ### When action = 'send_message_to_user'
        channel_id: The DM channel ID created for this conversation
        raw_data: Raw API response data
        timestamp: Timestamp of the sent message
    ### When action = 'send_message_as_user'
        channel_id: The DM channel ID created for this conversation
        raw_data: Raw API response data
        timestamp: Timestamp of the sent message
    ### When action = 'search_messages'
        channel_id: List of matching channel IDs
        channel_name: List of matching channel names
        message_details: List of matching message details
        messages: List of matching messages
        permalink: List of matching permalinks
        query: Query that was searched
        timestamp: List of matching timestamps
        total: Total number of results
        user_id: List of matching user IDs
    ### When action = 'get_channels'
        channel_ids: List of channel IDs
        channel_names: List of channel names
        channels: List of channel objects
        raw_data: Raw API response data
        total: Total number of channels
    ### When action = 'get_stars'
        channels: List of channels
        item_types: List of item types
        items: List of starred items
        raw_data: Raw API response data
        total: Total number of starred items
    ### When action = 'read_file'
        channels: Channels the file is shared in
        comments_count: Number of comments on the file
        created: When the file was created
        file_id: ID of the file
        file_name: Name of the file
        file_size: Size of the file
        file_type: Type of the file
        permalink: Permalink to the file
        raw_data: Raw API response data
        url_private: Private URL for the file
        url_private_download: Private download URL for the file
        user: User who uploaded the file
    ### When action = 'get_files'
        created: When the file was created
        download_urls: Download URL for the file
        file_ids: List of file IDs
        file_names: List of file names
        file_types: List of file types
        files: List of file objects
        permalinks: Permalink to the file
        preview_urls: Preview URL for the file
        raw_files: List of raw file objects
        total: Total number of files
    ### When action = 'update_user_group'
        description: Description of the updated user group
        handle: Handle of the updated user group
        raw_data: Raw API response data
        usergroup_id: ID of the updated user group
        usergroup_name: Name of the updated user group
    ### When action = 'read_user'
        email: Email of the user
        is_admin: Whether the user is an admin
        is_bot: Whether the user is a bot
        is_deleted: Whether the user is deleted
        profile: User profile information
        raw_data: Raw API response data
        real_name: Real name of the user
        user_id: ID of the user
        user_name: Name of the user
    ### When action = 'get_users'
        emails: List of user emails
        is_admin: List of admin status
        is_bot: List of bot status
        is_owner: List of owner status
        raw_data: Raw API response data
        real_names: List of real names
        total: Total number of users
        user_ids: List of user IDs
        user_names: List of user names
        users: List of user objects
    ### When action = 'upload_file'
        file_ids: ID of the uploaded file
        file_names: Name of the uploaded file
        file_sizes: Size of the uploaded file
        file_types: Type of the uploaded file
        permalinks: Permalink to the file
        raw_data: Raw API response data
        url_private: Private URL for the file
        url_private_download: Private download URL for the file
    ### When action = 'enable_user_group'
        is_active: Whether the user group is active
        raw_data: Raw API response data
        usergroup_id: ID of the enabled user group
        usergroup_name: Name of the enabled user group
    ### When action = 'disable_user_group'
        is_active: Whether the user group is active
        raw_data: Raw API response data
        usergroup_id: ID of the disabled user group
        usergroup_name: Name of the disabled user group
    ### When action = 'get_channel_members'
        member_count: Number of members returned
        members: List of member IDs
        raw_data: Raw API response data
    ### When action = 'read_reactions'
        message: Message object
        message_text: Message text
        raw_data: Raw API response data
        reaction_counts: List of reaction counts
        reaction_names: List of reaction names
        reactions: List of reactions
    ### When action = 'get_channel_history'
        message_texts: List of message texts
        message_timestamps: List of message timestamps
        messages: List of message objects
        raw_data: Raw API response data
        total: Total number of messages
    ### When action = 'get_channel_replies'
        message_texts: List of reply message texts
        messages: List of reply messages
        raw_data: Raw API response data
        total: Total number of replies
    ### When action = 'update_user_profile'
        profile: Updated profile information
        raw_data: Raw API response data
    ### When action = 'kick_from_channel'
        raw_data: Raw API response data
    ### When action = 'leave_channel'
        raw_data: Raw API response data
    ### When action = 'close_dm'
        raw_data: Raw API response data
    ### When action = 'archive_channel'
        raw_data: Raw API response data
    ### When action = 'unarchive_channel'
        raw_data: Raw API response data
    ### When action = 'send_message'
        raw_data: Raw API response data
        timestamp: Timestamp of the sent message
    ### When action = 'add_reaction'
        raw_data: Raw API response data
    ### When action = 'remove_reaction'
        raw_data: Raw API response data
    ### When action = 'add_star'
        raw_data: Raw API response data
    ### When action = 'remove_star'
        raw_data: Raw API response data
    ### When action = 'create_user_group'
        raw_data: Raw API response data
        user_group_description: Description of the created user group
        user_group_handle: Handle of the created user group
        user_group_id: ID of the created user group
        user_group_name: Name of the created user group
        user_group_user_count: Count of the created user group
        user_group_users: List of user IDs in the user group
    ### When action = 'get_user_groups'
        raw_data: Raw API response data
        usergroup_handles: List of user group handles
        usergroup_ids: List of user group IDs
        usergroup_names: List of user group names
        usergroups: List of user group objects
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Slack>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (optional, only needed for Enterprise Grid)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the channel to create",
                    "label": "Channel Name",
                    "placeholder": "my-new-channel",
                    "order": 4,
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the channel should be private",
                    "label": "Private Channel",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the created channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the created channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_channel",
            "task_name": "tasks.slack.create_channel",
            "description": "Create a new Slack channel",
            "label": "Create Channel",
            "ui_sort_order": ["integration", "action", "team", "name", "is_private"],
            "required": ["name"],
        },
        "kick_from_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to kick user from",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "user",
                    "type": "string",
                    "value": "",
                    "helper_text": "The user to kick from the channel",
                    "label": "User",
                    "placeholder": "Select user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "kick_from_channel",
            "task_name": "tasks.slack.kick_from_channel",
            "description": "Kick a user from a Slack channel",
            "label": "Kick From Channel",
            "ui_sort_order": ["integration", "action", "team", "channel", "user"],
            "required": ["channel", "user"],
        },
        "join_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to join",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the joined channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the joined channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "join_channel",
            "task_name": "tasks.slack.join_channel",
            "description": "Join a Slack channel",
            "label": "Join Channel",
            "ui_sort_order": ["integration", "action", "team", "channel"],
            "required": ["channel"],
        },
        "read_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to read information about",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel",
                },
                {
                    "field": "created",
                    "type": "string",
                    "helper_text": "When the channel was created",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "helper_text": "Who created the channel",
                },
                {
                    "field": "is_archived",
                    "type": "bool",
                    "helper_text": "Whether the channel is archived",
                },
                {
                    "field": "is_channel",
                    "type": "bool",
                    "helper_text": "Whether this is a channel",
                },
                {
                    "field": "is_general",
                    "type": "bool",
                    "helper_text": "Whether this is the general channel",
                },
                {
                    "field": "is_member",
                    "type": "bool",
                    "helper_text": "Whether you are a member",
                },
                {
                    "field": "is_private",
                    "type": "bool",
                    "helper_text": "Whether the channel is private",
                },
                {"field": "topic", "type": "string", "helper_text": "Channel topic"},
                {
                    "field": "purpose",
                    "type": "string",
                    "helper_text": "Channel purpose",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_channel",
            "task_name": "tasks.slack.read_channel",
            "description": "Read details of a specific channel",
            "label": "Get Channel",
            "inputs_sort_order": ["integration", "action", "team", "channel"],
            "required": ["channel"],
        },
        "get_channels**(*)**(*)": {
            "inputs": [
                {
                    "field": "types",
                    "type": "string",
                    "value": "public_channel",
                    "helper_text": "Types of channels to include (comma-separated)",
                    "label": "Channel Types",
                    "placeholder": "public_channel,private_channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {"label": "Public Channel", "value": "public_channel"},
                            {"label": "Private Channel", "value": "private_channel"},
                            {"label": "All Types", "value": "all_types"},
                        ],
                    },
                },
                {
                    "field": "exclude_archived",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Exclude archived channels",
                    "label": "Exclude Archived",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of channels to return",
                    "label": "Limit",
                    "placeholder": "10",
                },
            ],
            "outputs": [
                {
                    "field": "channels",
                    "type": "vec<string>",
                    "helper_text": "List of channel objects",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs",
                },
                {
                    "field": "channel_names",
                    "type": "vec<string>",
                    "helper_text": "List of channel names",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of channels",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_channels",
            "task_name": "tasks.slack.get_channels",
            "description": "Get multiple channels",
            "label": "List Channels",
            "inputs_sort_order": [
                "integration",
                "action",
                "types",
                "exclude_archived",
                "limit",
            ],
        },
        "get_channel_history**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to get history from",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "messages",
                    "type": "vec<string>",
                    "helper_text": "List of message objects",
                },
                {
                    "field": "message_texts",
                    "type": "vec<string>",
                    "helper_text": "List of message texts",
                },
                {
                    "field": "message_timestamps",
                    "type": "vec<timestamp>",
                    "helper_text": "List of message timestamps",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of messages",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_channel_history",
            "task_name": "tasks.slack.get_channel_history",
            "description": "Get multiple messages from channel history",
            "label": "List Channel History",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
            ],
            "required": ["channel"],
        },
        "get_channel_history**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Messages",
                    "helper_text": "Specify the number of messages to fetch",
                    "hidden": True,
                    "order": 8,
                }
            ],
            "outputs": [],
        },
        "get_channel_history**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "hidden": True,
                    "order": 6,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "get_channel_history**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "get_channel_history**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "invite_to_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to invite users to",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "users",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select user or enter comma-separated user IDs (e.g., U123,U456) to invite",
                    "label": "Users",
                    "placeholder": "Select user or enter IDs ",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&include_bots=true&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "invite_to_channel",
            "task_name": "tasks.slack.invite_to_channel",
            "description": "Invite users to a Slack channel. Uses user credentials for inviting to channel.",
            "label": "Invite To Channel",
            "inputs_sort_order": ["integration", "action", "team", "channel", "users"],
            "required": ["channel", "users"],
        },
        "leave_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to leave",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "leave_channel",
            "task_name": "tasks.slack.leave_channel",
            "description": "Leave a Slack channel",
            "label": "Leave Channel",
            "ui_sort_order": ["integration", "action", "team", "channel"],
            "required": ["channel"],
        },
        "get_channel_members**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to get members from",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of members to return",
                    "label": "Limit",
                    "placeholder": "10",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "members",
                    "type": "vec<string>",
                    "helper_text": "List of member IDs",
                },
                {
                    "field": "member_count",
                    "type": "string",
                    "helper_text": "Number of members returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_channel_members",
            "task_name": "tasks.slack.get_channel_members",
            "description": "Get multiple channel members",
            "label": "List Channel Members",
            "inputs_sort_order": ["integration", "action", "team", "channel", "limit"],
            "required": ["channel"],
        },
        "open_dm**(*)**(*)": {
            "inputs": [
                {
                    "field": "users",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of user IDs to open DM with",
                    "label": "Users",
                    "placeholder": "user1,user2",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "return_im",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Return IM channel",
                    "label": "Return IM",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the opened DM channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "open_dm",
            "task_name": "tasks.slack.open_dm",
            "description": "Open a direct message with users",
            "label": "Open Direct Message",
            "inputs_sort_order": ["integration", "action", "users", "return_im"],
            "required": ["users"],
        },
        "close_dm**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "Channel ID of the DM to close",
                    "label": "Channel",
                    "placeholder": "C0666666666",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "close_dm",
            "task_name": "tasks.slack.close_dm",
            "description": "Close a direct message with users",
            "label": "Close Direct Message",
            "inputs_sort_order": ["integration", "action", "team", "channel"],
            "required": ["channel"],
        },
        "rename_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to rename",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the channel",
                    "label": "New Name",
                    "placeholder": "my-renamed-channel",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the renamed channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "New name of the channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "rename_channel",
            "task_name": "tasks.slack.rename_channel",
            "description": "Rename a Slack channel",
            "label": "Rename Channel",
            "ui_sort_order": ["integration", "action", "team", "channel", "name"],
            "required": ["channel", "name"],
        },
        "get_channel_replies**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the thread",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "thread_ts",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the parent message(ISO 8601 or Unix timestamp)",
                    "label": "Thread Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "messages",
                    "type": "vec<string>",
                    "helper_text": "List of reply messages",
                },
                {
                    "field": "message_texts",
                    "type": "vec<string>",
                    "helper_text": "List of reply message texts",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of replies",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_channel_replies",
            "task_name": "tasks.slack.get_channel_replies",
            "description": "Get multiple replies from a message thread",
            "label": "List Channel Replies",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "thread_ts",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
            ],
            "required": ["channel", "thread_ts"],
        },
        "get_channel_replies**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Channels",
                    "helper_text": "Specify the number of channels to fetch",
                    "hidden": True,
                    "order": 9,
                }
            ],
            "outputs": [],
        },
        "get_channel_replies**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "get_channel_replies**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                    "order": 8,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "get_channel_replies**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                    "order": 8,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "set_channel_purpose**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to set purpose for",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "purpose",
                    "type": "string",
                    "value": "",
                    "helper_text": "Purpose for the channel",
                    "label": "Purpose",
                    "placeholder": "This channel is for discussing project updates",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "purpose",
                    "type": "string",
                    "helper_text": "Purpose that was set",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "set_channel_purpose",
            "task_name": "tasks.slack.set_channel_purpose",
            "description": "Set the purpose of a Slack channel",
            "label": "Set Channel Purpose",
            "ui_sort_order": ["integration", "action", "team", "channel", "purpose"],
            "required": ["channel", "purpose"],
        },
        "set_channel_topic**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to set topic for",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "topic",
                    "type": "string",
                    "value": "",
                    "helper_text": "Topic for the channel",
                    "label": "Topic",
                    "placeholder": "Weekly standup meetings",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "topic",
                    "type": "string",
                    "helper_text": "Topic that was set",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "set_channel_topic",
            "task_name": "tasks.slack.set_channel_topic",
            "description": "Set the topic of a Slack channel",
            "label": "Set Channel Topic",
            "ui_sort_order": ["integration", "action", "team", "channel", "topic"],
            "required": ["channel", "topic"],
        },
        "archive_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to archive",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "archive_channel",
            "task_name": "tasks.slack.archive_channel",
            "description": "Archive a Slack channel",
            "label": "Archive Channel",
            "ui_sort_order": ["integration", "action", "team", "channel"],
            "required": ["channel"],
        },
        "unarchive_channel**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to unarchive",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "unarchive_channel",
            "task_name": "tasks.slack.unarchive_channel",
            "description": "Unarchive a Slack channel",
            "label": "Unarchive Channel",
            "ui_sort_order": ["integration", "action", "team", "channel"],
            "required": ["channel"],
        },
        "send_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to send message to",
                    "label": "Channel",
                    "placeholder": "General",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "auto_invite_bot",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Automatically invite the bot to the channel if it is not already a member. Disable if you do not want the bot to be added automatically.",
                    "label": "Auto-invite Bot to Channel",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "helper_text": "The message text to send",
                    "label": "Message",
                    "placeholder": "Hello, world!",
                    "order": 6,
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_message",
            "task_name": "tasks.slack.create_message",
            "description": "Send a message to a Slack channel",
            "label": "Send Message to Channel",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "auto_invite_bot",
                "message",
                "attachments",
            ],
            "required": ["channel", "message"],
        },
        "send_message_to_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select user or enter comma-separated user IDs (e.g., U123,U456)",
                    "label": "Users",
                    "placeholder": "Select user or enter IDs",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "helper_text": "The message text to send",
                    "label": "Message",
                    "placeholder": "Hello!",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments",
                    "helper_text": "Attachments to be appended.",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "The DM channel ID created for this conversation",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_message_to_user",
            "task_name": "tasks.slack.send_message_to_user",
            "description": "Send a direct message to one or more Slack users as the bot",
            "label": "Send Message via Bot",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "users",
                "message",
                "attachments",
            ],
            "required": ["user_ids", "team_id", "message"],
        },
        "send_message_as_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select user or enter comma-separated user IDs (e.g., U123,U456)",
                    "label": "Users",
                    "placeholder": "Select user or enter IDs",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&team={inputs.team_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "helper_text": "The message text to send",
                    "label": "Message",
                    "placeholder": "Hello!",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments",
                    "helper_text": "Attachments to be appended.",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "The DM channel ID created for this conversation",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp of the sent message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "send_message_as_user",
            "task_name": "tasks.slack.send_message_as_user",
            "description": "Send a direct message to one or more Slack users as the authenticated user",
            "label": "Send Message as User",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "users",
                "message",
                "attachments",
            ],
            "required": ["user_ids", "message"],
        },
        "read_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel to read messages from",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "vec<string>",
                    "helper_text": "List of message texts",
                },
                {
                    "field": "thread_id",
                    "type": "vec<string>",
                    "helper_text": "List of thread IDs",
                },
                {
                    "field": "attachment_names",
                    "type": "vec<string>",
                    "helper_text": "List of attachment names",
                },
                {
                    "field": "sender_id",
                    "type": "vec<string>",
                    "helper_text": "List of sender IDs",
                },
                {
                    "field": "thread_link",
                    "type": "vec<string>",
                    "helper_text": "List of thread links",
                },
                {
                    "field": "message_details",
                    "type": "vec<string>",
                    "helper_text": "List of detailed message objects",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of messages",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_message",
            "task_name": "tasks.slack.read_messages",
            "description": "Get multiple messages",
            "label": "List Messages",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
            ],
            "required": ["channel"],
        },
        "read_message**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Messages",
                    "helper_text": "Specify the number of messages to fetch",
                    "hidden": True,
                    "order": 8,
                }
            ],
            "outputs": [],
        },
        "read_message**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "read_message**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "read_message**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "update_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the message",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message to update(ISO 8601 or timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "helper_text": "New message text",
                    "label": "Message",
                    "placeholder": "Updated message text",
                    "order": 6,
                },
                {
                    "field": "blocks",
                    "type": "string",
                    "value": "",
                    "helper_text": "Block kit blocks (JSON)",
                    "label": "Blocks",
                    "placeholder": "Blocks",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "as_user",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Update as user",
                    "label": "As User",
                    "order": 9,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp of the updated message",
                },
                {"field": "channel", "type": "string", "helper_text": "Channel ID"},
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "Updated message text",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_message",
            "task_name": "tasks.slack.update_message",
            "description": "Update a message in Slack",
            "label": "Update Message",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "message",
                "blocks",
                "as_user",
            ],
            "required": ["channel", "timestamp", "message"],
        },
        "delete_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the message",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message to delete(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
                {
                    "field": "as_user",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Delete as user",
                    "label": "As User",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {"field": "channel", "type": "string", "helper_text": "Channel ID"},
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "Timestamp of the deleted message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_message",
            "task_name": "tasks.slack.delete_message",
            "description": "Delete a message in Slack",
            "label": "Delete Message",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "as_user",
            ],
            "required": ["channel", "timestamp"],
        },
        "get_message_permalink**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the message",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "Permalink to the message",
                },
                {"field": "channel", "type": "string", "helper_text": "Channel ID"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_message_permalink",
            "task_name": "tasks.slack.get_message_permalink",
            "description": "Read details of a specific message permalink",
            "label": "Get Message Permalink",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
            ],
            "required": ["channel", "timestamp"],
        },
        "search_messages**(*)**(*)": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query",
                    "label": "Query",
                    "placeholder": "hello world",
                    "order": 3,
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "score",
                    "helper_text": "Sort by (score or timestamp)",
                    "label": "Sort",
                    "placeholder": "score",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sort_dir",
                    "type": "string",
                    "value": "desc",
                    "helper_text": "Sort direction (asc or desc)",
                    "label": "Sort Direction",
                    "placeholder": "desc",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "highlight",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Highlight search terms",
                    "label": "Highlight",
                    "order": 8,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "messages",
                    "type": "vec<string>",
                    "helper_text": "List of matching messages",
                },
                {
                    "field": "channel_id",
                    "type": "vec<string>",
                    "helper_text": "List of matching channel IDs",
                },
                {
                    "field": "channel_name",
                    "type": "vec<string>",
                    "helper_text": "List of matching channel names",
                },
                {
                    "field": "user_id",
                    "type": "vec<string>",
                    "helper_text": "List of matching user IDs",
                },
                {
                    "field": "timestamp",
                    "type": "vec<string>",
                    "helper_text": "List of matching timestamps",
                },
                {
                    "field": "permalink",
                    "type": "vec<string>",
                    "helper_text": "List of matching permalinks",
                },
                {
                    "field": "message_details",
                    "type": "vec<string>",
                    "helper_text": "List of matching message details",
                },
                {
                    "field": "total",
                    "type": "string",
                    "helper_text": "Total number of results",
                },
                {
                    "field": "query",
                    "type": "string",
                    "helper_text": "Query that was searched",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "search_messages",
            "task_name": "tasks.slack.search_messages",
            "description": "Search for messages in Slack",
            "label": "Search Messages",
            "ui_sort_order": [
                "integration",
                "action",
                "query",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "sort",
                "sort_dir",
                "highlight",
            ],
            "required": ["query"],
        },
        "search_messages**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Messages",
                    "helper_text": "Specify the number of messages to fetch",
                    "hidden": True,
                    "order": 8,
                }
            ],
            "outputs": [],
        },
        "search_messages**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "search_messages**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "search_messages**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "add_reaction**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the message",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the emoji reaction",
                    "label": "Emoji Name",
                    "placeholder": "Select emoji",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=emoji&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "add_reaction",
            "task_name": "tasks.slack.add_reaction",
            "description": "Add a reaction to a Slack message",
            "label": "Add Reaction",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "name",
            ],
            "required": ["channel", "timestamp", "name"],
        },
        "remove_reaction**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the message",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the emoji reaction",
                    "label": "Emoji Name",
                    "placeholder": "Select emoji",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=emoji&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "remove_reaction",
            "task_name": "tasks.slack.remove_reaction",
            "description": "Remove a reaction from a Slack message",
            "label": "Remove Reaction",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "name",
            ],
            "required": ["channel", "timestamp", "name"],
        },
        "read_reactions**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the message",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                },
                {
                    "field": "full",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Get full reaction details",
                    "label": "Full Details",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "reactions",
                    "type": "vec<string>",
                    "helper_text": "List of reactions",
                },
                {
                    "field": "reaction_names",
                    "type": "vec<string>",
                    "helper_text": "List of reaction names",
                },
                {
                    "field": "reaction_counts",
                    "type": "vec<string>",
                    "helper_text": "List of reaction counts",
                },
                {"field": "message", "type": "string", "helper_text": "Message object"},
                {
                    "field": "message_text",
                    "type": "string",
                    "helper_text": "Message text",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_reactions",
            "task_name": "tasks.slack.read_reactions",
            "description": "Get multiple reactions from a message",
            "label": "List Reactions",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "full",
            ],
            "required": ["channel", "timestamp"],
        },
        "add_star**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the item",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message (if target is message)(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "file",
                    "type": "string",
                    "value": "",
                    "helper_text": "File ID (if target is file)",
                    "label": "File",
                    "placeholder": "F1234567890",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "file_comment",
                    "type": "string",
                    "value": "",
                    "helper_text": "File comment ID",
                    "label": "File Comment",
                    "placeholder": "Optional file comment ID",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "add_star",
            "task_name": "tasks.slack.add_star",
            "description": "Add a star to a Slack item",
            "label": "Add Star",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "file",
                "file_comment",
            ],
            "required": ["channel"],
        },
        "remove_star**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "The channel containing the item",
                    "label": "Channel",
                    "placeholder": "General",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "helper_text": "Timestamp of the message(ISO 8601 or Unix timestamp)",
                    "label": "Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "file",
                    "type": "string",
                    "value": "",
                    "helper_text": "File ID",
                    "label": "File",
                    "placeholder": "F1234567890",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "file_comment",
                    "type": "string",
                    "value": "",
                    "helper_text": "File comment ID",
                    "label": "File Comment",
                    "placeholder": "Optional file comment ID",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "remove_star",
            "task_name": "tasks.slack.remove_star",
            "description": "Remove a star from a Slack item",
            "label": "Remove Star",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "timestamp",
                "file",
                "file_comment",
            ],
            "required": ["channel"],
        },
        "get_stars**(*)**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of stars to return",
                    "label": "Limit",
                    "placeholder": "10",
                    "order": 3,
                }
            ],
            "outputs": [
                {
                    "field": "items",
                    "type": "vec<string>",
                    "helper_text": "List of starred items",
                },
                {
                    "field": "item_types",
                    "type": "vec<string>",
                    "helper_text": "List of item types",
                },
                {
                    "field": "channels",
                    "type": "vec<string>",
                    "helper_text": "List of channels",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of starred items",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_stars",
            "task_name": "tasks.slack.get_stars",
            "description": "Get multiple starred items",
            "label": "List Starred Items",
            "inputs_sort_order": ["integration", "action", "limit"],
        },
        "upload_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "files",
                    "type": "vec<file>",
                    "value": [],
                    "helper_text": "File to upload",
                    "label": "File",
                    "placeholder": "Select file to upload",
                    "order": 3,
                },
                {
                    "field": "filename",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name for the uploaded file",
                    "label": "Filename",
                    "placeholder": "document.txt",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title for the file",
                    "label": "Title",
                    "placeholder": "My Document",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "select_team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "share_file_with_channels",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma separated list of channel IDs to share with",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.select_team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "initial_comment",
                    "type": "string",
                    "value": "",
                    "helper_text": "Initial comment for the file",
                    "label": "Initial Comment",
                    "placeholder": "Here's the file you requested",
                    "order": 8,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "thread_ts",
                    "type": "string",
                    "value": "",
                    "helper_text": "Thread timestamp to reply to(ISO 8601 or Unix timestamp)",
                    "label": "Thread Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 9,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "ID of the uploaded file",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "file_types",
                    "type": "vec<string>",
                    "helper_text": "Type of the uploaded file",
                },
                {
                    "field": "file_sizes",
                    "type": "vec<string>",
                    "helper_text": "Size of the uploaded file",
                },
                {
                    "field": "url_private",
                    "type": "string",
                    "helper_text": "Private URL for the file",
                },
                {
                    "field": "url_private_download",
                    "type": "string",
                    "helper_text": "Private download URL for the file",
                },
                {
                    "field": "permalinks",
                    "type": "vec<string>",
                    "helper_text": "Permalink to the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "upload_file",
            "task_name": "tasks.slack.upload_file",
            "description": "Upload a file to Slack",
            "label": "Upload File",
            "ui_sort_order": [
                "integration",
                "action",
                "files",
                "filename",
                "title",
                "select_team",
                "share_file_with_channels",
                "initial_comment",
                "thread_ts",
            ],
            "required": ["files"],
        },
        "read_file**(*)**(*)": {
            "inputs": [
                {
                    "field": "file",
                    "type": "string",
                    "value": "",
                    "helper_text": "File ID to read",
                    "label": "File",
                    "placeholder": "F1234567890",
                    "order": 3,
                },
                {
                    "field": "count",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Number of comments to include",
                    "label": "Comment Count",
                    "placeholder": "10",
                    "order": 4,
                },
                {
                    "field": "page",
                    "type": "int32",
                    "value": 1,
                    "helper_text": "Page of comments",
                    "label": "Comment Page",
                    "placeholder": "1",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {"field": "file_id", "type": "string", "helper_text": "ID of the file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_type",
                    "type": "string",
                    "helper_text": "Type of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file",
                },
                {
                    "field": "created",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "User who uploaded the file",
                },
                {
                    "field": "url_private",
                    "type": "string",
                    "helper_text": "Private URL for the file",
                },
                {
                    "field": "url_private_download",
                    "type": "string",
                    "helper_text": "Private download URL for the file",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "Permalink to the file",
                },
                {
                    "field": "channels",
                    "type": "vec<string>",
                    "helper_text": "Channels the file is shared in",
                },
                {
                    "field": "comments_count",
                    "type": "string",
                    "helper_text": "Number of comments on the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_file",
            "task_name": "tasks.slack.read_file",
            "description": "Read details of a specific file",
            "label": "Get File",
            "inputs_sort_order": ["integration", "action", "file", "count", "page"],
            "required": ["file", "count"],
        },
        "get_files**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by channel",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "user",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by user",
                    "label": "User",
                    "placeholder": "Select user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "types",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by file types (comma-separated)",
                    "label": "Types",
                    "placeholder": "images,docs",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "ts_from",
                    "type": "string",
                    "value": "",
                    "helper_text": "Files created after this timestamp(ISO 8601 or Unix timestamp)",
                    "label": "From Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "ts_to",
                    "type": "string",
                    "value": "",
                    "helper_text": "Files created before this timestamp(ISO 8601 or Unix timestamp)",
                    "label": "To Timestamp",
                    "placeholder": "2006-01-02T15:04:05.999999999-07:00",
                    "order": 8,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "show_files_hidden_by_limit",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Show files hidden by limit",
                    "label": "Show Hidden Files",
                    "order": 9,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                    "hidden": True,
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "files",
                    "type": "vec<file>",
                    "helper_text": "List of file objects",
                },
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "List of file IDs",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "List of file names",
                },
                {
                    "field": "file_types",
                    "type": "vec<string>",
                    "helper_text": "List of file types",
                },
                {
                    "field": "created",
                    "type": "vec<timestamp>",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "preview_urls",
                    "type": "vec<string>",
                    "helper_text": "Preview URL for the file",
                },
                {
                    "field": "download_urls",
                    "type": "vec<string>",
                    "helper_text": "Download URL for the file",
                },
                {
                    "field": "permalinks",
                    "type": "vec<string>",
                    "helper_text": "Permalink to the file",
                },
                {
                    "field": "raw_files",
                    "type": "vec<string>",
                    "helper_text": "List of raw file objects",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of files",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_files",
            "task_name": "tasks.slack.get_files",
            "description": "Get multiple files",
            "label": "List Files",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "channel",
                "user",
                "types",
                "ts_from",
                "ts_to",
                "show_files_hidden_by_limit",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
            ],
        },
        "get_files**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Files",
                    "helper_text": "Specify the number of files to fetch",
                    "hidden": True,
                    "order": 8,
                }
            ],
            "outputs": [],
        },
        "get_files**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "get_files**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "get_files**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                    "order": 7,
                    "section": "additional_fields_dropdown",
                }
            ],
            "outputs": [],
        },
        "read_user**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "user",
                    "type": "string",
                    "value": "",
                    "helper_text": "User ID to read",
                    "label": "User",
                    "placeholder": "Select user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user",
                },
                {
                    "field": "real_name",
                    "type": "string",
                    "helper_text": "Real name of the user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email of the user",
                },
                {
                    "field": "is_admin",
                    "type": "bool",
                    "helper_text": "Whether the user is an admin",
                },
                {
                    "field": "is_bot",
                    "type": "bool",
                    "helper_text": "Whether the user is a bot",
                },
                {
                    "field": "is_deleted",
                    "type": "bool",
                    "helper_text": "Whether the user is deleted",
                },
                {
                    "field": "profile",
                    "type": "string",
                    "helper_text": "User profile information",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_user",
            "task_name": "tasks.slack.read_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "inputs_sort_order": ["integration", "action", "team", "user"],
            "required": ["user"],
        },
        "get_users**(*)**(*)": {
            "inputs": [
                {
                    "field": "team_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Team ID to filter users",
                    "label": "Team",
                    "placeholder": "Select team",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of users to return",
                    "label": "Limit",
                    "placeholder": "10",
                    "order": 4,
                },
                {
                    "field": "include_locale",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include locale information for users",
                    "label": "Include Locale",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "users",
                    "type": "vec<string>",
                    "helper_text": "List of user objects",
                },
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user names",
                },
                {
                    "field": "real_names",
                    "type": "vec<string>",
                    "helper_text": "List of real names",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "List of user emails",
                },
                {
                    "field": "is_admin",
                    "type": "vec<bool>",
                    "helper_text": "List of admin status",
                },
                {
                    "field": "is_owner",
                    "type": "vec<bool>",
                    "helper_text": "List of owner status",
                },
                {
                    "field": "is_bot",
                    "type": "vec<bool>",
                    "helper_text": "List of bot status",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of users",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_users",
            "task_name": "tasks.slack.get_users",
            "description": "Get multiple users",
            "label": "List Users",
            "inputs_sort_order": [
                "integration",
                "action",
                "team_id",
                "limit",
                "include_locale",
            ],
        },
        "get_user_profile**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "user",
                    "type": "string",
                    "value": "",
                    "helper_text": "User ID to get profile for",
                    "label": "User",
                    "placeholder": "Select user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "include_labels",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include field labels",
                    "label": "Include Labels",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "avatar_hash",
                    "type": "string",
                    "helper_text": "User avatar hash",
                },
                {
                    "field": "display_name",
                    "type": "string",
                    "helper_text": "Display name",
                },
                {"field": "real_name", "type": "string", "helper_text": "Real name"},
                {"field": "email", "type": "string", "helper_text": "Email address"},
                {"field": "phone", "type": "string", "helper_text": "Phone number"},
                {"field": "title", "type": "string", "helper_text": "Job title"},
                {
                    "field": "status_text",
                    "type": "string",
                    "helper_text": "Status text",
                },
                {
                    "field": "status_emoji",
                    "type": "string",
                    "helper_text": "Status emoji",
                },
                {
                    "field": "status_expiration",
                    "type": "string",
                    "helper_text": "Status expiration",
                },
                {"field": "skype", "type": "string", "helper_text": "Skype"},
                {"field": "fields", "type": "string", "helper_text": "Fields"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_user_profile",
            "task_name": "tasks.slack.get_user_profile",
            "description": "Read details of a specific user profile",
            "label": "Get User Profile",
            "inputs_sort_order": [
                "integration",
                "action",
                "team",
                "user",
                "include_labels",
            ],
            "required": ["user"],
        },
        "update_user_profile**(*)**(*)": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "user",
                    "type": "string",
                    "value": "",
                    "helper_text": "User ID to update profile for",
                    "label": "User",
                    "placeholder": "Select user",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "profile",
                    "type": "string",
                    "value": "",
                    "helper_text": "Profile fields to update (JSON)",
                    "label": "Profile",
                    "placeholder": '{"display_name": "New Name"}',
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Single field name to update",
                    "label": "Field Name",
                    "placeholder": "display_name",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "helper_text": "Value for single field update",
                    "label": "Field Value",
                    "placeholder": "New Name",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "profile",
                    "type": "string",
                    "helper_text": "Updated profile information",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_user_profile",
            "task_name": "tasks.slack.update_user_profile",
            "description": "Update profile information for a Slack user",
            "label": "Update User Profile",
            "ui_sort_order": [
                "integration",
                "action",
                "team",
                "user",
                "profile",
                "name",
                "value",
            ],
            "required": ["user"],
        },
        "create_user_group**(*)**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the user group",
                    "label": "Name",
                    "placeholder": "engineering-team",
                    "order": 3,
                },
                {
                    "field": "handle",
                    "type": "string",
                    "value": "",
                    "helper_text": "Handle for the user group",
                    "label": "Handle",
                    "placeholder": "engineering",
                    "order": 4,
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the user group",
                    "label": "Description",
                    "placeholder": "Engineering team members",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma separated list of channel IDs",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_count",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Include member count",
                    "label": "Include Count",
                    "order": 8,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "user_group_id",
                    "type": "string",
                    "helper_text": "ID of the created user group",
                },
                {
                    "field": "user_group_name",
                    "type": "string",
                    "helper_text": "Name of the created user group",
                },
                {
                    "field": "user_group_users",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs in the user group",
                },
                {
                    "field": "user_group_user_count",
                    "type": "int32",
                    "helper_text": "Count of the created user group",
                },
                {
                    "field": "user_group_handle",
                    "type": "string",
                    "helper_text": "Handle of the created user group",
                },
                {
                    "field": "user_group_description",
                    "type": "string",
                    "helper_text": "Description of the created user group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_user_group",
            "task_name": "tasks.slack.create_user_group",
            "description": "Create a new user group in Slack",
            "label": "Create User Group",
            "ui_sort_order": [
                "integration",
                "action",
                "name",
                "handle",
                "description",
                "team",
                "channel",
                "include_count",
            ],
            "required": ["name", "handle"],
        },
        "enable_user_group**(*)**(*)": {
            "inputs": [
                {
                    "field": "usergroup",
                    "type": "string",
                    "value": "",
                    "helper_text": "User group ID to enable",
                    "label": "User Group",
                    "placeholder": "Select user group",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_group&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "include_count",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include member count",
                    "label": "Include Count",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "usergroup_id",
                    "type": "string",
                    "helper_text": "ID of the enabled user group",
                },
                {
                    "field": "usergroup_name",
                    "type": "string",
                    "helper_text": "Name of the enabled user group",
                },
                {
                    "field": "is_active",
                    "type": "bool",
                    "helper_text": "Whether the user group is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "enable_user_group",
            "task_name": "tasks.slack.enable_user_group",
            "description": "Enable a user group in Slack",
            "label": "Enable User Group",
            "ui_sort_order": ["integration", "action", "usergroup", "include_count"],
            "required": ["usergroup"],
        },
        "disable_user_group**(*)**(*)": {
            "inputs": [
                {
                    "field": "usergroup",
                    "type": "string",
                    "value": "",
                    "helper_text": "User group ID to disable",
                    "label": "User Group",
                    "placeholder": "Select user group",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_group&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "include_count",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include member count",
                    "label": "Include Count",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "usergroup_id",
                    "type": "string",
                    "helper_text": "ID of the disabled user group",
                },
                {
                    "field": "usergroup_name",
                    "type": "string",
                    "helper_text": "Name of the disabled user group",
                },
                {
                    "field": "is_active",
                    "type": "bool",
                    "helper_text": "Whether the user group is active",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "disable_user_group",
            "task_name": "tasks.slack.disable_user_group",
            "description": "Disable a user group in Slack",
            "label": "Disable User Group",
            "ui_sort_order": ["integration", "action", "usergroup", "include_count"],
            "required": ["usergroup"],
        },
        "get_user_groups**(*)**(*)": {
            "inputs": [
                {
                    "field": "include_disabled",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include disabled user groups",
                    "label": "Include Disabled",
                    "order": 3,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_count",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include member count",
                    "label": "Include Count",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_users",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include user list",
                    "label": "Include Users",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "usergroups",
                    "type": "vec<string>",
                    "helper_text": "List of user group objects",
                },
                {
                    "field": "usergroup_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user group IDs",
                },
                {
                    "field": "usergroup_names",
                    "type": "vec<string>",
                    "helper_text": "List of user group names",
                },
                {
                    "field": "usergroup_handles",
                    "type": "vec<string>",
                    "helper_text": "List of user group handles",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_user_groups",
            "task_name": "tasks.slack.get_user_groups",
            "description": "Get multiple user groups",
            "label": "List User Groups",
            "inputs_sort_order": [
                "integration",
                "action",
                "include_disabled",
                "include_count",
                "include_users",
            ],
        },
        "update_user_group**(*)**(*)": {
            "inputs": [
                {
                    "field": "usergroup",
                    "type": "string",
                    "value": "",
                    "helper_text": "User group ID to update",
                    "label": "User Group",
                    "placeholder": "Select user group",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=user_group&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the user group",
                    "label": "Name",
                    "placeholder": "new-engineering-team",
                    "order": 4,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "handle",
                    "type": "string",
                    "value": "",
                    "helper_text": "New handle for the user group",
                    "label": "Handle",
                    "placeholder": "new-engineering",
                    "order": 5,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the user group",
                    "label": "Description",
                    "placeholder": "Updated engineering team",
                    "order": 6,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "helper_text": "The team workspace (for filtering channels)",
                    "label": "Team",
                    "placeholder": "Vectorshift",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma separated list of channel IDs",
                    "label": "Channel",
                    "placeholder": "Select channel",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 8,
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_count",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include member count",
                    "label": "Include Count",
                    "order": 9,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "usergroup_id",
                    "type": "string",
                    "helper_text": "ID of the updated user group",
                },
                {
                    "field": "usergroup_name",
                    "type": "string",
                    "helper_text": "Name of the updated user group",
                },
                {
                    "field": "handle",
                    "type": "string",
                    "helper_text": "Handle of the updated user group",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the updated user group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_user_group",
            "task_name": "tasks.slack.update_user_group",
            "description": "Update a user group in Slack",
            "label": "Update User Group",
            "ui_sort_order": [
                "integration",
                "action",
                "usergroup",
                "name",
                "handle",
                "description",
                "team",
                "channel",
                "include_count",
            ],
            "required": ["usergroup"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "num_messages", "limit"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        as_user: bool = False,
        attachments: List[str] = [],
        auto_invite_bot: bool = True,
        blocks: str = "",
        channel: str = "",
        count: int = 10,
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        description: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        exclude_archived: bool = True,
        file: str = "",
        file_comment: str = "",
        filename: str = "",
        files: List[str] = [],
        full: bool = False,
        handle: str = "",
        highlight: bool = True,
        include_count: bool = True,
        include_disabled: bool = False,
        include_labels: bool = False,
        include_locale: bool = False,
        include_users: bool = False,
        initial_comment: str = "",
        is_private: bool = False,
        limit: int = 10,
        message: str = "",
        name: str = "",
        num_messages: int = 10,
        page: int = 1,
        profile: str = "",
        purpose: str = "",
        return_im: bool = True,
        select_team: str = "",
        share_file_with_channels: str = "",
        show_files_hidden_by_limit: bool = False,
        sort: str = "score",
        sort_dir: str = "desc",
        team: str = "",
        team_id: str = "",
        thread_ts: str = "",
        timestamp: str = "",
        title: str = "",
        topic: str = "",
        ts_from: str = "",
        ts_to: str = "",
        types: str = "public_channel",
        user: str = "",
        user_ids: str = "",
        usergroup: str = "",
        users: str = "",
        value: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_slack",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if team is not None:
            self.inputs["team"] = team
        if name is not None:
            self.inputs["name"] = name
        if is_private is not None:
            self.inputs["is_private"] = is_private
        if channel is not None:
            self.inputs["channel"] = channel
        if user is not None:
            self.inputs["user"] = user
        if types is not None:
            self.inputs["types"] = types
        if exclude_archived is not None:
            self.inputs["exclude_archived"] = exclude_archived
        if limit is not None:
            self.inputs["limit"] = limit
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if users is not None:
            self.inputs["users"] = users
        if return_im is not None:
            self.inputs["return_im"] = return_im
        if thread_ts is not None:
            self.inputs["thread_ts"] = thread_ts
        if purpose is not None:
            self.inputs["purpose"] = purpose
        if topic is not None:
            self.inputs["topic"] = topic
        if auto_invite_bot is not None:
            self.inputs["auto_invite_bot"] = auto_invite_bot
        if message is not None:
            self.inputs["message"] = message
        if attachments is not None:
            self.inputs["attachments"] = attachments
        if team_id is not None:
            self.inputs["team_id"] = team_id
        if user_ids is not None:
            self.inputs["user_ids"] = user_ids
        if timestamp is not None:
            self.inputs["timestamp"] = timestamp
        if blocks is not None:
            self.inputs["blocks"] = blocks
        if as_user is not None:
            self.inputs["as_user"] = as_user
        if query is not None:
            self.inputs["query"] = query
        if sort is not None:
            self.inputs["sort"] = sort
        if sort_dir is not None:
            self.inputs["sort_dir"] = sort_dir
        if highlight is not None:
            self.inputs["highlight"] = highlight
        if full is not None:
            self.inputs["full"] = full
        if file is not None:
            self.inputs["file"] = file
        if file_comment is not None:
            self.inputs["file_comment"] = file_comment
        if files is not None:
            self.inputs["files"] = files
        if filename is not None:
            self.inputs["filename"] = filename
        if title is not None:
            self.inputs["title"] = title
        if select_team is not None:
            self.inputs["select_team"] = select_team
        if share_file_with_channels is not None:
            self.inputs["share_file_with_channels"] = share_file_with_channels
        if initial_comment is not None:
            self.inputs["initial_comment"] = initial_comment
        if count is not None:
            self.inputs["count"] = count
        if page is not None:
            self.inputs["page"] = page
        if ts_from is not None:
            self.inputs["ts_from"] = ts_from
        if ts_to is not None:
            self.inputs["ts_to"] = ts_to
        if show_files_hidden_by_limit is not None:
            self.inputs["show_files_hidden_by_limit"] = show_files_hidden_by_limit
        if include_locale is not None:
            self.inputs["include_locale"] = include_locale
        if include_labels is not None:
            self.inputs["include_labels"] = include_labels
        if profile is not None:
            self.inputs["profile"] = profile
        if value is not None:
            self.inputs["value"] = value
        if handle is not None:
            self.inputs["handle"] = handle
        if description is not None:
            self.inputs["description"] = description
        if include_count is not None:
            self.inputs["include_count"] = include_count
        if usergroup is not None:
            self.inputs["usergroup"] = usergroup
        if include_disabled is not None:
            self.inputs["include_disabled"] = include_disabled
        if include_users is not None:
            self.inputs["include_users"] = include_users
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSlackNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
