"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("deep_research")
class DeepResearchNode(Node):
    """
    Perform advanced AI research and analysis with specialized model capabilities

    ## Inputs
    ### Common Inputs
        model: Select the LLM model for deep research
        conversation: Previous conversation context for research continuity
        input: The data input for deep research analysis
        instructions: Specific instructions for the deep research task
        max_output_tokens: Maximum number of tokens in the research output
        max_tool_calls: Maximum number of tool calls during research
        parallel_tool_calls: Enable parallel tool execution for faster research
        previous_response_id: ID of previous response for continuation
        prompt_cache_key: Cache key for prompt optimization
        provider: Select the LLM provider for deep research
        safety_identifier: Safety identifier for content filtering
        service_tier: Service tier for the research request
        stream: Whether to stream the research response
        tool_choice: Specific tool choice for research
        tools: Tools to use for research
        truncation: Truncation strategy for long inputs
        use_personal_api_key: Whether to use a personal API key
    ### When stream = True
        api_key: Your personal API key for the research provider
    ### When provider = 'azure'
        deployment_id: The deployment ID for the Azure OpenAI model
        endpoint: The Azure OpenAI endpoint URL
    ### When provider = 'openai'
        finetuned_model: Use your finetuned model for deep research

    ## Outputs
    ### Common Outputs
        conversation: The updated conversation including the research response
        created_at: Timestamp when the research was created
        credits_used: Number of credits consumed
        error: Error message if research failed
        id: The unique ID of the research response
        incomplete_details: Details about incomplete research
        input_tokens: Number of input tokens used
        output_tokens: Number of output tokens generated
        response: The research output and findings
        tokens_used: Total number of tokens used in research
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the LLM model for deep research",
            "value": "o3-deep-research",
            "type": "string",
        },
        {
            "field": "conversation",
            "helper_text": "Previous conversation context for research continuity",
            "value": "",
            "type": "string",
        },
        {
            "field": "input",
            "helper_text": "The data input for deep research analysis",
            "value": "",
            "type": "string",
        },
        {
            "field": "instructions",
            "helper_text": "Specific instructions for the deep research task",
            "value": "",
            "type": "string",
        },
        {
            "field": "max_output_tokens",
            "helper_text": "Maximum number of tokens in the research output",
            "value": 128000,
            "type": "int32",
        },
        {
            "field": "max_tool_calls",
            "helper_text": "Maximum number of tool calls during research",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "parallel_tool_calls",
            "helper_text": "Enable parallel tool execution for faster research",
            "value": True,
            "type": "bool",
        },
        {
            "field": "previous_response_id",
            "helper_text": "ID of previous response for continuation",
            "value": "",
            "type": "string",
        },
        {
            "field": "prompt_cache_key",
            "helper_text": "Cache key for prompt optimization",
            "value": "",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "Select the LLM provider for deep research",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "safety_identifier",
            "helper_text": "Safety identifier for content filtering",
            "value": "",
            "type": "string",
        },
        {
            "field": "service_tier",
            "helper_text": "Service tier for the research request",
            "value": "",
            "type": "string",
        },
        {
            "field": "stream",
            "helper_text": "Whether to stream the research response",
            "value": False,
            "type": "bool",
        },
        {
            "field": "tool_choice",
            "helper_text": "Specific tool choice for research",
            "value": "",
            "type": "string",
        },
        {
            "field": "tools",
            "helper_text": "Tools to use for research",
            "value": [{"type": "web_search_preview"}],
            "type": "vec<map<string, any>>",
        },
        {
            "field": "truncation",
            "helper_text": "Truncation strategy for long inputs",
            "value": "",
            "type": "string",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "Whether to use a personal API key",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "conversation",
            "helper_text": "The updated conversation including the research response",
            "type": "string",
        },
        {
            "field": "created_at",
            "helper_text": "Timestamp when the research was created",
            "type": "string",
        },
        {
            "field": "credits_used",
            "helper_text": "Number of credits consumed",
            "type": "float",
        },
        {
            "field": "error",
            "helper_text": "Error message if research failed",
            "type": "string",
        },
        {
            "field": "id",
            "helper_text": "The unique ID of the research response",
            "type": "string",
        },
        {
            "field": "incomplete_details",
            "helper_text": "Details about incomplete research",
            "type": "string",
        },
        {
            "field": "input_tokens",
            "helper_text": "Number of input tokens used",
            "type": "int64",
        },
        {
            "field": "output_tokens",
            "helper_text": "Number of output tokens generated",
            "type": "int64",
        },
        {
            "field": "response",
            "helper_text": "The research output and findings",
            "type": "string",
        },
        {
            "field": "tokens_used",
            "helper_text": "Total number of tokens used in research",
            "type": "int64",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**true": {
            "inputs": [],
            "outputs": [
                {
                    "field": "response",
                    "type": "stream<string>",
                    "helper_text": "The research response as a stream of text",
                }
            ],
        },
        "(*)**(*)**false": {
            "inputs": [],
            "outputs": [
                {
                    "field": "response",
                    "type": "string",
                    "helper_text": "The research response as a single string",
                }
            ],
        },
        "(*)**true**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Your personal API key for the research provider",
                    "section": "advanced_settings",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "openai**(*)**(*)": {
            "inputs": [
                {
                    "field": "finetuned_model",
                    "type": "string",
                    "value": "",
                    "helper_text": "Use your finetuned model for deep research",
                    "visibility": {
                        "logic": "AND",
                        "conditions": [
                            {
                                "field": "use_finetuned_model",
                                "operator": "==",
                                "value": True,
                            },
                            {
                                "field": "use_personal_api_key",
                                "operator": "==",
                                "value": True,
                            },
                        ],
                    },
                    "label": "Finetuned Model",
                    "section": "advanced_settings",
                    "component": {"type": "text", "is_advanced_setting": True},
                }
            ],
            "outputs": [],
            "title": "OpenAI Deep Research",
        },
        "azure**(*)**(*)": {
            "inputs": [
                {
                    "field": "endpoint",
                    "type": "string",
                    "value": "",
                    "helper_text": "The Azure OpenAI endpoint URL",
                    "label": "Endpoint",
                    "section": "advanced_settings",
                    "component": {"type": "text", "is_advanced_setting": True},
                },
                {
                    "field": "deployment_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The deployment ID for the Azure OpenAI model",
                    "label": "Deployment ID",
                    "section": "advanced_settings",
                    "component": {"type": "text", "is_advanced_setting": True},
                },
            ],
            "outputs": [],
            "title": "Azure Deep Research",
        },
        "anthropic**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "title": "Anthropic Deep Research",
        },
        "google**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "title": "Google Deep Research",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["provider", "stream", "use_personal_api_key"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["api_key"]

    def __init__(
        self,
        provider: str = "openai",
        stream: bool = False,
        use_personal_api_key: bool = False,
        model: str = "o3-deep-research",
        api_key: str = "",
        conversation: str = "",
        deployment_id: str = "",
        endpoint: str = "",
        finetuned_model: str = "",
        input: str = "",
        instructions: str = "",
        max_output_tokens: int = 128000,
        max_tool_calls: int = 10,
        parallel_tool_calls: bool = True,
        previous_response_id: str = "",
        prompt_cache_key: str = "",
        safety_identifier: str = "",
        service_tier: str = "",
        tool_choice: str = "",
        tools: List[Dict[str, Any]] = [{"type": "web_search_preview"}],
        truncation: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["provider"] = provider
        params["stream"] = stream
        params["use_personal_api_key"] = use_personal_api_key

        super().__init__(
            node_type="deep_research",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if input is not None:
            self.inputs["input"] = input
        if instructions is not None:
            self.inputs["instructions"] = instructions
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if conversation is not None:
            self.inputs["conversation"] = conversation
        if max_output_tokens is not None:
            self.inputs["max_output_tokens"] = max_output_tokens
        if max_tool_calls is not None:
            self.inputs["max_tool_calls"] = max_tool_calls
        if parallel_tool_calls is not None:
            self.inputs["parallel_tool_calls"] = parallel_tool_calls
        if previous_response_id is not None:
            self.inputs["previous_response_id"] = previous_response_id
        if prompt_cache_key is not None:
            self.inputs["prompt_cache_key"] = prompt_cache_key
        if safety_identifier is not None:
            self.inputs["safety_identifier"] = safety_identifier
        if service_tier is not None:
            self.inputs["service_tier"] = service_tier
        if tool_choice is not None:
            self.inputs["tool_choice"] = tool_choice
        if tools is not None:
            self.inputs["tools"] = tools
        if truncation is not None:
            self.inputs["truncation"] = truncation
        if stream is not None:
            self.inputs["stream"] = stream
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if finetuned_model is not None:
            self.inputs["finetuned_model"] = finetuned_model
        if endpoint is not None:
            self.inputs["endpoint"] = endpoint
        if deployment_id is not None:
            self.inputs["deployment_id"] = deployment_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "DeepResearchNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
