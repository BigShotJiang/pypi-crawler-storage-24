"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_notion")
class IntegrationNotionNode(Node):
    """
    Notion

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'search_databases'
        text: Text to search for in database names and content
        limit: Maximum number of databases to return
        return_all: If true, returns all databases regardless of limit
    ### When action = 'search_pages'
        text: Text to search for in database names and content
        get_page_content: If true, fetches the text content of each matching page
        limit: Maximum number of databases to return
        return_all: If true, returns all databases regardless of limit
    ### When action = 'update_database' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'create_new_page' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'create_new_block' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'write_to_database' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'update_database_page'
        archived: Whether to archive the page
        page_id: Select the page to archive
        properties: JSON object containing properties to update
    ### When action = 'get_child_blocks'
        block_id: The ID of the parent block to get children from
        limit: Maximum number of databases to return
        return_all: If true, returns all databases regardless of limit
    ### When action = 'create_new_page'
        blocks: Array of block objects. Each block should be a JSON string with 'type' (paragraph, heading_1, heading_2, heading_3, toggle, to_do, bulleted_list_item, numbered_list_item, image) and 'content' fields. Use checked for to_do blocks to indicate if the task is completed. Content will not be used if blocks are provided. Example: {"type":"paragraph","content":"Hello"}
        icon: Icon emoji (e.g., 😀) or external file URL if type is 'file'
        icon_type: Type of icon: emoji or external file URL
        item_id: Select Notion Database
    ### When action = 'create_new_block'
        blocks: Array of block objects. Each block should be a JSON string with 'type' (paragraph, heading_1, heading_2, heading_3, toggle, to_do, bulleted_list_item, numbered_list_item, image) and 'content' fields. Use checked for to_do blocks to indicate if the task is completed. Content will not be used if blocks are provided. Example: {"type":"paragraph","content":"Hello"}
        item_id: Select Notion Database
    ### When action = 'update_database'
        condition: Conditional Operator
        item_id: Select Notion Database
    ### When action = 'get_database_pages'
        database_id: Select Notion Database
        limit: Maximum number of databases to return
        return_all: If true, returns all databases regardless of limit
    ### When action = 'read_database'
        item_id: Select Notion Database
    ### When action = 'read_page'
        item_id: Select Notion Database
    ### When action = 'write_to_database'
        item_id: Select Notion Database
    ### When action = 'get_databases'
        limit: Maximum number of databases to return
        return_all: If true, returns all databases regardless of limit
    ### When action = 'get_users'
        limit: Maximum number of databases to return
        return_all: If true, returns all databases regardless of limit
    ### When action = 'archive_page'
        page_id: Select the page to archive
    ### When action = 'read_database_page'
        page_id: Select the page to archive
    ### When action = 'read_user'
        user_id: The ID of the user to read

    ## Outputs
    ### When action = 'read_database' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'read_page' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'archive_page'
        archive_status: Archive operation status message
        archived: Archive status of the page
        last_edited_time: Last edited time of the page
        page_id: ID of the archived page
        page_url: URL of the archived page
        raw_data: Raw API response data
    ### When action = 'read_page'
        archived: Whether the page is archived
        created_time: Page creation time
        in_trash: Whether the page is in trash
        last_edited_time: Page last edited time
        page_content: Text content of the page
        page_id: ID of the page
        page_title: Title of the page
        page_url: URL of the page
        parent_id: ID of the parent page or database
        raw_data: Raw API response data
    ### When action = 'read_database_page'
        archived: Archive status of the page
        created_time: Creation time of the page
        last_edited_time: Last edited time of the page
        page_id: ID of the database page
        page_url: URL of the database page
        properties: Page properties as JSON string
        raw_data: Raw API response data
    ### When action = 'read_user'
        avatar_url: URL of the user's avatar image
        raw_data: Raw API response data
        user_email: Email address of the user
        user_id: ID of the user
        user_name: Name of the user
        user_type: Type of user account
    ### When action = 'get_users'
        avatar_urls: List of user avatar URLs
        raw_data: Raw API response data
        user_emails: List of user email addresses
        user_ids: List of user IDs
        user_names: List of user names
        user_types: List of user account types
    ### When action = 'get_child_blocks'
        block_contents: List of child block contents
        block_created_times: List of block creation times
        block_has_children: List indicating if blocks have children
        block_ids: List of child block IDs
        block_last_edited_times: List of block last edited times
        block_types: List of child block types
        raw_data: Raw API response data
    ### When action = 'create_new_block'
        block_ids: IDs of the created blocks
        parent_block_id: ID of the parent block (page or block) containing the created blocks
        raw_data: Raw API response data
    ### When action = 'get_databases'
        database_created_at: List of database creation timestamps
        database_created_by: List of database creators
        database_ids: List of database IDs
        database_names: List of database names
        database_titles: List of database titles
        database_urls: List of database URLs
        raw_data: Raw API response data
    ### When action = 'search_databases'
        database_created_at: List of matching database creation timestamps
        database_created_by: List of matching database creators
        database_ids: List of matching database IDs
        database_names: List of matching database names
        database_titles: List of matching database titles
        database_urls: List of matching database URLs
        raw_data: Raw API response data
    ### When action = 'update_database_page'
        last_edited_time: Last edited time after update
        page_id: ID of the updated database page
        page_url: URL of the updated database page
        raw_data: Raw API response data
        update_status: Update operation status message
    ### When action = 'search_pages'
        page_archived: List indicating if pages are archived
        page_contents: Text content of each matching page (only populated when Get Page Content is enabled)
        page_created_times: List of page creation times
        page_ids: List of matching page IDs
        page_last_edited_times: List of page last edited times
        page_titles: List of matching page titles
        page_urls: List of matching page URLs
        raw_data: Raw API response data
    ### When action = 'get_database_pages'
        page_archived: List indicating if pages are archived
        page_created_times: List of page creation times
        page_ids: List of database page IDs
        page_last_edited_times: List of page last edited times
        page_titles: List of database page titles
        page_urls: List of database page URLs
        raw_data: Raw API response data
    ### When action = 'create_new_page'
        page_id: ID of the created page
        raw_data: Raw API response data
    ### When action = 'read_database'
        raw_data: Raw API response data
    ### When action = 'update_database'
        raw_data: Raw API response data
    ### When action = 'write_to_database'
        raw_data: Raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Notion>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "read_database**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Database",
                    "placeholder": "Choose a database",
                    "helper_text": "Select Notion Database",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "read_database",
            "task_name": "tasks.notion.read_database",
            "description": "Get multiple pages",
            "label": "List Database Pages",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "item_id"],
        },
        "read_database**[endpoint_0.<A>]": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "update_database**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Database",
                    "placeholder": "Choose a database",
                    "helper_text": "Select Notion Database",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "condition",
                    "type": "string",
                    "value": "",
                    "label": "Conditional Operator",
                    "placeholder": "",
                    "helper_text": "Conditional Operator",
                },
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "update_database",
            "task_name": "tasks.notion.update_database",
            "description": "Update a Notion database",
            "label": "Database Updater",
            "operation": "update",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "item_id", "condition"],
        },
        "update_database**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "get_databases**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of databases to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If true, returns all databases regardless of limit",
                },
            ],
            "outputs": [
                {
                    "field": "database_names",
                    "type": "vec<string>",
                    "helper_text": "List of database names",
                },
                {
                    "field": "database_ids",
                    "type": "vec<string>",
                    "helper_text": "List of database IDs",
                },
                {
                    "field": "database_urls",
                    "type": "vec<string>",
                    "helper_text": "List of database URLs",
                },
                {
                    "field": "database_titles",
                    "type": "vec<string>",
                    "helper_text": "List of database titles",
                },
                {
                    "field": "database_created_by",
                    "type": "vec<string>",
                    "helper_text": "List of database creators",
                },
                {
                    "field": "database_created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "List of database creation timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_databases",
            "task_name": "tasks.notion.get_databases",
            "description": "Get multiple databases",
            "label": "List Databases",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": ["integration", "action", "limit", "return_all"],
        },
        "search_databases**(*)": {
            "inputs": [
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "Enter search text",
                    "helper_text": "Text to search for in database names and content",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of databases to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If true, returns all matching databases regardless of limit",
                },
            ],
            "outputs": [
                {
                    "field": "database_names",
                    "type": "vec<string>",
                    "helper_text": "List of matching database names",
                },
                {
                    "field": "database_ids",
                    "type": "vec<string>",
                    "helper_text": "List of matching database IDs",
                },
                {
                    "field": "database_urls",
                    "type": "vec<string>",
                    "helper_text": "List of matching database URLs",
                },
                {
                    "field": "database_titles",
                    "type": "vec<string>",
                    "helper_text": "List of matching database titles",
                },
                {
                    "field": "database_created_by",
                    "type": "vec<string>",
                    "helper_text": "List of matching database creators",
                },
                {
                    "field": "database_created_at",
                    "type": "vec<timestamp>",
                    "helper_text": "List of matching database creation timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "search_databases",
            "task_name": "tasks.notion.search_databases",
            "description": "Search for databases in Notion workspace",
            "label": "Search Databases",
            "variant": "common_integration_nodes",
            "required": ["text", "limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "text",
                "limit",
                "return_all",
            ],
        },
        "read_page**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Page",
                    "placeholder": "Notion page ID",
                    "helper_text": "Select a page, or enter a page ID or Notion URL",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=page&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "page_id", "type": "string", "helper_text": "ID of the page"},
                {
                    "field": "page_url",
                    "type": "string",
                    "helper_text": "URL of the page",
                },
                {
                    "field": "page_title",
                    "type": "string",
                    "helper_text": "Title of the page",
                },
                {
                    "field": "page_content",
                    "type": "vec<string>",
                    "helper_text": "Text content of the page",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "Page creation time",
                },
                {
                    "field": "last_edited_time",
                    "type": "timestamp",
                    "helper_text": "Page last edited time",
                },
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "ID of the parent page or database",
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "helper_text": "Whether the page is archived",
                },
                {
                    "field": "in_trash",
                    "type": "bool",
                    "helper_text": "Whether the page is in trash",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_page",
            "task_name": "tasks.notion.read_page",
            "description": "Read details of a specific page",
            "label": "Get Page",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "item_id"],
        },
        "read_page**[endpoint_0.<A>]": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "create_new_page**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Page",
                    "placeholder": "Choose a Page",
                    "helper_text": "Select Notion Database",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=page&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "icon_type",
                    "type": "string",
                    "value": "",
                    "label": "Icon Type",
                    "helper_text": "Type of icon: emoji or external file URL",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Emoji", "value": "emoji"},
                            {"label": "File (External URL)", "value": "file"},
                        ],
                    },
                },
                {
                    "field": "icon",
                    "type": "string",
                    "value": "",
                    "label": "Icon",
                    "placeholder": "",
                    "helper_text": "Icon emoji (e.g., 😀) or external file URL if type is 'file'",
                },
                {
                    "field": "blocks",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Blocks",
                    "placeholder": '{"type":"paragraph","content":"Hello"}',
                    "helper_text": 'Array of block objects. Each block should be a JSON string with \'type\' (paragraph, heading_1, heading_2, heading_3, toggle, to_do, bulleted_list_item, numbered_list_item, image) and \'content\' fields. Use checked for to_do blocks to indicate if the task is completed. Content will not be used if blocks are provided. Example: {"type":"paragraph","content":"Hello"}',
                },
            ],
            "outputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "helper_text": "ID of the created page",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_new_page",
            "task_name": "tasks.notion.create_new_page",
            "description": "Create a new page on an existing Notion page with multiple block types",
            "label": "Create New Page",
            "required": ["title"],
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "item_id",
                "icon_type",
                "icon",
                "blocks",
            ],
        },
        "create_new_page**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "search_pages**(*)": {
            "inputs": [
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "Enter search text",
                    "helper_text": "Text to search for in page content",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of pages to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If true, returns all matching pages regardless of limit",
                },
                {
                    "field": "get_page_content",
                    "type": "bool",
                    "value": False,
                    "label": "Get Page Content",
                    "helper_text": "If true, fetches the text content of each matching page",
                },
            ],
            "outputs": [
                {
                    "field": "page_ids",
                    "type": "vec<string>",
                    "helper_text": "List of matching page IDs",
                },
                {
                    "field": "page_urls",
                    "type": "vec<string>",
                    "helper_text": "List of matching page URLs",
                },
                {
                    "field": "page_titles",
                    "type": "vec<string>",
                    "helper_text": "List of matching page titles",
                },
                {
                    "field": "page_created_times",
                    "type": "vec<string>",
                    "helper_text": "List of page creation times",
                },
                {
                    "field": "page_last_edited_times",
                    "type": "vec<string>",
                    "helper_text": "List of page last edited times",
                },
                {
                    "field": "page_archived",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if pages are archived",
                },
                {
                    "field": "page_contents",
                    "type": "vec<string>",
                    "helper_text": "Text content of each matching page (only populated when Get Page Content is enabled)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "search_pages",
            "task_name": "tasks.notion.search_pages",
            "description": "Search for pages in Notion workspace",
            "label": "Search Pages",
            "variant": "common_integration_nodes",
            "required": ["text", "limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "text",
                "limit",
                "return_all",
                "get_page_content",
            ],
        },
        "archive_page**(*)": {
            "inputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Page",
                    "placeholder": "Choose a page",
                    "helper_text": "Select the page to archive",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=page&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "helper_text": "ID of the archived page",
                },
                {
                    "field": "page_url",
                    "type": "string",
                    "helper_text": "URL of the archived page",
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "helper_text": "Archive status of the page",
                },
                {
                    "field": "last_edited_time",
                    "type": "string",
                    "helper_text": "Last edited time of the page",
                },
                {
                    "field": "archive_status",
                    "type": "string",
                    "helper_text": "Archive operation status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "archive_page",
            "task_name": "tasks.notion.archive_page",
            "description": "Archive a page in Notion",
            "label": "Archive Page",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "page_id"],
        },
        "create_new_block**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Page",
                    "placeholder": "Choose a Page",
                    "helper_text": "Select Notion Page",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=page&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "blocks",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Blocks",
                    "placeholder": '{"type":"paragraph","content":"Hello"}',
                    "helper_text": 'Array of block objects. Each block should be a JSON string with \'type\' (paragraph, heading_1, heading_2, heading_3, toggle, to_do, bulleted_list_item, numbered_list_item, image) and \'content\' fields. Use checked for to_do blocks to indicate if the task is completed. Content will not be used if blocks are provided. Example: {"type":"paragraph","content":"Hello"}',
                },
            ],
            "outputs": [
                {
                    "field": "block_ids",
                    "type": "vec<string>",
                    "helper_text": "IDs of the created blocks",
                },
                {
                    "field": "parent_block_id",
                    "type": "string",
                    "helper_text": "ID of the parent block (page or block) containing the created blocks",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_new_block",
            "task_name": "tasks.notion.create_new_block",
            "description": "Create multiple blocks in a Notion page with different types",
            "label": "Create New Block",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "item_id", "blocks"],
        },
        "create_new_block**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "get_child_blocks**(*)": {
            "inputs": [
                {
                    "field": "block_id",
                    "type": "string",
                    "value": "",
                    "label": "Block ID",
                    "placeholder": "Enter block ID",
                    "helper_text": "The ID of the parent block to get children from",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of child blocks to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If true, returns all child blocks regardless of limit",
                },
            ],
            "outputs": [
                {
                    "field": "block_ids",
                    "type": "vec<string>",
                    "helper_text": "List of child block IDs",
                },
                {
                    "field": "block_types",
                    "type": "vec<string>",
                    "helper_text": "List of child block types",
                },
                {
                    "field": "block_contents",
                    "type": "vec<string>",
                    "helper_text": "List of child block contents",
                },
                {
                    "field": "block_created_times",
                    "type": "vec<string>",
                    "helper_text": "List of block creation times",
                },
                {
                    "field": "block_last_edited_times",
                    "type": "vec<string>",
                    "helper_text": "List of block last edited times",
                },
                {
                    "field": "block_has_children",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if blocks have children",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_child_blocks",
            "task_name": "tasks.notion.get_child_blocks",
            "description": "Get multiple child blocks from a parent block",
            "label": "List Child Blocks",
            "variant": "common_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "block_id",
                "limit",
                "return_all",
            ],
            "required": ["block_id"],
        },
        "read_database_page**(*)": {
            "inputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "value": "",
                    "label": "Page ID",
                    "placeholder": "Enter page ID",
                    "helper_text": "The ID of the database page to read",
                }
            ],
            "outputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "helper_text": "ID of the database page",
                },
                {
                    "field": "page_url",
                    "type": "string",
                    "helper_text": "URL of the database page",
                },
                {
                    "field": "created_time",
                    "type": "string",
                    "helper_text": "Creation time of the page",
                },
                {
                    "field": "last_edited_time",
                    "type": "string",
                    "helper_text": "Last edited time of the page",
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "helper_text": "Archive status of the page",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "helper_text": "Page properties as JSON string",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_database_page",
            "task_name": "tasks.notion.read_database_page",
            "description": "Read details of a specific database page",
            "label": "Get Database Page",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "page_id"],
        },
        "write_to_database**(*)": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Database",
                    "placeholder": "Choose a database",
                    "helper_text": "Select Notion Database",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                }
            ],
            "name": "write_to_database",
            "task_name": "tasks.notion.write_to_database",
            "description": "Add a page to an existing Notion database",
            "label": "Write to Database",
            "variant": "common_integration_nodes",
            "ui_sort_order": ["integration", "action", "item_id"],
        },
        "write_to_database**[endpoint_0.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "get_database_pages**(*)": {
            "inputs": [
                {
                    "field": "database_id",
                    "type": "string",
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                    "value": "",
                    "label": "Database",
                    "placeholder": "Choose a database",
                    "helper_text": "Select Notion Database",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=database&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of pages to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If true, returns all pages regardless of limit",
                },
            ],
            "outputs": [
                {
                    "field": "page_ids",
                    "type": "vec<string>",
                    "helper_text": "List of database page IDs",
                },
                {
                    "field": "page_urls",
                    "type": "vec<string>",
                    "helper_text": "List of database page URLs",
                },
                {
                    "field": "page_titles",
                    "type": "vec<string>",
                    "helper_text": "List of database page titles",
                },
                {
                    "field": "page_created_times",
                    "type": "vec<string>",
                    "helper_text": "List of page creation times",
                },
                {
                    "field": "page_last_edited_times",
                    "type": "vec<string>",
                    "helper_text": "List of page last edited times",
                },
                {
                    "field": "page_archived",
                    "type": "vec<bool>",
                    "helper_text": "List indicating if pages are archived",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_database_pages",
            "task_name": "tasks.notion.get_database_pages",
            "description": "Get multiple pages",
            "label": "List Database Pages",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "database_id",
                "limit",
                "return_all",
            ],
        },
        "update_database_page**(*)": {
            "inputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "value": "",
                    "label": "Database Page ID",
                    "placeholder": "Enter database page ID",
                    "helper_text": "The ID of the database page to update",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "placeholder": '{"Status":{"status":{"name":"Completed"}}}',
                    "helper_text": "JSON object containing properties to update",
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "value": False,
                    "label": "Archived",
                    "helper_text": "Whether to archive the page",
                },
            ],
            "outputs": [
                {
                    "field": "page_id",
                    "type": "string",
                    "helper_text": "ID of the updated database page",
                },
                {
                    "field": "page_url",
                    "type": "string",
                    "helper_text": "URL of the updated database page",
                },
                {
                    "field": "last_edited_time",
                    "type": "string",
                    "helper_text": "Last edited time after update",
                },
                {
                    "field": "update_status",
                    "type": "string",
                    "helper_text": "Update operation status message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_database_page",
            "task_name": "tasks.notion.update_database_page",
            "description": "Update a database page in Notion",
            "label": "Update Database Page",
            "variant": "common_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "page_id",
                "properties",
                "archived",
            ],
            "required": ["properties"],
        },
        "read_user**(*)": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "Enter user ID",
                    "helper_text": "The ID of the user to read",
                }
            ],
            "outputs": [
                {"field": "user_id", "type": "string", "helper_text": "ID of the user"},
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email address of the user",
                },
                {
                    "field": "user_type",
                    "type": "string",
                    "helper_text": "Type of user account",
                },
                {
                    "field": "avatar_url",
                    "type": "string",
                    "helper_text": "URL of the user's avatar image",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_user",
            "task_name": "tasks.notion.read_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "variant": "common_integration_nodes",
            "inputs_sort_order": ["integration", "action", "user_id"],
        },
        "get_users**(*)": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of users to return",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "If true, returns all users regardless of limit",
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user names",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user email addresses",
                },
                {
                    "field": "user_types",
                    "type": "vec<string>",
                    "helper_text": "List of user account types",
                },
                {
                    "field": "avatar_urls",
                    "type": "vec<string>",
                    "helper_text": "List of user avatar URLs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_users",
            "task_name": "tasks.notion.get_users",
            "description": "Get multiple users",
            "label": "List Users",
            "variant": "common_integration_nodes",
            "required": ["limit"],
            "inputs_sort_order": ["integration", "action", "limit", "return_all"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "item_id",
        "page_id",
        "database_id",
        "user_id",
        "block_id",
    ]

    def __init__(
        self,
        action: str = "",
        text: str = "",
        archived: bool = False,
        block_id: str = "",
        blocks: List[str] = [],
        condition: str = "",
        database_id: str = "",
        get_page_content: bool = False,
        icon: str = "",
        icon_type: str = "",
        item_id: str = "",
        limit: int = 10,
        page_id: str = "",
        properties: str = "",
        return_all: bool = False,
        user_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_notion",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if condition is not None:
            self.inputs["condition"] = condition
        if limit is not None:
            self.inputs["limit"] = limit
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if text is not None:
            self.inputs["text"] = text
        if icon_type is not None:
            self.inputs["icon_type"] = icon_type
        if icon is not None:
            self.inputs["icon"] = icon
        if blocks is not None:
            self.inputs["blocks"] = blocks
        if get_page_content is not None:
            self.inputs["get_page_content"] = get_page_content
        if page_id is not None:
            self.inputs["page_id"] = page_id
        if block_id is not None:
            self.inputs["block_id"] = block_id
        if database_id is not None:
            self.inputs["database_id"] = database_id
        if properties is not None:
            self.inputs["properties"] = properties
        if archived is not None:
            self.inputs["archived"] = archived
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationNotionNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
