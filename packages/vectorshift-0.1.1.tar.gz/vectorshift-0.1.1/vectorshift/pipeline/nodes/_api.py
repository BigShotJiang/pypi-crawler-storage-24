"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import FileKeyValue, KeyValue


@Node.register_node_type("api")
class ApiNode(Node):
    """
    Make an API request to a given URL.

    ## Inputs
    ### Common Inputs
        files: Files to include in the API request
        headers: Headers to include in the API request
        is_raw_json: Whether to return the raw JSON response from the API
        method: Choose the API Method desired (GET, POST, PUT, DELETE, PATCH)
        query_params: Query parameters to include in the API request
        url: Target URL for the API Request
    ### When is_raw_json = False
        body_params: The body parameters to include in the API request
    ### When is_raw_json = True
        raw_json: The raw JSON request to the API

    ## Outputs
    ### Common Outputs
        output: The response from the API
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "files",
            "helper_text": "Files to include in the API request",
            "value": [],
            "type": "vec<interface{id: string, key: string, value: file}>",
        },
        {
            "field": "headers",
            "helper_text": "Headers to include in the API request",
            "value": [],
            "type": "vec<interface{id: string, key: string, value: string}>",
        },
        {
            "field": "is_raw_json",
            "helper_text": "Whether to return the raw JSON response from the API",
            "value": False,
            "type": "bool",
        },
        {
            "field": "method",
            "helper_text": "Choose the API Method desired (GET, POST, PUT, DELETE, PATCH)",
            "value": "GET",
            "type": "string",
        },
        {
            "field": "query_params",
            "helper_text": "Query parameters to include in the API request",
            "value": [],
            "type": "vec<interface{id: string, key: string, value: string}>",
        },
        {
            "field": "url",
            "helper_text": "Target URL for the API Request",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "The response from the API",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true": {
            "inputs": [
                {
                    "field": "raw_json",
                    "label": "Raw JSON",
                    "type": "string",
                    "value": "",
                    "helper_text": "The raw JSON request to the API",
                    "component": {"type": "text", "tab_group": "body"},
                    "order": 7,
                }
            ],
            "outputs": [],
        },
        "false": {
            "inputs": [
                {
                    "field": "body_params",
                    "type": "vec<interface{id: string, key: string, value: string}>",
                    "value": [],
                    "helper_text": "The body parameters to include in the API request",
                    "label": "Body Parameters",
                    "component": {
                        "type": "table",
                        "tab_group": "body",
                        "table": {
                            "key": {"helper_text": "The key of the api request"},
                            "value": {"helper_text": "The value of the API request"},
                        },
                    },
                    "order": 7,
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["is_raw_json"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["url"]

    def __init__(
        self,
        is_raw_json: bool = False,
        body_params: List[KeyValue] = [],
        files: List[FileKeyValue] = [],
        headers: List[KeyValue] = [],
        method: str = "GET",
        query_params: List[KeyValue] = [],
        raw_json: str = "",
        url: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["is_raw_json"] = is_raw_json

        super().__init__(
            node_type="api",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if method is not None:
            self.inputs["method"] = method
        if url is not None:
            self.inputs["url"] = url
        if headers is not None:
            self.inputs["headers"] = headers
        if query_params is not None:
            self.inputs["query_params"] = query_params
        if files is not None:
            self.inputs["files"] = files
        if is_raw_json is not None:
            self.inputs["is_raw_json"] = is_raw_json
        if raw_json is not None:
            self.inputs["raw_json"] = raw_json
        if body_params is not None:
            self.inputs["body_params"] = body_params
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ApiNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
