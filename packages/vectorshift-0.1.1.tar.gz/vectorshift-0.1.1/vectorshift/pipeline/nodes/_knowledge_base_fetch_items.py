"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("knowledge_base_fetch_items")
class KnowledgeBaseFetchItemsNode(Node):
    """
    Advanced knowledge base item fetching with traversal, filtering, and output shaping capabilities

    ## Inputs
    ### Common Inputs
        filter: JSON filter object, example filter syntax: '{"type": "condition", "field": "file_extension", "operator": "eq", "value": "pdf"}' only use filters if explicitly requested by the user. Do not use filters on fields other than file type. Available operators include are eq and neq, do not use filter operator contains
        item_return_type: Type of items to return: FOLDERS, DOCUMENTS, or ALL
        knowledge_base: Select an existing knowledge base
        limit: Maximum number of items to return
        max_depth: Maximum depth for descendants traversal, use 0 to traverse up as deep as possible to get to {{limit}} items, use 1 to get direct children etc
        offset: Number of items to skip for pagination
        root_ids: Filter to list items in specific folders by providing comma-separated root IDs
        sort_fields: Comma-separated fields to sort by
        sort_orders: Comma-separated sort orders: asc or desc
        verbosity: Output verbosity level: metadata (no summaries), short (short summaries), or long (short and long summaries), Use metadata for for simply finding folders/ documents, use short for understanding folder/document contents, use long with a lower limit for deep understanding of a particular folder/subfolder

    ## Outputs
    ### Common Outputs
        formatted_text: Formatted text
        kb_item_ids: Knowledge base item ids
        kb_items: knowledge base items
        stats: JSON serialized statistics
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "filter",
            "helper_text": 'JSON filter object, example filter syntax: \'{"type": "condition", "field": "file_extension", "operator": "eq", "value": "pdf"}\' only use filters if explicitly requested by the user. Do not use filters on fields other than file type. Available operators include are eq and neq, do not use filter operator contains',
            "value": "",
            "type": "string",
        },
        {
            "field": "item_return_type",
            "helper_text": "Type of items to return: FOLDERS, DOCUMENTS, or ALL",
            "value": "All",
            "type": "string",
        },
        {
            "field": "knowledge_base",
            "helper_text": "Select an existing knowledge base",
            "value": {"object_type": 1, "object_id": ""},
            "type": "knowledge_base",
        },
        {
            "field": "limit",
            "helper_text": "Maximum number of items to return",
            "value": 50,
            "type": "int32",
        },
        {
            "field": "max_depth",
            "helper_text": "Maximum depth for descendants traversal, use 0 to traverse up as deep as possible to get to {{limit}} items, use 1 to get direct children etc",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "offset",
            "helper_text": "Number of items to skip for pagination",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "root_ids",
            "helper_text": "Filter to list items in specific folders by providing comma-separated root IDs",
            "value": "",
            "type": "string",
        },
        {
            "field": "sort_fields",
            "helper_text": "Comma-separated fields to sort by",
            "value": "",
            "type": "string",
        },
        {
            "field": "sort_orders",
            "helper_text": "Comma-separated sort orders: asc or desc",
            "value": "",
            "type": "string",
        },
        {
            "field": "verbosity",
            "helper_text": "Output verbosity level: metadata (no summaries), short (short summaries), or long (short and long summaries), Use metadata for for simply finding folders/ documents, use short for understanding folder/document contents, use long with a lower limit for deep understanding of a particular folder/subfolder",
            "value": "metadata",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "formatted_text", "helper_text": "Formatted text", "type": "string"},
        {
            "field": "kb_item_ids",
            "helper_text": "Knowledge base item ids",
            "type": "vec<string>",
        },
        {
            "field": "kb_items",
            "helper_text": "knowledge base items",
            "type": "vec<string>",
        },
        {
            "field": "stats",
            "helper_text": "JSON serialized statistics",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "filter", "label": "Filter"},
        {"field": "item_return_type", "label": "Item Return Type"},
        {"field": "knowledge_base", "label": "Knowledge Base"},
        {"field": "root_ids", "label": "Root IDs"},
        {"field": "sort_fields", "label": "Sort Fields"},
        {"field": "sort_orders", "label": "Sort Orders"},
        {"field": "verbosity", "label": "Verbosity"},
    ]

    _REQUIRED_FIELDS = ["knowledge_base"]

    def __init__(
        self,
        filter: str = "",
        item_return_type: str = "All",
        knowledge_base: "KnowledgeBase" = "",
        limit: int = 50,
        max_depth: int = 0,
        offset: int = 0,
        root_ids: str = "",
        sort_fields: str = "",
        sort_orders: str = "",
        verbosity: str = "metadata",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="knowledge_base_fetch_items",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if knowledge_base is not None:
            self.inputs["knowledge_base"] = knowledge_base
        if root_ids is not None:
            self.inputs["root_ids"] = root_ids
        if max_depth is not None:
            self.inputs["max_depth"] = max_depth
        if sort_fields is not None:
            self.inputs["sort_fields"] = sort_fields
        if sort_orders is not None:
            self.inputs["sort_orders"] = sort_orders
        if limit is not None:
            self.inputs["limit"] = limit
        if offset is not None:
            self.inputs["offset"] = offset
        if item_return_type is not None:
            self.inputs["item_return_type"] = item_return_type
        if filter is not None:
            self.inputs["filter"] = filter
        if verbosity is not None:
            self.inputs["verbosity"] = verbosity
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseFetchItemsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
