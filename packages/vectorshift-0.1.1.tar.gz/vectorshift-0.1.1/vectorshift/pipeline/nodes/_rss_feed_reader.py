"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("rss_feed_reader")
class RssFeedReaderNode(Node):
    """
    Read the contents from an RSS feed

    ## Inputs
    ### Common Inputs
        entries: The number of entries you want to fetch
        timeframe: The publish dates of the items in the feed to read
        url: The link of the RSS feed you want to read

    ## Outputs
    ### Common Outputs
        authors: The authors of the RSS feed items
        contents: The contents of the RSS feed items
        links: The links of the RSS feed items
        published_dates: The publish dates of the RSS feed items
        summaries: The summaries of the RSS feed items
        titles: The titles of the RSS feed items
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "entries",
            "helper_text": "The number of entries you want to fetch",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "timeframe",
            "helper_text": "The publish dates of the items in the feed to read",
            "value": "all",
            "type": "string",
        },
        {
            "field": "url",
            "helper_text": "The link of the RSS feed you want to read",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "authors",
            "helper_text": "The authors of the RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "contents",
            "helper_text": "The contents of the RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "links",
            "helper_text": "The links of the RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "published_dates",
            "helper_text": "The publish dates of the RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "summaries",
            "helper_text": "The summaries of the RSS feed items",
            "type": "vec<string>",
        },
        {
            "field": "titles",
            "helper_text": "The titles of the RSS feed items",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["url"]

    def __init__(
        self,
        entries: int = 10,
        timeframe: str = "all",
        url: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="rss_feed_reader",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if url is not None:
            self.inputs["url"] = url
        if timeframe is not None:
            self.inputs["timeframe"] = timeframe
        if entries is not None:
            self.inputs["entries"] = entries
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "RssFeedReaderNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
