"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_gohighlevel")
class IntegrationGohighlevelNode(Node):
    """
    GoHighLevel

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### create_opportunity
        contact_name: Name of the existing contact to link to the opportunity. One contact can only be linked to one opportunity.
        name: Name of the opportunity
        pipeline_name: Name of the existing pipeline to link to the opportunity
        status: Status of the opportunity (must be one of: 'open', 'won', 'lost', 'abandoned')
        value: Money value of the opportunity
    ### create_contact
        email: Email address of the contact
        first_name: First name of the contact
        last_name: Last name of the contact
        phone: Phone number of the contact

    ## Outputs
        None
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<GoHighLevel>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "default_integration_nodes"},
        "create_contact": {
            "inputs": [
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "First name of the contact",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Last name of the contact",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@doe.com",
                    "helper_text": "Email address of the contact",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1 888-888-8888",
                    "helper_text": "Phone number of the contact",
                },
            ],
            "outputs": [],
            "name": "create_contact",
            "task_name": "tasks.gohighlevel.create_contact",
            "description": "Create a new contact on GoHighLevel",
            "label": "Create Contact",
        },
        "create_opportunity": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "placeholder": "First op",
                    "helper_text": "Name of the opportunity",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "placeholder": "open",
                    "helper_text": "Status of the opportunity (must be one of: 'open', 'won', 'lost', 'abandoned')",
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value",
                    "placeholder": "500",
                    "helper_text": "Money value of the opportunity",
                },
                {
                    "field": "pipeline_name",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline Name",
                    "placeholder": "onboarding",
                    "helper_text": "Name of the existing pipeline to link to the opportunity",
                },
                {
                    "field": "contact_name",
                    "type": "string",
                    "value": "",
                    "label": "Contact Name",
                    "placeholder": "John",
                    "helper_text": "Name of the existing contact to link to the opportunity. One contact can only be linked to one opportunity.",
                },
            ],
            "outputs": [],
            "name": "create_opportunity",
            "task_name": "tasks.gohighlevel.create_opportunity",
            "description": "Create a new opportunity on GoHighLevel",
            "label": "Create Opportunity",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        contact_name: str = "",
        email: str = "",
        first_name: str = "",
        last_name: str = "",
        name: str = "",
        phone: str = "",
        pipeline_name: str = "",
        status: str = "",
        value: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_gohighlevel",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if email is not None:
            self.inputs["email"] = email
        if phone is not None:
            self.inputs["phone"] = phone
        if name is not None:
            self.inputs["name"] = name
        if status is not None:
            self.inputs["status"] = status
        if value is not None:
            self.inputs["value"] = value
        if pipeline_name is not None:
            self.inputs["pipeline_name"] = pipeline_name
        if contact_name is not None:
            self.inputs["contact_name"] = contact_name
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGohighlevelNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
