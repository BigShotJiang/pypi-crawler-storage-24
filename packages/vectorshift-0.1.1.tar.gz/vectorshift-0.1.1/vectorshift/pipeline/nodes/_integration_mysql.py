"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_mysql")
class IntegrationMysqlNode(Node):
    """
    MySQL

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### nl
        query: Natural language query to be converted to SQL
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        sql_generation_model: The sql_generation_model input
    ### raw_sql
        query: Natural language query to be converted to SQL
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        sql_generation_model: The sql_generation_model input
    ### nl_agent
        query: Natural language query to be converted to SQL
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        sql_generation_model: The sql_generation_model input
    ### update
        column_to_match_on: Column used to find the row to update
        connection_limit: Maximum number of connections (default: 10)
        connection_timeout: Connection timeout in seconds (default: 30)
        data: JSON object with column-value pairs to insert
        table_name: Choose the table to insert into
        value: Value in the match column to identify the row
    ### upsert
        column_to_match_on: Column used to find the row to update
        connection_limit: Maximum number of connections (default: 10)
        connection_timeout: Connection timeout in seconds (default: 30)
        data: JSON object with column-value pairs to insert
        table_name: Choose the table to insert into
        value: Value in the match column to identify the row
    ### select
        columns: Choose specific columns (comma-separated or select multiple)
        connection_limit: Maximum number of connections (default: 10)
        connection_timeout: Connection timeout in seconds (default: 30)
        limit: Maximum number of rows to return
        order_by: Optional ORDER BY clause
        table_name: Choose the table to insert into
        where_clause: Optional WHERE condition (without WHERE keyword)
    ### insert
        connection_limit: Maximum number of connections (default: 10)
        connection_timeout: Connection timeout in seconds (default: 30)
        data: JSON object with column-value pairs to insert
        table_name: Choose the table to insert into
    ### execute_query
        connection_limit: Maximum number of connections (default: 10)
        connection_timeout: Connection timeout in seconds (default: 30)
        parameters: Comma-separated parameters for parameterized queries (optional)
        sql_query: SQL query to execute
    ### delete_table
        connection_limit: Maximum number of connections (default: 10)
        connection_timeout: Connection timeout in seconds (default: 30)
        delete_command: Delete command to execute (truncate, delete, or drop)
        table_name: Choose the table to insert into
        where_clause: Optional WHERE condition (without WHERE keyword)

    ## Outputs
    ### Common Outputs
        output: Operation result message
        raw_data: Raw response from database
        sql_query: The executed SQL query
    ### insert
        affected_rows: Number of rows inserted
        inserted_id: ID of the inserted record (if available)
    ### update
        affected_rows: Number of rows updated
    ### upsert
        affected_rows: Number of rows affected
        record_id: ID of the inserted or updated record (if available)
    ### delete_table
        affected_rows: Number of rows deleted
        table_dropped: Whether the entire table was dropped
    ### select
        columns: Column names in the result set
        results: Selected data as JSON
        row_count: Number of rows returned
    ### execute_query
        columns: Column names in the result set
        execution_time: Query execution time in seconds
        results: Query results as JSON
        row_count: Number of rows returned
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<MySQL>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "Operation result message",
            "type": "string",
        },
        {
            "field": "raw_data",
            "helper_text": "Raw response from database",
            "type": "string",
        },
        {
            "field": "sql_query",
            "helper_text": "The executed SQL query",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "nl": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "Natural language query to be converted to SQL",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "label": "Query Type",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "SQL Generation Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "Query Agent Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "nl",
            "task_name": "tasks.tables.integrations.mysql.query",
            "description": "Generate and execute a SQL query",
            "label": "Natural Language Query",
        },
        "raw_sql": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "SQL Query to execute",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "label": "Query Type",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "SQL Generation Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "Query Agent Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "raw_sql",
            "task_name": "tasks.tables.integrations.mysql.query",
            "description": "Execute a SQL query",
            "label": "Raw SQL Query",
        },
        "nl_agent": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "Natural language query for the LLM agent to process",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "label": "Query Type",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "SQL Generation Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "Query Agent Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "nl_agent",
            "task_name": "tasks.tables.integrations.mysql.query",
            "description": "Let an LLM agent query the database",
            "label": "Natural Language Agent",
        },
        "insert": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert into",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"name": "John", "email": "john@example.com"}',
                    "helper_text": "JSON object with column-value pairs to insert",
                },
                {
                    "field": "connection_timeout",
                    "type": "int32",
                    "value": 30,
                    "label": "Connection Timeout",
                    "helper_text": "Connection timeout in seconds (default: 30)",
                },
                {
                    "field": "connection_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Connection Limit",
                    "helper_text": "Maximum number of connections (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "inserted_id",
                    "type": "string",
                    "helper_text": "ID of the inserted record (if available)",
                },
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows inserted",
                },
            ],
            "name": "insert",
            "task_name": "tasks.mysql.insert",
            "description": "Insert rows in a table",
            "label": "Insert Rows",
            "variant": "common_integration_nodes",
            "required": ["table_name", "data"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "data",
                "connection_timeout",
                "connection_limit",
            ],
        },
        "select": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to query",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "columns",
                    "type": "string",
                    "value": "",
                    "label": "Columns",
                    "placeholder": "Select columns",
                    "helper_text": "Choose specific columns (comma-separated or select multiple)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=columns&table={inputs.table_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                        "allow_custom": True,
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "age > 21",
                    "helper_text": "Optional WHERE condition (without WHERE keyword)",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "ORDER BY",
                    "placeholder": "created_at DESC",
                    "helper_text": "Optional ORDER BY clause",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return",
                },
                {
                    "field": "connection_timeout",
                    "type": "int32",
                    "value": 30,
                    "label": "Connection Timeout",
                    "helper_text": "Connection timeout in seconds (default: 30)",
                },
                {
                    "field": "connection_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Connection Limit",
                    "helper_text": "Maximum number of connections (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Selected data as JSON",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names in the result set",
                },
            ],
            "name": "select",
            "task_name": "tasks.mysql.select",
            "description": "Select rows from a table",
            "label": "Select",
            "variant": "common_integration_nodes",
            "required": ["table_name", "limit"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "columns",
                "where_clause",
                "order_by",
                "limit",
                "connection_timeout",
                "connection_limit",
            ],
        },
        "execute_query": {
            "inputs": [
                {
                    "field": "sql_query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "SELECT * FROM users WHERE age > 21",
                    "helper_text": "SQL query to execute",
                },
                {
                    "field": "parameters",
                    "type": "string",
                    "value": "",
                    "label": "Query Parameters",
                    "placeholder": "value1,value2,value3",
                    "helper_text": "Comma-separated parameters for parameterized queries (optional)",
                },
                {
                    "field": "connection_timeout",
                    "type": "int32",
                    "value": 30,
                    "label": "Connection Timeout",
                    "helper_text": "Connection timeout in seconds (default: 30)",
                },
                {
                    "field": "connection_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Connection Limit",
                    "helper_text": "Maximum number of connections (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Query results as JSON",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names in the result set",
                },
                {
                    "field": "execution_time",
                    "type": "string",
                    "helper_text": "Query execution time in seconds",
                },
            ],
            "name": "execute_query",
            "task_name": "tasks.mysql.execute_query",
            "description": "Execute a SQL query",
            "label": "Execute Query",
            "variant": "common_integration_nodes",
            "required": ["sql_query"],
            "inputs_sort_order": [
                "integration",
                "action",
                "sql_query",
                "parameters",
                "connection_timeout",
                "connection_limit",
            ],
        },
        "update": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_to_match_on",
                    "type": "string",
                    "value": "",
                    "label": "Column to Match On",
                    "placeholder": "id",
                    "helper_text": "Column used to find the row to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=columns&table={inputs.table_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value to Match On",
                    "placeholder": "123",
                    "helper_text": "Value in the match column to identify the row",
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Update Data",
                    "placeholder": '{"name": "Jane", "status": "active"}',
                    "helper_text": "JSON object with column-value pairs to update",
                },
                {
                    "field": "connection_timeout",
                    "type": "int32",
                    "value": 30,
                    "label": "Connection Timeout",
                    "helper_text": "Connection timeout in seconds (default: 30)",
                },
                {
                    "field": "connection_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Connection Limit",
                    "helper_text": "Maximum number of connections (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows updated",
                }
            ],
            "name": "update",
            "task_name": "tasks.mysql.update",
            "description": "Update rows in a table",
            "label": "Update",
            "variant": "common_integration_nodes",
            "required": ["table_name", "column_to_match_on", "value", "data"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "column_to_match_on",
                "value",
                "data",
                "connection_timeout",
                "connection_limit",
            ],
        },
        "upsert": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert or update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_to_match_on",
                    "type": "string",
                    "value": "",
                    "label": "Column to Match On",
                    "placeholder": "id",
                    "helper_text": "Column used to find the row to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=columns&table={inputs.table_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "value": "",
                    "label": "Value to Match On",
                    "placeholder": "123",
                    "helper_text": "Value in the match column to identify the row",
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"id": 1, "name": "John", "email": "john@example.com"}',
                    "helper_text": "JSON object with column-value pairs to insert or update",
                },
                {
                    "field": "connection_timeout",
                    "type": "int32",
                    "value": 30,
                    "label": "Connection Timeout",
                    "helper_text": "Connection timeout in seconds (default: 30)",
                },
                {
                    "field": "connection_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Connection Limit",
                    "helper_text": "Maximum number of connections (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the inserted or updated record (if available)",
                },
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows affected",
                },
            ],
            "name": "upsert",
            "task_name": "tasks.mysql.upsert",
            "description": "Insert or update rows in a table",
            "label": "Insert or Update",
            "variant": "common_integration_nodes",
            "required": ["table_name", "column_to_match_on", "value", "data"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "column_to_match_on",
                "value",
                "data",
                "connection_timeout",
                "connection_limit",
            ],
        },
        "delete_table": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "delete_command",
                    "type": "string",
                    "value": "delete",
                    "label": "Command",
                    "helper_text": "Delete command to execute (truncate, delete, or drop)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Delete", "value": "delete"},
                            {"label": "Truncate", "value": "truncate"},
                            {"label": "Drop", "value": "drop"},
                        ],
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "id = 123",
                    "helper_text": "WHERE condition for delete command (not used for truncate/drop)",
                },
                {
                    "field": "connection_timeout",
                    "type": "int32",
                    "value": 30,
                    "label": "Connection Timeout",
                    "helper_text": "Connection timeout in seconds (default: 30)",
                },
                {
                    "field": "connection_limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Connection Limit",
                    "helper_text": "Maximum number of connections (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows deleted",
                },
                {
                    "field": "table_dropped",
                    "type": "bool",
                    "helper_text": "Whether the entire table was dropped",
                },
            ],
            "name": "delete_table",
            "task_name": "tasks.mysql.delete",
            "description": "Delete an entire table or rows in a table",
            "label": "Delete",
            "variant": "common_integration_nodes",
            "required": ["table_name", "delete_command"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_name",
                "delete_command",
                "where_clause",
                "connection_timeout",
                "connection_limit",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        column_to_match_on: str = "",
        columns: str = "",
        connection_limit: int = 10,
        connection_timeout: int = 30,
        data: str = "",
        delete_command: str = "delete",
        limit: int = 10,
        order_by: str = "",
        parameters: str = "",
        query_agent_model: str = "gpt-4-turbo-preview",
        query_type: str = "Raw SQL",
        sql_generation_model: str = "gpt-4-turbo-preview",
        sql_query: str = "",
        table_name: str = "",
        value: str = "",
        where_clause: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_mysql",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if query is not None:
            self.inputs["query"] = query
        if query_type is not None:
            self.inputs["query_type"] = query_type
        if sql_generation_model is not None:
            self.inputs["sql_generation_model"] = sql_generation_model
        if query_agent_model is not None:
            self.inputs["query_agent_model"] = query_agent_model
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if data is not None:
            self.inputs["data"] = data
        if connection_timeout is not None:
            self.inputs["connection_timeout"] = connection_timeout
        if connection_limit is not None:
            self.inputs["connection_limit"] = connection_limit
        if columns is not None:
            self.inputs["columns"] = columns
        if where_clause is not None:
            self.inputs["where_clause"] = where_clause
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if limit is not None:
            self.inputs["limit"] = limit
        if sql_query is not None:
            self.inputs["sql_query"] = sql_query
        if parameters is not None:
            self.inputs["parameters"] = parameters
        if column_to_match_on is not None:
            self.inputs["column_to_match_on"] = column_to_match_on
        if value is not None:
            self.inputs["value"] = value
        if delete_command is not None:
            self.inputs["delete_command"] = delete_command
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMysqlNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
