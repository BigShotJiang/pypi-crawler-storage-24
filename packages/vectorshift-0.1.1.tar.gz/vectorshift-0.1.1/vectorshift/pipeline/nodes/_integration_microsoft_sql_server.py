"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_microsoft_sql_server")
class IntegrationMicrosoftSqlServerNode(Node):
    """
    Microsoft SQL Server

    ## Inputs
    ### Common Inputs
        action: Select the database operation to perform
        integration: Connect to your SQL Server database
    ### create_rows
        batch_size: Number of rows to insert per batch
        columns: Specific columns to insert (optional - uses all if empty)
        data: JSON array of objects or single object to insert into the table
        table_name: Name of the table to insert data into
    ### delete_rows
        confirm_delete: Confirm that you want to delete the specified records
        limit: Maximum number of rows to return
        table_name: Name of the table to insert data into
        where_clause: WHERE condition to identify records to update
    ### update_rows
        data: JSON array of objects or single object to insert into the table
        limit: Maximum number of rows to return
        table_name: Name of the table to insert data into
        where_clause: WHERE condition to identify records to update
    ### execute_query
        limit: Maximum number of rows to return
        parameters: Query parameters for prepared statements
        sql_query: SQL query to execute
    ### get_tables
        limit: Maximum number of rows to return

    ## Outputs
    ### execute_query
        columns: Column names from the query result
        execution_time: Query execution time in seconds
        raw_data: Raw JSON response from the database
        results: Query results as JSON string
        row_count: Number of rows returned
    ### create_rows
        execution_time: Insert operation execution time in seconds
        raw_data: Raw response from the database
        rows_inserted: Number of rows successfully inserted
    ### update_rows
        execution_time: Update operation execution time in seconds
        output: Success message with details
        raw_data: Raw response from the database
        rows_updated: Number of rows successfully updated
        sql_query: Generated SQL query
    ### delete_rows
        execution_time: Delete operation execution time in seconds
        output: Success message with details
        raw_data: Raw response from the database
        rows_deleted: Number of rows successfully deleted
        sql_query: Generated SQL query
    ### get_tables
        raw_data: Raw response from the database
        table_count: Number of tables returned
        tables: List of table names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the database operation to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your SQL Server database",
            "value": None,
            "type": "integration<Microsoft SQL Server>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "execute_query": {
            "inputs": [
                {
                    "field": "sql_query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "SELECT * FROM users WHERE age > ?",
                    "helper_text": "SQL query to execute",
                },
                {
                    "field": "parameters",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Parameters",
                    "helper_text": "Query parameters for prepared statements",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Row Limit",
                    "helper_text": "Maximum number of rows to return",
                },
            ],
            "outputs": [
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Query results as JSON string",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "execution_time",
                    "type": "float",
                    "helper_text": "Query execution time in seconds",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names from the query result",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response from the database",
                },
            ],
            "name": "execute_query",
            "task_name": "tasks.microsoft_sql_server.execute_query",
            "description": "Execute a SQL query and return results",
            "label": "Execute Query",
            "variant": "common_integration_nodes",
            "required": ["sql_query", "limit"],
        },
        "create_rows": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table Name",
                    "placeholder": "Select table",
                    "helper_text": "Name of the table to insert data into",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '[{"column1": "value1", "column2": "value2"}]',
                    "helper_text": "JSON array of objects or single object to insert into the table",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Columns",
                    "helper_text": "Specific columns to insert (optional - uses all if empty)",
                },
                {
                    "field": "batch_size",
                    "type": "int32",
                    "value": 1000,
                    "label": "Batch Size",
                    "helper_text": "Number of rows to insert per batch",
                },
            ],
            "outputs": [
                {
                    "field": "rows_inserted",
                    "type": "int32",
                    "helper_text": "Number of rows successfully inserted",
                },
                {
                    "field": "execution_time",
                    "type": "float",
                    "helper_text": "Insert operation execution time in seconds",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from the database",
                },
            ],
            "name": "create_rows",
            "task_name": "tasks.microsoft_sql_server.create_rows",
            "description": "Insert rows into a SQL Server table",
            "label": "Create Rows",
            "variant": "common_integration_nodes",
            "required": ["table_name", "data"],
        },
        "update_rows": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Update Data",
                    "placeholder": '{"column1": "new_value1", "column2": "new_value2"}',
                    "helper_text": "JSON object with column-value pairs to update",
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "id = 123 AND status = 'active'",
                    "helper_text": "WHERE condition to identify records to update",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 0,
                    "label": "Update Limit",
                    "helper_text": "Maximum number of rows to update (0 for no limit)",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Success message with details",
                },
                {
                    "field": "rows_updated",
                    "type": "int32",
                    "helper_text": "Number of rows successfully updated",
                },
                {
                    "field": "execution_time",
                    "type": "float",
                    "helper_text": "Update operation execution time in seconds",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from the database",
                },
            ],
            "name": "update_rows",
            "task_name": "tasks.microsoft_sql_server.update_rows",
            "description": "Update existing data in a SQL Server table",
            "label": "Update Rows",
            "variant": "common_integration_nodes",
            "required": ["table_name", "data", "where_clause", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "data",
                "where_clause",
                "limit",
            ],
        },
        "delete_rows": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to delete from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "age > 65 AND status = 'inactive'",
                    "helper_text": "WHERE condition to identify records to delete",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 0,
                    "label": "Delete Limit",
                    "helper_text": "Maximum number of rows to delete (0 for no limit)",
                },
                {
                    "field": "confirm_delete",
                    "type": "bool",
                    "value": False,
                    "label": "Confirm Delete",
                    "helper_text": "Confirm that you want to delete the specified records",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Success message with details",
                },
                {
                    "field": "rows_deleted",
                    "type": "int32",
                    "helper_text": "Number of rows successfully deleted",
                },
                {
                    "field": "execution_time",
                    "type": "float",
                    "helper_text": "Delete operation execution time in seconds",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from the database",
                },
            ],
            "name": "delete_rows",
            "task_name": "tasks.microsoft_sql_server.delete_rows",
            "description": "Delete data from a SQL Server table",
            "label": "Delete Rows",
            "variant": "common_integration_nodes",
            "required": ["table_name", "where_clause", "confirm_delete", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "where_clause",
                "limit",
                "confirm_delete",
            ],
        },
        "get_tables": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of tables to return",
                }
            ],
            "outputs": [
                {
                    "field": "tables",
                    "type": "vec<string>",
                    "helper_text": "List of table names",
                },
                {
                    "field": "table_count",
                    "type": "int32",
                    "helper_text": "Number of tables returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from the database",
                },
            ],
            "name": "get_tables",
            "task_name": "tasks.microsoft_sql_server.get_tables",
            "description": "Get multiple tables",
            "label": "List Tables",
            "variant": "common_integration_nodes",
            "required": ["limit"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        batch_size: int = 1000,
        columns: List[str] = [],
        confirm_delete: bool = False,
        data: str = "",
        limit: int = 10,
        parameters: List[str] = [],
        sql_query: str = "",
        table_name: str = "",
        where_clause: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_microsoft_sql_server",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if sql_query is not None:
            self.inputs["sql_query"] = sql_query
        if parameters is not None:
            self.inputs["parameters"] = parameters
        if limit is not None:
            self.inputs["limit"] = limit
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if data is not None:
            self.inputs["data"] = data
        if columns is not None:
            self.inputs["columns"] = columns
        if batch_size is not None:
            self.inputs["batch_size"] = batch_size
        if where_clause is not None:
            self.inputs["where_clause"] = where_clause
        if confirm_delete is not None:
            self.inputs["confirm_delete"] = confirm_delete
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMicrosoftSqlServerNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
