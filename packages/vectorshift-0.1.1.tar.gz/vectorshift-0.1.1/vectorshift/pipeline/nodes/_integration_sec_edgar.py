"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_sec_edgar")
class IntegrationSecEdgarNode(Node):
    """
    SEC EDGAR

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to SEC EDGAR
    ### get_company_filings
        cik: Central Index Key (CIK) of the company. Can be with or without leading zeros (e.g., '320193' or '0000320193')
    ### get_company_xbrl_facts
        cik: Central Index Key (CIK) of the company. Can be with or without leading zeros (e.g., '320193' or '0000320193')
    ### get_company_xbrl_concept
        cik: Central Index Key (CIK) of the company. Can be with or without leading zeros (e.g., '320193' or '0000320193')
        concept: The XBRL concept/tag name (e.g., 'Revenues', 'AccountsPayableCurrent', 'Assets')
        taxonomy: The taxonomy (e.g., 'us-gaap', 'dei', 'ifrs-full')
    ### lookup_company
        company: Select a company from the dropdown or provide a CIK (e.g., '0000320193' for Apple)
    ### get_xbrl_frame
        concept: The XBRL concept/tag name (e.g., 'Revenues', 'AccountsPayableCurrent', 'Assets')
        period: Period identifier (e.g., 'CY2023' for annual, 'CY2023Q1I' for Q1 2023 instantaneous)
        taxonomy: The taxonomy (e.g., 'us-gaap', 'dei', 'ifrs-full')
        unit: Unit of measure (e.g., 'USD', 'shares', 'pure')

    ## Outputs
    ### lookup_company
        category: Company category
        cik: The company's CIK
        company_name: The company's name
        description: Company description
        ein: Employer Identification Number
        entity_type: Type of entity
        exchanges: Stock exchanges where traded
        fiscal_year_end: Fiscal year end date
        phone: Company phone number
        raw_data: Raw API response data
        sic: Standard Industrial Classification code
        sic_description: Description of the SIC code
        state_of_incorporation: State of incorporation
        tickers: Stock ticker symbols
        total_filings_count: Total number of filings available for this company
        website: Company website
    ### get_company_filings
        category: Company category
        cik: The company's CIK
        company_name: The company's name
        description: Company description
        ein: Employer Identification Number
        entity_type: Type of entity
        exchanges: Stock exchanges where traded
        fiscal_year_end: Fiscal year end date
        phone: Company phone number
        raw_data: Raw API response data
        sic: Standard Industrial Classification code
        sic_description: Description of the SIC code
        state_of_incorporation: State of incorporation
        tickers: Stock ticker symbols
        total_filings_count: Total number of filings available for this company
        website: Company website
    ### get_company_xbrl_facts
        cik: The company's CIK
        entity_name: The company's name
        raw_data: Raw API response data
        taxonomies: List of taxonomies with concepts and data points
        total_concepts: Total number of concepts across all taxonomies
    ### get_company_xbrl_concept
        cik: The company's CIK
        concept: The concept/tag name
        description: Description of the concept
        entity_name: The company's name
        label: Human-readable label for the concept
        raw_data: Raw API response data
        taxonomy: The taxonomy used
        units: Time series data grouped by unit of measure
    ### get_xbrl_frame
        companies: List of companies with their values for this concept
        companies_count: Number of companies in the frame
        concept: The concept/tag name
        description: Description of the concept
        label: Human-readable label for the concept
        period: Period identifier
        raw_data: Raw API response data
        taxonomy: The taxonomy used
        unit: Unit of measure
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to SEC EDGAR",
            "value": None,
            "type": "integration<Sec Edgar>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "lookup_company": {
            "inputs": [
                {
                    "field": "company",
                    "type": "string",
                    "label": "Select Company",
                    "helper_text": "Select a company from the dropdown or provide a CIK (e.g., '0000320193' for Apple)",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=company&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {"field": "cik", "type": "string", "helper_text": "The company's CIK"},
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "The company's name",
                },
                {
                    "field": "entity_type",
                    "type": "string",
                    "helper_text": "Type of entity",
                },
                {
                    "field": "sic",
                    "type": "string",
                    "helper_text": "Standard Industrial Classification code",
                },
                {
                    "field": "sic_description",
                    "type": "string",
                    "helper_text": "Description of the SIC code",
                },
                {
                    "field": "tickers",
                    "type": "vec<string>",
                    "helper_text": "Stock ticker symbols",
                },
                {
                    "field": "exchanges",
                    "type": "vec<string>",
                    "helper_text": "Stock exchanges where traded",
                },
                {
                    "field": "ein",
                    "type": "string",
                    "helper_text": "Employer Identification Number",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Company description",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Company website",
                },
                {
                    "field": "category",
                    "type": "string",
                    "helper_text": "Company category",
                },
                {
                    "field": "fiscal_year_end",
                    "type": "string",
                    "helper_text": "Fiscal year end date",
                },
                {
                    "field": "state_of_incorporation",
                    "type": "string",
                    "helper_text": "State of incorporation",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Company phone number",
                },
                {
                    "field": "total_filings_count",
                    "type": "int32",
                    "helper_text": "Total number of filings available for this company",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "lookup_company",
            "task_name": "tasks.sec_edgar.lookup_company",
            "description": "Select a company from the dropdown and get its SEC filing information",
            "label": "Lookup Company",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "company"],
            "required": ["company"],
        },
        "get_company_filings": {
            "inputs": [
                {
                    "field": "cik",
                    "type": "string",
                    "value": "",
                    "label": "CIK",
                    "placeholder": "0000320193",
                    "helper_text": "Central Index Key (CIK) of the company. Can be with or without leading zeros (e.g., '320193' or '0000320193')",
                }
            ],
            "outputs": [
                {"field": "cik", "type": "string", "helper_text": "The company's CIK"},
                {
                    "field": "company_name",
                    "type": "string",
                    "helper_text": "The company's name",
                },
                {
                    "field": "entity_type",
                    "type": "string",
                    "helper_text": "Type of entity",
                },
                {
                    "field": "sic",
                    "type": "string",
                    "helper_text": "Standard Industrial Classification code",
                },
                {
                    "field": "sic_description",
                    "type": "string",
                    "helper_text": "Description of the SIC code",
                },
                {
                    "field": "tickers",
                    "type": "vec<string>",
                    "helper_text": "Stock ticker symbols",
                },
                {
                    "field": "exchanges",
                    "type": "vec<string>",
                    "helper_text": "Stock exchanges where traded",
                },
                {
                    "field": "ein",
                    "type": "string",
                    "helper_text": "Employer Identification Number",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Company description",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Company website",
                },
                {
                    "field": "category",
                    "type": "string",
                    "helper_text": "Company category",
                },
                {
                    "field": "fiscal_year_end",
                    "type": "string",
                    "helper_text": "Fiscal year end date",
                },
                {
                    "field": "state_of_incorporation",
                    "type": "string",
                    "helper_text": "State of incorporation",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "helper_text": "Company phone number",
                },
                {
                    "field": "total_filings_count",
                    "type": "int32",
                    "helper_text": "Total number of filings available for this company",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_company_filings",
            "task_name": "tasks.sec_edgar.get_company_filings",
            "description": "Get company filing history from SEC EDGAR Submissions API",
            "label": "Get Company Filings",
            "variant": "default_integration_nodes",
            "input_sort_order": ["action", "integration", "cik"],
            "required": ["cik"],
        },
        "get_company_xbrl_facts": {
            "inputs": [
                {
                    "field": "cik",
                    "type": "string",
                    "value": "",
                    "label": "CIK",
                    "placeholder": "0000320193",
                    "helper_text": "Central Index Key (CIK) of the company",
                }
            ],
            "outputs": [
                {"field": "cik", "type": "string", "helper_text": "The company's CIK"},
                {
                    "field": "entity_name",
                    "type": "string",
                    "helper_text": "The company's name",
                },
                {
                    "field": "taxonomies",
                    "type": "vec<string>",
                    "helper_text": "List of taxonomies with concepts and data points",
                },
                {
                    "field": "total_concepts",
                    "type": "int32",
                    "helper_text": "Total number of concepts across all taxonomies",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_company_xbrl_facts",
            "task_name": "tasks.sec_edgar.get_company_xbrl_facts",
            "description": "Get all XBRL financial facts for a company",
            "label": "Get Company XBRL Facts",
            "variant": "default_integration_nodes",
            "input_sort_order": ["action", "integration", "cik"],
            "required": ["cik"],
        },
        "get_company_xbrl_concept": {
            "inputs": [
                {
                    "field": "cik",
                    "type": "string",
                    "value": "",
                    "label": "CIK",
                    "placeholder": "0000320193",
                    "helper_text": "Central Index Key (CIK) of the company",
                },
                {
                    "field": "taxonomy",
                    "type": "string",
                    "value": "",
                    "label": "Taxonomy",
                    "placeholder": "us-gaap",
                    "helper_text": "The taxonomy (e.g., 'us-gaap', 'dei', 'ifrs-full')",
                },
                {
                    "field": "concept",
                    "type": "string",
                    "value": "",
                    "label": "Concept",
                    "placeholder": "Revenues",
                    "helper_text": "The XBRL concept/tag name (e.g., 'Revenues', 'AccountsPayableCurrent', 'Assets')",
                },
            ],
            "outputs": [
                {"field": "cik", "type": "int32", "helper_text": "The company's CIK"},
                {
                    "field": "entity_name",
                    "type": "string",
                    "helper_text": "The company's name",
                },
                {
                    "field": "taxonomy",
                    "type": "string",
                    "helper_text": "The taxonomy used",
                },
                {
                    "field": "concept",
                    "type": "string",
                    "helper_text": "The concept/tag name",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Human-readable label for the concept",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the concept",
                },
                {
                    "field": "units",
                    "type": "vec<string>",
                    "helper_text": "Time series data grouped by unit of measure",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_company_xbrl_concept",
            "task_name": "tasks.sec_edgar.get_company_xbrl_concept",
            "description": "Get time series data for a specific XBRL concept for a company",
            "label": "Get Company XBRL Concept",
            "variant": "default_integration_nodes",
            "input_sort_order": ["action", "integration", "cik", "taxonomy", "concept"],
            "required": ["cik", "taxonomy", "concept"],
        },
        "get_xbrl_frame": {
            "inputs": [
                {
                    "field": "taxonomy",
                    "type": "string",
                    "value": "",
                    "label": "Taxonomy",
                    "placeholder": "us-gaap",
                    "helper_text": "The taxonomy (e.g., 'us-gaap', 'dei', 'ifrs-full')",
                },
                {
                    "field": "concept",
                    "type": "string",
                    "value": "",
                    "label": "Concept",
                    "placeholder": "AccountsPayableCurrent",
                    "helper_text": "The XBRL concept/tag name (e.g., 'Revenue', 'AccountsPayableCurrent')",
                },
                {
                    "field": "unit",
                    "type": "string",
                    "value": "",
                    "label": "Unit",
                    "placeholder": "USD",
                    "helper_text": "Unit of measure (e.g., 'USD', 'shares', 'pure')",
                },
                {
                    "field": "period",
                    "type": "string",
                    "value": "",
                    "label": "Period",
                    "placeholder": "CY2023Q1I",
                    "helper_text": "Period identifier (e.g., 'CY2023' for annual, 'CY2023Q1I' for Q1 2023 instantaneous)",
                },
            ],
            "outputs": [
                {
                    "field": "taxonomy",
                    "type": "string",
                    "helper_text": "The taxonomy used",
                },
                {
                    "field": "concept",
                    "type": "string",
                    "helper_text": "The concept/tag name",
                },
                {
                    "field": "label",
                    "type": "string",
                    "helper_text": "Human-readable label for the concept",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the concept",
                },
                {"field": "unit", "type": "string", "helper_text": "Unit of measure"},
                {
                    "field": "period",
                    "type": "string",
                    "helper_text": "Period identifier",
                },
                {
                    "field": "companies",
                    "type": "vec<string>",
                    "helper_text": "List of companies with their values for this concept",
                },
                {
                    "field": "companies_count",
                    "type": "int32",
                    "helper_text": "Number of companies in the frame",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_xbrl_frame",
            "task_name": "tasks.sec_edgar.get_xbrl_frame",
            "description": "Get cross-company data for a specific concept and period",
            "label": "Get XBRL Frame",
            "variant": "default_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "taxonomy",
                "concept",
                "unit",
                "period",
            ],
            "required": ["taxonomy", "concept", "unit", "period"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        cik: str = "",
        company: Optional[str] = None,
        concept: str = "",
        period: str = "",
        taxonomy: str = "",
        unit: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_sec_edgar",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if company is not None:
            self.inputs["company"] = company
        if cik is not None:
            self.inputs["cik"] = cik
        if taxonomy is not None:
            self.inputs["taxonomy"] = taxonomy
        if concept is not None:
            self.inputs["concept"] = concept
        if unit is not None:
            self.inputs["unit"] = unit
        if period is not None:
            self.inputs["period"] = period
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationSecEdgarNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
