"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_hubspot")
class IntegrationHubspotNode(Node):
    """
    Hubspot

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'get_contacts'
        query: General search query
        city: City of residence
        company_name: Search by company name
        country: Country name
        created_date: Filter by creation date (ISO 8601 format)
        email: Search by email address
        first_name: Contact's first name
        hs_analytics_source: Filter by original source
        hs_latest_source: Filter by latest source
        hs_lead_status: Filter by HubSpot lead status
        hubspot_owner_id: Filter by contact owner ID
        job_title: Job title of the contact
        last_modified_date: Filter by last modified date (ISO 8601 format)
        last_name: Contact's last name
        lead_status: Filter by lead status
        lifecycle_stage: Filter by lifecycle stage
        phone: Search by phone number
        properties: Comma-separated properties to fetch
        sort_by: Field to sort by
        sort_order: Sort order (asc/desc)
        state: Search by state
        use_date: Toggle to use dates
        website: Search by website
    ### When action = 'get_companies'
        query: General search query
        annual_revenue: Annual revenue
        city: City of residence
        country: Country name
        created_date: Filter by creation date (ISO 8601 format)
        domain: Search by domain
        founded_year: Filter by founded year
        hs_analytics_source: Filter by original source
        hs_analytics_source_data_1: Filter by source data 1
        hs_analytics_source_data_2: Filter by source data 2
        hubspot_owner_id: Filter by contact owner ID
        industry: Type of industry
        is_public: Filter by public company status
        last_modified_date: Filter by last modified date (ISO 8601 format)
        lead_status: Filter by lead status
        lifecycle_stage: Filter by lifecycle stage
        name: Search by company name
        number_of_employees: Employee count
        phone: Search by phone number
        properties: Comma-separated properties to fetch
        sort_by: Field to sort by
        sort_order: Sort order (asc/desc)
        state: Search by state
        type: Filter by company type
        use_date: Toggle to use dates
        web_technologies: Filter by web technologies
        zip: Search by zip code
    ### When action = 'get_deals'
        query: General search query
        amount: Deal amount
        close_date: Deal close date (ISO 8601 format)
        created_date: Filter by creation date (ISO 8601 format)
        deal_currency_code: Filter by currency code
        deal_name: Deal name
        deal_stage: Filter by deal stage
        deal_type: Deal type
        hs_analytics_source: Filter by original source
        hs_date_entered_closed_lost: Filter by date entered closed lost (ISO 8601 format)
        hs_date_entered_closed_won: Filter by date entered closed won (ISO 8601 format)
        hs_deal_stage_probability: Filter by deal probability
        hs_forecast_amount: Filter by forecast amount
        hs_is_closed: Filter by closed status
        hs_is_deal_split: Filter by deal split status
        hs_latest_source: Filter by latest source
        hubspot_owner_id: Filter by contact owner ID
        last_modified_date: Filter by last modified date (ISO 8601 format)
        num_associated_contacts: Filter by number of associated contacts
        num_contacted_notes: Filter by number of contact notes
        pipeline: Pipeline ID
        properties: Comma-separated properties to fetch
        sort_by: Field to sort by
        sort_order: Sort order (asc/desc)
        use_date: Toggle to use dates
    ### When action = 'get_tickets'
        query: General search query
        closed_date: Filter by closed date (ISO 8601 format)
        created_date: Filter by creation date (ISO 8601 format)
        first_agent_reply_date: Filter by first agent reply date (ISO 8601 format)
        hs_num_times_contacted: Filter by number of times contacted
        hs_pipeline: Filter by pipeline
        hs_pipeline_stage: Filter by pipeline stage
        hs_resolution: Filter by ticket resolution
        hs_ticket_category: Filter by ticket category
        hs_ticket_priority: Filter by ticket priority
        hs_time_to_close: Filter by time to close (milliseconds)
        hs_time_to_first_agent_reply: Filter by time to first agent reply
        hubspot_owner_id: Filter by contact owner ID
        last_modified_date: Filter by last modified date (ISO 8601 format)
        properties: Comma-separated properties to fetch
        sort_by: Field to sort by
        sort_order: Sort order (asc/desc)
        source_type: Filter by source type
        subject: Search by ticket subject
        tags: Filter by tags (comma-separated)
        use_date: Toggle to use dates
    ### When action = 'get_engagements'
        query: General search query
        company_id: Filter by associated company ID
        contact_id: Filter by associated contact ID
        created_date: Filter by creation date (ISO 8601 format)
        deal_id: Filter by associated deal ID
        engagement_type: Filter by engagement type (CALL, EMAIL, MEETING, TASK)
        hs_activity_type: Filter by activity type
        hs_communication_channel_type: Filter by communication channel type
        hs_communication_logged_from: Filter by where engagement was logged from
        hubspot_owner_id: Filter by contact owner ID
        last_modified_date: Filter by last modified date (ISO 8601 format)
        properties: Comma-separated properties to fetch
        sort_by: Field to sort by
        sort_order: Sort order (asc/desc)
        timestamp: Engagement timestamp (ISO 8601 format)
        use_date: Toggle to use dates
    ### When action = 'create_company'
        about_us: About the company
        annual_revenue: Annual revenue
        city: City of residence
        company_domain_name: Company's domain name
        company_owner: Owner's user ID
        country_region: Country or region
        create_company_name: Required company name
        description: Company description
        industry: Type of industry
        lead_status: Filter by lead status
        lifecycle: Lifecycle stage
        number_of_employees: Employee count
        phone_number: Main phone number
        website_url: Contact's website
    ### When action = 'create_deal'
        amount: Deal amount
        associated_company: Associated company IDs
        associated_vids: Associated contact IDs
        close_date: Deal close date (ISO 8601 format)
        create_deal_stage: Required deal stage ID
        deal_name: Deal name
        deal_owner: Deal owner ID
        deal_type: Deal type
        description: Company description
        pipeline: Pipeline ID
    ### When action = 'create_contact'
        associated_company_id: ID of associated company
        city: City of residence
        company: Name of the company
        country: Country name
        create_email: Required contact email
        custom_properties: Custom properties to add to the contact
        first_name: Contact's first name
        job_title: Job title of the contact
        last_name: Contact's last name
        mobile_phone_number: Mobile number
        phone_number: Main phone number
        postal_code: Postal or ZIP code
        state_region: State or region
        street_address: Street address
        website_url: Contact's website
    ### When action = 'create_ticket'
        associated_company_ids: Associated companies
        associated_contact_ids: Associated contacts
        category: Ticket category
        close_date: Deal close date (ISO 8601 format)
        create_ticket_name: Ticket subject (required)
        create_ticket_pipeline_id: Pipeline ID (required)
        create_ticket_stage_id: Stage ID (required)
        description: Company description
        priority: Priority level
        ticket_owner_id: Ticket owner ID
    ### When action = 'add_contact_to_list'
        by: Method to identify contacts: email or Contact ID
        contact_ids: Comma-separated contact IDs
        emails: Comma-separated email addresses (e.g., email1@example.com,email2@example.com)
        list_id: HubSpot list ID (required)
    ### When action = 'create_engagement'
        company_ids: Comma-separated company IDs
        contact_ids: Comma-separated contact IDs
        create_engagement_type: Select Engagement type (required)
        deal_ids: Comma-separated deal IDs
        metadata: Type-specific metadata (JSON)
        owner_id: Engagement owner ID
        timestamp: Engagement timestamp (ISO 8601 format)
    ### When action = 'remove_contact_from_list'
        contact_ids: Comma-separated contact IDs
        list_id: HubSpot list ID (required)
    ### When action = 'get_contacts' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_companies' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_deals' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_tickets' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'get_engagements' and use_date = True and use_exact_date = False
        date_range: pick the relative date range
    ### When action = 'delete_company'
        delete_company_id: HubSpot company ID to delete (required)
    ### When action = 'delete_contact'
        delete_contact_id: HubSpot contact ID to delete (required)
    ### When action = 'delete_deal'
        delete_deal_id: HubSpot deal ID to delete (required)
    ### When action = 'delete_engagement'
        delete_engagement_id: HubSpot engagement ID to delete (required)
        type: Filter by company type
    ### When action = 'delete_ticket'
        delete_ticket_id: HubSpot ticket ID to delete (required)
    ### When action = 'get_contacts' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_companies' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_deals' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_tickets' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'get_engagements' and use_date = True and use_exact_date = True
        exact_date: Pick the start and end dates
    ### When action = 'read_company'
        include_merge_audits: Include merge history if true
        properties: Comma-separated properties to fetch
        read_company_id: HubSpot company ID to read (required)
    ### When action = 'read_deal'
        include_property_versions: Include property history if true
        properties: Comma-separated properties to fetch
        read_deal_id: HubSpot deal ID to read (required)
    ### When action = 'get_contacts' and use_date = False
        num_messages: Specify the number of contacts to fetch
    ### When action = 'get_companies' and use_date = False
        num_messages: Specify the number of contacts to fetch
    ### When action = 'get_deals' and use_date = False
        num_messages: Specify the number of contacts to fetch
    ### When action = 'get_tickets' and use_date = False
        num_messages: Specify the number of contacts to fetch
    ### When action = 'get_engagements' and use_date = False
        num_messages: Specify the number of contacts to fetch
    ### When action = 'read_contact'
        properties: Comma-separated properties to fetch
        read_contact_id: HubSpot contact ID to read (required)
        show_list_memberships: Include list memberships
    ### When action = 'read_ticket'
        properties: Comma-separated properties to fetch
        read_ticket_id: HubSpot ticket ID to read (required)
    ### When action = 'read_engagement'
        properties: Comma-separated properties to fetch
        read_engagement_id: HubSpot engagement ID to read (required)
        type: Filter by company type
    ### When action = 'update_company'
        update_about_us: About the company
        update_annual_revenue: Annual revenue
        update_city: City of residence
        update_company_domain_name: Company domain
        update_company_id: HubSpot company ID to update (required)
        update_company_name: Company name
        update_company_owner: Owner's user ID
        update_country_region: Country or region
        update_description: Company description
        update_industry: Type of industry
        update_lead_status: Lead status
        update_lifecycle: Lifecycle stage
        update_number_of_employees: Employee count
        update_phone_number: Main phone number
        update_website_url: Contact's website
    ### When action = 'update_deal'
        update_amount: Deal amount
        update_close_date: Deal close date (ISO 8601 format)
        update_deal_id: HubSpot deal ID to update (required)
        update_deal_name: Deal name
        update_deal_owner: Deal owner ID
        update_deal_stage: Deal stage ID
        update_deal_type: Deal type
        update_description: Company description
        update_pipeline: Pipeline ID
    ### When action = 'update_ticket'
        update_category: Ticket category
        update_close_date: Deal close date (ISO 8601 format)
        update_description: Company description
        update_priority: Priority level
        update_stage_id: Stage ID
        update_ticket_id: HubSpot ticket ID to update (required)
        update_ticket_name: Ticket subject
        update_ticket_owner_id: Ticket owner ID
    ### When action = 'update_contact'
        update_city: City of residence
        update_company: Name of the company
        update_contact_id: HubSpot contact ID to update (required)
        update_country: Country name
        update_custom_properties: Custom properties to add to the contact
        update_email: Contact email
        update_first_name: Contact's first name
        update_job_title: Job title of the contact
        update_last_name: Contact's last name
        update_mobile_phone_number: Mobile number
        update_phone_number: Main phone number
        update_postal_code: Postal or ZIP code
        update_state_region: State or region
        update_street_address: Street address
        update_website_url: Contact's website
    ### When action = 'get_contacts' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_companies' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_deals' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_tickets' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_engagements' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_deal'
        amount: Deal amount
        close_date: Deal close date
        deal_id: HubSpot deal ID
        deal_name: Deal name
        deal_owner: Deal owner
        deal_type: Deal type
        description: Deal description
        pipeline: Deal pipeline
        probability: Deal probability
        raw_data: Full response data
        stage: Deal stage
    ### When action = 'get_deals'
        amounts: List of amounts
        close_dates: List of close dates
        deal_ids: List of deal IDs
        deal_names: List of deal names
        deal_owners: List of owners
        deal_types: List of deal types
        descriptions: List of descriptions
        pipelines: List of pipelines
        probabilities: List of probabilities
        raw_data: Full response data
        stages: List of stages
        total: Total deals retrieved
    ### When action = 'read_company'
        annual_revenue: Annual revenue
        city: City
        company_id: HubSpot company ID
        country: Country
        description: Company description
        domain: Company domain
        industry: Industry
        name: Company name
        number_of_employees: Employee count
        phone_number: Phone number
        raw_data: Full response data
        state: State
        website: Website
    ### When action = 'get_companies'
        annual_revenues: List of revenues
        cities: List of cities
        company_ids: List of company IDs
        countries: List of countries
        descriptions: List of descriptions
        domains: List of domains
        industries: List of industries
        names: List of company names
        number_of_employees: List of employee counts
        phone_numbers: List of phone numbers
        raw_data: Full response data
        states: List of states
        total: Total count returned
        websites: List of websites
    ### When action = 'get_engagements'
        bodies: Engagement bodies/notes
        created_ats: Created dates
        engagement_ids: HubSpot engagement IDs
        engagement_types: Engagement types (call, email, meeting, task)
        owner_ids: Engagement owner IDs
        raw_data: Raw response data
        subjects: Engagement subjects
        timestamps: Engagement timestamps
        total: Total number of engagements retrieved
        updated_ats: Updated dates
    ### When action = 'read_engagement'
        body: Engagement body/notes
        created_at: Created date
        engagement_id: HubSpot engagement ID
        engagement_type: Engagement type (call, email, meeting, task)
        owner_id: Engagement owner ID
        raw_data: Raw response data
        subject: Engagement subject
        timestamp: Engagement timestamp
        updated_at: Updated date
    ### When action = 'get_tickets'
        categories: Ticket categories
        created_ats: Created dates
        descriptions: Ticket descriptions
        owners: Ticket owners
        pipelines: Ticket pipelines
        priorities: Ticket priorities
        raw_data: Raw response data
        stages: Ticket stages
        statuses: Ticket statuses
        subjects: Ticket subjects
        ticket_ids: HubSpot ticket IDs
        total: Total number of tickets retrieved
        updated_ats: Updated dates
    ### When action = 'read_ticket'
        category: Ticket category
        created_at: Created date
        description: Ticket description
        owner: Ticket owner
        pipeline: Ticket pipeline
        priority: Ticket priority
        raw_data: Raw response data
        stage: Ticket stage
        status: Ticket status
        subject: Ticket subject
        ticket_id: HubSpot ticket ID
        updated_at: Updated date
    ### When action = 'get_contacts'
        cities: List of cities
        companies: List of companies
        contact_ids: List of contact IDs
        countries: List of countries
        emails: List of email addresses
        first_names: List of first names
        job_titles: List of job titles
        last_names: List of last names
        phone_numbers: List of phone numbers
        raw_data: Raw response from HubSpot
        states: List of states
        total: Total contacts retrieved
        websites: List of websites
    ### When action = 'read_contact'
        city: Contact's city
        company: Contact's company
        contact_id: HubSpot contact ID
        country: Contact's country
        email: Contact's email address
        first_name: Contact's first name
        job_title: Contact's job title
        last_name: Contact's last name
        phone_number: Contact's phone number
        raw_data: Raw response from HubSpot
        state: Contact's state
        website: Contact's website
    ### When action = 'create_company'
        company_id: HubSpot company ID
        name: Company name
        raw_data: Full response data
    ### When action = 'update_company'
        company_id: HubSpot company ID
        raw_data: Full response data
        updated: True if update succeeded
    ### When action = 'create_contact'
        contact_id: HubSpot contact ID
        email: Contact email address
        raw_data: Full response data
    ### When action = 'add_contact_to_list'
        contact_ids: HubSpot contact IDs
        list_id: HubSpot list ID
        raw_data: Raw response data
    ### When action = 'remove_contact_from_list'
        contact_ids: HubSpot contact IDs
        list_id: HubSpot list ID
        raw_data: Raw response data
    ### When action = 'create_deal'
        deal_id: HubSpot deal ID
        raw_data: Full response data
        stage: Deal stage ID
    ### When action = 'update_deal'
        deal_id: HubSpot deal ID
        raw_data: Full response data
        updated: True if deal was updated
    ### When action = 'delete_contact'
        deleted: True if contact was deleted
    ### When action = 'delete_company'
        deleted: True if company was deleted
    ### When action = 'delete_deal'
        deleted: True if deal was deleted
    ### When action = 'delete_ticket'
        deleted: Whether the ticket was deleted
    ### When action = 'delete_engagement'
        deleted: Whether the engagement was deleted
    ### When action = 'create_engagement'
        engagement_id: HubSpot engagement ID
        raw_data: Full response data
        type: Engagement type
    ### When action = 'create_ticket'
        raw_data: Full response data
        ticket_id: HubSpot ticket ID
    ### When action = 'update_ticket'
        raw_data: Full response data
        ticket_id: HubSpot ticket ID
        updated: Whether the ticket was updated
    ### When action = 'update_contact'
        updated: True if contact was updated
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Hubspot>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "create_email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@example.com",
                    "helper_text": "Required contact email",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "Contact's first name",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Contact's last name",
                },
                {
                    "field": "company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                    "helper_text": "Name of the company",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title of the contact",
                },
                {
                    "field": "phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Phone Number",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Main phone number",
                },
                {
                    "field": "mobile_phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-987-6543",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "street_address",
                    "type": "string",
                    "value": "",
                    "label": "Street Address",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "Boston",
                    "helper_text": "City of residence",
                },
                {
                    "field": "state_region",
                    "type": "string",
                    "value": "",
                    "label": "State/Region",
                    "placeholder": "MA",
                    "helper_text": "State or region",
                },
                {
                    "field": "postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Postal Code",
                    "placeholder": "02101",
                    "helper_text": "Postal or ZIP code",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "United States",
                    "helper_text": "Country name",
                },
                {
                    "field": "website_url",
                    "type": "string",
                    "value": "",
                    "label": "Website URL",
                    "placeholder": "https://example.com",
                    "helper_text": "Contact's website",
                },
                {
                    "field": "associated_company_id",
                    "type": "string",
                    "value": "",
                    "label": "Associated Company ID",
                    "placeholder": "12345",
                    "helper_text": "ID of associated company",
                },
                {
                    "field": "custom_properties",
                    "type": "string",
                    "value": "",
                    "label": "Custom Properties",
                    "helper_text": "Custom properties to add to the contact",
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "HubSpot contact ID",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Contact email address",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_contact",
            "task_name": "tasks.hubspot.create_contact",
            "description": "Creates a new contact",
            "label": "Create Contact",
            "required": ["create_email"],
        },
        "update_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "update_contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot contact ID to update (required)",
                },
                {
                    "field": "update_email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@example.com",
                    "helper_text": "Contact email",
                },
                {
                    "field": "update_first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "Contact's first name",
                },
                {
                    "field": "update_last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Contact's last name",
                },
                {
                    "field": "update_company",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                    "helper_text": "Name of the company",
                },
                {
                    "field": "update_job_title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Sales Manager",
                    "helper_text": "Job title of the contact",
                },
                {
                    "field": "update_phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Phone Number",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Main phone number",
                },
                {
                    "field": "update_mobile_phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Mobile Phone",
                    "placeholder": "+1-555-987-6543",
                    "helper_text": "Mobile number",
                },
                {
                    "field": "update_street_address",
                    "type": "string",
                    "value": "",
                    "label": "Street Address",
                    "placeholder": "123 Main St",
                    "helper_text": "Street address",
                },
                {
                    "field": "update_city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "Boston",
                    "helper_text": "City of residence",
                },
                {
                    "field": "update_state_region",
                    "type": "string",
                    "value": "",
                    "label": "State/Region",
                    "placeholder": "MA",
                    "helper_text": "State or region",
                },
                {
                    "field": "update_postal_code",
                    "type": "string",
                    "value": "",
                    "label": "Postal Code",
                    "placeholder": "02101",
                    "helper_text": "Postal or ZIP code",
                },
                {
                    "field": "update_country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "United States",
                    "helper_text": "Country name",
                },
                {
                    "field": "update_website_url",
                    "type": "string",
                    "value": "",
                    "label": "Website URL",
                    "placeholder": "https://example.com",
                    "helper_text": "Contact's website",
                },
                {
                    "field": "update_custom_properties",
                    "type": "string",
                    "value": "",
                    "label": "Custom Properties",
                    "helper_text": "Custom properties to add to the contact",
                },
            ],
            "outputs": [
                {
                    "field": "updated",
                    "type": "bool",
                    "helper_text": "True if contact was updated",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "update_contact",
            "task_name": "tasks.hubspot.update_contact",
            "description": "Updates an existing contact",
            "label": "Update Contact",
            "required": ["update_contact_id"],
        },
        "delete_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "delete_contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot contact ID to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "True if contact was deleted",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_contact",
            "task_name": "tasks.hubspot.delete_contact",
            "description": "Deletes a contact by ID",
            "label": "Delete Contact",
            "required": ["delete_contact_id"],
        },
        "read_contact**(*)**(*)": {
            "inputs": [
                {
                    "field": "read_contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot contact ID to read (required)",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
                {
                    "field": "show_list_memberships",
                    "type": "bool",
                    "value": False,
                    "label": "Show List Memberships",
                    "helper_text": "Include list memberships",
                },
            ],
            "outputs": [
                {
                    "field": "contact_id",
                    "type": "string",
                    "helper_text": "HubSpot contact ID",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "Contact's first name",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "Contact's last name",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Contact's email address",
                },
                {
                    "field": "phone_number",
                    "type": "string",
                    "helper_text": "Contact's phone number",
                },
                {
                    "field": "company",
                    "type": "string",
                    "helper_text": "Contact's company",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "helper_text": "Contact's job title",
                },
                {"field": "city", "type": "string", "helper_text": "Contact's city"},
                {"field": "state", "type": "string", "helper_text": "Contact's state"},
                {
                    "field": "country",
                    "type": "string",
                    "helper_text": "Contact's country",
                },
                {
                    "field": "website",
                    "type": "string",
                    "helper_text": "Contact's website",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from HubSpot",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_contact",
            "task_name": "tasks.hubspot.read_contact",
            "description": "Read details of a specific contact",
            "label": "Get Contact",
            "required": ["read_contact_id"],
        },
        "get_contacts**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "john",
                    "helper_text": "General search query",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "placeholder": "john@example.com",
                    "helper_text": "Search by email address",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "placeholder": "John",
                    "helper_text": "Search by first name",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "placeholder": "Doe",
                    "helper_text": "Search by last name",
                },
                {
                    "field": "company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company",
                    "placeholder": "Acme Corp",
                    "helper_text": "Search by company name",
                },
                {
                    "field": "job_title",
                    "type": "string",
                    "value": "",
                    "label": "Job Title",
                    "placeholder": "Manager",
                    "helper_text": "Search by job title",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Search by phone number",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "Boston",
                    "helper_text": "Search by city",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "MA",
                    "helper_text": "Search by state",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "United States",
                    "helper_text": "Search by country",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website",
                    "placeholder": "example.com",
                    "helper_text": "Search by website",
                },
                {
                    "field": "lifecycle_stage",
                    "type": "string",
                    "value": "",
                    "label": "Lifecycle Stage",
                    "placeholder": "lead",
                    "helper_text": "Filter by lifecycle stage",
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "value": "",
                    "label": "Lead Status",
                    "placeholder": "new",
                    "helper_text": "Filter by lead status",
                },
                {
                    "field": "hs_lead_status",
                    "type": "string",
                    "value": "",
                    "label": "HubSpot Lead Status",
                    "placeholder": "NEW",
                    "helper_text": "Filter by HubSpot lead status",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "label": "Created Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by creation date (ISO 8601 format)",
                },
                {
                    "field": "last_modified_date",
                    "type": "string",
                    "value": "",
                    "label": "Last Modified Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by last modified date (ISO 8601 format)",
                },
                {
                    "field": "hs_analytics_source",
                    "type": "string",
                    "value": "",
                    "label": "Original Source",
                    "placeholder": "ORGANIC_SEARCH",
                    "helper_text": "Filter by original source",
                },
                {
                    "field": "hs_latest_source",
                    "type": "string",
                    "value": "",
                    "label": "Latest Source",
                    "placeholder": "DIRECT_TRAFFIC",
                    "helper_text": "Filter by latest source",
                },
                {
                    "field": "hubspot_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Owner ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by contact owner ID",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "createdate",
                    "helper_text": "Field to sort by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "placeholder": "desc",
                    "helper_text": "Sort order (asc/desc)",
                },
            ],
            "outputs": [
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "List of contact IDs",
                },
                {
                    "field": "first_names",
                    "type": "vec<string>",
                    "helper_text": "List of first names",
                },
                {
                    "field": "last_names",
                    "type": "vec<string>",
                    "helper_text": "List of last names",
                },
                {
                    "field": "emails",
                    "type": "vec<string>",
                    "helper_text": "List of email addresses",
                },
                {
                    "field": "phone_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of phone numbers",
                },
                {
                    "field": "companies",
                    "type": "vec<string>",
                    "helper_text": "List of companies",
                },
                {
                    "field": "job_titles",
                    "type": "vec<string>",
                    "helper_text": "List of job titles",
                },
                {
                    "field": "cities",
                    "type": "vec<string>",
                    "helper_text": "List of cities",
                },
                {
                    "field": "states",
                    "type": "vec<string>",
                    "helper_text": "List of states",
                },
                {
                    "field": "countries",
                    "type": "vec<string>",
                    "helper_text": "List of countries",
                },
                {
                    "field": "websites",
                    "type": "vec<string>",
                    "helper_text": "List of websites",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total contacts retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from HubSpot",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_contacts",
            "task_name": "tasks.hubspot.get_contacts",
            "description": "Get multiple contacts",
            "label": "List Contacts",
            "required": ["num_messages"],
        },
        "get_contacts**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Contacts",
                    "helper_text": "Specify the number of contacts to fetch",
                }
            ],
            "outputs": [],
        },
        "get_contacts**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_contacts**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_contacts**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_company**(*)**(*)": {
            "inputs": [
                {
                    "field": "create_company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Corp",
                    "helper_text": "Required company name",
                },
                {
                    "field": "about_us",
                    "type": "string",
                    "value": "",
                    "label": "About Us",
                    "placeholder": "Leading software company",
                    "helper_text": "About the company",
                },
                {
                    "field": "annual_revenue",
                    "type": "int32",
                    "value": "",
                    "label": "Annual Revenue",
                    "helper_text": "Annual revenue",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "Boston",
                    "helper_text": "City",
                },
                {
                    "field": "company_domain_name",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "placeholder": "acme.com",
                    "helper_text": "Company's domain name",
                },
                {
                    "field": "company_owner",
                    "type": "string",
                    "value": "",
                    "label": "Company Owner",
                    "placeholder": "12345",
                    "helper_text": "Owner's user ID",
                },
                {
                    "field": "country_region",
                    "type": "string",
                    "value": "",
                    "label": "Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Country or region",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Company description",
                    "helper_text": "Company description",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "ACCOUNTING",
                    "helper_text": "Type of industry",
                    "placeholder": "Accounting",
                    "label": "Industry",
                    "component": {"type": "dropdown", "referenced_options": "industry"},
                },
                {
                    "field": "lifecycle",
                    "type": "string",
                    "value": "subscriber",
                    "helper_text": "Lifecycle stage",
                    "placeholder": "Subscriber",
                    "label": "Lifecycle",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "life_cycle",
                    },
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "value": "NEW",
                    "helper_text": "Lead status",
                    "placeholder": "New",
                    "label": "Lead Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "lead_status",
                    },
                },
                {
                    "field": "number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "helper_text": "Employee count",
                },
                {
                    "field": "phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Phone Number",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Phone number",
                },
                {
                    "field": "website_url",
                    "type": "string",
                    "value": "",
                    "label": "Website URL",
                    "placeholder": "https://acme.com",
                    "helper_text": "Website URL",
                },
            ],
            "outputs": [
                {
                    "field": "company_id",
                    "type": "string",
                    "helper_text": "HubSpot company ID",
                },
                {"field": "name", "type": "string", "helper_text": "Company name"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_company",
            "task_name": "tasks.hubspot.create_company",
            "description": "Creates a new company",
            "label": "Create Company",
            "required": ["create_company_name"],
        },
        "update_company**(*)**(*)": {
            "inputs": [
                {
                    "field": "update_company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot company ID to update (required)",
                },
                {
                    "field": "update_company_name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Corp",
                    "helper_text": "Company name",
                },
                {
                    "field": "update_about_us",
                    "type": "string",
                    "value": "",
                    "label": "About Us",
                    "placeholder": "Leading software company",
                    "helper_text": "About the company",
                },
                {
                    "field": "update_annual_revenue",
                    "type": "int32",
                    "value": 0,
                    "label": "Annual Revenue",
                    "helper_text": "Annual revenue",
                },
                {
                    "field": "update_city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "Boston",
                    "helper_text": "City",
                },
                {
                    "field": "update_company_domain_name",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "placeholder": "acme.com",
                    "helper_text": "Company domain",
                },
                {
                    "field": "update_company_owner",
                    "type": "string",
                    "value": "",
                    "label": "Company Owner",
                    "placeholder": "12345",
                    "helper_text": "Owner's user ID",
                },
                {
                    "field": "update_country_region",
                    "type": "string",
                    "value": "",
                    "label": "Country/Region",
                    "placeholder": "United States",
                    "helper_text": "Country or region",
                },
                {
                    "field": "update_description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Company description",
                    "helper_text": "Company description",
                },
                {
                    "field": "update_industry",
                    "type": "string",
                    "value": "ACCOUNTING",
                    "helper_text": "Type of industry",
                    "placeholder": "Accounting",
                    "label": "Industry",
                    "component": {"type": "dropdown", "referenced_options": "industry"},
                },
                {
                    "field": "update_lifecycle",
                    "type": "string",
                    "value": "subscriber",
                    "helper_text": "Lifecycle stage",
                    "placeholder": "Subscriber",
                    "label": "Lifecycle",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "life_cycle",
                    },
                },
                {
                    "field": "update_lead_status",
                    "type": "string",
                    "value": "NEW",
                    "helper_text": "Lead status",
                    "placeholder": "New",
                    "label": "Lead Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "lead_status",
                    },
                },
                {
                    "field": "update_number_of_employees",
                    "type": "int32",
                    "value": 0,
                    "label": "Number of Employees",
                    "helper_text": "Employee count",
                },
                {
                    "field": "update_phone_number",
                    "type": "string",
                    "value": "",
                    "label": "Phone Number",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Phone number",
                },
                {
                    "field": "update_website_url",
                    "type": "string",
                    "value": "",
                    "label": "Website URL",
                    "placeholder": "https://acme.com",
                    "helper_text": "Website URL",
                },
            ],
            "outputs": [
                {
                    "field": "updated",
                    "type": "bool",
                    "helper_text": "True if update succeeded",
                },
                {
                    "field": "company_id",
                    "type": "string",
                    "helper_text": "HubSpot company ID",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_company",
            "task_name": "tasks.hubspot.update_company",
            "description": "Updates an existing company",
            "label": "Update Company",
            "required": ["update_company_id"],
        },
        "delete_company**(*)**(*)": {
            "inputs": [
                {
                    "field": "delete_company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot company ID to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "True if company was deleted",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_company",
            "task_name": "tasks.hubspot.delete_company",
            "description": "Deletes a company by ID",
            "label": "Delete Company",
            "required": ["delete_company_id"],
        },
        "read_company**(*)**(*)": {
            "inputs": [
                {
                    "field": "read_company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot company ID to read (required)",
                },
                {
                    "field": "include_merge_audits",
                    "type": "bool",
                    "value": False,
                    "label": "Include Merge Audits",
                    "helper_text": "Include merge history if true",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
            ],
            "outputs": [
                {
                    "field": "company_id",
                    "type": "string",
                    "helper_text": "HubSpot company ID",
                },
                {"field": "name", "type": "string", "helper_text": "Company name"},
                {"field": "domain", "type": "string", "helper_text": "Company domain"},
                {
                    "field": "phone_number",
                    "type": "string",
                    "helper_text": "Phone number",
                },
                {"field": "city", "type": "string", "helper_text": "City"},
                {"field": "state", "type": "string", "helper_text": "State"},
                {"field": "country", "type": "string", "helper_text": "Country"},
                {"field": "industry", "type": "string", "helper_text": "Industry"},
                {"field": "website", "type": "string", "helper_text": "Website"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Company description",
                },
                {
                    "field": "number_of_employees",
                    "type": "string",
                    "helper_text": "Employee count",
                },
                {
                    "field": "annual_revenue",
                    "type": "string",
                    "helper_text": "Annual revenue",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_company",
            "task_name": "tasks.hubspot.read_company",
            "description": "Read details of a specific company",
            "label": "Get Company",
            "required": ["read_company_id"],
        },
        "get_companies**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "acme",
                    "helper_text": "General search query",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Company Name",
                    "placeholder": "Acme Corp",
                    "helper_text": "Search by company name",
                },
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "placeholder": "acme.com",
                    "helper_text": "Search by domain",
                },
                {
                    "field": "phone",
                    "type": "string",
                    "value": "",
                    "label": "Phone",
                    "placeholder": "+1-555-123-4567",
                    "helper_text": "Search by phone number",
                },
                {
                    "field": "city",
                    "type": "string",
                    "value": "",
                    "label": "City",
                    "placeholder": "Boston",
                    "helper_text": "Search by city",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "MA",
                    "helper_text": "Search by state",
                },
                {
                    "field": "country",
                    "type": "string",
                    "value": "",
                    "label": "Country",
                    "placeholder": "United States",
                    "helper_text": "Search by country",
                },
                {
                    "field": "zip",
                    "type": "string",
                    "value": "",
                    "label": "Zip Code",
                    "placeholder": "02101",
                    "helper_text": "Search by zip code",
                },
                {
                    "field": "industry",
                    "type": "string",
                    "value": "",
                    "label": "Industry",
                    "placeholder": "Technology",
                    "helper_text": "Filter by industry",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "",
                    "label": "Company Type",
                    "placeholder": "PROSPECT",
                    "helper_text": "Filter by company type",
                },
                {
                    "field": "lifecycle_stage",
                    "type": "string",
                    "value": "",
                    "label": "Lifecycle Stage",
                    "placeholder": "customer",
                    "helper_text": "Filter by lifecycle stage",
                },
                {
                    "field": "lead_status",
                    "type": "string",
                    "value": "",
                    "label": "Lead Status",
                    "placeholder": "NEW",
                    "helper_text": "Filter by lead status",
                },
                {
                    "field": "number_of_employees",
                    "type": "string",
                    "value": "",
                    "label": "Number of Employees",
                    "placeholder": "1-10",
                    "helper_text": "Filter by employee count range",
                },
                {
                    "field": "annual_revenue",
                    "type": "string",
                    "value": "",
                    "label": "Annual Revenue",
                    "placeholder": "1000000",
                    "helper_text": "Filter by annual revenue",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "label": "Created Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by creation date (ISO 8601 format)",
                },
                {
                    "field": "last_modified_date",
                    "type": "string",
                    "value": "",
                    "label": "Last Modified Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by last modified date (ISO 8601 format)",
                },
                {
                    "field": "hubspot_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Owner ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by company owner ID",
                },
                {
                    "field": "hs_analytics_source",
                    "type": "string",
                    "value": "",
                    "label": "Original Source",
                    "placeholder": "ORGANIC_SEARCH",
                    "helper_text": "Filter by original source",
                },
                {
                    "field": "hs_analytics_source_data_1",
                    "type": "string",
                    "value": "",
                    "label": "Source Data 1",
                    "placeholder": "google",
                    "helper_text": "Filter by source data 1",
                },
                {
                    "field": "hs_analytics_source_data_2",
                    "type": "string",
                    "value": "",
                    "label": "Source Data 2",
                    "placeholder": "keywords",
                    "helper_text": "Filter by source data 2",
                },
                {
                    "field": "web_technologies",
                    "type": "string",
                    "value": "",
                    "label": "Web Technologies",
                    "placeholder": "wordpress",
                    "helper_text": "Filter by web technologies",
                },
                {
                    "field": "founded_year",
                    "type": "string",
                    "value": "",
                    "label": "Founded Year",
                    "placeholder": "2020",
                    "helper_text": "Filter by founded year",
                },
                {
                    "field": "is_public",
                    "type": "bool",
                    "value": False,
                    "label": "Is Public Company",
                    "helper_text": "Filter by public company status",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "createdate",
                    "helper_text": "Field to sort by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "placeholder": "desc",
                    "helper_text": "Sort order (asc/desc)",
                },
            ],
            "outputs": [
                {
                    "field": "company_ids",
                    "type": "vec<string>",
                    "helper_text": "List of company IDs",
                },
                {
                    "field": "names",
                    "type": "vec<string>",
                    "helper_text": "List of company names",
                },
                {
                    "field": "domains",
                    "type": "vec<string>",
                    "helper_text": "List of domains",
                },
                {
                    "field": "phone_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of phone numbers",
                },
                {
                    "field": "cities",
                    "type": "vec<string>",
                    "helper_text": "List of cities",
                },
                {
                    "field": "states",
                    "type": "vec<string>",
                    "helper_text": "List of states",
                },
                {
                    "field": "countries",
                    "type": "vec<string>",
                    "helper_text": "List of countries",
                },
                {
                    "field": "industries",
                    "type": "vec<string>",
                    "helper_text": "List of industries",
                },
                {
                    "field": "websites",
                    "type": "vec<string>",
                    "helper_text": "List of websites",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of descriptions",
                },
                {
                    "field": "number_of_employees",
                    "type": "vec<string>",
                    "helper_text": "List of employee counts",
                },
                {
                    "field": "annual_revenues",
                    "type": "vec<string>",
                    "helper_text": "List of revenues",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total count returned",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_companies",
            "task_name": "tasks.hubspot.get_companies",
            "description": "Get multiple companies",
            "label": "List Companies",
            "required": ["num_messages"],
        },
        "get_companies**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Companies",
                    "helper_text": "Specify the number of companies to fetch",
                }
            ],
            "outputs": [],
        },
        "get_companies**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_companies**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_companies**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_deal**(*)**(*)": {
            "inputs": [
                {
                    "field": "create_deal_stage",
                    "type": "string",
                    "value": "",
                    "label": "Stage",
                    "placeholder": "appointmentscheduled",
                    "helper_text": "Required deal stage ID",
                },
                {
                    "field": "deal_name",
                    "type": "string",
                    "value": "",
                    "label": "Deal Name",
                    "placeholder": "Enterprise Solution 2024",
                    "helper_text": "Deal name",
                },
                {
                    "field": "amount",
                    "type": "int32",
                    "value": "",
                    "label": "Amount",
                    "helper_text": "Deal amount",
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "label": "Close Date",
                    "placeholder": "2024-12-31T00:00:00.000Z",
                    "helper_text": "Deal close date (ISO 8601 format)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Deal description",
                    "helper_text": "Deal description",
                },
                {
                    "field": "deal_owner",
                    "type": "string",
                    "value": "",
                    "label": "Deal Owner",
                    "placeholder": "12345",
                    "helper_text": "Deal owner ID",
                },
                {
                    "field": "deal_type",
                    "type": "string",
                    "value": "",
                    "label": "Deal Type",
                    "placeholder": "newbusiness",
                    "helper_text": "Deal type",
                },
                {
                    "field": "pipeline",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline",
                    "placeholder": "default",
                    "helper_text": "Pipeline ID",
                },
                {
                    "field": "associated_company",
                    "type": "string",
                    "value": "",
                    "label": "Associated Companies",
                    "placeholder": "12345",
                    "helper_text": "Associated company IDs",
                },
                {
                    "field": "associated_vids",
                    "type": "string",
                    "value": "",
                    "label": "Associated Contacts",
                    "placeholder": "12345",
                    "helper_text": "Associated contact IDs",
                },
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "HubSpot deal ID",
                },
                {"field": "stage", "type": "string", "helper_text": "Deal stage ID"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_deal",
            "task_name": "tasks.hubspot.create_deal",
            "description": "Creates a new deal",
            "label": "Create Deal",
            "required": ["create_deal_stage"],
        },
        "update_deal**(*)**(*)": {
            "inputs": [
                {
                    "field": "update_deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot deal ID to update (required)",
                },
                {
                    "field": "update_deal_stage",
                    "type": "string",
                    "value": "",
                    "label": "Stage",
                    "placeholder": "appointmentscheduled",
                    "helper_text": "Deal stage ID",
                },
                {
                    "field": "update_deal_name",
                    "type": "string",
                    "value": "",
                    "label": "Deal Name",
                    "placeholder": "Enterprise Solution 2024",
                    "helper_text": "Deal name",
                },
                {
                    "field": "update_amount",
                    "type": "int32",
                    "value": 0,
                    "label": "Amount",
                    "helper_text": "Deal amount",
                },
                {
                    "field": "update_close_date",
                    "type": "string",
                    "value": "",
                    "label": "Close Date",
                    "placeholder": "2024-12-31T00:00:00.000Z",
                    "helper_text": "Deal close date (ISO 8601 format)",
                },
                {
                    "field": "update_description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Deal description",
                    "helper_text": "Deal description",
                },
                {
                    "field": "update_deal_owner",
                    "type": "string",
                    "value": "",
                    "label": "Deal Owner",
                    "placeholder": "12345",
                    "helper_text": "Deal owner ID",
                },
                {
                    "field": "update_deal_type",
                    "type": "string",
                    "value": "",
                    "label": "Deal Type",
                    "placeholder": "newbusiness",
                    "helper_text": "Deal type",
                },
                {
                    "field": "update_pipeline",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline",
                    "placeholder": "default",
                    "helper_text": "Pipeline ID",
                },
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "HubSpot deal ID",
                },
                {
                    "field": "updated",
                    "type": "bool",
                    "helper_text": "True if deal was updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_deal",
            "task_name": "tasks.hubspot.update_deal",
            "description": "Updates an existing deal",
            "label": "Update Deal",
            "required": ["update_deal_id"],
        },
        "delete_deal**(*)**(*)": {
            "inputs": [
                {
                    "field": "delete_deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot deal ID to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "True if deal was deleted",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_deal",
            "task_name": "tasks.hubspot.delete_deal",
            "description": "Deletes a deal by ID",
            "label": "Delete Deal",
            "required": ["delete_deal_id"],
        },
        "read_deal**(*)**(*)": {
            "inputs": [
                {
                    "field": "read_deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot deal ID to read (required)",
                },
                {
                    "field": "include_property_versions",
                    "type": "bool",
                    "value": False,
                    "label": "Include Property Versions",
                    "helper_text": "Include property history if true",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated fields to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "deal_id",
                    "type": "string",
                    "helper_text": "HubSpot deal ID",
                },
                {"field": "deal_name", "type": "string", "helper_text": "Deal name"},
                {"field": "amount", "type": "string", "helper_text": "Deal amount"},
                {"field": "stage", "type": "string", "helper_text": "Deal stage"},
                {"field": "pipeline", "type": "string", "helper_text": "Deal pipeline"},
                {
                    "field": "close_date",
                    "type": "string",
                    "helper_text": "Deal close date",
                },
                {"field": "deal_type", "type": "string", "helper_text": "Deal type"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Deal description",
                },
                {"field": "deal_owner", "type": "string", "helper_text": "Deal owner"},
                {
                    "field": "probability",
                    "type": "string",
                    "helper_text": "Deal probability",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_deal",
            "task_name": "tasks.hubspot.read_deal",
            "description": "Read details of a specific deal",
            "label": "Get Deal",
            "required": ["read_deal_id"],
        },
        "get_deals**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "enterprise",
                    "helper_text": "General search query",
                },
                {
                    "field": "deal_name",
                    "type": "string",
                    "value": "",
                    "label": "Deal Name",
                    "placeholder": "Enterprise Solution",
                    "helper_text": "Search by deal name",
                },
                {
                    "field": "amount",
                    "type": "string",
                    "value": "",
                    "label": "Amount",
                    "placeholder": "50000",
                    "helper_text": "Filter by deal amount",
                },
                {
                    "field": "deal_stage",
                    "type": "string",
                    "value": "",
                    "label": "Deal Stage",
                    "placeholder": "closedwon",
                    "helper_text": "Filter by deal stage",
                },
                {
                    "field": "pipeline",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline",
                    "placeholder": "default",
                    "helper_text": "Filter by pipeline",
                },
                {
                    "field": "deal_type",
                    "type": "string",
                    "value": "",
                    "label": "Deal Type",
                    "placeholder": "newbusiness",
                    "helper_text": "Filter by deal type",
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "label": "Close Date",
                    "placeholder": "2024-12-31T00:00:00.000Z",
                    "helper_text": "Filter by close date (ISO 8601 format)",
                },
                {
                    "field": "hubspot_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Owner ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by deal owner ID",
                },
                {
                    "field": "deal_currency_code",
                    "type": "string",
                    "value": "",
                    "label": "Currency Code",
                    "placeholder": "USD",
                    "helper_text": "Filter by currency code",
                },
                {
                    "field": "hs_deal_stage_probability",
                    "type": "string",
                    "value": "",
                    "label": "Deal Probability",
                    "placeholder": "0.5",
                    "helper_text": "Filter by deal probability",
                },
                {
                    "field": "num_associated_contacts",
                    "type": "string",
                    "value": "",
                    "label": "Associated Contacts",
                    "placeholder": "5",
                    "helper_text": "Filter by number of associated contacts",
                },
                {
                    "field": "num_contacted_notes",
                    "type": "string",
                    "value": "",
                    "label": "Contact Notes",
                    "placeholder": "10",
                    "helper_text": "Filter by number of contact notes",
                },
                {
                    "field": "hs_analytics_source",
                    "type": "string",
                    "value": "",
                    "label": "Original Source",
                    "placeholder": "ORGANIC_SEARCH",
                    "helper_text": "Filter by original source",
                },
                {
                    "field": "hs_latest_source",
                    "type": "string",
                    "value": "",
                    "label": "Latest Source",
                    "placeholder": "DIRECT_TRAFFIC",
                    "helper_text": "Filter by latest source",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "label": "Created Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by creation date (ISO 8601 format)",
                },
                {
                    "field": "last_modified_date",
                    "type": "string",
                    "value": "",
                    "label": "Last Modified Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by last modified date (ISO 8601 format)",
                },
                {
                    "field": "hs_date_entered_closed_won",
                    "type": "string",
                    "value": "",
                    "label": "Date Closed Won",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by date entered closed won (ISO 8601 format)",
                },
                {
                    "field": "hs_date_entered_closed_lost",
                    "type": "string",
                    "value": "",
                    "label": "Date Closed Lost",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by date entered closed lost (ISO 8601 format)",
                },
                {
                    "field": "hs_forecast_amount",
                    "type": "string",
                    "value": "",
                    "label": "Forecast Amount",
                    "placeholder": "45000",
                    "helper_text": "Filter by forecast amount",
                },
                {
                    "field": "hs_is_closed",
                    "type": "bool",
                    "value": False,
                    "label": "Is Closed",
                    "helper_text": "Filter by closed status",
                },
                {
                    "field": "hs_is_deal_split",
                    "type": "bool",
                    "value": False,
                    "label": "Is Deal Split",
                    "helper_text": "Filter by deal split status",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "createdate",
                    "helper_text": "Field to sort by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "placeholder": "desc",
                    "helper_text": "Sort order (asc/desc)",
                },
            ],
            "outputs": [
                {
                    "field": "deal_ids",
                    "type": "vec<string>",
                    "helper_text": "List of deal IDs",
                },
                {
                    "field": "deal_names",
                    "type": "vec<string>",
                    "helper_text": "List of deal names",
                },
                {
                    "field": "amounts",
                    "type": "vec<string>",
                    "helper_text": "List of amounts",
                },
                {
                    "field": "stages",
                    "type": "vec<string>",
                    "helper_text": "List of stages",
                },
                {
                    "field": "pipelines",
                    "type": "vec<string>",
                    "helper_text": "List of pipelines",
                },
                {
                    "field": "close_dates",
                    "type": "vec<string>",
                    "helper_text": "List of close dates",
                },
                {
                    "field": "deal_types",
                    "type": "vec<string>",
                    "helper_text": "List of deal types",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of descriptions",
                },
                {
                    "field": "deal_owners",
                    "type": "vec<string>",
                    "helper_text": "List of owners",
                },
                {
                    "field": "probabilities",
                    "type": "vec<string>",
                    "helper_text": "List of probabilities",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total deals retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_deals",
            "task_name": "tasks.hubspot.get_deals",
            "description": "Get multiple deals",
            "label": "List Deals",
            "required": ["num_messages"],
        },
        "get_deals**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Deals",
                    "helper_text": "Specify the number of deals to fetch",
                }
            ],
            "outputs": [],
        },
        "get_deals**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_deals**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_deals**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "create_ticket_pipeline_id",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline ID",
                    "placeholder": "0",
                    "helper_text": "Pipeline ID (required)",
                },
                {
                    "field": "create_ticket_stage_id",
                    "type": "string",
                    "value": "",
                    "label": "Stage ID",
                    "placeholder": "1",
                    "helper_text": "Stage ID (required)",
                },
                {
                    "field": "create_ticket_name",
                    "type": "string",
                    "value": "",
                    "label": "Ticket Subject",
                    "placeholder": "Technical Support Request",
                    "helper_text": "Ticket subject (required)",
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "TECHNICAL_SUPPORT",
                    "helper_text": "Ticket category",
                },
                {
                    "field": "close_date",
                    "type": "string",
                    "value": "",
                    "label": "Close Date",
                    "placeholder": "2024-12-31T00:00:00.000Z",
                    "helper_text": "Ticket close date (ISO 8601 format)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Customer needs help with...",
                    "helper_text": "Ticket description",
                },
                {
                    "field": "priority",
                    "type": "string",
                    "value": "",
                    "label": "Priority",
                    "placeholder": "HIGH",
                    "helper_text": "Priority level",
                },
                {
                    "field": "ticket_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Ticket Owner",
                    "placeholder": "12345",
                    "helper_text": "Ticket owner ID",
                },
                {
                    "field": "associated_company_ids",
                    "type": "string",
                    "value": "",
                    "label": "Associated Companies",
                    "helper_text": "Associated companies",
                },
                {
                    "field": "associated_contact_ids",
                    "type": "string",
                    "value": "",
                    "label": "Associated Contacts",
                    "helper_text": "Associated contacts",
                },
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "HubSpot ticket ID",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_ticket",
            "task_name": "tasks.hubspot.create_ticket",
            "description": "Creates a new support ticket",
            "label": "Create Ticket",
            "required": [
                "create_ticket_pipeline_id",
                "create_ticket_stage_id",
                "create_ticket_name",
            ],
        },
        "update_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "update_ticket_id",
                    "type": "string",
                    "value": "",
                    "label": "Ticket ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot ticket ID to update (required)",
                },
                {
                    "field": "update_ticket_name",
                    "type": "string",
                    "value": "",
                    "label": "Ticket Subject",
                    "placeholder": "Technical Support Request",
                    "helper_text": "Ticket subject",
                },
                {
                    "field": "update_category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "TECHNICAL_SUPPORT",
                    "helper_text": "Ticket category",
                },
                {
                    "field": "update_description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Customer needs help with...",
                    "helper_text": "Ticket description",
                },
                {
                    "field": "update_priority",
                    "type": "string",
                    "value": "",
                    "label": "Priority",
                    "placeholder": "HIGH",
                    "helper_text": "Priority level",
                },
                {
                    "field": "update_stage_id",
                    "type": "string",
                    "value": "",
                    "label": "Stage ID",
                    "placeholder": "2",
                    "helper_text": "Stage ID",
                },
                {
                    "field": "update_ticket_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Ticket Owner",
                    "placeholder": "12345",
                    "helper_text": "Ticket owner ID",
                },
                {
                    "field": "update_close_date",
                    "type": "string",
                    "value": "",
                    "label": "Close Date",
                    "placeholder": "2024-12-31T00:00:00.000Z",
                    "helper_text": "Ticket close date (ISO 8601 format)",
                },
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "HubSpot ticket ID",
                },
                {
                    "field": "updated",
                    "type": "bool",
                    "helper_text": "Whether the ticket was updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_ticket",
            "task_name": "tasks.hubspot.update_ticket",
            "description": "Updates an existing ticket",
            "label": "Update Ticket",
            "required": ["update_ticket_id"],
        },
        "delete_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "delete_ticket_id",
                    "type": "string",
                    "value": "",
                    "label": "Ticket ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot ticket ID to delete (required)",
                }
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the ticket was deleted",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_ticket",
            "task_name": "tasks.hubspot.delete_ticket",
            "description": "Deletes a ticket by ID",
            "label": "Delete Ticket",
            "required": ["delete_ticket_id"],
        },
        "read_ticket**(*)**(*)": {
            "inputs": [
                {
                    "field": "read_ticket_id",
                    "type": "string",
                    "value": "",
                    "label": "Ticket ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot ticket ID to read (required)",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Properties to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "ticket_id",
                    "type": "string",
                    "helper_text": "HubSpot ticket ID",
                },
                {"field": "subject", "type": "string", "helper_text": "Ticket subject"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Ticket description",
                },
                {"field": "status", "type": "string", "helper_text": "Ticket status"},
                {
                    "field": "priority",
                    "type": "string",
                    "helper_text": "Ticket priority",
                },
                {
                    "field": "category",
                    "type": "string",
                    "helper_text": "Ticket category",
                },
                {
                    "field": "pipeline",
                    "type": "string",
                    "helper_text": "Ticket pipeline",
                },
                {"field": "stage", "type": "string", "helper_text": "Ticket stage"},
                {"field": "owner", "type": "string", "helper_text": "Ticket owner"},
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Created date",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Updated date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_ticket",
            "task_name": "tasks.hubspot.read_ticket",
            "description": "Read details of a specific ticket",
            "label": "Get Ticket",
            "required": ["read_ticket_id"],
        },
        "get_tickets**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "support request",
                    "helper_text": "General search query",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Technical Support",
                    "helper_text": "Search by ticket subject",
                },
                {
                    "field": "hs_ticket_category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "TECHNICAL_SUPPORT",
                    "helper_text": "Filter by ticket category",
                },
                {
                    "field": "hs_ticket_priority",
                    "type": "string",
                    "value": "",
                    "label": "Priority",
                    "placeholder": "HIGH",
                    "helper_text": "Filter by ticket priority",
                },
                {
                    "field": "hs_pipeline_stage",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline Stage",
                    "placeholder": "1",
                    "helper_text": "Filter by pipeline stage",
                },
                {
                    "field": "hs_pipeline",
                    "type": "string",
                    "value": "",
                    "label": "Pipeline",
                    "placeholder": "0",
                    "helper_text": "Filter by pipeline",
                },
                {
                    "field": "hubspot_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Owner ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by ticket owner ID",
                },
                {
                    "field": "hs_resolution",
                    "type": "string",
                    "value": "",
                    "label": "Resolution",
                    "placeholder": "RESOLVED",
                    "helper_text": "Filter by ticket resolution",
                },
                {
                    "field": "source_type",
                    "type": "string",
                    "value": "",
                    "label": "Source Type",
                    "placeholder": "EMAIL",
                    "helper_text": "Filter by source type",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "label": "Created Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by creation date (ISO 8601 format)",
                },
                {
                    "field": "last_modified_date",
                    "type": "string",
                    "value": "",
                    "label": "Last Modified Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by last modified date (ISO 8601 format)",
                },
                {
                    "field": "closed_date",
                    "type": "string",
                    "value": "",
                    "label": "Closed Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by closed date (ISO 8601 format)",
                },
                {
                    "field": "first_agent_reply_date",
                    "type": "string",
                    "value": "",
                    "label": "First Agent Reply Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by first agent reply date (ISO 8601 format)",
                },
                {
                    "field": "hs_time_to_close",
                    "type": "string",
                    "value": "",
                    "label": "Time to Close",
                    "placeholder": "3600000",
                    "helper_text": "Filter by time to close (milliseconds)",
                },
                {
                    "field": "hs_time_to_first_agent_reply",
                    "type": "string",
                    "value": "",
                    "label": "Time to First Reply",
                    "placeholder": "1800000",
                    "helper_text": "Filter by time to first agent reply",
                },
                {
                    "field": "hs_num_times_contacted",
                    "type": "string",
                    "value": "",
                    "label": "Times Contacted",
                    "placeholder": "5",
                    "helper_text": "Filter by number of times contacted",
                },
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "label": "Tags",
                    "placeholder": "urgent,bug",
                    "helper_text": "Filter by tags (comma-separated)",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "createdate",
                    "helper_text": "Field to sort by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "placeholder": "desc",
                    "helper_text": "Sort order (asc/desc)",
                },
            ],
            "outputs": [
                {
                    "field": "ticket_ids",
                    "type": "vec<string>",
                    "helper_text": "HubSpot ticket IDs",
                },
                {
                    "field": "subjects",
                    "type": "vec<string>",
                    "helper_text": "Ticket subjects",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "Ticket descriptions",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "Ticket statuses",
                },
                {
                    "field": "priorities",
                    "type": "vec<string>",
                    "helper_text": "Ticket priorities",
                },
                {
                    "field": "categories",
                    "type": "vec<string>",
                    "helper_text": "Ticket categories",
                },
                {
                    "field": "pipelines",
                    "type": "vec<string>",
                    "helper_text": "Ticket pipelines",
                },
                {
                    "field": "stages",
                    "type": "vec<string>",
                    "helper_text": "Ticket stages",
                },
                {
                    "field": "owners",
                    "type": "vec<string>",
                    "helper_text": "Ticket owners",
                },
                {
                    "field": "created_ats",
                    "type": "vec<string>",
                    "helper_text": "Created dates",
                },
                {
                    "field": "updated_ats",
                    "type": "vec<string>",
                    "helper_text": "Updated dates",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of tickets retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_tickets",
            "task_name": "tasks.hubspot.get_tickets",
            "description": "Get multiple tickets",
            "label": "List Tickets",
            "required": ["num_messages"],
        },
        "get_tickets**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Tickets",
                    "helper_text": "Specify the number of tickets to fetch",
                }
            ],
            "outputs": [],
        },
        "get_tickets**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_tickets**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_tickets**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "create_engagement**(*)**(*)": {
            "inputs": [
                {
                    "field": "create_engagement_type",
                    "type": "string",
                    "value": "call",
                    "label": "Type",
                    "placeholder": "Call",
                    "helper_text": "Select Engagement type (required)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "engagement_type",
                    },
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "value": "",
                    "label": "Metadata",
                    "placeholder": '{"body": "Call notes"}',
                    "helper_text": "Type-specific metadata (JSON)",
                },
                {
                    "field": "company_ids",
                    "type": "string",
                    "value": "",
                    "label": "Company IDs",
                    "placeholder": "123,456",
                    "helper_text": "Comma-separated company IDs",
                },
                {
                    "field": "contact_ids",
                    "type": "string",
                    "value": "",
                    "label": "Contact IDs",
                    "placeholder": "789,101",
                    "helper_text": "Comma-separated contact IDs",
                },
                {
                    "field": "deal_ids",
                    "type": "string",
                    "value": "",
                    "label": "Deal IDs",
                    "placeholder": "111,222",
                    "helper_text": "Comma-separated deal IDs",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Owner ID",
                    "placeholder": "12345",
                    "helper_text": "Engagement owner ID",
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "label": "Timestamp",
                    "placeholder": "2024-12-31T00:00:00.000Z",
                    "helper_text": "Engagement timestamp (ISO 8601 format)",
                },
            ],
            "outputs": [
                {
                    "field": "engagement_id",
                    "type": "string",
                    "helper_text": "HubSpot engagement ID",
                },
                {"field": "type", "type": "string", "helper_text": "Engagement type"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Full response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_engagement",
            "task_name": "tasks.hubspot.create_engagement",
            "description": "Creates a new engagement (call, email, meeting, or task)",
            "label": "Create Engagement",
            "required": ["create_engagement_type"],
        },
        "delete_engagement**(*)**(*)": {
            "inputs": [
                {
                    "field": "delete_engagement_id",
                    "type": "string",
                    "value": "",
                    "label": "Engagement ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot engagement ID to delete (required)",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "call",
                    "label": "Engagement Type",
                    "placeholder": "call",
                    "helper_text": "Type of engagement (call, email, meeting, task, note)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "engagement_type",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the engagement was deleted",
                }
            ],
            "variant": "common_integration_nodes",
            "name": "delete_engagement",
            "task_name": "tasks.hubspot.delete_engagement",
            "description": "Deletes an engagement by ID",
            "label": "Delete Engagement",
            "required": ["delete_engagement_id"],
        },
        "read_engagement**(*)**(*)": {
            "inputs": [
                {
                    "field": "read_engagement_id",
                    "type": "string",
                    "value": "",
                    "label": "Engagement ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot engagement ID to read (required)",
                },
                {
                    "field": "type",
                    "type": "string",
                    "value": "call",
                    "label": "Engagement Type",
                    "placeholder": "call",
                    "helper_text": "Type of engagement (call, email, meeting, task, note)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "engagement_type",
                    },
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
            ],
            "outputs": [
                {
                    "field": "engagement_id",
                    "type": "string",
                    "helper_text": "HubSpot engagement ID",
                },
                {
                    "field": "engagement_type",
                    "type": "string",
                    "helper_text": "Engagement type (call, email, meeting, task)",
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "helper_text": "Engagement timestamp",
                },
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "Engagement body/notes",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "Engagement subject",
                },
                {
                    "field": "owner_id",
                    "type": "string",
                    "helper_text": "Engagement owner ID",
                },
                {
                    "field": "created_at",
                    "type": "string",
                    "helper_text": "Created date",
                },
                {
                    "field": "updated_at",
                    "type": "string",
                    "helper_text": "Updated date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_engagement",
            "task_name": "tasks.hubspot.read_engagement",
            "description": "Read details of a specific engagement",
            "label": "Get Engagement",
            "required": ["read_engagement_id"],
        },
        "get_engagements**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "helper_text": "Comma-separated properties to fetch",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Search Query",
                    "placeholder": "meeting",
                    "helper_text": "General search query",
                },
                {
                    "field": "engagement_type",
                    "type": "string",
                    "value": "",
                    "label": "Engagement Type",
                    "helper_text": "Filter by engagement type (CALL, EMAIL, MEETING, TASK)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Call", "value": "CALL"},
                            {"label": "Email", "value": "EMAIL"},
                            {"label": "Meeting", "value": "MEETING"},
                            {"label": "Task", "value": "TASK"},
                        ],
                    },
                },
                {
                    "field": "hubspot_owner_id",
                    "type": "string",
                    "value": "",
                    "label": "Owner ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by engagement owner ID",
                },
                {
                    "field": "contact_id",
                    "type": "string",
                    "value": "",
                    "label": "Contact ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by associated contact ID",
                },
                {
                    "field": "company_id",
                    "type": "string",
                    "value": "",
                    "label": "Company ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by associated company ID",
                },
                {
                    "field": "deal_id",
                    "type": "string",
                    "value": "",
                    "label": "Deal ID",
                    "placeholder": "12345",
                    "helper_text": "Filter by associated deal ID",
                },
                {
                    "field": "created_date",
                    "type": "string",
                    "value": "",
                    "label": "Created Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by creation date (ISO 8601 format)",
                },
                {
                    "field": "last_modified_date",
                    "type": "string",
                    "value": "",
                    "label": "Last Modified Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by last modified date (ISO 8601 format)",
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "value": "",
                    "label": "Engagement Date",
                    "placeholder": "2024-01-01T00:00:00.000Z",
                    "helper_text": "Filter by engagement date (ISO 8601 format)",
                },
                {
                    "field": "hs_communication_channel_type",
                    "type": "string",
                    "value": "",
                    "label": "Communication Channel",
                    "placeholder": "EMAIL",
                    "helper_text": "Filter by communication channel type",
                },
                {
                    "field": "hs_communication_logged_from",
                    "type": "string",
                    "value": "",
                    "label": "Logged From",
                    "placeholder": "CRM",
                    "helper_text": "Filter by where engagement was logged from",
                },
                {
                    "field": "hs_activity_type",
                    "type": "string",
                    "value": "",
                    "label": "Activity Type",
                    "placeholder": "INCOMING_EMAIL",
                    "helper_text": "Filter by activity type",
                },
                {
                    "field": "sort_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort By",
                    "placeholder": "timestamp",
                    "helper_text": "Field to sort by",
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "placeholder": "desc",
                    "helper_text": "Sort order (asc/desc)",
                },
            ],
            "outputs": [
                {
                    "field": "engagement_ids",
                    "type": "vec<string>",
                    "helper_text": "HubSpot engagement IDs",
                },
                {
                    "field": "engagement_types",
                    "type": "vec<string>",
                    "helper_text": "Engagement types (call, email, meeting, task)",
                },
                {
                    "field": "timestamps",
                    "type": "vec<string>",
                    "helper_text": "Engagement timestamps",
                },
                {
                    "field": "bodies",
                    "type": "vec<string>",
                    "helper_text": "Engagement bodies/notes",
                },
                {
                    "field": "subjects",
                    "type": "vec<string>",
                    "helper_text": "Engagement subjects",
                },
                {
                    "field": "owner_ids",
                    "type": "vec<string>",
                    "helper_text": "Engagement owner IDs",
                },
                {
                    "field": "created_ats",
                    "type": "vec<string>",
                    "helper_text": "Created dates",
                },
                {
                    "field": "updated_ats",
                    "type": "vec<string>",
                    "helper_text": "Updated dates",
                },
                {
                    "field": "total",
                    "type": "int32",
                    "helper_text": "Total number of engagements retrieved",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_engagements",
            "task_name": "tasks.hubspot.get_engagements",
            "description": "Get multiple engagements",
            "label": "List Engagements",
            "required": ["num_messages"],
        },
        "get_engagements**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Engagements",
                    "helper_text": "Specify the number of engagements to fetch",
                }
            ],
            "outputs": [],
        },
        "get_engagements**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_engagements**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_engagements**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_data_range": True,
                    "hidden": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "add_contact_to_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot list ID (required)",
                },
                {
                    "field": "by",
                    "type": "string",
                    "value": "email",
                    "label": "Identify By",
                    "helper_text": "Method to identify contacts: email or Contact ID",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Email", "value": "email"},
                            {"label": "Contact ID", "value": "id"},
                        ],
                    },
                },
                {
                    "field": "emails",
                    "type": "string",
                    "value": "",
                    "label": "Email Addresses",
                    "helper_text": "Comma-separated email addresses (e.g., email1@example.com,email2@example.com)",
                },
                {
                    "field": "contact_ids",
                    "type": "string",
                    "value": "",
                    "label": "Contact IDs",
                    "helper_text": "Comma-separated contact IDs (e.g., 123,456,789)",
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "HubSpot list ID",
                },
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "HubSpot contact IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "add_contact_to_list",
            "task_name": "tasks.hubspot.add_contact_to_list",
            "description": "Adds contacts to a contact list",
            "label": "Add Contact to List",
            "required": ["list_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "list_id",
                "by",
                "emails",
                "contact_ids",
            ],
        },
        "remove_contact_from_list**(*)**(*)": {
            "inputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "value": "",
                    "label": "List ID",
                    "placeholder": "12345",
                    "helper_text": "HubSpot list ID (required)",
                },
                {
                    "field": "contact_ids",
                    "type": "string",
                    "value": "",
                    "label": "Contact IDs",
                    "helper_text": "Comma-separated contact IDs to remove (e.g., 123,456,789)",
                },
            ],
            "outputs": [
                {
                    "field": "list_id",
                    "type": "string",
                    "helper_text": "HubSpot list ID",
                },
                {
                    "field": "contact_ids",
                    "type": "vec<string>",
                    "helper_text": "HubSpot contact IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "remove_contact_from_list",
            "task_name": "tasks.hubspot.remove_contact_from_list",
            "description": "Removes contacts from a contact list",
            "label": "Remove Contact from List",
            "required": ["list_id", "contact_ids"],
            "inputs_sort_order": ["integration", "action", "list_id", "contact_ids"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        about_us: str = "",
        amount: int = None,
        annual_revenue: int = None,
        associated_company: str = "",
        associated_company_id: str = "",
        associated_company_ids: str = "",
        associated_contact_ids: str = "",
        associated_vids: str = "",
        by: str = "email",
        category: str = "",
        city: str = "",
        close_date: str = "",
        closed_date: str = "",
        company: str = "",
        company_domain_name: str = "",
        company_id: str = "",
        company_ids: str = "",
        company_name: str = "",
        company_owner: str = "",
        contact_id: str = "",
        contact_ids: str = "",
        country: str = "",
        country_region: str = "",
        create_company_name: str = "",
        create_deal_stage: str = "",
        create_email: str = "",
        create_engagement_type: str = "call",
        create_ticket_name: str = "",
        create_ticket_pipeline_id: str = "",
        create_ticket_stage_id: str = "",
        created_date: str = "",
        custom_properties: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        deal_currency_code: str = "",
        deal_id: str = "",
        deal_ids: str = "",
        deal_name: str = "",
        deal_owner: str = "",
        deal_stage: str = "",
        deal_type: str = "",
        delete_company_id: str = "",
        delete_contact_id: str = "",
        delete_deal_id: str = "",
        delete_engagement_id: str = "",
        delete_ticket_id: str = "",
        description: str = "",
        domain: str = "",
        email: str = "",
        emails: str = "",
        engagement_type: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        first_agent_reply_date: str = "",
        first_name: str = "",
        founded_year: str = "",
        hs_activity_type: str = "",
        hs_analytics_source: str = "",
        hs_analytics_source_data_1: str = "",
        hs_analytics_source_data_2: str = "",
        hs_communication_channel_type: str = "",
        hs_communication_logged_from: str = "",
        hs_date_entered_closed_lost: str = "",
        hs_date_entered_closed_won: str = "",
        hs_deal_stage_probability: str = "",
        hs_forecast_amount: str = "",
        hs_is_closed: bool = False,
        hs_is_deal_split: bool = False,
        hs_latest_source: str = "",
        hs_lead_status: str = "",
        hs_num_times_contacted: str = "",
        hs_pipeline: str = "",
        hs_pipeline_stage: str = "",
        hs_resolution: str = "",
        hs_ticket_category: str = "",
        hs_ticket_priority: str = "",
        hs_time_to_close: str = "",
        hs_time_to_first_agent_reply: str = "",
        hubspot_owner_id: str = "",
        include_merge_audits: bool = False,
        include_property_versions: bool = False,
        industry: str = "ACCOUNTING",
        is_public: bool = False,
        job_title: str = "",
        last_modified_date: str = "",
        last_name: str = "",
        lead_status: str = "",
        lifecycle: str = "subscriber",
        lifecycle_stage: str = "",
        list_id: str = "",
        metadata: str = "",
        mobile_phone_number: str = "",
        name: str = "",
        num_associated_contacts: str = "",
        num_contacted_notes: str = "",
        num_messages: int = 10,
        number_of_employees: int = 0,
        owner_id: str = "",
        phone: str = "",
        phone_number: str = "",
        pipeline: str = "",
        postal_code: str = "",
        priority: str = "",
        properties: str = "",
        read_company_id: str = "",
        read_contact_id: str = "",
        read_deal_id: str = "",
        read_engagement_id: str = "",
        read_ticket_id: str = "",
        show_list_memberships: bool = False,
        sort_by: str = "",
        sort_order: str = "",
        source_type: str = "",
        state: str = "",
        state_region: str = "",
        street_address: str = "",
        subject: str = "",
        tags: str = "",
        ticket_owner_id: str = "",
        timestamp: str = "",
        type: str = "",
        update_about_us: str = "",
        update_amount: int = 0,
        update_annual_revenue: int = 0,
        update_category: str = "",
        update_city: str = "",
        update_close_date: str = "",
        update_company: str = "",
        update_company_domain_name: str = "",
        update_company_id: str = "",
        update_company_name: str = "",
        update_company_owner: str = "",
        update_contact_id: str = "",
        update_country: str = "",
        update_country_region: str = "",
        update_custom_properties: str = "",
        update_deal_id: str = "",
        update_deal_name: str = "",
        update_deal_owner: str = "",
        update_deal_stage: str = "",
        update_deal_type: str = "",
        update_description: str = "",
        update_email: str = "",
        update_first_name: str = "",
        update_industry: str = "ACCOUNTING",
        update_job_title: str = "",
        update_last_name: str = "",
        update_lead_status: str = "NEW",
        update_lifecycle: str = "subscriber",
        update_mobile_phone_number: str = "",
        update_number_of_employees: int = 0,
        update_phone_number: str = "",
        update_pipeline: str = "",
        update_postal_code: str = "",
        update_priority: str = "",
        update_stage_id: str = "",
        update_state_region: str = "",
        update_street_address: str = "",
        update_ticket_id: str = "",
        update_ticket_name: str = "",
        update_ticket_owner_id: str = "",
        update_website_url: str = "",
        web_technologies: str = "",
        website: str = "",
        website_url: str = "",
        zip: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_hubspot",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if create_email is not None:
            self.inputs["create_email"] = create_email
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if company is not None:
            self.inputs["company"] = company
        if job_title is not None:
            self.inputs["job_title"] = job_title
        if phone_number is not None:
            self.inputs["phone_number"] = phone_number
        if mobile_phone_number is not None:
            self.inputs["mobile_phone_number"] = mobile_phone_number
        if street_address is not None:
            self.inputs["street_address"] = street_address
        if city is not None:
            self.inputs["city"] = city
        if state_region is not None:
            self.inputs["state_region"] = state_region
        if postal_code is not None:
            self.inputs["postal_code"] = postal_code
        if country is not None:
            self.inputs["country"] = country
        if website_url is not None:
            self.inputs["website_url"] = website_url
        if associated_company_id is not None:
            self.inputs["associated_company_id"] = associated_company_id
        if custom_properties is not None:
            self.inputs["custom_properties"] = custom_properties
        if update_contact_id is not None:
            self.inputs["update_contact_id"] = update_contact_id
        if update_email is not None:
            self.inputs["update_email"] = update_email
        if update_first_name is not None:
            self.inputs["update_first_name"] = update_first_name
        if update_last_name is not None:
            self.inputs["update_last_name"] = update_last_name
        if update_company is not None:
            self.inputs["update_company"] = update_company
        if update_job_title is not None:
            self.inputs["update_job_title"] = update_job_title
        if update_phone_number is not None:
            self.inputs["update_phone_number"] = update_phone_number
        if update_mobile_phone_number is not None:
            self.inputs["update_mobile_phone_number"] = update_mobile_phone_number
        if update_street_address is not None:
            self.inputs["update_street_address"] = update_street_address
        if update_city is not None:
            self.inputs["update_city"] = update_city
        if update_state_region is not None:
            self.inputs["update_state_region"] = update_state_region
        if update_postal_code is not None:
            self.inputs["update_postal_code"] = update_postal_code
        if update_country is not None:
            self.inputs["update_country"] = update_country
        if update_website_url is not None:
            self.inputs["update_website_url"] = update_website_url
        if update_custom_properties is not None:
            self.inputs["update_custom_properties"] = update_custom_properties
        if delete_contact_id is not None:
            self.inputs["delete_contact_id"] = delete_contact_id
        if read_contact_id is not None:
            self.inputs["read_contact_id"] = read_contact_id
        if properties is not None:
            self.inputs["properties"] = properties
        if show_list_memberships is not None:
            self.inputs["show_list_memberships"] = show_list_memberships
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if query is not None:
            self.inputs["query"] = query
        if email is not None:
            self.inputs["email"] = email
        if company_name is not None:
            self.inputs["company_name"] = company_name
        if phone is not None:
            self.inputs["phone"] = phone
        if state is not None:
            self.inputs["state"] = state
        if website is not None:
            self.inputs["website"] = website
        if lifecycle_stage is not None:
            self.inputs["lifecycle_stage"] = lifecycle_stage
        if lead_status is not None:
            self.inputs["lead_status"] = lead_status
        if hs_lead_status is not None:
            self.inputs["hs_lead_status"] = hs_lead_status
        if created_date is not None:
            self.inputs["created_date"] = created_date
        if last_modified_date is not None:
            self.inputs["last_modified_date"] = last_modified_date
        if hs_analytics_source is not None:
            self.inputs["hs_analytics_source"] = hs_analytics_source
        if hs_latest_source is not None:
            self.inputs["hs_latest_source"] = hs_latest_source
        if hubspot_owner_id is not None:
            self.inputs["hubspot_owner_id"] = hubspot_owner_id
        if sort_by is not None:
            self.inputs["sort_by"] = sort_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if create_company_name is not None:
            self.inputs["create_company_name"] = create_company_name
        if about_us is not None:
            self.inputs["about_us"] = about_us
        if annual_revenue is not None:
            self.inputs["annual_revenue"] = annual_revenue
        if company_domain_name is not None:
            self.inputs["company_domain_name"] = company_domain_name
        if company_owner is not None:
            self.inputs["company_owner"] = company_owner
        if country_region is not None:
            self.inputs["country_region"] = country_region
        if description is not None:
            self.inputs["description"] = description
        if industry is not None:
            self.inputs["industry"] = industry
        if lifecycle is not None:
            self.inputs["lifecycle"] = lifecycle
        if number_of_employees is not None:
            self.inputs["number_of_employees"] = number_of_employees
        if update_company_id is not None:
            self.inputs["update_company_id"] = update_company_id
        if update_company_name is not None:
            self.inputs["update_company_name"] = update_company_name
        if update_about_us is not None:
            self.inputs["update_about_us"] = update_about_us
        if update_annual_revenue is not None:
            self.inputs["update_annual_revenue"] = update_annual_revenue
        if update_company_domain_name is not None:
            self.inputs["update_company_domain_name"] = update_company_domain_name
        if update_company_owner is not None:
            self.inputs["update_company_owner"] = update_company_owner
        if update_country_region is not None:
            self.inputs["update_country_region"] = update_country_region
        if update_description is not None:
            self.inputs["update_description"] = update_description
        if update_industry is not None:
            self.inputs["update_industry"] = update_industry
        if update_lifecycle is not None:
            self.inputs["update_lifecycle"] = update_lifecycle
        if update_lead_status is not None:
            self.inputs["update_lead_status"] = update_lead_status
        if update_number_of_employees is not None:
            self.inputs["update_number_of_employees"] = update_number_of_employees
        if delete_company_id is not None:
            self.inputs["delete_company_id"] = delete_company_id
        if read_company_id is not None:
            self.inputs["read_company_id"] = read_company_id
        if include_merge_audits is not None:
            self.inputs["include_merge_audits"] = include_merge_audits
        if name is not None:
            self.inputs["name"] = name
        if domain is not None:
            self.inputs["domain"] = domain
        if zip is not None:
            self.inputs["zip"] = zip
        if type is not None:
            self.inputs["type"] = type
        if hs_analytics_source_data_1 is not None:
            self.inputs["hs_analytics_source_data_1"] = hs_analytics_source_data_1
        if hs_analytics_source_data_2 is not None:
            self.inputs["hs_analytics_source_data_2"] = hs_analytics_source_data_2
        if web_technologies is not None:
            self.inputs["web_technologies"] = web_technologies
        if founded_year is not None:
            self.inputs["founded_year"] = founded_year
        if is_public is not None:
            self.inputs["is_public"] = is_public
        if create_deal_stage is not None:
            self.inputs["create_deal_stage"] = create_deal_stage
        if deal_name is not None:
            self.inputs["deal_name"] = deal_name
        if amount is not None:
            self.inputs["amount"] = amount
        if close_date is not None:
            self.inputs["close_date"] = close_date
        if deal_owner is not None:
            self.inputs["deal_owner"] = deal_owner
        if deal_type is not None:
            self.inputs["deal_type"] = deal_type
        if pipeline is not None:
            self.inputs["pipeline"] = pipeline
        if associated_company is not None:
            self.inputs["associated_company"] = associated_company
        if associated_vids is not None:
            self.inputs["associated_vids"] = associated_vids
        if update_deal_id is not None:
            self.inputs["update_deal_id"] = update_deal_id
        if update_deal_stage is not None:
            self.inputs["update_deal_stage"] = update_deal_stage
        if update_deal_name is not None:
            self.inputs["update_deal_name"] = update_deal_name
        if update_amount is not None:
            self.inputs["update_amount"] = update_amount
        if update_close_date is not None:
            self.inputs["update_close_date"] = update_close_date
        if update_deal_owner is not None:
            self.inputs["update_deal_owner"] = update_deal_owner
        if update_deal_type is not None:
            self.inputs["update_deal_type"] = update_deal_type
        if update_pipeline is not None:
            self.inputs["update_pipeline"] = update_pipeline
        if delete_deal_id is not None:
            self.inputs["delete_deal_id"] = delete_deal_id
        if read_deal_id is not None:
            self.inputs["read_deal_id"] = read_deal_id
        if include_property_versions is not None:
            self.inputs["include_property_versions"] = include_property_versions
        if deal_stage is not None:
            self.inputs["deal_stage"] = deal_stage
        if deal_currency_code is not None:
            self.inputs["deal_currency_code"] = deal_currency_code
        if hs_deal_stage_probability is not None:
            self.inputs["hs_deal_stage_probability"] = hs_deal_stage_probability
        if num_associated_contacts is not None:
            self.inputs["num_associated_contacts"] = num_associated_contacts
        if num_contacted_notes is not None:
            self.inputs["num_contacted_notes"] = num_contacted_notes
        if hs_date_entered_closed_won is not None:
            self.inputs["hs_date_entered_closed_won"] = hs_date_entered_closed_won
        if hs_date_entered_closed_lost is not None:
            self.inputs["hs_date_entered_closed_lost"] = hs_date_entered_closed_lost
        if hs_forecast_amount is not None:
            self.inputs["hs_forecast_amount"] = hs_forecast_amount
        if hs_is_closed is not None:
            self.inputs["hs_is_closed"] = hs_is_closed
        if hs_is_deal_split is not None:
            self.inputs["hs_is_deal_split"] = hs_is_deal_split
        if create_ticket_pipeline_id is not None:
            self.inputs["create_ticket_pipeline_id"] = create_ticket_pipeline_id
        if create_ticket_stage_id is not None:
            self.inputs["create_ticket_stage_id"] = create_ticket_stage_id
        if create_ticket_name is not None:
            self.inputs["create_ticket_name"] = create_ticket_name
        if category is not None:
            self.inputs["category"] = category
        if priority is not None:
            self.inputs["priority"] = priority
        if ticket_owner_id is not None:
            self.inputs["ticket_owner_id"] = ticket_owner_id
        if associated_company_ids is not None:
            self.inputs["associated_company_ids"] = associated_company_ids
        if associated_contact_ids is not None:
            self.inputs["associated_contact_ids"] = associated_contact_ids
        if update_ticket_id is not None:
            self.inputs["update_ticket_id"] = update_ticket_id
        if update_ticket_name is not None:
            self.inputs["update_ticket_name"] = update_ticket_name
        if update_category is not None:
            self.inputs["update_category"] = update_category
        if update_priority is not None:
            self.inputs["update_priority"] = update_priority
        if update_stage_id is not None:
            self.inputs["update_stage_id"] = update_stage_id
        if update_ticket_owner_id is not None:
            self.inputs["update_ticket_owner_id"] = update_ticket_owner_id
        if delete_ticket_id is not None:
            self.inputs["delete_ticket_id"] = delete_ticket_id
        if read_ticket_id is not None:
            self.inputs["read_ticket_id"] = read_ticket_id
        if subject is not None:
            self.inputs["subject"] = subject
        if hs_ticket_category is not None:
            self.inputs["hs_ticket_category"] = hs_ticket_category
        if hs_ticket_priority is not None:
            self.inputs["hs_ticket_priority"] = hs_ticket_priority
        if hs_pipeline_stage is not None:
            self.inputs["hs_pipeline_stage"] = hs_pipeline_stage
        if hs_pipeline is not None:
            self.inputs["hs_pipeline"] = hs_pipeline
        if hs_resolution is not None:
            self.inputs["hs_resolution"] = hs_resolution
        if source_type is not None:
            self.inputs["source_type"] = source_type
        if closed_date is not None:
            self.inputs["closed_date"] = closed_date
        if first_agent_reply_date is not None:
            self.inputs["first_agent_reply_date"] = first_agent_reply_date
        if hs_time_to_close is not None:
            self.inputs["hs_time_to_close"] = hs_time_to_close
        if hs_time_to_first_agent_reply is not None:
            self.inputs["hs_time_to_first_agent_reply"] = hs_time_to_first_agent_reply
        if hs_num_times_contacted is not None:
            self.inputs["hs_num_times_contacted"] = hs_num_times_contacted
        if tags is not None:
            self.inputs["tags"] = tags
        if create_engagement_type is not None:
            self.inputs["create_engagement_type"] = create_engagement_type
        if metadata is not None:
            self.inputs["metadata"] = metadata
        if company_ids is not None:
            self.inputs["company_ids"] = company_ids
        if contact_ids is not None:
            self.inputs["contact_ids"] = contact_ids
        if deal_ids is not None:
            self.inputs["deal_ids"] = deal_ids
        if owner_id is not None:
            self.inputs["owner_id"] = owner_id
        if timestamp is not None:
            self.inputs["timestamp"] = timestamp
        if delete_engagement_id is not None:
            self.inputs["delete_engagement_id"] = delete_engagement_id
        if read_engagement_id is not None:
            self.inputs["read_engagement_id"] = read_engagement_id
        if engagement_type is not None:
            self.inputs["engagement_type"] = engagement_type
        if contact_id is not None:
            self.inputs["contact_id"] = contact_id
        if company_id is not None:
            self.inputs["company_id"] = company_id
        if deal_id is not None:
            self.inputs["deal_id"] = deal_id
        if hs_communication_channel_type is not None:
            self.inputs["hs_communication_channel_type"] = hs_communication_channel_type
        if hs_communication_logged_from is not None:
            self.inputs["hs_communication_logged_from"] = hs_communication_logged_from
        if hs_activity_type is not None:
            self.inputs["hs_activity_type"] = hs_activity_type
        if list_id is not None:
            self.inputs["list_id"] = list_id
        if by is not None:
            self.inputs["by"] = by
        if emails is not None:
            self.inputs["emails"] = emails
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationHubspotNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
