"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_cloud_storage")
class IntegrationGoogleCloudStorageNode(Node):
    """
    Google Cloud Storage

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### read_object
        alt: Alternative representation (json for metadata, media for content)
        bucket_name: Enter the name of the bucket to create
        download_content: Download file content instead of metadata
        encryption_key: Customer-supplied encryption key (base64 encoded)
        encryption_key_sha: SHA256 hash of the encryption key (base64 encoded)
        generation: Specify object generation for versioned buckets
        object_name: Enter the name for the object
        project_id: Select your Google Cloud Project
        projection: Select the level of detail to return
    ### create_bucket
        bucket_name: Enter the name of the bucket to create
        cors: Cross-Origin Resource Sharing configuration (JSON format)
        lifecycle: Object lifecycle management rules (JSON format)
        location: Enter the location for the bucket (e.g., US, EU, ASIA)
        project_id: Select your Google Cloud Project
        storage_class: Select the storage class for the bucket
        uniform_bucket_level_access: Enable uniform bucket-level access
        versioning: Enable object versioning for this bucket
    ### read_bucket
        bucket_name: Enter the name of the bucket to create
        project_id: Select your Google Cloud Project
        projection: Select the level of detail to return
    ### update_bucket
        bucket_name: Enter the name of the bucket to create
        cors: Cross-Origin Resource Sharing configuration (JSON format)
        encryption: Default encryption configuration (JSON format)
        labels: Labels to apply to the bucket (JSON format)
        lifecycle: Object lifecycle management rules (JSON format)
        logging: Access logging configuration (JSON format)
        project_id: Select your Google Cloud Project
        storage_class: Select the storage class for the bucket
        versioning: Enable object versioning for this bucket
        website: Static website hosting configuration (JSON format)
    ### delete_bucket
        bucket_name: Enter the name of the bucket to create
        project_id: Select your Google Cloud Project
    ### create_object
        bucket_name: Enter the name of the bucket to create
        cache_control: Cache control directives
        content_disposition: How the object should be displayed
        content_encoding: Content encoding of the object
        content_language: Language of the content
        file: Select a file to upload
        metadata: Custom metadata for the object (JSON format)
        object_name: Enter the name for the object
        project_id: Select your Google Cloud Project
    ### get_objects
        bucket_name: Enter the name of the bucket to create
        delimiter: Delimiter for directory-like listing
        include_versions: Include all versions of objects
        limit: Maximum number of buckets to return
        prefix: Filter results to buckets whose names begin with this prefix
        project_id: Select your Google Cloud Project
        projection: Select the level of detail to return
    ### update_object
        bucket_name: Enter the name of the bucket to create
        cache_control: Cache control directives
        content_disposition: How the object should be displayed
        content_encoding: Content encoding of the object
        content_language: Language of the content
        content_type: MIME type of the object
        generation: Specify object generation for versioned buckets
        metadata: Custom metadata for the object (JSON format)
        object_name: Enter the name for the object
        project_id: Select your Google Cloud Project
    ### delete_object
        bucket_name: Enter the name of the bucket to create
        generation: Specify object generation for versioned buckets
        object_name: Enter the name for the object
        project_id: Select your Google Cloud Project
    ### get_buckets
        limit: Maximum number of buckets to return
        prefix: Filter results to buckets whose names begin with this prefix
        project_id: Select your Google Cloud Project
        projection: Select the level of detail to return

    ## Outputs
    ### create_object
        bucket: The bucket containing the object
        content_type: The content type of the object
        generation: The generation of the object
        md5_hash: The MD5 hash of the object
        media_link: The download URL for the object
        metageneration: The metageneration of the object
        object_id: The unique ID of the created object
        object_name: The name of the created object
        raw_data: The raw API response data
        self_link: The URI of the object
        size: The size of the object in bytes
        storage_class: The storage class of the object
        time_created: The creation time of the object
        updated: The last update time of the object
    ### read_object
        bucket: The bucket containing the object
        content_type: The content type of the object
        crc32c: The CRC32C checksum of the object
        etag: The ETag of the object
        file: The downloaded file (when download_content is true)
        file_name: Name of the downloaded file (when download_content is true)
        generation: The generation of the object
        md5_hash: The MD5 hash of the object
        media_link: The download URL for the object
        metadata: Custom metadata of the object
        metageneration: The metageneration of the object
        object_id: The unique ID of the object
        object_name: The name of the object
        raw_data: The raw API response data
        self_link: The URI of the object
        size: The size of the object in bytes
        storage_class: The storage class of the object
        time_created: The creation time of the object
        updated: The last update time of the object
    ### update_object
        bucket: The bucket containing the object
        content_type: The content type of the object
        generation: The generation of the object
        md5_hash: The MD5 hash of the object
        metadata: Custom metadata of the object
        metageneration: The metageneration of the object
        object_id: The unique ID of the object
        object_name: The name of the object
        raw_data: The raw API response data
        size: The size of the object in bytes
        storage_class: The storage class of the object
        time_created: The creation time of the object
        updated: The last update time of the object
    ### create_bucket
        bucket_id: The unique ID of the created bucket
        bucket_name: The name of the created bucket
        location: The location of the bucket
        project_number: The project number associated with the bucket
        raw_data: The raw API response data
        storage_class: The storage class of the bucket
        time_created: The creation time of the bucket
        updated: The last update time of the bucket
    ### read_bucket
        bucket_id: The unique ID of the bucket
        bucket_name: The name of the bucket
        etag: The ETag of the bucket
        location: The location of the bucket
        metageneration: The metageneration of the bucket
        project_number: The project number associated with the bucket
        raw_data: The raw API response data
        storage_class: The storage class of the bucket
        time_created: The creation time of the bucket
        updated: The last update time of the bucket
    ### update_bucket
        bucket_id: The unique ID of the bucket
        bucket_name: The name of the bucket
        location: The location of the bucket
        project_number: The project number associated with the bucket
        raw_data: The raw API response data
        storage_class: The storage class of the bucket
        time_created: The creation time of the bucket
        updated: The last update time of the bucket
    ### get_buckets
        bucket_ids: List of bucket IDs
        bucket_names: List of bucket names
        buckets: List of bucket objects
        locations: List of bucket locations
        raw_data: The raw API response data
        storage_classes: List of bucket storage classes
    ### get_objects
        content_types: List of object content types
        object_names: List of object names
        object_sizes: List of object sizes
        objects: List of object metadata
        prefixes: List of prefixes (for directory-like listing)
        raw_data: The raw API response data
        time_created: List of object creation times
        updated: List of object update times
    ### delete_bucket
        message: Success or error message
    ### delete_object
        message: Success or error message
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Cloud Storage>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_bucket": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "value": "",
                    "label": "Bucket Name",
                    "helper_text": "Enter the name of the bucket to create",
                    "placeholder": "my-storage-bucket",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "helper_text": "Enter the location for the bucket (e.g., US, EU, ASIA)",
                    "placeholder": "US",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "label": "Storage Class",
                    "helper_text": "Select the storage class for the bucket",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Standard", "value": "STANDARD"},
                            {"label": "Nearline", "value": "NEARLINE"},
                            {"label": "Coldline", "value": "COLDLINE"},
                            {"label": "Archive", "value": "ARCHIVE"},
                        ],
                    },
                    "value": "STANDARD",
                },
                {
                    "field": "uniform_bucket_level_access",
                    "type": "bool",
                    "label": "Uniform Bucket Level Access",
                    "helper_text": "Enable uniform bucket-level access",
                    "value": False,
                },
                {
                    "field": "cors",
                    "type": "string",
                    "value": "",
                    "label": "CORS Configuration",
                    "helper_text": "Cross-Origin Resource Sharing configuration (JSON format)",
                    "placeholder": '[{"origin": ["*"], "method": ["GET"], ...}]',
                },
                {
                    "field": "lifecycle",
                    "type": "string",
                    "value": "",
                    "label": "Lifecycle Configuration",
                    "helper_text": "Object lifecycle management rules (JSON format)",
                    "placeholder": '{"rule": [{"action": {"type": "Delete"}, ...]}',
                },
                {
                    "field": "versioning",
                    "type": "bool",
                    "value": False,
                    "label": "Enable Versioning",
                    "helper_text": "Enable object versioning for this bucket",
                },
            ],
            "outputs": [
                {
                    "field": "bucket_id",
                    "type": "string",
                    "helper_text": "The unique ID of the created bucket",
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The name of the created bucket",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The location of the bucket",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "helper_text": "The storage class of the bucket",
                },
                {
                    "field": "time_created",
                    "type": "timestamp",
                    "helper_text": "The creation time of the bucket",
                },
                {
                    "field": "updated",
                    "type": "timestamp",
                    "helper_text": "The last update time of the bucket",
                },
                {
                    "field": "project_number",
                    "type": "string",
                    "helper_text": "The project number associated with the bucket",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "create_bucket",
            "task_name": "tasks.google_cloud_storage.create_bucket",
            "description": "Creates a new bucket in Google Cloud Storage",
            "label": "Create Bucket",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "location",
                "storage_class",
                "uniform_bucket_level_access",
                "cors",
                "lifecycle",
                "versioning",
            ],
            "required": ["project_id", "bucket_name", "storage_class"],
        },
        "read_bucket": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket to read",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "projection",
                    "type": "string",
                    "label": "Projection",
                    "helper_text": "Select the level of detail to return",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No ACL", "value": "noAcl"},
                            {"label": "Full", "value": "full"},
                        ],
                    },
                    "value": "noAcl",
                },
            ],
            "outputs": [
                {
                    "field": "bucket_id",
                    "type": "string",
                    "helper_text": "The unique ID of the bucket",
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The name of the bucket",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The location of the bucket",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "helper_text": "The storage class of the bucket",
                },
                {
                    "field": "time_created",
                    "type": "timestamp",
                    "helper_text": "The creation time of the bucket",
                },
                {
                    "field": "updated",
                    "type": "timestamp",
                    "helper_text": "The last update time of the bucket",
                },
                {
                    "field": "project_number",
                    "type": "string",
                    "helper_text": "The project number associated with the bucket",
                },
                {
                    "field": "metageneration",
                    "type": "string",
                    "helper_text": "The metageneration of the bucket",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "The ETag of the bucket",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "read_bucket",
            "task_name": "tasks.google_cloud_storage.read_bucket",
            "description": "Read details of a specific bucket",
            "label": "Get Bucket",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "projection",
            ],
            "required": ["project_id", "bucket_name"],
        },
        "get_buckets": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of buckets to return",
                    "placeholder": "10",
                },
                {
                    "field": "projection",
                    "type": "string",
                    "label": "Projection",
                    "helper_text": "Select the level of detail to return",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No ACL", "value": "noAcl"},
                            {"label": "Full", "value": "full"},
                        ],
                    },
                    "value": "noAcl",
                },
                {
                    "field": "prefix",
                    "type": "string",
                    "value": "",
                    "label": "Prefix",
                    "helper_text": "Filter results to buckets whose names begin with this prefix",
                    "placeholder": "backup-",
                },
            ],
            "outputs": [
                {
                    "field": "buckets",
                    "type": "string",
                    "helper_text": "List of bucket objects",
                },
                {
                    "field": "bucket_names",
                    "type": "vec<string>",
                    "helper_text": "List of bucket names",
                },
                {
                    "field": "bucket_ids",
                    "type": "vec<string>",
                    "helper_text": "List of bucket IDs",
                },
                {
                    "field": "locations",
                    "type": "vec<string>",
                    "helper_text": "List of bucket locations",
                },
                {
                    "field": "storage_classes",
                    "type": "vec<string>",
                    "helper_text": "List of bucket storage classes",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "get_buckets",
            "task_name": "tasks.google_cloud_storage.get_buckets",
            "description": "Get multiple buckets",
            "label": "List Buckets",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "limit",
                "projection",
                "prefix",
            ],
            "required": ["project_id", "limit"],
        },
        "update_bucket": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket to update",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "label": "Storage Class",
                    "helper_text": "Select the new storage class for the bucket",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Standard", "value": "STANDARD"},
                            {"label": "Nearline", "value": "NEARLINE"},
                            {"label": "Coldline", "value": "COLDLINE"},
                            {"label": "Archive", "value": "ARCHIVE"},
                        ],
                    },
                    "value": "STANDARD",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "label": "Labels",
                    "helper_text": "Labels to apply to the bucket (JSON format)",
                    "placeholder": '{"key": "value"}',
                },
                {
                    "field": "cors",
                    "type": "string",
                    "value": "",
                    "label": "CORS Configuration",
                    "helper_text": "Cross-Origin Resource Sharing configuration (JSON format)",
                    "placeholder": '[{"origin": ["*"], "method": ["GET"], ...}]',
                },
                {
                    "field": "lifecycle",
                    "type": "string",
                    "value": "",
                    "label": "Lifecycle Configuration",
                    "helper_text": "Object lifecycle management rules (JSON format)",
                    "placeholder": '{"rule": [{"action": {"type": "Delete"}, ...}]}',
                },
                {
                    "field": "versioning",
                    "type": "bool",
                    "value": False,
                    "label": "Enable Versioning",
                    "helper_text": "Enable object versioning for this bucket",
                },
                {
                    "field": "website",
                    "type": "string",
                    "value": "",
                    "label": "Website Configuration",
                    "helper_text": "Static website hosting configuration (JSON format)",
                    "placeholder": '{"mainPageSuffix": "index.html", ...}',
                },
                {
                    "field": "logging",
                    "type": "string",
                    "value": "",
                    "label": "Logging Configuration",
                    "helper_text": "Access logging configuration (JSON format)",
                    "placeholder": '{"logBucket": "my-log-bucket", ...}',
                },
                {
                    "field": "encryption",
                    "type": "string",
                    "value": "",
                    "label": "Encryption Configuration",
                    "helper_text": "Default encryption configuration (JSON format)",
                    "placeholder": '{"defaultKmsKeyName": "projects/my-project/.../my-key"}',
                },
            ],
            "outputs": [
                {
                    "field": "bucket_id",
                    "type": "string",
                    "helper_text": "The unique ID of the bucket",
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "helper_text": "The name of the bucket",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The location of the bucket",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "helper_text": "The storage class of the bucket",
                },
                {
                    "field": "time_created",
                    "type": "timestamp",
                    "helper_text": "The creation time of the bucket",
                },
                {
                    "field": "updated",
                    "type": "timestamp",
                    "helper_text": "The last update time of the bucket",
                },
                {
                    "field": "project_number",
                    "type": "string",
                    "helper_text": "The project number associated with the bucket",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "update_bucket",
            "task_name": "tasks.google_cloud_storage.update_bucket",
            "description": "Updates bucket metadata",
            "label": "Update Bucket",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "storage_class",
                "labels",
                "cors",
                "lifecycle",
                "versioning",
                "website",
                "logging",
                "encryption",
            ],
            "required": ["bucket_name"],
        },
        "delete_bucket": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket to delete",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                }
            ],
            "name": "delete_bucket",
            "task_name": "tasks.google_cloud_storage.delete_bucket",
            "description": "Deletes a bucket from Google Cloud Storage",
            "label": "Delete Bucket",
            "input_sort_order": ["action", "integration", "project_id", "bucket_name"],
            "required": ["project_id", "bucket_name"],
        },
        "create_object": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "value": "",
                    "label": "Object Name",
                    "helper_text": "Enter the name for the object",
                    "placeholder": "folder/subfolder/file.txt",
                },
                {
                    "field": "file",
                    "type": "file",
                    "label": "File",
                    "helper_text": "Select a file to upload",
                    "value": "",
                },
                {
                    "field": "cache_control",
                    "type": "string",
                    "value": "",
                    "label": "Cache Control",
                    "helper_text": "Cache control directives",
                    "placeholder": "max-age=3600, public",
                },
                {
                    "field": "content_disposition",
                    "type": "string",
                    "value": "",
                    "label": "Content Disposition",
                    "helper_text": "How the object should be displayed",
                    "placeholder": "attachment; filename=example.pdf",
                },
                {
                    "field": "content_encoding",
                    "type": "string",
                    "value": "",
                    "label": "Content Encoding",
                    "helper_text": "Content encoding of the object",
                    "placeholder": "gzip",
                },
                {
                    "field": "content_language",
                    "type": "string",
                    "value": "",
                    "label": "Content Language",
                    "helper_text": "Language of the content",
                    "placeholder": "en-US",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "value": "",
                    "label": "Custom Metadata",
                    "helper_text": "Custom metadata for the object (JSON format)",
                    "placeholder": '{"key": "value"}',
                },
            ],
            "outputs": [
                {
                    "field": "object_id",
                    "type": "string",
                    "helper_text": "The unique ID of the created object",
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "helper_text": "The name of the created object",
                },
                {
                    "field": "bucket",
                    "type": "string",
                    "helper_text": "The bucket containing the object",
                },
                {
                    "field": "generation",
                    "type": "string",
                    "helper_text": "The generation of the object",
                },
                {
                    "field": "metageneration",
                    "type": "string",
                    "helper_text": "The metageneration of the object",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "The content type of the object",
                },
                {
                    "field": "time_created",
                    "type": "timestamp",
                    "helper_text": "The creation time of the object",
                },
                {
                    "field": "updated",
                    "type": "timestamp",
                    "helper_text": "The last update time of the object",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "helper_text": "The storage class of the object",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "The size of the object in bytes",
                },
                {
                    "field": "md5_hash",
                    "type": "string",
                    "helper_text": "The MD5 hash of the object",
                },
                {
                    "field": "media_link",
                    "type": "string",
                    "helper_text": "The download URL for the object",
                },
                {
                    "field": "self_link",
                    "type": "string",
                    "helper_text": "The URI of the object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "create_object",
            "task_name": "tasks.google_cloud_storage.create_object",
            "description": "Creates/uploads a new object to Google Cloud Storage",
            "label": "Create Object",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "object_name",
                "file",
                "cache_control",
                "content_disposition",
                "content_encoding",
                "content_language",
                "metadata",
            ],
            "required": ["project_id", "bucket_name", "object_name", "file"],
        },
        "read_object": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "label": "Object Name",
                    "helper_text": "Enter the name of the object to read",
                    "placeholder": "folder/subfolder/file.txt",
                },
                {
                    "field": "download_content",
                    "type": "bool",
                    "label": "Download Content",
                    "helper_text": "Download file content instead of metadata",
                    "value": False,
                },
                {
                    "field": "generation",
                    "type": "int32",
                    "value": 0,
                    "label": "Generation",
                    "helper_text": "Specify object generation for versioned buckets",
                    "placeholder": "1234567890",
                },
                {
                    "field": "projection",
                    "type": "string",
                    "label": "Projection",
                    "helper_text": "Select the level of detail to return",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No ACL", "value": "noAcl"},
                            {"label": "Full", "value": "full"},
                        ],
                    },
                    "value": "noAcl",
                },
                {
                    "field": "alt",
                    "type": "string",
                    "value": "",
                    "label": "Alt Parameter",
                    "helper_text": "Alternative representation (json for metadata, media for content)",
                    "placeholder": "json",
                },
                {
                    "field": "encryption_key",
                    "type": "string",
                    "value": "",
                    "label": "Encryption Key",
                    "helper_text": "Customer-supplied encryption key (base64 encoded)",
                    "placeholder": "",
                },
                {
                    "field": "encryption_key_sha",
                    "type": "string",
                    "value": "",
                    "label": "Encryption Key SHA256",
                    "helper_text": "SHA256 hash of the encryption key (base64 encoded)",
                    "placeholder": "",
                },
            ],
            "outputs": [
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "The downloaded file (when download_content is true)",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the downloaded file (when download_content is true)",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "The content type of the object",
                },
                {
                    "field": "object_id",
                    "type": "string",
                    "helper_text": "The unique ID of the object",
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "helper_text": "The name of the object",
                },
                {
                    "field": "bucket",
                    "type": "string",
                    "helper_text": "The bucket containing the object",
                },
                {
                    "field": "generation",
                    "type": "string",
                    "helper_text": "The generation of the object",
                },
                {
                    "field": "metageneration",
                    "type": "string",
                    "helper_text": "The metageneration of the object",
                },
                {
                    "field": "time_created",
                    "type": "timestamp",
                    "helper_text": "The creation time of the object",
                },
                {
                    "field": "updated",
                    "type": "timestamp",
                    "helper_text": "The last update time of the object",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "helper_text": "The storage class of the object",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "The size of the object in bytes",
                },
                {
                    "field": "md5_hash",
                    "type": "string",
                    "helper_text": "The MD5 hash of the object",
                },
                {
                    "field": "crc32c",
                    "type": "string",
                    "helper_text": "The CRC32C checksum of the object",
                },
                {
                    "field": "etag",
                    "type": "string",
                    "helper_text": "The ETag of the object",
                },
                {
                    "field": "media_link",
                    "type": "string",
                    "helper_text": "The download URL for the object",
                },
                {
                    "field": "self_link",
                    "type": "string",
                    "helper_text": "The URI of the object",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "helper_text": "Custom metadata of the object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "read_object",
            "task_name": "tasks.google_cloud_storage.read_object",
            "description": "Read details of a specific object",
            "label": "Get Object",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "object_name",
                "download_content",
                "generation",
                "projection",
                "alt",
                "encryption_key",
                "encryption_key_sha256",
            ],
            "required": ["project_id", "bucket_name", "object_name"],
        },
        "get_objects": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "projection",
                    "type": "string",
                    "label": "Projection",
                    "helper_text": "Select the level of detail to return",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "No ACL", "value": "noAcl"},
                            {"label": "Full", "value": "full"},
                        ],
                    },
                    "value": "noAcl",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of objects to return",
                    "placeholder": "10",
                },
                {
                    "field": "prefix",
                    "type": "string",
                    "value": "",
                    "label": "Prefix",
                    "helper_text": "Filter results to objects whose names begin with this prefix",
                    "placeholder": "images/",
                },
                {
                    "field": "delimiter",
                    "type": "string",
                    "value": "",
                    "label": "Delimiter",
                    "helper_text": "Delimiter for directory-like listing",
                    "placeholder": "/",
                },
                {
                    "field": "include_versions",
                    "type": "bool",
                    "label": "Include Versions",
                    "helper_text": "Include all versions of objects",
                    "value": False,
                },
            ],
            "outputs": [
                {
                    "field": "objects",
                    "type": "string",
                    "helper_text": "List of object metadata",
                },
                {
                    "field": "object_names",
                    "type": "vec<string>",
                    "helper_text": "List of object names",
                },
                {
                    "field": "object_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of object sizes",
                },
                {
                    "field": "content_types",
                    "type": "vec<string>",
                    "helper_text": "List of object content types",
                },
                {
                    "field": "time_created",
                    "type": "vec<timestamp>",
                    "helper_text": "List of object creation times",
                },
                {
                    "field": "updated",
                    "type": "vec<timestamp>",
                    "helper_text": "List of object update times",
                },
                {
                    "field": "prefixes",
                    "type": "vec<string>",
                    "helper_text": "List of prefixes (for directory-like listing)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "get_objects",
            "task_name": "tasks.google_cloud_storage.get_objects",
            "description": "Get multiple objects",
            "label": "List Objects",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "projection",
                "limit",
                "prefix",
                "delimiter",
                "include_versions",
            ],
            "required": ["project_id", "bucket_name", "limit"],
        },
        "update_object": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "label": "Object Name",
                    "helper_text": "Enter the name of the object to update",
                    "placeholder": "folder/subfolder/file.txt",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "value": "",
                    "label": "Custom Metadata",
                    "helper_text": "Custom metadata for the object (JSON format)",
                    "placeholder": '{"key": "value"}',
                },
                {
                    "field": "cache_control",
                    "type": "string",
                    "value": "",
                    "label": "Cache Control",
                    "helper_text": "Cache control directives",
                    "placeholder": "max-age=3600, public",
                },
                {
                    "field": "content_disposition",
                    "type": "string",
                    "value": "",
                    "label": "Content Disposition",
                    "helper_text": "How the object should be displayed",
                    "placeholder": "attachment; filename=example.pdf",
                },
                {
                    "field": "content_encoding",
                    "type": "string",
                    "value": "",
                    "label": "Content Encoding",
                    "helper_text": "Content encoding of the object",
                    "placeholder": "gzip",
                },
                {
                    "field": "content_language",
                    "type": "string",
                    "value": "",
                    "label": "Content Language",
                    "helper_text": "Language of the content",
                    "placeholder": "en-US",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "",
                    "label": "Content Type",
                    "helper_text": "MIME type of the object",
                    "placeholder": "image/png",
                },
                {
                    "field": "generation",
                    "type": "int32",
                    "value": 0,
                    "label": "Generation",
                    "helper_text": "Specify object generation for versioned buckets",
                    "placeholder": "1234567890",
                },
            ],
            "outputs": [
                {
                    "field": "object_id",
                    "type": "string",
                    "helper_text": "The unique ID of the object",
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "helper_text": "The name of the object",
                },
                {
                    "field": "bucket",
                    "type": "string",
                    "helper_text": "The bucket containing the object",
                },
                {
                    "field": "generation",
                    "type": "string",
                    "helper_text": "The generation of the object",
                },
                {
                    "field": "metageneration",
                    "type": "string",
                    "helper_text": "The metageneration of the object",
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "helper_text": "The content type of the object",
                },
                {
                    "field": "time_created",
                    "type": "timestamp",
                    "helper_text": "The creation time of the object",
                },
                {
                    "field": "updated",
                    "type": "timestamp",
                    "helper_text": "The last update time of the object",
                },
                {
                    "field": "storage_class",
                    "type": "string",
                    "helper_text": "The storage class of the object",
                },
                {
                    "field": "size",
                    "type": "string",
                    "helper_text": "The size of the object in bytes",
                },
                {
                    "field": "md5_hash",
                    "type": "string",
                    "helper_text": "The MD5 hash of the object",
                },
                {
                    "field": "metadata",
                    "type": "string",
                    "helper_text": "Custom metadata of the object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "The raw API response data",
                },
            ],
            "name": "update_object",
            "task_name": "tasks.google_cloud_storage.update_object",
            "description": "Updates object metadata",
            "label": "Update Object",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "object_name",
                "metadata",
                "cache_control",
                "content_disposition",
                "content_encoding",
                "content_language",
                "content_type",
                "generation",
            ],
            "required": ["project_id", "bucket_name", "object_name"],
        },
        "delete_object": {
            "inputs": [
                {
                    "field": "project_id",
                    "type": "string",
                    "label": "Project",
                    "helper_text": "Select your Google Cloud Project",
                    "placeholder": "Select a project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "bucket_name",
                    "type": "string",
                    "label": "Bucket Name",
                    "helper_text": "Select the bucket",
                    "placeholder": "Select a bucket",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=bucket&project={inputs.project_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "object_name",
                    "type": "string",
                    "label": "Object Name",
                    "helper_text": "Enter the name of the object to delete",
                    "placeholder": "folder/subfolder/file.txt",
                },
                {
                    "field": "generation",
                    "type": "int32",
                    "value": 0,
                    "label": "Generation",
                    "helper_text": "Specify object generation for versioned buckets",
                    "placeholder": "1234567890",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success or error message",
                }
            ],
            "name": "delete_object",
            "task_name": "tasks.google_cloud_storage.delete_object",
            "description": "Deletes an object from Google Cloud Storage",
            "label": "Delete Object",
            "input_sort_order": [
                "action",
                "integration",
                "project_id",
                "bucket_name",
                "object_name",
                "generation",
            ],
            "required": ["project_id", "bucket_name", "object_name"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        alt: str = "",
        bucket_name: str = "",
        cache_control: str = "",
        content_disposition: str = "",
        content_encoding: str = "",
        content_language: str = "",
        content_type: str = "",
        cors: str = "",
        delimiter: str = "",
        download_content: bool = False,
        encryption: str = "",
        encryption_key: str = "",
        encryption_key_sha: str = "",
        file: str = "",
        generation: int = 0,
        include_versions: bool = False,
        labels: str = "",
        lifecycle: str = "",
        limit: int = 10,
        location: str = "",
        logging: str = "",
        metadata: str = "",
        object_name: str = "",
        prefix: str = "",
        project_id: Optional[str] = None,
        projection: str = "noAcl",
        storage_class: str = "STANDARD",
        uniform_bucket_level_access: bool = False,
        versioning: bool = False,
        website: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_cloud_storage",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if project_id is not None:
            self.inputs["project_id"] = project_id
        if bucket_name is not None:
            self.inputs["bucket_name"] = bucket_name
        if location is not None:
            self.inputs["location"] = location
        if storage_class is not None:
            self.inputs["storage_class"] = storage_class
        if uniform_bucket_level_access is not None:
            self.inputs["uniform_bucket_level_access"] = uniform_bucket_level_access
        if cors is not None:
            self.inputs["cors"] = cors
        if lifecycle is not None:
            self.inputs["lifecycle"] = lifecycle
        if versioning is not None:
            self.inputs["versioning"] = versioning
        if projection is not None:
            self.inputs["projection"] = projection
        if limit is not None:
            self.inputs["limit"] = limit
        if prefix is not None:
            self.inputs["prefix"] = prefix
        if labels is not None:
            self.inputs["labels"] = labels
        if website is not None:
            self.inputs["website"] = website
        if logging is not None:
            self.inputs["logging"] = logging
        if encryption is not None:
            self.inputs["encryption"] = encryption
        if object_name is not None:
            self.inputs["object_name"] = object_name
        if file is not None:
            self.inputs["file"] = file
        if cache_control is not None:
            self.inputs["cache_control"] = cache_control
        if content_disposition is not None:
            self.inputs["content_disposition"] = content_disposition
        if content_encoding is not None:
            self.inputs["content_encoding"] = content_encoding
        if content_language is not None:
            self.inputs["content_language"] = content_language
        if metadata is not None:
            self.inputs["metadata"] = metadata
        if download_content is not None:
            self.inputs["download_content"] = download_content
        if generation is not None:
            self.inputs["generation"] = generation
        if alt is not None:
            self.inputs["alt"] = alt
        if encryption_key is not None:
            self.inputs["encryption_key"] = encryption_key
        if encryption_key_sha is not None:
            self.inputs["encryption_key_sha"] = encryption_key_sha
        if delimiter is not None:
            self.inputs["delimiter"] = delimiter
        if include_versions is not None:
            self.inputs["include_versions"] = include_versions
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleCloudStorageNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
