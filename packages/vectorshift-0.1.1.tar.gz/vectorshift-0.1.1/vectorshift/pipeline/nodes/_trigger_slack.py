"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_slack")
class TriggerSlackNode(Node):
    """
    Slack Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        item_id: The item_id input
        trigger_enabled: Enable/Disable Automation
    ### new_message
        channel: The name of the Slack channel
        team: The name of the Slack team
    ### new_channel_member
        channel: The name of the Slack channel
        team: The name of the Slack team
    ### new_mention
        channel: The name of the Slack channel
        team: The name of the Slack team
    ### new_channel
        team: The name of the Slack team
    ### new_file
        team: The name of the Slack team
    ### new_user
        team: The name of the Slack team

    ## Outputs
    ### new_message
        attachments: Files attached to the message
        channel_id: Unique identifier of the channel where the message was sent
        channel_name: Name of the channel where the message was sent
        message: The content of the message
        message_id: Unique identifier for the message
        permalink: Direct link to access this message
        timestamp: When the message was sent
        user_id: Unique identifier of the message sender
        user_name: Display name of the message sender
    ### new_channel_member
        channel: Channel ID that was joined
        channel_name: Name of the channel that was joined
        inviter: User ID who invited the member (if applicable)
        timestamp: When the user joined the channel
        user: User ID who joined the channel
    ### new_mention
        channel: Channel ID where the mention occurred
        channel_name: Name of the channel where the mention occurred
        text: The content of the mention
        timestamp: When the mention occurred
        user: User ID who mentioned the app/keyword
    ### new_channel
        channel_id: Unique identifier of the new channel
        channel_name: Name of the new channel
        creator: User ID who created the channel
        timestamp: When the channel was created
    ### new_file
        download_url: Private download URL for the file
        file_id: Unique identifier of the uploaded file
        file_name: Name of the uploaded file
        file_title: Title of the uploaded file
        mime_type: MIME type of the file
        permalink: Permanent link to the file in Slack
        size: Size of the file in bytes
        timestamp: When the file was uploaded
        user_id: User ID who uploaded the file
    ### new_user
        email: Email address of the new user
        real_name: Real name of the new user
        timestamp: When the user joined the workspace
        user_id: Unique identifier of the new user
        user_name: Username of the new user
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Slack>",
        },
        {
            "field": "item_id",
            "helper_text": "The item_id input",
            "value": "",
            "type": "string",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_message": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Select a team",
                    "helper_text": "The name of the Slack team",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "placeholder": "Select a channel",
                    "helper_text": "The name of the Slack channel",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "The content of the message",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "Unique identifier for the message",
                },
                {
                    "field": "timestamp",
                    "type": "string",
                    "helper_text": "When the message was sent",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Display name of the message sender",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the message sender",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "helper_text": "Files attached to the message",
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the channel where the message was sent",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel where the message was sent",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "Direct link to access this message",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "new_message",
            "task_name": "tasks.slack.new_message",
            "description": "Triggers when new message appears in the specified channel",
            "label": "New Message",
            "required": ["team", "channel"],
        },
        "new_channel": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Select a team",
                    "helper_text": "The name of the Slack team",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the new channel",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "helper_text": "User ID who created the channel",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "When the channel was created",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "new_channel",
            "task_name": "tasks.slack.new_channel",
            "description": "Triggers when a new public channel is created in the workspace",
            "label": "New Channel",
            "required": ["team"],
        },
        "new_channel_member": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Select a team",
                    "helper_text": "The name of the Slack team",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "placeholder": "Select a channel",
                    "helper_text": "The name of the Slack channel",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "User ID who joined the channel",
                },
                {
                    "field": "channel",
                    "type": "string",
                    "helper_text": "Channel ID that was joined",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel that was joined",
                },
                {
                    "field": "inviter",
                    "type": "string",
                    "helper_text": "User ID who invited the member (if applicable)",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "When the user joined the channel",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "new_channel_member",
            "task_name": "tasks.slack.new_channel_member",
            "description": "Triggers when a new member joins a channel",
            "label": "New Channel Member",
            "required": ["team", "channel"],
        },
        "new_file": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Select a team",
                    "helper_text": "The name of the Slack team",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the uploaded file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "file_title",
                    "type": "string",
                    "helper_text": "Title of the uploaded file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int32",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "User ID who uploaded the file",
                },
                {
                    "field": "download_url",
                    "type": "string",
                    "helper_text": "Private download URL for the file",
                },
                {
                    "field": "permalink",
                    "type": "string",
                    "helper_text": "Permanent link to the file in Slack",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "When the file was uploaded",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "new_file",
            "task_name": "tasks.slack.new_file",
            "description": "Triggers when a new file is uploaded to your workspace",
            "label": "New File",
            "required": ["team"],
        },
        "new_mention": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Select a team",
                    "helper_text": "The name of the Slack team",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel",
                    "type": "string",
                    "value": "",
                    "label": "Channel",
                    "placeholder": "Select a channel",
                    "helper_text": "The name of the Slack channel",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_name&team={inputs.team}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user",
                    "type": "string",
                    "helper_text": "User ID who mentioned the app/keyword",
                },
                {
                    "field": "text",
                    "type": "string",
                    "helper_text": "The content of the mention",
                },
                {
                    "field": "channel",
                    "type": "string",
                    "helper_text": "Channel ID where the mention occurred",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel where the mention occurred",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "When the mention occurred",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "new_mention",
            "task_name": "tasks.slack.new_mention",
            "description": "Triggers when the app is mentioned in a channel",
            "label": "New Mention",
            "required": ["team", "channel"],
        },
        "new_user": {
            "inputs": [
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Select a team",
                    "helper_text": "The name of the Slack team",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Username of the new user",
                },
                {
                    "field": "real_name",
                    "type": "string",
                    "helper_text": "Real name of the new user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "Email address of the new user",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "When the user joined the workspace",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "new_user",
            "task_name": "tasks.slack.new_user",
            "description": "Triggers when a new user joins your workspace",
            "label": "New User",
            "required": ["team"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Item ID"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        channel: str = "",
        item_id: str = "",
        team: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_slack",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if team is not None:
            self.inputs["team"] = team
        if channel is not None:
            self.inputs["channel"] = channel
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerSlackNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
