"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import NameDescription
from ..config_objects import SamplingConfig


@Node.register_node_type("categorizer")
class CategorizerNode(Node):
    """
    Categorize text using AI into custom-defined buckets

    ## Inputs
    ### Common Inputs
        model: The specific model for categorization
        text: The text that will be categorized
        temperature: The temperature of the model
        max_tokens: The maximum number of tokens to generate
        top_p: The top-p value
        additional_context: Provide any additional context or instructions
        fields: The fields to be categorized
        justification: Include the AI's justification for its score
        provider: The model provider

    ## Outputs
    ### Common Outputs
        category: The category of the input text
        credits_used: The number of credits used
        input_tokens: The number of input tokens
        output_tokens: The number of output tokens
        tokens_used: The number of tokens used
    ### When justification = True
        justification: The AI justification
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for categorization",
            "value": "gpt-4o",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The text that will be categorized",
            "value": "",
            "type": "string",
        },
        {
            "field": "temperature",
            "helper_text": "The temperature of the model",
            "value": 0.7,
            "type": "float",
        },
        {
            "field": "max_tokens",
            "helper_text": "The maximum number of tokens to generate",
            "value": 2048,
            "type": "int64",
        },
        {
            "field": "top_p",
            "helper_text": "The top-p value",
            "value": 1.0,
            "type": "float",
        },
        {
            "field": "additional_context",
            "helper_text": "Provide any additional context or instructions",
            "value": "",
            "type": "string",
        },
        {
            "field": "fields",
            "helper_text": "The fields to be categorized",
            "value": [],
            "type": "vec<interface{id: string, name: string, description: string}>",
        },
        {
            "field": "justification",
            "helper_text": "Include the AI's justification for its score",
            "value": False,
            "type": "bool",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "category",
            "helper_text": "The category of the input text",
            "type": "string",
        },
        {
            "field": "credits_used",
            "helper_text": "The number of credits used",
            "type": "float",
        },
        {
            "field": "input_tokens",
            "helper_text": "The number of input tokens",
            "type": "int64",
        },
        {
            "field": "output_tokens",
            "helper_text": "The number of output tokens",
            "type": "int64",
        },
        {
            "field": "tokens_used",
            "helper_text": "The number of tokens used",
            "type": "int64",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "justification",
                    "type": "string",
                    "helper_text": "The AI justification",
                }
            ],
        },
        "false**(*)": {"inputs": [], "outputs": []},
        "(*)**openai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**cohere": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**google": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**xai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**aws": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**azure": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**together": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for categorization",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["justification", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text"]

    def __init__(
        self,
        justification: bool = False,
        provider: str = "openai",
        model: str = "gpt-4o",
        text: str = "",
        additional_context: str = "",
        fields: List[NameDescription] = [],
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["justification"] = justification
        params["provider"] = provider

        super().__init__(
            node_type="categorizer",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if justification is not None:
            self.inputs["justification"] = justification
        if fields is not None:
            self.inputs["fields"] = fields
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if additional_context is not None:
            self.inputs["additional_context"] = additional_context
        if text is not None:
            self.inputs["text"] = text
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CategorizerNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
