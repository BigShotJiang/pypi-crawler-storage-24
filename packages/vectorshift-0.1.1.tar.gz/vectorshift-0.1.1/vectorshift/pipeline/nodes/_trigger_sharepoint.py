"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_sharepoint")
class TriggerSharepointNode(Node):
    """
    SharePoint Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        trigger_enabled: Enable/Disable Automation
    ### new_file
        item_id: Select a SharePoint site or folder to monitor for new files
    ### updated_file
        item_id: Select a SharePoint site or folder to monitor for new files

    ## Outputs
    ### new_file
        created_by_email: Email of the user who created the file
        created_by_name: Name of the user who created the file
        created_time: When the file was created
        file_id: Unique identifier of the new file
        file_name: Name of the new file
        mime_type: MIME type of the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    ### updated_file
        created_time: When the file was created
        file_id: Unique identifier of the updated file
        file_name: Name of the updated file
        mime_type: MIME type of the file
        modified_by_email: Email of the user who last modified the file
        modified_by_name: Name of the user who last modified the file
        modified_time: When the file was last modified
        parent_folder_id: ID of the parent folder
        raw_data: Complete file data as JSON
        size: Size of the file in bytes
        trigger_timestamp: When this trigger was activated
        web_url: Link to view the file in browser
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Sharepoint>",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_file": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select a SharePoint site or folder to monitor for new files",
                    "label": "File location",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&is_trigger=true&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the new file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the new file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "created_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who created the file",
                },
                {
                    "field": "created_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who created the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "new_file",
            "task_name": "tasks.sharepoint.file_created",
            "description": "Triggers when a new file is created in the selected folder",
            "label": "New File",
            "required": ["item_id"],
        },
        "updated_file": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select a SharePoint site or folder to monitor for updated files",
                    "label": "File location",
                    "placeholder": "contoso.sharepoint.com,12345678-775f-4238-xyza-1234568,qwer2345-845b-abcd-b69d-12345678",
                    "agent_field_type": "static",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&is_trigger=true&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the updated file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the updated file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "size",
                    "type": "int64",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "created_time",
                    "type": "timestamp",
                    "helper_text": "When the file was created",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "When the file was last modified",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Link to view the file in browser",
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "helper_text": "ID of the parent folder",
                },
                {
                    "field": "modified_by_email",
                    "type": "string",
                    "helper_text": "Email of the user who last modified the file",
                },
                {
                    "field": "modified_by_name",
                    "type": "string",
                    "helper_text": "Name of the user who last modified the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete file data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_file_trigger_nodes",
            "name": "updated_file",
            "task_name": "tasks.sharepoint.file_updated",
            "description": "Triggers when a file in the selected folder is updated",
            "label": "Updated File",
            "required": ["item_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
    ]

    _REQUIRED_FIELDS = ["item_id", "event", "trigger_enabled", "integration"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_sharepoint",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerSharepointNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
