"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_gitlab")
class IntegrationGitlabNode(Node):
    """
    Gitlab

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'create_issue'
        assignee_ids: Comma-separated list of assignee ids
        description: A short project description (max 500 characters)
        due_date: Due date in YYYY-MM-DD format
        labels: Comma-separated list of labels
        project_name: Name of the project
        project_owner: Project owner username
        title: Title of the issue
    ### When action = 'edit_issue'
        assignee_ids: Comma-separated list of assignee ids
        due_date: Due date in YYYY-MM-DD format
        issue_body: New body/description for the issue (supports Markdown)
        issue_number: The issue number (IID) to comment on
        labels: Comma-separated list of labels
        project_name: Name of the project
        project_owner: Project owner username
        state: Filter issues by state
        title: Title of the issue
    ### When action = 'create_file'
        author_email: Email of the author
        author_name: Name of the author
        branch: Branch to create the file on
        commit_message: Commit message for the file creation
        committer_email: Email of the committer
        committer_name: Name of the committer
        encoding: Upload as text format or base64
        file: Please upload file
        file_path: Path where the file will be created
        project_name: Name of the project
        project_owner: Project owner username
    ### When action = 'edit_file'
        author_email: Email of the author
        author_name: Name of the author
        branch: Branch to create the file on
        commit_message: Commit message for the file creation
        encoding: Upload as text format or base64
        file: Please upload file
        file_path: Path where the file will be created
        project_name: Name of the project
        project_owner: Project owner username
        start_branch: The base branch to start the commit from, useful for creating a new branch
    ### When action = 'delete_file'
        author_email: Email of the author
        author_name: Name of the author
        branch: Branch to create the file on
        commit_message: Commit message for the file creation
        encoding: Upload as text format or base64
        file_path: Path where the file will be created
        project_name: Name of the project
        project_owner: Project owner username
        start_branch: The base branch to start the commit from, useful for creating a new branch
    ### When action = 'create_comment'
        body: The comment body text
        issue_number: The issue number (IID) to comment on
        project_name: Name of the project
        project_owner: Project owner username
    ### When action = 'list_issues'
        creator_username: Filter issues by creator username
        issue_assignee_username: Filter issues by assignee username
        labels: Comma-separated list of labels
        order_by: Field to sort results by
        project_name: Name of the project
        project_owner: Project owner username
        return_all: Whether to return all files (ignores limit)
        search: Filter issues by title or description matching the search term
        sort: Order of sorting (asc for ascending, desc for descending)
        state: Filter issues by state
        updated_after: Filter issues updated after a specific date/time (ISO 8601 format)
    ### When action = 'create_repository'
        description: A short project description (max 500 characters)
        namespace_id: The ID of the group or user namespace where the project should be created. If not specified, it defaults to the authenticated user's personal namespace
        path: Project slug (the URL path). If not provided, it's generated from the name
        repository_name: Project name
        visibility: Visibility level of the project. Can be public, internal, or private. Default is private
    ### When action = 'create_release'
        description: A short project description (max 500 characters)
        name: The release title. If omitted, it defaults to the Tag name.
        project_name: Name of the project
        project_owner: Project owner username
        ref: Branch, tag, or commit SHA to read from, default is main
        tag_name: The name of the Git tag this release will be created for (e.g., v1.2.3). This tag must exist in the repository or be created beforehand.
    ### When action = 'update_release'
        description: A short project description (max 500 characters)
        milestones: Comma-separated list of milestone titles assigned to the release
        name: The release title. If omitted, it defaults to the Tag name.
        project_name: Name of the project
        project_owner: Project owner username
        release_project_id: The project ID (optional, can be used instead of project_owner and project_name)
        released_at: Date and time the release was made, in ISO 8601 format (e.g., 2025-11-19T10:00:00Z)
        tag_name: The name of the Git tag this release will be created for (e.g., v1.2.3). This tag must exist in the repository or be created beforehand.
    ### When action = 'get_file'
        file_path: Path where the file will be created
        project_name: Name of the project
        project_owner: Project owner username
        ref: Branch, tag, or commit SHA to read from, default is main
    ### When action = 'get_issue'
        issue_number: The issue number (IID) to comment on
        project_name: Name of the project
        project_owner: Project owner username
    ### When action = 'lock_issue'
        issue_number: The issue number (IID) to comment on
        lock_reason: Optional message recorded before locking the issue
        project_name: Name of the project
        project_owner: Project owner username
    ### When action = 'list_files' and return_all = False
        limit: Maximum number of files to return (used only if Return All is OFF)
        page: Page of results to display
    ### When action = 'list_releases' and return_all = False
        limit: Maximum number of files to return (used only if Return All is OFF)
    ### When action = 'list_issues' and return_all = False
        limit: Maximum number of files to return (used only if Return All is OFF)
    ### When action = 'list_files'
        list_file_path: The path to list files in the repository (required)
        project_name: Name of the project
        project_owner: Project owner username
        ref: Branch, tag, or commit SHA to read from, default is main
        return_all: Whether to return all files (ignores limit)
    ### When action = 'list_releases'
        order_by: Field to sort results by
        project_id: The project ID (optional, can be used instead of project_owner and project_name)
        project_name: Name of the project
        project_owner: Project owner username
        return_all: Whether to return all files (ignores limit)
        sort: Order of sorting (asc for ascending, desc for descending)
    ### When action = 'get_release'
        project_id: The project ID (optional, can be used instead of project_owner and project_name)
        project_name: Name of the project
        project_owner: Project owner username
        tag_name: The name of the Git tag this release will be created for (e.g., v1.2.3). This tag must exist in the repository or be created beforehand.
    ### When action = 'get_repository'
        project_name: Name of the project
        project_owner: Project owner username
    ### When action = 'get_user_repositories'
        project_owner: Project owner username

    ## Outputs
    ### When action = 'get_repository'
        allow_pipeline_trigger_approve_deployment: Whether to allow pipeline trigger approve deployment
        approvals_before_merge: Number of approvals required before merge
        archived: Whether the repository is archived
        auto_duo_code_review_enabled: Whether auto Duo code review is enabled
        autoclose_referenced_issues: Whether to autoclose referenced issues
        clone_url: Clone URL for the repository
        compliance_frameworks: List of compliance frameworks
        created_at: Creation timestamp of the repository
        default_branch: Default branch of the repository
        description: Description of the repository
        duo_foundational_flows_enabled: Whether Duo foundational flows are enabled
        duo_remote_flows_enabled: Whether Duo remote flows are enabled
        empty_repo: Whether the repository is empty
        enforce_auth_checks_on_uploads: Whether to enforce auth checks on uploads
        expires_at: Expiration date of the project
        external_authorization_classification_label: External authorization classification label
        forks_count: Number of forks of the repository
        group_full_path: Full path of the group
        group_id: ID of the group
        has_issues: Whether the repository has issues enabled
        has_projects: Whether the repository has projects enabled
        has_wiki: Whether the repository has wiki enabled
        is_fork: Whether the repository is a fork
        issue_branch_template: Issue branch name template
        issues_template: Default issues template
        language: Primary programming language of the repository
        max_artifacts_size: Maximum artifacts size in bytes
        merge_commit_template: Merge commit message template
        merge_method: Merge method for merge requests
        merge_pipelines_enabled: Whether merge pipelines are enabled
        merge_request_title_regex: Regex pattern for merge request titles
        merge_request_title_regex_description: Description of merge request title regex
        merge_requests_template: Default merge requests template
        merge_trains_enabled: Whether merge trains are enabled
        merge_trains_skip_train_allowed: Whether skipping merge train is allowed
        mirror: Whether the repository is a mirror
        only_allow_merge_if_all_status_checks_passed: Whether to only allow merge if all status checks passed
        open_issues_count: Number of open issues in the repository
        permissions: Project permissions (project_access and group_access)
        prevent_merge_without_jira_issue: Whether to prevent merge without Jira issue
        printing_merge_request_link_enabled: Whether printing merge request link is enabled
        public_jobs: Whether public jobs are enabled
        raw_data: Raw API response data
        remove_source_branch_after_merge: Whether to remove source branch after merge
        repository_full_name: Full name of the repository (namespace/repo)
        repository_id: ID of the repository
        repository_name: Name of the repository
        repository_url: URL of the repository
        requirements_access_level: Requirements access level
        requirements_enabled: Whether requirements are enabled
        security_and_compliance_enabled: Whether security and compliance is enabled
        shared_runners_enabled: Whether shared runners are enabled
        spp_repository_pipeline_access: Whether SPP repository pipeline access is enabled
        squash_commit_template: Squash commit message template
        squash_option: Squash option for merge requests
        ssh_url: SSH URL for the repository
        stargazers_count: Number of stars on the repository
        suggestion_commit_message: Suggestion commit message template
        updated_at: Last activity timestamp of the repository
        visibility: Visibility level of the repository (public, internal, or private)
        warn_about_potentially_unwanted_characters: Whether to warn about potentially unwanted characters
        watchers_count: Number of watchers on the repository
    ### When action = 'create_release'
        assets_count: Number of assets in the release
        assets_links: List of asset links
        assets_sources: List of asset sources
        author: Author details of the release
        commit_path: Path to the commit in GitLab
        created_at: Creation timestamp of the release
        description: Description of the release
        links: Related links for the release
        milestones: List of milestones associated with the release
        raw_data: Raw API response data
        release_name: Name of the release
        release_url: URL of the release in GitLab
        released_at: Release timestamp
        tag_name: Tag name of the release
        tag_path: Path to the tag in GitLab
    ### When action = 'get_release'
        assets_count: Number of assets in the release
        assets_links: List of asset links
        assets_sources: List of asset sources
        author: Author details of the release
        commit_path: Path to the commit in GitLab
        created_at: Creation timestamp of the release
        description: Description of the release
        links: Related links for the release
        milestones: List of milestones associated with the release
        raw_data: Raw API response data
        release_name: Name of the release
        release_url: URL of the release in GitLab
        released_at: Release timestamp
        tag_name: Tag name of the release
        tag_path: Path to the tag in GitLab
    ### When action = 'update_release'
        assets_count: Number of assets in the release
        assets_links: List of asset links
        assets_sources: List of asset sources
        author: Author details of the release
        commit_path: Path to the commit in GitLab
        created_at: Creation timestamp of the release
        description: Description of the release
        links: Related links for the release
        milestones: List of milestones associated with the release
        raw_data: Raw API response data
        release_name: Name of the release
        release_url: URL of the release in GitLab
        released_at: Release timestamp
        tag_name: Tag name of the release
        tag_path: Path to the tag in GitLab
    ### When action = 'create_issue'
        assignees: List of assignee usernames
        author: Author details
        confidential: Whether the issue is confidential
        created_at: Creation timestamp
        description: Description of the issue
        due_date: Due date of the issue
        has_tasks: Whether the issue has tasks
        imported: Whether the issue was imported
        issue_id: ID of the created issue
        issue_iid: Internal issue ID within the project
        issue_number: Issue number (IID)
        issue_state: State of the issue
        issue_title: Title of the issue
        issue_type: Type of the issue
        issue_url: URL of the issue
        labels: List of labels
        links: Issue links in JSON format
        raw_data: Raw API response data
        references: Issue references in JSON format
        subscribed: Whether the user is subscribed to the issue
        task_completion_status: Task completion status in JSON format
        time_stats: Time tracking statistics in JSON format
        updated_at: Last update timestamp
        web_url: Web URL of the issue
    ### When action = 'get_issue'
        assignees: List of assignees
        author: Author details
        created_at: Creation timestamp
        description: Description of the issue
        due_date: Due date of the issue
        issue_id: ID of the issue
        issue_iid: Internal issue ID within the project
        issue_number: Issue number (IID)
        issue_state: State of the issue
        issue_title: Title of the issue
        issue_url: URL of the issue
        labels: List of labels
        raw_data: Raw API response data
        updated_at: Last update timestamp
    ### When action = 'edit_issue'
        assignees: List of assignee usernames
        author: Author details
        confidential: Whether the issue is confidential
        created_at: Creation timestamp
        description: Description of the issue
        due_date: Due date of the issue
        evidences: Evidences in JSON format
        has_tasks: Whether the issue has tasks
        imported: Whether the issue was imported
        issue_id: ID of the edited issue
        issue_iid: Internal issue ID within the project
        issue_number: Issue number (IID)
        issue_state: State of the issue
        issue_title: Title of the issue
        issue_type: Type of the issue
        issue_url: URL of the issue
        labels: List of labels
        links: Issue links in JSON format
        raw_data: Raw API response data
        references: Issue references in JSON format
        sources: Sources in JSON format
        subscribed: Whether the user is subscribed to the issue
        task_completion_status: Task completion status in JSON format
        time_stats: Time tracking statistics in JSON format
        updated_at: Last update timestamp
        web_url: Web URL of the issue
    ### When action = 'lock_issue'
        assignees: List of assignees
        author: Author details
        created_at: Creation timestamp
        description: Description of the issue
        due_date: Due date of the issue
        evidences: Evidences in JSON format
        issue_id: ID of the locked issue
        issue_iid: Internal issue ID within the project
        issue_number: Issue number (IID)
        issue_state: State of the issue
        issue_title: Title of the issue
        issue_url: URL of the issue
        labels: List of labels
        links: Issue links in JSON format (includes closed_issues_url, closed_merge_requests_url, edit_url, merged_merge_requests_url, opened_issues_url, opened_merge_requests_url, self)
        raw_data: Raw API response data
        sources: Sources in JSON format
        updated_at: Last update timestamp
    ### When action = 'create_comment'
        author: Author details of the comment in JSON format
        body: Body text of the comment
        comment_id: ID of the created comment
        comment_url: URL of the comment in GitLab
        confidential: Whether the comment is confidential
        created_at: Creation timestamp of the comment
        id: ID of the comment
        imported: Whether the comment was imported
        internal: Whether the comment is internal
        issue_number: Issue number the comment was added to
        noteable_id: ID of the noteable item (issue, merge request, etc.)
        noteable_iid: Internal ID of the noteable item within the project
        noteable_type: Type of the noteable item (e.g., Issue)
        project_id: ID of the project
        resolvable: Whether the comment is resolvable
        updated_at: Last update timestamp of the comment
        web_url: Web URL of the noteable item
    ### When action = 'edit_file'
        body: Commit message/body
        commands_changes: Command changes in JSON format
        file_path: Path of the edited file
        file_url: URL of the edited file
        noteable_id: ID of the noteable item (file/blob)
        noteable_iid: Internal ID of the noteable item
        noteable_type: Type of the noteable item (e.g., File)
        project_id: ID of the project
        raw_data: Raw API response data
    ### When action = 'create_repository'
        clone_url: Clone URL for the repository
        default_branch: Default branch of the repository
        raw_data: Raw API response data
        repository_id: ID of the created repository
        repository_name: Name of the created repository
        repository_url: URL of the repository
        ssh_url: SSH URL for the repository
        visibility: Visibility level of the repository (public, internal, or private)
    ### When action = 'delete_file'
        commit_message: Message of the commit
        file_path: Path of the deleted file
        raw_data: Raw API response data
    ### When action = 'create_file'
        commit_sha: SHA of the commit
        file_path: Path of the created file
        file_url: URL of the created file
        raw_data: Raw API response data
    ### When action = 'get_file'
        commit_sha: SHA of the commit
        encoding: Encoding of the file
        file: Content file from gitlab
        file_name: Name of the file
        file_path: Path of the file
        file_sha: SHA (blob ID) of the file
        file_url: URL of the file in GitLab
        raw_data: Raw API response data
        ref: Branch, tag, or commit reference
    ### When action = 'get_user_repositories'
        count: Total number of repositories returned
        raw_data: Raw API response data
        repo_names: List of repository names
    ### When action = 'list_releases'
        count: Total number of releases returned
        raw_data: Raw API response data
        release_names: List of release names
        tag_names: List of tag names
    ### When action = 'list_issues'
        count: Total number of issues returned
        issue_numbers: List of issue numbers (IID)
        issue_titles: List of issue titles
        raw_data: Raw API response data
    ### When action = 'list_files'
        file_ids: Array of file IDs
        file_modes: Array of file modes
        file_names: Array of file names
        file_paths: Array of file paths
        file_types: Array of file types (blob or tree)
        raw_data: Raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Gitlab>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_repository**(*)": {
            "inputs": [
                {
                    "field": "repository_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project name",
                    "label": "Project Name",
                    "placeholder": "my-awesome-project",
                },
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project slug (the URL path). If not provided, it's generated from the name",
                    "label": "Project Path",
                    "placeholder": "my-awesome-project",
                },
                {
                    "field": "namespace_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the group or user namespace where the project should be created. If not specified, it defaults to the authenticated user's personal namespace",
                    "label": "Namespace ID",
                    "placeholder": "123",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "A short project description (max 500 characters)",
                    "label": "Description",
                    "placeholder": "This is an awesome project",
                },
                {
                    "field": "visibility",
                    "type": "string",
                    "value": "private",
                    "helper_text": "Visibility level of the project. Can be public, internal, or private. Default is private",
                    "label": "Visibility",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Public", "value": "public"},
                            {"label": "Internal", "value": "internal"},
                            {"label": "Private", "value": "private"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "repository_id",
                    "type": "string",
                    "helper_text": "ID of the created repository",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Name of the created repository",
                },
                {
                    "field": "repository_url",
                    "type": "string",
                    "helper_text": "URL of the repository",
                },
                {
                    "field": "clone_url",
                    "type": "string",
                    "helper_text": "Clone URL for the repository",
                },
                {
                    "field": "ssh_url",
                    "type": "string",
                    "helper_text": "SSH URL for the repository",
                },
                {
                    "field": "visibility",
                    "type": "string",
                    "helper_text": "Visibility level of the repository (public, internal, or private)",
                },
                {
                    "field": "default_branch",
                    "type": "string",
                    "helper_text": "Default branch of the repository",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_repository",
            "task_name": "tasks.gitlab.create_repository",
            "description": "Create a new repository on GitLab",
            "label": "Create Repository",
            "required": ["repository_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "repository_name",
                "path",
                "namespace_id",
                "description",
                "visibility",
            ],
        },
        "get_repository**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "repository_id",
                    "type": "string",
                    "helper_text": "ID of the repository",
                },
                {
                    "field": "repository_name",
                    "type": "string",
                    "helper_text": "Name of the repository",
                },
                {
                    "field": "repository_full_name",
                    "type": "string",
                    "helper_text": "Full name of the repository (namespace/repo)",
                },
                {
                    "field": "repository_url",
                    "type": "string",
                    "helper_text": "URL of the repository",
                },
                {
                    "field": "clone_url",
                    "type": "string",
                    "helper_text": "Clone URL for the repository",
                },
                {
                    "field": "ssh_url",
                    "type": "string",
                    "helper_text": "SSH URL for the repository",
                },
                {
                    "field": "visibility",
                    "type": "string",
                    "helper_text": "Visibility level of the repository (public, internal, or private)",
                },
                {
                    "field": "default_branch",
                    "type": "string",
                    "helper_text": "Default branch of the repository",
                },
                {
                    "field": "language",
                    "type": "string",
                    "helper_text": "Primary programming language of the repository",
                },
                {
                    "field": "stargazers_count",
                    "type": "int32",
                    "helper_text": "Number of stars on the repository",
                },
                {
                    "field": "watchers_count",
                    "type": "int32",
                    "helper_text": "Number of watchers on the repository",
                },
                {
                    "field": "forks_count",
                    "type": "int32",
                    "helper_text": "Number of forks of the repository",
                },
                {
                    "field": "open_issues_count",
                    "type": "int32",
                    "helper_text": "Number of open issues in the repository",
                },
                {
                    "field": "has_issues",
                    "type": "bool",
                    "helper_text": "Whether the repository has issues enabled",
                },
                {
                    "field": "has_projects",
                    "type": "bool",
                    "helper_text": "Whether the repository has projects enabled",
                },
                {
                    "field": "has_wiki",
                    "type": "bool",
                    "helper_text": "Whether the repository has wiki enabled",
                },
                {
                    "field": "is_fork",
                    "type": "bool",
                    "helper_text": "Whether the repository is a fork",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the repository",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the repository",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last activity timestamp of the repository",
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "helper_text": "Whether the repository is archived",
                },
                {
                    "field": "empty_repo",
                    "type": "bool",
                    "helper_text": "Whether the repository is empty",
                },
                {
                    "field": "public_jobs",
                    "type": "bool",
                    "helper_text": "Whether public jobs are enabled",
                },
                {
                    "field": "shared_runners_enabled",
                    "type": "bool",
                    "helper_text": "Whether shared runners are enabled",
                },
                {
                    "field": "group_full_path",
                    "type": "string",
                    "helper_text": "Full path of the group",
                },
                {
                    "field": "group_id",
                    "type": "int32",
                    "helper_text": "ID of the group",
                },
                {
                    "field": "expires_at",
                    "type": "string",
                    "helper_text": "Expiration date of the project",
                },
                {
                    "field": "printing_merge_request_link_enabled",
                    "type": "bool",
                    "helper_text": "Whether printing merge request link is enabled",
                },
                {
                    "field": "merge_method",
                    "type": "string",
                    "helper_text": "Merge method for merge requests",
                },
                {
                    "field": "remove_source_branch_after_merge",
                    "type": "bool",
                    "helper_text": "Whether to remove source branch after merge",
                },
                {
                    "field": "merge_request_title_regex",
                    "type": "string",
                    "helper_text": "Regex pattern for merge request titles",
                },
                {
                    "field": "merge_request_title_regex_description",
                    "type": "string",
                    "helper_text": "Description of merge request title regex",
                },
                {
                    "field": "squash_option",
                    "type": "string",
                    "helper_text": "Squash option for merge requests",
                },
                {
                    "field": "enforce_auth_checks_on_uploads",
                    "type": "bool",
                    "helper_text": "Whether to enforce auth checks on uploads",
                },
                {
                    "field": "suggestion_commit_message",
                    "type": "string",
                    "helper_text": "Suggestion commit message template",
                },
                {
                    "field": "merge_commit_template",
                    "type": "string",
                    "helper_text": "Merge commit message template",
                },
                {
                    "field": "squash_commit_template",
                    "type": "string",
                    "helper_text": "Squash commit message template",
                },
                {
                    "field": "issue_branch_template",
                    "type": "string",
                    "helper_text": "Issue branch name template",
                },
                {
                    "field": "warn_about_potentially_unwanted_characters",
                    "type": "bool",
                    "helper_text": "Whether to warn about potentially unwanted characters",
                },
                {
                    "field": "autoclose_referenced_issues",
                    "type": "bool",
                    "helper_text": "Whether to autoclose referenced issues",
                },
                {
                    "field": "max_artifacts_size",
                    "type": "int32",
                    "helper_text": "Maximum artifacts size in bytes",
                },
                {
                    "field": "approvals_before_merge",
                    "type": "int32",
                    "helper_text": "Number of approvals required before merge",
                },
                {
                    "field": "mirror",
                    "type": "bool",
                    "helper_text": "Whether the repository is a mirror",
                },
                {
                    "field": "external_authorization_classification_label",
                    "type": "string",
                    "helper_text": "External authorization classification label",
                },
                {
                    "field": "requirements_enabled",
                    "type": "bool",
                    "helper_text": "Whether requirements are enabled",
                },
                {
                    "field": "requirements_access_level",
                    "type": "string",
                    "helper_text": "Requirements access level",
                },
                {
                    "field": "security_and_compliance_enabled",
                    "type": "bool",
                    "helper_text": "Whether security and compliance is enabled",
                },
                {
                    "field": "compliance_frameworks",
                    "type": "vec<string>",
                    "helper_text": "List of compliance frameworks",
                },
                {
                    "field": "issues_template",
                    "type": "string",
                    "helper_text": "Default issues template",
                },
                {
                    "field": "merge_requests_template",
                    "type": "string",
                    "helper_text": "Default merge requests template",
                },
                {
                    "field": "merge_pipelines_enabled",
                    "type": "bool",
                    "helper_text": "Whether merge pipelines are enabled",
                },
                {
                    "field": "merge_trains_enabled",
                    "type": "bool",
                    "helper_text": "Whether merge trains are enabled",
                },
                {
                    "field": "merge_trains_skip_train_allowed",
                    "type": "bool",
                    "helper_text": "Whether skipping merge train is allowed",
                },
                {
                    "field": "only_allow_merge_if_all_status_checks_passed",
                    "type": "bool",
                    "helper_text": "Whether to only allow merge if all status checks passed",
                },
                {
                    "field": "allow_pipeline_trigger_approve_deployment",
                    "type": "bool",
                    "helper_text": "Whether to allow pipeline trigger approve deployment",
                },
                {
                    "field": "prevent_merge_without_jira_issue",
                    "type": "bool",
                    "helper_text": "Whether to prevent merge without Jira issue",
                },
                {
                    "field": "auto_duo_code_review_enabled",
                    "type": "bool",
                    "helper_text": "Whether auto Duo code review is enabled",
                },
                {
                    "field": "duo_remote_flows_enabled",
                    "type": "bool",
                    "helper_text": "Whether Duo remote flows are enabled",
                },
                {
                    "field": "duo_foundational_flows_enabled",
                    "type": "bool",
                    "helper_text": "Whether Duo foundational flows are enabled",
                },
                {
                    "field": "spp_repository_pipeline_access",
                    "type": "bool",
                    "helper_text": "Whether SPP repository pipeline access is enabled",
                },
                {
                    "field": "permissions",
                    "type": "string",
                    "helper_text": "Project permissions (project_access and group_access)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_repository",
            "task_name": "tasks.gitlab.get_repository",
            "description": "Get a repository from GitLab",
            "label": "Get a repository",
            "required": ["project_owner", "project_name"],
            "ui_sort_order": ["integration", "action", "project_owner", "project_name"],
        },
        "get_user_repositories**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Gitlab's user username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of repositories returned",
                },
                {
                    "field": "repo_names",
                    "type": "vec<string>",
                    "helper_text": "List of repository names",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_user_repositories",
            "task_name": "tasks.gitlab.get_user_repositories",
            "description": "Lists all projects (repositories) owned by the specified user",
            "label": "Get a user's repositories",
            "required": ["project_owner"],
            "ui_sort_order": ["integration", "action", "project_owner"],
        },
        "create_file**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path where the file will be created",
                    "label": "File Path",
                    "placeholder": "docs/README.md",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "Please upload file",
                    "label": "File",
                    "placeholder": "",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "Commit message for the file creation",
                    "label": "Commit Message",
                    "placeholder": "",
                },
                {
                    "field": "branch",
                    "type": "string",
                    "value": "main",
                    "helper_text": "Branch to create the file on",
                    "label": "Branch",
                    "placeholder": "main",
                },
                {
                    "field": "committer_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the committer",
                    "label": "Committer Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "committer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the committer",
                    "label": "Committer Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the author",
                    "label": "Author Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "author_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the author",
                    "label": "Author Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "encoding",
                    "type": "string",
                    "value": "text",
                    "helper_text": "Upload as text format or base64",
                    "label": "Encoding",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "Base64", "value": "base64"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the created file",
                },
                {
                    "field": "commit_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the created file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_file",
            "task_name": "tasks.gitlab.create_file",
            "description": "Create a new file in a GitLab repository",
            "label": "Create File",
            "required": [
                "project_owner",
                "project_name",
                "file_path",
                "file",
                "commit_message",
            ],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "file_path",
                "file",
                "commit_message",
                "branch",
                "committer_name",
                "committer_email",
                "author_name",
                "author_email",
                "encoding",
            ],
        },
        "get_file**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the file to read",
                    "label": "File Path",
                    "placeholder": "docs/README.md",
                },
                {
                    "field": "ref",
                    "type": "string",
                    "value": "main",
                    "helper_text": "Branch, tag, or commit SHA to read from, default is main",
                    "label": "Reference",
                    "placeholder": "main",
                },
            ],
            "outputs": [
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the file",
                },
                {
                    "field": "file_sha",
                    "type": "string",
                    "helper_text": "SHA (blob ID) of the file",
                },
                {
                    "field": "commit_sha",
                    "type": "string",
                    "helper_text": "SHA of the commit",
                },
                {
                    "field": "ref",
                    "type": "string",
                    "helper_text": "Branch, tag, or commit reference",
                },
                {
                    "field": "encoding",
                    "type": "string",
                    "helper_text": "Encoding of the file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the file in GitLab",
                },
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "Content file from gitlab",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_file",
            "task_name": "tasks.gitlab.get_file",
            "description": "Get a file from a GitLab repository",
            "label": "Get File",
            "required": ["project_owner", "project_name", "file_path"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "file_path",
                "ref",
            ],
        },
        "list_files**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "list_file_path",
                    "type": "string",
                    "value": "",
                    "label": "File Path",
                    "placeholder": "docs/README.md",
                    "helper_text": "The path to list files in the repository (required)",
                },
                {
                    "field": "ref",
                    "type": "string",
                    "value": "",
                    "label": "Reference",
                    "placeholder": "main",
                    "helper_text": "The name of a repository branch, tag or commit. Defaults to main.",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all files (ignores limit)",
                },
            ],
            "outputs": [
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of file IDs",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Array of file names",
                },
                {
                    "field": "file_types",
                    "type": "vec<string>",
                    "helper_text": "Array of file types (blob or tree)",
                },
                {
                    "field": "file_paths",
                    "type": "vec<string>",
                    "helper_text": "Array of file paths",
                },
                {
                    "field": "file_modes",
                    "type": "vec<string>",
                    "helper_text": "Array of file modes",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_files",
            "task_name": "tasks.gitlab.list_files",
            "description": "Lists files in a repository directory",
            "label": "List files",
            "required": ["project_owner", "project_name", "list_file_path"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "list_file_path",
                "ref",
                "return_all",
                "limit",
                "page",
            ],
        },
        "list_files**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of files to return (used only if Return All is OFF)",
                },
                {
                    "field": "page",
                    "type": "int32",
                    "value": 1,
                    "label": "Page",
                    "placeholder": "1",
                    "helper_text": "Page of results to display",
                },
            ],
            "outputs": [],
        },
        "edit_file**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Path of the file to edit",
                    "label": "File Path",
                    "placeholder": "docs/README.md",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "Please upload file",
                    "label": "File",
                    "placeholder": "",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "Commit message for the file edit",
                    "label": "Commit Message",
                    "placeholder": "",
                },
                {
                    "field": "branch",
                    "type": "string",
                    "value": "main",
                    "helper_text": "Branch to edit the file on",
                    "label": "Branch",
                    "placeholder": "main",
                },
                {
                    "field": "start_branch",
                    "type": "string",
                    "value": "",
                    "helper_text": "The base branch to start the commit from, useful for creating a new branch",
                    "label": "Start Branch",
                    "placeholder": "main",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the commit author (overrides default author)",
                    "label": "Author Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "author_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the commit author (overrides default author)",
                    "label": "Author Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "encoding",
                    "type": "string",
                    "value": "text",
                    "helper_text": "Upload as text format or base64",
                    "label": "Encoding",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "Base64", "value": "base64"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the edited file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "URL of the edited file",
                },
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "Commit message/body",
                },
                {
                    "field": "noteable_id",
                    "type": "int32",
                    "helper_text": "ID of the noteable item (file/blob)",
                },
                {
                    "field": "noteable_type",
                    "type": "string",
                    "helper_text": "Type of the noteable item (e.g., File)",
                },
                {
                    "field": "project_id",
                    "type": "int32",
                    "helper_text": "ID of the project",
                },
                {
                    "field": "noteable_iid",
                    "type": "int32",
                    "helper_text": "Internal ID of the noteable item",
                },
                {
                    "field": "commands_changes",
                    "type": "string",
                    "helper_text": "Command changes in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "edit_file",
            "task_name": "tasks.gitlab.edit_file",
            "description": "Edit an existing file in a GitLab repository",
            "label": "Edit a file",
            "required": [
                "project_owner",
                "project_name",
                "file_path",
                "file",
                "commit_message",
                "branch",
            ],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "file_path",
                "file",
                "commit_message",
                "branch",
                "start_branch",
                "author_name",
                "author_email",
                "encoding",
            ],
        },
        "delete_file**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "The exact path to the file in the repository (e.g., docs/README.md).",
                    "label": "File Path",
                    "placeholder": "docs/README.md",
                },
                {
                    "field": "commit_message",
                    "type": "string",
                    "value": "",
                    "helper_text": "The message for the Git commit that performs the deletion.",
                    "label": "Commit Message",
                    "placeholder": "Delete file",
                },
                {
                    "field": "branch",
                    "type": "string",
                    "value": "main",
                    "helper_text": "The target branch where the file will be deleted.",
                    "label": "Branch",
                    "placeholder": "main",
                },
                {
                    "field": "start_branch",
                    "type": "string",
                    "value": "",
                    "helper_text": "The base branch to start the commit from, useful for complex branching.",
                    "label": "Start Branch",
                    "placeholder": "main",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the commit author (overrides default author)",
                    "label": "Author Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "author_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email of the commit author (overrides default author)",
                    "label": "Author Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "encoding",
                    "type": "string",
                    "value": "text",
                    "helper_text": "File encoding setting (rarely needed for deletion).",
                    "label": "Encoding",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "Base64", "value": "base64"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "commit_message",
                    "type": "string",
                    "helper_text": "Message of the commit",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the deleted file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_file",
            "task_name": "tasks.gitlab.delete_file",
            "description": "Delete a file from a GitLab repository",
            "label": "Delete File",
            "required": [
                "project_owner",
                "project_name",
                "file_path",
                "commit_message",
                "branch",
            ],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "file_path",
                "commit_message",
                "branch",
                "start_branch",
                "author_name",
                "author_email",
                "encoding",
            ],
        },
        "create_release**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "The name of the Git tag this release will be created for (e.g., v1.2.3). This tag must exist in the repository or be created beforehand.",
                    "label": "Tag",
                    "placeholder": "v1.2.3",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "The release title. If omitted, it defaults to the Tag name.",
                    "label": "Name",
                    "placeholder": "Release v1.2.3",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "The release notes, supporting Markdown formatting. This is the main body of the release.",
                    "label": "Description",
                    "placeholder": "## What's Changed\n\n* Feature X\n* Bug fix Y",
                },
                {
                    "field": "ref",
                    "type": "string",
                    "value": "main",
                    "helper_text": "The branch name (e.g., main), commit SHA, or another tag that the Tag should point to. Only required if the tag does not already exist.",
                    "label": "Ref",
                    "placeholder": "main",
                },
            ],
            "outputs": [
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the release",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "Name of the release",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the release",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the release",
                },
                {
                    "field": "released_at",
                    "type": "timestamp",
                    "helper_text": "Release timestamp",
                },
                {
                    "field": "release_url",
                    "type": "string",
                    "helper_text": "URL of the release in GitLab",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author details of the release",
                },
                {
                    "field": "milestones",
                    "type": "vec<string>",
                    "helper_text": "List of milestones associated with the release",
                },
                {
                    "field": "commit_path",
                    "type": "string",
                    "helper_text": "Path to the commit in GitLab",
                },
                {
                    "field": "tag_path",
                    "type": "string",
                    "helper_text": "Path to the tag in GitLab",
                },
                {
                    "field": "assets_count",
                    "type": "int32",
                    "helper_text": "Number of assets in the release",
                },
                {
                    "field": "assets_links",
                    "type": "vec<string>",
                    "helper_text": "List of asset links",
                },
                {
                    "field": "assets_sources",
                    "type": "vec<string>",
                    "helper_text": "List of asset sources",
                },
                {
                    "field": "links",
                    "type": "string",
                    "helper_text": "Related links for the release",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_release",
            "task_name": "tasks.gitlab.create_release",
            "description": "Creates a new release object tied to a specific Git tag",
            "label": "Create a release",
            "required": ["project_owner", "project_name", "tag_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "tag_name",
                "name",
                "description",
                "ref",
            ],
        },
        "get_release**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The project ID (optional, can be used instead of project_owner and project_name)",
                    "label": "Project ID",
                    "placeholder": "",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "The tag name of the release to retrieve",
                    "label": "Tag Name",
                    "placeholder": "v1.0.0",
                },
            ],
            "outputs": [
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the release",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "Name of the release",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the release",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the release",
                },
                {
                    "field": "released_at",
                    "type": "timestamp",
                    "helper_text": "Release timestamp",
                },
                {
                    "field": "release_url",
                    "type": "string",
                    "helper_text": "URL of the release in GitLab",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author details of the release",
                },
                {
                    "field": "milestones",
                    "type": "vec<string>",
                    "helper_text": "List of milestones associated with the release",
                },
                {
                    "field": "commit_path",
                    "type": "string",
                    "helper_text": "Path to the commit in GitLab",
                },
                {
                    "field": "tag_path",
                    "type": "string",
                    "helper_text": "Path to the tag in GitLab",
                },
                {
                    "field": "assets_count",
                    "type": "int32",
                    "helper_text": "Number of assets in the release",
                },
                {
                    "field": "assets_links",
                    "type": "vec<string>",
                    "helper_text": "List of asset links",
                },
                {
                    "field": "assets_sources",
                    "type": "vec<string>",
                    "helper_text": "List of asset sources",
                },
                {
                    "field": "links",
                    "type": "string",
                    "helper_text": "Related links for the release",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_release",
            "task_name": "tasks.gitlab.get_release",
            "description": "Get a release from a GitLab project",
            "label": "Get a release",
            "required": ["project_owner", "project_name", "tag_name", "project_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "project_id",
                "tag_name",
            ],
        },
        "list_releases**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The project ID (optional, can be used instead of project_owner and project_name)",
                    "label": "Project ID",
                    "placeholder": "",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all releases (ignores limit)",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "placeholder": "created_at",
                    "helper_text": "Field to sort results by",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "created_at", "label": "Created At"},
                            {"value": "released_at", "label": "Released At"},
                            {"value": "name", "label": "Name"},
                        ],
                    },
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "",
                    "label": "Sort",
                    "placeholder": "desc",
                    "helper_text": "Order of sorting (asc for ascending, desc for descending)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "asc", "label": "Ascending"},
                            {"value": "desc", "label": "Descending"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of releases returned",
                },
                {
                    "field": "release_names",
                    "type": "vec<string>",
                    "helper_text": "List of release names",
                },
                {
                    "field": "tag_names",
                    "type": "vec<string>",
                    "helper_text": "List of tag names",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_releases",
            "task_name": "tasks.gitlab.list_releases",
            "description": "Lists all releases for the specified project",
            "label": "List releases",
            "required": ["project_owner", "project_name", "project_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "project_id",
                "return_all",
                "sort",
                "limit",
            ],
        },
        "list_releases**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of releases to return (used only if Return All is OFF)",
                }
            ],
            "outputs": [],
        },
        "update_release**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "release_project_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The project ID (optional, can be used instead of project_owner and project_name)",
                    "label": "Project ID",
                    "placeholder": "",
                },
                {
                    "field": "tag_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "The name of the existing Git tag associated with the release to update",
                    "label": "Tag Name",
                    "placeholder": "v1.2.3",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New release title (if omitted, defaults to Tag Name)",
                    "label": "Name",
                    "placeholder": "Release v1.2.3",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New release notes/body for the release (supports Markdown)",
                    "label": "Description",
                    "placeholder": "Release notes...",
                },
                {
                    "field": "milestones",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of milestone titles assigned to the release",
                    "label": "Milestones",
                    "placeholder": "v1.0, v1.1",
                },
                {
                    "field": "released_at",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Date and time the release was made, in ISO 8601 format (e.g., 2025-11-19T10:00:00Z)",
                    "label": "Released At",
                    "placeholder": "2025-11-19T10:00:00Z",
                },
            ],
            "outputs": [
                {
                    "field": "tag_name",
                    "type": "string",
                    "helper_text": "Tag name of the release",
                },
                {
                    "field": "release_name",
                    "type": "string",
                    "helper_text": "Name of the release",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the release",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the release",
                },
                {
                    "field": "released_at",
                    "type": "timestamp",
                    "helper_text": "Release timestamp",
                },
                {
                    "field": "release_url",
                    "type": "string",
                    "helper_text": "URL of the release in GitLab",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author details of the release",
                },
                {
                    "field": "milestones",
                    "type": "vec<string>",
                    "helper_text": "List of milestones associated with the release",
                },
                {
                    "field": "commit_path",
                    "type": "string",
                    "helper_text": "Path to the commit in GitLab",
                },
                {
                    "field": "tag_path",
                    "type": "string",
                    "helper_text": "Path to the tag in GitLab",
                },
                {
                    "field": "assets_count",
                    "type": "int32",
                    "helper_text": "Number of assets in the release",
                },
                {
                    "field": "assets_links",
                    "type": "vec<string>",
                    "helper_text": "List of asset links",
                },
                {
                    "field": "assets_sources",
                    "type": "vec<string>",
                    "helper_text": "List of asset sources",
                },
                {
                    "field": "links",
                    "type": "string",
                    "helper_text": "Related links for the release",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_release",
            "task_name": "tasks.gitlab.update_release",
            "description": "Update an existing release in a GitLab project",
            "label": "Update a release",
            "required": [
                "project_owner",
                "project_name",
                "release_project_id",
                "tag_name",
            ],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "release_project_id",
                "tag_name",
                "name",
                "description",
                "milestones",
                "released_at",
            ],
        },
        "create_issue**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the issue",
                    "label": "Title",
                    "placeholder": "Enter issue title",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the issue (supports Markdown)",
                    "label": "Description",
                    "placeholder": "Enter issue description",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date in YYYY-MM-DD format",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of labels",
                    "label": "Labels",
                    "placeholder": "bug,enhancement",
                },
                {
                    "field": "assignee_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of assignee ids",
                    "label": "Assignees",
                    "placeholder": "id1,id2",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the created issue",
                },
                {
                    "field": "issue_iid",
                    "type": "int32",
                    "helper_text": "Internal issue ID within the project",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Issue number (IID)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignee usernames",
                },
                {"field": "author", "type": "string", "helper_text": "Author details"},
                {
                    "field": "confidential",
                    "type": "bool",
                    "helper_text": "Whether the issue is confidential",
                },
                {
                    "field": "issue_type",
                    "type": "string",
                    "helper_text": "Type of the issue",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the issue",
                },
                {
                    "field": "time_stats",
                    "type": "string",
                    "helper_text": "Time tracking statistics in JSON format",
                },
                {
                    "field": "task_completion_status",
                    "type": "string",
                    "helper_text": "Task completion status in JSON format",
                },
                {
                    "field": "has_tasks",
                    "type": "bool",
                    "helper_text": "Whether the issue has tasks",
                },
                {
                    "field": "links",
                    "type": "string",
                    "helper_text": "Issue links in JSON format",
                },
                {
                    "field": "references",
                    "type": "string",
                    "helper_text": "Issue references in JSON format",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "helper_text": "Whether the user is subscribed to the issue",
                },
                {
                    "field": "imported",
                    "type": "bool",
                    "helper_text": "Whether the issue was imported",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_issue",
            "task_name": "tasks.gitlab.create_issue",
            "description": "Create a new issue in a GitLab project",
            "label": "Create Issue",
            "required": ["project_owner", "project_name", "title"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "title",
                "description",
                "due_date",
                "labels",
                "assignee_ids",
            ],
        },
        "create_comment**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "The issue number (IID) to comment on",
                    "label": "Issue Number",
                    "placeholder": "0",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "helper_text": "The comment body text",
                    "label": "Body",
                    "placeholder": "Enter your comment here",
                },
            ],
            "outputs": [
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "ID of the created comment",
                },
                {"field": "id", "type": "int32", "helper_text": "ID of the comment"},
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "Body text of the comment",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp of the comment",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp of the comment",
                },
                {
                    "field": "comment_url",
                    "type": "string",
                    "helper_text": "URL of the comment in GitLab",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Issue number the comment was added to",
                },
                {
                    "field": "author",
                    "type": "string",
                    "helper_text": "Author details of the comment in JSON format",
                },
                {
                    "field": "noteable_id",
                    "type": "int32",
                    "helper_text": "ID of the noteable item (issue, merge request, etc.)",
                },
                {
                    "field": "noteable_type",
                    "type": "string",
                    "helper_text": "Type of the noteable item (e.g., Issue)",
                },
                {
                    "field": "project_id",
                    "type": "int32",
                    "helper_text": "ID of the project",
                },
                {
                    "field": "resolvable",
                    "type": "bool",
                    "helper_text": "Whether the comment is resolvable",
                },
                {
                    "field": "confidential",
                    "type": "bool",
                    "helper_text": "Whether the comment is confidential",
                },
                {
                    "field": "internal",
                    "type": "bool",
                    "helper_text": "Whether the comment is internal",
                },
                {
                    "field": "imported",
                    "type": "bool",
                    "helper_text": "Whether the comment was imported",
                },
                {
                    "field": "noteable_iid",
                    "type": "int32",
                    "helper_text": "Internal ID of the noteable item within the project",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the noteable item",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_comment",
            "task_name": "tasks.gitlab.create_comment",
            "description": "Creates a comment on an issue",
            "label": "Create a comment on an issue",
            "required": ["project_owner", "project_name", "issue_number", "body"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "issue_number",
                "body",
            ],
        },
        "get_issue**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "The issue number (IID) to retrieve",
                    "label": "Issue Number",
                    "placeholder": "1",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the issue",
                },
                {
                    "field": "issue_iid",
                    "type": "int32",
                    "helper_text": "Internal issue ID within the project",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Issue number (IID)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees",
                },
                {"field": "author", "type": "string", "helper_text": "Author details"},
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_issue",
            "task_name": "tasks.gitlab.get_issue",
            "description": "Get an issue from a GitLab project",
            "label": "Get an issue",
            "required": ["project_owner", "project_name", "issue_number"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "issue_number",
            ],
        },
        "list_issues**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_assignee_username",
                    "type": "string",
                    "value": "",
                    "label": "Assignee Username",
                    "placeholder": "",
                    "helper_text": "Filter issues by assignee username",
                },
                {
                    "field": "creator_username",
                    "type": "string",
                    "value": "",
                    "label": "Creator Username",
                    "placeholder": "",
                    "helper_text": "Filter issues by creator username",
                },
                {
                    "field": "search",
                    "type": "string",
                    "value": "",
                    "label": "Search",
                    "placeholder": "",
                    "helper_text": "Filter issues by title or description matching the search term",
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "label": "Labels",
                    "placeholder": "bug,enhancement",
                    "helper_text": "Filter issues that have the specified labels (comma-separated)",
                },
                {
                    "field": "updated_after",
                    "type": "timestamp",
                    "value": "",
                    "label": "Updated After",
                    "placeholder": "2024-01-01T00:00:00Z",
                    "helper_text": "Filter issues updated after a specific date/time (ISO 8601 format)",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "label": "State",
                    "placeholder": "opened",
                    "helper_text": "Filter issues by state",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "opened", "label": "Opened"},
                            {"value": "closed", "label": "Closed"},
                            {"value": "all", "label": "All"},
                        ],
                    },
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Sort",
                    "placeholder": "created_at",
                    "helper_text": "Field to sort results by",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "created_at", "label": "Created At"},
                            {"value": "updated_at", "label": "Updated At"},
                            {"value": "due_date", "label": "Due Date"},
                            {"value": "title", "label": "Title"},
                        ],
                    },
                },
                {
                    "field": "sort",
                    "type": "string",
                    "value": "",
                    "label": "Direction",
                    "placeholder": "desc",
                    "helper_text": "Order of sorting",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"value": "asc", "label": "Ascending"},
                            {"value": "desc", "label": "Descending"},
                        ],
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "Whether to return all issues (ignores limit)",
                },
            ],
            "outputs": [
                {
                    "field": "count",
                    "type": "int32",
                    "helper_text": "Total number of issues returned",
                },
                {
                    "field": "issue_titles",
                    "type": "vec<string>",
                    "helper_text": "List of issue titles",
                },
                {
                    "field": "issue_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of issue numbers (IID)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_issues",
            "task_name": "tasks.gitlab.list_issues",
            "description": "Lists all issues for the specified project",
            "label": "List issues of a repository",
            "required": ["project_owner", "project_name"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "issue_assignee_username",
                "creator_username",
                "search",
                "labels",
                "updated_after",
                "state",
                "sort",
                "return_all",
                "limit",
            ],
        },
        "list_issues**false": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of issues to return (used only if Return All is OFF)",
                }
            ],
            "outputs": [],
        },
        "edit_issue**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "The issue number (IID) to edit",
                    "label": "Issue Number",
                    "placeholder": "1",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the issue",
                    "label": "Title",
                    "placeholder": "Enter new issue title",
                },
                {
                    "field": "issue_body",
                    "type": "string",
                    "value": "",
                    "helper_text": "New body/description for the issue (supports Markdown)",
                    "label": "Body",
                    "placeholder": "Enter new issue description",
                },
                {
                    "field": "state",
                    "type": "string",
                    "value": "",
                    "helper_text": "State event: 'close' to close the issue, 'reopen' to reopen it",
                    "label": "State",
                    "placeholder": "close",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Close", "value": "close"},
                            {"label": "Reopen", "value": "reopen"},
                        ],
                    },
                },
                {
                    "field": "labels",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of labels (overwrites existing labels)",
                    "label": "Labels",
                    "placeholder": "bug,enhancement",
                },
                {
                    "field": "assignee_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of assignee user IDs",
                    "label": "Assignees",
                    "placeholder": "123,456",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Due date in YYYY-MM-DD format",
                    "label": "Due Date",
                    "placeholder": "2025-12-31",
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the edited issue",
                },
                {
                    "field": "issue_iid",
                    "type": "int32",
                    "helper_text": "Internal issue ID within the project",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Issue number (IID)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the issue",
                },
                {
                    "field": "web_url",
                    "type": "string",
                    "helper_text": "Web URL of the issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignee usernames",
                },
                {"field": "author", "type": "string", "helper_text": "Author details"},
                {
                    "field": "confidential",
                    "type": "bool",
                    "helper_text": "Whether the issue is confidential",
                },
                {
                    "field": "issue_type",
                    "type": "string",
                    "helper_text": "Type of the issue",
                },
                {
                    "field": "subscribed",
                    "type": "bool",
                    "helper_text": "Whether the user is subscribed to the issue",
                },
                {
                    "field": "imported",
                    "type": "bool",
                    "helper_text": "Whether the issue was imported",
                },
                {
                    "field": "has_tasks",
                    "type": "bool",
                    "helper_text": "Whether the issue has tasks",
                },
                {
                    "field": "time_stats",
                    "type": "string",
                    "helper_text": "Time tracking statistics in JSON format",
                },
                {
                    "field": "task_completion_status",
                    "type": "string",
                    "helper_text": "Task completion status in JSON format",
                },
                {
                    "field": "links",
                    "type": "string",
                    "helper_text": "Issue links in JSON format",
                },
                {
                    "field": "references",
                    "type": "string",
                    "helper_text": "Issue references in JSON format",
                },
                {
                    "field": "sources",
                    "type": "vec<string>",
                    "helper_text": "Sources in JSON format",
                },
                {
                    "field": "evidences",
                    "type": "vec<string>",
                    "helper_text": "Evidences in JSON format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "edit_issue",
            "task_name": "tasks.gitlab.edit_issue",
            "description": "Edit an existing issue in a GitLab project",
            "label": "Edit an issue",
            "required": ["project_owner", "project_name", "issue_number", "title"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "issue_number",
                "title",
                "issue_body",
                "state",
                "labels",
                "assignee_ids",
                "due_date",
            ],
        },
        "lock_issue**(*)": {
            "inputs": [
                {
                    "field": "project_owner",
                    "type": "string",
                    "value": "",
                    "helper_text": "Project owner username",
                    "label": "Project Owner",
                    "placeholder": "username",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_owner&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the project",
                    "label": "Project Name",
                    "placeholder": "my-project",
                    "component": {
                        "type": "dropdown",
                        "agent_field_type": "dynamic",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project_name&project_owner={inputs.project_owner}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "The issue number (IID) to lock",
                    "label": "Issue Number",
                    "placeholder": "1",
                },
                {
                    "field": "lock_reason",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional message recorded before locking the issue",
                    "label": "Lock Reason",
                    "placeholder": "Select a reason",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Off-topic", "value": "Off-topic"},
                            {"label": "Spam", "value": "Spam"},
                            {"label": "Too heated", "value": "Too heated"},
                            {"label": "Resolved", "value": "Resolved"},
                            {"label": "Duplicate", "value": "Duplicate"},
                            {"label": "Other", "value": "Other"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "issue_id",
                    "type": "string",
                    "helper_text": "ID of the locked issue",
                },
                {
                    "field": "issue_iid",
                    "type": "int32",
                    "helper_text": "Internal issue ID within the project",
                },
                {
                    "field": "issue_number",
                    "type": "string",
                    "helper_text": "Issue number (IID)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL of the issue",
                },
                {
                    "field": "issue_state",
                    "type": "string",
                    "helper_text": "State of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "due_date",
                    "type": "timestamp",
                    "helper_text": "Due date of the issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "Last update timestamp",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "List of labels",
                },
                {
                    "field": "assignees",
                    "type": "vec<string>",
                    "helper_text": "List of assignees",
                },
                {"field": "author", "type": "string", "helper_text": "Author details"},
                {
                    "field": "sources",
                    "type": "vec<string>",
                    "helper_text": "Sources in JSON format",
                },
                {
                    "field": "evidences",
                    "type": "vec<string>",
                    "helper_text": "Evidences in JSON format",
                },
                {
                    "field": "links",
                    "type": "string",
                    "helper_text": "Issue links in JSON format (includes closed_issues_url, closed_merge_requests_url, edit_url, merged_merge_requests_url, opened_issues_url, opened_merge_requests_url, self)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "lock_issue",
            "task_name": "tasks.gitlab.lock_issue",
            "description": "Lock an issue to prevent additional comments",
            "label": "Lock an issue",
            "required": ["project_owner", "project_name", "issue_number"],
            "ui_sort_order": [
                "integration",
                "action",
                "project_owner",
                "project_name",
                "issue_number",
                "lock_reason",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "return_all"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        return_all: bool = False,
        assignee_ids: str = "",
        author_email: str = "",
        author_name: str = "",
        body: str = "",
        branch: str = "main",
        commit_message: str = "",
        committer_email: str = "",
        committer_name: str = "",
        creator_username: str = "",
        description: str = "",
        due_date: Any = None,
        encoding: str = "text",
        file: str = "",
        file_path: str = "",
        issue_assignee_username: str = "",
        issue_body: str = "",
        issue_number: str = "",
        labels: str = "",
        limit: int = 10,
        list_file_path: str = "",
        lock_reason: str = "",
        milestones: str = "",
        name: str = "",
        namespace_id: str = "",
        order_by: str = "",
        page: int = 1,
        path: str = "",
        project_id: str = "",
        project_name: str = "",
        project_owner: str = "",
        ref: str = "main",
        release_project_id: str = "",
        released_at: Any = None,
        repository_name: str = "",
        search: str = "",
        sort: str = "",
        start_branch: str = "",
        state: str = "",
        tag_name: str = "",
        title: str = "",
        updated_after: Any = None,
        visibility: str = "private",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["return_all"] = return_all

        super().__init__(
            node_type="integration_gitlab",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if repository_name is not None:
            self.inputs["repository_name"] = repository_name
        if path is not None:
            self.inputs["path"] = path
        if namespace_id is not None:
            self.inputs["namespace_id"] = namespace_id
        if description is not None:
            self.inputs["description"] = description
        if visibility is not None:
            self.inputs["visibility"] = visibility
        if project_owner is not None:
            self.inputs["project_owner"] = project_owner
        if project_name is not None:
            self.inputs["project_name"] = project_name
        if file_path is not None:
            self.inputs["file_path"] = file_path
        if file is not None:
            self.inputs["file"] = file
        if commit_message is not None:
            self.inputs["commit_message"] = commit_message
        if branch is not None:
            self.inputs["branch"] = branch
        if committer_name is not None:
            self.inputs["committer_name"] = committer_name
        if committer_email is not None:
            self.inputs["committer_email"] = committer_email
        if author_name is not None:
            self.inputs["author_name"] = author_name
        if author_email is not None:
            self.inputs["author_email"] = author_email
        if encoding is not None:
            self.inputs["encoding"] = encoding
        if ref is not None:
            self.inputs["ref"] = ref
        if list_file_path is not None:
            self.inputs["list_file_path"] = list_file_path
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if page is not None:
            self.inputs["page"] = page
        if start_branch is not None:
            self.inputs["start_branch"] = start_branch
        if tag_name is not None:
            self.inputs["tag_name"] = tag_name
        if name is not None:
            self.inputs["name"] = name
        if project_id is not None:
            self.inputs["project_id"] = project_id
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if sort is not None:
            self.inputs["sort"] = sort
        if release_project_id is not None:
            self.inputs["release_project_id"] = release_project_id
        if milestones is not None:
            self.inputs["milestones"] = milestones
        if released_at is not None:
            self.inputs["released_at"] = released_at
        if title is not None:
            self.inputs["title"] = title
        if due_date is not None:
            self.inputs["due_date"] = due_date
        if labels is not None:
            self.inputs["labels"] = labels
        if assignee_ids is not None:
            self.inputs["assignee_ids"] = assignee_ids
        if issue_number is not None:
            self.inputs["issue_number"] = issue_number
        if body is not None:
            self.inputs["body"] = body
        if issue_assignee_username is not None:
            self.inputs["issue_assignee_username"] = issue_assignee_username
        if creator_username is not None:
            self.inputs["creator_username"] = creator_username
        if search is not None:
            self.inputs["search"] = search
        if updated_after is not None:
            self.inputs["updated_after"] = updated_after
        if state is not None:
            self.inputs["state"] = state
        if issue_body is not None:
            self.inputs["issue_body"] = issue_body
        if lock_reason is not None:
            self.inputs["lock_reason"] = lock_reason
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGitlabNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
