"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_google_calendar")
class IntegrationGoogleCalendarNode(Node):
    """
    Google Calendar

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'get_events'
        query: Return only events that contain these keywords
        calendar: Select the calendar to add the new event to
        use_date: Toggle to use dates
    ### When action = 'new_event'
        all_day_event: Toggle to set the event as an all-day event
        attendees: Email IDs of attendees (comma separated)
        calendar: Select the calendar to add the new event to
        description: The description of the event
        duration: The duration of the event (positive integer). Default: 30 (in minutes)
        event_name: The name of the calendar event
        location: Physical location or the meeting location (like Zoom)
        repeat_frequency: How often the event repeats (leave empty for non-recurring events)
        repeat_how_many_times: Number of times the event should repeat (use either this or Repeat Until, not both)
        repeat_until: End date for the recurring event (use either this or Repeat How Many Times, not both)
        rrule: Advanced: Custom recurrence rule (overrides Repeat Frequency, Repeat How Many Times, and Repeat Until if set). Format: RFC 5545
        start_datetime: The start time of the calendar event (format: YYYY-MM-DD for full day event or YYYY-MM-DDTHH:MM:SS for specific time)
    ### When action = 'check_availability'
        calendar: Select the calendar to add the new event to
        end_date_and_time: The last date and end time for everyday to look for availability
        slot_duration: The duration of an individual slot to look for (in minutes). Default: 30 (in minutes)
        start_date_and_time: The first date and start time for everyday to look for availability
        timezone: IANA Time Zone code (e.g., US/Eastern)
    ### When action = 'read_event'
        calendar: Select the calendar to add the new event to
        event_id: The ID of the event to read
    ### When action = 'update_event'
        calendar: Select the calendar to add the new event to
        end_time: New end time for the event (RFC3339 format)
        event_id: The ID of the event to read
        repeat_frequency: How often the event repeats (leave empty for non-recurring events)
        repeat_how_many_times: Number of times the event should repeat (use either this or Repeat Until, not both)
        repeat_until: End date for the recurring event (use either this or Repeat How Many Times, not both)
        rrule: Advanced: Custom recurrence rule (overrides Repeat Frequency, Repeat How Many Times, and Repeat Until if set). Format: RFC 5545
        send_notifications: Whether to send notifications about the changes
        send_updates: Whether to send notifications about the update to attendees
        start_time: New start time for the event (RFC3339 format)
        update_attendees: New attendee list (comma-separated emails)
        update_color_id: New color ID for the event (1-11)
        update_description: New description for the event
        update_guests_can_invite_others: Whether guests can invite other attendees
        update_guests_can_modify: Whether guests can modify the event
        update_guests_can_see_other_guests: Whether guests can see other attendees
        update_location: New location for the event
        update_max_attendees: Maximum number of attendees
        update_show_me_as: How to show the time slot (opaque=busy, transparent=free)
        update_summary: New title/summary for the event
        update_visibility: New visibility setting for the event
    ### When action = 'delete_event'
        calendar: Select the calendar to add the new event to
        event_id: The ID of the event to read
        send_updates: Whether to send notifications about the update to attendees
    ### When action = 'get_events' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_events' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_events' and use_date = False
        num_messages: Specify the last n numbers of events
    ### When action = 'get_events' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'new_event'
        attendees: List of attendee email addresses
        creator: The creator's email address
        description: The description of the event
        end_time: The end time of the event
        event_id: The ID of the created event
        event_link: The HTML link to the event in Google Calendar
        location: The location of the event
        organizer: The organizer's email address
        output: Calendar event link
        raw_data: Raw event data from Google Calendar
        reminders: Reminder settings for the event
        start_time: The start time of the event
        status: The status of the event
        summary: The title/summary of the event
    ### When action = 'read_event'
        attendees: List of attendee email addresses
        creator: The creator's email address
        description: The description of the event
        end_time: The end time of the event
        event_id: The ID of the event
        location: The location of the event
        organizer: The organizer's email address
        raw_data: Raw event data from Google Calendar
        start_time: The start time of the event
        status: The status of the event
        summary: The title/summary of the event
    ### When action = 'get_events'
        attendees: List of event attendees
        details: List of event details
        end_times: List of event end times
        event_ids: List of event IDs
        locations: List of event locations
        organizers: List of event organizers
        raw_data: Raw events data from Google Calendar
        start_times: List of event start times
        summaries: List of event summaries
    ### When action = 'update_event'
        attendees: List of updated attendee email addresses
        creator: The creator's email address
        description: The updated description of the event
        end_time: The updated end time of the event
        event_id: The ID of the updated event
        location: The updated location of the event
        organizer: The organizer's email address
        raw_data: Raw updated event data from Google Calendar
        start_time: The updated start time of the event
        status: The status of the event
        summary: The updated title/summary of the event
    ### When action = 'delete_event'
        event_id: The ID of the deleted event
        message: Success message
        raw_data: Raw deletion confirmation data from Google Calendar
    ### When action = 'check_availability'
        output: List of available time slots
        raw_data: Raw availability data from Google Calendar
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Calendar>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "new_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "label": "Calendar",
                    "helper_text": "Select the calendar to add the new event to",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_name",
                    "type": "string",
                    "value": "",
                    "label": "Event Name",
                    "placeholder": "Meeting with John Doe",
                    "helper_text": "The name of the calendar event",
                },
                {
                    "field": "all_day_event",
                    "type": "bool",
                    "value": False,
                    "label": "All Day Event",
                    "helper_text": "Toggle to set the event as an all-day event",
                },
                {
                    "field": "start_datetime",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start Datetime",
                    "placeholder": "2024-06-24 (full day event) or 2024-06-24T19:00:00-05:00",
                    "helper_text": "The start time of the calendar event (format: YYYY-MM-DD for full day event or YYYY-MM-DDTHH:MM:SS for specific time)",
                    "agent_helper_text": "If the user specifies a timezone, include the UTC offset in the datetime (e.g., 2024-06-24T19:00:00-05:00 for US/Eastern, 2024-06-24T19:00:00+05:30 for Asia/Kolkata). If no timezone is mentioned, omit the offset.",
                },
                {
                    "field": "duration",
                    "type": "int32",
                    "value": 30,
                    "label": "Duration",
                    "placeholder": "30 minutes",
                    "helper_text": "The duration of the event (positive integer). Default: 30 (in minutes)",
                },
                {
                    "field": "attendees",
                    "type": "string",
                    "value": "",
                    "label": "Attendees",
                    "placeholder": "abc@example.com,xyz@example.com,",
                    "helper_text": "Email IDs of attendees (comma separated)",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "placeholder": "800 Howard St., San Francisco, CA 94103",
                    "helper_text": "Physical location or the meeting location (like Zoom)",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Monthly sync",
                    "helper_text": "The description of the event",
                },
                {
                    "field": "repeat_frequency",
                    "type": "string",
                    "value": "",
                    "label": "Repeat Frequency",
                    "placeholder": "Select frequency",
                    "helper_text": "How often the event repeats (leave empty for non-recurring events)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "repeat_frequency",
                    },
                },
                {
                    "field": "repeat_how_many_times",
                    "type": "int32",
                    "value": 0,
                    "label": "Repeat How Many Times",
                    "placeholder": "e.g. 10",
                    "helper_text": "Number of times the event should repeat (use either this or Repeat Until, not both)",
                },
                {
                    "field": "repeat_until",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Repeat Until",
                    "placeholder": "2024-12-31",
                    "helper_text": "End date for the recurring event (use either this or Repeat How Many Times, not both)",
                },
                {
                    "field": "rrule",
                    "type": "string",
                    "value": "",
                    "label": "RRULE",
                    "placeholder": "FREQ=WEEKLY;COUNT=10",
                    "helper_text": "Advanced: Custom recurrence rule (overrides Repeat Frequency, Repeat How Many Times, and Repeat Until if set). Format: RFC 5545",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Calendar event link",
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "The ID of the created event",
                },
                {
                    "field": "event_link",
                    "type": "string",
                    "helper_text": "The HTML link to the event in Google Calendar",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "The title/summary of the event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The description of the event",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The location of the event",
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "helper_text": "The start time of the event",
                },
                {
                    "field": "end_time",
                    "type": "timestamp",
                    "helper_text": "The end time of the event",
                },
                {
                    "field": "organizer",
                    "type": "string",
                    "helper_text": "The organizer's email address",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "helper_text": "The creator's email address",
                },
                {
                    "field": "attendees",
                    "type": "vec<string>",
                    "helper_text": "List of attendee email addresses",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the event",
                },
                {
                    "field": "reminders",
                    "type": "string",
                    "helper_text": "Reminder settings for the event",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw event data from Google Calendar",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "new_event",
            "task_name": "tasks.google_calendar.create_event",
            "description": "Create a new event",
            "label": "New Event",
            "inputs_sort_order": [
                "integration",
                "action",
                "calendar",
                "event_name",
                "all_day_event",
                "start_datetime",
                "duration",
                "attendees",
                "location",
                "description",
                "repeat_frequency",
                "repeat_how_many_times",
                "repeat_until",
                "rrule",
            ],
            "required": ["calendar", "event_name", "start_datetime"],
        },
        "check_availability**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "label": "Calendar",
                    "helper_text": "Select the calendar to check availability",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "start_date_and_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start Date & Start Work Time",
                    "placeholder": "2024-06-24",
                    "helper_text": "The first date and start time for everyday to look for availability",
                },
                {
                    "field": "end_date_and_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "End Date & End Work Time",
                    "placeholder": "2024-06-24",
                    "helper_text": "The last date and end time for everyday to look for availability",
                },
                {
                    "field": "slot_duration",
                    "type": "int32",
                    "value": 30,
                    "label": "Slot Duration",
                    "placeholder": "30 minutes",
                    "helper_text": "The duration of an individual slot to look for (in minutes). Default: 30 (in minutes)",
                },
                {
                    "field": "timezone",
                    "type": "enum<string>",
                    "value": "US/Eastern",
                    "label": "Timezone",
                    "placeholder": "US/Eastern",
                    "helper_text": "IANA Time Zone code (e.g., US/Eastern)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Africa/Abidjan", "value": "Africa/Abidjan"},
                            {"label": "Africa/Accra", "value": "Africa/Accra"},
                            {
                                "label": "Africa/Addis_Ababa",
                                "value": "Africa/Addis_Ababa",
                            },
                            {"label": "Africa/Algiers", "value": "Africa/Algiers"},
                            {"label": "Africa/Asmara", "value": "Africa/Asmara"},
                            {"label": "Africa/Asmera", "value": "Africa/Asmera"},
                            {"label": "Africa/Bamako", "value": "Africa/Bamako"},
                            {"label": "Africa/Bangui", "value": "Africa/Bangui"},
                            {"label": "Africa/Banjul", "value": "Africa/Banjul"},
                            {"label": "Africa/Bissau", "value": "Africa/Bissau"},
                            {"label": "Africa/Blantyre", "value": "Africa/Blantyre"},
                            {
                                "label": "Africa/Brazzaville",
                                "value": "Africa/Brazzaville",
                            },
                            {"label": "Africa/Bujumbura", "value": "Africa/Bujumbura"},
                            {"label": "Africa/Cairo", "value": "Africa/Cairo"},
                            {
                                "label": "Africa/Casablanca",
                                "value": "Africa/Casablanca",
                            },
                            {"label": "Africa/Ceuta", "value": "Africa/Ceuta"},
                            {"label": "Africa/Conakry", "value": "Africa/Conakry"},
                            {"label": "Africa/Dakar", "value": "Africa/Dakar"},
                            {
                                "label": "Africa/Dar_es_Salaam",
                                "value": "Africa/Dar_es_Salaam",
                            },
                            {"label": "Africa/Djibouti", "value": "Africa/Djibouti"},
                            {"label": "Africa/Douala", "value": "Africa/Douala"},
                            {"label": "Africa/El_Aaiun", "value": "Africa/El_Aaiun"},
                            {"label": "Africa/Freetown", "value": "Africa/Freetown"},
                            {"label": "Africa/Gaborone", "value": "Africa/Gaborone"},
                            {"label": "Africa/Harare", "value": "Africa/Harare"},
                            {
                                "label": "Africa/Johannesburg",
                                "value": "Africa/Johannesburg",
                            },
                            {"label": "Africa/Juba", "value": "Africa/Juba"},
                            {"label": "Africa/Kampala", "value": "Africa/Kampala"},
                            {"label": "Africa/Khartoum", "value": "Africa/Khartoum"},
                            {"label": "Africa/Kigali", "value": "Africa/Kigali"},
                            {"label": "Africa/Kinshasa", "value": "Africa/Kinshasa"},
                            {"label": "Africa/Lagos", "value": "Africa/Lagos"},
                            {
                                "label": "Africa/Libreville",
                                "value": "Africa/Libreville",
                            },
                            {"label": "Africa/Lome", "value": "Africa/Lome"},
                            {"label": "Africa/Luanda", "value": "Africa/Luanda"},
                            {
                                "label": "Africa/Lubumbashi",
                                "value": "Africa/Lubumbashi",
                            },
                            {"label": "Africa/Lusaka", "value": "Africa/Lusaka"},
                            {"label": "Africa/Malabo", "value": "Africa/Malabo"},
                            {"label": "Africa/Maputo", "value": "Africa/Maputo"},
                            {"label": "Africa/Maseru", "value": "Africa/Maseru"},
                            {"label": "Africa/Mbabane", "value": "Africa/Mbabane"},
                            {"label": "Africa/Mogadishu", "value": "Africa/Mogadishu"},
                            {"label": "Africa/Monrovia", "value": "Africa/Monrovia"},
                            {"label": "Africa/Nairobi", "value": "Africa/Nairobi"},
                            {"label": "Africa/Ndjamena", "value": "Africa/Ndjamena"},
                            {"label": "Africa/Niamey", "value": "Africa/Niamey"},
                            {
                                "label": "Africa/Nouakchott",
                                "value": "Africa/Nouakchott",
                            },
                            {
                                "label": "Africa/Ouagadougou",
                                "value": "Africa/Ouagadougou",
                            },
                            {
                                "label": "Africa/Porto-Novo",
                                "value": "Africa/Porto-Novo",
                            },
                            {"label": "Africa/Sao_Tome", "value": "Africa/Sao_Tome"},
                            {"label": "Africa/Timbuktu", "value": "Africa/Timbuktu"},
                            {"label": "Africa/Tripoli", "value": "Africa/Tripoli"},
                            {"label": "Africa/Tunis", "value": "Africa/Tunis"},
                            {"label": "Africa/Windhoek", "value": "Africa/Windhoek"},
                            {"label": "America/Adak", "value": "America/Adak"},
                            {
                                "label": "America/Anchorage",
                                "value": "America/Anchorage",
                            },
                            {"label": "America/Anguilla", "value": "America/Anguilla"},
                            {"label": "America/Antigua", "value": "America/Antigua"},
                            {
                                "label": "America/Araguaina",
                                "value": "America/Araguaina",
                            },
                            {
                                "label": "America/Argentina/Buenos_Aires",
                                "value": "America/Argentina/Buenos_Aires",
                            },
                            {
                                "label": "America/Argentina/Catamarca",
                                "value": "America/Argentina/Catamarca",
                            },
                            {
                                "label": "America/Argentina/ComodRivadavia",
                                "value": "America/Argentina/ComodRivadavia",
                            },
                            {
                                "label": "America/Argentina/Cordoba",
                                "value": "America/Argentina/Cordoba",
                            },
                            {
                                "label": "America/Argentina/Jujuy",
                                "value": "America/Argentina/Jujuy",
                            },
                            {
                                "label": "America/Argentina/La_Rioja",
                                "value": "America/Argentina/La_Rioja",
                            },
                            {
                                "label": "America/Argentina/Mendoza",
                                "value": "America/Argentina/Mendoza",
                            },
                            {
                                "label": "America/Argentina/Rio_Gallegos",
                                "value": "America/Argentina/Rio_Gallegos",
                            },
                            {
                                "label": "America/Argentina/Salta",
                                "value": "America/Argentina/Salta",
                            },
                            {
                                "label": "America/Argentina/San_Juan",
                                "value": "America/Argentina/San_Juan",
                            },
                            {
                                "label": "America/Argentina/San_Luis",
                                "value": "America/Argentina/San_Luis",
                            },
                            {
                                "label": "America/Argentina/Tucuman",
                                "value": "America/Argentina/Tucuman",
                            },
                            {
                                "label": "America/Argentina/Ushuaia",
                                "value": "America/Argentina/Ushuaia",
                            },
                            {"label": "America/Aruba", "value": "America/Aruba"},
                            {"label": "America/Asuncion", "value": "America/Asuncion"},
                            {"label": "America/Atikokan", "value": "America/Atikokan"},
                            {"label": "America/Atka", "value": "America/Atka"},
                            {"label": "America/Bahia", "value": "America/Bahia"},
                            {
                                "label": "America/Bahia_Banderas",
                                "value": "America/Bahia_Banderas",
                            },
                            {"label": "America/Barbados", "value": "America/Barbados"},
                            {"label": "America/Belem", "value": "America/Belem"},
                            {"label": "America/Belize", "value": "America/Belize"},
                            {
                                "label": "America/Blanc-Sablon",
                                "value": "America/Blanc-Sablon",
                            },
                            {
                                "label": "America/Boa_Vista",
                                "value": "America/Boa_Vista",
                            },
                            {"label": "America/Bogota", "value": "America/Bogota"},
                            {"label": "America/Boise", "value": "America/Boise"},
                            {
                                "label": "America/Buenos_Aires",
                                "value": "America/Buenos_Aires",
                            },
                            {
                                "label": "America/Cambridge_Bay",
                                "value": "America/Cambridge_Bay",
                            },
                            {
                                "label": "America/Campo_Grande",
                                "value": "America/Campo_Grande",
                            },
                            {"label": "America/Cancun", "value": "America/Cancun"},
                            {"label": "America/Caracas", "value": "America/Caracas"},
                            {
                                "label": "America/Catamarca",
                                "value": "America/Catamarca",
                            },
                            {"label": "America/Cayenne", "value": "America/Cayenne"},
                            {"label": "America/Cayman", "value": "America/Cayman"},
                            {"label": "America/Chicago", "value": "America/Chicago"},
                            {
                                "label": "America/Chihuahua",
                                "value": "America/Chihuahua",
                            },
                            {
                                "label": "America/Ciudad_Juarez",
                                "value": "America/Ciudad_Juarez",
                            },
                            {
                                "label": "America/Coral_Harbour",
                                "value": "America/Coral_Harbour",
                            },
                            {"label": "America/Cordoba", "value": "America/Cordoba"},
                            {
                                "label": "America/Costa_Rica",
                                "value": "America/Costa_Rica",
                            },
                            {"label": "America/Creston", "value": "America/Creston"},
                            {"label": "America/Cuiaba", "value": "America/Cuiaba"},
                            {"label": "America/Curacao", "value": "America/Curacao"},
                            {
                                "label": "America/Danmarkshavn",
                                "value": "America/Danmarkshavn",
                            },
                            {"label": "America/Dawson", "value": "America/Dawson"},
                            {
                                "label": "America/Dawson_Creek",
                                "value": "America/Dawson_Creek",
                            },
                            {"label": "America/Denver", "value": "America/Denver"},
                            {"label": "America/Detroit", "value": "America/Detroit"},
                            {"label": "America/Dominica", "value": "America/Dominica"},
                            {"label": "America/Edmonton", "value": "America/Edmonton"},
                            {"label": "America/Eirunepe", "value": "America/Eirunepe"},
                            {
                                "label": "America/El_Salvador",
                                "value": "America/El_Salvador",
                            },
                            {"label": "America/Ensenada", "value": "America/Ensenada"},
                            {
                                "label": "America/Fort_Nelson",
                                "value": "America/Fort_Nelson",
                            },
                            {
                                "label": "America/Fort_Wayne",
                                "value": "America/Fort_Wayne",
                            },
                            {
                                "label": "America/Fortaleza",
                                "value": "America/Fortaleza",
                            },
                            {
                                "label": "America/Glace_Bay",
                                "value": "America/Glace_Bay",
                            },
                            {"label": "America/Godthab", "value": "America/Godthab"},
                            {
                                "label": "America/Goose_Bay",
                                "value": "America/Goose_Bay",
                            },
                            {
                                "label": "America/Grand_Turk",
                                "value": "America/Grand_Turk",
                            },
                            {"label": "America/Grenada", "value": "America/Grenada"},
                            {
                                "label": "America/Guadeloupe",
                                "value": "America/Guadeloupe",
                            },
                            {
                                "label": "America/Guatemala",
                                "value": "America/Guatemala",
                            },
                            {
                                "label": "America/Guayaquil",
                                "value": "America/Guayaquil",
                            },
                            {"label": "America/Guyana", "value": "America/Guyana"},
                            {"label": "America/Halifax", "value": "America/Halifax"},
                            {"label": "America/Havana", "value": "America/Havana"},
                            {
                                "label": "America/Hermosillo",
                                "value": "America/Hermosillo",
                            },
                            {
                                "label": "America/Indiana/Indianapolis",
                                "value": "America/Indiana/Indianapolis",
                            },
                            {
                                "label": "America/Indiana/Knox",
                                "value": "America/Indiana/Knox",
                            },
                            {
                                "label": "America/Indiana/Marengo",
                                "value": "America/Indiana/Marengo",
                            },
                            {
                                "label": "America/Indiana/Petersburg",
                                "value": "America/Indiana/Petersburg",
                            },
                            {
                                "label": "America/Indiana/Tell_City",
                                "value": "America/Indiana/Tell_City",
                            },
                            {
                                "label": "America/Indiana/Vevay",
                                "value": "America/Indiana/Vevay",
                            },
                            {
                                "label": "America/Indiana/Vincennes",
                                "value": "America/Indiana/Vincennes",
                            },
                            {
                                "label": "America/Indiana/Winamac",
                                "value": "America/Indiana/Winamac",
                            },
                            {
                                "label": "America/Indianapolis",
                                "value": "America/Indianapolis",
                            },
                            {"label": "America/Inuvik", "value": "America/Inuvik"},
                            {"label": "America/Iqaluit", "value": "America/Iqaluit"},
                            {"label": "America/Jamaica", "value": "America/Jamaica"},
                            {"label": "America/Jujuy", "value": "America/Jujuy"},
                            {"label": "America/Juneau", "value": "America/Juneau"},
                            {
                                "label": "America/Kentucky/Louisville",
                                "value": "America/Kentucky/Louisville",
                            },
                            {
                                "label": "America/Kentucky/Monticello",
                                "value": "America/Kentucky/Monticello",
                            },
                            {"label": "America/Knox_IN", "value": "America/Knox_IN"},
                            {
                                "label": "America/Kralendijk",
                                "value": "America/Kralendijk",
                            },
                            {"label": "America/La_Paz", "value": "America/La_Paz"},
                            {"label": "America/Lima", "value": "America/Lima"},
                            {
                                "label": "America/Los_Angeles",
                                "value": "America/Los_Angeles",
                            },
                            {
                                "label": "America/Louisville",
                                "value": "America/Louisville",
                            },
                            {
                                "label": "America/Lower_Princes",
                                "value": "America/Lower_Princes",
                            },
                            {"label": "America/Maceio", "value": "America/Maceio"},
                            {"label": "America/Managua", "value": "America/Managua"},
                            {"label": "America/Manaus", "value": "America/Manaus"},
                            {"label": "America/Marigot", "value": "America/Marigot"},
                            {
                                "label": "America/Martinique",
                                "value": "America/Martinique",
                            },
                            {
                                "label": "America/Matamoros",
                                "value": "America/Matamoros",
                            },
                            {"label": "America/Mazatlan", "value": "America/Mazatlan"},
                            {"label": "America/Mendoza", "value": "America/Mendoza"},
                            {
                                "label": "America/Menominee",
                                "value": "America/Menominee",
                            },
                            {"label": "America/Merida", "value": "America/Merida"},
                            {
                                "label": "America/Metlakatla",
                                "value": "America/Metlakatla",
                            },
                            {
                                "label": "America/Mexico_City",
                                "value": "America/Mexico_City",
                            },
                            {"label": "America/Miquelon", "value": "America/Miquelon"},
                            {"label": "America/Moncton", "value": "America/Moncton"},
                            {
                                "label": "America/Monterrey",
                                "value": "America/Monterrey",
                            },
                            {
                                "label": "America/Montevideo",
                                "value": "America/Montevideo",
                            },
                            {"label": "America/Montreal", "value": "America/Montreal"},
                            {
                                "label": "America/Montserrat",
                                "value": "America/Montserrat",
                            },
                            {"label": "America/Nassau", "value": "America/Nassau"},
                            {"label": "America/New_York", "value": "America/New_York"},
                            {"label": "America/Nipigon", "value": "America/Nipigon"},
                            {"label": "America/Nome", "value": "America/Nome"},
                            {"label": "America/Noronha", "value": "America/Noronha"},
                            {
                                "label": "America/North_Dakota/Beulah",
                                "value": "America/North_Dakota/Beulah",
                            },
                            {
                                "label": "America/North_Dakota/Center",
                                "value": "America/North_Dakota/Center",
                            },
                            {
                                "label": "America/North_Dakota/New_Salem",
                                "value": "America/North_Dakota/New_Salem",
                            },
                            {"label": "America/Nuuk", "value": "America/Nuuk"},
                            {"label": "America/Ojinaga", "value": "America/Ojinaga"},
                            {"label": "America/Panama", "value": "America/Panama"},
                            {
                                "label": "America/Pangnirtung",
                                "value": "America/Pangnirtung",
                            },
                            {
                                "label": "America/Paramaribo",
                                "value": "America/Paramaribo",
                            },
                            {"label": "America/Phoenix", "value": "America/Phoenix"},
                            {
                                "label": "America/Port-au-Prince",
                                "value": "America/Port-au-Prince",
                            },
                            {
                                "label": "America/Port_of_Spain",
                                "value": "America/Port_of_Spain",
                            },
                            {
                                "label": "America/Porto_Acre",
                                "value": "America/Porto_Acre",
                            },
                            {
                                "label": "America/Porto_Velho",
                                "value": "America/Porto_Velho",
                            },
                            {
                                "label": "America/Puerto_Rico",
                                "value": "America/Puerto_Rico",
                            },
                            {
                                "label": "America/Punta_Arenas",
                                "value": "America/Punta_Arenas",
                            },
                            {
                                "label": "America/Rainy_River",
                                "value": "America/Rainy_River",
                            },
                            {
                                "label": "America/Rankin_Inlet",
                                "value": "America/Rankin_Inlet",
                            },
                            {"label": "America/Recife", "value": "America/Recife"},
                            {"label": "America/Regina", "value": "America/Regina"},
                            {"label": "America/Resolute", "value": "America/Resolute"},
                            {
                                "label": "America/Rio_Branco",
                                "value": "America/Rio_Branco",
                            },
                            {"label": "America/Rosario", "value": "America/Rosario"},
                            {
                                "label": "America/Santa_Isabel",
                                "value": "America/Santa_Isabel",
                            },
                            {"label": "America/Santarem", "value": "America/Santarem"},
                            {"label": "America/Santiago", "value": "America/Santiago"},
                            {
                                "label": "America/Santo_Domingo",
                                "value": "America/Santo_Domingo",
                            },
                            {
                                "label": "America/Sao_Paulo",
                                "value": "America/Sao_Paulo",
                            },
                            {
                                "label": "America/Scoresbysund",
                                "value": "America/Scoresbysund",
                            },
                            {"label": "America/Shiprock", "value": "America/Shiprock"},
                            {"label": "America/Sitka", "value": "America/Sitka"},
                            {
                                "label": "America/St_Barthelemy",
                                "value": "America/St_Barthelemy",
                            },
                            {"label": "America/St_Johns", "value": "America/St_Johns"},
                            {"label": "America/St_Kitts", "value": "America/St_Kitts"},
                            {"label": "America/St_Lucia", "value": "America/St_Lucia"},
                            {
                                "label": "America/St_Thomas",
                                "value": "America/St_Thomas",
                            },
                            {
                                "label": "America/St_Vincent",
                                "value": "America/St_Vincent",
                            },
                            {
                                "label": "America/Swift_Current",
                                "value": "America/Swift_Current",
                            },
                            {
                                "label": "America/Tegucigalpa",
                                "value": "America/Tegucigalpa",
                            },
                            {"label": "America/Thule", "value": "America/Thule"},
                            {
                                "label": "America/Thunder_Bay",
                                "value": "America/Thunder_Bay",
                            },
                            {"label": "America/Tijuana", "value": "America/Tijuana"},
                            {"label": "America/Toronto", "value": "America/Toronto"},
                            {"label": "America/Tortola", "value": "America/Tortola"},
                            {
                                "label": "America/Vancouver",
                                "value": "America/Vancouver",
                            },
                            {"label": "America/Virgin", "value": "America/Virgin"},
                            {
                                "label": "America/Whitehorse",
                                "value": "America/Whitehorse",
                            },
                            {"label": "America/Winnipeg", "value": "America/Winnipeg"},
                            {"label": "America/Yakutat", "value": "America/Yakutat"},
                            {
                                "label": "America/Yellowknife",
                                "value": "America/Yellowknife",
                            },
                            {"label": "Antarctica/Casey", "value": "Antarctica/Casey"},
                            {"label": "Antarctica/Davis", "value": "Antarctica/Davis"},
                            {
                                "label": "Antarctica/DumontDUrville",
                                "value": "Antarctica/DumontDUrville",
                            },
                            {
                                "label": "Antarctica/Macquarie",
                                "value": "Antarctica/Macquarie",
                            },
                            {
                                "label": "Antarctica/Mawson",
                                "value": "Antarctica/Mawson",
                            },
                            {
                                "label": "Antarctica/McMurdo",
                                "value": "Antarctica/McMurdo",
                            },
                            {
                                "label": "Antarctica/Palmer",
                                "value": "Antarctica/Palmer",
                            },
                            {
                                "label": "Antarctica/Rothera",
                                "value": "Antarctica/Rothera",
                            },
                            {
                                "label": "Antarctica/South_Pole",
                                "value": "Antarctica/South_Pole",
                            },
                            {"label": "Antarctica/Syowa", "value": "Antarctica/Syowa"},
                            {"label": "Antarctica/Troll", "value": "Antarctica/Troll"},
                            {
                                "label": "Antarctica/Vostok",
                                "value": "Antarctica/Vostok",
                            },
                            {
                                "label": "Arctic/Longyearbyen",
                                "value": "Arctic/Longyearbyen",
                            },
                            {"label": "Asia/Aden", "value": "Asia/Aden"},
                            {"label": "Asia/Almaty", "value": "Asia/Almaty"},
                            {"label": "Asia/Amman", "value": "Asia/Amman"},
                            {"label": "Asia/Anadyr", "value": "Asia/Anadyr"},
                            {"label": "Asia/Aqtau", "value": "Asia/Aqtau"},
                            {"label": "Asia/Aqtobe", "value": "Asia/Aqtobe"},
                            {"label": "Asia/Ashgabat", "value": "Asia/Ashgabat"},
                            {"label": "Asia/Ashkhabad", "value": "Asia/Ashkhabad"},
                            {"label": "Asia/Atyrau", "value": "Asia/Atyrau"},
                            {"label": "Asia/Baghdad", "value": "Asia/Baghdad"},
                            {"label": "Asia/Bahrain", "value": "Asia/Bahrain"},
                            {"label": "Asia/Baku", "value": "Asia/Baku"},
                            {"label": "Asia/Bangkok", "value": "Asia/Bangkok"},
                            {"label": "Asia/Barnaul", "value": "Asia/Barnaul"},
                            {"label": "Asia/Beirut", "value": "Asia/Beirut"},
                            {"label": "Asia/Bishkek", "value": "Asia/Bishkek"},
                            {"label": "Asia/Brunei", "value": "Asia/Brunei"},
                            {"label": "Asia/Calcutta", "value": "Asia/Calcutta"},
                            {"label": "Asia/Chita", "value": "Asia/Chita"},
                            {"label": "Asia/Choibalsan", "value": "Asia/Choibalsan"},
                            {"label": "Asia/Chongqing", "value": "Asia/Chongqing"},
                            {"label": "Asia/Chungking", "value": "Asia/Chungking"},
                            {"label": "Asia/Colombo", "value": "Asia/Colombo"},
                            {"label": "Asia/Dacca", "value": "Asia/Dacca"},
                            {"label": "Asia/Damascus", "value": "Asia/Damascus"},
                            {"label": "Asia/Dhaka", "value": "Asia/Dhaka"},
                            {"label": "Asia/Dili", "value": "Asia/Dili"},
                            {"label": "Asia/Dubai", "value": "Asia/Dubai"},
                            {"label": "Asia/Dushanbe", "value": "Asia/Dushanbe"},
                            {"label": "Asia/Famagusta", "value": "Asia/Famagusta"},
                            {"label": "Asia/Gaza", "value": "Asia/Gaza"},
                            {"label": "Asia/Harbin", "value": "Asia/Harbin"},
                            {"label": "Asia/Hebron", "value": "Asia/Hebron"},
                            {"label": "Asia/Ho_Chi_Minh", "value": "Asia/Ho_Chi_Minh"},
                            {"label": "Asia/Hong_Kong", "value": "Asia/Hong_Kong"},
                            {"label": "Asia/Hovd", "value": "Asia/Hovd"},
                            {"label": "Asia/Irkutsk", "value": "Asia/Irkutsk"},
                            {"label": "Asia/Istanbul", "value": "Asia/Istanbul"},
                            {"label": "Asia/Jakarta", "value": "Asia/Jakarta"},
                            {"label": "Asia/Jayapura", "value": "Asia/Jayapura"},
                            {"label": "Asia/Jerusalem", "value": "Asia/Jerusalem"},
                            {"label": "Asia/Kabul", "value": "Asia/Kabul"},
                            {"label": "Asia/Kamchatka", "value": "Asia/Kamchatka"},
                            {"label": "Asia/Karachi", "value": "Asia/Karachi"},
                            {"label": "Asia/Kashgar", "value": "Asia/Kashgar"},
                            {"label": "Asia/Kathmandu", "value": "Asia/Kathmandu"},
                            {"label": "Asia/Katmandu", "value": "Asia/Katmandu"},
                            {"label": "Asia/Khandyga", "value": "Asia/Khandyga"},
                            {"label": "Asia/Kolkata", "value": "Asia/Kolkata"},
                            {"label": "Asia/Krasnoyarsk", "value": "Asia/Krasnoyarsk"},
                            {
                                "label": "Asia/Kuala_Lumpur",
                                "value": "Asia/Kuala_Lumpur",
                            },
                            {"label": "Asia/Kuching", "value": "Asia/Kuching"},
                            {"label": "Asia/Kuwait", "value": "Asia/Kuwait"},
                            {"label": "Asia/Macao", "value": "Asia/Macao"},
                            {"label": "Asia/Macau", "value": "Asia/Macau"},
                            {"label": "Asia/Magadan", "value": "Asia/Magadan"},
                            {"label": "Asia/Makassar", "value": "Asia/Makassar"},
                            {"label": "Asia/Manila", "value": "Asia/Manila"},
                            {"label": "Asia/Muscat", "value": "Asia/Muscat"},
                            {"label": "Asia/Nicosia", "value": "Asia/Nicosia"},
                            {
                                "label": "Asia/Novokuznetsk",
                                "value": "Asia/Novokuznetsk",
                            },
                            {"label": "Asia/Novosibirsk", "value": "Asia/Novosibirsk"},
                            {"label": "Asia/Omsk", "value": "Asia/Omsk"},
                            {"label": "Asia/Oral", "value": "Asia/Oral"},
                            {"label": "Asia/Phnom_Penh", "value": "Asia/Phnom_Penh"},
                            {"label": "Asia/Pontianak", "value": "Asia/Pontianak"},
                            {"label": "Asia/Pyongyang", "value": "Asia/Pyongyang"},
                            {"label": "Asia/Qatar", "value": "Asia/Qatar"},
                            {"label": "Asia/Qostanay", "value": "Asia/Qostanay"},
                            {"label": "Asia/Qyzylorda", "value": "Asia/Qyzylorda"},
                            {"label": "Asia/Rangoon", "value": "Asia/Rangoon"},
                            {"label": "Asia/Riyadh", "value": "Asia/Riyadh"},
                            {"label": "Asia/Saigon", "value": "Asia/Saigon"},
                            {"label": "Asia/Sakhalin", "value": "Asia/Sakhalin"},
                            {"label": "Asia/Samarkand", "value": "Asia/Samarkand"},
                            {"label": "Asia/Seoul", "value": "Asia/Seoul"},
                            {"label": "Asia/Shanghai", "value": "Asia/Shanghai"},
                            {"label": "Asia/Singapore", "value": "Asia/Singapore"},
                            {
                                "label": "Asia/Srednekolymsk",
                                "value": "Asia/Srednekolymsk",
                            },
                            {"label": "Asia/Taipei", "value": "Asia/Taipei"},
                            {"label": "Asia/Tashkent", "value": "Asia/Tashkent"},
                            {"label": "Asia/Tbilisi", "value": "Asia/Tbilisi"},
                            {"label": "Asia/Tehran", "value": "Asia/Tehran"},
                            {"label": "Asia/Tel_Aviv", "value": "Asia/Tel_Aviv"},
                            {"label": "Asia/Thimbu", "value": "Asia/Thimbu"},
                            {"label": "Asia/Thimphu", "value": "Asia/Thimphu"},
                            {"label": "Asia/Tokyo", "value": "Asia/Tokyo"},
                            {"label": "Asia/Tomsk", "value": "Asia/Tomsk"},
                            {
                                "label": "Asia/Ujung_Pandang",
                                "value": "Asia/Ujung_Pandang",
                            },
                            {"label": "Asia/Ulaanbaatar", "value": "Asia/Ulaanbaatar"},
                            {"label": "Asia/Ulan_Bator", "value": "Asia/Ulan_Bator"},
                            {"label": "Asia/Urumqi", "value": "Asia/Urumqi"},
                            {"label": "Asia/Ust-Nera", "value": "Asia/Ust-Nera"},
                            {"label": "Asia/Vientiane", "value": "Asia/Vientiane"},
                            {"label": "Asia/Vladivostok", "value": "Asia/Vladivostok"},
                            {"label": "Asia/Yakutsk", "value": "Asia/Yakutsk"},
                            {"label": "Asia/Yangon", "value": "Asia/Yangon"},
                            {
                                "label": "Asia/Yekaterinburg",
                                "value": "Asia/Yekaterinburg",
                            },
                            {"label": "Asia/Yerevan", "value": "Asia/Yerevan"},
                            {"label": "Atlantic/Azores", "value": "Atlantic/Azores"},
                            {"label": "Atlantic/Bermuda", "value": "Atlantic/Bermuda"},
                            {"label": "Atlantic/Canary", "value": "Atlantic/Canary"},
                            {
                                "label": "Atlantic/Cape_Verde",
                                "value": "Atlantic/Cape_Verde",
                            },
                            {"label": "Atlantic/Faeroe", "value": "Atlantic/Faeroe"},
                            {"label": "Atlantic/Faroe", "value": "Atlantic/Faroe"},
                            {
                                "label": "Atlantic/Jan_Mayen",
                                "value": "Atlantic/Jan_Mayen",
                            },
                            {"label": "Atlantic/Madeira", "value": "Atlantic/Madeira"},
                            {
                                "label": "Atlantic/Reykjavik",
                                "value": "Atlantic/Reykjavik",
                            },
                            {
                                "label": "Atlantic/South_Georgia",
                                "value": "Atlantic/South_Georgia",
                            },
                            {
                                "label": "Atlantic/St_Helena",
                                "value": "Atlantic/St_Helena",
                            },
                            {"label": "Atlantic/Stanley", "value": "Atlantic/Stanley"},
                            {"label": "Australia/ACT", "value": "Australia/ACT"},
                            {
                                "label": "Australia/Adelaide",
                                "value": "Australia/Adelaide",
                            },
                            {
                                "label": "Australia/Brisbane",
                                "value": "Australia/Brisbane",
                            },
                            {
                                "label": "Australia/Broken_Hill",
                                "value": "Australia/Broken_Hill",
                            },
                            {
                                "label": "Australia/Canberra",
                                "value": "Australia/Canberra",
                            },
                            {"label": "Australia/Currie", "value": "Australia/Currie"},
                            {"label": "Australia/Darwin", "value": "Australia/Darwin"},
                            {"label": "Australia/Eucla", "value": "Australia/Eucla"},
                            {"label": "Australia/Hobart", "value": "Australia/Hobart"},
                            {"label": "Australia/LHI", "value": "Australia/LHI"},
                            {
                                "label": "Australia/Lindeman",
                                "value": "Australia/Lindeman",
                            },
                            {
                                "label": "Australia/Lord_Howe",
                                "value": "Australia/Lord_Howe",
                            },
                            {
                                "label": "Australia/Melbourne",
                                "value": "Australia/Melbourne",
                            },
                            {"label": "Australia/NSW", "value": "Australia/NSW"},
                            {"label": "Australia/North", "value": "Australia/North"},
                            {"label": "Australia/Perth", "value": "Australia/Perth"},
                            {
                                "label": "Australia/Queensland",
                                "value": "Australia/Queensland",
                            },
                            {"label": "Australia/South", "value": "Australia/South"},
                            {"label": "Australia/Sydney", "value": "Australia/Sydney"},
                            {
                                "label": "Australia/Tasmania",
                                "value": "Australia/Tasmania",
                            },
                            {
                                "label": "Australia/Victoria",
                                "value": "Australia/Victoria",
                            },
                            {"label": "Australia/West", "value": "Australia/West"},
                            {
                                "label": "Australia/Yancowinna",
                                "value": "Australia/Yancowinna",
                            },
                            {"label": "Brazil/Acre", "value": "Brazil/Acre"},
                            {"label": "Brazil/DeNoronha", "value": "Brazil/DeNoronha"},
                            {"label": "Brazil/East", "value": "Brazil/East"},
                            {"label": "Brazil/West", "value": "Brazil/West"},
                            {"label": "CET", "value": "CET"},
                            {"label": "CST6CDT", "value": "CST6CDT"},
                            {"label": "Canada/Atlantic", "value": "Canada/Atlantic"},
                            {"label": "Canada/Central", "value": "Canada/Central"},
                            {"label": "Canada/Eastern", "value": "Canada/Eastern"},
                            {"label": "Canada/Mountain", "value": "Canada/Mountain"},
                            {
                                "label": "Canada/Newfoundland",
                                "value": "Canada/Newfoundland",
                            },
                            {"label": "Canada/Pacific", "value": "Canada/Pacific"},
                            {
                                "label": "Canada/Saskatchewan",
                                "value": "Canada/Saskatchewan",
                            },
                            {"label": "Canada/Yukon", "value": "Canada/Yukon"},
                            {
                                "label": "Chile/Continental",
                                "value": "Chile/Continental",
                            },
                            {
                                "label": "Chile/EasterIsland",
                                "value": "Chile/EasterIsland",
                            },
                            {"label": "Cuba", "value": "Cuba"},
                            {"label": "EET", "value": "EET"},
                            {"label": "EST", "value": "EST"},
                            {"label": "EST5EDT", "value": "EST5EDT"},
                            {"label": "Egypt", "value": "Egypt"},
                            {"label": "Eire", "value": "Eire"},
                            {"label": "Etc/GMT", "value": "Etc/GMT"},
                            {"label": "Etc/GMT+0", "value": "Etc/GMT+0"},
                            {"label": "Etc/GMT+1", "value": "Etc/GMT+1"},
                            {"label": "Etc/GMT+10", "value": "Etc/GMT+10"},
                            {"label": "Etc/GMT+11", "value": "Etc/GMT+11"},
                            {"label": "Etc/GMT+12", "value": "Etc/GMT+12"},
                            {"label": "Etc/GMT+2", "value": "Etc/GMT+2"},
                            {"label": "Etc/GMT+3", "value": "Etc/GMT+3"},
                            {"label": "Etc/GMT+4", "value": "Etc/GMT+4"},
                            {"label": "Etc/GMT+5", "value": "Etc/GMT+5"},
                            {"label": "Etc/GMT+6", "value": "Etc/GMT+6"},
                            {"label": "Etc/GMT+7", "value": "Etc/GMT+7"},
                            {"label": "Etc/GMT+8", "value": "Etc/GMT+8"},
                            {"label": "Etc/GMT+9", "value": "Etc/GMT+9"},
                            {"label": "Etc/GMT-0", "value": "Etc/GMT-0"},
                            {"label": "Etc/GMT-1", "value": "Etc/GMT-1"},
                            {"label": "Etc/GMT-10", "value": "Etc/GMT-10"},
                            {"label": "Etc/GMT-11", "value": "Etc/GMT-11"},
                            {"label": "Etc/GMT-12", "value": "Etc/GMT-12"},
                            {"label": "Etc/GMT-13", "value": "Etc/GMT-13"},
                            {"label": "Etc/GMT-14", "value": "Etc/GMT-14"},
                            {"label": "Etc/GMT-2", "value": "Etc/GMT-2"},
                            {"label": "Etc/GMT-3", "value": "Etc/GMT-3"},
                            {"label": "Etc/GMT-4", "value": "Etc/GMT-4"},
                            {"label": "Etc/GMT-5", "value": "Etc/GMT-5"},
                            {"label": "Etc/GMT-6", "value": "Etc/GMT-6"},
                            {"label": "Etc/GMT-7", "value": "Etc/GMT-7"},
                            {"label": "Etc/GMT-8", "value": "Etc/GMT-8"},
                            {"label": "Etc/GMT-9", "value": "Etc/GMT-9"},
                            {"label": "Etc/GMT0", "value": "Etc/GMT0"},
                            {"label": "Etc/Greenwich", "value": "Etc/Greenwich"},
                            {"label": "Etc/UCT", "value": "Etc/UCT"},
                            {"label": "Etc/UTC", "value": "Etc/UTC"},
                            {"label": "Etc/Universal", "value": "Etc/Universal"},
                            {"label": "Etc/Zulu", "value": "Etc/Zulu"},
                            {"label": "Europe/Amsterdam", "value": "Europe/Amsterdam"},
                            {"label": "Europe/Andorra", "value": "Europe/Andorra"},
                            {"label": "Europe/Astrakhan", "value": "Europe/Astrakhan"},
                            {"label": "Europe/Athens", "value": "Europe/Athens"},
                            {"label": "Europe/Belfast", "value": "Europe/Belfast"},
                            {"label": "Europe/Belgrade", "value": "Europe/Belgrade"},
                            {"label": "Europe/Berlin", "value": "Europe/Berlin"},
                            {
                                "label": "Europe/Bratislava",
                                "value": "Europe/Bratislava",
                            },
                            {"label": "Europe/Brussels", "value": "Europe/Brussels"},
                            {"label": "Europe/Bucharest", "value": "Europe/Bucharest"},
                            {"label": "Europe/Budapest", "value": "Europe/Budapest"},
                            {"label": "Europe/Busingen", "value": "Europe/Busingen"},
                            {"label": "Europe/Chisinau", "value": "Europe/Chisinau"},
                            {
                                "label": "Europe/Copenhagen",
                                "value": "Europe/Copenhagen",
                            },
                            {"label": "Europe/Dublin", "value": "Europe/Dublin"},
                            {"label": "Europe/Gibraltar", "value": "Europe/Gibraltar"},
                            {"label": "Europe/Guernsey", "value": "Europe/Guernsey"},
                            {"label": "Europe/Helsinki", "value": "Europe/Helsinki"},
                            {
                                "label": "Europe/Isle_of_Man",
                                "value": "Europe/Isle_of_Man",
                            },
                            {"label": "Europe/Istanbul", "value": "Europe/Istanbul"},
                            {"label": "Europe/Jersey", "value": "Europe/Jersey"},
                            {
                                "label": "Europe/Kaliningrad",
                                "value": "Europe/Kaliningrad",
                            },
                            {"label": "Europe/Kiev", "value": "Europe/Kiev"},
                            {"label": "Europe/Kirov", "value": "Europe/Kirov"},
                            {"label": "Europe/Kyiv", "value": "Europe/Kyiv"},
                            {"label": "Europe/Lisbon", "value": "Europe/Lisbon"},
                            {"label": "Europe/Ljubljana", "value": "Europe/Ljubljana"},
                            {"label": "Europe/London", "value": "Europe/London"},
                            {
                                "label": "Europe/Luxembourg",
                                "value": "Europe/Luxembourg",
                            },
                            {"label": "Europe/Madrid", "value": "Europe/Madrid"},
                            {"label": "Europe/Malta", "value": "Europe/Malta"},
                            {"label": "Europe/Mariehamn", "value": "Europe/Mariehamn"},
                            {"label": "Europe/Minsk", "value": "Europe/Minsk"},
                            {"label": "Europe/Monaco", "value": "Europe/Monaco"},
                            {"label": "Europe/Moscow", "value": "Europe/Moscow"},
                            {"label": "Europe/Nicosia", "value": "Europe/Nicosia"},
                            {"label": "Europe/Oslo", "value": "Europe/Oslo"},
                            {"label": "Europe/Paris", "value": "Europe/Paris"},
                            {"label": "Europe/Podgorica", "value": "Europe/Podgorica"},
                            {"label": "Europe/Prague", "value": "Europe/Prague"},
                            {"label": "Europe/Riga", "value": "Europe/Riga"},
                            {"label": "Europe/Rome", "value": "Europe/Rome"},
                            {"label": "Europe/Samara", "value": "Europe/Samara"},
                            {
                                "label": "Europe/San_Marino",
                                "value": "Europe/San_Marino",
                            },
                            {"label": "Europe/Sarajevo", "value": "Europe/Sarajevo"},
                            {"label": "Europe/Saratov", "value": "Europe/Saratov"},
                            {
                                "label": "Europe/Simferopol",
                                "value": "Europe/Simferopol",
                            },
                            {"label": "Europe/Skopje", "value": "Europe/Skopje"},
                            {"label": "Europe/Sofia", "value": "Europe/Sofia"},
                            {"label": "Europe/Stockholm", "value": "Europe/Stockholm"},
                            {"label": "Europe/Tallinn", "value": "Europe/Tallinn"},
                            {"label": "Europe/Tirane", "value": "Europe/Tirane"},
                            {"label": "Europe/Tiraspol", "value": "Europe/Tiraspol"},
                            {"label": "Europe/Ulyanovsk", "value": "Europe/Ulyanovsk"},
                            {"label": "Europe/Uzhgorod", "value": "Europe/Uzhgorod"},
                            {"label": "Europe/Vaduz", "value": "Europe/Vaduz"},
                            {"label": "Europe/Vatican", "value": "Europe/Vatican"},
                            {"label": "Europe/Vienna", "value": "Europe/Vienna"},
                            {"label": "Europe/Vilnius", "value": "Europe/Vilnius"},
                            {"label": "Europe/Volgograd", "value": "Europe/Volgograd"},
                            {"label": "Europe/Warsaw", "value": "Europe/Warsaw"},
                            {"label": "Europe/Zagreb", "value": "Europe/Zagreb"},
                            {
                                "label": "Europe/Zaporozhye",
                                "value": "Europe/Zaporozhye",
                            },
                            {"label": "Europe/Zurich", "value": "Europe/Zurich"},
                            {"label": "GB", "value": "GB"},
                            {"label": "GB-Eire", "value": "GB-Eire"},
                            {"label": "GMT", "value": "GMT"},
                            {"label": "GMT+0", "value": "GMT+0"},
                            {"label": "GMT-0", "value": "GMT-0"},
                            {"label": "GMT0", "value": "GMT0"},
                            {"label": "Greenwich", "value": "Greenwich"},
                            {"label": "HST", "value": "HST"},
                            {"label": "Hongkong", "value": "Hongkong"},
                            {"label": "Iceland", "value": "Iceland"},
                            {
                                "label": "Indian/Antananarivo",
                                "value": "Indian/Antananarivo",
                            },
                            {"label": "Indian/Chagos", "value": "Indian/Chagos"},
                            {"label": "Indian/Christmas", "value": "Indian/Christmas"},
                            {"label": "Indian/Cocos", "value": "Indian/Cocos"},
                            {"label": "Indian/Comoro", "value": "Indian/Comoro"},
                            {"label": "Indian/Kerguelen", "value": "Indian/Kerguelen"},
                            {"label": "Indian/Mahe", "value": "Indian/Mahe"},
                            {"label": "Indian/Maldives", "value": "Indian/Maldives"},
                            {"label": "Indian/Mauritius", "value": "Indian/Mauritius"},
                            {"label": "Indian/Mayotte", "value": "Indian/Mayotte"},
                            {"label": "Indian/Reunion", "value": "Indian/Reunion"},
                            {"label": "Iran", "value": "Iran"},
                            {"label": "Israel", "value": "Israel"},
                            {"label": "Jamaica", "value": "Jamaica"},
                            {"label": "Japan", "value": "Japan"},
                            {"label": "Kwajalein", "value": "Kwajalein"},
                            {"label": "Libya", "value": "Libya"},
                            {"label": "MET", "value": "MET"},
                            {"label": "MST", "value": "MST"},
                            {"label": "MST7MDT", "value": "MST7MDT"},
                            {"label": "Mexico/BajaNorte", "value": "Mexico/BajaNorte"},
                            {"label": "Mexico/BajaSur", "value": "Mexico/BajaSur"},
                            {"label": "Mexico/General", "value": "Mexico/General"},
                            {"label": "NZ", "value": "NZ"},
                            {"label": "NZ-CHAT", "value": "NZ-CHAT"},
                            {"label": "Navajo", "value": "Navajo"},
                            {"label": "PRC", "value": "PRC"},
                            {"label": "PST8PDT", "value": "PST8PDT"},
                            {"label": "Pacific/Apia", "value": "Pacific/Apia"},
                            {"label": "Pacific/Auckland", "value": "Pacific/Auckland"},
                            {
                                "label": "Pacific/Bougainville",
                                "value": "Pacific/Bougainville",
                            },
                            {"label": "Pacific/Chatham", "value": "Pacific/Chatham"},
                            {"label": "Pacific/Chuuk", "value": "Pacific/Chuuk"},
                            {"label": "Pacific/Easter", "value": "Pacific/Easter"},
                            {"label": "Pacific/Efate", "value": "Pacific/Efate"},
                            {
                                "label": "Pacific/Enderbury",
                                "value": "Pacific/Enderbury",
                            },
                            {"label": "Pacific/Fakaofo", "value": "Pacific/Fakaofo"},
                            {"label": "Pacific/Fiji", "value": "Pacific/Fiji"},
                            {"label": "Pacific/Funafuti", "value": "Pacific/Funafuti"},
                            {
                                "label": "Pacific/Galapagos",
                                "value": "Pacific/Galapagos",
                            },
                            {"label": "Pacific/Gambier", "value": "Pacific/Gambier"},
                            {
                                "label": "Pacific/Guadalcanal",
                                "value": "Pacific/Guadalcanal",
                            },
                            {"label": "Pacific/Guam", "value": "Pacific/Guam"},
                            {"label": "Pacific/Honolulu", "value": "Pacific/Honolulu"},
                            {"label": "Pacific/Johnston", "value": "Pacific/Johnston"},
                            {"label": "Pacific/Kanton", "value": "Pacific/Kanton"},
                            {
                                "label": "Pacific/Kiritimati",
                                "value": "Pacific/Kiritimati",
                            },
                            {"label": "Pacific/Kosrae", "value": "Pacific/Kosrae"},
                            {
                                "label": "Pacific/Kwajalein",
                                "value": "Pacific/Kwajalein",
                            },
                            {"label": "Pacific/Majuro", "value": "Pacific/Majuro"},
                            {
                                "label": "Pacific/Marquesas",
                                "value": "Pacific/Marquesas",
                            },
                            {"label": "Pacific/Midway", "value": "Pacific/Midway"},
                            {"label": "Pacific/Nauru", "value": "Pacific/Nauru"},
                            {"label": "Pacific/Niue", "value": "Pacific/Niue"},
                            {"label": "Pacific/Norfolk", "value": "Pacific/Norfolk"},
                            {"label": "Pacific/Noumea", "value": "Pacific/Noumea"},
                            {
                                "label": "Pacific/Pago_Pago",
                                "value": "Pacific/Pago_Pago",
                            },
                            {"label": "Pacific/Palau", "value": "Pacific/Palau"},
                            {"label": "Pacific/Pitcairn", "value": "Pacific/Pitcairn"},
                            {"label": "Pacific/Pohnpei", "value": "Pacific/Pohnpei"},
                            {"label": "Pacific/Ponape", "value": "Pacific/Ponape"},
                            {
                                "label": "Pacific/Port_Moresby",
                                "value": "Pacific/Port_Moresby",
                            },
                            {
                                "label": "Pacific/Rarotonga",
                                "value": "Pacific/Rarotonga",
                            },
                            {"label": "Pacific/Saipan", "value": "Pacific/Saipan"},
                            {"label": "Pacific/Samoa", "value": "Pacific/Samoa"},
                            {"label": "Pacific/Tahiti", "value": "Pacific/Tahiti"},
                            {"label": "Pacific/Tarawa", "value": "Pacific/Tarawa"},
                            {
                                "label": "Pacific/Tongatapu",
                                "value": "Pacific/Tongatapu",
                            },
                            {"label": "Pacific/Truk", "value": "Pacific/Truk"},
                            {"label": "Pacific/Wake", "value": "Pacific/Wake"},
                            {"label": "Pacific/Wallis", "value": "Pacific/Wallis"},
                            {"label": "Pacific/Yap", "value": "Pacific/Yap"},
                            {"label": "Poland", "value": "Poland"},
                            {"label": "Portugal", "value": "Portugal"},
                            {"label": "ROC", "value": "ROC"},
                            {"label": "ROK", "value": "ROK"},
                            {"label": "Singapore", "value": "Singapore"},
                            {"label": "Turkey", "value": "Turkey"},
                            {"label": "UCT", "value": "UCT"},
                            {"label": "US/Alaska", "value": "US/Alaska"},
                            {"label": "US/Aleutian", "value": "US/Aleutian"},
                            {"label": "US/Arizona", "value": "US/Arizona"},
                            {"label": "US/Central", "value": "US/Central"},
                            {"label": "US/East-Indiana", "value": "US/East-Indiana"},
                            {"label": "US/Eastern", "value": "US/Eastern"},
                            {"label": "US/Hawaii", "value": "US/Hawaii"},
                            {
                                "label": "US/Indiana-Starke",
                                "value": "US/Indiana-Starke",
                            },
                            {"label": "US/Michigan", "value": "US/Michigan"},
                            {"label": "US/Mountain", "value": "US/Mountain"},
                            {"label": "US/Pacific", "value": "US/Pacific"},
                            {"label": "US/Samoa", "value": "US/Samoa"},
                            {"label": "UTC", "value": "UTC"},
                            {"label": "Universal", "value": "Universal"},
                            {"label": "W-SU", "value": "W-SU"},
                            {"label": "WET", "value": "WET"},
                            {"label": "Zulu", "value": "Zulu"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "List of available time slots",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw availability data from Google Calendar",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "check_availability",
            "task_name": "tasks.google_calendar.check_availability",
            "description": "Check Google calendar availability",
            "label": "Check Availability",
            "required": ["start_date_and_time", "end_date_and_time"],
            "inputs_sort_order": [
                "integration",
                "action",
                "calendar",
                "start_date_and_time",
                "end_date_and_time",
                "slot_duration",
                "timezone",
            ],
        },
        "read_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "label": "Calendar",
                    "helper_text": "Select the calendar to read the event from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "value": "",
                    "label": "Event ID",
                    "placeholder": "Event ID from Google Calendar",
                    "helper_text": "The ID of the event to read",
                },
            ],
            "outputs": [
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "The ID of the event",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "The title/summary of the event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The description of the event",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The location of the event",
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "helper_text": "The start time of the event",
                },
                {
                    "field": "end_time",
                    "type": "timestamp",
                    "helper_text": "The end time of the event",
                },
                {
                    "field": "organizer",
                    "type": "string",
                    "helper_text": "The organizer's email address",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "helper_text": "The creator's email address",
                },
                {
                    "field": "attendees",
                    "type": "vec<string>",
                    "helper_text": "List of attendee email addresses",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the event",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw event data from Google Calendar",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "read_event",
            "task_name": "tasks.google_calendar.read_event",
            "description": "Read details of a specific event",
            "label": "Get Event",
            "inputs_sort_order": ["integration", "action", "calendar", "event_id"],
            "required": ["calendar", "event_id"],
        },
        "get_events**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "label": "Calendar",
                    "helper_text": "Select the calendar to read events from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "helper_text": "Return only events that contain these keywords",
                    "placeholder": "Keywords to filter events",
                },
            ],
            "outputs": [
                {
                    "field": "event_ids",
                    "type": "vec<string>",
                    "helper_text": "List of event IDs",
                },
                {
                    "field": "summaries",
                    "type": "vec<string>",
                    "helper_text": "List of event summaries",
                },
                {
                    "field": "start_times",
                    "type": "vec<string>",
                    "helper_text": "List of event start times",
                },
                {
                    "field": "end_times",
                    "type": "vec<string>",
                    "helper_text": "List of event end times",
                },
                {
                    "field": "locations",
                    "type": "vec<string>",
                    "helper_text": "List of event locations",
                },
                {
                    "field": "organizers",
                    "type": "vec<string>",
                    "helper_text": "List of event organizers",
                },
                {
                    "field": "attendees",
                    "type": "vec<vec<string>>",
                    "helper_text": "List of event attendees",
                },
                {
                    "field": "details",
                    "type": "vec<string>",
                    "helper_text": "List of event details",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw events data from Google Calendar",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "get_events",
            "task_name": "tasks.google_calendar.get_events",
            "description": "Get multiple events",
            "label": "List Events",
            "inputs_sort_order": [
                "integration",
                "action",
                "calendar",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "query",
            ],
            "required": ["calendar", "num_messages"],
        },
        "get_events**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Events",
                    "helper_text": "Specify the last n numbers of events",
                }
            ],
            "outputs": [],
        },
        "get_events**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_events**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "hidden": True,
                    "label": "Date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_events**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "label": "Exact date",
                    "component": {"type": "date_range", "show_future_dates": True},
                }
            ],
            "outputs": [],
        },
        "update_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "label": "Calendar",
                    "helper_text": "Select the calendar containing the event to update",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "value": "",
                    "label": "Event ID",
                    "placeholder": "Event ID from Google Calendar",
                    "helper_text": "The ID of the event to update",
                },
                {
                    "field": "update_summary",
                    "type": "string",
                    "value": "",
                    "label": "Update Summary",
                    "placeholder": "New event title",
                    "helper_text": "New title/summary for the event",
                },
                {
                    "field": "update_description",
                    "type": "string",
                    "value": "",
                    "label": "Update Description",
                    "placeholder": "New event description",
                    "helper_text": "New description for the event",
                },
                {
                    "field": "update_location",
                    "type": "string",
                    "value": "",
                    "label": "Update Location",
                    "placeholder": "New event location",
                    "helper_text": "New location for the event",
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Start Time",
                    "placeholder": "2024-06-24T19:00:00",
                    "helper_text": "New start time for the event (RFC3339 format)",
                },
                {
                    "field": "end_time",
                    "type": "timestamp",
                    "value": -1,
                    "label": "End Time",
                    "placeholder": "2024-06-24T20:00:00",
                    "helper_text": "New end time for the event (RFC3339 format)",
                },
                {
                    "field": "update_attendees",
                    "type": "string",
                    "value": "",
                    "label": "Update Attendees",
                    "placeholder": "email1@example.com,email2@example.com",
                    "helper_text": "New attendee list (comma-separated emails)",
                },
                {
                    "field": "update_visibility",
                    "type": "string",
                    "value": "",
                    "label": "Update Visibility",
                    "helper_text": "New visibility setting for the event",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Default", "value": "default"},
                            {"label": "Public", "value": "public"},
                            {"label": "Private", "value": "private"},
                        ],
                    },
                },
                {
                    "field": "update_color_id",
                    "type": "string",
                    "value": "",
                    "label": "Update Color ID",
                    "placeholder": "1-11",
                    "helper_text": "New color ID for the event (1-11)",
                },
                {
                    "field": "update_guests_can_invite_others",
                    "type": "bool",
                    "value": False,
                    "label": "Guests Can Invite Others",
                    "helper_text": "Whether guests can invite other attendees",
                },
                {
                    "field": "update_guests_can_modify",
                    "type": "bool",
                    "value": False,
                    "label": "Guests Can Modify",
                    "helper_text": "Whether guests can modify the event",
                },
                {
                    "field": "update_guests_can_see_other_guests",
                    "type": "bool",
                    "value": False,
                    "label": "Guests Can See Other Guests",
                    "helper_text": "Whether guests can see other attendees",
                },
                {
                    "field": "update_show_me_as",
                    "type": "string",
                    "value": "",
                    "label": "Show Me As",
                    "helper_text": "How to show the time slot (opaque=busy, transparent=free)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Opaque", "value": "opaque"},
                            {"label": "Transparent", "value": "transparent"},
                        ],
                    },
                },
                {
                    "field": "update_max_attendees",
                    "type": "int32",
                    "value": 0,
                    "label": "Max Attendees",
                    "placeholder": "0",
                    "helper_text": "Maximum number of attendees",
                },
                {
                    "field": "send_updates",
                    "type": "string",
                    "value": "",
                    "label": "Send Updates",
                    "helper_text": "Whether to send notifications about the update to attendees",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "all"},
                            {"label": "External Only", "value": "externalOnly"},
                            {"label": "None", "value": "none"},
                        ],
                    },
                },
                {
                    "field": "send_notifications",
                    "type": "bool",
                    "value": False,
                    "label": "Send Notifications",
                    "helper_text": "Whether to send notifications about the changes",
                },
                {
                    "field": "repeat_frequency",
                    "type": "string",
                    "value": "",
                    "label": "Repeat Frequency",
                    "placeholder": "Select frequency",
                    "helper_text": "How often the event repeats (leave empty to keep existing recurrence or make non-recurring)",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "repeat_frequency",
                    },
                },
                {
                    "field": "repeat_how_many_times",
                    "type": "int32",
                    "value": 0,
                    "label": "Repeat How Many Times",
                    "placeholder": "e.g. 10",
                    "helper_text": "Number of times the event should repeat (use either this or Repeat Until, not both)",
                },
                {
                    "field": "repeat_until",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Repeat Until",
                    "placeholder": "2024-12-31",
                    "helper_text": "End date for the recurring event (use either this or Repeat How Many Times, not both)",
                },
                {
                    "field": "rrule",
                    "type": "string",
                    "value": "",
                    "label": "RRULE",
                    "placeholder": "FREQ=WEEKLY;COUNT=10",
                    "helper_text": "Advanced: Custom recurrence rule (overrides Repeat Frequency, Repeat How Many Times, and Repeat Until if set). Format: RFC 5545",
                },
            ],
            "outputs": [
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "The ID of the updated event",
                },
                {
                    "field": "summary",
                    "type": "string",
                    "helper_text": "The updated title/summary of the event",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The updated description of the event",
                },
                {
                    "field": "location",
                    "type": "string",
                    "helper_text": "The updated location of the event",
                },
                {
                    "field": "start_time",
                    "type": "timestamp",
                    "helper_text": "The updated start time of the event",
                },
                {
                    "field": "end_time",
                    "type": "timestamp",
                    "helper_text": "The updated end time of the event",
                },
                {
                    "field": "organizer",
                    "type": "string",
                    "helper_text": "The organizer's email address",
                },
                {
                    "field": "creator",
                    "type": "string",
                    "helper_text": "The creator's email address",
                },
                {
                    "field": "attendees",
                    "type": "vec<string>",
                    "helper_text": "List of updated attendee email addresses",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the event",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw updated event data from Google Calendar",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_event",
            "hidden": True,
            "task_name": "tasks.google_calendar.update_event",
            "description": "Update a Google calendar event",
            "label": "Update Event",
            "ui_sort_order": [
                "integration",
                "action",
                "calendar",
                "event_id",
                "update_summary",
                "update_description",
                "update_location",
                "start_time",
                "end_time",
                "update_attendees",
                "update_visibility",
                "update_color_id",
                "update_guests_can_invite_others",
                "update_guests_can_modify",
                "update_guests_can_see_other_guests",
                "update_show_me_as",
                "update_max_attendees",
                "send_updates",
                "send_notifications",
                "repeat_frequency",
                "repeat_how_many_times",
                "repeat_until",
                "rrule",
            ],
            "required": ["calendar", "event_id"],
        },
        "delete_event**(*)**(*)": {
            "inputs": [
                {
                    "field": "calendar",
                    "type": "string",
                    "label": "Calendar",
                    "helper_text": "Select the calendar to delete the event from",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=calendar_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "value": "",
                    "label": "Event ID",
                    "placeholder": "Event ID from Google Calendar",
                    "helper_text": "The ID of the event to delete",
                },
                {
                    "field": "send_updates",
                    "type": "string",
                    "value": "none",
                    "placeholder": "None",
                    "label": "Send Updates",
                    "helper_text": "Whether to send notifications about the deletion to attendees",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "all"},
                            {"label": "External Only", "value": "externalOnly"},
                            {"label": "None", "value": "none"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "event_id",
                    "type": "string",
                    "helper_text": "The ID of the deleted event",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw deletion confirmation data from Google Calendar",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "delete_event",
            "task_name": "tasks.google_calendar.delete_event",
            "description": "Delete a Google calendar event",
            "label": "Delete Event",
            "inputs_sort_order": [
                "integration",
                "action",
                "calendar",
                "event_id",
                "send_updates",
            ],
            "required": ["calendar", "event_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        all_day_event: bool = False,
        attendees: str = "",
        calendar: Optional[str] = None,
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        description: str = "",
        duration: int = 30,
        end_date_and_time: Any = -1,
        end_time: Any = -1,
        event_id: str = "",
        event_name: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        location: str = "",
        num_messages: int = 10,
        repeat_frequency: str = "",
        repeat_how_many_times: int = 0,
        repeat_until: Any = -1,
        rrule: str = "",
        send_notifications: bool = False,
        send_updates: str = "",
        slot_duration: int = 30,
        start_date_and_time: Any = -1,
        start_datetime: Any = -1,
        start_time: Any = -1,
        timezone: str = "US/Eastern",
        update_attendees: str = "",
        update_color_id: str = "",
        update_description: str = "",
        update_guests_can_invite_others: bool = False,
        update_guests_can_modify: bool = False,
        update_guests_can_see_other_guests: bool = False,
        update_location: str = "",
        update_max_attendees: int = 0,
        update_show_me_as: str = "",
        update_summary: str = "",
        update_visibility: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_google_calendar",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if calendar is not None:
            self.inputs["calendar"] = calendar
        if event_name is not None:
            self.inputs["event_name"] = event_name
        if all_day_event is not None:
            self.inputs["all_day_event"] = all_day_event
        if start_datetime is not None:
            self.inputs["start_datetime"] = start_datetime
        if duration is not None:
            self.inputs["duration"] = duration
        if attendees is not None:
            self.inputs["attendees"] = attendees
        if location is not None:
            self.inputs["location"] = location
        if description is not None:
            self.inputs["description"] = description
        if repeat_frequency is not None:
            self.inputs["repeat_frequency"] = repeat_frequency
        if repeat_how_many_times is not None:
            self.inputs["repeat_how_many_times"] = repeat_how_many_times
        if repeat_until is not None:
            self.inputs["repeat_until"] = repeat_until
        if rrule is not None:
            self.inputs["rrule"] = rrule
        if start_date_and_time is not None:
            self.inputs["start_date_and_time"] = start_date_and_time
        if end_date_and_time is not None:
            self.inputs["end_date_and_time"] = end_date_and_time
        if slot_duration is not None:
            self.inputs["slot_duration"] = slot_duration
        if timezone is not None:
            self.inputs["timezone"] = timezone
        if event_id is not None:
            self.inputs["event_id"] = event_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if query is not None:
            self.inputs["query"] = query
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if update_summary is not None:
            self.inputs["update_summary"] = update_summary
        if update_description is not None:
            self.inputs["update_description"] = update_description
        if update_location is not None:
            self.inputs["update_location"] = update_location
        if start_time is not None:
            self.inputs["start_time"] = start_time
        if end_time is not None:
            self.inputs["end_time"] = end_time
        if update_attendees is not None:
            self.inputs["update_attendees"] = update_attendees
        if update_visibility is not None:
            self.inputs["update_visibility"] = update_visibility
        if update_color_id is not None:
            self.inputs["update_color_id"] = update_color_id
        if update_guests_can_invite_others is not None:
            self.inputs["update_guests_can_invite_others"] = (
                update_guests_can_invite_others
            )
        if update_guests_can_modify is not None:
            self.inputs["update_guests_can_modify"] = update_guests_can_modify
        if update_guests_can_see_other_guests is not None:
            self.inputs["update_guests_can_see_other_guests"] = (
                update_guests_can_see_other_guests
            )
        if update_show_me_as is not None:
            self.inputs["update_show_me_as"] = update_show_me_as
        if update_max_attendees is not None:
            self.inputs["update_max_attendees"] = update_max_attendees
        if send_updates is not None:
            self.inputs["send_updates"] = send_updates
        if send_notifications is not None:
            self.inputs["send_notifications"] = send_notifications
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleCalendarNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
