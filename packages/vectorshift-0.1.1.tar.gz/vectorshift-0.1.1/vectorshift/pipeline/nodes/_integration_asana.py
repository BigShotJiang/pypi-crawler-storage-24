"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_asana")
class IntegrationAsanaNode(Node):
    """
    Asana

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Asana account
    ### search_tasks
        text: Text to search for in task names and descriptions
        assignee: Email of the person to assign the task to
        project: The project to create the task in
        workspace: The Asana workspace
    ### add_task_comment
        text: Text to search for in task names and descriptions
        parent: The task to create the subtask in
        project: The project to create the task in
        section: The section to create the task in
        workspace: The Asana workspace
    ### get_projects
        archived: Whether to include archived projects in the results
        limit: Maximum number of projects to return (1-100)
        team: The team to create the project in
        workspace: The Asana workspace
    ### create_task
        assignee: Email of the person to assign the task to
        due_on: Due date for the task (YYYY-MM-DD format)
        name: The name of the project to create
        notes: Notes or description for the project
        project: The project to create the task in
        section: The section to create the task in
        workspace: The Asana workspace
    ### get_tasks
        assignee: Email of the person to assign the task to
        completed_since: Only return tasks completed after this time (optional)
        project: The project to create the task in
        workspace: The Asana workspace
    ### update_task
        assignee: Email of the person to assign the task to
        completed: Whether to mark the task as completed
        due_on: Due date for the task (YYYY-MM-DD format)
        name: The name of the project to create
        notes: Notes or description for the project
        project: The project to create the task in
        section: The section to create the task in
        task: The task to get details from
        workspace: The Asana workspace
    ### create_subtask
        assignee: Email of the person to assign the task to
        name: The name of the project to create
        notes: Notes or description for the project
        parent: The task to create the subtask in
        project: The project to create the task in
        section: The section to create the task in
        workspace: The Asana workspace
    ### remove_task_comment
        comment_gid: The global ID of the comment to remove
    ### get_subtasks
        limit: Maximum number of projects to return (1-100)
        parent: The task to create the subtask in
        project: The project to create the task in
        section: The section to create the task in
        workspace: The Asana workspace
    ### create_project
        name: The name of the project to create
        notes: Notes or description for the project
        public: Whether the project should be public
        team: The team to create the project in
        workspace: The Asana workspace
    ### update_project
        name: The name of the project to create
        notes: Notes or description for the project
        project: The project to create the task in
        public: Whether the project should be public
        workspace: The Asana workspace
    ### read_project
        project: The project to create the task in
        workspace: The Asana workspace
    ### delete_project
        project: The project to create the task in
        workspace: The Asana workspace
    ### read_task
        project: The project to create the task in
        section: The section to create the task in
        task: The task to get details from
        workspace: The Asana workspace
    ### delete_task
        project: The project to create the task in
        section: The section to create the task in
        task: The task to get details from
        workspace: The Asana workspace
    ### move_task
        project: The project to create the task in
        section: The section to create the task in
        target_project: The project to move the task to
        target_section: The section within the project to move the task to (optional)
        target_workspace: The Asana workspace to move the task to
        task: The task to get details from
        workspace: The Asana workspace
    ### add_task_tag
        project: The project to create the task in
        tag: The tag to add
        task: The task to get details from
        workspace: The Asana workspace
    ### add_task_project
        project: The project to create the task in
        section: The section to create the task in
        task: The task to get details from
    ### remove_task_project
        project: The project to create the task in
        task: The task to get details from
    ### remove_task_tag
        tag: The tag to add
        task: The task to get details from
    ### read_user
        user_gid: The global ID of the user to retrieve (optional, defaults to current user)
    ### get_users
        workspace: The Asana workspace

    ## Outputs
    ### read_task
        assignee_name: The name of the assignee
        completed: Whether the task is completed
        created_at: When the task was created
        data: The full response data from Asana API
        due_on: The due date of the task
        modified_at: When the task was last modified
        task_gid: The global ID of the task
        task_name: The name of the task
        task_notes: The notes/description of the task
    ### add_task_comment
        author_name: The name of the comment author
        comment_gid: The global ID of the created comment
        comment_text: The text of the comment
        created_at: When the comment was created
        data: The full response data from Asana API
    ### read_project
        created_at: When the project was created
        data: The full response data from Asana API
        modified_at: When the project was last modified
        project_gid: The global ID of the project
        project_name: The name of the project
        project_notes: The notes/description of the project
    ### create_project
        data: The full response data from Asana API
        project_gid: The global ID of the created project
        project_name: The name of the created project
        project_url: The URL of the created project
    ### get_projects
        data: The full response data from Asana API
        project_gids: The global IDs of all projects
        project_names: The names of all projects
    ### update_project
        data: The full response data from Asana API
        project_gid: The global ID of the updated project
        project_name: The updated name of the project
    ### create_task
        data: The full response data from Asana API
        task_gid: The global ID of the created task
        task_name: The name of the created task
        task_url: The URL of the created task
    ### get_tasks
        data: The full response data from Asana API
        task_gids: The global IDs of all tasks
        task_names: The names of all tasks
    ### update_task
        data: The full response data from Asana API
        task_gid: The global ID of the updated task
        task_name: The updated name of the task
    ### search_tasks
        data: The full response data from Asana API
        task_gids: The global IDs of matching tasks
        task_names: The names of matching tasks
    ### move_task
        data: The full response data from Asana API
        task_gid: The global ID of the moved task
    ### create_subtask
        data: The full response data from Asana API
        parent_task_gid: The global ID of the parent task
        subtask_gid: The global ID of the created subtask
        subtask_name: The name of the created subtask
    ### get_subtasks
        data: The full response data from Asana API
        subtask_gids: The global IDs of all subtasks
        subtask_names: The names of all subtasks
    ### add_task_tag
        data: The full response data from Asana API
        tag_gid: The global ID of the added tag
        task_gid: The global ID of the task
    ### remove_task_tag
        data: The full response data from Asana API
        tag_gid: The global ID of the removed tag
        task_gid: The global ID of the task
    ### add_task_project
        data: The full response data from Asana API
        project_gid: The global ID of the project
        task_gid: The global ID of the task
    ### remove_task_project
        data: The full response data from Asana API
        project_gid: The global ID of the project
        task_gid: The global ID of the task
    ### read_user
        data: The full response data from Asana API
        user_email: The email of the user
        user_gid: The global ID of the user
        user_name: The name of the user
        workspaces: List of workspace names the user belongs to
    ### get_users
        data: The full response data from Asana API
        user_emails: The emails of all users
        user_gids: The global IDs of all users
        user_names: The names of all users
    ### delete_project
        status_code: The HTTP status code of the response
    ### delete_task
        status_code: The HTTP status code of the response
    ### remove_task_comment
        status_code: The HTTP status code of the response
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Asana account",
            "value": None,
            "type": "integration<Asana>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_project": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Development Team",
                    "helper_text": "The team to create the project in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Project Name",
                    "placeholder": "My New Project",
                    "helper_text": "The name of the project to create",
                    "order": 5,
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Project Notes",
                    "placeholder": "Project description",
                    "helper_text": "Notes or description for the project",
                    "order": 6,
                },
                {
                    "field": "public",
                    "type": "bool",
                    "value": False,
                    "label": "Public Project",
                    "helper_text": "Whether the project should be public",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "project_gid",
                    "type": "string",
                    "helper_text": "The global ID of the created project",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "The name of the created project",
                },
                {
                    "field": "project_url",
                    "type": "string",
                    "helper_text": "The URL of the created project",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "create_project",
            "task_name": "tasks.asana.create_project",
            "description": "Create a new project in Asana",
            "label": "Create Project",
            "ui_sort_order": [
                "integration",
                "action",
                "workspace",
                "team",
                "name",
                "notes",
                "public",
            ],
            "required": ["workspace", "name"],
        },
        "read_project": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "project_gid",
                    "type": "string",
                    "helper_text": "The global ID of the project",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "The name of the project",
                },
                {
                    "field": "project_notes",
                    "type": "string",
                    "helper_text": "The notes/description of the project",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the project was created",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the project was last modified",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "read_project",
            "task_name": "tasks.asana.read_project",
            "description": "Read details of a specific project",
            "label": "Get Project",
            "inputs_sort_order": ["integration", "action", "workspace", "project"],
            "required": ["workspace", "project"],
        },
        "get_projects": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace to get projects from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "team",
                    "type": "string",
                    "value": "",
                    "label": "Team",
                    "placeholder": "Development Team",
                    "helper_text": "The team to get projects from (optional)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=team&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "archived",
                    "type": "bool",
                    "value": False,
                    "label": "Include Archived",
                    "placeholder": False,
                    "helper_text": "Whether to include archived projects in the results",
                    "component": {"agent_field_type": "dynamic", "type": "checkbox"},
                    "order": 5,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 50,
                    "label": "Limit",
                    "placeholder": "50",
                    "helper_text": "Maximum number of projects to return (1-100)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "number",
                        "min": 1,
                        "max": 100,
                    },
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "project_gids",
                    "type": "vec<string>",
                    "helper_text": "The global IDs of all projects",
                },
                {
                    "field": "project_names",
                    "type": "vec<string>",
                    "helper_text": "The names of all projects",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "get_projects",
            "task_name": "tasks.asana.get_projects",
            "description": "Get multiple projects",
            "label": "List Projects",
            "inputs_sort_order": [
                "integration",
                "action",
                "workspace",
                "team",
                "archived",
                "limit",
            ],
            "required": ["workspace"],
        },
        "update_project": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Project Name",
                    "placeholder": "Updated Project Name",
                    "helper_text": "The new name for the project",
                    "order": 4,
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Project Notes",
                    "placeholder": "Updated description",
                    "helper_text": "Updated notes or description for the project",
                    "order": 5,
                },
                {
                    "field": "public",
                    "type": "bool",
                    "value": False,
                    "label": "Public Project",
                    "helper_text": "Whether the project should be public",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "project_gid",
                    "type": "string",
                    "helper_text": "The global ID of the updated project",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "The updated name of the project",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "update_project",
            "task_name": "tasks.asana.update_project",
            "description": "Update an existing project",
            "label": "Update Project",
            "ui_sort_order": [
                "integration",
                "action",
                "workspace",
                "project",
                "name",
                "notes",
                "public",
            ],
            "required": ["workspace", "project"],
        },
        "delete_project": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "string",
                    "helper_text": "The HTTP status code of the response",
                }
            ],
            "name": "delete_project",
            "task_name": "tasks.asana.delete_project",
            "description": "Delete a project",
            "label": "Delete Project",
            "ui_sort_order": ["integration", "action", "workspace", "project"],
            "required": ["workspace", "project"],
        },
        "create_task": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to create the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Task Name",
                    "placeholder": "Complete feature implementation",
                    "helper_text": "The name of the task to create",
                    "order": 6,
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Task Description",
                    "placeholder": "Detailed task description",
                    "helper_text": "Notes or description for the task",
                    "order": 7,
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "placeholder": "john@example.com",
                    "helper_text": "Email of the person to assign the task to",
                    "order": 8,
                },
                {
                    "field": "due_on",
                    "type": "string",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date for the task (YYYY-MM-DD format)",
                    "order": 9,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the created task",
                },
                {
                    "field": "task_name",
                    "type": "string",
                    "helper_text": "The name of the created task",
                },
                {
                    "field": "task_url",
                    "type": "string",
                    "helper_text": "The URL of the created task",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "create_task",
            "task_name": "tasks.asana.create_task",
            "description": "Create a new task in Asana",
            "label": "Create Task",
            "ui_sort_order": [
                "integration",
                "action",
                "workspace",
                "project",
                "name",
                "notes",
                "assignee",
                "due_on",
            ],
            "required": ["workspace", "projects", "name"],
        },
        "read_task": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace to get projects from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to get tasks from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to get tasks from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to get details from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the task",
                },
                {
                    "field": "task_name",
                    "type": "string",
                    "helper_text": "The name of the task",
                },
                {
                    "field": "task_notes",
                    "type": "string",
                    "helper_text": "The notes/description of the task",
                },
                {
                    "field": "completed",
                    "type": "bool",
                    "helper_text": "Whether the task is completed",
                },
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "The name of the assignee",
                },
                {
                    "field": "due_on",
                    "type": "string",
                    "helper_text": "The due date of the task",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the task was created",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "When the task was last modified",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "read_task",
            "task_name": "tasks.asana.read_task",
            "description": "Read details of a specific task",
            "label": "Get Task",
            "inputs_sort_order": [
                "integration",
                "action",
                "workspace",
                "project",
                "task",
            ],
            "required": ["workspace", "project", "task"],
        },
        "get_tasks": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to get tasks from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "label": "Assignee Filter",
                    "placeholder": "john@example.com",
                    "helper_text": "Filter tasks by assignee email (optional)",
                    "order": 5,
                },
                {
                    "field": "completed_since",
                    "type": "timestamp",
                    "value": -1,
                    "label": "Completed Since",
                    "placeholder": "2024-01-01T00:00:00Z",
                    "helper_text": "Only return tasks completed after this time (optional)",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "task_gids",
                    "type": "vec<string>",
                    "helper_text": "The global IDs of all tasks",
                },
                {
                    "field": "task_names",
                    "type": "vec<string>",
                    "helper_text": "The names of all tasks",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "get_tasks",
            "task_name": "tasks.asana.get_tasks",
            "description": "Get multiple tasks",
            "label": "List Tasks",
            "inputs_sort_order": [
                "integration",
                "action",
                "workspace",
                "project",
                "assignee",
                "completed_since",
            ],
            "required": ["workspace", "project"],
        },
        "update_task": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to update the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to update the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Task Name",
                    "placeholder": "Updated task name",
                    "helper_text": "The new name for the task",
                    "order": 4,
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Task Description",
                    "placeholder": "Updated description",
                    "helper_text": "Updated notes or description for the task",
                    "order": 5,
                },
                {
                    "field": "completed",
                    "type": "bool",
                    "value": False,
                    "label": "Mark Completed",
                    "helper_text": "Whether to mark the task as completed",
                    "order": 6,
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "placeholder": "john@example.com",
                    "helper_text": "Email of the person to assign the task to",
                    "order": 7,
                },
                {
                    "field": "due_on",
                    "type": "string",
                    "value": "",
                    "label": "Due Date",
                    "placeholder": "2024-12-31",
                    "helper_text": "Due date for the task (YYYY-MM-DD format)",
                    "order": 8,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the updated task",
                },
                {
                    "field": "task_name",
                    "type": "string",
                    "helper_text": "The updated name of the task",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "update_task",
            "task_name": "tasks.asana.update_task",
            "description": "Update an existing task",
            "label": "Update Task",
            "ui_sort_order": [
                "integration",
                "action",
                "workspace",
                "project",
                "section",
                "task",
                "name",
                "notes",
                "completed",
                "assignee",
                "due_on",
            ],
            "required": ["workspace", "project", "section", "task"],
        },
        "delete_task": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to delete the task from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to delete the task from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "string",
                    "helper_text": "The HTTP status code of the response",
                }
            ],
            "name": "delete_task",
            "task_name": "tasks.asana.delete_task",
            "description": "Delete a task",
            "label": "Delete Task",
            "ui_sort_order": ["integration", "action", "task_gid"],
            "required": ["task_gid"],
        },
        "search_tasks": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace to search in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Search Text",
                    "placeholder": "bug fix",
                    "helper_text": "Text to search for in task names and descriptions",
                    "order": 4,
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "placeholder": "john@example.com",
                    "helper_text": "Filter by assignee email (optional)",
                    "order": 5,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "Filter by specific project (optional)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "task_gids",
                    "type": "vec<string>",
                    "helper_text": "The global IDs of matching tasks",
                },
                {
                    "field": "task_names",
                    "type": "vec<string>",
                    "helper_text": "The names of matching tasks",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "search_tasks",
            "task_name": "tasks.asana.search_tasks",
            "description": "Search for tasks in workspace",
            "label": "Search Tasks",
            "ui_sort_order": [
                "integration",
                "action",
                "workspace",
                "text",
                "assignee",
                "project",
            ],
            "required": ["workspace", "text"],
        },
        "move_task": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Source Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Source Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to update the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Source Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to update the task in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Source Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "target_workspace",
                    "type": "string",
                    "value": "",
                    "label": "Target Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace to move the task to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 7,
                },
                {
                    "field": "target_project",
                    "type": "string",
                    "value": "",
                    "label": "Target Project",
                    "placeholder": "New Project",
                    "helper_text": "The project to move the task to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.target_workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 8,
                },
                {
                    "field": "target_section",
                    "type": "string",
                    "value": "",
                    "label": "Target Section",
                    "placeholder": "In Progress",
                    "helper_text": "The section within the project to move the task to (optional)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.target_workspace}&project={inputs.target_project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 9,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the moved task",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "move_task",
            "task_name": "tasks.asana.move_task",
            "description": "Move a task to a different project or section",
            "label": "Move Task",
            "ui_sort_order": [
                "integration",
                "action",
                "task_gid",
                "project",
                "section",
            ],
            "required": ["task_gid", "project"],
        },
        "create_subtask": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to create the subtask in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to create the subtask in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "parent",
                    "type": "string",
                    "value": "",
                    "label": "Parent Task ID",
                    "placeholder": "My Task",
                    "helper_text": "The task to create the subtask in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Subtask Name",
                    "placeholder": "Complete subtask",
                    "helper_text": "The name of the subtask to create",
                    "order": 4,
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Subtask Description",
                    "placeholder": "Detailed subtask description",
                    "helper_text": "Notes or description for the subtask",
                    "order": 5,
                },
                {
                    "field": "assignee",
                    "type": "string",
                    "value": "",
                    "label": "Assignee",
                    "placeholder": "john@example.com",
                    "helper_text": "Email of the person to assign the subtask to",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "subtask_gid",
                    "type": "string",
                    "helper_text": "The global ID of the created subtask",
                },
                {
                    "field": "subtask_name",
                    "type": "string",
                    "helper_text": "The name of the created subtask",
                },
                {
                    "field": "parent_task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the parent task",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "create_subtask",
            "task_name": "tasks.asana.create_subtask",
            "description": "Create a new subtask under a parent task",
            "label": "Create Subtask",
            "ui_sort_order": [
                "integration",
                "action",
                "parent",
                "name",
                "notes",
                "assignee",
            ],
            "required": ["workspace", "project", "section", "parent", "name"],
        },
        "get_subtasks": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to get subtasks from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to get subtasks from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "parent",
                    "type": "string",
                    "value": "",
                    "label": "Parent Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to get subtasks from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 50,
                    "label": "Limit",
                    "placeholder": "50",
                    "helper_text": "Maximum number of subtasks to return (1-100)",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "number",
                        "min": 1,
                        "max": 100,
                    },
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "subtask_gids",
                    "type": "vec<string>",
                    "helper_text": "The global IDs of all subtasks",
                },
                {
                    "field": "subtask_names",
                    "type": "vec<string>",
                    "helper_text": "The names of all subtasks",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "get_subtasks",
            "task_name": "tasks.asana.get_subtasks",
            "description": "Get multiple subtasks",
            "label": "List Subtasks",
            "inputs_sort_order": ["integration", "action", "parent", "limit"],
            "required": ["parent"],
        },
        "add_task_comment": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to add comment to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section",
                    "placeholder": "My Section",
                    "helper_text": "The section to add comment to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=section&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "parent",
                    "type": "string",
                    "value": "",
                    "label": "Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to add comment to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&section={inputs.section}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 6,
                },
                {
                    "field": "text",
                    "type": "string",
                    "value": "",
                    "label": "Comment Text",
                    "placeholder": "This task is ready for review",
                    "helper_text": "The comment text to add",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "comment_gid",
                    "type": "string",
                    "helper_text": "The global ID of the created comment",
                },
                {
                    "field": "comment_text",
                    "type": "string",
                    "helper_text": "The text of the comment",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "helper_text": "The name of the comment author",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "add_task_comment",
            "task_name": "tasks.asana.add_task_comment",
            "description": "Add a comment to a task",
            "label": "Add Task Comment",
            "ui_sort_order": ["integration", "action", "parent", "text"],
            "required": ["workspace", "project", "section", "parent", "text"],
        },
        "remove_task_comment": {
            "inputs": [
                {
                    "field": "comment_gid",
                    "type": "string",
                    "value": "",
                    "label": "Comment ID",
                    "placeholder": "1234567890",
                    "helper_text": "The global ID of the comment to remove",
                    "order": 3,
                }
            ],
            "outputs": [
                {
                    "field": "status_code",
                    "type": "string",
                    "helper_text": "The HTTP status code of the response",
                }
            ],
            "name": "remove_task_comment",
            "task_name": "tasks.asana.remove_task_comment",
            "description": "Remove a comment from a task",
            "label": "Remove Task Comment",
            "ui_sort_order": ["integration", "action", "comment_gid"],
            "required": ["comment_gid"],
        },
        "add_task_tag": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project",
                    "placeholder": "My Project",
                    "helper_text": "The project to add tag to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=project&workspace={inputs.workspace}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 4,
                },
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task",
                    "placeholder": "My Task",
                    "helper_text": "The task to add tag to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=task&workspace={inputs.workspace}&project={inputs.project}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 5,
                },
                {
                    "field": "tag",
                    "type": "string",
                    "value": "",
                    "label": "Tag",
                    "placeholder": "My Tag",
                    "helper_text": "The tag to add",
                    "component": {"agent_field_type": "dynamic", "type": "dropdown"},
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the task",
                },
                {
                    "field": "tag_gid",
                    "type": "string",
                    "helper_text": "The global ID of the added tag",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "add_task_tag",
            "task_name": "tasks.asana.add_task_tag",
            "description": "Add a tag to a task",
            "label": "Add Task Tag",
            "ui_sort_order": [
                "integration",
                "action",
                "workspace",
                "project",
                "task",
                "tag",
            ],
            "required": ["workspace", "project", "task", "tag"],
        },
        "remove_task_tag": {
            "inputs": [
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "1234567890",
                    "helper_text": "The global ID of the task to remove tag from",
                    "order": 3,
                },
                {
                    "field": "tag",
                    "type": "string",
                    "value": "",
                    "label": "Tag ID",
                    "placeholder": "0987654321",
                    "helper_text": "The global ID of the tag to remove",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the task",
                },
                {
                    "field": "tag_gid",
                    "type": "string",
                    "helper_text": "The global ID of the removed tag",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "remove_task_tag",
            "task_name": "tasks.asana.remove_task_tag",
            "description": "Remove a tag from a task",
            "label": "Remove Task Tag",
            "ui_sort_order": ["integration", "action", "task", "tag"],
            "required": ["task", "tag"],
        },
        "add_task_project": {
            "inputs": [
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "1234567890",
                    "helper_text": "The global ID of the task to add to project",
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "0987654321",
                    "helper_text": "The global ID of the project to add task to",
                    "order": 4,
                },
                {
                    "field": "section",
                    "type": "string",
                    "value": "",
                    "label": "Section ID",
                    "placeholder": "1122334455",
                    "helper_text": "The global ID of the section within the project (optional)",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the task",
                },
                {
                    "field": "project_gid",
                    "type": "string",
                    "helper_text": "The global ID of the project",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "add_task_project",
            "task_name": "tasks.asana.add_task_project",
            "description": "Add a task to a project",
            "label": "Add Task to Project",
            "ui_sort_order": ["integration", "action", "task", "project", "section"],
            "required": ["task", "project"],
        },
        "remove_task_project": {
            "inputs": [
                {
                    "field": "task",
                    "type": "string",
                    "value": "",
                    "label": "Task ID",
                    "placeholder": "1234567890",
                    "helper_text": "The global ID of the task to remove from project",
                    "order": 3,
                },
                {
                    "field": "project",
                    "type": "string",
                    "value": "",
                    "label": "Project ID",
                    "placeholder": "0987654321",
                    "helper_text": "The global ID of the project to remove task from",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "task_gid",
                    "type": "string",
                    "helper_text": "The global ID of the task",
                },
                {
                    "field": "project_gid",
                    "type": "string",
                    "helper_text": "The global ID of the project",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "remove_task_project",
            "task_name": "tasks.asana.remove_task_project",
            "description": "Remove a task from a project",
            "label": "Remove Task from Project",
            "ui_sort_order": ["integration", "action", "task", "project"],
            "required": ["task", "project"],
        },
        "read_user": {
            "inputs": [
                {
                    "field": "user_gid",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "1234567890",
                    "helper_text": "The global ID of the user to retrieve (optional, defaults to current user)",
                    "order": 3,
                }
            ],
            "outputs": [
                {
                    "field": "user_gid",
                    "type": "string",
                    "helper_text": "The global ID of the user",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "The name of the user",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "The email of the user",
                },
                {
                    "field": "workspaces",
                    "type": "vec<string>",
                    "helper_text": "List of workspace names the user belongs to",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "read_user",
            "task_name": "tasks.asana.read_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "inputs_sort_order": ["integration", "action", "user_gid"],
            "required": ["user_gid"],
        },
        "get_users": {
            "inputs": [
                {
                    "field": "workspace",
                    "type": "string",
                    "value": "",
                    "label": "Workspace",
                    "placeholder": "My Workspace",
                    "helper_text": "The Asana workspace to get users from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                    "order": 3,
                }
            ],
            "outputs": [
                {
                    "field": "user_gids",
                    "type": "vec<string>",
                    "helper_text": "The global IDs of all users",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "The names of all users",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "The emails of all users",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The full response data from Asana API",
                },
            ],
            "name": "get_users",
            "task_name": "tasks.asana.get_users",
            "description": "Get multiple users from a workspace",
            "label": "List Users",
            "inputs_sort_order": ["integration", "action", "workspace"],
            "required": ["workspace"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        text: str = "",
        archived: bool = False,
        assignee: str = "",
        comment_gid: str = "",
        completed: bool = False,
        completed_since: Any = -1,
        due_on: str = "",
        limit: int = 50,
        name: str = "",
        notes: str = "",
        parent: str = "",
        project: str = "",
        public: bool = False,
        section: str = "",
        tag: str = "",
        target_project: str = "",
        target_section: str = "",
        target_workspace: str = "",
        task: str = "",
        team: str = "",
        user_gid: str = "",
        workspace: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_asana",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if workspace is not None:
            self.inputs["workspace"] = workspace
        if team is not None:
            self.inputs["team"] = team
        if name is not None:
            self.inputs["name"] = name
        if notes is not None:
            self.inputs["notes"] = notes
        if public is not None:
            self.inputs["public"] = public
        if project is not None:
            self.inputs["project"] = project
        if archived is not None:
            self.inputs["archived"] = archived
        if limit is not None:
            self.inputs["limit"] = limit
        if section is not None:
            self.inputs["section"] = section
        if assignee is not None:
            self.inputs["assignee"] = assignee
        if due_on is not None:
            self.inputs["due_on"] = due_on
        if task is not None:
            self.inputs["task"] = task
        if completed_since is not None:
            self.inputs["completed_since"] = completed_since
        if completed is not None:
            self.inputs["completed"] = completed
        if text is not None:
            self.inputs["text"] = text
        if target_workspace is not None:
            self.inputs["target_workspace"] = target_workspace
        if target_project is not None:
            self.inputs["target_project"] = target_project
        if target_section is not None:
            self.inputs["target_section"] = target_section
        if parent is not None:
            self.inputs["parent"] = parent
        if comment_gid is not None:
            self.inputs["comment_gid"] = comment_gid
        if tag is not None:
            self.inputs["tag"] = tag
        if user_gid is not None:
            self.inputs["user_gid"] = user_gid
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationAsanaNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
