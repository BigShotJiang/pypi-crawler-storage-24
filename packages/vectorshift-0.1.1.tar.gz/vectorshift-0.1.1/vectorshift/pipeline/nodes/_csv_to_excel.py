"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("csv_to_excel")
class CsvToExcelNode(Node):
    """
    Convert a CSV file into XLSX.

    ## Inputs
    ### Common Inputs
        csv_file: The CSV file to convert.
        horizontal_alignment: The horizontal alignment of the text
        max_column_width: The maximum width of the columns
        vertical_alignment: The vertical alignment of the text
        wrap_text: Enable text wrapping

    ## Outputs
    ### Common Outputs
        xlsx_file: The Excel file created.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "csv_file",
            "helper_text": "The CSV file to convert.",
            "value": None,
            "type": "file",
        },
        {
            "field": "horizontal_alignment",
            "helper_text": "The horizontal alignment of the text",
            "value": "left",
            "type": "string",
        },
        {
            "field": "max_column_width",
            "helper_text": "The maximum width of the columns",
            "value": 100,
            "type": "int32",
        },
        {
            "field": "vertical_alignment",
            "helper_text": "The vertical alignment of the text",
            "value": "top",
            "type": "string",
        },
        {
            "field": "wrap_text",
            "helper_text": "Enable text wrapping",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "xlsx_file", "helper_text": "The Excel file created.", "type": "file"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    def __init__(
        self,
        csv_file: Optional[str] = None,
        horizontal_alignment: str = "left",
        max_column_width: int = 100,
        vertical_alignment: str = "top",
        wrap_text: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="csv_to_excel",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if csv_file is not None:
            self.inputs["csv_file"] = csv_file
        if wrap_text is not None:
            self.inputs["wrap_text"] = wrap_text
        if max_column_width is not None:
            self.inputs["max_column_width"] = max_column_width
        if horizontal_alignment is not None:
            self.inputs["horizontal_alignment"] = horizontal_alignment
        if vertical_alignment is not None:
            self.inputs["vertical_alignment"] = vertical_alignment
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CsvToExcelNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
