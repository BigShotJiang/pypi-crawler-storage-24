"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("nl_to_sql")
class NlToSqlNode(Node):
    """
    Convert natural language queries to SQL queries.

    ## Inputs
    ### Common Inputs
        model: The model to use for the conversion
        text: The natural language query to convert to SQL
        db_dialect: The database dialect to use
        schema: The schema of the database

    ## Outputs
    ### Common Outputs
        sql_query: The SQL query generated from the natural language query
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The model to use for the conversion",
            "value": "gpt-4o",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The natural language query to convert to SQL",
            "value": "",
            "type": "string",
        },
        {
            "field": "db_dialect",
            "helper_text": "The database dialect to use",
            "value": "PostgreSQL",
            "type": "string",
        },
        {
            "field": "schema",
            "helper_text": "The schema of the database",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "sql_query",
            "helper_text": "The SQL query generated from the natural language query",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text", "db_dialect", "schema"]

    def __init__(
        self,
        model: str = "gpt-4o",
        text: str = "",
        db_dialect: str = "PostgreSQL",
        schema: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="nl_to_sql",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if db_dialect is not None:
            self.inputs["db_dialect"] = db_dialect
        if schema is not None:
            self.inputs["schema"] = schema
        if text is not None:
            self.inputs["text"] = text
        if model is not None:
            self.inputs["model"] = model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "NlToSqlNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
