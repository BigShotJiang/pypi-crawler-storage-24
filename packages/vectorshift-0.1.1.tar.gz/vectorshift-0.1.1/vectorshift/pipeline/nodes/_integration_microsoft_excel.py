"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_microsoft_excel")
class IntegrationMicrosoftExcelNode(Node):
    """
    Microsoft Excel 365

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your Microsoft Excel 365 account
    ### When action = 'append_table_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'append_worksheet_rows' and endpoint_1 = '[endpoint_1.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'update_worksheet' and endpoint_1 = '[endpoint_1.<A>]'
        [<A>.inputs]: The [<A>.inputs] input
    ### When action = 'list_worksheets'
        fields: Comma-separated list of fields to include in response (e.g., id,name,position)
        limit: Maximum number of columns to return (default: 10)
        return_all: When enabled, returns all columns (ignores limit)
        workbook_id: Select the workbook
    ### When action = 'list_workbooks'
        fields: Comma-separated list of fields to include in response (e.g., id,name,position)
        limit: Maximum number of columns to return (default: 10)
        return_all: When enabled, returns all columns (ignores limit)
    ### When action = 'create_table'
        has_headers: Whether the range has header row
        range_address: The range address for the table (e.g., A1:D10)
        worksheet_id: Select the sheet from your workbook
    ### When action = 'get_table_columns'
        limit: Maximum number of columns to return (default: 10)
        return_all: When enabled, returns all columns (ignores limit)
        table_id: Select the table from your workbook
    ### When action = 'get_table_rows'
        limit: Maximum number of columns to return (default: 10)
        return_all: When enabled, returns all columns (ignores limit)
        table_id: Select the table from your workbook
    ### When action = 'lookup_table'
        limit: Maximum number of columns to return (default: 10)
        lookup_column: Column name to search in
        lookup_value: Value to search for
        return_all: When enabled, returns all columns (ignores limit)
        table_id: Select the table from your workbook
    ### When action = 'get_worksheet_rows'
        limit: Maximum number of columns to return (default: 10)
        range_address: The range address for the table (e.g., A1:D10)
        return_all: When enabled, returns all columns (ignores limit)
        worksheet_id: Select the sheet from your workbook
    ### When action = 'upsert_worksheet'
        mode: Choose append or update mode
        row_data: JSON object or array of objects with column-value pairs (e.g., {"Name": "John", "Age": 30} or [{"Name": "John"}, {"Name": "Jane"}])
        search_column: Column name to search for matching rows (used only in Update mode)
        search_value: Value to search for in the search column (used only in Update mode)
        worksheet_id: Select the sheet from your workbook
    ### When action = 'clear_worksheet'
        range_address: The range address for the table (e.g., A1:D10)
        worksheet_id: Select the sheet from your workbook
    ### When action = 'append_table_rows'
        table_id: Select the table from your workbook
    ### When action = 'convert_table_to_range'
        table_id: Select the table from your workbook
    ### When action = 'delete_table'
        table_id: Select the table from your workbook
    ### When action = 'add_worksheet'
        workbook_id: Select the workbook
        worksheet_name: Name for the new sheet
    ### When action = 'delete_workbook'
        workbook_id: Select the workbook
    ### When action = 'append_worksheet_rows'
        worksheet_id: Select the sheet from your workbook
    ### When action = 'update_worksheet'
        worksheet_id: Select the sheet from your workbook
    ### When action = 'delete_worksheet'
        worksheet_id: Select the sheet from your workbook

    ## Outputs
    ### When action = 'get_table_columns' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'get_table_rows' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'lookup_table' and endpoint_0 = '[endpoint_0.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'get_worksheet_rows' and endpoint_1 = '[endpoint_1.<A>]'
        [<A>.outputs]: The [<A>.outputs] output
    ### When action = 'update_worksheet'
        cells_updated: Number of cells that were updated
        matched_rows: List of row numbers that matched the search criteria
        raw_data: Raw Data
        rows_updated: Number of rows that were updated
    ### When action = 'upsert_worksheet'
        cells_updated: Number of cells that were updated
        matched_rows: List of row numbers that were affected
        raw_data: Raw Data
        rows_updated: Number of rows that were updated or appended
    ### When action = 'clear_worksheet'
        cleared_range: Cleared Range
        raw_data: Raw Data
        worksheet_id: Sheet ID
    ### When action = 'get_table_columns'
        column_names: List of column names
        raw_data: Raw JSON response data
        total_count: Total number of columns found
    ### When action = 'delete_table'
        deleted_table_id: Deleted Table ID
        raw_data: Raw Data
    ### When action = 'delete_workbook'
        deleted_workbook_id: Deleted Workbook ID
        raw_data: Raw Data
    ### When action = 'delete_worksheet'
        deleted_worksheet_id: Deleted Sheet ID
        raw_data: Raw Data
    ### When action = 'convert_table_to_range'
        range_address: Range Address
        raw_data: Raw Data
    ### When action = 'create_table'
        raw_data: Raw Data
        table_id: Table ID
        table_name: Table Name
    ### When action = 'get_table_rows'
        raw_data: Raw Data
    ### When action = 'lookup_table'
        raw_data: Raw Data
    ### When action = 'append_table_rows'
        raw_data: Raw Data
    ### When action = 'add_worksheet'
        raw_data: Raw Data
        worksheet_id: Sheet ID
        worksheet_name: Sheet Name
    ### When action = 'list_worksheets'
        raw_data: Raw JSON response data
        total_count: Total number of sheets found
        worksheet_ids: List of sheet IDs
        worksheet_names: List of sheet names
    ### When action = 'get_worksheet_rows'
        raw_data: Raw Data
    ### When action = 'append_worksheet_rows'
        raw_data: Raw Data
    ### When action = 'list_workbooks'
        raw_data: Raw JSON response data
        total_count: Total number of workbooks found
        workbook_ids: List of workbook IDs
        workbook_names: List of workbook names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your Microsoft Excel 365 account",
            "value": None,
            "type": "integration<Microsoft Excel>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_table**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                },
                {
                    "field": "range_address",
                    "type": "string",
                    "value": "",
                    "label": "Range Address",
                    "helper_text": "The range address for the table (e.g., A1:D10)",
                    "placeholder": "A1:D10",
                },
                {
                    "field": "has_headers",
                    "type": "bool",
                    "value": True,
                    "label": "Has Headers",
                    "helper_text": "Whether the range has header row",
                },
            ],
            "outputs": [
                {"field": "table_id", "type": "string", "helper_text": "Table ID"},
                {"field": "table_name", "type": "string", "helper_text": "Table Name"},
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "create_table",
            "task_name": "tasks.microsoft_excel.create_table",
            "description": "Create a new table from a range",
            "label": "Create Table",
            "required": ["worksheet_id", "range_address"],
            "inputs_sort_order": [
                "integration",
                "action",
                "worksheet_id",
                "range_address",
                "has_headers",
            ],
        },
        "get_table_columns**(*)**(*)": {
            "inputs": [
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Table",
                    "helper_text": "Select the table from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "When enabled, returns all columns (ignores limit)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of columns to return (default: 10)",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of columns found",
                },
                {
                    "field": "column_names",
                    "type": "vec<string>",
                    "helper_text": "List of column names",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_table_columns",
            "task_name": "tasks.microsoft_excel.get_table_columns",
            "description": "Get the columns of an Excel table",
            "label": "Get Table Columns",
            "required": ["table_id", "return_all"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_id",
                "return_all",
                "limit",
            ],
        },
        "get_table_columns**[endpoint_0.<A>]**(*)": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "get_table_rows**(*)**(*)": {
            "inputs": [
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Table",
                    "helper_text": "Select the table from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "When enabled, returns all rows (ignores limit)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return (default: 10)",
                },
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"}
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_table_rows",
            "task_name": "tasks.microsoft_excel.get_table_rows",
            "description": "Get all rows from an Excel table",
            "label": "Get Table Rows",
            "required": ["table_id", "return_all"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_id",
                "return_all",
                "limit",
            ],
        },
        "get_table_rows**[endpoint_0.<A>]**(*)": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "lookup_table**(*)**(*)": {
            "inputs": [
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Table",
                    "helper_text": "Select the table from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                },
                {
                    "field": "lookup_column",
                    "type": "string",
                    "value": "",
                    "label": "Lookup Column",
                    "helper_text": "Column name to search in",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_name&table_id={inputs.table_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "lookup_value",
                    "type": "string",
                    "value": "",
                    "label": "Lookup Value",
                    "helper_text": "Value to search for",
                    "placeholder": "Enter value to search",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "When enabled, returns all matching rows (may be slow for large tables)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 1,
                    "label": "Limit",
                    "helper_text": "Maximum number of matching rows to return (default: 1)",
                },
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"}
            ],
            "variant": "common_integration_file_nodes",
            "name": "lookup_table",
            "task_name": "tasks.microsoft_excel.lookup_table",
            "description": "Find rows that match a value in a specific column",
            "label": "Lookup Table",
            "required": ["table_id", "lookup_column", "lookup_value", "return_all"],
            "inputs_sort_order": [
                "integration",
                "action",
                "table_id",
                "lookup_column",
                "lookup_value",
                "return_all",
                "limit",
            ],
        },
        "lookup_table**[endpoint_0.<A>]**(*)": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "append_table_rows**(*)**(*)": {
            "inputs": [
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Table",
                    "helper_text": "Select the table from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"}
            ],
            "variant": "common_integration_file_nodes",
            "name": "append_table_rows",
            "task_name": "tasks.microsoft_excel.append_table_rows",
            "description": "Add rows to the end of an Excel table using column-based inputs",
            "label": "Append Table Rows",
            "required": ["table_id"],
            "inputs_sort_order": ["integration", "action", "table_id"],
        },
        "append_table_rows**[endpoint_0.<A>]**(*)": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "convert_table_to_range**(*)**(*)": {
            "inputs": [
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Table",
                    "helper_text": "Select the table to convert from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "range_address",
                    "type": "string",
                    "helper_text": "Range Address",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "convert_table_to_range",
            "task_name": "tasks.microsoft_excel.convert_table_to_range",
            "description": "Convert an Excel table to a regular range",
            "label": "Convert Table to Range",
            "required": ["table_id"],
            "inputs_sort_order": ["integration", "action", "table_id"],
        },
        "delete_table**(*)**(*)": {
            "inputs": [
                {
                    "field": "table_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Table",
                    "helper_text": "Select the table to delete from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                }
            ],
            "outputs": [
                {
                    "field": "deleted_table_id",
                    "type": "string",
                    "helper_text": "Deleted Table ID",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_table",
            "task_name": "tasks.microsoft_excel.delete_table",
            "description": "Delete an Excel table",
            "label": "Delete Table",
            "required": ["table_id"],
            "inputs_sort_order": ["integration", "action", "table_id"],
        },
        "add_worksheet**(*)**(*)": {
            "inputs": [
                {
                    "field": "workbook_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Workbook",
                    "helper_text": "Select the workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=workbook",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["workbook"],
                    },
                },
                {
                    "field": "worksheet_name",
                    "type": "string",
                    "value": "",
                    "label": "Sheet Name",
                    "helper_text": "Name for the new sheet",
                    "placeholder": "Enter sheet name",
                },
            ],
            "outputs": [
                {"field": "worksheet_id", "type": "string", "helper_text": "Sheet ID"},
                {
                    "field": "worksheet_name",
                    "type": "string",
                    "helper_text": "Sheet Name",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "add_worksheet",
            "task_name": "tasks.microsoft_excel.add_worksheet",
            "description": "Add a new sheet to a workbook",
            "label": "Add Sheet",
            "required": ["workbook_id", "worksheet_name"],
            "inputs_sort_order": [
                "integration",
                "action",
                "workbook_id",
                "worksheet_name",
            ],
        },
        "list_worksheets**(*)**(*)": {
            "inputs": [
                {
                    "field": "workbook_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Workbook",
                    "helper_text": "Select the workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=workbook",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["workbook"],
                    },
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "When enabled, returns all sheets (ignores limit)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of sheets to return (default: 10)",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "helper_text": "Comma-separated list of fields to include in response (e.g., id,name,position)",
                    "placeholder": "id, name, position",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of sheets found",
                },
                {
                    "field": "worksheet_names",
                    "type": "vec<string>",
                    "helper_text": "List of sheet names",
                },
                {
                    "field": "worksheet_ids",
                    "type": "vec<string>",
                    "helper_text": "List of sheet IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response data",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "list_worksheets",
            "task_name": "tasks.microsoft_excel.list_worksheets",
            "description": "List all sheets in a workbook",
            "label": "List Sheets",
            "required": ["workbook_id", "return_all"],
            "inputs_sort_order": [
                "integration",
                "action",
                "workbook_id",
                "return_all",
                "limit",
                "fields",
            ],
        },
        "get_worksheet_rows**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                },
                {
                    "field": "range_address",
                    "type": "string",
                    "value": "",
                    "label": "Range (Optional)",
                    "helper_text": "Specific range to read (e.g., A1:D10). Leave empty to read used range",
                    "placeholder": "A1:D10",
                },
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "When enabled, returns all rows (ignores limit)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return (default: 10)",
                },
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"}
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_worksheet_rows",
            "task_name": "tasks.microsoft_excel.get_worksheet_rows",
            "description": "Read rows from a sheet",
            "label": "Get Sheet Rows",
            "required": ["worksheet_id", "return_all"],
            "inputs_sort_order": [
                "integration",
                "action",
                "worksheet_id",
                "range_address",
                "return_all",
                "limit",
            ],
        },
        "get_worksheet_rows**(*)**[endpoint_1.<A>]": {
            "inputs": [],
            "outputs": [{"field": "[<A>.outputs]", "type": ""}],
        },
        "append_worksheet_rows**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                }
            ],
            "outputs": [
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"}
            ],
            "variant": "common_integration_file_nodes",
            "name": "append_worksheet_rows",
            "task_name": "tasks.microsoft_excel.append_worksheet_rows",
            "description": "Append data to the end of a sheet using column-based inputs",
            "label": "Append Sheet Rows",
            "required": ["worksheet_id"],
            "inputs_sort_order": ["integration", "action", "worksheet_id"],
        },
        "append_worksheet_rows**(*)**[endpoint_1.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "update_worksheet**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                }
            ],
            "outputs": [
                {
                    "field": "rows_updated",
                    "type": "int32",
                    "helper_text": "Number of rows that were updated",
                },
                {
                    "field": "cells_updated",
                    "type": "int32",
                    "helper_text": "Number of cells that were updated",
                },
                {
                    "field": "matched_rows",
                    "type": "vec<int32>",
                    "helper_text": "List of row numbers that matched the search criteria",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "update_worksheet",
            "task_name": "tasks.microsoft_excel.update_worksheet",
            "description": "Update rows in a sheet by searching and replacing column values",
            "label": "Update Sheet",
            "required": ["worksheet_id"],
            "inputs_sort_order": ["integration", "action", "worksheet_id"],
        },
        "update_worksheet**(*)**[endpoint_1.<A>]": {
            "inputs": [{"field": "[<A>.inputs]", "type": ""}],
            "outputs": [],
        },
        "upsert_worksheet**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                },
                {
                    "field": "mode",
                    "type": "string",
                    "value": "append",
                    "label": "Mode",
                    "helper_text": "Choose append or update mode",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Append", "value": "append"},
                            {"label": "Update", "value": "update"},
                        ],
                    },
                },
                {
                    "field": "row_data",
                    "type": "string",
                    "value": "",
                    "label": "Row Data (JSON)",
                    "helper_text": 'JSON object or array of objects with column-value pairs (e.g., {"Name": "John", "Age": 30} or [{"Name": "John"}, {"Name": "Jane"}])',
                    "placeholder": '{"Name": "John", "Age": 30}',
                },
                {
                    "field": "search_column",
                    "type": "string",
                    "value": "",
                    "label": "Search Column (for Update)",
                    "helper_text": "Column name to search for matching rows (used only in Update mode)",
                    "placeholder": "Name",
                },
                {
                    "field": "search_value",
                    "type": "string",
                    "value": "",
                    "label": "Search Value (for Update)",
                    "helper_text": "Value to search for in the search column (used only in Update mode)",
                    "placeholder": "John",
                },
            ],
            "outputs": [
                {
                    "field": "rows_updated",
                    "type": "int32",
                    "helper_text": "Number of rows that were updated or appended",
                },
                {
                    "field": "cells_updated",
                    "type": "int32",
                    "helper_text": "Number of cells that were updated",
                },
                {
                    "field": "matched_rows",
                    "type": "vec<int32>",
                    "helper_text": "List of row numbers that were affected",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "upsert_worksheet",
            "task_name": "tasks.microsoft_excel.upsert_worksheet",
            "description": "Append new rows or update existing rows in a sheet",
            "label": "Create or Update Sheet",
            "required": ["worksheet_id", "row_data"],
            "inputs_sort_order": [
                "integration",
                "action",
                "worksheet_id",
                "mode",
                "row_data",
                "search_column",
                "search_value",
            ],
        },
        "clear_worksheet**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                },
                {
                    "field": "range_address",
                    "type": "string",
                    "value": "",
                    "label": "Range (Optional)",
                    "helper_text": "Specific range to clear (e.g., A1:D10). Leave empty to clear all",
                    "placeholder": "A1:D10",
                },
            ],
            "outputs": [
                {"field": "worksheet_id", "type": "string", "helper_text": "Sheet ID"},
                {
                    "field": "cleared_range",
                    "type": "string",
                    "helper_text": "Cleared Range",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "clear_worksheet",
            "task_name": "tasks.microsoft_excel.clear_worksheet",
            "description": "Clear contents of a sheet or range",
            "label": "Clear Sheet",
            "required": ["worksheet_id"],
            "inputs_sort_order": [
                "integration",
                "action",
                "worksheet_id",
                "range_address",
            ],
        },
        "delete_worksheet**(*)**(*)": {
            "inputs": [
                {
                    "field": "worksheet_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Sheet",
                    "helper_text": "Select the sheet to delete from your workbook",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=worksheet",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["worksheet"],
                    },
                }
            ],
            "outputs": [
                {
                    "field": "deleted_worksheet_id",
                    "type": "string",
                    "helper_text": "Deleted Sheet ID",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_worksheet",
            "task_name": "tasks.microsoft_excel.delete_worksheet",
            "description": "Delete a sheet from a workbook",
            "label": "Delete Sheet",
            "required": ["worksheet_id"],
            "inputs_sort_order": ["integration", "action", "worksheet_id"],
        },
        "list_workbooks**(*)**(*)": {
            "inputs": [
                {
                    "field": "return_all",
                    "type": "bool",
                    "value": False,
                    "label": "Return All",
                    "helper_text": "When enabled, returns all workbooks (ignores limit)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of workbooks to return (default: 10)",
                },
                {
                    "field": "fields",
                    "type": "string",
                    "value": "",
                    "label": "Fields",
                    "helper_text": "Comma-separated list of fields to include in response (e.g., id,name,webUrl)",
                    "placeholder": "id, name, webUrl",
                },
            ],
            "outputs": [
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of workbooks found",
                },
                {
                    "field": "workbook_names",
                    "type": "vec<string>",
                    "helper_text": "List of workbook names",
                },
                {
                    "field": "workbook_ids",
                    "type": "vec<string>",
                    "helper_text": "List of workbook IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response data",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "list_workbooks",
            "task_name": "tasks.microsoft_excel.list_workbooks",
            "description": "List all Excel workbooks from OneDrive",
            "label": "List Workbooks",
            "required": ["return_all"],
            "inputs_sort_order": [
                "integration",
                "action",
                "return_all",
                "limit",
                "fields",
            ],
        },
        "delete_workbook**(*)**(*)": {
            "inputs": [
                {
                    "field": "workbook_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Workbook",
                    "helper_text": "Select the workbook to delete",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}&type=workbook",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "selectable_types": ["workbook"],
                    },
                }
            ],
            "outputs": [
                {
                    "field": "deleted_workbook_id",
                    "type": "string",
                    "helper_text": "Deleted Workbook ID",
                },
                {"field": "raw_data", "type": "string", "helper_text": "Raw Data"},
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_workbook",
            "task_name": "tasks.microsoft_excel.delete_workbook",
            "description": "Delete an Excel workbook",
            "label": "Delete Workbook",
            "required": ["workbook_id"],
            "inputs_sort_order": ["integration", "action", "workbook_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "endpoint_0", "endpoint_1"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        fields: str = "",
        has_headers: bool = True,
        limit: int = 10,
        lookup_column: str = "",
        lookup_value: str = "",
        mode: str = "append",
        range_address: str = "",
        return_all: bool = False,
        row_data: str = "",
        search_column: str = "",
        search_value: str = "",
        table_id: str = "",
        workbook_id: str = "",
        worksheet_id: str = "",
        worksheet_name: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_microsoft_excel",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if worksheet_id is not None:
            self.inputs["worksheet_id"] = worksheet_id
        if range_address is not None:
            self.inputs["range_address"] = range_address
        if has_headers is not None:
            self.inputs["has_headers"] = has_headers
        if table_id is not None:
            self.inputs["table_id"] = table_id
        if return_all is not None:
            self.inputs["return_all"] = return_all
        if limit is not None:
            self.inputs["limit"] = limit
        if lookup_column is not None:
            self.inputs["lookup_column"] = lookup_column
        if lookup_value is not None:
            self.inputs["lookup_value"] = lookup_value
        if workbook_id is not None:
            self.inputs["workbook_id"] = workbook_id
        if worksheet_name is not None:
            self.inputs["worksheet_name"] = worksheet_name
        if fields is not None:
            self.inputs["fields"] = fields
        if mode is not None:
            self.inputs["mode"] = mode
        if row_data is not None:
            self.inputs["row_data"] = row_data
        if search_column is not None:
            self.inputs["search_column"] = search_column
        if search_value is not None:
            self.inputs["search_value"] = search_value
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMicrosoftExcelNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
