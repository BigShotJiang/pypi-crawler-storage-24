"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("trigger_linear")
class TriggerLinearNode(Node):
    """
    Linear Trigger

    ## Inputs
    ### Common Inputs
        event: The event input
        integration: The integration input
        item_id: Select the Linear team to watch
        trigger_enabled: Enable/Disable Automation

    ## Outputs
    ### issue_removed
        action: Action performed (remove)
        assignee_email: Email of the assignee
        assignee_name: Name of the assignee
        created_at: When the issue was created
        creator_email: Email of the creator
        creator_name: Name of the creator
        description: Description of the issue
        id: Unique identifier of the issue
        identifier: Issue identifier (e.g., ENG-123)
        parent_id: Parent issue ID if this was a sub-issue
        priority: Priority level
        raw_data: Issue data before removal as JSON
        state: State when removed
        team_key: Team key
        team_name: Team name
        title: Title of the issue
        trigger_timestamp: When this trigger was activated
        updated_at: When the issue was last updated
        url: URL to the issue
    ### comment_removed
        action: Action performed (remove)
        comment_body: Content of the comment before removal
        created_at: When the comment was created
        edited_at: When the comment was last edited
        id: Unique identifier of the comment
        issue_identifier: Related issue identifier (e.g., ENG-123)
        issue_title: Related issue title
        issue_url: URL to the related issue
        raw_data: Comment data before removal as JSON
        trigger_timestamp: When this trigger was activated
        updated_at: When the comment was last updated
        url: URL to the comment
        user_email: Email of the comment creator
        user_name: Name of the comment creator
    ### project_removed
        action: Action performed (remove)
        color: Project color
        content: Project content
        created_at: When the project was created
        description: Project description
        id: Unique identifier of the project
        priority: Priority level
        project_name: Name of the project
        raw_data: Project data before removal as JSON
        slug_id: Project slug identifier
        start_date: Project start date
        status_color: Status color
        status_name: Status name
        status_type: Status type
        target_date: Project target date
        trigger_timestamp: When this trigger was activated
        updated_at: When the project was last updated
        url: URL to the project
    ### cycle_removed
        action: Action performed (remove)
        created_at: When the cycle was created
        description: Cycle description
        ends_at: Cycle end date
        id: Unique identifier of the cycle
        is_active: Whether the cycle is currently active
        is_future: Whether the cycle is in the future
        is_past: Whether the cycle is past
        number: Cycle number
        raw_data: Cycle data before removal as JSON
        starts_at: Cycle start date
        team_id: Team ID
        trigger_timestamp: When this trigger was activated
        updated_at: When the cycle was last updated
        url: URL to the cycle
    ### issue_label_created
        action: Action performed (create)
        created_at: When the label was created
        id: Unique identifier of the label
        is_group: Whether the label is a group
        label_color: Color of the label
        label_description: Description of the label
        label_name: Name of the label
        last_applied_at: When the label was last applied
        raw_data: Complete label data as JSON
        team_id: Team ID
        trigger_timestamp: When this trigger was activated
        updated_at: When the label was last updated
        url: URL to the label
    ### issue_label_updated
        action: Action performed (update)
        created_at: When the label was created
        id: Unique identifier of the label
        is_group: Whether the label is a group
        label_color: Color of the label
        label_description: Description of the label
        label_name: Name of the label
        last_applied_at: When the label was last applied
        raw_data: Complete label data as JSON
        team_id: Team ID
        trigger_timestamp: When this trigger was activated
        updated_at: When the label was last updated
        updated_from: Previous values before the update as JSON
        url: URL to the label
    ### issue_label_removed
        action: Action performed (remove)
        created_at: When the label was created
        id: Unique identifier of the label
        is_group: Whether the label is a group
        label_color: Color of the label
        label_description: Description of the label
        label_name: Name of the label
        last_applied_at: When the label was last applied
        raw_data: Label data before removal as JSON
        team_id: Team ID
        trigger_timestamp: When this trigger was activated
        updated_at: When the label was last updated
        url: URL to the label
    ### reaction_removed
        action: Action performed (remove)
        comment_body: Comment body if reaction is on a comment
        comment_id: Comment ID if reaction is on a comment
        created_at: When the reaction was created
        id: Unique identifier of the reaction
        issue_identifier: Issue identifier if reaction is on an issue
        issue_title: Issue title if reaction is on an issue
        issue_url: Issue URL if reaction is on an issue
        raw_data: Reaction data before removal as JSON
        reaction_emoji: Emoji of the reaction
        trigger_timestamp: When this trigger was activated
        updated_at: When the reaction was last updated
        user_email: Email of the user who reacted
        user_name: Name of the user who reacted
    ### issue_created
        assignee_email: Email of the assignee
        assignee_name: Name of the assignee
        created_at: When the issue was created
        creator_email: Email of the creator
        creator_name: Name of the creator
        description: Description of the issue
        id: Unique identifier of the issue
        identifier: Issue identifier (e.g., ENG-123)
        parent_id: Parent issue ID if this is a sub-issue
        priority: Priority level
        raw_data: Complete issue data as JSON
        state: Current state of the issue
        team_key: Team key
        team_name: Team name
        title: Title of the issue
        trigger_timestamp: When this trigger was activated
        updated_at: When the issue was last updated
        url: URL to the issue
    ### issue_updated
        assignee_email: Email of the assignee
        assignee_name: Name of the assignee
        created_at: When the issue was created
        creator_email: Email of the creator
        creator_name: Name of the creator
        description: Description of the issue
        id: Unique identifier of the issue
        identifier: Issue identifier (e.g., ENG-123)
        parent_id: Parent issue ID if this is a sub-issue
        priority: Priority level
        raw_data: Complete issue data as JSON
        state: Current state of the issue
        team_key: Team key
        team_name: Team name
        title: Title of the issue
        trigger_timestamp: When this trigger was activated
        updated_at: When the issue was last updated
        updated_from: Previous values before the update as JSON
        url: URL to the issue
    ### project_created
        color: Project color
        content: Project content
        created_at: When the project was created
        description: Project description
        id: Unique identifier of the project
        priority: Priority level
        project_name: Name of the project
        raw_data: Complete project data as JSON
        slug_id: Project slug identifier
        start_date: Project start date
        status_color: Status color
        status_name: Status name
        status_type: Status type
        target_date: Project target date
        trigger_timestamp: When this trigger was activated
        updated_at: When the project was last updated
        url: URL to the project
    ### project_updated
        color: Project color
        content: Project content
        created_at: When the project was created
        description: Project description
        id: Unique identifier of the project
        priority: Priority level
        project_name: Name of the project
        raw_data: Complete project data as JSON
        slug_id: Project slug identifier
        start_date: Project start date
        status_color: Status color
        status_name: Status name
        status_type: Status type
        target_date: Project target date
        trigger_timestamp: When this trigger was activated
        updated_at: When the project was last updated
        updated_from: Previous values before the update as JSON
        url: URL to the project
    ### comment_created
        comment_body: Content of the comment
        created_at: When the comment was created
        edited_at: When the comment was last edited
        id: Unique identifier of the comment
        issue_identifier: Related issue identifier (e.g., ENG-123)
        issue_title: Related issue title
        issue_url: URL to the related issue
        raw_data: Complete comment data as JSON
        trigger_timestamp: When this trigger was activated
        updated_at: When the comment was last updated
        url: URL to the comment
        user_email: Email of the comment creator
        user_name: Name of the comment creator
    ### comment_updated
        comment_body: Updated content of the comment
        created_at: When the comment was created
        edited_at: When the comment was last edited
        id: Unique identifier of the comment
        issue_identifier: Related issue identifier (e.g., ENG-123)
        issue_title: Related issue title
        issue_url: URL to the related issue
        raw_data: Complete comment data as JSON
        trigger_timestamp: When this trigger was activated
        updated_at: When the comment was last updated
        updated_from: Previous values before the update as JSON
        url: URL to the comment
        user_email: Email of the comment creator
        user_name: Name of the comment creator
    ### reaction_created
        comment_body: Comment body if reaction is on a comment
        comment_id: Comment ID if reaction is on a comment
        created_at: When the reaction was created
        id: Unique identifier of the reaction
        issue_identifier: Issue identifier if reaction is on an issue
        issue_title: Issue title if reaction is on an issue
        issue_url: Issue URL if reaction is on an issue
        raw_data: Complete reaction data as JSON
        reaction_emoji: Emoji of the reaction
        trigger_timestamp: When this trigger was activated
        updated_at: When the reaction was last updated
        user_email: Email of the user who reacted
        user_name: Name of the user who reacted
    ### cycle_created
        created_at: When the cycle was created
        description: Cycle description
        ends_at: Cycle end date
        id: Unique identifier of the cycle
        is_active: Whether the cycle is currently active
        is_future: Whether the cycle is in the future
        is_past: Whether the cycle is past
        number: Cycle number
        raw_data: Complete cycle data as JSON
        starts_at: Cycle start date
        team_id: Team ID
        trigger_timestamp: When this trigger was activated
        updated_at: When the cycle was last updated
        url: URL to the cycle
    ### cycle_updated
        created_at: When the cycle was created
        description: Cycle description
        ends_at: Cycle end date
        id: Unique identifier of the cycle
        is_active: Whether the cycle is currently active
        is_future: Whether the cycle is in the future
        is_past: Whether the cycle is past
        number: Cycle number
        raw_data: Complete cycle data as JSON
        starts_at: Cycle start date
        team_id: Team ID
        trigger_timestamp: When this trigger was activated
        updated_at: When the cycle was last updated
        updated_from: Previous values before the update as JSON
        url: URL to the cycle
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "event",
            "helper_text": "The event input",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "The integration input",
            "value": None,
            "type": "integration<Linear>",
        },
        {
            "field": "item_id",
            "helper_text": "Select the Linear team to watch",
            "value": "",
            "type": "string",
        },
        {
            "field": "trigger_enabled",
            "helper_text": "Enable/Disable Automation",
            "value": True,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "issue_created": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the issue",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "identifier",
                    "type": "string",
                    "helper_text": "Issue identifier (e.g., ENG-123)",
                },
                {"field": "priority", "type": "int32", "helper_text": "Priority level"},
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the issue",
                },
                {"field": "team_name", "type": "string", "helper_text": "Team name"},
                {"field": "team_key", "type": "string", "helper_text": "Team key"},
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "Name of the assignee",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "Email of the assignee",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the creator",
                },
                {
                    "field": "creator_email",
                    "type": "string",
                    "helper_text": "Email of the creator",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the issue"},
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Parent issue ID if this is a sub-issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete issue data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "issue_created",
            "task_name": "tasks.linear.issue_created",
            "description": "Triggers when a new issue is created",
            "label": "Issue Created",
        },
        "issue_updated": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the issue",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {
                    "field": "identifier",
                    "type": "string",
                    "helper_text": "Issue identifier (e.g., ENG-123)",
                },
                {"field": "priority", "type": "int32", "helper_text": "Priority level"},
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the issue",
                },
                {"field": "team_name", "type": "string", "helper_text": "Team name"},
                {"field": "team_key", "type": "string", "helper_text": "Team key"},
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "Name of the assignee",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "Email of the assignee",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the creator",
                },
                {
                    "field": "creator_email",
                    "type": "string",
                    "helper_text": "Email of the creator",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the issue"},
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Parent issue ID if this is a sub-issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was last updated",
                },
                {
                    "field": "updated_from",
                    "type": "string",
                    "helper_text": "Previous values before the update as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete issue data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "issue_updated",
            "task_name": "tasks.linear.issue_updated",
            "description": "Triggers when an issue is updated",
            "label": "Issue Updated",
        },
        "issue_removed": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the issue",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (remove)",
                },
                {
                    "field": "identifier",
                    "type": "string",
                    "helper_text": "Issue identifier (e.g., ENG-123)",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the issue",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the issue",
                },
                {"field": "priority", "type": "int32", "helper_text": "Priority level"},
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "State when removed",
                },
                {"field": "team_name", "type": "string", "helper_text": "Team name"},
                {"field": "team_key", "type": "string", "helper_text": "Team key"},
                {
                    "field": "assignee_name",
                    "type": "string",
                    "helper_text": "Name of the assignee",
                },
                {
                    "field": "assignee_email",
                    "type": "string",
                    "helper_text": "Email of the assignee",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the creator",
                },
                {
                    "field": "creator_email",
                    "type": "string",
                    "helper_text": "Email of the creator",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the issue"},
                {
                    "field": "parent_id",
                    "type": "string",
                    "helper_text": "Parent issue ID if this was a sub-issue",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the issue was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Issue data before removal as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "issue_removed",
            "task_name": "tasks.linear.issue_removed",
            "description": "Triggers when an issue is removed",
            "label": "Issue Removed",
        },
        "comment_created": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the comment",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Content of the comment",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the comment creator",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the comment creator",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Related issue identifier (e.g., ENG-123)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Related issue title",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL to the related issue",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the comment"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last updated",
                },
                {
                    "field": "edited_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last edited",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete comment data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "comment_created",
            "task_name": "tasks.linear.comment_created",
            "description": "Triggers when a new comment is created",
            "label": "Comment Created",
        },
        "comment_updated": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the comment",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Updated content of the comment",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the comment creator",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the comment creator",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Related issue identifier (e.g., ENG-123)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Related issue title",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL to the related issue",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the comment"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last updated",
                },
                {
                    "field": "edited_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last edited",
                },
                {
                    "field": "updated_from",
                    "type": "string",
                    "helper_text": "Previous values before the update as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete comment data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "comment_updated",
            "task_name": "tasks.linear.comment_updated",
            "description": "Triggers when a comment is updated",
            "label": "Comment Updated",
        },
        "comment_removed": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the comment",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (remove)",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Content of the comment before removal",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the comment creator",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the comment creator",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Related issue identifier (e.g., ENG-123)",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Related issue title",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "URL to the related issue",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the comment"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last updated",
                },
                {
                    "field": "edited_at",
                    "type": "timestamp",
                    "helper_text": "When the comment was last edited",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Comment data before removal as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "comment_removed",
            "task_name": "tasks.linear.comment_removed",
            "description": "Triggers when a comment is removed",
            "label": "Comment Removed",
        },
        "project_created": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the project",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "Name of the project",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Project description",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "Project content",
                },
                {"field": "priority", "type": "int32", "helper_text": "Priority level"},
                {"field": "color", "type": "string", "helper_text": "Project color"},
                {
                    "field": "status_name",
                    "type": "string",
                    "helper_text": "Status name",
                },
                {
                    "field": "status_color",
                    "type": "string",
                    "helper_text": "Status color",
                },
                {
                    "field": "status_type",
                    "type": "string",
                    "helper_text": "Status type",
                },
                {
                    "field": "slug_id",
                    "type": "string",
                    "helper_text": "Project slug identifier",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the project"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the project was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the project was last updated",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "Project start date",
                },
                {
                    "field": "target_date",
                    "type": "timestamp",
                    "helper_text": "Project target date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete project data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "project_created",
            "task_name": "tasks.linear.project_created",
            "description": "Triggers when a new project is created",
            "label": "Project Created",
        },
        "project_updated": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the project",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "Name of the project",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Project description",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "Project content",
                },
                {"field": "priority", "type": "int32", "helper_text": "Priority level"},
                {"field": "color", "type": "string", "helper_text": "Project color"},
                {
                    "field": "status_name",
                    "type": "string",
                    "helper_text": "Status name",
                },
                {
                    "field": "status_color",
                    "type": "string",
                    "helper_text": "Status color",
                },
                {
                    "field": "status_type",
                    "type": "string",
                    "helper_text": "Status type",
                },
                {
                    "field": "slug_id",
                    "type": "string",
                    "helper_text": "Project slug identifier",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the project"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the project was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the project was last updated",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "Project start date",
                },
                {
                    "field": "target_date",
                    "type": "timestamp",
                    "helper_text": "Project target date",
                },
                {
                    "field": "updated_from",
                    "type": "string",
                    "helper_text": "Previous values before the update as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete project data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "project_updated",
            "task_name": "tasks.linear.project_updated",
            "description": "Triggers when a project is updated",
            "label": "Project Updated",
        },
        "project_removed": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the project",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (remove)",
                },
                {
                    "field": "project_name",
                    "type": "string",
                    "helper_text": "Name of the project",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Project description",
                },
                {
                    "field": "content",
                    "type": "string",
                    "helper_text": "Project content",
                },
                {"field": "priority", "type": "int32", "helper_text": "Priority level"},
                {"field": "color", "type": "string", "helper_text": "Project color"},
                {
                    "field": "status_name",
                    "type": "string",
                    "helper_text": "Status name",
                },
                {
                    "field": "status_color",
                    "type": "string",
                    "helper_text": "Status color",
                },
                {
                    "field": "status_type",
                    "type": "string",
                    "helper_text": "Status type",
                },
                {
                    "field": "slug_id",
                    "type": "string",
                    "helper_text": "Project slug identifier",
                },
                {"field": "url", "type": "string", "helper_text": "URL to the project"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the project was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the project was last updated",
                },
                {
                    "field": "start_date",
                    "type": "timestamp",
                    "helper_text": "Project start date",
                },
                {
                    "field": "target_date",
                    "type": "timestamp",
                    "helper_text": "Project target date",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Project data before removal as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "project_removed",
            "task_name": "tasks.linear.project_removed",
            "description": "Triggers when a project is removed",
            "label": "Project Removed",
        },
        "cycle_created": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the cycle",
                },
                {"field": "number", "type": "int32", "helper_text": "Cycle number"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Cycle description",
                },
                {
                    "field": "starts_at",
                    "type": "timestamp",
                    "helper_text": "Cycle start date",
                },
                {
                    "field": "ends_at",
                    "type": "timestamp",
                    "helper_text": "Cycle end date",
                },
                {
                    "field": "is_active",
                    "type": "bool",
                    "helper_text": "Whether the cycle is currently active",
                },
                {
                    "field": "is_future",
                    "type": "bool",
                    "helper_text": "Whether the cycle is in the future",
                },
                {
                    "field": "is_past",
                    "type": "bool",
                    "helper_text": "Whether the cycle is past",
                },
                {"field": "team_id", "type": "string", "helper_text": "Team ID"},
                {"field": "url", "type": "string", "helper_text": "URL to the cycle"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the cycle was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the cycle was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete cycle data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "cycle_created",
            "task_name": "tasks.linear.cycle_created",
            "description": "Triggers when a new cycle is created",
            "label": "Cycle Created",
        },
        "cycle_updated": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the cycle",
                },
                {"field": "number", "type": "int32", "helper_text": "Cycle number"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Cycle description",
                },
                {
                    "field": "starts_at",
                    "type": "timestamp",
                    "helper_text": "Cycle start date",
                },
                {
                    "field": "ends_at",
                    "type": "timestamp",
                    "helper_text": "Cycle end date",
                },
                {
                    "field": "is_active",
                    "type": "bool",
                    "helper_text": "Whether the cycle is currently active",
                },
                {
                    "field": "is_future",
                    "type": "bool",
                    "helper_text": "Whether the cycle is in the future",
                },
                {
                    "field": "is_past",
                    "type": "bool",
                    "helper_text": "Whether the cycle is past",
                },
                {"field": "team_id", "type": "string", "helper_text": "Team ID"},
                {"field": "url", "type": "string", "helper_text": "URL to the cycle"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the cycle was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the cycle was last updated",
                },
                {
                    "field": "updated_from",
                    "type": "string",
                    "helper_text": "Previous values before the update as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete cycle data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "cycle_updated",
            "task_name": "tasks.linear.cycle_updated",
            "description": "Triggers when a cycle is updated",
            "label": "Cycle Updated",
        },
        "cycle_removed": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the cycle",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (remove)",
                },
                {"field": "number", "type": "int32", "helper_text": "Cycle number"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Cycle description",
                },
                {
                    "field": "starts_at",
                    "type": "timestamp",
                    "helper_text": "Cycle start date",
                },
                {
                    "field": "ends_at",
                    "type": "timestamp",
                    "helper_text": "Cycle end date",
                },
                {
                    "field": "is_active",
                    "type": "bool",
                    "helper_text": "Whether the cycle is currently active",
                },
                {
                    "field": "is_future",
                    "type": "bool",
                    "helper_text": "Whether the cycle is in the future",
                },
                {
                    "field": "is_past",
                    "type": "bool",
                    "helper_text": "Whether the cycle is past",
                },
                {"field": "team_id", "type": "string", "helper_text": "Team ID"},
                {"field": "url", "type": "string", "helper_text": "URL to the cycle"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the cycle was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the cycle was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Cycle data before removal as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "cycle_removed",
            "task_name": "tasks.linear.cycle_removed",
            "description": "Triggers when a cycle is removed",
            "label": "Cycle Removed",
        },
        "issue_label_created": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the label",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "Name of the label",
                },
                {
                    "field": "label_color",
                    "type": "string",
                    "helper_text": "Color of the label",
                },
                {
                    "field": "label_description",
                    "type": "string",
                    "helper_text": "Description of the label",
                },
                {
                    "field": "is_group",
                    "type": "bool",
                    "helper_text": "Whether the label is a group",
                },
                {"field": "team_id", "type": "string", "helper_text": "Team ID"},
                {"field": "url", "type": "string", "helper_text": "URL to the label"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the label was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the label was last updated",
                },
                {
                    "field": "last_applied_at",
                    "type": "timestamp",
                    "helper_text": "When the label was last applied",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (create)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete label data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "issue_label_created",
            "task_name": "tasks.linear.issue_label_created",
            "description": "Triggers when a new issue label is created",
            "label": "Label Created",
        },
        "issue_label_updated": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the label",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "Name of the label",
                },
                {
                    "field": "label_color",
                    "type": "string",
                    "helper_text": "Color of the label",
                },
                {
                    "field": "label_description",
                    "type": "string",
                    "helper_text": "Description of the label",
                },
                {
                    "field": "is_group",
                    "type": "bool",
                    "helper_text": "Whether the label is a group",
                },
                {"field": "team_id", "type": "string", "helper_text": "Team ID"},
                {"field": "url", "type": "string", "helper_text": "URL to the label"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the label was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the label was last updated",
                },
                {
                    "field": "last_applied_at",
                    "type": "timestamp",
                    "helper_text": "When the label was last applied",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (update)",
                },
                {
                    "field": "updated_from",
                    "type": "string",
                    "helper_text": "Previous values before the update as JSON",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete label data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "issue_label_updated",
            "task_name": "tasks.linear.issue_label_updated",
            "description": "Triggers when an issue label is updated",
            "label": "Label Updated",
        },
        "issue_label_removed": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the label",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (remove)",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "Name of the label",
                },
                {
                    "field": "label_color",
                    "type": "string",
                    "helper_text": "Color of the label",
                },
                {
                    "field": "label_description",
                    "type": "string",
                    "helper_text": "Description of the label",
                },
                {
                    "field": "is_group",
                    "type": "bool",
                    "helper_text": "Whether the label is a group",
                },
                {"field": "team_id", "type": "string", "helper_text": "Team ID"},
                {"field": "url", "type": "string", "helper_text": "URL to the label"},
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the label was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the label was last updated",
                },
                {
                    "field": "last_applied_at",
                    "type": "timestamp",
                    "helper_text": "When the label was last applied",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Label data before removal as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "issue_label_removed",
            "task_name": "tasks.linear.issue_label_removed",
            "description": "Triggers when an issue label is removed",
            "label": "Label Removed",
        },
        "reaction_created": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the reaction",
                },
                {
                    "field": "reaction_emoji",
                    "type": "string",
                    "helper_text": "Emoji of the reaction",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user who reacted",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user who reacted",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Issue identifier if reaction is on an issue",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Issue title if reaction is on an issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "Issue URL if reaction is on an issue",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Comment body if reaction is on a comment",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "Comment ID if reaction is on a comment",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the reaction was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the reaction was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete reaction data as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "reaction_created",
            "task_name": "tasks.linear.reaction_created",
            "description": "Triggers when a reaction is created on an issue or comment",
            "label": "Reaction Created",
        },
        "reaction_removed": {
            "inputs": [],
            "outputs": [
                {
                    "field": "id",
                    "type": "string",
                    "helper_text": "Unique identifier of the reaction",
                },
                {
                    "field": "action",
                    "type": "string",
                    "helper_text": "Action performed (remove)",
                },
                {
                    "field": "reaction_emoji",
                    "type": "string",
                    "helper_text": "Emoji of the reaction",
                },
                {
                    "field": "user_name",
                    "type": "string",
                    "helper_text": "Name of the user who reacted",
                },
                {
                    "field": "user_email",
                    "type": "string",
                    "helper_text": "Email of the user who reacted",
                },
                {
                    "field": "issue_identifier",
                    "type": "string",
                    "helper_text": "Issue identifier if reaction is on an issue",
                },
                {
                    "field": "issue_title",
                    "type": "string",
                    "helper_text": "Issue title if reaction is on an issue",
                },
                {
                    "field": "issue_url",
                    "type": "string",
                    "helper_text": "Issue URL if reaction is on an issue",
                },
                {
                    "field": "comment_body",
                    "type": "string",
                    "helper_text": "Comment body if reaction is on a comment",
                },
                {
                    "field": "comment_id",
                    "type": "string",
                    "helper_text": "Comment ID if reaction is on a comment",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the reaction was created",
                },
                {
                    "field": "updated_at",
                    "type": "timestamp",
                    "helper_text": "When the reaction was last updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Reaction data before removal as JSON",
                },
                {
                    "field": "trigger_timestamp",
                    "type": "timestamp",
                    "helper_text": "When this trigger was activated",
                },
            ],
            "variant": "common_trigger_nodes",
            "name": "reaction_removed",
            "task_name": "tasks.linear.reaction_removed",
            "description": "Triggers when a reaction is removed from an issue or comment",
            "label": "Reaction Removed",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["event"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "event", "label": "Event"},
        {"field": "integration", "label": "Integration"},
        {"field": "item_id", "label": "Team"},
    ]

    _REQUIRED_FIELDS = ["event", "trigger_enabled", "integration", "item_id"]

    def __init__(
        self,
        event: str = "",
        item_id: str = "",
        trigger_enabled: bool = True,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["event"] = event

        super().__init__(
            node_type="trigger_linear",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if event is not None:
            self.inputs["event"] = event
        if trigger_enabled is not None:
            self.inputs["trigger_enabled"] = trigger_enabled
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TriggerLinearNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
