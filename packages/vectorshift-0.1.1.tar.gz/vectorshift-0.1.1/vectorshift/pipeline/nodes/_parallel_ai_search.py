"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("parallel_ai_search")
class ParallelAiSearchNode(Node):
    """
    Search the web with Parallel's Search API

    ## Inputs
    ### Common Inputs
        blocked_domains: Exclude these domains from the response.
        excerpts_max_chars_per_result: Limit the excerpt length returned inside the excerpts object.
        fetch_live_results: Enable to fetch the latest version of each page instead of relying on cached index entries.
        max_chars_per_result: Legacy field for truncating excerpts. Prefer the excerpts.* controls when available.
        max_results: Upper bound on the number of results to return.
        mode: Choose output presets. one-shot maximizes coverage, agentic optimizes for iterative agent loops.
        objective: Describe what the search should accomplish. Provide preferred sources or freshness hints here.
        preferred_domains: Prioritize these domains in ranked results.
        processor: Legacy tier selector. Leave blank to use the default tier for your workspace.
        search_queries: Optional structured keyword queries. At least one of objective or search queries is required.

    ## Outputs
    ### Common Outputs
        formatted_text: Parallel Search results formatted for LLM consumption
        output: Raw JSON payload from the Parallel Search API
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "blocked_domains",
            "helper_text": "Exclude these domains from the response.",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "excerpts_max_chars_per_result",
            "helper_text": "Limit the excerpt length returned inside the excerpts object.",
            "value": 1500,
            "type": "int32",
        },
        {
            "field": "fetch_live_results",
            "helper_text": "Enable to fetch the latest version of each page instead of relying on cached index entries.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "max_chars_per_result",
            "helper_text": "Legacy field for truncating excerpts. Prefer the excerpts.* controls when available.",
            "value": 1500,
            "type": "int32",
        },
        {
            "field": "max_results",
            "helper_text": "Upper bound on the number of results to return.",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "mode",
            "helper_text": "Choose output presets. one-shot maximizes coverage, agentic optimizes for iterative agent loops.",
            "value": "one-shot",
            "type": "string",
        },
        {
            "field": "objective",
            "helper_text": "Describe what the search should accomplish. Provide preferred sources or freshness hints here.",
            "value": "",
            "type": "string",
        },
        {
            "field": "preferred_domains",
            "helper_text": "Prioritize these domains in ranked results.",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "processor",
            "helper_text": "Legacy tier selector. Leave blank to use the default tier for your workspace.",
            "value": "",
            "type": "string",
        },
        {
            "field": "search_queries",
            "helper_text": "Optional structured keyword queries. At least one of objective or search queries is required.",
            "value": [],
            "type": "vec<string>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "formatted_text",
            "helper_text": "Parallel Search results formatted for LLM consumption",
            "type": "string",
        },
        {
            "field": "output",
            "helper_text": "Raw JSON payload from the Parallel Search API",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    def __init__(
        self,
        blocked_domains: List[str] = [],
        excerpts_max_chars_per_result: int = 1500,
        fetch_live_results: bool = False,
        max_chars_per_result: int = 1500,
        max_results: int = 10,
        mode: str = "one-shot",
        objective: str = "",
        preferred_domains: List[str] = [],
        processor: str = "",
        search_queries: List[str] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="parallel_ai_search",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if objective is not None:
            self.inputs["objective"] = objective
        if search_queries is not None:
            self.inputs["search_queries"] = search_queries
        if mode is not None:
            self.inputs["mode"] = mode
        if max_chars_per_result is not None:
            self.inputs["max_chars_per_result"] = max_chars_per_result
        if excerpts_max_chars_per_result is not None:
            self.inputs["excerpts_max_chars_per_result"] = excerpts_max_chars_per_result
        if processor is not None:
            self.inputs["processor"] = processor
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if preferred_domains is not None:
            self.inputs["preferred_domains"] = preferred_domains
        if blocked_domains is not None:
            self.inputs["blocked_domains"] = blocked_domains
        if fetch_live_results is not None:
            self.inputs["fetch_live_results"] = fetch_live_results
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ParallelAiSearchNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
