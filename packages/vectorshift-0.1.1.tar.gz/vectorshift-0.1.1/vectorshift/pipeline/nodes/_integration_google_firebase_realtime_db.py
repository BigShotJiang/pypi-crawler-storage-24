"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_firebase_realtime_db")
class IntegrationGoogleFirebaseRealtimeDbNode(Node):
    """
    Google Firebase Realtime DB

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### create_record
        data: The data to write (JSON format)
        database_url: Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)
        path: The path where you want to create/write data
    ### push_to_list
        data: The data to write (JSON format)
        database_url: Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)
        path: The path where you want to create/write data
    ### read_record
        database_url: Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)
        path: The path where you want to create/write data
    ### update_record
        database_url: Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)
        path: The path where you want to create/write data
        update_data: The fields to update (JSON format)
    ### delete_record
        database_url: Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)
        path: The path where you want to create/write data

    ## Outputs
    ### create_record
        data: The data that was written
        message: Status message
        path: The path where data was written
        raw_data: Raw response from Firebase
    ### read_record
        data: The data read from the Realtime DB
        item_count: Number of items if data is a collection
        keys: List of keys if data is an object
        path: The path that was read
        raw_data: Raw response from Firebase
    ### push_to_list
        full_path: The full path including the generated key
        generated_key: The auto-generated key for the new item
        message: Status message
        path: The path where data was pushed
        pushed_data: The data that was pushed
        raw_data: Raw response from Firebase
    ### update_record
        message: Status message
        path: The path that was updated
        raw_data: Raw response from Firebase
        response: Response from Firebase
        updated_fields: The fields that were updated
    ### delete_record
        message: Status message
        path: The path that was deleted
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Firebase Realtime DB>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_record": {
            "inputs": [
                {
                    "field": "database_url",
                    "type": "string",
                    "value": "",
                    "label": "Database URL",
                    "placeholder": "https://your-project-id-default-rtdb.firebaseio.com",
                    "helper_text": "Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)",
                },
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "label": "Path",
                    "placeholder": "/users/123",
                    "helper_text": "The path where you want to create/write data",
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"name": "John", "age": 30}',
                    "helper_text": "The data to write (JSON format)",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "The path where data was written",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The data that was written",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Firebase",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "name": "create_record",
            "task_name": "tasks.google_firebase_realtime_db.create_record",
            "description": "Write data to Firebase Realtime Database",
            "label": "Create/Write Data",
            "ui_sort_order": ["integration", "action", "database_url", "path", "data"],
            "required": ["database_url", "path", "data"],
        },
        "read_record": {
            "inputs": [
                {
                    "field": "database_url",
                    "type": "string",
                    "value": "",
                    "label": "Database URL",
                    "placeholder": "https://your-project-id-default-rtdb.firebaseio.com",
                    "helper_text": "Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)",
                },
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "label": "Path",
                    "placeholder": "/users/123/name",
                    "helper_text": "The path to the data you want to read",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "The path that was read",
                },
                {
                    "field": "data",
                    "type": "string",
                    "helper_text": "The data read from the Realtime DB",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Firebase",
                },
                {
                    "field": "keys",
                    "type": "vec<string>",
                    "helper_text": "List of keys if data is an object",
                },
                {
                    "field": "item_count",
                    "type": "string",
                    "helper_text": "Number of items if data is a collection",
                },
            ],
            "name": "read_record",
            "task_name": "tasks.google_firebase_realtime_db.read_record",
            "description": "Read details of a specific record",
            "label": "Get Record",
            "inputs_sort_order": ["integration", "action", "database_url", "path"],
            "required": ["database_url", "path"],
        },
        "update_record": {
            "inputs": [
                {
                    "field": "database_url",
                    "type": "string",
                    "value": "",
                    "label": "Database URL",
                    "placeholder": "https://your-project-id-default-rtdb.firebaseio.com",
                    "helper_text": "Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)",
                },
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "label": "Path",
                    "placeholder": "/users/123",
                    "helper_text": "The path to the data you want to update",
                },
                {
                    "field": "update_data",
                    "type": "string",
                    "value": "",
                    "label": "Update Data",
                    "placeholder": '{"age": 31, "city": "New York"}',
                    "helper_text": "The fields to update (JSON format)",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "The path that was updated",
                },
                {
                    "field": "updated_fields",
                    "type": "string",
                    "helper_text": "The fields that were updated",
                },
                {
                    "field": "response",
                    "type": "string",
                    "helper_text": "Response from Firebase",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Firebase",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "name": "update_record",
            "task_name": "tasks.google_firebase_realtime_db.update_record",
            "description": "Update specific fields in Firebase Realtime Database",
            "label": "Update Data",
            "ui_sort_order": [
                "integration",
                "action",
                "database_url",
                "path",
                "update_data",
            ],
            "required": ["database_url", "path", "update_data"],
        },
        "delete_record": {
            "inputs": [
                {
                    "field": "database_url",
                    "type": "string",
                    "value": "",
                    "label": "Database URL",
                    "placeholder": "https://your-project-id-default-rtdb.firebaseio.com",
                    "helper_text": "Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)",
                },
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "label": "Path",
                    "placeholder": "/users/123",
                    "helper_text": "The path to the data you want to delete",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "The path that was deleted",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "name": "delete_record",
            "task_name": "tasks.google_firebase_realtime_db.delete_record",
            "description": "Delete data from Firebase Realtime Database",
            "label": "Delete Data",
            "ui_sort_order": ["integration", "action", "database_url", "path"],
            "required": ["database_url", "path"],
        },
        "push_to_list": {
            "inputs": [
                {
                    "field": "database_url",
                    "type": "string",
                    "value": "",
                    "label": "Database URL",
                    "placeholder": "https://your-project-id-default-rtdb.firebaseio.com",
                    "helper_text": "Your Firebase Realtime Database URL (e.g., https://your-project-id-default-rtdb.firebaseio.com)",
                },
                {
                    "field": "path",
                    "type": "string",
                    "value": "",
                    "label": "Path",
                    "placeholder": "/messages",
                    "helper_text": "The path to the list where you want to push data",
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"text": "Hello", "timestamp": 1234567890}',
                    "helper_text": "The data to push to the list (JSON format)",
                },
            ],
            "outputs": [
                {
                    "field": "path",
                    "type": "string",
                    "helper_text": "The path where data was pushed",
                },
                {
                    "field": "pushed_data",
                    "type": "string",
                    "helper_text": "The data that was pushed",
                },
                {
                    "field": "generated_key",
                    "type": "string",
                    "helper_text": "The auto-generated key for the new item",
                },
                {
                    "field": "full_path",
                    "type": "string",
                    "helper_text": "The full path including the generated key",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Firebase",
                },
                {"field": "message", "type": "string", "helper_text": "Status message"},
            ],
            "name": "push_to_list",
            "task_name": "tasks.google_firebase_realtime_db.push_to_list",
            "description": "Push data to a list in Firebase Realtime Database with auto-generated key",
            "label": "Push to List",
            "ui_sort_order": ["integration", "action", "database_url", "path", "data"],
            "required": ["database_url", "path", "data"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        data: str = "",
        database_url: str = "",
        path: str = "",
        update_data: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_firebase_realtime_db",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if database_url is not None:
            self.inputs["database_url"] = database_url
        if path is not None:
            self.inputs["path"] = path
        if data is not None:
            self.inputs["data"] = data
        if update_data is not None:
            self.inputs["update_data"] = update_data
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleFirebaseRealtimeDbNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
