"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_youtube")
class IntegrationYoutubeNode(Node):
    """
    YouTube

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### upload_channel_banner
        banner_image: Banner image file to upload
    ### list_videos
        category_id: Get videos by category
        chart: Chart to retrieve
        max_results: Maximum number of results to return
        page_token: Page token for pagination
        playlist_id: The ID of the playlist to delete
        region_code: Region code for results
        video_ids: Comma-separated list of video IDs
    ### update_video
        category_id: Get videos by category
        default_language: Default language of the playlist
        description: New description for the channel
        embeddable: Whether the video can be embedded
        license: License of the video
        made_for_kids: Whether the video is made for kids
        playlist_id: The ID of the playlist to delete
        privacy_status: Privacy status of the playlist
        public_stats_viewable: Whether the video's stats are viewable
        publish_at: Publish date and time of the video
        recording_date: Recording date of the video
        tags: Tags for the playlist (comma-separated)
        title: New title for the channel
        video_id: The ID of the video to add
    ### upload_video
        category_id: Get videos by category
        description: New description for the channel
        embeddable: Whether the video can be embedded
        made_for_kids: Whether the video is made for kids
        playlist_id: The ID of the playlist to delete
        privacy_status: Privacy status of the playlist
        tags: Tags for the playlist (comma-separated)
        title: New title for the channel
        video_file: Video file to upload
    ### list_channels
        channel_ids: Comma-separated list of channel IDs
        managed_by_me: Get channels managed by you
        max_results: Maximum number of results to return
        mine: Get your own channels
        page_token: Page token for pagination
        username: Username of the channel
    ### create_playlist
        default_language: Default language of the playlist
        description: New description for the channel
        privacy_status: Privacy status of the playlist
        tags: Tags for the playlist (comma-separated)
        title: New title for the channel
    ### update_channel
        default_tab: Default tab for the channel
        description: New description for the channel
        featured_channels_title: Title for the featured channels section
        featured_channels_urls: URLs for the featured channels
        keywords: Keywords for the channel
        moderate_comments: Whether to moderate comments on the channel
        show_browse_view: Whether to show the browse view on the channel
        show_related_channels: Whether to show related channels on the channel
        show_sponsor_list: Whether to show the sponsor list on the channel
        title: New title for the channel
        tracking_analytics_account_id: Tracking analytics account ID for the channel
        unsubscribed_trailer: Unsubscribed trailer video ID for the channel
    ### update_playlist
        description: New description for the channel
        playlist_id: The ID of the playlist to delete
        privacy_status: Privacy status of the playlist
        tags: Tags for the playlist (comma-separated)
        title: New title for the channel
    ### add_playlist_item
        end_at: End time (PT2M30S format)
        note: Note about the playlist item
        playlist_id: The ID of the playlist to delete
        position: Position in the playlist
        start_at: Start time (PT1M30S format)
        video_id: The ID of the video to add
    ### list_playlists
        fetch_all: Fetch all playlists
        max_results: Maximum number of results to return
        mine: Get your own channels
        page_token: Page token for pagination
        playlist_ids: Comma-separated list of playlist IDs
    ### list_playlist_items
        fetch_all: Fetch all playlists
        max_results: Maximum number of results to return
        page_token: Page token for pagination
        playlist_id: The ID of the playlist to delete
        video_id: The ID of the video to add
    ### list_video_categories
        language: Language for category names
        region_code: Region code for results
    ### delete_playlist
        playlist_id: The ID of the playlist to delete
    ### get_playlist
        playlist_id: The ID of the playlist to delete
    ### delete_video
        playlist_id: The ID of the playlist to delete
        video_id: The ID of the video to add
    ### get_video
        playlist_id: The ID of the playlist to delete
        video_id: The ID of the video to add
    ### delete_playlist_item
        playlist_item_id: The ID of the playlist item to delete
    ### get_playlist_item
        playlist_item_id: The ID of the playlist item to delete
    ### rate_video
        rating: Rating to give the video
        video_id: The ID of the video to add

    ## Outputs
    ### upload_video
        added_to_playlist: Playlist ID if video was added to playlist
        channel_id: ID of the channel
        description: Description of the video
        privacy_status: Privacy status
        published_at: When the video was published
        raw_data: Raw response data
        thumbnail_url: Thumbnail URL
        title: Title of the video
        upload_status: Upload status
        video_id: ID of the uploaded video
    ### list_video_categories
        assignables: List of assignable values
        category_ids: List of video category IDs
        channel_ids: List of channel IDs
        raw_data: Raw response data
        region_code: Region code used
        titles: List of video category titles
        total_count: Total number of categories
    ### upload_channel_banner
        banner_url: URL of the uploaded banner
        channel_updated: Whether the channel was updated with the banner
        raw_data: Raw response data
    ### list_videos
        captions: List of video caption values
        category_ids: List of video category IDs
        channel_ids: List of channel IDs
        channel_titles: List of channel titles
        comment_counts: List of video comment counts
        definitions: List of video definitions
        descriptions: List of video descriptions
        durations: List of video durations
        embeddables: List of video embeddable values
        like_counts: List of video like counts
        made_for_kids: List of video made for kids values
        next_page_token: Token for next page
        prev_page_token: Token for previous page
        privacy_statuses: List of video privacy statuses
        published_ats: List of video published at timestamps
        raw_data: Raw response data
        tags: List of video tags
        thumbnail_urls: List of video thumbnail URLs
        titles: List of video titles
        total_results: Total number of results
        upload_statuses: List of video upload statuses
        video_ids: List of video IDs
        view_counts: List of video view counts
    ### get_video
        category_id: Category ID of the video
        channel_id: ID of the channel
        channel_title: Title of the channel
        comment_count: Comment count of the video
        description: Description of the video
        duration: Duration of the video
        embed_html: HTML embed code
        like_count: Like count of the video
        privacy_status: Privacy status of the video
        published_at: When the video was published
        raw_data: Raw response data
        tags: List of tags
        thumbnails: Thumbnail URLs object
        title: Title of the video
        upload_status: Upload status of the video
        video_id: ID of the video
        view_count: View count of the video
    ### list_channels
        channel_count: Total number of channels
        channel_ids: List of channel IDs
        countries: List of channel countries
        custom_urls: List of channel custom URLs
        descriptions: List of channel descriptions
        is_linked: List of channel is linked values
        keywords: List of channel keywords
        likes_playlist_ids: List of channel likes playlist IDs
        long_uploads_statuses: List of channel long uploads statuses
        made_for_kids: List of channel made for kids values
        moderate_comments: List of channel moderate comments values
        next_page_token: Token for next page
        prev_page_token: Token for previous page
        privacy_statuses: List of channel privacy statuses
        published_ats: List of channel published at timestamps
        raw_data: Raw response data
        subscriber_counts: List of channel subscriber counts
        thumbnail_urls: List of channel thumbnail URLs
        titles: List of channel titles
        total_results: Total number of results
        tracking_analytics_account_ids: List of channel tracking analytics account IDs
        unsubscribed_trailers: List of channel unsubscribed trailer video IDs
        uploads_playlist_ids: List of channel uploads playlist IDs
        video_counts: List of channel video counts
        view_counts: List of channel view counts
    ### get_channel
        channel_id: ID of the channel
        country: Country of the channel
        custom_url: Custom URL of the channel
        description: Description of the channel
        is_linked: Whether the channel is linked to a Google+ account
        privacy_status: Privacy status of the channel
        published_at: When the channel was created
        raw_data: Raw response data
        subscriber_count: Subscriber count of the channel
        thumbnail_url: Thumbnail image URL
        title: Title of the channel
        video_count: Number of videos on the channel
        view_count: Total view count of the channel
    ### update_channel
        channel_id: ID of the updated channel
        description: Updated description
        keywords: Updated keywords
        raw_data: Raw response data
        title: Updated title
    ### create_playlist
        channel_id: ID of the channel that owns the playlist
        description: Description of the playlist
        playlist_id: ID of the created playlist
        privacy_status: Privacy status of the playlist
        published_at: When the playlist was created
        raw_data: Raw response data
        title: Title of the playlist
    ### get_playlist
        channel_id: ID of the channel that owns the playlist
        description: Description of the playlist
        item_count: Number of items in the playlist
        playlist_id: ID of the playlist
        privacy_status: Privacy status of the playlist
        published_at: When the playlist was created
        raw_data: Raw response data
        thumbnails: Thumbnail URLs object
        title: Title of the playlist
    ### list_playlists
        channel_ids: List of channel IDs that own the playlists
        channel_titles: List of channel titles that own the playlists
        default_languages: List of playlist default languages
        descriptions: List of playlist descriptions
        next_page_token: Token for next page
        playlist_ids: List of playlist IDs
        privacy_statuses: List of playlist privacy statuses
        published_ats: List of playlist published at timestamps
        raw_data: Raw response data
        tags: List of playlist tags
        thumbnail_urls: List of playlist thumbnail URLs
        titles: List of playlist titles
        total_count: Total number of playlists
    ### list_playlist_items
        channel_ids: List of channel IDs
        channel_titles: List of channel titles
        descriptions: List of video descriptions
        end_ats: List of end at times
        item_count: Number of items returned
        next_page_token: Token for next page
        notes: List of notes
        playlist_id: ID of the playlist
        playlist_ids: List of playlist IDs
        playlist_item_ids: List of playlist item IDs
        positions: List of positions in playlist
        privacy_statuses: List of privacy statuses
        published_ats: List of published at timestamps
        raw_data: Raw response data
        start_ats: List of start at times
        thumbnail_urls: List of thumbnail URLs
        titles: List of video titles
        total_results: Total number of results
        video_ids: List of video IDs
        video_owner_channel_ids: List of video owner channel IDs
        video_owner_channel_titles: List of video owner channel titles
        video_published_ats: List of video published at timestamps
    ### update_playlist
        description: Updated description
        playlist_id: ID of the updated playlist
        privacy_status: Updated privacy status
        raw_data: Raw response data
        tags: Updated tags
        title: Updated title
    ### get_playlist_item
        description: Description of the video
        playlist_id: ID of the playlist
        playlist_item_id: ID of the playlist item
        position: Position in the playlist
        privacy_status: Privacy status
        published_at: When the item was published
        raw_data: Raw response data
        thumbnails: Thumbnail URLs object
        title: Title of the video
        video_id: ID of the video
    ### update_video
        description: Updated description
        privacy_status: Updated privacy status
        raw_data: Raw response data
        tags: Updated tags
        title: Updated title
        video_id: ID of the updated video
    ### delete_playlist
        message: Success message
        playlist_id: ID of the deleted playlist
    ### delete_playlist_item
        message: Success message
        playlist_item_id: ID of the deleted playlist item
    ### delete_video
        message: Success message
        video_id: ID of the deleted video
    ### rate_video
        message: Success message
        rating: Rating given to the video
        video_id: ID of the rated video
    ### add_playlist_item
        playlist_id: ID of the playlist
        playlist_item_id: ID of the created playlist item
        position: Position in the playlist
        published_at: When the item was added
        raw_data: Raw response data
        thumbnail_url: Thumbnail URL
        title: Title of the video
        video_id: ID of the video
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Youtube>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_channel": {
            "inputs": [],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the channel",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the channel",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the channel was created",
                },
                {
                    "field": "country",
                    "type": "string",
                    "helper_text": "Country of the channel",
                },
                {
                    "field": "custom_url",
                    "type": "string",
                    "helper_text": "Custom URL of the channel",
                },
                {
                    "field": "thumbnail_url",
                    "type": "string",
                    "helper_text": "Thumbnail image URL",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Privacy status of the channel",
                },
                {
                    "field": "is_linked",
                    "type": "bool",
                    "helper_text": "Whether the channel is linked to a Google+ account",
                },
                {
                    "field": "view_count",
                    "type": "string",
                    "helper_text": "Total view count of the channel",
                },
                {
                    "field": "subscriber_count",
                    "type": "string",
                    "helper_text": "Subscriber count of the channel",
                },
                {
                    "field": "video_count",
                    "type": "string",
                    "helper_text": "Number of videos on the channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "get_channel",
            "task_name": "tasks.youtube.get_channel",
            "description": "Get your YouTube channel",
            "label": "Get My Channel",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action"],
            "required": [],
        },
        "list_channels": {
            "inputs": [
                {
                    "field": "channel_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of channel IDs",
                    "label": "Channel IDs",
                    "placeholder": "UC1234567890abcdef,UC0987654321fedcba",
                },
                {
                    "field": "username",
                    "type": "string",
                    "value": "",
                    "helper_text": "Username of the channel",
                    "label": "Username",
                    "placeholder": "google",
                },
                {
                    "field": "mine",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Get your own channels",
                    "label": "My Channels",
                },
                {
                    "field": "managed_by_me",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Get channels managed by you",
                    "label": "Managed by Me",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of results to return",
                    "label": "Max Results",
                },
                {
                    "field": "page_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Page token for pagination",
                    "label": "Page Token",
                    "placeholder": "CAUQAA",
                },
            ],
            "outputs": [
                {
                    "field": "channel_count",
                    "type": "int32",
                    "helper_text": "Total number of channels",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of channel titles",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of channel descriptions",
                },
                {
                    "field": "published_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of channel published at timestamps",
                },
                {
                    "field": "countries",
                    "type": "vec<string>",
                    "helper_text": "List of channel countries",
                },
                {
                    "field": "custom_urls",
                    "type": "vec<string>",
                    "helper_text": "List of channel custom URLs",
                },
                {
                    "field": "thumbnail_urls",
                    "type": "vec<string>",
                    "helper_text": "List of channel thumbnail URLs",
                },
                {
                    "field": "privacy_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of channel privacy statuses",
                },
                {
                    "field": "is_linked",
                    "type": "vec<bool>",
                    "helper_text": "List of channel is linked values",
                },
                {
                    "field": "long_uploads_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of channel long uploads statuses",
                },
                {
                    "field": "made_for_kids",
                    "type": "vec<bool>",
                    "helper_text": "List of channel made for kids values",
                },
                {
                    "field": "keywords",
                    "type": "vec<string>",
                    "helper_text": "List of channel keywords",
                },
                {
                    "field": "tracking_analytics_account_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel tracking analytics account IDs",
                },
                {
                    "field": "moderate_comments",
                    "type": "vec<bool>",
                    "helper_text": "List of channel moderate comments values",
                },
                {
                    "field": "unsubscribed_trailers",
                    "type": "vec<string>",
                    "helper_text": "List of channel unsubscribed trailer video IDs",
                },
                {
                    "field": "uploads_playlist_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel uploads playlist IDs",
                },
                {
                    "field": "likes_playlist_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel likes playlist IDs",
                },
                {
                    "field": "view_counts",
                    "type": "vec<string>",
                    "helper_text": "List of channel view counts",
                },
                {
                    "field": "subscriber_counts",
                    "type": "vec<string>",
                    "helper_text": "List of channel subscriber counts",
                },
                {
                    "field": "video_counts",
                    "type": "vec<string>",
                    "helper_text": "List of channel video counts",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of results",
                },
                {
                    "field": "next_page_token",
                    "type": "string",
                    "helper_text": "Token for next page",
                },
                {
                    "field": "prev_page_token",
                    "type": "string",
                    "helper_text": "Token for previous page",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "list_channels",
            "task_name": "tasks.youtube.list_channels",
            "description": "List YouTube channels",
            "label": "List Channels",
            "variant": "default_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "channel_ids",
                "username",
                "mine",
                "managed_by_me",
                "max_results",
                "page_token",
            ],
            "required": ["max_results"],
        },
        "update_channel": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the channel",
                    "label": "Title",
                    "placeholder": "My Awesome Channel",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the channel",
                    "label": "Description",
                    "placeholder": "Welcome to my channel where I share amazing content!",
                },
                {
                    "field": "keywords",
                    "type": "string",
                    "value": "",
                    "helper_text": "Keywords for the channel",
                    "label": "Keywords",
                    "placeholder": "gaming, entertainment, tutorials",
                },
                {
                    "field": "default_tab",
                    "type": "string",
                    "value": "",
                    "helper_text": "Default tab for the channel",
                    "label": "Default Tab",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_channel_default_tab",
                    },
                },
                {
                    "field": "tracking_analytics_account_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tracking analytics account ID for the channel",
                    "label": "Tracking Analytics Account ID",
                    "placeholder": "1234567890",
                },
                {
                    "field": "moderate_comments",
                    "type": "string",
                    "value": "",
                    "placeholder": "No updates",
                    "helper_text": "Whether to moderate comments on the channel",
                    "label": "Moderate Comments",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_boolean_update",
                    },
                },
                {
                    "field": "show_related_channels",
                    "type": "string",
                    "value": "",
                    "placeholder": "No updates",
                    "helper_text": "Whether to show related channels on the channel",
                    "label": "Show Related Channels",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_boolean_update",
                    },
                },
                {
                    "field": "show_sponsor_list",
                    "type": "string",
                    "value": "",
                    "placeholder": "No updates",
                    "helper_text": "Whether to show the sponsor list on the channel",
                    "label": "Show Sponsor List",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_boolean_update",
                    },
                },
                {
                    "field": "show_browse_view",
                    "type": "string",
                    "value": "",
                    "placeholder": "No updates",
                    "helper_text": "Whether to show the browse view on the channel",
                    "label": "Show Browse View",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_boolean_update",
                    },
                },
                {
                    "field": "featured_channels_title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title for the featured channels section",
                    "label": "Featured Channels Title",
                    "placeholder": "Featured Channels",
                },
                {
                    "field": "featured_channels_urls",
                    "type": "string",
                    "value": "",
                    "helper_text": "URLs for the featured channels",
                    "label": "Featured Channels URLs",
                    "placeholder": "https://www.youtube.com/channel/UC1234567890abcdef",
                },
                {
                    "field": "unsubscribed_trailer",
                    "type": "string",
                    "value": "",
                    "helper_text": "Unsubscribed trailer video ID for the channel",
                    "label": "Unsubscribed Trailer",
                    "placeholder": "dQw4w9WgXcQ",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the updated channel",
                },
                {"field": "title", "type": "string", "helper_text": "Updated title"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Updated description",
                },
                {
                    "field": "keywords",
                    "type": "string",
                    "helper_text": "Updated keywords",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "update_channel",
            "task_name": "tasks.youtube.update_channel",
            "description": "Update your YouTube channel",
            "label": "Update My Channel",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "title",
                "description",
                "keywords",
                "default_tab",
                "tracking_analytics_account_id",
                "moderate_comments",
                "show_related_channels",
                "show_sponsor_list",
                "show_browse_view",
                "featured_channels_title",
                "featured_channels_urls",
                "unsubscribed_trailer",
            ],
            "required": [],
        },
        "upload_channel_banner": {
            "inputs": [
                {
                    "field": "banner_image",
                    "type": "image",
                    "value": "",
                    "helper_text": "Banner image file to upload",
                    "label": "Banner Image",
                }
            ],
            "outputs": [
                {
                    "field": "banner_url",
                    "type": "string",
                    "helper_text": "URL of the uploaded banner",
                },
                {
                    "field": "channel_updated",
                    "type": "bool",
                    "helper_text": "Whether the channel was updated with the banner",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "upload_channel_banner",
            "task_name": "tasks.youtube.upload_channel_banner",
            "description": "Upload banner for your channel",
            "label": "Upload My Channel Banner",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action", "banner_image"],
            "required": ["banner_image"],
        },
        "create_playlist": {
            "inputs": [
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the playlist",
                    "label": "Title",
                    "placeholder": "My Favorite Videos",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the playlist",
                    "label": "Description",
                    "placeholder": "A collection of my most watched videos",
                },
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tags for the playlist (comma-separated)",
                    "label": "Tags",
                    "placeholder": "tag1, tag2, tag3",
                },
                {
                    "field": "default_language",
                    "type": "string",
                    "value": "",
                    "helper_text": "Default language of the playlist",
                    "label": "Default Language",
                    "placeholder": "en",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "value": "private",
                    "helper_text": "Privacy status of the playlist",
                    "label": "Privacy Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_privacy_status",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the created playlist",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the playlist",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the playlist",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the playlist was created",
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel that owns the playlist",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Privacy status of the playlist",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "create_playlist",
            "task_name": "tasks.youtube.create_playlist",
            "description": "Create a YouTube playlist",
            "label": "Create Playlist",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "title",
                "description",
                "tags",
                "default_language",
                "privacy_status",
            ],
            "required": ["title"],
        },
        "delete_playlist": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist to delete",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the deleted playlist",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "delete_playlist",
            "task_name": "tasks.youtube.delete_playlist",
            "description": "Delete a YouTube playlist",
            "label": "Delete Playlist",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action", "playlist_id"],
            "required": ["playlist_id"],
        },
        "get_playlist": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist to retrieve",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the playlist",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the playlist",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the playlist",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the playlist was created",
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel that owns the playlist",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Privacy status of the playlist",
                },
                {
                    "field": "item_count",
                    "type": "int32",
                    "helper_text": "Number of items in the playlist",
                },
                {
                    "field": "thumbnails",
                    "type": "string",
                    "helper_text": "Thumbnail URLs object",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "get_playlist",
            "task_name": "tasks.youtube.get_playlist",
            "description": "Get a YouTube playlist",
            "label": "Get Playlist",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action", "playlist_id"],
            "required": ["playlist_id"],
        },
        "list_playlists": {
            "inputs": [
                {
                    "field": "playlist_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of playlist IDs",
                    "label": "Playlist IDs",
                    "placeholder": "PLrAl6c7v8w2N3XYZ,PLbC4d9e5f6g7H8IJ",
                },
                {
                    "field": "mine",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Get your own playlists",
                    "label": "My Playlists",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of results to return",
                    "label": "Max Results",
                },
                {
                    "field": "page_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Page token for pagination",
                    "label": "Page Token",
                    "placeholder": "CAUQAA",
                },
                {
                    "field": "fetch_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Fetch all playlists",
                    "label": "Fetch All",
                },
            ],
            "outputs": [
                {
                    "field": "playlist_ids",
                    "type": "vec<string>",
                    "helper_text": "List of playlist IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of playlist titles",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of playlist descriptions",
                },
                {
                    "field": "published_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of playlist published at timestamps",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs that own the playlists",
                },
                {
                    "field": "channel_titles",
                    "type": "vec<string>",
                    "helper_text": "List of channel titles that own the playlists",
                },
                {
                    "field": "tags",
                    "type": "vec<string>",
                    "helper_text": "List of playlist tags",
                },
                {
                    "field": "default_languages",
                    "type": "vec<string>",
                    "helper_text": "List of playlist default languages",
                },
                {
                    "field": "thumbnail_urls",
                    "type": "vec<string>",
                    "helper_text": "List of playlist thumbnail URLs",
                },
                {
                    "field": "privacy_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of playlist privacy statuses",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of playlists",
                },
                {
                    "field": "next_page_token",
                    "type": "string",
                    "helper_text": "Token for next page",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "list_playlists",
            "task_name": "tasks.youtube.list_playlists",
            "description": "List YouTube playlists",
            "label": "List Playlists",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "playlist_ids",
                "mine",
                "max_results",
                "page_token",
                "fetch_all",
            ],
            "required": ["max_results"],
        },
        "update_playlist": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist to update",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the playlist",
                    "label": "Title",
                    "placeholder": "My Updated Playlist",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the playlist",
                    "label": "Description",
                    "placeholder": "This playlist contains updated content",
                },
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tags for the playlist (comma-separated)",
                    "label": "Tags",
                    "placeholder": "tag1, tag2, tag3",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Privacy status of the playlist",
                    "label": "Privacy Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_privacy_status",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the updated playlist",
                },
                {"field": "title", "type": "string", "helper_text": "Updated title"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Updated description",
                },
                {"field": "tags", "type": "string", "helper_text": "Updated tags"},
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Updated privacy status",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "update_playlist",
            "task_name": "tasks.youtube.update_playlist",
            "description": "Update a YouTube playlist",
            "label": "Update Playlist",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "playlist_id",
                "title",
                "description",
                "tags",
                "privacy_status",
            ],
            "required": ["playlist_id"],
        },
        "add_playlist_item": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the video to add",
                    "label": "Video ID",
                    "placeholder": "dQw4w9WgXcQ",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "value": "",
                    "helper_text": "Position in the playlist",
                    "label": "Position",
                    "placeholder": "1",
                },
                {
                    "field": "note",
                    "type": "string",
                    "value": "",
                    "helper_text": "Note about the playlist item",
                    "label": "Note",
                    "placeholder": "My favorite part is at 2:30",
                },
                {
                    "field": "start_at",
                    "type": "string",
                    "value": "",
                    "helper_text": "Start time (PT1M30S format)",
                    "label": "Start At",
                    "placeholder": "PT1M30S",
                },
                {
                    "field": "end_at",
                    "type": "string",
                    "value": "",
                    "helper_text": "End time (PT2M30S format)",
                    "label": "End At",
                    "placeholder": "PT2M30S",
                },
            ],
            "outputs": [
                {
                    "field": "playlist_item_id",
                    "type": "string",
                    "helper_text": "ID of the created playlist item",
                },
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the playlist",
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the video",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position in the playlist",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the video",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the item was added",
                },
                {
                    "field": "thumbnail_url",
                    "type": "string",
                    "helper_text": "Thumbnail URL",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "add_playlist_item",
            "task_name": "tasks.youtube.add_playlist_item",
            "description": "Add a video to a YouTube playlist",
            "label": "Add Playlist Item",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "playlist_id",
                "video_id",
                "position",
                "note",
                "start_at",
                "end_at",
            ],
            "required": ["playlist_id", "video_id"],
        },
        "delete_playlist_item": {
            "inputs": [
                {
                    "field": "playlist_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist item to delete",
                    "label": "Playlist Item ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ001",
                }
            ],
            "outputs": [
                {
                    "field": "playlist_item_id",
                    "type": "string",
                    "helper_text": "ID of the deleted playlist item",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "delete_playlist_item",
            "task_name": "tasks.youtube.delete_playlist_item",
            "description": "Delete a video from a YouTube playlist",
            "label": "Delete Playlist Item",
            "variant": "default_integration_nodes",
            "input_sort_order": ["integration", "action", "playlist_item_id"],
            "required": ["playlist_item_id"],
        },
        "get_playlist_item": {
            "inputs": [
                {
                    "field": "playlist_item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist item to retrieve",
                    "label": "Playlist Item ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ001",
                }
            ],
            "outputs": [
                {
                    "field": "playlist_item_id",
                    "type": "string",
                    "helper_text": "ID of the playlist item",
                },
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the playlist",
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the video",
                },
                {
                    "field": "position",
                    "type": "int32",
                    "helper_text": "Position in the playlist",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the video",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the video",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the item was published",
                },
                {
                    "field": "thumbnails",
                    "type": "string",
                    "helper_text": "Thumbnail URLs object",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Privacy status",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "get_playlist_item",
            "task_name": "tasks.youtube.get_playlist_item",
            "description": "Get a YouTube playlist item",
            "label": "Get Playlist Item",
            "variant": "default_integration_nodes",
            "input_sort_order": ["integration", "action", "playlist_item_id"],
            "required": ["playlist_item_id"],
        },
        "list_playlist_items": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the playlist",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by specific video ID",
                    "label": "Video ID",
                    "placeholder": "dQw4w9WgXcQ",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of results to return",
                    "label": "Max Results",
                },
                {
                    "field": "page_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Page token for pagination",
                    "label": "Page Token",
                    "placeholder": "CAUQAA",
                },
                {
                    "field": "fetch_all",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Fetch all playlist items",
                    "label": "Fetch All",
                },
            ],
            "outputs": [
                {
                    "field": "playlist_item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of playlist item IDs",
                },
                {
                    "field": "playlist_ids",
                    "type": "vec<string>",
                    "helper_text": "List of playlist IDs",
                },
                {
                    "field": "video_ids",
                    "type": "vec<string>",
                    "helper_text": "List of video IDs",
                },
                {
                    "field": "positions",
                    "type": "vec<int32>",
                    "helper_text": "List of positions in playlist",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of video titles",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of video descriptions",
                },
                {
                    "field": "published_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of published at timestamps",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs",
                },
                {
                    "field": "channel_titles",
                    "type": "vec<string>",
                    "helper_text": "List of channel titles",
                },
                {
                    "field": "video_owner_channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of video owner channel IDs",
                },
                {
                    "field": "video_owner_channel_titles",
                    "type": "vec<string>",
                    "helper_text": "List of video owner channel titles",
                },
                {
                    "field": "thumbnail_urls",
                    "type": "vec<string>",
                    "helper_text": "List of thumbnail URLs",
                },
                {
                    "field": "start_ats",
                    "type": "vec<string>",
                    "helper_text": "List of start at times",
                },
                {
                    "field": "end_ats",
                    "type": "vec<string>",
                    "helper_text": "List of end at times",
                },
                {
                    "field": "notes",
                    "type": "vec<string>",
                    "helper_text": "List of notes",
                },
                {
                    "field": "video_published_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of video published at timestamps",
                },
                {
                    "field": "privacy_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of privacy statuses",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of results",
                },
                {
                    "field": "item_count",
                    "type": "int32",
                    "helper_text": "Number of items returned",
                },
                {
                    "field": "next_page_token",
                    "type": "string",
                    "helper_text": "Token for next page",
                },
                {
                    "field": "playlist_id",
                    "type": "string",
                    "helper_text": "ID of the playlist",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "list_playlist_items",
            "task_name": "tasks.youtube.list_playlist_items",
            "description": "List items in a YouTube playlist",
            "label": "List Playlist Items",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "playlist_id",
                "video_id",
                "max_results",
                "page_token",
                "fetch_all",
            ],
            "required": ["playlist_id", "max_results"],
        },
        "delete_video": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Playlist ID to filter videos",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the video to delete",
                    "label": "Video ID",
                    "placeholder": "dQw4w9WgXcQ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=video_id&playlist_id={inputs.playlist_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the deleted video",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "delete_video",
            "task_name": "tasks.youtube.delete_video",
            "description": "Delete a YouTube video",
            "label": "Delete Video",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action", "playlist_id", "video_id"],
            "required": ["video_id"],
        },
        "get_video": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Playlist ID to filter videos",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the video to retrieve",
                    "label": "Video ID",
                    "placeholder": "dQw4w9WgXcQ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=video_id&playlist_id={inputs.playlist_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the video",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the video",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the video",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the video was published",
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "channel_title",
                    "type": "string",
                    "helper_text": "Title of the channel",
                },
                {"field": "tags", "type": "vec<string>", "helper_text": "List of tags"},
                {
                    "field": "category_id",
                    "type": "string",
                    "helper_text": "Category ID of the video",
                },
                {
                    "field": "duration",
                    "type": "string",
                    "helper_text": "Duration of the video",
                },
                {
                    "field": "view_count",
                    "type": "string",
                    "helper_text": "View count of the video",
                },
                {
                    "field": "like_count",
                    "type": "string",
                    "helper_text": "Like count of the video",
                },
                {
                    "field": "comment_count",
                    "type": "string",
                    "helper_text": "Comment count of the video",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Privacy status of the video",
                },
                {
                    "field": "upload_status",
                    "type": "string",
                    "helper_text": "Upload status of the video",
                },
                {
                    "field": "thumbnails",
                    "type": "string",
                    "helper_text": "Thumbnail URLs object",
                },
                {
                    "field": "embed_html",
                    "type": "string",
                    "helper_text": "HTML embed code",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "get_video",
            "task_name": "tasks.youtube.get_video",
            "description": "Get a YouTube video",
            "label": "Get Video",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action", "playlist_id", "video_id"],
            "required": ["video_id"],
        },
        "list_videos": {
            "inputs": [
                {
                    "field": "video_ids",
                    "type": "string",
                    "value": "",
                    "helper_text": "Comma-separated list of video IDs",
                    "label": "Video IDs",
                    "placeholder": "dQw4w9WgXcQ,jNQXAC9IVRw",
                },
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Get videos from a playlist",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Get videos by category",
                    "label": "Category ID",
                    "placeholder": "10",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Film & Animation", "value": "1"},
                            {"label": "Autos & Vehicles", "value": "2"},
                            {"label": "Music", "value": "10"},
                            {"label": "Pets & Animals", "value": "15"},
                            {"label": "Sports", "value": "17"},
                            {"label": "Travel & Events", "value": "19"},
                            {"label": "Gaming", "value": "20"},
                            {"label": "People & Blogs", "value": "22"},
                            {"label": "Comedy", "value": "23"},
                            {"label": "Entertainment", "value": "24"},
                            {"label": "News & Politics", "value": "25"},
                            {"label": "Howto & Style", "value": "26"},
                            {"label": "Education", "value": "27"},
                            {"label": "Science & Technology", "value": "28"},
                            {"label": "Nonprofits & Activism", "value": "29"},
                        ],
                    },
                },
                {
                    "field": "chart",
                    "type": "string",
                    "value": "mostPopular",
                    "helper_text": "Chart to retrieve",
                    "label": "Chart",
                    "component": {
                        "type": "dropdown",
                        "options": [{"label": "Most Popular", "value": "mostPopular"}],
                    },
                },
                {
                    "field": "region_code",
                    "type": "string",
                    "value": "",
                    "helper_text": "Region code for results",
                    "label": "Region Code",
                    "placeholder": "US",
                },
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of results to return",
                    "label": "Max Results",
                },
                {
                    "field": "page_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Page token for pagination",
                    "label": "Page Token",
                    "placeholder": "CAUQAA",
                },
            ],
            "outputs": [
                {
                    "field": "video_ids",
                    "type": "vec<string>",
                    "helper_text": "List of video IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of video titles",
                },
                {
                    "field": "descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of video descriptions",
                },
                {
                    "field": "published_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of video published at timestamps",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs",
                },
                {
                    "field": "channel_titles",
                    "type": "vec<string>",
                    "helper_text": "List of channel titles",
                },
                {
                    "field": "tags",
                    "type": "vec<string>",
                    "helper_text": "List of video tags",
                },
                {
                    "field": "category_ids",
                    "type": "vec<string>",
                    "helper_text": "List of video category IDs",
                },
                {
                    "field": "thumbnail_urls",
                    "type": "vec<string>",
                    "helper_text": "List of video thumbnail URLs",
                },
                {
                    "field": "privacy_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of video privacy statuses",
                },
                {
                    "field": "upload_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of video upload statuses",
                },
                {
                    "field": "embeddables",
                    "type": "vec<bool>",
                    "helper_text": "List of video embeddable values",
                },
                {
                    "field": "made_for_kids",
                    "type": "vec<bool>",
                    "helper_text": "List of video made for kids values",
                },
                {
                    "field": "durations",
                    "type": "vec<string>",
                    "helper_text": "List of video durations",
                },
                {
                    "field": "definitions",
                    "type": "vec<string>",
                    "helper_text": "List of video definitions",
                },
                {
                    "field": "captions",
                    "type": "vec<string>",
                    "helper_text": "List of video caption values",
                },
                {
                    "field": "view_counts",
                    "type": "vec<string>",
                    "helper_text": "List of video view counts",
                },
                {
                    "field": "like_counts",
                    "type": "vec<string>",
                    "helper_text": "List of video like counts",
                },
                {
                    "field": "comment_counts",
                    "type": "vec<string>",
                    "helper_text": "List of video comment counts",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of results",
                },
                {
                    "field": "next_page_token",
                    "type": "string",
                    "helper_text": "Token for next page",
                },
                {
                    "field": "prev_page_token",
                    "type": "string",
                    "helper_text": "Token for previous page",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "list_videos",
            "task_name": "tasks.youtube.list_videos",
            "description": "List YouTube videos",
            "label": "List Videos",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "video_ids",
                "playlist_id",
                "category_id",
                "chart",
                "region_code",
                "max_results",
                "page_token",
            ],
            "required": ["max_results"],
        },
        "rate_video": {
            "inputs": [
                {
                    "field": "video_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the video to rate",
                    "label": "Video ID",
                    "placeholder": "dQw4w9WgXcQ",
                },
                {
                    "field": "rating",
                    "type": "string",
                    "value": "",
                    "helper_text": "Rating to give the video",
                    "label": "Rating",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_video_rating",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the rated video",
                },
                {
                    "field": "rating",
                    "type": "string",
                    "helper_text": "Rating given to the video",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "rate_video",
            "task_name": "tasks.youtube.rate_video",
            "description": "Rate a YouTube video",
            "label": "Rate Video",
            "variant": "common_integration_nodes",
            "input_sort_order": ["integration", "action", "video_id", "rating"],
            "required": ["video_id", "rating"],
        },
        "update_video": {
            "inputs": [
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Playlist ID to filter videos",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "show_on_node": True,
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "video_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "The ID of the video to update",
                    "label": "Video ID",
                    "placeholder": "dQw4w9WgXcQ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=video_id&playlist_id={inputs.playlist_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "New title for the video",
                    "label": "Title",
                    "placeholder": "My Amazing Video",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the video",
                    "label": "Description",
                    "placeholder": "This video shows how to do amazing things",
                },
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tags for the video (comma-separated)",
                    "label": "Tags",
                    "placeholder": "tag1, tag2, tag3",
                },
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Category ID for the video",
                    "label": "Category ID",
                    "placeholder": "10",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_category_id",
                    },
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "value": "",
                    "helper_text": "Privacy status of the video",
                    "label": "Privacy Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_privacy_status",
                    },
                },
                {
                    "field": "publish_at",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Publish date and time of the video",
                    "label": "Publish At",
                    "placeholder": "2025-01-01T00:00:00Z",
                },
                {
                    "field": "default_language",
                    "type": "string",
                    "value": "",
                    "helper_text": "Default language of the video",
                    "label": "Default Language",
                    "placeholder": "en",
                },
                {
                    "field": "license",
                    "type": "string",
                    "value": "",
                    "helper_text": "License of the video",
                    "label": "License",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_license",
                    },
                },
                {
                    "field": "public_stats_viewable",
                    "type": "bool",
                    "value": "",
                    "helper_text": "Whether the video's stats are viewable",
                    "label": "Public Stats Viewable",
                },
                {
                    "field": "recording_date",
                    "type": "string",
                    "value": "",
                    "helper_text": "Recording date of the video",
                    "label": "Recording Date",
                    "placeholder": "2025-01-01",
                },
                {
                    "field": "embeddable",
                    "type": "bool",
                    "value": "",
                    "helper_text": "Whether the video can be embedded",
                    "label": "Embeddable",
                },
                {
                    "field": "made_for_kids",
                    "type": "bool",
                    "value": "",
                    "helper_text": "Whether the video is made for kids",
                    "label": "Made for Kids",
                },
            ],
            "outputs": [
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the updated video",
                },
                {"field": "title", "type": "string", "helper_text": "Updated title"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Updated description",
                },
                {"field": "tags", "type": "vec<string>", "helper_text": "Updated tags"},
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Updated privacy status",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "update_video",
            "task_name": "tasks.youtube.update_video",
            "description": "Update a YouTube video's metadata",
            "label": "Update Video Metadata",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "playlist_id",
                "video_id",
                "title",
                "description",
                "tags",
                "category_id",
                "privacy_status",
                "publish_at",
                "default_language",
                "license",
                "public_stats_viewable",
                "recording_date",
                "embeddable",
                "made_for_kids",
            ],
            "required": ["video_id"],
        },
        "upload_video": {
            "inputs": [
                {
                    "field": "video_file",
                    "type": "file",
                    "value": "",
                    "helper_text": "Video file to upload",
                    "label": "Video File",
                },
                {
                    "field": "title",
                    "type": "string",
                    "value": "",
                    "helper_text": "Title of the video",
                    "label": "Title",
                    "placeholder": "Optional - uses filename if not provided",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the video",
                    "label": "Description",
                    "placeholder": "Optional",
                },
                {
                    "field": "tags",
                    "type": "string",
                    "value": "",
                    "helper_text": "Tags for the video (comma-separated)",
                    "label": "Tags",
                    "placeholder": "tag1, tag2, tag3",
                },
                {
                    "field": "category_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Category ID for the video",
                    "label": "Category ID",
                    "placeholder": "10",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_category_id",
                    },
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "value": "private",
                    "helper_text": "Privacy status of the video",
                    "label": "Privacy Status",
                    "component": {
                        "type": "dropdown",
                        "referenced_options": "youtube_privacy_status",
                    },
                },
                {
                    "field": "embeddable",
                    "type": "bool",
                    "value": True,
                    "helper_text": "Whether the video can be embedded",
                    "label": "Embeddable",
                },
                {
                    "field": "made_for_kids",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether the video is made for kids",
                    "label": "Made for Kids",
                },
                {
                    "field": "playlist_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Add video to this playlist after upload",
                    "label": "Playlist ID",
                    "placeholder": "PLrAl6c7v8w2N3XYZ",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=playlist_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "video_id",
                    "type": "string",
                    "helper_text": "ID of the uploaded video",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the video",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the video",
                },
                {
                    "field": "published_at",
                    "type": "timestamp",
                    "helper_text": "When the video was published",
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "upload_status",
                    "type": "string",
                    "helper_text": "Upload status",
                },
                {
                    "field": "privacy_status",
                    "type": "string",
                    "helper_text": "Privacy status",
                },
                {
                    "field": "thumbnail_url",
                    "type": "string",
                    "helper_text": "Thumbnail URL",
                },
                {
                    "field": "added_to_playlist",
                    "type": "string",
                    "helper_text": "Playlist ID if video was added to playlist",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "upload_video",
            "task_name": "tasks.youtube.upload_video",
            "description": "Upload a video to YouTube",
            "label": "Upload Video",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "integration",
                "action",
                "video_file",
                "title",
                "description",
                "tags",
                "category_id",
                "privacy_status",
                "embeddable",
                "made_for_kids",
                "playlist_id",
            ],
            "required": ["video_file"],
        },
        "list_video_categories": {
            "inputs": [
                {
                    "field": "region_code",
                    "type": "string",
                    "value": "US",
                    "helper_text": "Region code for video categories",
                    "label": "Region Code",
                    "placeholder": "US",
                },
                {
                    "field": "language",
                    "type": "string",
                    "value": "",
                    "helper_text": "Language for category names",
                    "label": "Language",
                    "placeholder": "en",
                },
            ],
            "outputs": [
                {
                    "field": "category_ids",
                    "type": "vec<string>",
                    "helper_text": "List of video category IDs",
                },
                {
                    "field": "titles",
                    "type": "vec<string>",
                    "helper_text": "List of video category titles",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "List of channel IDs",
                },
                {
                    "field": "assignables",
                    "type": "vec<bool>",
                    "helper_text": "List of assignable values",
                },
                {
                    "field": "region_code",
                    "type": "string",
                    "helper_text": "Region code used",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of categories",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response data",
                },
            ],
            "name": "list_video_categories",
            "task_name": "tasks.youtube.list_video_categories",
            "description": "List YouTube video categories",
            "label": "List Video Categories",
            "variant": "default_integration_nodes",
            "input_sort_order": ["integration", "action", "region_code", "language"],
            "required": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        banner_image: Any = None,
        category_id: str = "",
        channel_ids: str = "",
        chart: str = "mostPopular",
        default_language: str = "",
        default_tab: str = "",
        description: str = "",
        embeddable: bool = False,
        end_at: str = "",
        featured_channels_title: str = "",
        featured_channels_urls: str = "",
        fetch_all: bool = False,
        keywords: str = "",
        language: str = "",
        license: str = "",
        made_for_kids: bool = False,
        managed_by_me: bool = False,
        max_results: int = 10,
        mine: bool = True,
        moderate_comments: str = "",
        note: str = "",
        page_token: str = "",
        playlist_id: str = "",
        playlist_ids: str = "",
        playlist_item_id: str = "",
        position: int = None,
        privacy_status: str = "private",
        public_stats_viewable: bool = False,
        publish_at: Any = None,
        rating: str = "",
        recording_date: str = "",
        region_code: str = "",
        show_browse_view: str = "",
        show_related_channels: str = "",
        show_sponsor_list: str = "",
        start_at: str = "",
        tags: str = "",
        title: str = "",
        tracking_analytics_account_id: str = "",
        unsubscribed_trailer: str = "",
        username: str = "",
        video_file: str = "",
        video_id: str = "",
        video_ids: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_youtube",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if channel_ids is not None:
            self.inputs["channel_ids"] = channel_ids
        if username is not None:
            self.inputs["username"] = username
        if mine is not None:
            self.inputs["mine"] = mine
        if managed_by_me is not None:
            self.inputs["managed_by_me"] = managed_by_me
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if page_token is not None:
            self.inputs["page_token"] = page_token
        if title is not None:
            self.inputs["title"] = title
        if description is not None:
            self.inputs["description"] = description
        if keywords is not None:
            self.inputs["keywords"] = keywords
        if default_tab is not None:
            self.inputs["default_tab"] = default_tab
        if tracking_analytics_account_id is not None:
            self.inputs["tracking_analytics_account_id"] = tracking_analytics_account_id
        if moderate_comments is not None:
            self.inputs["moderate_comments"] = moderate_comments
        if show_related_channels is not None:
            self.inputs["show_related_channels"] = show_related_channels
        if show_sponsor_list is not None:
            self.inputs["show_sponsor_list"] = show_sponsor_list
        if show_browse_view is not None:
            self.inputs["show_browse_view"] = show_browse_view
        if featured_channels_title is not None:
            self.inputs["featured_channels_title"] = featured_channels_title
        if featured_channels_urls is not None:
            self.inputs["featured_channels_urls"] = featured_channels_urls
        if unsubscribed_trailer is not None:
            self.inputs["unsubscribed_trailer"] = unsubscribed_trailer
        if banner_image is not None:
            self.inputs["banner_image"] = banner_image
        if tags is not None:
            self.inputs["tags"] = tags
        if default_language is not None:
            self.inputs["default_language"] = default_language
        if privacy_status is not None:
            self.inputs["privacy_status"] = privacy_status
        if playlist_id is not None:
            self.inputs["playlist_id"] = playlist_id
        if playlist_ids is not None:
            self.inputs["playlist_ids"] = playlist_ids
        if fetch_all is not None:
            self.inputs["fetch_all"] = fetch_all
        if video_id is not None:
            self.inputs["video_id"] = video_id
        if position is not None:
            self.inputs["position"] = position
        if note is not None:
            self.inputs["note"] = note
        if start_at is not None:
            self.inputs["start_at"] = start_at
        if end_at is not None:
            self.inputs["end_at"] = end_at
        if playlist_item_id is not None:
            self.inputs["playlist_item_id"] = playlist_item_id
        if video_ids is not None:
            self.inputs["video_ids"] = video_ids
        if category_id is not None:
            self.inputs["category_id"] = category_id
        if chart is not None:
            self.inputs["chart"] = chart
        if region_code is not None:
            self.inputs["region_code"] = region_code
        if rating is not None:
            self.inputs["rating"] = rating
        if publish_at is not None:
            self.inputs["publish_at"] = publish_at
        if license is not None:
            self.inputs["license"] = license
        if public_stats_viewable is not None:
            self.inputs["public_stats_viewable"] = public_stats_viewable
        if recording_date is not None:
            self.inputs["recording_date"] = recording_date
        if embeddable is not None:
            self.inputs["embeddable"] = embeddable
        if made_for_kids is not None:
            self.inputs["made_for_kids"] = made_for_kids
        if video_file is not None:
            self.inputs["video_file"] = video_file
        if language is not None:
            self.inputs["language"] = language
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationYoutubeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
