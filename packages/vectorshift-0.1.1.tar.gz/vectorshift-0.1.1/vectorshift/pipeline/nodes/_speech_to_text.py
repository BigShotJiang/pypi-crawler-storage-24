"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("speech_to_text")
class SpeechToTextNode(Node):
    """


    ## Inputs
    ### Common Inputs
        model: The model input
        audio: The audio input
    ### Deepgram
        submodel: The submodel input
        tier: The tier input

    ## Outputs
    ### Common Outputs
        text: The text output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The model input",
            "value": "OpenAI Whisper",
            "type": "string",
        },
        {
            "field": "audio",
            "helper_text": "The audio input",
            "value": "",
            "type": "audio",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "text", "helper_text": "The text output", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "OpenAI Whisper": {"inputs": [], "outputs": []},
        "Deepgram": {
            "inputs": [
                {
                    "field": "submodel",
                    "type": "string",
                    "value": "nova-2",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "tier",
                    "type": "string",
                    "value": "general",
                    "component": {"type": "dropdown"},
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["model"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["audio"]

    def __init__(
        self,
        model: str = "OpenAI Whisper",
        audio: Any = None,
        submodel: str = "nova-2",
        tier: str = "general",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["model"] = model

        super().__init__(
            node_type="speech_to_text",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if model is not None:
            self.inputs["model"] = model
        if audio is not None:
            self.inputs["audio"] = audio
        if submodel is not None:
            self.inputs["submodel"] = submodel
        if tier is not None:
            self.inputs["tier"] = tier
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "SpeechToTextNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
