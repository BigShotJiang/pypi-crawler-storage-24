"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_microsoft")
class IntegrationMicrosoftNode(Node):
    """
    Microsoft One Drive

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### create_file
        content_type: MIME type of the file
        file_content: Content of the file
        file_name: Name of the file to create
        folder_id: ID of the folder where the file will be created
    ### copy_file
        destination_folder_id: Select the destination folder
        file_id: Select the file to read from OneDrive
        new_name: New name for the copied file (optional)
    ### create_file_share_link
        expiration_date: Expiration date for the link (ISO 8601)
        item_id: Select the folder within your OneDrive to add the file
        link_scope: Scope of link
        link_type: Type of link
        password: Password for the link (optional)
    ### create_folder_share_link
        expiration_date: Expiration date for the link (ISO 8601)
        item_id: Select the folder within your OneDrive to add the file
        link_scope: Scope of link
        link_type: Type of link
        password: Password for the link (optional)
    ### add_file
        file: Select or Upload a file
        item_id: Select the folder within your OneDrive to add the file
    ### read_file
        file_id: Select the file to read from OneDrive
    ### delete_file
        file_id: Select the file to read from OneDrive
    ### rename_file
        file_id: Select the file to read from OneDrive
        file_name: Name of the file to create
    ### read_folder
        folder_id: ID of the folder where the file will be created
    ### delete_folder
        folder_id: ID of the folder where the file will be created
    ### rename_folder
        folder_id: ID of the folder where the file will be created
        folder_name: Name of the folder to create
    ### create_folder
        folder_name: Name of the folder to create
        parent_folder_id: Select the parent folder
    ### get_files
        limit: Maximum number of files to return
        search_folder_id: Select folder to search within (optional, leave empty to search all files)
        search_query: Search query to filter files ( will be used only if folder is not provided)
        skip_token: Token for pagination (or Microsoft Graph next-link URL)
    ### search_file_folder
        limit: Maximum number of files to return
        search_query: Search query to filter files ( will be used only if folder is not provided)
        skip_token: Token for pagination (or Microsoft Graph next-link URL)
    ### get_folders
        limit: Maximum number of files to return
        order_by: Sort order
        parent_folder_id: Select the parent folder
        skip_token: Token for pagination (or Microsoft Graph next-link URL)

    ## Outputs
    ### read_folder
        child_count: Number of items in the folder
        created_at: Creation timestamp
        folder_id: ID of the folder
        folder_name: Name of the folder
        folder_path: Full path of the folder
        folder_url: Web URL of the folder
        modified_at: Last modification timestamp
        raw_data: Complete response from the API
    ### get_folders
        child_counts: Array of child counts
        created_dates: Array of creation dates
        folder_ids: Array of folder IDs
        folder_names: Array of folder names
        folder_paths: Array of folder paths
        folder_urls: Array of folder URLs
        modified_dates: Array of modification dates
        next_link: URL for next page of results
        raw_data: Complete response from the API
    ### add_file
        created_at: Creation timestamp
        file_id: ID of the uploaded file
        file_name: Name of the uploaded file
        file_path: Full path of the file
        file_size: Size of the file in bytes
        file_url: Web URL of the file
        modified_at: Last modification timestamp
        raw_data: Complete response from the API
    ### create_file
        created_at: Creation timestamp
        file_id: ID of the created file
        file_name: Name of the created file
        file_path: Full path of the file
        file_url: Web URL of the file
        raw_data: Complete response from the API
    ### read_file
        created_at: Creation timestamp
        download_url: Direct download URL
        file: File object
        file_id: ID of the file
        file_name: Name of the file
        file_size: Size of the file in bytes
        file_url: Web URL of the file
        mime_type: MIME type of the file
        modified_at: Last modification timestamp
        raw_data: Complete response from the API
    ### create_folder
        created_at: Creation timestamp
        folder_id: ID of the created folder
        folder_name: Name of the folder
        folder_path: Full path of the folder
        folder_url: Web URL of the folder
        raw_data: Complete response from the API
    ### get_files
        created_dates: Array of creation dates
        file_ids: Array of file IDs
        file_names: Array of file names
        file_paths: Array of file paths
        file_sizes: Array of file sizes in bytes
        file_urls: Array of file URLs
        mime_types: Array of MIME types
        modified_dates: Array of modification dates
        next_link: URL for next page of results
        raw_data: Complete response from the API
    ### search_file_folder
        created_dates: List of creation dates
        item_ids: List of item IDs
        item_names: List of item names
        item_paths: List of item paths
        item_sizes: List of item sizes in bytes
        item_types: List of item types (file/folder)
        item_urls: List of item URLs
        mime_types: List of MIME types (empty for folders)
        modified_dates: List of modification dates
        next_link: URL for next page of results
        raw_data: Complete response from the API
    ### create_file_share_link
        expiration_date: When the link expires
        permissions: Permissions granted by the link
        raw_data: Complete response from the API
        share_id: ID of the share
        share_link: The sharing link URL
    ### create_folder_share_link
        expiration_date: When the link expires
        permissions: Permissions granted by the link
        raw_data: Complete response from the API
        share_id: ID of the share
        share_link: The sharing link URL
    ### rename_file
        file_id: ID of the file
        file_name: Name of the file
        file_path: Full path of the file
        file_url: Web URL of the file
        modified_at: Last modification timestamp
        raw_data: Complete response from the API
    ### rename_folder
        folder_id: ID of the folder
        folder_name: Updated name of the folder
        folder_url: Web URL of the folder
        modified_at: Last modification timestamp
        raw_data: Complete response from the API
    ### delete_file
        message: Status message
    ### copy_file
        message: Status message
        success: Whether the copy was successful
    ### delete_folder
        message: Status message
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Microsoft>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_file_nodes",
        },
        "add_file": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder within your OneDrive to add the file",
                    "agent_helper_text": "Folder ID (item id) where the file should be uploaded. NEVER use {user_integration} or the integration/account value here. If the user does not provide a folder ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "label": "File",
                    "placeholder": "Select a file",
                    "helper_text": "Select or Upload a file",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the uploaded file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "Web URL of the file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Full path of the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "add_file",
            "task_name": "tasks.microsoft.add_file",
            "description": "Add file to OneDrive",
            "label": "Add File",
            "ui_sort_order": ["integration", "action", "item_id", "file"],
        },
        "create_file": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the folder where the file will be created",
                    "agent_helper_text": "Folder ID where the file will be created (e.g. 'root' for the root folder). NEVER use {user_integration} or the integration/account value here. If the user provides a folder name instead of an ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "hidden": True,
                    "label": "Folder ID",
                    "placeholder": "root",
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the file to create",
                    "label": "File Name",
                    "placeholder": "document.txt",
                    "order": 4,
                },
                {
                    "field": "file_content",
                    "type": "string",
                    "value": "",
                    "helper_text": "Content of the file",
                    "label": "File Content",
                    "placeholder": "File content here",
                    "order": 5,
                },
                {
                    "field": "content_type",
                    "type": "string",
                    "value": "text/plain",
                    "helper_text": "MIME type of the file",
                    "label": "Content Type",
                    "placeholder": "text/plain",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the created file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the created file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "Web URL of the file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Full path of the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "create_file",
            "task_name": "tasks.microsoft.create_file",
            "description": "Create a new file in OneDrive",
            "label": "Create File",
            "ui_sort_order": [
                "integration",
                "action",
                "folder_id",
                "file_name",
                "file_content",
                "content_type",
            ],
        },
        "read_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to read from OneDrive",
                    "agent_helper_text": "The actual file ID of the file to read. NEVER use {user_integration} or the integration/account value here. If the user does not provide a file ID, you MUST first call 'List Files' (get_files) to search for the file by name and get its ID, then use that ID here.",
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [
                {"field": "file", "type": "file", "helper_text": "File object"},
                {"field": "file_id", "type": "string", "helper_text": "ID of the file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "Web URL of the file",
                },
                {
                    "field": "download_url",
                    "type": "string",
                    "helper_text": "Direct download URL",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "read_file",
            "task_name": "tasks.microsoft.read_file",
            "description": "Read details of a specific file",
            "label": "Get File",
            "inputs_sort_order": ["integration", "action", "file_id"],
        },
        "delete_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "hidden": True,
                    "label": "File",
                    "helper_text": "Select the file to delete from OneDrive",
                    "agent_helper_text": "The actual file ID of the file to delete. NEVER use {user_integration} or the integration/account value here. If the user does not provide a file ID, you MUST first call 'List Files' (get_files) to search for the file by name and get its ID, then use that ID here.",
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"}
            ],
            "name": "delete_file",
            "task_name": "tasks.microsoft.delete_file",
            "description": "Delete a file from OneDrive",
            "label": "Delete File",
            "ui_sort_order": ["integration", "action", "file_id"],
        },
        "get_files": {
            "inputs": [
                {
                    "field": "search_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select folder to search within (optional, leave empty to search all files)",
                    "agent_helper_text": "Folder ID to search within, or leave empty to search all files. NEVER use {user_integration} or the integration/account value here. If the user mentions a folder name, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here. Leave empty if the user does not specify a folder.",
                    "label": "Search Folder",
                    "placeholder": "",
                    "order": 3,
                    "hidden": True,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "search_query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to filter files ( will be used only if folder is not provided)",
                    "label": "Search Query",
                    "placeholder": "document",
                    "order": 4,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of files to return",
                    "label": "Limit",
                    "order": 5,
                },
                {
                    "field": "skip_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Token for pagination (or Microsoft Graph next-link URL)",
                    "label": "Skip Token",
                    "placeholder": "pagination_token",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of file IDs",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "Array of file names",
                },
                {
                    "field": "file_urls",
                    "type": "vec<string>",
                    "helper_text": "Array of file URLs",
                },
                {
                    "field": "file_sizes",
                    "type": "vec<string>",
                    "helper_text": "Array of file sizes in bytes",
                },
                {
                    "field": "mime_types",
                    "type": "vec<string>",
                    "helper_text": "Array of MIME types",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of creation dates",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of modification dates",
                },
                {
                    "field": "file_paths",
                    "type": "vec<string>",
                    "helper_text": "Array of file paths",
                },
                {
                    "field": "next_link",
                    "type": "string",
                    "helper_text": "URL for next page of results",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "get_files",
            "task_name": "tasks.microsoft.get_files",
            "description": "Get multiple files",
            "label": "List Files",
            "inputs_sort_order": [
                "integration",
                "action",
                "search_query",
                "limit",
                "skip_token",
            ],
        },
        "search_file_folder": {
            "inputs": [
                {
                    "field": "search_query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Search query to find files and folders in OneDrive",
                    "label": "Search Query",
                    "placeholder": "document",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of items to return",
                    "label": "Limit",
                },
                {
                    "field": "skip_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Pagination token (or Microsoft Graph next-link URL)",
                    "label": "Skip Token",
                    "placeholder": "pagination_token",
                },
            ],
            "outputs": [
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of item IDs",
                },
                {
                    "field": "item_names",
                    "type": "vec<string>",
                    "helper_text": "List of item names",
                },
                {
                    "field": "item_types",
                    "type": "vec<string>",
                    "helper_text": "List of item types (file/folder)",
                },
                {
                    "field": "item_urls",
                    "type": "vec<string>",
                    "helper_text": "List of item URLs",
                },
                {
                    "field": "item_paths",
                    "type": "vec<string>",
                    "helper_text": "List of item paths",
                },
                {
                    "field": "item_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of item sizes in bytes",
                },
                {
                    "field": "mime_types",
                    "type": "vec<string>",
                    "helper_text": "List of MIME types (empty for folders)",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation dates",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of modification dates",
                },
                {
                    "field": "next_link",
                    "type": "string",
                    "helper_text": "URL for next page of results",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "search_file_folder",
            "task_name": "tasks.microsoft.search_file_folder",
            "description": "Search files and folders across OneDrive",
            "label": "Search File/Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "search_query",
                "limit",
                "skip_token",
            ],
            "required": ["search_query", "limit"],
        },
        "copy_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the file to copy",
                    "agent_helper_text": "The actual file ID of the source file to copy. NEVER use {user_integration} or the integration/account value here. If the user does not provide a file ID, you MUST first call 'List Files' (get_files) to search for the file by name and get its ID, then use that ID here.",
                    "label": "File",
                    "hidden": True,
                    "placeholder": "abc123",
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the destination folder",
                    "agent_helper_text": "The actual folder ID of the destination folder. NEVER use {user_integration} or the integration/account value here. If the user provides a folder name instead of an ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "hidden": True,
                    "label": "Destination Folder",
                    "placeholder": "def456",
                    "order": 4,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "new_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the copied file (optional)",
                    "label": "New Name",
                    "placeholder": "copy_of_file.txt",
                    "order": 5,
                },
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"},
                {
                    "field": "success",
                    "type": "bool",
                    "helper_text": "Whether the copy was successful",
                },
            ],
            "name": "copy_file",
            "task_name": "tasks.microsoft.copy_file",
            "description": "Copy a file to another location",
            "label": "Copy File",
            "ui_sort_order": [
                "integration",
                "action",
                "file_id",
                "destination_folder_id",
                "new_name",
            ],
        },
        "rename_file": {
            "inputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the file to rename",
                    "agent_helper_text": "The actual file ID of the file to rename. NEVER use {user_integration} or the integration/account value here. If the user does not provide a file ID, you MUST first call 'List Files' (get_files) to search for the file by name and get its ID, then use that ID here.",
                    "label": "File",
                    "placeholder": "abc123",
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the file",
                    "label": "File Name",
                    "placeholder": "renamed_file.txt",
                    "order": 4,
                },
            ],
            "outputs": [
                {"field": "file_id", "type": "string", "helper_text": "ID of the file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_url",
                    "type": "string",
                    "helper_text": "Web URL of the file",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Full path of the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "rename_file",
            "task_name": "tasks.microsoft.rename_file",
            "description": "Rename a file in OneDrive",
            "label": "Rename File",
            "ui_sort_order": ["integration", "action", "file_id", "file_name"],
        },
        "create_file_share_link": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the file",
                    "agent_helper_text": "The actual file ID (item_id) of the file to share. NEVER use {user_integration} or the integration/account value here. If the user does not provide a file ID, you MUST first call 'List Files' (get_files) to search for the file by name and get its ID, then use that ID here.",
                    "label": "File",
                    "placeholder": "abc123",
                    "hidden": True,
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "link_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of link",
                    "label": "Link Type",
                    "placeholder": "view or edit or embed",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "View", "value": "view"},
                            {"label": "Edit", "value": "edit"},
                            {"label": "Embed", "value": "embed"},
                        ],
                    },
                    "order": 4,
                },
                {
                    "field": "link_scope",
                    "type": "string",
                    "value": "",
                    "helper_text": "Scope of link",
                    "label": "Link Scope",
                    "placeholder": "anonymous or organization",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Any One", "value": "anonymous"},
                            {"label": "Within Organization", "value": "organization"},
                        ],
                    },
                    "order": 5,
                },
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "helper_text": "Password for the link (optional)",
                    "label": "Password",
                    "placeholder": "optional_password",
                    "order": 6,
                },
                {
                    "field": "expiration_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Expiration date for the link (ISO 8601)",
                    "label": "Expiration Date",
                    "placeholder": "2024-12-31T23:59:59Z",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "share_link",
                    "type": "string",
                    "helper_text": "The sharing link URL",
                },
                {
                    "field": "share_id",
                    "type": "string",
                    "helper_text": "ID of the share",
                },
                {
                    "field": "permissions",
                    "type": "vec<string>",
                    "helper_text": "Permissions granted by the link",
                },
                {
                    "field": "expiration_date",
                    "type": "timestamp",
                    "helper_text": "When the link expires",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "create_file_share_link",
            "task_name": "tasks.microsoft.create_share_link",
            "description": "Create a sharing link for a file",
            "label": "Create File Share Link",
            "ui_sort_order": [
                "integration",
                "action",
                "item_id",
                "link_type",
                "link_scope",
                "password",
                "expiration_date",
            ],
        },
        "create_folder": {
            "inputs": [
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the parent folder",
                    "agent_helper_text": "The actual folder ID of the parent folder where the new folder will be created. NEVER use {user_integration} or the integration/account value here. If the user provides a folder name instead of an ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "label": "Parent Folder",
                    "placeholder": "",
                    "hidden": True,
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the folder to create",
                    "label": "Folder Name",
                    "placeholder": "New Folder",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the created folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "folder_url",
                    "type": "string",
                    "helper_text": "Web URL of the folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Full path of the folder",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "create_folder",
            "task_name": "tasks.microsoft.create_folder",
            "description": "Create a new folder in OneDrive",
            "label": "Create Folder",
            "ui_sort_order": [
                "integration",
                "action",
                "parent_folder_id",
                "folder_name",
            ],
        },
        "read_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the folder",
                    "agent_helper_text": "The actual folder ID of the folder to read. NEVER use {user_integration} or the integration/account value here. If the user does not provide a folder ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "label": "Folder",
                    "placeholder": "abc123",
                    "hidden": True,
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the folder",
                },
                {
                    "field": "folder_url",
                    "type": "string",
                    "helper_text": "Web URL of the folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Full path of the folder",
                },
                {
                    "field": "child_count",
                    "type": "string",
                    "helper_text": "Number of items in the folder",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "read_folder",
            "task_name": "tasks.microsoft.read_folder",
            "description": "Read details of a specific folder",
            "label": "Get Folder",
            "inputs_sort_order": ["integration", "action", "folder_id"],
        },
        "delete_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the folder to delete",
                    "agent_helper_text": "The actual folder ID of the folder to delete. NEVER use {user_integration} or the integration/account value here. If the user does not provide a folder ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "label": "Folder",
                    "placeholder": "abc123",
                    "hidden": True,
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Status message"}
            ],
            "name": "delete_folder",
            "task_name": "tasks.microsoft.delete_folder",
            "description": "Delete a folder and all its contents",
            "label": "Delete Folder",
            "ui_sort_order": ["integration", "action", "folder_id"],
        },
        "get_folders": {
            "inputs": [
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the parent folder",
                    "agent_helper_text": "The actual folder ID of the parent folder to list subfolders from, or leave empty to list root-level folders. NEVER use {user_integration} or the integration/account value here. If the user gives only a folder name (e.g. 'list subfolders in my test folder'), first call get_folders with parent_folder_id empty to find the folder ID matching the name, then call get_folders again with that returned ID to list its subfolders.",
                    "label": "Parent Folder",
                    "placeholder": "root",
                    "hidden": True,
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "name",
                    "helper_text": "Sort order",
                    "label": "Order By",
                    "placeholder": "name",
                    "order": 4,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of folders to return",
                    "label": "Limit",
                    "order": 5,
                },
                {
                    "field": "skip_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Token for pagination",
                    "label": "Skip Token",
                    "placeholder": "pagination_token",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "folder_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of folder IDs",
                },
                {
                    "field": "folder_names",
                    "type": "vec<string>",
                    "helper_text": "Array of folder names",
                },
                {
                    "field": "folder_urls",
                    "type": "vec<string>",
                    "helper_text": "Array of folder URLs",
                },
                {
                    "field": "folder_paths",
                    "type": "vec<string>",
                    "helper_text": "Array of folder paths",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of creation dates",
                },
                {
                    "field": "modified_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "Array of modification dates",
                },
                {
                    "field": "child_counts",
                    "type": "vec<string>",
                    "helper_text": "Array of child counts",
                },
                {
                    "field": "next_link",
                    "type": "string",
                    "helper_text": "URL for next page of results",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "get_folders",
            "task_name": "tasks.microsoft.get_folders",
            "description": "Get multiple folders",
            "label": "List Folders",
            "inputs_sort_order": [
                "integration",
                "action",
                "parent_folder_id",
                "order_by",
                "limit",
                "skip_token",
            ],
        },
        "rename_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the folder to rename",
                    "agent_helper_text": "The actual folder ID of the folder to rename. NEVER use {user_integration} or the integration/account value here. If the user does not provide a folder ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "label": "Folder",
                    "placeholder": "abc123",
                    "order": 3,
                    "hidden": True,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the folder",
                    "label": "Folder Name",
                    "placeholder": "Renamed Folder",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Updated name of the folder",
                },
                {
                    "field": "folder_url",
                    "type": "string",
                    "helper_text": "Web URL of the folder",
                },
                {
                    "field": "modified_at",
                    "type": "timestamp",
                    "helper_text": "Last modification timestamp",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "rename_folder",
            "task_name": "tasks.microsoft.rename_folder",
            "description": "Rename a folder in OneDrive",
            "label": "Rename Folder",
            "ui_sort_order": ["integration", "action", "folder_id", "folder_name"],
        },
        "create_folder_share_link": {
            "inputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the folder",
                    "agent_helper_text": "The actual folder ID (item_id) of the folder to share. NEVER use {user_integration} or the integration/account value here. If the user does not provide a folder ID, you MUST first call 'List Folders' (get_folders) to find the folder by name and get its ID, then use that ID here.",
                    "label": "Folder",
                    "placeholder": "abc123",
                    "hidden": True,
                    "order": 3,
                    "agent_direct_value": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                    },
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "link_type",
                    "type": "string",
                    "value": "",
                    "helper_text": "Type of link",
                    "label": "Link Type",
                    "placeholder": "view or edit or embed",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "View", "value": "view"},
                            {"label": "Edit", "value": "edit"},
                        ],
                    },
                    "order": 4,
                },
                {
                    "field": "link_scope",
                    "type": "string",
                    "value": "",
                    "helper_text": "Scope of link",
                    "label": "Link Scope",
                    "placeholder": "anonymous or organization",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Any One", "value": "anonymous"},
                            {"label": "Within Organization", "value": "organization"},
                        ],
                    },
                    "order": 5,
                },
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "helper_text": "Password for the link (optional)",
                    "label": "Password",
                    "placeholder": "optional_password",
                    "order": 6,
                },
                {
                    "field": "expiration_date",
                    "type": "timestamp",
                    "value": "",
                    "helper_text": "Expiration date for the link (ISO 8601)",
                    "label": "Expiration Date",
                    "placeholder": "2024-12-31T23:59:59Z",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "share_link",
                    "type": "string",
                    "helper_text": "The sharing link URL",
                },
                {
                    "field": "share_id",
                    "type": "string",
                    "helper_text": "ID of the share",
                },
                {
                    "field": "permissions",
                    "type": "vec<string>",
                    "helper_text": "Permissions granted by the link",
                },
                {
                    "field": "expiration_date",
                    "type": "timestamp",
                    "helper_text": "When the link expires",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Complete response from the API",
                },
            ],
            "name": "create_folder_share_link",
            "task_name": "tasks.microsoft.create_share_link",
            "description": "Create a sharing link for a folder",
            "label": "Create Folder Share Link",
            "ui_sort_order": [
                "integration",
                "action",
                "item_id",
                "link_type",
                "link_scope",
                "password",
                "expiration_date",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "folder_id",
        "file_id",
        "item_id",
        "file_name",
        "folder_name",
        "file_content",
        "destination_folder_id",
        "parent_folder_id",
        "link_type",
        "link_scope",
        "permission_id",
    ]

    def __init__(
        self,
        action: str = "",
        content_type: str = "text/plain",
        destination_folder_id: str = "",
        expiration_date: Any = None,
        file: str = "",
        file_content: str = "",
        file_id: Optional[str] = None,
        file_name: str = "",
        folder_id: str = "",
        folder_name: str = "",
        item_id: Optional[str] = None,
        limit: int = 10,
        link_scope: str = "",
        link_type: str = "",
        new_name: str = "",
        order_by: str = "name",
        parent_folder_id: str = "",
        password: str = "",
        search_folder_id: str = "",
        search_query: str = "",
        skip_token: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_microsoft",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if file is not None:
            self.inputs["file"] = file
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if file_name is not None:
            self.inputs["file_name"] = file_name
        if file_content is not None:
            self.inputs["file_content"] = file_content
        if content_type is not None:
            self.inputs["content_type"] = content_type
        if file_id is not None:
            self.inputs["file_id"] = file_id
        if search_folder_id is not None:
            self.inputs["search_folder_id"] = search_folder_id
        if search_query is not None:
            self.inputs["search_query"] = search_query
        if limit is not None:
            self.inputs["limit"] = limit
        if skip_token is not None:
            self.inputs["skip_token"] = skip_token
        if destination_folder_id is not None:
            self.inputs["destination_folder_id"] = destination_folder_id
        if new_name is not None:
            self.inputs["new_name"] = new_name
        if link_type is not None:
            self.inputs["link_type"] = link_type
        if link_scope is not None:
            self.inputs["link_scope"] = link_scope
        if password is not None:
            self.inputs["password"] = password
        if expiration_date is not None:
            self.inputs["expiration_date"] = expiration_date
        if parent_folder_id is not None:
            self.inputs["parent_folder_id"] = parent_folder_id
        if folder_name is not None:
            self.inputs["folder_name"] = folder_name
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMicrosoftNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
