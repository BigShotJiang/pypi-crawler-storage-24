"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("knowledge_base_create")
class KnowledgeBaseCreateNode(Node):
    """
    Dynamically create a Knowledge Base with configured options

    ## Inputs
    ### Common Inputs
        analyze_documents: To analyze document contents and enrich them when parsing
        apify_key: Apify API Key for scraping URLs (optional)
        chunk_overlap: The overlap of the chunks to store in the knowledge base
        chunk_size: The size of the chunks to store in the knowledge base
        collection_name: The name of the collection to store the knowledge base in
        embedding_model: The embedding model to use for the knowledge base. Format: provider/model
        embedding_provider: The embedding provider to use
        file_processing_implementation: The file processing implementation to use for parsing documents
        is_hybrid: Whether to create a hybrid knowledge base
        name: The name of the knowledge base to create
        precision: The precision to use for the knowledge base
        segmentation_method: The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.
        sharded: Whether to shard the knowledge base
        splitter_method: Strategy for grouping segmented text into final chunks. 'sentence': groups sentences; 'markdown': respects Markdown structure (headers, code); 'dynamic': optimizes breaks for size using chosen segmentation method.
        vector_db_provider: The vector database provider to use

    ## Outputs
    ### Common Outputs
        knowledge_base: The created knowledge base
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "analyze_documents",
            "helper_text": "To analyze document contents and enrich them when parsing",
            "value": False,
            "type": "bool",
        },
        {
            "field": "apify_key",
            "helper_text": "Apify API Key for scraping URLs (optional)",
            "value": "",
            "type": "string",
        },
        {
            "field": "chunk_overlap",
            "helper_text": "The overlap of the chunks to store in the knowledge base",
            "value": 0,
            "type": "int32",
        },
        {
            "field": "chunk_size",
            "helper_text": "The size of the chunks to store in the knowledge base",
            "value": 400,
            "type": "int32",
        },
        {
            "field": "collection_name",
            "helper_text": "The name of the collection to store the knowledge base in",
            "value": "voyage-4-lite",
            "type": "string",
        },
        {
            "field": "embedding_model",
            "helper_text": "The embedding model to use for the knowledge base. Format: provider/model",
            "value": "voyageai/voyage-4-lite",
            "type": "enum<string>",
        },
        {
            "field": "embedding_provider",
            "helper_text": "The embedding provider to use",
            "value": "voyageai",
            "type": "string",
        },
        {
            "field": "file_processing_implementation",
            "helper_text": "The file processing implementation to use for parsing documents",
            "value": "default",
            "type": "enum<string>",
        },
        {
            "field": "is_hybrid",
            "helper_text": "Whether to create a hybrid knowledge base",
            "value": False,
            "type": "bool",
        },
        {
            "field": "name",
            "helper_text": "The name of the knowledge base to create",
            "value": "",
            "type": "string",
        },
        {
            "field": "precision",
            "helper_text": "The precision to use for the knowledge base",
            "value": "Float16",
            "type": "string",
        },
        {
            "field": "segmentation_method",
            "helper_text": "The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.",
            "value": "words",
            "type": "string",
        },
        {
            "field": "sharded",
            "helper_text": "Whether to shard the knowledge base",
            "value": True,
            "type": "bool",
        },
        {
            "field": "splitter_method",
            "helper_text": "Strategy for grouping segmented text into final chunks. 'sentence': groups sentences; 'markdown': respects Markdown structure (headers, code); 'dynamic': optimizes breaks for size using chosen segmentation method.",
            "value": "markdown",
            "type": "enum<string>",
        },
        {
            "field": "vector_db_provider",
            "helper_text": "The vector database provider to use",
            "value": "qdrant",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "knowledge_base",
            "helper_text": "The created knowledge base",
            "type": "knowledge_base",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "advanced": {
            "inputs": [
                {
                    "field": "segmentation_method",
                    "label": "Segmentation Method",
                    "type": "string",
                    "value": "words",
                    "helper_text": "The method to break text into units before chunking. 'words': splits by word; 'sentences': splits by sentence boundary; 'paragraphs': splits by blank line/paragraph.",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Words", "value": "words"},
                            {"label": "Sentences", "value": "sentences"},
                            {"label": "Paragraphs", "value": "paragraphs"},
                        ],
                    },
                    "visibility": {
                        "field": "splitter_method",
                        "operator": "==",
                        "value": "dynamic",
                    },
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["splitter_method"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "name",
        "file_processing_implementation",
        "vector_db_provider",
        "collection_name",
        "embedding_model",
        "embedding_provider",
        "precision",
        "sharded",
        "chunk_size",
        "chunk_overlap",
        "analyze_documents",
        "is_hybrid",
    ]

    def __init__(
        self,
        splitter_method: str = "markdown",
        analyze_documents: bool = False,
        apify_key: str = "",
        chunk_overlap: int = 0,
        chunk_size: int = 400,
        collection_name: str = "voyage-4-lite",
        embedding_model: str = "voyageai/voyage-4-lite",
        embedding_provider: str = "voyageai",
        file_processing_implementation: str = "default",
        is_hybrid: bool = False,
        name: str = "",
        precision: str = "Float16",
        segmentation_method: str = "words",
        sharded: bool = True,
        vector_db_provider: str = "qdrant",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["splitter_method"] = splitter_method

        super().__init__(
            node_type="knowledge_base_create",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if name is not None:
            self.inputs["name"] = name
        if file_processing_implementation is not None:
            self.inputs["file_processing_implementation"] = (
                file_processing_implementation
            )
        if embedding_model is not None:
            self.inputs["embedding_model"] = embedding_model
        if vector_db_provider is not None:
            self.inputs["vector_db_provider"] = vector_db_provider
        if collection_name is not None:
            self.inputs["collection_name"] = collection_name
        if embedding_provider is not None:
            self.inputs["embedding_provider"] = embedding_provider
        if precision is not None:
            self.inputs["precision"] = precision
        if sharded is not None:
            self.inputs["sharded"] = sharded
        if chunk_size is not None:
            self.inputs["chunk_size"] = chunk_size
        if chunk_overlap is not None:
            self.inputs["chunk_overlap"] = chunk_overlap
        if splitter_method is not None:
            self.inputs["splitter_method"] = splitter_method
        if segmentation_method is not None:
            self.inputs["segmentation_method"] = segmentation_method
        if analyze_documents is not None:
            self.inputs["analyze_documents"] = analyze_documents
        if is_hybrid is not None:
            self.inputs["is_hybrid"] = is_hybrid
        if apify_key is not None:
            self.inputs["apify_key"] = apify_key
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseCreateNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
