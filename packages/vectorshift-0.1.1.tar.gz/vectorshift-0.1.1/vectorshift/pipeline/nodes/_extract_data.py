"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import NameTypeDescription


@Node.register_node_type("extract_data")
class ExtractDataNode(Node):
    """
    Extract key pieces of information or a list of information from a input text.

    ## Inputs
    ### Common Inputs
        model: The specific model for data extraction
        text: The text that data will be extracted from
        additional_context: Provide any additional context or instructions on how to extarct the text
        fields: The fields input
        processed_outputs: The processed_outputs input
        provider: The model provider

    ## Outputs
    ### Common Outputs
        [processed_outputs]: The [processed_outputs] output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for data extraction",
            "value": "gpt-4o",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The text that data will be extracted from",
            "value": "",
            "type": "string",
        },
        {
            "field": "additional_context",
            "helper_text": "Provide any additional context or instructions on how to extarct the text",
            "value": "",
            "type": "string",
        },
        {
            "field": "fields",
            "helper_text": "The fields input",
            "value": [],
            "type": "vec<interface{id: string, name: string, type: string, description: string}>",
        },
        {
            "field": "processed_outputs",
            "helper_text": "The processed_outputs input",
            "value": {},
            "type": "map<string, string>",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "[processed_outputs]",
            "helper_text": "The [processed_outputs] output",
            "type": "",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text", "processed_outputs", "fields"]

    def __init__(
        self,
        model: str = "gpt-4o",
        text: str = "",
        additional_context: str = "",
        fields: List[NameTypeDescription] = [],
        processed_outputs: Dict[str, str] = {},
        provider: str = "openai",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="extract_data",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if fields is not None:
            self.inputs["fields"] = fields
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if additional_context is not None:
            self.inputs["additional_context"] = additional_context
        if text is not None:
            self.inputs["text"] = text
        if processed_outputs is not None:
            self.inputs["processed_outputs"] = processed_outputs
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ExtractDataNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
