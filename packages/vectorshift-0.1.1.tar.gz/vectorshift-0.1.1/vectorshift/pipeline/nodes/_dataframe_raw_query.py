"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("dataframe_raw_query")
class DataframeRawQueryNode(Node):
    """
    Execute custom queries on dataframes.

    ## Inputs
    ### Common Inputs
        query: SQL query to execute on the dataframe. Use {df} as the table name placeholder. Example: SELECT * FROM {df} limit 10;
        dataframe: The dataframe to query
        dataframe_type: The type of dataframe to be used
        preload: Whether to preload dataframe instead of lazy load

    ## Outputs
    ### Common Outputs
        dataframe: The result of the query as a dataframe
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "SQL query to execute on the dataframe. Use {df} as the table name placeholder. Example: SELECT * FROM {df} limit 10;",
            "value": "SELECT * FROM {df}",
            "type": "string",
        },
        {
            "field": "dataframe",
            "helper_text": "The dataframe to query",
            "value": {"object_info": {"object_id": "", "object_type": 3}},
            "type": "dataframe",
        },
        {
            "field": "dataframe_type",
            "helper_text": "The type of dataframe to be used",
            "value": "table",
            "type": "string",
        },
        {
            "field": "preload",
            "helper_text": "Whether to preload dataframe instead of lazy load",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "dataframe",
            "helper_text": "The result of the query as a dataframe",
            "type": "dataframe",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "table": {
            "inputs": [
                {
                    "field": "dataframe",
                    "type": "dataframe",
                    "value": {"object_info": {"object_id": "", "object_type": 3}},
                    "label": "Select Database",
                    "helper_text": "The dataframe to query",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dataframe",
                        "decorators": {"hide": ["variable_switch"]},
                        "source": "dataframe_options",
                        "source_key": "dataframe_type",
                        "source_sub_key": "component.options",
                        "access_value_sub_key": "objectInfo",
                    },
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["dataframe_type"]

    _batch_mode_allowed = True

    _list_mode_fields = [
        {"field": "dataframe", "label": "Dataframe"},
        {"field": "dataframe_type", "label": "Dataframe Type"},
        {"field": "query", "label": "Query"},
    ]

    _REQUIRED_FIELDS = ["dataframe_type", "dataframe", "query", "preload"]

    def __init__(
        self,
        dataframe_type: str = "table",
        query: str = "SELECT * FROM {df}",
        dataframe: Any = "",
        preload: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["dataframe_type"] = dataframe_type

        super().__init__(
            node_type="dataframe_raw_query",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if dataframe_type is not None:
            self.inputs["dataframe_type"] = dataframe_type
        if dataframe is not None:
            self.inputs["dataframe"] = dataframe
        if query is not None:
            self.inputs["query"] = query
        if preload is not None:
            self.inputs["preload"] = preload
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "DataframeRawQueryNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
