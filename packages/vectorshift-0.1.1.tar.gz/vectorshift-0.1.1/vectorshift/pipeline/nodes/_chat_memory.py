"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("chat_memory")
class ChatMemoryNode(Node):
    """
    Give connected nodes access to conversation history.

    ## Inputs
    ### Common Inputs
        memory_type: The type of memory to use
        memory_window: The number of tokens to store in memory

    ## Outputs
    ### Common Outputs
        memory: The conversation history in the format of the selected type
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "memory_type",
            "helper_text": "The type of memory to use",
            "value": "Token Buffer",
            "type": "string",
        },
        {
            "field": "memory_window",
            "helper_text": "The number of tokens to store in memory",
            "value": 2048,
            "type": "int32",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "memory",
            "helper_text": "The conversation history in the format of the selected type",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "Vector Database": {
            "inputs": [
                {
                    "field": "memory_type",
                    "type": "string",
                    "value": "Vector Database",
                    "label": "Memory Type",
                    "helper_text": "Stores all previous messages in a Vector Database. Will return most similar messages based on the user message",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "memory_window",
                    "type": "int32",
                    "value": 20,
                    "label": "Token Window",
                    "helper_text": "The number of tokens to store in memory",
                    "section": "advanced_settings",
                    "component": {"type": "number", "default": 10},
                },
            ],
            "outputs": [],
        },
        "Message Buffer": {
            "inputs": [
                {
                    "field": "memory_type",
                    "type": "string",
                    "value": "Message Buffer",
                    "label": "Memory Type",
                    "helper_text": "Returns a set number of previous consecutive messages",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "memory_window",
                    "type": "int32",
                    "value": 10,
                    "label": "Token Window",
                    "helper_text": "The number of tokens to store in memory",
                    "section": "advanced_settings",
                    "component": {"type": "number", "default": 10},
                },
            ],
            "outputs": [],
        },
        "Token Buffer": {
            "inputs": [
                {
                    "field": "memory_type",
                    "type": "string",
                    "value": "Token Buffer",
                    "label": "Memory Type",
                    "helper_text": "Returns a set number of previous consecutive messages until adding an additional message would cause the total history size to be larger than the Max Tokens",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "memory_window",
                    "type": "int32",
                    "value": 2048,
                    "label": "Token Window",
                    "helper_text": "The number of tokens to store in memory",
                    "section": "advanced_settings",
                    "component": {"type": "number", "default": 2048},
                },
            ],
            "outputs": [],
        },
        "Full - Formatted": {
            "inputs": [
                {
                    "field": "memory_type",
                    "type": "string",
                    "value": "Full - Formatted",
                    "label": "Memory Type",
                    "helper_text": "Returns all previous chat history",
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "memory_window",
                    "type": "int32",
                    "value": 2048,
                    "label": "Token Window",
                    "helper_text": "The number of tokens to store in memory",
                    "section": "advanced_settings",
                    "component": {"type": "number", "default": 0},
                },
            ],
            "outputs": [],
        },
        "Full - Raw": {
            "inputs": [
                {
                    "field": "memory_type",
                    "type": "string",
                    "value": "Full - Raw",
                    "label": "Memory Type",
                    "helper_text": 'Returns a Python list with elements in the following format: {"type": type, "message": message}',
                    "component": {"type": "dropdown"},
                },
                {
                    "field": "memory_window",
                    "type": "int32",
                    "value": 2048,
                    "label": "Token Window",
                    "helper_text": "The number of tokens to store in memory",
                    "section": "advanced_settings",
                    "component": {"type": "number", "default": 0},
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["memory_type"]

    _batch_mode_allowed = False

    def __init__(
        self,
        memory_type: str = "Token Buffer",
        memory_window: int = 2048,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["memory_type"] = memory_type

        super().__init__(
            node_type="chat_memory",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if memory_type is not None:
            self.inputs["memory_type"] = memory_type
        if memory_window is not None:
            self.inputs["memory_window"] = memory_window
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ChatMemoryNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
