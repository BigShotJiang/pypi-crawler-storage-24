"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_perspective")
class IntegrationGooglePerspectiveNode(Node):
    """
    Google Perspective

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### analyze_comment
        comment: The text content to analyze for various attributes
        language: Language code (e.g., en, es, fr). Leave empty for auto-detection
        requested_attributes: Select which attribute to analyze
        score_threshold: Optional threshold (0-1) to filter results. Only scores above this value will be flagged

    ## Outputs
    ### analyze_comment
        attribute_scores: JSON object containing scores for requested attribute
        detected_languages: Languages detected in the comment
        raw_response: Complete API response as JSON string
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Perspective>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "analyze_comment": {
            "inputs": [
                {
                    "field": "comment",
                    "type": "string",
                    "value": "",
                    "label": "Comment",
                    "placeholder": "This is a comment to analyze",
                    "helper_text": "The text content to analyze for various attributes",
                },
                {
                    "field": "requested_attributes",
                    "type": "string",
                    "value": "TOXICITY",
                    "label": "Attributes to Analyze",
                    "placeholder": "TOXICITY,INSULT,THREAT",
                    "helper_text": "Select which attribute to analyze",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Toxicity", "value": "TOXICITY"},
                            {"label": "Severe Toxicity", "value": "SEVERE_TOXICITY"},
                            {"label": "Identity Attack", "value": "IDENTITY_ATTACK"},
                            {"label": "Insult", "value": "INSULT"},
                            {"label": "Profanity", "value": "PROFANITY"},
                            {"label": "Threat", "value": "THREAT"},
                            {
                                "label": "Sexually Explicit",
                                "value": "SEXUALLY_EXPLICIT",
                            },
                            {"label": "Flirtation", "value": "FLIRTATION"},
                        ],
                    },
                },
                {
                    "field": "language",
                    "type": "string",
                    "value": "",
                    "label": "Language",
                    "placeholder": "en",
                    "helper_text": "Language code (e.g., en, es, fr). Leave empty for auto-detection",
                },
                {
                    "field": "score_threshold",
                    "type": "float",
                    "value": "",
                    "label": "Score Threshold",
                    "placeholder": "0.7",
                    "helper_text": "Optional threshold (0-1) to filter results. Only scores above this value will be flagged",
                },
            ],
            "outputs": [
                {
                    "field": "attribute_scores",
                    "type": "string",
                    "helper_text": "JSON object containing scores for requested attribute",
                },
                {
                    "field": "detected_languages",
                    "type": "vec<string>",
                    "helper_text": "Languages detected in the comment",
                },
                {
                    "field": "raw_response",
                    "type": "string",
                    "helper_text": "Complete API response as JSON string",
                },
            ],
            "name": "analyze_comment",
            "task_name": "tasks.google_perspective.analyze_comment",
            "description": "Analyze a comment for toxicity, threats, insults, and other attributes using Google Perspective API",
            "label": "Analyze Comment",
            "ui_sort_order": [
                "comment",
                "requested_attributes",
                "language",
                "score_threshold",
            ],
            "required": ["comment", "requested_attributes"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        comment: str = "",
        language: str = "",
        requested_attributes: str = "TOXICITY",
        score_threshold: Any = None,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_perspective",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if comment is not None:
            self.inputs["comment"] = comment
        if requested_attributes is not None:
            self.inputs["requested_attributes"] = requested_attributes
        if language is not None:
            self.inputs["language"] = language
        if score_threshold is not None:
            self.inputs["score_threshold"] = score_threshold
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGooglePerspectiveNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
