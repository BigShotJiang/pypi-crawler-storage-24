"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("excel_cell_writer")
class ExcelCellWriterNode(Node):
    """
    Write data to an Excel cell.

    ## Inputs
    ### Common Inputs
        cell_index: The cell to read from.
        cell_value: The value to write to the cell.
        selected_file: The file to read from.
        set_fill_color: Whether to set the fill color of the cell.
        set_horizontal_alignment: Whether to set the horizontal alignment of the cell.
        set_vertical_alignment: Whether to set the vertical alignment of the cell.
        sheet: The sheet to read from.
    ### When set_fill_color = True
        fill_color: The fill color of the cell.
    ### When set_horizontal_alignment = True
        horizontal_alignment: The horizontal alignment of the cell.
    ### When set_vertical_alignment = True
        vertical_alignment: The vertical alignment of the cell.

    ## Outputs
    ### Common Outputs
        output_file: The updated Excel file.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "cell_index",
            "helper_text": "The cell to read from.",
            "value": "",
            "type": "string",
        },
        {
            "field": "cell_value",
            "helper_text": "The value to write to the cell.",
            "value": "",
            "type": "string",
        },
        {
            "field": "selected_file",
            "helper_text": "The file to read from.",
            "value": None,
            "type": "file",
        },
        {
            "field": "set_fill_color",
            "helper_text": "Whether to set the fill color of the cell.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "set_horizontal_alignment",
            "helper_text": "Whether to set the horizontal alignment of the cell.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "set_vertical_alignment",
            "helper_text": "Whether to set the vertical alignment of the cell.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "sheet",
            "helper_text": "The sheet to read from.",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output_file",
            "helper_text": "The updated Excel file.",
            "type": "file",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)**(*)": {
            "inputs": [
                {
                    "field": "vertical_alignment",
                    "type": "string",
                    "value": "bottom",
                    "helper_text": "The vertical alignment of the cell.",
                    "label": "Vertical Alignment",
                    "agent_field_type": "dynamic",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**true**(*)": {
            "inputs": [
                {
                    "field": "horizontal_alignment",
                    "type": "string",
                    "value": "left",
                    "helper_text": "The horizontal alignment of the cell.",
                    "label": "Horizontal Alignment",
                    "agent_field_type": "dynamic",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**(*)**true": {
            "inputs": [
                {
                    "field": "fill_color",
                    "type": "string",
                    "value": "FFFFFF",
                    "helper_text": "The fill color of the cell.",
                    "label": "Fill Color",
                    "agent_field_type": "dynamic",
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["set_vertical_alignment", "set_horizontal_alignment", "set_fill_color"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["selected_file", "sheet", "cell_index", "cell_value"]

    def __init__(
        self,
        set_vertical_alignment: bool = False,
        set_horizontal_alignment: bool = False,
        set_fill_color: bool = False,
        cell_index: str = "",
        cell_value: str = "",
        fill_color: str = "FFFFFF",
        horizontal_alignment: str = "left",
        selected_file: Optional[str] = None,
        sheet: str = "",
        vertical_alignment: str = "bottom",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["set_vertical_alignment"] = set_vertical_alignment
        params["set_horizontal_alignment"] = set_horizontal_alignment
        params["set_fill_color"] = set_fill_color

        super().__init__(
            node_type="excel_cell_writer",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if selected_file is not None:
            self.inputs["selected_file"] = selected_file
        if sheet is not None:
            self.inputs["sheet"] = sheet
        if cell_index is not None:
            self.inputs["cell_index"] = cell_index
        if cell_value is not None:
            self.inputs["cell_value"] = cell_value
        if set_vertical_alignment is not None:
            self.inputs["set_vertical_alignment"] = set_vertical_alignment
        if set_horizontal_alignment is not None:
            self.inputs["set_horizontal_alignment"] = set_horizontal_alignment
        if set_fill_color is not None:
            self.inputs["set_fill_color"] = set_fill_color
        if vertical_alignment is not None:
            self.inputs["vertical_alignment"] = vertical_alignment
        if horizontal_alignment is not None:
            self.inputs["horizontal_alignment"] = horizontal_alignment
        if fill_color is not None:
            self.inputs["fill_color"] = fill_color
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ExcelCellWriterNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
