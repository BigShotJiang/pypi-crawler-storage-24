"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_discord")
class IntegrationDiscordNode(Node):
    """
    Discord

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### list_messages
        after: Get messages after this message ID (optional)
        before: Get messages before this message ID (optional)
        channel_id: Select the channel to delete
        guild_id: Select the Discord server
        limit: Maximum number of channels to retrieve
    ### delete_channel
        channel_id: Select the channel to delete
        guild_id: Select the Discord server
    ### get_channel
        channel_id: Select the channel to delete
        guild_id: Select the Discord server
    ### update_channel
        channel_id: Select the channel to delete
        channel_name: Name of the channel to create
        guild_id: Select the Discord server
        topic: Topic for the channel (optional)
    ### delete_message
        channel_id: Select the channel to delete
        guild_id: Select the Discord server
        message_id: ID of the message to delete
    ### get_message
        channel_id: Select the channel to delete
        guild_id: Select the Discord server
        message_id: ID of the message to delete
    ### react_with_emoji
        channel_id: Select the channel to delete
        emoji: Emoji to react with (unicode or :name:)
        guild_id: Select the Discord server
        message_id: ID of the message to delete
    ### create_channel
        channel_name: Name of the channel to create
        channel_type: Type of the channel to create
        guild_id: Select the Discord server
        topic: Topic for the channel (optional)
    ### send_message
        channel_name: Name of the channel to create
        guild_id: Select the Discord server
        message: The message to send
        tts: Whether the message should be read aloud
    ### list_channels
        guild_id: Select the Discord server
        limit: Maximum number of channels to retrieve
    ### list_members
        guild_id: Select the Discord server
        limit: Maximum number of channels to retrieve
    ### add_member_role
        guild_id: Select the Discord server
        reason: Reason for adding the role (optional)
        role_id: Select the role to add
        user_id: ID of the user to add the role to
    ### remove_member_role
        guild_id: Select the Discord server
        reason: Reason for adding the role (optional)
        role_id: Select the role to add
        user_id: ID of the user to add the role to

    ## Outputs
    ### get_message
        author_id: ID of the message author
        author_name: Name of the message author
        message_content: Content of the message
        message_id: ID of the message
        raw_data: Raw API response data
        timestamp: When the message was sent
    ### list_channels
        channel_count: Number of channels retrieved
        channel_ids: Array of channel IDs
        channel_last_message_ids: Array of last message IDs
        channel_names: Array of channel names
        channel_nsfw: Array of channel NSFW flags
        channel_parent_ids: Array of channel parent IDs
        channel_positions: Array of channel positions
        channel_topics: Array of channel topics
        channel_types: Array of channel types
        raw_data: Raw API response data
    ### create_channel
        channel_id: ID of the created channel
        channel_name: Name of the created channel
        channel_url: URL to the channel
        raw_data: Raw API response data
    ### get_channel
        channel_id: ID of the channel
        channel_name: Name of the channel
        channel_type: Type of the channel
        guild_id: Server (guild) ID
        raw_data: Raw API response data
        topic: Channel topic
    ### update_channel
        channel_id: ID of the updated channel
        channel_name: Updated channel name
        raw_data: Raw API response data
    ### list_members
        member_count: Number of members retrieved
        member_ids: Array of member user IDs
        member_nicknames: Array of member nicknames (server-specific)
        member_roles: Array of member role IDs (nested array)
        member_usernames: Array of member usernames
        raw_data: Raw API response data
    ### delete_channel
        message: Success message
        raw_data: Raw API response data
    ### delete_message
        message: Success message
        raw_data: Raw API response data
    ### react_with_emoji
        message: Success message
        raw_data: Raw API response data
    ### add_member_role
        message: Success message
        raw_data: Raw API response data
    ### remove_member_role
        message: Success message
        raw_data: Raw API response data
    ### list_messages
        message_authors: Array of message author usernames
        message_contents: Array of message contents
        message_count: Number of messages retrieved
        message_ids: Array of message IDs
        message_timestamps: Array of message timestamps
        raw_data: Raw API response data
    ### send_message
        message_content: Content of the sent message
        message_id: ID of the sent message
        message_url: URL to the message
        raw_data: Raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Discord>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "create_channel": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "value": "",
                    "label": "Channel Name",
                    "placeholder": "my-new-channel",
                    "helper_text": "Name of the channel to create",
                },
                {
                    "field": "channel_type",
                    "type": "string",
                    "value": "text",
                    "label": "Channel Type",
                    "helper_text": "Type of the channel to create",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text Channel", "value": "text"},
                            {"label": "Voice Channel", "value": "voice"},
                            {"label": "Category", "value": "category"},
                            {"label": "Announcement Channel", "value": "announcement"},
                            {"label": "Stage Channel", "value": "stage"},
                            {"label": "Forum Channel", "value": "forum"},
                        ],
                    },
                },
                {
                    "field": "topic",
                    "type": "string",
                    "value": "",
                    "label": "Topic",
                    "placeholder": "Channel topic",
                    "helper_text": "Topic for the channel (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the created channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the created channel",
                },
                {
                    "field": "channel_url",
                    "type": "string",
                    "helper_text": "URL to the channel",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_channel",
            "task_name": "tasks.discord.create_channel",
            "description": "Create a new Discord channel",
            "label": "Create Channel",
            "variant": "common_integration_nodes",
            "required": ["channel_name", "guild_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_name",
                "channel_type",
                "topic",
            ],
        },
        "delete_channel": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel to delete",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_channel",
            "task_name": "tasks.discord.delete_channel",
            "description": "Delete a Discord channel",
            "label": "Delete Channel",
            "variant": "common_integration_nodes",
            "required": ["channel_id"],
            "ui_sort_order": ["integration", "action", "guild_id", "channel_id"],
        },
        "get_channel": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel to retrieve",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Name of the channel",
                },
                {
                    "field": "channel_type",
                    "type": "string",
                    "helper_text": "Type of the channel",
                },
                {"field": "topic", "type": "string", "helper_text": "Channel topic"},
                {
                    "field": "guild_id",
                    "type": "string",
                    "helper_text": "Server (guild) ID",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_channel",
            "task_name": "tasks.discord.get_channel",
            "description": "Read details of a channel",
            "label": "Get Channel",
            "variant": "common_integration_nodes",
            "required": ["channel_id"],
            "ui_sort_order": ["integration", "action", "guild_id", "channel_id"],
        },
        "list_channels": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of channels to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "channel_count",
                    "type": "int32",
                    "helper_text": "Number of channels retrieved",
                },
                {
                    "field": "channel_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of channel IDs",
                },
                {
                    "field": "channel_names",
                    "type": "vec<string>",
                    "helper_text": "Array of channel names",
                },
                {
                    "field": "channel_types",
                    "type": "vec<string>",
                    "helper_text": "Array of channel types",
                },
                {
                    "field": "channel_topics",
                    "type": "vec<string>",
                    "helper_text": "Array of channel topics",
                },
                {
                    "field": "channel_positions",
                    "type": "vec<int32>",
                    "helper_text": "Array of channel positions",
                },
                {
                    "field": "channel_nsfw",
                    "type": "vec<bool>",
                    "helper_text": "Array of channel NSFW flags",
                },
                {
                    "field": "channel_parent_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of channel parent IDs",
                },
                {
                    "field": "channel_last_message_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of last message IDs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_channels",
            "task_name": "tasks.discord.list_channels",
            "description": "Get multiple channels",
            "label": "List Channels",
            "variant": "common_integration_nodes",
            "required": ["guild_id", "limit"],
            "ui_sort_order": ["integration", "action", "guild_id", "limit"],
        },
        "update_channel": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel to update",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "value": "",
                    "label": "New Channel Name",
                    "placeholder": "updated-channel",
                    "helper_text": "New name for the channel (optional)",
                },
                {
                    "field": "topic",
                    "type": "string",
                    "value": "",
                    "label": "New Topic",
                    "placeholder": "Updated topic",
                    "helper_text": "New topic for the channel (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "channel_id",
                    "type": "string",
                    "helper_text": "ID of the updated channel",
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "helper_text": "Updated channel name",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_channel",
            "task_name": "tasks.discord.update_channel",
            "description": "Update a Discord channel",
            "label": "Update Channel",
            "variant": "common_integration_nodes",
            "required": ["channel_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_id",
                "channel_name",
                "topic",
            ],
        },
        "delete_message": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel containing the message",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "987654321",
                    "helper_text": "ID of the message to delete",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_message",
            "task_name": "tasks.discord.delete_message",
            "description": "Delete a Discord message",
            "label": "Delete Message",
            "variant": "common_integration_nodes",
            "required": ["channel_id", "message_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_id",
                "message_id",
            ],
        },
        "get_message": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel containing the message",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "987654321",
                    "helper_text": "ID of the message to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the message",
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "helper_text": "Content of the message",
                },
                {
                    "field": "author_name",
                    "type": "string",
                    "helper_text": "Name of the message author",
                },
                {
                    "field": "author_id",
                    "type": "string",
                    "helper_text": "ID of the message author",
                },
                {
                    "field": "timestamp",
                    "type": "timestamp",
                    "helper_text": "When the message was sent",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_message",
            "task_name": "tasks.discord.get_message",
            "description": "Read details of a message",
            "label": "Get Message",
            "variant": "common_integration_nodes",
            "required": ["channel_id", "message_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_id",
                "message_id",
            ],
        },
        "list_messages": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel to get messages from",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of messages to retrieve",
                },
                {
                    "field": "before",
                    "type": "string",
                    "value": "",
                    "label": "Before Message ID",
                    "placeholder": "987654321",
                    "helper_text": "Get messages before this message ID (optional)",
                },
                {
                    "field": "after",
                    "type": "string",
                    "value": "",
                    "label": "After Message ID",
                    "placeholder": "987654321",
                    "helper_text": "Get messages after this message ID (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message_count",
                    "type": "int32",
                    "helper_text": "Number of messages retrieved",
                },
                {
                    "field": "message_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of message IDs",
                },
                {
                    "field": "message_contents",
                    "type": "vec<string>",
                    "helper_text": "Array of message contents",
                },
                {
                    "field": "message_authors",
                    "type": "vec<string>",
                    "helper_text": "Array of message author usernames",
                },
                {
                    "field": "message_timestamps",
                    "type": "vec<string>",
                    "helper_text": "Array of message timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_messages",
            "task_name": "tasks.discord.list_messages",
            "description": "Get multiple messages",
            "label": "List Messages",
            "variant": "common_integration_nodes",
            "required": ["channel_id", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_id",
                "limit",
                "before",
                "after",
            ],
        },
        "react_with_emoji": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel containing the message",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "987654321",
                    "helper_text": "ID of the message to react to",
                },
                {
                    "field": "emoji",
                    "type": "string",
                    "value": "",
                    "label": "Emoji",
                    "placeholder": "👍 or :thumbsup:",
                    "helper_text": "Emoji to react with (unicode or :name:)",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "react_with_emoji",
            "task_name": "tasks.discord.react_with_emoji",
            "description": "React to a Discord message with an emoji",
            "label": "React with Emoji",
            "variant": "common_integration_nodes",
            "required": ["channel_id", "message_id", "emoji"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_id",
                "message_id",
                "emoji",
            ],
        },
        "send_message": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "show_on_node": True,
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "channel_name",
                    "type": "string",
                    "value": "",
                    "label": "Select Channel",
                    "placeholder": "123456789",
                    "helper_text": "Select the channel to send the message to",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=channel_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "message",
                    "type": "string",
                    "value": "",
                    "label": "Message",
                    "placeholder": "Hello World!",
                    "helper_text": "The message to send",
                },
                {
                    "field": "tts",
                    "type": "bool",
                    "value": False,
                    "label": "Text-to-Speech",
                    "helper_text": "Whether the message should be read aloud",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "ID of the sent message",
                },
                {
                    "field": "message_content",
                    "type": "string",
                    "helper_text": "Content of the sent message",
                },
                {
                    "field": "message_url",
                    "type": "string",
                    "helper_text": "URL to the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "send_message",
            "task_name": "tasks.discord.send_message",
            "description": "Send a message to a Discord channel",
            "label": "Send Message",
            "variant": "common_integration_nodes",
            "required": ["channel_name", "message"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "channel_name",
                "message",
                "tts",
            ],
        },
        "list_members": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of members to retrieve",
                },
            ],
            "outputs": [
                {
                    "field": "member_count",
                    "type": "int32",
                    "helper_text": "Number of members retrieved",
                },
                {
                    "field": "member_ids",
                    "type": "vec<string>",
                    "helper_text": "Array of member user IDs",
                },
                {
                    "field": "member_usernames",
                    "type": "vec<string>",
                    "helper_text": "Array of member usernames",
                },
                {
                    "field": "member_nicknames",
                    "type": "vec<string>",
                    "helper_text": "Array of member nicknames (server-specific)",
                },
                {
                    "field": "member_roles",
                    "type": "vec<vec<string>>",
                    "helper_text": "Array of member role IDs (nested array)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_members",
            "task_name": "tasks.discord.list_members",
            "description": "Get multiple members",
            "label": "List Members",
            "variant": "common_integration_nodes",
            "required": ["guild_id"],
            "ui_sort_order": ["integration", "action", "guild_id", "limit"],
        },
        "add_member_role": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "987654321",
                    "helper_text": "ID of the user to add the role to",
                },
                {
                    "field": "role_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Role",
                    "placeholder": "456789123",
                    "helper_text": "Select the role to add",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=role_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "reason",
                    "type": "string",
                    "value": "",
                    "label": "Reason",
                    "placeholder": "Role assignment",
                    "helper_text": "Reason for adding the role (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_member_role",
            "task_name": "tasks.discord.add_member_role",
            "description": "Add a role to a Discord server member",
            "label": "Add Role to Member",
            "variant": "common_integration_nodes",
            "required": ["guild_id", "user_id", "role_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "user_id",
                "role_id",
                "reason",
            ],
        },
        "remove_member_role": {
            "inputs": [
                {
                    "field": "guild_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Server",
                    "placeholder": "123456789",
                    "helper_text": "Select the Discord server",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=guild_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "placeholder": "987654321",
                    "helper_text": "ID of the user to remove the role from",
                },
                {
                    "field": "role_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Role",
                    "placeholder": "456789123",
                    "helper_text": "Select the role to remove",
                    "agent_field_type": "static",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=role_id&parent={inputs.guild_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "reason",
                    "type": "string",
                    "value": "",
                    "label": "Reason",
                    "placeholder": "Role removal",
                    "helper_text": "Reason for removing the role (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "remove_member_role",
            "task_name": "tasks.discord.remove_member_role",
            "description": "Remove a role from a Discord server member",
            "label": "Remove Role from Member",
            "variant": "common_integration_nodes",
            "required": ["guild_id", "user_id", "role_id"],
            "ui_sort_order": [
                "integration",
                "action",
                "guild_id",
                "user_id",
                "role_id",
                "reason",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        after: str = "",
        before: str = "",
        channel_id: str = "",
        channel_name: str = "",
        channel_type: str = "text",
        emoji: str = "",
        guild_id: str = "",
        limit: int = 10,
        message: str = "",
        message_id: str = "",
        reason: str = "",
        role_id: str = "",
        topic: str = "",
        tts: bool = False,
        user_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_discord",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if guild_id is not None:
            self.inputs["guild_id"] = guild_id
        if channel_name is not None:
            self.inputs["channel_name"] = channel_name
        if channel_type is not None:
            self.inputs["channel_type"] = channel_type
        if topic is not None:
            self.inputs["topic"] = topic
        if channel_id is not None:
            self.inputs["channel_id"] = channel_id
        if limit is not None:
            self.inputs["limit"] = limit
        if message_id is not None:
            self.inputs["message_id"] = message_id
        if before is not None:
            self.inputs["before"] = before
        if after is not None:
            self.inputs["after"] = after
        if emoji is not None:
            self.inputs["emoji"] = emoji
        if message is not None:
            self.inputs["message"] = message
        if tts is not None:
            self.inputs["tts"] = tts
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if role_id is not None:
            self.inputs["role_id"] = role_id
        if reason is not None:
            self.inputs["reason"] = reason
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationDiscordNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
