"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_mailgun")
class IntegrationMailgunNode(Node):
    """
    Mailgun

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### send_mail
        bcc_recipients: The email(s) of the recipient(s) you want to BCC the email to
        body: The body (message) of the email
        cc_recipients: The email(s) of the recipient(s) you want to CC the email to
        domain: Your Mailgun domain
        from_email: The email of the sender of the email
        from_name: The name of the sender of the email
        recipients: The email of the recipient you want to send the email to, example: john@company.com, alex@company.com
        subject: The subject of the email
    ### add_contact_to_mailing_list
        email: The email of the contact to be added to the list
        list_name: The list the contact will be added to
        name: The name of contact to be added to the list

    ## Outputs
    ### send_mail
        output: Status of the email sending operation
    ### add_contact_to_mailing_list
        output: Status of the contact addition operation
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Mailgun>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "send_mail": {
            "inputs": [
                {
                    "field": "domain",
                    "type": "string",
                    "label": "Domain",
                    "agent_field_type": "dynamic",
                    "helper_text": "Your Mailgun domain",
                    "component": {
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=domain_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Important: Your Account Update",
                    "helper_text": "The subject of the email",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Dear valued customer...",
                    "helper_text": "The body (message) of the email",
                },
                {
                    "field": "from_name",
                    "type": "string",
                    "value": "",
                    "label": "The name of the sender",
                    "placeholder": "John Smith",
                    "helper_text": "The name of the sender of the email",
                },
                {
                    "field": "from_email",
                    "type": "string",
                    "value": "",
                    "label": "The Email of the sender",
                    "placeholder": "john@company.com",
                    "helper_text": "The email of the sender of the email",
                },
                {
                    "field": "recipients",
                    "type": "string",
                    "value": "",
                    "label": "Recipients email address",
                    "placeholder": "recipient@example.com",
                    "helper_text": "The email of the recipient you want to send the email to, example: john@company.com, alex@company.com",
                },
                {
                    "field": "cc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "CC Recipients email address",
                    "placeholder": "cc1@example.com, cc2@example.com",
                    "helper_text": "The email(s) of the recipient(s) you want to CC the email to",
                },
                {
                    "field": "bcc_recipients",
                    "type": "string",
                    "value": "",
                    "label": "BCC Recipients email address",
                    "placeholder": "bcc1@example.com, bcc2@example.com",
                    "helper_text": "The email(s) of the recipient(s) you want to BCC the email to",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Status of the email sending operation",
                }
            ],
            "name": "send_mail",
            "task_name": "tasks.mailgun.send_mail",
            "description": "Send mail ",
            "label": "Send mail",
        },
        "add_contact_to_mailing_list": {
            "inputs": [
                {
                    "field": "list_name",
                    "type": "string",
                    "value": "",
                    "label": "Name of the mailing list",
                    "placeholder": "newsletter-subscribers",
                    "helper_text": "The list the contact will be added to",
                    "agent_field_type": "dynamic",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name of the contact to add",
                    "placeholder": "John Smith",
                    "helper_text": "The name of contact to be added to the list",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email of the contact to add",
                    "placeholder": "john@example.com",
                    "helper_text": "The email of the contact to be added to the list",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Status of the contact addition operation",
                }
            ],
            "name": "add_contact_to_mailing_list",
            "task_name": "tasks.mailgun.add_contact_to_mailing_list",
            "description": "Adds a contact to a Mailgun Mailing list",
            "label": "Add Contact to Mailing List",
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        bcc_recipients: str = "",
        body: str = "",
        cc_recipients: str = "",
        domain: Optional[str] = None,
        email: str = "",
        from_email: str = "",
        from_name: str = "",
        list_name: str = "",
        name: str = "",
        recipients: str = "",
        subject: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_mailgun",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if domain is not None:
            self.inputs["domain"] = domain
        if subject is not None:
            self.inputs["subject"] = subject
        if body is not None:
            self.inputs["body"] = body
        if from_name is not None:
            self.inputs["from_name"] = from_name
        if from_email is not None:
            self.inputs["from_email"] = from_email
        if recipients is not None:
            self.inputs["recipients"] = recipients
        if cc_recipients is not None:
            self.inputs["cc_recipients"] = cc_recipients
        if bcc_recipients is not None:
            self.inputs["bcc_recipients"] = bcc_recipients
        if list_name is not None:
            self.inputs["list_name"] = list_name
        if name is not None:
            self.inputs["name"] = name
        if email is not None:
            self.inputs["email"] = email
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMailgunNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
