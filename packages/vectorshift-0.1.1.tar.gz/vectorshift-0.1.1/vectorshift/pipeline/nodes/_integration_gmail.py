"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import DateRange, TimeRange


@Node.register_node_type("integration_gmail")
class IntegrationGmailNode(Node):
    """
    Gmail

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### When action = 'list_messages'
        query: Raw query string to use directly. If provided, overrides all other query parameters.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        category: Filter by tab (e.g. Primary, Social)
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        custom_params: Extra filters as raw query
        filename: Find attachments by name or type
        from: Emails sent by this address
        has: Filter by feature (e.g. attachment, drive)
        has_attachment: Only emails with attachments
        has_images: Emails containing images
        has_links: Emails containing links
        has_starred: Only starred emails
        has_unread: Only unread emails
        has_user_labels: Emails with custom labels
        in: Search within a folder (e.g. sent, spam)
        include_spam_trash: Include spam and trash emails
        is: Filter by status (e.g. read, unread, starred)
        label: Search emails with this label
        label_ids: Emails with all listed label IDs
        larger: Emails larger than this size (e.g. 5M)
        list: Emails from this mailing list
        msg_id: Search by message ID (ignores other filters)
        newer_than: Emails newer than a time (e.g. 7d, 2m)
        older_than: Emails older than a time (e.g. 7d, 2m)
        page_token: Use to fetch next page of results
        projection: Select which fields to return
        smaller: Emails smaller than this size (e.g. 5M)
        subject: The subject of the email
        to: Emails sent to this address
        use_date: Toggle to use dates
    ### When action = 'get_drafts'
        query: Raw query string to use directly. If provided, overrides all other query parameters.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        category: Filter by tab (e.g. Primary, Social)
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        detailed_view: Include full draft details in the response
        filename: Find attachments by name or type
        from: Emails sent by this address
        has: Filter by feature (e.g. attachment, drive)
        has_attachment: Only emails with attachments
        has_images: Emails containing images
        has_links: Emails containing links
        has_starred: Only starred emails
        has_unread: Only unread emails
        has_user_labels: Emails with custom labels
        in: Search within a folder (e.g. sent, spam)
        include_spam_trash: Include spam and trash emails
        is: Filter by status (e.g. read, unread, starred)
        label: Search emails with this label
        label_ids: Emails with all listed label IDs
        larger: Emails larger than this size (e.g. 5M)
        list: Emails from this mailing list
        newer_than: Emails newer than a time (e.g. 7d, 2m)
        older_than: Emails older than a time (e.g. 7d, 2m)
        page_token: Use to fetch next page of results
        smaller: Emails smaller than this size (e.g. 5M)
        subject: The subject of the email
        to: Emails sent to this address
        use_date: Toggle to use dates
    ### When action = 'get_threads'
        query: Raw query string to use directly. If provided, overrides all other query parameters.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        category: Filter by tab (e.g. Primary, Social)
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        filename: Find attachments by name or type
        from: Emails sent by this address
        has: Filter by feature (e.g. attachment, drive)
        has_attachment: Only emails with attachments
        has_chat: Only chat threads
        has_images: Emails containing images
        has_important: Only important threads
        has_links: Emails containing links
        has_starred: Only starred emails
        has_unread: Only unread emails
        has_user_labels: Emails with custom labels
        in: Search within a folder (e.g. sent, spam)
        include_spam_trash: Include spam and trash emails
        is: Filter by status (e.g. read, unread, starred)
        label: Search emails with this label
        label_ids: Emails with all listed label IDs
        larger: Emails larger than this size (e.g. 5M)
        list: Emails from this mailing list
        newer_than: Emails newer than a time (e.g. 7d, 2m)
        older_than: Emails older than a time (e.g. 7d, 2m)
        page_token: Use to fetch next page of results
        read_status: Filter by read status
        received_after: RFC3339 timestamp (e.g. 2023-01-01T00:00:00Z)
        received_before: RFC3339 timestamp (e.g. 2023-12-31T23:59:59Z)
        smaller: Emails smaller than this size (e.g. 5M)
        subject: The subject of the email
        to: Emails sent to this address
        use_date: Toggle to use dates
    ### When action = 'send_email'
        attachments: Attachments to be appended.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com
        reply_to: Alternative email address where replies should be sent instead of the sender's address
        reply_to_sender_only: When enabled, ensures that replies go only to the sender, excluding CC or group recipients
        sender_name: Custom name to display as the sender in the recipient's inbox
        subject: The subject of the email
    ### When action = 'send_reply'
        attachments: Attachments to be appended.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        email_id: The ID of the email (often used in conjunction with a trigger where the email ID is received from the trigger)
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com
        reply_to: Alternative email address where replies should be sent instead of the sender's address
        reply_to_sender_only: When enabled, ensures that replies go only to the sender, excluding CC or group recipients
        sender_name: Custom name to display as the sender in the recipient's inbox
    ### When action = 'create_draft'
        attachments: Attachments to be appended.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com
        reply_to: Alternative email address where replies should be sent instead of the sender's address
        reply_to_sender_only: When enabled, ensures that replies go only to the sender, excluding CC or group recipients
        sender_name: Custom name to display as the sender in the recipient's inbox
        subject: The subject of the email
    ### When action = 'draft_reply'
        attachments: Attachments to be appended.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        email_id: The ID of the email (often used in conjunction with a trigger where the email ID is received from the trigger)
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com
        reply_to: Alternative email address where replies should be sent instead of the sender's address
        reply_to_sender_only: When enabled, ensures that replies go only to the sender, excluding CC or group recipients
        sender_name: Custom name to display as the sender in the recipient's inbox
    ### When action = 'reply_to_thread'
        attachments: Attachments to be appended.
        bcc: Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)
        body: The body of the email
        cc: Carbon copy recipients who will receive a visible copy of the email (comma-separated)
        format: Either html (to allow html content) or text (for plaintext content - default)
        recipients: A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com
        reply_to: Alternative email address where replies should be sent instead of the sender's address
        reply_to_sender_only: When enabled, ensures that replies go only to the sender, excluding CC or group recipients
        sender_name: Custom name to display as the sender in the recipient's inbox
        thread_id: The ID of the thread to read
    ### When action = 'list_messages' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_drafts' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'get_threads' and use_date = True and use_exact_date = False
        date_range: The date_range input
    ### When action = 'read_draft'
        draft_id: The ID of the draft to read
        format: Either html (to allow html content) or text (for plaintext content - default)
    ### When action = 'delete_draft'
        draft_id: The ID of the draft to read
    ### When action = 'trash_draft'
        draft_message_id: The ID of the draft message to trash
    ### When action = 'list_messages' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_drafts' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'get_threads' and use_date = True and use_exact_date = True
        exact_date: The exact_date input
    ### When action = 'read_message'
        format: Either html (to allow html content) or text (for plaintext content - default)
        message_id: The ID of the message to read
    ### When action = 'read_thread'
        format: Either html (to allow html content) or text (for plaintext content - default)
        thread_id: The ID of the thread to read
    ### When action = 'read_label'
        label_id: The ID of the label to read, example: Label_1, Label_2
    ### When action = 'delete_label'
        label_id: The ID of the label to read, example: Label_1, Label_2
    ### When action = 'add_label_to_message'
        label_ids: Emails with all listed label IDs
        message_id: The ID of the message to read
    ### When action = 'remove_label_from_message'
        label_ids: Emails with all listed label IDs
        message_id: The ID of the message to read
    ### When action = 'add_label_to_thread'
        label_ids: Emails with all listed label IDs
        thread_id: The ID of the thread to read
    ### When action = 'remove_label_from_thread'
        label_ids: Emails with all listed label IDs
        thread_id: The ID of the thread to read
    ### When action = 'create_label'
        label_list_visibility: The visibility of the label in the label list
        message_list_visibility: The visibility of messages with this label
        name: The name of the label to create
    ### When action = 'mark_as_read'
        message_id: The ID of the message to read
    ### When action = 'mark_as_unread'
        message_id: The ID of the message to read
    ### When action = 'trash_message'
        message_id: The ID of the message to read
    ### When action = 'delete_message'
        message_id: The ID of the message to read
    ### When action = 'list_messages' and use_date = False
        num_messages: Specify the last n number of emails
    ### When action = 'get_drafts' and use_date = False
        num_messages: Specify the last n number of emails
    ### When action = 'get_threads' and use_date = False
        num_messages: Specify the last n number of emails
    ### When action = 'trash_thread'
        thread_id: The ID of the thread to read
    ### When action = 'delete_thread'
        thread_id: The ID of the thread to read
    ### When action = 'untrash_thread'
        thread_id: The ID of the thread to read
    ### When action = 'list_messages' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_drafts' and use_date = True
        use_exact_date: Switch between exact date range and relative dates
    ### When action = 'get_threads' and use_date = True
        use_exact_date: Switch between exact date range and relative dates

    ## Outputs
    ### When action = 'read_message'
        attachments: The attachments of the message
        body: The body of the message
        date: The date the message was sent
        from: The sender of the message
        has_attachments: Whether the message has attachments
        labels: The labels applied to the message
        message_id: The ID of the message
        raw_data: Raw data of the message
        snippet: A short snippet of the message
        subject: The subject of the message
        thread_id: The ID of the thread this message belongs to
        to: The recipients of the message
    ### When action = 'list_messages'
        attachments: The attachments of the retrieved emails
        email_bodies: The content of the retrieved emails
        email_dates: The sent dates of the retrieved emails
        email_display_names: The display names of the senders
        email_ids: The IDs of the retrieved emails
        email_subjects: The subjects of the retrieved emails
        raw_data: Raw data of the retrieved emails
        recipient_addresses: The email addresses of the recipients
        sender_addresses: The email addresses of the senders
    ### When action = 'read_draft'
        attachments: The attachments of the draft
        body: The body of the draft
        date: The date the draft was created
        draft_id: The ID of the draft
        from: The sender of the draft
        has_attachments: Whether the draft has attachments
        labels: The labels applied to the draft
        message_id: The ID of the draft message
        raw_data: Raw data of the draft
        snippet: A short snippet of the draft
        subject: The subject of the draft
        thread_id: The ID of the thread this draft belongs to
        to: The recipients of the draft
    ### When action = 'get_drafts'
        attachments: The attachments of the drafts
        draft_bodies: The bodies of the drafts
        draft_ids: The IDs of the drafts
        draft_message_ids: The IDs of the draft messages
        draft_recipients: The recipients of the drafts
        draft_subjects: The subjects of the drafts
        draft_thread_ids: The IDs of the draft threads
        raw_data: Raw data of the drafts
        total_results: Total number of drafts found
    ### When action = 'create_draft'
        draft_id: The ID of the created draft
        labels: The labels applied to the draft
        message_id: The ID of the created draft message
        raw_data: Raw data of the created draft
        thread_id: The ID of the thread this draft belongs to
    ### When action = 'draft_reply'
        draft_id: The ID of the created draft
        labels: The labels applied to the draft
        message_id: The ID of the created draft message
        raw_data: Raw data of the draft reply
        thread_id: The ID of the thread this draft belongs to
    ### When action = 'trash_draft'
        draft_message_id: The ID of the trashed draft message
        message: Success message
        raw_data: Raw data of the trashed draft
    ### When action = 'read_thread'
        history_id: The history ID of the thread
        message_bodies: The bodies of messages in the thread
        message_count: Number of messages in the thread
        message_dates: The dates of messages in the thread
        message_senders: The senders of messages in the thread
        message_subjects: The subjects of messages in the thread
        messages: The messages in the thread
        raw_data: Raw data of the thread
        thread_id: The ID of the thread
    ### When action = 'create_label'
        label_id: The ID of the created label
        label_list_visibility: The visibility of the label in the label list
        label_name: The name of the created label
        label_type: The type of the label
        message: Success message
        message_list_visibility: The visibility of messages with this label
        raw_data: Raw data of the created label
    ### When action = 'read_label'
        label_id: The ID of the label
        label_list_visibility: The visibility of the label in the label list
        label_name: The name of the label
        label_type: The type of the label
        message_list_visibility: The visibility of messages with this label
        raw_data: Raw data of the label
    ### When action = 'get_labels'
        label_ids: The IDs of all labels, example: Label_1, Label_2
        label_names: The names of all labels
        label_types: The types of all labels
        raw_data: Raw data of the labels
        system_labels: System labels
        total_labels: Total number of labels
        user_labels: User-created labels
    ### When action = 'send_email'
        labels: The labels applied to the message
        message_id: The ID of the sent message
        raw_data: Raw data of the sent message
        thread_id: The ID of the thread this message belongs to
    ### When action = 'send_reply'
        labels: The labels applied to the message
        message_id: The ID of the sent reply
        raw_data: Raw data of the sent reply
        thread_id: The ID of the thread this message belongs to
    ### When action = 'mark_as_read'
        labels: The updated labels of the message
        message_id: The ID of the modified message
        raw_data: Raw data of the modified message
    ### When action = 'mark_as_unread'
        labels: The updated labels of the message
        message_id: The ID of the modified message
        raw_data: Raw data of the modified message
    ### When action = 'add_label_to_message'
        labels: The updated labels of the message
        message_id: The ID of the modified message
        raw_data: Raw data of the modified message
    ### When action = 'remove_label_from_message'
        labels: The updated labels of the message
        message_id: The ID of the modified message
        raw_data: Raw data of the modified message
    ### When action = 'reply_to_thread'
        labels: The labels applied to the reply
        message_id: The ID of the created reply message
        raw_data: Raw data of the reply
        thread_id: The ID of the thread this reply belongs to
    ### When action = 'trash_message'
        message: Success message
        message_id: The ID of the trashed message
        raw_data: Raw data of the trashed message
    ### When action = 'delete_message'
        message: Success message
        raw_data: Raw data of the deleted message
    ### When action = 'delete_draft'
        message: Success message
        raw_data: Raw data of the deleted draft
    ### When action = 'delete_thread'
        message: Success message
    ### When action = 'delete_label'
        message: Success message
    ### When action = 'add_label_to_thread'
        raw_data: Raw data of the modified thread
        thread_id: The ID of the modified thread
    ### When action = 'remove_label_from_thread'
        raw_data: Raw data of the modified thread
        thread_id: The ID of the modified thread
    ### When action = 'get_threads'
        raw_data: Raw data of the threads
        thread_history_ids: History IDs of the threads
        thread_ids: The IDs of the threads
        thread_snippets: Snippets of the threads
        total_results: Total number of threads found
    ### When action = 'trash_thread'
        raw_data: Raw data of the modified thread
        thread_id: The ID of the modified thread
    ### When action = 'untrash_thread'
        raw_data: Raw data of the modified thread
        thread_id: The ID of the modified thread
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Gmail>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)**(*)**(*)": {
            "inputs": [],
            "outputs": [],
            "variant": "common_integration_nodes",
        },
        "send_email**(*)**(*)": {
            "inputs": [
                {
                    "field": "recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com",
                },
                {
                    "field": "subject",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Introduction to John",
                    "helper_text": "The subject of the email",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "cc1@company.com, cc2@company.com",
                    "helper_text": "Carbon copy recipients who will receive a visible copy of the email (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sender_name",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Name",
                    "placeholder": "John Doe",
                    "helper_text": "Custom name to display as the sender in the recipient's inbox",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Reply To",
                    "placeholder": "replies@company.com",
                    "helper_text": "Alternative email address where replies should be sent instead of the sender's address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to_sender_only",
                    "type": "bool",
                    "value": False,
                    "label": "Reply to Sender Only",
                    "helper_text": "When enabled, ensures that replies go only to the sender, excluding CC or group recipients",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the sent message",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this message belongs to",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the sent message",
                },
            ],
            "name": "send_email",
            "task_name": "tasks.gmail.send_email",
            "description": "Create and send a new email",
            "label": "Send Email",
            "ui_sort_order": [
                "integration",
                "action",
                "format",
                "recipients",
                "cc",
                "bcc",
                "subject",
                "body",
                "sender_name",
                "reply_to",
                "reply_to_sender_only",
                "attachments",
            ],
            "required": ["recipients", "subject", "body", "format"],
        },
        "read_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to read",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "full",
                    "label": "Format",
                    "placeholder": "Full",
                    "helper_text": "The format to return the message in",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Full", "value": "full"},
                            {"label": "Minimal", "value": "minimal"},
                            {"label": "Raw", "value": "raw"},
                            {"label": "Metadata", "value": "metadata"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the message",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this message belongs to",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "The subject of the message",
                },
                {
                    "field": "from",
                    "type": "string",
                    "helper_text": "The sender of the message",
                },
                {
                    "field": "to",
                    "type": "string",
                    "helper_text": "The recipients of the message",
                },
                {
                    "field": "date",
                    "type": "timestamp",
                    "helper_text": "The date the message was sent",
                },
                {
                    "field": "snippet",
                    "type": "string",
                    "helper_text": "A short snippet of the message",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the message",
                },
                {
                    "field": "has_attachments",
                    "type": "bool",
                    "helper_text": "Whether the message has attachments",
                },
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "The body of the message",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "helper_text": "The attachments of the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the message",
                },
            ],
            "name": "read_message",
            "task_name": "tasks.gmail.read_message",
            "description": "Read details of a specific message",
            "label": "Get Message",
            "inputs_sort_order": ["integration", "action", "message_id", "format"],
            "required": ["message_id", "format"],
        },
        "send_reply**(*)**(*)": {
            "inputs": [
                {
                    "field": "recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com ",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "email_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Email Id",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the email (often used in conjunction with a trigger where the email ID is received from the trigger)",
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "cc1@company.com, cc2@company.com",
                    "helper_text": "Carbon copy recipients who will receive a visible copy of the email (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sender_name",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Name",
                    "placeholder": "John Doe",
                    "helper_text": "Custom name to display as the sender in the recipient's inbox",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Reply To",
                    "placeholder": "replies@company.com",
                    "helper_text": "Alternative email address where replies should be sent instead of the sender's address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to_sender_only",
                    "type": "bool",
                    "value": False,
                    "label": "Reply to Sender Only",
                    "helper_text": "When enabled, ensures that replies go only to the sender, excluding CC or group recipients",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                    "order": 7,
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the sent reply",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this message belongs to",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the sent reply",
                },
            ],
            "name": "send_reply",
            "task_name": "tasks.gmail.send_reply",
            "description": "Create and send a new reply to an existing email",
            "label": "Send Reply",
            "ui_sort_order": [
                "integration",
                "action",
                "format",
                "recipients",
                "cc",
                "bcc",
                "body",
                "email_id",
                "sender_name",
                "reply_to",
                "reply_to_sender_only",
                "attachments",
            ],
            "required": ["recipients", "body", "format", "email_id"],
        },
        "list_messages**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "query",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "placeholder": "from:john@company.com subject:urgent",
                    "helper_text": "Raw query string to use directly. If provided, overrides all other query parameters.",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "from",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "From",
                    "placeholder": "john@company.com",
                    "helper_text": "Emails sent by this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "alex@company.com",
                    "helper_text": "Emails sent to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "subject",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "urgent meeting",
                    "helper_text": "Search keywords in the subject",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "project update",
                    "helper_text": "Search text in the email body",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_attachment",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only emails with attachments",
                    "label": "Has Attachment",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Emails With Attachments", "value": "true"},
                            {"label": "Emails Without Attachments", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_images",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Emails containing images",
                    "label": "Has Images",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Emails With Images", "value": "true"},
                            {"label": "Emails Without Images", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_links",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Emails containing links",
                    "label": "Has Links",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Emails With Links", "value": "true"},
                            {"label": "Emails Without Links", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_starred",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only starred emails",
                    "label": "Has Starred",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Starred Emails", "value": "true"},
                            {"label": "Exclude Starred Emails", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_unread",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only unread emails",
                    "label": "Has Unread",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Unread Emails", "value": "true"},
                            {"label": "Exclude Unread Emails", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "label",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Label",
                    "placeholder": "important",
                    "helper_text": "Search emails with this label",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "in",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Inside Folder",
                    "placeholder": "sent",
                    "helper_text": "Search within a folder (e.g. sent, spam)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "is",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Is",
                    "placeholder": "unread",
                    "helper_text": "Filter by status (e.g. read, unread, starred)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Has",
                    "placeholder": "attachment",
                    "helper_text": "Filter by feature (e.g. attachment, drive)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "filename",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Filename",
                    "placeholder": "report.pdf",
                    "helper_text": "Find attachments by name or type",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "newer_than",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Newer Than",
                    "placeholder": "7d",
                    "helper_text": "Emails newer than a time (e.g. 7d, 2m)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "older_than",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Older Than",
                    "placeholder": "1m",
                    "helper_text": "Emails older than a time (e.g. 7d, 2m)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "manager@company.com",
                    "helper_text": "Emails CC'd to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "admin@company.com",
                    "helper_text": "Emails BCC'd to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "list",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "newsletter@company.com",
                    "helper_text": "Emails from this mailing list",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "category",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "primary",
                    "helper_text": "Filter by tab (e.g. Primary, Social)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "larger",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Larger",
                    "placeholder": "5M",
                    "helper_text": "Emails larger than this size (e.g. 5M)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "smaller",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Smaller",
                    "placeholder": "1M",
                    "helper_text": "Emails smaller than this size (e.g. 5M)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "custom_params",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Custom Parameters",
                    "placeholder": "has:nouserlabels",
                    "helper_text": "Extra filters as raw query",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "projection",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Projection",
                    "placeholder": "id,threadId,snippet",
                    "helper_text": "Select which fields to return",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "page_token",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Page Token",
                    "placeholder": "abc123nextpage",
                    "helper_text": "Use to fetch next page of results",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "label_ids",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Emails with all listed label IDs",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_user_labels",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Emails with custom labels",
                    "label": "Has User Labels",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Emails With User Labels", "value": "true"},
                            {"label": "Emails Without User Labels", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_spam_trash",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Include spam and trash emails",
                    "label": "Include Spam Trash",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Spam and Trash Emails", "value": "true"},
                            {
                                "label": "Exclude Spam and Trash Emails",
                                "value": "false",
                            },
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "msg_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "Search by message ID (ignores other filters)",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "email_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of the retrieved emails",
                },
                {
                    "field": "email_subjects",
                    "type": "vec<string>",
                    "helper_text": "The subjects of the retrieved emails",
                },
                {
                    "field": "email_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "The sent dates of the retrieved emails",
                },
                {
                    "field": "email_bodies",
                    "type": "vec<string>",
                    "helper_text": "The content of the retrieved emails",
                },
                {
                    "field": "sender_addresses",
                    "type": "vec<string>",
                    "helper_text": "The email addresses of the senders",
                },
                {
                    "field": "email_display_names",
                    "type": "vec<string>",
                    "helper_text": "The display names of the senders",
                },
                {
                    "field": "recipient_addresses",
                    "type": "vec<string>",
                    "helper_text": "The email addresses of the recipients",
                },
                {
                    "field": "attachments",
                    "type": "vec<vec<file>>",
                    "helper_text": "The attachments of the retrieved emails",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the retrieved emails",
                },
            ],
            "variant": "get_integration_nodes",
            "name": "list_messages",
            "task_name": "tasks.gmail.list_messages",
            "description": "Get multiple emails",
            "label": "List Emails",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "query",
                "from",
                "to",
                "subject",
                "body",
                "has_attachment",
                "has_images",
                "has_links",
                "has_starred",
                "has_unread",
                "has_user_labels",
                "label",
                "in",
                "is",
                "has",
                "filename",
                "newer_than",
                "older_than",
                "cc",
                "bcc",
                "list",
                "category",
                "larger",
                "smaller",
                "custom_params",
                "projection",
                "page_token",
                "label_ids",
                "include_spam_trash",
                "msg_id",
            ],
        },
        "list_messages**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Emails",
                    "helper_text": "Specify the last n number of emails",
                }
            ],
            "outputs": [],
        },
        "list_messages**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "list_messages**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "label": "Date Range",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "list_messages**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "label": "Exact date",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "mark_as_read**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to mark as read",
                }
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the modified message",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The updated labels of the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified message",
                },
            ],
            "name": "mark_as_read",
            "hidden": True,
            "task_name": "tasks.gmail.mark_as_read",
            "description": "Mark a message as read",
            "label": "Mark as Read",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "message_id"],
            "required": ["message_id"],
        },
        "mark_as_unread**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to mark as unread",
                }
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the modified message",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The updated labels of the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified message",
                },
            ],
            "name": "mark_as_unread",
            "hidden": True,
            "task_name": "tasks.gmail.mark_as_unread",
            "description": "Mark a message as unread",
            "label": "Mark as Unread",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "message_id"],
            "required": ["message_id"],
        },
        "add_label_to_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to add labels to",
                },
                {
                    "field": "label_ids",
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Comma-separated list of label IDs to add, example: Label_1, Label_2",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the modified message",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The updated labels of the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified message",
                },
            ],
            "name": "add_label_to_message",
            "hidden": True,
            "task_name": "tasks.gmail.add_label_to_message",
            "description": "Add labels to a message",
            "label": "Add Label to Message",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "message_id", "label_ids"],
            "required": ["message_id", "label_ids"],
        },
        "remove_label_from_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to remove labels from",
                },
                {
                    "field": "label_ids",
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Comma-separated list of label IDs to remove, example: Label_1, Label_2",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the modified message",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The updated labels of the message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified message",
                },
            ],
            "name": "remove_label_from_message",
            "hidden": True,
            "task_name": "tasks.gmail.remove_label_from_message",
            "description": "Remove labels from a message",
            "label": "Remove Label from Message",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "message_id", "label_ids"],
            "required": ["message_id", "label_ids"],
        },
        "trash_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to trash",
                }
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the trashed message",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the trashed message",
                },
            ],
            "name": "trash_message",
            "hidden": True,
            "task_name": "tasks.gmail.trash_message",
            "description": "Move a message to the trash",
            "label": "Trash Message",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "message_id"],
            "required": ["message_id"],
        },
        "delete_message**(*)**(*)": {
            "inputs": [
                {
                    "field": "message_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the message to delete",
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the deleted message",
                },
            ],
            "name": "delete_message",
            "hidden": True,
            "task_name": "tasks.gmail.delete_message",
            "description": "Permanently delete a message",
            "label": "Delete Message",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "message_id"],
            "required": ["message_id"],
            "banner_text": "This action will permanently delete the message and cannot be undone.",
        },
        "create_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com",
                },
                {
                    "field": "subject",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "Introduction to John",
                    "helper_text": "The subject of the email",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "cc1@company.com, cc2@company.com",
                    "helper_text": "Carbon copy recipients who will receive a visible copy of the email (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sender_name",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Name",
                    "placeholder": "John Doe",
                    "helper_text": "Custom name to display as the sender in the recipient's inbox",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Reply To",
                    "placeholder": "replies@company.com",
                    "helper_text": "Alternative email address where replies should be sent instead of the sender's address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to_sender_only",
                    "type": "bool",
                    "value": False,
                    "label": "Reply to Sender Only",
                    "helper_text": "When enabled, ensures that replies go only to the sender, excluding CC or group recipients",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "draft_id",
                    "type": "string",
                    "helper_text": "The ID of the created draft",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the created draft message",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this draft belongs to",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the draft",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the created draft",
                },
            ],
            "name": "create_draft",
            "task_name": "tasks.gmail.create_email_draft",
            "description": "Create (but do not send) a new email",
            "label": "Create Email Draft",
            "ui_sort_order": [
                "integration",
                "action",
                "format",
                "recipients",
                "cc",
                "bcc",
                "subject",
                "body",
                "sender_name",
                "reply_to",
                "reply_to_sender_only",
                "attachments",
            ],
            "required": ["recipients", "subject", "body", "format"],
        },
        "read_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "draft_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Draft ID",
                    "placeholder": "r-123456789abcdef",
                    "helper_text": "The ID of the draft to read",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "full",
                    "label": "Format",
                    "placeholder": "Full",
                    "helper_text": "The format to return the draft in",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Full", "value": "full"},
                            {"label": "Minimal", "value": "minimal"},
                            {"label": "Raw", "value": "raw"},
                            {"label": "Metadata", "value": "metadata"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "draft_id",
                    "type": "string",
                    "helper_text": "The ID of the draft",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the draft message",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this draft belongs to",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "helper_text": "The subject of the draft",
                },
                {
                    "field": "from",
                    "type": "string",
                    "helper_text": "The sender of the draft",
                },
                {
                    "field": "to",
                    "type": "string",
                    "helper_text": "The recipients of the draft",
                },
                {
                    "field": "date",
                    "type": "timestamp",
                    "helper_text": "The date the draft was created",
                },
                {
                    "field": "snippet",
                    "type": "string",
                    "helper_text": "A short snippet of the draft",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the draft",
                },
                {
                    "field": "has_attachments",
                    "type": "bool",
                    "helper_text": "Whether the draft has attachments",
                },
                {
                    "field": "body",
                    "type": "string",
                    "helper_text": "The body of the draft",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "helper_text": "The attachments of the draft",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the draft",
                },
            ],
            "name": "read_draft",
            "task_name": "tasks.gmail.read_draft",
            "description": "Read details of a specific draft",
            "label": "Get Draft",
            "inputs_sort_order": ["integration", "action", "draft_id", "format"],
            "required": ["draft_id", "format"],
        },
        "draft_reply**(*)**(*)": {
            "inputs": [
                {
                    "field": "recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the email",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "email_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Email Id",
                    "placeholder": "r-123456789abcdef",
                    "helper_text": "The ID of the email (often used in conjunction with a trigger where the email ID is received from the trigger)",
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "cc1@company.com, cc2@company.com",
                    "helper_text": "Carbon copy recipients who will receive a visible copy of the email (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sender_name",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Name",
                    "placeholder": "John Doe",
                    "helper_text": "Custom name to display as the sender in the recipient's inbox",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Reply To",
                    "placeholder": "replies@company.com",
                    "helper_text": "Alternative email address where replies should be sent instead of the sender's address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to_sender_only",
                    "type": "bool",
                    "value": False,
                    "label": "Reply to Sender Only",
                    "helper_text": "When enabled, ensures that replies go only to the sender, excluding CC or group recipients",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "draft_id",
                    "type": "string",
                    "helper_text": "The ID of the created draft",
                },
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the created draft message",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this draft belongs to",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the draft",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the draft reply",
                },
            ],
            "name": "draft_reply",
            "task_name": "tasks.gmail.draft_reply",
            "description": "Create (but do not send) a draft of a reply to an existing email",
            "label": "Draft Reply",
            "ui_sort_order": [
                "integration",
                "action",
                "format",
                "recipients",
                "cc",
                "bcc",
                "body",
                "email_id",
                "sender_name",
                "reply_to",
                "reply_to_sender_only",
                "attachments",
            ],
            "required": ["recipients", "body", "format", "email_id"],
        },
        "get_drafts**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "query",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "placeholder": "from:john@company.com subject:urgent",
                    "helper_text": "Raw query string to use directly. If provided, overrides all other query parameters.",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "from",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "From",
                    "placeholder": "john@company.com",
                    "helper_text": "Drafts created by this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "alex@company.com",
                    "helper_text": "Drafts sent to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "subject",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "draft meeting",
                    "helper_text": "Search keywords in the subject",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "project update",
                    "helper_text": "Search text in the draft body",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_attachment",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only drafts with attachments",
                    "label": "Has Attachment",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Drafts With Attachments", "value": "true"},
                            {"label": "Drafts Without Attachments", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_images",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Drafts containing images",
                    "label": "Has Images",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Drafts With Images", "value": "true"},
                            {"label": "Drafts Without Images", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_links",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Drafts containing links",
                    "label": "Has Links",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Drafts With Links", "value": "true"},
                            {"label": "Drafts Without Links", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_starred",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only starred drafts",
                    "label": "Has Starred",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Starred Drafts", "value": "true"},
                            {"label": "Exclude Starred Drafts", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_unread",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only unread drafts",
                    "label": "Has Unread",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Unread Drafts", "value": "true"},
                            {"label": "Exclude Unread Drafts", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "label",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Label",
                    "placeholder": "important",
                    "helper_text": "Search drafts with this label",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "in",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Inside Folder",
                    "placeholder": "drafts",
                    "helper_text": "Search within a folder (e.g. drafts, spam)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "is",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Is",
                    "placeholder": "unread",
                    "helper_text": "Filter by status (e.g. read, unread, starred)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Has",
                    "placeholder": "attachment",
                    "helper_text": "Filter by feature (e.g. attachment, drive)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "filename",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Filename",
                    "placeholder": "report.pdf",
                    "helper_text": "Find attachments by name or type",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "newer_than",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Newer Than",
                    "placeholder": "7d",
                    "helper_text": "Drafts newer than a time (e.g. 7d, 2m)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "older_than",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Older Than",
                    "placeholder": "1m",
                    "helper_text": "Drafts older than a time (e.g. 7d, 2m)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "manager@company.com",
                    "helper_text": "Drafts CC'd to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "admin@company.com",
                    "helper_text": "Drafts BCC'd to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "list",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "newsletter@company.com",
                    "helper_text": "Drafts from this mailing list",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "category",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "primary",
                    "helper_text": "Filter by tab (e.g. Primary, Social)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "larger",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Larger",
                    "placeholder": "5M",
                    "helper_text": "Drafts larger than this size (e.g. 5M)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "smaller",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Smaller",
                    "placeholder": "1M",
                    "helper_text": "Drafts smaller than this size (e.g. 5M)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "detailed_view",
                    "type": "bool",
                    "value": False,
                    "label": "Detailed View",
                    "placeholder": False,
                    "helper_text": "Include full draft details in the response",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "page_token",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Page Token",
                    "placeholder": "abc123nextpage",
                    "helper_text": "Use to fetch next page of results",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "label_ids",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Drafts with all listed label IDs",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_user_labels",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Drafts with custom labels",
                    "label": "Has User Labels",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Drafts With User Labels", "value": "true"},
                            {"label": "Drafts Without User Labels", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_spam_trash",
                    "type": "bool",
                    "value": False,
                    "label": "Include Spam/Trash",
                    "helper_text": "Include drafts in spam and trash",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "draft_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of the drafts",
                },
                {
                    "field": "draft_message_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of the draft messages",
                },
                {
                    "field": "draft_thread_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of the draft threads",
                },
                {
                    "field": "draft_subjects",
                    "type": "vec<string>",
                    "helper_text": "The subjects of the drafts",
                },
                {
                    "field": "draft_bodies",
                    "type": "vec<string>",
                    "helper_text": "The bodies of the drafts",
                },
                {
                    "field": "draft_recipients",
                    "type": "vec<string>",
                    "helper_text": "The recipients of the drafts",
                },
                {
                    "field": "attachments",
                    "type": "vec<vec<file>>",
                    "helper_text": "The attachments of the drafts",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of drafts found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the drafts",
                },
            ],
            "name": "get_drafts",
            "task_name": "tasks.gmail.get_drafts",
            "description": "Get multiple drafts",
            "label": "List Drafts",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "query",
                "from",
                "to",
                "subject",
                "body",
                "has_attachment",
                "has_images",
                "has_links",
                "has_starred",
                "has_unread",
                "has_user_labels",
                "label",
                "in",
                "is",
                "has",
                "filename",
                "newer_than",
                "older_than",
                "cc",
                "bcc",
                "list",
                "category",
                "larger",
                "smaller",
                "detailed_view",
                "page_token",
                "label_ids",
                "include_spam_trash",
            ],
        },
        "get_drafts**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Drafts",
                    "helper_text": "Specify the number of drafts to fetch",
                }
            ],
            "outputs": [],
        },
        "get_drafts**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_drafts**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_drafts**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "trash_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "draft_message_id",
                    "type": "string",
                    "value": "",
                    "label": "Draft Message ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the draft message to trash",
                }
            ],
            "outputs": [
                {
                    "field": "draft_message_id",
                    "type": "string",
                    "helper_text": "The ID of the trashed draft message",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the trashed draft",
                },
            ],
            "name": "trash_draft",
            "hidden": True,
            "task_name": "tasks.gmail.trash_draft",
            "description": "Move a draft to the trash",
            "label": "Trash Draft",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "draft_message_id"],
            "required": ["draft_message_id"],
        },
        "delete_draft**(*)**(*)": {
            "inputs": [
                {
                    "field": "draft_id",
                    "type": "string",
                    "value": "",
                    "label": "Draft ID",
                    "placeholder": "r-123456789abcdef",
                    "helper_text": "The ID of the draft to delete",
                }
            ],
            "outputs": [
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the deleted draft",
                },
            ],
            "name": "delete_draft",
            "hidden": True,
            "task_name": "tasks.gmail.delete_draft",
            "description": "Permanently delete a draft",
            "label": "Delete Draft",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "draft_id"],
            "required": ["draft_id"],
            "banner_text": "This action will permanently delete the draft and cannot be undone.",
        },
        "read_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to read",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "full",
                    "label": "Format",
                    "placeholder": "full",
                    "helper_text": "The format to return the thread in",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Full", "value": "full"},
                            {"label": "Minimal", "value": "minimal"},
                            {"label": "Metadata", "value": "metadata"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread",
                },
                {
                    "field": "history_id",
                    "type": "string",
                    "helper_text": "The history ID of the thread",
                },
                {
                    "field": "messages",
                    "type": "vec<string>",
                    "helper_text": "The messages in the thread",
                },
                {
                    "field": "message_subjects",
                    "type": "vec<string>",
                    "helper_text": "The subjects of messages in the thread",
                },
                {
                    "field": "message_senders",
                    "type": "vec<string>",
                    "helper_text": "The senders of messages in the thread",
                },
                {
                    "field": "message_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "The dates of messages in the thread",
                },
                {
                    "field": "message_bodies",
                    "type": "vec<string>",
                    "helper_text": "The bodies of messages in the thread",
                },
                {
                    "field": "message_count",
                    "type": "int32",
                    "helper_text": "Number of messages in the thread",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the thread",
                },
            ],
            "name": "read_thread",
            "task_name": "tasks.gmail.read_thread",
            "description": "Read details of a specific thread",
            "label": "Get Thread",
            "inputs_sort_order": ["integration", "action", "thread_id", "format"],
            "required": ["thread_id", "format"],
        },
        "add_label_to_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to add labels to",
                },
                {
                    "field": "label_ids",
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Comma-separated list of label IDs to add, example: Label_1, Label_2",
                },
            ],
            "outputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the modified thread",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified thread",
                },
            ],
            "name": "add_label_to_thread",
            "hidden": True,
            "task_name": "tasks.gmail.add_label_to_thread",
            "description": "Add labels to a thread",
            "label": "Add Label to Thread",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "thread_id", "label_ids"],
            "required": ["thread_id", "label_ids"],
        },
        "remove_label_from_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to remove labels from",
                },
                {
                    "field": "label_ids",
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Comma-separated list of label IDs to remove, example: Label_1, Label_2",
                },
            ],
            "outputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the modified thread",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified thread",
                },
            ],
            "name": "remove_label_from_thread",
            "hidden": True,
            "task_name": "tasks.gmail.remove_label_from_thread",
            "description": "Remove labels from a thread",
            "label": "Remove Label from Thread",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "thread_id", "label_ids"],
            "required": ["thread_id", "label_ids"],
        },
        "reply_to_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to reply to",
                },
                {
                    "field": "recipients",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "john@company.com, alex@company.com",
                    "helper_text": "A single email or a comma-separated list of the recipients' emails, example: john@company.com, alex@company.com",
                },
                {
                    "field": "body",
                    "multiline": True,
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "Hi John, …",
                    "helper_text": "The body of the reply",
                },
                {
                    "field": "format",
                    "type": "string",
                    "value": "text",
                    "label": "Format",
                    "placeholder": "html / text (default)",
                    "helper_text": "Either html (to allow html content) or text (for plaintext content - default)",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "HTML", "value": "html"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "cc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "cc1@company.com, cc2@company.com",
                    "helper_text": "Carbon copy recipients who will receive a visible copy of the email (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "bcc@company.com",
                    "helper_text": "Blind carbon copy recipients. These addresses are hidden from other recipients (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "sender_name",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Sender Name",
                    "placeholder": "John Doe",
                    "helper_text": "Custom name to display as the sender in the recipient's inbox",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to",
                    "multiline": False,
                    "type": "string",
                    "value": "",
                    "label": "Reply To",
                    "placeholder": "replies@company.com",
                    "helper_text": "Alternative email address where replies should be sent instead of the sender's address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "reply_to_sender_only",
                    "type": "bool",
                    "value": False,
                    "label": "Reply to Sender Only",
                    "helper_text": "When enabled, ensures that replies go only to the sender, excluding CC or group recipients",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "attachments",
                    "type": "vec<file>",
                    "value": [],
                    "label": "Attachments",
                    "placeholder": "Attachments!",
                    "helper_text": "Attachments to be appended.",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "message_id",
                    "type": "string",
                    "helper_text": "The ID of the created reply message",
                },
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the thread this reply belongs to",
                },
                {
                    "field": "labels",
                    "type": "vec<string>",
                    "helper_text": "The labels applied to the reply",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the reply",
                },
            ],
            "name": "reply_to_thread",
            "hidden": True,
            "task_name": "tasks.gmail.reply_to_thread",
            "description": "Reply to a thread",
            "label": "Reply to Thread",
            "ui_sort_order": [
                "integration",
                "action",
                "thread_id",
                "format",
                "recipients",
                "cc",
                "bcc",
                "body",
                "sender_name",
                "reply_to",
                "reply_to_sender_only",
                "attachments",
            ],
            "required": ["thread_id", "recipients", "body", "format"],
        },
        "get_threads**(*)**(*)": {
            "inputs": [
                {
                    "field": "use_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Date",
                    "helper_text": "Toggle to use dates",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "placeholder": "from:john@company.com subject:urgent",
                    "helper_text": "Raw query string to use directly. If provided, overrides all other query parameters.",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "from",
                    "type": "string",
                    "value": "",
                    "label": "From",
                    "placeholder": "john@company.com",
                    "helper_text": "Threads with emails from this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "to",
                    "type": "string",
                    "value": "",
                    "label": "To",
                    "placeholder": "alex@company.com",
                    "helper_text": "Threads with emails to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "subject",
                    "type": "string",
                    "value": "",
                    "label": "Subject",
                    "placeholder": "urgent meeting",
                    "helper_text": "Search keywords in the subject",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "body",
                    "type": "string",
                    "value": "",
                    "label": "Body",
                    "placeholder": "project update",
                    "helper_text": "Search text in the thread body",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_attachment",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only threads with attachments",
                    "label": "Has Attachment",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Threads With Attachments", "value": "true"},
                            {"label": "Threads Without Attachments", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_images",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Threads containing images",
                    "label": "Has Images",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Threads With Images", "value": "true"},
                            {"label": "Threads Without Images", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_links",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Threads containing links",
                    "label": "Has Links",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Threads With Links", "value": "true"},
                            {"label": "Threads Without Links", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_starred",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only starred threads",
                    "label": "Has Starred",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Starred Threads", "value": "true"},
                            {"label": "Exclude Starred Threads", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_unread",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only unread threads",
                    "label": "Has Unread",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Unread Threads", "value": "true"},
                            {"label": "Exclude Unread Threads", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_important",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only important threads",
                    "label": "Has Important",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Important Threads", "value": "true"},
                            {"label": "Exclude Important Threads", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_chat",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Only chat threads",
                    "label": "Has Chat",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Include Chat Threads", "value": "true"},
                            {"label": "Exclude Chat Threads", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "label",
                    "type": "string",
                    "value": "",
                    "label": "Label",
                    "placeholder": "important",
                    "helper_text": "Search threads with this label",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "in",
                    "type": "string",
                    "value": "",
                    "label": "Inside Folder",
                    "placeholder": "sent",
                    "helper_text": "Search within a folder (e.g. sent, spam) the in: prefix is already there so only add mailbox after that",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "is",
                    "type": "string",
                    "value": "",
                    "label": "Is",
                    "placeholder": "unread",
                    "helper_text": "Filter by status (e.g. read, unread, starred)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has",
                    "type": "string",
                    "value": "",
                    "label": "Has",
                    "placeholder": "attachment",
                    "helper_text": "Filter by feature (e.g. attachment, drive)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "filename",
                    "type": "string",
                    "value": "",
                    "label": "Filename",
                    "placeholder": "report.pdf",
                    "helper_text": "Find attachments by name or type",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "newer_than",
                    "type": "string",
                    "value": "",
                    "label": "Newer Than",
                    "placeholder": "7d",
                    "helper_text": "Threads newer than a time (e.g. 7d, 2m)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "older_than",
                    "type": "string",
                    "value": "",
                    "label": "Older Than",
                    "placeholder": "1m",
                    "helper_text": "Threads older than a time (e.g. 7d, 2m)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "cc",
                    "type": "string",
                    "value": "",
                    "label": "CC",
                    "placeholder": "manager@company.com",
                    "helper_text": "Threads with emails CC'd to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "bcc",
                    "type": "string",
                    "value": "",
                    "label": "BCC",
                    "placeholder": "admin@company.com",
                    "helper_text": "Threads with emails BCC'd to this address",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "list",
                    "type": "string",
                    "value": "",
                    "label": "List",
                    "placeholder": "newsletter@company.com",
                    "helper_text": "Threads from this mailing list",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "category",
                    "type": "string",
                    "value": "",
                    "label": "Category",
                    "placeholder": "primary",
                    "helper_text": "Filter by tab (e.g. Primary, Social)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "larger",
                    "type": "string",
                    "value": "",
                    "label": "Larger",
                    "placeholder": "5M",
                    "helper_text": "Threads larger than this size (e.g. 5M)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "smaller",
                    "type": "string",
                    "value": "",
                    "label": "Smaller",
                    "placeholder": "1M",
                    "helper_text": "Threads smaller than this size (e.g. 5M)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "read_status",
                    "type": "string",
                    "value": "all",
                    "helper_text": "Filter by read status",
                    "label": "Read Status",
                    "placeholder": "All",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "All", "value": "all"},
                            {"label": "Unread", "value": "unread"},
                            {"label": "Read", "value": "read"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "received_after",
                    "type": "timestamp",
                    "value": "",
                    "hidden": True,
                    "label": "Received After",
                    "placeholder": "2023-01-01T00:00:00Z",
                    "helper_text": "RFC3339 timestamp (e.g. 2023-01-01T00:00:00Z)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "received_before",
                    "type": "timestamp",
                    "value": "",
                    "hidden": True,
                    "label": "Received Before",
                    "placeholder": "2023-12-31T23:59:59Z",
                    "helper_text": "RFC3339 timestamp (e.g. 2023-12-31T23:59:59Z)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "page_token",
                    "type": "string",
                    "value": "",
                    "label": "Page Token",
                    "placeholder": "abc123nextpage",
                    "helper_text": "Use to fetch next page of results",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "label_ids",
                    "type": "string",
                    "value": "",
                    "label": "Label IDs",
                    "placeholder": "Label_1,Label_2",
                    "helper_text": "Filter by label IDs (comma-separated)",
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "has_user_labels",
                    "type": "string",
                    "value": "Ignore",
                    "helper_text": "Threads with custom labels",
                    "label": "Has User Labels",
                    "placeholder": "Ignore",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Threads With User Labels", "value": "true"},
                            {"label": "Threads Without User Labels", "value": "false"},
                            {"label": "Ignore", "value": "Ignore"},
                        ],
                    },
                    "section": "additional_fields_dropdown",
                },
                {
                    "field": "include_spam_trash",
                    "type": "bool",
                    "value": False,
                    "label": "Include Spam/Trash",
                    "helper_text": "Include threads in spam and trash",
                    "section": "additional_fields_dropdown",
                },
            ],
            "outputs": [
                {
                    "field": "thread_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of the threads",
                },
                {
                    "field": "thread_snippets",
                    "type": "vec<string>",
                    "helper_text": "Snippets of the threads",
                },
                {
                    "field": "thread_history_ids",
                    "type": "vec<string>",
                    "helper_text": "History IDs of the threads",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of threads found",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the threads",
                },
            ],
            "name": "get_threads",
            "task_name": "tasks.gmail.get_threads",
            "description": "Get email threads from Gmail",
            "label": "List Threads",
            "variant": "get_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "use_date",
                "use_exact_date",
                "date_range",
                "exact_date",
                "num_messages",
                "query",
                "from",
                "to",
                "subject",
                "body",
                "has_attachment",
                "has_images",
                "has_links",
                "has_starred",
                "has_unread",
                "has_user_labels",
                "has_important",
                "has_chat",
                "label",
                "in",
                "is",
                "has",
                "filename",
                "newer_than",
                "older_than",
                "cc",
                "bcc",
                "list",
                "category",
                "larger",
                "smaller",
                "read_status",
                "received_after",
                "received_before",
                "page_token",
                "label_ids",
                "include_spam_trash",
            ],
        },
        "get_threads**false**(*)": {
            "inputs": [
                {
                    "field": "num_messages",
                    "type": "int32",
                    "value": 10,
                    "show_date_range": True,
                    "label": "Number of Threads",
                    "helper_text": "Specify the number of threads to fetch",
                }
            ],
            "outputs": [],
        },
        "get_threads**true**(*)": {
            "inputs": [
                {
                    "field": "use_exact_date",
                    "type": "bool",
                    "value": False,
                    "show_date_range": True,
                    "label": "Use Exact Date",
                    "helper_text": "Switch between exact date range and relative dates",
                }
            ],
            "outputs": [],
        },
        "get_threads**true**false": {
            "inputs": [
                {
                    "field": "date_range",
                    "type": "interface{date_type: enum<string>, date_value: int, date_period: enum<string>}",
                    "value": {
                        "date_type": "Last",
                        "date_value": 1,
                        "date_period": "Months",
                    },
                    "show_date_range": True,
                    "label": "Date Range",
                    "placeholder": "last 3 days",
                    "helper_text": "pick the relative date range",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "get_threads**true**true": {
            "inputs": [
                {
                    "field": "exact_date",
                    "type": "interface{start: string, end: string}",
                    "value": {"start": "", "end": ""},
                    "show_date_range": True,
                    "label": "Exact Date",
                    "placeholder": "2021-01-01 12:00:00",
                    "helper_text": "Pick the start and end dates",
                    "component": {"type": "date_range"},
                }
            ],
            "outputs": [],
        },
        "trash_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to move to trash",
                }
            ],
            "outputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the modified thread",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified thread",
                },
            ],
            "name": "trash_thread",
            "hidden": True,
            "task_name": "tasks.gmail.trash_thread",
            "description": "Move a thread to trash",
            "label": "Trash Thread",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "thread_id"],
            "required": ["thread_id"],
        },
        "delete_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to delete",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Success message"}
            ],
            "name": "delete_thread",
            "hidden": True,
            "task_name": "tasks.gmail.delete_thread",
            "description": "Permanently delete a thread",
            "label": "Delete Thread",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "thread_id"],
            "required": ["thread_id"],
            "banner_text": "This action will permanently delete the thread and cannot be undone.",
        },
        "untrash_thread**(*)**(*)": {
            "inputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "value": "",
                    "label": "Thread ID",
                    "placeholder": "123456789abcdef",
                    "helper_text": "The ID of the thread to remove from trash",
                }
            ],
            "outputs": [
                {
                    "field": "thread_id",
                    "type": "string",
                    "helper_text": "The ID of the modified thread",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the modified thread",
                },
            ],
            "name": "untrash_thread",
            "hidden": True,
            "task_name": "tasks.gmail.untrash_thread",
            "description": "Remove a thread from trash",
            "label": "Untrash Thread",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "thread_id"],
            "required": ["thread_id"],
        },
        "create_label**(*)**(*)": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Label Name",
                    "placeholder": "My Custom Label",
                    "helper_text": "The name of the label to create",
                },
                {
                    "field": "label_list_visibility",
                    "type": "string",
                    "value": "",
                    "label": "Label List Visibility",
                    "placeholder": "labelShow",
                    "helper_text": "The visibility of the label in the label list",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Show", "value": "labelShow"},
                            {"label": "Show If Unread", "value": "labelShowIfUnread"},
                            {"label": "Hide", "value": "labelHide"},
                        ],
                    },
                },
                {
                    "field": "message_list_visibility",
                    "type": "string",
                    "value": "show",
                    "label": "Message List Visibility",
                    "placeholder": "show",
                    "helper_text": "The visibility of messages with this label",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Show", "value": "show"},
                            {"label": "Hide", "value": "hide"},
                        ],
                    },
                },
            ],
            "outputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "The ID of the created label",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "The name of the created label",
                },
                {
                    "field": "label_type",
                    "type": "string",
                    "helper_text": "The type of the label",
                },
                {
                    "field": "message_list_visibility",
                    "type": "string",
                    "helper_text": "The visibility of messages with this label",
                },
                {
                    "field": "label_list_visibility",
                    "type": "string",
                    "helper_text": "The visibility of the label in the label list",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the created label",
                },
            ],
            "name": "create_label",
            "hidden": True,
            "task_name": "tasks.gmail.create_label",
            "description": "Create a new label",
            "label": "Create Label",
            "ui_sort_order": [
                "integration",
                "action",
                "name",
                "label_list_visibility",
                "message_list_visibility",
            ],
            "required": ["name", "label_list_visibility", "message_list_visibility"],
        },
        "read_label**(*)**(*)": {
            "inputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "value": "",
                    "label": "Label ID",
                    "placeholder": "Label_123456789",
                    "helper_text": "The ID of the label to read, example: Label_1, Label_2",
                }
            ],
            "outputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "helper_text": "The ID of the label",
                },
                {
                    "field": "label_name",
                    "type": "string",
                    "helper_text": "The name of the label",
                },
                {
                    "field": "label_type",
                    "type": "string",
                    "helper_text": "The type of the label",
                },
                {
                    "field": "message_list_visibility",
                    "type": "string",
                    "helper_text": "The visibility of messages with this label",
                },
                {
                    "field": "label_list_visibility",
                    "type": "string",
                    "helper_text": "The visibility of the label in the label list",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the label",
                },
            ],
            "name": "read_label",
            "task_name": "tasks.gmail.read_label",
            "description": "Read details of a specific label",
            "label": "Get Label",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "label_id"],
            "required": ["label_id"],
        },
        "get_labels**(*)**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "label_ids",
                    "type": "vec<string>",
                    "helper_text": "The IDs of all labels, example: Label_1, Label_2",
                },
                {
                    "field": "label_names",
                    "type": "vec<string>",
                    "helper_text": "The names of all labels",
                },
                {
                    "field": "label_types",
                    "type": "vec<string>",
                    "helper_text": "The types of all labels",
                },
                {
                    "field": "system_labels",
                    "type": "vec<string>",
                    "helper_text": "System labels",
                },
                {
                    "field": "user_labels",
                    "type": "vec<string>",
                    "helper_text": "User-created labels",
                },
                {
                    "field": "total_labels",
                    "type": "int32",
                    "helper_text": "Total number of labels",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the labels",
                },
            ],
            "name": "get_labels",
            "task_name": "tasks.gmail.get_labels",
            "description": "Get multiple labels",
            "label": "List Labels",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action"],
        },
        "delete_label**(*)**(*)": {
            "inputs": [
                {
                    "field": "label_id",
                    "type": "string",
                    "value": "",
                    "label": "Label ID",
                    "placeholder": "Label_123456789",
                    "helper_text": "The ID of the label to delete, example: Label_1, Label_2",
                }
            ],
            "outputs": [
                {"field": "message", "type": "string", "helper_text": "Success message"}
            ],
            "name": "delete_label",
            "hidden": True,
            "task_name": "tasks.gmail.delete_label",
            "description": "Delete a label",
            "label": "Delete Label",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "label_id"],
            "banner_text": "This action will permanently delete the label and cannot be undone.",
            "required": ["label_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action", "use_date", "use_exact_date"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action", "num_messages"]

    def __init__(
        self,
        action: str = "",
        use_date: bool = False,
        use_exact_date: bool = False,
        query: str = "",
        attachments: List[str] = [],
        bcc: str = "",
        body: str = "",
        category: str = "",
        cc: str = "",
        custom_params: str = "",
        date_range: DateRange = {
            "date_type": "Last",
            "date_value": 1,
            "date_period": "Months",
        },
        detailed_view: bool = False,
        draft_id: str = "",
        draft_message_id: str = "",
        email_id: str = "",
        exact_date: TimeRange = {"start": "", "end": ""},
        filename: str = "",
        format: str = "text",
        from_: str = "",
        has: str = "",
        has_attachment: str = "Ignore",
        has_chat: str = "Ignore",
        has_images: str = "Ignore",
        has_important: str = "Ignore",
        has_links: str = "Ignore",
        has_starred: str = "Ignore",
        has_unread: str = "Ignore",
        has_user_labels: str = "Ignore",
        in_: str = "",
        include_spam_trash: str = "Ignore",
        is_: str = "",
        label: str = "",
        label_id: str = "",
        label_ids: str = "",
        label_list_visibility: str = "",
        larger: str = "",
        list: str = "",
        message_id: str = "",
        message_list_visibility: str = "show",
        msg_id: str = "",
        name: str = "",
        newer_than: str = "",
        num_messages: int = 10,
        older_than: str = "",
        page_token: str = "",
        projection: str = "",
        read_status: str = "all",
        received_after: Any = None,
        received_before: Any = None,
        recipients: str = "",
        reply_to: str = "",
        reply_to_sender_only: bool = False,
        sender_name: str = "",
        smaller: str = "",
        subject: str = "",
        thread_id: str = "",
        to: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action
        params["use_date"] = use_date
        params["use_exact_date"] = use_exact_date

        super().__init__(
            node_type="integration_gmail",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if recipients is not None:
            self.inputs["recipients"] = recipients
        if subject is not None:
            self.inputs["subject"] = subject
        if body is not None:
            self.inputs["body"] = body
        if format is not None:
            self.inputs["format"] = format
        if cc is not None:
            self.inputs["cc"] = cc
        if bcc is not None:
            self.inputs["bcc"] = bcc
        if sender_name is not None:
            self.inputs["sender_name"] = sender_name
        if reply_to is not None:
            self.inputs["reply_to"] = reply_to
        if reply_to_sender_only is not None:
            self.inputs["reply_to_sender_only"] = reply_to_sender_only
        if attachments is not None:
            self.inputs["attachments"] = attachments
        if message_id is not None:
            self.inputs["message_id"] = message_id
        if email_id is not None:
            self.inputs["email_id"] = email_id
        if use_date is not None:
            self.inputs["use_date"] = use_date
        if query is not None:
            self.inputs["query"] = query
        if from_ is not None:
            self.inputs["from"] = from_
        if to is not None:
            self.inputs["to"] = to
        if has_attachment is not None:
            self.inputs["has_attachment"] = has_attachment
        if has_images is not None:
            self.inputs["has_images"] = has_images
        if has_links is not None:
            self.inputs["has_links"] = has_links
        if has_starred is not None:
            self.inputs["has_starred"] = has_starred
        if has_unread is not None:
            self.inputs["has_unread"] = has_unread
        if label is not None:
            self.inputs["label"] = label
        if in_ is not None:
            self.inputs["in"] = in_
        if is_ is not None:
            self.inputs["is"] = is_
        if has is not None:
            self.inputs["has"] = has
        if filename is not None:
            self.inputs["filename"] = filename
        if newer_than is not None:
            self.inputs["newer_than"] = newer_than
        if older_than is not None:
            self.inputs["older_than"] = older_than
        if list is not None:
            self.inputs["list"] = list
        if category is not None:
            self.inputs["category"] = category
        if larger is not None:
            self.inputs["larger"] = larger
        if smaller is not None:
            self.inputs["smaller"] = smaller
        if custom_params is not None:
            self.inputs["custom_params"] = custom_params
        if projection is not None:
            self.inputs["projection"] = projection
        if page_token is not None:
            self.inputs["page_token"] = page_token
        if label_ids is not None:
            self.inputs["label_ids"] = label_ids
        if has_user_labels is not None:
            self.inputs["has_user_labels"] = has_user_labels
        if include_spam_trash is not None:
            self.inputs["include_spam_trash"] = include_spam_trash
        if msg_id is not None:
            self.inputs["msg_id"] = msg_id
        if num_messages is not None:
            self.inputs["num_messages"] = num_messages
        if use_exact_date is not None:
            self.inputs["use_exact_date"] = use_exact_date
        if date_range is not None:
            self.inputs["date_range"] = date_range
        if exact_date is not None:
            self.inputs["exact_date"] = exact_date
        if draft_id is not None:
            self.inputs["draft_id"] = draft_id
        if detailed_view is not None:
            self.inputs["detailed_view"] = detailed_view
        if draft_message_id is not None:
            self.inputs["draft_message_id"] = draft_message_id
        if thread_id is not None:
            self.inputs["thread_id"] = thread_id
        if has_important is not None:
            self.inputs["has_important"] = has_important
        if has_chat is not None:
            self.inputs["has_chat"] = has_chat
        if read_status is not None:
            self.inputs["read_status"] = read_status
        if received_after is not None:
            self.inputs["received_after"] = received_after
        if received_before is not None:
            self.inputs["received_before"] = received_before
        if name is not None:
            self.inputs["name"] = name
        if label_list_visibility is not None:
            self.inputs["label_list_visibility"] = label_list_visibility
        if message_list_visibility is not None:
            self.inputs["message_list_visibility"] = message_list_visibility
        if label_id is not None:
            self.inputs["label_id"] = label_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if from_ is not None:
            self.inputs["from"] = from_
        if in_ is not None:
            self.inputs["in"] = in_
        if integration is not None:
            self.inputs["integration"] = integration
        if is_ is not None:
            self.inputs["is"] = is_

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGmailNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
