"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("list_deduplicator")
class ListDeduplicatorNode(Node):
    """
    Remove duplicate items from a list. Outputs a list of unique items.

    ## Inputs
    ### Common Inputs
        type: The type of the list
    ### <T>
        list: The list to deduplicate

    ## Outputs
    ### <T>
        unique_items: The list of unique items
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "type",
            "helper_text": "The type of the list",
            "value": "string",
            "type": "string",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "<T>": {
            "inputs": [
                {
                    "field": "list",
                    "label": "List",
                    "type": "vec<<T>>",
                    "value": [],
                    "helper_text": "The list to deduplicate",
                }
            ],
            "outputs": [
                {
                    "field": "unique_items",
                    "label": "Unique Items",
                    "type": "vec<<T>>",
                    "helper_text": "The list of unique items",
                }
            ],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["list"]

    def __init__(
        self,
        type: str = "string",
        list: List[Any] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["type"] = type

        super().__init__(
            node_type="list_deduplicator",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if type is not None:
            self.inputs["type"] = type
        if list is not None:
            self.inputs["list"] = list
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ListDeduplicatorNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
