"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("llm_anthropic_vision")
class LlmAnthropicVisionNode(Node):
    """


    ## Inputs
    ### Common Inputs
        model: The model input
        prompt: The prompt input
        system: The system input
        temperature: The temperature input
        max_tokens: The max_tokens input
        top_p: The top_p input
        image: The image input
        json_response: The json_response input
        use_personal_api_key: The use_personal_api_key input
    ### When use_personal_api_key = True
        api_key: The api_key input
    ### When json_response = True
        json_schema: The json_schema input

    ## Outputs
    ### Common Outputs
        response: The response output
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The model input",
            "value": "claude-3-haiku-20240307",
            "type": "string",
        },
        {
            "field": "prompt",
            "helper_text": "The prompt input",
            "value": "",
            "type": "string",
        },
        {
            "field": "system",
            "helper_text": "The system input",
            "value": "",
            "type": "string",
        },
        {
            "field": "temperature",
            "helper_text": "The temperature input",
            "value": 0.7,
            "type": "float",
        },
        {
            "field": "max_tokens",
            "helper_text": "The max_tokens input",
            "value": 200000,
            "type": "int32",
        },
        {
            "field": "top_p",
            "helper_text": "The top_p input",
            "value": 0.9,
            "type": "float",
        },
        {
            "field": "image",
            "helper_text": "The image input",
            "value": None,
            "type": "image",
        },
        {
            "field": "json_response",
            "helper_text": "The json_response input",
            "value": False,
            "type": "bool",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "The use_personal_api_key input",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "response", "helper_text": "The response output", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "false**(*)": {"inputs": [], "outputs": []},
        "true**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "component": {"type": "password"},
                }
            ],
            "outputs": [],
        },
        "(*)**false": {"inputs": [], "outputs": []},
        "(*)**true": {
            "inputs": [{"field": "json_schema", "type": "string", "value": ""}],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_personal_api_key", "json_response"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["image", "api_key", "json_schema"]

    def __init__(
        self,
        use_personal_api_key: bool = False,
        json_response: bool = False,
        model: str = "claude-3-haiku-20240307",
        prompt: str = "",
        system: str = "",
        api_key: str = "",
        image: Optional[Any] = None,
        json_schema: str = "",
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["use_personal_api_key"] = use_personal_api_key
        params["json_response"] = json_response

        super().__init__(
            node_type="llm_anthropic_vision",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if system is not None:
            self.inputs["system"] = system
        if prompt is not None:
            self.inputs["prompt"] = prompt
        if image is not None:
            self.inputs["image"] = image
        if model is not None:
            self.inputs["model"] = model
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if json_response is not None:
            self.inputs["json_response"] = json_response
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if json_schema is not None:
            self.inputs["json_schema"] = json_schema
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "LlmAnthropicVisionNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
