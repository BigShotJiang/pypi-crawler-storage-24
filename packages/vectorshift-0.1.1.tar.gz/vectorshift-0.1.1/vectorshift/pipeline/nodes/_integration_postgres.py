"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_postgres")
class IntegrationPostgresNode(Node):
    """
    Postgres

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### nl
        query: Natural language query to be converted to SQL
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        sql_generation_model: The sql_generation_model input
    ### raw_sql
        query: Natural language query to be converted to SQL
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        sql_generation_model: The sql_generation_model input
    ### nl_agent
        query: Natural language query to be converted to SQL
        query_agent_model: The query_agent_model input
        query_type: The query_type input
        sql_generation_model: The sql_generation_model input
    ### select
        columns: Choose specific columns
        limit: Maximum number of rows to return
        order_by: Optional ORDER BY clause
        table_name: Choose the table to query
        where_clause: Optional WHERE condition (without WHERE keyword)
    ### delete
        confirm_delete: Confirm that you want to delete the specified records
        delete_entire_table: WARNING: This will drop the entire table
        limit: Maximum number of rows to return
        table_name: Choose the table to query
        where_clause: Optional WHERE condition (without WHERE keyword)
    ### insert_or_update
        conflict_columns: Comma-separated column names that define uniqueness constraint
        data: JSON object with column-value pairs to insert
        table_name: Choose the table to query
    ### insert
        data: JSON object with column-value pairs to insert
        return_id: Return the ID of the inserted record
        table_name: Choose the table to query
    ### update
        data: JSON object with column-value pairs to insert
        limit: Maximum number of rows to return
        table_name: Choose the table to query
        where_clause: Optional WHERE condition (without WHERE keyword)
    ### execute_query
        parameters: Parameters for parameterized queries (optional)
        sql_query: SQL query to execute
    ### describe_table
        table_name: Choose the table to query

    ## Outputs
    ### Common Outputs
        output: Query results in Markdown format
    ### insert
        affected_rows: Number of rows inserted
        inserted_id: ID of the inserted record (if available)
        raw_data: Raw response from database
        sql_query: Generated SQL query
    ### update
        affected_rows: Number of rows updated
        raw_data: Raw response from database
        sql_query: Generated SQL query
    ### delete
        affected_rows: Number of rows deleted
        raw_data: Raw response from database
        sql_query: Generated SQL query
        table_dropped: Whether the entire table was dropped
    ### insert_or_update
        affected_rows: Number of rows affected
        raw_data: Raw response from database
        record_id: ID of the inserted or updated record (if available)
        sql_query: Generated SQL query
    ### execute_query
        columns: Column names in the result set
        execution_time: Query execution time in seconds
        raw_data: Raw JSON response
        results: Query results as JSON
        row_count: Number of rows returned
        sql_query: The executed SQL query
    ### select
        columns: Column names in the result set
        raw_data: Raw JSON response
        results: Selected data as JSON
        row_count: Number of rows returned
        sql_query: Generated SQL query
    ### describe_table
        columns: List of column names
        raw_data: Raw schema data
        row_count: Approximate number of rows in the table
        schema: Detailed table schema information
        table_type: Type of table (BASE TABLE, VIEW, etc.)
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Postgres>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "Query results in Markdown format",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "nl": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "Natural language query to be converted to SQL",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "label": "Query Type",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "SQL Generation Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "Query Agent Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "nl",
            "task_name": "tasks.tables.integrations.postgres.query",
            "description": "Generate and execute a SQL query",
            "label": "Natural Language Query",
        },
        "raw_sql": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "SQL Query to execute",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "label": "Query Type",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "SQL Generation Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "Query Agent Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "raw_sql",
            "task_name": "tasks.tables.integrations.postgres.query",
            "description": "Execute a SQL query",
            "label": "Raw SQL Query",
        },
        "nl_agent": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "select * from dummy_table",
                    "helper_text": "Natural language query for the LLM agent to process",
                },
                {
                    "field": "query_type",
                    "type": "string",
                    "value": "Raw SQL",
                    "label": "Query Type",
                    "hidden": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "sql_generation_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "SQL Generation Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
                {
                    "field": "query_agent_model",
                    "type": "string",
                    "value": "gpt-4-turbo-preview",
                    "label": "Query Agent Model",
                    "hidden": True,
                    "is_hidden_in_agent": True,
                    "agent_field_type": "dynamic",
                    "disable_conversion": False,
                },
            ],
            "outputs": [],
            "name": "nl_agent",
            "task_name": "tasks.tables.integrations.postgres.query",
            "description": "Let an LLM agent query the database",
            "label": "Natural Language Agent",
        },
        "execute_query": {
            "inputs": [
                {
                    "field": "sql_query",
                    "type": "string",
                    "value": "",
                    "label": "SQL Query",
                    "placeholder": "SELECT * FROM users WHERE age > 21",
                    "helper_text": "SQL query to execute",
                },
                {
                    "field": "parameters",
                    "type": "vec<string>",
                    "value": [],
                    "label": "Query Parameters",
                    "helper_text": "Parameters for parameterized queries (optional)",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Query results in Markdown format",
                },
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Query results as JSON",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names in the result set",
                },
                {
                    "field": "execution_time",
                    "type": "float",
                    "helper_text": "Query execution time in seconds",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "The executed SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response",
                },
            ],
            "name": "execute_query",
            "task_name": "tasks.postgres.execute_query",
            "description": "Execute a custom SQL query",
            "label": "Execute Query",
            "variant": "common_integration_nodes",
            "required": ["sql_query"],
            "ui_sort_order": ["integration", "action", "sql_query", "parameters"],
        },
        "select": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "columns",
                    "type": "string",
                    "value": "",
                    "label": "Columns",
                    "placeholder": "Select columns",
                    "helper_text": "Choose specific columns",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=columns&table={inputs.table_name}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "column = 'value'",
                    "helper_text": "Optional WHERE condition (without WHERE keyword)",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "ORDER BY",
                    "placeholder": "column_name ASC",
                    "helper_text": "Optional ORDER BY clause",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "helper_text": "Maximum number of rows to return",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Query results in Markdown format",
                },
                {
                    "field": "results",
                    "type": "string",
                    "helper_text": "Selected data as JSON",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Number of rows returned",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "Column names in the result set",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw JSON response",
                },
            ],
            "name": "select",
            "task_name": "tasks.postgres.select",
            "description": "Select data from a specific table with optional filtering and ordering",
            "label": "Select",
            "variant": "common_integration_nodes",
            "required": ["table_name", "columns", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "columns",
                "where_clause",
                "order_by",
                "limit",
            ],
        },
        "insert": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert into",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"column1": "value1", "column2": "value2"}',
                    "helper_text": "JSON object with column-value pairs to insert",
                },
                {
                    "field": "return_id",
                    "type": "bool",
                    "value": True,
                    "label": "Return ID",
                    "helper_text": "Return the ID of the inserted record",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Success message with details",
                },
                {
                    "field": "inserted_id",
                    "type": "string",
                    "helper_text": "ID of the inserted record (if available)",
                },
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows inserted",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from database",
                },
            ],
            "name": "insert",
            "task_name": "tasks.postgres.insert",
            "description": "Insert new data into a database table",
            "label": "Insert",
            "variant": "common_integration_nodes",
            "required": ["table_name", "data"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "data",
                "return_id",
            ],
        },
        "update": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Update Data",
                    "placeholder": '{"column1": "new_value1", "column2": "new_value2"}',
                    "helper_text": "JSON object with column-value pairs to update",
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "id = 123",
                    "helper_text": "WHERE condition to identify records to update",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 0,
                    "label": "Update Limit",
                    "helper_text": "Maximum number of rows to update (0 for no limit)",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Success message with details",
                },
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows updated",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from database",
                },
            ],
            "name": "update",
            "task_name": "tasks.postgres.update",
            "description": "Update existing data in a database table",
            "label": "Update",
            "variant": "common_integration_nodes",
            "required": ["table_name", "data", "where_clause", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "data",
                "where_clause",
                "limit",
            ],
        },
        "delete": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to delete from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "where_clause",
                    "type": "string",
                    "value": "",
                    "label": "WHERE Condition",
                    "placeholder": "id = 123",
                    "helper_text": "WHERE condition to identify records to delete (leave empty to drop entire table)",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 0,
                    "label": "Delete Limit",
                    "helper_text": "Maximum number of rows to delete (0 for no limit)",
                },
                {
                    "field": "delete_entire_table",
                    "type": "bool",
                    "value": False,
                    "label": "Drop Entire Table",
                    "helper_text": "WARNING: This will drop the entire table",
                },
                {
                    "field": "confirm_delete",
                    "type": "bool",
                    "value": False,
                    "label": "Confirm Delete",
                    "helper_text": "Confirm that you want to delete the specified records",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Success message with details",
                },
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows deleted",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "table_dropped",
                    "type": "bool",
                    "helper_text": "Whether the entire table was dropped",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from database",
                },
            ],
            "name": "delete",
            "task_name": "tasks.postgres.delete",
            "description": "Delete data from a database table or drop the entire table",
            "label": "Delete",
            "variant": "common_integration_nodes",
            "required": ["table_name", "confirm_delete", "limit"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "where_clause",
                "limit",
                "delete_entire_table",
                "confirm_delete",
            ],
        },
        "insert_or_update": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to insert or update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "data",
                    "type": "string",
                    "value": "",
                    "label": "Data",
                    "placeholder": '{"id": 1, "name": "John", "email": "john@example.com"}',
                    "helper_text": "JSON object with column-value pairs to insert or update",
                },
                {
                    "field": "conflict_columns",
                    "type": "string",
                    "value": "id",
                    "label": "Conflict Columns",
                    "placeholder": "id",
                    "helper_text": "Comma-separated column names that define uniqueness constraint",
                },
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Success message with details",
                },
                {
                    "field": "record_id",
                    "type": "string",
                    "helper_text": "ID of the inserted or updated record (if available)",
                },
                {
                    "field": "affected_rows",
                    "type": "int32",
                    "helper_text": "Number of rows affected",
                },
                {
                    "field": "sql_query",
                    "type": "string",
                    "helper_text": "Generated SQL query",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from database",
                },
            ],
            "name": "insert_or_update",
            "task_name": "tasks.postgres.insert_or_update",
            "description": "Insert new data or update existing data using PostgreSQL's ON CONFLICT feature",
            "label": "Insert or Update",
            "variant": "common_integration_nodes",
            "required": ["table_name", "data", "conflict_columns"],
            "ui_sort_order": [
                "integration",
                "action",
                "table_name",
                "data",
                "conflict_columns",
            ],
        },
        "describe_table": {
            "inputs": [
                {
                    "field": "table_name",
                    "type": "string",
                    "value": "",
                    "label": "Table",
                    "placeholder": "Select table",
                    "helper_text": "Choose the table to describe",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/integrations-go/item/{inputs.integration.object_id}?field=table_name&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                }
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "string",
                    "helper_text": "Table schema information in readable format",
                },
                {
                    "field": "columns",
                    "type": "vec<string>",
                    "helper_text": "List of column names",
                },
                {
                    "field": "schema",
                    "type": "string",
                    "helper_text": "Detailed table schema information",
                },
                {
                    "field": "row_count",
                    "type": "int32",
                    "helper_text": "Approximate number of rows in the table",
                },
                {
                    "field": "table_type",
                    "type": "string",
                    "helper_text": "Type of table (BASE TABLE, VIEW, etc.)",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw schema data",
                },
            ],
            "name": "describe_table",
            "task_name": "tasks.postgres.describe_table",
            "description": "Get detailed information about a database table structure",
            "label": "Describe Table",
            "variant": "common_integration_nodes",
            "required": ["table_name"],
            "ui_sort_order": ["integration", "action", "table_name"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        columns: str = "",
        confirm_delete: bool = False,
        conflict_columns: str = "id",
        data: str = "",
        delete_entire_table: bool = False,
        limit: int = 10,
        order_by: str = "",
        parameters: List[str] = [],
        query_agent_model: str = "gpt-4-turbo-preview",
        query_type: str = "Raw SQL",
        return_id: bool = True,
        sql_generation_model: str = "gpt-4-turbo-preview",
        sql_query: str = "",
        table_name: str = "",
        where_clause: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_postgres",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if query is not None:
            self.inputs["query"] = query
        if query_type is not None:
            self.inputs["query_type"] = query_type
        if sql_generation_model is not None:
            self.inputs["sql_generation_model"] = sql_generation_model
        if query_agent_model is not None:
            self.inputs["query_agent_model"] = query_agent_model
        if sql_query is not None:
            self.inputs["sql_query"] = sql_query
        if parameters is not None:
            self.inputs["parameters"] = parameters
        if table_name is not None:
            self.inputs["table_name"] = table_name
        if columns is not None:
            self.inputs["columns"] = columns
        if where_clause is not None:
            self.inputs["where_clause"] = where_clause
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if limit is not None:
            self.inputs["limit"] = limit
        if data is not None:
            self.inputs["data"] = data
        if return_id is not None:
            self.inputs["return_id"] = return_id
        if delete_entire_table is not None:
            self.inputs["delete_entire_table"] = delete_entire_table
        if confirm_delete is not None:
            self.inputs["confirm_delete"] = confirm_delete
        if conflict_columns is not None:
            self.inputs["conflict_columns"] = conflict_columns
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationPostgresNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
