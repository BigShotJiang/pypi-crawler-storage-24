"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_dropbox")
class IntegrationDropboxNode(Node):
    """
    Dropbox

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### delete_file
        delete_file_id: Select file to delete
    ### copy_file
        destination_folder_id: Select the destination folder
        new_file_name: Name for the copied file
        source_file_id: Select the file to copy
    ### move_file
        destination_folder_id: Select the destination folder
        new_file_name: Name for the copied file
        source_file_id: Select the file to copy
    ### copy_folder
        destination_folder_id: Select the destination folder
        new_folder_name: Name for the copied folder
        source_folder_id: Select folder to copy
    ### move_folder
        destination_folder_id: Select the destination folder
        new_folder_name: Name for the copied folder
        source_folder_id: Select folder to copy
    ### add_file
        file: Content of the file to upload
        folder_id: Select the folder where you want to post the file to
    ### download_file_by_path
        file_path: Full path to the file. Personal folders: /folder/file.pdf | Shared folders: ns:namespace_id/file.pdf (copy from search results or folder listings)
    ### search
        file_types: Filter by file types (comma-separated)
        include_shared_folders: Include shared/team folders in search. If disabled, only personal folders will be searched, even if you specify a shared folder ID.
        search_folder_id: Optional: Restrict search to specific folder. Paste folder ID from search results or folder listings (format: id:XXXXX for personal folders, ns:XXXXX for shared folders). Leave blank to search everywhere.
        search_limit: Maximum number of search results
        search_query: Query to search for files and folders
    ### get_files
        folder_id: Select the folder where you want to post the file to
        include_deleted: Include deleted files
        include_subfolders: Include files from subfolders
        limit: Number of files to retrieve
    ### read_folder
        folder_id: Select the folder where you want to post the file to
        include_deleted: Include deleted files
        limit: Number of files to retrieve
        recursive: Whether to list folder contents recursively
    ### delete_folder
        folder_id: Select the folder where you want to post the file to
    ### create_folder
        folder_name: Name of the folder to create
        parent_folder_id: Select parent folder
    ### read_file
        read_file_id: Select file to read

    ## Outputs
    ### delete_file
        deleted_file_id: ID of the deleted file
        raw_data: Raw data of the response
    ### read_file
        file: File object
        file_name: Name of the file
        file_path: Path of the file
        file_size: Size of the file
        mime_type: MIME type of the file
        modified_time: Last modified date of the file
        raw_data: Raw data of the response
    ### download_file_by_path
        file: Downloaded file object
        file_id: ID of the file
        file_name: Name of the file
        file_path: Path of the file
        file_size: Size of the file in bytes
        mime_type: MIME type of the file
        modified_time: Last modified date of the file
        raw_data: Raw data of the response
    ### add_file
        file_id: ID of the uploaded file
        file_name: Name of the uploaded file
        file_path: Path of the uploaded file
        modified_time: Last modified date of the file
        raw_data: Raw data of the response
    ### get_files
        file_ids: List of file IDs
        file_names: List of file names
        file_paths: List of file paths
        file_sizes: List of file sizes
        files: List of files
        has_more: Whether there are more files available
        mime_types: List of file MIME types
        modified_times: List of file modified times
        raw_data: Raw data of the response
        total_count: Total number of files
    ### create_folder
        folder_id: ID of the created folder
        folder_name: Name of the created folder
        folder_path: Path of the created folder
        raw_data: Raw data of the response
    ### delete_folder
        folder_id: ID of the deleted folder
        folder_name: Name of the deleted folder
        folder_path: Path of the deleted folder
        raw_data: Raw data of the response
    ### move_folder
        folder_id: ID of the moved folder
        folder_name: Name of the moved folder
        folder_path: Path of the moved folder
        raw_data: Raw data of the response
    ### read_folder
        has_more: Whether there are more items available
        item_ids: List of item IDs
        item_names: List of item names
        item_paths: List of item paths
        item_sizes: List of item sizes
        item_types: List of item types (file/folder)
        raw_data: Raw response from Dropbox API
        total_count: Total number of items returned
    ### move_file
        moved_file_id: ID of the moved file
        moved_file_name: Name of the moved file
        moved_file_path: Path of the moved file
        raw_data: Raw data of the response
    ### copy_file
        new_file_id: ID of the copied file
        new_file_name: Name of the copied file
        new_file_path: Path of the copied file
        raw_data: Raw data of the response
    ### copy_folder
        new_folder_id: ID of the copied folder
        new_folder_name: Name of the copied folder
        new_folder_path: Path of the copied folder
        raw_data: Raw data of the response
    ### search
        raw_data: Raw data of the response
        result_highlights: List of highlights from search
        result_ids: List of file/folder IDs from search
        result_names: List of file/folder names from search
        result_paths: List of file/folder paths from search
        result_types: List of result types (file/folder)
        total_results: Total number of search results
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Dropbox>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "add_file": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "label": "Folder",
                    "helper_text": "Select the folder where you want to post the file to",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 3,
                },
                {
                    "field": "file",
                    "type": "file",
                    "value": "",
                    "helper_text": "Content of the file to upload",
                    "label": "File",
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "file_id",
                    "type": "string",
                    "helper_text": "ID of the uploaded file",
                },
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the uploaded file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the uploaded file",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "Last modified date of the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "add_file",
            "task_name": "tasks.dropbox.upload_file",
            "description": "Add a file to Dropbox",
            "label": "Add File",
            "ui_sort_order": ["integration", "action", "folder_id", "file"],
        },
        "read_file": {
            "inputs": [
                {
                    "field": "read_file_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select file to read",
                    "label": "File",
                    "placeholder": "file_123",
                    "order": 3,
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {"field": "file", "type": "file", "helper_text": "File object"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "Last modified date of the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "read_file",
            "task_name": "tasks.dropbox.read_file",
            "description": "Read details of a specific file",
            "label": "Get File",
            "inputs_sort_order": ["integration", "action", "read_file_id"],
        },
        "download_file_by_path": {
            "inputs": [
                {
                    "field": "file_path",
                    "type": "string",
                    "value": "",
                    "helper_text": "Full path to the file. Personal folders: /folder/file.pdf | Shared folders: ns:namespace_id/file.pdf (copy from search results or folder listings)",
                    "label": "File Path",
                    "placeholder": "/Documents/report.pdf",
                }
            ],
            "outputs": [
                {
                    "field": "file",
                    "type": "file",
                    "helper_text": "Downloaded file object",
                },
                {"field": "file_id", "type": "string", "helper_text": "ID of the file"},
                {
                    "field": "file_name",
                    "type": "string",
                    "helper_text": "Name of the file",
                },
                {
                    "field": "file_size",
                    "type": "string",
                    "helper_text": "Size of the file in bytes",
                },
                {
                    "field": "file_path",
                    "type": "string",
                    "helper_text": "Path of the file",
                },
                {
                    "field": "mime_type",
                    "type": "string",
                    "helper_text": "MIME type of the file",
                },
                {
                    "field": "modified_time",
                    "type": "timestamp",
                    "helper_text": "Last modified date of the file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "download_file_by_path",
            "task_name": "tasks.dropbox.download_file_by_path",
            "description": "Download a file from Dropbox using its file path",
            "label": "Download File by Path",
            "inputs_sort_order": ["integration", "action", "file_path"],
        },
        "delete_file": {
            "inputs": [
                {
                    "field": "delete_file_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select file to delete",
                    "label": "File",
                    "placeholder": "file_123",
                    "order": 3,
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                }
            ],
            "outputs": [
                {
                    "field": "deleted_file_id",
                    "type": "string",
                    "helper_text": "ID of the deleted file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "delete_file",
            "task_name": "tasks.dropbox.delete_file",
            "description": "Delete a file from Dropbox",
            "label": "Delete File",
            "ui_sort_order": ["integration", "action", "delete_file_id"],
        },
        "copy_file": {
            "inputs": [
                {
                    "field": "source_file_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select the file to copy",
                    "label": "Source File",
                    "placeholder": "file_123",
                    "order": 3,
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select the destination folder",
                    "label": "Destination Folder",
                    "placeholder": "folder_456",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 4,
                },
                {
                    "field": "new_file_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name for the copied file",
                    "label": "New File Name",
                    "placeholder": "copy_of_document.pdf",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "new_file_id",
                    "type": "string",
                    "helper_text": "ID of the copied file",
                },
                {
                    "field": "new_file_name",
                    "type": "string",
                    "helper_text": "Name of the copied file",
                },
                {
                    "field": "new_file_path",
                    "type": "string",
                    "helper_text": "Path of the copied file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "copy_file",
            "task_name": "tasks.dropbox.copy_file",
            "description": "Copy a file in Dropbox",
            "label": "Copy File",
            "ui_sort_order": [
                "integration",
                "action",
                "source_file_id",
                "destination_folder_id",
                "new_file_name",
            ],
        },
        "move_file": {
            "inputs": [
                {
                    "field": "source_file_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Select file to move",
                    "label": "Source File",
                    "placeholder": "file_123",
                    "order": 3,
                    "hidden": True,
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": False,
                        },
                        "multi_select": False,
                        "select_directories": False,
                        "select_file": True,
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select the destination folder",
                    "label": "Destination Folder",
                    "placeholder": "folder_456",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 4,
                },
                {
                    "field": "new_file_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the moved file (optional)",
                    "label": "New File Name",
                    "placeholder": "moved_document.pdf",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "moved_file_id",
                    "type": "string",
                    "helper_text": "ID of the moved file",
                },
                {
                    "field": "moved_file_name",
                    "type": "string",
                    "helper_text": "Name of the moved file",
                },
                {
                    "field": "moved_file_path",
                    "type": "string",
                    "helper_text": "Path of the moved file",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "move_file",
            "task_name": "tasks.dropbox.move_file",
            "description": "Move a file in Dropbox",
            "label": "Move File",
            "ui_sort_order": [
                "integration",
                "action",
                "source_file_id",
                "destination_folder_id",
                "new_file_name",
            ],
        },
        "get_files": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select folder to list files from",
                    "label": "Folder",
                    "placeholder": "folder_123",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 3,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Number of files to retrieve",
                    "label": "Limit",
                    "order": 4,
                },
                {
                    "field": "include_subfolders",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include files from subfolders",
                    "label": "Include Subfolders",
                    "order": 5,
                },
                {
                    "field": "include_deleted",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include deleted files",
                    "label": "Include Deleted",
                    "order": 6,
                },
            ],
            "outputs": [
                {"field": "files", "type": "vec<file>", "helper_text": "List of files"},
                {
                    "field": "file_ids",
                    "type": "vec<string>",
                    "helper_text": "List of file IDs",
                },
                {
                    "field": "file_names",
                    "type": "vec<string>",
                    "helper_text": "List of file names",
                },
                {
                    "field": "file_paths",
                    "type": "vec<string>",
                    "helper_text": "List of file paths",
                },
                {
                    "field": "file_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of file sizes",
                },
                {
                    "field": "modified_times",
                    "type": "vec<timestamp>",
                    "helper_text": "List of file modified times",
                },
                {
                    "field": "mime_types",
                    "type": "vec<string>",
                    "helper_text": "List of file MIME types",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of files",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether there are more files available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "get_files",
            "task_name": "tasks.dropbox.get_files",
            "description": "Get multiple files",
            "label": "List Files",
            "inputs_sort_order": [
                "integration",
                "action",
                "folder_id",
                "limit",
                "include_subfolders",
                "include_deleted",
            ],
        },
        "create_folder": {
            "inputs": [
                {
                    "field": "folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the folder to create",
                    "label": "Folder Name",
                    "placeholder": "New Folder",
                    "order": 3,
                },
                {
                    "field": "parent_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select parent folder",
                    "label": "Parent Folder",
                    "placeholder": "folder_123",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 4,
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the created folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the created folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Path of the created folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "create_folder",
            "task_name": "tasks.dropbox.create_folder",
            "description": "Create a new folder in Dropbox",
            "label": "Create Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "folder_name",
                "parent_folder_id",
            ],
        },
        "read_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select folder to read",
                    "label": "Folder",
                    "placeholder": "folder_123",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 3,
                },
                {
                    "field": "recursive",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to list folder contents recursively",
                    "label": "Recursive",
                    "order": 4,
                },
                {
                    "field": "include_deleted",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Whether to include deleted items",
                    "label": "Include Deleted",
                    "order": 5,
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of items to return",
                    "label": "Limit",
                    "order": 6,
                },
            ],
            "outputs": [
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of item IDs",
                },
                {
                    "field": "item_names",
                    "type": "vec<string>",
                    "helper_text": "List of item names",
                },
                {
                    "field": "item_types",
                    "type": "vec<string>",
                    "helper_text": "List of item types (file/folder)",
                },
                {
                    "field": "item_paths",
                    "type": "vec<string>",
                    "helper_text": "List of item paths",
                },
                {
                    "field": "item_sizes",
                    "type": "vec<string>",
                    "helper_text": "List of item sizes",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of items returned",
                },
                {
                    "field": "has_more",
                    "type": "bool",
                    "helper_text": "Whether there are more items available",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Dropbox API",
                },
            ],
            "name": "read_folder",
            "task_name": "tasks.dropbox.read_folder",
            "description": "Get multiple folder items",
            "label": "List Folder Contents",
            "variant": "common_integration_file_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "folder_id",
                "recursive",
                "include_deleted",
                "limit",
            ],
        },
        "delete_folder": {
            "inputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select folder to delete",
                    "label": "Folder",
                    "placeholder": "folder_123",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 3,
                }
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the deleted folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the deleted folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Path of the deleted folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "name": "delete_folder",
            "task_name": "tasks.dropbox.delete_folder",
            "description": "Delete a folder from Dropbox",
            "label": "Delete Folder",
            "variant": "common_integration_file_nodes",
            "ui_sort_order": ["integration", "action", "folder_id"],
        },
        "copy_folder": {
            "inputs": [
                {
                    "field": "source_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select folder to copy",
                    "label": "Source Folder",
                    "placeholder": "folder_123",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 3,
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select the destination folder",
                    "label": "Destination Folder",
                    "placeholder": "folder_456",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 4,
                },
                {
                    "field": "new_folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name for the copied folder",
                    "label": "New Folder Name",
                    "placeholder": "Copy of Folder",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "new_folder_id",
                    "type": "string",
                    "helper_text": "ID of the copied folder",
                },
                {
                    "field": "new_folder_name",
                    "type": "string",
                    "helper_text": "Name of the copied folder",
                },
                {
                    "field": "new_folder_path",
                    "type": "string",
                    "helper_text": "Path of the copied folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "copy_folder",
            "task_name": "tasks.dropbox.copy_folder",
            "description": "Copy a folder in Dropbox",
            "label": "Copy Folder",
            "inputs_sort_order": [
                "integration",
                "action",
                "source_folder_id",
                "destination_folder_id",
                "new_folder_name",
            ],
        },
        "move_folder": {
            "inputs": [
                {
                    "field": "source_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select folder to move",
                    "label": "Source Folder",
                    "placeholder": "folder_123",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 3,
                },
                {
                    "field": "destination_folder_id",
                    "type": "string",
                    "value": "",
                    "hidden": True,
                    "helper_text": "Select the destination folder",
                    "label": "Destination Folder",
                    "placeholder": "folder_456",
                    "component": {
                        "type": "folder",
                        "dynamic_config": {
                            "metadata_endpoint": "/{prefix}/metadata/children/{inputs.integration.object_id}?parent_id={}&page={}&page_size={dynamic_config.page_size}&directory={dynamic_config.show_only_directories}&q={}",
                            "tree_endpoint": "/{prefix}/metadata/get-tree/{inputs.integration.object_id}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "show_only_directories": True,
                        },
                        "multi_select": False,
                        "select_directories": True,
                        "select_file": False,
                        "agent_field_type": "dynamic",
                    },
                    "order": 4,
                },
                {
                    "field": "new_folder_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the moved folder",
                    "label": "New Folder Name",
                    "placeholder": "Moved Folder",
                    "order": 5,
                },
            ],
            "outputs": [
                {
                    "field": "folder_id",
                    "type": "string",
                    "helper_text": "ID of the moved folder",
                },
                {
                    "field": "folder_name",
                    "type": "string",
                    "helper_text": "Name of the moved folder",
                },
                {
                    "field": "folder_path",
                    "type": "string",
                    "helper_text": "Path of the moved folder",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_file_nodes",
            "name": "move_folder",
            "task_name": "tasks.dropbox.move_folder",
            "description": "Move a folder in Dropbox",
            "label": "Move Folder",
            "ui_sort_order": [
                "integration",
                "action",
                "source_folder_id",
                "destination_folder_id",
                "new_folder_name",
            ],
        },
        "search": {
            "inputs": [
                {
                    "field": "search_query",
                    "type": "string",
                    "value": "",
                    "helper_text": "Query to search for files and folders",
                    "label": "Search Query",
                    "placeholder": "document.pdf",
                    "order": 3,
                },
                {
                    "field": "search_folder_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Optional: Restrict search to specific folder. Paste folder ID from search results or folder listings (format: id:XXXXX for personal folders, ns:XXXXX for shared folders). Leave blank to search everywhere.",
                    "label": "Search Folder",
                    "placeholder": "id:Po7tjA6JO20AAAAAAAAAA or ns:13268171587",
                    "order": 4,
                },
                {
                    "field": "search_limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Maximum number of search results",
                    "label": "Search Limit",
                    "order": 5,
                },
                {
                    "field": "file_types",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by file types (comma-separated)",
                    "label": "File Types",
                    "placeholder": "pdf",
                    "order": 6,
                },
                {
                    "field": "include_shared_folders",
                    "type": "bool",
                    "value": False,
                    "helper_text": "Include shared/team folders in search. If disabled, only personal folders will be searched, even if you specify a shared folder ID.",
                    "label": "Include Shared Folders",
                    "order": 7,
                },
            ],
            "outputs": [
                {
                    "field": "result_ids",
                    "type": "vec<string>",
                    "helper_text": "List of file/folder IDs from search",
                },
                {
                    "field": "result_names",
                    "type": "vec<string>",
                    "helper_text": "List of file/folder names from search",
                },
                {
                    "field": "result_types",
                    "type": "vec<string>",
                    "helper_text": "List of result types (file/folder)",
                },
                {
                    "field": "result_paths",
                    "type": "vec<string>",
                    "helper_text": "List of file/folder paths from search",
                },
                {
                    "field": "result_highlights",
                    "type": "vec<string>",
                    "helper_text": "List of highlights from search",
                },
                {
                    "field": "total_results",
                    "type": "int32",
                    "helper_text": "Total number of search results",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw data of the response",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "search",
            "task_name": "tasks.dropbox.search",
            "description": "Search for files and folders in Dropbox",
            "label": "Search",
            "ui_sort_order": [
                "integration",
                "action",
                "search_query",
                "search_folder_id",
                "search_limit",
                "file_types",
                "include_shared_folders",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "file",
        "folder_id",
        "file_id",
        "source_file_id",
        "destination_folder_id",
        "search_query",
    ]

    def __init__(
        self,
        action: str = "",
        delete_file_id: str = "",
        destination_folder_id: str = "",
        file: str = "",
        file_path: str = "",
        file_types: str = "",
        folder_id: str = "",
        folder_name: str = "",
        include_deleted: bool = False,
        include_shared_folders: bool = False,
        include_subfolders: bool = False,
        limit: int = 10,
        new_file_name: str = "",
        new_folder_name: str = "",
        parent_folder_id: str = "",
        read_file_id: str = "",
        recursive: bool = False,
        search_folder_id: str = "",
        search_limit: int = 10,
        search_query: str = "",
        source_file_id: str = "",
        source_folder_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_dropbox",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if folder_id is not None:
            self.inputs["folder_id"] = folder_id
        if file is not None:
            self.inputs["file"] = file
        if read_file_id is not None:
            self.inputs["read_file_id"] = read_file_id
        if file_path is not None:
            self.inputs["file_path"] = file_path
        if delete_file_id is not None:
            self.inputs["delete_file_id"] = delete_file_id
        if source_file_id is not None:
            self.inputs["source_file_id"] = source_file_id
        if destination_folder_id is not None:
            self.inputs["destination_folder_id"] = destination_folder_id
        if new_file_name is not None:
            self.inputs["new_file_name"] = new_file_name
        if limit is not None:
            self.inputs["limit"] = limit
        if include_subfolders is not None:
            self.inputs["include_subfolders"] = include_subfolders
        if include_deleted is not None:
            self.inputs["include_deleted"] = include_deleted
        if folder_name is not None:
            self.inputs["folder_name"] = folder_name
        if parent_folder_id is not None:
            self.inputs["parent_folder_id"] = parent_folder_id
        if recursive is not None:
            self.inputs["recursive"] = recursive
        if source_folder_id is not None:
            self.inputs["source_folder_id"] = source_folder_id
        if new_folder_name is not None:
            self.inputs["new_folder_name"] = new_folder_name
        if search_query is not None:
            self.inputs["search_query"] = search_query
        if search_folder_id is not None:
            self.inputs["search_folder_id"] = search_folder_id
        if search_limit is not None:
            self.inputs["search_limit"] = search_limit
        if file_types is not None:
            self.inputs["file_types"] = file_types
        if include_shared_folders is not None:
            self.inputs["include_shared_folders"] = include_shared_folders
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationDropboxNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
