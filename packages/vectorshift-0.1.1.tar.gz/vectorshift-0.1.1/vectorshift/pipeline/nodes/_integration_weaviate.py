"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_weaviate")
class IntegrationWeaviateNode(Node):
    """
    Weaviate

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### query_weaviate
        query: Natural Language Query
        collection: Select the Weaviate collection to query
        embedding_model: Select the embedding model to use to embed the query
        properties: Comma-separated list of keywords to use

    ## Outputs
    ### Common Outputs
        output: Output of the Query. Example: “Salmon…”
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Weaviate>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "output",
            "helper_text": "Output of the Query. Example: “Salmon…”",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "query_weaviate": {
            "inputs": [
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Query",
                    "placeholder": "“Fish species in the South Pacific Ocean”",
                    "helper_text": "Natural Language Query",
                },
                {
                    "field": "embedding_model",
                    "type": "string",
                    "value": "",
                    "label": "Embedding Model",
                    "placeholder": "Select Embedding Model",
                    "helper_text": "Select the embedding model to use to embed the query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "options": [
                            {
                                "label": "OpenAI Text Embedding 3 Small",
                                "value": "openai/text-embedding-3-small",
                            },
                            {
                                "label": "OpenAI Text Embedding 3 Large",
                                "value": "openai/text-embedding-3-large",
                            },
                            {
                                "label": "OpenAI Text Embedding Ada 002",
                                "value": "openai/text-embedding-ada-002",
                            },
                            {
                                "label": "Cohere Embed English v3.0",
                                "value": "cohere/embed-english-v3.0",
                            },
                            {
                                "label": "Cohere Embed Multilingual v3.0",
                                "value": "cohere/embed-multilingual-v3.0",
                            },
                            {
                                "label": "Cohere Embed English Light v3.0",
                                "value": "cohere/embed-english-light-v3.0",
                            },
                            {
                                "label": "Cohere Embed Multilingual Light v3.0",
                                "value": "cohere/embed-multilingual-light-v3.0",
                            },
                        ],
                    },
                },
                {
                    "field": "collection",
                    "type": "string",
                    "value": "",
                    "label": "Collection",
                    "placeholder": "Collection",
                    "helper_text": "Select the Weaviate collection to query",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=collection&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": False,
                            "supports_pagination": False,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "properties",
                    "type": "string",
                    "value": "",
                    "label": "Properties",
                    "placeholder": "Properties",
                    "helper_text": "Comma-separated list of keywords to use",
                },
            ],
            "outputs": [],
            "name": "query_weaviate",
            "task_name": "tasks.vectordbs.integrations.weaviate.query",
            "description": "Query Weaviate data",
            "label": "Query Weaviate",
            "variant": "common_integration_nodes",
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        collection: str = "",
        embedding_model: str = "",
        properties: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_weaviate",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if query is not None:
            self.inputs["query"] = query
        if embedding_model is not None:
            self.inputs["embedding_model"] = embedding_model
        if collection is not None:
            self.inputs["collection"] = collection
        if properties is not None:
            self.inputs["properties"] = properties
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationWeaviateNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
