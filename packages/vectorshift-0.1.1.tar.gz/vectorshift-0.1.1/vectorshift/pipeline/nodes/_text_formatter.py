"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("text_formatter")
class TextFormatterNode(Node):
    """
    Format text based off a specified formatter

    ## Inputs
    ### Common Inputs
        text: The text to format
        formatter: The formatter to apply to the text
    ### Truncate
        max_num_token: The maximum number of tokens to truncate the text to

    ## Outputs
    ### Common Outputs
        output: The formatted text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "text",
            "helper_text": "The text to format",
            "value": "",
            "type": "string",
        },
        {
            "field": "formatter",
            "helper_text": "The formatter to apply to the text",
            "value": "To Uppercase",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "output", "helper_text": "The formatted text", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "Truncate": {
            "inputs": [
                {
                    "field": "max_num_token",
                    "label": "Max number of tokens",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "The maximum number of tokens to truncate the text to",
                }
            ],
            "outputs": [],
        }
    }

    # List of parameters that affect configuration
    _PARAMS = ["formatter"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text", "max_num_token"]

    def __init__(
        self,
        formatter: str = "To Uppercase",
        text: str = "",
        max_num_token: int = 0,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["formatter"] = formatter

        super().__init__(
            node_type="text_formatter",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if text is not None:
            self.inputs["text"] = text
        if formatter is not None:
            self.inputs["formatter"] = formatter
        if max_num_token is not None:
            self.inputs["max_num_token"] = max_num_token
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TextFormatterNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
