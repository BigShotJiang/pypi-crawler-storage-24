"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("exa_ai")
class ExaAiNode(Node):
    """
    Query the Exa search API

    ## Inputs
    ### Common Inputs
        query: The search query
        end_crawl_date: Only return results crawled before this date (ISO 8601)
        end_published_date: Only return results published before this date (ISO 8601, e.g. 2024-12-31T00:00:00.000Z)
        livecrawl: Enable live crawling to fetch fresh content. When on, always fetches live content. When off, uses cached content.
        loader_type: Select the search category
        max_characters: Maximum characters per result for text or highlights content
        num_results: Number of results to return (1-100)
        search_type: Search method: auto (default) intelligently combines methods, neural uses embeddings, fast is streamlined, instant is lowest latency, deep/deep-reasoning/deep-max offer increasing search depth
        start_crawl_date: Only return results crawled after this date (ISO 8601)
        start_published_date: Only return results published after this date (ISO 8601, e.g. 2024-01-01T00:00:00.000Z)
        use_highlights: Return LLM-selected highlights instead of full text. Uses ~10x fewer tokens with better relevance.

    ## Outputs
    ### Common Outputs
        formatted_text: Exa AI search results formatted for LLM consumption
        output: The search results from Exa AI
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "query",
            "helper_text": "The search query",
            "value": "",
            "type": "string",
        },
        {
            "field": "end_crawl_date",
            "helper_text": "Only return results crawled before this date (ISO 8601)",
            "value": "",
            "type": "string",
        },
        {
            "field": "end_published_date",
            "helper_text": "Only return results published before this date (ISO 8601, e.g. 2024-12-31T00:00:00.000Z)",
            "value": "",
            "type": "string",
        },
        {
            "field": "livecrawl",
            "helper_text": "Enable live crawling to fetch fresh content. When on, always fetches live content. When off, uses cached content.",
            "value": True,
            "type": "bool",
        },
        {
            "field": "loader_type",
            "helper_text": "Select the search category",
            "value": "EXA_AI_SEARCH",
            "type": "string",
        },
        {
            "field": "max_characters",
            "helper_text": "Maximum characters per result for text or highlights content",
            "value": 2000,
            "type": "int32",
        },
        {
            "field": "num_results",
            "helper_text": "Number of results to return (1-100)",
            "value": 10,
            "type": "int32",
        },
        {
            "field": "search_type",
            "helper_text": "Search method: auto (default) intelligently combines methods, neural uses embeddings, fast is streamlined, instant is lowest latency, deep/deep-reasoning/deep-max offer increasing search depth",
            "value": "auto",
            "type": "string",
        },
        {
            "field": "start_crawl_date",
            "helper_text": "Only return results crawled after this date (ISO 8601)",
            "value": "",
            "type": "string",
        },
        {
            "field": "start_published_date",
            "helper_text": "Only return results published after this date (ISO 8601, e.g. 2024-01-01T00:00:00.000Z)",
            "value": "",
            "type": "string",
        },
        {
            "field": "use_highlights",
            "helper_text": "Return LLM-selected highlights instead of full text. Uses ~10x fewer tokens with better relevance.",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "formatted_text",
            "helper_text": "Exa AI search results formatted for LLM consumption",
            "type": "string",
        },
        {
            "field": "output",
            "helper_text": "The search results from Exa AI",
            "type": "vec<string>",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "EXA_AI_SEARCH": {"inputs": [], "outputs": [], "title": "Exa AI Web Search"},
        "EXA_AI_SEARCH_COMPANIES": {
            "inputs": [],
            "outputs": [],
            "title": "Exa AI Companies",
        },
        "EXA_AI_SEARCH_RESEARCH_PAPERS": {
            "inputs": [],
            "outputs": [],
            "title": "Exa AI Research Papers",
        },
        "EXA_AI_SEARCH_NEWS": {"inputs": [], "outputs": [], "title": "Exa AI News"},
        "EXA_AI_SEARCH_TWEETS": {"inputs": [], "outputs": [], "title": "Exa AI Tweets"},
        "EXA_AI_SEARCH_FINANCIAL_REPORTS": {
            "inputs": [],
            "outputs": [],
            "title": "Exa AI Financial Reports",
        },
        "EXA_AI_SEARCH_PERSONAL_SITES": {
            "inputs": [],
            "outputs": [],
            "title": "Exa AI Personal Sites",
        },
        "EXA_AI_SEARCH_PEOPLE": {"inputs": [], "outputs": [], "title": "Exa AI People"},
    }

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["query"]

    def __init__(
        self,
        query: str = "",
        end_crawl_date: str = "",
        end_published_date: str = "",
        livecrawl: bool = True,
        loader_type: str = "EXA_AI_SEARCH",
        max_characters: int = 2000,
        num_results: int = 10,
        search_type: str = "auto",
        start_crawl_date: str = "",
        start_published_date: str = "",
        use_highlights: bool = False,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="exa_ai",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if query is not None:
            self.inputs["query"] = query
        if loader_type is not None:
            self.inputs["loader_type"] = loader_type
        if search_type is not None:
            self.inputs["search_type"] = search_type
        if num_results is not None:
            self.inputs["num_results"] = num_results
        if start_published_date is not None:
            self.inputs["start_published_date"] = start_published_date
        if end_published_date is not None:
            self.inputs["end_published_date"] = end_published_date
        if start_crawl_date is not None:
            self.inputs["start_crawl_date"] = start_crawl_date
        if end_crawl_date is not None:
            self.inputs["end_crawl_date"] = end_crawl_date
        if use_highlights is not None:
            self.inputs["use_highlights"] = use_highlights
        if max_characters is not None:
            self.inputs["max_characters"] = max_characters
        if livecrawl is not None:
            self.inputs["livecrawl"] = livecrawl
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ExaAiNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
