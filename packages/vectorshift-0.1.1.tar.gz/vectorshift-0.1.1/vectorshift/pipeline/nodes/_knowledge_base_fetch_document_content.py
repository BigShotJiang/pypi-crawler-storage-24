"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("knowledge_base_fetch_document_content")
class KnowledgeBaseFetchDocumentContentNode(Node):
    """
    Fetch the full content of a specific document from a knowledge base by scrolling through all its chunks

    ## Inputs
    ### Common Inputs
        item_id: item id of the item to fetch content from
        knowledge_base: Select an existing knowledge base
        max_chunks: Maximum number of chunks to include in the content

    ## Outputs
    ### Common Outputs
        document_content: Full document content as formatted text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "item_id",
            "helper_text": "item id of the item to fetch content from",
            "value": "",
            "type": "string",
        },
        {
            "field": "knowledge_base",
            "helper_text": "Select an existing knowledge base",
            "value": {"object_type": 1, "object_id": ""},
            "type": "knowledge_base",
        },
        {
            "field": "max_chunks",
            "helper_text": "Maximum number of chunks to include in the content",
            "value": 200,
            "type": "int32",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "document_content",
            "helper_text": "Full document content as formatted text",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["knowledge_base", "item_id"]

    def __init__(
        self,
        item_id: str = "",
        knowledge_base: "KnowledgeBase" = "",
        max_chunks: int = 200,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="knowledge_base_fetch_document_content",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if knowledge_base is not None:
            self.inputs["knowledge_base"] = knowledge_base
        if item_id is not None:
            self.inputs["item_id"] = item_id
        if max_chunks is not None:
            self.inputs["max_chunks"] = max_chunks
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "KnowledgeBaseFetchDocumentContentNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
