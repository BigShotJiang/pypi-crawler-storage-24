"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("get_run_data")
class GetRunDataNode(Node):
    """
    Fetch run metrics (trace, latency, cost, tokens, status) for a session

    ## Inputs
    ### Common Inputs
        session_id: The session ID (execution_id) to fetch run metrics for

    ## Outputs
    ### Common Outputs
        avg_api_latency: Average API latency across LLM spans in seconds
        avg_cache_hit_rate: Average cache hit rate across LLM spans (0.0 to 1.0)
        end_time: Latest span end time
        start_time: Earliest span start time
        status: Aggregated status of the run (success, failure, in_progress, not_found)
        status_message: Last status message from the run, if any
        tokens: Total tokens across spans
        total_ai_cost: Total AI credits/cost across spans
        total_cache_savings: Total cache savings across LLM spans
        total_cached_tokens: Total cached tokens across LLM spans
        total_latency: Total latency as difference between earliest start time and latest end time in nanoseconds
        trace_id: Trace ID associated with this session run
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "session_id",
            "helper_text": "The session ID (execution_id) to fetch run metrics for",
            "value": "",
            "type": "string",
        }
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "avg_api_latency",
            "helper_text": "Average API latency across LLM spans in seconds",
            "type": "float",
        },
        {
            "field": "avg_cache_hit_rate",
            "helper_text": "Average cache hit rate across LLM spans (0.0 to 1.0)",
            "type": "float",
        },
        {"field": "end_time", "helper_text": "Latest span end time", "type": "string"},
        {
            "field": "start_time",
            "helper_text": "Earliest span start time",
            "type": "string",
        },
        {
            "field": "status",
            "helper_text": "Aggregated status of the run (success, failure, in_progress, not_found)",
            "type": "string",
        },
        {
            "field": "status_message",
            "helper_text": "Last status message from the run, if any",
            "type": "string",
        },
        {
            "field": "tokens",
            "helper_text": "Total tokens across spans",
            "type": "int64",
        },
        {
            "field": "total_ai_cost",
            "helper_text": "Total AI credits/cost across spans",
            "type": "float",
        },
        {
            "field": "total_cache_savings",
            "helper_text": "Total cache savings across LLM spans",
            "type": "float",
        },
        {
            "field": "total_cached_tokens",
            "helper_text": "Total cached tokens across LLM spans",
            "type": "int64",
        },
        {
            "field": "total_latency",
            "helper_text": "Total latency as difference between earliest start time and latest end time in nanoseconds",
            "type": "int64",
        },
        {
            "field": "trace_id",
            "helper_text": "Trace ID associated with this session run",
            "type": "string",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["session_id"]

    def __init__(
        self,
        session_id: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="get_run_data",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if session_id is not None:
            self.inputs["session_id"] = session_id
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "GetRunDataNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
