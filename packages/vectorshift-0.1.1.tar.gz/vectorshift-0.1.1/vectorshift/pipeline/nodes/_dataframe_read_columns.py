"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("dataframe_read_columns")
class DataframeReadColumnsNode(Node):
    """
    Read columns from a dataframe.

    ## Inputs
    ### Common Inputs
        column_name: The name of the column to read
        column_type: The expected type of the column values
        dataframe: The dataframe input
        dataframe_type: The type of dataframe to be used

    ## Outputs
    ### Common Outputs
        column_values: The values of the selected column as a list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "column_name",
            "helper_text": "The name of the column to read",
            "value": "",
            "type": "string",
        },
        {
            "field": "column_type",
            "helper_text": "The expected type of the column values",
            "value": "any",
            "type": "string",
        },
        {
            "field": "dataframe",
            "helper_text": "The dataframe input",
            "value": {"object_info": {"object_id": "", "object_type": 3}},
            "type": "dataframe",
        },
        {
            "field": "dataframe_type",
            "helper_text": "The type of dataframe to be used",
            "value": "table",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "column_values",
            "helper_text": "The values of the selected column as a list",
            "type": "vec<any>",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "<A>**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "column_values",
                    "type": "vec<<A>>",
                    "helper_text": "The values of the selected column as a list",
                }
            ],
        },
        "(*)**table": {
            "inputs": [
                {
                    "field": "dataframe",
                    "type": "dataframe",
                    "value": {"object_info": {"object_id": "", "object_type": 3}},
                    "label": "Select Dataframe",
                    "component": {
                        "type": "dataframe",
                        "source": "dataframe_options",
                        "source_key": "dataframe_type",
                        "source_sub_key": "component.options",
                        "access_value_sub_key": "objectInfo",
                    },
                },
                {
                    "field": "column_name",
                    "type": "string",
                    "value": "",
                    "label": "Column Name",
                    "helper_text": "The name of the column to read",
                    "agent_field_type": "dynamic",
                    "component": {
                        "type": "dropdown",
                        "source": "table_columns",
                        "source_key": "dataframe",
                    },
                    "visibility": {
                        "logic": "OR",
                        "conditions": [
                            {
                                "field": "dataframe.value.objectInfo",
                                "operator": "exists",
                                "sub_field_key": "object_id",
                            },
                            {"field": "dataframe", "operator": "is_string"},
                            {
                                "field": "dataframe.value",
                                "sub_field_key": "objectInfo",
                                "operator": "is_string",
                            },
                            {
                                "field": "{{dataframe_type}}",
                                "operator": "!=",
                                "value": "table",
                            },
                        ],
                    },
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["column_type", "dataframe_type"]

    _batch_mode_allowed = False

    _REQUIRED_FIELDS = ["dataframe_type", "dataframe", "column_name", "column_type"]

    def __init__(
        self,
        column_type: str = "any",
        dataframe_type: str = "table",
        column_name: str = "",
        dataframe: Any = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["column_type"] = column_type
        params["dataframe_type"] = dataframe_type

        super().__init__(
            node_type="dataframe_read_columns",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if dataframe_type is not None:
            self.inputs["dataframe_type"] = dataframe_type
        if dataframe is not None:
            self.inputs["dataframe"] = dataframe
        if column_name is not None:
            self.inputs["column_name"] = column_name
        if column_type is not None:
            self.inputs["column_type"] = column_type
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "DataframeReadColumnsNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
