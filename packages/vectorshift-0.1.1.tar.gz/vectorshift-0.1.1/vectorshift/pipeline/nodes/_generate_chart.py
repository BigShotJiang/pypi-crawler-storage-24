"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("generate_chart")
class GenerateChartNode(Node):
    """
    Use this to generate a chart from. Convert a tabular file, dataframe or table to a chart or graph visualization. Supports bar, line, pie, scatter, and donut charts/graphs.

    ## Inputs
    ### Common Inputs
        chart_description: A brief description or subtitle explaining what the chart shows
        chart_type: The type of chart to generate (bar, line, pie, scatter, donut)
        dataframe: The dataframe to visualize as a chart. In case of csv, the input should be a properly formatted valid csv string with appropriate headers.
        dataframe_column_names: Actual column names from the dataframe. It should be a string representing the comma separated list of column names.
        dataframe_type: The type of dataframe to be used. Only available options are table, csv, md, json, file.
        title: The title to display on the chart
        x_axis_field: The column name to use for the X-axis (categories). Must EXACTLY match (case-sensitive) one of the column names from the CSV header.
        y_axis_fields: Column name(s) for Y-axis values. Must EXACTLY match (case-sensitive) column name(s) from the CSV header. For multi-series charts (multiple lines/bars), use comma-separated names like 'revenue,profit,cost'.
    ### bar
        aggregation: How to aggregate values when there are multiple data points per category
        legend_orientation: Where to display the chart legend
        sort_order: The order to sort the data
        x_axis_label: The label to display on the X-axis. Defaults to the field name if not provided.
        y_axis_label: The label to display on the Y-axis
    ### line
        aggregation: How to aggregate values when there are multiple data points per category
        legend_orientation: Where to display the chart legend
        sort_order: The order to sort the data
        x_axis_label: The label to display on the X-axis. Defaults to the field name if not provided.
        y_axis_label: The label to display on the Y-axis
    ### pie
        legend_orientation: Where to display the chart legend
    ### donut
        legend_orientation: Where to display the chart legend
    ### scatter
        legend_orientation: Where to display the chart legend
        x_axis_label: The label to display on the X-axis. Defaults to the field name if not provided.
        y_axis_label: The label to display on the Y-axis

    ## Outputs
    ### Common Outputs
        chart: The generated chart visualization
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "chart_description",
            "helper_text": "A brief description or subtitle explaining what the chart shows",
            "value": "",
            "type": "string",
        },
        {
            "field": "chart_type",
            "helper_text": "The type of chart to generate (bar, line, pie, scatter, donut)",
            "value": "bar",
            "type": "enum<string>",
        },
        {
            "field": "dataframe",
            "helper_text": "The dataframe to visualize as a chart. In case of csv, the input should be a properly formatted valid csv string with appropriate headers.",
            "value": {"object_info": {"object_id": "", "object_type": 3}},
            "type": "dataframe",
        },
        {
            "field": "dataframe_column_names",
            "helper_text": "Actual column names from the dataframe. It should be a string representing the comma separated list of column names.",
            "value": "",
            "type": "string",
        },
        {
            "field": "dataframe_type",
            "helper_text": "The type of dataframe to be used. Only available options are table, csv, md, json, file.",
            "value": "table",
            "type": "enum<string>",
        },
        {
            "field": "title",
            "helper_text": "The title to display on the chart",
            "value": "Chart",
            "type": "string",
        },
        {
            "field": "x_axis_field",
            "helper_text": "The column name to use for the X-axis (categories). Must EXACTLY match (case-sensitive) one of the column names from the CSV header.",
            "value": "",
            "type": "string",
        },
        {
            "field": "y_axis_fields",
            "helper_text": "Column name(s) for Y-axis values. Must EXACTLY match (case-sensitive) column name(s) from the CSV header. For multi-series charts (multiple lines/bars), use comma-separated names like 'revenue,profit,cost'.",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "chart",
            "helper_text": "The generated chart visualization",
            "type": "chart",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "bar": {
            "inputs": [
                {
                    "field": "x_axis_label",
                    "type": "string",
                    "value": "",
                    "label": "X-Axis Label",
                    "helper_text": "The label to display on the X-axis. Defaults to the field name if not provided.",
                },
                {
                    "field": "y_axis_label",
                    "type": "string",
                    "value": "",
                    "label": "Y-Axis Label",
                    "helper_text": "The label to display on the Y-axis",
                },
                {
                    "field": "aggregation",
                    "type": "enum<string>",
                    "value": "sum",
                    "label": "Aggregation",
                    "helper_text": "How to aggregate values when there are multiple data points per category",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sum", "value": "sum"},
                            {"label": "Average", "value": "average"},
                            {"label": "Count", "value": "count"},
                            {"label": "Min", "value": "min"},
                            {"label": "Max", "value": "max"},
                        ],
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "ascending",
                    "label": "Sort Order",
                    "helper_text": "The order to sort the data",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Ascending", "value": "ascending"},
                            {"label": "Descending", "value": "descending"},
                        ],
                    },
                },
                {
                    "field": "legend_orientation",
                    "type": "enum<string>",
                    "value": "right",
                    "label": "Legend Position",
                    "helper_text": "Where to display the chart legend",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Right", "value": "right"},
                            {"label": "Left", "value": "left"},
                            {"label": "Top", "value": "top"},
                            {"label": "Bottom", "value": "bottom"},
                            {"label": "Hidden", "value": "hidden"},
                        ],
                    },
                },
            ],
            "outputs": [],
        },
        "line": {
            "inputs": [
                {
                    "field": "x_axis_label",
                    "type": "string",
                    "value": "",
                    "label": "X-Axis Label",
                    "helper_text": "The label to display on the X-axis. Defaults to the field name if not provided.",
                },
                {
                    "field": "y_axis_label",
                    "type": "string",
                    "value": "",
                    "label": "Y-Axis Label",
                    "helper_text": "The label to display on the Y-axis",
                },
                {
                    "field": "aggregation",
                    "type": "enum<string>",
                    "value": "sum",
                    "label": "Aggregation",
                    "helper_text": "How to aggregate values when there are multiple data points per category",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Sum", "value": "sum"},
                            {"label": "Average", "value": "average"},
                            {"label": "Count", "value": "count"},
                            {"label": "Min", "value": "min"},
                            {"label": "Max", "value": "max"},
                        ],
                    },
                },
                {
                    "field": "sort_order",
                    "type": "enum<string>",
                    "value": "ascending",
                    "label": "Sort Order",
                    "helper_text": "The order to sort the data",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Ascending", "value": "ascending"},
                            {"label": "Descending", "value": "descending"},
                        ],
                    },
                },
                {
                    "field": "legend_orientation",
                    "type": "enum<string>",
                    "value": "right",
                    "label": "Legend Position",
                    "helper_text": "Where to display the chart legend",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Right", "value": "right"},
                            {"label": "Left", "value": "left"},
                            {"label": "Top", "value": "top"},
                            {"label": "Bottom", "value": "bottom"},
                            {"label": "Hidden", "value": "hidden"},
                        ],
                    },
                },
            ],
            "outputs": [],
        },
        "pie": {
            "inputs": [
                {
                    "field": "legend_orientation",
                    "type": "enum<string>",
                    "value": "right",
                    "label": "Legend Position",
                    "helper_text": "Where to display the chart legend",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Right", "value": "right"},
                            {"label": "Left", "value": "left"},
                            {"label": "Top", "value": "top"},
                            {"label": "Bottom", "value": "bottom"},
                            {"label": "Hidden", "value": "hidden"},
                        ],
                    },
                }
            ],
            "outputs": [],
        },
        "donut": {
            "inputs": [
                {
                    "field": "legend_orientation",
                    "type": "enum<string>",
                    "value": "right",
                    "label": "Legend Position",
                    "helper_text": "Where to display the chart legend",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Right", "value": "right"},
                            {"label": "Left", "value": "left"},
                            {"label": "Top", "value": "top"},
                            {"label": "Bottom", "value": "bottom"},
                            {"label": "Hidden", "value": "hidden"},
                        ],
                    },
                }
            ],
            "outputs": [],
        },
        "scatter": {
            "inputs": [
                {
                    "field": "x_axis_label",
                    "type": "string",
                    "value": "",
                    "label": "X-Axis Label",
                    "helper_text": "The label to display on the X-axis. Defaults to the field name if not provided.",
                },
                {
                    "field": "y_axis_label",
                    "type": "string",
                    "value": "",
                    "label": "Y-Axis Label",
                    "helper_text": "The label to display on the Y-axis",
                },
                {
                    "field": "legend_orientation",
                    "type": "enum<string>",
                    "value": "right",
                    "label": "Legend Position",
                    "helper_text": "Where to display the chart legend",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Right", "value": "right"},
                            {"label": "Left", "value": "left"},
                            {"label": "Top", "value": "top"},
                            {"label": "Bottom", "value": "bottom"},
                            {"label": "Hidden", "value": "hidden"},
                        ],
                    },
                },
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["chart_type"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "dataframe_type",
        "dataframe",
        "chart_type",
        "title",
        "x_axis_field",
        "y_axis_fields",
        "dataframe_column_names",
    ]

    def __init__(
        self,
        chart_type: str = "bar",
        aggregation: str = "sum",
        chart_description: str = "",
        dataframe: Any = "",
        dataframe_column_names: str = "",
        dataframe_type: str = "table",
        legend_orientation: str = "right",
        sort_order: str = "ascending",
        title: str = "Chart",
        x_axis_field: str = "",
        x_axis_label: str = "",
        y_axis_fields: str = "",
        y_axis_label: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["chart_type"] = chart_type

        super().__init__(
            node_type="generate_chart",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if dataframe_column_names is not None:
            self.inputs["dataframe_column_names"] = dataframe_column_names
        if dataframe_type is not None:
            self.inputs["dataframe_type"] = dataframe_type
        if dataframe is not None:
            self.inputs["dataframe"] = dataframe
        if chart_type is not None:
            self.inputs["chart_type"] = chart_type
        if title is not None:
            self.inputs["title"] = title
        if chart_description is not None:
            self.inputs["chart_description"] = chart_description
        if x_axis_field is not None:
            self.inputs["x_axis_field"] = x_axis_field
        if y_axis_fields is not None:
            self.inputs["y_axis_fields"] = y_axis_fields
        if x_axis_label is not None:
            self.inputs["x_axis_label"] = x_axis_label
        if y_axis_label is not None:
            self.inputs["y_axis_label"] = y_axis_label
        if aggregation is not None:
            self.inputs["aggregation"] = aggregation
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if legend_orientation is not None:
            self.inputs["legend_orientation"] = legend_orientation
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "GenerateChartNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
