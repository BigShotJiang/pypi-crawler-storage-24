"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import ColumnEntry


@Node.register_node_type("extract_to_table")
class ExtractToTableNode(Node):
    """
    Extract data to a CSV using AI

    ## Inputs
    ### Common Inputs
        model: The specific model for extracting the table
        add_columns_manually: Add data points for some columns manually instead of having them extracted by the AI model.
        additional_context: Provide any additional context that may help the AI model extract the data.
        extract_multiple_rows: Choose the mode of extraction. If checked, it will extract multiple rows of data. If unchecked, it will extract a single row.
        file: Your file should contain headers in the first row.
        manual_columns: Pass in data to column names manually.
        provider: The model provider
        text_for_extraction: Text to extract table from

    ## Outputs
    ### Common Outputs
        table: The table extracted from the text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for extracting the table",
            "value": "gpt-4o",
            "type": "string",
        },
        {
            "field": "add_columns_manually",
            "helper_text": "Add data points for some columns manually instead of having them extracted by the AI model.",
            "value": False,
            "type": "bool",
        },
        {
            "field": "additional_context",
            "helper_text": "Provide any additional context that may help the AI model extract the data.",
            "value": "",
            "type": "string",
        },
        {
            "field": "extract_multiple_rows",
            "helper_text": "Choose the mode of extraction. If checked, it will extract multiple rows of data. If unchecked, it will extract a single row.",
            "value": True,
            "type": "bool",
        },
        {
            "field": "file",
            "helper_text": "Your file should contain headers in the first row.",
            "value": "",
            "type": "file",
        },
        {
            "field": "manual_columns",
            "helper_text": "Pass in data to column names manually.",
            "value": [],
            "type": "vec<interface{id: string, column_name: string, column_value: string}>",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "text_for_extraction",
            "helper_text": "Text to extract table from",
            "value": "",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "table",
            "helper_text": "The table extracted from the text",
            "type": "file",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text_for_extraction", "file"]

    def __init__(
        self,
        model: str = "gpt-4o",
        add_columns_manually: bool = False,
        additional_context: str = "",
        extract_multiple_rows: bool = True,
        file: str = "",
        manual_columns: List[ColumnEntry] = [],
        provider: str = "openai",
        text_for_extraction: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="extract_to_table",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if text_for_extraction is not None:
            self.inputs["text_for_extraction"] = text_for_extraction
        if extract_multiple_rows is not None:
            self.inputs["extract_multiple_rows"] = extract_multiple_rows
        if add_columns_manually is not None:
            self.inputs["add_columns_manually"] = add_columns_manually
        if manual_columns is not None:
            self.inputs["manual_columns"] = manual_columns
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if additional_context is not None:
            self.inputs["additional_context"] = additional_context
        if file is not None:
            self.inputs["file"] = file
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ExtractToTableNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
