"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_stripe")
class IntegrationStripeNode(Node):
    """
    Stripe

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### add_customer_card
        card_customer_id: ID of the customer to add card to
        card_token: Token representing the card information
    ### create_charge
        charge_amount: Amount to charge in cents
        charge_currency: Three-letter currency code
        charge_description: Description of the charge
        charge_source: Payment source ID or token
        customer_id: ID of the customer to retrieve
    ### read_charge
        charge_id: ID of the charge to retrieve
    ### update_charge
        charge_id: ID of the charge to retrieve
        update_charge_description: New description for the charge
    ### create_coupon
        coupon_amount_off: Fixed amount off in cents
        coupon_currency: Currency for amount_off coupons
        coupon_duration: Duration of the coupon
        coupon_duration_in_months: Duration in months for repeating coupons
        coupon_max_redemptions: Maximum number of redemptions
        coupon_name: Name of the coupon
        coupon_percent_off: Percentage off
    ### create_customer
        customer_description: Description of the customer
        customer_email: Email address of the customer
        customer_name: Full name of the customer
        customer_phone: Phone number of the customer
    ### get_customers
        customer_email: Email address of the customer
        limit: Number of customers to retrieve
    ### read_customer
        customer_id: ID of the customer to retrieve
    ### update_customer
        customer_id: ID of the customer to retrieve
        update_customer_description: New description for the customer
        update_customer_email: New email for the customer
        update_customer_name: New name for the customer
        update_customer_phone: New phone for the customer
    ### delete_customer
        customer_id: ID of the customer to retrieve
    ### get_charges
        customer_id: ID of the customer to retrieve
        limit: Number of customers to retrieve
    ### delete_source
        delete_source_customer_id: ID of the customer whose source to delete
        delete_source_id: ID of the source to delete
    ### get_coupons
        limit: Number of customers to retrieve
    ### read_customer_card
        read_card_customer_id: ID of the customer whose card to retrieve
        read_card_source_id: ID of the card/source to retrieve
    ### read_source
        read_source_id: ID of the source to retrieve
    ### remove_customer_card
        remove_card_customer_id: ID of the customer whose card to remove
        remove_card_id: ID of the card to remove
    ### create_source
        source_amount: Amount in cents for this source
        source_currency: Three-letter currency code
        source_customer_id: ID of the customer to attach the source to
        source_statement_descriptor: Text to display on customer's statement
        source_type: Type of source to create
    ### create_token
        token_card_number: Card number
        token_cvc: Card security code
        token_exp_month: Expiration month
        token_exp_year: Expiration year

    ## Outputs
    ### get_balance
        available: Available balance amounts by currency
        livemode: Whether this is live or test mode
        object: Object type identifier
        pending: Pending balance amounts by currency
        raw_data: Raw response from Stripe API
    ### add_customer_card
        brand: Card brand (e.g., Visa, MasterCard)
        card_id: Unique ID of the added card
        customer_id: Customer ID the card is attached to
        exp_month: Card expiration month
        exp_year: Card expiration year
        fingerprint: Unique fingerprint for the card
        last4: Last 4 digits of the card
        raw_data: Raw response from Stripe API
    ### read_customer_card
        brand: Card brand (e.g., Visa, MasterCard)
        card_id: Unique ID of the card
        customer_id: Customer ID the card is attached to
        exp_month: Card expiration month
        exp_year: Card expiration year
        fingerprint: Unique fingerprint for the card
        last4: Last 4 digits of the card
        raw_data: Raw response from Stripe API
    ### create_token
        card_brand: Brand of the card
        card_exp_month: Card expiration month
        card_exp_year: Card expiration year
        card_fingerprint: Unique fingerprint for the card
        card_last4: Last 4 digits of the card
        created_at: Creation timestamp in RFC3339 format
        raw_data: Raw response from Stripe API
        token_id: Unique ID of the created token
        token_type: Type of the token
    ### remove_customer_card
        card_id: ID of the removed card
        deleted: Whether the card was successfully deleted
        message: Success message
        raw_data: Raw response from Stripe API
    ### create_charge
        charge_amount: Amount charged in cents
        charge_currency: Currency of the charge
        charge_customer: Customer ID associated with charge
        charge_description: Charge description
        charge_id: Unique ID of the created charge
        charge_paid: Whether the charge was paid
        charge_status: Status of the charge
        created_at: Creation timestamp in RFC3339 format
        raw_data: Raw response from Stripe API
    ### read_charge
        charge_amount: Amount charged in cents
        charge_currency: Currency of the charge
        charge_customer: Customer ID associated with charge
        charge_description: Charge description
        charge_id: Unique ID of the charge
        charge_paid: Whether the charge was paid
        charge_status: Status of the charge
        created_at: Creation timestamp in RFC3339 format
        raw_data: Raw response from Stripe API
    ### update_charge
        charge_amount: Amount charged in cents
        charge_currency: Currency of the charge
        charge_customer: Customer ID associated with charge
        charge_description: Charge description
        charge_id: Unique ID of the charge
        charge_paid: Whether the charge was paid
        charge_status: Status of the charge
        message: Success message
        raw_data: Raw response from Stripe API
    ### get_charges
        charge_amounts: List of charge amounts
        charge_currencies: List of charge currencies
        charge_customers: List of associated customer IDs
        charge_descriptions: List of charge descriptions
        charge_ids: List of charge IDs
        charge_paids: List of paid status booleans
        charge_statuses: List of charge statuses
        created_ats: List of creation timestamps
        raw_data: Raw response from Stripe API
    ### create_coupon
        coupon_amount_off: Fixed amount off in cents
        coupon_currency: Currency of the coupon
        coupon_duration: Duration of the coupon
        coupon_duration_in_months: Duration in months
        coupon_id: Unique ID of the created coupon
        coupon_max_redemptions: Maximum redemptions allowed
        coupon_name: Name of the coupon
        coupon_percent_off: Percentage off
        coupon_times_redeemed: Times already redeemed
        coupon_valid: Whether the coupon is valid
        created_at: Creation timestamp in RFC3339 format
        raw_data: Raw response from Stripe API
    ### get_coupons
        coupon_amount_offs: List of amount offs
        coupon_currencies: List of coupon currencies
        coupon_durations: List of coupon durations
        coupon_ids: List of coupon IDs
        coupon_names: List of coupon names
        coupon_percent_offs: List of percent offs
        coupon_valids: List of validity statuses
        created_ats: List of creation timestamps
        raw_data: Raw response from Stripe API
    ### create_customer
        created_at: Creation timestamp in RFC3339 format
        customer_description: Customer description
        customer_email: Customer's email address
        customer_id: Unique ID of the created customer
        customer_name: Customer's full name
        customer_phone: Customer's phone number
        raw_data: Raw response from Stripe API
    ### read_customer
        created_at: Creation timestamp in RFC3339 format
        customer_description: Customer description
        customer_email: Customer's email address
        customer_id: Unique ID of the customer
        customer_name: Customer's full name
        customer_phone: Customer's phone number
        raw_data: Raw response from Stripe API
    ### create_source
        created_at: Creation timestamp in RFC3339 format
        raw_data: Raw response from Stripe API
        source_amount: Amount for the source in cents
        source_currency: Currency of the source
        source_customer: Customer ID the source is attached to
        source_id: Unique ID of the created source
        source_status: Status of the source
        source_type: Type of the source
    ### read_source
        created_at: Creation timestamp in RFC3339 format
        raw_data: Raw response from Stripe API
        source_amount: Amount for the source in cents
        source_currency: Currency of the source
        source_customer: Customer ID the source is attached to
        source_id: Unique ID of the source
        source_status: Status of the source
        source_type: Type of the source
    ### get_customers
        created_ats: List of creation timestamps
        customer_descriptions: List of customer descriptions
        customer_emails: List of customer emails
        customer_ids: List of customer IDs
        customer_names: List of customer names
        customer_phones: List of customer phones
        raw_data: Raw response from Stripe API
    ### update_customer
        customer_description: Customer description
        customer_email: Customer's email address
        customer_id: Unique ID of the customer
        customer_name: Customer's full name
        customer_phone: Customer's phone number
        message: Success message
        raw_data: Raw response from Stripe API
    ### delete_customer
        customer_id: ID of the deleted customer
        deleted: Whether the deletion was successful
        message: Success message
        raw_data: Raw response from Stripe API
    ### delete_source
        deleted: Whether the source was successfully deleted
        message: Success message
        raw_data: Raw response from Stripe API
        source_id: ID of the deleted source
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Stripe>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "get_balance": {
            "inputs": [],
            "outputs": [
                {
                    "field": "object",
                    "type": "string",
                    "helper_text": "Object type identifier",
                },
                {
                    "field": "available",
                    "type": "string",
                    "helper_text": "Available balance amounts by currency",
                },
                {
                    "field": "pending",
                    "type": "string",
                    "helper_text": "Pending balance amounts by currency",
                },
                {
                    "field": "livemode",
                    "type": "bool",
                    "helper_text": "Whether this is live or test mode",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "get_balance",
            "task_name": "tasks.stripe.get_balance",
            "description": "Read details of a specific balance",
            "label": "Get Balance",
            "inputs_sort_order": ["integration", "action"],
        },
        "create_customer": {
            "inputs": [
                {
                    "field": "customer_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Full name of the customer",
                    "label": "Customer Name",
                    "placeholder": "John Doe",
                },
                {
                    "field": "customer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Email address of the customer",
                    "label": "Customer Email",
                    "placeholder": "john@example.com",
                },
                {
                    "field": "customer_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "Phone number of the customer",
                    "label": "Customer Phone",
                    "placeholder": "+1-555-123-4567",
                },
                {
                    "field": "customer_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the customer",
                    "label": "Customer Description",
                    "placeholder": "VIP customer",
                },
            ],
            "outputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "helper_text": "Unique ID of the created customer",
                },
                {
                    "field": "customer_email",
                    "type": "string",
                    "helper_text": "Customer's email address",
                },
                {
                    "field": "customer_name",
                    "type": "string",
                    "helper_text": "Customer's full name",
                },
                {
                    "field": "customer_phone",
                    "type": "string",
                    "helper_text": "Customer's phone number",
                },
                {
                    "field": "customer_description",
                    "type": "string",
                    "helper_text": "Customer description",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_customer",
            "task_name": "tasks.stripe.create_customer",
            "description": "Create a new customer in Stripe",
            "label": "Create Customer",
            "ui_sort_order": [
                "integration",
                "action",
                "customer_name",
                "customer_email",
                "customer_phone",
                "customer_description",
            ],
        },
        "read_customer": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer to retrieve",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                }
            ],
            "outputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "helper_text": "Unique ID of the customer",
                },
                {
                    "field": "customer_email",
                    "type": "string",
                    "helper_text": "Customer's email address",
                },
                {
                    "field": "customer_name",
                    "type": "string",
                    "helper_text": "Customer's full name",
                },
                {
                    "field": "customer_phone",
                    "type": "string",
                    "helper_text": "Customer's phone number",
                },
                {
                    "field": "customer_description",
                    "type": "string",
                    "helper_text": "Customer description",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "read_customer",
            "task_name": "tasks.stripe.read_customer",
            "description": "Read details of a specific customer",
            "label": "Get Customer",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "customer_id"],
        },
        "update_customer": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer to update",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "update_customer_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "New name for the customer",
                    "label": "New Customer Name",
                    "placeholder": "Jane Doe",
                },
                {
                    "field": "update_customer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "New email for the customer",
                    "label": "New Customer Email",
                    "placeholder": "jane@example.com",
                },
                {
                    "field": "update_customer_phone",
                    "type": "string",
                    "value": "",
                    "helper_text": "New phone for the customer",
                    "label": "New Customer Phone",
                    "placeholder": "+1-555-987-6543",
                },
                {
                    "field": "update_customer_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the customer",
                    "label": "New Customer Description",
                    "placeholder": "Updated description",
                },
            ],
            "outputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "helper_text": "Unique ID of the customer",
                },
                {
                    "field": "customer_email",
                    "type": "string",
                    "helper_text": "Customer's email address",
                },
                {
                    "field": "customer_name",
                    "type": "string",
                    "helper_text": "Customer's full name",
                },
                {
                    "field": "customer_phone",
                    "type": "string",
                    "helper_text": "Customer's phone number",
                },
                {
                    "field": "customer_description",
                    "type": "string",
                    "helper_text": "Customer description",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_customer",
            "task_name": "tasks.stripe.update_customer",
            "description": "Update an existing customer's information",
            "label": "Update Customer",
            "ui_sort_order": [
                "integration",
                "action",
                "customer_id",
                "update_customer_name",
                "update_customer_email",
                "update_customer_phone",
                "update_customer_description",
            ],
        },
        "delete_customer": {
            "inputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer to delete",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                }
            ],
            "outputs": [
                {
                    "field": "customer_id",
                    "type": "string",
                    "helper_text": "ID of the deleted customer",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the deletion was successful",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "delete_customer",
            "task_name": "tasks.stripe.delete_customer",
            "description": "Delete an existing customer",
            "label": "Delete Customer",
            "variant": "default_integration_nodes",
            "ui_sort_order": ["integration", "action", "customer_id"],
        },
        "get_customers": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Number of customers to retrieve",
                    "label": "Number of Customers",
                    "placeholder": "10",
                },
                {
                    "field": "customer_email",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by customer email",
                    "label": "Filter by Email",
                    "placeholder": "john@example.com",
                },
            ],
            "outputs": [
                {
                    "field": "customer_ids",
                    "type": "vec<string>",
                    "helper_text": "List of customer IDs",
                },
                {
                    "field": "customer_emails",
                    "type": "vec<string>",
                    "helper_text": "List of customer emails",
                },
                {
                    "field": "customer_names",
                    "type": "vec<string>",
                    "helper_text": "List of customer names",
                },
                {
                    "field": "customer_phones",
                    "type": "vec<string>",
                    "helper_text": "List of customer phones",
                },
                {
                    "field": "customer_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of customer descriptions",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_customers",
            "task_name": "tasks.stripe.get_customers",
            "description": "Get multiple customers",
            "label": "List Customers",
            "inputs_sort_order": ["integration", "action", "limit", "customer_email"],
        },
        "create_charge": {
            "inputs": [
                {
                    "field": "charge_amount",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Amount to charge in cents",
                    "label": "Charge Amount (cents)",
                    "placeholder": "5000",
                },
                {
                    "field": "charge_currency",
                    "type": "string",
                    "value": "USD",
                    "helper_text": "Three-letter currency code",
                    "label": "Currency",
                    "placeholder": "USD",
                },
                {
                    "field": "charge_source",
                    "type": "string",
                    "value": "",
                    "helper_text": "Payment source ID or token",
                    "label": "Payment Source",
                    "placeholder": "tok_visa",
                },
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Customer ID to associate with charge",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "charge_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "Description of the charge",
                    "label": "Charge Description",
                    "placeholder": "Payment for services",
                },
            ],
            "outputs": [
                {
                    "field": "charge_id",
                    "type": "string",
                    "helper_text": "Unique ID of the created charge",
                },
                {
                    "field": "charge_amount",
                    "type": "int32",
                    "helper_text": "Amount charged in cents",
                },
                {
                    "field": "charge_currency",
                    "type": "string",
                    "helper_text": "Currency of the charge",
                },
                {
                    "field": "charge_customer",
                    "type": "string",
                    "helper_text": "Customer ID associated with charge",
                },
                {
                    "field": "charge_description",
                    "type": "string",
                    "helper_text": "Charge description",
                },
                {
                    "field": "charge_status",
                    "type": "string",
                    "helper_text": "Status of the charge",
                },
                {
                    "field": "charge_paid",
                    "type": "bool",
                    "helper_text": "Whether the charge was paid",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_charge",
            "task_name": "tasks.stripe.create_charge",
            "description": "Create a new charge",
            "label": "Create Charge",
            "ui_sort_order": [
                "integration",
                "action",
                "charge_amount",
                "charge_currency",
                "charge_source",
                "customer_id",
                "charge_description",
            ],
        },
        "read_charge": {
            "inputs": [
                {
                    "field": "charge_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the charge to retrieve",
                    "label": "Charge ID",
                    "placeholder": "ch_123456789",
                }
            ],
            "outputs": [
                {
                    "field": "charge_id",
                    "type": "string",
                    "helper_text": "Unique ID of the charge",
                },
                {
                    "field": "charge_amount",
                    "type": "int32",
                    "helper_text": "Amount charged in cents",
                },
                {
                    "field": "charge_currency",
                    "type": "string",
                    "helper_text": "Currency of the charge",
                },
                {
                    "field": "charge_customer",
                    "type": "string",
                    "helper_text": "Customer ID associated with charge",
                },
                {
                    "field": "charge_description",
                    "type": "string",
                    "helper_text": "Charge description",
                },
                {
                    "field": "charge_status",
                    "type": "string",
                    "helper_text": "Status of the charge",
                },
                {
                    "field": "charge_paid",
                    "type": "bool",
                    "helper_text": "Whether the charge was paid",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "read_charge",
            "task_name": "tasks.stripe.read_charge",
            "description": "Read details of a specific charge",
            "label": "Get Charge",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "charge_id"],
        },
        "update_charge": {
            "inputs": [
                {
                    "field": "charge_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the charge to update",
                    "label": "Charge ID",
                    "placeholder": "ch_123456789",
                },
                {
                    "field": "update_charge_description",
                    "type": "string",
                    "value": "",
                    "helper_text": "New description for the charge",
                    "label": "New Description",
                    "placeholder": "Updated payment description",
                },
            ],
            "outputs": [
                {
                    "field": "charge_id",
                    "type": "string",
                    "helper_text": "Unique ID of the charge",
                },
                {
                    "field": "charge_amount",
                    "type": "int32",
                    "helper_text": "Amount charged in cents",
                },
                {
                    "field": "charge_currency",
                    "type": "string",
                    "helper_text": "Currency of the charge",
                },
                {
                    "field": "charge_customer",
                    "type": "string",
                    "helper_text": "Customer ID associated with charge",
                },
                {
                    "field": "charge_description",
                    "type": "string",
                    "helper_text": "Charge description",
                },
                {
                    "field": "charge_status",
                    "type": "string",
                    "helper_text": "Status of the charge",
                },
                {
                    "field": "charge_paid",
                    "type": "bool",
                    "helper_text": "Whether the charge was paid",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "update_charge",
            "task_name": "tasks.stripe.update_charge",
            "description": "Update an existing charge",
            "label": "Update Charge",
            "ui_sort_order": [
                "integration",
                "action",
                "charge_id",
                "update_charge_description",
            ],
        },
        "get_charges": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Number of charges to retrieve",
                    "label": "Number of Charges",
                    "placeholder": "10",
                },
                {
                    "field": "customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "Filter by customer ID",
                    "label": "Filter by Customer ID",
                    "placeholder": "cus_123456789",
                },
            ],
            "outputs": [
                {
                    "field": "charge_ids",
                    "type": "vec<string>",
                    "helper_text": "List of charge IDs",
                },
                {
                    "field": "charge_amounts",
                    "type": "vec<int32>",
                    "helper_text": "List of charge amounts",
                },
                {
                    "field": "charge_currencies",
                    "type": "vec<string>",
                    "helper_text": "List of charge currencies",
                },
                {
                    "field": "charge_customers",
                    "type": "vec<string>",
                    "helper_text": "List of associated customer IDs",
                },
                {
                    "field": "charge_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of charge descriptions",
                },
                {
                    "field": "charge_statuses",
                    "type": "vec<string>",
                    "helper_text": "List of charge statuses",
                },
                {
                    "field": "charge_paids",
                    "type": "vec<bool>",
                    "helper_text": "List of paid status booleans",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_charges",
            "task_name": "tasks.stripe.get_charges",
            "description": "Get multiple charges",
            "label": "List Charges",
            "inputs_sort_order": ["integration", "action", "limit", "customer_id"],
        },
        "create_coupon": {
            "inputs": [
                {
                    "field": "coupon_duration",
                    "type": "string",
                    "value": "once",
                    "helper_text": "Duration of the coupon",
                    "label": "Duration",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Once", "value": "once"},
                            {"label": "Repeating", "value": "repeating"},
                            {"label": "Forever", "value": "forever"},
                        ],
                    },
                },
                {
                    "field": "coupon_amount_off",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Fixed amount off in cents",
                    "label": "Amount Off (cents)",
                    "placeholder": "1000",
                },
                {
                    "field": "coupon_percent_off",
                    "type": "float",
                    "value": 0.0,
                    "helper_text": "Percentage off",
                    "label": "Percent Off",
                    "placeholder": "25.0",
                },
                {
                    "field": "coupon_currency",
                    "type": "string",
                    "value": "USD",
                    "helper_text": "Currency for amount_off coupons",
                    "label": "Currency",
                    "placeholder": "USD",
                },
                {
                    "field": "coupon_name",
                    "type": "string",
                    "value": "",
                    "helper_text": "Name of the coupon",
                    "label": "Coupon Name",
                    "placeholder": "Holiday Sale",
                },
                {
                    "field": "coupon_duration_in_months",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Duration in months for repeating coupons",
                    "label": "Duration (months)",
                },
                {
                    "field": "coupon_max_redemptions",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Maximum number of redemptions",
                    "label": "Max Redemptions",
                },
            ],
            "outputs": [
                {
                    "field": "coupon_id",
                    "type": "string",
                    "helper_text": "Unique ID of the created coupon",
                },
                {
                    "field": "coupon_name",
                    "type": "string",
                    "helper_text": "Name of the coupon",
                },
                {
                    "field": "coupon_duration",
                    "type": "string",
                    "helper_text": "Duration of the coupon",
                },
                {
                    "field": "coupon_amount_off",
                    "type": "int32",
                    "helper_text": "Fixed amount off in cents",
                },
                {
                    "field": "coupon_percent_off",
                    "type": "float",
                    "helper_text": "Percentage off",
                },
                {
                    "field": "coupon_currency",
                    "type": "string",
                    "helper_text": "Currency of the coupon",
                },
                {
                    "field": "coupon_duration_in_months",
                    "type": "int32",
                    "helper_text": "Duration in months",
                },
                {
                    "field": "coupon_max_redemptions",
                    "type": "int32",
                    "helper_text": "Maximum redemptions allowed",
                },
                {
                    "field": "coupon_times_redeemed",
                    "type": "int32",
                    "helper_text": "Times already redeemed",
                },
                {
                    "field": "coupon_valid",
                    "type": "bool",
                    "helper_text": "Whether the coupon is valid",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_coupon",
            "task_name": "tasks.stripe.create_coupon",
            "description": "Create a new coupon",
            "label": "Create Coupon",
            "ui_sort_order": [
                "integration",
                "action",
                "coupon_duration",
                "coupon_amount_off",
                "coupon_percent_off",
                "coupon_currency",
                "coupon_name",
                "coupon_duration_in_months",
                "coupon_max_redemptions",
            ],
        },
        "get_coupons": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "helper_text": "Number of coupons to retrieve",
                    "label": "Number of Coupons",
                    "placeholder": "10",
                }
            ],
            "outputs": [
                {
                    "field": "coupon_ids",
                    "type": "vec<string>",
                    "helper_text": "List of coupon IDs",
                },
                {
                    "field": "coupon_names",
                    "type": "vec<string>",
                    "helper_text": "List of coupon names",
                },
                {
                    "field": "coupon_durations",
                    "type": "vec<string>",
                    "helper_text": "List of coupon durations",
                },
                {
                    "field": "coupon_amount_offs",
                    "type": "vec<int32>",
                    "helper_text": "List of amount offs",
                },
                {
                    "field": "coupon_percent_offs",
                    "type": "vec<float>",
                    "helper_text": "List of percent offs",
                },
                {
                    "field": "coupon_currencies",
                    "type": "vec<string>",
                    "helper_text": "List of coupon currencies",
                },
                {
                    "field": "coupon_valids",
                    "type": "vec<bool>",
                    "helper_text": "List of validity statuses",
                },
                {
                    "field": "created_ats",
                    "type": "vec<timestamp>",
                    "helper_text": "List of creation timestamps",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "get_coupons",
            "task_name": "tasks.stripe.get_coupons",
            "description": "Get multiple coupons",
            "label": "List Coupons",
            "inputs_sort_order": ["integration", "action", "limit"],
        },
        "add_customer_card": {
            "inputs": [
                {
                    "field": "card_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer to add card to",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "card_token",
                    "type": "string",
                    "value": "",
                    "helper_text": "Token representing the card information",
                    "label": "Card Token",
                    "placeholder": "tok_1IMfKdJhRTnqS5TKQVG1LI9o",
                },
            ],
            "outputs": [
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "Unique ID of the added card",
                },
                {
                    "field": "customer_id",
                    "type": "string",
                    "helper_text": "Customer ID the card is attached to",
                },
                {
                    "field": "brand",
                    "type": "string",
                    "helper_text": "Card brand (e.g., Visa, MasterCard)",
                },
                {
                    "field": "last4",
                    "type": "string",
                    "helper_text": "Last 4 digits of the card",
                },
                {
                    "field": "exp_month",
                    "type": "int32",
                    "helper_text": "Card expiration month",
                },
                {
                    "field": "exp_year",
                    "type": "int32",
                    "helper_text": "Card expiration year",
                },
                {
                    "field": "fingerprint",
                    "type": "string",
                    "helper_text": "Unique fingerprint for the card",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "add_customer_card",
            "task_name": "tasks.stripe.add_customer_card",
            "description": "Add a card to a customer",
            "label": "Add Customer Card",
            "ui_sort_order": [
                "integration",
                "action",
                "card_customer_id",
                "card_token",
            ],
        },
        "read_customer_card": {
            "inputs": [
                {
                    "field": "read_card_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer whose card to retrieve",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "read_card_source_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the card/source to retrieve",
                    "label": "Source ID",
                    "placeholder": "card_1A2B3C4D5E6F7G8H",
                },
            ],
            "outputs": [
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "Unique ID of the card",
                },
                {
                    "field": "customer_id",
                    "type": "string",
                    "helper_text": "Customer ID the card is attached to",
                },
                {
                    "field": "brand",
                    "type": "string",
                    "helper_text": "Card brand (e.g., Visa, MasterCard)",
                },
                {
                    "field": "last4",
                    "type": "string",
                    "helper_text": "Last 4 digits of the card",
                },
                {
                    "field": "exp_month",
                    "type": "int32",
                    "helper_text": "Card expiration month",
                },
                {
                    "field": "exp_year",
                    "type": "int32",
                    "helper_text": "Card expiration year",
                },
                {
                    "field": "fingerprint",
                    "type": "string",
                    "helper_text": "Unique fingerprint for the card",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "read_customer_card",
            "task_name": "tasks.stripe.read_customer_card",
            "description": "Read details of a specific customer card",
            "label": "Get Customer Card",
            "variant": "default_integration_nodes",
            "inputs_sort_order": [
                "integration",
                "action",
                "read_card_customer_id",
                "read_card_source_id",
            ],
        },
        "remove_customer_card": {
            "inputs": [
                {
                    "field": "remove_card_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer whose card to remove",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "remove_card_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the card to remove",
                    "label": "Card ID",
                    "placeholder": "card_1A2B3C4D5E6F7G8H",
                },
            ],
            "outputs": [
                {
                    "field": "card_id",
                    "type": "string",
                    "helper_text": "ID of the removed card",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the card was successfully deleted",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "remove_customer_card",
            "task_name": "tasks.stripe.remove_customer_card",
            "description": "Remove a card from a customer",
            "label": "Remove Customer Card",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "remove_card_customer_id",
                "remove_card_id",
            ],
        },
        "create_source": {
            "inputs": [
                {
                    "field": "source_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer to attach the source to",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "source_type",
                    "type": "string",
                    "value": "wechat",
                    "helper_text": "Type of source to create",
                    "label": "Source Type",
                    "component": {
                        "type": "dropdown",
                        "options": [{"label": "WeChat", "value": "wechat"}],
                    },
                },
                {
                    "field": "source_amount",
                    "type": "int32",
                    "value": 0,
                    "helper_text": "Amount in cents for this source",
                    "label": "Amount (cents)",
                    "placeholder": "5000",
                },
                {
                    "field": "source_currency",
                    "type": "string",
                    "value": "USD",
                    "helper_text": "Three-letter currency code",
                    "label": "Currency",
                    "placeholder": "USD",
                },
                {
                    "field": "source_statement_descriptor",
                    "type": "string",
                    "value": "",
                    "helper_text": "Text to display on customer's statement",
                    "label": "Statement Descriptor",
                    "placeholder": "Payment description",
                },
            ],
            "outputs": [
                {
                    "field": "source_id",
                    "type": "string",
                    "helper_text": "Unique ID of the created source",
                },
                {
                    "field": "source_type",
                    "type": "string",
                    "helper_text": "Type of the source",
                },
                {
                    "field": "source_amount",
                    "type": "int32",
                    "helper_text": "Amount for the source in cents",
                },
                {
                    "field": "source_currency",
                    "type": "string",
                    "helper_text": "Currency of the source",
                },
                {
                    "field": "source_status",
                    "type": "string",
                    "helper_text": "Status of the source",
                },
                {
                    "field": "source_customer",
                    "type": "string",
                    "helper_text": "Customer ID the source is attached to",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "common_integration_nodes",
            "name": "create_source",
            "task_name": "tasks.stripe.create_source",
            "description": "Create a new payment source",
            "label": "Create Source",
            "ui_sort_order": [
                "integration",
                "action",
                "source_customer_id",
                "source_type",
                "source_amount",
                "source_currency",
                "source_statement_descriptor",
            ],
        },
        "read_source": {
            "inputs": [
                {
                    "field": "read_source_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the source to retrieve",
                    "label": "Source ID",
                    "placeholder": "src_123456789",
                }
            ],
            "outputs": [
                {
                    "field": "source_id",
                    "type": "string",
                    "helper_text": "Unique ID of the source",
                },
                {
                    "field": "source_type",
                    "type": "string",
                    "helper_text": "Type of the source",
                },
                {
                    "field": "source_amount",
                    "type": "int32",
                    "helper_text": "Amount for the source in cents",
                },
                {
                    "field": "source_currency",
                    "type": "string",
                    "helper_text": "Currency of the source",
                },
                {
                    "field": "source_status",
                    "type": "string",
                    "helper_text": "Status of the source",
                },
                {
                    "field": "source_customer",
                    "type": "string",
                    "helper_text": "Customer ID the source is attached to",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "read_source",
            "task_name": "tasks.stripe.read_source",
            "description": "Read details of a specific source",
            "label": "Get Source",
            "variant": "default_integration_nodes",
            "inputs_sort_order": ["integration", "action", "read_source_id"],
        },
        "delete_source": {
            "inputs": [
                {
                    "field": "delete_source_customer_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the customer whose source to delete",
                    "label": "Customer ID",
                    "placeholder": "cus_123456789",
                },
                {
                    "field": "delete_source_id",
                    "type": "string",
                    "value": "",
                    "helper_text": "ID of the source to delete",
                    "label": "Source ID",
                    "placeholder": "src_123456789",
                },
            ],
            "outputs": [
                {
                    "field": "source_id",
                    "type": "string",
                    "helper_text": "ID of the deleted source",
                },
                {
                    "field": "deleted",
                    "type": "bool",
                    "helper_text": "Whether the source was successfully deleted",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "name": "delete_source",
            "task_name": "tasks.stripe.delete_source",
            "description": "Delete a source from a customer",
            "label": "Delete Source",
            "variant": "default_integration_nodes",
            "ui_sort_order": [
                "integration",
                "action",
                "delete_source_customer_id",
                "delete_source_id",
            ],
        },
        "create_token": {
            "inputs": [
                {
                    "field": "token_card_number",
                    "type": "string",
                    "value": "",
                    "helper_text": "Card number",
                    "label": "Card Number",
                    "placeholder": "4242424242424242",
                },
                {
                    "field": "token_cvc",
                    "type": "string",
                    "value": "",
                    "helper_text": "Card security code",
                    "label": "CVC",
                    "placeholder": "314",
                },
                {
                    "field": "token_exp_month",
                    "type": "string",
                    "value": "",
                    "helper_text": "Expiration month",
                    "label": "Expiration Month",
                    "placeholder": "10",
                },
                {
                    "field": "token_exp_year",
                    "type": "string",
                    "value": "",
                    "helper_text": "Expiration year",
                    "label": "Expiration Year",
                    "placeholder": "2027",
                },
            ],
            "outputs": [
                {
                    "field": "token_id",
                    "type": "string",
                    "helper_text": "Unique ID of the created token",
                },
                {
                    "field": "token_type",
                    "type": "string",
                    "helper_text": "Type of the token",
                },
                {
                    "field": "card_brand",
                    "type": "string",
                    "helper_text": "Brand of the card",
                },
                {
                    "field": "card_last4",
                    "type": "string",
                    "helper_text": "Last 4 digits of the card",
                },
                {
                    "field": "card_exp_month",
                    "type": "int32",
                    "helper_text": "Card expiration month",
                },
                {
                    "field": "card_exp_year",
                    "type": "int32",
                    "helper_text": "Card expiration year",
                },
                {
                    "field": "card_fingerprint",
                    "type": "string",
                    "helper_text": "Unique fingerprint for the card",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "Creation timestamp in RFC3339 format",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw response from Stripe API",
                },
            ],
            "variant": "default_integration_nodes",
            "name": "create_token",
            "task_name": "tasks.stripe.create_token",
            "description": "Create a new card token",
            "label": "Create Token",
            "ui_sort_order": [
                "integration",
                "action",
                "token_card_number",
                "token_cvc",
                "token_exp_month",
                "token_exp_year",
            ],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = [
        "integration",
        "action",
        "charge_amount",
        "charge_currency",
        "charge_source",
        "customer_id",
        "customer_name",
        "coupon_duration",
        "card_customer_id",
        "card_token",
        "remove_card_customer_id",
        "remove_card_id",
        "read_card_customer_id",
        "read_card_source_id",
        "source_customer_id",
        "source_type",
        "source_amount",
        "source_currency",
        "delete_source_customer_id",
        "delete_source_id",
        "read_source_id",
        "token_card_number",
        "token_cvc",
        "token_exp_month",
        "token_exp_year",
    ]

    def __init__(
        self,
        action: str = "",
        card_customer_id: str = "",
        card_token: str = "",
        charge_amount: int = 0,
        charge_currency: str = "USD",
        charge_description: str = "",
        charge_id: str = "",
        charge_source: str = "",
        coupon_amount_off: int = 0,
        coupon_currency: str = "USD",
        coupon_duration: str = "once",
        coupon_duration_in_months: int = 0,
        coupon_max_redemptions: int = 0,
        coupon_name: str = "",
        coupon_percent_off: Any = 0.0,
        customer_description: str = "",
        customer_email: str = "",
        customer_id: str = "",
        customer_name: str = "",
        customer_phone: str = "",
        delete_source_customer_id: str = "",
        delete_source_id: str = "",
        limit: int = 10,
        read_card_customer_id: str = "",
        read_card_source_id: str = "",
        read_source_id: str = "",
        remove_card_customer_id: str = "",
        remove_card_id: str = "",
        source_amount: int = 0,
        source_currency: str = "USD",
        source_customer_id: str = "",
        source_statement_descriptor: str = "",
        source_type: str = "wechat",
        token_card_number: str = "",
        token_cvc: str = "",
        token_exp_month: str = "",
        token_exp_year: str = "",
        update_charge_description: str = "",
        update_customer_description: str = "",
        update_customer_email: str = "",
        update_customer_name: str = "",
        update_customer_phone: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_stripe",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if customer_name is not None:
            self.inputs["customer_name"] = customer_name
        if customer_email is not None:
            self.inputs["customer_email"] = customer_email
        if customer_phone is not None:
            self.inputs["customer_phone"] = customer_phone
        if customer_description is not None:
            self.inputs["customer_description"] = customer_description
        if customer_id is not None:
            self.inputs["customer_id"] = customer_id
        if update_customer_name is not None:
            self.inputs["update_customer_name"] = update_customer_name
        if update_customer_email is not None:
            self.inputs["update_customer_email"] = update_customer_email
        if update_customer_phone is not None:
            self.inputs["update_customer_phone"] = update_customer_phone
        if update_customer_description is not None:
            self.inputs["update_customer_description"] = update_customer_description
        if limit is not None:
            self.inputs["limit"] = limit
        if charge_amount is not None:
            self.inputs["charge_amount"] = charge_amount
        if charge_currency is not None:
            self.inputs["charge_currency"] = charge_currency
        if charge_source is not None:
            self.inputs["charge_source"] = charge_source
        if charge_description is not None:
            self.inputs["charge_description"] = charge_description
        if charge_id is not None:
            self.inputs["charge_id"] = charge_id
        if update_charge_description is not None:
            self.inputs["update_charge_description"] = update_charge_description
        if coupon_duration is not None:
            self.inputs["coupon_duration"] = coupon_duration
        if coupon_amount_off is not None:
            self.inputs["coupon_amount_off"] = coupon_amount_off
        if coupon_percent_off is not None:
            self.inputs["coupon_percent_off"] = coupon_percent_off
        if coupon_currency is not None:
            self.inputs["coupon_currency"] = coupon_currency
        if coupon_name is not None:
            self.inputs["coupon_name"] = coupon_name
        if coupon_duration_in_months is not None:
            self.inputs["coupon_duration_in_months"] = coupon_duration_in_months
        if coupon_max_redemptions is not None:
            self.inputs["coupon_max_redemptions"] = coupon_max_redemptions
        if card_customer_id is not None:
            self.inputs["card_customer_id"] = card_customer_id
        if card_token is not None:
            self.inputs["card_token"] = card_token
        if read_card_customer_id is not None:
            self.inputs["read_card_customer_id"] = read_card_customer_id
        if read_card_source_id is not None:
            self.inputs["read_card_source_id"] = read_card_source_id
        if remove_card_customer_id is not None:
            self.inputs["remove_card_customer_id"] = remove_card_customer_id
        if remove_card_id is not None:
            self.inputs["remove_card_id"] = remove_card_id
        if source_customer_id is not None:
            self.inputs["source_customer_id"] = source_customer_id
        if source_type is not None:
            self.inputs["source_type"] = source_type
        if source_amount is not None:
            self.inputs["source_amount"] = source_amount
        if source_currency is not None:
            self.inputs["source_currency"] = source_currency
        if source_statement_descriptor is not None:
            self.inputs["source_statement_descriptor"] = source_statement_descriptor
        if read_source_id is not None:
            self.inputs["read_source_id"] = read_source_id
        if delete_source_customer_id is not None:
            self.inputs["delete_source_customer_id"] = delete_source_customer_id
        if delete_source_id is not None:
            self.inputs["delete_source_id"] = delete_source_id
        if token_card_number is not None:
            self.inputs["token_card_number"] = token_card_number
        if token_cvc is not None:
            self.inputs["token_cvc"] = token_cvc
        if token_exp_month is not None:
            self.inputs["token_exp_month"] = token_exp_month
        if token_exp_year is not None:
            self.inputs["token_exp_year"] = token_exp_year
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationStripeNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
