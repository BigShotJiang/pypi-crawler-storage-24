"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..config_objects import SamplingConfig


@Node.register_node_type("ai_filter_list")
class AiFilterListNode(Node):
    """
    Filter items in a list given a specific AI condition. Example, Filter (Red, White, Boat) by whether it is a color: (Red, White)

    ## Inputs
    ### Common Inputs
        model: The specific model for filtering
        ai_condition: Write in natural language the condition to filter each item in the list
        filter_mode: Choose whether to filter a single list or filter by another list
        list_to_filter: The list to filter
        output_blank_value: If true, output a blank value for values that do not meet the filter condition. If false, nothing will be outputted
        provider: The model provider
    ### When filter_mode = 'another'
        filter_by: The items to filter the list by

    ## Outputs
    ### When filter_mode = 'single'
        output: The filtered list
    ### When filter_mode = 'another'
        output: The filtered list
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for filtering",
            "value": "",
            "type": "string",
        },
        {
            "field": "ai_condition",
            "helper_text": "Write in natural language the condition to filter each item in the list",
            "value": "",
            "type": "string",
        },
        {
            "field": "filter_mode",
            "helper_text": "Choose whether to filter a single list or filter by another list",
            "value": "single",
            "type": "string",
        },
        {
            "field": "list_to_filter",
            "helper_text": "The list to filter",
            "value": [],
            "type": "vec<string>",
        },
        {
            "field": "output_blank_value",
            "helper_text": "If true, output a blank value for values that do not meet the filter condition. If false, nothing will be outputted",
            "value": False,
            "type": "bool",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "single**(*)": {
            "inputs": [],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<string>",
                    "helper_text": "The filtered list",
                }
            ],
        },
        "another**(*)": {
            "inputs": [
                {
                    "field": "filter_by",
                    "label": "Filter by",
                    "type": "vec<string>",
                    "value": [],
                    "helper_text": "The items to filter the list by",
                    "component": {"type": "text", "default_itemize": False},
                }
            ],
            "outputs": [
                {
                    "field": "output",
                    "type": "vec<string>",
                    "helper_text": "The filtered list",
                }
            ],
            "required": ["filter_by"],
        },
        "(*)**openai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**google": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**xai": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**cohere": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**together": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**bedrock": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "(*)**azure": {
            "inputs": [
                {
                    "field": "model",
                    "label": "LLM model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for filtering",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["filter_mode", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["list_to_filter", "ai_condition"]

    def __init__(
        self,
        filter_mode: str = "single",
        provider: str = "openai",
        model: str = "",
        ai_condition: str = "",
        filter_by: List[str] = [],
        list_to_filter: List[str] = [],
        output_blank_value: bool = False,
        dependencies: Optional[List[str]] = None,
        sampling: Optional[SamplingConfig] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Unpack config objects (or apply defaults)
        _cfg_sampling = sampling if sampling is not None else SamplingConfig()
        temperature = _cfg_sampling.temperature
        top_p = _cfg_sampling.top_p
        max_tokens = _cfg_sampling.max_tokens
        # Initialize with params
        params = {}
        params["filter_mode"] = filter_mode
        params["provider"] = provider

        super().__init__(
            node_type="ai_filter_list",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if temperature is not None:
            self.inputs["temperature"] = temperature
        if top_p is not None:
            self.inputs["top_p"] = top_p
        if max_tokens is not None:
            self.inputs["max_tokens"] = max_tokens
        if filter_mode is not None:
            self.inputs["filter_mode"] = filter_mode
        if list_to_filter is not None:
            self.inputs["list_to_filter"] = list_to_filter
        if ai_condition is not None:
            self.inputs["ai_condition"] = ai_condition
        if output_blank_value is not None:
            self.inputs["output_blank_value"] = output_blank_value
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if filter_by is not None:
            self.inputs["filter_by"] = filter_by
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiFilterListNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
