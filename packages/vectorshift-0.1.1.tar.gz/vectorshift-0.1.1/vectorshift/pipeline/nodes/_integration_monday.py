"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_monday")
class IntegrationMondayNode(Node):
    """
    Monday

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### get_board
        board_id: The board to retrieve
        workspace_id: The workspace to retrieve boards from
    ### archive_board
        board_id: The board to retrieve
        workspace_id: The workspace to retrieve boards from
    ### create_board_group
        board_id: The board to retrieve
        color: Color of the group
        group_name: Name of the group to create
        position: Position of the group
        workspace_id: The workspace to retrieve boards from
    ### list_board_groups
        board_id: The board to retrieve
        include_archived: Whether to include archived groups
        workspace_id: The workspace to retrieve boards from
    ### delete_board_group
        board_id: The board to retrieve
        group_id: The group to delete
        workspace_id: The workspace to retrieve boards from
    ### create_board_column
        board_id: The board to retrieve
        column_type: Type of column to create
        defaults: Defaults of the column to create
        description: Optional description for the board
        title: Title of the column to create
        workspace_id: The workspace to retrieve boards from
    ### list_board_columns
        board_id: The board to retrieve
        include_archived: Whether to include archived groups
        workspace_id: The workspace to retrieve boards from
    ### create_item
        board_id: The board to retrieve
        column_values: Values of the item to create
        group_id: The group to delete
        item_name: Name of the item to create
        workspace_id: The workspace to retrieve boards from
    ### list_items
        board_id: The board to retrieve
        group_id: The group to delete
        limit: Maximum number of boards to return
        workspace_id: The workspace to retrieve boards from
    ### change_column_value
        board_id: The board to retrieve
        column_id: The column to update
        column_item_id: ID of the item to retrieve
        value: New value for the column
        workspace_id: The workspace to retrieve boards from
    ### change_multiple_column_values
        board_id: The board to retrieve
        column_item_id: ID of the item to retrieve
        column_values: Values of the item to create
        workspace_id: The workspace to retrieve boards from
    ### get_items_by_column_value
        board_id: The board to retrieve
        column_id: The column to update
        column_value: Value to search for in the column
        limit: Maximum number of boards to return
        workspace_id: The workspace to retrieve boards from
    ### move_item
        board_id: The board to retrieve
        column_item_id: ID of the item to retrieve
        target_group_id: ID of the group to move the item to
        workspace_id: The workspace to retrieve boards from
    ### create_board
        board_kind: Type of board to create
        description: Optional description for the board
        name: Name of the board to create
    ### get_item
        column_item_id: ID of the item to retrieve
    ### delete_item
        column_item_id: ID of the item to retrieve
    ### add_item_update
        column_item_id: ID of the item to retrieve
        update_text: Content of the update
    ### list_boards
        limit: Maximum number of boards to return

    ## Outputs
    ### list_boards
        board_descriptions: List of board descriptions
        board_ids: List of board IDs
        board_names: List of board names
        board_states: List of board states
        board_urls: List of board URLs
        raw_data: Raw API response data
    ### create_board
        board_id: Unique identifier of the created board
        created_at: When the board was created
        name: Name of the created board
        raw_data: Raw API response data
        url: URL of the created board
    ### get_board
        board_id: Unique identifier of the board
        board_kind: Type of the board
        description: Description of the board
        name: Name of the board
        owners: List of board owners
        raw_data: Raw API response data
        state: Current state of the board
        url: URL of the board
    ### archive_board
        board_id: ID of the archived board
        raw_data: Raw API response data
    ### create_board_group
        board_id: ID of the board containing the group
        color: Color of the created group
        group_id: Unique identifier of the created group
        group_name: Name of the created group
        position: Position of the created group
        raw_data: Raw API response data
    ### create_board_column
        board_id: ID of the board containing the column
        column_id: Unique identifier of the created column
        column_type: Type of the created column
        defaults: Defaults of the created column
        description: Description of the created column
        raw_data: Raw API response data
        settings: Settings of the created column
        title: Title of the created column
    ### create_item
        board_id: ID of the board containing the item
        created_at: When the item was created
        group_id: ID of the group containing the item
        group_title: Title of the group containing the item
        item_id: Unique identifier of the created item
        item_name: Name of the created item
        raw_data: Raw API response data
        url: URL of the created item
    ### get_item
        board_id: ID of the board containing the item
        board_name: Name of the board containing the item
        column_ids: List of column IDs
        column_texts: List of column texts
        column_titles: List of column titles
        column_types: List of column types
        created_at: When the item was created
        group_id: ID of the group containing the item
        group_title: Title of the group containing the item
        item_id: Unique identifier of the item
        item_name: Name of the item
        raw_data: Raw API response data
        state: Current state of the item
    ### list_items
        board_id: ID of the board containing the items
        created_dates: List of item creation dates
        group_ids: List of group IDs
        group_titles: List of group titles
        item_ids: List of item IDs
        item_names: List of item names
        item_states: List of item states
        raw_data: Raw API response data
        total_count: Total number of items
        updated_dates: List of item update dates
    ### change_column_value
        board_id: ID of the board containing the item
        column_id: ID of the updated column
        item_id: ID of the updated item
        item_name: Name of the updated item
        raw_data: Raw API response data
        updated_column_text: Text of the updated column
    ### get_items_by_column_value
        board_id: ID of the board containing the items
        board_names: List of matching board names
        column_id: ID of the column searched in
        column_value: Value searched for in the column
        created_dates: List of matching item creation dates
        group_ids: List of matching group IDs
        group_titles: List of matching group titles
        item_ids: List of matching item IDs
        item_names: List of matching item names
        item_states: List of matching item states
        raw_data: Raw API response data
        total_count: Total number of items
    ### list_board_columns
        column_archived: List of column archived statuses
        column_descriptions: List of column descriptions
        column_ids: List of column IDs
        column_settings: List of column settings
        column_titles: List of column titles
        column_types: List of column types
        raw_data: Raw API response data
        total_count: Total number of columns
    ### add_item_update
        created_at: When the update was created
        creator_id: ID of the person who created the update
        creator_name: Name of the person who created the update
        item_id: ID of the item the update was added to
        raw_data: Raw API response data
        update_id: ID of the created update
        update_text: Content of the update
    ### list_board_groups
        group_archived: List of group archived statuses
        group_colors: List of group colors
        group_ids: List of group IDs
        group_item_counts: List of group item counts
        group_names: List of group names
        group_positions: List of group positions
        raw_data: Raw API response data
    ### delete_board_group
        group_id: ID of the deleted group
        raw_data: Raw API response data
    ### delete_item
        item_id: ID of the deleted item
        raw_data: Raw API response data
    ### change_multiple_column_values
        item_id: ID of the updated item
        raw_data: Raw API response data
        updated_columns: List of column IDs that were updated
    ### move_item
        item_id: ID of the moved item
        item_name: Name of the moved item
        new_group_id: ID of the new group
        new_group_title: Title of the new group
        raw_data: Raw API response data
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Monday>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "create_board": {
            "inputs": [
                {
                    "field": "name",
                    "type": "string",
                    "label": "Board Name",
                    "placeholder": "My New Board",
                    "helper_text": "Name of the board to create",
                },
                {
                    "field": "board_kind",
                    "type": "string",
                    "value": "public",
                    "label": "Board Type",
                    "helper_text": "Type of board to create",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Public", "value": "public"},
                            {"label": "Private", "value": "private"},
                            {"label": "Share", "value": "share"},
                        ],
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "placeholder": "Board description",
                    "helper_text": "Optional description for the board",
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created board",
                },
                {
                    "field": "name",
                    "type": "string",
                    "helper_text": "Name of the created board",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "URL of the created board",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the board was created",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_board",
            "task_name": "tasks.monday.create_board",
            "description": "Create a new board",
            "label": "Create Board",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "name",
                "board_kind",
                "description",
            ],
            "required": ["name"],
        },
        "get_board": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to retrieve",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the board",
                },
                {"field": "name", "type": "string", "helper_text": "Name of the board"},
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the board",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the board",
                },
                {
                    "field": "board_kind",
                    "type": "string",
                    "helper_text": "Type of the board",
                },
                {"field": "url", "type": "string", "helper_text": "URL of the board"},
                {
                    "field": "owners",
                    "type": "vec<string>",
                    "helper_text": "List of board owners",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_board",
            "task_name": "tasks.monday.get_board",
            "description": "Read details of a specific board",
            "label": "Get Board",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "workspace_id", "board_id"],
            "required": ["board_id"],
        },
        "list_boards": {
            "inputs": [
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of boards to return",
                }
            ],
            "outputs": [
                {
                    "field": "board_ids",
                    "type": "vec<string>",
                    "helper_text": "List of board IDs",
                },
                {
                    "field": "board_names",
                    "type": "vec<string>",
                    "helper_text": "List of board names",
                },
                {
                    "field": "board_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of board descriptions",
                },
                {
                    "field": "board_states",
                    "type": "vec<string>",
                    "helper_text": "List of board states",
                },
                {
                    "field": "board_urls",
                    "type": "vec<string>",
                    "helper_text": "List of board URLs",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_boards",
            "task_name": "tasks.monday.list_boards",
            "description": "Get multiple boards",
            "label": "List Boards",
            "variant": "default_integration_nodes",
            "input_sort_order": ["action", "integration", "limit"],
            "required": ["limit"],
        },
        "archive_board": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to archive",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the archived board",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "archive_board",
            "task_name": "tasks.monday.archive_board",
            "description": "Archive a board",
            "label": "Archive Board",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "workspace_id", "board_id"],
            "required": ["board_id"],
        },
        "create_board_group": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to create the group in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "label": "Group Name",
                    "placeholder": "My New Group",
                    "helper_text": "Name of the group to create",
                },
                {
                    "field": "color",
                    "type": "string",
                    "label": "Group Color",
                    "placeholder": "Red",
                    "helper_text": "Color of the group",
                },
                {
                    "field": "position",
                    "type": "string",
                    "label": "Group Position",
                    "placeholder": "1",
                    "helper_text": "Position of the group",
                },
            ],
            "outputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created group",
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "helper_text": "Name of the created group",
                },
                {
                    "field": "color",
                    "type": "string",
                    "helper_text": "Color of the created group",
                },
                {
                    "field": "position",
                    "type": "string",
                    "helper_text": "Position of the created group",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_board_group",
            "task_name": "tasks.monday.create_board_group",
            "description": "Create a new group in a board",
            "label": "Create Board Group",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "group_name",
                "color",
                "position",
            ],
            "required": ["board_id", "group_name"],
        },
        "list_board_groups": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to list groups from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "include_archived",
                    "type": "bool",
                    "value": False,
                    "label": "Include Archived",
                    "helper_text": "Whether to include archived groups",
                },
            ],
            "outputs": [
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of group IDs",
                },
                {
                    "field": "group_names",
                    "type": "vec<string>",
                    "helper_text": "List of group names",
                },
                {
                    "field": "group_colors",
                    "type": "vec<string>",
                    "helper_text": "List of group colors",
                },
                {
                    "field": "group_positions",
                    "type": "vec<string>",
                    "helper_text": "List of group positions",
                },
                {
                    "field": "group_archived",
                    "type": "vec<bool>",
                    "helper_text": "List of group archived statuses",
                },
                {
                    "field": "group_item_counts",
                    "type": "vec<int32>",
                    "helper_text": "List of group item counts",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_board_groups",
            "task_name": "tasks.monday.list_board_groups",
            "description": "Get multiple board groups",
            "label": "List Board Groups",
            "variant": "common_integration_nodes",
            "input_sort_order": ["action", "integration", "workspace_id", "board_id"],
            "required": ["board_id"],
        },
        "delete_board_group": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board containing the group",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "label": "Select Group",
                    "helper_text": "The group to delete",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=group_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
            ],
            "outputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "ID of the deleted group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_board_group",
            "task_name": "tasks.monday.delete_board_group",
            "description": "Delete a group from a board",
            "label": "Delete Board Group",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "group_id",
            ],
            "required": ["board_id", "group_id"],
        },
        "create_board_column": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to create the column in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "title",
                    "type": "string",
                    "label": "Column Title",
                    "placeholder": "My New Column",
                    "helper_text": "Title of the column to create",
                },
                {
                    "field": "column_type",
                    "type": "string",
                    "value": "text",
                    "label": "Column Type",
                    "helper_text": "Type of column to create",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Text", "value": "text"},
                            {"label": "Number", "value": "number"},
                            {"label": "Status", "value": "status"},
                            {"label": "Date", "value": "date"},
                            {"label": "Person", "value": "person"},
                            {"label": "Dropdown", "value": "dropdown"},
                            {"label": "Checkbox", "value": "checkbox"},
                            {"label": "Email", "value": "email"},
                            {"label": "Phone", "value": "phone"},
                            {"label": "Link", "value": "link"},
                        ],
                    },
                },
                {
                    "field": "description",
                    "type": "string",
                    "label": "Column Description",
                    "placeholder": "My New Column",
                    "helper_text": "Description of the column to create",
                },
                {
                    "field": "defaults",
                    "type": "string",
                    "label": "Column Defaults",
                    "placeholder": '{"text": "My New Column"}',
                    "helper_text": "Defaults of the column to create",
                },
            ],
            "outputs": [
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created column",
                },
                {
                    "field": "title",
                    "type": "string",
                    "helper_text": "Title of the created column",
                },
                {
                    "field": "column_type",
                    "type": "string",
                    "helper_text": "Type of the created column",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "Description of the created column",
                },
                {
                    "field": "defaults",
                    "type": "string",
                    "helper_text": "Defaults of the created column",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the column",
                },
                {
                    "field": "settings",
                    "type": "string",
                    "helper_text": "Settings of the created column",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_board_column",
            "task_name": "tasks.monday.create_board_column",
            "description": "Create a new column in a board",
            "label": "Create Board Column",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "title",
                "column_type",
                "description",
                "defaults",
            ],
            "required": ["board_id", "title", "column_type"],
        },
        "list_board_columns": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to list columns from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "include_archived",
                    "type": "bool",
                    "value": False,
                    "label": "Include Archived",
                    "helper_text": "Whether to include archived columns",
                },
            ],
            "outputs": [
                {
                    "field": "column_ids",
                    "type": "vec<string>",
                    "helper_text": "List of column IDs",
                },
                {
                    "field": "column_titles",
                    "type": "vec<string>",
                    "helper_text": "List of column titles",
                },
                {
                    "field": "column_types",
                    "type": "vec<string>",
                    "helper_text": "List of column types",
                },
                {
                    "field": "column_settings",
                    "type": "vec<string>",
                    "helper_text": "List of column settings",
                },
                {
                    "field": "column_descriptions",
                    "type": "vec<string>",
                    "helper_text": "List of column descriptions",
                },
                {
                    "field": "column_archived",
                    "type": "vec<bool>",
                    "helper_text": "List of column archived statuses",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of columns",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_board_columns",
            "task_name": "tasks.monday.list_board_columns",
            "description": "Get multiple board columns",
            "label": "List Board Columns",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "include_archived",
            ],
            "required": ["board_id"],
        },
        "create_item": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "value": "",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "value": "",
                    "helper_text": "The board to create the item in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "label": "Select Group",
                    "value": "",
                    "helper_text": "The group to create the item in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=group_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "item_name",
                    "type": "string",
                    "label": "Item Name",
                    "value": "",
                    "placeholder": "My New Item",
                    "helper_text": "Name of the item to create",
                },
                {
                    "field": "column_values",
                    "type": "string",
                    "value": "",
                    "label": "Column Values",
                    "placeholder": '{"text": "My New Item"}',
                    "helper_text": "Values of the item to create",
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the created item",
                },
                {
                    "field": "item_name",
                    "type": "string",
                    "helper_text": "Name of the created item",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the item",
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "ID of the group containing the item",
                },
                {
                    "field": "group_title",
                    "type": "string",
                    "helper_text": "Title of the group containing the item",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the item was created",
                },
                {
                    "field": "url",
                    "type": "string",
                    "helper_text": "URL of the created item",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_item",
            "task_name": "tasks.monday.create_item",
            "description": "Create a new item",
            "label": "Create Item",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "group_id",
                "item_name",
                "column_values",
            ],
            "required": ["board_id", "group_id", "item_name"],
        },
        "get_item": {
            "inputs": [
                {
                    "field": "column_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "placeholder": "123456789",
                    "helper_text": "ID of the item to retrieve",
                }
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "Unique identifier of the item",
                },
                {
                    "field": "item_name",
                    "type": "string",
                    "helper_text": "Name of the item",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the item",
                },
                {
                    "field": "board_name",
                    "type": "string",
                    "helper_text": "Name of the board containing the item",
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "ID of the group containing the item",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the item was created",
                },
                {
                    "field": "state",
                    "type": "string",
                    "helper_text": "Current state of the item",
                },
                {
                    "field": "group_title",
                    "type": "string",
                    "helper_text": "Title of the group containing the item",
                },
                {
                    "field": "column_ids",
                    "type": "vec<string>",
                    "helper_text": "List of column IDs",
                },
                {
                    "field": "column_texts",
                    "type": "vec<string>",
                    "helper_text": "List of column texts",
                },
                {
                    "field": "column_types",
                    "type": "vec<string>",
                    "helper_text": "List of column types",
                },
                {
                    "field": "column_titles",
                    "type": "vec<string>",
                    "helper_text": "List of column titles",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_item",
            "task_name": "tasks.monday.get_item",
            "description": "Read details of a specific item",
            "label": "Get Item",
            "variant": "default_integration_nodes",
            "input_sort_order": ["action", "integration", "column_item_id"],
            "required": ["column_item_id"],
        },
        "list_items": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to list items from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "value": "",
                    "label": "Select Group (Optional)",
                    "helper_text": "Filter items by group",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=group_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of items to return",
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the items",
                },
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of item IDs",
                },
                {
                    "field": "item_names",
                    "type": "vec<string>",
                    "helper_text": "List of item names",
                },
                {
                    "field": "item_states",
                    "type": "vec<string>",
                    "helper_text": "List of item states",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of item creation dates",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of group IDs",
                },
                {
                    "field": "group_titles",
                    "type": "vec<string>",
                    "helper_text": "List of group titles",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of items",
                },
                {
                    "field": "updated_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of item update dates",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "list_items",
            "task_name": "tasks.monday.list_items",
            "description": "Get multiple items",
            "label": "List Items",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "group_id",
                "limit",
            ],
            "required": ["board_id", "limit"],
        },
        "delete_item": {
            "inputs": [
                {
                    "field": "column_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "placeholder": "123456789",
                    "helper_text": "ID of the item to delete",
                }
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the deleted item",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "delete_item",
            "task_name": "tasks.monday.delete_item",
            "description": "Delete an item",
            "label": "Delete Item",
            "variant": "default_integration_nodes",
            "input_sort_order": ["action", "integration", "column_item_id"],
            "required": ["column_item_id"],
        },
        "change_column_value": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board containing the item",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "placeholder": "123456789",
                    "helper_text": "ID of the item to update",
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "label": "Select Column",
                    "helper_text": "The column to update",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "value",
                    "type": "string",
                    "label": "Value",
                    "placeholder": "New value",
                    "helper_text": "New value for the column",
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the updated item",
                },
                {
                    "field": "item_name",
                    "type": "string",
                    "helper_text": "Name of the updated item",
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the updated column",
                },
                {
                    "field": "updated_column_text",
                    "type": "string",
                    "helper_text": "Text of the updated column",
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the item",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "change_column_value",
            "task_name": "tasks.monday.change_column_value",
            "description": "Update a single column value for an item",
            "label": "Change Column Value",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "column_item_id",
                "column_id",
                "value",
            ],
            "required": ["board_id", "column_item_id", "column_id", "value"],
        },
        "change_multiple_column_values": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board containing the item",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "placeholder": "123456789",
                    "helper_text": "ID of the item to update",
                },
                {
                    "field": "column_values",
                    "type": "string",
                    "label": "Column Values JSON",
                    "placeholder": '{"column1": "value1", "column2": "value2"}',
                    "helper_text": "JSON object with column IDs and their new values",
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the updated item",
                },
                {
                    "field": "updated_columns",
                    "type": "vec<string>",
                    "helper_text": "List of column IDs that were updated",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "change_multiple_column_values",
            "task_name": "tasks.monday.change_multiple_column_values",
            "description": "Update multiple column values for an item",
            "label": "Change Multiple Column Values",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "column_item_id",
                "column_values",
            ],
            "required": ["board_id", "column_item_id", "column_values"],
        },
        "get_items_by_column_value": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "helper_text": "The workspace to retrieve boards from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "helper_text": "The board to search in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "label": "Select Column",
                    "helper_text": "The column to search in",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=column_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_value",
                    "type": "string",
                    "label": "Column Value",
                    "placeholder": "Search value",
                    "helper_text": "Value to search for in the column",
                },
                {
                    "field": "limit",
                    "type": "int32",
                    "value": 10,
                    "label": "Limit",
                    "placeholder": "10",
                    "helper_text": "Maximum number of items to return",
                },
            ],
            "outputs": [
                {
                    "field": "board_id",
                    "type": "string",
                    "helper_text": "ID of the board containing the items",
                },
                {
                    "field": "column_id",
                    "type": "string",
                    "helper_text": "ID of the column searched in",
                },
                {
                    "field": "column_value",
                    "type": "string",
                    "helper_text": "Value searched for in the column",
                },
                {
                    "field": "item_ids",
                    "type": "vec<string>",
                    "helper_text": "List of matching item IDs",
                },
                {
                    "field": "item_names",
                    "type": "vec<string>",
                    "helper_text": "List of matching item names",
                },
                {
                    "field": "item_states",
                    "type": "vec<string>",
                    "helper_text": "List of matching item states",
                },
                {
                    "field": "created_dates",
                    "type": "vec<timestamp>",
                    "helper_text": "List of matching item creation dates",
                },
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of matching group IDs",
                },
                {
                    "field": "group_titles",
                    "type": "vec<string>",
                    "helper_text": "List of matching group titles",
                },
                {
                    "field": "board_names",
                    "type": "vec<string>",
                    "helper_text": "List of matching board names",
                },
                {
                    "field": "total_count",
                    "type": "int32",
                    "helper_text": "Total number of items",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_items_by_column_value",
            "task_name": "tasks.monday.get_items_by_column_value",
            "description": "Get multiple items by column value",
            "label": "List Items By Column Value",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "column_id",
                "column_value",
                "limit",
            ],
            "required": ["board_id", "column_id", "column_value", "limit"],
        },
        "move_item": {
            "inputs": [
                {
                    "field": "workspace_id",
                    "type": "string",
                    "label": "Select Workspace",
                    "value": "",
                    "helper_text": "The workspace to retrieve boards from",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=workspace_id&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "board_id",
                    "type": "string",
                    "label": "Select Board",
                    "value": "",
                    "helper_text": "The board to list items from",
                    "show_on_node": True,
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=board_id&workspace_id={inputs.workspace_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "target_group_id",
                    "type": "string",
                    "label": "Target Group ID",
                    "value": "",
                    "placeholder": "group123",
                    "helper_text": "ID of the group to move the item to",
                    "component": {
                        "agent_field_type": "dynamic",
                        "type": "dropdown",
                        "dynamic_config": {
                            "endpoint": "/{prefix}/item/{inputs.integration.object_id}?field=group_id&board_id={inputs.board_id}&page={}&page_size={dynamic_config.page_size}&q={}",
                            "page_size": 25,
                            "supports_search": True,
                            "supports_pagination": True,
                            "refreshable": True,
                            "useSameEndpointForRefresh": True,
                        },
                    },
                },
                {
                    "field": "column_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "value": "",
                    "placeholder": "123456789",
                    "helper_text": "ID of the item to move",
                },
            ],
            "outputs": [
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the moved item",
                },
                {
                    "field": "item_name",
                    "type": "string",
                    "helper_text": "Name of the moved item",
                },
                {
                    "field": "new_group_id",
                    "type": "string",
                    "helper_text": "ID of the new group",
                },
                {
                    "field": "new_group_title",
                    "type": "string",
                    "helper_text": "Title of the new group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "move_item",
            "task_name": "tasks.monday.move_item",
            "description": "Move an item to a different group",
            "label": "Move Item",
            "variant": "common_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "workspace_id",
                "board_id",
                "target_group_id",
                "column_item_id",
            ],
            "required": ["column_item_id", "target_group_id"],
        },
        "add_item_update": {
            "inputs": [
                {
                    "field": "column_item_id",
                    "type": "string",
                    "label": "Item ID",
                    "placeholder": "123456789",
                    "helper_text": "ID of the item to add an update to",
                },
                {
                    "field": "update_text",
                    "type": "string",
                    "label": "Update Body",
                    "placeholder": "This is an update on the item",
                    "helper_text": "Content of the update",
                },
            ],
            "outputs": [
                {
                    "field": "update_id",
                    "type": "string",
                    "helper_text": "ID of the created update",
                },
                {
                    "field": "item_id",
                    "type": "string",
                    "helper_text": "ID of the item the update was added to",
                },
                {
                    "field": "update_text",
                    "type": "string",
                    "helper_text": "Content of the update",
                },
                {
                    "field": "created_at",
                    "type": "timestamp",
                    "helper_text": "When the update was created",
                },
                {
                    "field": "creator_id",
                    "type": "string",
                    "helper_text": "ID of the person who created the update",
                },
                {
                    "field": "creator_name",
                    "type": "string",
                    "helper_text": "Name of the person who created the update",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_item_update",
            "task_name": "tasks.monday.add_item_update",
            "description": "Add an update/comment to an item",
            "label": "Add Item Update",
            "variant": "default_integration_nodes",
            "input_sort_order": [
                "action",
                "integration",
                "column_item_id",
                "update_text",
            ],
            "required": ["column_item_id", "update_text"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        board_id: Optional[str] = None,
        board_kind: str = "public",
        color: Optional[str] = None,
        column_id: Optional[str] = None,
        column_item_id: Optional[str] = None,
        column_type: str = "text",
        column_value: Optional[str] = None,
        column_values: str = "",
        defaults: Optional[str] = None,
        description: str = "",
        group_id: Optional[str] = None,
        group_name: Optional[str] = None,
        include_archived: bool = False,
        item_name: str = "",
        limit: int = 10,
        name: Optional[str] = None,
        position: Optional[str] = None,
        target_group_id: str = "",
        title: Optional[str] = None,
        update_text: Optional[str] = None,
        value: Optional[str] = None,
        workspace_id: Optional[str] = None,
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_monday",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if name is not None:
            self.inputs["name"] = name
        if board_kind is not None:
            self.inputs["board_kind"] = board_kind
        if description is not None:
            self.inputs["description"] = description
        if workspace_id is not None:
            self.inputs["workspace_id"] = workspace_id
        if board_id is not None:
            self.inputs["board_id"] = board_id
        if limit is not None:
            self.inputs["limit"] = limit
        if group_name is not None:
            self.inputs["group_name"] = group_name
        if color is not None:
            self.inputs["color"] = color
        if position is not None:
            self.inputs["position"] = position
        if include_archived is not None:
            self.inputs["include_archived"] = include_archived
        if group_id is not None:
            self.inputs["group_id"] = group_id
        if title is not None:
            self.inputs["title"] = title
        if column_type is not None:
            self.inputs["column_type"] = column_type
        if defaults is not None:
            self.inputs["defaults"] = defaults
        if item_name is not None:
            self.inputs["item_name"] = item_name
        if column_values is not None:
            self.inputs["column_values"] = column_values
        if column_item_id is not None:
            self.inputs["column_item_id"] = column_item_id
        if column_id is not None:
            self.inputs["column_id"] = column_id
        if value is not None:
            self.inputs["value"] = value
        if column_value is not None:
            self.inputs["column_value"] = column_value
        if target_group_id is not None:
            self.inputs["target_group_id"] = target_group_id
        if update_text is not None:
            self.inputs["update_text"] = update_text
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationMondayNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
