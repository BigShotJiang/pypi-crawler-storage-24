"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("create_workspace")
class CreateWorkspaceNode(Node):
    """
    Create a new workspace in a portal, upload files to its knowledge base, and share with users

    ## Inputs
    ### Common Inputs
        files: Files to index into the workspace's knowledge base
        name: Name for the new workspace
        portal: The portal to create the workspace in
        shared_emails: Emails to share the workspace with

    ## Outputs
    ### Common Outputs
        workspace: The created workspace
        workspace_id: The ID of the created workspace
        workspace_kb: The workspace's knowledge base
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "files",
            "helper_text": "Files to index into the workspace's knowledge base",
            "value": [],
            "type": "vec<file>",
        },
        {
            "field": "name",
            "helper_text": "Name for the new workspace",
            "value": "",
            "type": "string",
        },
        {
            "field": "portal",
            "helper_text": "The portal to create the workspace in",
            "value": {"object_type": 19, "object_id": ""},
            "type": "portal",
        },
        {
            "field": "shared_emails",
            "helper_text": "Emails to share the workspace with",
            "value": [],
            "type": "vec<string>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "workspace",
            "helper_text": "The created workspace",
            "type": "project",
        },
        {
            "field": "workspace_id",
            "helper_text": "The ID of the created workspace",
            "type": "string",
        },
        {
            "field": "workspace_kb",
            "helper_text": "The workspace's knowledge base",
            "type": "knowledge_base",
        },
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["portal", "name"]

    def __init__(
        self,
        files: List[str] = [],
        name: str = "",
        portal: Any = "",
        shared_emails: List[str] = [],
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="create_workspace",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if portal is not None:
            self.inputs["portal"] = portal
        if name is not None:
            self.inputs["name"] = name
        if files is not None:
            self.inputs["files"] = files
        if shared_emails is not None:
            self.inputs["shared_emails"] = shared_emails
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "CreateWorkspaceNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
