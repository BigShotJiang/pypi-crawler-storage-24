"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration

from ..interface_types import KeyItem


@Node.register_node_type("read_json_values")
class ReadJsonValuesNode(Node):
    """
    Read values from a JSON object based on a provided key(s).

    ## Inputs
    ### Common Inputs
        json_string: The JSON you want to read from
        keys: Define the name(s) of the JSON keys from the JSON that you want to read
        processed_outputs: The processed_outputs input

    ## Outputs
    ### Common Outputs
        [processed_outputs]: The [processed_outputs] output
        json_values: The JSON Value
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "json_string",
            "helper_text": "The JSON you want to read from",
            "value": "",
            "type": "string",
        },
        {
            "field": "keys",
            "helper_text": "Define the name(s) of the JSON keys from the JSON that you want to read",
            "value": [{"id": "key_1", "key": ""}],
            "type": "vec<interface{id: string, key: string}>",
        },
        {
            "field": "processed_outputs",
            "helper_text": "The processed_outputs input",
            "value": {},
            "type": "map<string, string>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "[processed_outputs]",
            "helper_text": "The [processed_outputs] output",
            "type": "",
        },
        {"field": "json_values", "helper_text": "The JSON Value", "type": "string"},
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {}

    # List of parameters that affect configuration
    _PARAMS = []

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["keys", "json_string", "processed_outputs"]

    def __init__(
        self,
        json_string: str = "",
        keys: List[KeyItem] = [{"id": "key_1", "key": ""}],
        processed_outputs: Dict[str, str] = {},
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}

        super().__init__(
            node_type="read_json_values",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if json_string is not None:
            self.inputs["json_string"] = json_string
        if keys is not None:
            self.inputs["keys"] = keys
        if processed_outputs is not None:
            self.inputs["processed_outputs"] = processed_outputs
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "ReadJsonValuesNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
