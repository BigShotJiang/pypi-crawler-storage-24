"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("ai_speech_to_text")
class AiSpeechToTextNode(Node):
    """
    Generate Text from Audio using AI

    ## Inputs
    ### Common Inputs
        model: Select the speech-to-text model
        audio: The audio for conversion
        provider: Select the model provider.
        use_personal_api_key: Use your personal API key
    ### When use_personal_api_key = True
        api_key: Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run
    ### When provider = 'deepgram'
        tier: Select the tier

    ## Outputs
    ### Common Outputs
        text: The Text from the Audio.
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "Select the speech-to-text model",
            "value": "whisper-1",
            "type": "string",
        },
        {
            "field": "audio",
            "helper_text": "The audio for conversion",
            "value": "",
            "type": "audio",
        },
        {
            "field": "provider",
            "helper_text": "Select the model provider.",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "use_personal_api_key",
            "helper_text": "Use your personal API key",
            "value": False,
            "type": "bool",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {"field": "text", "helper_text": "The Text from the Audio.", "type": "string"}
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "true**(*)": {
            "inputs": [
                {
                    "field": "api_key",
                    "label": "Api Key",
                    "type": "string",
                    "value": "",
                    "helper_text": "Input your personal API key from the model provider. Note: if you do not have access to the selected model, the workflow will not run",
                    "component": {
                        "type": "password",
                        "agent_field_type": "dynamic",
                        "disable_conversion": True,
                    },
                }
            ],
            "outputs": [],
        },
        "(*)**openai": {"inputs": [], "outputs": [], "title": "OpenAI Speech to Text"},
        "(*)**deepgram": {
            "inputs": [
                {
                    "field": "tier",
                    "type": "string",
                    "value": "general",
                    "label": "Tier",
                    "helper_text": "Select the tier",
                    "component": {
                        "type": "dropdown",
                        "source": "llm",
                        "source_key": "tier",
                        "source_type": "speech_to_text",
                        "agent_field_type": "dynamic",
                        "disable_conversion": False,
                    },
                }
            ],
            "outputs": [],
            "title": "Deepgram Speech to Text",
        },
        "false**(*)": {"inputs": [], "outputs": []},
    }

    # List of parameters that affect configuration
    _PARAMS = ["use_personal_api_key", "provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["audio", "api_key"]

    def __init__(
        self,
        use_personal_api_key: bool = False,
        provider: str = "openai",
        model: str = "whisper-1",
        api_key: str = "",
        audio: Any = None,
        tier: str = "general",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["use_personal_api_key"] = use_personal_api_key
        params["provider"] = provider

        super().__init__(
            node_type="ai_speech_to_text",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if audio is not None:
            self.inputs["audio"] = audio
        if use_personal_api_key is not None:
            self.inputs["use_personal_api_key"] = use_personal_api_key
        if api_key is not None:
            self.inputs["api_key"] = api_key
        if tier is not None:
            self.inputs["tier"] = tier
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "AiSpeechToTextNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
