"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("translator")
class TranslatorNode(Node):
    """
    Translate text from one language to another.

    ## Inputs
    ### Common Inputs
        model: The specific model for translation
        text: The text to be translated
        provider: The model provider
        source_language: The language of the input text
        target_language: The language to translate to

    ## Outputs
    ### Common Outputs
        translation: The translation of the text
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "model",
            "helper_text": "The specific model for translation",
            "value": "",
            "type": "string",
        },
        {
            "field": "text",
            "helper_text": "The text to be translated",
            "value": "",
            "type": "string",
        },
        {
            "field": "provider",
            "helper_text": "The model provider",
            "value": "openai",
            "type": "string",
        },
        {
            "field": "source_language",
            "helper_text": "The language of the input text",
            "value": "Detect Language",
            "type": "string",
        },
        {
            "field": "target_language",
            "helper_text": "The language to translate to",
            "value": "English",
            "type": "string",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = [
        {
            "field": "translation",
            "helper_text": "The translation of the text",
            "type": "string",
        }
    ]

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "openai": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "anthropic": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "google": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "xai": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "cohere": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "perplexity": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "together": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "bedrock": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
        "azure": {
            "inputs": [
                {
                    "field": "model",
                    "type": "string",
                    "value": "",
                    "helper_text": "The specific model for translation",
                    "label": "LLM model",
                    "section": "advanced_settings",
                    "component": {"type": "dropdown"},
                }
            ],
            "outputs": [],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["provider"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["text"]

    def __init__(
        self,
        provider: str = "openai",
        model: str = "",
        text: str = "",
        source_language: str = "Detect Language",
        target_language: str = "English",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["provider"] = provider

        super().__init__(
            node_type="translator",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if text is not None:
            self.inputs["text"] = text
        if source_language is not None:
            self.inputs["source_language"] = source_language
        if target_language is not None:
            self.inputs["target_language"] = target_language
        if provider is not None:
            self.inputs["provider"] = provider
        if model is not None:
            self.inputs["model"] = model
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "TranslatorNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
