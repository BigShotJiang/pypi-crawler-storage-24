"""
Generated node class from TOML configuration.
This file is auto-generated. Do not edit manually.
"""

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Union,
    Protocol,
    runtime_checkable,
    TYPE_CHECKING,
)
from ..node import Node, NodeOutputs

if TYPE_CHECKING:
    from vectorshift.agent.object import Agent
    from vectorshift.pipeline.object import Pipeline
    from vectorshift.transformation import Transformation
    from vectorshift.knowledge_base import KnowledgeBase
    from vectorshift.integrations.integration import Integration


@Node.register_node_type("integration_google_workspace_admin")
class IntegrationGoogleWorkspaceAdminNode(Node):
    """
    Google Workspace Admin

    ## Inputs
    ### Common Inputs
        action: Select the action to perform
        integration: Connect to your account
    ### get_chromeos_devices
        query: Raw query string for advanced filtering
        asset_id: Filter by asset ID
        ethernet_mac: Filter by Ethernet MAC address (no colons)
        include_child_orgunits: Include devices from child organizational units
        location: Filter by annotated location
        max_results: Maximum number of results to return (1-200)
        notes: Filter by device notes
        order_by: Field to order results by
        org_unit_path: Filter by organizational unit path
        projection: What subset of fields to fetch
        register_date: Filter by registration date (YYYY-MM-DD)
        serial_number: Filter by serial number (partial search, min 3 chars)
        sort_order: Sort order for results
        status: Filter by device status
        sync_date: Filter by last sync date (YYYY-MM-DD)
        user: Filter by annotated user
        wifi_mac: Filter by WiFi MAC address (no colons)
    ### get_users
        query: Raw query string for advanced filtering
        domain: The domain name to filter users
        email: Search by email address
        email_prefix: Search by email prefix (e.g., admin*)
        family_name: Search by last name
        given_name: Search by first name
        is_admin: Filter by admin status
        is_archived: Filter by archived status
        is_delegated_admin: Filter by delegated admin status
        is_suspended: Filter by suspension status
        max_results: Maximum number of results to return (1-200)
        name: Search by name (given name, family name, or email)
        order_by: Field to order results by
        org_unit_path: Filter by organizational unit path
        projection: What subset of fields to fetch
        show_deleted: Include deleted users in results
        sort_order: Sort order for results
        view_type: View type for results
    ### get_groups
        query: Raw query string for advanced filtering
        domain: The domain name to filter users
        max_results: Maximum number of results to return (1-200)
        order_by: Field to order results by
        search_group_email: Search by group email
        search_group_name: Search by group name
        sort_order: Sort order for results
        user_key: Filter groups by user membership
    ### update_chromeos_device
        annotated_asset_id: The new annotated asset ID
        annotated_location: The new annotated location
        annotated_user: The new annotated user
        device_id: The unique identifier of the ChromeOS device
        notes: Filter by device notes
        org_unit_path: Filter by organizational unit path
    ### create_user
        change_password_at_next_login: Force user to change password on next login
        first_name: The first name of the user
        last_name: The last name of the user
        org_unit_path: Filter by organizational unit path
        password: The password for the user
        primary_email: The primary email address of the user
    ### update_user
        change_password_at_next_login: Force user to change password on next login
        first_name: The first name of the user
        last_name: The last name of the user
        org_unit_path: Filter by organizational unit path
        password: The password for the user
        primary_email: The primary email address of the user
        suspended: Whether to suspend the user
        user_id: The unique identifier or email of the user to delete
    ### change_chromeos_device_status
        deprovision_reason: Provide a reason for deprovisioning (only required if the Device Action is set to 'Deprovision')
        device_action: The action to perform on the device
        device_id: The unique identifier of the ChromeOS device
    ### create_group
        description: The description of the group
        group_email: The email address of the group
        group_name: The name of the group
    ### update_group
        description: The description of the group
        group_email: The email address of the group
        group_id: The unique identifier or email of the group
        group_name: The name of the group
    ### read_chromeos_device
        device_id: The unique identifier of the ChromeOS device
        projection: What subset of fields to fetch
    ### add_user_to_group
        group_id: The unique identifier or email of the group
        role: The role of the user in the group
        user_id: The unique identifier or email of the user to delete
    ### remove_user_from_group
        group_id: The unique identifier or email of the group
        user_id: The unique identifier or email of the user to delete
    ### delete_group
        group_id: The unique identifier or email of the group
    ### read_group
        group_id: The unique identifier or email of the group
    ### read_user
        projection: What subset of fields to fetch
        user_id: The unique identifier or email of the user to delete
    ### delete_user
        user_id: The unique identifier or email of the user to delete

    ## Outputs
    ### read_group
        admin_created: Whether the group was created by an admin
        description: The description of the group
        direct_members_count: The number of direct members in the group
        group_email: The email address of the group
        group_id: The unique identifier of the group
        group_name: The name of the group
        raw_data: Raw API response data
    ### update_chromeos_device
        annotated_asset_id: The annotated asset ID of the device
        annotated_location: The annotated location of the device
        annotated_user: The annotated user of the device
        device_id: The unique identifier of the device
        notes: The notes of the device
        org_unit_path: The organizational unit path of the device
        raw_data: Raw API response data
        serial_number: The serial number of the device
        status: The status of the device
    ### read_chromeos_device
        annotated_location: The annotated location of the device
        annotated_user: The annotated user of the device
        device_id: The unique identifier of the device
        last_sync: The last sync time of the device
        model: The model of the device
        org_unit_path: The organizational unit path of the device
        os_version: The OS version of the device
        raw_data: Raw API response data
        serial_number: The serial number of the device
        status: The status of the device
    ### read_user
        creation_time: The creation time of the user
        first_name: The first name of the user
        full_name: The full name of the user
        is_admin: Whether the user is an admin
        last_login_time: The last login time of the user
        last_name: The last name of the user
        org_unit_path: The organizational unit path of the user
        primary_email: The primary email address of the user
        raw_data: Raw API response data
        suspended: Whether the user is suspended
        user_id: The unique identifier of the user
    ### create_group
        description: The description of the created group
        direct_members_count: The number of direct members in the group
        group_email: The email address of the created group
        group_id: The unique identifier of the created group
        group_name: The name of the created group
        raw_data: Raw API response data
    ### update_group
        description: The description of the updated group
        direct_members_count: The number of direct members in the group
        group_email: The email address of the updated group
        group_id: The unique identifier of the updated group
        group_name: The name of the updated group
        raw_data: Raw API response data
    ### change_chromeos_device_status
        device_action: The action performed
        device_id: The ID of the device
        raw_data: Raw API response data
    ### get_chromeos_devices
        device_ids: List of device IDs
        models: List of device models
        org_unit_paths: List of organizational unit paths
        raw_data: Raw API response data
        serial_numbers: List of serial numbers
        statuses: List of device statuses
    ### add_user_to_group
        email: The email address of the user
        group_id: The ID of the group
        raw_data: Raw API response data
        role: The role assigned to the user
        user_id: The ID of the user
    ### create_user
        first_name: The first name of the created user
        full_name: The full name of the created user
        is_admin: Whether the user is an admin
        last_name: The last name of the created user
        org_unit_path: The organizational unit path of the user
        primary_email: The primary email address of the created user
        raw_data: Raw API response data
        suspended: Whether the user is suspended
        user_id: The unique identifier of the created user
    ### update_user
        first_name: The first name of the updated user
        full_name: The full name of the updated user
        is_admin: Whether the user is an admin
        last_name: The last name of the updated user
        org_unit_path: The organizational unit path of the user
        primary_email: The primary email address of the updated user
        raw_data: Raw API response data
        suspended: Whether the user is suspended
        user_id: The unique identifier of the updated user
    ### get_groups
        group_emails: List of group email addresses
        group_ids: List of group IDs
        group_names: List of group names
        raw_data: Raw API response data
    ### remove_user_from_group
        group_id: The ID of the group
        message: Success message
        user_id: The ID of the user
    ### delete_group
        group_id: The ID of the deleted group
        message: Success message
    ### delete_user
        message: Success message
        user_id: The ID of the deleted user
    ### get_users
        raw_data: Raw API response data
        user_emails: List of user email addresses
        user_ids: List of user IDs
        user_names: List of user names
    """

    # Common inputs and outputs
    _COMMON_INPUTS = [
        {
            "field": "action",
            "helper_text": "Select the action to perform",
            "value": "",
            "type": "string",
        },
        {
            "field": "integration",
            "helper_text": "Connect to your account",
            "value": None,
            "type": "integration<Google Workspace Admin>",
        },
    ]

    # Common outputs and inputs
    _COMMON_OUTPUTS = []

    # Configuration patterns and their associated inputs/outputs
    _CONFIGS = {
        "(*)": {"inputs": [], "outputs": [], "variant": "common_integration_nodes"},
        "read_chromeos_device": {
            "inputs": [
                {
                    "field": "device_id",
                    "type": "string",
                    "value": "",
                    "label": "Device ID",
                    "helper_text": "The unique identifier of the ChromeOS device",
                    "placeholder": "device-12345",
                },
                {
                    "field": "projection",
                    "type": "string",
                    "value": "basic",
                    "placeholder": "Basic",
                    "label": "Projection",
                    "helper_text": "What subset of fields to fetch",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Basic", "value": "basic"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "device_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the device",
                },
                {
                    "field": "serial_number",
                    "type": "string",
                    "helper_text": "The serial number of the device",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the device",
                },
                {
                    "field": "last_sync",
                    "type": "timestamp",
                    "helper_text": "The last sync time of the device",
                },
                {
                    "field": "model",
                    "type": "string",
                    "helper_text": "The model of the device",
                },
                {
                    "field": "os_version",
                    "type": "string",
                    "helper_text": "The OS version of the device",
                },
                {
                    "field": "annotated_user",
                    "type": "string",
                    "helper_text": "The annotated user of the device",
                },
                {
                    "field": "annotated_location",
                    "type": "string",
                    "helper_text": "The annotated location of the device",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "helper_text": "The organizational unit path of the device",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_chromeos_device",
            "task_name": "tasks.google_workspace_admin.read_chromeos_device",
            "description": "Read details of a specific ChromeOS device",
            "label": "Get ChromeOS Device",
            "inputs_sort_order": ["integration", "action", "device_id", "projection"],
            "required": ["device_id"],
        },
        "get_chromeos_devices": {
            "inputs": [
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "label": "Max Results",
                    "helper_text": "Maximum number of results to return (1-200)",
                    "placeholder": "10",
                },
                {
                    "field": "projection",
                    "type": "string",
                    "value": "basic",
                    "placeholder": "Basic",
                    "label": "Projection",
                    "helper_text": "What subset of fields to fetch",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Basic", "value": "basic"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "include_child_orgunits",
                    "type": "bool",
                    "value": False,
                    "label": "Include Child OrgUnits",
                    "helper_text": "Include devices from child organizational units",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "value": "",
                    "label": "Organization Unit Path",
                    "helper_text": "Filter by organizational unit path",
                    "placeholder": "/Sales/Marketing",
                },
                {
                    "field": "serial_number",
                    "type": "string",
                    "value": "",
                    "label": "Serial Number",
                    "helper_text": "Filter by serial number (partial search, min 3 chars)",
                    "placeholder": "ABC123",
                },
                {
                    "field": "status",
                    "type": "string",
                    "value": "",
                    "label": "Status",
                    "helper_text": "Filter by device status",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Provisioned", "value": "provisioned"},
                            {"label": "Disabled", "value": "disabled"},
                            {"label": "Deprovisioned", "value": "deprovisioned"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "user",
                    "type": "string",
                    "value": "",
                    "label": "User",
                    "helper_text": "Filter by annotated user",
                    "placeholder": "john.doe@company.com",
                },
                {
                    "field": "location",
                    "type": "string",
                    "value": "",
                    "label": "Location",
                    "helper_text": "Filter by annotated location",
                    "placeholder": "Building A, Floor 2",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Notes",
                    "helper_text": "Filter by device notes",
                    "placeholder": "Assigned to marketing",
                },
                {
                    "field": "asset_id",
                    "type": "string",
                    "value": "",
                    "label": "Asset ID",
                    "helper_text": "Filter by asset ID",
                    "placeholder": "ASSET-123",
                },
                {
                    "field": "wifi_mac",
                    "type": "string",
                    "value": "",
                    "label": "WiFi MAC Address",
                    "helper_text": "Filter by WiFi MAC address (no colons)",
                    "placeholder": "00aabbccddee",
                },
                {
                    "field": "ethernet_mac",
                    "type": "string",
                    "value": "",
                    "label": "Ethernet MAC Address",
                    "helper_text": "Filter by Ethernet MAC address (no colons)",
                    "placeholder": "00aabbccddee",
                },
                {
                    "field": "register_date",
                    "type": "string",
                    "value": "",
                    "label": "Register Date",
                    "helper_text": "Filter by registration date (YYYY-MM-DD)",
                    "placeholder": "2023-01-01",
                },
                {
                    "field": "sync_date",
                    "type": "string",
                    "value": "",
                    "label": "Sync Date",
                    "helper_text": "Filter by last sync date (YYYY-MM-DD)",
                    "placeholder": "2023-01-01",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "helper_text": "Raw query string for advanced filtering",
                    "placeholder": "id:ABC123 status:provisioned",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "helper_text": "Field to order results by",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {
                                "label": "Annotated Location",
                                "value": "annotatedLocation",
                            },
                            {"label": "Annotated User", "value": "annotatedUser"},
                            {"label": "Last Sync", "value": "lastSync"},
                            {"label": "Notes", "value": "notes"},
                            {"label": "Serial Number", "value": "serialNumber"},
                            {"label": "Status", "value": "status"},
                            {"label": "Support End Date", "value": "supportEndDate"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Ascending", "value": "ascending"},
                            {"label": "Descending", "value": "descending"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "device_ids",
                    "type": "vec<string>",
                    "helper_text": "List of device IDs",
                },
                {
                    "field": "serial_numbers",
                    "type": "vec<string>",
                    "helper_text": "List of serial numbers",
                },
                {
                    "field": "statuses",
                    "type": "vec<string>",
                    "helper_text": "List of device statuses",
                },
                {
                    "field": "models",
                    "type": "vec<string>",
                    "helper_text": "List of device models",
                },
                {
                    "field": "org_unit_paths",
                    "type": "vec<string>",
                    "helper_text": "List of organizational unit paths",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_chromeos_devices",
            "task_name": "tasks.google_workspace_admin.get_chromeos_devices",
            "description": "Get a list of ChromeOS devices with optional filtering",
            "label": "Get ChromeOS Devices",
            "ui_sort_order": [
                "integration",
                "action",
                "max_results",
                "projection",
                "include_child_orgunits",
                "org_unit_path",
                "serial_number",
                "status",
                "user",
                "location",
                "notes",
                "asset_id",
                "wifi_mac",
                "ethernet_mac",
                "register_date",
                "sync_date",
                "query",
                "order_by",
                "sort_order",
            ],
            "required": ["max_results"],
        },
        "update_chromeos_device": {
            "inputs": [
                {
                    "field": "device_id",
                    "type": "string",
                    "value": "",
                    "label": "Device ID",
                    "helper_text": "The unique identifier of the ChromeOS device",
                    "placeholder": "device-12345",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "value": "",
                    "label": "Organization Unit Path",
                    "helper_text": "The new organizational unit path",
                    "placeholder": "/Sales/Marketing",
                },
                {
                    "field": "annotated_user",
                    "type": "string",
                    "value": "",
                    "label": "Annotated User",
                    "helper_text": "The new annotated user",
                    "placeholder": "john.doe@company.com",
                },
                {
                    "field": "annotated_location",
                    "type": "string",
                    "value": "",
                    "label": "Annotated Location",
                    "helper_text": "The new annotated location",
                    "placeholder": "Building A, Floor 2",
                },
                {
                    "field": "annotated_asset_id",
                    "type": "string",
                    "value": "",
                    "label": "Annotated Asset ID",
                    "helper_text": "The new annotated asset ID",
                    "placeholder": "ASSET-123",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "value": "",
                    "label": "Notes",
                    "helper_text": "The new notes for the device",
                    "placeholder": "Assigned to marketing team",
                },
            ],
            "outputs": [
                {
                    "field": "device_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the device",
                },
                {
                    "field": "serial_number",
                    "type": "string",
                    "helper_text": "The serial number of the device",
                },
                {
                    "field": "status",
                    "type": "string",
                    "helper_text": "The status of the device",
                },
                {
                    "field": "annotated_user",
                    "type": "string",
                    "helper_text": "The annotated user of the device",
                },
                {
                    "field": "annotated_location",
                    "type": "string",
                    "helper_text": "The annotated location of the device",
                },
                {
                    "field": "annotated_asset_id",
                    "type": "string",
                    "helper_text": "The annotated asset ID of the device",
                },
                {
                    "field": "notes",
                    "type": "string",
                    "helper_text": "The notes of the device",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "helper_text": "The organizational unit path of the device",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_chromeos_device",
            "task_name": "tasks.google_workspace_admin.update_chromeos_device",
            "description": "Update a ChromeOS device",
            "label": "Update ChromeOS Device",
            "ui_sort_order": [
                "integration",
                "action",
                "device_id",
                "org_unit_path",
                "annotated_user",
                "annotated_location",
                "annotated_asset_id",
                "notes",
            ],
            "required": ["device_id"],
        },
        "change_chromeos_device_status": {
            "inputs": [
                {
                    "field": "device_id",
                    "type": "string",
                    "value": "",
                    "label": "Device ID",
                    "helper_text": "The unique identifier of the ChromeOS device",
                    "placeholder": "device-12345",
                },
                {
                    "field": "device_action",
                    "type": "string",
                    "value": "",
                    "label": "Device Action",
                    "helper_text": "The action to perform on the device",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Disable", "value": "disable"},
                            {"label": "Re-enable", "value": "reenable"},
                            {"label": "Deprovision", "value": "deprovision"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "deprovision_reason",
                    "type": "string",
                    "value": "",
                    "label": "Deprovision Reason",
                    "helper_text": "Provide a reason for deprovisioning (only required if the Device Action is set to 'Deprovision')",
                    "placeholder": "Device lost or stolen",
                },
            ],
            "outputs": [
                {
                    "field": "device_id",
                    "type": "string",
                    "helper_text": "The ID of the device",
                },
                {
                    "field": "device_action",
                    "type": "string",
                    "helper_text": "The action performed",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "change_chromeos_device_status",
            "task_name": "tasks.google_workspace_admin.change_chromeos_device_status",
            "description": "Change the status of a ChromeOS device",
            "label": "Change ChromeOS Device Status",
            "ui_sort_order": [
                "integration",
                "action",
                "device_id",
                "device_action",
                "deprovision_reason",
            ],
            "required": ["device_id", "device_action"],
        },
        "create_user": {
            "inputs": [
                {
                    "field": "primary_email",
                    "type": "string",
                    "value": "",
                    "label": "Primary Email",
                    "helper_text": "The primary email address of the user",
                    "placeholder": "user@company.com",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "helper_text": "The first name of the user",
                    "placeholder": "John",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "helper_text": "The last name of the user",
                    "placeholder": "Doe",
                },
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "helper_text": "The password for the user",
                    "placeholder": "SecurePassword123!",
                },
                {
                    "field": "change_password_at_next_login",
                    "type": "bool",
                    "value": False,
                    "label": "Change Password at Next Login",
                    "helper_text": "Force user to change password on next login",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "value": "",
                    "label": "Organization Unit Path",
                    "helper_text": "The organizational unit path for the user",
                    "placeholder": "/Sales/Marketing",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the created user",
                },
                {
                    "field": "primary_email",
                    "type": "string",
                    "helper_text": "The primary email address of the created user",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "helper_text": "The full name of the created user",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "The first name of the created user",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "The last name of the created user",
                },
                {
                    "field": "is_admin",
                    "type": "bool",
                    "helper_text": "Whether the user is an admin",
                },
                {
                    "field": "suspended",
                    "type": "bool",
                    "helper_text": "Whether the user is suspended",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "helper_text": "The organizational unit path of the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_user",
            "task_name": "tasks.google_workspace_admin.create_user",
            "description": "Create a new user in Google Workspace",
            "label": "Create User",
            "ui_sort_order": [
                "integration",
                "action",
                "primary_email",
                "first_name",
                "last_name",
                "password",
                "change_password_at_next_login",
                "org_unit_path",
            ],
            "required": ["primary_email", "first_name", "last_name", "password"],
        },
        "delete_user": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "helper_text": "The unique identifier or email of the user to delete",
                    "placeholder": "user@company.com",
                }
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The ID of the deleted user",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "delete_user",
            "task_name": "tasks.google_workspace_admin.delete_user",
            "description": "Delete a user from Google Workspace",
            "label": "Delete User",
            "ui_sort_order": ["integration", "action", "user_id"],
            "required": ["user_id"],
        },
        "read_user": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "helper_text": "The unique identifier or email of the user to read",
                    "placeholder": "user@company.com",
                },
                {
                    "field": "projection",
                    "type": "string",
                    "value": "basic",
                    "placeholder": "Basic",
                    "label": "Projection",
                    "helper_text": "What subset of fields to fetch",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Basic", "value": "basic"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the user",
                },
                {
                    "field": "primary_email",
                    "type": "string",
                    "helper_text": "The primary email address of the user",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "helper_text": "The full name of the user",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "The first name of the user",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "The last name of the user",
                },
                {
                    "field": "is_admin",
                    "type": "bool",
                    "helper_text": "Whether the user is an admin",
                },
                {
                    "field": "suspended",
                    "type": "bool",
                    "helper_text": "Whether the user is suspended",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "helper_text": "The organizational unit path of the user",
                },
                {
                    "field": "last_login_time",
                    "type": "timestamp",
                    "helper_text": "The last login time of the user",
                },
                {
                    "field": "creation_time",
                    "type": "timestamp",
                    "helper_text": "The creation time of the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_user",
            "task_name": "tasks.google_workspace_admin.read_user",
            "description": "Read details of a specific user",
            "label": "Get User",
            "inputs_sort_order": ["integration", "action", "user_id", "projection"],
            "required": ["user_id"],
        },
        "get_users": {
            "inputs": [
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "label": "Max Results",
                    "helper_text": "Maximum number of results to return",
                    "placeholder": "10",
                },
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "helper_text": "The domain name to filter users",
                    "placeholder": "company.com",
                },
                {
                    "field": "name",
                    "type": "string",
                    "value": "",
                    "label": "Name",
                    "helper_text": "Search by name (given name, family name, or email)",
                    "placeholder": "John Doe",
                },
                {
                    "field": "email",
                    "type": "string",
                    "value": "",
                    "label": "Email",
                    "helper_text": "Search by email address",
                    "placeholder": "user@company.com",
                },
                {
                    "field": "email_prefix",
                    "type": "string",
                    "value": "",
                    "label": "Email Prefix",
                    "helper_text": "Search by email prefix (e.g., admin*)",
                    "placeholder": "admin",
                },
                {
                    "field": "given_name",
                    "type": "string",
                    "value": "",
                    "label": "Given Name",
                    "helper_text": "Search by first name",
                    "placeholder": "John",
                },
                {
                    "field": "family_name",
                    "type": "string",
                    "value": "",
                    "label": "Family Name",
                    "helper_text": "Search by last name",
                    "placeholder": "Doe",
                },
                {
                    "field": "is_admin",
                    "type": "bool",
                    "value": False,
                    "label": "Is Admin",
                    "helper_text": "Filter by admin status",
                },
                {
                    "field": "is_delegated_admin",
                    "type": "bool",
                    "value": False,
                    "label": "Is Delegated Admin",
                    "helper_text": "Filter by delegated admin status",
                },
                {
                    "field": "is_suspended",
                    "type": "bool",
                    "value": False,
                    "label": "Is Suspended",
                    "helper_text": "Filter by suspension status",
                },
                {
                    "field": "is_archived",
                    "type": "bool",
                    "value": False,
                    "label": "Is Archived",
                    "helper_text": "Filter by archived status",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "value": "",
                    "label": "Organization Unit Path",
                    "helper_text": "Filter by organizational unit path",
                    "placeholder": "/Sales/Marketing",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "helper_text": "Raw query string for advanced filtering",
                    "placeholder": "name:John orgUnitPath:/Sales",
                },
                {
                    "field": "show_deleted",
                    "type": "bool",
                    "value": False,
                    "label": "Show Deleted",
                    "helper_text": "Include deleted users in results",
                },
                {
                    "field": "projection",
                    "type": "string",
                    "value": "basic",
                    "placeholder": "Basic",
                    "label": "Projection",
                    "helper_text": "What subset of fields to fetch",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Basic", "value": "basic"},
                            {"label": "Full", "value": "full"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "helper_text": "Field to order results by",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Email", "value": "email"},
                            {"label": "Given Name", "value": "givenName"},
                            {"label": "Family Name", "value": "familyName"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Ascending", "value": "ascending"},
                            {"label": "Descending", "value": "descending"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "view_type",
                    "type": "string",
                    "value": "",
                    "label": "View Type",
                    "helper_text": "View type for results",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Admin View", "value": "admin_view"},
                            {"label": "Domain Public", "value": "domain_public"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_ids",
                    "type": "vec<string>",
                    "helper_text": "List of user IDs",
                },
                {
                    "field": "user_emails",
                    "type": "vec<string>",
                    "helper_text": "List of user email addresses",
                },
                {
                    "field": "user_names",
                    "type": "vec<string>",
                    "helper_text": "List of user names",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_users",
            "task_name": "tasks.google_workspace_admin.get_users",
            "description": "Get multiple users",
            "label": "List Users",
            "inputs_sort_order": [
                "integration",
                "action",
                "max_results",
                "domain",
                "name",
                "email",
                "email_prefix",
                "given_name",
                "family_name",
                "is_admin",
                "is_delegated_admin",
                "is_suspended",
                "is_archived",
                "org_unit_path",
                "query",
                "show_deleted",
                "projection",
                "order_by",
                "sort_order",
                "view_type",
            ],
            "required": ["max_results"],
        },
        "update_user": {
            "inputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "helper_text": "The unique identifier or email of the user to update",
                    "placeholder": "user@company.com",
                },
                {
                    "field": "primary_email",
                    "type": "string",
                    "value": "",
                    "label": "Primary Email",
                    "helper_text": "The new primary email address",
                    "placeholder": "newuser@company.com",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "value": "",
                    "label": "First Name",
                    "helper_text": "The new first name",
                    "placeholder": "John",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "value": "",
                    "label": "Last Name",
                    "helper_text": "The new last name",
                    "placeholder": "Doe",
                },
                {
                    "field": "suspended",
                    "type": "bool",
                    "value": False,
                    "label": "Suspended",
                    "helper_text": "Whether to suspend the user",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "value": "",
                    "label": "Organization Unit Path",
                    "helper_text": "The new organizational unit path",
                    "placeholder": "/Sales/Marketing",
                },
                {
                    "field": "password",
                    "type": "string",
                    "value": "",
                    "label": "Password",
                    "helper_text": "The new password for the user",
                    "placeholder": "NewSecurePassword123!",
                },
                {
                    "field": "change_password_at_next_login",
                    "type": "bool",
                    "value": False,
                    "label": "Change Password at Next Login",
                    "helper_text": "Force user to change password on next login",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the updated user",
                },
                {
                    "field": "primary_email",
                    "type": "string",
                    "helper_text": "The primary email address of the updated user",
                },
                {
                    "field": "full_name",
                    "type": "string",
                    "helper_text": "The full name of the updated user",
                },
                {
                    "field": "first_name",
                    "type": "string",
                    "helper_text": "The first name of the updated user",
                },
                {
                    "field": "last_name",
                    "type": "string",
                    "helper_text": "The last name of the updated user",
                },
                {
                    "field": "is_admin",
                    "type": "bool",
                    "helper_text": "Whether the user is an admin",
                },
                {
                    "field": "suspended",
                    "type": "bool",
                    "helper_text": "Whether the user is suspended",
                },
                {
                    "field": "org_unit_path",
                    "type": "string",
                    "helper_text": "The organizational unit path of the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_user",
            "task_name": "tasks.google_workspace_admin.update_user",
            "description": "Update an existing user",
            "label": "Update User",
            "ui_sort_order": [
                "integration",
                "action",
                "user_id",
                "primary_email",
                "first_name",
                "last_name",
                "suspended",
                "org_unit_path",
                "password",
                "change_password_at_next_login",
            ],
            "required": ["user_id"],
        },
        "add_user_to_group": {
            "inputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "value": "",
                    "label": "Group ID",
                    "helper_text": "The unique identifier or email of the group",
                    "placeholder": "group@company.com",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "helper_text": "The unique identifier or email of the user",
                    "placeholder": "user@company.com",
                },
                {
                    "field": "role",
                    "type": "string",
                    "value": "member",
                    "label": "Role",
                    "helper_text": "The role of the user in the group",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Member", "value": "member"},
                            {"label": "Manager", "value": "manager"},
                            {"label": "Owner", "value": "owner"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The ID of the user",
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "The ID of the group",
                },
                {
                    "field": "role",
                    "type": "string",
                    "helper_text": "The role assigned to the user",
                },
                {
                    "field": "email",
                    "type": "string",
                    "helper_text": "The email address of the user",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "add_user_to_group",
            "task_name": "tasks.google_workspace_admin.add_user_to_group",
            "description": "Add a user to a group",
            "label": "Add User to Group",
            "ui_sort_order": ["integration", "action", "group_id", "user_id", "role"],
            "required": ["group_id", "user_id"],
        },
        "remove_user_from_group": {
            "inputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "value": "",
                    "label": "Group ID",
                    "helper_text": "The unique identifier or email of the group",
                    "placeholder": "group@company.com",
                },
                {
                    "field": "user_id",
                    "type": "string",
                    "value": "",
                    "label": "User ID",
                    "helper_text": "The unique identifier or email of the user",
                    "placeholder": "user@company.com",
                },
            ],
            "outputs": [
                {
                    "field": "user_id",
                    "type": "string",
                    "helper_text": "The ID of the user",
                },
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "The ID of the group",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "remove_user_from_group",
            "task_name": "tasks.google_workspace_admin.remove_user_from_group",
            "description": "Remove a user from a group",
            "label": "Remove User from Group",
            "ui_sort_order": ["integration", "action", "group_id", "user_id"],
            "required": ["group_id", "user_id"],
        },
        "create_group": {
            "inputs": [
                {
                    "field": "group_email",
                    "type": "string",
                    "value": "",
                    "label": "Group Email",
                    "helper_text": "The email address of the group",
                    "placeholder": "team@company.com",
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "value": "",
                    "label": "Group Name",
                    "helper_text": "The name of the group",
                    "placeholder": "Marketing Team",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "The description of the group",
                    "placeholder": "Marketing team for product campaigns",
                },
            ],
            "outputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the created group",
                },
                {
                    "field": "group_email",
                    "type": "string",
                    "helper_text": "The email address of the created group",
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "helper_text": "The name of the created group",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The description of the created group",
                },
                {
                    "field": "direct_members_count",
                    "type": "string",
                    "helper_text": "The number of direct members in the group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "create_group",
            "task_name": "tasks.google_workspace_admin.create_group",
            "description": "Create a new group in Google Workspace",
            "label": "Create Group",
            "ui_sort_order": [
                "integration",
                "action",
                "group_email",
                "group_name",
                "description",
            ],
            "required": ["group_email", "group_name"],
        },
        "delete_group": {
            "inputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "value": "",
                    "label": "Group ID",
                    "helper_text": "The unique identifier or email of the group to delete",
                    "placeholder": "group@company.com",
                }
            ],
            "outputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "The ID of the deleted group",
                },
                {
                    "field": "message",
                    "type": "string",
                    "helper_text": "Success message",
                },
            ],
            "name": "delete_group",
            "task_name": "tasks.google_workspace_admin.delete_group",
            "description": "Delete a group from Google Workspace",
            "label": "Delete Group",
            "ui_sort_order": ["integration", "action", "group_id"],
            "required": ["group_id"],
        },
        "read_group": {
            "inputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "value": "",
                    "label": "Group ID",
                    "helper_text": "The unique identifier or email of the group to read",
                    "placeholder": "group@company.com",
                }
            ],
            "outputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the group",
                },
                {
                    "field": "group_email",
                    "type": "string",
                    "helper_text": "The email address of the group",
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "helper_text": "The name of the group",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The description of the group",
                },
                {
                    "field": "direct_members_count",
                    "type": "string",
                    "helper_text": "The number of direct members in the group",
                },
                {
                    "field": "admin_created",
                    "type": "bool",
                    "helper_text": "Whether the group was created by an admin",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "read_group",
            "task_name": "tasks.google_workspace_admin.read_group",
            "description": "Read details of a specific group",
            "label": "Get Group",
            "inputs_sort_order": ["integration", "action", "group_id"],
            "required": ["group_id"],
        },
        "get_groups": {
            "inputs": [
                {
                    "field": "max_results",
                    "type": "int32",
                    "value": 10,
                    "label": "Max Results",
                    "helper_text": "Maximum number of results to return (1-200)",
                    "placeholder": "10",
                },
                {
                    "field": "domain",
                    "type": "string",
                    "value": "",
                    "label": "Domain",
                    "helper_text": "The domain name to filter groups",
                    "placeholder": "company.com",
                },
                {
                    "field": "user_key",
                    "type": "string",
                    "value": "",
                    "label": "User Key",
                    "helper_text": "Filter groups by user membership",
                    "placeholder": "user@company.com",
                },
                {
                    "field": "search_group_name",
                    "type": "string",
                    "value": "",
                    "label": "Group Name",
                    "helper_text": "Search by group name",
                    "placeholder": "Marketing Team",
                },
                {
                    "field": "search_group_email",
                    "type": "string",
                    "value": "",
                    "label": "Group Email",
                    "helper_text": "Search by group email",
                    "placeholder": "team@company.com",
                },
                {
                    "field": "query",
                    "type": "string",
                    "value": "",
                    "label": "Raw Query",
                    "helper_text": "Raw query string for advanced filtering",
                    "placeholder": "name:Marketing email:team@company.com",
                },
                {
                    "field": "order_by",
                    "type": "string",
                    "value": "",
                    "label": "Order By",
                    "helper_text": "Field to order results by",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Email", "value": "email"},
                            {"label": "Name", "value": "name"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
                {
                    "field": "sort_order",
                    "type": "string",
                    "value": "",
                    "label": "Sort Order",
                    "helper_text": "Sort order for results",
                    "component": {
                        "type": "dropdown",
                        "options": [
                            {"label": "Ascending", "value": "ascending"},
                            {"label": "Descending", "value": "descending"},
                        ],
                        "agent_field_type": "dynamic",
                    },
                },
            ],
            "outputs": [
                {
                    "field": "group_ids",
                    "type": "vec<string>",
                    "helper_text": "List of group IDs",
                },
                {
                    "field": "group_emails",
                    "type": "vec<string>",
                    "helper_text": "List of group email addresses",
                },
                {
                    "field": "group_names",
                    "type": "vec<string>",
                    "helper_text": "List of group names",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "get_groups",
            "task_name": "tasks.google_workspace_admin.get_groups",
            "description": "Get multiple groups",
            "label": "List Groups",
            "inputs_sort_order": [
                "integration",
                "action",
                "max_results",
                "domain",
                "user_key",
                "search_group_name",
                "search_group_email",
                "query",
                "order_by",
                "sort_order",
            ],
            "required": ["max_results"],
        },
        "update_group": {
            "inputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "value": "",
                    "label": "Group ID",
                    "helper_text": "The unique identifier or email of the group to update",
                    "placeholder": "group@company.com",
                },
                {
                    "field": "group_email",
                    "type": "string",
                    "value": "",
                    "label": "Group Email",
                    "helper_text": "The new email address of the group",
                    "placeholder": "newteam@company.com",
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "value": "",
                    "label": "Group Name",
                    "helper_text": "The new name of the group",
                    "placeholder": "New Marketing Team",
                },
                {
                    "field": "description",
                    "type": "string",
                    "value": "",
                    "label": "Description",
                    "helper_text": "The new description of the group",
                    "placeholder": "Updated marketing team description",
                },
            ],
            "outputs": [
                {
                    "field": "group_id",
                    "type": "string",
                    "helper_text": "The unique identifier of the updated group",
                },
                {
                    "field": "group_email",
                    "type": "string",
                    "helper_text": "The email address of the updated group",
                },
                {
                    "field": "group_name",
                    "type": "string",
                    "helper_text": "The name of the updated group",
                },
                {
                    "field": "description",
                    "type": "string",
                    "helper_text": "The description of the updated group",
                },
                {
                    "field": "direct_members_count",
                    "type": "string",
                    "helper_text": "The number of direct members in the group",
                },
                {
                    "field": "raw_data",
                    "type": "string",
                    "helper_text": "Raw API response data",
                },
            ],
            "name": "update_group",
            "task_name": "tasks.google_workspace_admin.update_group",
            "description": "Update an existing group",
            "label": "Update Group",
            "ui_sort_order": [
                "integration",
                "action",
                "group_id",
                "group_email",
                "group_name",
                "description",
            ],
            "required": ["group_id"],
        },
    }

    # List of parameters that affect configuration
    _PARAMS = ["action"]

    _batch_mode_allowed = True

    _REQUIRED_FIELDS = ["integration", "action"]

    def __init__(
        self,
        action: str = "",
        query: str = "",
        annotated_asset_id: str = "",
        annotated_location: str = "",
        annotated_user: str = "",
        asset_id: str = "",
        change_password_at_next_login: bool = False,
        deprovision_reason: str = "",
        description: str = "",
        device_action: str = "",
        device_id: str = "",
        domain: str = "",
        email: str = "",
        email_prefix: str = "",
        ethernet_mac: str = "",
        family_name: str = "",
        first_name: str = "",
        given_name: str = "",
        group_email: str = "",
        group_id: str = "",
        group_name: str = "",
        include_child_orgunits: bool = False,
        is_admin: bool = False,
        is_archived: bool = False,
        is_delegated_admin: bool = False,
        is_suspended: bool = False,
        last_name: str = "",
        location: str = "",
        max_results: int = 10,
        name: str = "",
        notes: str = "",
        order_by: str = "",
        org_unit_path: str = "",
        password: str = "",
        primary_email: str = "",
        projection: str = "basic",
        register_date: str = "",
        role: str = "member",
        search_group_email: str = "",
        search_group_name: str = "",
        serial_number: str = "",
        show_deleted: bool = False,
        sort_order: str = "",
        status: str = "",
        suspended: bool = False,
        sync_date: str = "",
        user: str = "",
        user_id: str = "",
        user_key: str = "",
        view_type: str = "",
        wifi_mac: str = "",
        dependencies: Optional[List[str]] = None,
        node_name: str = None,
        id: str = None,
        execution_mode: str = None,
        integration: Optional[Any] = None,
        **kwargs
    ):
        # Initialize with params
        params = {}
        params["action"] = action

        super().__init__(
            node_type="integration_google_workspace_admin",
            params=params,
            id=id,
            node_name=node_name,
            execution_mode=execution_mode,
        )

        # Set input values
        if action is not None:
            self.inputs["action"] = action
        if integration is not None:
            self.inputs["integration"] = integration
        if device_id is not None:
            self.inputs["device_id"] = device_id
        if projection is not None:
            self.inputs["projection"] = projection
        if max_results is not None:
            self.inputs["max_results"] = max_results
        if include_child_orgunits is not None:
            self.inputs["include_child_orgunits"] = include_child_orgunits
        if org_unit_path is not None:
            self.inputs["org_unit_path"] = org_unit_path
        if serial_number is not None:
            self.inputs["serial_number"] = serial_number
        if status is not None:
            self.inputs["status"] = status
        if user is not None:
            self.inputs["user"] = user
        if location is not None:
            self.inputs["location"] = location
        if notes is not None:
            self.inputs["notes"] = notes
        if asset_id is not None:
            self.inputs["asset_id"] = asset_id
        if wifi_mac is not None:
            self.inputs["wifi_mac"] = wifi_mac
        if ethernet_mac is not None:
            self.inputs["ethernet_mac"] = ethernet_mac
        if register_date is not None:
            self.inputs["register_date"] = register_date
        if sync_date is not None:
            self.inputs["sync_date"] = sync_date
        if query is not None:
            self.inputs["query"] = query
        if order_by is not None:
            self.inputs["order_by"] = order_by
        if sort_order is not None:
            self.inputs["sort_order"] = sort_order
        if annotated_user is not None:
            self.inputs["annotated_user"] = annotated_user
        if annotated_location is not None:
            self.inputs["annotated_location"] = annotated_location
        if annotated_asset_id is not None:
            self.inputs["annotated_asset_id"] = annotated_asset_id
        if device_action is not None:
            self.inputs["device_action"] = device_action
        if deprovision_reason is not None:
            self.inputs["deprovision_reason"] = deprovision_reason
        if primary_email is not None:
            self.inputs["primary_email"] = primary_email
        if first_name is not None:
            self.inputs["first_name"] = first_name
        if last_name is not None:
            self.inputs["last_name"] = last_name
        if password is not None:
            self.inputs["password"] = password
        if change_password_at_next_login is not None:
            self.inputs["change_password_at_next_login"] = change_password_at_next_login
        if user_id is not None:
            self.inputs["user_id"] = user_id
        if domain is not None:
            self.inputs["domain"] = domain
        if name is not None:
            self.inputs["name"] = name
        if email is not None:
            self.inputs["email"] = email
        if email_prefix is not None:
            self.inputs["email_prefix"] = email_prefix
        if given_name is not None:
            self.inputs["given_name"] = given_name
        if family_name is not None:
            self.inputs["family_name"] = family_name
        if is_admin is not None:
            self.inputs["is_admin"] = is_admin
        if is_delegated_admin is not None:
            self.inputs["is_delegated_admin"] = is_delegated_admin
        if is_suspended is not None:
            self.inputs["is_suspended"] = is_suspended
        if is_archived is not None:
            self.inputs["is_archived"] = is_archived
        if show_deleted is not None:
            self.inputs["show_deleted"] = show_deleted
        if view_type is not None:
            self.inputs["view_type"] = view_type
        if suspended is not None:
            self.inputs["suspended"] = suspended
        if group_id is not None:
            self.inputs["group_id"] = group_id
        if role is not None:
            self.inputs["role"] = role
        if group_email is not None:
            self.inputs["group_email"] = group_email
        if group_name is not None:
            self.inputs["group_name"] = group_name
        if description is not None:
            self.inputs["description"] = description
        if user_key is not None:
            self.inputs["user_key"] = user_key
        if search_group_name is not None:
            self.inputs["search_group_name"] = search_group_name
        if search_group_email is not None:
            self.inputs["search_group_email"] = search_group_email
        if dependencies is not None:
            self.inputs["dependencies"] = dependencies
        if integration is not None:
            self.inputs["integration"] = integration

        # Update any additional inputs
        if kwargs:
            self.update_inputs(**kwargs)
        self.set_node_task_name()
        self.set_output_name_attributes()
        self._check_visibility_warnings()

    @classmethod
    def from_dict(cls, data: dict) -> "IntegrationGoogleWorkspaceAdminNode":
        """Create a node instance from a dictionary."""
        inputs = data.get("inputs", {})
        id = data.get("id", None)
        name = data.get("name", None)
        execution_mode = data.get("execution_mode", None)
        return cls(**inputs, id=id, node_name=name, execution_mode=execution_mode)
