"""
Generator for TypedDict classes from TOML interface type definitions.

Scans pipeline_node.toml for all interface{...} type patterns and
generates vectorshift/pipeline/interface_types.py with TypedDict classes
that give users proper type safety and IDE autocomplete.
"""

import re
from pathlib import Path
from typing import Any


def parse_interface_fields(
    interface_str: str,
) -> list[tuple[str, str]]:
    """Parse interface{field1: type1, field2: type2} into field-type pairs.

    Handles nested interface{} and generic <> depth correctly.
    """
    fields_str = interface_str[10:-1]
    fields: list[tuple[str, str]] = []

    depth = 0
    current = ''
    for char in fields_str:
        if char in '<{':
            depth += 1
        elif char in '>}':
            depth -= 1
        if char == ',' and depth == 0:
            parts = current.split(':', 1)
            if len(parts) == 2:
                fields.append((parts[0].strip(), parts[1].strip()))
            current = ''
        else:
            current += char

    if current.strip():
        parts = current.split(':', 1)
        if len(parts) == 2:
            fields.append((parts[0].strip(), parts[1].strip()))

    return fields


def _canonical_key(
    interface_str: str,
) -> tuple[tuple[str, str], ...]:
    """Produce a canonical hashable key from an interface type string."""
    fields = parse_interface_fields(interface_str)
    return tuple((n, t) for n, t in fields)


def _extract_interface_types(type_str: str) -> list[str]:
    """Extract all interface{...} type strings from a compound type string."""
    results: list[str] = []

    if type_str.startswith('vec<') and type_str.endswith('>'):
        inner = type_str[4:-1]
        results.extend(_extract_interface_types(inner))
    elif type_str.startswith('interface{') and type_str.endswith('}'):
        results.append(type_str)
        fields = parse_interface_fields(type_str)
        for _, field_type in fields:
            results.extend(_extract_interface_types(field_type))
    return results


def _collect_type_strings(obj: Any) -> set[str]:
    """Recursively collect all 'type' field values from a TOML config."""
    types: set[str] = set()
    if isinstance(obj, dict):
        for key, val in obj.items():
            if key == 'type' and isinstance(val, str):
                types.add(val)
            else:
                types.update(_collect_type_strings(val))
    elif isinstance(obj, list):
        for item in obj:
            types.update(_collect_type_strings(item))
    return types


def _snake_to_pascal(name: str) -> str:
    """Convert a snake_case or camelCase name to PascalCase."""
    if '_' in name:
        return ''.join(part.capitalize() for part in name.split('_'))
    return name[0].upper() + name[1:] if name else name


def _field_type_to_python(
    toml_type: str,
    interface_name_map: dict[tuple[tuple[str, str], ...], str],
) -> str:
    """Convert a TOML field type to a Python type annotation string."""
    if toml_type == 'string':
        return 'str'
    if toml_type in ('int32', 'int64'):
        return 'int'
    if toml_type in ('float', 'float32', 'float64'):
        return 'float'
    if toml_type == 'bool':
        return 'bool'
    if toml_type in ('file', 'image', 'audio'):
        return 'str'
    if toml_type.startswith('vec<') and toml_type.endswith('>'):
        inner = toml_type[4:-1]
        inner_py = _field_type_to_python(inner, interface_name_map)
        return f'List[{inner_py}]'
    if toml_type.startswith('map<'):
        return 'Dict[str, Any]'
    if toml_type.startswith('interface{') and toml_type.endswith('}'):
        canonical = _canonical_key(toml_type)
        if canonical in interface_name_map:
            return interface_name_map[canonical]
        return 'Dict[str, Any]'
    if toml_type.startswith('enum<') and toml_type.endswith('>'):
        inner = toml_type[5:-1]
        return _field_type_to_python(inner, interface_name_map)
    return 'Any'


_NAME_OVERRIDES: dict[frozenset[str], str] = {
    frozenset(
        {
            'contact_id',
            'given_name',
            'family_name',
            'display_name',
            'contact_name',
            'full_name',
            'email',
            'phone',
            'organization',
            'etag',
        }
    ): 'ContactRecord',
    frozenset(
        {
            'id',
            'title',
            'description',
            'image_url',
            'button',
        }
    ): 'CarouselCard',
    frozenset(
        {
            'id',
            'name',
            'url',
            'actionType',
        }
    ): 'CardButton',
    frozenset(
        {
            'id',
            'column_name',
            'column_value',
        }
    ): 'ColumnEntry',
    frozenset(
        {
            'date_type',
            'date_value',
            'date_period',
        }
    ): 'DateRange',
    frozenset(
        {
            'start',
            'end',
        }
    ): 'TimeRange',
    frozenset(
        {
            'id',
            'field',
            'description',
            'example',
        }
    ): 'FieldDefinition',
    frozenset(
        {
            'operators',
            'terms',
        }
    ): 'ConditionGroup',
}


def _generate_base_name(
    fields: list[tuple[str, str]],
) -> str:
    """Generate a base TypedDict class name from field names."""
    field_names = frozenset(n for n, _ in fields)
    if field_names in _NAME_OVERRIDES:
        return _NAME_OVERRIDES[field_names]

    non_id_fields = [(n, t) for n, t in fields if n != 'id']
    if not non_id_fields:
        return 'IdItem'

    parts = [_snake_to_pascal(n) for n, _ in non_id_fields]

    if len(parts) == 1:
        return parts[0] + 'Item'
    return ''.join(parts)


_TYPE_PREFIX_MAP = {
    'file': 'File',
    'image': 'Image',
    'audio': 'Audio',
}


def _type_modifier(toml_type: str) -> str:
    """Get a modifier string to disambiguate colliding names by type."""
    if toml_type in _TYPE_PREFIX_MAP:
        return _TYPE_PREFIX_MAP[toml_type]
    if toml_type.startswith('vec<'):
        return 'List'
    if toml_type.startswith('map<'):
        return 'Map'
    return ''


def _resolve_collisions(
    shapes: list[tuple[tuple[tuple[str, str], ...], str]],
) -> dict[tuple[tuple[str, str], ...], str]:
    """Assign unique names, resolving collisions by adding type modifiers."""
    name_groups: dict[str, list[tuple[tuple[str, str], ...], ...]] = {}
    for canonical, base_name in shapes:
        name_groups.setdefault(base_name, []).append(canonical)

    result: dict[tuple[tuple[str, str], ...], str] = {}

    for base_name, canonicals in name_groups.items():
        if len(canonicals) == 1:
            result[canonicals[0]] = base_name
            continue

        fields_lists = [dict(c) for c in canonicals]
        all_field_names = set()
        for fl in fields_lists:
            all_field_names.update(fl.keys())

        differing_field = None
        for fname in all_field_names:
            types_for_field = {fl.get(fname, '') for fl in fields_lists}
            if len(types_for_field) > 1:
                differing_field = fname
                break

        if differing_field is None:
            for i, canonical in enumerate(canonicals):
                suffix = str(i + 1) if i > 0 else ''
                result[canonical] = base_name + suffix
            continue

        string_canonical = None
        for canonical, fl in zip(canonicals, fields_lists):
            if fl.get(differing_field) == 'string':
                string_canonical = canonical
                break

        for canonical, fl in zip(canonicals, fields_lists):
            if canonical == string_canonical:
                result[canonical] = base_name
            else:
                modifier = _type_modifier(fl.get(differing_field, ''))
                if modifier:
                    result[canonical] = modifier + base_name
                else:
                    result[canonical] = base_name + _snake_to_pascal(
                        fl.get(differing_field, 'Variant')
                    )

    return result


def collect_interface_types(
    config: dict[str, Any],
) -> dict[tuple[tuple[str, str], ...], str]:
    """Scan TOML config and return a mapping of canonical keys to class names.

    Returns:
        dict mapping canonical field tuples to TypedDict class names.
    """
    type_strings = _collect_type_strings(config)

    all_interfaces: set[str] = set()
    for ts in type_strings:
        all_interfaces.update(_extract_interface_types(ts))

    if not all_interfaces:
        return {}

    seen: dict[tuple[tuple[str, str], ...], str] = {}
    shapes: list[tuple[tuple[tuple[str, str], ...], str]] = []

    for iface_str in all_interfaces:
        canonical = _canonical_key(iface_str)
        if canonical in seen:
            continue
        fields = list(canonical)
        base_name = _generate_base_name(fields)
        seen[canonical] = base_name
        shapes.append((canonical, base_name))

    return _resolve_collisions(shapes)


def get_typeddict_name(
    type_str: str,
    interface_map: dict[tuple[tuple[str, str], ...], str],
) -> str | None:
    """Look up the TypedDict class name for an interface type string.

    Returns the class name if found, None for bare interface types.
    """
    if not (type_str.startswith('interface{') and type_str.endswith('}')):
        return None
    canonical = _canonical_key(type_str)
    return interface_map.get(canonical)


def _dependency_order(
    interface_map: dict[tuple[tuple[str, str], ...], str],
) -> list[tuple[tuple[tuple[str, str], ...], str]]:
    """Sort TypedDicts so nested ones come before their parents."""
    ordered: list[tuple[tuple[tuple[str, str], ...], str]] = []
    visited: set[tuple[tuple[str, str], ...]] = set()

    def visit(canonical: tuple[tuple[str, str], ...]) -> None:
        if canonical in visited:
            return
        visited.add(canonical)
        for _, field_type in canonical:
            if field_type.startswith('interface{') and field_type.endswith('}'):
                dep_key = _canonical_key(field_type)
                if dep_key in interface_map:
                    visit(dep_key)
        ordered.append((canonical, interface_map[canonical]))

    for canonical in sorted(interface_map.keys(), key=lambda c: interface_map[c]):
        visit(canonical)

    return ordered


def generate_interface_types_file(
    config: dict[str, Any],
    output_path: str,
) -> dict[tuple[tuple[str, str], ...], str]:
    """Generate interface_types.py with TypedDict classes from TOML config.

    Returns:
        The interface mapping (canonical key -> class name).
    """
    interface_map = collect_interface_types(config)
    if not interface_map:
        lines = [
            '"""',
            'Generated TypedDict classes for interface types.',
            'This file is auto-generated by interface_type_generator.py.',
            'Do not edit manually.',
            '"""',
            '',
        ]
        Path(output_path).write_text('\n'.join(lines))
        return interface_map

    ordered = _dependency_order(interface_map)

    lines = [
        '"""',
        'Generated TypedDict classes for interface types.',
        'This file is auto-generated by interface_type_generator.py.',
        'Do not edit manually.',
        '"""',
        '',
        'from typing import Any, Dict, List, TypedDict',
        '',
        '',
    ]

    for canonical, class_name in ordered:
        lines.append(f'class {class_name}(TypedDict):')
        for field_name, field_type in canonical:
            py_type = _field_type_to_python(field_type, interface_map)
            lines.append(f'    {field_name}: {py_type}')
        lines.append('')
        lines.append('')

    Path(output_path).write_text('\n'.join(lines))
    return interface_map


def get_interface_type_names(
    interface_map: dict[tuple[tuple[str, str], ...], str],
) -> set[str]:
    """Get all TypedDict class names from the interface mapping."""
    return set(interface_map.values())


def resolve_type_str(
    type_str: str,
    interface_map: dict[tuple[tuple[str, str], ...], str],
) -> str | None:
    """Given a full TOML type string, resolve to a Python annotation if it
    contains interface types. Returns None if no interface types are present.

    Examples:
        'vec<interface{id: string, key: string}>' -> 'List[KeyItem]'
        'interface{id: string, key: string}' -> 'KeyItem'
        'string' -> None
    """
    if type_str.startswith('vec<') and type_str.endswith('>'):
        inner = type_str[4:-1]
        inner_resolved = resolve_type_str(inner, interface_map)
        if inner_resolved:
            return f'List[{inner_resolved}]'
        return None

    if type_str.startswith('interface{') and type_str.endswith('}'):
        name = get_typeddict_name(type_str, interface_map)
        if name:
            return name
        return None

    return None


def collect_needed_imports(
    node_config: dict[str, Any],
    interface_map: dict[tuple[tuple[str, str], ...], str],
) -> set[str]:
    """Collect the set of TypedDict class names needed by a node's config."""
    type_strings = _collect_type_strings(node_config)
    needed: set[str] = set()

    for ts in type_strings:
        interfaces = _extract_interface_types(ts)
        for iface_str in interfaces:
            canonical = _canonical_key(iface_str)
            name = interface_map.get(canonical)
            if name:
                needed.add(name)

    return needed
