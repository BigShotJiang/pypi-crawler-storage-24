"""
NodeOutput class that wraps template strings with type metadata.

At runtime, all node outputs are template strings like "{{ node_id.field }}".
This format is required for the VectorShift backend to understand node
dependencies. NodeOutput extends str so it IS a string at runtime, but
carries metadata about the semantic type for validation.

Usage:
    output = NodeOutput(
        "{{ query.text }}",
        source_type="string",
        source_node_id="query",
        source_field="text",
    )
    # output is a str: isinstance(output, str) == True
    # output has type info: output.semantic_type == "string"
"""

import warnings
from typing import Any

from .type_compatibility import Compatibility, get_compatibility, is_vec


class TypeCompatibilityWarning(UserWarning):
    """Warning for partial type compatibility between node connections."""

    pass


class NodeOutput(str):
    """Wraps a template string with type metadata for validation.

    At runtime, this IS a string (e.g., "{{ query.text }}") for backend
    compatibility. But it carries metadata about its semantic type for
    validation when connecting nodes.
    """

    _source_type: str
    _source_node_id: str
    _source_field: str

    def __new__(
        cls,
        template: str,
        source_type: str = "any",
        source_node_id: str = "",
        source_field: str = "",
    ) -> "NodeOutput":
        instance = super().__new__(cls, template)
        instance._source_type = source_type
        instance._source_node_id = source_node_id
        instance._source_field = source_field
        return instance

    @property
    def semantic_type(self) -> str:
        """The declared type from TOML config."""
        return self._source_type


def validate_input_type(
    value: Any,
    input_name: str,
    expected_type: str,
    target_node_class: str,
) -> None:
    """Validate that a value's semantic type is compatible with an input.

    Only validates NodeOutput values (node connections).
    Raw Python values (str, int, list) are accepted without validation.

    Args:
        value: The value being passed to the input
        input_name: Name of the input field
        expected_type: Expected type from TOML config
        target_node_class: Class name of the target node (for error messages)

    Raises:
        TypeError: If types are incompatible (Compatibility.NONE)
    """
    if not isinstance(value, NodeOutput):
        return

    source_type = value.semantic_type
    if not source_type or not expected_type:
        return

    compatibility = get_compatibility(source_type, expected_type)

    if compatibility == Compatibility.NONE and is_vec(expected_type):
        inner_type = expected_type[4:-1]
        inner_compat = get_compatibility(source_type, inner_type)
        if inner_compat == Compatibility.FULL:
            compatibility = inner_compat

    if compatibility == Compatibility.NONE:
        raise TypeError(
            f"Type error: Cannot connect "
            f"{value._source_node_id}.{value._source_field} "
            f"(type: {source_type}) to "
            f"{target_node_class}.{input_name} "
            f"(expected: {expected_type})"
        )

    if compatibility == Compatibility.PARTIAL:
        warnings.warn(
            f"Partial type compatibility: {source_type} -> "
            f"{expected_type}. Connection from "
            f"{value._source_node_id}.{value._source_field} to "
            f"{target_node_class}.{input_name} may fail at runtime.",
            TypeCompatibilityWarning,
            stacklevel=3,
        )
