from vectorshift.object import ObjectInfo
from typing import Literal


class Integration(ObjectInfo):
    object_type: Literal[20] = 20
