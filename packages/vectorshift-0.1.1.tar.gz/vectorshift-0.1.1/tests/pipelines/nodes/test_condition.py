"""Tests for the manually written ConditionNode.

Covers:
- Creation with no args, single clause, unary ops, multiple clauses
- Validation: binary op requires operand2, path name length mismatch
- Outputs: path_else always present, dynamic output wiring
- Serialization: to_dict matches expected format
- Operators: all enum values match expected set
"""

import pytest
from vectorshift.pipeline.node_output import NodeOutput
from vectorshift.pipeline.nodes import ConditionNode
from vectorshift.pipeline.nodes._condition import (
    Operator,
    LogicalOp,
    Clause,
    ConditionGroup,
    UNARY_OPERATORS,
)

# ---------------------------------------------------------------------------
# Operator enum
# ---------------------------------------------------------------------------


class TestOperatorEnum:
    EXPECTED_OPERATORS = {
        "Equal",
        "NotEqual",
        "GreaterThan",
        "LessThan",
        "GreaterThanEqual",
        "LessThanEqual",
        "TextContains",
        "TextDoesNotContains",
        "TextStartsWith",
        "TextDoesNotStartWith",
        "TextEndsWith",
        "TextDoesNotEndWith",
        "TextGreaterThanNCharacters",
        "TextLessThanNCharacters",
        "IsEmpty",
        "IsNotEmpty",
        "IsTrue",
        "IsFalse",
        "VecContainsItem",
        "VecDoesNotContainsItem",
        "MapContainsKey",
        "Expression",
    }

    def test_all_operators_present(self):
        actual = {op.value for op in Operator}
        assert actual == self.EXPECTED_OPERATORS

    def test_operator_count(self):
        assert len(Operator) == 22

    def test_unary_operators(self):
        expected_unary = {
            Operator.IS_EMPTY,
            Operator.IS_NOT_EMPTY,
            Operator.IS_TRUE,
            Operator.IS_FALSE,
            Operator.EXPRESSION,
        }
        assert UNARY_OPERATORS == expected_unary

    def test_operator_is_str(self):
        assert isinstance(Operator.EQUAL, str)
        assert Operator.EQUAL == "Equal"


class TestLogicalOp:
    def test_and_or(self):
        assert LogicalOp.AND == "AND"
        assert LogicalOp.OR == "OR"
        assert len(LogicalOp) == 2


# ---------------------------------------------------------------------------
# Clause
# ---------------------------------------------------------------------------


class TestClause:
    def test_binary_clause(self):
        c = Clause(Operator.EQUAL, "a", "b")
        assert c.operator == Operator.EQUAL
        assert c.operand1 == "a"
        assert c.operand2 == "b"

    def test_unary_clause(self):
        c = Clause(Operator.IS_EMPTY, "a")
        assert c.operator == Operator.IS_EMPTY
        assert c.operand1 == "a"
        assert c.operand2 is None

    def test_binary_requires_operand2(self):
        with pytest.raises(ValueError, match="requires operand2"):
            Clause(Operator.EQUAL, "a")

    def test_unary_ignores_operand2(self):
        c = Clause(Operator.IS_TRUE, "a", "ignored")
        assert c.operand2 is None

    def test_to_dict_binary(self):
        c = Clause(Operator.GREATER_THAN, "x", 10)
        d = c.to_dict()
        assert d["operand1"] == "x"
        assert d["operand2"] == "10"
        assert d["operator"] == "GreaterThan"
        assert d["termType"] == "Clause"

    def test_to_dict_unary(self):
        c = Clause(Operator.IS_EMPTY, "x")
        d = c.to_dict()
        assert "operand2" not in d
        assert d["operator"] == "IsEmpty"

    def test_repr_binary(self):
        c = Clause(Operator.EQUAL, "a", "b")
        assert "Equal" in repr(c)
        assert "'a'" in repr(c)
        assert "'b'" in repr(c)

    def test_repr_unary(self):
        c = Clause(Operator.IS_EMPTY, "a")
        assert "IsEmpty" in repr(c)

    def test_node_output_as_operand(self):
        out = NodeOutput(
            "{{ node.field }}",
            source_type="string",
            source_node_id="node",
            source_field="field",
        )
        c = Clause(Operator.EQUAL, out, "value")
        assert c.operand1 == "{{ node.field }}"


# ---------------------------------------------------------------------------
# ConditionGroup
# ---------------------------------------------------------------------------


class TestConditionGroup:
    def test_single_clause(self):
        c = Clause(Operator.EQUAL, "a", "b")
        g = ConditionGroup([c])
        assert len(g.clauses) == 1
        assert g.operators == []

    def test_multiple_clauses_with_operators(self):
        c1 = Clause(Operator.EQUAL, "a", "b")
        c2 = Clause(Operator.IS_EMPTY, "c")
        g = ConditionGroup([c1, c2], [LogicalOp.AND])
        assert len(g.clauses) == 2
        assert g.operators == [LogicalOp.AND]

    def test_default_operators_are_and(self):
        c1 = Clause(Operator.EQUAL, "a", "b")
        c2 = Clause(Operator.IS_EMPTY, "c")
        c3 = Clause(Operator.IS_TRUE, "d")
        g = ConditionGroup([c1, c2, c3])
        assert g.operators == [LogicalOp.AND, LogicalOp.AND]

    def test_empty_clauses_raises(self):
        with pytest.raises(ValueError, match="at least one clause"):
            ConditionGroup([])

    def test_wrong_operator_count_raises(self):
        c1 = Clause(Operator.EQUAL, "a", "b")
        c2 = Clause(Operator.IS_EMPTY, "c")
        with pytest.raises(ValueError, match="Expected 1 operators"):
            ConditionGroup([c1, c2], [LogicalOp.AND, LogicalOp.OR])

    def test_to_dict(self):
        c1 = Clause(Operator.EQUAL, "a", "b")
        c2 = Clause(Operator.IS_EMPTY, "c")
        g = ConditionGroup([c1, c2], [LogicalOp.OR])
        d = g.to_dict()
        assert len(d["terms"]) == 2
        assert d["operators"] == ["OR"]


# ---------------------------------------------------------------------------
# ConditionNode creation
# ---------------------------------------------------------------------------


class TestConditionNodeCreation:
    def test_create_empty(self):
        node = ConditionNode(id="cond")
        assert node.node_type == "condition"
        assert "complete" in node.outputs

    def test_create_with_single_group(self):
        g = ConditionGroup([Clause(Operator.EQUAL, "a", "b")])
        node = ConditionNode(id="cond", conditions=[g])
        assert "path_0" in node.outputs
        assert "path_else" in node.outputs
        assert "complete" in node.outputs

    def test_create_with_multiple_groups(self):
        g1 = ConditionGroup([Clause(Operator.GREATER_THAN, "x", 10)])
        g2 = ConditionGroup([Clause(Operator.IS_EMPTY, "y")])
        node = ConditionNode(id="cond", conditions=[g1, g2])
        assert "path_0" in node.outputs
        assert "path_1" in node.outputs
        assert "path_else" in node.outputs
        assert "complete" in node.outputs

    def test_create_with_outputs_dict(self):
        node = ConditionNode(
            id="cond",
            outputs={"path_a": "path", "path_b": "path"},
        )
        assert "path_a" in node.outputs
        assert "path_b" in node.outputs

    def test_batch_mode_not_allowed(self):
        node = ConditionNode(id="cond")
        assert node._batch_mode_allowed is False  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# ConditionNode outputs
# ---------------------------------------------------------------------------


class TestConditionNodeOutputs:
    def test_path_else_always_present(self):
        node = ConditionNode(id="cond")
        # Even with no conditions, outputs should include path_else
        # (set via the outputs dict default)
        outputs_map = node.inputs.get("outputs", {})
        assert "path_else" in outputs_map

    def test_dynamic_output_returns_node_output(self):
        node = ConditionNode(
            id="cond",
            outputs={"path_a": "path", "path_b": "path"},
        )
        path_a = node.path_a
        assert isinstance(path_a, NodeOutput)
        assert str(path_a) == "{{ cond.path_a }}"
        assert path_a.semantic_type == "path"

    def test_complete_output(self):
        node = ConditionNode(id="cond")
        complete = node.complete
        assert isinstance(complete, NodeOutput)
        assert str(complete) == "{{ cond.complete }}"

    def test_invalid_output_raises(self):
        node = ConditionNode(id="cond")
        with pytest.raises(AttributeError):
            _ = node.nonexistent

    def test_auto_path_names_accessible(self):
        g = ConditionGroup([Clause(Operator.EQUAL, "a", "b")])
        node = ConditionNode(id="c", conditions=[g])
        out = node.path_0
        assert str(out) == "{{ c.path_0 }}"
        else_out = node.path_else
        assert str(else_out) == "{{ c.path_else }}"


# ---------------------------------------------------------------------------
# ConditionNode serialization
# ---------------------------------------------------------------------------


class TestConditionNodeSerialization:
    def test_conditions_serialized(self):
        g = ConditionGroup([Clause(Operator.EQUAL, "a", "b")])
        node = ConditionNode(id="cond", conditions=[g])
        assert node.node_type == "condition"
        assert node.id == "cond"
        conditions = node.inputs["conditions"]
        assert len(conditions) == 1
        term = conditions[0]["terms"][0]
        assert term["operator"] == "Equal"

    def test_from_dict_roundtrip(self):
        g = ConditionGroup([Clause(Operator.EQUAL, "a", "b")])
        node = ConditionNode(id="cond", conditions=[g])
        data = {
            "type": "condition",
            "id": node.id,
            "inputs": dict(node.inputs),
        }
        restored = ConditionNode.from_dict(data)
        assert restored.id == "cond"
        assert "path_0" in restored.outputs
        assert "path_else" in restored.outputs

    def test_from_dict_preserves_conditions(self):
        g = ConditionGroup(
            [Clause(Operator.EQUAL, "a", "b"), Clause(Operator.IS_EMPTY, "c")],
            [LogicalOp.AND],
        )
        node = ConditionNode(id="cond", conditions=[g])
        data = {
            "type": "condition",
            "id": node.id,
            "inputs": dict(node.inputs),
        }
        restored = ConditionNode.from_dict(data)
        assert restored.inputs["conditions"] == node.inputs["conditions"]
        assert len(restored.inputs["conditions"]) == 1
        assert len(restored.inputs["conditions"][0]["terms"]) == 2
        assert restored.inputs["conditions"][0]["terms"][0]["operator"] == "Equal"
        assert restored.inputs["conditions"][0]["operators"] == ["AND"]
