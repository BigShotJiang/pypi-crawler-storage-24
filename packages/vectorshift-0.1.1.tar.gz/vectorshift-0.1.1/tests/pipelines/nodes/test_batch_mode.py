"""Tests for batch mode support.

Verifies that:
- Nodes with batch_mode=false have _batch_mode_allowed=False
- Nodes without batch_mode=false have _batch_mode_allowed=True
- Vectorizable inputs are wrapped in vec<T> in batch mode
- Non-vectorizable fields (path, int32, bool, enum, dropdown) stay unchanged
- Outputs are vectorized in batch mode
- Advanced outputs (complete, success, failure) are not vectorized
"""

import pytest

from vectorshift.pipeline.node import (
    NON_BATCH_INPUT_BASE_TYPES,
)
from vectorshift.pipeline.nodes import (
    LlmNode,
    ConditionNode,
    TableReadColumnsNode,
)

# ---------------------------------------------------------------------------
# Batch mode allowed / disallowed
# ---------------------------------------------------------------------------


class TestBatchModeAllowed:
    def test_llm_allows_batch(self):
        node = LlmNode(id='l', provider='openai', model='gpt-4', stream=False)
        assert node._batch_mode_allowed is True  # type: ignore[attr-defined]

    def test_condition_disallows_batch(self):
        node = ConditionNode(id='cond')
        assert node._batch_mode_allowed is False  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Batch mode vectorization at runtime
# ---------------------------------------------------------------------------


class TestBatchModeVectorizesInputs:
    def test_string_input_becomes_vec(self):
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            execution_mode='batch',
        )
        valid = llm._get_valid_inputs_for_params()  # type: ignore[attr-defined]
        prompt_type = valid.get('prompt', {}).get('type', '')
        assert prompt_type == 'vec<string>', f"Expected vec<string>, got {prompt_type}"

    def test_non_vectorizable_stays_same(self):
        """Fields with non-vectorizable base types stay unwrapped."""
        trc = TableReadColumnsNode(
            id='trc',
            column_type='string',
            column_name='col',
            dataframe='',
            execution_mode='batch',
        )
        valid_batch = trc._get_valid_inputs_for_params()  # type: ignore[attr-defined]
        trc_normal = TableReadColumnsNode(
            id='trc_n',
            column_type='string',
            column_name='col',
            dataframe='',
            execution_mode='normal',
        )
        valid_normal = trc_normal._get_valid_inputs_for_params()  # type: ignore[attr-defined]
        for field in valid_normal:
            if field not in valid_batch:
                continue
            normal_type = valid_normal[field].get('type', '')
            batch_type = valid_batch[field].get('type', '')
            if normal_type in NON_BATCH_INPUT_BASE_TYPES:
                assert normal_type == batch_type, (
                    f"Field {field} with type {normal_type} should not be "
                    f"vectorized, got {batch_type}"
                )

    def test_normal_mode_no_wrapping(self):
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            execution_mode='normal',
        )
        valid = llm._get_valid_inputs_for_params()  # type: ignore[attr-defined]
        prompt_type = valid.get('prompt', {}).get('type', '')
        assert (
            prompt_type == 'string'
        ), f"Expected string in normal mode, got {prompt_type}"


class TestBatchModeVectorizesOutputs:
    def test_output_becomes_vec(self):
        llm = LlmNode(
            id='llm',
            provider='openai',
            model="gpt-4",
            stream=False,
            execution_mode='batch',
        )
        response_out = llm.response
        assert (
            response_out.semantic_type == 'vec<string>'
        ), f"Expected vec<string>, got {response_out.semantic_type}"

    def test_complete_not_vectorized(self):
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            execution_mode='batch',
        )
        complete_out = llm.complete
        assert not complete_out.semantic_type.startswith('vec<'), (
            f"complete should not be vectorized, " f"got {complete_out.semantic_type}"
        )

    def test_normal_mode_output_not_wrapped(self):
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            execution_mode='normal',
        )
        response_out = llm.response
        assert response_out.semantic_type == 'string', (
            f"Expected string in normal mode, " f"got {response_out.semantic_type}"
        )


class TestBatchModeDisallowedNode:
    def test_condition_ignores_batch_mode(self):
        """Nodes with _batch_mode_allowed=False should not vectorize."""
        cond = ConditionNode(
            id='cond',
            outputs={'path_a': 'path'},
        )
        assert cond._batch_mode_allowed is False  # type: ignore[attr-defined]
