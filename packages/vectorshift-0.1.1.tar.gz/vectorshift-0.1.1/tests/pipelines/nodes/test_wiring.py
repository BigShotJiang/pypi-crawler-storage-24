import warnings
import pytest
from vectorshift.integrations.integration import Integration
from vectorshift.pipeline.node_output import (
    NodeOutput,
    TypeCompatibilityWarning,
    validate_input_type,
)
from vectorshift.pipeline.nodes import (
    InputNode,
    OutputNode,
    LlmNode,
    ConditionNode,
    CodeExecutionNode,
    CsvReaderNode,
    FileNode,
    DataframeGetSchemaNode,
    PipelineNode,
    IntegrationGmailNode,
)
from vectorshift.pipeline.node import Node

INTEGRATION = Integration(object_id='test')


def _make_output(semantic_type, node_id='src', field='out'):
    return NodeOutput(
        f'{{{{ {node_id}.{field} }}}}',
        source_type=semantic_type,
        source_node_id=node_id,
        source_field=field,
    )


# ---------------------------------------------------------------------------
# Basic wiring chains
# ---------------------------------------------------------------------------


class TestBasicChain:
    def test_input_llm_output(self):
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=inp.text,
        )
        out = OutputNode(
            id='out',
            output_type='string',
            value=llm.response,
        )
        assert llm.inputs['prompt'] == '{{ inp.text }}'
        assert out.inputs['value'] == '{{ llm.response }}'


class TestMultiNodeWiring:
    def test_llm_chain(self):
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        llm1 = LlmNode(
            id='llm1',
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=inp.text,
        )
        llm2 = LlmNode(
            id='llm2',
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=llm1.response,
        )
        assert llm2.inputs['prompt'] == '{{ llm1.response }}'


class TestFileChain:
    def test_input_file_to_csv_reader(self):
        inp = InputNode(id='inp_f', input_type='file', use_default_value=False)
        csv = CsvReaderNode(
            id='csv_r',
            selected_file=inp.file,
            file_type='CSV',
            is_file_variable=True,
        )
        assert csv.inputs['selected_file'] == '{{ inp_f.file }}'


class TestCrossNodeWiring:
    def test_code_execution_wiring(self):
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        ce = CodeExecutionNode(
            id='ce',
            code=inp.text,
            processed_outputs={'result': 'string'},
        )
        out = OutputNode(id='out', output_type='string', value=ce.result)
        assert ce.inputs['code'] == '{{ inp.text }}'
        assert out.inputs['value'] == '{{ ce.result }}'


class TestConditionWiring:
    def test_dynamic_output_wiring(self):
        cond = ConditionNode(
            id='cond',
            outputs={'path_a': 'path', 'path_b': 'path'},
        )
        path_a = cond.path_a
        path_b = cond.path_b
        assert str(path_a) == '{{ cond.path_a }}'
        assert str(path_b) == '{{ cond.path_b }}'
        assert path_a.semantic_type == 'path'
        assert path_b.semantic_type == 'path'


# ---------------------------------------------------------------------------
# Object reference normalization
# ---------------------------------------------------------------------------


class TestObjectRefNormalization:
    """Test object-reference normalization for all semantic types."""

    def test_pipeline_string_normalized(self):
        pipe = PipelineNode(id='pipe', pipeline='pipe_id_1')
        assert pipe.inputs['pipeline'] == {
            'object_id': 'pipe_id_1',
            'object_type': 0,
        }

    def test_dataframe_string_normalized_nested(self):
        df = DataframeGetSchemaNode(
            id='dfs', dataframe_type='table', dataframe='df_id_1'
        )
        assert df.inputs['dataframe'] == {
            'object_info': {'object_id': 'df_id_1', 'object_type': 3},
        }

    def test_template_string_passthrough(self):
        """Template strings like {{ node.field }} must not be normalized."""
        pipe = PipelineNode(id='pipe', pipeline='{{ some_node.pipeline_id }}')
        assert pipe.inputs['pipeline'] == '{{ some_node.pipeline_id }}'

    def test_node_output_passthrough(self):
        """NodeOutput objects must pass through without normalization."""
        out = _make_output('pipeline', node_id='src', field='pipe_ref')
        pipe = PipelineNode(id='pipe', pipeline=out)
        assert pipe.inputs['pipeline'] == '{{ src.pipe_ref }}'

    def test_dict_passthrough(self):
        """Already-structured dicts must pass through unchanged."""
        payload = {'object_id': 'already_set', 'object_type': 0}
        pipe = PipelineNode(id='pipe', pipeline=payload)
        assert pipe.inputs['pipeline'] == payload


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


class TestDependencies:
    def test_single_dependency(self):
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=inp.text,
        )
        non_cyclic, all_deps = llm.get_dependencies()
        assert 'inp' in all_deps

    def test_multi_dependency(self):
        from vectorshift.pipeline.nodes import CreateListNode

        inp1 = InputNode(id='inp1', input_type='string', use_default_value=False)
        inp2 = InputNode(id='inp2', input_type='string', use_default_value=False)
        cl = CreateListNode(
            id='cl',
            type='string',
            list=[inp1.text, inp2.text],
        )
        non_cyclic, all_deps = cl.get_dependencies()
        assert 'inp1' in all_deps
        assert 'inp2' in all_deps

    def test_chain_dependency(self):
        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        llm = LlmNode(
            id='llm',
            provider='openai',
            model='gpt-4',
            stream=False,
            prompt=inp.text,
        )
        out = OutputNode(id='out', output_type='string', value=llm.response)
        non_cyclic, all_deps = out.get_dependencies()
        assert 'llm' in all_deps


# ---------------------------------------------------------------------------
# Type compatibility
# ---------------------------------------------------------------------------


class TestFullCompatibility:
    def test_string_to_string(self):
        out = _make_output('string')
        validate_input_type(out, 'prompt', 'string', 'LlmNode')

    def test_int_to_float(self):
        out = _make_output('int32')
        validate_input_type(out, 'value', 'float', 'OutputNode')

    def test_anything_to_any(self):
        out = _make_output('file')
        validate_input_type(out, 'input', 'any', 'SomeNode')


class TestPartialCompatibility:
    def test_string_to_int_warns(self):
        out = _make_output('string')
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            validate_input_type(out, 'value', 'int32', 'OutputNode')
            type_warnings = [
                x for x in w if issubclass(x.category, TypeCompatibilityWarning)
            ]
            assert len(type_warnings) == 1


class TestIncompatibleConnections:
    def test_image_to_knowledge_base_raises(self):
        out = _make_output('image')
        with pytest.raises(TypeError, match='Type error'):
            validate_input_type(out, 'kb', 'knowledge_base', 'SomeNode')

    def test_integration_mismatch_raises(self):
        out = _make_output('integration<Gmail>')
        with pytest.raises(TypeError, match='Type error'):
            validate_input_type(out, 'conn', 'integration<Slack>', 'SomeNode')


class TestStreamTypeCompatibility:
    """Verify stream<T> type compatibility rules."""

    def test_stream_string_to_string_is_full(self):
        out = _make_output('stream<string>')
        validate_input_type(out, 'prompt', 'string', 'LlmNode')

    def test_stream_string_to_json_is_full(self):
        out = _make_output('stream<string>')
        validate_input_type(out, 'value', 'json', 'SomeNode')

    def test_int64_to_stream_string_raises(self):
        out = _make_output('int64')
        with pytest.raises(TypeError, match='Type error'):
            validate_input_type(out, 'value', 'stream<string>', 'OutputNode')

    def test_stream_to_stream_is_full(self):
        out = _make_output('stream<string>')
        validate_input_type(out, 'value', 'stream<string>', 'OutputNode')

    def test_stream_string_to_int_warns(self):
        out = _make_output('stream<string>')
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            validate_input_type(out, 'value', 'int32', 'SomeNode')
            type_warnings = [
                x for x in w if issubclass(x.category, TypeCompatibilityWarning)
            ]
            assert len(type_warnings) == 1


class TestFileTypeHierarchy:
    """Verify file/image/audio hierarchy is correct."""

    def test_image_to_file_is_full(self):
        out = _make_output('image')
        validate_input_type(out, 'value', 'file', 'SomeNode')

    def test_audio_to_file_is_full(self):
        out = _make_output('audio')
        validate_input_type(out, 'value', 'file', 'SomeNode')

    def test_file_to_image_warns(self):
        out = _make_output('file')
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            validate_input_type(out, 'value', 'image', 'SomeNode')
            type_warnings = [
                x for x in w if issubclass(x.category, TypeCompatibilityWarning)
            ]
            assert len(type_warnings) == 1

    def test_file_to_audio_warns(self):
        out = _make_output('file')
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            validate_input_type(out, 'value', 'audio', 'SomeNode')
            type_warnings = [
                x for x in w if issubclass(x.category, TypeCompatibilityWarning)
            ]
            assert len(type_warnings) == 1

    def test_image_to_bytes_is_full(self):
        out = _make_output('image')
        validate_input_type(out, 'value', 'bytes', 'SomeNode')

    def test_audio_to_bytes_is_full(self):
        out = _make_output('audio')
        validate_input_type(out, 'value', 'bytes', 'SomeNode')


class TestStreamingLlmWiring:
    """Verify streaming LLM outputs wire correctly to OutputNode."""

    def test_stream_response_to_stream_output(self):
        llm = LlmNode(id='llm', provider='openai', model='gpt-4', stream=True)
        out = OutputNode(id='out', output_type='stream<string>', value=llm.response)
        assert out.inputs['value'] == '{{ llm.response }}'

    def test_stream_response_to_string_output(self):
        llm = LlmNode(id='llm', provider='openai', model='gpt-4', stream=True)
        out = OutputNode(id='out', output_type='string', value=llm.response)
        assert out.inputs['value'] == '{{ llm.response }}'

    def test_int64_to_stream_output_raises(self):
        llm = LlmNode(id='llm', provider='openai', model='gpt-4', stream=True)
        with pytest.raises(TypeError, match='Type error'):
            OutputNode(id='out', output_type='stream<string>', value=llm.tokens_used)

    def test_tokens_used_type_is_int64(self):
        llm = LlmNode(id='llm', provider='openai', model='gpt-4', stream=True)
        assert llm.tokens_used.semantic_type == 'int64'


class TestRawValuesSkipValidation:
    def test_raw_string_accepted(self):
        validate_input_type('hello', 'prompt', 'string', 'LlmNode')


# ---------------------------------------------------------------------------
# Dynamic kwargs for PipelineNode
# ---------------------------------------------------------------------------


class TestDynamicKwargsForPipelineNode:
    class _FakePipelineDefinition:
        inputs = {'input_0': {'io_type': 'string', 'description': 'dynamic input'}}
        outputs = {'output_0': 'string'}

    @staticmethod
    def _fake_fetch_definition(object_type, object_id):
        return TestDynamicKwargsForPipelineNode._FakePipelineDefinition()

    def test_dynamic_nodeoutput_kwarg_is_supported(self, monkeypatch):
        Node.__dict__['_cached_definitions'].clear()  # type: ignore[attr-defined]
        monkeypatch.setattr(
            Node,
            '_fetch_object_definition',  # type: ignore[attr-defined]
            staticmethod(self._fake_fetch_definition),
        )

        inp = InputNode(id='inp', input_type='string', use_default_value=False)
        pipe = PipelineNode(id='pipe', pipeline='pipeline_1', input_0=inp.text)

        assert pipe.inputs['input_0'] == '{{ inp.text }}'


# ---------------------------------------------------------------------------
# Backward compatibility
# ---------------------------------------------------------------------------


class TestFromJsonBackwardCompatibility:
    def test_from_json_filters_stale_inputs_for_integration_gmail(self):
        data = {
            'type': 'integration_gmail',
            'id': 'gmail_1',
            'name': 'gmail',
            'inputs': {
                'action': 'send_email',
                'integration': {'object_id': 'test'},
                'recipients': 'user@example.com',
                'subject': 'hello',
                'body': 'world',
                'format': 'text',
                # stale keys from a different Gmail config variant
                'from': 'someone@example.com',
                'in': 'inbox',
                'is': 'read',
            },
        }

        node = Node.from_json(data)

        assert node.node_type == 'integration_gmail'
        assert node.inputs['recipients'] == 'user@example.com'
        # Stale fields from a different config variant must not override state.
        assert node.inputs.get('in') != 'inbox'
        assert node.inputs.get('is') != 'read'
