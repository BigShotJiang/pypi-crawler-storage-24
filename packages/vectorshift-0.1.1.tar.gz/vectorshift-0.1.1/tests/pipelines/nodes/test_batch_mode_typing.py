"""Tests for batch mode static typing (stub generation).

Verifies that the stub generator correctly produces batch-mode overloads:
- Batch return classes wrap outputs in vst.ListType[T]
- Advanced outputs (complete, success, failure) are NOT wrapped
- Vectorizable inputs get Accepts*Batch types (accept both T and List<T>)
- Non-vectorizable inputs (int32, bool, enum, dropdown, etc.) stay unchanged
- list_mode_fields restricts which fields are vectorized
- _is_field_vectorizable_for_stubs mirrors node.py logic
"""

import pytest

from vectorshift.types import (
    ACCEPTS_TO_LIST_MAP,
    get_output_type_name,
)
from vectorshift.pipeline.stub_generator import (
    _generate_return_class,
    _generate_param_annotation,
    _is_field_vectorizable_for_stubs,
    _ADVANCED_OUTPUTS,
    _NON_BATCH_INPUT_BASE_TYPES,
    _NON_BATCH_OBJECT_TYPES,
    _ADVANCED_INPUTS,
)

# ---------------------------------------------------------------------------
# _is_field_vectorizable_for_stubs
# ---------------------------------------------------------------------------


class TestFieldVectorizable:
    def test_string_is_vectorizable(self):
        assert _is_field_vectorizable_for_stubs("prompt", {"type": "string"}) is True

    def test_file_is_vectorizable(self):
        assert _is_field_vectorizable_for_stubs("doc", {"type": "file"}) is True

    def test_json_is_vectorizable(self):
        assert _is_field_vectorizable_for_stubs("data", {"type": "json"}) is True

    def test_dependencies_not_vectorizable(self):
        assert _is_field_vectorizable_for_stubs("dependencies", {"type": "any"}) is False

    @pytest.mark.parametrize("base_type", sorted(_NON_BATCH_INPUT_BASE_TYPES))
    def test_non_batch_base_types(self, base_type):
        assert _is_field_vectorizable_for_stubs("f", {"type": base_type}) is False

    @pytest.mark.parametrize("obj_type", sorted(_NON_BATCH_OBJECT_TYPES))
    def test_non_batch_object_types(self, obj_type):
        assert _is_field_vectorizable_for_stubs("f", {"type": obj_type}) is False

    def test_enum_not_vectorizable(self):
        assert _is_field_vectorizable_for_stubs("mode", {"type": "enum<a|b>"}) is False

    def test_dropdown_not_vectorizable(self):
        input_def = {"type": "string", "component": {"type": "dropdown"}}
        assert _is_field_vectorizable_for_stubs("opt", input_def) is False

    def test_variable_options_not_vectorizable(self):
        input_def = {"type": "string", "component": {"type": "variable_options"}}
        assert _is_field_vectorizable_for_stubs("opt", input_def) is False

    # list_mode_fields
    def test_list_mode_fields_includes_field(self):
        lmf = [{"field": "prompt", "label": "Prompt"}]
        assert (
            _is_field_vectorizable_for_stubs("prompt", {"type": "string"}, lmf) is True
        )

    def test_list_mode_fields_excludes_field(self):
        lmf = [{"field": "prompt", "label": "Prompt"}]
        assert (
            _is_field_vectorizable_for_stubs("system", {"type": "string"}, lmf) is False
        )

    def test_list_mode_fields_plain_strings(self):
        lmf = ["prompt"]
        assert (
            _is_field_vectorizable_for_stubs("prompt", {"type": "string"}, lmf) is True
        )
        assert (
            _is_field_vectorizable_for_stubs("system", {"type": "string"}, lmf) is False
        )


# ---------------------------------------------------------------------------
# _generate_return_class — batch_mode
# ---------------------------------------------------------------------------


class TestBatchReturnClass:
    def test_normal_mode_no_wrapping(self):
        rc = _generate_return_class(
            "_TestNode_Normal",
            "TestNode",
            {"response": "string", "tokens": "int32"},
        )
        assert "vst.Str" in rc
        assert "vst.Int32" in rc
        assert "vst.ListType" not in rc

    def test_batch_mode_wraps_outputs(self):
        rc = _generate_return_class(
            "_TestNode_Batch",
            "TestNode",
            {"response": "string", "tokens": "int32"},
            batch_mode=True,
        )
        assert "vst.ListType[vst.Str]" in rc
        assert "vst.ListType[vst.Int32]" in rc

    def test_batch_mode_skips_advanced_outputs(self):
        rc = _generate_return_class(
            "_TestNode_Batch",
            "TestNode",
            {
                "response": "string",
                "complete": "path",
                "success": "bool",
                "failure": "bool",
            },
            batch_mode=True,
        )
        lines = rc.split("\n")
        for field in ("complete", "success", "failure"):
            field_lines = [line for line in lines if f"def {field}" in line]
            assert field_lines, f"Missing {field} property"
            assert (
                "vst.ListType" not in field_lines[0]
            ), f"Advanced output '{field}' should NOT be wrapped"
        # response SHOULD be wrapped
        resp_lines = [line for line in lines if "def response" in line]
        assert "vst.ListType" in resp_lines[0]

    def test_batch_vec_output_double_wraps(self):
        rc = _generate_return_class(
            "_TestNode_Batch",
            "TestNode",
            {"items": "vec<string>"},
            batch_mode=True,
        )
        # vec<string> in batch -> vec<vec<string>> -> vst.ListType[vst.ListType[vst.Str]]
        assert "vst.ListType[vst.ListType[vst.Str]]" in rc


# ---------------------------------------------------------------------------
# _generate_param_annotation — batch_mode
# ---------------------------------------------------------------------------


class TestBatchParamAnnotation:
    def test_normal_mode_unchanged(self):
        ann = _generate_param_annotation("prompt", {"type": "string"}, {}, {}, [], [])
        assert "vst.AcceptsStr" in ann
        assert "List" not in ann or "vst.AcceptsStrList" not in ann

    def test_batch_mode_vectorizable_field(self):
        ann = _generate_param_annotation(
            "prompt",
            {"type": "string"},
            {},
            {},
            [],
            [],
            batch_mode=True,
        )
        assert "vst.AcceptsStrBatch" in ann

    def test_batch_mode_non_vectorizable_field(self):
        ann = _generate_param_annotation(
            "max_tokens",
            {"type": "int32"},
            {},
            {},
            [],
            [],
            batch_mode=True,
        )
        assert "vst.AcceptsInt" in ann
        # Should NOT be mapped to a batch type
        assert "AcceptsIntList" not in ann

    def test_batch_mode_with_list_mode_fields_included(self):
        lmf = [{"field": "prompt"}]
        ann = _generate_param_annotation(
            "prompt",
            {"type": "string"},
            {},
            {},
            [],
            [],
            batch_mode=True,
            list_mode_fields=lmf,
        )
        assert "vst.AcceptsStrBatch" in ann

    def test_batch_mode_with_list_mode_fields_excluded(self):
        lmf = [{"field": "prompt"}]
        ann = _generate_param_annotation(
            "system",
            {"type": "string"},
            {},
            {},
            [],
            [],
            batch_mode=True,
            list_mode_fields=lmf,
        )
        assert "vst.AcceptsStr" in ann
        # Should stay scalar — not in list_mode_fields
        assert "vst.AcceptsStrBatch" not in ann

    def test_batch_mode_file_input(self):
        ann = _generate_param_annotation(
            "document",
            {"type": "file"},
            {},
            {},
            [],
            [],
            batch_mode=True,
        )
        assert "vst.AcceptsFileBatch" in ann

    def test_batch_mode_json_input(self):
        ann = _generate_param_annotation(
            "data",
            {"type": "json"},
            {},
            {},
            [],
            [],
            batch_mode=True,
        )
        assert "vst.AcceptsJsonBatch" in ann

    def test_constrained_param_ignores_batch(self):
        """Literal-constrained params should not be batch-ified."""
        ann = _generate_param_annotation(
            "stream",
            {"type": "bool"},
            {"stream": "true"},
            {},
            [],
            [],
            batch_mode=True,
        )
        assert "Literal[True]" in ann
        assert "List" not in ann


# ---------------------------------------------------------------------------
# ACCEPTS_TO_LIST_MAP completeness
# ---------------------------------------------------------------------------


class TestAcceptsToListMap:
    expected_mappings = [
        ("vst.AcceptsStr", "vst.AcceptsStrBatch"),
        ("vst.AcceptsFile", "vst.AcceptsFileBatch"),
        ("vst.AcceptsImage", "vst.AcceptsImageBatch"),
        ("vst.AcceptsAudio", "vst.AcceptsAudioBatch"),
        ("vst.AcceptsBytes", "vst.AcceptsBytesBatch"),
        ("vst.AcceptsDataframe", "vst.AcceptsDataframeBatch"),
        ("vst.AcceptsTable", "vst.AcceptsTableBatch"),
        ("vst.AcceptsJson", "vst.AcceptsJsonBatch"),
        ("vst.AcceptsKnowledgeBase", "vst.AcceptsKnowledgeBaseBatch"),
        ("vst.AcceptsChart", "vst.AcceptsChartBatch"),
        ("vst.AcceptsDict", "vst.AcceptsDictBatch"),
        ("vst.AcceptsTimestamp", "vst.AcceptsTimestampBatch"),
        ("vst.AcceptsBucketKey", "vst.AcceptsBucketKeyBatch"),
        ("vst.AcceptsAny", "vst.AcceptsAnyBatch"),
        ("vst.AcceptsStream", "vst.AcceptsStreamBatch"),
        ("vst.AcceptsStrList", "vst.AcceptsStrListBatch"),
        ("vst.AcceptsIntList", "vst.AcceptsIntListBatch"),
    ]

    @pytest.mark.parametrize("normal,batch_variant", expected_mappings)
    def test_mapping_exists(self, normal, batch_variant):
        assert ACCEPTS_TO_LIST_MAP[normal] == batch_variant


# ---------------------------------------------------------------------------
# get_output_type_name handles vec wrapping
# ---------------------------------------------------------------------------


class TestOutputTypeVecWrapping:
    def test_vec_string(self):
        assert get_output_type_name("vec<string>") == "ListType[Str]"

    def test_vec_file(self):
        assert get_output_type_name("vec<file>") == "ListType[File]"

    def test_vec_vec_string(self):
        assert get_output_type_name("vec<vec<string>>") == "ListType[ListType[Str]]"
