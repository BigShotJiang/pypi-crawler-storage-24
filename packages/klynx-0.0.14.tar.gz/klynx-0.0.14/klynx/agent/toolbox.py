"""Shared toolbox facade for runtimes that delegate tool operations."""

from __future__ import annotations

from typing import Any


class ToolboxRuntime:
    """Provide a stable tool-management surface for composable runtimes."""

    def _toolbox_backend(self) -> Any:
        raise NotImplementedError("_toolbox_backend must be implemented by subclasses")

    def add_tools(self, *args: Any):
        backend = self._toolbox_backend()
        backend.add_tools(*args)
        return self

    def register_tool_group(self, group_name: str, *tool_specs: Any, load: bool = False):
        backend = self._toolbox_backend()
        backend.register_tool_group(group_name, *tool_specs, load=load)
        return self

    def clear_tools(self):
        backend = self._toolbox_backend()
        backend.clear_tools()
        return self

    def disable_tools(self):
        return self.clear_tools()

    def _refresh_tool_prompts(self):
        backend = self._toolbox_backend()
        refresher = getattr(backend, "_refresh_tool_prompts", None)
        if callable(refresher):
            refresher()
        return self
