"""TSS node and MPC wallet orchestration helpers for onboarding commands."""

from __future__ import annotations

import asyncio
import hashlib
import os
import platform
import re
import secrets
import shutil
import subprocess
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Any, Callable

import httpx

from cobo_agentic_wallet.client import WalletAPIClient

ProgressReporter = Callable[[str], None]

TSS_NODE_URL_ENV = "CAW_TSS_NODE_URL"
TSS_NODE_STRICT_ENV = "CAW_TSS_NODE_STRICT"
TSS_NODE_REPO_ENV = "CAW_TSS_NODE_REPO"
TSS_NODE_VERSION_ENV = "CAW_TSS_NODE_VERSION"
TSS_NODE_ENV_ENV = "CAW_TSS_NODE_ENV"
DEFAULT_TSS_REPO = "CoboTest/cobo-tss-node-release"
DEFAULT_TSS_DOWNLOAD_BASE_URL = "https://download.tss.cobo.com/binary-release/latest"


def _detect_platform() -> tuple[str, str]:
    """Return (os_name, arch) normalized for TSS node release asset naming."""
    os_name = platform.system().lower()
    machine = platform.machine().lower()
    arch_map = {
        "x86_64": "amd64",
        "amd64": "amd64",
        "aarch64": "arm64",
        "arm64": "arm64",
    }
    arch = arch_map.get(machine)
    if arch is None:
        raise RuntimeError(f"Unsupported architecture: {machine}")
    if os_name not in ("linux", "darwin"):
        raise RuntimeError(f"Unsupported OS: {os_name}")
    return os_name, arch


def _github_auth_headers() -> dict[str, str]:
    """Build GitHub API auth headers from GITHUB_TOKEN if available."""
    token = os.getenv("GITHUB_TOKEN", "").strip()
    if token:
        return {"Authorization": f"token {token}"}
    return {}


def _resolve_latest_version(repo: str, timeout: float) -> str:
    """Fetch the latest release tag from GitHub API."""
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    resp = httpx.get(url, timeout=timeout, follow_redirects=True, headers=_github_auth_headers())
    resp.raise_for_status()
    tag = resp.json().get("tag_name", "").strip()
    if not tag:
        raise RuntimeError("Could not determine latest TSS node release version")
    return tag


def _verify_checksum(
    archive_path: Path,
    asset_name: str,
    repo: str,
    version: str,
    timeout: float,
) -> None:
    """Verify SHA256 checksum against the release SHA256SUMS file (best-effort)."""
    checksum_url = f"https://github.com/{repo}/releases/download/{version}/SHA256SUMS"
    try:
        resp = httpx.get(checksum_url, timeout=timeout, follow_redirects=True)
        resp.raise_for_status()
    except httpx.HTTPError:
        return

    expected = ""
    for line in resp.text.splitlines():
        if asset_name in line:
            expected = line.split()[0]
            break
    if not expected:
        return

    sha256 = hashlib.sha256()
    with archive_path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    actual = sha256.hexdigest()
    if actual != expected:
        raise RuntimeError(
            f"Checksum mismatch for {asset_name}!\n  Expected: {expected}\n  Got:      {actual}"
        )


def _ensure_tss_dir_structure(tss_dir: Path) -> None:
    """Create the standard TSS node directory layout."""
    for subdir in ("configs", "db", "logs", "recovery"):
        (tss_dir / subdir).mkdir(parents=True, exist_ok=True)


def _stream_download(
    url: str,
    dest: Path,
    *,
    timeout: float,
    reporter: ProgressReporter | None,
) -> None:
    """Download a URL to a file with optional progress reporting."""
    downloaded = 0
    with httpx.stream("GET", url, timeout=timeout, follow_redirects=True, verify=False) as response:
        response.raise_for_status()
        with dest.open("wb") as fh:
            for chunk in response.iter_bytes():
                if not chunk:
                    continue
                fh.write(chunk)
                downloaded += len(chunk)


def download_tss_node(
    *,
    destination: str | Path,
    source_url: str | None = None,
    tss_env: str | None = None,
    reporter: ProgressReporter | None = None,
    timeout_seconds: float = 60.0,
) -> Path:
    """Download TSS node binary.

    Resolution order:
    1. ``source_url`` parameter → direct binary download
    2. ``CAW_TSS_NODE_URL`` env var → direct binary download
    3. ``CAW_TSS_NODE_REPO`` env var → GitHub releases (version via ``CAW_TSS_NODE_VERSION``)
    4. Cobo CDN (``download.tss.cobo.com``)

    Set ``CAW_TSS_NODE_STRICT=true`` to error out instead of auto-downloading.
    """
    destination_path = Path(destination).expanduser()
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    if destination_path.exists():
        return destination_path

    url = source_url or os.getenv(TSS_NODE_URL_ENV)
    if url:
        if reporter is not None:
            reporter(f"Downloading TSS-Node from {url}")
        _stream_download(url, destination_path, timeout=timeout_seconds, reporter=reporter)
        os.chmod(destination_path, 0o755)
        _ensure_tss_dir_structure(destination_path.parent)
        return destination_path

    if str(os.getenv(TSS_NODE_STRICT_ENV, "")).strip().lower() in {"1", "true", "yes", "on"}:
        raise RuntimeError(
            "TSS node URL is not configured. Set CAW_TSS_NODE_URL or disable strict mode."
        )

    os_name, arch = _detect_platform()
    if reporter is not None:
        reporter(f"Platform: {os_name}/{arch}")

    asset_name = f"cobo-tss-node-{os_name}-{arch}.tar.gz"

    github_repo = os.getenv(TSS_NODE_REPO_ENV)
    if github_repo:
        version = os.getenv(TSS_NODE_VERSION_ENV, "").strip()
        if not version:
            if reporter is not None:
                reporter("Resolving latest TSS-Node version...")
            version = _resolve_latest_version(github_repo, timeout=timeout_seconds)
        if reporter is not None:
            reporter(f"TSS-Node version: {version}")
        gh_asset = f"cobo-tss-node-{version}-{os_name}-{arch}.tar.gz"
        download_url = f"https://github.com/{github_repo}/releases/download/{version}/{gh_asset}"
        asset_name = gh_asset
    else:
        base_url = DEFAULT_TSS_DOWNLOAD_BASE_URL
        download_url = f"{base_url}/{asset_name}"

    tmp_dir = tempfile.mkdtemp(prefix="caw-tss-")
    try:
        archive_path = Path(tmp_dir) / asset_name
        if reporter is not None:
            reporter(f"Downloading {asset_name}...")
        _stream_download(
            download_url,
            archive_path,
            timeout=timeout_seconds,
            reporter=reporter,
        )

        if github_repo:
            if reporter is not None:
                reporter("Verifying checksum...")
            _verify_checksum(
                archive_path, asset_name, github_repo, version, timeout=timeout_seconds
            )

        if reporter is not None:
            reporter("Extracting archive...")
        with tarfile.open(archive_path, "r:gz") as tar:
            tar.extractall(path=tmp_dir, filter="data")

        candidates = [
            p
            for p in Path(tmp_dir).rglob("cobo-tss-node")
            if p.is_file() and p.name == "cobo-tss-node"
        ]
        if not candidates:
            raise RuntimeError("cobo-tss-node binary not found in archive")
        binary_path = candidates[0]

        tss_dir = destination_path.parent
        _ensure_tss_dir_structure(tss_dir)
        shutil.copy2(binary_path, destination_path)
        os.chmod(destination_path, 0o755)

        if os_name == "darwin":
            subprocess.run(
                ["xattr", "-d", "com.apple.quarantine", str(destination_path)],
                capture_output=True,
            )

        config_dir = tss_dir / "configs"
        templates = list(Path(tmp_dir).rglob("*.yaml.template"))
        if templates and not (config_dir / "cobo-tss-node-config.yaml").exists():
            shutil.copy2(templates[0], config_dir / "cobo-tss-node-config.yaml.template")
            shutil.copy2(templates[0], config_dir / "cobo-tss-node-config.yaml")
            if reporter is not None:
                reporter("Config template installed")

        env_value = tss_env if tss_env is not None else os.getenv(TSS_NODE_ENV_ENV, "dev")
        (tss_dir / ".tss-env").write_text(env_value, encoding="utf-8")

        if reporter is not None:
            reporter(f"TSS-Node installed at {destination_path}")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    return destination_path


def _get_tss_node_id(binary: Path, keyfile: Path, db_path: Path) -> str:
    """Extract TSS Node ID via the ``info`` subcommand.

    Handles log-prefixed output (e.g. ``[2026-03-04 24:50+08:00] Node ID: xxx``)
    by matching ``Node ID: <value>`` and extracting only the value.
    """
    result = subprocess.run(
        [str(binary), "info", "--key-file", str(keyfile), "--db", str(db_path)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return ""
    match = re.search(r"Node ID:\s*(\S+)", result.stdout, re.IGNORECASE)
    if match:
        return match.group(1).strip()
    return result.stdout.strip()


def init_tss_node(
    *,
    tss_binary_path: str | Path,
    config_path: str | Path,
) -> dict[str, str]:
    """Initialize TSS node: generate key file and run ``cobo-tss-node init``.

    Steps (matching ``setup-keyfile.sh`` + ``init-node.sh`` from cobo-tss-node-skill):
    1. Validate binary exists.
    2. Create ``.password`` key file with a random 32-byte URL-safe token.
    3. Ensure directory structure (configs/, db/, logs/, recovery/).
    4. Run ``cobo-tss-node init`` to create the secrets database.
    5. Run ``cobo-tss-node info`` to retrieve the TSS Node ID.
    """
    binary = Path(tss_binary_path).expanduser()
    config = Path(config_path).expanduser()
    if not binary.exists():
        raise FileNotFoundError(f"TSS binary not found: {binary}")
    if not config.exists():
        raise FileNotFoundError(f"CLI config not found: {config}")

    tss_dir = binary.parent
    keyfile = tss_dir / ".password"
    tss_config = tss_dir / "configs" / "cobo-tss-node-config.yaml"
    db_path = tss_dir / "db" / "secrets.db"

    _ensure_tss_dir_structure(tss_dir)

    if not keyfile.exists():
        password = secrets.token_urlsafe(32)
        keyfile.write_text(password, encoding="utf-8")
        keyfile.chmod(0o600)

    if db_path.exists():
        node_id = _get_tss_node_id(binary, keyfile, db_path)
        return {
            "binary_path": str(binary),
            "config_path": str(config),
            "tss_node_id": node_id,
            "status": "already_initialized",
        }

    init_config = tss_config if tss_config.exists() else config

    result = subprocess.run(
        [
            str(binary),
            "init",
            "--key-file",
            str(keyfile),
            "--config",
            str(init_config),
            "--db",
            str(db_path),
        ],
        capture_output=True,
        text=True,
        cwd=str(tss_dir),
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"TSS node init failed (exit {result.returncode}):\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    node_id = _get_tss_node_id(binary, keyfile, db_path)
    return {
        "binary_path": str(binary),
        "config_path": str(config),
        "tss_node_id": node_id,
        "status": "initialized",
    }


def _resolve_tss_env(tss_dir: Path) -> str:
    """Read TSS environment from marker file or env var, default ``dev``."""
    env_file = tss_dir / ".tss-env"
    if env_file.exists():
        return env_file.read_text(encoding="utf-8").strip() or "dev"
    return os.getenv(TSS_NODE_ENV_ENV, "dev")


def _env_start_flag(env: str) -> str:
    """Map environment name to ``cobo-tss-node start`` flag."""
    env_lower = env.strip().lower()
    if env_lower == "prod":
        return "--prod"
    if env_lower == "sandbox":
        return "--sandbox"
    return "--dev"


TSS_PID_FILE = ".tss-node.pid"
TSS_STARTUP_GRACE_SECONDS = 2.0


def start_tss_node(
    *,
    tss_binary_path: str | Path,
    tss_env: str | None = None,
    reporter: ProgressReporter | None = None,
) -> dict[str, Any]:
    """Start TSS node as a background process (matching ``start-node.sh``).

    The process writes stdout/stderr to ``logs/tss-node.log`` and its PID
    is persisted to ``.tss-node.pid`` so it can be stopped later.

    If the node is already running (PID file exists and process alive),
    this is a no-op and returns ``status: already_running``.

    tss_env: Override env for start flag. ``dev`` -> ``--dev``, ``prod`` -> ``--prod``,
    ``sandbox`` -> ``--sandbox``. Default from ``.tss-env`` or ``CAW_TSS_NODE_ENV``.
    """
    binary = Path(tss_binary_path).expanduser()
    if not binary.exists():
        raise FileNotFoundError(f"TSS binary not found: {binary}")

    tss_dir = binary.parent
    keyfile = tss_dir / ".password"
    tss_config = tss_dir / "configs" / "cobo-tss-node-config.yaml"
    db_path = tss_dir / "db" / "secrets.db"
    pid_file = tss_dir / TSS_PID_FILE
    log_file = tss_dir / "logs" / "tss-node.log"

    if not keyfile.exists():
        raise FileNotFoundError(f"Key file not found: {keyfile} (run init first)")
    if not db_path.exists():
        raise FileNotFoundError(f"Database not found: {db_path} (run init first)")

    if pid_file.exists():
        try:
            old_pid = int(pid_file.read_text(encoding="utf-8").strip())
            os.kill(old_pid, 0)
            if reporter is not None:
                reporter(f"TSS-Node already running (PID {old_pid})")
            return {
                "pid": old_pid,
                "binary_path": str(binary),
                "log_file": str(log_file),
                "status": "already_running",
            }
        except (ValueError, OSError):
            pid_file.unlink(missing_ok=True)

    resolved_env = tss_env if tss_env is not None else _resolve_tss_env(tss_dir)
    start_flag = _env_start_flag(resolved_env)

    log_file.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        str(binary),
        "start",
        "--caw",
        start_flag,
        "--key-file",
        str(keyfile),
        "--db",
        str(db_path),
    ]
    if tss_config.exists():
        cmd.extend(["--config", str(tss_config)])

    if reporter is not None:
        reporter(f"Starting TSS-Node (env: {resolved_env}, flag: {start_flag})...")

    log_fh = log_file.open("a", encoding="utf-8")
    proc = subprocess.Popen(
        cmd,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        cwd=str(tss_dir),
        start_new_session=True,
    )

    pid_file.write_text(str(proc.pid), encoding="utf-8")

    time.sleep(TSS_STARTUP_GRACE_SECONDS)
    exit_code = proc.poll()
    if exit_code is not None:
        log_fh.close()
        pid_file.unlink(missing_ok=True)
        tail = ""
        try:
            tail = log_file.read_text(encoding="utf-8")[-500:]
        except OSError:
            pass
        raise RuntimeError(f"TSS-Node exited immediately (code {exit_code}).\nLog tail:\n{tail}")

    if reporter is not None:
        reporter(f"TSS-Node started (PID {proc.pid}), logs at {log_file}")

    return {
        "pid": proc.pid,
        "binary_path": str(binary),
        "log_file": str(log_file),
        "status": "running",
    }


def stop_tss_node(
    *,
    tss_binary_path: str | Path,
    reporter: ProgressReporter | None = None,
) -> dict[str, str]:
    """Stop a running TSS node by its PID file."""
    import signal

    tss_dir = Path(tss_binary_path).expanduser().parent
    pid_file = tss_dir / TSS_PID_FILE

    if not pid_file.exists():
        return {"status": "not_running"}

    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        pid_file.unlink(missing_ok=True)
        return {"status": "not_running"}

    try:
        os.kill(pid, signal.SIGTERM)
        if reporter is not None:
            reporter(f"Sent SIGTERM to TSS-Node (PID {pid})")
        for _ in range(10):
            time.sleep(0.5)
            try:
                os.kill(pid, 0)
            except OSError:
                break
        else:
            os.kill(pid, signal.SIGKILL)
            if reporter is not None:
                reporter(f"Sent SIGKILL to TSS-Node (PID {pid})")
    except OSError:
        pass

    pid_file.unlink(missing_ok=True)
    if reporter is not None:
        reporter("TSS-Node stopped")
    return {"pid": pid, "status": "stopped"}


async def create_mpc_wallet(
    *,
    client: WalletAPIClient,
    main_node_id: str,
    group_type: str = "agent",
    name: str = "default",
    backup_node_id: str | None = None,
    for_owner: bool = False,
) -> dict[str, Any]:
    """Create MPC wallet through create_wallet API and return normalized payload.

    Uses main_node_id from the TSS node (from init_tss_node) and group_type
    (default "agent" for 2/2 MPC).
    """
    payload = await client.create_wallet(
        name=name,
        wallet_type="MPC-UCW",
        main_node_id=main_node_id,
        group_type=group_type,
        backup_node_id=backup_node_id,
        for_owner=for_owner,
    )
    if not isinstance(payload, dict):
        raise RuntimeError("Invalid wallet creation response: expected object")
    # Normalize uuid for callers expecting wallet_uuid
    if "uuid" in payload and "wallet_uuid" not in payload:
        payload = {**payload, "wallet_uuid": payload["uuid"]}
    return payload


async def poll_wallet_status(
    *,
    client: WalletAPIClient,
    wallet_uuid: str,
    poll_interval_seconds: float = 2.0,
    timeout_seconds: float = 300.0,
) -> dict[str, Any]:
    """Poll wallet status until active/failed or timeout."""
    started_at = time.monotonic()
    while True:
        payload = await client.get_wallet(wallet_uuid)
        if not isinstance(payload, dict):
            raise RuntimeError("Invalid wallet status response: expected object")
        status_value = str(payload.get("status", "")).strip().lower()
        if status_value == "active":
            return payload
        if status_value == "failed":
            error_value = payload.get("error")
            if error_value:
                raise RuntimeError(f"MPC wallet provisioning failed: {error_value}")
            raise RuntimeError("MPC wallet provisioning failed")
        if time.monotonic() - started_at >= timeout_seconds:
            raise TimeoutError(f"Timed out waiting for wallet activation: {wallet_uuid}")
        await asyncio.sleep(max(0.0, poll_interval_seconds))
