"""Faucet commands – request test tokens."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agentic_wallet.cli._common import run_command
from cobo_agentic_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("tokens")
def list_tokens(ctx: typer.Context) -> None:
    """List available testnet tokens grouped by chain. Use the token IDs with 'caw faucet deposit'."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_tokens()

    run_command(ctx, _operation)


@app.command("deposit")
def deposit(
    ctx: typer.Context,
    address: str = typer.Option(
        ..., "--address", "-a", help="Wallet address to receive the testnet tokens."
    ),
    token: str = typer.Option(
        ...,
        "--token",
        "-t",
        help="Token ID to request (e.g. SETH_USDC, SOLDEV_SOL_USDC). Use 'caw faucet tokens' to list available tokens.",
    ),
) -> None:
    """Request testnet tokens for a wallet address. Useful for funding a wallet before testing transfers."""

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.deposit(address=address, token_id=token)

    run_command(ctx, _operation)
