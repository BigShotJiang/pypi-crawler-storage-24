"""TSS Node management commands — status, start, stop, restart, info, health, logs."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Any

import typer

from cobo_agentic_wallet.cli._common import get_context
from cobo_agentic_wallet.cli._output import emit
from cobo_agentic_wallet.cli.config import (
    TSS_NODE_BINARY_NAME,
    TSS_NODE_DIR_NAME,
    get_default_profile,
    resolve_config_path,
    resolve_tss_binary_path,
)
from cobo_agentic_wallet.cli.tss import (
    TSS_PID_FILE,
    _get_tss_node_id,
    _resolve_tss_env,
    start_tss_node,
    stop_tss_node,
)

app = typer.Typer(no_args_is_help=True)


def _resolve_tss_dir() -> Path:
    """Resolve the TSS node directory for the active profile.

    Falls back to the parent of the credentials file for legacy layouts.
    """
    profile = get_default_profile()
    if profile:
        return resolve_tss_binary_path(profile).parent
    creds = resolve_config_path()
    return creds.parent / TSS_NODE_DIR_NAME


def _resolve_binary() -> Path:
    profile = get_default_profile()
    if profile:
        return resolve_tss_binary_path(profile)
    creds = resolve_config_path()
    return creds.parent / TSS_NODE_DIR_NAME / TSS_NODE_BINARY_NAME


def _read_pid(tss_dir: Path) -> int | None:
    pid_file = tss_dir / TSS_PID_FILE
    if not pid_file.exists():
        return None
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)
        return pid
    except (ValueError, OSError):
        return None


@app.command("status")
def status(ctx: typer.Context) -> None:
    """Show TSS Node running status for the active profile."""
    context = get_context(ctx)
    tss_dir = _resolve_tss_dir()
    binary = _resolve_binary()
    pid = _read_pid(tss_dir)

    result: dict[str, Any] = {
        "tss_dir": str(tss_dir),
        "binary_exists": binary.exists(),
        "running": pid is not None,
        "pid": pid,
        "env": _resolve_tss_env(tss_dir) if tss_dir.exists() else None,
    }
    emit(result, context.output_format)


@app.command("info")
def info(ctx: typer.Context) -> None:
    """Show TSS Node ID and metadata."""
    context = get_context(ctx)
    tss_dir = _resolve_tss_dir()
    binary = _resolve_binary()
    keyfile = tss_dir / ".password"
    db_path = tss_dir / "db" / "secrets.db"

    if not binary.exists():
        typer.echo("TSS binary not found. Run 'caw onboard --create-wallet' first.", err=True)
        raise typer.Exit(1)

    node_id = _get_tss_node_id(binary, keyfile, db_path) if db_path.exists() else ""
    result: dict[str, Any] = {
        "tss_dir": str(tss_dir),
        "node_id": node_id or None,
        "binary_path": str(binary),
        "db_exists": db_path.exists(),
        "env": _resolve_tss_env(tss_dir),
    }
    emit(result, context.output_format)


@app.command("health")
def health(ctx: typer.Context) -> None:
    """Run health checks on the TSS Node: binary, db, keyfile, process, disk."""
    context = get_context(ctx)
    tss_dir = _resolve_tss_dir()
    binary = _resolve_binary()
    keyfile = tss_dir / ".password"
    db_path = tss_dir / "db" / "secrets.db"
    config_file = tss_dir / "configs" / "cobo-tss-node-config.yaml"
    pid = _read_pid(tss_dir)

    checks: dict[str, Any] = {
        "tss_dir": str(tss_dir),
        "binary_exists": binary.exists(),
        "db_exists": db_path.exists(),
        "db_size_bytes": db_path.stat().st_size if db_path.exists() else None,
        "config_exists": config_file.exists(),
        "keyfile_exists": keyfile.exists(),
        "keyfile_mode": None,
        "running": pid is not None,
        "pid": pid,
        "env": _resolve_tss_env(tss_dir) if tss_dir.exists() else None,
        "node_id": None,
    }

    if keyfile.exists():
        mode = oct(keyfile.stat().st_mode & 0o777)
        checks["keyfile_mode"] = mode
        checks["keyfile_mode_ok"] = mode == "0o600"

    if binary.exists() and db_path.exists():
        checks["node_id"] = _get_tss_node_id(binary, keyfile, db_path) or None

    try:
        stat = os.statvfs(str(tss_dir)) if tss_dir.exists() else None
        if stat:
            checks["disk_available_mb"] = (stat.f_bavail * stat.f_frsize) // (1024 * 1024)
    except OSError:
        pass

    all_ok = all(
        [
            checks["binary_exists"],
            checks["db_exists"],
            checks["config_exists"],
            checks["keyfile_exists"],
            checks.get("keyfile_mode_ok", False),
            checks["running"],
        ]
    )
    checks["healthy"] = all_ok

    emit(checks, context.output_format)
    if not all_ok:
        raise typer.Exit(1)


@app.command("start")
def start(ctx: typer.Context) -> None:
    """Start the TSS Node for the active profile."""
    context = get_context(ctx)
    binary = _resolve_binary()
    if not binary.exists():
        typer.echo("TSS binary not found. Run 'caw onboard --create-wallet' first.", err=True)
        raise typer.Exit(1)
    result = start_tss_node(
        tss_binary_path=binary,
        reporter=lambda msg: typer.echo(msg, err=True),
    )
    emit(result, context.output_format)


def _check_pending_transactions(ctx: typer.Context) -> list[dict[str, Any]]:
    """Return pending transactions for the active wallet, empty list if none or unavailable.

    Best-effort check — returns empty list on any failure (missing config,
    missing API key, network errors, etc.) so that ``stop --force`` is not
    the only way to proceed when the API is unreachable.
    """
    import asyncio

    from cobo_agentic_wallet.cli._common import make_client
    from cobo_agentic_wallet.cli.config import load_config

    try:
        wallet_uuid = str(load_config().get("wallet_uuid", "")).strip() or None
    except (FileNotFoundError, ValueError, OSError):
        return []
    if not wallet_uuid:
        return []

    context = get_context(ctx)
    if not context.api_key:
        return []

    async def _query() -> Any:
        client = make_client(context, api_key=context.api_key)
        try:
            return await client.list_transaction_records(wallet_uuid, status="pending", limit=10)
        finally:
            await client.close()

    try:
        result = asyncio.run(_query())
    except Exception:
        return []

    if isinstance(result, list):
        return result
    if isinstance(result, dict):
        items = result.get("items") or result.get("transactions") or result.get("data")
        if isinstance(items, list):
            return items
    return []


@app.command("stop")
def stop(
    ctx: typer.Context,
    force: bool = typer.Option(
        False, "--force", "-f", help="Stop even if there are pending transactions."
    ),
) -> None:
    """Stop the TSS Node for the active profile.

    Checks for pending transactions before stopping. Use --force to skip the check.
    """
    context = get_context(ctx)

    if not force:
        pending = _check_pending_transactions(ctx)
        if pending:
            count = len(pending)
            typer.echo(
                f"Cannot stop: {count} pending transaction(s) found. "
                "Wait for them to complete or use --force to stop anyway.",
                err=True,
            )
            raise typer.Exit(1)

    binary = _resolve_binary()
    result = stop_tss_node(
        tss_binary_path=binary,
        reporter=lambda msg: typer.echo(msg, err=True),
    )
    emit(result, context.output_format)


@app.command("restart")
def restart(ctx: typer.Context) -> None:
    """Restart the TSS Node (stop then start)."""
    context = get_context(ctx)
    binary = _resolve_binary()
    if not binary.exists():
        typer.echo("TSS binary not found. Run 'caw onboard --create-wallet' first.", err=True)
        raise typer.Exit(1)
    stop_result = stop_tss_node(
        tss_binary_path=binary,
        reporter=lambda msg: typer.echo(msg, err=True),
    )
    start_result = start_tss_node(
        tss_binary_path=binary,
        reporter=lambda msg: typer.echo(msg, err=True),
    )
    result: dict[str, Any] = {
        "stop": stop_result.get("status", "unknown"),
        **start_result,
    }
    emit(result, context.output_format)


@app.command("logs")
def logs(
    ctx: typer.Context,
    lines: int = typer.Option(50, "--lines", "-n", help="Number of log lines to display."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Tail the log in real time."),
) -> None:
    """View TSS Node log output."""
    tss_dir = _resolve_tss_dir()
    log_file = tss_dir / "logs" / "tss-node.log"

    if not log_file.exists():
        typer.echo("No log file found.", err=True)
        raise typer.Exit(1)

    if follow:
        try:
            subprocess.run(["tail", "-f", str(log_file)], check=False)
        except KeyboardInterrupt:
            pass
        return

    content = log_file.read_text(encoding="utf-8", errors="replace")
    tail = "\n".join(content.splitlines()[-lines:])
    typer.echo(tail)
