import hashlib
import hmac
import ipaddress
import time

from flask import request

from lesscode_flask.model.response_result import ResponseResult
from lesscode_flask.utils.redis.redis_helper import RedisHelper

SIGN_ERROR_MESSAGE = "未知错误"


def _body_sha256() -> str:
    # 对原始请求体做哈希，保证不同 content-type 下签名输入一致。
    body_bytes = request.get_data(cache=True) or b""
    return hashlib.sha256(body_bytes).hexdigest()


def _is_upload_request() -> bool:
    # 上传文件请求：multipart/form-data 或存在文件字段。
    content_type = (request.content_type or "").lower()
    return content_type.startswith("multipart/form-data") or bool(request.files)


def _canonical_sign_content(timestamp: str, nonce: str) -> str:
    # 规范签名串格式：
    # METHOD \n PATH \n QUERY_STRING \n BODY_SHA256 \n TIMESTAMP \n NONCE
    method = request.method.upper()
    path = request.path
    query_string = (request.query_string or b"").decode("utf-8")
    if _is_upload_request():
        # 上传请求忽略body参与签名时，固定使用空串哈希。
        body_hash = hashlib.sha256(b"").hexdigest()
    else:
        body_hash = _body_sha256()
    return f"{method}\n{path}\n{query_string}\n{body_hash}\n{timestamp}\n{nonce}"


def _in_sign_white_list(white_list: list) -> bool:
    # 白名单匹配规则：只要请求路径以前缀命中就跳过签名校验。
    if not white_list:
        return False
    request_path = request.path or ""
    for white_item in white_list:
        if white_item and request_path.startswith(white_item):
            return True
    return False


def _request_client_ip() -> str:
    # 优先读取公司网关透传IP，再回退到常见代理头和直连IP。
    remote_addr_header = request.headers.get("remote-addr", "").strip()
    if remote_addr_header:
        return remote_addr_header

    x_forwarded_for = request.headers.get("X-Forwarded-For", "")
    if x_forwarded_for:
        client_ip = x_forwarded_for.split(",")[0].strip()
        if client_ip:
            return client_ip
    x_real_ip = request.headers.get("X-Real-IP", "").strip()
    if x_real_ip:
        return x_real_ip
    return (request.remote_addr or "").strip()


def _in_sign_ip_white_list(ip_white_list: list) -> bool:
    # IP白名单支持单IP和CIDR网段，例如：["10.0.0.1", "10.10.0.0/16"]。
    if not ip_white_list:
        return False
    client_ip = _request_client_ip()
    if not client_ip:
        return False
    try:
        client_ip_obj = ipaddress.ip_address(client_ip)
    except ValueError:
        return False

    for item in ip_white_list:
        white_item = (item or "").strip()
        if not white_item:
            continue
        try:
            if "/" in white_item:
                if client_ip_obj in ipaddress.ip_network(white_item, strict=False):
                    return True
            elif client_ip_obj == ipaddress.ip_address(white_item):
                return True
        except ValueError:
            # 非法配置项直接跳过，避免影响其它合法项匹配。
            continue
    return False


def verify_request_signature(app):
    # 签名校验在 token/权限校验前执行。
    # 关闭开关时，直接放行，不影响现有接口。
    if not app.config.get("SIGN_ENABLE", False):
        return
    # 公司内部IP可走白名单，命中则跳过签名校验。
    if _in_sign_ip_white_list(app.config.get("SIGN_IP_WHITE_LIST", [])):
        return
    # 预检请求通常不带业务签名，默认忽略。
    if request.method in app.config.get("SIGN_IGNORE_METHODS", ["OPTIONS"]):
        return
    # 白名单接口不做签名校验，例如登录、swagger等入口。
    if _in_sign_white_list(app.config.get("SIGN_WHITE_LIST", [])):
        return

    # 读取签名相关请求头，固定使用无前缀命名。
    timestamp = request.headers.get("Timestamp", "")
    nonce = request.headers.get("Nonce", "")
    signature = request.headers.get("Signature", "")
    sign_secret = app.config.get("SIGN_SECRET", "")

    # 任何签名基础参数缺失都统一返回“未知错误”，避免向外暴露细节。
    if not timestamp or not nonce or not signature:
        ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")
    # 服务端密钥未配置时也拦截，防止“空密钥”误放行。
    if not sign_secret:
        ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")

    # 时间戳必须是整数秒。
    try:
        ts = int(timestamp)
    except (TypeError, ValueError):
        ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")
        return

    # 时间窗校验，防止旧请求被重放。
    sign_window_sec = int(app.config.get("SIGN_WINDOW_SEC", 300))
    now_ts = int(time.time())
    if abs(now_ts - ts) > sign_window_sec:
        ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")

    if app.config.get("SIGN_NONCE_ENABLE", True):
        # 防重放：同一个 nonce 在 TTL 窗口内只能使用一次。
        nonce_key = f"sign:nonce:{nonce}"
        nonce_ttl = int(app.config.get("SIGN_NONCE_TTL_SEC", sign_window_sec))
        try:
            ok = RedisHelper(app.config.get("REDIS_LIMIT_KEY", "redis")).sync_set(
                nonce_key, "1", ex=nonce_ttl, nx=True
            )
            if not ok:
                ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")
        except Exception:
            # Redis 异常按失败处理，避免在防重放失效时放过请求。
            ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")

    # 按统一规则组装签名串并计算服务端签名。
    sign_content = _canonical_sign_content(timestamp=timestamp, nonce=nonce)
    expected = hmac.new(
        sign_secret.encode("utf-8"),
        sign_content.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    # 常量时间比较，降低时序侧信道风险。
    if not hmac.compare_digest(expected, signature):
        ResponseResult.fail(message=SIGN_ERROR_MESSAGE, status_code="401", http_code="401")
