import hashlib
import logging

import json

import requests

from lesscode_flask.utils.helpers import app_config
from lesscode_flask.utils.redis.redis_helper import RedisHelper

logger = logging.getLogger(__name__)

_FS_WEBHOOK_CACHE_TTL = 3 * 60 * 60  # 3小时，单位秒


def fs_webhook(webhook_url: str, title: str, fs_content: list):
    """
    发送飞书 webhook 消息。3小时内相同内容不重复发送。

    :param webhook_url: 飞书 webhook 的 URL 地址
    :param title: 消息的标题
    :param fs_content: 消息内容列表
    """
    # 构建缓存 key：对 webhook_url + title + content 做 MD5 哈希
    cache_raw = (
        f"{webhook_url}:{title}:"
        f"{json.dumps(fs_content, ensure_ascii=False, sort_keys=True)}"
    )
    cache_key = "fs_webhook:" + hashlib.md5(cache_raw.encode("utf-8")).hexdigest()

    # 检查 Redis 中是否已存在该 key（3小时内已发送过）
    redis = None
    try:
        redis_oauth_key = app_config.get("REDIS_OAUTH_KEY", "redis")
        redis = RedisHelper(redis_oauth_key)
        if redis.sync_exists(cache_key):
            logger.info("fs_webhook 重复内容，跳过发送，cache_key=%s", cache_key)
            return
    except Exception:  # pylint: disable=broad-except
        logger.warning("fs_webhook Redis 检查失败，继续发送")

    headers = {'Content-Type': 'application/json;charset=utf-8'}

    # 构造飞书消息的 JSON 结构
    json_text = {
        "msg_type": "post",
        "content": {
            "post": {
                "zh_cn": {
                    "title": title,
                    "content": [
                        fs_content
                    ]
                }
            }
        }
    }

    # 发送 POST 请求并记录响应结果
    result = requests.post(webhook_url, json.dumps(json_text), headers=headers, timeout=10).content
    logger.info(result)

    # 发送成功后写入 Redis 缓存，3小时内不再重复发送
    if redis is not None:
        try:
            redis.sync_set(cache_key, "1", ex=_FS_WEBHOOK_CACHE_TTL)
        except Exception:  # pylint: disable=broad-except
            logger.warning("fs_webhook Redis 写入缓存失败")
