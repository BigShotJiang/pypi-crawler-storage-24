
# yu-pytools

## 描述
YuHaoran的python工具包
Python tools for climate data analysis.
主要用来做气候数据的数据挖掘工作。

## Modules
1. **ETCCDI** - Extreme climate indices calculation
2. **SDD** - Spatial Data Mining  
3. **NCC** - Climate change statistics

## Installation

```bash
pip install yu-pytools
