const s=["discover","search","party","artists","albums","tracks","playlists","audiobooks","podcasts","radios","genres","browse","settings"];export{s as D};
