from typing import Callable
import numpy as np


def running_mean(
    result,
    name,
    window_duration: int = 10,
    window_function: Callable = np.blackman,
    trim=True,
):
    check_time_linearly_increasing(result.index)
    time_diff = np.diff(result.index)
    mean_time_diff = np.mean(time_diff)

    window_length = window_duration // mean_time_diff
    window_length = min(len(result), window_length)
    window = window_function(window_length)

    normalized_window = window / np.sum(window)
    convolution = np.convolve(result[name], normalized_window, mode="same")

    if trim:
        len_window = len(normalized_window) // 2
        convolution[:len_window] = np.nan
        convolution[-len_window:] = np.nan

    return {f"mean_{name}": convolution}


def check_time_linearly_increasing(time):
    time_diff = np.diff(time)
    mean_time_diff = np.mean(time_diff)
    if not np.allclose(time_diff, mean_time_diff) or mean_time_diff <= 0:
        msg = "Time should be linearly increasing. Run the simulation with a fixed `time_step`."
        raise ValueError(msg)
