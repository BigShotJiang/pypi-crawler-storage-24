from __future__ import annotations

import hashlib
import itertools
from collections.abc import Callable
from typing import Literal, Self

import attrs
import numpy as np
import pandas as pd
from scipy import integrate
from attrs import field, validate
from frozendict import frozendict

from physiomodeler import _helpers as h
from physiomodeler import _converters as c
from physiomodeler import _validators as v
from physiomodeler.settings import load_settings
from physiomodeler._helpers import (
    TimeUnitsType,
    TimeSpec,
    SimulationResults,
    FunctionMeta,
)

settings = load_settings()


@attrs.define()
class Model:
    """A state-space model described by system dynamics and parameters.

    This class can be used to describe and numerically analyze a state space
    model. A state-space model has at least one state variable that evolves
    over time based on the state, as well as the inputs to and parameters of
    the model.

    The model is described by one or multiple dynamics (functions, submodels, or
    combinations thereof) that define how the state changes. A dynamics function
    can have `time`, `state`, `inputs` and `parameters` as arguments. Each
    dynamics function should return a dictionary containing state derivatives and
    other value outputs. Dynamics are called in the order they are provided. The
    output of each dynamics is added to the input of later dynamics. State
    derivatives can be returned by different dynamics, but a derivative should be
    returned for all state variables.

    By default, the key for a state derivative should be "d" + the state label,
    e.g. "dvelocity" for the state "velocity". Alternatively, you can supply a
    mapping dictionary `state_derivative_label_map` where the key is the state
    variable label and the value is the state derivative label.

    Inputs and parameters both contain values that can be used by the update
    function. There is, however, a distinction between inputs and parameters.
    Parameters are fixed values that are independent of time, e.g. the mass of
    an object at the end of a pendulum. Inputs are disturbances added to the
    system, and can be either fixed or variable with time, e.g. the force
    applied to a moving mass. `inputs` and `parameters` are both dictionaries.
    `inputs` values can be functions with the signature `fun(time, inputs,
    parameters)`, which are converted to the appropriate before being passed to
    the update function.

    Events are functions with a signature `fun(time, state, inputs,
    parameters)`. An event occurs when a function returns `0`. The solver will
    find an accurate value of `time` where `fun(time, ...) == 0`. This ensures
    proper simulation around that time point. Each event function can be marked
    'terminal' by adding the `terminal` attribute with value `True` to the event
    function (`fun.terminal = True`). This results in the simulation being
    terminated as soon as the event return value crosses `0`. See
    [`scipy.integrate.solve_ivp`](https://docs.scipy.org/doc/scipy-1.14.1/reference/reference/generated/scipy.integrate.solve_ivp.html#scipy.integrate.solve_ivp)
    for more details.

    Post analysis functions can be supplied, which receive the output of the
    system as a pandas DataFrame (see `run_simulation`) and either
    update the dataframe or return an array, list, Series or DataFrame object
    with the same length that is added to the output of the model.

    Example:
        The example below is the classic undampended pendulum. The system is
        governed by the second derivative of the angle theta. The system state has
        two components: the current angle "theta" and the angular velocity
        "dtheta". The function `pendulum()` calculates the second derivative and
        returns both the first and second derivative. When this system is solved,
        the new state is calculated based on the derivatives of the previous step.

        ```
        >>> def pendulum(time, state, inputs, parameters):
        ...     g = parameters["g"]
        ...     l = parameters["l"]
        ...     theta = state["theta"]
        ...
        ...     first_derivative_theta = state["dtheta"]
        ...     second_derivative_theta = -(g / l) * np.sin(theta)
        ...
        ...     return {
        ...         "dtheta": first_derivative_theta,
        ...         "ddtheta": second_derivative_theta
        ...     }
        >>> model = Model(
        ...     function=pendulum,
        ...     state=("theta", "dtheta"),
        ...     parameters={"g": 9.81, "l": 1},
        ... )
        >>> df = model.run_simulation(time=10, initial_state=(0.1, 0))
        ```

    Args:
        function (Callable | list[Callable]): function(s) with accepting time, state, inputs and
            parameters as arguments and returning a dictionary containing (at
            least) the state derivatives
        state (list | dict): list of state labels, or a dictionary with the intial values of the state
        inputs (dict): dictionary containing the inputs as name/value pairs
        parameters (dict): a dictionary containing the parameters of the model
        post_analysis (dict): optional, a dictionary containing functions to calculate
            values based on the output of the model
        state_derivative_label_map (dict): optional, a dictionary mapping the labels
            of the state derivatives to the labels of the state variables.

    """

    name: str = field(
        default=attrs.Factory(
            lambda s: hashlib.shake_256(str(id(s)).encode()).hexdigest(4), True
        ),
        kw_only=True,
        eq=False,
    )
    dynamics: list[Callable] = attrs.field(
        converter=attrs.converters.pipe(
            c.convert_single_function_to_list,
            c.convert_nonstr_sequence_to_list,
            c.convert_models_to_functions,
        ),
        validator=v.validate_functions_field,
        eq=attrs.cmp_using(eq=h.compare_function_lists),
    )
    state_components: list[str] = attrs.field(
        default=[],
        converter=c.convert_nonstr_sequence_to_list,
        validator=v.validate_state_components_field,
        kw_only=True,
    )
    initial_state: dict[str, float] = attrs.field(
        default={}, validator=v.validate_initial_state_field, kw_only=True
    )
    state_derivative_label_map: dict[str, str] = attrs.field(
        default={}, validator=v.validate_state_derivative_label_map_field, kw_only=True
    )
    inputs: dict[str, float | int | Callable] = attrs.field(
        default={}, validator=v.validate_inputs_field, kw_only=True
    )
    parameters: dict[str, int | float | str | bool | list | tuple] = attrs.field(
        default={}, validator=v.validate_parameters_field, kw_only=True
    )
    events: list[Callable] = attrs.field(
        default=[],
        converter=c.convert_nonstr_sequence_to_list,
        validator=v.validate_events_field,
        kw_only=True,
    )
    post_analysis: list[Callable] = attrs.field(
        default=[],
        converter=c.convert_nonstr_sequence_to_list,
        validator=v.validate_post_analysis_field,
        kw_only=True,
    )
    time_units: TimeUnitsType = attrs.field(
        default=None, kw_only=True, validator=v.validate_time_units_field
    )

    def __init__(
        self,
        dynamics: Callable | "Model" | list[Callable | "Model"],
        *,
        state_components: list[str] | None = None,
        initial_state: dict[str, float] | None = None,
        state_derivative_label_map: dict[str, str] | None = None,
        inputs: dict[str, float | int | Callable] | None = None,
        parameters: dict[str, int | float | str | bool | list | tuple] | None = None,
        events: list[Callable] | None = None,
        post_analysis: list[Callable] | None = None,
        time_units: TimeUnitsType | None = None,
        name: str | None = None,
    ):
        """Initialize a Model instance.

        Args:
            dynamics: System dynamics defining state evolution. Can be a single function,
                Model instance, or list of callables/Models.
            state_components: Optional list of state variable labels.
            initial_state: Optional initial values for state variables as dict.
            state_derivative_label_map: Maps state labels to their derivative labels.
                If not provided, defaults are generated from settings.
            inputs: Model inputs as dict. Values can be constants or time-dependent functions.
            parameters: Model parameters as dict. Fixed values independent of time.
            events: List of event detection functions.
            post_analysis: List of post-simulation analysis functions.
            time_units: Units for time axis in output (e.g., "s", "ms").
            name: Optional model name. Auto-generated if not provided.
        """
        dynamics = c.convert_single_function_to_list(dynamics)
        dynamics = c.convert_nonstr_sequence_to_list(dynamics)

        state_components = state_components or []
        initial_state = initial_state or {}
        parameters = parameters or {}
        state_derivative_label_map = state_derivative_label_map or {}

        # gather state labels and initial state from submodels
        # this needs to be done before __attrs_init__ is called, because
        # __attrs_init__ requires the correct state labels to be set
        for function in dynamics:
            if not isinstance((model := function), Model):
                continue

            validate(model)

            for state_label in model.state_components:
                if state_label not in state_components:
                    state_components.append(state_label)
                    # Update derivative label mapping if available
                    if (
                        state_label in model.state_derivative_label_map
                        and state_label not in state_derivative_label_map
                    ):
                        state_derivative_label_map[state_label] = (
                            model.state_derivative_label_map[state_label]
                        )

                # Update initial state if not already set
                if (
                    state_label in model.initial_state
                    and state_label not in initial_state
                ):
                    initial_state[state_label] = model.initial_state[state_label]

        getattr(self, "__attrs_init__")(
            dynamics=dynamics,
            state_components=state_components,
            initial_state=initial_state,
            state_derivative_label_map=state_derivative_label_map or {},
            inputs=inputs or {},
            parameters=parameters or {},
            events=events or [],
            post_analysis=post_analysis or [],
            time_units=time_units,
            name=name,
        )

    def __attrs_post_init__(self):
        # make sure every state has a derivative label

        default_state_derivative_label_map = {
            k: settings.templates.state_derivative_label.format(state_label=k)
            for k in self.state_components
        }
        object.__setattr__(
            self,
            "state_derivative_label_map",
            default_state_derivative_label_map | self.state_derivative_label_map,
        )

        # make sure every state has an initial value
        default_initial_state = {k: 0.0 for k in self.state_components}
        object.__setattr__(
            self, "initial_state", default_initial_state | self.initial_state
        )

        validate(self)

    @property
    def state_derivative_labels(self):
        return list(self.state_derivative_label_map.values())

    def run_simulation(  # noqa: F811
        self,
        *,
        time: float
        | tuple[float, float]
        | tuple[float, float, float]
        | TimeSpec
        | list
        | np.ndarray,
        initial_state: dict | None = None,
        inputs: dict | None = None,
        parameters: dict | None = None,
        solve_ivp_method: Literal["Radau"] = "Radau",
        relative_tolerance: float | None = None,
        absolute_torelance: float | None = None,
        result_index_as_time: bool = False,
        solver_output: dict | None = None,
    ):
        """Generate an output based on the given initial state, inputs and
        parameters.

        This function generates the output of the model over a given time axis
        based on an initial state, the inputs and parameters. If no or not all
        the `initial_state`, `inputs` or `parameters` values are given, the
        values provided to the system at initialisation are used instead.

        The time can be passed in several ways. The simplest is passing a
        duration. The model will be solved up to that duration. When `time` is
        a tuple of length 2, it indicates the start and end time. (Note that
        the initial state is the state at `t=start`, not at `t=0`.) The time
        step will be `time_step` if supplied, or determined by the solver otherwise.
        If `time` is a tuple of length 3, the last value is used as the time
        step. If a list or array is supplied, the output will contain these
        time points.

        Relative and absolute tolerance for the solver. The solver estimates a
        local error as `absolute_torelance + relative_tolerance * abs(state)`. `relative_tolerance` controls a relative
        accuracy ('number of correct digits') while `absolute_torelance` controls absolute
        accuracy ('number of correct decimal places'). See
        [`scipy.integrate.solve_ivp`](https://docs.scipy.org/doc/scipy-1.14.1/reference/reference/generated/scipy.integrate.solve_ivp.html#scipy.integrate.solve_ivp)
        for more details.

        Args:
            initial_state (dict): optional, initial values for the state as a
                dictionary, or list/tuple of values
            inputs (dict): optional, inputs of the system as a dictionary or
                list/tuple of values
            parameters (dict): optional, dictionary with the parameters of the system
            time (float | TimeSpec | tuple | np.ndarray): Time specification. Can be:
                - float: total duration from 0 to time
                - TimeSpec: start, end, and optional step (use keyword args for clarity)
                - tuple[start, end]: time range
                - tuple[start, end, step]: time range with step
                - list/ndarray: specific time points

                Examples:
                  time=10  # Simulate 0 to 10
                  time=TimeSpec(start=0, end=10)  # Start to end
                  time=TimeSpec(start=0, end=10, step=0.1)  # With step
            solve_ivp_method (str): solver used; currently only "Radau" is supported
            relative_tolerance (float | None): relative tolerance
            absolute_torelance (float | None): absolute tolerance
        """

        validate(self)

        inputs = v.validate_inputs(inputs)
        parameters = v.validate_parameters(parameters)
        initial_state = v.validate_initial_state(
            initial_state, self.initial_state, self.state_components
        )
        (t_start, t_end, time_) = c.convert_time(time)

        solve_ivp_func, full_output_func, running_output = self.get_functions(
            inputs, parameters
        )
        # Only pass runtime parameters (not model's own parameters)
        runtime_params = parameters if parameters else {}
        events = h.wrap_nested_events(
            model=self,
            state_components=self.state_components,
            inputs=running_output,
            runtime_parameters=runtime_params,
        )

        rtol = relative_tolerance or settings.simulation.relative_tolerance
        atol = absolute_torelance or settings.simulation.absolute_tolerance

        solution = integrate.solve_ivp(
            solve_ivp_func,
            (t_start, t_end),
            [initial_state[k] for k in self.state_components],
            method=solve_ivp_method,
            t_eval=time_,
            events=events,
            rtol=rtol,
            atol=atol,
            vectorized=False,
        )
        if solver_output is not None:
            solver_output.update(**solution)

        # generate an output for each timepoint/state combination
        all_outputs = list(
            full_output_func(time, state)
            for time, state in zip(solution.t, solution.y.T)
        )
        output_keys = all_outputs[0].keys()

        # zip all outputs
        zipped_outputs = {k: [o[k] for o in all_outputs] for k in output_keys}
        if result_index_as_time:
            if not self.time_units:
                raise ValueError(
                    "Time units set to None, cannot convert index to timedelta."
                )
            index_name = "time"
            time = pd.to_timedelta(solution.t, unit=self.time_units)
        else:
            index_name = f"time ({self.time_units})" if self.time_units else "time"
            time = solution.t

        data_frame = pd.DataFrame(
            index=pd.Index(data=time, name=index_name),
            data=zipped_outputs,
        )

        for func in self.post_analysis:
            result = func(data_frame.copy())
            if result is None:
                raise TypeError(
                    f"Post-analysis function '{func.__name__}' does not return any values."
                )
            if isinstance(result, pd.Series):
                result = result.to_frame()

            if isinstance(result, dict):
                if not len(result):
                    raise RuntimeError(
                        f"Post-analysis function '{func.__name__}' returned an empty dictionary."
                    )
                # Add dict items as columns
                for key, value in result.items():
                    if key in data_frame.columns:
                        msg = f"Post-analysis function '{func.__name__}' returned key '{key}' which already exists in dataframe"
                        raise ValueError(msg)
                    data_frame[key] = value
            elif isinstance(result, pd.DataFrame):
                # Check overlapping columns have the same values
                overlap_cols = set(data_frame.columns) & set(result.columns)
                new_cols = set(result.columns) - set(data_frame.columns)

                for col in overlap_cols:
                    if not data_frame[col].equals(result[col]):
                        msg = f"Post-analysis function '{func.__name__}' returned dataframe with column '{col}' that has different values than the original"
                        raise ValueError(msg)

                if not len(new_cols):
                    raise RuntimeError(
                        f"No new columns to add from post-analysis function '{func.__name__}'."
                    )

                # Add only new columns
                data_frame = pd.concat([data_frame, result[list(new_cols)]], axis=1)
            else:
                msg = f"Post-analysis function '{func.__name__}' must return a dict, dataframe or series, not {type(result)}"
                raise TypeError(msg)

        # data_frame.attrs["solve_result"] = solution

        return data_frame

    def get_update_function(self) -> Callable:
        """Return an update function for use by submodel wrapping.

        This delegates to the optimized _build_dynamics_runner but wraps it
        with the old signature for backward compatibility with
        convert_model_to_function.
        """
        dynamics = self.dynamics

        submodel_state_components = {
            label
            for function in dynamics
            if getattr(function, "_is_submodel_function", False)
            for label in getattr(function, "_model").state_components
        }

        # Pre-compute per-function call metadata
        _numeric = (int, float, np.floating, np.integer, bool)
        function_meta = []
        for func in dynamics:
            is_submodel = getattr(func, "_is_submodel_function", False)
            if is_submodel:
                submodel = getattr(func, "_model")
                submodel_statecomponents = frozenset(submodel.state_components)
                non_submodel_state_components = tuple(
                    k
                    for k in self.state_components
                    if k not in submodel_statecomponents
                )
                function_meta.append(
                    FunctionMeta(
                        func,
                        True,
                        submodel_statecomponents,
                        non_submodel_state_components,
                        None,
                        None,
                    )
                )
            else:
                accepts_kw, accepted = h.get_signature(func)
                function_meta.append(
                    FunctionMeta(
                        func, False, None, None, accepts_kw, frozenset(accepted)
                    )
                )

        submodel_keys_tuple = tuple(submodel_state_components)
        non_submodel_keys = tuple(
            k for k in self.state_components if k not in submodel_state_components
        )

        def update_function(time: float, state: dict, inputs: dict, parameters: dict):
            frozen_parameters = frozendict(self.parameters | parameters)
            combined_inputs = self.inputs | inputs

            # Classify and convert inputs inline
            static_input_values = {}
            dynamic_input_functions = {}
            for key, value in combined_inputs.items():
                if callable(value):
                    dynamic_input_functions[key] = value
                else:
                    static_input_values[key] = value

            inputs_outputs = dict(static_input_values)
            for k, fn in dynamic_input_functions.items():
                inputs_outputs[k] = h.safe_call(
                    fn,
                    time=time,
                    parameters=frozen_parameters,
                    inputs=frozendict(inputs_outputs),
                )

            for function_meta_ in function_meta:
                try:
                    if function_meta_.is_submodel:
                        local_inputs = dict(inputs_outputs)
                        for k in function_meta_.non_submodel_statecomponents:
                            local_inputs[k] = state[k]
                        local_state = {
                            k: state[k] for k in function_meta_.submodel_statecomponents
                        }
                        output = function_meta_.func(
                            time=time,
                            state=local_state,
                            inputs=local_inputs,
                            parameters=frozen_parameters,
                        )
                    else:
                        local_inputs = frozendict(
                            {
                                **inputs_outputs,
                                **{k: state[k] for k in submodel_keys_tuple},
                            }
                        )
                        local_state = frozendict(
                            {k: state[k] for k in non_submodel_keys}
                        )
                        if function_meta_.accepts_kw:
                            output = function_meta_.func(
                                time=time,
                                state=local_state,
                                inputs=local_inputs,
                                parameters=frozen_parameters,
                            )
                        else:
                            _kw = {
                                "time": time,
                                "state": local_state,
                                "inputs": local_inputs,
                                "parameters": frozen_parameters,
                            }
                            output = function_meta_.func(
                                **{k: _kw[k] for k in function_meta_.accepted_args}
                            )

                except TypeError as exc:
                    if exc.args[0].startswith(
                        "'frozendict' object doesn't support item assignment"
                    ):
                        msg = (
                            f"It seems that the function '{function_meta_.func.__name__}' tries to modify "
                            "one of the dictionaries (state, inputs, parameters) passed to it. "
                            "These dictionaries are immutable and should not change during a "
                            "simulation run."
                        )
                        exc.add_note(msg)
                    raise exc

                for key, value in output.items():
                    if not isinstance(value, _numeric):
                        msg = (
                            f"Output '{key}' of function '{function_meta_.func.__name__}' has value '{value}' "
                            f"of type {type(value)}, but only int and float values are allowed."
                        )
                        raise TypeError(msg)
                    if value != value:  # Fast NaN check
                        msg = f"Output '{key}' of function '{function_meta_.func.__name__}' has value NaN, which is not allowed."
                        raise ValueError(msg)

                combined_arguments = state | inputs_outputs | frozen_parameters
                existing_keys = combined_arguments.keys()

                for key in set(output.keys()) & existing_keys:
                    if (ov := output[key]) != (iv := combined_arguments[key]):
                        msg = (
                            f"Key '{key}' with value '{ov}' in output of function "
                            f"'{function_meta_.func.__name__}' already exist(s) with value '{iv}'."
                        )
                        exc = KeyError(msg)
                        exc.add_note(
                            "Outputs can not overwrite an existing output, state component, "
                            "input or parameters value."
                        )
                        raise exc
                inputs_outputs |= output

            return inputs_outputs

        return update_function

    def get_functions(self, inputs, parameters) -> tuple:
        """Create optimized solve_ivp and full_output functions.

        Pre-computes everything constant across solver calls to minimize
        per-call overhead during integration.
        """
        inputs = inputs or {}
        parameters = parameters or {}

        # --- Pre-compute constants (done once, not per solver call) ---

        # Merge parameters once (was: frozendict(self.parameters | parameters) per call)
        frozen_params = frozendict(self.parameters | parameters)

        # Merge and classify inputs once
        combined_inputs = self.inputs | inputs
        dynamic_input_functions = {}  # key -> callable
        static_input_values = {}  # key -> value
        for key, value in combined_inputs.items():
            if callable(value):
                dynamic_input_functions[key] = value
            else:
                static_input_values[key] = value
        has_dynamic_inputs = bool(dynamic_input_functions)

        dynamics = self.dynamics
        state_components = self.state_components
        # Cache derivative labels (was: property creating new list per call)
        derivative_labels = list(self.state_derivative_label_map.values())
        _numeric = (int, float, np.floating, np.integer, bool)

        # Pre-compute submodel metadata
        submodel_state_set = frozenset(
            label
            for func in dynamics
            if getattr(func, "_is_submodel_function", False)
            for label in getattr(func, "_model").state_components
        )
        non_submodel_keys = tuple(
            k for k in state_components if k not in submodel_state_set
        )
        submodel_keys_tuple = tuple(submodel_state_set)

        # Pre-inspect function signatures (was: safe_call doing this per call)
        func_meta = []
        for func in dynamics:
            is_sub = getattr(func, "_is_submodel_function", False)
            if is_sub:
                m = getattr(func, "_model")
                m_sc = frozenset(m.state_components)
                non_m_sc = tuple(k for k in state_components if k not in m_sc)
                func_meta.append((func, True, m_sc, non_m_sc, None, None))
            else:
                accepts_kw, accepted = h.get_signature(func)
                func_meta.append(
                    (func, False, None, None, accepts_kw, frozenset(accepted))
                )

        # Pre-inspect dynamic input function signatures
        dynamic_fn_sigs = {}
        for k, fn in dynamic_input_functions.items():
            dynamic_fn_sigs[k] = h.get_signature(fn)

        running_output = {}

        def _run_dynamics(time, state):
            """Core dynamics loop with pre-computed constants."""
            # Resolve inputs: static are copied, dynamic are evaluated
            if has_dynamic_inputs:
                inputs_outputs = dict(static_input_values)
                for k, fn in dynamic_input_functions.items():
                    accepts_kw, accepted = dynamic_fn_sigs[k]
                    if accepts_kw:
                        inputs_outputs[k] = fn(
                            time=time,
                            parameters=frozen_params,
                            inputs=frozendict(inputs_outputs),
                        )
                    else:
                        _kw = {
                            "time": time,
                            "parameters": frozen_params,
                            "inputs": frozendict(inputs_outputs),
                        }
                        inputs_outputs[k] = fn(**{a: _kw[a] for a in accepted})
            else:
                inputs_outputs = dict(static_input_values)

            for func, is_sub, m_sc, non_m_sc, accepts_kw, accepted in func_meta:
                try:
                    if is_sub:
                        local_inputs = dict(inputs_outputs)
                        for k in non_m_sc:
                            local_inputs[k] = state[k]
                        local_state = {k: state[k] for k in m_sc}
                        output = func(
                            time=time,
                            state=local_state,
                            inputs=local_inputs,
                            parameters=frozen_params,
                        )
                    else:
                        local_inputs = frozendict(
                            {
                                **inputs_outputs,
                                **{k: state[k] for k in submodel_keys_tuple},
                            }
                        )
                        local_state = frozendict(
                            {k: state[k] for k in non_submodel_keys}
                        )
                        if accepts_kw:
                            output = func(
                                time=time,
                                state=local_state,
                                inputs=local_inputs,
                                parameters=frozen_params,
                            )
                        else:
                            _kw = {
                                "time": time,
                                "state": local_state,
                                "inputs": local_inputs,
                                "parameters": frozen_params,
                            }
                            output = func(**{k: _kw[k] for k in accepted})

                except TypeError as exc:
                    if exc.args[0].startswith(
                        "'frozendict' object doesn't support item assignment"
                    ):
                        msg = (
                            f"It seems that the function '{func.__name__}' tries to modify "
                            "one of the dictionaries (state, inputs, parameters) passed to it. "
                            "These dictionaries are immutable and should not change during a "
                            "simulation run."
                        )
                        exc.add_note(msg)
                    raise exc

                for key, value in output.items():
                    if not isinstance(value, _numeric):
                        msg = (
                            f"Output '{key}' of function '{func.__name__}' has value '{value}' "
                            f"of type {type(value)}, but only int and float values are allowed."
                        )
                        raise TypeError(msg)
                    if value != value:  # Fast NaN check (x != x iff NaN)
                        msg = f"Output '{key}' of function '{func.__name__}' has value NaN, which is not allowed."
                        raise ValueError(msg)

                combined_arguments = state | inputs_outputs | frozen_params
                existing_keys = combined_arguments.keys()

                for key in set(output.keys()) & existing_keys:
                    if (ov := output[key]) != (iv := combined_arguments[key]):
                        msg = (
                            f"Key '{key}' with value '{ov}' in output of function "
                            f"'{func.__name__}' already exist(s) with value '{iv}'."
                        )
                        exc = KeyError(msg)
                        exc.add_note(
                            "Outputs can not overwrite an existing output, state component, "
                            "input or parameters value."
                        )
                        raise exc
                inputs_outputs |= output

            return inputs_outputs

        def solve_ivp_func(time, state_array):
            state = dict(zip(state_components, state_array))
            result = _run_dynamics(time, state)
            combined = state | result
            running_output.update(inputs)
            running_output.update(combined)
            return np.array([combined[label] for label in derivative_labels])

        def full_output_func(time, state_array):
            state = dict(zip(state_components, state_array))
            result = _run_dynamics(time, state)
            return {**inputs, **state, **result}

        return solve_ivp_func, full_output_func, running_output

    def run_to_equilibrium(
        self,
        *,
        start_time: float = 0,
        period: float,
        time_step: float | None = None,
        initial_state: dict | None = None,
        inputs: dict | None = None,
        parameters: dict | None = None,
        relative_tolerance_simulation: float | None = None,
        absolute_tolerance_simulation: float | None = None,
        relative_tolerance_equilibrium: float | None = None,
        absolute_tolerance_equilibrium: float | None = None,
        max_n_runs: int = 100,
    ) -> pd.DataFrame:
        validate(self)

        default_estimated_equilibrium_state = {
            k: 0 for k in self.state_components
        } | self.initial_state
        if initial_state is None:
            initial_state = default_estimated_equilibrium_state
        else:
            initial_state = default_estimated_equilibrium_state | initial_state

        all_results = []

        atol_simulation = (
            absolute_tolerance_simulation or settings.simulation.absolute_tolerance
        )
        rtol_simulation = (
            relative_tolerance_simulation or settings.simulation.relative_tolerance
        )
        rtol_equilibrium = (
            relative_tolerance_equilibrium or settings.simulation.eq_relative_tolerance
        )
        atol_equilibrium = (
            absolute_tolerance_equilibrium or settings.simulation.eq_absolute_tolerance
        )
        end_time = start_time + period
        for i in range(max_n_runs):
            result = self.run_simulation(
                time=(start_time, end_time, time_step),
                initial_state=initial_state,
                inputs=inputs,
                parameters=parameters,
                absolute_torelance=atol_simulation,
                relative_tolerance=rtol_simulation,
            )
            all_results.append(result)
            final_state = dict(result.iloc[-1][initial_state.keys()])

            if np.allclose(
                list(initial_state.values()),
                list(final_state.values()),
                rtol=rtol_equilibrium,
                atol=atol_equilibrium,
            ):
                break

            initial_state = final_state
            start_time = end_time
            end_time += period

        else:
            msg = f"Model did not reach equilibrium within the maximum number ({max_n_runs}) of iterations."
            raise RuntimeError(msg)

        for result in all_results:
            result.attrs = {}

        combined_results = pd.concat(all_results, axis="index")
        combined_results: pd.DataFrame = combined_results.loc[
            ~combined_results.index.duplicated(keep="last")
        ]
        return combined_results

    def find_equilibrium_state(
        self, *, estimated_equilibrium_state: dict | None = None, **kwargs
    ) -> dict:
        """
        Find the equilibrium state of the model.

        The equilibrium state is either a state of absolute equilibrium if the
        inputs are constant, the state at the start of a period resulting in a
        periodic output if the inputs are periodic.

        This function runs the model from 0 to `time` a maximum of `max_n_runs`
        times. The initial state is equal to the estimated equilibrium state
        during the first run, and the last state of the last iteration each
        subsequent run. Assuming the model converges to a stable state, each
        subsequent run should start and end closer to the equilibrium state
        than the previous run.
        When the end state does not change by more than `rtol`, it is assumed
        this is the equilibrium state.

        Args:
            time (float): the time at which the equilibrium is evaluated.
            time_step (float | None, optional): time step used in running the simulation. Defaults to None.
            estimated_equilibrium_state (dict | None, optional): starting point
                for finding the equilibrium state. Defaults to None.
            inputs (dict | None, optional): inputs of the model. Defaults to None.
            parameters (dict | None, optional): parameters of the model. Defaults to None.
            max_n_runs (int, optional): maximum number of iterations before the
                function fails. Defaults to 100.
            rtol (float, optional): relative tolerance of model run. Defaults to 1e-4.
            atol (float, optional): absolute tolerance of the model run. Defaults to 1e-6.
            rtol_eq (float, optional): relative tolerance comparing the current
                to the previous iteration. Defaults to 1e-3.

        Raises:
            RuntimeError: is raised then no equilibrium can be found after
                max_n_runs iterations.

        Returns:
            dict: the resulting equilibrium state.
        """
        result = self.run_to_equilibrium(
            initial_state=estimated_equilibrium_state, **kwargs
        )
        return {
            k: float(v)
            for k, v in result.loc[:, self.state_components].iloc[-1].items()
        }

    def run_simulations(
        self,
        *,
        initial_state: dict | list[dict] | None = None,
        inputs: dict | list[dict] | None = None,
        parameters: dict | list[dict] | None = None,
        time: float
        | tuple
        | np.ndarray
        | list[float | tuple | np.ndarray]
        | None = None,
        relative_tolerance: float | list[float] | None = None,
        absolute_tolerance: float | list[float] | None = None,
        solver_outputs: list | None = None,
    ) -> list[tuple[pd.DataFrame, dict]]:
        rtol = relative_tolerance or settings.simulation.relative_tolerance
        atol = absolute_tolerance or settings.simulation.absolute_tolerance
        # TODO: write tests for run_simulations
        initial_state_, initial_state_variable_keys_ = (
            h.unpack_dict_with_variable_values(initial_state)
        )
        inputs_, inputs_variable_keys_ = h.unpack_dict_with_variable_values(inputs)
        parameters_, parameters_variable_keys_ = h.unpack_dict_with_variable_values(
            parameters
        )

        def ensure_list(item):
            if isinstance(item, list):
                return item
            return [item]

        time_, rtol_, atol_ = map(ensure_list, [time, rtol, atol])

        results: list[tuple[pd.DataFrame, dict]] = []
        for (
            _initial_state,
            _inputs,
            _parameters,
            _time,
            _rtol,
            _atol,
        ) in itertools.product(
            initial_state_, inputs_, parameters_, time_, rtol_, atol_
        ):
            if solver_outputs is not None:
                solver_output = {}
                solver_outputs.append(solver_output)
            else:
                solver_output = None
            result = self.run_simulation(
                initial_state=_initial_state,
                inputs=_inputs,
                parameters=_parameters,
                time=_time,
                relative_tolerance=_rtol,
                absolute_torelance=_atol,
                solver_output=solver_output,
            )

            result_dict = {}

            if len(initial_state_) > 1:
                assert isinstance(_initial_state, dict)
                result_dict["initial_state"] = {
                    k: _initial_state[k] for k in initial_state_variable_keys_
                }

            if len(inputs_) > 1:
                assert isinstance(_inputs, dict)
                result_dict["inputs"] = {k: _inputs[k] for k in inputs_variable_keys_}

            if len(parameters_) > 1:
                assert isinstance(_parameters, dict)
                result_dict["parameters"] = {
                    k: _parameters[k] for k in parameters_variable_keys_
                }

            if len(time_) > 1:
                result_dict["time"] = _time

            if len(rtol_) > 1:
                result_dict["relative_tolerance"] = _rtol

            if len(atol_) > 1:
                result_dict["absolute_tolerance"] = _atol

            result.attrs.update(result_dict)
            results.append(result)

        return SimulationResults(results)

    def replace(self, **changes) -> Self:
        """Create a copy of the model with the given changes.

        This function creates a copy of the model with the given changes.
        Similar to `attrs.evolve`, but with proper typing.

        Args:
            **changes: changes to the model

        Returns:
            Self: a copy of the model with the given changes
        """
        if "state_components" in changes:
            new_state_components = changes["state_components"]
            kept_state_components = set(self.state_components) & set(
                new_state_components
            )

            changes["state_derivative_label_map"] = {
                k: v
                for k, v in self.state_derivative_label_map.items()
                if k in kept_state_components
            } | changes.get("state_derivative_label_map", {})
            changes["initial_state"] = {
                k: v
                for k, v in self.initial_state.items()
                if k in kept_state_components
            } | changes.get("initial_state", {})

            changes["parameters"] = self.parameters | changes.get("parameters", {})

        return attrs.evolve(self, **changes)

    __call__ = run_simulation
