from __future__ import annotations
from os import PathLike

from dataclasses import dataclass, replace
from typing import Self

from dataclass_wizard import TOMLWizard
from dataclass_wizard.bases_meta import DumpMeta, LoadMeta
from dataclass_wizard.enums import LetterCase
from dataclass_wizard.errors import UnknownKeysError


@dataclass
class SettingsBase(TOMLWizard):
    def __init_subclass__(cls):
        LoadMeta(raise_on_unknown_json_key=True).bind_to(cls)
        DumpMeta(key_transform=LetterCase.NONE).bind_to(cls)

    def __iter__(self):
        for field_name in self.__dataclass_fields__:
            yield field_name, getattr(self, field_name)

    @classmethod
    def from_toml_file(cls, file: PathLike | bytes | str, **kwargs) -> Self | list:
        try:
            return super().from_toml_file(file, **kwargs)
        except KeyError as e:
            raise KeyError(f"Unknown key in file {file}.") from e

    @classmethod
    def from_toml(cls, *args, **kwargs) -> list[Self] | Self:
        try:
            return super().from_toml(*args, **kwargs)
        except UnknownKeysError as e:
            raise KeyError(f"Unknown key: '{e.unknown_keys}'.") from e

    def update(self, other: Self | None = None, **kwargs) -> Self:
        other_dict = dict(other) if other is not None else {}
        return replace(self, **other_dict, **kwargs)
