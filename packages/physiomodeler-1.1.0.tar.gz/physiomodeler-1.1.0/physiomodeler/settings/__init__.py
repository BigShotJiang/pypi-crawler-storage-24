from __future__ import annotations
from os import PathLike

import os
from pathlib import Path
from typing import Any, Callable

from physiomodeler.settings.settings import Settings

DEFAULT_SETTINGS_FILE_PATH = Path.cwd() / "physiomodeler.toml"
SETTINGS_PATH_ENV_VAR_NAME = "PHYSIOMODELER_CONFIG"

_settings: Settings | None = None


def generate_settings_file(path: PathLike | None = None, overwrite=False) -> None:
    """Generate a default settings file at the specified path.

    Args:
        path: Path to write the settings file to. Defaults to 'physiomodeler.toml' in the current working directory.
        overwrite: Whether to overwrite an existing file. Defaults to False.

    Raises:
        FileExistsError: If the file already exists and overwrite is False.
    """
    # TODO: write test for generate_settings_file
    path = Path(path) if path is not None else DEFAULT_SETTINGS_FILE_PATH
    if path.exists() and not overwrite:
        raise FileExistsError(
            f"File '{path}' already exists. Use overwrite=True to overwrite."
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    default_settings = get_default_settings()
    default_settings.to_toml_file(path)


def get_default_settings() -> Settings:
    return Settings()


def find_settings_files() -> Path | None:
    if env_variable := os.getenv(SETTINGS_PATH_ENV_VAR_NAME):
        return Path(env_variable)

    if DEFAULT_SETTINGS_FILE_PATH.exists():
        return DEFAULT_SETTINGS_FILE_PATH

    return None


def load_settings() -> Settings:
    global _settings

    if _settings is None:
        _settings = get_default_settings()
        if (path := find_settings_files()) is not None:
            _settings = _settings.update(Settings.from_toml_file(path))

    return _settings


def get_settings_value(key: str) -> Any:
    """Get a settings value by dot notation path.

    Args:
        key: Dot-separated path to setting (e.g., "simulation.relative_tolerance")

    Returns:
        The setting value
    """
    settings = load_settings()
    current_value = settings
    for part in key.split("."):
        current_value = getattr(current_value, part)
    return current_value


def setting_default_factory(key: str) -> Callable:
    """Create a default_factory for dataclass fields that loads from settings.

    Args:
        key: Dot-separated path to setting (e.g., "simulation.relative_tolerance")

    Returns:
        A callable suitable for use as dataclass field default_factory

    Example:
        @dataclass
        class MyModel:
            tolerance: float = field(default_factory=setting_default_factory("simulation.relative_tolerance"))
    """

    def getter() -> Any:
        return get_settings_value(key)

    return getter
