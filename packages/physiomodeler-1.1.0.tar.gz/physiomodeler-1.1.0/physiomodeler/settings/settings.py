from dataclasses import dataclass, field

from physiomodeler.settings.settings_base import SettingsBase


@dataclass
class Templates(SettingsBase):
    state_derivative_label: str = "d{state_label}"


@dataclass
class Simulation(SettingsBase):
    relative_tolerance: float = 1e-5
    absolute_tolerance: float = 1e-7
    eq_relative_tolerance: float = 1e-5
    eq_absolute_tolerance: float = 1e-7


@dataclass
class Settings(SettingsBase):
    simulation: Simulation = field(default_factory=Simulation)
    templates: Templates = field(default_factory=Templates)
