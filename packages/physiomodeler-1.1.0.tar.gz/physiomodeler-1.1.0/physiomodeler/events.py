from typing import Callable
from typing import Literal


def terminal(fn: Callable) -> Callable:
    """
    Decorator to mark an event function as terminal.

    Example:
        This example will have an event and terminate when the volume (state)
        crosses the value 0.

        ```
        @terminal
        def volume_crosses_zero(time, state, inputs, parameters):
            return state["volume"]

        model = PhysioModeler(
            ...,
            events=[
                volume_crosses_zero,
            ]
        )
        ```
    """
    setattr(fn, "terminal", True)
    return fn


def becomes_positive(fn: Callable) -> Callable:
    """
    Decorator to mark an event function as detecting positive crossings.

    Example:
        This example will have an event that detects when the volume (state)
        becomes positive.

        ```
        @becomes_positive
        def volume_becomes_positive(time, state, inputs, parameters):
            return state["volume"]

        model = PhysioModeler(
            ...,
            events=[
                volume_becomes_positive,
            ]
        )
        ```
    """
    setattr(fn, "direction", 1)
    return fn


def becomes_negative(fn: Callable) -> Callable:
    """
    Decorator to mark an event function as detecting negative crossings.

    Example:
        This example will have an event that detects when the volume (state)
        becomes negative.

        ```
        @becomes_negative
        def volume_becomes_negative(time, state, inputs, parameters):
            return state["volume"]

        model = PhysioModeler(
            ...,
            events=[
                volume_becomes_negative,
            ]
        )
        ```
    """
    setattr(fn, "direction", -1)
    return fn


def state_crosses_value(
    label: str,
    value: float,
    *,
    terminal: bool = False,
    direction: Literal[-1, 0, 1] = 0,
):
    """
    Create an event that detects when a state crossing the given value.

    Example:
        This example will have an event and terminate when the volume (state)
        crosses the value 0.

        ```
        model = PhysioModeler(
            ...,
            events=[
                state_crosses_value("volume", 0, terminal=True),
            ]
        )
        ```

    Args:
        label (str): label of the state to track
        value (float): the event will trigger when the state crosses this value
        terminal (bool): whether to terminate the simulation if the event occurs
        direction (int): if 0, any crossing will be detected; if 1, only positive
            crossings (value goes from negative to positive) will be detected; if
            -1, only negative crossings will be detected.
    """

    def event(time, state, inputs, parameters):
        return state[label] - value

    setattr(event, "terminal", terminal)
    setattr(event, "direction", direction)
    return event
