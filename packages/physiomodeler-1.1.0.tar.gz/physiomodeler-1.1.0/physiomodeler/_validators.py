import inspect
from collections.abc import Callable, Iterable, Sequence
from typing import Any, Literal, overload

import numpy as np
from attrs import validators

UPDATE_FUNCTION_ALLOWED_ARGUMENTS = EVENT_FUNCTION_ALLOWED_ARGUMENTS = [
    "time",
    "state",
    "inputs",
    "parameters",
]
INPUT_FUNCTION_ALLOWED_ARGUMENTS = ["time", "parameters", "inputs"]
POST_HOC_FUNCTION_REQUIRED_ARGUMENTS = ["result"]


def _key_not_equal_value(instance, attribute, value: dict[str, str]):
    for k, v in value.items():
        if k == v:
            raise ValueError(
                f"In '{attribute.name}', key and value must not be the same: '{k}': '{v}'"
            )


def _is_update_function_or_model(instance, attribute, value):
    try:
        _is_update_function(instance, attribute, value)
        return
    except TypeError as e_fn:
        try:
            _is_model(instance, attribute, value)
            return
        except TypeError as e_model:
            from physiomodeler import Model

            if isinstance(value, Model):
                raise e_model
            raise e_fn


def _is_update_function(instance, attribute, value):
    validators.is_callable()(instance, attribute, value)
    _signature_matches(value, [], UPDATE_FUNCTION_ALLOWED_ARGUMENTS, "update", False)


def _is_event_function(instance, attribute, value):
    return _signature_matches(
        value, [], EVENT_FUNCTION_ALLOWED_ARGUMENTS, "event", False
    )


def _signature_matches(
    func,
    required_arguments,
    optional_arguments,
    name: str,
    allow_other_arguments: bool = False,
):
    signature = inspect.signature(func)
    arguments = list(signature.parameters.keys())

    if not all(argument in set(arguments) for argument in required_arguments):
        msg = (
            f"{name.capitalize()} function must accept "
            + ("at least " if len(optional_arguments) > 0 else "")
            + (
                f"{_printable_list_str(required_arguments)} "
                "as arguments, not "
                f"{_printable_list_str(arguments)}."
            )
        )
        raise TypeError(msg)

    other_arguments = set(arguments) - set(required_arguments)

    if (not allow_other_arguments) and (
        superfluous_arguments := (other_arguments - set(optional_arguments))
    ):
        msg = (
            f"{name.capitalize()} function has unknown optional arguments: "
            f"{_printable_list_str(list(superfluous_arguments))}."
        )
        raise TypeError(msg)

    return True


def _is_function_with_arguments(arguments, name, allow_other_arguments: bool = False):
    return lambda instance, attribute, value: _signature_matches(
        value, arguments, [], name, allow_other_arguments
    )


def _is_input_function(instance, attribute, value):
    _signature_matches(value, [], INPUT_FUNCTION_ALLOWED_ARGUMENTS, "input", False)


def _convert_nonstr_nondict_iterable_to_set(value):
    if isinstance(value, Iterable) and not isinstance(value, (str, dict)):
        return set(value)
    return value


def _state_exists(instance, attribute, value):
    if value not in instance.state_components:
        msg = f"State '{value}' (in '{attribute.name}') does not exist."
        raise ValueError(msg)


def _printable_list_str(list_):
    if len(list_) == 0:
        return "''"
    if len(list_) == 1:
        return f"'{list_[0]}'"

    return ", ".join(f"'{p}'" for p in list_[:-1]) + f" and '{list_[-1]}'"


def _is_model(instance, attribute, value):
    from physiomodeler import Model

    if not isinstance(value, Model):
        msg = f"Expected a 'Model' instance, not '{type(value)}'."
        raise TypeError(msg)


validate_functions_field: tuple = (
    validators.instance_of(list),
    validators.min_len(1),
    validators.deep_iterable(
        member_validator=_is_update_function_or_model,
        iterable_validator=validators.instance_of(list),
    ),
)

validate_state_components_field: tuple = (
    validators.deep_iterable(
        member_validator=validators.instance_of(str),
        iterable_validator=validators.instance_of(list),
    ),
    validators.min_len(0),
)
validate_state_derivative_label_map_field: tuple = (
    validators.instance_of(dict),
    validators.deep_mapping(
        key_validator=validators.and_(validators.instance_of(str), _state_exists),
        value_validator=validators.instance_of(str),
    ),
    _key_not_equal_value,
)


def validate_inputs_field(instance, attribute, value):
    validate_inputs_field_tuple[0](instance, attribute, value)
    try:
        validate_inputs_field_tuple[1](instance, attribute, value)
    except Exception as e:
        msg = "Invalid inputs."
        exc = TypeError(msg)
        exc.add_note(
            "Inputs should be a dict mapping str keys to with either numerical values, "
            "or functions that optionally accept time, inputs and parameters arguments."
        )
        raise exc from e


validate_inputs_field_tuple = (
    validators.instance_of(dict),
    validators.deep_mapping(
        key_validator=validators.instance_of(str),
        value_validator=validators.or_(
            validators.instance_of((float, int)),
            validators.and_(validators.is_callable(), _is_input_function),
        ),
    ),
)


def validate_parameters_field(instance, attribute, value):
    validate_parameters_field_tuple[0](instance, attribute, value)
    try:
        validate_parameters_field_tuple[1](instance, attribute, value)
    except Exception as e:
        msg = f"Invalid parameters in '{attribute.name}'."
        exc = TypeError(msg)
        exc.add_note(
            "Parameters should be a dict mapping str keys to with either "
            "numerical, string, boolean, list or tuple values."
        )
        raise exc from e


validate_parameters_field_tuple: tuple = (
    validators.instance_of(dict),
    validators.deep_mapping(
        key_validator=validators.instance_of(str),
        value_validator=validators.instance_of((int, float, str, bool, list, tuple)),
    ),
)
validate_events_field = validators.deep_iterable(
    iterable_validator=validators.instance_of(list),
    member_validator=validators.and_(validators.is_callable(), _is_event_function),
)
validate_post_analysis_field = validators.deep_iterable(
    iterable_validator=validators.instance_of(list),
    member_validator=validators.and_(
        validators.is_callable(),
        _is_function_with_arguments(
            POST_HOC_FUNCTION_REQUIRED_ARGUMENTS, "post-analysis", True
        ),
    ),
)


def _value_in_sequence(sequence):
    def internal(instance, attribute, value):
        if value not in sequence:
            str_sequence = [f"'{s:s}'" for s in sequence]
            raise ValueError(
                f"Invalid value {value}. Should be one of {', '.join(str_sequence)}."
            )

    return internal


validate_time_units_field = validators.optional(validators.instance_of(str))
validate_initial_state_field = (
    validators.instance_of(dict),
    validators.deep_mapping(
        key_validator=validators.and_(validators.instance_of(str), _state_exists),
        value_validator=validators.instance_of((float, int)),
    ),
)


def validate_inputs(inputs) -> dict[str, float | Callable]:
    if inputs is None:
        inputs = {}

    if not isinstance(inputs, dict):
        # TODO: make test case with inputs as non-dict
        raise TypeError(f"Inputs should be dict, not {type(inputs)}")

    inputs = _sanitize_argument(inputs, allow_callable=True, allow_none=False)
    return inputs


def validate_parameters(parameters: dict | None) -> dict[str, float | str]:
    parameters_ = parameters if parameters is not None else {}

    parameters_ = _sanitize_argument(parameters_, allow_string=True, allow_none=False)
    return parameters_


def validate_initial_state(state, model_state, state_components) -> dict:
    default_state = {k: 0 for k in state_components}

    if state is None:
        state = {}

    elif not isinstance(state, dict):
        # TODO: make test case with initial state as non-dict
        msg = f"The initial state should be a dict, not '{type(state)}'"
        raise TypeError(msg)

    if sk := set(state.keys()) - set(state_components):
        msg = f"Initial state contains keys not in state components: {sk}."
        raise KeyError(msg)

    state = default_state | model_state | state

    return _sanitize_argument(state, allow_none=False)


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[False] = ...,
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[False] = ...,
) -> dict[str, float]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[True],
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | Callable]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[False] = ...,
    allow_string: Literal[True],
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | str]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[False] = ...,
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[True],
) -> dict[str, float | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[True],
    allow_string: Literal[True],
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | Callable | str]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[True],
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[True],
) -> dict[str, float | Callable | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[False] = ...,
    allow_string: Literal[True],
    allow_sequence: Literal[True],
) -> dict[str, float | str | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[False],
    allow_callable: Literal[True],
    allow_string: Literal[True],
    allow_sequence: Literal[True],
) -> dict[str, float | Callable | str | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[False] = ...,
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | None]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[True],
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | None | Callable]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[False] = ...,
    allow_string: Literal[True],
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | None | str]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[False] = ...,
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[True],
) -> dict[str, float | None | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[True],
    allow_string: Literal[True],
    allow_sequence: Literal[False] = ...,
) -> dict[str, float | None | Callable | str]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[True],
    allow_string: Literal[False] = ...,
    allow_sequence: Literal[True],
) -> dict[str, float | None | Callable | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[False] = ...,
    allow_string: Literal[True],
    allow_sequence: Literal[True],
) -> dict[str, float | None | str | Sequence]: ...


@overload
def _sanitize_argument(
    arg: dict,
    *,
    allow_none: Literal[True] = ...,
    allow_callable: Literal[True],
    allow_string: Literal[True],
    allow_sequence: Literal[True],
) -> dict[str, float | None | Callable | str | Sequence]: ...


def _sanitize_argument(
    arg: dict,
    *,
    allow_none: bool = True,
    allow_callable: bool = False,
    allow_string: bool = False,
    allow_sequence: bool = False,
) -> dict[str, Any]:
    if not isinstance(arg, dict):
        msg = f"Argument should be a dictionary, not '{type(arg)}'"
        raise TypeError(msg)

    def check_value(key, value):
        if not isinstance(key, str):
            msg = f"Keys should be a non-string sequence, not '{key}' ({type(key)})"
            raise TypeError(msg)

        if (
            (allow_none and value is None)
            or isinstance(value, (int, float))
            or (allow_callable and callable(value))
            or (allow_string and isinstance(value, str))
            or (allow_sequence and isinstance(value, (list, tuple)))
        ):
            return value

        if isinstance(value, list):
            value = np.array(value)

        if isinstance(value, np.ndarray):
            if np.sum(np.array(value.shape)) != 1:
                raise ValueError("Input array should be 1D or reducable to 1D")

            value = value.flatten()

            return value

        msg = f"Input with key '{key}' must be a {'function, ' if allow_callable else ''}number, list or 1D-array, not '{value}' ({type(value)})."
        raise TypeError(msg)

    return {key: check_value(key, value) for key, value in arg.items()}
