"""Tests for type definitions."""

import pytest
from soothe_sdk.types import PluginManifest, PluginHealth


def test_plugin_manifest():
    """Test PluginManifest creation and validation."""
    manifest = PluginManifest(
        name="test-plugin",
        version="1.0.0",
        description="Test plugin",
        dependencies=["langchain>=0.1.0"],
    )

    assert manifest.name == "test-plugin"
    assert manifest.version == "1.0.0"
    assert manifest.description == "Test plugin"
    assert manifest.dependencies == ["langchain>=0.1.0"]


def test_plugin_health():
    """Test PluginHealth creation."""
    health = PluginHealth(status="healthy")

    assert health.status == "healthy"
    assert health.details is None

    health_with_details = PluginHealth(
        status="degraded", details={"error": "API unavailable"}
    )

    assert health_with_details.status == "degraded"
    assert health_with_details.details == {"error": "API unavailable"}


def test_plugin_manifest_invalid_version():
    """Test PluginManifest rejects invalid semantic version."""
    with pytest.raises(ValueError):
        PluginManifest(
            name="test-plugin",
            version="invalid-version",
            description="Test plugin",
        )