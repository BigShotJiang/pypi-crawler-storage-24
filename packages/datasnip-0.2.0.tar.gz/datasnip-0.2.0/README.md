# datasnip

Snip little bits of fun data from the internet in one line.

## Install
pip install datasnip

## Usage
import datasnip

datasnip.joke()         # random joke
datasnip.fact()         # random fun fact
datasnip.weather("Copenhagen")  # current weather
datasnip.dog()          # random dog image URL