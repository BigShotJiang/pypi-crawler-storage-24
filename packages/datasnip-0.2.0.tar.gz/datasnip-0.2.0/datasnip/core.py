import urllib.request
import json

def joke():
    """Print a random joke."""
    url = "https://official-joke-api.appspot.com/random_joke"
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    print(f"😄 {data['setup']}")
    print(f"   → {data['punchline']}")

def fact():
    """Print a random fun fact."""
    url = "https://uselessfacts.jsph.pl/api/v2/facts/random?language=en"
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    print(f"💡 {data['text']}")

def weather(city):
    """Print current weather for a city."""
    url = f"https://wttr.in/{city}?format=3"
    with urllib.request.urlopen(url) as r:
        print(f"🌤  {r.read().decode()}")

def dog():
    """Print a random dog image URL."""
    url = "https://dog.ceo/api/breeds/image/random"
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    print(f"🐶 {data['message']}")

def country(name):
    """Print info about a country (capital, population, flag)."""
    encoded = urllib.request.quote(name)
    url = f"https://restcountries.com/v3.1/name/{encoded}?fullText=true"
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())[0]
    capital = data.get("capital", ["N/A"])[0]
    population = f"{data['population']:,}"
    flag = data.get("flag", "")
    common_name = data["name"]["common"]
    region = data.get("region", "N/A")
    print(f"{flag}  {common_name}")
    print(f"   Capital:    {capital}")
    print(f"   Population: {population}")
    print(f"   Region:     {region}")

def crypto(symbol):
    """Print the current price of a cryptocurrency (e.g. 'bitcoin', 'ethereum')."""
    encoded = urllib.request.quote(symbol.lower())
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={encoded}&vs_currencies=usd"
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    if symbol.lower() not in data:
        print(f"❌ Couldn't find crypto: {symbol}")
        return
    price = data[symbol.lower()]["usd"]
    print(f"🪙 {symbol.capitalize()}: ${price:,.2f} USD")

def trivia():
    """Print a random movie/TV trivia question and answer."""
    url = "https://opentdb.com/api.php?amount=1&category=11&type=multiple"
    with urllib.request.urlopen(url) as r:
        data = json.loads(r.read())
    result = data["results"][0]
    question = _decode(result["question"])
    answer = _decode(result["correct_answer"])
    difficulty = result["difficulty"].capitalize()
    print(f"🎬 [{difficulty}] {question}")
    print(f"   ✅ Answer: {answer}")

def _decode(text):
    """Decode HTML entities in text."""
    replacements = {
        "&amp;": "&", "&quot;": '"', "&#039;": "'",
        "&lt;": "<", "&gt;": ">", "&eacute;": "é",
        "&ndash;": "–", "&mdash;": "—"
    }
    for entity, char in replacements.items():
        text = text.replace(entity, char)
    return text