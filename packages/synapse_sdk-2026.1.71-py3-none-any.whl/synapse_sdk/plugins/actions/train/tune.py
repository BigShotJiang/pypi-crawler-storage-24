"""Tune helper utilities extracted from BaseTrainAction.

Contains stateless functions and classes for Ray Tune integration:
- Parameter conversion (backend format → Ray Tune search space)
- Search algorithm / scheduler creation
- Model upload helpers for tune trials
- Logger wrappers for tune mode
- TuneTrialCallback for trial progress tracking
"""

from __future__ import annotations

import logging
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.action import BaseTrainAction

logger = logging.getLogger(__name__)


# Lazy base class for tune callback — avoids hard dependency on ray
try:
    from ray.tune import Callback as _TuneCallbackBase
except ImportError:
    _TuneCallbackBase = object  # type: ignore[misc,assignment]


class TuneTrialLoggerWrapper:
    """Logger wrapper that ignores progress updates in tune trials.

    In tune mode, individual trials should not report their training progress
    to the backend. Only the main process reports trial completion progress.
    This wrapper forwards all logger methods except set_progress.
    """

    def __init__(self, inner: Any) -> None:
        self._logger = inner

    def set_progress(self, current: int, total: int, step: str | None = None) -> None:
        """Ignore progress updates from tune trials."""
        pass

    def __getattr__(self, name: str) -> Any:
        return getattr(self._logger, name)


def convert_tune_params(param_list: list[dict[str, Any]]) -> dict[str, Any]:
    """Convert backend hyperparameter definitions to Ray Tune search space.

    Backend sends search space definitions like:
        [{"name": "epochs", "type": "randint", "min": 5, "max": 10},
         {"name": "batch_size", "type": "choice", "options": [2, 4, 8]}]

    This converts them to Ray Tune functions:
        {"epochs": tune.randint(5, 10), "batch_size": tune.choice([2, 4, 8])}
    """
    from ray import tune

    param_handlers = {
        'uniform': lambda p: tune.uniform(p['min'], p['max']),
        'quniform': lambda p: tune.quniform(p['min'], p['max']),
        'loguniform': lambda p: tune.loguniform(p['min'], p['max'], p['base']),
        'qloguniform': lambda p: tune.qloguniform(p['min'], p['max'], p['base']),
        'randn': lambda p: tune.randn(p['mean'], p['sd']),
        'qrandn': lambda p: tune.qrandn(p['mean'], p['sd']),
        'randint': lambda p: tune.randint(p['min'], p['max']),
        'qrandint': lambda p: tune.qrandint(p['min'], p['max']),
        'lograndint': lambda p: tune.lograndint(p['min'], p['max'], p['base']),
        'qlograndint': lambda p: tune.qlograndint(p['min'], p['max'], p['base']),
        'choice': lambda p: tune.choice(p['options']),
        'grid_search': lambda p: tune.grid_search(p['options']),
    }

    param_space: dict[str, Any] = {}

    for param in param_list:
        name = param['name']
        param_type = param['type']

        if param_type in param_handlers:
            param_space[name] = param_handlers[param_type](param)
        else:
            raise ValueError(
                f"Unknown tune parameter type: '{param_type}' for '{name}'. "
                f'Supported types: {", ".join(param_handlers.keys())}'
            )

    return param_space


def convert_tune_search_alg(tune_config: dict[str, Any]) -> Any:
    """Convert tune_config to a Ray Tune search algorithm instance.

    Supports both string and dict formats for search_alg:
        - String: "basicvariantgenerator"
        - Dict: {"name": "basicvariantgenerator", "options": {...}}
    """
    search_alg_raw = tune_config.get('search_alg')
    if search_alg_raw is None:
        return None

    if isinstance(search_alg_raw, str):
        search_alg_name = search_alg_raw.lower()
    elif isinstance(search_alg_raw, dict):
        search_alg_name = search_alg_raw.get('name', '').lower()
    else:
        return None

    metric = tune_config.get('metric')
    mode = tune_config.get('mode')

    if search_alg_name == 'bayesoptsearch':
        from ray.tune.search.bayesopt import BayesOptSearch

        return BayesOptSearch(metric=metric, mode=mode)
    elif search_alg_name == 'hyperoptsearch':
        from ray.tune.search.hyperopt import HyperOptSearch

        return HyperOptSearch(metric=metric, mode=mode)
    elif search_alg_name == 'optunasearch':
        from ray.tune.search.optuna import OptunaSearch

        return OptunaSearch(metric=metric, mode=mode)
    elif search_alg_name == 'basicvariantgenerator':
        from ray.tune.search.basic_variant import BasicVariantGenerator

        max_concurrent = tune_config.get('max_concurrent_trials')
        return BasicVariantGenerator(max_concurrent=max_concurrent)
    elif search_alg_name == 'axsearch':
        from ray.tune.search.ax import AxSearch

        return AxSearch(metric=metric, mode=mode)
    else:
        raise ValueError(
            f"Unsupported search algorithm: '{search_alg_name}'. "
            f'Supported: basicvariantgenerator, hyperoptsearch, optunasearch, '
            f'bayesoptsearch, axsearch'
        )


def infer_max_t(hyperparameters: list[dict[str, Any]]) -> int | None:
    """Infer max_t from hyperparameters search space.

    Looks for the 'epochs' parameter and returns its max value.
    Used by HyperBand/ASHA schedulers to properly calculate rung
    boundaries and terminate eliminated trials instead of leaving
    them in PAUSED limbo.
    """
    for param in hyperparameters:
        if param.get('name') == 'epochs':
            max_val = param.get('max')
            if max_val is not None:
                return int(max_val)
    return None


def convert_tune_scheduler(tune_config: dict[str, Any], max_t: int | None = None) -> Any:
    """Convert tune_config to a Ray Tune scheduler instance.

    Supports both string and dict formats for scheduler:
        - String: "hyperband"
        - Dict: {"name": "hyperband", "options": {...}}

    For HyperBand and ASHA schedulers, max_t is automatically injected
    if not explicitly set in options. Without max_t, these schedulers may
    leave paused trials in limbo instead of terminating them.
    """
    from ray.tune.schedulers import (
        ASHAScheduler,
        FIFOScheduler,
        HyperBandScheduler,
        MedianStoppingRule,
        PopulationBasedTraining,
    )

    scheduler_raw = tune_config.get('scheduler')
    if scheduler_raw is None:
        return None

    if isinstance(scheduler_raw, str):
        scheduler_name = scheduler_raw.lower()
        options: dict[str, Any] = {}
    elif isinstance(scheduler_raw, dict):
        scheduler_name = scheduler_raw.get('name', 'fifo').lower()
        options = scheduler_raw.get('options') or {}
    else:
        return None

    scheduler_map = {
        'fifo': FIFOScheduler,
        'asha': ASHAScheduler,
        'hyperband': HyperBandScheduler,
        'pbt': PopulationBasedTraining,
        'median': MedianStoppingRule,
    }

    scheduler_class = scheduler_map.get(scheduler_name)
    if scheduler_class is None:
        raise ValueError(f"Unsupported scheduler: '{scheduler_name}'. Supported: {', '.join(scheduler_map.keys())}")

    # Auto-inject max_t for HyperBand/ASHA if not explicitly set
    if scheduler_name in ('hyperband', 'asha') and max_t is not None:
        options = dict(options)
        options.setdefault('max_t', max_t)
        logger.info('Auto-injected max_t=%d for %s scheduler.', max_t, scheduler_name)

    return scheduler_class(**options) if options else scheduler_class()


def build_tune_runtime_env(action: BaseTrainAction[Any]) -> dict[str, Any]:
    """Build Ray runtime_env for tune trials.

    Mirrors the logic in BaseRayExecutor._build_runtime_env() to ensure
    tune trial workers have access to plugin code, dependencies, and credentials.
    """
    from synapse_sdk.plugins.executors.ray.base import read_requirements

    runtime_env: dict[str, Any] = {}

    # 1. Working directory — ship plugin code to workers
    working_dir = Path.cwd()
    runtime_env['working_dir'] = str(working_dir)

    # 2. Python dependencies from requirements.txt
    req_path = working_dir / 'requirements.txt'
    requirements = read_requirements(req_path)
    if requirements:
        packages = [r for r in requirements if not r.strip().startswith('-')]
        pip_args = [r for r in requirements if r.strip().startswith('-')]

        if packages:
            runtime_env['pip'] = {'packages': packages}

        if pip_args:
            import shlex

            split_args = []
            for arg in pip_args:
                split_args.extend(shlex.split(arg))
            runtime_env.setdefault('pip', {})
            runtime_env['pip']['pip_install_options'] = split_args

    # 3. Include SDK source so workers can import synapse_sdk
    import synapse_sdk

    sdk_path = str(Path(synapse_sdk.__file__).parent)
    runtime_env['py_modules'] = [sdk_path]

    # 4. Environment variables — Synapse credentials for backend client
    env_vars: dict[str, str] = {}

    from synapse_sdk.utils.auth import ENV_SYNAPSE_ACCESS_TOKEN, ENV_SYNAPSE_HOST, load_credentials

    creds = load_credentials()
    if creds.host:
        env_vars[ENV_SYNAPSE_HOST] = creds.host
    if creds.token:
        env_vars[ENV_SYNAPSE_ACCESS_TOKEN] = creds.token

    # Include plugin environment variables
    if hasattr(action.ctx, 'env') and action.ctx.env:
        env_vars.update(action.ctx.env.to_dict())

    # Include job_id for trial logging
    if action.ctx.job_id:
        env_vars['SYNAPSE_TUNE_JOB_ID'] = action.ctx.job_id

    if env_vars:
        runtime_env['env_vars'] = env_vars

    logger.info(
        'Built tune runtime_env: working_dir=%s, pip=%s, py_modules=%s',
        working_dir,
        bool(requirements),
        bool(sdk_path),
    )

    return runtime_env


def get_tune_artifact_path(result: Any) -> str | None:
    """Get the checkpoint/artifact path from a Ray Tune result.

    Priority:
    1. checkpoint_output from metrics (plugin-reported)
    2. Ray checkpoint path (result.checkpoint.path or result.best_checkpoints)
    """
    metrics = getattr(result, 'metrics', None)
    if isinstance(metrics, dict):
        for key in ('checkpoint_output', 'checkpoint', 'result'):
            path = metrics.get(key)
            if path:
                return str(path)

    checkpoint = getattr(result, 'checkpoint', None)
    if checkpoint:
        if hasattr(checkpoint, 'path') and checkpoint.path:
            return str(checkpoint.path)
        try:
            return str(checkpoint.to_directory())
        except Exception:
            pass

    best_checkpoints = getattr(result, 'best_checkpoints', None)
    if best_checkpoints and len(best_checkpoints) > 0:
        ckpt = best_checkpoints[0]
        if hasattr(ckpt, 'path'):
            return str(ckpt.path)

    return None


def upload_trial_model(
    action: BaseTrainAction[Any],
    trial_id: str,
    config: dict[str, Any],
    metrics: dict[str, Any],
    artifact_path: str,
) -> dict[str, Any] | None:
    """Upload model for a completed trial.

    Called by TuneTrialCallback.on_trial_complete() to upload each trial's
    model to the backend as soon as the trial completes.
    """
    from synapse_sdk.utils.file.archive import create_archive

    if not action.client:
        logger.warning('No client available for model upload.')
        return None

    if not artifact_path or not Path(artifact_path).exists():
        logger.warning('Trial %s: No valid artifact path for model upload.', trial_id)
        return None

    params_dict = action.params.model_dump() if hasattr(action.params, 'model_dump') else dict(action.params)
    configuration = {
        'hyperparameters': params_dict.get('hyperparameters'),
        'tune_config': params_dict.get('tune_config'),
        'tune_trial': {
            'trial_id': trial_id,
            'config': config,
            'metrics': metrics,
            'logdir': artifact_path,
        },
    }

    base_name = params_dict.get('name') or f'tune_{action.ctx.job_id}'
    model_name = f'{base_name}_{trial_id}'

    # Get plugin code from job's plugin_release
    plugin_code = None
    version = None
    job_id = action.ctx.job_id
    if job_id and action.client:
        try:
            job_info = action.client.get_job(job_id)
            plugin_release = job_info.get('plugin_release')

            if isinstance(plugin_release, int):
                release_info = action.client.get_plugin_release(plugin_release, params={'expand': 'plugin'})
                plugin = release_info.get('plugin')
                if isinstance(plugin, dict):
                    plugin_code = plugin.get('code')
                version = release_info.get('version')
            elif isinstance(plugin_release, dict):
                plugin = plugin_release.get('plugin')
                if isinstance(plugin, dict):
                    plugin_code = plugin.get('code')
                version = plugin_release.get('version')
        except Exception as e:
            logger.warning('Failed to get plugin info from job: %s', e)

    temp_dir = tempfile.mkdtemp()
    try:
        archive_path = Path(temp_dir) / 'model.zip'
        create_archive(Path(artifact_path), archive_path)

        model_data: dict[str, Any] = {
            'name': model_name,
            'description': f'Trial {trial_id} model',
            'configuration': configuration,
        }
        if plugin_code:
            model_data['plugin'] = plugin_code
        if version:
            model_data['version'] = version

        # Set checkpoint (parent model) for fine-tuned category
        checkpoint_id = None
        if action.ctx.checkpoint:
            checkpoint_id = action.ctx.checkpoint.get('id')
        if not checkpoint_id:
            checkpoint_id = params_dict.get('checkpoint')
        if checkpoint_id:
            model_data['checkpoint'] = checkpoint_id

        logger.info(
            'Uploading trial %s model: plugin=%s, version=%s, name=%s',
            trial_id,
            plugin_code,
            version,
            model_name,
        )

        model = action.client.create_model(model_data, file=archive_path)
        logger.info('Trial %s model uploaded successfully: %s', trial_id, model.get('id') if model else None)
        return model
    except Exception as e:
        logger.error('Failed to upload trial %s model: %s', trial_id, e)
        return None
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def override_best_trial(
    action: BaseTrainAction[Any],
    trial_id: str,
    best_config: dict[str, Any],
    trial_callback: TuneTrialCallback,
) -> None:
    """Override best trial via backend API and emit final log_trials snapshot."""
    job_id = action.ctx.job_id
    if not job_id:
        logger.warning('Skipping override_best_trial: job_id not available.')
        if trial_callback._trial_rows:
            trial_callback._emit_final_snapshot(trial_id)
        return

    payload = {'trial_id': trial_id, **best_config}
    url = f'trains/{job_id}/override_best_trial/'

    logger.info('Calling override_best_trial: %s payload=%s', url, payload)

    try:
        action.client._put(url, data=payload)
        logger.info('Successfully called override_best_trial API.')
    except Exception as e:
        logger.warning('Failed to override best trial via API: %s', e)

    if trial_callback._trial_rows:
        trial_callback._emit_final_snapshot(trial_id)


class TuneTrialCallback(_TuneCallbackBase):
    """Ray Tune callback for tracking trial progress and logging trial tables.

    Captures Ray Tune trial snapshots and forwards them to action.ctx.log_trials().
    Also reports trial completion progress via the action's set_progress().
    """

    BASE_COLUMNS = ('trial_id', 'status')
    METRIC_COLUMN_LIMIT = 4
    RESERVED_RESULT_KEYS = {
        'config',
        'date',
        'done',
        'experiment_id',
        'experiment_state',
        'experiment_tag',
        'hostname',
        'iterations_since_restore',
        'logdir',
        'node_ip',
        'pid',
        'restored_from_trial_id',
        'time_since_restore',
        'time_this_iter_s',
        'time_total',
        'time_total_s',
        'timestamp',
        'timesteps_since_restore',
        'timesteps_total',
        'training_iteration',
        'trial_id',
    }

    def __init__(self, action: BaseTrainAction[Any], num_samples: int = 1) -> None:
        self._action = action
        self._num_samples = num_samples
        self._completed = 0
        self._trial_rows: dict[str, dict[str, Any]] = {}
        self._config_keys: list[str] = []
        self._metric_keys: list[str] = []
        self._last_snapshot: tuple[Any, ...] | None = None
        self._trial_models: list[dict[str, Any]] = []

    def on_trial_result(
        self, iteration: int, trials: list[Any], trial: Any, result: dict[str, Any], **info: Any
    ) -> None:
        """Called when a trial reports intermediate results."""
        self._record_trial(trial, result, status_override='RUNNING')
        self._emit_snapshot()

    def on_trial_complete(self, iteration: int, trials: list[Any], trial: Any, **info: Any) -> None:
        """Called when a trial completes successfully."""
        last_result = getattr(trial, 'last_result', None) or {}
        self._record_trial(trial, last_result, status_override='TERMINATED')
        self._emit_snapshot()
        self._completed += 1
        self._update_progress()

        # Upload trial model to backend
        trial_id = getattr(trial, 'trial_id', None)
        if trial_id and isinstance(last_result, dict):
            artifact_path = last_result.get('checkpoint_output')
            if artifact_path:
                try:
                    config = getattr(trial, 'config', {}) or {}
                    model = upload_trial_model(
                        action=self._action,
                        trial_id=trial_id,
                        config=config,
                        metrics=last_result,
                        artifact_path=artifact_path,
                    )
                    if model:
                        self._trial_models.append({
                            'trial_logdir': artifact_path,
                            'model_id': model.get('id'),
                            'config': config,
                            'metrics': last_result,
                        })
                except Exception as e:
                    logger.warning('Failed to upload trial %s model: %s', trial_id, e)

    def on_trial_error(self, iteration: int, trials: list[Any], trial: Any, **info: Any) -> None:
        """Called when a trial errors out."""
        self._record_trial(trial, getattr(trial, 'last_result', None), status_override='ERROR')
        self._emit_snapshot()
        self._completed += 1
        logger.warning('Tune trial %s ended with error.', getattr(trial, 'trial_id', '?'))
        self._update_progress()

    def on_step_end(self, iteration: int, trials: list[Any], **info: Any) -> None:
        """Called at the end of each tuning step to detect status changes."""
        updated = False
        for trial in trials or []:
            trial_id = getattr(trial, 'trial_id', None)
            if not trial_id:
                continue
            status = getattr(trial, 'status', None)
            existing = self._trial_rows.get(trial_id)
            existing_status = existing.get('status') if existing else None
            if existing is None or (status and status != existing_status):
                self._record_trial(
                    trial,
                    getattr(trial, 'last_result', None),
                    status_override=status,
                )
                updated = True
        if updated:
            self._emit_snapshot()

    def _record_trial(self, trial: Any, result: dict[str, Any] | None, status_override: str | None = None) -> None:
        """Record trial data (config, metrics, status) into trial_rows."""
        trial_id = getattr(trial, 'trial_id', None)
        if not trial_id:
            return

        row = self._trial_rows.setdefault(trial_id, {})
        result = result if isinstance(result, dict) else {}

        row['trial_id'] = trial_id
        row['status'] = status_override or getattr(trial, 'status', 'PENDING')

        config_data = self._extract_config(getattr(trial, 'config', None) or {})
        metric_data = self._extract_metrics(result)

        row.update(config_data)
        row.update(metric_data)

        self._track_columns(config_data.keys(), metric_data.keys())

    def _extract_config(self, config: dict[str, Any]) -> dict[str, Any]:
        """Extract and flatten config values."""
        flat: dict[str, Any] = {}
        if not isinstance(config, dict):
            return flat
        for key, value in self._flatten_items(config):
            flat[key] = self._serialize_config_value(value)
        return flat

    def _extract_metrics(self, result: dict[str, Any]) -> dict[str, Any]:
        """Extract metrics from trial result."""
        metrics: dict[str, Any] = {}
        if not isinstance(result, dict):
            return metrics

        nested = result.get('metrics')
        if isinstance(nested, dict):
            for key, value in self._flatten_items(nested, prefix='metrics'):
                serialized = self._serialize_metric_value(value)
                if serialized is not None:
                    metrics[key] = serialized

        for key, value in result.items():
            if key in self.RESERVED_RESULT_KEYS or key == 'metrics':
                continue
            if isinstance(value, dict):
                continue
            serialized = self._serialize_metric_value(value)
            if serialized is not None:
                metrics[key] = serialized

        return metrics

    def _track_columns(self, config_keys: Any, metric_keys: Any) -> None:
        """Track discovered config and metric column names."""
        for key in config_keys:
            if key not in self._config_keys:
                self._config_keys.append(key)
        for key in metric_keys:
            if key not in self._metric_keys and len(self._metric_keys) < self.METRIC_COLUMN_LIMIT:
                self._metric_keys.append(key)

    def _emit_snapshot(self) -> None:
        """Emit trial table snapshot via log_trials() if changed."""
        if not self._trial_rows:
            return

        base_keys = list(self.BASE_COLUMNS)
        config_keys = list(self._config_keys)
        metric_keys = list(self._metric_keys)

        ordered_trials: dict[str, dict[str, Any]] = {}
        flat_rows: list[tuple[str, tuple[Any, ...]]] = []

        for trial_id in sorted(self._trial_rows.keys()):
            row = self._trial_rows[trial_id]
            base_values = [row.get(col) for col in base_keys]
            hyper_values = [row.get(col) for col in config_keys]
            metric_values = [row.get(col) for col in metric_keys]

            ordered_trials[trial_id] = {
                'base': base_values,
                'hyperparameters': hyper_values,
                'metrics': metric_values,
            }
            flat_rows.append((trial_id, tuple(base_values + hyper_values + metric_values)))

        snapshot = (tuple(base_keys + config_keys + metric_keys), tuple(flat_rows))
        if snapshot == self._last_snapshot:
            return
        self._last_snapshot = snapshot

        try:
            self._action.ctx.log_trials(
                base=base_keys,
                trials=ordered_trials,
                hyperparameters=config_keys,
                metrics=metric_keys,
                best_trial='',
            )
        except Exception as e:
            logger.debug('Failed to log trials snapshot: %s', e)

    def _flatten_items(self, data: dict[str, Any], prefix: str | None = None) -> Any:
        """Flatten nested dict into (key, value) pairs."""
        if not isinstance(data, dict):
            return
        for key, value in data.items():
            key_str = str(key)
            current = f'{prefix}/{key_str}' if prefix else key_str
            if isinstance(value, dict):
                yield from self._flatten_items(value, current)
            else:
                yield current, value

    def _serialize_config_value(self, value: Any) -> Any:
        """Serialize config value for JSON compatibility."""
        from numbers import Number

        if isinstance(value, (str, bool)) or value is None:
            return value
        if isinstance(value, Number) and not isinstance(value, bool):
            return float(value)
        return str(value)

    def _serialize_metric_value(self, value: Any) -> float | None:
        """Serialize metric value (only numeric values)."""
        from numbers import Number

        if isinstance(value, Number) and not isinstance(value, bool):
            return float(value)
        return None

    def _update_progress(self) -> None:
        """Update trial completion progress using step='trials'."""
        completed = min(self._completed, self._num_samples)
        try:
            self._action.ctx.set_progress(completed, self._num_samples, step='trials')
        except Exception:
            pass

    def _emit_final_snapshot(self, best_trial_id: str) -> None:
        """Emit final trial table snapshot with best_trial set."""
        if not self._trial_rows:
            return

        base_keys = list(self.BASE_COLUMNS)
        config_keys = list(self._config_keys)
        metric_keys = list(self._metric_keys)

        ordered_trials: dict[str, dict[str, Any]] = {}

        for trial_id in sorted(self._trial_rows.keys()):
            row = self._trial_rows[trial_id]
            base_values = [row.get(col) for col in base_keys]
            hyper_values = [row.get(col) for col in config_keys]
            metric_values = [row.get(col) for col in metric_keys]

            ordered_trials[trial_id] = {
                'base': base_values,
                'hyperparameters': hyper_values,
                'metrics': metric_values,
            }

        try:
            self._action.ctx.log_trials(
                base=base_keys,
                trials=ordered_trials,
                hyperparameters=config_keys,
                metrics=metric_keys,
                best_trial=best_trial_id,
            )
            logger.info('Emitted final trials snapshot with best_trial=%s', best_trial_id)
        except Exception as e:
            logger.debug('Failed to log final trials snapshot: %s', e)


__all__ = [
    'TuneTrialCallback',
    'TuneTrialLoggerWrapper',
    'build_tune_runtime_env',
    'convert_tune_params',
    'infer_max_t',
    'convert_tune_scheduler',
    'convert_tune_search_alg',
    'get_tune_artifact_path',
    'override_best_trial',
    'upload_trial_model',
]
