"""Tune trials execution step — runs Ray Tune hyperparameter search."""

from __future__ import annotations

import logging
import os
import tempfile
from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.action import BaseTrainAction
    from synapse_sdk.plugins.actions.train.context import TrainContext

logger = logging.getLogger(__name__)


class TuneTrialsStep(BaseStep['TrainContext']):
    """Execute hyperparameter tuning trials via Ray Tune.

    Initializes Ray, builds the search space from backend params,
    creates a trainable function, and runs the Tuner. Per-trial
    model uploads happen via TuneTrialCallback.on_trial_complete().

    Progress is reported as completed_trials / total_trials.
    """

    def __init__(self, action: BaseTrainAction[Any]) -> None:
        self._action = action

    @property
    def name(self) -> str:
        return 'trials'

    @property
    def progress_weight(self) -> float:
        return 0.6

    @property
    def progress_proportion(self) -> int:
        return 75

    def execute(self, context: TrainContext) -> StepResult:
        import ray
        from ray import tune

        from synapse_sdk.plugins.actions.train.tune import (
            TuneTrialCallback,
            TuneTrialLoggerWrapper,
            build_tune_runtime_env,
            convert_tune_params,
            convert_tune_scheduler,
            convert_tune_search_alg,
            infer_max_t,
            override_best_trial,
        )

        action = self._action

        if not ray.is_initialized():
            is_inside_ray_job = bool(os.environ.get('RAY_JOB_CONFIG_JSON_ENV_VAR'))

            if is_inside_ray_job:
                ray.init(address='auto')
                logger.info('Connected to existing Ray cluster (inside Ray Job).')
            else:
                runtime_env = build_tune_runtime_env(action)
                ray.init(runtime_env=runtime_env)
                logger.info('Initialized Ray with custom runtime_env (local mode).')

        logger.info('Starting hyperparameter tuning mode.')

        # Parse tune_config from params
        params_dict = action.params.model_dump() if hasattr(action.params, 'model_dump') else dict(action.params)
        tune_config = params_dict.get('tune_config') or {}
        hyperparameters = action.params.hyperparameters or []

        # Convert search space definitions to Ray Tune param_space
        param_space = convert_tune_params(hyperparameters)

        # Setup search algorithm and scheduler
        search_alg = convert_tune_search_alg(tune_config)
        max_t = infer_max_t(hyperparameters)
        scheduler = convert_tune_scheduler(tune_config, max_t=max_t)

        # Build TuneConfig kwargs
        os.environ['TUNE_DISABLE_STRICT_METRIC_CHECKING'] = '1'

        tune_config_kwargs: dict[str, Any] = {
            'num_samples': tune_config.get('num_samples', 1),
        }
        if tune_config.get('mode'):
            tune_config_kwargs['mode'] = tune_config['mode']
        if tune_config.get('metric'):
            tune_config_kwargs['metric'] = tune_config['metric']
        if tune_config.get('max_concurrent_trials'):
            tune_config_kwargs['max_concurrent_trials'] = tune_config['max_concurrent_trials']
        if search_alg is not None:
            tune_config_kwargs['search_alg'] = search_alg
        if scheduler is not None:
            tune_config_kwargs['scheduler'] = scheduler

        # Create trainable function
        action_cls = type(action)
        base_params = params_dict.copy()
        data_path = context.data_path
        checkpoint = action.get_checkpoint()
        job_id = action.ctx.job_id

        def _trial_entrypoint(
            config: dict[str, Any],
            action_cls: type,
            base_params: dict[str, Any],
            data_path: Any,
            checkpoint: Any,
            tune_job_id: str | None,
        ) -> dict[str, Any]:
            """Single tune trial entrypoint."""
            from synapse_sdk.plugins.context import PluginEnvironment, RuntimeContext

            os.environ['IS_TUNE'] = 'true'

            # Extract trial_id
            trial_id = None
            try:
                from ray import train

                ctx = train.get_context()
                trial_id = ctx.get_trial_id()
            except Exception:
                pass

            if not trial_id:
                try:
                    from ray import tune as ray_tune

                    trial_id = ray_tune.get_trial_id()
                except Exception:
                    pass

            if trial_id:
                os.environ['SYNAPSE_TRIAL_ID'] = trial_id

            # Merge base params with trial config
            trial_params = {**base_params, **config}

            # Create logger
            if tune_job_id:
                try:
                    from synapse_sdk.loggers import JobLogger
                    from synapse_sdk.utils.auth import create_backend_client

                    client = create_backend_client()
                    if client:
                        base_logger = JobLogger(client=client, job_id=tune_job_id)
                        trial_logger = TuneTrialLoggerWrapper(base_logger)
                    else:
                        from synapse_sdk.loggers import ConsoleLogger

                        trial_logger = ConsoleLogger()
                except Exception:
                    from synapse_sdk.loggers import ConsoleLogger

                    trial_logger = ConsoleLogger()
            else:
                from synapse_sdk.loggers import ConsoleLogger

                trial_logger = ConsoleLogger()

            # Create fresh action instance
            ctx = RuntimeContext(
                logger=trial_logger,
                env=PluginEnvironment.from_environ(),
                job_id=tune_job_id,
            )
            trial_action = action_cls(action_cls.params_model(**trial_params), ctx)

            # Setup tune.report wrapper to cache metrics
            last_metrics: dict[str, Any] = {}

            try:
                from ray import tune as ray_tune

                original_report = ray_tune.report

                def caching_report(metrics: dict[str, Any] = None, *args: Any, **kwargs: Any) -> Any:
                    nonlocal last_metrics

                    checkpoint = kwargs.pop('checkpoint', None)

                    if metrics is not None:
                        if isinstance(metrics, dict):
                            report_metrics = metrics
                        elif hasattr(metrics, 'items'):
                            report_metrics = dict(metrics)
                        else:
                            report_metrics = {}
                    elif kwargs:
                        report_metrics = dict(kwargs)
                        kwargs = {}
                    else:
                        report_metrics = {}

                    for k, v in report_metrics.items():
                        last_metrics[k] = v

                    if checkpoint is not None:
                        return original_report(report_metrics, checkpoint=checkpoint)
                    else:
                        return original_report(report_metrics)

                ray_tune.report = caching_report
            except ImportError:
                original_report = None
                ray_tune = None

            execute_result = None
            try:
                execute_result = trial_action.execute(data_path, checkpoint)
            finally:
                if ray_tune and original_report:
                    ray_tune.report = original_report

            # Add checkpoint_output from multiple sources
            if execute_result is not None:
                if hasattr(execute_result, 'weights_path'):
                    weights_path = execute_result.weights_path
                elif isinstance(execute_result, dict):
                    weights_path = execute_result.get('weights_path')
                else:
                    weights_path = None

                if weights_path:
                    last_metrics['checkpoint_output'] = str(weights_path)

            if 'checkpoint_output' not in last_metrics:
                try:
                    from synapse_sdk.integrations._context import get_autolog_context

                    autolog_ctx = get_autolog_context()
                    if autolog_ctx and 'model_path' in autolog_ctx.extra:
                        last_metrics['checkpoint_output'] = autolog_ctx.extra['model_path']
                except ImportError:
                    pass

            return last_metrics

        train_fn = tune.with_parameters(
            _trial_entrypoint,
            action_cls=action_cls,
            base_params=base_params,
            data_path=data_path,
            checkpoint=checkpoint,
            tune_job_id=job_id,
        )

        trainable = tune.with_resources(train_fn, {'cpu': 1, 'gpu': 0.5})

        storage_dir = tempfile.mkdtemp(prefix='synapse_tune_')
        num_samples = tune_config.get('num_samples', 1)

        # Initialize trials progress
        try:
            action.ctx.set_progress(0, num_samples, step='trials')
        except Exception:
            pass

        trial_callback = TuneTrialCallback(action=action, num_samples=num_samples)
        callbacks = [trial_callback]

        tuner = tune.Tuner(
            trainable,
            tune_config=tune.TuneConfig(**tune_config_kwargs),
            run_config=tune.RunConfig(
                name='synapse_tune_hpo',
                log_to_file=('stdout.log', 'stderr.log'),
                storage_path=storage_dir,
                callbacks=callbacks,
            ),
            param_space=param_space,
        )

        logger.info('Launching Ray Tune with %d samples.', num_samples)
        result_grid = tuner.fit()

        # Extract best result
        best_result = result_grid.get_best_result()
        best_config = best_result.config if best_result else {}
        best_trial_id = ''

        if best_result and trial_callback._trial_rows:
            best_metrics = getattr(best_result, 'metrics', {}) or {}
            metric_key = tune_config.get('metric')

            if metric_key and metric_key in best_metrics:
                target_value = best_metrics[metric_key]
                for tid, row in trial_callback._trial_rows.items():
                    if metric_key in row:
                        try:
                            if abs(float(row[metric_key]) - float(target_value)) < 1e-6:
                                best_trial_id = tid
                                break
                        except (TypeError, ValueError):
                            pass

            if not best_trial_id:
                for tid, row in trial_callback._trial_rows.items():
                    if row.get('status') == 'TERMINATED':
                        best_trial_id = tid
                        break

        # Override best trial via backend API
        if best_trial_id:
            override_best_trial(action, best_trial_id, best_config, trial_callback)

        # Store results in context
        context.tune_result = {'best_result': best_config}
        context.trial_models = trial_callback._trial_models

        logger.info('Tune completed. Best config: %s', best_config)

        return StepResult(
            success=True,
            data={
                'best_result': best_config,
                'trial_models': trial_callback._trial_models,
            },
        )


__all__ = ['TuneTrialsStep']
