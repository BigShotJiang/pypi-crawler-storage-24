"""Model upload step for training workflow."""

from __future__ import annotations

import logging
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.action import BaseTrainAction
    from synapse_sdk.plugins.actions.train.context import TrainContext

logger = logging.getLogger(__name__)


class ModelUploadStep(BaseStep['TrainContext']):
    """Upload trained model to backend.

    Archives the model from context.model_path and uploads to the
    Synapse backend. Includes plugin code/version from the job's
    plugin_release and checkpoint ID for fine-tuned categorization.

    In tune mode, this step is skipped because models are uploaded
    per-trial by TuneTrialsStep.
    """

    def __init__(self, action: BaseTrainAction[Any]) -> None:
        self._action = action

    @property
    def name(self) -> str:
        return 'model_upload'

    @property
    def progress_weight(self) -> float:
        return 0.1

    @property
    def progress_proportion(self) -> int:
        return 5

    def can_skip(self, context: TrainContext) -> bool:
        """Skip in tune mode (models uploaded per-trial) or if no model."""
        is_tune = context.params.get('is_tune', False)
        return is_tune or not context.model_path

    def execute(self, context: TrainContext) -> StepResult:
        from synapse_sdk.plugins.actions.train.log_messages import TrainLogMessageCode
        from synapse_sdk.utils.file.archive import create_archive

        # Check if model_path is available
        model_path = context.model_path
        if not model_path:
            logger.info('No model_path in context. Skipping model upload.')
            return StepResult(success=True, data={'skipped': True})

        model_path = Path(model_path)
        if not model_path.exists():
            logger.warning('Model path does not exist: %s', model_path)
            return StepResult(success=True, data={'skipped': True, 'reason': 'path_not_found'})

        # Get client
        try:
            client = self._action.client
        except (RuntimeError, AttributeError):
            logger.warning('No client available for model upload.')
            return StepResult(success=True, data={'skipped': True, 'reason': 'no_client'})

        # Log upload start
        self._action.log_message(TrainLogMessageCode.TRAIN_MODEL_SAVED)

        temp_dir = tempfile.mkdtemp()
        try:
            archive_path = Path(temp_dir) / 'model.zip'
            create_archive(model_path, archive_path)

            # Build model name
            params_dict = self._action.params.model_dump() if hasattr(self._action.params, 'model_dump') else {}
            model_name = params_dict.get('name') or f'train_{self._action.ctx.job_id}'

            # Build configuration
            configuration = {
                'hyperparameter': params_dict.get('hyperparameter')
                or (params_dict.get('hyperparameters', [{}])[0] if params_dict.get('hyperparameters') else {}),
            }

            # Build model data
            model_data: dict[str, Any] = {
                'name': model_name,
                'description': params_dict.get('description', ''),
                'configuration': configuration,
            }

            # Get plugin code and version from job's plugin_release
            job_id = self._action.ctx.job_id
            if job_id:
                try:
                    job_info = client.get_job(job_id)
                    plugin_release = job_info.get('plugin_release')

                    if isinstance(plugin_release, int):
                        release_info = client.get_plugin_release(plugin_release, params={'expand': 'plugin'})
                        plugin = release_info.get('plugin')
                        if isinstance(plugin, dict):
                            model_data['plugin'] = plugin.get('code')
                        model_data['version'] = release_info.get('version')
                    elif isinstance(plugin_release, dict):
                        plugin = plugin_release.get('plugin')
                        if isinstance(plugin, dict):
                            model_data['plugin'] = plugin.get('code')
                        model_data['version'] = plugin_release.get('version')
                except Exception as e:
                    logger.debug('Failed to get plugin info from job: %s', e)

            # Set checkpoint (parent model) for fine-tuned category
            checkpoint_id = None
            if context.runtime_ctx.checkpoint:
                checkpoint_id = context.runtime_ctx.checkpoint.get('id')
            if not checkpoint_id:
                checkpoint_id = params_dict.get('checkpoint')
            if checkpoint_id:
                model_data['checkpoint'] = checkpoint_id

            # Register model
            model = client.create_model(model_data, file=archive_path)
            self._action.log_message(f'Model registered: {model.get("id")}')

            # Store model info in context
            context.model = model

            # Log upload complete
            self._action.log_message(TrainLogMessageCode.TRAIN_MODEL_UPLOADED)

            return StepResult(success=True, data={'model_id': model})

        except Exception as e:
            logger.error('Model upload failed: %s', e)
            self._action.log_message(f'Model registration failed: {e}')
            return StepResult(success=False, error=str(e))
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)


__all__ = ['ModelUploadStep']
