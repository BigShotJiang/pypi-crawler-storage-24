"""Tune-mode dataset preparation step.

Combines dataset export and conversion into a single step for tune mode,
since dataset preparation only runs once before all trials.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from synapse_sdk.plugins.actions.train.tune import TuneTrialLoggerWrapper
from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.context import TrainContext


class TuneDatasetStep(BaseStep['TrainContext']):
    """Export and convert dataset once for all tune trials.

    Combines export + convert into a single step because in tune mode,
    dataset preparation runs once before launching Ray Tune trials.
    Uses _ScopedLoggerProxy to contain DatasetAction's sub-step progress.

    After execution, sets context.data_path for use by TuneTrialsStep.
    """

    def __init__(
        self,
        target_format: str | None = None,
        source_format: str = 'dm_v2',
    ) -> None:
        self._target_format = target_format
        self._source_format = source_format

    @property
    def name(self) -> str:
        return 'dataset'

    @property
    def progress_weight(self) -> float:
        return 0.3

    @property
    def progress_proportion(self) -> int:
        return 20

    def can_skip(self, context: TrainContext) -> bool:
        return context.params.get('dataset') is None

    def execute(self, context: TrainContext) -> StepResult:
        from synapse_sdk.plugins.actions.dataset import (
            DatasetAction,
            DatasetOperation,
            DatasetParams,
        )

        dataset = context.params.get('dataset')
        if dataset is None:
            return StepResult(success=True, data={'skipped': True})

        splits = context.params.get('splits')
        output_dir = context.params.get('output_dir')

        # Suppress sub-step progress during dataset preparation.
        # Use TuneTrialLoggerWrapper to ignore progress + ScopedLoggerProxy for containment.
        original_logger = context.runtime_ctx.logger
        suppressed_logger = TuneTrialLoggerWrapper(original_logger)
        context.runtime_ctx.logger = suppressed_logger

        try:
            # 1. Export dataset
            export_params = DatasetParams(
                operation=DatasetOperation.DOWNLOAD,
                dataset=dataset,
                splits=splits,
                output_dir=output_dir,
            )
            export_action = DatasetAction(export_params, context.runtime_ctx)
            export_result = export_action.execute()

            # Store export result in context
            context.dataset = {
                'path': export_result.path,
                'format': export_result.format,
                'is_categorized': export_result.is_categorized,
                'count': export_result.count,
            }

            # 2. Convert dataset if target_format specified
            if self._target_format:
                convert_params = DatasetParams(
                    operation=DatasetOperation.CONVERT,
                    path=export_result.path,
                    source_format=self._source_format,
                    target_format=self._target_format,
                    is_categorized=export_result.is_categorized,
                )
                convert_action = DatasetAction(convert_params, context.runtime_ctx)
                convert_result = convert_action.execute()

                context.dataset = {
                    'path': convert_result.path,
                    'config_path': convert_result.config_path,
                    'format': convert_result.format,
                    'is_categorized': convert_result.is_categorized,
                    'source_path': export_result.path,
                }
        finally:
            context.runtime_ctx.logger = original_logger

        # Resolve data_path for TuneTrialsStep
        context.data_path = self._resolve_data_path(context)

        return StepResult(
            success=True,
            data={
                'path': str(context.dataset.get('path', '')),
                'data_path': str(context.data_path) if context.data_path else None,
            },
        )

    def _resolve_data_path(self, context: TrainContext) -> Path | None:
        """Resolve final data path from context.dataset."""
        if context.dataset is None:
            return None

        config_path = context.dataset.get('config_path')
        if config_path is not None:
            return Path(config_path)

        path = context.dataset.get('path')
        if path is not None:
            path = Path(path)
            return path / 'dataset.yaml' if path.is_dir() else path

        return None


__all__ = ['TuneDatasetStep']
