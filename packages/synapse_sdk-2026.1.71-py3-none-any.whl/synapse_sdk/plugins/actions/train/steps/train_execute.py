"""Training execution step that wraps the plugin's execute() method."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.action import BaseTrainAction
    from synapse_sdk.plugins.actions.train.context import TrainContext


class TrainExecuteStep(BaseStep['TrainContext']):
    """Execute the plugin's training logic.

    Resolves data_path and checkpoint from context, then calls
    action.execute(data_path, checkpoint). Stores model_path
    in context for the subsequent ModelUploadStep.
    """

    def __init__(self, action: BaseTrainAction[Any]) -> None:
        self._action = action

    @property
    def name(self) -> str:
        return 'train'

    @property
    def progress_weight(self) -> float:
        return 0.5

    @property
    def progress_proportion(self) -> int:
        return 75

    def execute(self, context: TrainContext) -> StepResult:
        # Resolve data path from context (set by export/convert steps)
        data_path = self._resolve_data_path(context)
        if data_path is None:
            return StepResult(
                success=False,
                error='No data path available. Ensure ExportDatasetStep and ConvertDatasetStep ran successfully.',
            )

        # Resolve checkpoint
        checkpoint = self._action.get_checkpoint()

        # Call action's execute method
        try:
            result = self._action.execute(data_path, checkpoint)
        except Exception as e:
            return StepResult(success=False, error=str(e))

        # Extract result data
        if hasattr(result, 'model_dump'):
            result_data = result.model_dump()
        elif isinstance(result, dict):
            result_data = result
        else:
            result_data = {'result': result}

        # Store model_path in context if available (from execute() result)
        weights_path = result_data.get('weights_path')
        if weights_path:
            context.model_path = weights_path

        # Also check autolog context for model_path (set by on_train_end callback)
        if not context.model_path:
            try:
                from synapse_sdk.integrations._context import get_autolog_context

                autolog_ctx = get_autolog_context()
                if autolog_ctx and autolog_ctx.extra.get('model_path'):
                    context.model_path = autolog_ctx.extra['model_path']
            except ImportError:
                pass

        return StepResult(success=True, data=result_data)

    def _resolve_data_path(self, context: TrainContext) -> Path | None:
        """Resolve data path from context (set by ConvertDatasetStep)."""
        if context.dataset is None:
            return None

        config_path = context.dataset.get('config_path')
        if config_path is not None:
            return Path(config_path)

        path = context.dataset.get('path')
        if path is not None:
            path = Path(path)
            if path.is_dir():
                return path / 'dataset.yaml'
            return path

        return None


__all__ = ['TrainExecuteStep']
