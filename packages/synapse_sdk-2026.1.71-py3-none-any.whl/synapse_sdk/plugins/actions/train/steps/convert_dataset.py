"""Train-specific dataset conversion step with progress containment."""

from __future__ import annotations

from typing import TYPE_CHECKING

from synapse_sdk.plugins.actions.train.steps.export_dataset import _ScopedLoggerProxy
from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.context import TrainContext


class ConvertDatasetStep(BaseStep['TrainContext']):
    """Convert dataset between formats with progress containment.

    Reads dataset info from context.dataset (set by ExportDatasetStep)
    and converts to the target format. Updates context.dataset with:
        - path: Path to converted dataset
        - config_path: Path to config file (e.g., dataset.yaml)
        - format: Target format
        - is_categorized: Whether dataset has splits
        - source_path: Original source path

    Args:
        target_format: Target format to convert to (default: 'yolo').
        source_format: Source format to convert from (default: 'dm_v2').
    """

    def __init__(
        self,
        target_format: str = 'yolo',
        source_format: str = 'dm_v2',
    ) -> None:
        self._target_format = target_format
        self._source_format = source_format

    @property
    def name(self) -> str:
        return 'convert'

    @property
    def progress_weight(self) -> float:
        return 0.2

    @property
    def progress_proportion(self) -> int:
        """0% — conversion is fast and folded into the dataset phase."""
        return 0

    def execute(self, context: TrainContext) -> StepResult:
        from synapse_sdk.plugins.actions.dataset import (
            DatasetAction,
            DatasetOperation,
            DatasetParams,
        )

        if context.dataset is None:
            return StepResult(
                success=False,
                error='No dataset in context. ExportDatasetStep must run first.',
            )

        source_path = context.dataset.get('path')
        if source_path is None:
            return StepResult(
                success=False,
                error='No path in context.dataset',
            )

        is_categorized = context.dataset.get('is_categorized', False)

        params = DatasetParams(
            operation=DatasetOperation.CONVERT,
            path=source_path,
            source_format=self._source_format,
            target_format=self._target_format,
            is_categorized=is_categorized,
        )

        # Wrap logger to contain any sub-step progress
        original_logger = context.runtime_ctx.logger
        context.runtime_ctx.logger = _ScopedLoggerProxy(original_logger, parent_step='dataset')

        try:
            action = DatasetAction(params, context.runtime_ctx)
            result = action.execute()
        finally:
            context.runtime_ctx.logger = original_logger

        if result.config_path is None:
            return StepResult(
                success=False,
                error=f'Conversion failed: no config file generated at {result.path}',
            )

        # Update context with converted dataset info
        context.dataset = {
            'path': result.path,
            'config_path': result.config_path,
            'format': result.format,
            'is_categorized': result.is_categorized,
            'source_path': source_path,
        }

        return StepResult(
            success=True,
            data={
                'path': str(result.path),
                'config_path': str(result.config_path),
            },
        )


__all__ = ['ConvertDatasetStep']
