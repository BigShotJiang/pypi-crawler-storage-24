"""Train-specific dataset export step with progress containment.

Unlike the shared ExportDatasetStep in plugins/steps/dataset.py, this version
wraps DatasetAction with _ScopedLoggerProxy to prevent internal sub-step
progress (init, fetch, download) from leaking to JobLogger as dynamic steps.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from synapse_sdk.plugins.steps.base import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.plugins.actions.train.context import TrainContext


class _ScopedLoggerProxy:
    """Logger proxy that redirects sub-step progress to a parent step.

    When DatasetAction.download() calls set_progress(50, 100, step='download'),
    this proxy rewrites it to set_progress(50, 100, step='dataset'), keeping
    all internal progress within the parent step's scope.

    This prevents sub-steps from being registered as new dynamic steps in
    JobLogger, which would cause progress to exceed 100%.
    """

    def __init__(self, inner: Any, parent_step: str) -> None:
        self._inner = inner
        self._parent_step = parent_step

    def set_progress(self, current: int, total: int, step: str | None = None) -> None:
        """Redirect all progress calls to the parent step."""
        self._inner.set_progress(current, total, self._parent_step)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class ExportDatasetStep(BaseStep['TrainContext']):
    """Download dataset from Synapse backend with progress containment.

    Wraps DatasetAction.download() with _ScopedLoggerProxy so that internal
    sub-steps (init, fetch, download) contribute to the 'dataset' step's
    progress without creating separate dynamic step entries.

    Stores result in context.dataset with keys:
        - path: Path to downloaded dataset
        - format: Dataset format (e.g., 'dm_v2')
        - is_categorized: Whether dataset has train/valid/test splits
        - count: Number of data units downloaded
    """

    @property
    def name(self) -> str:
        return 'dataset'

    @property
    def progress_weight(self) -> float:
        return 0.3

    @property
    def progress_proportion(self) -> int:
        return 20

    def execute(self, context: TrainContext) -> StepResult:
        from synapse_sdk.plugins.actions.dataset import (
            DatasetAction,
            DatasetOperation,
            DatasetParams,
        )

        dataset = context.params.get('dataset')
        if dataset is None:
            return StepResult(
                success=False,
                error='dataset is required in params',
            )

        splits = context.params.get('splits')
        output_dir = context.params.get('output_dir')

        params = DatasetParams(
            operation=DatasetOperation.DOWNLOAD,
            dataset=dataset,
            splits=splits,
            output_dir=output_dir,
        )

        # Wrap logger to contain sub-step progress within 'dataset' step
        original_logger = context.runtime_ctx.logger
        context.runtime_ctx.logger = _ScopedLoggerProxy(original_logger, parent_step=self.name)

        try:
            action = DatasetAction(params, context.runtime_ctx)
            result = action.execute()
        finally:
            context.runtime_ctx.logger = original_logger

        # Store result in context for next step
        context.dataset = {
            'path': result.path,
            'format': result.format,
            'is_categorized': result.is_categorized,
            'count': result.count,
        }

        return StepResult(
            success=True,
            data={
                'path': str(result.path),
                'count': result.count,
            },
        )


__all__ = ['ExportDatasetStep', '_ScopedLoggerProxy']
