"""Synology Drive storage provider."""

from __future__ import annotations

import json
import logging
import ssl
import threading
import time
from collections.abc import Generator
from io import BytesIO, StringIO
from pathlib import Path, PurePosixPath
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.ssl_ import create_urllib3_context

from synapse_sdk.utils.storage.config import SynologyStorageConfig
from synapse_sdk.utils.storage.errors import (
    StorageConnectionError,
    StorageError,
    StorageNotFoundError,
    StorageUploadError,
)

logger = logging.getLogger(__name__)

ZONE_MYDRIVE = 'mydrive'
ZONE_TEAM_FOLDER = 'team-folder'

# Synology API error codes that are transient and safe to retry
RETRYABLE_API_ERROR_CODES: frozenset[int] = frozenset({1022})


class _Http11Adapter(HTTPAdapter):
    """Disable HTTP/2 to prevent stream reset issues with Synology NAS."""

    def init_poolmanager(self, *args, **kwargs):
        try:
            from urllib3 import HttpVersion

            kwargs['disabled_svn'] = {HttpVersion.h2, HttpVersion.h3}
        except (ImportError, AttributeError):
            pass
        ctx = create_urllib3_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.set_alpn_protocols(['http/1.1'])
        kwargs['ssl_context'] = ctx
        super().init_poolmanager(*args, **kwargs)


class SynologyApiError(Exception):
    """Exception raised when a Synology Drive API call fails."""

    def __init__(self, api: str, method: str, error_code: int, error_info: Any = None):
        self.api = api
        self.method = method
        self.error_code = error_code
        self.error_info = error_info
        super().__init__(f'{api}.{method} failed: error_code={error_code}, info={error_info}')


class SynologyStorage:
    """Storage provider for Synology Drive via REST API.

    Supports both personal drive (mydrive) and team folders (team-folder).
    The zone is determined by the path prefix:

      - ``/mydrive/...`` → personal drive
      - ``/team-folder/<name>/...`` → team folder

    Internally, the Synology Drive API uses ``id:<file_id>`` path format.
    Zone-specific root folder IDs are resolved and cached on first access.

    Args:
        config: Configuration dict with Synology Drive credentials.

    Example:
        >>> storage = SynologyStorage({
        ...     'url': 'https://nas.example.com:5001',
        ...     'username': 'admin',
        ...     'password': 'secret',
        ...     'base_path': '/team-folder/projects',
        ... })
        >>> storage.upload(Path('local.txt'), 'remote/file.txt')
        'synology://nas.example.com:5001/team-folder/projects/remote/file.txt'

        >>> storage = SynologyStorage({
        ...     'url': 'https://nas.example.com:5001',
        ...     'username': 'admin',
        ...     'password': 'secret',
        ...     'base_path': '/mydrive',
        ... })
        >>> storage.upload(Path('local.txt'), 'docs/file.txt')
        'synology://nas.example.com:5001/mydrive/docs/file.txt'
    """

    def __init__(self, config: dict[str, Any]):
        validated = SynologyStorageConfig.model_validate(config)

        self._base_url = validated.url.rstrip('/')
        self._username = validated.username
        self._password = validated.password
        self._otp_code = validated.otp_code
        self._verify_ssl = validated.verify_ssl

        raw = validated.base_path.strip('/')
        self._base_path = f'/{raw}' if raw else ''

        self._sid: str | None = None
        self._sid_lock = threading.Lock()
        self._root_ids: dict[str, str] = {}  # cache_key -> file_id
        self._root_ids_lock = threading.Lock()
        self._session = self._create_session()

    @staticmethod
    def _create_session() -> requests.Session:
        session = requests.Session()
        session.mount('https://', _Http11Adapter())
        return session

    # ── Session management ────────────────────────────────

    def _login(self) -> str:
        """Log in via Synology API Auth and acquire SID."""
        params: dict[str, Any] = {
            'api': 'SYNO.API.Auth',
            'version': 6,
            'method': 'login',
            'account': self._username,
            'passwd': self._password,
            'session': 'synologyDrive',
            'format': 'sid',
        }
        if self._otp_code:
            params['otp_code'] = self._otp_code

        try:
            resp = requests.post(
                f'{self._base_url}/webapi/auth.cgi',
                data=params,
                verify=self._verify_ssl,
                timeout=15,
            )
            data = resp.json()
        except Exception as e:
            raise StorageConnectionError(
                f'Failed to connect to Synology NAS: {e}',
                details={'url': self._base_url},
            ) from e

        if not data.get('success'):
            error_code = data.get('error', {}).get('code')
            raise StorageConnectionError(
                f'Synology login failed: error_code={error_code}',
                details={'url': self._base_url, 'error_code': error_code},
            )
        return data['data']['sid']

    def _get_sid(self) -> str:
        """Return current SID, logging in if needed."""
        if self._sid is None:
            with self._sid_lock:
                if self._sid is None:
                    self._sid = self._login()
        return self._sid

    def _invalidate_sid(self) -> None:
        """Invalidate SID to force re-login on next request."""
        with self._sid_lock:
            self._sid = None

    # ── Path utils ────────────────────────────────────────

    def _full_path(self, name: str = '') -> str:
        """Combine base_path and name into a full zone-prefixed path.

        If *name* already starts with a zone prefix (``mydrive`` or
        ``team-folder``), it is treated as an absolute path and
        ``base_path`` is **not** prepended.  This prevents accidental
        double-prefixing when callers pass zone-qualified paths.

        Returns:
            Full path like ``/mydrive/...`` or ``/team-folder/<name>/...``.
        """
        stripped = name.strip('/')
        if stripped:
            first_segment = stripped.split('/')[0]
            if first_segment in (ZONE_MYDRIVE, ZONE_TEAM_FOLDER):
                return f'/{stripped}'
        parts = [p for p in [self._base_path.strip('/'), stripped] if p]
        return '/' + '/'.join(parts) if parts else '/'

    @staticmethod
    def _classify_path(full_path: str) -> str:
        """Determine whether the path targets mydrive or team-folder."""
        first = full_path.strip('/').split('/')[0]
        if first == ZONE_MYDRIVE:
            return ZONE_MYDRIVE
        if first == ZONE_TEAM_FOLDER:
            return ZONE_TEAM_FOLDER
        raise ValueError(f'Path must start with /mydrive or /team-folder: {full_path}')

    def _is_virtual_path(self, name: str = '') -> bool:
        """Check if the resolved path is virtual (root or team-folder zone)."""
        full = self._full_path(name)
        return full == '/' or full.strip('/') == ZONE_TEAM_FOLDER

    # ── Root folder ID resolution ─────────────────────────

    def _get_root_id(self, cache_key: str, resolver: Any) -> str:
        """Look up or resolve and cache a root folder ID."""
        if cache_key not in self._root_ids:
            with self._root_ids_lock:
                if cache_key not in self._root_ids:
                    self._root_ids[cache_key] = resolver()
        return self._root_ids[cache_key]

    def _resolve_mydrive_id(self) -> str:
        """Resolve the personal drive root file_id."""
        result = self._call_api(
            'GET',
            'SYNO.SynologyDrive.Files',
            'get',
            2,
            params={'path': '/mydrive'},
        )
        return str(result['data']['file_id'])

    def _resolve_team_folder_id(self, team_folder_name: str) -> str:
        """Resolve team folder name to file_id via TeamFolders API."""
        result = self._call_api(
            'GET',
            'SYNO.SynologyDrive.TeamFolders',
            'list',
            1,
        )
        for item in result.get('data', {}).get('items', []):
            if item.get('name') == team_folder_name:
                return str(item['file_id'])
        raise SynologyApiError(
            'SYNO.SynologyDrive.TeamFolders',
            'list',
            -1,
            f'Team folder not found: {team_folder_name}',
        )

    def _resolve_path(self, full_path: str) -> tuple[str, str]:
        """Decompose full_path into (root_id, remaining_subpath).

        Example:
            /mydrive/folder/file.txt → (mydrive_root_id, 'folder/file.txt')
            /team-folder/tf1/sub/file.txt → (tf1_root_id, 'sub/file.txt')
        """
        parts = full_path.strip('/').split('/')
        zone = parts[0]

        if zone == ZONE_MYDRIVE:
            root_id = self._get_root_id(ZONE_MYDRIVE, self._resolve_mydrive_id)
            remaining = '/'.join(parts[1:])
            return root_id, remaining

        if zone == ZONE_TEAM_FOLDER and len(parts) >= 2:
            tf_name = parts[1]
            cache_key = f'{ZONE_TEAM_FOLDER}/{tf_name}'
            root_id = self._get_root_id(
                cache_key,
                lambda name=tf_name: self._resolve_team_folder_id(name),
            )
            remaining = '/'.join(parts[2:])
            return root_id, remaining

        raise ValueError(f'Path must be /mydrive/... or /team-folder/<name>/...: {full_path}')

    # ── API call ──────────────────────────────────────────

    def _call_api(
        self,
        method: str,
        api: str,
        api_method: str,
        api_version: int,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        stream: bool = False,
    ) -> Any:
        """Call Synology API with automatic session retry and connection retry."""
        max_retries = 3
        for attempt in range(max_retries):
            sid = self._get_sid()
            api_params = {
                'api': api,
                'version': api_version,
                'method': api_method,
            }

            kwargs: dict[str, Any] = {
                'verify': self._verify_ssl,
                'timeout': 60,
            }

            if method == 'GET':
                kwargs['params'] = {**api_params, '_sid': sid, **(params or {})}
            else:
                # POST: _sid goes in URL query, rest in form data
                kwargs['params'] = {'_sid': sid}
                kwargs['data'] = {**api_params, **(data or {})}

            if files:
                kwargs['files'] = files
            if stream:
                kwargs['stream'] = True

            url = f'{self._base_url}/webapi/entry.cgi'
            try:
                resp = self._session.request(method, url, **kwargs)
            except requests.ConnectionError:
                if attempt < max_retries - 1:
                    logger.warning(
                        'Synology connection reset, retrying (%d/%d): %s.%s',
                        attempt + 1,
                        max_retries,
                        api,
                        api_method,
                    )
                    self._session.close()
                    self._session = self._create_session()
                    time.sleep(1)
                    continue
                raise

            if stream:
                content_type = resp.headers.get('Content-Type', '')
                if 'application/json' not in content_type:
                    resp.raise_for_status()
                    return resp

            result = resp.json()
            if result.get('success'):
                return result

            error_code = result.get('error', {}).get('code')
            # 119: SID missing or session expired
            # 105: permission denied by anonymous (SID invalidated/unrecognized)
            if error_code in (119, 105) and attempt == 0:
                self._invalidate_sid()
                self._root_ids.clear()
                continue

            # Transient API errors (e.g. 1022: file operation stopped)
            if error_code in RETRYABLE_API_ERROR_CODES and attempt < max_retries - 1:
                delay = min(1 * (2**attempt), 8)
                logger.warning(
                    'Synology API error %d (retryable), retrying in %.1fs (%d/%d): %s.%s',
                    error_code,
                    delay,
                    attempt + 1,
                    max_retries,
                    api,
                    api_method,
                )
                time.sleep(delay)
                continue

            raise SynologyApiError(api, api_method, error_code, result.get('error'))

    def _id_path(self, name: str = '') -> str:
        """Convert name to ``id:<root_id>/remaining`` format."""
        full = self._full_path(name)
        root_id, remaining = self._resolve_path(full)
        if remaining:
            return f'id:{root_id}/{remaining}'
        return f'id:{root_id}'

    def _display_path(self, name: str = '') -> str:
        """Return the full zone-prefixed display path."""
        return self._full_path(name)

    # ── StorageProtocol implementation ────────────────────

    def upload(self, source: Path, target: str) -> str:
        """Upload a file to Synology Drive.

        Args:
            source: Local file path to upload.
            target: Target path on Synology Drive.

        Returns:
            synology:// URL of uploaded file.
        """
        source_path = Path(source) if isinstance(source, str) else source

        if not source_path.exists():
            raise StorageNotFoundError(
                f'Source file not found: {source_path}',
                details={'source': str(source_path)},
            )

        id_path = self._id_path(target)
        filename = target.rsplit('/', 1)[-1] if '/' in target else target

        try:
            with open(source_path, 'rb') as f:
                self._call_api(
                    'POST',
                    'SYNO.SynologyDrive.Files',
                    'upload',
                    2,
                    data={
                        'path': id_path,
                        'create_parents': 'true',
                        'overwrite': 'true',
                        'type': 'file',
                    },
                    files={'file': (filename, f.read())},
                )
        except SynologyApiError as e:
            raise StorageUploadError(
                f'Failed to upload to Synology Drive: {e}',
                details={'source': str(source_path), 'target': id_path},
            ) from e

        return self.get_url(target)

    def _filestation_path(self, name: str = '') -> str:
        """Convert relative name to FileStation absolute path.

        - mydrive → ``/homes/<username>/...``
        - team-folder/<name> → ``/<name>/...``
        """
        full = self._full_path(name)
        parts = full.strip('/').split('/')
        zone = parts[0]

        if zone == ZONE_MYDRIVE:
            rest = '/'.join(parts[1:])
            base = f'/homes/{self._username}'
            return f'{base}/{rest}' if rest else base

        if zone == ZONE_TEAM_FOLDER and len(parts) >= 2:
            team_folder_name = parts[1]
            rest = '/'.join(parts[2:])
            return f'/{team_folder_name}/{rest}' if rest else f'/{team_folder_name}'

        raise ValueError(f'Cannot convert to FileStation path: {full}')

    def download(self, name: str) -> bytes | None:
        """Download file content as bytes.

        Tries Drive API first (two-step: metadata lookup for file_id,
        then download by file_id), falls back to FileStation on failure.

        Args:
            name: File path relative to base_path.

        Returns:
            File content as bytes, or None on failure.
        """
        if self._is_virtual_path(name):
            return None

        content = self._download_via_drive_api(name)
        if content is not None:
            return content
        return self._download_via_filestation(name)

    def _download_via_filestation(self, name: str) -> bytes | None:
        """Download via FileStation Download API."""
        fs_path = self._filestation_path(name)
        sid = self._get_sid()
        try:
            resp = self._session.get(
                f'{self._base_url}/webapi/entry.cgi',
                params={
                    'api': 'SYNO.FileStation.Download',
                    'version': 2,
                    'method': 'download',
                    'path': fs_path,
                    'mode': 'download',
                    '_sid': sid,
                },
                verify=self._verify_ssl,
                timeout=60,
            )
            resp.raise_for_status()
            return resp.content
        except requests.RequestException:
            logger.exception('Failed to download via FileStation: %s', fs_path)
            return None

    def _download_via_drive_api(self, name: str) -> bytes | None:
        """Download via Synology Drive Files API (two-step)."""
        id_path = self._id_path(name)
        sid = self._get_sid()
        try:
            # 1) 파일 메타데이터 조회 (file_id 획득)
            resp = self._session.get(
                f'{self._base_url}/webapi/entry.cgi',
                params={
                    'api': 'SYNO.SynologyDrive.Files',
                    'version': '3',
                    'method': 'get',
                    'path': '/' + name,
                    'mode': 'download',
                    '_sid': sid,
                },
                verify=self._verify_ssl,
                timeout=60,
            )
            file_info = resp.json()
            file_id = file_info['data']['file_id']

            # 2) file_id 기반 다운로드
            resp = self._session.get(
                f'{self._base_url}/webapi/entry.cgi',
                params={
                    'api': 'SYNO.SynologyDrive.Files',
                    'version': '2',
                    'method': 'download',
                    'mode': 'download',
                    'files': f'["id:{file_id}"]',
                    'force_download': 'true',
                    'download_type': 'download',
                    '_sid': sid,
                },
                verify=self._verify_ssl,
                timeout=60,
            )
            if hasattr(resp, 'content'):
                return resp.content
            return None
        except (SynologyApiError, requests.RequestException):
            logger.exception('Failed to download via Drive API: %s', id_path)
            return None

    def exists(self, target: str) -> bool:
        """Check if file exists on Synology Drive.

        Args:
            target: Path to check.

        Returns:
            True if exists, False otherwise.
        """
        if self._is_virtual_path(target):
            return True
        id_path = self._id_path(target)
        try:
            self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            return True
        except SynologyApiError:
            return False

    def delete(self, name: str) -> None:
        """Delete a file on Synology Drive.

        Args:
            name: File path relative to base_path.
        """
        id_path = self._id_path(name)
        try:
            # 파일 메타데이터 조회 (file_id, revisions 획득)
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            file_id = result['data']['file_id']
            revisions = result['data']['revisions']

            # Drive API delete: files 파라미터(JSON 배열)와 revisions 필요
            sid = self._get_sid()
            resp = self._session.post(
                f'{self._base_url}/webapi/entry.cgi',
                params={'_sid': sid},
                data={
                    'api': 'SYNO.SynologyDrive.Files',
                    'version': 2,
                    'method': 'delete',
                    'files': json.dumps([f'id:{file_id}']),
                    'permanent': 'false',
                    'revisions': json.dumps(revisions),
                },
                verify=self._verify_ssl,
                timeout=60,
            )
            resp_data = resp.json()
            if not resp_data.get('success'):
                logger.debug('Drive delete failed for %s: %s', id_path, resp_data.get('error'))
        except SynologyApiError:
            logger.debug('Failed to delete %s, ignoring', name)

    def listdir(self, path: str = '') -> tuple[list[str], list[str]]:
        """List directory contents on Synology Drive.

        Special paths (when ``base_path`` is empty):

        - Root (``/``): returns ``mydrive`` and all team folders
          (``team-folder/<name>``) as virtual directories.
        - ``/team-folder``: returns all team folder names.

        Args:
            path: Directory path relative to base_path.

        Returns:
            Tuple of (directories, files).
        """
        full = self._full_path(path)

        if full == '/':
            return self._listdir_root()

        if full.strip('/') == ZONE_TEAM_FOLDER:
            return self._list_team_folders()

        id_path = self._id_path(path)
        try:
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'list',
                2,
                params={
                    'path': id_path,
                    'filter_type': 'all',
                    'sort_by': 'name',
                    'sort_direction': 'asc',
                    'offset': 0,
                    'limit': 5000,
                },
            )
        except SynologyApiError as e:
            if e.error_code == 404:
                raise StorageNotFoundError(
                    f'Directory not found: {path}',
                    details={'error_code': e.error_code},
                ) from e
            raise StorageError(
                f'Failed to list directory: {path}',
                details={'error_code': e.error_code, 'error_info': e.error_info},
            ) from e

        dirs: list[str] = []
        files: list[str] = []
        for item in result.get('data', {}).get('items', []):
            item_name = item.get('name', '')
            if item.get('type') in ('dir', 'folder'):
                dirs.append(item_name)
            else:
                files.append(item_name)
        return dirs, files

    def _listdir_root(self) -> tuple[list[str], list[str]]:
        """List root: ``mydrive`` + ``team-folder`` as virtual directories.

        Returns:
            ``(['mydrive', 'team-folder'], [])``.
        """
        return [ZONE_MYDRIVE, ZONE_TEAM_FOLDER], []

    def _list_team_folders(self) -> tuple[list[str], list[str]]:
        """List all available team folders.

        Returns:
            ``(['team_folder_name', ...], [])``.
        """
        dirs: list[str] = []

        try:
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.TeamFolders',
                'list',
                1,
            )
            for item in result.get('data', {}).get('items', []):
                tf_name = item.get('name', '')
                if tf_name:
                    dirs.append(tf_name)
        except SynologyApiError:
            logger.warning('Failed to list team folders')

        return dirs, []

    def size(self, name: str) -> int:
        """Get file size on Synology Drive.

        Args:
            name: File path relative to base_path.

        Returns:
            File size in bytes, 0 on failure.
        """
        if self._is_virtual_path(name):
            return 0
        id_path = self._id_path(name)
        try:
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            return result.get('data', {}).get('size', 0)
        except SynologyApiError:
            return 0

    def _get_file_info(self, path: str) -> dict[str, Any]:
        """Get file size and modification time in a single API call.

        Args:
            path: File path relative to base_path.

        Returns:
            Dict with 'size' (int) and 'mtime' (float). Defaults on failure.
        """
        if self._is_virtual_path(path):
            return {'size': 0, 'mtime': 0.0}
        id_path = self._id_path(path)
        try:
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            data = result.get('data', {})
            size = data.get('size', 0)
            # Synology Drive API may return modification time under various keys
            mtime = data.get('content_mtime')
            if mtime is None:
                mtime = data.get('modify_time', 0)
            return {'size': size, 'mtime': float(mtime)}
        except SynologyApiError:
            return {'size': 0, 'mtime': 0.0}

    def get_url(self, target: str) -> str:
        """Get synology:// URL for target.

        Args:
            target: Target path.

        Returns:
            synology:// URL string.
        """
        display = self._display_path(target)
        host = self._base_url.split('://', 1)[-1]
        return f'synology://{host}{display}'

    def get_download_url(self, target: str) -> str:
        """Get a direct download URL with current SID.

        Team folder: FileStation Download API URL.
        Personal drive: Synology Drive Files API URL.

        Args:
            target: Target path.

        Returns:
            HTTP URL for downloading the file.
        """
        full = self._full_path(target)
        zone = self._classify_path(full)
        sid = self._get_sid()

        if zone == ZONE_TEAM_FOLDER:
            fs_path = self._filestation_path(target)
            return (
                f'{self._base_url}/webapi/entry.cgi'
                f'?api=SYNO.FileStation.Download&version=2&method=download'
                f'&path={fs_path}&mode=download&_sid={sid}'
            )

        # mydrive: Drive API download URL
        id_path = self._id_path(target)
        return (
            f'{self._base_url}/webapi/entry.cgi'
            f'?api=SYNO.SynologyDrive.Files&version=2&method=download'
            f'&path={id_path}&_sid={sid}'
        )

    def _upload_content(self, name: str, content: bytes) -> None:
        """Upload raw bytes to Synology Drive (no local file needed)."""
        id_path = self._id_path(name)
        filename = name.rsplit('/', 1)[-1] if '/' in name else name
        self._call_api(
            'POST',
            'SYNO.SynologyDrive.Files',
            'upload',
            2,
            data={
                'path': id_path,
                'create_parents': 'true',
                'overwrite': 'true',
                'type': 'file',
            },
            files={'file': (filename, content)},
        )

    def _create_folder(self, name: str, exist_ok: bool = False) -> None:
        """Create a folder on Synology Drive."""
        id_path = self._id_path(name)
        try:
            self._call_api(
                'POST',
                'SYNO.SynologyDrive.Files',
                'create',
                2,
                data={
                    'path': id_path,
                    'type': 'folder',
                    'create_parents': 'true',
                },
            )
        except SynologyApiError:
            if exist_ok and self.exists(name):
                return
            raise

    def get_pathlib(self, path: str) -> SynologyPath:
        """Get SynologyPath object for path.

        Args:
            path: Path relative to base_path.

        Returns:
            SynologyPath object (pathlib-like interface).
        """
        return SynologyPath(self, path)

    def get_path_file_count(self, pathlib_obj: SynologyPath) -> int:
        """Count files recursively in the given path.

        Args:
            pathlib_obj: SynologyPath object from get_pathlib().

        Returns:
            Number of files.
        """
        return pathlib_obj._count_files()

    def get_path_total_size(self, pathlib_obj: SynologyPath) -> int:
        """Calculate total size of files recursively.

        Args:
            pathlib_obj: SynologyPath object from get_pathlib().

        Returns:
            Total size in bytes.
        """
        return pathlib_obj._total_size()


class SynologyPath:
    """Pathlib-like interface for Synology Drive paths.

    Provides a subset of pathlib.Path functionality for Synology Drive resources.
    Supports directory listing and recursive file operations via the Synology API.
    """

    def __init__(self, storage: SynologyStorage, path: str):
        self._storage = storage
        self._path = path.strip('/')

    def __str__(self) -> str:
        return self._storage.get_url(self._path)

    def __repr__(self) -> str:
        return f"SynologyPath('{self}')"

    def __fspath__(self) -> str:
        """Return the file system path representation."""
        return self._path

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SynologyPath):
            return NotImplemented
        return self._path == other._path

    def __hash__(self) -> int:
        return hash(self._path)

    def __truediv__(self, other: str) -> SynologyPath:
        """Join paths using / operator."""
        new_path = f'{self._path}/{other}' if self._path else str(other)
        return SynologyPath(self._storage, new_path)

    @property
    def parts(self) -> tuple[str, ...]:
        """Get the path components as a tuple."""
        return tuple(self._path.split('/')) if self._path else ()

    @property
    def name(self) -> str:
        """Get the final component of the path."""
        return PurePosixPath(self._path).name if self._path else ''

    @property
    def stem(self) -> str:
        """Get the final component without its suffix."""
        return PurePosixPath(self._path).stem if self._path else ''

    @property
    def suffix(self) -> str:
        """Get the file extension of the final component."""
        return PurePosixPath(self._path).suffix if self._path else ''

    @property
    def parent(self) -> SynologyPath:
        """Get the parent directory."""
        parent_path = str(PurePosixPath(self._path).parent)
        if parent_path == '.':
            parent_path = ''
        return SynologyPath(self._storage, parent_path)

    def relative_to(self, other: SynologyPath | str) -> PurePosixPath:
        """Return a relative version of this path compared to other."""
        if isinstance(other, SynologyPath):
            other_path = other._path
        else:
            other_path = str(other).strip('/')
        if not self._path.startswith(other_path):
            raise ValueError(f'{self._path!r} is not relative to {other_path!r}')
        rel = self._path[len(other_path) :].lstrip('/')
        return PurePosixPath(rel) if rel else PurePosixPath('.')

    def as_posix(self) -> str:
        """Return the string representation of the path with forward slashes."""
        return self._path

    def with_name(self, name: str) -> SynologyPath:
        """Return a new path with the file name changed."""
        p = PurePosixPath(self._path)
        new_path = str(p.with_name(name))
        return SynologyPath(self._storage, new_path)

    def with_suffix(self, suffix: str) -> SynologyPath:
        """Return a new path with the suffix changed."""
        p = PurePosixPath(self._path)
        new_path = str(p.with_suffix(suffix))
        return SynologyPath(self._storage, new_path)

    def exists(self) -> bool:
        """Check if this path exists."""
        return self._storage.exists(self._path)

    def is_file(self) -> bool:
        """Check if this path is a file."""
        if self._storage._is_virtual_path(self._path):
            return False
        return self._storage.exists(self._path)

    def is_dir(self) -> bool:
        """Check if this path is a directory."""
        if self._storage._is_virtual_path(self._path):
            return True
        id_path = self._storage._id_path(self._path)
        try:
            result = self._storage._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            return result.get('data', {}).get('type') in ('dir', 'folder')
        except SynologyApiError:
            return False

    def mkdir(self, parents: bool = False, exist_ok: bool = False) -> None:
        """Create a directory on Synology Drive.

        Args:
            parents: If True, create parent directories as needed (always true for Synology).
            exist_ok: If True, don't raise if directory already exists.
        """
        if not self._path:
            if exist_ok:
                return
            raise FileExistsError('Cannot mkdir on root path')
        self._storage._create_folder(self._path, exist_ok=exist_ok)

    def open(self, mode: str = 'r', encoding: str | None = None, **_kwargs: Any) -> _SynologyFileIO:
        """Open this path for reading or writing.

        Supports 'r', 'rb', 'w', 'wb' modes. Write modes buffer content
        in memory and upload to Synology Drive on close.

        Args:
            mode: File open mode ('r', 'rb', 'w', 'wb').
            encoding: Text encoding (default: utf-8 for text modes).

        Returns:
            A file-like context manager.
        """
        return _SynologyFileIO(self._storage, self._path, mode, encoding)

    def read_bytes(self) -> bytes:
        """Read file contents as bytes."""
        content = self._storage.download(self._path)
        if content is None:
            raise StorageNotFoundError(
                f'File not found: {self._path}',
                details={'path': self._path},
            )
        return content

    def read_text(self, encoding: str = 'utf-8') -> str:
        """Read file contents as text."""
        return self.read_bytes().decode(encoding)

    def stat(self) -> SynologyStat:
        """Get file statistics."""
        info = self._storage._get_file_info(self._path)
        return SynologyStat(st_size=info['size'], st_mtime=info['mtime'])

    def _count_files(self) -> int:
        """Count files recursively."""
        try:
            dirs, files = self._storage.listdir(self._path)
        except (StorageError, StorageNotFoundError):
            return 0
        count = len(files)
        for d in dirs:
            count += (self / d)._count_files()
        return count

    def _total_size(self) -> int:
        """Calculate total size recursively."""
        try:
            dirs, files = self._storage.listdir(self._path)
        except (StorageError, StorageNotFoundError):
            return 0
        total = sum(self._storage.size(f'{self._path}/{f}') for f in files)
        for d in dirs:
            total += (self / d)._total_size()
        return total

    def iterdir(self) -> Generator[SynologyPath, None, None]:
        """Iterate over directory contents.

        Yields:
            SynologyPath objects for each item in the directory.
        """
        dirs, files = self._storage.listdir(self._path)
        for name in dirs:
            yield self / name
        for name in files:
            yield self / name


class _SynologyFileIO:
    """Buffered file-like object for Synology Drive.

    For read modes: downloads content into memory buffer on init.
    For write modes: buffers writes and uploads to Synology Drive on close.
    """

    def __init__(self, storage: SynologyStorage, path: str, mode: str = 'r', encoding: str | None = None):
        self._storage = storage
        self._path = path
        self._mode = mode
        self._encoding = encoding or 'utf-8'
        self._closed = False

        is_binary = 'b' in mode

        if 'r' in mode:
            content = storage.download(path)
            if content is None:
                raise FileNotFoundError(f'File not found on Synology Drive: {path}')
            if is_binary:
                self._buffer: BytesIO | StringIO = BytesIO(content)
            else:
                self._buffer = StringIO(content.decode(self._encoding))
        elif 'w' in mode or 'a' in mode:
            if is_binary:
                self._buffer = BytesIO()
            else:
                self._buffer = StringIO()
        else:
            raise ValueError(f'Unsupported mode: {mode}')

    def write(self, data: str | bytes) -> int:
        return self._buffer.write(data)

    def read(self, size: int = -1) -> str | bytes:
        return self._buffer.read(size)

    def readline(self) -> str | bytes:
        return self._buffer.readline()

    def readlines(self) -> list[str | bytes]:
        return self._buffer.readlines()

    def seek(self, offset: int, whence: int = 0) -> int:
        return self._buffer.seek(offset, whence)

    def tell(self) -> int:
        return self._buffer.tell()

    def flush(self) -> None:
        pass

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        if 'w' in self._mode or 'a' in self._mode:
            if isinstance(self._buffer, BytesIO):
                content = self._buffer.getvalue()
            else:
                content = self._buffer.getvalue().encode(self._encoding)
            self._storage._upload_content(self._path, content)

    def __iter__(self) -> _SynologyFileIO:
        return self

    def __next__(self) -> str | bytes:
        line = self.readline()
        if not line:
            raise StopIteration
        return line

    def readable(self) -> bool:
        if self._closed:
            raise ValueError('I/O operation on closed file')
        return 'r' in self._mode

    def writable(self) -> bool:
        if self._closed:
            raise ValueError('I/O operation on closed file')
        return 'w' in self._mode or 'a' in self._mode

    def seekable(self) -> bool:
        if self._closed:
            raise ValueError('I/O operation on closed file')
        return True

    def __enter__(self) -> _SynologyFileIO:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class SynologyStat:
    """Minimal stat result for Synology Drive files."""

    def __init__(self, st_size: int = 0, st_mtime: float = 0.0):
        self.st_size = st_size
        self.st_mtime = st_mtime


__all__ = ['SynologyStorage', 'SynologyPath', 'SynologyApiError', 'ZONE_MYDRIVE', 'ZONE_TEAM_FOLDER']
