WORKFLOW_EXAMPLE_HELLO_WORLD = "example-hello-world-workflow"
WORKFLOW_EXAMPLE_INTERACTIVE_GAME = "example-interactive-game-workflow"
WORKFLOW_SIMPLE_CHATBOT = "simple-chatbot-workflow"
