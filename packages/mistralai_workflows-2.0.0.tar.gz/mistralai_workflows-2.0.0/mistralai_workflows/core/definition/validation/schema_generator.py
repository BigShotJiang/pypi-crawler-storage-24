import dataclasses
import inspect
from types import NoneType, UnionType
from typing import Any, Callable, Dict, Literal, Type, Union, get_args, get_origin

from pydantic import BaseModel, ConfigDict, Field, create_model


def _transform_type(annotation: Any, processing: set[type]) -> Any:
    origin = get_origin(annotation)
    if origin is not None:
        return _recurse_into_generic(annotation, processing)

    if dataclasses.is_dataclass(annotation) and isinstance(annotation, type):
        return _dataclass_to_forbid_extra(annotation, processing)

    return annotation


def _recurse_into_generic(annotation: Any, processing: set[type]) -> Any:
    origin = get_origin(annotation)
    args = get_args(annotation)
    transformed_args = tuple(_transform_type(arg, processing) for arg in args)

    if origin is Union or origin is UnionType:
        return Union[transformed_args]

    try:
        return origin[transformed_args]
    except TypeError:
        return annotation


def _dataclass_to_forbid_extra(dc: type, processing: set[type]) -> Type[BaseModel]:
    if dc in processing:
        return dc

    processing.add(dc)
    try:
        fields: dict[str, Any] = {}
        for field in dataclasses.fields(dc):
            transformed = _transform_type(field.type, processing)

            if field.default is not dataclasses.MISSING:
                fields[field.name] = (transformed, Field(default=field.default))
            elif field.default_factory is not dataclasses.MISSING:
                fields[field.name] = (transformed, Field(default_factory=field.default_factory))
            else:
                fields[field.name] = (transformed, ...)

        return create_model(
            f"{dc.__name__}_ForbidExtra",
            __config__=ConfigDict(extra="forbid"),
            **fields,
        )
    finally:
        processing.discard(dc)


def generate_pydantic_model_from_params(
    func_name: str,
    user_params_dict: Dict[str, Type],
    model_suffix: str = "Input",
    func: Callable | None = None,
    allow_extra: bool = False,
) -> Type[BaseModel]:
    extra_mode: Literal["allow", "forbid"] = "allow" if allow_extra else "forbid"

    if not user_params_dict:
        model_name = f"{func_name}_{model_suffix}"
        return create_model(model_name, __config__=ConfigDict(extra=extra_mode))

    if len(user_params_dict) == 1:
        param_type = next(iter(user_params_dict.values()))
        if inspect.isclass(param_type) and issubclass(param_type, BaseModel):
            return param_type

    fields = {}
    sig = inspect.signature(func) if func else None
    processing: set[type] = set()

    for param_name, param_type in user_params_dict.items():
        transformed = _transform_type(param_type, processing)

        if sig and param_name in sig.parameters:
            param = sig.parameters[param_name]
            if param.default is not inspect.Parameter.empty:
                fields[param_name] = (transformed, Field(default=param.default))
            else:
                fields[param_name] = (transformed, ...)
        else:
            fields[param_name] = (transformed, ...)

    model_name = f"{func_name}_{model_suffix}"
    return create_model(model_name, __config__=ConfigDict(extra=extra_mode), **fields)  # type: ignore[call-overload, no-any-return]


def generate_pydantic_model_from_return_type(
    func_name: str, return_type: Type, model_suffix: str = "Output"
) -> Type[BaseModel] | None:
    if return_type is NoneType or return_type is type(None):
        return None

    if inspect.isclass(return_type) and issubclass(return_type, BaseModel):
        return return_type

    origin = get_origin(return_type)
    if origin in (Union, UnionType):
        args = get_args(return_type)
        non_none_types = [arg for arg in args if arg is not NoneType and arg is not type(None)]
        if len(non_none_types) == 1:
            actual_type = non_none_types[0]
            if inspect.isclass(actual_type) and issubclass(actual_type, BaseModel):
                return actual_type
            return_type = actual_type
        elif len(non_none_types) > 1:
            return_type = Union[tuple(non_none_types)]  # type: ignore[assignment]

    model_name = f"{func_name}_{model_suffix}"
    return create_model(model_name, result=(return_type, ...))
