from __future__ import annotations

import mistralai_workflows as workflows
from mistralai_workflows.models import WorkflowSpec
from mistralai_workflows.plugins.nuage import settings as nuage_settings
from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.workflow import workflow_models as nuage_workflow_models

from . import chat_assistant_activities, chat_assistant_hooks, chat_assistant_models

_MAX_CHAT_TITLE_LENGTH = 200


async def build_chat_assistant_integration(
    params: chat_assistant_models.ChatAssistantParams,
    workflow_params: nuage_workflow_models.NuageWorkflowParams,
    workflow_spec: WorkflowSpec,
    identity: nuage_experimental_identity.ExperimentalIdentity | None,
) -> chat_assistant_models.ChatAssistantIntegration:
    if identity is None:
        raise ValueError("ChatAssistantParams requires identity for authentication")

    workflow_version_id = await chat_assistant_activities.get_workflow_version_id(workflow_spec)
    user_message = params.user_message or workflow_params.prompt

    result = await chat_assistant_activities.create_chat_assistant_thread(
        chat_assistant_models.CreateChatAssistantThreadParams(
            workflow_version_id=str(workflow_version_id),
            identity=identity,
            user_message=user_message,
            chat_title=(user_message[: _MAX_CHAT_TITLE_LENGTH - len("...")] + "...")
            if len(user_message) > _MAX_CHAT_TITLE_LENGTH
            else user_message,
            workflow_execution_id=workflows.get_execution_id() or "",
            workflow_name=nuage_settings.settings.workflow.name,
            workflow_params=workflow_params.model_dump(),
            project_name=params.project_name,
        )
    )

    return chat_assistant_models.ChatAssistantIntegration(
        workflow_task=chat_assistant_hooks.ChatAssistantWorkflowTaskHook(),
        public_data=chat_assistant_models.ChatAssistantPublicData(chat_url=result.chat_url),
    )
