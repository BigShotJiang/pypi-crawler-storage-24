from __future__ import annotations

from abc import abstractmethod
from typing import Any

from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import polymorphic as nuage_polymorphic


class AgentExecutor(nuage_polymorphic.PolymorphicModel):
    @abstractmethod
    async def complete(self, request: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    async def invoke_tool(self, request: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    async def list_tools_http(self, request: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    async def list_tools_stdio(self, request: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    async def compute_search_paths(self, request: Any) -> Any:
        raise NotImplementedError

    @abstractmethod
    async def iter_tool_classes(self, request: Any) -> Any:
        raise NotImplementedError


class AgentExecutorHook(nuage_hook.Hook[AgentExecutor], AgentExecutor):
    async def complete(self, request: Any) -> Any:
        return await self.next.complete(request)

    async def invoke_tool(self, request: Any) -> Any:
        return await self.next.invoke_tool(request)

    async def list_tools_http(self, request: Any) -> Any:
        return await self.next.list_tools_http(request)

    async def list_tools_stdio(self, request: Any) -> Any:
        return await self.next.list_tools_stdio(request)

    async def compute_search_paths(self, request: Any) -> Any:
        return await self.next.compute_search_paths(request)

    async def iter_tool_classes(self, request: Any) -> Any:
        return await self.next.iter_tool_classes(request)
