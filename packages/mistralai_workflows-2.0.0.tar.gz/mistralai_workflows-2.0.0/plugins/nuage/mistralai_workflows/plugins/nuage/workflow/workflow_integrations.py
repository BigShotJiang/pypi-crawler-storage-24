from __future__ import annotations

import asyncio
from functools import partial
from typing import Any, Callable, Coroutine

import structlog

import mistralai_workflows as workflows
from mistralai_workflows.models import WorkflowSpec
from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base
from mistralai_workflows.plugins.nuage.integrations.chat_assistant import (
    chat_assistant as nuage_chat_assistant,
)
from mistralai_workflows.plugins.nuage.integrations.github import github as nuage_github
from mistralai_workflows.plugins.nuage.integrations.integrations_base import IntegrationHooks
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox

from . import workflow_models

logger = structlog.get_logger(__name__)

OnReadyCallback = Callable[[nuage_integrations_base.IntegrationId, nuage_integrations_base.BaseIntegration[Any]], None]

MERGE_ORDER: list[nuage_integrations_base.IntegrationId] = [
    nuage_integrations_base.IntegrationId.GITHUB,
    nuage_integrations_base.IntegrationId.CHAT_ASSISTANT,
]

_missing = set(nuage_integrations_base.IntegrationId) - set(MERGE_ORDER)
if _missing:
    raise RuntimeError(f"MERGE_ORDER is missing integration(s): {', '.join(m.value for m in _missing)}")


async def build_integrations(
    params: workflow_models.NuageWorkflowParams,
    sandbox: nuage_sandbox.Sandbox,
    workflow_spec: WorkflowSpec,
    identity: nuage_experimental_identity.ExperimentalIdentity | None,
    on_ready: OnReadyCallback | None = None,
) -> IntegrationHooks:
    workflow_id = workflows.get_execution_id()
    results: dict[nuage_integrations_base.IntegrationId, nuage_integrations_base.BaseIntegration[Any]] = {}

    logger.info("Building integrations", identity=identity)

    def _on_ready_for(
        integration_id: nuage_integrations_base.IntegrationId,
        integration: nuage_integrations_base.BaseIntegration[Any],
    ) -> None:
        results[integration_id] = integration
        if on_ready:
            on_ready(integration_id, integration)

    async def collect(
        integration_id: nuage_integrations_base.IntegrationId,
        coro: Coroutine[Any, Any, nuage_integrations_base.BaseIntegration[Any]],
    ) -> None:
        integration = await coro
        _on_ready_for(integration_id, integration)

    async with asyncio.TaskGroup() as tg:
        if params.integrations.github:
            tg.create_task(
                collect(
                    nuage_integrations_base.IntegrationId.GITHUB,
                    nuage_github.build_github_integration(
                        params.integrations.github,
                        sandbox,
                        identity,
                        workflow_id,
                        on_ready=partial(_on_ready_for, nuage_integrations_base.IntegrationId.GITHUB),
                    ),
                )
            )

        if params.integrations.chat_assistant:
            tg.create_task(
                collect(
                    nuage_integrations_base.IntegrationId.CHAT_ASSISTANT,
                    nuage_chat_assistant.build_chat_assistant_integration(
                        params.integrations.chat_assistant, params, workflow_spec, identity
                    ),
                )
            )

    ordered = [results[k] for k in MERGE_ORDER if k in results]
    return nuage_integrations_base.merge_hooks(*ordered)
