from __future__ import annotations

from datetime import timedelta
from typing import Awaitable, Callable, overload

import temporalio.workflow


class PollTimeout(Exception):
    pass


async def poll_until[T](
    fetch: Callable[[], Awaitable[T | None]],
    timeout_seconds: float,
    interval_seconds: float,
) -> T:
    deadline = temporalio.workflow.time() + timeout_seconds
    while temporalio.workflow.time() < deadline:
        result = await fetch()
        if result is not None:
            return result
        remaining = deadline - temporalio.workflow.time()
        if remaining <= 0:
            break
        await temporalio.workflow.sleep(timedelta(seconds=interval_seconds))
    raise PollTimeout()


@overload
def ensure[T](value: T | None) -> T: ...


@overload
def ensure[T](value: T | None, error: Exception) -> T: ...


def ensure[T](value: T | None, error: Exception | None = None) -> T:
    if value is None:
        raise error if error is not None else RuntimeError("Value is required but was None")
    return value


def unwrap_exception_group(exc: BaseException) -> str:
    """Extract meaningful error messages from ExceptionGroup."""
    if isinstance(exc, BaseExceptionGroup):
        messages = [unwrap_exception_group(e) for e in exc.exceptions]
        return "; ".join(messages)
    return str(exc)
