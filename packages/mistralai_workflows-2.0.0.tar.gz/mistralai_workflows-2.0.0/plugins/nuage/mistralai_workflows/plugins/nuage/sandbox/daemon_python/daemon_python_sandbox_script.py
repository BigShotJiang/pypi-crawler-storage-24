#!/usr/bin/env python3
"""Python daemon server for executing code via file-based IPC.

This script runs inside the sandbox and watches for code execution requests.
It monitors a request directory for new .json files, executes the code,
and writes results to a response directory.

Protocol:
- Client writes request to /tmp/daemon_req/{uuid}.json
- Daemon detects file, reads and deletes it
- Daemon executes code
- Daemon writes response to /tmp/daemon_resp/{uuid}.json
- Client reads and deletes response

Request format:
- Exec: {"type": "exec", "code": str, "cwd": str|None, "env": dict[str, str]|None, "timeout_s": int|None}
- Ping: {"type": "ping"}
Response format: {"ok": bool, "result": any, "stdout": str, "stderr": str, "error": dict|None}
"""

from __future__ import annotations

import io
import json
import os
import re
import signal
import sys
import time
import traceback
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from pathlib import Path
from typing import Any, Iterator

DAEMON_BASE_DIR = os.environ.get("DAEMON_BASE_DIR", "/tmp")
DAEMON_SCRIPT_FILENAME = "_daemon.py"
DAEMON_LOG_FILENAME = "_daemon_python.log"
DAEMON_DEBUG_LOG_FILENAME = "_daemon_python_debug.log"
DAEMON_READY_FILENAME = "_daemon_ready"
DAEMON_REQUEST_DIRNAME = "daemon_req"
DAEMON_RESPONSE_DIRNAME = "daemon_resp"
DAEMON_DEBUG_PATH = f"{DAEMON_BASE_DIR}/{DAEMON_DEBUG_LOG_FILENAME}"
DAEMON_READY_FILE = f"{DAEMON_BASE_DIR}/{DAEMON_READY_FILENAME}"
DAEMON_REQUEST_DIR = f"{DAEMON_BASE_DIR}/{DAEMON_REQUEST_DIRNAME}"
DAEMON_RESPONSE_DIR = f"{DAEMON_BASE_DIR}/{DAEMON_RESPONSE_DIRNAME}"
DAEMON_DEFAULT_TIMEOUT = 300
DAEMON_MAX_TIMEOUT = 1800
DAEMON_POLL_INTERVAL = 0.01
DAEMON_RESULT_VAR = "__result__"
DAEMON_MAX_DEBUG_ENTRIES = 100
DAEMON_MAX_OUTPUT_CHARS = 1_000_000
DAEMON_RESPONSE_TTL_SECONDS = 3600

ENV_KEY_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

REQUEST_DIR = Path(DAEMON_REQUEST_DIR)
RESPONSE_DIR = Path(DAEMON_RESPONSE_DIR)
DEBUG_LOG = Path(DAEMON_DEBUG_PATH)
READY_FILE = Path(DAEMON_READY_FILE)

# INTENTIONAL: Shared namespace across all exec() calls to persist imports and state.
# This dramatically reduces latency (~6s import overhead) by keeping modules loaded.
# Side effects from executions persist, which is expected for tool invocations.
NS: dict = {"__name__": "__main__"}


def debug(msg: str, **kw: object) -> None:
    entry = {"ts": time.time(), "msg": msg, **kw}
    try:
        with open(DEBUG_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
        lines = DEBUG_LOG.read_text().splitlines()
        if len(lines) > DAEMON_MAX_DEBUG_ENTRIES:
            DEBUG_LOG.write_text("\n".join(lines[-DAEMON_MAX_DEBUG_ENTRIES:]) + "\n")
    except Exception as e:
        print(f"[daemon] debug log error: {e}", file=sys.stderr)  # noqa: T201


class ExecutionTimeoutError(TimeoutError):
    """Raised when a daemon execution exceeds its per-request timeout."""


def _validate_timeout(timeout_s: object | None) -> int:
    if timeout_s is None:
        return DAEMON_DEFAULT_TIMEOUT
    if isinstance(timeout_s, bool) or not isinstance(timeout_s, int):
        raise ValueError("timeout_s must be an integer")
    if timeout_s <= 0:
        raise ValueError("timeout_s must be > 0")
    return min(timeout_s, DAEMON_MAX_TIMEOUT)


def _validate_env(env: Any) -> dict[str, str]:
    if env is None:
        return {}
    if not isinstance(env, dict):
        raise ValueError("env must be a JSON object")

    validated: dict[str, str] = {}
    for key, value in env.items():
        if not isinstance(key, str) or not ENV_KEY_PATTERN.fullmatch(key):
            raise ValueError(f"invalid env key: {key!r}")
        if not isinstance(value, str):
            raise ValueError(f"env value for {key!r} must be a string")
        validated[key] = value
    return validated


def _truncate_output(text: str) -> str:
    if len(text) <= DAEMON_MAX_OUTPUT_CHARS:
        return text
    truncated = len(text) - DAEMON_MAX_OUTPUT_CHARS
    return f"{text[:DAEMON_MAX_OUTPUT_CHARS]}\n...[truncated {truncated} chars]"


@contextmanager
def _temporary_cwd(cwd: str | None) -> Iterator[None]:
    if cwd is None:
        yield
        return

    old_cwd = os.getcwd()
    os.chdir(cwd)
    try:
        yield
    finally:
        os.chdir(old_cwd)


@contextmanager
def _temporary_env(env: dict[str, str]) -> Iterator[None]:
    if not env:
        yield
        return

    original = {key: os.environ.get(key) for key in env}
    os.environ.update(env)
    try:
        yield
    finally:
        for key, previous in original.items():
            if previous is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = previous


@contextmanager
def _execution_timeout(timeout_s: int) -> Iterator[None]:
    if timeout_s <= 0:
        yield
        return

    def _raise_timeout(_signum: int, _frame: Any) -> None:
        raise ExecutionTimeoutError(f"Execution timed out after {timeout_s}s")

    previous_handler = signal.getsignal(signal.SIGALRM)
    signal.signal(signal.SIGALRM, _raise_timeout)
    signal.setitimer(signal.ITIMER_REAL, float(timeout_s))
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


def execute_code(code: str, cwd: str | None, env: dict[str, str], timeout_s: int) -> dict:
    stdout, stderr = io.StringIO(), io.StringIO()
    result, error = None, None
    NS.setdefault("__builtins__", __builtins__)
    try:
        with _temporary_cwd(cwd), _temporary_env(env), _execution_timeout(timeout_s):
            with redirect_stdout(stdout), redirect_stderr(stderr):
                exec(code, NS, NS)
                result = NS.pop(DAEMON_RESULT_VAR, None)
    except Exception as e:
        error = {
            "type": type(e).__module__ + "." + type(e).__name__,
            "message": str(e),
            "traceback": traceback.format_exc(),
        }
    return {
        "ok": error is None,
        "result": result,
        "stdout": _truncate_output(stdout.getvalue()),
        "stderr": _truncate_output(stderr.getvalue()),
        "error": error,
    }


def _write_response(req_id: str, response: dict[str, Any]) -> None:
    resp_path = RESPONSE_DIR / f"{req_id}.json"
    tmp_path = RESPONSE_DIR / f"{req_id}.tmp"
    tmp_path.write_text(json.dumps(response))
    tmp_path.rename(resp_path)


def _handle_request(req_id: str, request: dict[str, Any]) -> dict[str, Any]:
    request_type = request.get("type", "exec")
    if request_type == "ping":
        return {"ok": True, "result": {"pong": True, "pid": os.getpid()}, "stdout": "", "stderr": "", "error": None}

    if request_type != "exec":
        raise ValueError(f"Unsupported request type: {request_type!r}")

    code = request.get("code", "")
    if not isinstance(code, str):
        raise ValueError("code must be a string")

    cwd = request.get("cwd")
    if cwd is not None and not isinstance(cwd, str):
        raise ValueError("cwd must be a string or null")

    timeout_s = _validate_timeout(request.get("timeout_s", DAEMON_DEFAULT_TIMEOUT))
    env = _validate_env(request.get("env"))
    debug("executing", req_id=req_id, code_len=len(code), cwd=cwd, env_keys=sorted(env), timeout_s=timeout_s)
    return execute_code(code, cwd=cwd, env=env, timeout_s=timeout_s)


def process_request(req_path: Path) -> None:
    req_id = req_path.stem
    debug("processing", req_id=req_id)
    try:
        request = json.loads(req_path.read_text())
        if not isinstance(request, dict):
            raise ValueError("request payload must be a JSON object")
        response = _handle_request(req_id, request)
        debug("executed", req_id=req_id, ok=response["ok"])
        _write_response(req_id, response)
        debug("response_written", req_id=req_id)
        req_path.unlink(missing_ok=True)
    except Exception as e:
        debug("process_error", req_id=req_id, error=str(e), tb=traceback.format_exc())
        try:
            error_resp = {
                "ok": False,
                "result": None,
                "stdout": "",
                "stderr": "",
                "error": {"type": "DaemonError", "message": str(e), "traceback": traceback.format_exc()},
            }
            _write_response(req_id, error_resp)
            req_path.unlink(missing_ok=True)
        except Exception as recovery_err:
            debug("recovery_error", req_id=req_id, error=str(recovery_err))


def _cleanup_startup_files() -> None:
    now = time.time()
    for pattern in ("*.tmp",):
        for path in REQUEST_DIR.glob(pattern):
            path.unlink(missing_ok=True)
        for path in RESPONSE_DIR.glob(pattern):
            path.unlink(missing_ok=True)

    for old in REQUEST_DIR.glob("*.json"):
        old.unlink(missing_ok=True)

    for old in RESPONSE_DIR.glob("*.json"):
        if (now - old.stat().st_mtime) > DAEMON_RESPONSE_TTL_SECONDS:
            old.unlink(missing_ok=True)


def main() -> None:
    debug("starting")
    REQUEST_DIR.mkdir(parents=True, exist_ok=True)
    RESPONSE_DIR.mkdir(parents=True, exist_ok=True)
    _cleanup_startup_files()
    READY_FILE.write_text(str(os.getpid()))
    print(f"daemon ready, watching {REQUEST_DIR}", file=sys.stderr, flush=True)  # noqa: T201
    debug("listening")

    while True:
        try:
            requests = sorted(REQUEST_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime)
            for req_path in requests:
                process_request(req_path)
            time.sleep(DAEMON_POLL_INTERVAL)
        except KeyboardInterrupt:
            debug("shutdown")
            break
        except Exception as e:
            debug("loop_error", error=str(e))
            time.sleep(DAEMON_POLL_INTERVAL)


if __name__ == "__main__":
    main()
