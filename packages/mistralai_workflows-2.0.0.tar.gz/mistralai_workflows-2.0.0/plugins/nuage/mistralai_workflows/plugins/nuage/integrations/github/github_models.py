from __future__ import annotations

import enum
import re
from pathlib import Path
from typing import ClassVar

from pydantic import BaseModel, Field

from mistralai_workflows.models import EncryptedStrField
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base


class GitHubStatus(str, enum.Enum):
    CONNECTED = "connected"
    WAITING_FOR_OAUTH = "waiting_for_oauth"
    OAUTH_TIMEOUT = "oauth_timeout"
    ERROR = "error"


class GitHubParams(nuage_integrations_base.BaseIntegrationParams):
    requires_secrets: ClassVar[bool] = False

    url: str = Field(description="Repository URL")
    branch: str | None = Field(default=None, description="Branch to clone")
    commit: str | None = Field(default=None, description="Commit SHA to checkout")
    teleported_diffs: bytes | None = Field(default=None, description="Git diffs to apply after clone")


class GitHubConfig(GitHubParams):
    working_branch: str | None = Field(default=None, description="Branch to create after clone")
    github_token: EncryptedStrField | None = Field(default=None, description="Encrypted GitHub token")

    def get_repo_name(self) -> str:
        url = self.url.rstrip("/")
        if url.endswith(".git"):
            url = url[:-4]
        match = re.search(r"/([^/]+?)(?:\.git)?/?$", url)
        return match.group(1) if match else Path(url).name


class GitHubPublicData(BaseModel):
    status: GitHubStatus = Field(description="Current GitHub connection status")
    oauth_url: str | None = Field(default=None, description="OAuth URL when waiting for authorization")
    error: str | None = Field(default=None, description="Error message if status is error/timeout")
    working_branch: str = Field(description="Working branch created for this session")
    repo_url: str = Field(description="Repository URL")


class GitHubIntegration(nuage_integrations_base.BaseIntegration[GitHubPublicData]):
    pass


class GitHubPRInfo(BaseModel):
    baseRefName: str = Field(alias="baseRefName")
    headRefName: str = Field(alias="headRefName")


class GitHubValidationState(BaseModel):
    branch: str = Field(default="")
    dirty: int = Field(default=0)
    remote_exists: bool = Field(default=False)
    unpushed: int = Field(default=0)
    pr: list[GitHubPRInfo] = Field(default_factory=list)
