from __future__ import annotations

from abc import abstractmethod
from typing import TYPE_CHECKING

import mistralai

from mistralai_workflows.plugins.mistralai.agent import Agent
from mistralai_workflows.plugins.mistralai.session.session import FinalOutputs as AgentFinalOutputs
from mistralai_workflows.plugins.mistralai.session.session import Inputs as AgentInputs
from mistralai_workflows.plugins.mistralai.session.session import Outputs as AgentOutputs
from mistralai_workflows.plugins.mistralai.session.session import Session as AgentSession
from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import polymorphic as nuage_polymorphic
from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox

if TYPE_CHECKING:
    from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
    from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base


class Session(nuage_polymorphic.PolymorphicModel, AgentSession):
    @classmethod
    def default_hooks(cls) -> nuage_integrations_base.IntegrationHooks | None:
        return None

    @staticmethod
    @abstractmethod
    async def create(
        uncreated_session: Session,
        sandbox: nuage_sandbox.Sandbox,
        workflow_task: nuage_agent_task.WorkflowTask,
        agent_executor_hook: nuage_agent_executor.AgentExecutorHook | None = None,
    ) -> Session:
        raise NotImplementedError


class SessionHook(nuage_hook.Hook[Session], Session):
    @staticmethod
    async def create(
        uncreated_session: Session,
        sandbox: nuage_sandbox.Sandbox,
        workflow_task: nuage_agent_task.WorkflowTask,
        agent_executor_hook: nuage_agent_executor.AgentExecutorHook | None = None,
    ) -> Session:
        raise NotImplementedError

    async def initialize_conversation(self, agent: Agent, inputs: AgentInputs) -> AgentOutputs:
        return await self.next.initialize_conversation(agent, inputs)

    async def append_messages(self, inputs: list[str | mistralai.ContentChunk]) -> list[str]:
        return await self.next.append_messages(inputs)

    async def process_output(self, output: str) -> list[str]:
        return await self.next.process_output(output)

    def format_final_outputs(self, outputs: list[str]) -> AgentFinalOutputs:
        return self.next.format_final_outputs(outputs)

    def is_conversation_active(self) -> bool:
        return self.next.is_conversation_active()

    async def close_conversation(self) -> None:
        await self.next.close_conversation()
