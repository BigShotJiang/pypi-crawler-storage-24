from __future__ import annotations

import base64
import urllib.parse
from typing import Iterable

from detect_secrets.plugins.aws import AWSKeyDetector
from detect_secrets.plugins.basic_auth import BasicAuthDetector
from detect_secrets.plugins.high_entropy_strings import Base64HighEntropyString, HexHighEntropyString
from detect_secrets.plugins.private_key import PrivateKeyDetector

MASK = "********"


def _variants(token: str) -> set[str]:
    token = token.strip()
    out = {token}

    out.add(urllib.parse.quote(token, safe=""))
    out.add(urllib.parse.quote_plus(token))

    b = token.encode("utf-8")
    out.add(base64.b64encode(b).decode("ascii"))
    out.add(base64.urlsafe_b64encode(b).decode("ascii").rstrip("="))

    return {v for v in out if v}


def _redact_known_tokens(text: str, tokens: Iterable[str]) -> str:
    masked = text
    all_needles: list[str] = []
    for t in tokens:
        all_needles.extend(_variants(t))

    for needle in sorted(set(all_needles), key=len, reverse=True):
        if len(needle) < 6:
            continue
        masked = masked.replace(needle, MASK)

    return masked


def _redact_detected_secrets(text: str) -> str:
    lines = text.splitlines(keepends=True)
    plugins = [
        Base64HighEntropyString(limit=4.5),
        HexHighEntropyString(limit=4.5),
        AWSKeyDetector(),
        BasicAuthDetector(),
        PrivateKeyDetector(),
    ]

    all_secrets: set[str] = set()
    for idx, line in enumerate(lines):
        for plugin in plugins:
            for potential in plugin.analyze_line("", line, idx):
                if potential.secret_value:
                    all_secrets.add(potential.secret_value)

    findings = sorted(all_secrets, key=len, reverse=True)

    masked = text
    for s in findings:
        masked = masked.replace(s, MASK)
    return masked


def redact(text: str, known_tokens: Iterable[str] | None = None) -> str:
    if known_tokens:
        text = _redact_known_tokens(text, known_tokens)
    text = _redact_detected_secrets(text)
    return text
