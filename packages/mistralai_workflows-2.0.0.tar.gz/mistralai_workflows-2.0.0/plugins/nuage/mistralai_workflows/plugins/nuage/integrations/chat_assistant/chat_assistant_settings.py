from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ChatAssistantSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CHAT_ASSISTANT_", env_file=".env", extra="ignore")

    api_url: str = Field(default="http://ask-ui.chat")
    public_url: str = Field(default="https://chat.globalaegis.net")
    api_key: str | None = Field(default=None, description="API key for x-api-key header")


settings = ChatAssistantSettings()
