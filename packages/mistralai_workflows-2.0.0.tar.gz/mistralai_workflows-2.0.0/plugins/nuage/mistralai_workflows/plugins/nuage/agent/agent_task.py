from __future__ import annotations

import asyncio
from abc import abstractmethod
from typing import Any, Self

import structlog
from pydantic import Field, PrivateAttr

import mistralai_workflows as workflows
from mistralai_workflows.core.task import Task
from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import polymorphic as nuage_polymorphic

from . import agent_models

logger = structlog.get_logger(__name__)


class AgentTask[T](nuage_polymorphic.PolymorphicModel):
    @abstractmethod
    async def __aenter__(self) -> Self:
        raise NotImplementedError

    @abstractmethod
    async def __aexit__(self, *args: Any) -> None:
        raise NotImplementedError

    @abstractmethod
    async def set_state(self, state: T) -> None:
        raise NotImplementedError


class StreamingAgentTask[T](AgentTask[T]):
    _ctx: Any = PrivateAttr(default=None)
    _task: Task[T] | None = PrivateAttr(default=None)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._ctx is not None:
            await self._ctx.__aexit__(*args)

    async def set_state(self, state: T) -> None:
        if self._ctx is None:
            self._ctx = workflows.task_from(state)
            self._task = await self._ctx.__aenter__()
        elif self._task is not None:
            await self._task.set_state(state)


class AgentTaskHook[T](nuage_hook.Hook[AgentTask[T]], AgentTask[T]):
    async def __aenter__(self) -> Self:
        await self.next.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.next.__aexit__(*args)

    async def set_state(self, state: T) -> None:
        await self.next.set_state(state)


class MappingAgentTaskHook[TInput, TOutput](AgentTaskHook[TInput]):
    """Helper hook that maps input state to a different output type.

    Subclasses implement `_map_state(state: TInput) -> TOutput | None` to transform
    state for a separate task stream. Returns None to skip emitting.
    """

    _ctx: Any = PrivateAttr(default=None)
    _task: Task[TOutput] | None = PrivateAttr(default=None)

    async def __aexit__(self, *args: Any) -> None:
        async def _local_exit() -> None:
            if self._ctx:
                await self._ctx.__aexit__(*args)

        await asyncio.gather(_local_exit(), self.next.__aexit__(*args))

    async def set_state(self, state: TInput) -> None:
        async def _local_update() -> None:
            output = self._map_state(state)
            if output is None:
                return
            if self._ctx is None:
                self._ctx = workflows.task_from(output)
                self._task = await self._ctx.__aenter__()
            elif self._task is not None:
                await self._task.set_state(output)

        await asyncio.gather(_local_update(), self.next.set_state(state))

    @abstractmethod
    def _map_state(self, state: TInput) -> TOutput | None:
        raise NotImplementedError


class WorkflowTask(nuage_polymorphic.PolymorphicModel):
    completion: AgentTask[agent_models.AgentCompletionState] = Field(default_factory=StreamingAgentTask)
    tool_call: AgentTask[agent_models.AgentToolCallState] = Field(default_factory=StreamingAgentTask)
    startup: AgentTask[agent_models.AgentStartupState] = Field(default_factory=StreamingAgentTask)

    async def __aenter__(self) -> Self:
        await asyncio.gather(
            self.completion.__aenter__(),
            self.tool_call.__aenter__(),
            self.startup.__aenter__(),
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        await asyncio.gather(
            self.completion.__aexit__(*args),
            self.tool_call.__aexit__(*args),
            self.startup.__aexit__(*args),
        )


class WorkflowTaskHook(nuage_hook.Hook[WorkflowTask], WorkflowTask):
    def attach_to(self, target: WorkflowTask) -> None:
        super().attach_to(target)
        self.completion = nuage_hook.with_hook(target.completion, _as_hook(self.completion))
        self.tool_call = nuage_hook.with_hook(target.tool_call, _as_hook(self.tool_call))
        self.startup = nuage_hook.with_hook(target.startup, _as_hook(self.startup))


def _as_hook[T](task: AgentTask[T]) -> AgentTaskHook[T] | None:
    return task if isinstance(task, AgentTaskHook) else None
