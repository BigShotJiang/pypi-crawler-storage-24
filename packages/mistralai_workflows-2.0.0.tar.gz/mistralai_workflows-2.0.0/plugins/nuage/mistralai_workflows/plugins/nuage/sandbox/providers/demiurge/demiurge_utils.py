from __future__ import annotations

import shlex

import structlog
from demiurge_sdk.config import DemiurgeConfig as DemiurgeSDKConfig

from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets
from mistralai_workflows.plugins.nuage.sandbox import sandbox_utils

from . import demiurge_models

logger = structlog.get_logger(__name__)


def format_env_vars(env: dict[str, str] | None) -> str:
    if not env:
        return ""
    parts = []
    for key, value in env.items():
        if not sandbox_utils.is_valid_env_key(key):
            logger.warning("Skipping invalid env key", key=key)
            continue
        parts.append(f"{key}={shlex.quote(str(value))}")
    return " ".join(parts)


def prepare_command(command: str, cwd: str | None = None, env: dict[str, str] | None = None) -> str:
    if cwd:
        command = f"cd {shlex.quote(cwd)} && {command}"
    if env_cmd := format_env_vars(env):
        command = f"env {env_cmd} bash -c {shlex.quote(command)}"
    return command


def split_runtime_secrets(
    demiurge_config: demiurge_models.DemiurgeSandboxConfig,
    secrets: dict[str, str],
) -> tuple[dict[str, str], str | None]:
    key_name = demiurge_config.demiurge_config.bearer_token_secret_key
    if not key_name:
        return secrets, None

    token = secrets.get(key_name)
    runtime_secrets = {k: v for k, v in secrets.items() if k != key_name}
    if token is not None:
        return runtime_secrets, token

    return runtime_secrets, DemiurgeSDKConfig().bearer_token


def build_client_config(
    demiurge_config: demiurge_models.DemiurgeSandboxConfig,
    secrets: nuage_env_secrets.EnvDict | None,
) -> tuple[DemiurgeSDKConfig, dict[str, str]]:
    extracted = nuage_env_secrets.convert_env_to_dict(secrets)
    runtime_secrets, bearer_token = split_runtime_secrets(demiurge_config, extracted)
    resolved = DemiurgeSDKConfig(
        base_url=demiurge_config.demiurge_config.base_url,
        customer_id=demiurge_config.demiurge_config.customer_id,
        workspace_id=demiurge_config.demiurge_config.workspace_id,
        bearer_token=bearer_token,
        http_timeout_seconds=demiurge_config.demiurge_config.http_timeout_seconds,
        default_ttl_seconds=demiurge_config.demiurge_config.default_ttl_seconds,
        default_exec_timeout_seconds=demiurge_config.demiurge_config.default_exec_timeout_seconds,
        default_image=demiurge_config.demiurge_config.default_image,
        default_setup_script=demiurge_config.demiurge_config.default_setup_script,
        ca_bundle=demiurge_config.demiurge_config.ca_bundle,
    )
    return resolved, runtime_secrets
