from __future__ import annotations

import structlog

import mistralai_workflows as workflows
from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets
from mistralai_workflows.plugins.nuage import redact as nuage_redact
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models

from . import daemon_python_commands, daemon_python_protocol, daemon_python_sandbox_script

logger = structlog.get_logger(__name__)


@workflows.activity()
async def daemon_python_try_collect_diagnostics(
    sandbox: nuage_sandbox.Sandbox,
    tail_lines: int,
) -> str:
    cmd = daemon_python_commands.build_diagnostics_cmd(tail_lines)
    try:
        result = await sandbox.execute(command=cmd, timeout=10)
        return f"{result.stdout}\n{result.stderr}".strip()
    except Exception:
        return "(diagnostics collection failed)"


@workflows.activity()
async def daemon_python_start(
    sandbox: nuage_sandbox.Sandbox,
    env: dict[str, str] | None,
) -> None:
    cmd = daemon_python_commands.build_write_and_start_cmd(env)
    try:
        result = await sandbox.execute(command=cmd, timeout=25)
    except Exception as e:
        diag = await daemon_python_try_collect_diagnostics(sandbox, 50)
        raise RuntimeError(f"Daemon start failed: {e}\n\nDiagnostics:\n{diag}") from e

    if result.exit_code != 0:
        diag = await daemon_python_try_collect_diagnostics(sandbox, 50)
        msg = f"Daemon failed to start (exit={result.exit_code}):\n{result.stderr}\n\nDiagnostics:\n{diag}"
        raise RuntimeError(msg)

    logger.info("Python daemon started", sandbox_id=sandbox.get_info().sandbox_id)


@workflows.activity()
async def daemon_python_execute(
    sandbox: nuage_sandbox.Sandbox, kwargs: nuage_sandbox_models.ExecutePythonKwargs
) -> nuage_sandbox_models.SandboxPythonExecuteResult:
    code = daemon_python_protocol.build_function_invocation_code(
        kwargs["function_source"],
        kwargs["function_name"],
        kwargs.get("kwargs"),
        kwargs.get("is_async", False),
    )
    timeout = kwargs.get("timeout") or daemon_python_sandbox_script.DAEMON_DEFAULT_TIMEOUT
    env = nuage_env_secrets.convert_env_to_dict(kwargs.get("env"))

    send_result = await daemon_python_protocol.send_code_to_daemon(
        sandbox, code, kwargs.get("cwd"), env or None, timeout
    )
    if send_result.exit_code != 0:
        raise daemon_python_protocol.build_error(stderr=send_result.stderr, stdout=send_result.stdout)

    try:
        result = daemon_python_protocol.parse_result(send_result.stdout)
    except Exception as e:
        if await daemon_python_protocol.is_daemon_down(sandbox):
            logger.warning("daemon down, restarting before retry", error=str(e))
            await daemon_python_start(sandbox, env)
            diag = await daemon_python_try_collect_diagnostics(sandbox, 50)
            raise daemon_python_protocol.build_send_runtime_error(str(e), diag) from e
        raise

    if not kwargs.get("skip_redact", False):
        result.result = daemon_python_protocol.redact_result(result.result)
        result.stdout = nuage_redact.redact(result.stdout)
        result.stderr = nuage_redact.redact(result.stderr)
    return result
