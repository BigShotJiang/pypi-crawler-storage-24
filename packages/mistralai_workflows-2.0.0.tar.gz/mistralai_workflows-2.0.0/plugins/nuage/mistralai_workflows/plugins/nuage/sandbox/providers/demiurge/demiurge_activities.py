from __future__ import annotations

import time

from demiurge_sdk.client import DemiurgeClient

import mistralai_workflows as workflows
from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets
from mistralai_workflows.plugins.nuage import redact as nuage_redact
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models

from . import demiurge_constants, demiurge_models, demiurge_utils


def _parse_stream_exit_code(raw_exit_code: str) -> int:
    try:
        return int(raw_exit_code)
    except ValueError as e:
        raise ValueError(f"Demiurge streamed execution returned invalid exit code: {raw_exit_code!r}") from e


async def _execute_streamed(
    client: DemiurgeClient, sandbox_id: str, prepared: str, timeout: int | None
) -> tuple[str, str, int, float]:
    started_at = time.perf_counter()
    buffers: dict[str, list[str]] = {"stdout": [], "stderr": []}
    exit_code: int | None = None

    async for chunk in client.stream_execute(sandbox_id, prepared, timeout=timeout):
        buffer = buffers.get(chunk.type)
        if buffer is not None:
            buffer.append(chunk.data)
            continue

        if chunk.type == "exit":
            exit_code = _parse_stream_exit_code(chunk.data)

    if exit_code is None:
        raise ValueError("Demiurge execution returned no exit_code")

    execution_time = time.perf_counter() - started_at
    return "".join(buffers["stdout"]), "".join(buffers["stderr"]), exit_code, execution_time


async def _execute_blocking(
    client: DemiurgeClient, sandbox_id: str, prepared: str, timeout: int | None
) -> tuple[str, str, int, float]:
    result = await client.execute(sandbox_id, prepared, timeout=timeout)
    if result.exit_code is None:
        raise ValueError("Demiurge execution returned no exit_code")
    if result.execution_time is None:
        raise ValueError("Demiurge execution returned no execution_time")
    return result.stdout, result.stderr, result.exit_code, result.execution_time


@workflows.activity()
async def demiurge_create_sandbox(
    config: demiurge_models.DemiurgeSandboxConfig,
    params: nuage_sandbox_models.CreateSandboxParams,
) -> nuage_sandbox_models.SandboxResult:
    client_config, secrets = demiurge_utils.build_client_config(config, params.secrets)
    env = nuage_env_secrets.convert_env_to_dict(params.env)

    async with DemiurgeClient.from_config(client_config) as client:
        sandbox = await client.create_sandbox(
            image=config.image,
            ttl_seconds=config.ttl_seconds,
            setup_script="",
            envs=env if env else None,
            secrets=secrets if secrets else None,
            cpu_request=config.cpu_request,
            cpu_limit=config.cpu_limit,
            memory_request=config.memory_request,
            memory_limit=config.memory_limit,
            storage_limit=config.storage_limit,
        )

        if config.setup_script:
            await client.execute(sandbox.sandbox_id, config.setup_script)

        return nuage_sandbox_models.SandboxResult(sandbox_id=sandbox.sandbox_id)


@workflows.activity()
async def demiurge_execute(
    sandbox_id: str,
    params: nuage_sandbox_models.ExecuteParams,
    demiurge_config: demiurge_models.DemiurgeSandboxConfig,
) -> nuage_sandbox_models.SandboxExecuteResult:
    client_config, decrypted = demiurge_utils.build_client_config(demiurge_config, params.secrets)
    if params.stream and params.timeout is not None:
        min_http_timeout_seconds = (
            float(params.timeout) + demiurge_config.demiurge_config.stream_http_timeout_buffer_seconds
        )
        if min_http_timeout_seconds > client_config.http_timeout_seconds:
            client_config = client_config.model_copy(update={"http_timeout_seconds": min_http_timeout_seconds})

    env = nuage_env_secrets.convert_env_to_dict(params.env)
    merged_env = {**env, **decrypted}

    effective_cwd = params.cwd or demiurge_constants.DEFAULT_WORKSPACE
    prepared = demiurge_utils.prepare_command(params.command, cwd=effective_cwd, env=merged_env or None)

    async with DemiurgeClient.from_config(client_config) as client:
        execute = _execute_streamed if params.stream else _execute_blocking
        stdout, stderr, exit_code, execution_time = await execute(client, sandbox_id, prepared, params.timeout)

        if not params.skip_redact:
            known_tokens = list(decrypted.values()) if decrypted else None
            stdout = nuage_redact.redact(stdout, known_tokens=known_tokens)
            stderr = nuage_redact.redact(stderr, known_tokens=known_tokens)

        return nuage_sandbox_models.SandboxExecuteResult(
            stdout=stdout,
            stderr=stderr,
            exit_code=exit_code,
            execution_time=execution_time,
        )


@workflows.activity()
async def demiurge_delete_sandbox(
    sandbox_id: str,
    demiurge_config: demiurge_models.DemiurgeSandboxConfig,
    secrets: nuage_env_secrets.EnvDict | None = None,
) -> None:
    client_config, _ = demiurge_utils.build_client_config(demiurge_config, secrets)
    async with DemiurgeClient.from_config(client_config) as client:
        await client.delete_sandbox(sandbox_id)
