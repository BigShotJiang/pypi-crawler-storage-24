from datetime import timedelta
from typing import Any

import mistralai
import structlog
import temporalio.workflow

import mistralai_workflows as workflows
import mistralai_workflows.plugins.mistralai as workflows_mistralai
from mistralai_workflows.core.interactive_workflow import InteractiveWorkflow
from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import settings as nuage_settings
from mistralai_workflows.plugins.nuage import utils as nuage_utils
from mistralai_workflows.plugins.nuage import wait_for_input as nuage_wait_for_input
from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.experimental import experimental_extract as nuage_experimental_extract
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox.daemon_python import daemon_python_hook as nuage_daemon_python_hook

from . import workflow_integrations, workflow_models

logger = structlog.get_logger(__name__)

SECRETS_TIMEOUT = timedelta(minutes=5)
INTEGRATION_TIMEOUT = timedelta(minutes=5)


@workflows.workflow.define(
    name=nuage_settings.settings.workflow.name,
    workflow_display_name=nuage_settings.settings.workflow_display_name,
)
class NuageSandboxWorkflow(InteractiveWorkflow):
    def __init__(self) -> None:
        super().__init__()
        self._integrations: dict[
            nuage_integrations_base.IntegrationId, nuage_integrations_base.BaseIntegration[Any]
        ] = {}
        self._sandbox: nuage_sandbox.Sandbox | None = None

    @workflows.workflow.entrypoint
    async def run(self, params: workflow_models.NuageWorkflowParams) -> workflows_mistralai.ChatAssistantWorkflowOutput:
        logger.info("Starting Nuage sandbox workflow", params=params)

        agent = params.config.agent
        owns_sandbox = params.config.sandbox.get_info().created is False

        try:
            session = await self._setup(params=params)

            with nuage_wait_for_input.WorkflowWaitForInputContext(
                wait_for_input=self.wait_for_input,
            ):
                outputs = await workflows_mistralai.Runner.run(agent=agent, inputs=[params.prompt], session=session)

            await session.close_conversation()

            text_output = outputs[0].text if isinstance(outputs[0], mistralai.TextChunk) else ""
            output = workflows_mistralai.TextOutput(text=text_output)
            return workflows_mistralai.ChatAssistantWorkflowOutput(content=[output])
        except Exception as exc:
            error_msg = nuage_utils.unwrap_exception_group(exc)
            logger.exception("Workflow failed", error=error_msg)
            raise workflows.WorkflowError(f"Workflow failed: {error_msg}") from exc
        finally:
            if owns_sandbox and temporalio.workflow.in_workflow() and self._sandbox:
                try:
                    await self._sandbox.delete_sandbox()
                    logger.info("Deleted sandbox")
                except Exception as e:
                    logger.warning("Failed to delete sandbox", error=str(e))

    @workflows.workflow.update(name="get_integration")
    async def get_integration_update(self, integration_id: nuage_integrations_base.IntegrationId) -> dict[str, Any]:
        try:
            await workflows.workflow.wait_condition(
                lambda: integration_id in self._integrations,
                timeout=INTEGRATION_TIMEOUT,
            )
        except TimeoutError as e:
            raise workflows.WorkflowError(f"Timeout waiting for integration '{integration_id}' to be ready") from e
        result: dict[str, Any] = self._integrations[integration_id].public_data.model_dump()
        return result

    def _on_integration_ready(
        self,
        integration_id: nuage_integrations_base.IntegrationId,
        integration: nuage_integrations_base.BaseIntegration[Any],
    ) -> None:
        self._integrations[integration_id] = integration

    async def _setup(self, params: workflow_models.NuageWorkflowParams) -> nuage_agent_session.Session:
        sandbox, agent_session = params.config.sandbox, params.config.agent_session
        identity = nuage_experimental_extract.experimental_extract_identity(params)

        integration_hooks = await workflow_integrations.build_integrations(
            params=params,
            sandbox=sandbox,
            workflow_spec=workflows.get_workflow_definition(NuageSandboxWorkflow),
            identity=identity,
            on_ready=self._on_integration_ready,
        )
        daemon_hooks = nuage_integrations_base.IntegrationHooks(sandbox=nuage_daemon_python_hook.DaemonPythonHook())
        hooks = nuage_integrations_base.merge_hooks(
            agent_session.default_hooks(),
            daemon_hooks,
            integration_hooks,
        )

        self._sandbox = nuage_hook.with_hook(sandbox, hooks.sandbox)
        workflow_task = nuage_hook.with_hook(nuage_agent_task.WorkflowTask(), hooks.workflow_task)
        agent_session = await agent_session.create(
            agent_session,
            self._sandbox,
            workflow_task,
            hooks.agent_executor,
        )
        agent_session = nuage_hook.with_hook(agent_session, hooks.agent_session)

        async with workflow_task.startup:
            await workflow_task.startup.set_state(nuage_agent_models.AgentStartupState(step="spinning up"))
            await self._sandbox.create_sandbox()
            await workflow_task.startup.set_state(nuage_agent_models.AgentStartupState(step="ready"))

        return agent_session
