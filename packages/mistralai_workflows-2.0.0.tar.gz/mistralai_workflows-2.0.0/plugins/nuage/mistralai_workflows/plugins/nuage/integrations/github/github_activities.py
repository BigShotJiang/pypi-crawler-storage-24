from __future__ import annotations

from datetime import timedelta

import httpx
import pydantic
import structlog

import mistralai_workflows as workflows
from mistralai_workflows.models import EncryptedStrField
from mistralai_workflows.plugins.nuage import constants as nuage_constants
from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox

from . import github_models, github_scripts, github_settings

logger = structlog.get_logger(__name__)
GITHUB_CLONE_TIMEOUT_SECONDS = github_settings.settings.clone_timeout_seconds
GITHUB_CLONE_ACTIVITY_TIMEOUT_SECONDS = (
    github_settings.settings.clone_timeout_seconds + github_settings.settings.clone_activity_timeout_buffer_seconds
)


@workflows.activity()
async def github_validate_token(token: EncryptedStrField) -> bool:
    settings = github_settings.settings
    try:
        async with httpx.AsyncClient(timeout=settings.api_timeout) as client:
            response = await client.get(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"Bearer {token.data}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": settings.token_validation_api_version,
                },
            )
            return response.status_code == 200
    except Exception:
        return False


@workflows.activity()
async def github_fetch_oauth_url(
    identity: nuage_experimental_identity.ExperimentalIdentity,
) -> str | None:
    settings = github_settings.settings
    url = f"{settings.api_url}/v1/internal/connectors/{settings.connector_name}/auth_url"
    headers = identity.build_headers()

    try:
        async with httpx.AsyncClient(timeout=settings.api_timeout) as client:
            response = await client.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            auth_url = data.get("auth_url")
            return str(auth_url) if auth_url else None
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise ValueError(f"GitHub connector not found (connector_name={settings.connector_name})") from e
        return None
    except Exception:
        return None


@workflows.activity()
async def github_fetch_token(
    identity: nuage_experimental_identity.ExperimentalIdentity,
) -> EncryptedStrField | None:
    settings = github_settings.settings
    if settings.connector_id is None:
        return None

    url = f"{settings.api_url}/v1/internal/integrations/{settings.connector_id}"
    headers = identity.build_headers()

    try:
        async with httpx.AsyncClient(timeout=settings.api_timeout) as client:
            response = await client.get(
                url,
                headers=headers,
                params={"fetch_user_data": "true", "fetch_connection_secrets": "true"},
            )
            response.raise_for_status()
            data = response.json()
            token = (data.get("secrets") or {}).get("t_auth_token")
            if not token:
                return None

            encrypted_token = EncryptedStrField(data=token)
            if not await github_validate_token(encrypted_token):
                return None

            return encrypted_token
    except httpx.HTTPStatusError:
        return None
    except Exception:
        logger.exception("Failed to fetch GitHub token from integrations API")
        return None


@workflows.activity(
    start_to_close_timeout=timedelta(seconds=GITHUB_CLONE_ACTIVITY_TIMEOUT_SECONDS),
    retry_policy_max_attempts=1,
)
async def github_clone_repo(
    sandbox: nuage_sandbox.Sandbox,
    url: str,
    github_token: EncryptedStrField,
    branch: str | None = None,
    commit: str | None = None,
    working_branch: str | None = None,
) -> None:
    workspace = sandbox.get_info().workspace
    token = github_token.data
    auth_url = f"https://x-access-token:{token}@{url[len('https://') :]}" if url.startswith("https://") else url

    cmd = github_scripts.build_clone_command(
        dest=workspace,
        url=url,
        auth_url=auth_url,
        git_user_name=nuage_constants.GIT_USER_NAME,
        git_user_email=nuage_constants.GIT_USER_EMAIL,
        branch=branch,
        commit=commit,
        working_branch=working_branch,
    )
    result = await sandbox.execute(command=cmd, timeout=GITHUB_CLONE_TIMEOUT_SECONDS, stream=True)

    if result.exit_code != 0:
        raise RuntimeError(f"Git clone failed (exit {result.exit_code}): {result.stderr or result.stdout}")


@workflows.activity()
async def github_apply_diffs(
    sandbox: nuage_sandbox.Sandbox,
    diffs_b64_zstd: str,
) -> None:
    workspace = sandbox.get_info().workspace
    command = github_scripts.build_apply_diffs_command(diffs_b64_zstd)
    result = await sandbox.execute(command=command, cwd=workspace)
    if result.exit_code != 0:
        raise RuntimeError(f"Git apply diffs failed (exit {result.exit_code}): {result.stderr or result.stdout}")


@workflows.activity()
async def github_validate_state(
    sandbox: nuage_sandbox.Sandbox,
    github_token: EncryptedStrField,
    expected_head: str,
    expected_base: str,
) -> list[str]:
    token = github_token.data

    check_script = github_scripts.build_validate_state_script(
        github_token=token,
        expected_head=expected_head,
    )
    result = await sandbox.execute(command=check_script, timeout=60)

    errors: list[str] = []

    try:
        state = github_models.GitHubValidationState.model_validate_json(result.stdout.strip())
    except pydantic.ValidationError as e:
        logger.error(
            "github_validate_state: failed to parse output",
            raw_stdout=repr(result.stdout),
            raw_stderr=repr(result.stderr),
            error=str(e),
        )
        return [f"Failed to parse validation output: {e}"]

    if not state.branch or state.branch == "HEAD":
        errors.append(f"Not on a valid git branch (expected: '{expected_head}')")
    elif state.branch != expected_head:
        errors.append(f"On branch '{state.branch}' (expected: '{expected_head}')")

    if state.dirty > 0:
        errors.append(f"{state.dirty} uncommitted change(s) in working directory (expected: clean working tree)")

    if not state.remote_exists:
        errors.append(f"Branch '{state.branch}' not on remote (expected: branch pushed to origin)")
    elif state.unpushed > 0:
        errors.append(f"{state.unpushed} local commit(s) not pushed (expected: all commits pushed)")

    if not state.pr:
        errors.append(f"No open PR found (expected: PR from '{expected_head}' to '{expected_base}')")
    elif not any(pr.baseRefName == expected_base for pr in state.pr):
        actual_bases = ", ".join(f"'{pr.baseRefName}'" for pr in state.pr)
        errors.append(f"PR base is {actual_bases} (expected: '{expected_base}')")

    return errors
