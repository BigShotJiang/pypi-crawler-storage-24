from __future__ import annotations

import mistralai_workflows as workflows
from mistralai_workflows.core.config import config as workflows_config


def get_workflows_client() -> workflows.WorkflowsClient:
    return workflows.WorkflowsClient(
        base_url=workflows_config.worker.server_url,
        api_version=workflows_config.worker.api_version,
        headers=workflows_config.worker.mistral_api_headers,
        api_key=workflows_config.common.mistral_api_key.get_secret_value()
        if workflows_config.common.mistral_api_key
        else None,
    )
