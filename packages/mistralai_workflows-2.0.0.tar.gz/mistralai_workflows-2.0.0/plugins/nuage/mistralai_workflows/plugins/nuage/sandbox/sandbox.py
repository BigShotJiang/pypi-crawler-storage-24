from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Unpack

from mistralai_workflows.plugins.nuage import hook as nuage_hook
from mistralai_workflows.plugins.nuage import polymorphic as nuage_polymorphic

from . import sandbox_models


class Sandbox(nuage_polymorphic.PolymorphicModel, ABC):
    @abstractmethod
    def get_info(self) -> sandbox_models.SandboxInfo:
        raise NotImplementedError

    @abstractmethod
    async def create_sandbox(
        self, **kwargs: Unpack[sandbox_models.CreateSandboxKwargs]
    ) -> sandbox_models.SandboxResult:
        raise NotImplementedError

    @abstractmethod
    async def execute(self, **kwargs: Unpack[sandbox_models.ExecuteKwargs]) -> sandbox_models.SandboxExecuteResult:
        raise NotImplementedError

    @abstractmethod
    async def delete_sandbox(self) -> None:
        raise NotImplementedError

    @abstractmethod
    async def execute_python(
        self, **kwargs: Unpack[sandbox_models.ExecutePythonKwargs]
    ) -> sandbox_models.SandboxPythonExecuteResult:
        raise NotImplementedError


class SandboxHook(nuage_hook.Hook[Sandbox], Sandbox):
    def get_info(self) -> sandbox_models.SandboxInfo:
        return self.next.get_info()

    async def create_sandbox(
        self, **kwargs: Unpack[sandbox_models.CreateSandboxKwargs]
    ) -> sandbox_models.SandboxResult:
        return await self.next.create_sandbox(**kwargs)

    async def execute(self, **kwargs: Unpack[sandbox_models.ExecuteKwargs]) -> sandbox_models.SandboxExecuteResult:
        return await self.next.execute(**kwargs)

    async def delete_sandbox(self) -> None:
        await self.next.delete_sandbox()

    async def execute_python(
        self, **kwargs: Unpack[sandbox_models.ExecutePythonKwargs]
    ) -> sandbox_models.SandboxPythonExecuteResult:
        return await self.next.execute_python(**kwargs)
