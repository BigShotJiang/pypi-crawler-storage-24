# Sandbox-executable functions for Vibe tool invocation.
#
# These functions run inside the sandbox via daemon_python_execute().
# All imports MUST be local (inside function body) since the sandbox
# environment is isolated and only has access to packages installed there.
#
# NOTE: Type annotations use string literals to avoid import errors when executed
# remotely. These functions are serialized via inspect.getsource() and the sandbox
# environment doesn't have access to local types at parse time.


# Pre-import vibe modules and initialize tool manager to reduce first-call latency.
# Called in background during sandbox creation. Importing vibe and loading
# the tool registry takes ~6s on Demiurge; doing this upfront hides the cost.
async def warmup_invoke_tool_in_sandbox() -> "dict[str, str]":
    from vibe.core.config import VibeConfig
    from vibe.core.paths.config_paths import unlock_config_paths
    from vibe.core.tools.manager import ToolManager

    unlock_config_paths()  # Required by vibe to allow writing to config paths

    config = VibeConfig()
    tool_manager = ToolManager(config_getter=lambda: config)
    _tool = tool_manager.get("bash")
    return {
        "tool_result": "warmup completed",
    }


# Invoke a Vibe tool inside the sandbox with the given params.
# Patches asyncio.create_subprocess_shell to redirect background command output.
async def invoke_tool_in_sandbox(params: "dict[str, object]") -> "dict[str, object]":
    import asyncio
    import re
    from typing import Any, cast

    from pydantic import BaseModel
    from vibe.core.config import VibeConfig
    from vibe.core.paths.config_paths import unlock_config_paths
    from vibe.core.tools.base import InvokeContext
    from vibe.core.tools.manager import ToolManager
    from vibe.core.types import ToolStreamEvent

    if not getattr(asyncio, "_vibe_subprocess_shell_patched", False):
        original = asyncio.create_subprocess_shell

        async def patched(cmd: str, *args, **kwargs):  # type: ignore[no-untyped-def]
            stripped = cmd.rstrip()
            is_bg = stripped.endswith("&") and not stripped.endswith("&&")
            has_redirect = bool(re.search(r"[12]?>\s*[&/\w]", cmd))
            if is_bg and not has_redirect:
                cmd = f"{stripped[:-1].rstrip()} >/dev/null 2>&1 &"
            return await original(cmd, *args, **kwargs)

        asyncio.create_subprocess_shell = patched  # type: ignore[assignment]
        setattr(asyncio, "_vibe_subprocess_shell_patched", True)

    unlock_config_paths()  # Required by vibe to allow writing to config paths

    config = VibeConfig.model_validate(params["config"])
    tool_manager = ToolManager(config_getter=lambda: config)
    tool_name = cast(str, params["tool_name"])
    tool = tool_manager.get(tool_name)

    tool_state = params.get("tool_state")
    if tool_state is not None:
        state_class = type(tool.state)
        if issubclass(state_class, BaseModel):
            tool.state = state_class.model_validate(tool_state)
        else:
            tool.state = tool_state

    tool_call_id = cast(str, params["tool_call_id"])
    tool_kwargs = cast(dict[str, Any], params["tool_kwargs"])
    ctx = InvokeContext(tool_call_id=tool_call_id)
    result = None
    async for item in tool.invoke(ctx=ctx, **tool_kwargs):
        if not isinstance(item, ToolStreamEvent):
            result = item
    if result is None:
        raise RuntimeError(f"Tool {tool_name} did not yield a result")

    def _dump_if_pydantic_model(value: object) -> object:
        if hasattr(value, "model_dump"):
            return cast(Any, value).model_dump()
        return value

    return {
        "tool_result": _dump_if_pydantic_model(result),
        "tool_state": _dump_if_pydantic_model(tool.state),
    }
