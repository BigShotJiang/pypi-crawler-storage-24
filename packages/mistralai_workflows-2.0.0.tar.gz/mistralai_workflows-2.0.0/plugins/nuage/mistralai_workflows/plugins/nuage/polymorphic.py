from __future__ import annotations

from typing import Any, ClassVar, Self, cast

from pydantic import BaseModel, ConfigDict, model_serializer, model_validator

_POLYMORPHIC_REGISTRY: dict[str, type[PolymorphicModel]] = {}
_POLYMORPHIC_TYPE_KEY = "_polymorphic_type"


class PolymorphicModel(BaseModel):
    """Base for polymorphic Pydantic models with automatic type-based serialization.

    Serialization: Adds `_polymorphic_type` field with runtime type name.
    Deserialization: Dispatches to correct subclass via type registry.
    Nested models: Serializes by actual runtime type (duck-typing) without requiring SerializeAsAny.

    Usage:
        class Animal(PolymorphicModel): name: str
        class Dog(Animal): breed: str

        dog = Dog(name="Rex", breed="Husky")
        data = dog.model_dump()  # includes _polymorphic_type
        restored = Animal.model_validate(data)  # returns Dog instance
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    _type_name: ClassVar[str] = ""

    def __init_subclass__(
        cls, polymorphic_type: str | None = None, polymorphic_version: int = 1, **kwargs: Any
    ) -> None:
        super().__init_subclass__(**kwargs)
        if polymorphic_type is None:
            cls._type_name = f"{cls.__module__}.{cls.__qualname__}"
        elif ":v" in polymorphic_type:
            cls._type_name = polymorphic_type
        else:
            cls._type_name = f"{polymorphic_type}:v{polymorphic_version}"
        _POLYMORPHIC_REGISTRY[cls._type_name] = cls

    @model_serializer(mode="wrap")
    def _serialize(self, handler: Any, info: Any) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for field_name in type(self).model_fields:
            value = getattr(self, field_name)
            if isinstance(value, PolymorphicModel):
                result[field_name] = value._serialize(handler, info)
            else:
                result[field_name] = value
        result[_POLYMORPHIC_TYPE_KEY] = self._type_name
        return result

    @model_validator(mode="wrap")
    @classmethod
    def _deserialize(cls, data: Any, handler: Any) -> Self:
        if isinstance(data, PolymorphicModel):
            return cast(Self, data)
        if not isinstance(data, dict):
            return cast(Self, handler(data))

        data = dict(data)
        type_name: str | None = data.pop(_POLYMORPHIC_TYPE_KEY, None)
        target = _POLYMORPHIC_REGISTRY.get(type_name) if type_name else None
        if target and target is not cls:
            return cast(Self, target.model_validate(data))
        if type_name and not target:
            raise ValueError(f"Unknown type: {type_name}")
        return cast(Self, handler(data))
