from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MistralApiSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MISTRAL_", env_file=".env", extra="ignore")


class WorkflowSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="NUAGE_WORKFLOW_", env_file=".env", extra="ignore")

    # The `__shared` prefix defines a shared workflow accessible across workspaces/namespaces.
    name: str = Field(default="__shared-nuage-workflow")
    display_name: str = Field(default="Vibe Nuage")


class LocalWorkerSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="NUAGE_", env_file=".env", extra="ignore")

    local_worker: bool = Field(default=False)


class MockIdentitySettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="NUAGE_MOCK_IDENTITY_", env_file=".env", extra="ignore")

    enabled: bool = Field(default=False)
    customer_id: str | None = Field(default=None)
    user_id: str | None = Field(default=None)
    workspace_id: str | None = Field(default=None)
    organization_id: str | None = Field(default=None)

    def model_post_init(self, __context: object) -> None:
        if self.enabled and not self.customer_id:
            raise ValueError("customer_id is required when mock identity is enabled")


class Settings(BaseSettings):
    mistral_api: MistralApiSettings = Field(default_factory=MistralApiSettings)  # pyright: ignore[reportArgumentType]
    workflow: WorkflowSettings = Field(default_factory=WorkflowSettings)  # pyright: ignore[reportArgumentType]
    mock_identity: MockIdentitySettings = Field(default_factory=MockIdentitySettings)  # pyright: ignore[reportArgumentType]
    local_worker: LocalWorkerSettings = Field(default_factory=LocalWorkerSettings)  # pyright: ignore[reportArgumentType]

    @property
    def workflow_display_name(self) -> str:
        base = self.workflow.display_name
        if self.local_worker.local_worker:
            return f"{base} (local)"
        return base


settings = Settings()
