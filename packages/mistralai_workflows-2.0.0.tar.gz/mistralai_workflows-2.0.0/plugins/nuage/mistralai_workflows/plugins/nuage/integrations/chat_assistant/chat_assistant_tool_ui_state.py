import re

from mistralai_workflows.plugins.mistralai.lechat import (
    CreateFileOperation,
    FileOperation,
    FileToolUIState,
    GenericToolUIState,
    ReplaceFileOperation,
    SearchReplaceBlock,
    ToolResultFailed,
    ToolResultRunning,
    ToolResultSuccess,
    ToolUIState,
)
from mistralai_workflows.plugins.nuage import utils as nuage_utils
from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models

_SEARCH_REPLACE_BLOCK_RE = re.compile(
    r"<{5,} SEARCH\r?\n(.*?)\r?\n?={5,}\r?\n(.*?)\r?\n?>{5,} REPLACE",
    flags=re.DOTALL,
)

_FILE_MODIFYING_TOOLS = {"write_file", "search_replace"}


def _build_write_file_operations(state: nuage_agent_models.AgentToolCallState) -> list[FileOperation]:
    if state.output is None:
        return []

    path = state.output.get("path", "")
    content = state.output.get("content", "")
    file_existed = state.output.get("file_existed", False)
    file_content_before = state.output.get("file_content_before")

    if not path:
        return []

    if file_existed and file_content_before is not None:
        blocks = [SearchReplaceBlock(search=file_content_before, replace=content)]
        return [ReplaceFileOperation(uri=path, fileContentBefore=file_content_before, blocks=blocks)]

    return [CreateFileOperation(uri=path, content=content)]


def _build_search_replace_operations(state: nuage_agent_models.AgentToolCallState) -> list[FileOperation]:
    if state.output is None:
        return []

    file_path = state.output.get("file", "")
    file_content_before = state.output.get("file_content_before")
    content_raw = state.output.get("content", "")

    if not file_path or file_content_before is None:
        return []

    blocks = [SearchReplaceBlock(search=s, replace=r) for s, r in _SEARCH_REPLACE_BLOCK_RE.findall(content_raw)]
    return [ReplaceFileOperation(uri=file_path, fileContentBefore=file_content_before, blocks=blocks)]


def _build_file_tool_ui_state(state: nuage_agent_models.AgentToolCallState) -> FileToolUIState:
    if state.name == "write_file":
        operations = _build_write_file_operations(state)
    elif state.name == "search_replace":
        operations = _build_search_replace_operations(state)
    else:
        operations = []

    return FileToolUIState(toolCallId=nuage_utils.ensure(state.tool_call_id), operations=operations)


def _build_generic_tool_ui_state(state: nuage_agent_models.AgentToolCallState, *, toolName: str) -> GenericToolUIState:
    result: ToolResultRunning | ToolResultFailed | ToolResultSuccess
    if state.output is None:
        result = ToolResultRunning()
    elif "error" in state.output:
        result = ToolResultFailed(error=state.output["error"])
    else:
        result = ToolResultSuccess(value=state.output)

    return GenericToolUIState(
        toolCallId=nuage_utils.ensure(state.tool_call_id),
        name=toolName,
        arguments=state.kwargs,
        result=result,
    )


def build_tool_ui_state(state: nuage_agent_models.AgentToolCallState, *, toolName: str) -> ToolUIState | None:
    if state.tool_call_id is None:
        return None

    if state.name in _FILE_MODIFYING_TOOLS:
        return _build_file_tool_ui_state(state)

    return _build_generic_tool_ui_state(state, toolName=toolName)
