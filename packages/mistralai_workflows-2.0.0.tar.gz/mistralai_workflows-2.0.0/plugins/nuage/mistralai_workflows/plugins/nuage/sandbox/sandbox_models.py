from typing import Any, NotRequired, TypedDict

from pydantic import BaseModel, Field

from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets


class SandboxInfo(BaseModel):
    workspace: str = Field(description="Workspace directory")
    created: bool = Field(description="Flag indicating if the sandbox has been created")
    sandbox_id: str | None = Field(default=None, description="Sandbox ID (set after creation)")


class SandboxResult(BaseModel):
    sandbox_id: str


class CreateSandboxKwargs(TypedDict):
    env: NotRequired[nuage_env_secrets.EnvDict | None]
    secrets: NotRequired[nuage_env_secrets.EnvDict | None]


class CreateSandboxParams(BaseModel):
    env: nuage_env_secrets.EnvDict | None = None
    secrets: nuage_env_secrets.EnvDict | None = None

    @classmethod
    def from_kwargs(cls, kwargs: CreateSandboxKwargs) -> "CreateSandboxParams":
        return cls(env=kwargs.get("env"), secrets=kwargs.get("secrets"))


class ExecuteKwargs(TypedDict):
    command: str
    cwd: NotRequired[str | None]
    env: NotRequired[nuage_env_secrets.EnvDict | None]
    secrets: NotRequired[nuage_env_secrets.EnvDict | None]
    timeout: NotRequired[int | None]
    stream: NotRequired[bool]
    skip_redact: NotRequired[bool]


class ExecuteParams(BaseModel):
    command: str
    cwd: str | None = None
    env: nuage_env_secrets.EnvDict | None = None
    secrets: nuage_env_secrets.EnvDict | None = None
    timeout: int | None = None
    stream: bool = False
    skip_redact: bool = False

    @classmethod
    def from_kwargs(cls, kwargs: ExecuteKwargs) -> "ExecuteParams":
        return cls(
            command=kwargs["command"],
            cwd=kwargs.get("cwd"),
            env=kwargs.get("env"),
            secrets=kwargs.get("secrets"),
            timeout=kwargs.get("timeout"),
            stream=kwargs.get("stream", False),
            skip_redact=kwargs.get("skip_redact", False),
        )


class SandboxExecuteResult(BaseModel):
    stdout: str
    stderr: str
    exit_code: int
    execution_time: float


class ExecutePythonKwargs(TypedDict):
    function_source: str
    function_name: str
    kwargs: NotRequired[dict[str, Any]]
    is_async: NotRequired[bool]
    python_executable: NotRequired[str]
    cwd: NotRequired[str | None]
    env: NotRequired[nuage_env_secrets.EnvDict | None]
    timeout: NotRequired[int | None]
    skip_redact: NotRequired[bool]


class SandboxPythonExecuteResult(BaseModel):
    result: Any
    stdout: str
    stderr: str
    exit_code: int
    execution_time: float
