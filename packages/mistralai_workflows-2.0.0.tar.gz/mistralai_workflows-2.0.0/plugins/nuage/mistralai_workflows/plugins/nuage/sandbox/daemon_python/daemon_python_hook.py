from __future__ import annotations

from typing import Unpack

import structlog

from mistralai_workflows.plugins.nuage import env_secrets as nuage_env_secrets
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models

from . import daemon_python_activities

logger = structlog.get_logger(__name__)


class DaemonPythonHook(nuage_sandbox.SandboxHook):
    async def create_sandbox(
        self, **kwargs: Unpack[nuage_sandbox_models.CreateSandboxKwargs]
    ) -> nuage_sandbox_models.SandboxResult:
        result = await self.next.create_sandbox(**kwargs)
        env = nuage_env_secrets.convert_env_to_dict(kwargs.get("env"))
        await daemon_python_activities.daemon_python_start(self.next, env or None)
        return result
