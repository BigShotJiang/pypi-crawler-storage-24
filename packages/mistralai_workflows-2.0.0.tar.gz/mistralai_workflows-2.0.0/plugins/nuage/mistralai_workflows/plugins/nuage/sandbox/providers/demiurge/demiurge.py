from __future__ import annotations

from typing import Literal, Unpack

from pydantic import Field

from mistralai_workflows.plugins.nuage import utils as nuage_utils
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox import sandbox_models as nuage_sandbox_models
from mistralai_workflows.plugins.nuage.sandbox.daemon_python import (
    daemon_python_activities as nuage_daemon_python_activities,
)

from . import demiurge_activities, demiurge_constants, demiurge_models


class DemiurgeSandbox(nuage_sandbox.Sandbox, polymorphic_type="demiurge"):
    type: Literal["demiurge"] = "demiurge"
    config: demiurge_models.DemiurgeSandboxConfig = Field(default_factory=demiurge_models.DemiurgeSandboxConfig)
    internal_state: demiurge_models.DemiurgeInternalState = Field(default_factory=demiurge_models.DemiurgeInternalState)

    def get_info(self) -> nuage_sandbox_models.SandboxInfo:
        return nuage_sandbox_models.SandboxInfo(
            workspace=demiurge_constants.DEFAULT_WORKSPACE,
            created=self.internal_state.sandbox_id is not None,
            sandbox_id=self.internal_state.sandbox_id,
        )

    async def create_sandbox(
        self, **kwargs: Unpack[nuage_sandbox_models.CreateSandboxKwargs]
    ) -> nuage_sandbox_models.SandboxResult:
        if self.get_info().created:
            sandbox_id = nuage_utils.ensure(
                self.internal_state.sandbox_id,
                RuntimeError("Sandbox ID is not set while sandbox is considered created"),
            )
            return nuage_sandbox_models.SandboxResult(sandbox_id=sandbox_id)

        self.internal_state.secrets = kwargs.get("secrets")
        params = nuage_sandbox_models.CreateSandboxParams.from_kwargs(kwargs)
        result = await demiurge_activities.demiurge_create_sandbox(self.config, params)
        self.internal_state.sandbox_id = result.sandbox_id
        return result

    async def execute(
        self, **kwargs: Unpack[nuage_sandbox_models.ExecuteKwargs]
    ) -> nuage_sandbox_models.SandboxExecuteResult:
        sandbox_id = nuage_utils.ensure(
            self.internal_state.sandbox_id,
            RuntimeError("Sandbox ID is not set, call create_sandbox first"),
        )
        if kwargs.get("secrets") is not None:
            self.internal_state.secrets = kwargs.get("secrets")
        params = nuage_sandbox_models.ExecuteParams.from_kwargs(kwargs)
        return await demiurge_activities.demiurge_execute(sandbox_id, params, self.config)

    async def delete_sandbox(self) -> None:
        sandbox_id = nuage_utils.ensure(
            self.internal_state.sandbox_id,
            RuntimeError("Sandbox ID is not set, call create_sandbox first"),
        )
        await demiurge_activities.demiurge_delete_sandbox(sandbox_id, self.config, self.internal_state.secrets)

    async def execute_python(
        self, **kwargs: Unpack[nuage_sandbox_models.ExecutePythonKwargs]
    ) -> nuage_sandbox_models.SandboxPythonExecuteResult:
        return await nuage_daemon_python_activities.daemon_python_execute(self, kwargs)
