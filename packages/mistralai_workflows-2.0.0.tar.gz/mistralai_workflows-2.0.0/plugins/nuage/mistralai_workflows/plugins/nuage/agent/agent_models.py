from typing import Any

from pydantic import BaseModel

from mistralai_workflows.plugins.mistralai.agent import Agent as MistralAgent


class Agent(MistralAgent):
    handoffs: None = None  # pyright: ignore[reportIncompatibleVariableOverride] # no supported yet by nuage


class AgentToolCallState(BaseModel):
    name: str
    kwargs: dict[str, Any] = {}
    output: dict[str, Any] | None = None
    tool_call_id: str | None = None


class AgentCompletionState(BaseModel):
    content: str = ""


class AgentStartupState(BaseModel):
    step: str = ""
