from __future__ import annotations

from pydantic import BaseModel, Field, PrivateAttr
from vibe.core.agent_loop import AgentLoop as VibeLoop
from vibe.core.config import Backend, ModelConfig, ProviderConfig, SessionLoggingConfig
from vibe.core.config import VibeConfig as OriginalVibeConfig
from vibe.core.paths.config_paths import unlock_config_paths
from vibe.core.teleport.nuage import TeleportSession

from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox
from mistralai_workflows.plugins.nuage.sandbox.providers.demiurge import demiurge_constants as nuage_demiurge_constants

# TODO: Vibe SDK requirement; to be removed after vibe SDK refactor
unlock_config_paths()


class VibeParams(BaseModel):
    config: OriginalVibeConfig | None = Field(default=None, description="Vibe configuration")
    teleported_session: TeleportSession | None = Field(default=None, description="Teleported session state")


class VibeAgent(nuage_agent_models.Agent):
    name: str = Field(default="vibe-agent", description="Agent name")

    api_key_env_var: str = Field(default="PROD_MISTRAL_API_KEY", description="Environment variable for API key")
    api_base: str = Field(default="https://api.mistral.ai/v1", description="API base URL")
    auto_approve: bool = Field(default=True, description="Auto-approve tool calls")
    temperature: float = Field(default=0.2, description="Model temperature")

    @staticmethod
    def from_vibe_config(config: VibeConfig) -> VibeAgent:
        provider = config.providers[0] if config.providers else None
        model = next((m for m in config.models if m.alias == config.active_model), None)

        return VibeAgent(
            model=model.name if model else "mistral-medium-latest",
            name="vibe-agent",
            api_key_env_var=provider.api_key_env_var if provider else "PROD_MISTRAL_API_KEY",
            api_base=provider.api_base if provider else "https://api.mistral.ai/v1",
            auto_approve=config.auto_approve,
            temperature=model.temperature if model else 0.2,
        )


class VibeConfig(OriginalVibeConfig):
    @staticmethod
    def from_agent(agent: nuage_agent_session.Agent | VibeAgent) -> VibeConfig:
        if isinstance(agent, VibeAgent):
            api_key_env_var = agent.api_key_env_var
            api_base = agent.api_base
            auto_approve = agent.auto_approve
            temperature = agent.temperature
        else:
            api_key_env_var = "PROD_MISTRAL_API_KEY"
            api_base = "https://api.mistral.ai/v1"
            auto_approve = True
            temperature = 0.2

        provider = ProviderConfig(
            name="mistral",
            api_base=api_base,
            api_key_env_var=api_key_env_var,
            backend=Backend.MISTRAL,
        )

        model_config = ModelConfig(
            name=agent.model,
            provider="mistral",
            alias="active-model",
            temperature=temperature,
        )

        return VibeConfig(
            displayed_workdir=nuage_demiurge_constants.DEFAULT_WORKSPACE,
            active_model="active-model",
            providers=[provider],
            models=[model_config],
            mcp_servers=[],
            session_logging=SessionLoggingConfig(enabled=False),
            include_project_context=False,
            auto_approve=auto_approve,
            include_commit_signature=False,
        )


class VibeSessionInternalState(BaseModel):
    sandbox: nuage_sandbox.Sandbox | None = Field(default=None, description="Sandbox")
    workflow_task: nuage_agent_task.WorkflowTask | None = Field(default=None, description="Workflow task")
    agent_executor: nuage_agent_executor.AgentExecutor | None = Field(default=None, description="Agent executor")
    conversation_active: bool = Field(default=False, description="Whether the conversation is active")
    last_assistant_message: str = Field(default="", description="Last assistant message")

    _vibe_agent: VibeLoop | None = PrivateAttr(default=None)
