from __future__ import annotations

from collections.abc import Awaitable, Callable
from contextvars import ContextVar, Token

from pydantic import BaseModel

WaitForInputCallback = Callable[[type[BaseModel], str | None], Awaitable[BaseModel]]

_wait_for_input_callback: ContextVar[WaitForInputCallback | None] = ContextVar(
    "nuage_wait_for_input_callback",
    default=None,
)


class WorkflowWaitForInputContext:
    def __init__(
        self,
        *,
        wait_for_input: WaitForInputCallback,
    ) -> None:
        self._wait_for_input = wait_for_input
        self._callback_token: Token[WaitForInputCallback | None] | None = None

    def __enter__(self) -> WorkflowWaitForInputContext:
        self._callback_token = _wait_for_input_callback.set(self._wait_for_input)
        return self

    def __exit__(self, *_: object) -> None:
        if self._callback_token is None:
            raise RuntimeError("WorkflowWaitForInputContext was not entered")
        _wait_for_input_callback.reset(self._callback_token)
        self._callback_token = None

    @staticmethod
    def get_wait_for_input() -> WaitForInputCallback:
        callback = _wait_for_input_callback.get()
        if callback is None:
            raise RuntimeError("wait_for_input callback is not set")
        return callback
