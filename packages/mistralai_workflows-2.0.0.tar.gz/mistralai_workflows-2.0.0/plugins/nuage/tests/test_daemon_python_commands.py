from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

import pytest

from mistralai_workflows.plugins.nuage.sandbox.daemon_python import (
    daemon_python_commands as nuage_daemon_python_commands,
)


def _run_cmd(cmd: str, cwd: str | None = None, timeout: float = 10.0) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


class TestDaemonPythonCommands:
    def test_build_send_code_cmd_rejects_non_string_env_value(self) -> None:
        with pytest.raises(ValueError, match="expected string"):
            nuage_daemon_python_commands.build_send_code_cmd(
                "__result__ = 1",
                env={"A": "ok", "B": 123},  # type: ignore[dict-item]
            )

    def test_build_write_and_start_cmd_rejects_invalid_env_key(self) -> None:
        with pytest.raises(ValueError, match="Invalid environment variable name"):
            nuage_daemon_python_commands.build_write_and_start_cmd(env={"BAD-KEY": "value"})

    def test_ping_end_to_end(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            start_cmd = nuage_daemon_python_commands.build_write_and_start_cmd(base_dir=tmpdir)
            started = _run_cmd(start_cmd, cwd=tmpdir, timeout=20)
            assert started.returncode == 0, f"Failed to start daemon: {started.stderr}"

            ping_cmd = nuage_daemon_python_commands.build_ping_cmd(base_dir=tmpdir, timeout=3)
            ping = _run_cmd(ping_cmd, timeout=10)
            assert ping.returncode == 0, f"Ping failed: {ping.stderr}"

            response = json.loads(ping.stdout)
            assert response["ok"] is True
            assert response["result"]["pong"] is True
            assert isinstance(response["result"]["pid"], int)

            ready_file = Path(tmpdir) / "_daemon_ready"
            assert ready_file.exists()

            subprocess.run(f"pkill -f '{tmpdir}/_daemon.py'", shell=True, capture_output=True)
