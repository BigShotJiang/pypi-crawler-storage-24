from __future__ import annotations

from pydantic import BaseModel

from mistralai_workflows.plugins.nuage.agent import agent_executor as nuage_agent_executor
from mistralai_workflows.plugins.nuage.agent import agent_session as nuage_agent_session
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.integrations import integrations_base as nuage_integrations_base
from mistralai_workflows.plugins.nuage.sandbox import sandbox as nuage_sandbox


class DummyPublicData(BaseModel):
    label: str = "ok"


class DummyIntegration(nuage_integrations_base.BaseIntegration[DummyPublicData]):
    pass


class DummySandboxHook(nuage_sandbox.SandboxHook):
    pass


class DummySessionHook(nuage_agent_session.SessionHook):
    pass


class DummyWorkflowTaskHook(nuage_agent_task.WorkflowTaskHook):
    pass


class DummyAgentExecutorHook(nuage_agent_executor.AgentExecutorHook):
    pass


class TestMergeIntegrations:
    def test_empty_integrations_returns_empty_hooks(self) -> None:
        hooks = nuage_integrations_base.merge_hooks()
        assert hooks.sandbox is None
        assert hooks.agent_session is None
        assert hooks.workflow_task is None
        assert hooks.agent_executor is None

    def test_single_integration_propagates_all_hook_types(self) -> None:
        integration = DummyIntegration(
            public_data=DummyPublicData(),
            sandbox=DummySandboxHook(),
            agent_session=DummySessionHook(),
            workflow_task=DummyWorkflowTaskHook(),
            agent_executor=DummyAgentExecutorHook(),
        )
        hooks = nuage_integrations_base.merge_hooks(integration)
        assert hooks.sandbox is not None
        assert hooks.agent_session is not None
        assert hooks.workflow_task is not None
        assert hooks.agent_executor is not None

    def test_multiple_integrations_chains_hooks(self) -> None:
        github = DummyIntegration(
            public_data=DummyPublicData(),
            sandbox=DummySandboxHook(),
            agent_session=DummySessionHook(),
        )
        chat_assistant = DummyIntegration(
            public_data=DummyPublicData(),
            workflow_task=DummyWorkflowTaskHook(),
        )
        hooks = nuage_integrations_base.merge_hooks(github, chat_assistant)
        assert hooks.sandbox is not None
        assert hooks.agent_session is not None
        assert hooks.workflow_task is not None
        assert hooks.agent_executor is None

    def test_multiple_hooks_of_same_type_are_chained(self) -> None:
        int1 = DummyIntegration(
            public_data=DummyPublicData(),
            sandbox=DummySandboxHook(),
        )
        int2 = DummyIntegration(
            public_data=DummyPublicData(),
            sandbox=DummySandboxHook(),
        )
        hooks = nuage_integrations_base.merge_hooks(int1, int2)
        assert hooks.sandbox is not None
        assert hooks.sandbox.next_hook is not None
