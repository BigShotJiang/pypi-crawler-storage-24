from __future__ import annotations

import pytest

from mistralai_workflows.plugins.nuage.sandbox import sandbox_utils as nuage_sandbox_utils


def sample_sync_func(x: int, y: int) -> int:
    return x + y


async def sample_async_func(name: str) -> str:
    return f"hello {name}"


class TestBuildExecutePythonKwargs:
    def test_sync_function(self) -> None:
        result = nuage_sandbox_utils.build_execute_python_kwargs(sample_sync_func, kwargs={"x": 1, "y": 2})
        assert result["function_name"] == "sample_sync_func"
        assert result.get("is_async") is False
        assert "def sample_sync_func" in result["function_source"]
        assert result.get("kwargs") == {"x": 1, "y": 2}

    def test_async_function_detected(self) -> None:
        result = nuage_sandbox_utils.build_execute_python_kwargs(sample_async_func)
        assert result["function_name"] == "sample_async_func"
        assert result.get("is_async") is True

    def test_optional_params_forwarded(self) -> None:
        result = nuage_sandbox_utils.build_execute_python_kwargs(
            sample_sync_func,
            cwd="/custom",
            env={"KEY": "val"},
            timeout=30,
            python_executable="python3.12",
            skip_redact=True,
        )
        assert result.get("cwd") == "/custom"
        assert result.get("env") == {"KEY": "val"}
        assert result.get("timeout") == 30
        assert result.get("python_executable") == "python3.12"
        assert result.get("skip_redact") is True

    def test_optional_params_omitted_when_none(self) -> None:
        result = nuage_sandbox_utils.build_execute_python_kwargs(sample_sync_func)
        assert "cwd" not in result
        assert "env" not in result
        assert "timeout" not in result

    def test_non_callable_raises(self) -> None:
        with pytest.raises(ValueError, match="func must be callable"):
            nuage_sandbox_utils.build_execute_python_kwargs("not a function")  # type: ignore[arg-type]

    def test_source_is_dedented(self) -> None:
        result = nuage_sandbox_utils.build_execute_python_kwargs(sample_sync_func)
        assert result["function_source"].startswith("def ")
