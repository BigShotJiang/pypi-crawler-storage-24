from __future__ import annotations

import inspect
from dataclasses import dataclass
from uuid import UUID, uuid4

import httpx
import pytest
import respx

import mistralai_workflows as workflows
from mistralai_workflows.models import WorkflowSpec
from mistralai_workflows.plugins.nuage.experimental import experimental_identity as nuage_experimental_identity
from mistralai_workflows.plugins.nuage.integrations.chat_assistant import (
    chat_assistant_activities,
    chat_assistant_models,
    chat_assistant_settings,
)


@dataclass
class _FakeWorkflowVersion:
    id: UUID


@dataclass
class _FakeWorkflowVersionListResponse:
    workflow_versions: list[_FakeWorkflowVersion]


class _FakeWorkflowsClient:
    def __init__(self, response: _FakeWorkflowVersionListResponse):
        self._response = response
        self.calls: list[dict[str, object]] = []

    async def get_workflow_versions(self, **kwargs: object) -> _FakeWorkflowVersionListResponse:
        self.calls.append(kwargs)
        return self._response


def _workflow_spec(name: str = "wf") -> WorkflowSpec:
    return WorkflowSpec(name=name, input_schema={}, signals=[], queries=[], updates=[], schedules=[])


def _make_identity() -> nuage_experimental_identity.ExperimentalIdentity:
    return nuage_experimental_identity.ExperimentalIdentity(
        version=1,
        customer_id="test-customer",
        user_id="test-user",
        workspace_id="test-workspace",
        organization_id="test-org",
    )


def _make_create_params() -> chat_assistant_models.CreateChatAssistantThreadParams:
    return chat_assistant_models.CreateChatAssistantThreadParams(
        identity=_make_identity(),
        workflow_version_id="wf-123",
        workflow_execution_id="exec-456",
        workflow_name="test-workflow",
        workflow_params={},
        user_message="Hello",
        chat_title="Test Chat",
        project_name=None,
    )


_RAW_CREATE_CHAT_THREAD = inspect.unwrap(chat_assistant_activities.create_chat_assistant_thread)
_RAW_GET_WORKFLOW_VERSION_ID = inspect.unwrap(chat_assistant_activities.get_workflow_version_id)


@pytest.fixture
def mock_chat_api(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        chat_assistant_settings.settings,
        "api_url",
        "https://api.test.com",
    )
    monkeypatch.setattr(
        chat_assistant_settings.settings,
        "public_url",
        "https://api.test.com",
    )


class TestGetWorkflowVersionId:
    @pytest.mark.asyncio
    async def test_returns_last_version_id(self) -> None:
        first_id = uuid4()
        latest_id = uuid4()
        client = _FakeWorkflowsClient(
            _FakeWorkflowVersionListResponse(
                workflow_versions=[
                    _FakeWorkflowVersion(id=first_id),
                    _FakeWorkflowVersion(id=latest_id),
                ]
            )
        )

        result = await _RAW_GET_WORKFLOW_VERSION_ID(_workflow_spec("nuage"), client)

        assert result == str(latest_id)
        assert len(client.calls) == 1
        assert client.calls[0]["workflow_name"] == "nuage"
        assert client.calls[0]["active_only"] is False
        assert client.calls[0]["limit"] == 250

    @pytest.mark.asyncio
    async def test_raises_when_no_versions(self) -> None:
        client = _FakeWorkflowsClient(_FakeWorkflowVersionListResponse(workflow_versions=[]))

        with pytest.raises(workflows.WorkflowError, match="No workflow version found"):
            await _RAW_GET_WORKFLOW_VERSION_ID(_workflow_spec("empty"), client)


class TestCreateChatAssistantThread:
    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_thread_creation(self, mock_chat_api: None) -> None:
        respx.post("https://api.test.com/api/v1/chats").mock(
            return_value=httpx.Response(200, json={"chatId": "chat-789"})
        )
        result = await _RAW_CREATE_CHAT_THREAD(_make_create_params())
        assert result.chat_url == "https://api.test.com/chat/chat-789"

    @respx.mock
    @pytest.mark.asyncio
    async def test_raises_on_http_500(self, mock_chat_api: None) -> None:
        respx.post("https://api.test.com/api/v1/chats").mock(
            return_value=httpx.Response(500, json={"error": "Internal Server Error"})
        )
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await _RAW_CREATE_CHAT_THREAD(_make_create_params())
        assert exc_info.value.response.status_code == 500

    @respx.mock
    @pytest.mark.asyncio
    async def test_raises_on_http_401_unauthorized(self, mock_chat_api: None) -> None:
        respx.post("https://api.test.com/api/v1/chats").mock(
            return_value=httpx.Response(401, json={"error": "Unauthorized"})
        )
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await _RAW_CREATE_CHAT_THREAD(_make_create_params())
        assert exc_info.value.response.status_code == 401
