import pytest

from mistralai_workflows.plugins.nuage.integrations.integrations_base import IntegrationId


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("chat_assistant", IntegrationId.CHAT_ASSISTANT),
        ("lechat", IntegrationId.CHAT_ASSISTANT),
        ("github", IntegrationId.GITHUB),
    ],
)
def test_integration_id_aliases(raw: str, expected: IntegrationId) -> None:
    assert IntegrationId(raw) is expected


def test_integration_id_unknown_raises() -> None:
    with pytest.raises(ValueError):
        IntegrationId("nope")
