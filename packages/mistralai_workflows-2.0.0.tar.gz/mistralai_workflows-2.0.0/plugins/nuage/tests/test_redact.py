from __future__ import annotations

import base64
import urllib.parse

from mistralai_workflows.plugins.nuage import redact as nuage_redact

MASK = nuage_redact.MASK


class TestVariants:
    def test_produces_url_encoded_variant(self) -> None:
        token = "secret/key+value"
        variants = nuage_redact._variants(token)
        assert urllib.parse.quote(token, safe="") in variants
        assert urllib.parse.quote_plus(token) in variants

    def test_produces_base64_variants(self) -> None:
        token = "my-secret-token"
        variants = nuage_redact._variants(token)
        assert base64.b64encode(token.encode()).decode("ascii") in variants
        assert base64.urlsafe_b64encode(token.encode()).decode("ascii").rstrip("=") in variants

    def test_strips_whitespace(self) -> None:
        variants = nuage_redact._variants("  secret  ")
        assert "secret" in variants
        assert "  secret  " not in variants

    def test_empty_variants_excluded(self) -> None:
        variants = nuage_redact._variants("   ")
        for v in variants:
            assert v != ""


class TestRedactKnownTokens:
    def test_masks_plain_token(self) -> None:
        text = "Authorization: Bearer ghp_abc123def456"
        result = nuage_redact._redact_known_tokens(text, ["ghp_abc123def456"])
        assert "ghp_abc123def456" not in result
        assert MASK in result

    def test_masks_url_encoded_token(self) -> None:
        token = "secret/key+value"
        encoded = urllib.parse.quote(token, safe="")
        text = f"url=https://example.com?key={encoded}"
        result = nuage_redact._redact_known_tokens(text, [token])
        assert encoded not in result

    def test_masks_base64_encoded_token(self) -> None:
        token = "my-secret-value"
        b64 = base64.b64encode(token.encode()).decode()
        text = f"encoded: {b64}"
        result = nuage_redact._redact_known_tokens(text, [token])
        assert b64 not in result

    def test_skips_short_tokens(self) -> None:
        text = "value=abc"
        result = nuage_redact._redact_known_tokens(text, ["abc"])
        assert result == text

    def test_multiple_tokens(self) -> None:
        text = "key1=secret_aaaaaa key2=secret_bbbbbb"
        result = nuage_redact._redact_known_tokens(text, ["secret_aaaaaa", "secret_bbbbbb"])
        assert "secret_aaaaaa" not in result
        assert "secret_bbbbbb" not in result

    def test_longer_match_replaced_first(self) -> None:
        text = "token=secret_long_value_here"
        result = nuage_redact._redact_known_tokens(text, ["secret_long_value_here", "secret"])
        assert result == f"token={MASK}"

    def test_no_tokens_returns_unchanged(self) -> None:
        text = "nothing to redact"
        assert nuage_redact._redact_known_tokens(text, []) == text


class TestRedactDetectedSecrets:
    def test_masks_aws_access_key(self) -> None:
        text = "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE"
        result = nuage_redact._redact_detected_secrets(text)
        assert "AKIAIOSFODNN7EXAMPLE" not in result
        assert MASK in result

    def test_masks_basic_auth_url(self) -> None:
        text = "https://admin:supersecretpassword@example.com/api"
        result = nuage_redact._redact_detected_secrets(text)
        assert "supersecretpassword" not in result

    def test_masks_private_key(self) -> None:
        text = "-----BEGIN RSA PRIVATE KEY-----\nMIIBogIBAAJBALRi\n-----END RSA PRIVATE KEY-----"
        result = nuage_redact._redact_detected_secrets(text)
        assert "BEGIN RSA PRIVATE KEY" not in result

    def test_leaves_normal_text_unchanged(self) -> None:
        text = "Hello world, this is just a normal log line"
        assert nuage_redact._redact_detected_secrets(text) == text


class TestRedactComposed:
    def test_redacts_both_known_and_detected(self) -> None:
        token = "ghp_myGithubToken1234"
        text = f"token={token} aws=AKIAIOSFODNN7EXAMPLE"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert token not in result
        assert "AKIAIOSFODNN7EXAMPLE" not in result

    def test_no_known_tokens_still_detects_secrets(self) -> None:
        text = "AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE"
        result = nuage_redact.redact(text)
        assert "AKIAIOSFODNN7EXAMPLE" not in result

    def test_clean_text_passes_through(self) -> None:
        text = "clean log output with nothing sensitive"
        assert nuage_redact.redact(text) == text


class TestGitHubPATRedaction:
    def test_masks_classic_github_pat(self) -> None:
        token = "ghp_FAKE_TEST_TOKEN_NOT_REAL_0000000"
        text = f"GITHUB_TOKEN={token}"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert token not in result
        assert MASK in result

    def test_masks_fine_grained_github_pat(self) -> None:
        token = "github_pat_FAKE_TEST_TOKEN_000000_notrealtokenvalue0000000000000"
        text = f"Authorization: Bearer {token}"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert token not in result

    def test_masks_github_pat_in_git_url(self) -> None:
        token = "ghp_FAKE_GIT_URL_TOKEN_NOT_REAL_00"
        text = f"git clone https://{token}@github.com/org/repo.git"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert token not in result
        assert "org/repo" in result

    def test_masks_url_encoded_github_pat(self) -> None:
        token = "ghp_abc123+special/chars"
        encoded = urllib.parse.quote(token, safe="")
        text = f"url=https://example.com?token={encoded}"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert encoded not in result

    def test_masks_base64_encoded_github_pat(self) -> None:
        token = "ghp_FAKE_B64_TOKEN_NOT_REAL_00000"
        b64 = base64.b64encode(token.encode()).decode()
        text = f"encoded_token: {b64}"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert b64 not in result

    def test_masks_multiple_github_pats(self) -> None:
        token1 = "ghp_FAKE_FIRST_TOKEN_NOT_REAL_000"
        token2 = "ghp_FAKE_SECOND_TOKEN_NOT_REAL_00"
        text = f"GH_TOKEN={token1} GITHUB_TOKEN={token2}"
        result = nuage_redact.redact(text, known_tokens=[token1, token2])
        assert token1 not in result
        assert token2 not in result

    def test_masks_github_pat_in_error_message(self) -> None:
        token = "ghp_FAKE_LOG_TOKEN_NOT_REAL_0000"
        text = f"Error: Authentication failed for token {token}"
        result = nuage_redact.redact(text, known_tokens=[token])
        assert token not in result
        assert "Error:" in result
        assert "Authentication failed" in result
