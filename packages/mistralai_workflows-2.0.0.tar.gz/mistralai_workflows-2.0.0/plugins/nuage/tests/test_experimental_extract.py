from __future__ import annotations

from typing import Any

import pytest

from mistralai_workflows.core.config.config import ReservedExtraFieldsAttribute
from mistralai_workflows.plugins.nuage.experimental import (
    experimental_extract as nuage_experimental_extract,
)
from mistralai_workflows.plugins.nuage.workflow import (
    workflow_models as nuage_workflow_models,
)


def _make_params(**extra: Any) -> nuage_workflow_models.NuageWorkflowParams:
    return nuage_workflow_models.NuageWorkflowParams(prompt="test", **extra)


class TestExperimentalExtractIdentity:
    def test_extracts_valid_identity_from_params(self) -> None:
        raw_identity = {
            "version": 1,
            "customer_id": "cust-123",
            "user_id": "user-456",
            "workspace_id": "ws-789",
            "organization_id": "org-000",
        }
        params = _make_params(**{ReservedExtraFieldsAttribute.EXPERIMENTAL_IDENTITY: raw_identity})

        result = nuage_experimental_extract.experimental_extract_identity(params)

        assert result is not None
        assert result.version == 1
        assert result.customer_id == "cust-123"
        assert result.user_id == "user-456"
        assert result.workspace_id == "ws-789"
        assert result.organization_id == "org-000"

    def test_returns_none_or_mock_when_no_identity_in_params(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from mistralai_workflows.plugins.nuage import settings as nuage_settings

        monkeypatch.setattr(nuage_settings.settings.mock_identity, "enabled", False)  # type: ignore[attr-defined]
        params = _make_params()

        result = nuage_experimental_extract.experimental_extract_identity(params)

        assert result is None

    def test_returns_none_for_invalid_identity_data(self) -> None:
        params = _make_params(**{ReservedExtraFieldsAttribute.EXPERIMENTAL_IDENTITY: "invalid"})

        result = nuage_experimental_extract.experimental_extract_identity(params)

        assert result is None

    def test_returns_none_for_missing_version(self) -> None:
        raw_identity = {"customer_id": "cust-123"}
        params = _make_params(**{ReservedExtraFieldsAttribute.EXPERIMENTAL_IDENTITY: raw_identity})

        result = nuage_experimental_extract.experimental_extract_identity(params)

        assert result is None

    def test_extracts_partial_identity(self) -> None:
        raw_identity = {"version": 1, "customer_id": "cust-only"}
        params = _make_params(**{ReservedExtraFieldsAttribute.EXPERIMENTAL_IDENTITY: raw_identity})

        result = nuage_experimental_extract.experimental_extract_identity(params)

        assert result is not None
        assert result.customer_id == "cust-only"
        assert result.user_id is None
        assert result.workspace_id is None
        assert result.organization_id is None
