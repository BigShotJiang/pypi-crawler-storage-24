from __future__ import annotations

from typing import Any, cast

import pytest
from pydantic import BaseModel
from vibe.core.tools.builtins.ask_user_question import AskUserQuestionArgs, AskUserQuestionResult

from mistralai_workflows.plugins.nuage import wait_for_input as nuage_wait_for_input
from mistralai_workflows.plugins.nuage.agent import agent_task as nuage_agent_task
from mistralai_workflows.plugins.nuage.agent.providers.vibe import (
    vibe_hook_wait_for_input as nuage_vibe_hook_wait_for_input,
)
from mistralai_workflows.plugins.nuage.agent.providers.vibe import vibe_patches as nuage_vibe_patches

from .vibe_fixtures import MockAgentExecutor, MockWorkflowTaskRecorder, create_vibe_config


def _proxy_request(tool_name: str, tool_kwargs: dict[str, object]) -> nuage_vibe_patches.ProxyInvokeToolRequest:
    return nuage_vibe_patches.ProxyInvokeToolRequest(
        config=create_vibe_config(),
        tool_name=tool_name,
        tool_call_id="tool-call-1",
        tool_kwargs=tool_kwargs,
        tool_state={"state": "x"},
    )


def _workflow_task_with_mock_tool_call() -> tuple[nuage_agent_task.WorkflowTask, MockWorkflowTaskRecorder]:
    workflow_task = nuage_agent_task.WorkflowTask()
    recorder = MockWorkflowTaskRecorder()
    workflow_task.tool_call = cast(Any, recorder.tool_call)
    return workflow_task, recorder


class TestAskUserQuestionBridgeHook:
    def test_runtime_context_getters_raise_without_binding(self) -> None:
        with pytest.raises(RuntimeError, match="wait_for_input callback is not set"):
            nuage_wait_for_input.WorkflowWaitForInputContext.get_wait_for_input()

    @pytest.mark.asyncio
    async def test_runtime_context_nested_bind_restores_parent_values(self) -> None:
        async def outer_cb(input_model: type[BaseModel], _label: str | None) -> BaseModel:
            return input_model.model_validate({"value": "outer"})

        async def inner_cb(input_model: type[BaseModel], _label: str | None) -> BaseModel:
            return input_model.model_validate({"value": "inner"})

        class _Input(BaseModel):
            value: str

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=outer_cb):
            outer_result = await nuage_wait_for_input.WorkflowWaitForInputContext.get_wait_for_input()(_Input, None)
            assert _Input.model_validate(outer_result).value == "outer"

            with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=inner_cb):
                inner_result = await nuage_wait_for_input.WorkflowWaitForInputContext.get_wait_for_input()(_Input, None)
                assert _Input.model_validate(inner_result).value == "inner"

            restored_result = await nuage_wait_for_input.WorkflowWaitForInputContext.get_wait_for_input()(_Input, None)
            assert _Input.model_validate(restored_result).value == "outer"

    def test_wait_for_input_schema_orders_answer_before_other_text(self) -> None:
        args = AskUserQuestionArgs.model_validate(
            {
                "questions": [
                    {
                        "question": "Preferred stack?",
                        "options": [
                            {"label": "Python", "description": "Use Python"},
                            {"label": "Rust", "description": "Use Rust"},
                        ],
                        "multi_select": False,
                        "hide_other": False,
                    }
                ]
            }
        )

        input_model, _ = nuage_vibe_hook_wait_for_input._build_wait_for_input_model(args)
        schema = input_model.model_json_schema()
        properties = list((schema.get("properties") or {}).keys())

        assert properties == ["question_0_answer", "question_0_other_text"]

    @pytest.mark.asyncio
    async def test_non_ask_request_is_delegated(self) -> None:
        hook = nuage_vibe_hook_wait_for_input.VibeWaitForInputHook(workflow_task=nuage_agent_task.WorkflowTask())
        executor = MockAgentExecutor()
        hook.attach_to(executor)

        delegated_response = nuage_vibe_patches.ProxyInvokeToolResponse(
            tool_result={"output_text": "delegated"},
            tool_state={"state": "next"},
        )
        executor.tool_response = delegated_response

        response = await hook.invoke_tool(_proxy_request("dummy_tool", {"input_text": "hello"}))

        assert response == delegated_response
        assert len(executor.tool_calls) == 1
        assert executor.tool_calls[0].tool_name == "dummy_tool"

    @pytest.mark.asyncio
    async def test_single_select_flow_maps_result_and_updates_task_state(self) -> None:
        workflow_task, workflow_task_recorder = _workflow_task_with_mock_tool_call()

        async def wait_for_input(input_model: type[BaseModel], _label: str | None) -> BaseModel:
            return input_model.model_validate({"question_0_answer": "Yes"})

        hook = nuage_vibe_hook_wait_for_input.VibeWaitForInputHook(workflow_task=workflow_task)
        hook.attach_to(MockAgentExecutor())

        request = _proxy_request(
            "ask_user_question",
            {
                "questions": [
                    {
                        "question": "Proceed?",
                        "header": "Confirm",
                        "options": [
                            {"label": "Yes", "description": "Continue"},
                            {"label": "No", "description": "Stop"},
                        ],
                        "multi_select": False,
                        "hide_other": True,
                    }
                ]
            },
        )

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await hook.invoke_tool(request)

        assert response.error is None
        parsed = AskUserQuestionResult.model_validate(response.tool_result)
        assert parsed.cancelled is False
        assert len(parsed.answers) == 1
        assert parsed.answers[0].question == "Proceed?"
        assert parsed.answers[0].answer == "Yes"
        assert parsed.answers[0].is_other is False

        assert len(workflow_task_recorder.tool_call.states) == 2
        assert workflow_task_recorder.tool_call.states[0].name == "ask_user_question"
        assert workflow_task_recorder.tool_call.states[0].kwargs == request.tool_kwargs
        assert workflow_task_recorder.tool_call.states[0].output is None
        assert workflow_task_recorder.tool_call.states[1].output == response.tool_result

    @pytest.mark.asyncio
    async def test_single_select_other_sets_is_other_true(self) -> None:
        workflow_task, _ = _workflow_task_with_mock_tool_call()

        async def wait_for_input(input_model: type[BaseModel], _label: str | None) -> BaseModel:
            return input_model.model_validate(
                {
                    "question_0_answer": "__other__",
                    "question_0_other_text": "Custom answer",
                }
            )

        hook = nuage_vibe_hook_wait_for_input.VibeWaitForInputHook(workflow_task=workflow_task)
        hook.attach_to(MockAgentExecutor())

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await hook.invoke_tool(
                _proxy_request(
                    "ask_user_question",
                    {
                        "questions": [
                            {
                                "question": "Preferred stack?",
                                "options": [
                                    {"label": "Python", "description": "Use Python"},
                                    {"label": "Rust", "description": "Use Rust"},
                                ],
                                "multi_select": False,
                                "hide_other": False,
                            }
                        ]
                    },
                )
            )

        assert response.error is None
        parsed = AskUserQuestionResult.model_validate(response.tool_result)
        assert parsed.answers[0].answer == "Custom answer"
        assert parsed.answers[0].is_other is True

    @pytest.mark.asyncio
    async def test_multi_select_answer_is_comma_joined(self) -> None:
        workflow_task, _ = _workflow_task_with_mock_tool_call()

        async def wait_for_input(input_model: type[BaseModel], _label: str | None) -> BaseModel:
            return input_model.model_validate({"question_0_answer": ["Feature A", "Feature B"]})

        hook = nuage_vibe_hook_wait_for_input.VibeWaitForInputHook(workflow_task=workflow_task)
        hook.attach_to(MockAgentExecutor())

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await hook.invoke_tool(
                _proxy_request(
                    "ask_user_question",
                    {
                        "questions": [
                            {
                                "question": "Pick features",
                                "options": [
                                    {"label": "Feature A", "description": "A"},
                                    {"label": "Feature B", "description": "B"},
                                ],
                                "multi_select": True,
                                "hide_other": True,
                            }
                        ]
                    },
                )
            )

        assert response.error is None
        parsed = AskUserQuestionResult.model_validate(response.tool_result)
        assert parsed.answers[0].answer == "Feature A, Feature B"
        assert parsed.answers[0].is_other is False

    @pytest.mark.asyncio
    async def test_invalid_kwargs_returns_error_response(self) -> None:
        workflow_task, workflow_task_recorder = _workflow_task_with_mock_tool_call()
        callback_called = False

        async def wait_for_input(_input_model: type[BaseModel], _label: str | None) -> BaseModel:
            nonlocal callback_called
            callback_called = True
            raise AssertionError("wait_for_input callback must not be called for invalid args")

        hook = nuage_vibe_hook_wait_for_input.VibeWaitForInputHook(workflow_task=workflow_task)
        hook.attach_to(MockAgentExecutor())

        with nuage_wait_for_input.WorkflowWaitForInputContext(wait_for_input=wait_for_input):
            response = await hook.invoke_tool(_proxy_request("ask_user_question", {"questions": []}))

        assert response.error is not None
        assert response.error.startswith("Invalid ask_user_question arguments:")
        assert callback_called is False
        assert len(workflow_task_recorder.tool_call.states) == 2
        assert workflow_task_recorder.tool_call.states[1].output == {"error": response.error}
