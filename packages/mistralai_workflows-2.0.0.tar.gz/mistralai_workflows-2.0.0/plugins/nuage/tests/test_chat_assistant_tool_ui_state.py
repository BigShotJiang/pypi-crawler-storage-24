from pathlib import Path

from vibe.core.tools.base import InvokeContext
from vibe.core.tools.manager import ToolManager
from vibe.core.types import ToolStreamEvent

from mistralai_workflows.plugins.nuage.agent import agent_models as nuage_agent_models
from mistralai_workflows.plugins.nuage.integrations.chat_assistant.chat_assistant_tool_ui_state import (
    _SEARCH_REPLACE_BLOCK_RE,
    _build_search_replace_operations,
    _build_write_file_operations,
    build_tool_ui_state,
)
from tests.vibe_fixtures import create_vibe_config


class TestSearchReplaceBlockRegex:
    """Unit tests for _SEARCH_REPLACE_BLOCK_RE.

    These test the regex against hardcoded strings. See TestSearchReplaceBlockRegexVibe
    for integration tests that validate the regex against real vibe tool output.
    """

    def test_matches_standard_vibe_format(self) -> None:
        content = "<<<<<<< SEARCH\nold code\n=======\nnew code\n>>>>>>> REPLACE"
        matches = _SEARCH_REPLACE_BLOCK_RE.findall(content)
        assert matches == [("old code", "new code")]

    def test_matches_multiline_blocks(self) -> None:
        content = "<<<<<<< SEARCH\nline1\nline2\n=======\nline3\nline4\n>>>>>>> REPLACE"
        matches = _SEARCH_REPLACE_BLOCK_RE.findall(content)
        assert matches == [("line1\nline2", "line3\nline4")]

    def test_matches_windows_line_endings(self) -> None:
        content = "<<<<<<< SEARCH\r\nold\r\n=======\r\nnew\r\n>>>>>>> REPLACE"
        matches = _SEARCH_REPLACE_BLOCK_RE.findall(content)
        assert matches == [("old", "new")]

    def test_matches_multiple_consecutive_blocks(self) -> None:
        content = (
            "<<<<<<< SEARCH\naaa\n=======\nAAA\n>>>>>>> REPLACE\n<<<<<<< SEARCH\nbbb\n=======\nBBB\n>>>>>>> REPLACE"
        )
        matches = _SEARCH_REPLACE_BLOCK_RE.findall(content)
        assert matches == [("aaa", "AAA"), ("bbb", "BBB")]

    def test_matches_with_extra_angle_brackets(self) -> None:
        content = "<<<<<<<<< SEARCH\nold\n=========\nnew\n>>>>>>>>> REPLACE"
        matches = _SEARCH_REPLACE_BLOCK_RE.findall(content)
        assert matches == [("old", "new")]


async def _invoke_vibe_search_replace(file_path: str, content: str) -> dict:
    """Invoke the real vibe search_replace tool and return its output as a dict."""
    config = create_vibe_config()
    tool_manager = ToolManager(config_getter=lambda: config)
    tool = tool_manager.get("search_replace")
    ctx = InvokeContext(tool_call_id="tc-vibe-integration")

    result = None
    async for item in tool.invoke(ctx=ctx, file_path=file_path, content=content):
        if not isinstance(item, ToolStreamEvent):
            result = item

    assert result is not None
    return result.model_dump()


class TestSearchReplaceBlockRegexVibe:
    """Integration tests that run the regex against real vibe search_replace output.

    These catch breaking changes in vibe's output format that the unit tests would miss.
    """

    async def test_single_block_matches_real_vibe_output(self, tmp_path: Path) -> None:
        target = tmp_path / "example.py"
        target.write_text("hello world\nfoo bar\n")

        sr_content = "<<<<<<< SEARCH\nhello world\n=======\nhello universe\n>>>>>>> REPLACE"
        output = await _invoke_vibe_search_replace(str(target), sr_content)

        matches = _SEARCH_REPLACE_BLOCK_RE.findall(output["content"])
        assert matches == [("hello world", "hello universe")]

    async def test_multiple_blocks_match_real_vibe_output(self, tmp_path: Path) -> None:
        target = tmp_path / "example.py"
        target.write_text("aaa\nbbb\nccc\n")

        sr_content = (
            "<<<<<<< SEARCH\naaa\n=======\nAAA\n>>>>>>> REPLACE\n<<<<<<< SEARCH\nccc\n=======\nCCC\n>>>>>>> REPLACE"
        )
        output = await _invoke_vibe_search_replace(str(target), sr_content)

        matches = _SEARCH_REPLACE_BLOCK_RE.findall(output["content"])
        assert matches == [("aaa", "AAA"), ("ccc", "CCC")]


class TestWriteFileCreate:
    def test_write_file_create_produces_file_state(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="write_file",
            kwargs={"path": "/tmp/new.py", "content": "print('hello')"},
            output={
                "path": "/tmp/new.py",
                "bytes_written": 14,
                "file_existed": False,
                "content": "print('hello')",
            },
            tool_call_id="tc-1",
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is not None
        assert result.type == "file"
        assert result.toolCallId == "tc-1"
        assert len(result.operations) == 1
        op = result.operations[0]
        assert op.type == "create"
        assert op.uri == "/tmp/new.py"
        assert op.content == "print('hello')"


class TestWriteFileOverwrite:
    def test_write_file_overwrite_produces_replace_operation(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="write_file",
            kwargs={"path": "/tmp/exist.py", "content": "new content", "overwrite": True},
            output={
                "path": "/tmp/exist.py",
                "bytes_written": 11,
                "file_existed": True,
                "content": "new content",
                "file_content_before": "old content",
            },
            tool_call_id="tc-2",
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is not None
        assert result.type == "file"
        assert len(result.operations) == 1
        op = result.operations[0]
        assert op.type == "replace"
        assert op.fileContentBefore == "old content"
        assert len(op.blocks) == 1
        assert op.blocks[0].search == "old content"
        assert op.blocks[0].replace == "new content"


class TestSearchReplace:
    def test_search_replace_produces_file_state(self) -> None:
        original = "hello world\nfoo bar\n"
        sr_content = "<<<<<<< SEARCH\nhello world\n=======\nhello universe\n>>>>>>> REPLACE"
        state = nuage_agent_models.AgentToolCallState(
            name="search_replace",
            kwargs={"file_path": "/tmp/test.py", "content": sr_content},
            output={
                "file": "/tmp/test.py",
                "blocks_applied": 1,
                "lines_changed": 0,
                "content": sr_content,
                "file_content_before": original,
            },
            tool_call_id="tc-3",
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is not None
        assert result.type == "file"
        assert len(result.operations) == 1
        op = result.operations[0]
        assert op.type == "replace"
        assert op.uri == "/tmp/test.py"
        assert op.fileContentBefore == original
        assert len(op.blocks) == 1
        assert op.blocks[0].search == "hello world"
        assert op.blocks[0].replace == "hello universe"

    def test_search_replace_multiple_blocks(self) -> None:
        original = "aaa\nbbb\nccc\n"
        sr_content = (
            "<<<<<<< SEARCH\naaa\n=======\nAAA\n>>>>>>> REPLACE\n<<<<<<< SEARCH\nccc\n=======\nCCC\n>>>>>>> REPLACE"
        )
        state = nuage_agent_models.AgentToolCallState(
            name="search_replace",
            kwargs={"file_path": "/tmp/multi.py", "content": sr_content},
            output={
                "file": "/tmp/multi.py",
                "blocks_applied": 2,
                "lines_changed": 0,
                "content": sr_content,
                "file_content_before": original,
            },
            tool_call_id="tc-3b",
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is not None
        assert result.type == "file"
        op = result.operations[0]
        assert op.type == "replace"
        assert len(op.blocks) == 2
        assert op.blocks[0].search == "aaa"
        assert op.blocks[0].replace == "AAA"
        assert op.blocks[1].search == "ccc"
        assert op.blocks[1].replace == "CCC"


class TestGenericTools:
    def test_generic_tool_running(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="bash",
            kwargs={"command": "ls"},
            output=None,
            tool_call_id="tc-4",
        )
        result = build_tool_ui_state(state, toolName="Listing files")
        assert result is not None
        assert result.type == "generic_tool"
        assert result.name == "Listing files"
        assert result.arguments == {"command": "ls"}
        assert result.result.status == "running"

    def test_generic_tool_success(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="bash",
            kwargs={"command": "ls"},
            output={"stdout": "file.txt", "exit_code": 0},
            tool_call_id="tc-5",
        )
        result = build_tool_ui_state(state, toolName="Listing files")
        assert result is not None
        assert result.type == "generic_tool"
        assert result.name == "Listing files"
        assert result.arguments == {"command": "ls"}
        assert result.result.status == "success"
        assert result.result.value == {"stdout": "file.txt", "exit_code": 0}

    def test_generic_tool_failed(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="bash",
            kwargs={"command": "bad-cmd"},
            output={"error": "command not found"},
            tool_call_id="tc-6",
        )
        result = build_tool_ui_state(state, toolName="Running command")
        assert result is not None
        assert result.type == "generic_tool"
        assert result.result.status == "failed"
        assert result.result.error == "command not found"


class TestNoneOutputReturnsEmptyOperations:
    def test_write_file_none_output_returns_empty_list(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="write_file",
            kwargs={"path": "/tmp/new.py", "content": "x"},
            output=None,
            tool_call_id="tc-none-1",
        )
        result = _build_write_file_operations(state)
        assert result == []

    def test_search_replace_none_output_returns_empty_list(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="search_replace",
            kwargs={"file_path": "/tmp/test.py", "content": "x"},
            output=None,
            tool_call_id="tc-none-2",
        )
        result = _build_search_replace_operations(state)
        assert result == []


class TestFileToolEmptyOperations:
    def test_file_tool_without_content_before_returns_empty_operations(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="search_replace",
            kwargs={"file_path": "/tmp/test.py", "content": "no blocks"},
            output={
                "file": "/tmp/test.py",
                "blocks_applied": 0,
                "lines_changed": 0,
                "content": "no blocks",
            },
            tool_call_id="tc-7",
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is not None
        assert result.type == "file"
        assert result.operations == []

    def test_file_tool_running_returns_empty_operations(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="write_file",
            kwargs={"path": "/tmp/new.py", "content": "x"},
            output=None,
            tool_call_id="tc-8",
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is not None
        assert result.type == "file"
        assert result.operations == []


class TestNoToolCallId:
    def test_no_tool_call_id_returns_none(self) -> None:
        state = nuage_agent_models.AgentToolCallState(
            name="bash",
            kwargs={"command": "ls"},
            output=None,
        )
        result = build_tool_ui_state(state, toolName="")
        assert result is None
