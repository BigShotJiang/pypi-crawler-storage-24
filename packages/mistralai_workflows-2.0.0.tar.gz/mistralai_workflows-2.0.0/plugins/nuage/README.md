# Nuage

integrations (GitHub, LeChat).

## Architecture

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for system design, module structure, and design decisions.

## Conventions

### Workflow Naming

Workflows prefixed with `__shared` (e.g., `__shared-nuage-workflow`) are shared workflows accessible across workspaces and namespaces. This is a platform convention for workflows not tied to a specific user deployment.

## Prerequisites

## Create your own organization and workspace

⚠️ **WARNING: USE YOUR OWN ORGANIZATION/WORKSPACE**
When running a local worker against staging, you **MUST** use your own organization and workspace. Your local worker competes with the deployed staging worker for tasks. If both pick up tasks from the same workspace, you will get inconsistent behavior and workflow failures. Create your own organization at https://console.globalaegis.net/ for local development.


### Install Vibe

```bash
uv tool install mistral-vibe-private==2.2.1b2 --force --no-cache
```

### API Keys

```bash
export MISTRAL_API_KEY=xxx           # from https://console.mistral.ai/
export STAGING_MISTRAL_API_KEY=xxx   # from https://console.globalaegis.net/
```

## Running

| Mode | Worker | Orchestrator | Best for |
|------|--------|--------------|----------|
| **Staging** | Staging | Staging | Demos, quick testing |
| **Local Worker + Staging** | Local | Staging | Development, fast iteration |
| **Fully Local** | Local | Local | Development, full observability |

### Staging Mode

Uses deployed staging worker and orchestrator. No local setup required.

#### Step 1: Configure Vibe

```bash
sed -i '' '/^nuage_/d' ~/.vibe/config.toml; printf 'nuage_enabled = true\nnuage_base_url = "https://api.globalaegis.net"\nnuage_api_key_env_var = "STAGING_MISTRAL_API_KEY"\n' | cat - ~/.vibe/config.toml > /tmp/vc && mv /tmp/vc ~/.vibe/config.toml
```

#### Step 2: Run Vibe

```bash
vibe --prompt "create a hello world file" --teleport
```

---

## Development

### Local Worker + Staging Orchestrator

Runs the worker locally while connecting to the staging Temporal server and API at `api.globalaegis.net`.



#### Prerequisites

**Mock Identity:**

Open https://console.globalaegis.net/ → DevTools (F12) → Console, run:
```javascript
fetch("/api/users/me").then(r=>r.json()).then(({customer:c,uuid:u,workspace:w,organization:o})=>console.log(`export NUAGE_MOCK_IDENTITY_ENABLED=true NUAGE_MOCK_IDENTITY_CUSTOMER_ID=${c.uuid} NUAGE_MOCK_IDENTITY_USER_ID=${u} NUAGE_MOCK_IDENTITY_WORKSPACE_ID=${w.uuid} NUAGE_MOCK_IDENTITY_ORGANIZATION_ID=${o.uuid}`))
```
Export the output.

#### Step 1: Start the worker

```bash
make run-worker
```

#### Step 2: Configure Vibe

```bash
sed -i '' '/^nuage_/d' ~/.vibe/config.toml; printf 'nuage_enabled = true\nnuage_workflow_id = "__dev-shared-nuage-workflow"\nnuage_base_url = "https://api.globalaegis.net"\nnuage_api_key_env_var = "STAGING_MISTRAL_API_KEY"\n' | cat - ~/.vibe/config.toml > /tmp/vc && mv /tmp/vc ~/.vibe/config.toml
```

#### Step 3: Trigger workflow with Vibe

```bash
vibe --prompt "create a hello world file" --teleport
```

#### Alternative: Trigger via make

```bash
export STAGING_MISTRAL_API_KEY=xxx
make run-workflow INPUT='{"prompt":"create a hello world file"}'
```

### Fully Local Mode

Runs the entire stack locally via Docker Compose in `abraxas/`:
- Temporal server + UI
- Gateway (Kong)
- PostgreSQL, Redis, NATS
- Tempo (observability)

This gives full visibility into all logs from Temporal to the workflows server.

> **Note:** LeChat URLs work in local mode but the live stream will not be visible. This is expected. Use the Temporal UI to monitor workflow progress.

#### Step 1: Start the worker

```bash
make run-worker-local
```

This will:
1. Start the dev environment via `make -C abraxas dev`
2. Start the gateway and stop the default dockerized worker
3. Run the local worker with hot-reload
4. Display the `LOCAL_MISTRAL_API_KEY` to export for Vibe

If containers fail to start, rebuild with `make build-worker`.

#### Step 2: Configure Vibe

The worker startup will show you the required vibe config. If not configured, run:
```bash
sed -i '' '/^nuage_/d' ~/.vibe/config.toml; printf 'nuage_enabled = true\nnuage_workflow_id = "__dev-shared-nuage-workflow"\nnuage_base_url = "http://localhost:7444"\nnuage_api_key_env_var = "LOCAL_MISTRAL_API_KEY"\n' | cat - ~/.vibe/config.toml > /tmp/vc && mv /tmp/vc ~/.vibe/config.toml
```

#### Step 3: Export API key for Vibe

Copy the `LOCAL_MISTRAL_API_KEY` from the worker output and export it:
```bash
export LOCAL_MISTRAL_API_KEY=<key-from-worker-output>
```

#### Step 4: Trigger workflow with Vibe

```bash
vibe --prompt "create a hello world file" --teleport
```

#### Alternative: Trigger via make

```bash
make run-workflow MISTRAL_ENV=local INPUT='{"prompt":"create a hello world file"}'
```

#### Local URLs

| Service | URL |
|---------|-----|
| Temporal UI | http://localhost:8080 |
| Abraxas API | http://localhost:8000 |
| Gateway | http://localhost:7444 |
| Grafana | http://localhost:3007 (admin/admin) |

For more options, see `make help`.

## Troubleshooting

### Vibe teleport: `Nuage workflow trigger failed: {"detail":"Workflow version not found"}`

Common causes:
- `nuage_workflow_id` in `~/.vibe/config.toml` does not match the workflow name registered by your local worker (`NUAGE_WORKFLOW_NAME`).
- Worker is running on a different task queue than the queue used by the execution request.

### Vibe teleport not working with `Teleport error: Failed to get GitHub integration: {"detail":"Workflow not running","code":"WF_1102","status":"FAILED"}`

If you are getting this error or another one related to vibe while worker is running and healthy, please check
if your are in the org/workspace you created and your mock identity (the `fetch` command you ran`) are correct.


## Installation

The nuage plugin and its private dependencies are hosted on Gemfury.

```bash
# Configure Gemfury index (get token from Bitwarden)
export UV_INDEX_GEMFURY_PASSWORD="<your-gemfury-token>"

# Add to your project
uv add mistralai-workflows-plugins-nuage --index-strategy unsafe-best-match --prerelease=allow
```

Or add to `pyproject.toml`:

```toml
[project]
dependencies = [
    "mistralai-workflows-plugins-nuage>=0.0.1rc1",
]

[tool.uv]
extra-index-url = ["https://pypi.fury.io/mistralai/"]
prerelease = "allow"
index-strategy = "unsafe-best-match"
```

Then run `uv sync` with the Gemfury token exported.

## Docker

### Build worker image

```bash
# From repo root
docker build -f infra/docker/mistralai_nuage/worker.Dockerfile -t mistralai-nuage-worker \
  --secret id=GEMFURY_DEPLOY_TOKEN,env=UV_INDEX_GEMFURY_PASSWORD .
```

### Run worker image

```bash
docker run --rm \
  -e MODE=partial \
  -e MAIN_KEY="$(openssl rand -hex 32)" \
  -e MISTRAL_API_KEY="$STAGING_MISTRAL_API_KEY" \
  -e PROD_MISTRAL_API_KEY="$PROD_MISTRAL_API_KEY" \
  -e DEMIURGE_BEARER_TOKEN="$STAGING_MISTRAL_API_KEY" \
  -e DEMIURGE_BASE_URL="https://api.globalaegis.net/v1" \
  -e SERVER_URL="https://api.globalaegis.net" \
  -e NUAGE_WORKFLOW_NAME="__dev-shared-nuage-workflow" \
  -e LOG_LEVEL=DEBUG \
  -e GITHUB_INTEGRATION_API_URL="https://integrations-api-staging.cheetah-koi.ts.net" \
  -e GITHUB_INTEGRATION_CONNECTOR_ID="<connector-id>" \
  -e CHAT_ASSISTANT_API_URL="https://chat.globalaegis.net" \
  -e CHAT_ASSISTANT_PUBLIC_URL="https://chat.globalaegis.net" \
  mistralai-nuage-worker
```

**With mock identity (development):**

```bash
docker run --rm \
  -e MODE=partial \
  -e MAIN_KEY="$(openssl rand -hex 32)" \
  -e MISTRAL_API_KEY="$STAGING_MISTRAL_API_KEY" \
  -e PROD_MISTRAL_API_KEY="$PROD_MISTRAL_API_KEY" \
  -e DEMIURGE_BEARER_TOKEN="$STAGING_MISTRAL_API_KEY" \
  -e DEMIURGE_BASE_URL="https://api.globalaegis.net/v1" \
  -e SERVER_URL="https://api.globalaegis.net" \
  -e NUAGE_WORKFLOW_NAME="__dev-shared-nuage-workflow" \
  -e LOG_LEVEL=DEBUG \
  -e GITHUB_INTEGRATION_API_URL="https://integrations-api-staging.cheetah-koi.ts.net" \
  -e GITHUB_INTEGRATION_CONNECTOR_ID="f603f8b9-bab5-4b02-8c80-35f7aba694c3" \
  -e CHAT_ASSISTANT_API_URL="http://host.docker.internal:3000" \
  -e CHAT_ASSISTANT_PUBLIC_URL="https://chat.globalaegis.net" \
  -e NUAGE_MOCK_IDENTITY_ENABLED=true \
  -e NUAGE_MOCK_IDENTITY_CUSTOMER_ID="xxx" \
  -e NUAGE_MOCK_IDENTITY_USER_ID="xxx" \
  -e NUAGE_MOCK_IDENTITY_WORKSPACE_ID="xxx" \
  -e NUAGE_MOCK_IDENTITY_ORGANIZATION_ID="xxx" \
  mistralai-nuage-worker
```

## Environment Variables

### Core
| Variable | Description | Default |
|----------|-------------|---------|
| `NUAGE_WORKFLOW_NAME` | Workflow name identifier | `__shared-nuage-workflow` |
| `LOG_LEVEL` | Logging level | `INFO` |

### Temporal Payload Encryption (Required)
| Variable | Description | Default |
|----------|-------------|---------|
| `MODE` | Encryption mode: `partial` or `full` | Required |
| `MAIN_KEY` | 32-byte hex encryption key | Required |

Generate a key: `openssl rand -hex 32`

### Integrations API (GitHub)
| Variable | Description | Default |
|----------|-------------|---------|
| `GITHUB_INTEGRATION_API_URL` | Integrations API URL for GitHub auth | `https://integrations-api.mistral.ai` |
| `GITHUB_INTEGRATION_CONNECTOR_ID` | Connector ID (user's GitHub connection) | None |
| `GITHUB_INTEGRATION_CONNECTOR_NAME` | Connector name/type | `github_oauth` |

### Chat Assistant (LeChat)
| Variable | Description | Default |
|----------|-------------|---------|
| `CHAT_ASSISTANT_API_URL` | Internal API URL for chat thread creation | `https://chat.mistral.ai` |
| `CHAT_ASSISTANT_PUBLIC_URL` | Public-facing URL for chat links | `https://chat.mistral.ai` |

#### Local Worker Only
| Variable | Description | Default |
|----------|-------------|---------|
| `CHAT_ASSISTANT_API_KEY` | API key for x-api-key header | `$STAGING_MISTRAL_API_KEY` |

### Mock Identity (Development)
| Variable | Description | Default |
|----------|-------------|---------|
| `NUAGE_MOCK_IDENTITY_ENABLED` | Enable mock identity injection | `false` |
| `NUAGE_MOCK_IDENTITY_CUSTOMER_ID` | Mock customer ID | None |
| `NUAGE_MOCK_IDENTITY_USER_ID` | Mock user ID | None |
| `NUAGE_MOCK_IDENTITY_WORKSPACE_ID` | Mock workspace ID | None |
| `NUAGE_MOCK_IDENTITY_ORGANIZATION_ID` | Mock organization ID | None |

To get your mock identity credentials, open https://console.globalaegis.net/ → DevTools (F12) → Console, run:
```javascript
fetch("/api/users/me").then(r=>r.json()).then(({customer:c,uuid:u,workspace:w,organization:o})=>console.log(`export NUAGE_MOCK_IDENTITY_ENABLED=true NUAGE_MOCK_IDENTITY_CUSTOMER_ID=${c.uuid} NUAGE_MOCK_IDENTITY_USER_ID=${u} NUAGE_MOCK_IDENTITY_WORKSPACE_ID=${w.uuid} NUAGE_MOCK_IDENTITY_ORGANIZATION_ID=${o.uuid}`))
```
Export the output before running the worker.

## Publishing

The nuage plugin is published to Gemfury (private registry).

### Release Process

1. Create and push a release tag:
   ```bash
   git tag workflows-nuage/v0.0.1
   git push origin workflows-nuage/v0.0.1
   ```

2. CI automatically:
   - Builds and publishes the Python package to Gemfury
   - Builds and pushes the worker Docker image to our private registry

### Version Format

Tags must follow: `workflows-nuage/v<semver>` (e.g., `workflows-nuage/v0.0.1`, `workflows-nuage/v0.0.1rc1`)
