#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

export NUAGE_LOCAL_WORKER=true
source scripts/env.sh

trap 'kill -- -$$' SIGINT SIGTERM

exec uv run watchmedo auto-restart --directory ../.. --pattern='*.py' --recursive --kill-after 1 -- \
  uv run python -m mistralai_workflows.plugins.nuage.worker
