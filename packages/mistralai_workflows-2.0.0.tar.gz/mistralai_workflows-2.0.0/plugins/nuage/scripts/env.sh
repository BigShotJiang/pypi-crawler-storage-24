#!/usr/bin/env bash
# Central env configuration. All vars overridable via env or make CLI args.
# Scripts can pre-set vars before sourcing to use context-specific defaults.
# Usage: source env.sh [--validate-only] [--skip-validate]

VALIDATE_ONLY=false
SKIP_VALIDATE=false
for arg in "$@"; do
  case "$arg" in
    --validate-only) VALIDATE_ONLY=true ;;
    --skip-validate) SKIP_VALIDATE=true ;;
  esac
done

MISTRAL_ENV="${MISTRAL_ENV:-staging}"

echo "▸ MISTRAL_ENV=${MISTRAL_ENV}  (override with MISTRAL_ENV=local|staging|prod)"

require_env() {
  local var_name="$1" hint="$2"
  if [[ -z "${!var_name:-}" ]]; then
    echo ""
    echo "❌ ERROR: $var_name is required. $hint"
    echo ""
    exit 1
  fi
}

case "$MISTRAL_ENV" in
  prod)
    export BASE_URL="${BASE_URL:-https://api.mistral.ai}"
    export CHAT_URL="${CHAT_URL:-https://chat.mistral.ai}"
    require_env MISTRAL_API_KEY "Get it from https://console.mistral.ai/"
    ;;
  staging)
    export BASE_URL="${BASE_URL:-https://api.globalaegis.net}"
    export CHAT_URL="${CHAT_URL:-https://chat.globalaegis.net}"
    require_env STAGING_MISTRAL_API_KEY "Get it from https://console.globalaegis.net/ or switch with MISTRAL_ENV=local|prod"
    export MISTRAL_API_KEY="${STAGING_MISTRAL_API_KEY}"
    ;;
  local)
    BRUNO_ENV="$(dirname "${BASH_SOURCE[0]}")/../../../../bruno/mistral-internal/.env"
    if [[ -f "$BRUNO_ENV" ]]; then
      set -a; source "$BRUNO_ENV"; set +a
      echo "Loaded Bruno .env (STAGING_MISTRAL_API_KEY) from $(cd "$(dirname "$BRUNO_ENV")" && pwd)/.env"
    fi
    require_env STAGING_MISTRAL_API_KEY "Get it from https://console.globalaegis.net/"
    export BASE_URL="${BASE_URL:-http://localhost:7444}"
    export CHAT_URL="${CHAT_URL:-}"
    export SERVER_URL="${SERVER_URL:-http://localhost:7444}"
    export DEMIURGE_BASE_URL="${DEMIURGE_BASE_URL:-https://api.globalaegis.net/v1}"
    export DEMIURGE_BEARER_TOKEN="${DEMIURGE_BEARER_TOKEN:-${STAGING_MISTRAL_API_KEY}}"
    ;;
  *)
    echo ""
    echo "❌ ERROR: MISTRAL_ENV must be 'local', 'staging', or 'prod' (got '$MISTRAL_ENV')"
    echo ""
    exit 1
    ;;
esac

export MISTRAL_ENV
export LOG_LEVEL="${LOG_LEVEL:-INFO}"
require_env PROD_MISTRAL_API_KEY "API key for model calls inside the sandbox. Get it from https://console.mistral.ai/"
export PROD_MISTRAL_API_KEY
export DEMIURGE_BASE_URL="${DEMIURGE_BASE_URL:-$BASE_URL/v1}"
export DEMIURGE_BEARER_TOKEN="${DEMIURGE_BEARER_TOKEN-${MISTRAL_API_KEY:-}}"
export SERVER_URL="${SERVER_URL:-$BASE_URL}"
export MISTRAL_CHAT_BASE_URL="${MISTRAL_CHAT_BASE_URL:-${CHAT_URL:-}}"
export ALLOW_OVERRIDE_NAMESPACE="${ALLOW_OVERRIDE_NAMESPACE:-true}"
export NUAGE_WORKFLOW_NAME="${NUAGE_WORKFLOW_NAME:-__dev-shared-nuage-workflow}"

export MODE="${MODE:-partial}"
if [[ -z "${MAIN_KEY:-}" ]]; then
  export MAIN_KEY="$(openssl rand -hex 32)"
  echo ""
  echo "⚠️  WARNING: MAIN_KEY auto-generated. Workflows will fail to decrypt on restart. To persist:"
  echo ""
  echo "export MAIN_KEY=$MAIN_KEY"
  echo ""
else
  export MAIN_KEY
fi

if [[ "$SKIP_VALIDATE" != "true" ]]; then
  VIBE_CONFIG="$HOME/.vibe/config.toml"
  VIBE_ERRORS=()

  case "$MISTRAL_ENV" in
    local)  EXPECTED_API_KEY_VAR="LOCAL_MISTRAL_API_KEY" ;;
    staging) EXPECTED_API_KEY_VAR="STAGING_MISTRAL_API_KEY" ;;
    prod)   EXPECTED_API_KEY_VAR="MISTRAL_API_KEY" ;;
  esac

  if [[ ! -f "$VIBE_CONFIG" ]]; then
    VIBE_ERRORS+=("File not found: $VIBE_CONFIG")
  else
    grep -q '^nuage_enabled\s*=\s*true' "$VIBE_CONFIG" || VIBE_ERRORS+=("nuage_enabled = true")
    grep -q "^nuage_workflow_id\s*=\s*\"$NUAGE_WORKFLOW_NAME\"" "$VIBE_CONFIG" || VIBE_ERRORS+=("nuage_workflow_id = \"$NUAGE_WORKFLOW_NAME\"")
    if [[ "$MISTRAL_ENV" == "local" ]]; then
      grep -q '^nuage_base_url\s*=\s*"http://localhost:7444"' "$VIBE_CONFIG" || VIBE_ERRORS+=("nuage_base_url = \"http://localhost:7444\"")
    else
      grep -q "^nuage_base_url\s*=\s*\"$BASE_URL\"" "$VIBE_CONFIG" || VIBE_ERRORS+=("nuage_base_url = \"$BASE_URL\"")
    fi
    grep -q "^nuage_api_key_env_var\s*=\s*\"$EXPECTED_API_KEY_VAR\"" "$VIBE_CONFIG" || VIBE_ERRORS+=("nuage_api_key_env_var = \"$EXPECTED_API_KEY_VAR\"")
  fi
  if [[ ${#VIBE_ERRORS[@]} -gt 0 ]]; then
    NUAGE_BASE_URL_VAL=$([[ "$MISTRAL_ENV" == "local" ]] && echo "http://localhost:7444" || echo "$BASE_URL")
    echo ""
    echo "❌ ERROR: Vibe config missing required nuage settings. Run:"
    echo ""
    echo "sed -i '' '/^nuage_/d' ~/.vibe/config.toml; printf 'nuage_enabled = true\nnuage_workflow_id = \"$NUAGE_WORKFLOW_NAME\"\nnuage_base_url = \"$NUAGE_BASE_URL_VAL\"\nnuage_api_key_env_var = \"$EXPECTED_API_KEY_VAR\"\n' | cat - ~/.vibe/config.toml > /tmp/vc && mv /tmp/vc ~/.vibe/config.toml"
    echo ""
    exit 1
  fi

  if [[ "$MISTRAL_ENV" == "local" ]]; then
    echo ""
    echo "⚠️  WARNING: LeChat stream does not work in local mode. Chat URLs will not show the live stream."
    echo "Use MISTRAL_ENV=staging for full LeChat support."
    echo ""
  fi

  if [[ "$MISTRAL_ENV" == "local" || "${NUAGE_LOCAL_WORKER:-}" == "true" ]]; then
    if [[ -z "${NUAGE_MOCK_IDENTITY_ENABLED:-}" || "${NUAGE_MOCK_IDENTITY_ENABLED}" != "true" ]]; then
      echo ""
      echo "❌ ERROR: Mock identity required for local development."
      echo ""
      echo "To get your identity credentials:"
      echo "1. Open https://console.globalaegis.net/ (staging) or https://console.mistral.ai/ (prod)"
      echo "2. Open browser DevTools (F12) → Console"
      echo "3. Run:"
      echo ""
      echo 'fetch("/api/users/me").then(r=>r.json()).then(({customer:c,uuid:u,workspace:w,organization:o})=>console.log(`export NUAGE_MOCK_IDENTITY_ENABLED=true NUAGE_MOCK_IDENTITY_CUSTOMER_ID=${c.uuid} NUAGE_MOCK_IDENTITY_USER_ID=${u} NUAGE_MOCK_IDENTITY_WORKSPACE_ID=${w.uuid} NUAGE_MOCK_IDENTITY_ORGANIZATION_ID=${o.uuid}`))'
      echo ""
      echo "4. Export the output and re-run."
      echo ""
      exit 1
    fi
    require_env NUAGE_MOCK_IDENTITY_CUSTOMER_ID "Required when mock identity is enabled"
  fi
fi

[[ "$VALIDATE_ONLY" == "true" ]] && return 0

export NUAGE_MOCK_IDENTITY_ENABLED
export NUAGE_MOCK_IDENTITY_CUSTOMER_ID
export NUAGE_MOCK_IDENTITY_USER_ID="${NUAGE_MOCK_IDENTITY_USER_ID:-}"
export NUAGE_MOCK_IDENTITY_WORKSPACE_ID="${NUAGE_MOCK_IDENTITY_WORKSPACE_ID:-}"
export NUAGE_MOCK_IDENTITY_ORGANIZATION_ID="${NUAGE_MOCK_IDENTITY_ORGANIZATION_ID:-}"

export GITHUB_INTEGRATION_API_URL="${GITHUB_INTEGRATION_API_URL:-https://integrations-api-staging.cheetah-koi.ts.net}"
export GITHUB_INTEGRATION_CONNECTOR_ID="${GITHUB_INTEGRATION_CONNECTOR_ID:-019c9068-e98d-7235-bb61-3112bae0134e}"
export GITHUB_INTEGRATION_CONNECTOR_NAME="${GITHUB_INTEGRATION_CONNECTOR_NAME:-github_oauth}"

export CHAT_ASSISTANT_API_URL="${CHAT_ASSISTANT_API_URL:-https://chat.globalaegis.net}"
export CHAT_ASSISTANT_PUBLIC_URL="${CHAT_ASSISTANT_PUBLIC_URL:-${CHAT_URL:-https://chat.globalaegis.net}}"
export CHAT_ASSISTANT_API_KEY="${CHAT_ASSISTANT_API_KEY:-${STAGING_MISTRAL_API_KEY:-}}"

check_reachable() {
  curl -s --connect-timeout 2 "$1" >/dev/null 2>&1 || echo "⚠️  Cannot reach $1 (enable Tailscale?)"
}
check_reachable "$GITHUB_INTEGRATION_API_URL"
check_reachable "$CHAT_ASSISTANT_API_URL"

mask() { local v="$1"; [[ ${#v} -ge 4 ]] && echo "***${v: -4}" || echo "***"; }

echo "─── env ───────────────────────────────────────────"
echo "  MISTRAL_ENV             = $MISTRAL_ENV"
echo "  LOG_LEVEL               = $LOG_LEVEL"
echo "  MODE                    = $MODE"
echo "  NUAGE_WORKFLOW_NAME     = $NUAGE_WORKFLOW_NAME"
echo ""
echo "  MISTRAL_API_KEY         = $(mask "${MISTRAL_API_KEY:-}")"
echo "  STAGING_MISTRAL_API_KEY = $(mask "${STAGING_MISTRAL_API_KEY:-}")"
echo "  PROD_MISTRAL_API_KEY    = $(mask "$PROD_MISTRAL_API_KEY")"
echo "  MAIN_KEY                = $(mask "$MAIN_KEY")"
echo ""
echo "  BASE_URL                = $BASE_URL"
echo "  SERVER_URL              = $SERVER_URL"
echo "  DEMIURGE_BASE_URL       = $DEMIURGE_BASE_URL"
echo "  DEMIURGE_BEARER_TOKEN   = $(mask "$DEMIURGE_BEARER_TOKEN")"
echo ""
echo "  GITHUB_INTEGRATION_API_URL = $GITHUB_INTEGRATION_API_URL"
echo ""
echo "  CHAT_ASSISTANT_API_URL  = $CHAT_ASSISTANT_API_URL"
echo "  CHAT_ASSISTANT_PUBLIC_URL = $CHAT_ASSISTANT_PUBLIC_URL"
echo "  CHAT_ASSISTANT_API_KEY  = $(mask "${CHAT_ASSISTANT_API_KEY:-}")"
echo "───────────────────────────────────────────────────"
if [[ "$MISTRAL_ENV" == "local" ]]; then
  echo ""
  echo "─── Vibe Usage ────────────────────────────────────"
  echo "  Run in your terminal before using Vibe:"
  echo "  export LOCAL_MISTRAL_API_KEY=${MISTRAL_API_KEY}"
  echo ""
  echo "  ⚠️  LeChat URLs will NOT show the stream in local mode."
  echo "  Use Temporal UI to monitor workflows: http://localhost:8080"
  echo "───────────────────────────────────────────────────"
fi
