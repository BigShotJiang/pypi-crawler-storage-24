#!/usr/bin/env python
# /// script
# requires-python = ">=3.10"
# dependencies = ["cryptography"]
# ///
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


def main() -> None:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    print(private_pem.decode("utf-8"))  # noqa: T201


if __name__ == "__main__":
    main()
