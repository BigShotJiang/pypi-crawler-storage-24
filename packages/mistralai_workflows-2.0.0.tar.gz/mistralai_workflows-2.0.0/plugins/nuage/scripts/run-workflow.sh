#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

: "${INPUT:?INPUT is required (e.g. INPUT='{\"prompt\":\"...\"}')}"

MISTRAL_ENV="${MISTRAL_ENV:-staging}"

case "$MISTRAL_ENV" in
  prod)
    BASE_URL="${BASE_URL:-https://api.mistral.ai}"
    : "${MISTRAL_API_KEY:?MISTRAL_API_KEY is required for prod}"
    ;;
  staging)
    BASE_URL="${BASE_URL:-https://api.globalaegis.net}"
    : "${STAGING_MISTRAL_API_KEY:?STAGING_MISTRAL_API_KEY is required for staging}"
    MISTRAL_API_KEY="${STAGING_MISTRAL_API_KEY}"
    ;;
  local)
    BASE_URL="${BASE_URL:-http://localhost:7444}"
    BRUNO_ENV="$(dirname "$0")/../../../../bruno/mistral-internal/.env"
    if [[ -f "$BRUNO_ENV" ]]; then
      set -a; source "$BRUNO_ENV"; set +a
    fi
    : "${MISTRAL_API_KEY:?MISTRAL_API_KEY is required for local}"
    ;;
  *)
    echo "Error: MISTRAL_ENV must be 'local', 'staging', or 'prod'" >&2
    exit 1
    ;;
esac

NUAGE_WORKFLOW_NAME="${NUAGE_WORKFLOW_NAME:-__dev-shared-nuage-workflow}"

mask() { local v="$1"; [[ ${#v} -ge 4 ]] && echo "***${v: -4}" || echo "***"; }

echo "▸ MISTRAL_ENV=$MISTRAL_ENV"
echo "▸ BASE_URL=$BASE_URL"
echo "▸ MISTRAL_API_KEY=$(mask "$MISTRAL_API_KEY")"
echo "▸ NUAGE_WORKFLOW_NAME=$NUAGE_WORKFLOW_NAME"
echo ""

exec uv run python -m mistralai_workflows.scripts.dev_interactive_workflow_cli \
  "$NUAGE_WORKFLOW_NAME" --input "$INPUT" --base-url "$BASE_URL" --api-key "$MISTRAL_API_KEY"
