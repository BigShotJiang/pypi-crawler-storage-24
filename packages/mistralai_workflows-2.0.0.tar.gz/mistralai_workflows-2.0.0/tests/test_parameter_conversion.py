"""Tests for parameter conversion functions.

Tests convert_params_dict_to_user_args which validates input using generated
Pydantic models and converts to function arguments.
"""

import pytest
from pydantic import BaseModel, ValidationError

from mistralai_workflows.core.definition.validation.parameter_conversion import (
    convert_params_dict_to_user_args,
    convert_query_update_result_to_temporal_format,
    convert_result_to_temporal_format,
)
from mistralai_workflows.core.definition.validation.schema_generator import (
    generate_pydantic_model_from_params,
    generate_pydantic_model_from_return_type,
)


class UserModel(BaseModel):
    name: str
    value: int


class NestedModel(BaseModel):
    outer: str
    inner: UserModel


class TestConvertParamsDictToUserArgs:
    def test_rejects_extra_fields(self):
        def my_func(name: str) -> None:
            pass

        model = generate_pydantic_model_from_params(
            "my_func",
            {"name": str},
            func=my_func,
        )

        with pytest.raises(ValidationError) as exc_info:
            convert_params_dict_to_user_args(
                {"name": "test", "extra": "bad"},
                {"name": str},
                model,
            )

        error_msg = str(exc_info.value).lower()
        assert "extra" in error_msg or "additional" in error_msg

    def test_accepts_valid_input(self):
        def my_func(name: str) -> None:
            pass

        model = generate_pydantic_model_from_params(
            "my_func",
            {"name": str},
            func=my_func,
        )

        result = convert_params_dict_to_user_args(
            {"name": "test"},
            {"name": str},
            model,
        )

        assert result == ("test",)

    def test_returns_empty_tuple_when_no_params(self):
        model = generate_pydantic_model_from_params("my_func", {})
        result = convert_params_dict_to_user_args({}, {}, model)
        assert result == ()

    def test_multiple_params_returns_tuple_in_order(self):
        def my_func(name: str, count: int) -> None:
            pass

        model = generate_pydantic_model_from_params(
            "my_func",
            {"name": str, "count": int},
            func=my_func,
        )

        result = convert_params_dict_to_user_args(
            {"name": "test", "count": 42},
            {"name": str, "count": int},
            model,
        )

        assert result == ("test", 42)

    def test_single_basemodel_param_returns_model_instance(self):
        model = generate_pydantic_model_from_params(
            "my_func",
            {"data": UserModel},
            func=lambda data: None,
        )

        result = convert_params_dict_to_user_args(
            {"name": "test", "value": 42},
            {"data": UserModel},
            model,
        )

        assert len(result) == 1
        assert isinstance(result[0], UserModel)
        assert result[0].name == "test"
        assert result[0].value == 42

    def test_nested_model_validation(self):
        model = generate_pydantic_model_from_params(
            "my_func",
            {"data": NestedModel},
            func=lambda data: None,
        )

        result = convert_params_dict_to_user_args(
            {"outer": "hello", "inner": {"name": "test", "value": 10}},
            {"data": NestedModel},
            model,
        )

        assert len(result) == 1
        assert isinstance(result[0], NestedModel)
        assert result[0].outer == "hello"
        assert result[0].inner.name == "test"


class TestConvertResultToTemporalFormat:
    def test_none_result_returns_none(self):
        result = convert_result_to_temporal_format(None, None)
        assert result is None

    def test_basemodel_result_returns_dict(self):
        model_instance = UserModel(name="test", value=42)
        result = convert_result_to_temporal_format(model_instance, None)
        assert result == {"name": "test", "value": 42}

    def test_primitive_with_output_model_wraps_in_result(self):
        output_model = generate_pydantic_model_from_return_type("my_func", int)
        result = convert_result_to_temporal_format(42, output_model)
        assert result == {"result": 42}

    def test_primitive_without_output_model_returns_as_is(self):
        result = convert_result_to_temporal_format(42, None)
        assert result == 42

    def test_dict_with_output_model_validates_and_dumps(self):
        result = convert_result_to_temporal_format(
            {"name": "test", "value": 10},
            UserModel,
        )
        assert result == {"name": "test", "value": 10}


class TestConvertQueryUpdateResultToTemporalFormat:
    def test_none_result_returns_none(self):
        result = convert_query_update_result_to_temporal_format(None, None)
        assert result is None

    def test_basemodel_result_returns_dict(self):
        model_instance = UserModel(name="test", value=42)
        result = convert_query_update_result_to_temporal_format(model_instance, None)
        assert result == {"name": "test", "value": 42}

    def test_primitive_returns_as_is(self):
        result = convert_query_update_result_to_temporal_format(42, None)
        assert result == 42

    def test_string_returns_as_is(self):
        result = convert_query_update_result_to_temporal_format("hello", None)
        assert result == "hello"
