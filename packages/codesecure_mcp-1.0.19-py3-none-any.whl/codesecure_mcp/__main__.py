"""
CodeSecure MCP Server - Entry Point.

This allows running the server directly via:
python -m codesecure_mcp
"""
from codesecure_mcp.scanner.server import main

if __name__ == "__main__":
    main()
