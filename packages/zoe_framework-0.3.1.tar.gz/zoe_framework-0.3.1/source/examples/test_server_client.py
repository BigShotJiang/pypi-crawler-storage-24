import asyncio
import httpx
import time

async def fazer_requisicao(client: httpx.AsyncClient, i: int, resultados: list):
    try:
        inicio = time.time()
        response = await client.get("http://127.0.0.1:8080/user/hello", timeout=30)
        fim = time.time()
        resultados.append({
            "status": response.status_code,
            "tempo": fim - inicio,
            "erro": None
        })
    except Exception as e:
        resultados.append({
            "status": None,
            "tempo": None,
            "erro": str(e)
        })

async def testar_carga(n: int):
    resultados = []
    inicio = time.time()

    async with httpx.AsyncClient() as client:
        tasks = [fazer_requisicao(client, i, resultados) for i in range(n)]
        await asyncio.gather(*tasks)

    fim = time.time()
    tempo_total = fim - inicio

    sucesso   = [r for r in resultados if r["status"] == 200]
    falhas    = [r for r in resultados if r["erro"] is not None]
    tempo_med = sum(r["tempo"] for r in sucesso) / len(sucesso) if sucesso else 0

    print(f"\n{'─' * 50}")
    print(f"  Requisições:    {n}")
    print(f"  Sucesso:        {len(sucesso)}/{n}")
    print(f"  Falhas:         {len(falhas)}")
    print(f"  Tempo total:    {tempo_total:.2f}s")
    print(f"  Tempo médio:    {tempo_med:.2f}s")
    print(f"{'─' * 50}")

    return len(falhas) == 0

async def main():
    cargas = [10, 50, 100, 250, 500, 1000, 5000]

    print("Teste de carga — Zoe Framework")
    print("Handler: asyncio.sleep(1) por requisição\n")

    for n in cargas:
        print(f"Testando {n} requisições simultâneas...")
        ok = await testar_carga(n)
        if not ok:
            print(f"  ⚠ Falhas detectadas em {n} requisições — parando teste.")
            break
        await asyncio.sleep(2)  # respiro entre rodadas

asyncio.run(main())
