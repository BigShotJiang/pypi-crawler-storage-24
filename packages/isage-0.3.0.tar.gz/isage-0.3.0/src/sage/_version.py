"""Version information for sage package."""

# Single version source — updated by release tooling; do not edit manually.
__version__ = "0.3.0"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
