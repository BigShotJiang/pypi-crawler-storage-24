# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, TypedDict

__all__ = ["DeploymentArchiveParams"]


class DeploymentArchiveParams(TypedDict, total=False):
    expand: List[Literal["device", "release", "config_instances"]]
    """Fields to expand on the deployment resource."""
