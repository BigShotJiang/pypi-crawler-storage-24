"""Urock Codec Python Bindings

Compression and decompression library with domain-optimized JSON compression.
"""

from urock_codec._urock_codec import (
    Compression,
    Compressor,
    CodecError,
    OptimizeError,
    compress,
    decompress,
)

__all__ = [
    "Compression",
    "Compressor",
    "CodecError",
    "OptimizeError",
    "compress",
    "decompress",
]
