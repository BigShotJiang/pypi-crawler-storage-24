# Claude Code

Shared project instructions live in @AGENTS.md.
