class LogModel:
    pass
