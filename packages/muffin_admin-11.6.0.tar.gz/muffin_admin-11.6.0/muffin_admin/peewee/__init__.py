"""Peewee ORM Support."""

from __future__ import annotations

from functools import partial
from typing import TYPE_CHECKING

import marshmallow as ma
import peewee as pw
from muffin_peewee import JSONLikeField
from muffin_rest import APIError, PWRESTHandler
from muffin_rest.peewee.filters import PWFilter
from muffin_rest.peewee.options import PWRESTOptions
from muffin_rest.peewee.types import TVCollection, TVResource
from peewee import CompositeKey

from muffin_admin.handler import AdminHandler, AdminOptions
from muffin_admin.peewee.schemas import PeeweeModelSchema
from muffin_admin.peewee.utils import composite_key_to_id, id_to_composite_key

if TYPE_CHECKING:
    from muffin import Request
    from muffin_rest.filters import Filter

    from muffin_admin.types import TRAInfo


class PWAdminOptions(AdminOptions, PWRESTOptions):
    """Keep PWAdmin options."""

    def setup(self, cls):
        """Auto insert filter by id."""

        # Make a copy of schema_fields to avoid modifying the class variable in subclasses
        self.__dict__["schema_fields"] = dict(self.schema_fields)

        super(PWAdminOptions, self).setup(cls)

        pk = self.model_pk
        if isinstance(pk, CompositeKey):
            return

        self.id = self.model_pk.name
        for flt in self.filters:
            name = flt

            if isinstance(flt, PWFilter):
                name = flt.name

            elif isinstance(flt, tuple):
                name = flt[0]

            if name == self.id:
                break

        else:
            self.filters = [PWFilter(self.id, field=self.model_pk), *self.filters]  # type: ignore[]

    def setup_schema_meta(self, _):
        """Prepare a schema."""
        pk = self.model_pk

        if isinstance(pk, CompositeKey):
            self.schema_fields.setdefault(
                "id",
                ma.fields.Function(partial(composite_key_to_id, pk), dump_only=True),
            )

        return type(
            "Meta",
            (object,),
            dict(
                {"unknown": self.schema_unknown, "model": self.model},
                **self.schema_meta,
            ),
        )

    def default_sort(self: PWAdminOptions):
        """Default sorting."""
        fields = self.model._meta.fields  # type: ignore[]
        sorting: list = [name for name in self.columns if name in fields]
        if sorting:
            sorting[0] = (sorting[0], {"default": "desc"})
            self.sorting = sorting  # type: ignore[assignment]


class PWAdminHandler(
    AdminHandler[TVResource, TVCollection], PWRESTHandler[TVResource, TVCollection]
):
    """Work with Peewee Models."""

    meta_class = PWAdminOptions
    meta: PWAdminOptions  # type: ignore[override]

    class Meta(AdminHandler.Meta):
        schema_base = PeeweeModelSchema

    async def prepare_resource(self, request: Request) -> TVResource | None:
        """Load a resource."""
        key = request["path_params"].get("id")
        if not key:
            return None

        meta = self.meta
        model_pk = meta.model_pk
        if isinstance(model_pk, CompositeKey):
            keys = id_to_composite_key(model_pk, key)
            query = self.collection.filter(**keys)
        else:
            query = self.collection.where(model_pk == key)

        try:
            resource = await meta.manager.fetchone(query)
        except Exception:  # noqa: BLE001
            resource = None

        if resource is None:
            raise APIError.NOT_FOUND("Resource not found")

        return resource

    def get_selected(self, request: Request):
        """Get selected objects."""
        keys = request.query.getall("ids")
        qs = self.collection
        if keys:
            qs = qs.where(self.meta.model_pk.in_(keys))  # type: ignore[]

        return qs

    @classmethod
    def to_ra_field(cls, field: ma.fields.Field, source: str) -> TRAInfo:
        """Setup RA fields."""
        model_field = getattr(cls.meta.model, field.attribute or source, None)
        ra_type, props = super(PWAdminHandler, cls).to_ra_field(field, source)
        refs = cls.meta.ra_refs

        if model_field and isinstance(model_field, pw.Field):
            if model_field.choices:
                ra_type, props = (
                    "SelectField",
                    {
                        "choices": [{"id": c[0], "name": c[1]} for c in model_field.choices],
                        **props,
                    },
                )

            elif isinstance(model_field, JSONLikeField) or model_field.field_type.lower() == "json":
                ra_type = "JsonField"

            elif isinstance(model_field, pw.ForeignKeyField) and source in refs:
                ref_data = refs[source]
                rel_model = model_field.rel_model
                return "FKField", dict(
                    props,
                    refSource=ref_data.get("source") or model_field.rel_field.name,
                    refKey=ref_data.get("key") or rel_model._meta.primary_key.name,
                    reference=ref_data.get("reference") or rel_model._meta.table_name,
                )

        return ra_type, props

    @classmethod
    def to_ra_input(  # noqa: PLR0911
        cls, field: ma.fields.Field, source: str, *, resource: bool = True
    ) -> TRAInfo:
        """Setup RA inputs."""
        model_field = resource and getattr(
            cls.meta.model, field.attribute or field.metadata.get("name") or source, None
        )
        ra_type, props = super(PWAdminHandler, cls).to_ra_input(field, source)
        refs = cls.meta.ra_refs

        if model_field and isinstance(model_field, pw.Field):
            if model_field.choices:
                return "SelectInput", dict(
                    props,
                    choices=[{"id": c[0], "name": c[1]} for c in model_field.choices],
                )

            if isinstance(model_field, pw.TextField):
                return "TextInput", dict(props, multiline=True)

            if isinstance(model_field, pw.DateTimeField) and isinstance(field, ma.fields.DateTime):
                dtformat = field.format or cls.meta.Schema.opts.datetimeformat  # type: ignore[]
                if dtformat == "timestamp_ms":
                    return "TimestampInput", dict(props, ms=True)
                elif dtformat == "timestamp":
                    return "TimestampInput", dict(props, ms=False)

                return ra_type, props

            if isinstance(model_field, JSONLikeField) or model_field.field_type.lower() == "json":
                return "JsonInput", props

            if isinstance(model_field, pw.ForeignKeyField) and source in refs:
                ref_data = refs[source]
                rel_model = model_field.rel_model
                return "FKInput", dict(
                    props,
                    refSource=ref_data.get("source") or model_field.rel_field.name,
                    refKey=ref_data.get("key") or rel_model._meta.primary_key.name,
                    reference=ref_data.get("reference") or rel_model._meta.table_name,
                )

        return ra_type, props

    @classmethod
    def to_ra_filter(cls, flt: Filter) -> TRAInfo:
        meta = cls.meta
        field = flt.field

        if isinstance(field, pw.Field) and field.choices:
            source = flt.name
            ra_type, props = (
                "SelectArrayInput",
                {
                    "source": source,
                    "choices": [{"id": c[0], "name": c[1]} for c in field.choices],
                },
            )
            custom = meta.ra_filters.get(source)
            if custom:
                ra_type, props = custom[0], {**props, **custom[1]}

            if source in meta.ra_filters_always_on:
                props["alwaysOn"] = True  # type: ignore[assignment]
                props["resettable"] = True  # type: ignore[assignment]

            return ra_type, props

        return super(PWAdminHandler, cls).to_ra_filter(flt)


class PWSearchFilter(PWFilter):
    """Search in query by value."""

    async def filter(self, collection: pw.ModelSelect, *ops: tuple, **_) -> pw.ModelSelect:
        """Apply the filters to Peewee QuerySet.."""
        _, value = ops[0]
        column = self.field
        return collection.where(column.contains(value))
