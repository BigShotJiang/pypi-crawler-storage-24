# Standalone tools

This document showcases standalone tools from the examples directory. Each tool is a complete, runnable script that demonstrates specific features of the AIR SDK. Make sure to set your `AIR_API_KEY` and optionally `AIR_BASE_URL` in your environment or a `.env` file before running these scripts. Complete runnable scripts from the
[`examples/`](https://github.com/Denario-private/air-sdk/tree/main/examples)
directory.

## Text enhancement

Enhances input text by retrieving and summarizing referenced papers from sources like arXiv, bioRxiv, PubMed, and PDFs, providing enriched context for AI processing.

```python
--8<-- "examples/enhance.py"
```

## OCR

Downloads a paper from arXiv and performs OCR to extract the full text, returning both plain text and structured markdown that preserves headings, equations, and tables. Accepts an optional arXiv URL as a command-line argument.

```python
--8<-- "examples/ocr_arxiv.py"
```

## One-shot execution

Executes a free-form task by leveraging AI agents with local code execution capabilities, enabling dynamic script generation and execution in an isolated environment.

```python
--8<-- "examples/one_shot.py"
```

## Deep research

Performs in-depth research with a planning phase followed by multi-step execution using specialized AI agents, such as generating synthetic data and conducting statistical analysis in fields like biostatistics.

```python
--8<-- "examples/deep_research_biostatistics.py"
```

## Review

Reviews a scientific paper by downloading it from arXiv and using the Skepthical engine to generate a detailed review report, including analysis of figures, statements, and mathematical derivations.

```python
--8<-- "examples/one_shot.py"
```

## Keywords

Extracts relevant keywords from input text using specialized vocabularies such as UNESCO or AAS, aiding in categorization and indexing of academic content.

```python
--8<-- "examples/keywords_unesco.py"
```

