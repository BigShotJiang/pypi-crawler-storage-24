"""
Entry point for: py -m bytecraft file.bc

Usage:
  bytecraft <script.bc>             Run the script normally
  bytecraft --dry-run <script.bc>   Preview what the script would do (no writes)
"""

import sys
from .interpreter import run


def main() -> None:
    args = sys.argv[1:]

    if not args:
        print("Usage: bytecraft [--dry-run] <script.bc>")
        sys.exit(1)

    dry_run = False
    if args[0] == "--dry-run":
        dry_run = True
        args = args[1:]

    if not args:
        print("Error: no script file provided.")
        print("Usage: bytecraft [--dry-run] <script.bc>")
        sys.exit(1)

    script = args[0]
    run(script, dry_run=dry_run)


if __name__ == "__main__":
    main()
