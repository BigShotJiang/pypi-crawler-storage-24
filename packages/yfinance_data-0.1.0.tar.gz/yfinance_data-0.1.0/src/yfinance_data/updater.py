"""Nightly updater: fetch latest daily data and merge into R2."""

import tempfile
import time
from pathlib import Path

import pandas as pd
import yfinance as yf

from yfinance_data.r2 import R2
from yfinance_data.symbols import fetch_symbols


def fetch_latest(symbols: list[str], batch_size: int = 50, pause: float = 1.0) -> dict[str, pd.DataFrame]:
    """Fetch last 5 days of data for all symbols. Returns {symbol: DataFrame}."""
    results = {}
    total_batches = -(-len(symbols) // batch_size)

    for i in range(0, len(symbols), batch_size):
        batch = symbols[i : i + batch_size]
        batch_num = i // batch_size + 1
        print(f"[{batch_num}/{total_batches}] Fetching {len(batch)} symbols...")

        try:
            data = yf.download(
                batch,
                period="5d",
                auto_adjust=True,
                threads=True,
                group_by="ticker",
            )
        except Exception as e:
            print(f"  Batch failed: {e}")
            continue

        for symbol in batch:
            try:
                df = data[symbol] if len(batch) > 1 else data
                df = df.dropna(how="all")
                if not df.empty:
                    results[symbol] = df
            except (KeyError, Exception):
                pass  # Symbol delisted or missing — skip silently

        if batch_num < total_batches:
            time.sleep(pause)

    return results


def merge_and_upload(new_data: dict[str, pd.DataFrame], r2: R2, tmp_dir: Path) -> tuple[int, int]:
    """Merge new data with existing R2 parquets and upload. Returns (success, fail) counts."""
    success = 0
    fail = 0

    for symbol, new_df in new_data.items():
        try:
            key = f"daily/{symbol}.parquet"
            local = tmp_dir / f"{symbol}.parquet"

            # Try to download existing data from R2
            try:
                r2.download(key, local)
                existing = pd.read_parquet(local)
                combined = pd.concat([existing, new_df])
                combined = combined[~combined.index.duplicated(keep="last")]
                combined = combined.sort_index()
            except Exception:
                combined = new_df

            combined.to_parquet(local)
            r2.upload(local, key)
            success += 1
        except Exception as e:
            print(f"  Failed {symbol}: {e}")
            fail += 1

    return success, fail


def main():
    from dotenv import load_dotenv

    load_dotenv()

    print("Fetching symbols...")
    symbols = fetch_symbols()
    print(f"Found {len(symbols)} symbols")

    print("Fetching latest data from yfinance...")
    new_data = fetch_latest(symbols)
    print(f"Got data for {len(new_data)}/{len(symbols)} symbols")

    print("Merging and uploading to R2...")
    r2 = R2.from_env()
    with tempfile.TemporaryDirectory() as tmp:
        success, fail = merge_and_upload(new_data, r2, Path(tmp))

    print(f"Done! Uploaded: {success}, Failed: {fail}")


if __name__ == "__main__":
    main()
