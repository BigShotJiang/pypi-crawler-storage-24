"""Client library to read market data from R2."""

import io
import json
from concurrent.futures import ThreadPoolExecutor

import pandas as pd
from dotenv import load_dotenv

from yfinance_data.r2 import R2

_r2: R2 | None = None


def _get_r2() -> R2:
    global _r2
    if _r2 is None:
        load_dotenv()
        _r2 = R2.from_env()
    return _r2


def _read_parquet(key: str) -> pd.DataFrame | None:
    try:
        resp = _get_r2().s3.get_object(Bucket=_get_r2().bucket, Key=key)
        return pd.read_parquet(io.BytesIO(resp["Body"].read()))
    except Exception:
        return None


def _read_json(key: str) -> dict | None:
    try:
        resp = _get_r2().s3.get_object(Bucket=_get_r2().bucket, Key=key)
        return json.loads(resp["Body"].read())
    except Exception:
        return None


def _filter_dates(df: pd.DataFrame | None, start: str | None, end: str | None) -> pd.DataFrame | None:
    if df is None or df.empty:
        return df
    if start:
        df = df[df.index >= start]
    if end:
        df = df[df.index <= end]
    return df


# --- Public API ---


def history(
    symbol: str | list[str],
    start: str | None = None,
    end: str | None = None,
) -> pd.DataFrame | dict[str, pd.DataFrame]:
    """Daily OHLCV history."""
    if isinstance(symbol, list):
        with ThreadPoolExecutor(max_workers=10) as pool:
            futures = {s: pool.submit(history, s, start, end) for s in symbol}
            return {s: f.result() for s, f in futures.items() if f.result() is not None}
    return _filter_dates(_read_parquet(f"daily/{symbol}.parquet"), start, end)


def dividends(symbol: str) -> pd.DataFrame | None:
    return _read_parquet(f"dividends/{symbol}.parquet")


def splits(symbol: str) -> pd.DataFrame | None:
    return _read_parquet(f"splits/{symbol}.parquet")


def financials(symbol: str, quarterly: bool = False) -> pd.DataFrame | None:
    prefix = "financials_quarterly" if quarterly else "financials"
    return _read_parquet(f"{prefix}/{symbol}.parquet")


def balance_sheet(symbol: str, quarterly: bool = False) -> pd.DataFrame | None:
    prefix = "balance_sheet_quarterly" if quarterly else "balance_sheet"
    return _read_parquet(f"{prefix}/{symbol}.parquet")


def cashflow(symbol: str, quarterly: bool = False) -> pd.DataFrame | None:
    prefix = "cashflow_quarterly" if quarterly else "cashflow"
    return _read_parquet(f"{prefix}/{symbol}.parquet")


def info(symbol: str) -> dict | None:
    return _read_json(f"info/{symbol}.json")


def institutional_holders(symbol: str) -> pd.DataFrame | None:
    return _read_parquet(f"institutional_holders/{symbol}.parquet")


def recommendations(symbol: str) -> pd.DataFrame | None:
    return _read_parquet(f"recommendations/{symbol}.parquet")


def options(symbol: str) -> pd.DataFrame | None:
    return _read_parquet(f"options/{symbol}.parquet")


def earnings(symbol: str) -> pd.DataFrame | None:
    return _read_parquet(f"earnings/{symbol}.parquet")


def symbols() -> list[str]:
    """List all available symbols."""
    r2 = _get_r2()
    paginator = r2.s3.get_paginator("list_objects_v2")
    result = []
    for page in paginator.paginate(Bucket=r2.bucket, Prefix="daily/"):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".parquet"):
                result.append(key.removeprefix("daily/").removesuffix(".parquet"))
    return sorted(result)
