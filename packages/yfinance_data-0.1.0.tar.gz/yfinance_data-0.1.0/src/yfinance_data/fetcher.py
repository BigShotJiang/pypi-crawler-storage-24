import time
from pathlib import Path

import pandas as pd
import yfinance as yf


def fetch_daily_history(
    symbols: list[str],
    output_dir: Path,
    batch_size: int = 50,
    pause: float = 1.0,
    end: str | None = None,
) -> list[str]:
    """Fetch full daily OHLCV history and save as per-symbol parquet files.

    Returns list of symbols that failed.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    existing = {p.stem for p in output_dir.glob("*.parquet")}
    remaining = [s for s in symbols if s not in existing]
    if existing:
        print(f"Skipping {len(existing)} already fetched, {len(remaining)} remaining")

    failed = []
    total_batches = -(-len(remaining) // batch_size)

    for i in range(0, len(remaining), batch_size):
        batch = remaining[i : i + batch_size]
        batch_num = i // batch_size + 1
        print(f"[{batch_num}/{total_batches}] Fetching {len(batch)} symbols...")

        try:
            data = yf.download(
                batch,
                period="max",
                end=end,
                auto_adjust=True,
                threads=True,
                group_by="ticker",
            )
        except Exception as e:
            print(f"  Batch failed: {e}")
            failed.extend(batch)
            continue

        saved = 0
        for symbol in batch:
            try:
                df = data[symbol] if len(batch) > 1 else data
                df = df.dropna(how="all")
                if not df.empty:
                    df.to_parquet(output_dir / f"{symbol}.parquet")
                    saved += 1
            except (KeyError, Exception):
                failed.append(symbol)

        print(f"  Saved {saved}/{len(batch)} symbols")

        if batch_num < total_batches:
            time.sleep(pause)

    return failed
