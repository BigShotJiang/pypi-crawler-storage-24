import os
from pathlib import Path

import boto3


class R2:
    def __init__(self, endpoint: str, access_key: str, secret_key: str, bucket: str):
        self.s3 = boto3.client(
            "s3",
            endpoint_url=endpoint,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name="auto",
        )
        self.bucket = bucket

    @classmethod
    def from_env(cls) -> "R2":
        return cls(
            endpoint=os.environ["R2_ENDPOINT"],
            access_key=os.environ["R2_ACCESS_KEY_ID"],
            secret_key=os.environ["R2_SECRET_ACCESS_KEY"],
            bucket=os.environ["R2_BUCKET"],
        )

    def download(self, key: str, local_path: Path):
        local_path.parent.mkdir(parents=True, exist_ok=True)
        self.s3.download_file(self.bucket, key, str(local_path))

    def upload(self, local_path: Path, key: str):
        self.s3.upload_file(str(local_path), self.bucket, key)

    def exists(self, key: str) -> bool:
        try:
            self.s3.head_object(Bucket=self.bucket, Key=key)
            return True
        except self.s3.exceptions.ClientError:
            return False
