"""Fetch non-price data (dividends, financials, etc.) and upload to R2."""

import io
import json
import time

import pandas as pd
import yfinance as yf

from yfinance_data.r2 import R2
from yfinance_data.symbols import fetch_symbols

# (ticker attribute, R2 prefix)
DF_TYPES = [
    ("dividends", "dividends"),
    ("splits", "splits"),
    ("financials", "financials"),
    ("quarterly_financials", "financials_quarterly"),
    ("balance_sheet", "balance_sheet"),
    ("quarterly_balance_sheet", "balance_sheet_quarterly"),
    ("cashflow", "cashflow"),
    ("quarterly_cashflow", "cashflow_quarterly"),
    ("institutional_holders", "institutional_holders"),
    ("recommendations", "recommendations"),
    ("earnings_dates", "earnings"),
]


def _put_df(df: pd.DataFrame | pd.Series | None, r2: R2, key: str):
    if df is None or df.empty:
        return
    if isinstance(df, pd.Series):
        df = df.to_frame()
    buf = io.BytesIO()
    df.to_parquet(buf)
    r2.s3.put_object(Bucket=r2.bucket, Key=key, Body=buf.seek(0) or buf.read())


def _put_json(data: dict | None, r2: R2, key: str):
    if not data:
        return
    r2.s3.put_object(
        Bucket=r2.bucket,
        Key=key,
        Body=json.dumps(data, default=str).encode(),
    )


def _put_options(ticker: yf.Ticker, symbol: str, r2: R2):
    try:
        expiries = ticker.options
    except Exception:
        return
    if not expiries:
        return

    frames = []
    for expiry in expiries:
        try:
            chain = ticker.option_chain(expiry)
            for opt_type, df in [("call", chain.calls), ("put", chain.puts)]:
                if df is not None and not df.empty:
                    df = df.copy()
                    df["expiry"] = expiry
                    df["type"] = opt_type
                    frames.append(df)
        except Exception:
            continue

    if frames:
        _put_df(pd.concat(frames, ignore_index=True), r2, f"options/{symbol}.parquet")


def _already_done(r2: R2) -> set[str]:
    """Symbols that already have info in R2 (marker for fully processed)."""
    done = set()
    paginator = r2.s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=r2.bucket, Prefix="info/"):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if key.endswith(".json"):
                done.add(key.removeprefix("info/").removesuffix(".json"))
    return done


def fetch_fundamentals(
    symbols: list[str],
    r2: R2,
    batch_limit: int = 1000,
    pause: float = 0.5,
) -> tuple[int, int]:
    """Fetch all non-price data and upload to R2. Returns (success, fail)."""
    done = _already_done(r2)
    remaining = [s for s in symbols if s not in done]
    if done:
        print(f"Skipping {len(done)} already done, {len(remaining)} remaining")

    batch = remaining[:batch_limit]
    if not batch:
        print("All symbols already processed")
        return 0, 0

    print(f"Processing {len(batch)} symbols...")
    success = fail = 0

    for i, symbol in enumerate(batch):
        try:
            ticker = yf.Ticker(symbol)

            for attr, prefix in DF_TYPES:
                try:
                    _put_df(getattr(ticker, attr), r2, f"{prefix}/{symbol}.parquet")
                except Exception:
                    pass

            _put_options(ticker, symbol, r2)

            # Info last — serves as "done" marker
            try:
                _put_json(ticker.info, r2, f"info/{symbol}.json")
            except Exception:
                pass

            success += 1
        except Exception as e:
            print(f"  Failed {symbol}: {e}")
            fail += 1

        if (i + 1) % 100 == 0:
            print(f"  {i + 1}/{len(batch)} done")

        time.sleep(pause)

    return success, fail


def main():
    import os

    from dotenv import load_dotenv

    load_dotenv()

    symbols = fetch_symbols()
    print(f"Found {len(symbols)} symbols")

    r2 = R2.from_env()
    batch_limit = int(os.environ.get("BATCH_LIMIT", "1000"))
    success, fail = fetch_fundamentals(symbols, r2, batch_limit=batch_limit)
    print(f"Done! Success: {success}, Failed: {fail}")


if __name__ == "__main__":
    main()
