import requests

SYMBOLS_URL = "https://raw.githubusercontent.com/rreichel3/US-Stock-Symbols/main/all/all_tickers.txt"


def fetch_symbols() -> list[str]:
    """Fetch US stock symbols and format for Yahoo Finance."""
    resp = requests.get(SYMBOLS_URL)
    resp.raise_for_status()
    raw = [line.strip() for line in resp.text.splitlines() if line.strip()]
    return [to_yahoo_symbol(s) for s in raw]


def to_yahoo_symbol(symbol: str) -> str:
    """Convert standard ticker to Yahoo Finance format (dots become dashes)."""
    return symbol.replace(".", "-")
