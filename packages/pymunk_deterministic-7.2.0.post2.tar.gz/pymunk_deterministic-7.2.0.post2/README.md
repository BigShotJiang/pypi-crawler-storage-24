# pymunk-deterministic

A fork of [pymunk](https://github.com/viblo/pymunk) with modifications for deterministic physics simulation. Adds arbiter cache save/restore APIs (`_arbiter_to_dict`, `_arbiter_from_dict`, `cpSpaceClearCachedArbiters`, `cpSpaceAddCachedArbiter`, etc.) that enable exact state rollback for applications like MPC planning.

## Important: sdist-only distribution

This package is distributed as source-only (no prebuilt wheels). The Chipmunk C physics engine is compiled from source during installation. This is intentional — prebuilt wheels compiled on CI with different compiler flags produce slightly different floating-point results, which breaks the determinism guarantees this fork exists to provide.

Installation takes ~8 seconds due to the C compilation step.
