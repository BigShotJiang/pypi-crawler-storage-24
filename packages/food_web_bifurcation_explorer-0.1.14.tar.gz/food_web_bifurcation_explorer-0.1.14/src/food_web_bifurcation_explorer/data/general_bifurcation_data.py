from plotly.subplots import make_subplots
import numpy as np
import os
import pandas as pd
import plotly.graph_objects as go
import shutil
import zipfile


from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.bifurcation_types import BifurcationTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.enums.numbers.float_numbers import FloatNumbers
from food_web_bifurcation_explorer.enums.numbers.integer_numbers import IntegerNumbers    

class GeneralBifurcationData:

    def __init__(self):
        # declare a set of pandas divided by branch types and bifurcation types
        self.data: dict[BranchTypes, dict[BifurcationTypes, pd.DataFrame]] = {}
        for branch_type in BranchTypes:
            self.data[branch_type] = {}
            for bifurcation_type in BifurcationTypes:
                self.data[branch_type][bifurcation_type] = pd.DataFrame()
        # declare a dataframe for ternary grid counts
        columns_grid_counts = ['sd', 'sr', 'sl'] + [bifurcation_type.value for bifurcation_type in BifurcationTypes]
        self.data_ternary_grid_counts: dict[BranchTypes, pd.DataFrame] = {}
        for branch_type in BranchTypes:
            self.data_ternary_grid_counts[branch_type] = pd.DataFrame(columns=columns_grid_counts)

    def generate(self):
        # show info
        print("generating bifurcation data")
        # get all networks
        networks = glob.files.get_continuation_subfolders()
        # declare a temporal dictionary to save readed bifurcation types
        temp_data = {
            branch_type: {bifurcation_type: [] for bifurcation_type in BifurcationTypes}
            for branch_type in BranchTypes
        }
        # run sequentially the reading of the continuation zip files and the extraction of the bifurcation types
        for network in networks:
            # show info
            print(network)
            for fixed_parameter_value in glob.plot_data.fixed_parameter_values:
                # get continuation zip file correspond to this fixed parameter
                continuation_zip_file_path = os.path.join(glob.files.get_continuation_folder(), network, fixed_parameter_value + ".zip")
                # check that exist
                if not os.path.exists(continuation_zip_file_path):
                    continue
                try:
                    # open continuation zip file
                    with zipfile.ZipFile(continuation_zip_file_path, "r") as continuation_zip_file:
                        # iterate over both branches
                        for branch_type in BranchTypes:
                            file_name = f"bifurcations_{branch_type.value}_{ParameterTypes.LOTKAVOLTERRA.value}_{fixed_parameter_value}.csv"
                            
                            # Check if file exists in zip to avoid catching general exceptions blindly
                            if file_name not in continuation_zip_file.namelist():
                                continue
                            with continuation_zip_file.open(file_name) as file:
                                # read only the neccesary information
                                bifurcations_dataframe = pd.read_csv(file, usecols=['type', 'sd', 'sr', 'sl'])
                                # group by type
                                grouped = bifurcations_dataframe.groupby('type')
                                # iterate over bifurcation types
                                for bifurcation_type in BifurcationTypes:
                                    if bifurcation_type.value in grouped.groups:
                                        # extract group and drop the 'type' column as it's no longer needed
                                        df_filtered = grouped.get_group(bifurcation_type.value)[['sd', 'sr', 'sl']]
                                        # save in temporal data
                                        temp_data[branch_type][bifurcation_type].append(df_filtered)
                except Exception as e:
                    print(f"Error processing {continuation_zip_file_path}: {e}")
                    pass
        # create directory
        os.makedirs(glob.files.get_data_folder(), exist_ok=True)
        temporal_dir = os.path.join(glob.files.get_data_folder(), "temp_parquet_general_bifurcation_data")
        os.makedirs(temporal_dir, exist_ok=True)
        # sequentially concatenate and save
        temporal_files = []
        for branch_type in BranchTypes:
            for bifurcation_type in BifurcationTypes:
                dfs = temp_data[branch_type][bifurcation_type]
                if dfs:
                    # avoid copy when concatenating to save memory
                    df = pd.concat(dfs, ignore_index=True, copy=False)
                else:
                    df = pd.DataFrame(columns=['sd', 'sr', 'sl'])
                
                # get parquet file
                parquet_file = glob.files.get_general_bifurcation_data_parquet_file(branch_type, bifurcation_type)
                temp_path = os.path.join(temporal_dir, parquet_file)
                # use snappy compression for parquet (more fast)
                df.to_parquet(temp_path, compression='snappy')
                # set data
                self.data[branch_type][bifurcation_type] = df
                # save temporal files
                temporal_files.append((temp_path, parquet_file))
                
        # generate grid counts
        self.generate_grid_counts()
        
        # save it in parquet format
        for branch_type in BranchTypes:
            # define filename
            temp_path = os.path.join(temporal_dir, glob.files.get_ternary_grid_counts_file(branch_type))
            # save in temporal folder
            self.data_ternary_grid_counts[branch_type].to_parquet(temp_path, compression='snappy')
            # add to zip file path
            temporal_files.append((temp_path, glob.files.get_ternary_grid_counts_file(branch_type)))
            
        # write zip
        with zipfile.ZipFile(
            glob.files.get_general_bifurcation_data_zip_file(), "w", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
            for temporal_path, archive_name in temporal_files:
                data_zip_file.write(temporal_path, archive_name)
                
        # remove temporal dir
        shutil.rmtree(temporal_dir)

    def generate_grid_counts(self):
        # show info
        print("generating grid counts")
        # get bifurcation columns
        bifurcation_columns = [b.value for b in BifurcationTypes]
        # snap to grid with precision 3
        def _snap_to_grid(series: pd.Series) -> pd.Series:
            return ((series / FloatNumbers.FIXED_PARAMETER_STEP).round() * FloatNumbers.FIXED_PARAMETER_STEP).round(3)
        # Iterate over every branch type
        for branch_type in BranchTypes:
            list_of_counts = []
            # iterate over bifurcation types
            for bifurcation_type in BifurcationTypes:
                # get dataframe associated with bifurcation type
                df = self.data[branch_type][bifurcation_type]
                # check that isn't empty
                if df is None or df.empty:
                    continue
                # create temporal dataframe
                temp_df = pd.DataFrame({
                    'sd': _snap_to_grid(df['sd']),
                    'sr': _snap_to_grid(df['sr']),
                    'sl': _snap_to_grid(df['sl'])
                })
                # group by bifurcation type
                counts = temp_df.groupby(['sd', 'sr', 'sl']).size().reset_index(name=bifurcation_type.value)
                list_of_counts.append(counts)
            
            # if we don't have counts, create empty dataframe
            if not list_of_counts:
                empty_cols = ['sd', 'sr', 'sl'] + bifurcation_columns
                self.data_ternary_grid_counts[branch_type] = pd.DataFrame(columns=empty_cols)
            else:
                # merge all dataframes
                from functools import reduce
                merged_df = reduce(
                    lambda left, right: pd.merge(left, right, on=['sd', 'sr', 'sl'], how='outer'), 
                    list_of_counts
                )
                # fill with none values all empty columns
                for col in bifurcation_columns:
                    if col not in merged_df.columns:
                        merged_df[col] = 0
                merged_df[bifurcation_columns] = merged_df[bifurcation_columns].fillna(0).astype(int)
                # save dataframe
                self.data_ternary_grid_counts[branch_type] = merged_df

    def load(self):
        # simply open the general bifurcation data zip and load every parquet file
        with zipfile.ZipFile(glob.files.get_general_bifurcation_data_zip_file(), "r", compression=zipfile.ZIP_DEFLATED) as data_zip_file:
            # load data parquets
            for branch_type in BranchTypes:
                for bifurcation_type in BifurcationTypes:
                    with data_zip_file.open(glob.files.get_general_bifurcation_data_parquet_file(branch_type, bifurcation_type)) as f:
                        self.data[branch_type][bifurcation_type] = pd.read_parquet(f)
            # aso load grid count parquets
            for branch_type in BranchTypes:
                with data_zip_file.open(glob.files.get_ternary_grid_counts_file(branch_type)) as f:
                    self.data_ternary_grid_counts[branch_type] = pd.read_parquet(f)
        # plot files
        self.plot_data(ParameterTypes.DONOR, ParameterTypes.RECIPIENT)
        self.plot_data(ParameterTypes.RECIPIENT, ParameterTypes.LOTKAVOLTERRA)
        self.plot_data(ParameterTypes.LOTKAVOLTERRA, ParameterTypes.DONOR)
        self.plot_grid_counts_ternary_heatmap()
        self.plot_grid_counts_ternary_heatmap_combined()

    def load_grid_counts(self):
        """Carga los DataFrames de grid counts desde el ZIP existente."""
        zip_path = glob.files.get_general_bifurcation_data_zip_file()
        names = ['grid_sd_sr', 'grid_sr_sl', 'grid_sl_sd', 'grid_sd_sr_sl']

        self.grid_counts = {}
        with zipfile.ZipFile(zip_path, "r") as data_zip_file:
            for name in names:
                parquet_name = f"{name}.parquet"
                with data_zip_file.open(parquet_name) as f:
                    self.grid_counts[name] = pd.read_parquet(f)



    def plot_data(self, paramA: ParameterTypes, paramB: ParameterTypes):
        """
        Genera y abre en el navegador diagramas de densidad (KDE 2D) 
        para cada tipo de bifurcación y rama.
        """
        branch_types = list(BranchTypes)
        bifurcation_types = list(BifurcationTypes)

        # Verificar si hay algún dato real
        has_data = any(
            not self.data[bt][bift].empty
            for bt in branch_types
            for bift in bifurcation_types
        )

        if not has_data:
            print("No hay datos suficientes para generar los diagramas de densidad.")
            return

        fig = make_subplots(
            rows=len(branch_types),
            cols=len(bifurcation_types),
            subplot_titles=[
                f"{bt.name} - {bift.name}"
                for bt in branch_types
                for bift in bifurcation_types
            ],
            vertical_spacing=0.1,
            horizontal_spacing=0.05
        )

        for i, bt in enumerate(branch_types, 1):
            for j, bift in enumerate(bifurcation_types, 1):
                df = self.data[bt][bift]

                if not df.empty:
                    # Usar go.Histogram2dContour en lugar de px.density_contour
                    # para compatibilidad directa con make_subplots
                    trace = go.Histogram2dContour(
                        x=df[paramA.value],
                        y=df[paramB.value],
                        colorscale="Blues",
                        contours_coloring="heatmap",  # antes "contours_filling", incorrecto
                        showscale=False,
                        ncontours=20,
                    )
                    fig.add_trace(trace, row=i, col=j)

        fig.update_layout(
            title_text=f"Bifurcation density ({paramA.value} vs {paramB.value})",
            height=500 * len(branch_types),
            width=500 * len(bifurcation_types),
            showlegend=False,
            template="plotly_white"
        )
        axis_ticks = [round(i * 0.1, 1) for i in range(11)]

        fig.update_xaxes(title_text=paramA.value, tickvals=axis_ticks, range=[0, 1])
        fig.update_yaxes(title_text=paramB.value, tickvals=axis_ticks, range=[0, 1])

        fig.update_xaxes(title_text=paramA.value)
        fig.update_yaxes(title_text=paramB.value)

        fig.show()

    def plot_grid_counts_ternary_heatmap(self):
        # 1. Comprobar si hay datos
        has_data = any(not df.empty for df in self.data_ternary_grid_counts.values())
        if not has_data:
            print("No hay datos de grid counts ternarios para mostrar.")
            return

        # 2. Iterar por cada rama (branch_type) y tipo de bifurcación
        df_grid = self.data_ternary_grid_counts.get(BranchTypes.EMPIRICAL)

        for bifurcation_type in BifurcationTypes:
            if bifurcation_type.value not in df_grid.columns:
                continue

            # Filtrar solo donde hay cuentas > 0
            df_filtered = df_grid[df_grid[bifurcation_type.value] > 0].copy()

            if df_filtered.empty:
                continue

            # Extraer los datos directamente del dataframe del grid
            sds = df_filtered['sd']
            srs = df_filtered['sr']
            sls = df_filtered['sl']
            counts = df_filtered[bifurcation_type.value]

            # Crear el gráfico ternario nativo de Plotly
            fig = go.Figure(go.Scatterternary({
                'mode': 'markers',
                'a': sls,  # Eje superior (LotkaVolterra)
                'b': sds,  # Eje inferior izquierdo (Donor)
                'c': srs,  # Eje inferior derecho (Recipient)
                'marker': {
                    'symbol': 'hexagon',  # Los hexágonos se acoplan mejor creando un efecto "malla continua"
                    'color': counts,      # El color depende de la cantidad de elementos
                    'colorscale': 'Viridis', # Escala de calor ('Plasma', 'Inferno', 'Viridis')
                    'size': 4,           # Ajusta el tamaño para que se toquen en la vista por defecto
                    'showscale': True,    # Mostrar la barra de leyenda lateral
                    'colorbar': {'title': 'Nº Elementos'},
                    'line': {'width': 0},  # Sin bordes para un efecto más suave
                    'cmin': 0,               # <--- FORZAR EL MÍNIMO DE LA ESCALA A 0
                    'cmax': counts.max(),    # <--- Establecer el máximo al valor mayor del DataFrame
                },
                # Hover dinámico
                'hovertemplate': (
                    f"<b>{bifurcation_type.name} ({BranchTypes.EMPIRICAL.name})</b><br>"
                    f"{ParameterTypes.LOTKAVOLTERRA.value}: %{{a:.3f}}<br>"
                    f"{ParameterTypes.DONOR.value}: %{{b:.3f}}<br>"
                    f"{ParameterTypes.RECIPIENT.value}: %{{c:.3f}}<br>"
                    f"Elementos: %{{marker.color}}<extra></extra>"
                )
            }))

            # Configurar el diseño del triángulo
            fig.update_layout({
                'title': f"Ternary Heatmap — {bifurcation_type.name} ({BranchTypes.EMPIRICAL.name})",
                'ternary': {
                    'sum': 1,
                    'aaxis': {'title': ParameterTypes.LOTKAVOLTERRA.value, 'min': 0, 'linewidth': 2, 'ticks': 'outside'},
                    'baxis': {'title': ParameterTypes.DONOR.value, 'min': 0, 'linewidth': 2, 'ticks': 'outside'},
                    'caxis': {'title': ParameterTypes.RECIPIENT.value, 'min': 0, 'linewidth': 2, 'ticks': 'outside'},
                    'bgcolor': 'rgba(0,0,0,0)' # Fondo transparente para resaltar los colores
                },
                'height': 800,
                'width': 800,
                'template': 'plotly_white'
            })

            fig.show()

    def plot_grid_counts_ternary_heatmap_combined(self):
        # 1. Comprobar si hay datos
        df_grid = self.data_ternary_grid_counts.get(BranchTypes.EMPIRICAL)
        if df_grid is None or df_grid.empty:
            print("No hay datos de grid counts ternarios para mostrar.")
            return

        # 2. Identificar las columnas de bifurcación presentes en el DataFrame
        # Filtramos las columnas del DF que coincidan con los valores definidos en BifurcationTypes
        bif_columns = [
            b.value for b in BifurcationTypes 
            if b.value in df_grid.columns and b != BifurcationTypes.FRONTIER and b != BifurcationTypes.INTERNAL_ERROR and b != BifurcationTypes.EXTINCT
        ]
    
        if not bif_columns:
            print("No se encontraron columnas de bifurcación válidas.")
            return

        # 3. Crear una columna 'total_counts' sumando todas las bifurcaciones
        df_combined = df_grid.copy()
        df_combined['total_counts'] = df_combined[bif_columns].sum(axis=1)

        # Filtrar solo donde la suma total sea mayor que 0
        df_filtered = df_combined[df_combined['total_counts'] > 0].copy()

        if df_filtered.empty:
            print("No hay elementos en ninguna categoría para mostrar.")
            return

        # 4. Configurar el gráfico único
        fig = go.Figure(go.Scatterternary({
            'mode': 'markers',
            'a': df_filtered['sl'],
            'b': df_filtered['sd'],
            'c': df_filtered['sr'],
            'marker': {
                'symbol': 'hexagon',
                'color': df_filtered['total_counts'],
                'colorscale': 'Viridis',
                'size': 4,
                'showscale': True,
                'colorbar': {'title': 'Total Elementos'},
                'line': {'width': 0},
                'cmin': 0,
                'cmax': df_filtered['total_counts'].max(),
            },
            'hovertemplate': (
                f"<b>Total Bifurcaciones ({BranchTypes.EMPIRICAL.name})</b><br>"
                f"{ParameterTypes.LOTKAVOLTERRA.value}: %{{a:.3f}}<br>"
                f"{ParameterTypes.DONOR.value}: %{{b:.3f}}<br>"
                f"{ParameterTypes.RECIPIENT.value}: %{{c:.3f}}<br>"
                "Total: %{marker.color}<extra></extra>"
            )
        }))

        # 5. Diseño del triángulo
        fig.update_layout({
            'title': f"Ternary Heatmap Global — {BranchTypes.EMPIRICAL.name}",
            'ternary': {
                'sum': 1,
                'aaxis': {'title': ParameterTypes.LOTKAVOLTERRA.value, 'min': 0, 'linewidth': 2},
                'baxis': {'title': ParameterTypes.DONOR.value, 'min': 0, 'linewidth': 2},
                'caxis': {'title': ParameterTypes.RECIPIENT.value, 'min': 0, 'linewidth': 2},
            },
            'height': 800,
            'width': 800,
            'template': 'plotly_white'
        })

        fig.show()




        def plot_grid_counts_ternary_heatmap_combined_log(self):
        # 1. Comprobar si hay datos
        df_grid = self.data_ternary_grid_counts.get(BranchTypes.EMPIRICAL)
        if df_grid is None or df_grid.empty:
            print("No hay datos de grid counts ternarios para mostrar.")
            return

        # 2. Identificar las columnas de bifurcación presentes en el DataFrame
        # Filtramos las columnas del DF que coincidan con los valores definidos en BifurcationTypes
        bif_columns = [
            b.value for b in BifurcationTypes 
            if b.value in df_grid.columns and b != BifurcationTypes.FRONTIER and b != BifurcationTypes.INTERNAL_ERROR and b != BifurcationTypes.EXTINCT
        ]
    
        if not bif_columns:
            print("No se encontraron columnas de bifurcación válidas.")
            return

        # 3. Crear una columna 'total_counts' sumando todas las bifurcaciones
        df_combined = df_grid.copy()
        df_combined['total_counts'] = df_combined[bif_columns].sum(axis=1)

        # Filtrar solo donde la suma total sea mayor que 0
        df_filtered = df_combined[df_combined['total_counts'] > 0].copy()

        if df_filtered.empty:
            print("No hay elementos en ninguna categoría para mostrar.")
            return

        # 3. Sumar y preparar datos
        df_combined = df_grid.copy()
        df_combined['total_counts'] = df_combined[bif_columns].sum(axis=1)
        df_filtered = df_combined[df_combined['total_counts'] > 0].copy()

        # Creamos una columna para el color aplicando logaritmo
        # Usamos log1p (log(1+x)) para evitar problemas si hubiera algún 0 y para que el valor 1 no de 0
        df_filtered['color_log'] = np.log1p(df_filtered['total_counts'])

        # 4. Generar el Scatterternary
        fig = go.Figure(go.Scatterternary({
            'mode': 'markers',
            'a': df_filtered['sl'],
            'b': df_filtered['sd'],
            'c': df_filtered['sr'],
            'marker': {
                'symbol': 'hexagon',
                'color': df_filtered['color_log'], # Usamos la columna transformada
                'colorscale': 'Viridis',
                'size': 5,
                'showscale': True,
                'colorbar': {'title': 'Total Elementos'},
                'line': {'width': 0},
            },
            'hovertemplate': (
                f"<b>Distribución Global</b><br>"
                f"{ParameterTypes.LOTKAVOLTERRA.value}: %{{a:.3f}}<br>"
                f"{ParameterTypes.DONOR.value}: %{{b:.3f}}<br>"
                f"{ParameterTypes.RECIPIENT.value}: %{{c:.3f}}<br>"
                "<b>Elementos Reales: %{text}</b><extra></extra>"
            ),
            'text': df_filtered['total_counts'] # Pasamos el valor real para el hover
        }))

        # 5. Diseño del triángulo
        fig.update_layout({
            'title': f"Ternary Heatmap Global — {BranchTypes.EMPIRICAL.name}",
            'ternary': {
                'sum': 1,
                'aaxis': {'title': ParameterTypes.LOTKAVOLTERRA.value, 'min': 0, 'linewidth': 2},
                'baxis': {'title': ParameterTypes.DONOR.value, 'min': 0, 'linewidth': 2},
                'caxis': {'title': ParameterTypes.RECIPIENT.value, 'min': 0, 'linewidth': 2},
            },
            'height': 800,
            'width': 800,
            'template': 'plotly_white'
        })

        fig.show()