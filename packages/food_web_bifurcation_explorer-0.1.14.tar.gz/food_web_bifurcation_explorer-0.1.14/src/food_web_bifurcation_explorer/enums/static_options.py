class StaticOptions:
    DEBUG = False
    PRECACHE_ALL_TRACES = False
    GENERATE_GENERAL_BIFURCATION_DATA = False
