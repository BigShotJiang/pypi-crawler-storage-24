from dataclasses import dataclass


@dataclass
class Memory:
    id: str
    text: str
    metadata: dict
    namespace: str


@dataclass
class SearchResult(Memory):
    distance: float = 0.0


@dataclass
class ConversationMessage:
    role: str
    content: str
