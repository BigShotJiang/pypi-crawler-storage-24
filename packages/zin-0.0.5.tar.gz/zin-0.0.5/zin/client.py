"""Zin Memory SDK — async client for the Zin memory server."""

from __future__ import annotations

import httpx

from zin.models import (
    ConversationMessage,
    Memory,
    SearchResult,
)


class ZinMemory:
    """Async client for the Zin memory API.

    Can be used as a singleton — user_id and namespaces are passed per-call,
    not at init time.

    Usage::

        client = ZinMemory("http://localhost:8000")

        # Add a memory
        mem_id = await client.add("Likes dark mode", user_id="u1")

        # Search
        results = await client.search("preferences", user_id="u1")

        # Process a conversation (fire-and-forget on server side)
        await client.process_memory(
            messages=[("user", "I love hiking"), ("assistant", "Nice!")],
            user_id="u1",
        )

        # Cleanup
        await client.close()
    """

    def __init__(self, base_url: str = "http://localhost:8000", timeout: float = 10.0):
        self._http = httpx.AsyncClient(base_url=base_url, timeout=timeout)

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> ZinMemory:
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    # ── Add ───────────────────────────────────────────────────────────────

    async def add(
        self,
        text: str,
        *,
        user_id: str | None = None,
        namespace: str = "personal",
        metadata: dict | None = None,
    ) -> str:
        """Add a memory. Returns the memory ID."""
        payload: dict = {"text": text, "namespace": namespace, "metadata": metadata or {}}
        if user_id:
            payload["user_id"] = user_id
        resp = await self._http.post("/add", json=payload)
        resp.raise_for_status()
        return resp.json()["id"]

    # ── Search ────────────────────────────────────────────────────────────

    async def search(
        self,
        query: str,
        *,
        user_id: str | None = None,
        namespace: str | None = None,
        top_k: int = 5,
    ) -> list[SearchResult]:
        """Search for memories by semantic similarity."""
        payload: dict = {"query": query, "top_k": top_k}
        if user_id:
            payload["user_id"] = user_id
        if namespace:
            payload["namespace"] = namespace
        resp = await self._http.post("/search", json=payload)
        resp.raise_for_status()
        return [
            SearchResult(
                id=r["id"],
                text=r["text"],
                metadata=r["metadata"],
                namespace=r["namespace"],
                distance=r["distance"],
            )
            for r in resp.json()
        ]

    # ── Process memory ────────────────────────────────────────────────────

    async def process_memory(
        self,
        messages: list[tuple[str, str] | ConversationMessage],
        *,
        user_id: str | None = None,
        namespaces: dict[str, str] | None = None,
        store_personal: bool = True,
    ) -> None:
        """Send a conversation window to the memory agent for processing.

        Args:
            messages: List of (role, content) tuples or ConversationMessage objects.
            user_id: User ID for personal namespace scoping.
            namespaces: Shared namespace dict (e.g. {"company": "Company knowledge"}).
            store_personal: Whether the agent can store personal memories.
        """
        msg_dicts = []
        for m in messages:
            if isinstance(m, ConversationMessage):
                msg_dicts.append({"role": m.role, "content": m.content})
            else:
                msg_dicts.append({"role": m[0], "content": m[1]})

        payload: dict = {"messages": msg_dicts, "store_personal": store_personal}
        if user_id:
            payload["user_id"] = user_id
        if namespaces:
            payload["namespaces"] = namespaces
        resp = await self._http.post("/process-memory", json=payload)
        resp.raise_for_status()

    # ── Delete / Update ──────────────────────────────────────────────────

    async def delete_memory(self, memory_id: str) -> None:
        """Delete a single memory by ID."""
        resp = await self._http.delete(f"/memories/{memory_id}")
        resp.raise_for_status()

    async def update_memory(self, memory_id: str, text: str) -> None:
        """Update a memory's text."""
        resp = await self._http.put(f"/memories/{memory_id}", json={"text": text})
        resp.raise_for_status()

    async def delete_all_memories(self) -> int:
        """Delete all memories by listing then deleting each. Returns count deleted."""
        memories = await self.list_memories()
        for m in memories:
            await self.delete_memory(m.id)
        return len(memories)

    # ── List memories ─────────────────────────────────────────────────────

    async def list_memories(
        self,
        *,
        namespace: str | None = None,
        limit: int = 100,
    ) -> list[Memory]:
        """List stored memories (no vector search). For dev/debugging."""
        params: dict = {"limit": limit}
        if namespace:
            params["namespace"] = namespace
        resp = await self._http.get("/memories", params=params)
        resp.raise_for_status()
        return [
            Memory(id=r["id"], text=r["text"], metadata=r["metadata"], namespace=r["namespace"])
            for r in resp.json()
        ]
