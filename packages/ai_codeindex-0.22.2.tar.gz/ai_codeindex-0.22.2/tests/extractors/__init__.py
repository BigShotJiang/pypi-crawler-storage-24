"""Tests for route extractors."""
