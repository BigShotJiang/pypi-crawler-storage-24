from __future__ import annotations
import json
from pathlib import Path
from typing import Any
def is_valid_json_file(path: str | Path) -> bool:
    p = Path(path)
    if not p.is_file():
        return False
    try:
        with p.open("r", encoding="utf-8") as f:
            json.load(f)
        return True
    except (json.JSONDecodeError, UnicodeDecodeError, OSError):
        return False
def load_json_file(path: str | Path) -> Any:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"JSON file not found: {p}")
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)