from __future__ import annotations

import base64
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .enclave import Enclave


def _encode_secret(value: str | bytes) -> dict[str, Any]:
    if isinstance(value, str):
        data = value.encode("utf-8")
        kind = "text"
    elif isinstance(value, bytes):
        data = value
        kind = "bytes"
    else:
        raise TypeError("secret value must be str or bytes")
    return {"kind": kind, "value_b64": base64.b64encode(data).decode("ascii")}


def _decode_secret(payload: dict[str, Any]) -> str | bytes:
    raw = base64.b64decode(payload["value_b64"])
    return raw.decode("utf-8") if payload["kind"] == "text" else raw

@dataclass(frozen=True, slots=True)
class SecretMetadata:
    key: str
    created_at: float
    updated_at: float
    kind: str

class SecretStore:
    def __init__(self, path: str | Path, *, vault: Enclave) -> None:
        self.path = Path(path)
        self.vault = vault
        self._data: dict[str, Any] = {"version": 1, "created_at": time.time(), "updated_at": time.time(), "secrets": {}}
        if self.path.exists():
            self.load()

    @classmethod
    def from_key(cls, path: str | Path, key: bytes) -> "SecretStore":
        return cls(path, vault=Enclave.from_key(key))

    @classmethod
    def from_password(cls, path: str | Path, password: str) -> "SecretStore":
        return cls(path, vault=Enclave.from_password(password))

    def set(self, key: str, value: str | bytes) -> None:
        if not key:
            raise ValueError("key must be non-empty")
        now = time.time()
        encoded = _encode_secret(value)
        created_at = self._data["secrets"].get(key, {}).get("created_at", now)
        self._data["secrets"][key] = {**encoded, "created_at": created_at, "updated_at": now}
        self._data["updated_at"] = now

    def get(self, key: str, default: Any = None) -> Any:
        item = self._data["secrets"].get(key)
        return default if item is None else _decode_secret(item)

    def delete(self, key: str) -> bool:
        removed = self._data["secrets"].pop(key, None) is not None
        if removed:
            self._data["updated_at"] = time.time()
        return removed

    def list_keys(self) -> list[str]:
        return sorted(self._data["secrets"].keys())

    def metadata(self, key: str) -> SecretMetadata:
        item = self._data["secrets"][key]
        return SecretMetadata(key=key, created_at=float(item["created_at"]), updated_at=float(item["updated_at"]), kind=str(item["kind"]))

    def save(self) -> Path:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data["updated_at"] = time.time()
        self.vault.pack_to_file(str(self.path), self._data, serializer="json")
        return self.path

    def load(self) -> None:
        self._data = self.vault.unpack_from_file(str(self.path), serializer="json")

    def rotate_key(self, *, new_key: bytes | None = None, new_password: str | None = None) -> None:
        if (new_key is None) == (new_password is None):
            raise ValueError("Provide exactly one of new_key or new_password")
        self.vault = Enclave.from_key(new_key) if new_key is not None else Enclave.from_password(new_password or "")
        self.save()

    def export_plaintext(self) -> dict[str, str | bytes]:
        return {key: self.get(key) for key in self.list_keys()}

    def clear(self) -> None:
        self._data["secrets"].clear()
        self._data["updated_at"] = time.time()
