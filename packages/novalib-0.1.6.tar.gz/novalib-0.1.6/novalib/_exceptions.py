from __future__ import annotations

class NovaCoreError(Exception):
    default_message = "An unknown library error occurred."

    def __init__(self, message: str | None = None) -> None:
        self.message = message or self.default_message
        super().__init__(self.message)

    def __str__(self) -> str:
        return self.message


class HWIDError(NovaCoreError):
    default_message = "No hardware identifiers found for this system."


class NotJson(NovaCoreError):
    default_message = "Provided file is not a valid JSON file."


class IntegrityError(NovaCoreError):
    default_message = "Integrity failed: code has been modified or tampered with."


class MetadataSignatureError(IntegrityError):
    default_message = "Metadata signature verification failed."


class ConfigValidationError(NovaCoreError):
    default_message = "Configuration validation failed."


class PathAccessError(ConfigValidationError):
    default_message = "Invalid path access in configuration."


class PoWError(NovaCoreError):
    default_message = "Proof-of-work operation failed."


class WatcherError(NovaCoreError):
    default_message = "File system watcher encountered an error."


class WatcherStartupError(WatcherError):
    default_message = "Failed to start file system watcher."


class ShredderError(NovaCoreError):
    default_message = "Secure file deletion failed."


class SchemaGenerationError(NovaCoreError):
    default_message = "Failed to generate schema from the given target."


class SchedulerError(NovaCoreError):
    default_message = "Task scheduler encountered an error."


class VaultError(NovaCoreError):
    default_message = "Vault operation failed."


class VaultFormatError(VaultError):
    default_message = "Vault data format is invalid or unsupported."


class VaultIntegrityError(VaultError):
    default_message = "Vault integrity check failed."


class VaultSerializerError(VaultError):
    default_message = "Vault serializer or deserializer reported an error."


class VaultConfigurationError(VaultError):
    default_message = "Vault configuration is invalid."


class CodecError(NovaCoreError):
    default_message = "Binary codec operation failed."