from __future__ import annotations
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import (
    Any, Dict, Set, Optional, TypeVar, Generic, Tuple, ClassVar,
    Callable, Hashable
)

from syncraft.path import builtin_cache_path, user_cache_path

from syncraft.alphabet import AlphabetProtocol
from syncraft.fa import DEFAULT_TAG, NFA, Builder, ReverseDFA, Runner, ModeAction, ModeActionEnum, DFA
from syncraft.ast import SyncraftError
from syncraft.cache import Either
from collections import deque, defaultdict
import random
from pathlib import Path
import hashlib
import threading
from syncraft.token import TokenSpec
from functools import cached_property
import pickle
from syncraft.lexerprotocol import LexerProtocol, LexerError, LexerResult, LexerBuilder, GeneratedToken, VerifiedToken

Tag = str | Enum | None

C = TypeVar('C', bound=Hashable)
A = TypeVar('A')
Ret = TypeVar('Ret', bound=Either[Any, Tuple])
T = TypeVar('T', bound=Hashable)



@dataclass
class Mode(Generic[C]):
    runner: Runner[C]
    rdfa: ReverseDFA[C]
    priority: Dict[Tag, int] = field(default_factory=dict)
    skip: frozenset[Tag] = field(default_factory=frozenset)
    non_greedy: frozenset[Tag] = field(default_factory=frozenset)
    start_index: Optional[int] = None


    @cached_property
    def has_skip(self) -> bool:
        return bool(self.skip)

    
    def reset(self) -> None:
        self.runner = self.runner.reset()
        self.start_index = None
        
    
    def select_tag(self, tags: frozenset[Tag]) -> Optional[Tag]:
        if not tags:
            
            return None
        sortted_tags = sorted(tags, key=lambda tag: (-self.priority.get(tag, -1), str(tag)))
        return sortted_tags[0]


@dataclass(slots=True)
class LexerCache:

    dict: Dict[str, Lexer[Any]] = field(default_factory=dict)
    lock: threading.RLock = field(default_factory=threading.RLock)

    @staticmethod
    def _load(dir: Path, key: str) -> Optional[Lexer[Any]]:
        file = dir / f"{key}.lex"
        if file.exists():
            with open(file, "rb") as f:
                try:
                    return pickle.load(f)
                except Exception as e:
                    print(e)
                    print("Failed to load lexer from cache:", file)
                    file.unlink()
        return None
    
    @staticmethod
    def _save(dir: Path, key: str, lexer: Lexer[Any]) -> None:
        dir.mkdir(parents=True, exist_ok=True)
        file = dir / f"{key}.lex"
        with open(file, "wb") as f:
            pickle.dump(lexer, f)

    def load(self, 
             *,
             builders: Set[Builder[Any]], 
             factory: Callable[[], Lexer[Any]],
             dir: Path) -> Tuple[Lexer[Any], Path]:
        tmp = sorted(repr(fb) for fb in builders)
        joined = "\n".join(tmp)
        key = hashlib.sha256(joined.encode("utf-8")).hexdigest()

        with self.lock:
            if key in self.dict:
                return self.dict[key], dir / f"{key}.lex"
            else:
                lexer = self._load(dir, key)
                if lexer is not None:
                    normalize = lexer._normalize_default_tags
                    if callable(normalize) and normalize():
                        self._save(dir, key, lexer)
                    self.dict[key] = lexer
                    return lexer, dir / f"{key}.lex"
                lexer = factory()
                if lexer is not None:
                    self.dict[key] = lexer
                    self._save(dir, key, lexer)
                    return lexer, dir / f"{key}.lex"
                raise SyncraftError(
                    "Lexer factory did not produce a lexer",
                    offender=factory,
                    expect="a Lexer instance",
                )
            
@dataclass(slots=True)
class Lexer(LexerProtocol[C]):
    modes: Dict[str | None, Mode[C]] = field(default_factory=dict)
    actions: Dict[Tag, ModeAction] = field(default_factory=dict)

    _stack: deque[Mode[C]] = field(default_factory=deque)
    cache: ClassVar[LexerCache] = LexerCache()
    filepath: Optional[Path] = field(default=None, compare=False, hash=False, repr=False)

    @staticmethod
    def _summarize_expected(expected: frozenset[Hashable]) -> str:
        if not expected:
            return "valid input"

        items = sorted(str(item) for item in expected)
        if len(items) == 1:
            return f"'{items[0]}'"
        if len(items) <= 10:
            quoted = [f"'{item}'" for item in items]
            return f"one of {', '.join(quoted)}"
        return f"one of {', '.join(items[:5])} ... {len(items)} valid inputs"

    def _normalize_default_tags(self) -> bool:
        def needs_normalization(mode: Mode[C]) -> bool:
            has_default_tag = False
            for tags in mode.runner.dfa.accept.values():
                if not tags:
                    return True
                if DEFAULT_TAG in tags:
                    has_default_tag = True
                    if len(tags) > 1:
                        return True
            if not has_default_tag:
                return False
            return False

        changed = False
        for mode in self.modes.values():
            if not needs_normalization(mode):
                continue
            dfa = mode.runner.dfa.with_default_tag_invariant()
            self._raise_on_unreachable_accept(dfa)
            mode.runner = dfa.runner(non_greedy=mode.non_greedy)
            mode.rdfa = dfa.reverse
            changed = True
        return changed

    @staticmethod
    def _raise_on_unreachable_accept(dfa: DFA[Any]) -> None:
        by_tag = dfa.accept_reachability()
        for tag, (reachable, unreachable) in by_tag.items():
            if unreachable:
                raise SyncraftError(
                    "Unreachable accept state(s) detected",
                    offender={"tag": tag, "reachable": reachable, "unreachable": unreachable},
                    expect="accept states reachable from init",
                )

    
    def tags(self) -> frozenset[Tag]:
        all_tags: Set[Tag] = set()
        for mode in self.modes.values():
            for tags in mode.runner.dfa.accept.values():
                if tags:
                    all_tags.update(tags)
                else:
                    all_tags.add(None)
        return frozenset(all_tags)

    @classmethod
    def create(cls, 
               *args: Builder,

               builtin: bool = False,
               cache_path: str | Path | None = None,
               ) -> Optional["Lexer[C]"]:
        def fabuilder(*args: Any) -> Tuple[Set[Builder[Any]], Path]:
            if builtin:
                path = builtin_cache_path()
            else:
                path = user_cache_path(cache_path)

            acc: Set[Builder[Any]] = set()
            for v in args:
                if isinstance(v, Builder):
                    acc.add(v)                    
            return acc, path

        builders, dir = fabuilder(*args)
        if not builders:
            return None
        lexer, path = cls.cache.load(builders=builders, 
                              factory=lambda: cls.from_builders(*builders),
                              dir=dir)
        lexer.filepath = path
        return lexer

    def reset(self) -> None:
        self.current_mode.reset()
    
    @property
    def current_mode(self) -> Mode[C]:
        if not self._stack:
            return self.push_mode(None)
        return self._stack[-1]
        
    def pop_mode(self, mode_name: str | None = None) -> Mode[C]:
        if not self._stack:
            raise SyncraftError("Cannot pop mode from empty stack", offender=self._stack, expect="non-empty stack")
        if mode_name not in self.modes:
            raise SyncraftError(f"Cannot pop unknown mode '{mode_name}'", offender=mode_name, expect=f"one of {list(self.modes.keys())}")
        if self._stack[-1] is not self.modes.get(mode_name):
            raise SyncraftError(f"Cannot pop mode '{mode_name}' because it is not the current mode", offender=mode_name, expect=f"current mode '{self._stack[-1]}'")
        self._stack.pop()
        return self.current_mode

    def push_mode(self, mode_name: str | None = None) -> Mode[C]:
        if mode_name not in self.modes:
            raise SyncraftError(f"Cannot push unknown mode '{mode_name}'", offender=mode_name, expect=f"one of {list(self.modes.keys())}")
        target_mode = self.modes[mode_name]
        current = self._stack[-1] if self._stack else None
        if current is target_mode:
            return target_mode
        self._stack.append(target_mode)
        target_mode.reset()
        return target_mode
            

    @staticmethod
    def one_mode(*rules: Builder[C]) -> "Mode[C]":
        if not rules:
            raise SyncraftError("Cannot build a Mode with no rules", offender=rules, expect="at least one rule")
        alphabet: Optional[AlphabetProtocol[C]] = None
        for rule in rules:
            if alphabet is None:
                alphabet = rule.alphabet
                break
                
        assert alphabet is not None, "Cannot build a Mode without an alphabet"

        skip: Set[Tag] = set()
        priority: Dict[Tag, int] = {}
        non_greedy: Set[Tag] = set()
        combined: Optional[NFA[C]] = None 
        for rule in rules:
            if rule.skip:
                # assert rule.tag is not None, "Skip rules must have a tag"
                skip.add(rule.tag)
            if rule.priority != 0:
                # assert rule.tag is not None, "Priority rules must have a tag"
                priority[rule.tag] = rule.priority
            if rule.non_greedy:
                # assert rule.tag is not None, "Greedy rules must have a tag"
                non_greedy.add(rule.tag)
            nfa = rule.compile(alphabet).nfa
            nfa = nfa.tagged(rule.tag) if rule.tag is not None else nfa
            combined = nfa if combined is None else combined.union(nfa)

        assert combined is not None
        dfa = combined.dfa.normalized.with_default_tag_invariant()
        Lexer._raise_on_unreachable_accept(dfa)
        non_greedy_set = frozenset(non_greedy)
        return Mode(
            runner=dfa.runner(non_greedy=non_greedy_set),
            rdfa=dfa.reverse,
            priority=dict(priority),
            skip=frozenset(skip),
            non_greedy=non_greedy_set,
        )

    @classmethod
    def from_builders(cls, *rules: Builder[C]) -> Lexer[C]:
        if len(rules) == 0:
            raise SyncraftError("Cannot build a Lexer with no rules", offender=rules, expect="at least one rule")
        modes: Dict[str | None, Set[Builder[C]]] = defaultdict(set)
        universal_rules: Set[Builder[C]] = set()
        actions: Dict[Tag, ModeAction] = {}
        def add_rule_to_mode(rule: Builder[C], belong_name: str | None) -> None:
            if belong_name == '*':
                universal_rules.add(rule)
            else:
                modes[belong_name].add(rule)

        for rule in rules:
            match rule.action:
                case None:
                    modes[None].add(rule)
                case ModeAction(action=ModeActionEnum.PUSH, belong=belong_name):
                    add_rule_to_mode(rule, belong_name)
                    assert rule.tag is not None, "PUSH actions must have a tag"
                    actions[rule.tag] = rule.action
                case ModeAction(action=ModeActionEnum.BELONG, belong=belong_name):
                    add_rule_to_mode(rule, belong_name)
                case ModeAction(action=ModeActionEnum.POP, belong=belong_name):
                    add_rule_to_mode(rule, belong_name)
                    assert rule.tag is not None, "POP actions must have a tag"
                    actions[rule.tag] = rule.action
        
        for r in universal_rules:
            for mode_rules in modes.values():
                mode_rules.add(r)


        lexer_modes: Dict[str | None, Mode[C]] = {}
        for mname, mode_rules in modes.items():
            lexer_modes[mname] = cls.one_mode(*mode_rules)

        lexer = cls(modes=lexer_modes, actions=actions)
        lexer.push_mode(None)
        return lexer

    def gen(self, tag: Tag, rng: random.Random) -> GeneratedToken:
        ret = self.current_mode.rdfa.gen(tag, rng)
        act = self.actions.get(tag)
        if act is not None:
            match act:
                case ModeAction(action=ModeActionEnum.PUSH, mode=mode_name):
                    self.push_mode(mode_name)
                case ModeAction(action=ModeActionEnum.POP, belong=mode_name):
                    self.pop_mode(mode_name)
                case _:
                    raise SyncraftError(f"Unknown action {act}", offender=act, expect="PUSH, POP, or BELONG action")
        return GeneratedToken(value=ret, tag=tag, steps=len(ret) if isinstance(ret, (str, bytes, tuple)) else 1)

    def verify(self, tag: frozenset[Tag], value: Any) -> VerifiedToken:
        txt = value
        lexer = self
        try:
            for index, char in enumerate(txt):
                match lexer.match(char, index):  # type: ignore[arg-type]

                    case LexerResult(tag=t, start=s, end=e):
                        if len(tag) > 0 and t not in tag:
                            return VerifiedToken(False, 0)
                        if s != 0 or e != len(txt):
                            return VerifiedToken(False, 0)
                        if index != len(txt) - 1:
                            return VerifiedToken(False, 0)
                        return VerifiedToken(True, len(txt))
                    case None:
                        continue  # Intermediate character, keep going
                    case LexerError():
                        return VerifiedToken(False, 0)
            candidate = lexer.candidate()
            if isinstance(candidate, LexerResult):
                if len(tag) > 0 and candidate.tag not in tag:
                    return VerifiedToken(False, 0)
                return VerifiedToken(candidate.start == 0 and candidate.end == len(txt), len(txt))
        except TypeError:
            raise SyncraftError(
                f"Value {value} is not valid for verification, expected an eenumerable object like string, bytes, or tuple",
                offender=value,
                expect="an enumerable object",
            )
        return VerifiedToken(False, 0)

    def candidate(self) -> LexerError | LexerResult[C]:
        mode = self.current_mode
        if mode.start_index is None:
            return LexerError.message_only("Cannot get candidate when no input has been processed")
        
        candidate_ = mode.runner.candidates
        if not candidate_:
            return LexerError.message_only("No candidate available")
        latest = candidate_[-1]
        tag = mode.select_tag(latest[1])
        return LexerResult(
                tag=tag,
                start=mode.start_index,
                end=latest[0] + 1,
                skip=tag in mode.skip
            )
        

    def match(self, char: C, index: int) -> LexerError | None | LexerResult[C]:
        mode = self.current_mode
        if mode.start_index is None:
            mode.start_index = index
        old_state = mode.runner.current
        rr = mode.runner.step(char, index)
        if rr.error:
            expecting = mode.runner.resumable_str(old_state)
            mode.runner = mode.runner.reset()
            exp = expecting or frozenset()
            expected_str = self._summarize_expected(exp)
            return LexerError(
                message=f"Lexing mismatch '{char}' at index {index}, expected {expected_str}",
                index=index,
                offender=char,
                expect=exp,
            )

        if rr.final and rr.accepted is None:
            mode.runner = mode.runner.reset()
            return LexerError(
                message=f"Lexing reached final state at index {index} without acceptance",
                index=index,
                offender=char,
                expect=frozenset(),
            )

        if rr.final and rr.accepted is not None:
            accepted_pos, accepted_tags = rr.accepted
            tag = mode.select_tag(accepted_tags)
            act = self.actions.get(tag)
            if act is not None:
                match act:
                    case ModeAction(action=ModeActionEnum.PUSH, mode=mode_name):
                        self.push_mode(mode_name)
                    case ModeAction(action=ModeActionEnum.POP, mode=mode_name):
                        new_mode = self.pop_mode(mode_name)
                        new_mode.reset()
                    case _:
                        raise SyncraftError(f"Unknown action {act}", offender=act, expect="PUSH, POP, or BELONG action")
            mode.runner = mode.runner.reset()
            start = mode.start_index if mode.start_index is not None else accepted_pos
            end = accepted_pos + 1
            mode.start_index = None
            return LexerResult(
                    tag=tag,
                    start=start,
                    end=end,
                    skip=tag in mode.skip
                )
            
        return None
    


@dataclass(frozen=True, slots=True)
class ExtRule(Generic[T]):
    predicate: Callable[[T], bool]
    generator: Callable[[Any, random.Random], GeneratedToken]

@dataclass(slots=True)
class ExtLexer(LexerProtocol[T]):
    rules: Dict[Tag, ExtRule[T]] = field(default_factory=dict)

    def reset(self) -> None:
        pass

    def tags(self) -> frozenset[str|Enum|None]:
        return frozenset(self.rules.keys())

    @classmethod
    def create(cls, tkspec: TokenSpec) -> Optional[ExtLexer[T]]:
        if isinstance(tkspec, TokenSpec):
            ret = cls()
            for t in tkspec.tags():
                existing = ret.rules.get(t)
                if existing is None:
                    pred = tkspec.predicate()
                    gen = tkspec.generator() 
                    ret.rules[t] = ExtRule(pred, gen)
            return ret
        return None
    
    
    def clone(self) -> "ExtLexer[T]":
        return replace(self, rules=dict(self.rules))

    

    def candidate(self) -> LexerError | LexerResult[T]:
        return LexerError.message_only("External lexer cannot provide candidates")

    def match(self, item: T, index: int) -> LexerError | None | LexerResult[T]:
        for tag in self.tags():
            if tag in self.rules and self.rules[tag].predicate(item):
                return LexerResult(tag=tag, start=index, end=index + 1, value=item, skip=False)
                
        return LexerError.new(
            message=f"External lexer token mismatch, no tag matched item '{item}'",
            index=index,
            offender=item,
            expect=self.tags()
        )
        

    def verify(self, tag: frozenset[Tag], value: Any) -> VerifiedToken:
        for t in tag:
            rule = self.rules.get(t)
            if rule is not None:
                if rule.predicate(value):
                    return VerifiedToken(True, 1)
        return VerifiedToken(False, 0)

    def gen(self, tag: Tag, rng: random.Random) -> GeneratedToken:
        rule = self.rules.get(tag)
        if rule is None or rule.generator is None:
            raise SyncraftError(
                f"External lexer cannot generate tokens for tag '{tag}'",
                offender=self,
                expect="generator callable",
            )
        return rule.generator(tag, rng)





@dataclass(frozen=True, slots=True)
class LocalLexerBuilder(LexerBuilder[C]):
    """Per-terminal lexer builder (Syncraft's default mode).
    
    Each terminal (`S.re()`, `S.lit()`) gets its own independent lexer.
    The `skip=True` flag affects only that specific terminal and is NOT
    globally applied to other terminals in the grammar.
    
    Example:
        >>> S = Syntax.set()  # Uses LocalLexerBuilder by default
        >>> _ws = S.re(r"\\s+", skip=True)  # Skip only for this terminal
        >>> expr = S.lit("a") + S.lit("b")   # "a b" will NOT parse
        >>> # Each lit() has its own lexer without whitespace skipping
    
    Use this mode when:
    - Terminals have different whitespace/spacing rules
    - Using `S.rp()` patterns with explicit spacing
    - You want fine-grained control over where skipping applies
    
    For global skip behavior, use `GlobalLexerBuilder` instead.
    """
    lexer: LexerProtocol[C] | None = field(default=None, compare=False, hash=False, repr=False)
    def __call__(self, arg: TokenSpec | Builder, **kwargs: Any) -> LocalLexerBuilder[C]:
        if isinstance(arg, TokenSpec):
            tlexer: ExtLexer[C] | None = ExtLexer.create(arg)
            if tlexer is not None:
                return LocalLexerBuilder(lexer=tlexer)
        elif isinstance(arg, Builder):
            lexer: LexerProtocol[C] | None = Lexer.create(arg, **kwargs)
            if lexer is not None:
                return LocalLexerBuilder(lexer=lexer)
        raise SyncraftError(
            f"LocalLexerBuilder cannot create a lexer from argument of type {type(arg)}",
            offender=(arg, kwargs),
            expect="a TokenSpec or Builder instance",
        )

    def resolve(self) -> LexerProtocol[C]:
        assert self.lexer is not None, "LocalLexerBuilder has not been called with valid arguments to create a lexer"
        return self.lexer

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LocalLexerBuilder):
            return False
        return self.lexer is other.lexer

    def __hash__(self) -> int:
        return hash(id(self.lexer))
    

@dataclass(slots=True)
class GlobalLexerBuilder(LexerBuilder[C]):
    """Unified DFA lexer builder for global skip behavior.
    
    All terminals are combined into a single DFA. The `skip=True` flag is
    globally applied: marked tokens are automatically filtered between ALL
    terminals in the grammar.
    
    Example:
        >>> G = Syntax.set_lexer(GlobalLexerBuilder())
        >>> _ws = G.re(r"\\s+", skip=True)  # Global skip rule
        >>> expr = G.lit("a") + G.lit("b")   # "a b" parses successfully
        >>> # Whitespace is skipped between all terminals
    
    Features requiring GlobalLexerBuilder:
    - **Global skip behavior**: skip=True applies to all terminals
    - **Lexer modes**: push/pop/of parameters for context-sensitive lexing
      (e.g., string interpolation, nested comments)
    - **Priority rules**: Disambiguate overlapping patterns with explicit
      precedence (higher priority wins)
    - **Non-greedy matching**: Shortest-match semantics instead of maximal
      munch (useful for minimal string matching)
    - **DFA caching**: Compiled lexer persisted to disk for faster startup
    
    Use this mode when:
    - All terminals share the same whitespace/comment skipping rules
    - You need lexer modes for context-sensitive tokens
    - You want traditional lexer behavior (single tokenization pass)
    - Performance optimization via compiled DFA
    
    Note: Cannot mix `S.rp()` with GlobalLexerBuilder; rp patterns are
    PEG-based and bypass the DFA lexer.
    """
    args: Set[Builder] = field(default_factory=set)

    builtin: bool = False
    cache_path: str | Path | None = None 
    lexer: LexerProtocol[C] | None = field(default=None, compare=False, hash=False, repr=False)
    def __call__(self, arg: TokenSpec | Builder, **kwargs: Any) -> GlobalLexerBuilder[C]:
        if isinstance(arg, Builder):
            # Set automatically handles deduplication
            self.args.add(arg)
            self.builtin = kwargs.get("builtin", self.builtin)
            self.cache_path = kwargs.get("cache_path", self.cache_path)
            return self
        elif isinstance(arg, TokenSpec):
            assert not self.args, "Cannot mix Syntax.lit with Syntax.re/Syntax.lit"
            lexer: ExtLexer[C] | None = ExtLexer.create(arg)
            if lexer is not None:
                return GlobalLexerBuilder(args=self.args, builtin=self.builtin, cache_path=self.cache_path, lexer=lexer)
        raise SyncraftError(
            f"GlobalLexerBuilder cannot create a lexer from argument of type {type(arg)}",
            offender=(arg, kwargs),
            expect="a TokenSpec or Builder instance",
        )
    
    def resolve(self) -> LexerProtocol[C]:
        if self.lexer is None:
            lexer: LexerProtocol[C] | None = Lexer.create(*self.args, builtin=self.builtin, cache_path=self.cache_path)
            object.__setattr__(self, 'lexer', lexer)
            if self.lexer is None:
                raise SyncraftError(
                    "GlobalLexerBuilder could not create a lexer from the provided builders",
                    offender=(self.args, self.builtin, self.cache_path),
                    expect="at least one valid Builder instance",
                )
            return self.lexer
        else:
            return self.lexer

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, GlobalLexerBuilder):
            return False
        return self.args == other.args
        

    def __hash__(self) -> int:
        return hash(frozenset(self.args))
        