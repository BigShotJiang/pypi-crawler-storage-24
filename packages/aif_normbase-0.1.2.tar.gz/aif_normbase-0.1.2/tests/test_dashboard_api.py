from fastapi.testclient import TestClient

from dashboard.main import app


async def _ok_health():
    return {"status": "healthy"}


async def _ok_mcp_health():
    return {"reachable": True, "status_code": 200}


def test_dashboard_overview(monkeypatch):
    from dashboard import main as dashboard_main

    monkeypatch.setattr(dashboard_main.clients, "normbase_health", _ok_health)
    monkeypatch.setattr(dashboard_main.clients, "eda_health", _ok_health)
    monkeypatch.setattr(dashboard_main.clients, "mcp_health", _ok_mcp_health)
    monkeypatch.setattr(dashboard_main.clients, "read_mcp_audit", lambda limit=50: [])
    monkeypatch.setenv("AIF_INTERNAL_SERVICE_TOKEN", "token-test")
    monkeypatch.setenv("AIF_API_KEY_SALT", "salt-test")

    with TestClient(app) as client:
        resp = client.get("/api/overview")
        assert resp.status_code == 200
        body = resp.json()
        assert body["normbase"]["status"] == "healthy"
        assert body["eda"]["status"] == "healthy"
        assert body["mcp"]["reachable"] is True
        assert body["security_config"]["internal_service_token_configured"] is True
        assert body["security_config"]["api_key_salt_configured"] is True


def test_dashboard_proxy_endpoints(monkeypatch):
    from dashboard import main as dashboard_main

    async def _list_norms(page_size=100):
        del page_size
        return {"items": []}

    async def _list_agents(limit=100):
        del limit
        return []

    async def _list_keys(agent_id=None, include_inactive=False):
        del agent_id, include_inactive
        return []

    monkeypatch.setattr(dashboard_main.clients, "list_norms", _list_norms)
    monkeypatch.setattr(dashboard_main.clients, "list_agents", _list_agents)
    monkeypatch.setattr(dashboard_main.clients, "list_keys", _list_keys)

    with TestClient(app) as client:
        norms = client.get("/api/norms")
        assert norms.status_code == 200
        assert norms.json() == {"items": []}

        agents = client.get("/api/agents")
        assert agents.status_code == 200
        assert agents.json() == []

        keys = client.get("/api/keys")
        assert keys.status_code == 200
        assert keys.json() == []

