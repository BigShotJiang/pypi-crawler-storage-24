from security.auth.api_keys import (
    generate_api_key,
    hash_api_key,
    mask_api_key,
    verify_api_key_hash,
)


def test_api_key_hash_and_verify(monkeypatch):
    monkeypatch.setenv("AIF_API_KEY_SALT", "test-salt")
    key = "aif_ak_example_key"
    hashed = hash_api_key(key)
    assert hashed
    assert verify_api_key_hash(key, hashed) is True
    assert verify_api_key_hash("wrong-key", hashed) is False


def test_generate_and_mask_key():
    key = generate_api_key()
    assert key.startswith("aif_ak_")
    masked = mask_api_key(key)
    assert masked.startswith("aif_ak")
    assert "..." in masked

