"""Authentication helpers shared by integrations and services."""

