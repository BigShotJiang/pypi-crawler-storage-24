"""Pydantic schemas for EDA Agent API."""
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class ValueWeightInput(BaseModel):
    value_name: str
    weight: float = Field(..., ge=0.0, le=1.0)
    hierarchy: int = 0
    rationale: str = ""


class AgentCreateRequest(BaseModel):
    agent_id: str
    agent_role: str
    llm_provider: str
    llm_api_key: str
    llm_model: str
    llm_embedding_model: str
    llm_base_url: Optional[str] = None
    llm_secret_ref: Optional[str] = None
    active_fields: List[str] = Field(default_factory=list)
    value_weights: List[ValueWeightInput] = Field(default_factory=list)
    trust_score: float = Field(0.8, ge=0.0, le=1.0)


class AgentUpdateRequest(BaseModel):
    agent_role: Optional[str] = None
    llm_provider: Optional[str] = None
    llm_api_key: Optional[str] = None
    llm_model: Optional[str] = None
    llm_embedding_model: Optional[str] = None
    llm_base_url: Optional[str] = None
    active_fields: Optional[List[str]] = None
    trust_score: Optional[float] = Field(default=None, ge=0.0, le=1.0)


class AgentSummaryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    agent_id: str
    agent_role: str
    llm_provider: str
    llm_model: str
    llm_embedding_model: str
    llm_base_url: Optional[str] = None
    llm_secret_ref: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class AgentStateResponse(BaseModel):
    agent_id: str
    agent_role: str
    beliefs: Dict[str, Any]
    norm_bindings: List[Dict[str, Any]]
    value_weights: List[Dict[str, Any]]
    active_fields: List[str]
    current_intention: Optional[str]
    trust_score: float
    created_at: datetime
    updated_at: datetime


class PerceiveRequest(BaseModel):
    input_data: Dict[str, Any]


class BindNormsRequest(BaseModel):
    context: Dict[str, Any]


class DecideRequest(BaseModel):
    candidate_actions: List[Dict[str, Any]]


class ExecuteRequest(BaseModel):
    action: Dict[str, Any]


class DecisionResponse(BaseModel):
    selected_action: Optional[Dict[str, Any]]
    ranking: List[Dict[str, Any]]


class ExecutionResponse(BaseModel):
    success: bool
    reason: Optional[str] = None
    compliance: Optional[Dict[str, Any]] = None
    trace_id: Optional[str] = None


class TraceResponse(BaseModel):
    id: str
    agent_id: str
    stage: str
    input_payload: Dict[str, Any]
    norms_applied: List[Dict[str, Any]]
    compliance_result: Dict[str, Any]
    value_ranking: List[Dict[str, Any]]
    final_action: Optional[Dict[str, Any]] = None
    result_payload: Dict[str, Any]
    latency_ms: Optional[int] = None
    created_at: datetime

