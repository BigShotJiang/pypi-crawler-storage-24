"""Auth dependencies for EDA Agent API."""
from __future__ import annotations

from typing import Annotated, Optional

from fastapi import Depends, Header, HTTPException, status

from security.auth.models import Principal
from security.auth.verifier import verify_internal_service_token


def _require_internal_token(
    authorization: Annotated[Optional[str], Header()] = None,
    x_service_token: Annotated[Optional[str], Header()] = None,
    x_agent_id: Annotated[Optional[str], Header()] = None,
    x_key_id: Annotated[Optional[str], Header()] = None,
    x_request_id: Annotated[Optional[str], Header()] = None,
    x_caller_id: Annotated[Optional[str], Header()] = None,
) -> Principal:
    principal = verify_internal_service_token(
        authorization=authorization,
        x_service_token=x_service_token,
    )
    if not principal.authenticated:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized: invalid internal service token.",
        )
    principal.agent_id = x_agent_id
    principal.key_id = x_key_id
    principal.request_id = x_request_id
    principal.caller_id = x_caller_id
    return principal


RequireInternalToken = Depends(_require_internal_token)

