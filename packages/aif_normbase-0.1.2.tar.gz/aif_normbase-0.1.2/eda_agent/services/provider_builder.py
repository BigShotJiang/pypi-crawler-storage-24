"""Build LLM provider instances from agent profile configuration."""
from typing import Any, Dict

from llm.providers import LLMProviderFactory


def build_llm_provider(
    provider_name: str,
    api_key: str,
    model: str,
    embedding_model: str,
    base_url: str | None = None,
):
    """Create one provider instance via shared factory."""
    provider_config: Dict[str, Dict[str, Any]] = {
        provider_name: {
            "api_key": api_key,
            "model": model,
            "embedding_model": embedding_model,
        }
    }
    if base_url:
        provider_config[provider_name]["base_url"] = base_url

    LLMProviderFactory.configure(provider_config)
    provider = LLMProviderFactory.get(provider_name)
    if provider is None:
        raise RuntimeError(f"Failed to initialize provider '{provider_name}'.")
    return provider

