"""Unified dashboard application package."""

