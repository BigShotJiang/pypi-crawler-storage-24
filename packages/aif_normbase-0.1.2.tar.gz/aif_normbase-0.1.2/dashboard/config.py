"""Dashboard runtime configuration."""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class DashboardSettings:
    host: str
    port: int
    debug: bool
    normbase_base_url: str
    eda_base_url: str
    mcp_base_url: str
    mcp_audit_log: str


def load_settings() -> DashboardSettings:
    return DashboardSettings(
        host=os.getenv("DASHBOARD_HOST", "0.0.0.0"),
        port=int(os.getenv("DASHBOARD_PORT", "8010")),
        debug=os.getenv("DASHBOARD_DEBUG", "false").lower() in ("1", "true", "yes"),
        normbase_base_url=os.getenv("NORMBASE_BASE_URL", "http://localhost:8001").rstrip("/"),
        eda_base_url=os.getenv("EDA_BASE_URL", "http://localhost:8002").rstrip("/"),
        mcp_base_url=os.getenv("MCP_BASE_URL", "http://localhost:8003").rstrip("/"),
        mcp_audit_log=os.getenv("AIF_MCP_AUDIT_LOG", "").strip(),
    )


settings = load_settings()

