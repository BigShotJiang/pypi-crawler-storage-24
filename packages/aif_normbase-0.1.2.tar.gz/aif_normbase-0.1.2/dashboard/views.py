"""Reserved for future server-rendered dashboard views."""

