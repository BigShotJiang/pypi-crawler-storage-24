"""HTTP clients for Normbase and EDA services."""
from __future__ import annotations

import os
from typing import Any, Dict, List

import httpx

from security.auth.verifier import build_internal_auth_headers


def _normbase_base_url() -> str:
    return os.getenv("NORMBASE_BASE_URL", "http://localhost:8001").rstrip("/")


def _eda_base_url() -> str:
    return os.getenv("EDA_BASE_URL", "http://localhost:8002").rstrip("/")


async def retrieve_norms(
    context: Dict[str, Any],
    agent_role: str,
    top_k: int = 20,
    request_id: str = "",
    caller_id: str = "",
    agent_id: str = "",
    key_id: str = "",
) -> Dict[str, Any]:
    payload = {
        "context": context,
        "agent_role": agent_role,
        "top_k": top_k,
    }
    headers = build_internal_auth_headers()
    if request_id:
        headers["X-Request-Id"] = request_id
    if caller_id:
        headers["X-Caller-Id"] = caller_id
    if agent_id:
        headers["X-Agent-Id"] = agent_id
    if key_id:
        headers["X-Key-Id"] = key_id
    async with httpx.AsyncClient(timeout=45.0) as client:
        resp = await client.post(
            f"{_normbase_base_url()}/api/v1/retrieve",
            json=payload,
            headers=headers,
        )
        resp.raise_for_status()
        return resp.json()


async def bind_norms(
    agent_id: str,
    context: Dict[str, Any],
    request_id: str = "",
    caller_id: str = "",
    key_id: str = "",
) -> Dict[str, Any]:
    payload = {"context": context}
    headers = build_internal_auth_headers()
    if request_id:
        headers["X-Request-Id"] = request_id
    if caller_id:
        headers["X-Caller-Id"] = caller_id
    if agent_id:
        headers["X-Agent-Id"] = agent_id
    if key_id:
        headers["X-Key-Id"] = key_id
    async with httpx.AsyncClient(timeout=90.0) as client:
        resp = await client.post(
            f"{_eda_base_url()}/api/v1/agents/{agent_id}/bind_norms",
            json=payload,
            headers=headers,
        )
        resp.raise_for_status()
        return resp.json()


async def get_traces(
    agent_id: str,
    limit: int = 20,
    request_id: str = "",
    caller_id: str = "",
    key_id: str = "",
) -> List[Dict[str, Any]]:
    headers = build_internal_auth_headers()
    if request_id:
        headers["X-Request-Id"] = request_id
    if caller_id:
        headers["X-Caller-Id"] = caller_id
    if agent_id:
        headers["X-Agent-Id"] = agent_id
    if key_id:
        headers["X-Key-Id"] = key_id
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(
            f"{_eda_base_url()}/api/v1/agents/{agent_id}/traces",
            params={"limit": limit},
            headers=headers,
        )
        resp.raise_for_status()
        return resp.json()

