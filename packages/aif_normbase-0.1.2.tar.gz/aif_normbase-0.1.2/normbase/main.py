"""AIF Normbase - FastAPI Application Entry Point"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import json

from normbase.config import settings
from normbase.db.connection import init_db, close_db
from normbase.api.norms import router as norms_router
from normbase.api.retrieve import router as retrieve_router
from normbase.api.keys import router as keys_router
from normbase.api.retrieve import prewarm_retrieval_service
from normbase.api.deps_auth import RequireInternalToken
from normbase.admin import admin_html


class CustomJSONResponse(JSONResponse):
    def render(self, content) -> bytes:
        return json.dumps(
            content,
            ensure_ascii=False,
            allow_nan=False,
            indent=None,
            separators=(",", ":"),
        ).encode("utf-8")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    await init_db()
    prewarm_retrieval_service()
    yield
    # Shutdown
    await close_db()


app = FastAPI(
    title="AIF Normbase API",
    description="Agent Information Field - Norm Repository",
    version="0.1.0",
    lifespan=lifespan,
    default_response_class=CustomJSONResponse,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(norms_router, prefix="/api/v1", dependencies=[RequireInternalToken])
app.include_router(retrieve_router, prefix="/api/v1", dependencies=[RequireInternalToken])
app.include_router(keys_router, prefix="/api/v1", dependencies=[RequireInternalToken])


@app.get("/")
async def root():
    """Health check endpoint"""
    return {
        "name": "AIF Normbase",
        "version": "0.1.0",
        "status": "running"
    }


@app.get("/health")
async def health():
    """Detailed health check"""
    return {
        "status": "healthy",
        "database": "connected",
        "redis": "not_checked",
        "qdrant": "not_checked"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "normbase.main:app",
        host=settings.api_host,
        port=settings.normbase_api_port,
        reload=settings.api_debug
    )
