"""Agent Zero tool modules for Dominus Node.

Each module in this package follows Agent Zero's numeric-prefix convention:

- ``01_proxy_fetch`` -- Proxied HTTP fetch, proxy config, active sessions, status
- ``02_wallet`` -- Balance, usage, top-ups, transactions, forecast, analytics
- ``03_agentic_wallets`` -- Sub-wallet CRUD, funding, freeze/unfreeze, policy
- ``04_teams`` -- Team CRUD, funding, keys, members, invitations
- ``05_account`` -- Registration, login, profile, email verification, password
- ``06_keys`` -- Personal API key CRUD
- ``07_plans`` -- Plan listing, current plan, plan changes
"""
