"""Knowledge graph components — entity extraction, graph construction, community detection."""

from res_sum.graph.knowledge_graph import KnowledgeGraph
from res_sum.graph.entities import (
    extract_from_full_paper,
    extract_from_chunks_with_consolidation,
    batch_extract,
)
from res_sum.graph.community import detect_communities, generate_community_summaries

__all__ = [
    "KnowledgeGraph",
    "extract_from_full_paper",
    "extract_from_chunks_with_consolidation",
    "batch_extract",
    "detect_communities",
    "generate_community_summaries",
]
