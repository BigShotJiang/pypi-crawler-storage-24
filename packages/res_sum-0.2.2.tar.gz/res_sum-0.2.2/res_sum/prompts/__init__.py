"""Prompt templates for summarization."""

from res_sum.prompts.templates import build_summarization_prompt

__all__ = ["build_summarization_prompt"]
