"""Evaluation metrics (Phase 3 — stubs for now)."""
