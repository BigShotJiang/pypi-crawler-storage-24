"""Interactive dashboard for exploring knowledge graphs and vector stores."""

from res_sum.explore.dashboard import generate_dashboard

__all__ = ["generate_dashboard"]
