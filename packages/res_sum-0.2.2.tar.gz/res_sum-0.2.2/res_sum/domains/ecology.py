"""Ecology domain configuration — node types, relationships, section headers, and CoT prompt."""

from res_sum.schemas import DomainConfig, EntityTypeDef


ECOLOGY_COT_TEMPLATE = """You are an expert ecological research analyst. Summarize the following scientific text using a structured chain-of-thought approach.

Follow these steps carefully:

Step 1 — RESEARCH QUESTION: Identify the primary research question or hypothesis being tested.

Step 2 — STUDY DESIGN: Extract the study design and key methods, including:
  - Study species or taxa (use scientific names where available)
  - Study location and geographic context
  - Temporal scale (duration, seasons, years)
  - Spatial scale (plot size, landscape extent, region)
  - Statistical or analytical methods used

Step 3 — KEY FINDINGS: Identify the main results with statistical evidence:
  - Report effect sizes, p-values, confidence intervals, or other metrics when available
  - Distinguish statistically significant from non-significant results
  - Note sample sizes where reported

Step 4 — ECOLOGICAL SIGNIFICANCE: Assess the ecological implications:
  - What do these findings mean for the species, community, or ecosystem studied?
  - How do they relate to broader ecological theory or conservation?
  - Are there management or policy implications?

Step 5 — LIMITATIONS: Note any limitations, caveats, or future directions mentioned by the authors.

Step 6 — SYNTHESIS: Combine the above into a clear, concise structured summary.

Provide your summary in a well-organized format with clear section headings."""


ECOLOGY_CONFIG = DomainConfig(
    name="ecology",
    entity_types=[
        EntityTypeDef(
            name="RESEARCH_PROBLEM",
            description="The research question the paper addresses",
            examples=[
                "Does wolf reintroduction trigger trophic cascades in temperate forests?",
                "How does habitat fragmentation affect pollinator diversity?",
            ],
        ),
        EntityTypeDef(
            name="FINDING",
            description="A specific empirical result with evidence (include statistics and effect direction)",
            examples=[
                "Willow height increased 3x in wolf-present areas (p<0.01, n=24 plots)",
                "Species richness declined by 40% in fragments <10ha (Shannon H: 2.1 vs 3.5)",
            ],
        ),
        EntityTypeDef(
            name="CLAIM",
            description="An interpretive conclusion the authors draw beyond the direct data — implications for ecology, conservation, or theory",
            examples=[
                "Trophic cascades in terrestrial systems are primarily behaviorally mediated",
                "Small habitat fragments cannot sustain viable pollinator populations long-term",
            ],
        ),
        EntityTypeDef(
            name="METHOD",
            description="The specific research approach used (be specific, not generic)",
            examples=[
                "MaxEnt species distribution modeling with 5 bioclimatic variables",
                "Before-after-control-impact design with camera traps across 24 plots over 10 years",
            ],
        ),
        EntityTypeDef(
            name="STUDY_SYSTEM",
            description="The organism(s), location, and ecological context combined",
            examples=[
                "Gray wolf (Canis lupus) reintroduction in Yellowstone NP, USA",
                "Neotropical dung beetle assemblages in Atlantic Forest fragments, Brazil",
            ],
        ),
        EntityTypeDef(
            name="LIMITATION",
            description="Caveats or boundary conditions acknowledged by the authors",
            examples=[
                "Correlational design cannot establish causation",
                "Study limited to a single site — generalizability unknown",
            ],
        ),
    ],
    relationship_types=[
        "ADDRESSES",
        "HAS_FINDING",
        "HAS_CLAIM",
        "USES_METHOD",
        "STUDIED_IN",
        "SUPPORTED_BY",
        "PRODUCED_BY",
        "HAS_LIMITATION",
    ],
    cot_prompt=ECOLOGY_COT_TEMPLATE,
    section_headers=[
        "study area",
        "study site",
        "study sites",
        "study species",
        "field methods",
        "field sampling",
        "data collection",
        "sampling design",
        "sampling methods",
        "statistical analysis",
        "statistical analyses",
        "data analysis",
        "data analyses",
        "experimental design",
        "materials and methods",
        "materials & methods",
        "conservation implications",
    ],
)
