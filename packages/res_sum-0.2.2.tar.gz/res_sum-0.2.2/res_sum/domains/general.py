"""General (domain-agnostic) configuration — works for any scientific field."""

from res_sum.schemas import DomainConfig, EntityTypeDef


GENERAL_COT_TEMPLATE = """You are an expert research analyst. Summarize the following scientific text using a structured chain-of-thought approach.

Follow these steps carefully:

Step 1 — RESEARCH QUESTION: Identify the primary research question or hypothesis.

Step 2 — METHODS: Extract the key methods, including study design, data sources, and analytical approaches.

Step 3 — KEY FINDINGS: Identify the main results with supporting evidence (statistics, measurements, observations).

Step 4 — SIGNIFICANCE: Assess the implications of the findings for the field.

Step 5 — LIMITATIONS: Note any limitations or future directions mentioned.

Step 6 — SYNTHESIS: Combine the above into a clear, concise structured summary.

Provide your summary in a well-organized format with clear section headings."""


GENERAL_CONFIG = DomainConfig(
    name="general",
    entity_types=[
        EntityTypeDef(
            name="RESEARCH_PROBLEM",
            description="The research question or problem the paper addresses",
            examples=["Does X cause Y?", "How does A affect B?"],
        ),
        EntityTypeDef(
            name="FINDING",
            description="A specific empirical result with evidence",
            examples=["Treatment group showed 30% improvement (p<0.05)"],
        ),
        EntityTypeDef(
            name="CLAIM",
            description="An interpretive conclusion drawn by the authors",
            examples=["These results suggest X is a viable approach for Y"],
        ),
        EntityTypeDef(
            name="METHOD",
            description="The specific research approach used",
            examples=["Randomized controlled trial with 200 participants"],
        ),
        EntityTypeDef(
            name="STUDY_SYSTEM",
            description="What was studied and in what context",
            examples=["Undergraduate students at 3 US universities"],
        ),
    ],
    relationship_types=[
        "ADDRESSES",
        "HAS_FINDING",
        "HAS_CLAIM",
        "USES_METHOD",
        "SUPPORTED_BY",
        "PRODUCED_BY",
    ],
    cot_prompt=GENERAL_COT_TEMPLATE,
    section_headers=[],
)
