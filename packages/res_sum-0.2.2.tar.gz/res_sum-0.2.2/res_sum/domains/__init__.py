"""Domain configurations for res_sum. Domains define entity types, relationships, and prompts."""

from res_sum.domains.config import load_domain, list_domains

__all__ = ["load_domain", "list_domains"]
