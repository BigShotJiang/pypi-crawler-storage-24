"""LLM provider abstraction."""

from res_sum.models.providers import get_llm

__all__ = ["get_llm"]
