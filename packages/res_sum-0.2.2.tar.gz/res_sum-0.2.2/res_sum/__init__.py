"""res_sum — A Python package leveraging LLMs for research evidence synthesis."""

from res_sum.core import ResSum
from res_sum.schemas import (
    DomainConfig,
    EntityTypeDef,
    ExtractedEntity,
    ExtractedRelationship,
    ExtractionResult,
    StructuredSummary,
)
from res_sum.domains.config import load_domain, list_domains
from res_sum.models.providers import get_llm, list_providers, list_models
from res_sum.graph.knowledge_graph import KnowledgeGraph
from res_sum.retrieval.hybrid import HybridRetriever

__version__ = "0.2.2"

__all__ = [
    "ResSum",
    "DomainConfig",
    "EntityTypeDef",
    "ExtractedEntity",
    "ExtractedRelationship",
    "ExtractionResult",
    "StructuredSummary",
    "KnowledgeGraph",
    "HybridRetriever",
    "load_domain",
    "list_domains",
    "get_llm",
    "list_providers",
    "list_models",
]
