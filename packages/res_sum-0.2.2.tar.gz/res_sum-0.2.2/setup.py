"""Minimal setup.py for backwards compatibility. Config is in pyproject.toml."""

from setuptools import setup, find_packages

setup(
    name="res_sum",
    packages=find_packages(),
    python_requires=">=3.9",
)
