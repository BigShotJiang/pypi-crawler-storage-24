"""AgentAnycast CLI tools."""
