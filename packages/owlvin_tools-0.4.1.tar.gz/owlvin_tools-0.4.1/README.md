# owlvin-tools

One MCP server, every tool an agent needs.

## Quick Start

```bash
pip install owlvin-tools
owlvin-init
```

That's it. `owlvin-init` auto-detects your editor (Claude Code, Cursor, Windsurf) and writes the MCP config.

Or manually add to `.mcp.json`:

```json
{
  "mcpServers": {
    "owlvin-tools": {
      "command": "owlvin-tools"
    }
  }
}
``` Your agent now has web search, URL fetching, code linting, data queries, health checks, process management, and more — through a single tool called `search`.

## Why One Tool?

Most MCP servers expose 10-100 tools, burning 10,000-60,000 context tokens before your agent does anything. owlvin-tools exposes **one tool** that routes internally. Your agent describes what it needs in natural language, and the server figures it out.

## What's Included

| Capability | Example | Requires |
|-----------|---------|----------|
| Web search | `search("latest Python release")` | ddgs (included) |
| URL fetch | `search("https://example.com")` | trafilatura (optional) |
| Twitter/X | `search("https://x.com/user/status/123")` | — |
| YouTube transcripts | `search("https://youtube.com/watch?v=xyz")` | yt-dlp |
| Code linting | `search("lint server.py")` | ruff (optional) |
| Data queries | `search("SELECT count(*) FROM data file.csv")` | duckdb (optional) |
| Health checks | `search("is drumsplit healthy")` | — |
| Process management | `search("what ports are listening")` | — |
| Secrets | `search("check STRIPE_SECRET_KEY")` | keyring (optional) |
| Document conversion | `search("convert report.pdf")` | docling (optional) |
| Cost tracking | `search("how much have I spent")` | OWLVIN_API_KEY |

Install optional extras:

```bash
pip install owlvin-tools[all]    # everything
pip install owlvin-tools[fetch]  # just URL fetching
pip install owlvin-tools[data]   # just SQL queries
```

## Zero-Config Alternative

```bash
uvx owlvin-tools
```
