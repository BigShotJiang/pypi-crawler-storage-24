from __future__ import annotations

"""
Shared MAVSDK System() connection manager for the PX4 configuration API.

This module ensures that we only create and maintain a small number of
MAVSDK System instances (typically one per (port, baudrate)), so that:

- We avoid repeated mavsdk_server startup/teardown and port conflicts.
- Calibration start/cancel, health checks, and status_text streaming
  all operate on the same underlying PX4 connection.

Connection state is monitored by a background watcher per connection; when
the link is lost (connection_state reports not connected or gRPC error),
we set is_connected=False so the next get_system() creates a fresh System().
"""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

from mavsdk import System

try:
    from grpc import RpcError
except ImportError:  # pragma: no cover
    RpcError = Exception  # type: ignore[misc,assignment]

log = logging.getLogger(__name__)


def _is_connection_loss(exc: BaseException) -> bool:
    """Return True if the exception indicates connection loss (so we should mark disconnected)."""
    msg = str(exc)
    return (
        "UNAVAILABLE" in msg
        or "Socket closed" in msg
        or "Connection reset by peer" in msg
        or "StatusCode.UNAVAILABLE" in msg
    )


@dataclass
class _Px4Connection:
    system: System
    lock: asyncio.Lock
    is_connected: bool = False
    watcher_task: Optional[asyncio.Task] = None
    # Background telemetry cache
    telemetry_tasks: list[asyncio.Task] = field(default_factory=list)
    latest_health: Optional[Any] = None
    latest_gps_info: Optional[Any] = None
    latest_battery: Optional[Any] = None
    health_received: bool = False


@dataclass
class CachedTelemetry:
    available: bool
    health: Optional[Any] = None
    gps_info: Optional[Any] = None
    battery: Optional[Any] = None


_connections: Dict[Tuple[str, int], _Px4Connection] = {}
_connections_lock = asyncio.Lock()


async def _watcher_loop(port: str, baudrate: int, conn: _Px4Connection) -> None:
    """
    Background task: watch connection_state(); when not connected or on error,
    set conn.is_connected = False and exit so the next get_system() can reconnect.
    """
    try:
        async for state in conn.system.core.connection_state():
            if not state.is_connected:
                async with conn.lock:
                    conn.is_connected = False
                    conn.watcher_task = None
                log.info("Connection lost (connection_state) for %s at %s baud", port, baudrate)
                return
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        async with conn.lock:
            conn.is_connected = False
            conn.watcher_task = None
        log.info(
            "Connection watcher error for %s at %s baud: %s",
            port,
            baudrate,
            exc,
            exc_info=False,
        )


async def _telemetry_health_loop(port: str, baudrate: int, conn: _Px4Connection) -> None:
    """Background task: subscribe to telemetry.health() and cache the latest value."""
    try:
        async for health in conn.system.telemetry.health():
            conn.latest_health = health
            conn.health_received = True
            if not conn.is_connected:
                break
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # pragma: no cover - best-effort cache
        log.info(
            "Telemetry health loop error for %s at %s baud: %s",
            port,
            baudrate,
            exc,
            exc_info=False,
        )


async def _telemetry_gps_loop(port: str, baudrate: int, conn: _Px4Connection) -> None:
    """Background task: subscribe to telemetry.gps_info() and cache the latest value."""
    try:
        async for info in conn.system.telemetry.gps_info():
            conn.latest_gps_info = info
            if not conn.is_connected:
                break
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # pragma: no cover - best-effort cache
        log.info(
            "Telemetry GPS loop error for %s at %s baud: %s",
            port,
            baudrate,
            exc,
            exc_info=False,
        )


async def _telemetry_battery_loop(port: str, baudrate: int, conn: _Px4Connection) -> None:
    """Background task: subscribe to telemetry.battery() and cache the latest value."""
    try:
        async for battery in conn.system.telemetry.battery():
            conn.latest_battery = battery
            if not conn.is_connected:
                break
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # pragma: no cover - best-effort cache
        log.info(
            "Telemetry battery loop error for %s at %s baud: %s",
            port,
            baudrate,
            exc,
            exc_info=False,
        )


def _start_telemetry_tasks(port: str, baudrate: int, conn: _Px4Connection) -> None:
    """Start background telemetry subscriber tasks for this connection."""
    for task in conn.telemetry_tasks:
        task.cancel()
    conn.telemetry_tasks.clear()

    conn.telemetry_tasks.append(asyncio.create_task(_telemetry_health_loop(port, baudrate, conn)))
    conn.telemetry_tasks.append(asyncio.create_task(_telemetry_gps_loop(port, baudrate, conn)))
    conn.telemetry_tasks.append(asyncio.create_task(_telemetry_battery_loop(port, baudrate, conn)))


async def mark_disconnected(port: str, baudrate: int) -> None:
    """
    Mark the connection for (port, baudrate) as disconnected: set is_connected=False
    and cancel the watcher task. Next get_system() will create a new System() and reconnect.
    """
    key = (port, baudrate)
    async with _connections_lock:
        conn = _connections.get(key)
        if conn is None:
            return
        async with conn.lock:
            conn.is_connected = False
            if conn.watcher_task:
                conn.watcher_task.cancel()
                conn.watcher_task = None
            for task in conn.telemetry_tasks:
                task.cancel()
            conn.telemetry_tasks.clear()
        log.info("Marked disconnected: %s at %s baud", port, baudrate)


async def is_connected(port: str, baudrate: int) -> bool:
    """
    Return the current in-memory connection state for (port, baudrate).
    No I/O and does not trigger reconnect. Used by the heartbeat route.
    """
    key = (port, baudrate)
    conn = _connections.get(key)
    if conn is None:
        return False
    return conn.is_connected


async def cancel_all_watchers(shutdown_timeout_s: float = 2.0) -> None:
    """
    Cancel all connection watcher tasks so the process can exit cleanly.
    Call from FastAPI lifespan on shutdown.
    """
    async with _connections_lock:
        tasks: list[asyncio.Task] = []
        for conn in _connections.values():
            if conn.watcher_task:
                conn.watcher_task.cancel()
                tasks.append(conn.watcher_task)
                conn.watcher_task = None
            for t in conn.telemetry_tasks:
                t.cancel()
                tasks.append(t)
            conn.telemetry_tasks.clear()
    for t in tasks:
        try:
            await asyncio.wait_for(asyncio.shield(t), timeout=shutdown_timeout_s)
        except (asyncio.CancelledError, asyncio.TimeoutError):
            pass


async def _wait_for_connection(system: System, timeout_s: float) -> bool:
    """Wait until connection_state reports is_connected, with a timeout."""
    async for state in system.core.connection_state():
        if state.is_connected:
            return True
    return False


async def get_system(
    port: str,
    baudrate: int,
    timeout_s: float = 10.0,
) -> System:
    """
    Return a shared MAVSDK System instance for the given serial port/baudrate.

    The first caller for a (port, baudrate) pair will create and connect the
    System; subsequent callers reuse the same connection. If the connection
    is marked disconnected (watcher or mark_disconnected), the next caller
    gets a new System() and reconnects. If the connection cannot be established
    within `timeout_s`, an exception is raised.
    """

    key = (port, baudrate)

    conn = _connections.get(key)
    if conn is None:
        async with _connections_lock:
            conn = _connections.get(key)
            if conn is None:
                conn = _Px4Connection(
                    system=System(),
                    lock=asyncio.Lock(),
                    is_connected=False,
                    watcher_task=None,
                )
                _connections[key] = conn

    # Only one task at a time should (re)connect this System
    async with conn.lock:
        if conn.is_connected:
            return conn.system

        # Reconnect path: cancel watcher if present, create new System
        if conn.watcher_task:
            conn.watcher_task.cancel()
            try:
                await conn.watcher_task
            except asyncio.CancelledError:
                pass
            conn.watcher_task = None

        new_system = System()
        conn.system = new_system
        serial = f"serial://{port}:{baudrate}"
        await conn.system.connect(system_address=serial)

        try:
            connected = await asyncio.wait_for(
                _wait_for_connection(conn.system, timeout_s),
                timeout=timeout_s,
            )
        except (RpcError, Exception, asyncio.TimeoutError):
            connected = False

        if not connected:
            # Leave is_connected as False so a later caller can retry.
            raise TimeoutError(
                f"Timed out connecting to PX4 on {port} at {baudrate} baud."
            )

        conn.is_connected = True
        _start_telemetry_tasks(port, baudrate, conn)
        conn.watcher_task = asyncio.create_task(_watcher_loop(port, baudrate, conn))
        log.info("Connected to PX4 on %s at %s baud", port, baudrate)
        return conn.system


async def get_cached_telemetry(port: str, baudrate: int) -> CachedTelemetry:
    """
    Return the latest cached telemetry for this connection.

    This is a zero-I/O helper intended for latency-sensitive health checks.
    """
    key = (port, baudrate)
    conn = _connections.get(key)
    if conn is None or not conn.is_connected:
        return CachedTelemetry(available=False)
    return CachedTelemetry(
        available=True,
        health=conn.latest_health,
        gps_info=conn.latest_gps_info,
        battery=conn.latest_battery,
    )

