# Your AI Coding Agent Has Amnesia. Here's the Cure.

*Every session starts from zero. Every session, the agent forgets. I got tired of it — so I built persistent memory for my AI agent and open-sourced it.*

---

Picture this.

You open Claude Code. You type your task. The agent starts reading files — `memory.md`, `consumer.py`, `prompts.py`, `model_builder.py` — one after another. Five minutes pass. The context window is climbing. Not a single line of code has been written yet.

Then the agent makes a change. A reasonable-looking change. Except that file had a rule from three weeks ago — a decision that took 45 minutes to reason through. The agent didn't know. It read the file, not the *history*.

You correct it. The context window is now 60% full. You haven't shipped anything.

If you've been building anything serious with AI coding tools, you know this scene.

---

## The Problem Has a Name: Stateless Sessions

Every time you start a new AI coding session, your agent starts from absolute zero.

It has no memory of what it did last time. No memory of which files are off-limits. No idea what phase the project is in, what's already been tried, or why a particular decision was made three weeks ago.

So it reads. And reads. And reads.

I tracked this on my own codebase — a Python data platform with 400+ files and 26 phases of development — for a few weeks:

- **12,000–18,000 tokens** burned on orientation before any code was written
- **8–15 source files** read before the first edit
- **1 in 3 sessions** hitting the context limit before the task was done
- **1 in 4 sessions** where the agent quietly reversed a decision I'd intentionally made

That last number hit hardest. Not the cost — the *undo*. An agent confidently touching a file it didn't fully understand, reversing a hard-won architectural decision, with no indication that anything had gone wrong.

There had to be a better way.

---

## The Key Insight

The agent was reading `memory.md` — 3,500 lines of project history — not because it wanted to. It read it because that was the *only* way to understand the project state.

That's the wrong delivery mechanism.

The same information can be delivered as structured, queryable data:

```
# Before — reading files
Read memory.md        → 3,500 lines → ~10,000 tokens
Read journal.md       → 2,452 lines → ~7,000 tokens
Read 5 more files     → ~3,000 tokens
Total: 12,000–18,000 tokens just to orient

# After — querying structured data
get_roadmap()         → current phase, next action     ~400 tokens
get_node(file)        → role, rules, do_not_revert     ~200 tokens
get_impact(file)      → blast radius before editing    ~300 tokens
Total: ~1,000–2,500 tokens — and the agent knows more
```

Same project knowledge. 75–85% fewer tokens. And the structured data contains *exactly* what the agent needs — not everything ever written.

That was the idea. So I built it.

---

## What I Built: Codevira MCP

**Codevira** is a local [Model Context Protocol](https://modelcontextprotocol.io) server that gives your AI agent persistent memory — across every session, every tool, every file.

It has four core components:

### 1. The Context Graph — A Memory for Each File

Every important file in your codebase gets a YAML node with structured metadata the agent can act on:

```yaml
src/services/generator/prompts.py:
  role: "ALL LLM prompt templates for generation passes"
  stability: medium
  do_not_revert: true
  rules:
    - "Never drop the synonyms field — downstream indexer requires it"
  connects_to:
    - target: src/services/generator/llm_strategy.py
      edge: consumed_by
  last_changed_by: "Phase 17 — synonym generation fix"
```

When the agent calls `get_node("prompts.py")`, it gets ~200 tokens of structured intelligence — the role, the rules it must respect, what it connects to, and whether it contains protected decisions.

When it calls `get_impact("prompts.py")`, it gets a graph traversal — every file downstream of this one, how deep, and which are marked `do_not_revert`. Before touching a single line, the agent knows the blast radius.

The `do_not_revert` flag sounds simple — it's just a boolean in a YAML file. But it's the difference between an agent that undoes your hard work once a week and one that almost never does.

### 2. Semantic Code Search — Find Instead of Read

Instead of reading five files hoping to stumble across the right function, the agent searches:

```
search_codebase("payment validation flow")
→ Returns the exact function, with source, in one call
```

ChromaDB under the hood, with AST-level chunking (one chunk per function, not per file) so searches find the specific pattern needed — not a vague file-level match.

The index stays current via timestamp-based change detection, not commit-based. Every save is caught — committed or not. This matters: stale search results are how AI hallucinations happen in a coding context. The agent isn't making things up — it's confidently working from outdated information.

### 3. The Queryable Roadmap — Project State as Data

Every team I've seen tracks project progress in a markdown file or Notion doc — readable by humans, invisible to agents. I replaced my `memory.md` with a YAML roadmap:

```yaml
current_phase:
  number: 26
  name: "Context Graph Auto-Refresh"
  status: in_progress
  next_action: "Implement CI step to detect drifted graph nodes"

completed_phases:
  - phase: 23
    name: "Context Assembly Pipeline"
    key_decisions:
      - "entity_id reconciliation: resolved by name_to_id dict"
```

`get_roadmap()` returns the current phase and next action in ~400 tokens. Agents can also *write* to it — queuing new phases, completing current ones, recording key decisions inline. The roadmap stays current with actual project state.

### 4. The Session Protocol — Making It Stick

Having the tools is one thing. Making agents use them consistently is another.

Every session follows a mandatory ritual:

**Session start:**
```
list_open_changesets()        → any unfinished work to resume?
get_roadmap()                 → where are we, what's next?
search_decisions("keyword")   → has this been decided before?
get_node(file)                → rules before touching anything
get_impact(file)              → blast radius before editing
```

**Session end:**
```
complete_changeset(id, decisions)
update_node(file_path, changes)
update_next_action("exact description for the next agent")
write_session_log(...)
```

The changeset system solves multi-file changes that hit the context limit mid-way. The session records which files are done and which are pending. The next session picks it up and knows exactly where to continue.

---

## The Honest Numbers

Across ~15 sessions on a 400-file Python codebase after the framework was stable:

| Metric | Before | After |
|---|---|---|
| Tokens on orientation | 12,000–18,000 | 1,000–2,500 |
| Files read before first edit | 8–15 | 0–2 |
| Sessions hitting context limit | ~1 in 3 | ~1 in 10 |
| Agent reversing a protected decision | ~1 in 4 | ~1 in 20 |
| Multi-file changes resuming cleanly | ~30% | ~85–90% |

These are from one codebase, one developer. Treat them as directional.

The token reduction is structural — it's fixed by how much information is in the graph vs. the raw files. The blast radius protection is the one I care about most. Going from "roughly 1 in 4 sessions, the agent undoes something" to "this almost never happens" — that's not a metric, that's peace of mind.

---

## What Broke Along the Way

**Search wasn't finding the right things.** Early on, I was embedding whole files as single chunks, so a search for a specific function returned a file-level average. Switching to function-level chunking fixed it completely.

**The stale index problem almost broke everything.** During active development I'd be saving files constantly — and the agent was searching code from hours ago. It would confidently cite functions that had been refactored. Switching from commit-based to timestamp-based change detection caught every save.

**The MCP SDK silently broke the server.** Version 1.26.0 changed `stdio_server` from a coroutine to an async context manager. No error — just silent connection failure. The correct pattern now:

```python
async def _run():
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())

asyncio.run(_run())
```

If you're building MCP servers, save yourself half a session of debugging.

---

## Is This For You?

If your codebase is small — under 50 files, early stage, few interdependencies — a well-written `CLAUDE.md` is probably enough. The overhead doesn't pay back at small scale.

Codevira earns its keep when:

- You have **50+ files** with real interdependencies
- You're running **multiple agent sessions per week**
- You have **accumulated decisions** that must survive across sessions
- You've been burned by an **agent undoing** intentional choices
- You're working across **more than one AI tool** on the same codebase

---

## Try It

Codevira MCP is open source under the MIT license. 26 tools, five modules, works with Claude Code, Cursor, Windsurf, and any MCP-compatible tool. Runs entirely locally — no API keys, no data leaving your machine.

Setup is one command:

```bash
git clone https://github.com/sachinshelke/codevira .agents
pip install -r .agents/requirements.txt
python .agents/indexer/index_codebase.py --full --generate-graph --bootstrap-roadmap
```

Add to your MCP config:

```json
{
  "mcpServers": {
    "codevira": {
      "command": "python",
      "args": [".agents/mcp-server/server.py"]
    }
  }
}
```

Add four lines to your `CLAUDE.md`:

```
At session start: call list_open_changesets(), get_roadmap(), get_node(), get_impact()
before touching any file.
At session end: call complete_changeset(), update_node(), update_next_action().
```

Try it for a week. Watch your context window. See how often the agent runs out before finishing. See how often it reverses something you didn't want reversed.

---

## The Shift That Surprised Me

When I started this, I framed it as a token efficiency problem — save tokens, save money, ship faster.

That framing is correct, but it undersells what actually changes.

The bigger shift is how you feel about starting a session. Before — there was always low-level anxiety. Will the agent remember what matters? Will it undo something? Will the session run out before the task is done?

After — the agent orients itself in seconds, and you mostly just do the work.

That shift from supervision to collaboration is what the tooling actually buys you. The token reduction is how you measure it. The feeling is why it matters.

---

**GitHub:** [github.com/sachinshelke/codevira](https://github.com/sachinshelke/codevira)

*MIT licensed. Contributions welcome. If you try it and have results — good or bad — open a Discussion on GitHub. The numbers above are from one project; the more data points from different codebases, the better picture we all get.*

---

*If this resonated, follow for more on building with AI agents, developer tooling, and the unglamorous parts of shipping software.*
