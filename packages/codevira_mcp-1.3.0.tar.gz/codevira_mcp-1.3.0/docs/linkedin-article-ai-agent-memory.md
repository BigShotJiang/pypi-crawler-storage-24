# I Was Losing Hours Every Week to My AI Coding Agent. So I Fixed It.

*How I cut AI agent orientation time by 85% — and open-sourced the solution.*

---

Here's something no one in the AI tooling space talks about honestly:

**Your AI coding agent forgets everything the moment a session ends.**

Every time you start a new session — in Claude Code, Cursor, Windsurf, wherever — the agent starts from absolute zero. It re-reads the same files. Re-discovers the same patterns. Makes decisions that contradict ones made last week. Has no idea what phase your project is in, what's already been tried, or why a particular file is off-limits.

And you pay for it. Every single session.

---

## The Hidden Cost of Stateless AI Sessions

I started tracking this on my own codebase — a Python data platform with 400+ files and 26 phases of development.

The numbers were worse than I expected:

- **12,000–18,000 tokens** burned on orientation before any code was written
- **8–15 source files** read before the first edit
- **1 in 3 sessions** hitting the context limit before the task was done
- **1 in 4 sessions** where the agent quietly reversed a decision I'd intentionally made

That last number is the one that should concern any engineering team.

It's not just a productivity problem. It's a **reliability problem.** An agent with no memory of past decisions will confidently undo architectural choices, remove constraints that exist for good reasons, and repeat mistakes that were already resolved. With no indication that anything went wrong.

At small scale, this is annoying. At team scale — multiple developers, multiple sessions per day, a codebase with real interdependencies — this becomes a genuine engineering risk.

---

## The Root Cause: Agents Read When They Should Query

The agent re-reads `memory.md` (3,500 lines, ~10,000 tokens) every session not because it wants to — but because that's the *only* way it can understand the project state.

There's no alternative. If you want to know what phase the project is in, you read the file. If you want to know the rules for a specific file, you read the file. If you want to know what will break if you touch something, you trace imports manually.

That's the wrong delivery mechanism for structured information.

The same project knowledge can be delivered as queryable data:

```
# Old approach — reading files
memory.md      → 3,500 lines → ~10,000 tokens
journal.md     → 2,452 lines → ~7,000 tokens
5 more files   →              → ~3,000 tokens
─────────────────────────────────────────────
Total: 12,000–18,000 tokens before the first line of code

# New approach — querying structured data
get_roadmap()  → current phase, next action     ~400 tokens
get_node(file) → role, rules, protected flags   ~200 tokens
get_impact()   → full dependency blast radius   ~300 tokens
─────────────────────────────────────────────
Total: ~1,000–2,500 tokens — and the agent knows more
```

Same knowledge. 75–85% fewer tokens. And critically — the structured data contains exactly what the agent needs, not everything ever written.

---

## What I Built to Fix This

I spent several weeks building a framework that gives AI coding agents persistent memory. Then I open-sourced it as **Codevira MCP**.

It's a local [Model Context Protocol](https://modelcontextprotocol.io) server — one JSON config block and it connects to any MCP-compatible AI tool your team uses.

Here's what it provides:

**Context Graph** — Every important file gets a YAML node: its role, the rules any agent must respect, its dependencies, its stability level, and a `do_not_revert` flag for decisions that must never be reversed. Before touching a file, the agent queries the node. Before editing, it checks the blast radius via BFS graph traversal.

**Semantic Code Search** — Natural language search across the codebase at function level. `search_codebase("payment validation flow")` returns the exact function — not a list of files to read through. The index updates on every file save, not just on commit, so results are never stale.

**Queryable Roadmap** — Project phase tracking as structured data, not a markdown file. Agents can query the current phase, next action, and open work. They can also write to it — recording decisions, advancing phases, queuing new work — so the roadmap reflects actual state, not just what was planned.

**Changeset Tracking** — Multi-file changes tracked atomically. If a session hits the context limit mid-change, the changeset records what's done and what's pending. The next session picks it up and resumes cleanly instead of starting over or — worse — thinking the job is done.

**Session Protocol** — A mandatory start/end ritual that every agent follows. Session start: query the roadmap, check open changesets, review node rules before touching files. Session end: record decisions, update nodes, set the next action for whoever comes next.

---

## Results Across 15 Sessions

These are from one codebase. Treat them as directional, not benchmarks.

**Orientation tokens:** 12,000–18,000 → 1,000–2,500
The agent queries structured data instead of reading files. The reduction is structural — fixed by how rich your graph nodes are.

**Files read before first edit:** 8–15 → 0–2
Most sessions now start with zero file reads. The agent already knows what it needs.

**Sessions hitting context limit:** ~1 in 3 → ~1 in 10
Not running out of context mid-task changes how you plan and scope sessions entirely.

**Agent reversing a protected decision:** ~1 in 4 → ~1 in 20
This one matters most. The `do_not_revert` flag surfaces protection *before the edit* — preventing the mistake rather than catching it after.

**Multi-file changes resuming cleanly:** ~30% → ~85–90%
Changeset tracking means a session interrupted mid-way picks up exactly where it left off.

The number I care most about: going from "roughly 1 in 4 sessions, the agent undoes something intentional" to "this almost never happens." For a solo developer, that's less frustration. For a team, that's fewer production incidents and less time spent asking "why did this change?"

---

## When Does This Matter?

If your codebase is small — under 50 files, early stage, simple structure — a well-written `CLAUDE.md` is probably enough. The overhead of maintaining a context graph doesn't pay back at that scale.

Codevira earns its keep when:

- You have **50+ files** with real interdependencies
- Your team runs **multiple AI coding sessions per week**
- You have **accumulated decisions** that must survive across sessions and across developers
- You work across **more than one AI tool** on the same codebase
- You've been burned by an **agent undoing** something intentional

At that point, the maintenance overhead is genuinely small compared to the reliability and productivity problems it eliminates.

---

## Try It

Codevira MCP is open source under the MIT license. 26 tools across five modules. Works with Claude Code, Cursor, Windsurf, and Google Antigravity. Runs entirely locally — no external services, no API keys, no data leaving your machine.

```bash
git clone https://github.com/sachinshelke/codevira .agents
pip install -r .agents/requirements.txt
python .agents/indexer/index_codebase.py --full --generate-graph --bootstrap-roadmap
```

Full setup guide, tool reference, and agent persona definitions: [github.com/sachinshelke/codevira](https://github.com/sachinshelke/codevira)

---

## The Shift I Didn't Expect

I built this as a token efficiency tool. Save tokens, reduce cost, ship faster.

That framing is correct — but it misses what actually changes day to day.

The bigger shift is how you feel about starting a session. Before Codevira, there was always low-level anxiety: will the agent remember what matters? Will it undo something? Will the context run out before we're done?

After: the agent orients in seconds. You mostly just do the work.

That shift — from supervising the agent to collaborating with it — is what persistent memory actually buys you.

The token reduction is how you measure it. The feeling is why it matters.

---

*Building something similar or have results to share? Drop a comment — curious what patterns others are hitting on larger codebases.*

*Follow for more on AI-assisted engineering, developer tooling, and practical lessons from building with agents.*
