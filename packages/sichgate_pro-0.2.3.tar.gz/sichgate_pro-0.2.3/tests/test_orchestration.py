"""
tests/test_orchestration.py — Runner and API orchestration tests.

Tests the AttackRunner, attack scheduling, and result aggregation.
"""
import pytest
import json
from unittest.mock import Mock, patch, MagicMock

from sichgate.runner import AttackRunner
from sichgate.schema import RunSummary, now_iso


class TestAttackRunner:
    """Test the AttackRunner orchestrator."""

    @pytest.fixture
    def mock_model(self):
        """Mock ModelAdapter."""
        model = Mock()
        model.model_path = "test_model"
        model.model_type = "huggingface"
        model.query = Mock(return_value="test response")
        return model

    def test_runner_initialization(self, mock_model):
        """Test AttackRunner setup."""
        runner = AttackRunner(optimize=False)
        assert runner is not None
        assert hasattr(runner, 'run')

    def test_runner_has_optimize_flag(self):
        """Test optimize parameter."""
        runner1 = AttackRunner(optimize=False)
        assert runner1.optimize is False
        
        runner2 = AttackRunner(optimize=True)
        assert runner2.optimize is True

    def test_runner_accepts_optuna_trials_param(self):
        """Test Optuna trials configuration."""
        runner = AttackRunner(n_optuna_trials=100)
        assert runner.n_optuna_trials == 100
