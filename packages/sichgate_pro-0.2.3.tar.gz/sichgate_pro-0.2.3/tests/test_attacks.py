"""
tests/test_attacks.py — Test all attack implementations.

Uses mocks for models and databases. Zero external dependencies.
"""
import pytest
from unittest.mock import Mock, patch, MagicMock

from sichgate.schema import AttackResult, ExecutionTelemetry, now_iso
from sichgate.attacks.llm.prompt_injection import PromptInjectionDirect
from sichgate.attacks.base import BaseAttack


class TestPromptInjectionDirect:
    """Test prompt injection attack."""

    def test_direct_injection_attack_exists(self):
        """Test that PromptInjectionDirect class exists."""
        attack = PromptInjectionDirect()
        assert attack.attack_type == "llm"
        assert attack.attack_name == "prompt_injection_direct"

    def test_attack_has_compliance_tags(self):
        """Test attack declares compliance concerns."""
        attack = PromptInjectionDirect()
        assert len(attack.compliance_tags) > 0
        assert any("NIST" in tag or "EU" in tag for tag in attack.compliance_tags)

    def test_attack_has_default_severity(self):
        """Test default severity is set."""
        attack = PromptInjectionDirect()
        assert attack.default_severity in ("critical", "high", "medium", "low")


class TestBaseAttackStructure:
    """Test BaseAttack contract."""

    def test_base_attack_requires_subclass_fields(self):
        """Verify subclass must define required fields."""
        attack = PromptInjectionDirect()
        assert hasattr(attack, 'attack_type')
        assert hasattr(attack, 'attack_name')
        assert hasattr(attack, 'compliance_tags')
        assert hasattr(attack, 'default_severity')

    def test_base_attack_has_run_method(self):
        """Test BaseAttack.run() method exists."""
        attack = PromptInjectionDirect()
        assert hasattr(attack, 'run')
        assert callable(attack.run)
