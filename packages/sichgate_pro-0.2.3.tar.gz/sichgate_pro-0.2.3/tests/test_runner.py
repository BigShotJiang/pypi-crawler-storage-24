"""
tests/test_runner.py — Runner smoke tests.

Minimal. You will write the real tests.
"""

import pytest
from unittest.mock import MagicMock, patch
from sichgate.runner import AttackRunner, resolve_attack_names, ALL_ATTACKS


class TestResolveAttackNames:
    def test_all_expands(self):
        names = resolve_attack_names(["all"])
        assert len(names) > 0
        assert "prompt_injection_direct" in names

    def test_category_expands(self):
        names = resolve_attack_names(["llm"])
        assert "prompt_injection_direct" in names
        assert "jailbreak_many_shot" in names

    def test_specific_name(self):
        names = resolve_attack_names(["prompt_injection_direct"])
        assert names == ["prompt_injection_direct"]

    def test_unknown_name_skipped(self):
        names = resolve_attack_names(["does_not_exist"])
        assert "does_not_exist" not in names

    def test_deduplication(self):
        names = resolve_attack_names(["all", "llm", "prompt_injection_direct"])
        assert names.count("prompt_injection_direct") == 1

    def test_hyphen_normalized(self):
        names = resolve_attack_names(["prompt-injection"])
        assert len(names) >= 1  # at least one injection attack matched
