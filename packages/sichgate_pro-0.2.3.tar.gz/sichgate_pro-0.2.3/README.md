# SichGate Pro

AI red teaming and compliance infrastructure for small language models deployed in regulated industries.

SichGate Pro runs adversarial tests against your AI models and generates EU AI Act Article 11 Technical Documentation automatically. It surfaces real vulnerabilities — bias, jailbreaks, prompt injection, hallucination, alignment failures — with findings mapped directly to regulatory requirements.

Every scan produces:
- Validated adversarial findings with severity ratings
- EU AI Act Annex IV section coverage
- CycloneDX 1.6 AI Bill of Materials (AIBoM)
- Cryptographic attestation (ed25519)
- Differential red teaming report (base vs. fine-tuned model)
- Article 11 Technical File PDF

---

## Installation

```bash
pip install sichgate-pro
```

Requires Python 3.9+.

---

## Quick start

```bash
# Activate your license
sichgate activate SG-XXXX-XXXX-XXXX-XXXX

# Run adversarial tests
sichgate run --model Qwen/Qwen2-1.5B-Instruct --output results.json

# Generate EU AI Act Technical File
sichgate technical-file --findings results.json --output technical_file.pdf

# System health check
sichgate check

# List all available attack modules
sichgate list-attacks
```

---

## Commands

| Command | Description |
|---|---|
| `sichgate activate` | Activate license key |
| `sichgate deactivate` | Free this machine's license seat |
| `sichgate run` | Execute adversarial test suite |
| `sichgate technical-file` | Generate Article 11 Technical File PDF |
| `sichgate diff` | Differential report: base vs. fine-tuned model |
| `sichgate check` | System preflight and health check |
| `sichgate list-attacks` | Show all available attack modules |
| `sichgate estimate-cost` | Estimate scan cost before running |

---

## sichgate run

```
sichgate run --model MODEL [OPTIONS]
```

| Option | Default | Description |
|---|---|---|
| `--model`, `-m` | required | HuggingFace model ID or local path |
| `--attacks`, `-a` | `all-llm` | Attack group or comma-separated names |
| `--output`, `-o` | (print only) | Write results to JSON file |
| `--device` | auto | Force device: `cpu`, `cuda`, `mps` |
| `--adapter` | `hf` | Model adapter: `hf`, `openai_compat`, `callable` |
| `--aibom` | off | Capture CycloneDX 1.6 AIBoM |
| `--attest` | off | Sign report with ed25519 attestation |
| `--key-path` | (generate) | Path to ed25519 private key PEM |
| `--api-mode` | off | Lightweight battery for API deployments |
| `--provider` | `gpt-4o` | API provider (with `--api-mode`) |
| `--optimize` | off | Auto-tune attacks with Optuna |
| `--verbose`, `-v` | off | Verbose logging |

---

## Attack groups

| Group | Attacks included |
|---|---|
| `all-llm` | prompt-injection, jailbreak, token-smuggling, system-prompt-extraction, pii-leakage, training-data-extraction |
| `all-evasion` | prompt-perturbation, simba, nes, hopskipjump, transfer |
| `all` | everything above + model-extraction, backdoor-probe, membership-inference |

Run `sichgate list-attacks` to see all available names.

---

## Attack coverage

| Attack | Name flag |
|---|---|
| Prompt injection (direct) | `prompt-injection-direct` |
| Prompt injection (indirect) | `prompt-injection-indirect` |
| Jailbreak roleplay / persona | `jailbreak` |
| Token smuggling / encoding bypass | `token-smuggling` |
| System prompt extraction | `system-prompt-extraction` |
| PII leakage probe | `pii-leakage` |
| Training data extraction | `training-data-extraction` |
| Adversarial text perturbation | `prompt-perturbation` |
| SimBA word substitution | `simba` |
| NES evolved variants | `nes` |
| HopSkipJump boundary probe | `hopskipjump` |
| Cross-model transfer attack | `transfer` |
| Model architecture extraction | `model-extraction` |
| Backdoor trigger probe | `backdoor-probe` |
| Membership inference (score-based) | `membership-inference` |

---

## Loading models

### HuggingFace Hub

```bash
sichgate run --model Qwen/Qwen2-1.5B-Instruct
sichgate run --model meta-llama/Llama-3.2-1B-Instruct
sichgate run --model microsoft/Phi-3-mini-4k-instruct
```

### Local HuggingFace format

Folder containing `config.json` + `model.safetensors` (or `.bin`):

```bash
sichgate run --model ./path/to/your-model
sichgate run --model ./medassist-tinyllama
```

### Apple Silicon

On M-series Macs, pass `--device cpu` to avoid the MPS 4 GB NDArray limit during inference:

```bash
sichgate run --model Qwen/Qwen2-1.5B-Instruct --device cpu --output results.json
```

### OpenAI-compatible API endpoint

```bash
sichgate run \
  --model gpt-4o \
  --adapter openai_compat \
  --api-mode \
  --provider gpt-4o \
  --output results.json
```

---

## sichgate diff

Compare a base model against a fine-tuned variant. Runs the full attack battery on both and reports which vulnerabilities worsened, improved, or stayed the same.

```bash
sichgate diff \
  --base-model TinyLlama/TinyLlama-1.1B-Chat-v1.0 \
  --custom-model ./medassist-tinyllama \
  --output differential_report.json
```

| Option | Description |
|---|---|
| `--base-model` | Base model path or HuggingFace ID |
| `--custom-model` | Fine-tuned model path or HuggingFace ID |
| `--attacks`, `-a` | Attack group (default: `all-llm`) |
| `--output`, `-o` | Write differential report to JSON |
| `--aibom` / `--no-aibom` | Embed AIBoM for both models (default: on) |
| `--attest` | Sign report with ed25519 |
| `--key-path` | Path to ed25519 private key PEM |
| `--adapter` | Model adapter: `hf`, `openai_compat` |

---

## sichgate technical-file

Generate an EU AI Act Article 11 Technical File from scan results.

```bash
sichgate technical-file \
  --findings results.json \
  --output technical_file.pdf
```

With all optional inputs:

```bash
sichgate technical-file \
  --findings results.json \
  --aibom aibom.json \
  --differential differential_report.json \
  --attest \
  --key-path signing_key.pem \
  --output technical_file.pdf
```

Produces three artefacts: `technical_file.pdf`, `technical_file.html`, `technical_file.json`.

If `results.json` was produced with `--aibom`, the AIBoM is loaded automatically — no separate `--aibom` flag needed.

---

## sichgate estimate-cost

Show query counts and estimated API cost before running.

```bash
# API mode estimate
sichgate estimate-cost --mode api --provider gpt-4o

# Local mode estimate
sichgate estimate-cost --mode local
```

---

## Full workflow example

```bash
# 1. Health check
sichgate check

# 2. Run full attack battery
sichgate run \
  --model Qwen/Qwen2-1.5B-Instruct \
  --attacks all \
  --device cpu \
  --aibom \
  --attest \
  --output results.json

# 3. Compare against fine-tuned variant
sichgate diff \
  --base-model Qwen/Qwen2-1.5B-Instruct \
  --custom-model ./my-finetuned-model \
  --device cpu \
  --output differential_report.json

# 4. Generate Technical File
sichgate technical-file \
  --findings results.json \
  --differential differential_report.json \
  --attest \
  --output technical_file.pdf
```

---

## Compliance frameworks

Findings are automatically mapped to:

- EU AI Act (Regulation (EU) 2024/1689) — Articles 9, 10, 13, 14, 15 + Annex IV
- GDPR — Articles 5, 17, 22
- HIPAA — §164.308, §164.312
- NIST AI RMF — GOVERN, MAP, MEASURE, MANAGE
- ISO/IEC 42001
- OWASP LLM Top 10
- CycloneDX 1.6 ML-BOM
- NIST Cyber AI Profile (IR 8596)

---

## License

Proprietary. License key required.

```bash
sichgate activate SG-XXXX-XXXX-XXXX-XXXX
```

Purchase at sichgate.com. Activates online once, then works fully offline. 7-day grace period for network outages.

---

## Support

- Email: support@sichgate.com
- Website: sichgate.com
