# Surrogate Model Setup

The bundled surrogate model is required for transfer-based evasion attacks.

## What it is
A quantized TinyLlama 1.1B (~80MB when quantized to INT4/INT8).
Used by `evasion_transfer` to generate adversarial examples offline.

## Setup

```bash
# One-time setup — downloads and quantizes the surrogate
python -c "
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model_name = 'TinyLlama/TinyLlama-1.1B-Chat-v1.0'
save_path = './model'

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float16)

tokenizer.save_pretrained(save_path)
model.save_pretrained(save_path)
print('Surrogate ready at', save_path)
"
```

## Notes
- The surrogate is used locally only — no data is transmitted
- If not present, transfer attacks are skipped with a warning (not a crash)
- For the pip package build, pre-download and quantize before running `python -m build`
