"""
SichGate — Comprehensive AI Security Testing Framework
"""
