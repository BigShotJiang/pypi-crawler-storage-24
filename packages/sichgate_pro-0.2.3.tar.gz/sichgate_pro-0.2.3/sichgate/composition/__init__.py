"""Gap #4: Multi-Model Composition Testing — cascade failure and data leakage detection."""
from sichgate.composition.pipeline import (
    CompositionTemplate,
    ModelStage,
    CompositionPipeline,
    PipelineTrace,
)

__all__ = ["CompositionTemplate", "ModelStage", "CompositionPipeline", "PipelineTrace"]
