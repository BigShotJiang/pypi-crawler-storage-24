"""
_constants.py — Supabase credentials (anon/public keys, safe to bundle).
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Allow local .env override (dev workflow), fall back to bundled defaults
load_dotenv(Path(__file__).parent.parent / ".env")

SUPABASE_URL      = os.environ.get("SUPABASE_URL",      "https://vhuaqjixhdakpzlftdaf.supabase.co")
SUPABASE_ANON_KEY = os.environ.get("SUPABASE_ANON_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZodWFxaml4aGRha3B6bGZ0ZGFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM5NTQ0NzcsImV4cCI6MjA4OTUzMDQ3N30.kq7gNOqpSv4gMdSGnUGu8bg66xwmcrjHk8QOA_kdhhk")
