
# Evasion Robustness attack, adversarial text perturbations.


from .base import AttackResult, ModelFn, Status, Severity, ExecutionTelemetry

def run_evasion_robustness(
    model_fn: ModelFn,
    model_target: str,
    custom_robustness_probes: list = None,
    hipaa_mode: bool = False,
    timeout_seconds: int = 30,
) -> list:
   
    return []
