# Membership inference attack modules.
# Re-export the legacy function-based runner so existing imports keep working.

from sichgate.attacks.base import AttackResult, ModelFn, Status, Severity, ExecutionTelemetry


def run_membership_inference(
    model_fn: ModelFn,
    model_target: str,
    probe_entities: list = None,
    nonmember_calibration: list = None,
    hipaa_mode: bool = False,
    timeout_seconds: int = 30,
) -> list:
    """Legacy function-based membership inference runner (stub — results via old runner path)."""
    return []
