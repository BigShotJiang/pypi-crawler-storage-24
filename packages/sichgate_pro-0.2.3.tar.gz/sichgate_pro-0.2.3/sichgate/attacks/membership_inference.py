
# Membership Inference attack eg score based membership detection.
from .base import AttackResult, ModelFn, Status, Severity, ExecutionTelemetry

def run_membership_inference(
    model_fn: ModelFn,
    model_target: str,
    probe_entities: list = None,
    nonmember_calibration: list = None,
    hipaa_mode: bool = False,
    timeout_seconds: int = 30,
) -> list:

    return []
