# LLM attack modules (class-based, new runner path)
