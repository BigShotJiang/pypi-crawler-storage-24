
from .base import AttackResult, ModelFn, Status, Severity, ExecutionTelemetry

def run_prompt_injection(
    model_fn: ModelFn,
    model_target: str,
    system_prompt_fragments: list = None,
    hipaa_mode: bool = False,
    timeout_seconds: int = 30,
) -> list:

    return []
