

from .runner import run_all, run_selected, list_attacks, SichGateConfig, SichGateReport
from .runner import ATTACK_REGISTRY, ATTACK_GROUPS
from .base   import AttackResult, ModelFn, ExecutionTelemetry, Status, Severity

# Model adapters
from .models import (ModelAdapter, HuggingFaceAdapter, OpenAICompatAdapter,
                     RawCallableAdapter, make_adapter)

# Individual runners — importable directly for fine-grained use
from .prompt_injection               import run_prompt_injection
from .data_extraction                import run_training_data_extraction
from .membership_inference           import run_membership_inference
from .evasion_robustness             import run_evasion_robustness
from .model_extraction               import run_model_extraction
from .alignment                      import (run_alignment, run_sycophancy_probe,
                                             run_consistency_attack, run_crescendo,
                                             run_competing_objectives)
from .bias_fairness                  import run_bias_fairness
from .hallucination_safe_messaging   import run_hallucination_probe, run_safe_messaging
from .llm_attacks_extended           import (run_instruction_hijacking, run_payload_splitting,
                                             run_virtualization, run_json_xml_smuggling,
                                             run_llm_attacks_extended)
from .textattack_suite               import run_textattack_suite

# Phase 2.3 modules
from .infinite_context               import (run_infinite_context_attack,
                                             run_context_window_injection,
                                             run_early_turn_poisoning,
                                             run_context_overflow_displacement)
from .multiturn_training             import (run_multiturn_training_vulnerability,
                                             run_role_confusion_injection,
                                             run_training_data_pattern_exploitation,
                                             run_conversation_context_manipulation)
from .reasoning_chain                import (run_reasoning_chain_manipulation,
                                             run_cot_hijacking,
                                             run_scratchpad_poisoning,
                                             run_logical_entrapment,
                                             run_confidence_anchoring)

__all__ = [
    # Top-level API
    "run_all", "run_selected", "list_attacks",
    "SichGateConfig", "SichGateReport",
    "ATTACK_REGISTRY", "ATTACK_GROUPS",
    # Schema
    "AttackResult", "ModelFn", "ExecutionTelemetry", "Status", "Severity",
    # Adapters
    "ModelAdapter", "HuggingFaceAdapter", "OpenAICompatAdapter",
    "RawCallableAdapter", "make_adapter",
    # Individual runners
    "run_prompt_injection", "run_training_data_extraction",
    "run_membership_inference", "run_evasion_robustness", "run_model_extraction",
    "run_alignment", "run_sycophancy_probe", "run_consistency_attack",
    "run_crescendo", "run_competing_objectives",
    "run_bias_fairness",
    "run_hallucination_probe", "run_safe_messaging",
    "run_instruction_hijacking", "run_payload_splitting",
    "run_virtualization", "run_json_xml_smuggling", "run_llm_attacks_extended",
    "run_textattack_suite",
    # Phase 2.3
    "run_infinite_context_attack", "run_context_window_injection",
    "run_early_turn_poisoning", "run_context_overflow_displacement",
    "run_multiturn_training_vulnerability", "run_role_confusion_injection",
    "run_training_data_pattern_exploitation", "run_conversation_context_manipulation",
    "run_reasoning_chain_manipulation", "run_cot_hijacking",
    "run_scratchpad_poisoning", "run_logical_entrapment", "run_confidence_anchoring",
]
