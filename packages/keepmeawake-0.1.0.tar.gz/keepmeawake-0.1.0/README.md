# keepmeawake

Keep your Microsoft Teams status active by periodically jiggling the mouse — runs from WSL using PowerShell interop.

## How It Works

`keepmeawake` calls the Windows `mouse_event` API via PowerShell to move the mouse 1 pixel right and then 1 pixel left on a loop. This tiny, invisible movement is enough to prevent Teams (and Windows) from marking you as idle.

## Requirements

- **WSL** (Windows Subsystem for Linux) with Windows interop enabled
- **Python 3.12+**
- **[uv](https://docs.astral.sh/uv/)** (recommended) or pip

WSL interop must be enabled so that `powershell.exe` is accessible from within WSL. This is the default, but if you've changed it, ensure `/etc/wsl.conf` contains:

```ini
[interop]
enabled = true
```

## Installation

```bash
git clone https://github.com/<you>/keepmeawake.git
cd keepmeawake
uv pip install -e .
```

## Usage

```bash
# Run with default settings (jiggle every 60 seconds)
uv run keepmeawake

# Jiggle every 30 seconds with verbose logging
uv run keepmeawake --interval 30 --verbose
```

Press **Ctrl+C** to stop.

### Options

| Flag | Description |
|---|---|
| `-i`, `--interval` | Seconds between each mouse jiggle (default: `60`) |
| `-v`, `--verbose` | Log each jiggle with a timestamp |

## Troubleshooting

**`powershell.exe not found on PATH`**
You're either not running inside WSL, or WSL interop is disabled. Check `/etc/wsl.conf` and restart your WSL instance.

**`ModuleNotFoundError: No module named 'keepmeawake'`**
The package isn't installed in your environment. Run `uv pip install -e .` to fix it.

## License

MIT