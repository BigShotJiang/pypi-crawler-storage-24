# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


from apfio.base.array import IndependentPointArray
from apfio.base.types import check_type
from apfio.caching.cache import Cache
from apfio.caching.memory import MemoryCache


class CachedArray(IndependentPointArray):
    """
    A readonly :py:class:`~apfio.base.array.IndependentPointArray` the accesses to which are sped up by a cache.
    """

    def __init__(self, base, identifier, cache=None, own=True):
        """
        Equips an array with a cache for read accesses.

        :param base: An :py:class:`~apfio.base.array.IndependentPointArray`.

        :param identifier: A string that uniquely identifies this array. This means: All those arrays that this
                           constructor associates with the same cache will be considered equal if and only if they
                           have the same identifier.

        :param cache: A :py:class:`~Cache` object.

        :param own: Specifies if this array should own its base, i.e. if the base should be closed when
                    this array is closed.
        """
        super().__init__()
        self._base = check_type(base, IndependentPointArray)
        self._identifier = check_type(identifier, str)
        self._cache = MemoryCache() if cache is None else check_type(cache, Cache)
        self._own = check_type(own, bool)

    @property
    def base(self):
        """
        The underlying :py:class:`~apfio.base.array.IndependentPointArray`, accesses to which are cached.
        """
        return self._base

    @property
    def cache(self):
        """
        The :py:class:`~Cache` object used for this array.
        """
        return self._cache

    @property
    def identifier(self):
        """
        A string that uniquely identifies this array in the context of its cache.
        """
        return self._identifier

    @property
    def readable(self):
        return True

    @property
    def writable(self):
        return False

    def close(self):
        self.flush()
        if self._own:
            self._base.close()

    def flush(self):
        pass

    @property
    def shape(self):
        return self._base.shape

    @property
    def metadata(self):
        return self._base.metadata

    def write_meta(self, key, info):
        self._base.write_meta(key, info)

    def read_sized(self, *indices):
        indices = tuple(idx % d for idx, d in zip(indices, self.shape))
        key = (self._identifier, *indices)
        try:
            return self._cache.get(key)
        except KeyError:
            p, s = self._base.read_sized(*indices)
            self._cache.set(key, p, s)
            return p, s

    def write(self, point, *indices):
        raise NotImplementedError("CachedArray does not support write accesses!")
