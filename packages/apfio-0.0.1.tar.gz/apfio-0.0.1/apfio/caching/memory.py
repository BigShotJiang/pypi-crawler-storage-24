# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from collections import OrderedDict
from threading import Lock

from apfio.base.types import check_type
from apfio.caching.cache import Cache


class MemoryCache(Cache):
    """
    A :py:class:`~Cache` that stores its data in RAM.
    """

    def __init__(self, capacity=None):
        """
        Initializes a new in-memory cache for data points.

        :param capacity: A nonnegative integer specifying the number of bytes that the data stored in this cache must
                         occupy at most.
        """
        super().__init__()
        self._capacity = None if capacity is None else check_type(capacity, int)
        self._size = 0
        self._content = OrderedDict()
        self._lock = Lock()

    def close(self):
        self.prune(0)

    @property
    def capacity(self):
        return self._capacity

    @property
    def size(self):
        with self._lock:
            return self._size

    @property
    def count(self):
        with self._lock:
            return len(self._content)

    def prune(self, limit=None):
        if limit is None:
            limit = self._capacity
        if limit is None:
            return
        with self._lock:
            while self._size > limit:
                key, (point, size) = self._content.popitem(last=False)
                self._size -= size

    def get(self, key):
        with self._lock:
            entry = self._content[key]
            self._content.move_to_end(key)
            return entry

    def set(self, key, point, size):
        with self._lock:
            try:
                # Maybe there already is something for that key...
                self._size -= self._content[key][-1]
            except KeyError:
                pass
            self._content[key] = (point, size)
            self._content.move_to_end(key)
            self._size += size
        self.prune()
