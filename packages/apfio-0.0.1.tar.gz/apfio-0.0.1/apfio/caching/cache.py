# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

import abc


class Cache(abc.ABC):
    """
    A cache stores the outcomes of read accesses to :py:class:`~apfio.base.array.IndependentPointArray` instances,
    in order to serve repeated accesses to
    the same indices faster.
    Note: A cache may contain data from more than one array!
    """

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __del__(self):
        self.close()

    @abc.abstractmethod
    def close(self):
        """
        Releases any resources held by this cache object.
        """
        pass

    @property
    @abc.abstractmethod
    def capacity(self):
        """
        The number of bytes that the data stored in this cache is allowed to ever occupy.
        """
        pass

    @property
    @abc.abstractmethod
    def size(self):
        """
        The number of bytes currently occupied by data in this cache.
        """
        pass

    @property
    @abc.abstractmethod
    def count(self):
        """
        The number of indices for which this cache is currently holding data.

        :return: A nonnegative integer.
        """
        pass

    def __len__(self):
        return self.count

    @abc.abstractmethod
    def prune(self, limit=None):
        """
        Removes data points from this cache.
        When this call returns, the data remaining in the cache occupies at most the given number of bytes.

        :param limit: The limit to prune the cache to, in bytes. If None is given, the cache capacity is used.
        """
        pass

    def clear(self):
        """
        Clears this cache, i.e. makes it discard all its entries.
        """
        self.prune(limit=0)

    @abc.abstractmethod
    def get(self, key):
        """
        Retrieves the data point cached for the given key object, also indicating its size.
        This procedure will not modify the cache.

        :param key: A hashable :py:class:`~python:object`.

        :exception :py:class:`~python:KeyError`: If this cache does not hold any data for the given key.

        :return: A pair :code:`(p, s)`, where `p` is the data point that was retrieved, and `s` is its size in bytes.
        """
        pass

    @abc.abstractmethod
    def set(self, key, point, size):
        """
        Makes this cache hold the given data point for the given key.

        :param key: A hashable :py:class:`~python:object`.

        :param point: The data to associate with the given key.

        :param size: The size of the given data point in bytes. Note: There may be more than one possible definition
                     for the size of a data point. The Cache class uses this parameter as the definitive source of
                     information about data point size.
        """
        pass
