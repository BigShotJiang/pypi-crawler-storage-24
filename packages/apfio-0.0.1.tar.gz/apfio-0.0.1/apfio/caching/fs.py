# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import os
from collections import OrderedDict
from pathlib import Path
from threading import Lock

from apfio.base.types import check_type
from apfio.caching.cache import Cache


class FileSystemCache(Cache):
    """
    A :py:class:`~Cache` that stores its data in the file system.
    """

    def __init__(self, root, reader, writer, extension=".bin", capacity=None):
        """
        Makes a filesystem directory available as a cache for array data.

        :param root: A path to the root directory of the cache. Note that existing data in this directory may be
                     interpreted as cache content!

        :param reader: A procedure that takes a file path as an argument and reads this file to return an array point.

        :parma writer: A procedure that takes a file path and an array point as arguments and encodes the point under
                       that path.

        :param extension: The file name extension to use for cache files. This only matters if the cache directory
                          is ever inspected by humans or other software.

        :param capacity: A nonnegative integer specifying the number of bytes that the data stored in this cache must
                         occupy at most.
        """
        super().__init__()
        self._root = check_type(root, str)
        self._reader = reader
        self._writer = writer
        self._capacity = None if capacity is None else check_type(capacity, int)
        self._size = 0
        self._count = 0
        self._ext = extension
        self._lock = Lock()

        files = []

        os.makedirs(root, exist_ok=True)

        for de in os.scandir(root):
            if not de.is_dir():
                continue

            for de2 in os.scandir(de.path):
                if not de2.is_file():
                    continue

                _, name = os.path.split(de2.path)
                name, ext = os.path.splitext(name)
                if not (ext == self._ext):
                    continue

                if not all(n.isnumeric() for n in name.split("_")):
                    continue

                stat = de2.stat()

                path = de2.path
                size = stat.st_size
                tstamp = stat.st_atime_ns

                files.append((path, size, tstamp))
                self._count += 1
                self._size += size

        self._files = OrderedDict((p, s) for p, s, _ in sorted(files, key=lambda t: t[-1]))
        self.prune()

    def close(self):
        # We could delete the data on disk, but it can be useful to keep them there.
        pass

    @property
    def capacity(self):
        return self._capacity

    @property
    def size(self):
        with self._lock:
            return self._size

    @property
    def count(self):
        with self._lock:
            return self._count

    def prune(self, limit=None):
        if limit is None:
            limit = self._capacity
        with self._lock:
            while self._size > limit:
                path, size = self._files.popitem(last=False)
                os.remove(path)
                self._size -= size
                self._count -= 1

    def _key2path(self, key):
        identifier, *indices = key
        return os.path.join(self._root, identifier, "_".join(map(str, indices)) + self._ext)

    def get(self, key):
        path = self._key2path(key)
        with self._lock:
            size = self._files[path]
            self._files.move_to_end(path)
            Path(path).touch(exist_ok=True)
            return self._reader(path), size

    def set(self, key, point, size):
        path = self._key2path(key)
        dpath, _ = os.path.split(path)
        with self._lock:
            os.makedirs(dpath, exist_ok=True)
            self._writer(path, point)
            self._files[path] = size
            self._size += size
            self._count += 1
        self.prune()
