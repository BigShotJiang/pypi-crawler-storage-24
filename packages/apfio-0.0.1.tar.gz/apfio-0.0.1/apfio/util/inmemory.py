# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import os
from concurrent.futures.thread import ThreadPoolExecutor
from io import BufferedIOBase, UnsupportedOperation
from threading import Lock


class InMemoryFileWriter(BufferedIOBase):
    """
    Each instance of this class is a file-like object and represents a proper file descriptor that is recognized as such
    by the OS and to which this process can write. However, the file is backed only by memory and does not exist on
    disk. Instances of this class are _not_ thread-safe.

    This class would be unnecessary if os.memfd_create was reliably available on all platform. As of December 2025,
    it is not available on Windows and apparently not in all Python versions on Linux: Even though we tested
    os.memfd_create on an installation that has Python and glibc versions higher than what is required by the official
    Python documentation for os.memfd_create, the member does not seem to be available. We speculate that this is
    because the inclusion of this system call needs to be activated at build time of the Python interpreter, and so
    maybe is not available in conda-forge.
    So since we cannot rely on os.memfd_create to be available for all users, and because the tempfile module usually
    interacts with the file system, this class seems to be the only way of having a proper OS-recognized file descriptor
    for an in-memory buffer.

    Such an object is necessary for libraries that only when given an OS-recognized file descriptor will lift the GIL.
    PIL is an example of such a library.
    """

    # Theoretically, limiting the number of threads in the pool can lead to deadlocks.
    # So we should have an *unbounded* threadpool, relying on the number of threads to be bounded elsewhere.
    # But since the ThreadPool API does not allow this, we instead set the bound extremely high.
    __threads = ThreadPoolExecutor(2 ** 64)

    # Nothing in the Python docs guarantees that accessing the thread pool from different threads is safe.
    # So we better lock it:
    __lock = Lock()

    def __init__(self):
        """
        Creates a new in-memory file, that has an OS-recognized file descriptor.
        """
        self._pipe_reader, self._pipe_writer, self._bytes, self._future = None, None, None, None
        self._pipe_reader, self._pipe_writer = os.pipe()
        self._bytes = None
        with InMemoryFileWriter.__lock:
            self._future = InMemoryFileWriter.__threads.submit(self._suckle)

    def _suckle(self):
        with os.fdopen(self._pipe_reader, 'rb') as reader:
            self._bytes = reader.read()
            self._pipe_reader = None
        return True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __del__(self):
        self.close()

    def close(self):
        if self._pipe_writer is not None:
            # Make it known that we're done.
            os.close(self._pipe_writer)
            self._pipe_writer = None
        # Make sure that we wait until the last bytes have been processed.
        self._future.result()

    @property
    def closed(self):
        return self._pipe_writer is None and self._future.done()

    def fileno(self):
        return self._pipe_writer

    def flush(self):
        pass

    def getvalue(self):
        """
        Returns all bytes that were written to this in-memory file.
        :raises: IOError: If this file has not been closed yet.
        :return: A bytes object.
        """
        if not self.closed:
            raise IOError("This InMemoryFileWriter has not been closed yet, which would be the prerequisite for "
                          "retrieving the data that was written to it!")
        return self._bytes

    def read(self, size=-1):
        raise OSError("To retrieve the data written into a InMemoryFileWriter instance, "
                      "call self.close and self.getvalue!")

    def read1(self, size=-1):
        raise OSError("To retrieve the data written into a InMemoryFileWriter instance, "
                      "call self.close and self.getvalue!")

    def readinto(self, b):
        raise OSError("To retrieve the data written into a InMemoryFileWriter instance, "
                      "call self.close and self.getvalue!")

    def readinto1(self, b):
        raise OSError("To retrieve the data written into a InMemoryFileWriter instance, "
                      "call self.close and self.getvalue!")

    def readable(self):
        return False

    def readline(self):
        raise OSError("To retrieve the data written into a InMemoryFileWriter instance, "
                      "call self.close and self.getvalue!")

    def readlines(self):
        raise OSError("To retrieve the data written into a InMemoryFileWriter instance, "
                      "call self.close and self.getvalue!")

    def seekable(self):
        return False

    def tell(self):
        raise OSError("InMemoryFileWriter instances are not seekable!")

    def truncate(self, size = ..., /):
        raise OSError("InMemoryFileWriter instances are not seekable!")

    def write(self, b):
        os.write(self._pipe_writer, b)

    def writable(self):
        return not self.closed

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def isatty(self):
        return False

    def detach(self):
        raise UnsupportedOperation("InMemoryFileWriter does not support 'detach'!")
