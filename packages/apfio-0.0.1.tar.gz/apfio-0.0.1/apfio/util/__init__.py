# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


# This package contains helper code that is not strongly specific to apfio and does not depend on apfio,
# but is handy for various things.