# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import os
import re
import subprocess
from fractions import Fraction
from tempfile import TemporaryDirectory

import numpy
from numpy import uint8


def ffmpeg(args_in, data_in, args_out):
    """
    Has input data processed by an ffmpeg process, and returns the result.
    :param args_in: Arguments passed to ffmpeg *before* the input specification. This must be used to inform ffmpeg
                    of the format of the input data.
    :param data_in: A bytes-like object that will be passed as input to FFMPEG.
    :param args_out: Arguments passed to ffmpeg *after* the input specification, before the output specification.
    :return: The standard output from ffmpeg.
    :raises IOError: If ffmpeg crashed.
    """

    with TemporaryDirectory() as tmpdir:

        in_path = os.path.join(tmpdir, "in")
        out_path = os.path.join(tmpdir, "out")

        with open(in_path, 'wb') as file:
            file.write(data_in)

        args = ("ffmpeg",
                # "-loglevel", "error",
                # "-y",
                *args_in,
                "-i", in_path, # Unfortunately this cannot be a pipe, because some codecs want it to be seekable.
                *args_out,
                out_path # Unfortunately this cannot be a pipe, because some codecs want it to be seekable.
                )

        args = list(map(str, args))

        process = subprocess.run(args, capture_output=True, check=True)

        with open(out_path, 'rb') as file:
            out = file.read()

        return out, process.stderr.decode("utf-8")


def ffmpeg_encode(frames_in, *args_out):
    """
    Has ffmpeg encode raw input frames.
    :param frames_in: A numpy array of shape (t, h, w, 3) containing a sequence of video frames. They will be passed
                      to FFMPEG. If 't' is omitted, it will be assumed to be 1.
    :param args_out: Arguments passed to ffmpeg *after* the input specification, before the output specification.
    :return: The standard output from ffmpeg, i.e. the encoding result.
    :raises IOError: If ffmpeg crashed.
    """

    t, h, w, d = frames_in.shape if len(frames_in.shape) == 4 else (1, *frames_in.shape)

    if frames_in.dtype == numpy.uint8:
        pf = "rgb24"
    elif frames_in.dtype == numpy.uint16:
        pf = "rgb48"
    elif frames_in.dtype == numpy.uint32:
        pf = "rgb96"
    else:
        raise ValueError(f"The given frames have data type {frames_in.dtype}, which is not supported by ffmpeg_encode!")

    data_in = frames_in.tobytes()

    args_in = ("-f", "rawvideo",
               "-pixel_format", pf,
               "-video_size", f"{w}x{h}",
               "-blocksize", d * w * h
               )

    out, _ = ffmpeg(args_in, data_in, args_out)
    return out


__pattern_line = re.compile(r"\s*Stream .* Video: av1")
__pattern_format = re.compile(r"(yuv4[024][024]p[^(]*)")
__pattern_resolution = re.compile(r" (\d+)x(\d+)\s*\[.*]")


def ffmpeg_decode(bytes_in, *args_in, num_frames=1, num_bytes_per_subpixel=1):
    """
    Has ffmpeg decode compressed video frames.
    :param bytes_in: A byte-like object to be passed to FFMPEG.
    :param args_in: Arguments passed to ffmpeg *before* the input specification.
    :param num_frames: The number of frames to decode.
    :param num_bytes_per_subpixel:
    :return: A numpy array of shape (t, h, w, d) holding the raw decoded frames, as BGR.
             The datatype of the array depends on num_bytes_per_subpixel.
    :raises IOError: If ffmpeg crashed.
    """

    args_out = ("-f", "rawvideo",
                "-pix_fmt", f"rgb{3 * 8 * num_bytes_per_subpixel}")

    out, err = ffmpeg(args_in, bytes_in, args_out)

    w, h = None, None
    for line in err.splitlines():
        if re.match(__pattern_line, line):
            w, h = map(int, re.search(__pattern_resolution, line).groups())
            break

    d = Fraction(len(out), w * h * num_bytes_per_subpixel)
    if d.denominator != 1:
        raise IOError("Failed to interpret ffmpeg output: Could not infer the number of channels from the size of the "
                      "input and the resolution and pixel format information!")
    d = int(d)

    if num_bytes_per_subpixel == 1:
        dtype = uint8
    elif num_bytes_per_subpixel == 2:
        dtype = numpy.uint16
    elif num_bytes_per_subpixel == 4:
        dtype = numpy.uint32
    else:
        raise NotImplementedError(f"Cannot pick a numpy datatype for {num_bytes_per_subpixel} bytes per subpixel!")

    return numpy.frombuffer(out, dtype=dtype).reshape((num_frames, h, w, d))
