# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


from abc import abstractmethod

from apfio.base.array import IndependentPointArray


class TransformedArray(IndependentPointArray):
    """
    An array the points of which have undergone some transformation.
    """

    def __init__(self, base, own=True):
        """
        Transforms an array.

        :param base: An :py:class:`~apfio.base.array.IndependentPointArray` that is to be transformed.

        :param own: Specifies if this transformed array should own the base, i.e. if the base should be closed when
                    this transformed array is closed.

        """
        self._base = base
        self._own = own

    @property
    def base(self):
        """
        The array that was transformed to obtain this one.

        :return: An :py:class:`~apfio.base.array.IndependentPointArray`.
        """
        return self._base

    @abstractmethod
    def externalize(self, point):
        """
        Turns a point from the base array into a point of this array.
        This procedure assumes exclusive access to the given point.

        :param point: A point from the base array.

        :return: A pair :code:`(p, s)`, where `p` is a point from this array, and `s` is its size in bytes.
        """
        pass

    @abstractmethod
    def internalize(self, point):
        """
        Transforms a point for this array into a point for the base array.
        This procedure assumes exclusive access to the given point.

        :param point: A point for this array.

        :return: A point for the base array.
        """
        pass

    @property
    def readable(self):
        return self.base.readable

    @property
    def writable(self):
        return self.base.writable

    def close(self):
        self.flush()
        if self._own:
            self.base.close()

    def flush(self):
        self.base.flush()

    @property
    def shape(self):
        return self.base.shape

    @shape.setter
    def shape(self, value):
        self.base.shape = value

    def read_sized(self, *indices):
        return self.externalize(self.base.read(*indices))

    def write(self, point, *indices):
        self.base.write(self.internalize(point), *indices)
