# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


from apfio.base.array import IndependentPointArray
from apfio.base.types import check_types, check_type


class TupleArray(IndependentPointArray):
    """
    An array that results from combining the points of a tuple of arrays into tuples of points.
    The metadata of this array result from the metadata of the underlying arrays by prepending the index of each array
    to its keys, followed by a dot (".").
    """

    def __init__(self, *arrays, own=True):
        """
        Combines a tuple of arrays into a :py:class:`~apfio.base.tuple.TupleArray`.

        :param arrays: The tuple of :py:class:`~apfio.base.array.IndependentPointArray` instances to combine.

        :param own: Specifies if this :py:class:`~apfio.base.tuple.TupleArray`
                    should own the constituent arrays, i.e. if they should be closed when
                    this :py:class:`~apfio.base.tuple.TupleArray` is closed.
        """
        super().__init__()
        self._arrays = check_types(arrays, IndependentPointArray)
        self._own = check_type(own, bool)

        for a in self._arrays:
            if a.shape != self.shape:
                raise ValueError("The given arrays differ in shape!")

    @property
    def readable(self):
        return all(a.readable for a in self._arrays)

    @property
    def writable(self):
        return all(a.writable for a in self._arrays)

    def close(self):
        if self._own:
            for a in self._arrays:
                a.close()

    def flush(self):
        for a in self._arrays:
            a.flush()

    @property
    def shape(self):
        return self._arrays[0].shape

    @property
    def metadata(self):
        return {f"{idx}.{k}": v for idx, a in enumerate(self._arrays) for k, v in a.metadata.items()}

    def write_meta(self, key, info):
        offset = key.find(".")
        idx = int(key[:offset])
        key = key[offset + 1:]
        self._arrays[idx].write_meta(key, info)

    def read_sized(self, *indices):
        size = 0
        read = []
        for a in self._arrays:
            r, s = a.read_sized(*indices)
            size += s
            read.append(r)
        return read, size

    def write(self, point, *indices):
        if len(point) != len(self._arrays):
            raise ValueError(f"This TupleArray is composed of {len(self._arrays)} arrays, "
                             f"but the given point has {len(point)} components.")
        for p, a in zip(point, self._arrays):
            a.write(p, *indices)
