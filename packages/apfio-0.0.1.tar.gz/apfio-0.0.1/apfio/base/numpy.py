# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import copy

import numpy

from apfio.base.array import IndependentPointArray
from apfio.base.types import check_type


class NumpyArray(IndependentPointArray):
    """
    A :py:class:`numpy:numpy.ndarray` that is accessible as an :py:class:`~apfio.base.array.IndependentPointArray`.
    This is nothing but an adapter class. It adds no real functionality to numpy arrays. It only makes them usable
    in apfio's :py:class:`~apfio.base.array.IndependentPointArray` framework.
    This class does not provide the arithmetic operations that numpy
    arrays typically offer. Its main purpose is to serve as a reference in the apfio test suite.
    Note that reading and writing from instances of this class will be extremely slow for but the smallest arrays,
    because the iteration over all array cells is executed in Python, not via the underlying numpy code!
    :py:meth:`~apfio.base.numpy.NumpyArray.read` returns views onto the underlying numpy array.
    :py:meth:`~NumpyArray.write` writes to the underlying numpy array.
    This class is as thread-safe as the underlying numpy array.
    """

    def __init__(self, array):
        """
        Casts a :py:class:`numpy:numpy.ndarray` as an :py:class:`~apfio.base.array.IndependentPointArray`.

        :param array: A :py:class:`numpy:numpy.ndarray`.
        """
        self._numpy = check_type(array, numpy.ndarray)
        self._meta = None

    @property
    def readable(self):
        return True

    @property
    def writable(self):
        return self._numpy.flags.writeable

    @property
    def shape(self):
        return self._numpy.shape

    @shape.setter
    def shape(self, new_shape):
        # First try if the new shape is valid, but discard the resulting view.
        self._numpy.reshape(new_shape)
        # Write the new shape to the very numpy array instance we are based on.
        self._numpy.shape = new_shape

    @property
    def dtype(self):
        """
        The :py:class:`numpy:numpy.dtype` of this array.
        """
        return self._numpy.dtype

    @property
    def metadata(self):
        return dict() if self._meta is None else dict(self._meta)

    def write_meta(self, key, info):
        key = check_type(key, str)
        info = copy.deepcopy(info)
        if self._meta is None:
            self._meta = dict()
        self._meta[key] = info

    def read_sized(self, *indices):
        return self._numpy[indices].item(), self._numpy.itemsize

    def write(self, point, *indices):
        self._numpy[indices] = point

    def flush(self):
        pass

    def close(self):
        pass
