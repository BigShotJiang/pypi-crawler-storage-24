# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from abc import ABC, abstractmethod
from collections.abc import Sequence
from fractions import Fraction
from itertools import product, chain, repeat

import numpy
from numpy import ndarray

from apfio.base.broadcasting import broadcast_shapes
from apfio.base.linearization import delinearize, linearize
from apfio.base.types import check_type, check_types


def check_shape(s, allow_wildcard=False):
    """
    Checks that the given object is a valid shape tuple.
    :param s: An :py:class:`~object`.
    :param allow_wildcard: If True, then the given shape may contain an entry of -1.
    :raises ValueError: If the given object is not a valid shape tuple.
    :return: s
    """
    try:
        s = check_types(s, int)
    except TypeError as te:
        raise ValueError(f"{s} is not a valid array shape, because it is not an iterable of ints!") from te
    if sum(1 for d in s if d < 0) > allow_wildcard:
        raise ValueError(f"{s} is not a valid array shape, because it contains negative numbers!")
    return s

class IndependentPointArray(ABC):
    """
    Represents an N-dimensional array.
    This base class is agnostic of the type of the array entries.
    All subclasses of this class are safe to use by multiple threads concurrently.
    """

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __len__(self):
        return self.shape[0]

    @property
    @abstractmethod
    def readable(self):
        """
        Indicates if points can be read from this array.
        """
        pass

    @property
    @abstractmethod
    def writable(self):
        """
        Indicates if points can be written to this array.
        """
        pass

    @abstractmethod
    def close(self):
        """
        Closes this array, flushing all underlying buffers and makes the array unusable for further reads or writes.
        """
        pass

    @abstractmethod
    def flush(self):
        """
        Flushes all underlying buffers and blocks until this has happened.
        """
        pass

    @property
    @abstractmethod
    def shape(self):
        """
        Returns a tuple of nonnegative integers that specify the sizes of the dimensions of this array.
        """
        pass

    @property
    def size(self):
        """
        The total number of entries in this array, i.e. the product of its shape tuple.

        :return: A nonnegative integer.
        """
        s = 1
        for d in self.shape:
            s *= d
        return s

    def reshape(self, *new_shape):
        """
        Returns a view of this array with a new shape.

        :param new_shape: A tuple of nonnegative integers whose product is equal to :py:attr:`~IndependentPointArray.size`.
        :return: An :py:class:`~apfio.base.array.IndependentPointArray` of the new shape,
                 that forwards all its accesses to `self`.
        """
        return ReshapedIndependentPointArray(self, *new_shape)

    def permute(self, *axes):
        """
        Returns a view of this array with reordered dimensions.

        :param axes: A tuple indices into :py:attr:`~IndependentPointArray.shape`,
                     specifying the order in which the dimensions should be arranged.
        :return: An :py:class:`~apfio.base.array.IndependentPointArray` that forwards all its accesses to `self`.
        """
        return PermutedIndependentPointArray(self, *axes)

    def broadcast_to(self, *new_shape):
        """
        Broadcasts the dimensions of self to a new shape, i.e. extends dimensions of size 1.

        :param new_shape: A tuple of nonnegative integers. Every entry in it is either equal to 1, or equal to the
                          corresponding entry in :py:attr:`~IndependentPointArray.shape`.

        :return: An :py:class:`~apfio.base.array.IndependentPointArray` of the new shape,
                 that forwards all its accesses to `self`.
        """
        return BroadcastIndependentPointArray(self, *new_shape)

    def slice(self, *selectors):
        """
        Selects parts of this array.

        :param selectors:  A tuple of selectors. A selector is either a single integer, a :py:class:`~python:slice` object, a
                           sequence of integers, or a sequence of booleans.
                           There are at most as many selectors as there are dimensions in
                           :py:attr:`~IndependentPointArray.shape`.
                           Each selector specifies which entries along the corresponding dimension are
                           to be part of the returned array.

        :return: An :py:class:`~apfio.base.array.IndependentPointArray` that forwards all its accesses to `self`.
        """
        return SlicedIndependentPointArray(self, *selectors)

    def __getitem__(self, selectors):
        if isinstance(selectors, (int, slice)):
            selectors = (selectors, )
        return self.slice(*selectors)

    def __iter__(self):
        for idx in range(len(self)):
            yield self.slice(idx)

    def __setitem__(self, selectors, value):
        if not isinstance(selectors, tuple):
            selectors = (selectors, )
        target = self.slice(*selectors)

        def cells(value, shape):
            if len(shape) == 0:
                yield value
            else:
                d, *rshape = shape
                if not hasattr(value, "__len__"):
                    value = repeat(value, d)
                elif len(value) == 1 and d > 1:
                    value = repeat(value[0], d)

                for rvalue in value:
                    for c in cells(rvalue, rshape):
                        yield c
        for indices, v in zip(chain(product(*(range(d) for d in target.shape)), ((), )), cells(value, target.shape)):
            target.write(v, *indices)

    @property
    @abstractmethod
    def metadata(self):
        """
        A mapping from string keys to objects.
        This mapping comprises all the information about this array that is available but has not been interpreted
        by `self`.
        Any modifications that may be possible to the object returned by this property will not affect this array
        in any way.
        """
        pass

    @abstractmethod
    def write_meta(self, key, info):
        """
        Writes information about this array that will not be interpreted by `self`.

        :param key: A string key, under which the information may be retrieved.

        :param info: An :py:class:`~python:object` to store under the given key. This object will be copied by this call.
        """
        pass

    def read(self, *indices):
        """
        Reads one point from this array.

        :param indices: A tuple of integers. There must be as many integers as there are dimensions in this array.
                        The tuple specifies which point to read.

        :return: The point that was read.
        """
        p, _ = self.read_sized(*indices)
        return p

    @abstractmethod
    def read_sized(self, *indices):
        """
        Reads one point from this array, and indicates the size of this point in bytes.

        :param indices: A tuple of integers. There must be as many integers as there are dimensions in this array.
                        The tuple specifies which point to read.

        :return: A pair :code:`(p, s)`, where `p` is the point that was read and `s` is its size in bytes.
        """
        pass

    def point(self):
        """
        Reads the only point in this array.

        :raises ValueError: If this array contains more than one point or no points at all.

        :return: The point that was read.
        """
        if self.size != 1:
            raise ValueError(f"This array contains {self.size} points, so reading 'the single point' "
                             f"in it is not possible!")

        return self.read(*((0, ) * len(self.shape)))

    @abstractmethod
    def write(self, point, *indices):
        """
        Writes the given point.

        :param indices: A tuple of integers. There must be as many integers as there are dimensions in this array.
                        The tuple specifies which point to write.

        :param point: The object to be written to the array coordinate.
        """
        pass


class IndependentPointArrayView(IndependentPointArray):
    """
    Instances of this class simply translate accesses to their points into accesses to points of an underlying array.
    """

    def __init__(self, base, *new_shape):
        """
        Initializes a view onto a base array.

        :param base: An :py:class:`~apfio.base.array.IndependentPointArray`.
        """
        self._base = check_type(base, IndependentPointArray)
        self._shape = check_shape(new_shape)

    @property
    def shape(self):
        return self._shape

    @property
    def readable(self):
        return self.base.readable

    @property
    def writable(self):
        return self.base.writable

    @property
    def base(self):
        """
        The array that this one is a view of.

        :return: An :py:class:`~apfio.base.array.IndependentPointArray`.
        """
        return self._base

    @abstractmethod
    def translate(self, *indices):
        """
        Translates an index tuple for this view into an index tuple for :py:attr:`~IndependentPointArrayView.base`.

        :param indices: A tuple of integers. There must be as many integers as there are dimensions in this array.
        The tuple specifies a point in the array.
        :return: A new index tuple, specifying a point in :py:attr:`~IndependentPointArrayView.base`.
        """
        pass

    def flush(self):
        self.base.flush()

    def close(self):
        # A view never owns its base, so it is definitely not in charge of closing it.
        pass

    @property
    def metadata(self):
        return self.base.metadata

    def write_meta(self, key, info):
        return self.write_meta(key, info)

    def read_sized(self, *indices):
        return self.base.read_sized(*self.translate(*indices))

    def write(self, point, *indices):
        self.base.write(point, *self.translate(*indices))


class ReshapedIndependentPointArray(IndependentPointArrayView):
    """
    An array the shape of which was changed, based on the same underlying points.
    """

    def __init__(self, base, *new_shape):
        """
        Reshapes an array.

        :param base: The :py:class:`~apfio.base.array.IndependentPointArray` that is to be reshaped.
        :param new_shape: The new shape.
        """

        n = 1
        for d in base.shape:
            n *= d
        n = Fraction(n)
        wdx = None
        for idx, d in enumerate(check_shape(new_shape, allow_wildcard=True)):
            if d == 0 and n != 0:
                raise ValueError(f"Cannot reshape array of size {n} to shape {new_shape}!")
            if d > 0:
                n /= d
            else:
                wdx = idx

        if wdx is not None:
            assert n.denominator == 1
            new_shape = (*new_shape[:wdx], int(n), *new_shape[wdx + 1:])

        super().__init__(base, *new_shape)

    def translate(self, *indices):
        return delinearize(self.base.shape, linearize(self._shape, *indices))


class BroadcastIndependentPointArray(IndependentPointArrayView):
    """
    An array the singleton dimensions of which are being broadcast to a larger size.
    """

    def __init__(self, base, *new_shape):
        """
        Broadcasts an array.

        :param base: The :py:class:`~apfio.base.array.IndependentPointArray` that is to be broadcast.

        :param new_shape: The new shape. It must be at least as long as :code:`base.shape`. :code:`base.shape` will
                          implicitly be extended to the same length as new_shape by adding ones to the left.
                          Each entry in this implicitly extended base.shape must either match the corresponding entry
                          in new_shape, or be equal to 1.
        """
        new_shape = broadcast_shapes(base.shape, new_shape)
        super().__init__(base, *new_shape)

    def translate(self, *indices):
        return tuple(idx % d for d, idx in zip(self.base.shape, indices))


class PermutedIndependentPointArray(IndependentPointArrayView):
    """
    An array the axes/dimensions of which have been reordered.
    """

    def __init__(self, base, *axes):
        """
        Reorders the dimensions of an array.

        :param base: The :py:class:`~apfio.base.array.IndependentPointArray` the axes of which are to be reordered.

        :param axes: A tuple of indices into :code:`base.shape`. It specifies the new order of the axes.
        """
        axes = check_types(axes, int)

        if not (len(base.shape) == len(axes)):
            raise ValueError(f"{len(axes)} axis indices were given, but the array has {len(base.shape)} dimensions, "
                             f"which is a different number!")

        if len(set(axes)) != len(axes):
            raise ValueError(f"The axis tuple {axes} contains duplicates!")

        if not all(0 <= aidx < len(base.shape) for aidx in axes):
            raise ValueError(f"The axis tuple {axes} contains axis indices that are out of range for an array "
                             f"with {len(base.shape)} dimensions!")

        super().__init__(base, *(base.shape[aidx] for aidx in axes))

        t = [0, ] * len(axes)
        for idx, aidx in enumerate(axes):
            t[aidx] = idx
        self._t = tuple(t)

    def translate(self, *indices):
        return tuple(indices[self._t[aidx]] for aidx in range(len(self.base.shape)))


class SlicedIndependentPointArray(IndependentPointArrayView):
    """
    A slice of an array, i.e. a selection of its entries.
    """

    def __init__(self, base, *selectors):
        """
        Selects part of an array.

        :param base: The :py:class:`~apfio.base.array.IndependentPointArray` parts of which are to be selected.

        :param selectors: A tuple of selectors. A selector is either a single integer, a :py:class:`~python:slice` object, a
                          sequence/array of integers, or a sequence/array of booleans.
                          There are at most as many selectors as there are dimensions in
                          :code:`self.shape`. Each selector specifies which entries along the corresponding dimension are
                          to be part of the returned array.
        """

        if len(selectors) > len(base.shape):
            raise ValueError(f"The base array has {len(base.shape)} dimensions, but {len(selectors)} were given, "
                             f"which is a greater number.")

        # We are following Numpy indexing rules, see https://numpy.org/doc/stable/user/basics.indexing.html .

        # Step 1: Turn all boolean selectors into integer selectors and mark which selectors are "advanced".
        selectors_basic = []
        selectors_advanced = []
        advanced = []
        shape_basic = []
        shape_advanced = ()
        for idx, (d, s) in enumerate(zip(base.shape, selectors)):
            a = True
            if isinstance(s, Sequence) and isinstance(s[0], bool):
                s_out = numpy.array([idx for idx, m in enumerate(s) if m]),
                shapes = tuple(t.shape for t in s_out)
            elif isinstance(s, Sequence) and isinstance(s[0], int):
                s_out = numpy.array(s),
                shapes = tuple(t.shape for t in s_out)
            elif isinstance(s, ndarray) and s.dtype == numpy.bool:
                s_out = s.nonzero()
                shapes = tuple(t.shape for t in s_out)
            elif isinstance(s, ndarray) and issubclass(s.dtype.type, numpy.integer):
                s_out = s,
                shapes = s.shape,
            elif isinstance(s, slice):
                # Then this is a "basic" indexer.
                s_out = range(d)[s],
                shapes = None
                a = False
                shape_basic.append(len(range(d)[s]))
            elif isinstance(s, int):
                # Then this is a "basic" indexer.
                s_out = s,
                shapes = None
                a = False
                shape_basic.append(None) # Integers do not show up in self.shape.
            else:
                raise TypeError("The selector tuple includes objects that cannot be interpreted as selectors!")
            (selectors_advanced if a else selectors_basic).extend(s_out)
            advanced.append(a)
            if a:
                shape_advanced = broadcast_shapes(shape_advanced, *shapes)

        selectors_advanced = tuple(numpy.broadcast_to(s, shape_advanced) for s in selectors_advanced)

        if len(advanced) > 0 and advanced[0] + sum(1 for a, b in zip(advanced[:-1], advanced[1:]) if a < b) <= 1:
            # If all advanced indexers are next to each other, then their shape is inserted into the result shape
            # at the position of the indexers:
            shape_out = []
            self._selectors = []
            selectors_advanced = iter(selectors_advanced)
            selectors_basic = iter(zip(shape_basic, selectors_basic))
            for a in advanced:
                if a:
                    s = next(selectors_advanced)
                    if shape_advanced is not None:
                        shape_out.extend(shape_advanced)
                        shape_advanced = None
                else:
                    d, s = next(selectors_basic)
                    if d is not None:
                        shape_out.append(d)
                self._selectors.append(s)
            self._p = range(len(self._selectors))
        else: # Otherwise the advanced shape will be moved to the front of the result shape:
            shape_out = list(shape_advanced) + shape_basic
            self._selectors = selectors_advanced + tuple(selectors_basic)
            pindices = range(len(self._selectors))
            self._p = tuple(pdx for pdx, a in zip(pindices, advanced) if a) + tuple(pdx for pdx, a in zip(pindices, advanced) if not a)

        shape_out.extend(base.shape[len(self._selectors):])

        super().__init__(base, *shape_out)

    def translate(self, *indices):

        indices_in = iter(check_types(indices, int))
        self_indices_advanced = None
        indices_out = [None] * len(self.base.shape)
        n = 0

        for pdx, s in zip(self._p, self._selectors):
            odx = None
            try:
                if isinstance(s, int):
                    odx = s
                elif isinstance(s, range):
                    odx = s[next(indices_in)]
                elif isinstance(s, ndarray):
                    if self_indices_advanced is None:
                        self_indices_advanced = []
                        for _ in s.shape:
                            self_indices_advanced.append(next(indices_in))
                    odx = s[*self_indices_advanced].item()
                else:
                    raise Exception("Severe bug in SlicedIndependentPointArray!")
            except StopIteration:
                break

            indices_out[pdx] = odx
            n = max(n, pdx + 1)

        for idx in indices_in:
            indices_out[n] = idx
            n += 1

        indices_out = indices_out[:n]
        assert all(x is not None for x in indices_out)
        return indices_out
