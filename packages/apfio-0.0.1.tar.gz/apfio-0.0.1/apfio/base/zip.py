# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import copy
import json
from copy import deepcopy
from io import BytesIO, TextIOWrapper
from threading import RLock, Semaphore
from zipfile import ZipFile, Path

from apfio.base.array import IndependentPointArray, check_shape
from apfio.base.exceptions import UnsupportedOperation
from apfio.base.types import check_type, check_types


class ZippedArray(IndependentPointArray):
    r"""
    An array that is stored inside a \*.zip file.
    :py:meth:`~ZippedArray.read` returns file-like objects that are owned by the caller and can be used to read binary data.
    :py:meth:`~ZippedArray.write` accepts a procedure as a 'point'. This procedure will be called with a binary writer as an argument.
    This class supports concurrent accesses to an instance. Internal locks ensure that reading and writing concurrently
    cannot violate any invariants or corrupt data, under the assumption that the instance is the only one accessing
    the underlying zip file.
    """

    class OpenFile:
        def __init__(self, owner):
            self._owner = owner
            self._zf = None

        @property
        def zf(self):
            return self._zf

        def __enter__(self):
            self._zf = self._owner._acquire_file()
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            self._owner._release_file(self._zf)
            self._zf = None

    __keys_internal = {"shape", "ext"}

    def __init__(self, zf, read=True, write=False, own=True, num_leading_zeros=10, max_open=1):
        """
        Initializes a new zipped array.

        :param zf: An instance of :py:class:`~python:zipfile.ZipFile`.
                   Ownership remains with the caller, i.e. the :py:class:`~ZippedArray` class will
                   under no circumstance close the file.

        :param read: Specifies if this instance is supposed to read from the underlying zip file.

        :param write: Specifies if this instance is supposed to write from the underlying zip file.

        :param own: Specifies if this array should own 'zf', i.e. closing this array should also close the zip file.

        :param num_leading_zeros: The number of leading zeros to use for formatting indices to strings. If this value
                                  is an int, it will be used for all dimensions of the array. If it is a tuple, it
                                  must have as many entries as the array has dimensions and a different entry for each
                                  dimension will be used.

        :param max_open: The maximum number of times the underlying zip file should be opened. Increasing this number
                         may slightly speed up concurrent reads.
        """

        if max_open < 1:
            raise ValueError("ZippedArray needs to use at least one reader!")

        if read and write:
            raise ValueError("ZippedArray does not support reading and writing at the same time!")

        self._zips_max = max_open
        self._zips = [check_type(zf, ZipFile)]

        self._filename = None
        if max_open > 1:
            self._filename = self._zips[0].filename
            if self._filename is None:
                raise ValueError("max_open > 1, but the given ZipFile does not provide a filename!")

        if isinstance(num_leading_zeros, int):
            self._num_leading = num_leading_zeros
        else:
            self._num_leading = check_types(num_leading_zeros, int)
        self._read = read
        self._write = write
        self._meta_internal = None
        self._meta_external = None
        self._own = own
        self._lock = RLock()
        self._semaphore = Semaphore(1 if write else max_open)

    def _acquire_file(self):
        """
        Blocks until an open :py:class:`~python:ZipFile` instance can be provided,
        which is only possible when the number of instances.
        in use is lower than :code:`self._zips_max`.
        This procedure should not be called outside of :py:class:`~ZippedArray.OpenFile`.

        :return: The :py:class:`~python:ZipFile` instance that became available.
        """

        # Wait until the number of readers in use drops under the limit.
        self._semaphore.acquire()
        try:
            with self._lock:
                # If there already is a free open reader, use that one.
                return self._zips.pop(-1)
        except IndexError:
            # Otherwise create one.
            return ZipFile(self._filename, mode='w' if self._write else 'r')

    def _release_file(self, zf):
        """
        Frees a :py:class:`~python:ZipFile` instance for reuse.
        This procedure should not be called outside of :py:class:`~ZippedArray.OpenFile`.

        :param zf: The :py:class:`~python:ZipFile` instance to release.
        """
        with self._lock:
            # Put the reader back into the reader pool.
            self._zips.append(zf)
        # Allow other threads to go and use that ZipFile.
        self._semaphore.release()

    @property
    def readable(self):
        return self._read

    @property
    def writable(self):
        return self._write

    def _get_meta(self, zf):
        if self._meta_internal is None:
            if self._read:
                mf = None
                try:
                    try:
                        mf = zf.open("metadata.json", mode='r')
                    except KeyError as ke:
                        raise IOError("This ZippedArray instance was opened for reading, but the underlying Zip file"
                                      "does not contain a metadata.json file. Without this file, one cannot safely interpret"
                                      "the contents of the ZipFile.") from ke
                    if self._write:
                        raise IOError("This ZippedArray instance was opened for writing, but the underlying Zip file"
                                      "already contains a metadata file. Since *.zips do not allow efficient overwriting"
                                      "of existing contents, ZippedArray does not support this case!")

                    meta = json.load(mf)
                finally:
                    if mf is not None:
                        mf.close()

                if not isinstance(meta, dict):
                    raise IOError(f"Expected to read a JSON dictionary, but got a {type(meta)}!")

                self._meta_internal = {k: deepcopy(meta[k]) for k in ZippedArray.__keys_internal}
                self._meta_external = {check_type(k, str): deepcopy(v) for k, v in meta.items()
                                       if k not in ZippedArray.__keys_internal}
            else:
                self._meta_internal = dict()
                self._meta_external = dict()

        return self._meta_internal, self._meta_external

    def _write_meta(self, zf, key, value):
        if not self._write:
            raise UnsupportedOperation("This ZippedArray instance has not been opened for writing, "
                                       "so no metadata can be written!")
        meta_internal, meta_external = self._get_meta(zf)
        meta = meta_internal if key in ZippedArray.__keys_internal else meta_external
        meta[key] = value

    @property
    def shape(self):
        with ZippedArray.OpenFile(self) as zf:
            return self._get_shape(zf.zf)

    def _get_shape(self, zf):
        meta_internal, _ = self._get_meta(zf)
        try:
            return check_shape(meta_internal["shape"])
        except KeyError as ke:
            raise KeyError("No shape has been set for this ZippedArray!") from ke

    @shape.setter
    def shape(self, new_shape):
        new_shape = check_shape(new_shape)
        with ZippedArray.OpenFile(self) as zf:
            with self._lock:
                try:
                    old_shape = self._get_shape(zf.zf)
                except KeyError:
                    old_shape = None

                if new_shape != old_shape:
                    if old_shape is not None:
                        if len(new_shape) != len(old_shape):
                            raise ValueError(f"This ZippedArray has {len(old_shape)} dimensions, but the new shape "
                                             f"has {len(new_shape)} dimensions, which is a different number. "
                                             f"Since one cannot efficiently change existing contents of a *.zip file, "
                                             f"ZippedArray does not support dimensionality changes.")
                        if any(n < o for o, n in zip(old_shape, new_shape)):
                            raise ValueError(
                                f"The new shape {new_shape} is smaller than the old shape {old_shape} in at least one"
                                f"dimension. Since *.zip files do not support efficient deletion of parts of their"
                                f"contents, ZippedArray does not support shrinking any dimensions.")
                    self._write_meta(zf.zf,"shape", new_shape)

    @property
    def extension(self):
        """
        The file name extension to use for the point data inside the zip file.

        :return: A string, assumed to contain the leading dot of the extension string.
        """
        with ZippedArray.OpenFile(self) as zf:
            return self._get_extension(zf.zf)

    def _get_extension(self, zf):
        meta_internal, _ = self._get_meta(zf)
        try:
            return check_type(meta_internal["ext"], str)
        except KeyError as ke:
            raise KeyError("No extension string for zip entry names has been set for this ZippedArray!") from ke

    @extension.setter
    def extension(self, new_ext):
        new_ext = check_type(new_ext, str)
        with ZippedArray.OpenFile(self) as zf:
            with self._lock:
                try:
                    old_ext = self._get_extension(zf.zf)
                except KeyError:
                    old_ext = None

                if new_ext != old_ext:
                    if old_ext is not None:
                        raise UnsupportedOperation("The file name extension string for a ZippedArray instance can only be set once!")
                    self._write_meta(zf.zf, "ext", new_ext)

    @property
    def metadata(self):
        with ZippedArray.OpenFile(self) as zf:
            _, meta_external = self._get_meta(zf.zf)
            return copy.deepcopy(meta_external)

    def write_meta(self, key, info):
        if key in ZippedArray.__keys_internal:
            raise ValueError(f"ZippedArray uses the metadata key '{key}' internally, "
                             "so it cannot be used as an argument to ZippedArray.write_meta!")
        with ZippedArray.OpenFile(self) as zf:
            with self._lock:
                self._write_meta(zf.zf, key, copy.deepcopy(info))

    def _key2path(self, zf, *indices):
        """
        Translates the index tuple for a point to a path in the zip file.

        :param indices: An array index tuple.

        :return: A :py:class:`~python:zipfile.Path` object.
        """

        shape = self._get_shape(zf)

        if len(indices) != len(shape):
            raise ValueError(f"This ZippedArray has {len(shape)} dimensions, "
                             f"but the given index tuple has {len(indices)} entries, which is a different number.")

        indices = tuple(idx % d for idx, d in zip(indices, shape))

        num_leading = self._num_leading
        if isinstance(num_leading, int):
            num_leading = (num_leading, ) * len(indices)

        if len(indices) == 0:
            return Path(zf, at=f"singleton{self._get_extension(zf)}")

        indices = tuple(f"{idx:0{nlz}d}" for idx, nlz in zip(indices, num_leading))

        return Path(zf).joinpath(*indices[:-1],f"{indices[-1]}{self._get_extension(zf)}")

    def read_sized(self, *indices):
        if not self.readable:
            raise UnsupportedOperation("This ZippedArray was not opened for reading!")

        if self.writable:
            # According to the zip file documentation, any 'w' handle on any file in the zip file being open would
            # lead to the following attempt at reading any file to fail with a ValueError.
            # This is why we need the lock: Write handles will only ever be open under the lock, so if we acquire
            # the lock first, there can be no problem:
            data = None
            try:
                data = BytesIO()
                with ZippedArray.OpenFile(self) as zf:
                    with self._lock:
                        with self._key2path(zf.zf, *indices).open(mode='rb') as file:
                            data.write(file.read())
                # The caller owns the file-like object.
                return data, data.tell()
            except:
                data.close()
        else:
            # We are readonly, so can simply return file handles.
            # Since we assume that we're the only gateway to accessing this zip file, and because we are guaranteed
            # to never write, there cannot be any 'w' file handles on any files in the zip file.
            # According to the zip file documentation, this should make the file handle we return here usable
            # independently from the zip file.
            # The caller owns the file-like object.
            with ZippedArray.OpenFile(self) as zf:
                path = self._key2path(zf.zf, *indices)
                return path.open(mode='rb'), zf.zf.getinfo(path.at).file_size

    def write(self, point, *indices):
        if not self.writable:
            raise UnsupportedOperation("This ZippedArray is not open for writing!")

        with ZippedArray.OpenFile(self) as zf:
            with self._lock:
                path = self._key2path(zf.zf, *indices)
                if path.exists():
                    raise UnsupportedOperation(f"This ZippedArray already contains data at {indices}! Since *.zip files "
                                               f"cannot efficiently overwrite their entries, ZippedArray does not "
                                               f"support overwriting points!")
                with path.open(mode='wb') as f:
                    point(f)

    def flush(self):
        # All points are written synchronously.
        # Metadata will not be flushed until the file was closed.
        pass

    def close(self):
        if len(self._zips) == 0:
            # Already closed.
            return
        with ZippedArray.OpenFile(self) as zf:
            with self._lock:
                if self._write:
                    meta_internal, meta_external = self._get_meta(zf.zf)
                    with zf.zf.open("metadata.json", mode='w') as mf:
                        with TextIOWrapper(mf, encoding="utf-8") as tmf:
                            json.dump(dict(**meta_internal, **meta_external), tmf, indent="  ")
                self._write = False

        with self._lock:
            if self._own:
                for z in self._zips:
                    z.close()
                self._zips.clear()
            else:
                for z in self._zips[1:]:
                    z.close()
                self._zips = self._zips[:1]
            self._own = False
