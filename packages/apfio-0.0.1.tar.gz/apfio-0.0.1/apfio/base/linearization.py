# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


def linearize(shape, *indices):
    """
    Turns an index tuple for an array of the given shape into a single index integer for the flattened array.

    :param shape: The shape of the array to linearize the index tuple for.

    :param indices: A tuple of integers indexing the dimensions of the array of the given shape.

    :return: An :py:class:`python:int`.
    """
    if len(shape) != len(indices):
        raise ValueError(f"Index tuple {indices} does not have the same length as shape tuple {shape}!")
    idx = 0
    power = 1
    for d, i in zip(reversed(shape), reversed(indices)):
        if d < 0:
            raise ValueError(f"The shape tuple {shape} contains negative entries!")
        idx += power * (i % d)
        power *= d
    return idx


def delinearize(shape, linear):
    """
    Turns an index into the flattened version of an array of the given shape into a proper index tuple for the array.

    :param shape: The shape of the array to delinearize the flat index for.

    :param linear: An integer index into the flattened version of the array.

    :return: A tuple of integers indexing the dimensions of the array of the given shape.
    """
    if linear < 0:
        raise ValueError("The given linear index is negative!")
    indices = [0, ] * len(shape)
    for idx, d in zip(range(len(shape))[::-1], reversed(shape)):
        indices[idx] = linear % d
        linear //= d
    if linear != 0:
        raise ValueError(f"The linear index {linear} is too large for shape tuple {shape}!")
    return tuple(indices)
