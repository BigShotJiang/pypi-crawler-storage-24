# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


from encodings import normalize_encoding
from io import TextIOWrapper
from threading import RLock

from apfio.base.transform import TransformedArray


class TextArray(TransformedArray):
    """
    An array the points of which are strings, that are encoded as byte strings in an underlying array.
    """

    __key_encoding = "encoding"

    def __init__(self, base, **kwargs):
        """
        Makes an array of binary points available as an array of text strings.

        :param base: An :py:class:`~apfio.base.array.IndependentPointArray`.
                     :code:`base.read` must return readable, binary file-like objects owned by and
                     exclusively accessible to the caller.
                     :code:`base.write` must accept as :code:`point` a procedure that takes a writable file object as its only argument
                     and will be called in the course of :code:`base.write` under a lock that guarantees exclusive access to
                     the file object.

        :param kwargs: See constructor of :py:class:`~apfio.base.transform.TransformedArray`.
        """
        super().__init__(base, **kwargs)
        self._lock = RLock()
        if self.writable:
            self.encoding = "utf-8"

    def externalize(self, point):
        # Because of the constraints of this class and its superclasses, we can assume exclusive access to 'point'.
        # However, access to 'self' may not be exclusive.
        with TextIOWrapper(point, encoding=self.encoding) as reader:
            offset = reader.tell()
            txt = reader.read()
            return txt, reader.tell() - offset

    def internalize(self, point):
        encoding = self.encoding
        def w(writer):
            with TextIOWrapper(writer, encoding=encoding) as writer:
                writer.write(point)
        return w

    def _check_encoding(self, fmt):
        nfmt = normalize_encoding(fmt)
        if nfmt not in ('utf_8',):
            raise ValueError(f"The encoding '{fmt}' is not supported by TextArray!")
        return nfmt

    @property
    def encoding(self):
        """
        The text encoding to use for encoding text as byte strings.

        :return: A string.
        """
        with self._lock:
            meta = self.base.metadata
            try:
                return self._check_encoding(meta[TextArray.__key_encoding])
            except KeyError as ke:
                raise KeyError("No text encoding has been set for this TextArray!") from ke

    @encoding.setter
    def encoding(self, fmt):
        with self._lock:
            self.base.write_meta(TextArray.__key_encoding, self._check_encoding(fmt))

    @property
    def metadata(self):
        m = self.base.metadata.copy()
        del m[TextArray.__key_encoding]
        return m

    def write_meta(self, key, info):
        if key == TextArray.__key_encoding:
            raise ValueError(f"The key {key} is used by TextArray to document which text encoding is being used!")
        self.base.write_meta(key, info)
