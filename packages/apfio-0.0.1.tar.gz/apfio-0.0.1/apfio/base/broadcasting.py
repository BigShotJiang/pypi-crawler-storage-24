# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

def broadcast_shapes(*shapes):
    """
    Broadcasts a number of given shapes into one common shape.

    :param shapes: The shapes to be broadcast into one common shape.

    :raises ValueError: If the given shapes cannot all be broadcast into one shape.

    :return: The common shape to which all given shapes were broadcast.
    """
    shape = []
    for s in shapes:
        shape = [1] * (len(s) - len(shape)) + shape
        for (idx, a), b in zip(reversed(list(enumerate(shape))), reversed(s)):
            if a != b and 1 not in (a, b):
                raise ValueError(f"The shape {s} cannot be broadcast together with the other shapes!")
            shape[idx] = max(a, b)
    return tuple(shape)
