from ._http import HttpClient
from .namespaces.dynamo import DynamoNamespace
from .namespaces.files import FilesNamespace
from .namespaces.projects import ProjectsNamespace
from .namespaces.rosalind import RosalindNamespace
from .namespaces.lab import LabNamespace

_DEFAULT_BASE_URL = "https://agentsapi.litefold.ai"


class Client:
    """Entry point for the LiteFold SDK.

    Each Client owns its own connection pool — safe to share across
    threads or give each agent its own instance.

    Usage:
        client = Client(api_key="lf_...")
        client.rosalind.send_message(project="Default", chat_name="run-1", message="...")
        client.lab.peptide.submit_design(project="Default", ...)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 60.0,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
        pool_max_connections: int = 200,
        pool_max_keepalive: int = 40,
    ):
        self._http = HttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            retry_backoff=retry_backoff,
            pool_max_connections=pool_max_connections,
            pool_max_keepalive=pool_max_keepalive,
        )
        self.dynamo = DynamoNamespace(self._http)
        self.files = FilesNamespace(self._http)
        self.projects = ProjectsNamespace(self._http)
        self.rosalind = RosalindNamespace(self._http)
        self.lab = LabNamespace(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
