from __future__ import annotations

from .._http import HttpClient
from .structure import StructureNamespace
from .docking import DockingNamespace
from .sbdd import SBDDNamespace
from .design import DesignNamespace
from .peptide import PeptideNamespace


class LabNamespace:
    """LiteFold Lab — structure prediction, docking, SBDD, protein design, and peptide design.

    Usage:
        client.lab.structure.submit(...)
        client.lab.docking.find_pockets(...)
        client.lab.docking.submit(...)
        client.lab.sbdd.submit(...)
        client.lab.design.validate_and_submit(...)
        client.lab.peptide.submit_design(...)
        client.lab.peptide.submit_docking(...)
    """

    def __init__(self, http: HttpClient):
        self.structure = StructureNamespace(http)
        self.docking = DockingNamespace(http)
        self.sbdd = SBDDNamespace(http)
        self.design = DesignNamespace(http)
        self.peptide = PeptideNamespace(http)
