"""Helpers for reading signed license payloads in CLI/TUI flows."""

from __future__ import annotations

import base64
import json
from typing import Any


def decode_license_email(license_code: str) -> str:
    """Extract the account email (`uid`) from a base64-encoded license payload."""
    cleaned = license_code.strip()
    if not cleaned:
        raise ValueError("License key cannot be empty.")

    padded = cleaned + "=" * (-len(cleaned) % 4)
    try:
        raw = base64.b64decode(padded, validate=True)
        payload: Any = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise ValueError("Could not decode email from the license key.") from exc

    email = payload.get("uid") if isinstance(payload, dict) else None
    if not isinstance(email, str) or not email.strip():
        raise ValueError("License key is missing the account email.")
    return email.strip()
