"""
Async HTTP client for the Nowledge Mem REST API.
"""

import ipaddress
import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlparse

import httpx

DEFAULT_API_URL = "http://127.0.0.1:14242"
_CONFIG_FILE = Path.home() / ".nowledge-mem" / "config.json"


def _load_connection_config() -> dict[str, Any]:
    try:
        if _CONFIG_FILE.is_file():
            with _CONFIG_FILE.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {}


class ApiClient:
    """Async HTTP client for communicating with the Nowledge Mem server."""

    def __init__(self, base_url: str | None = None):
        config = _load_connection_config()
        self.base_url = (
            base_url
            or os.environ.get("NMEM_API_URL")
            or str(config.get("apiUrl") or config.get("api_url") or DEFAULT_API_URL)
        ).rstrip("/")
        env_api_key = os.environ.get("NMEM_API_KEY")
        if env_api_key is not None:
            api_key = env_api_key.strip()
        else:
            api_key = str(config.get("apiKey") or config.get("api_key") or "").strip()
        self._headers = (
            {
                "Authorization": f"Bearer {api_key}",
                "X-NMEM-API-Key": api_key,
            }
            if api_key
            else {}
        )
        self._cookies = {"nmem_api_key": api_key} if api_key else {}
        self._client: httpx.AsyncClient | None = None

    @property
    def is_remote(self) -> bool:
        """True when base_url points to a non-loopback host."""
        try:
            host = (urlparse(self.base_url).hostname or "").strip().lower()
            if host in {"localhost", "127.0.0.1", "::1", ""}:
                return False
            return not ipaddress.ip_address(host).is_loopback
        except ValueError:
            # Not a literal IP (e.g. mem.example.com) → remote.
            return True

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=30.0,
                headers=self._headers,
                cookies=self._cookies,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    @staticmethod
    def _extract_http_error_message(exc: Exception) -> str:
        """Extract a user-friendly error from HTTP exceptions."""
        if isinstance(exc, httpx.HTTPStatusError):
            response = exc.response
            detail = ""
            try:
                body = response.json()
                if isinstance(body, dict):
                    raw_detail = body.get("detail") or body.get("error")
                    if raw_detail:
                        detail = str(raw_detail)
            except Exception:
                pass
            if detail:
                return detail
            return f"{response.status_code} {response.reason_phrase}"
        return str(exc)

    # =========================================================================
    # Health & Status
    # =========================================================================

    async def get_health(self) -> dict[str, Any]:
        """Get server health status."""
        client = await self._get_client()
        try:
            response = await client.get("/health")
            response.raise_for_status()
            return response.json()
        except httpx.ConnectError:
            return {"status": "offline", "error": "Cannot connect to server"}
        except Exception as e:
            return {"status": "error", "error": str(e)}

    async def get_stats(self) -> dict[str, Any]:
        """Get database statistics."""
        client = await self._get_client()
        try:
            response = await client.get("/stats")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    # =========================================================================
    # Memories
    # =========================================================================

    async def list_memories(
        self,
        limit: int = 20,
        offset: int = 0,
        importance_min: float = 0.0,
    ) -> dict[str, Any]:
        """List memories with pagination."""
        client = await self._get_client()
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if importance_min > 0:
            params["importance_min"] = importance_min
        response = await client.get("/memories", params=params)
        response.raise_for_status()
        return response.json()

    async def search_memories(
        self,
        query: str,
        limit: int = 20,
        labels: list[str] | None = None,
        importance_min: float = 0.0,
        mode: str = "deep",
    ) -> dict[str, Any]:
        """Search memories with filters."""
        client = await self._get_client()
        params: dict[str, Any] = {"q": query, "limit": limit, "mode": mode}
        if labels:
            params["labels"] = labels
        if importance_min > 0:
            params["importance_min"] = importance_min
        response = await client.get("/memories/search", params=params)
        response.raise_for_status()
        return response.json()

    async def get_memory(self, memory_id: str) -> dict[str, Any]:
        """Get a single memory by ID."""
        client = await self._get_client()
        response = await client.get(f"/memories/{memory_id}")
        response.raise_for_status()
        return response.json()

    async def create_memory(
        self,
        content: str,
        title: str | None = None,
        importance: float = 0.5,
        source: str = "tui",
        labels: list[str] | None = None,
        event_start: str | None = None,
        event_end: str | None = None,
        temporal_context: str | None = None,
    ) -> dict[str, Any]:
        """Create a new memory."""
        client = await self._get_client()
        payload: dict[str, Any] = {
            "content": content,
            "importance": importance,
            "source": source,
        }
        if title:
            payload["title"] = title
        if labels:
            payload["labels"] = labels
        if event_start:
            payload["event_start"] = event_start
        if event_end:
            payload["event_end"] = event_end
        if temporal_context:
            payload["temporal_context"] = temporal_context
        response = await client.post("/memories", json=payload)
        response.raise_for_status()
        return response.json()

    async def delete_memory(self, memory_id: str) -> dict[str, Any]:
        """Delete a memory."""
        client = await self._get_client()
        response = await client.delete(f"/memories/{memory_id}")
        response.raise_for_status()
        return response.json()

    async def update_memory(
        self,
        memory_id: str,
        title: str | None = None,
        content: str | None = None,
        importance: float | None = None,
    ) -> dict[str, Any]:
        """Update a memory."""
        client = await self._get_client()
        payload: dict[str, Any] = {}
        if title is not None:
            payload["title"] = title
        if content is not None:
            payload["content"] = content
        if importance is not None:
            payload["importance"] = importance
        response = await client.patch(f"/memories/{memory_id}", json=payload)
        response.raise_for_status()
        return response.json()

    # =========================================================================
    # Threads
    # =========================================================================

    async def list_threads(self, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        """List threads with pagination."""
        client = await self._get_client()
        params = {"limit": limit, "offset": offset}
        response = await client.get("/threads", params=params)
        response.raise_for_status()
        return response.json()

    async def search_threads(self, query: str, limit: int = 20) -> dict[str, Any]:
        """Search threads."""
        client = await self._get_client()
        params = {"query": query, "limit": limit}
        response = await client.get("/threads/search", params=params)
        response.raise_for_status()
        return response.json()

    async def get_thread(self, thread_id: str) -> dict[str, Any]:
        """Get a thread with messages."""
        client = await self._get_client()
        response = await client.get(f"/threads/{quote(thread_id, safe='')}")
        response.raise_for_status()
        return response.json()

    async def delete_thread(
        self, thread_id: str, cascade: bool = False
    ) -> dict[str, Any]:
        """Delete a thread."""
        client = await self._get_client()
        params = {"cascade_delete_memories": cascade}
        response = await client.delete(f"/threads/{quote(thread_id, safe='')}", params=params)
        response.raise_for_status()
        return response.json()

    # =========================================================================
    # Graph
    # =========================================================================

    async def search_graph(
        self, query: str, limit: int = 30, depth: int = 2
    ) -> dict[str, Any]:
        """Search the knowledge graph."""
        client = await self._get_client()
        params = {"query": query, "limit": limit, "depth": depth}
        response = await client.get("/graph/search", params=params)
        response.raise_for_status()
        return response.json()

    async def get_graph_sample(
        self, limit: int = 100, depth: int = 1
    ) -> dict[str, Any]:
        """Get a sample of the graph for visualization."""
        client = await self._get_client()
        params = {"limit": limit, "depth": depth}
        response = await client.get("/graph/sample", params=params)
        response.raise_for_status()
        return response.json()

    async def get_graph_analysis(self) -> dict[str, Any]:
        """Get graph analysis including communities and centrality."""
        client = await self._get_client()
        response = await client.get("/graph/analysis")
        response.raise_for_status()
        return response.json()

    # =========================================================================
    # Labels
    # =========================================================================

    async def list_labels(self) -> list[dict[str, Any]]:
        """List all labels."""
        client = await self._get_client()
        response = await client.get("/labels")
        response.raise_for_status()
        data = response.json()
        return data.get("labels", [])

    # =========================================================================
    # Models Management
    # =========================================================================

    async def get_models_status(
        self,
        *,
        full_verify: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """Get status of all cached models (embedding, LLM, search)."""
        client = await self._get_client()
        try:
            params: dict[str, Any] = {}
            if full_verify:
                params["full_verify"] = True
            if force_refresh:
                params["force_refresh"] = True
            response = await client.get("/models/status", params=params or None)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def get_bge_m3_status(
        self,
        *,
        full_verify: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        """Get status of search embedding model for hybrid search.

        Platform-specific: Qwen3-Embedding on macOS, BGE-M3 on Windows/Linux.
        """
        client = await self._get_client()
        try:
            params: dict[str, Any] = {}
            if full_verify:
                params["full_verify"] = True
            if force_refresh:
                params["force_refresh"] = True
            response = await client.get("/models/bge-m3/status", params=params or None)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def install_bge_m3(
        self, force_reinstall: bool = False
    ) -> dict[str, Any]:
        """Download and install the search embedding model for hybrid search.

        Platform-specific: Qwen3-Embedding on macOS, BGE-M3 on Windows/Linux.
        """
        client = await self._get_client()
        try:
            response = await client.post(
                "/models/bge-m3/install",
                json={"force_reinstall": force_reinstall},
                timeout=600.0,  # 10 minute timeout for model download
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # =========================================================================
    # Search Index Management
    # =========================================================================

    async def get_search_index_status(self) -> dict[str, Any]:
        """Get status of the search index (LanceDB + embeddings)."""
        client = await self._get_client()
        try:
            response = await client.get("/search-index/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"available": False, "error": str(e)}

    async def reindex_search_index(self) -> dict[str, Any]:
        """Rebuild the search index from Kuzu database.

        This reindexes all memories, messages, communities, and entities.
        It can take a while for large databases.
        """
        client = await self._get_client()
        try:
            response = await client.post(
                "/search-index/reindex",
                timeout=600.0,  # 10 minute timeout for reindex
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # =========================================================================
    # License Management
    # =========================================================================

    async def get_license_status(self) -> dict[str, Any]:
        """Get current license status."""
        client = await self._get_client()
        try:
            response = await client.get("/api/license/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def activate_license(
        self,
        license_code: str,
        email: str,
        device_name: str | None = None,
    ) -> dict[str, Any]:
        """Activate a license key."""
        client = await self._get_client()
        try:
            payload: dict[str, Any] = {"license_code": license_code, "email": email}
            if device_name:
                payload["device_name"] = device_name
            response = await client.post(
                "/api/license/activate",
                json=payload,
                timeout=30.0,
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    async def deactivate_license(self) -> dict[str, Any]:
        """Deactivate the current license."""
        client = await self._get_client()
        try:
            response = await client.post("/api/license/deactivate")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def renew_license(self) -> dict[str, Any]:
        """Renew device authorization."""
        client = await self._get_client()
        try:
            response = await client.post("/api/license/renew", timeout=30.0)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "message": str(e)}

    # =========================================================================
    # Remote LLM Configuration
    # =========================================================================

    async def get_remote_llm_config(self) -> dict[str, Any]:
        """Get current remote LLM configuration."""
        client = await self._get_client()
        try:
            response = await client.get("/remote-llm/config")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def update_remote_llm_config(self, config: dict[str, Any]) -> dict[str, Any]:
        """Update remote LLM configuration."""
        client = await self._get_client()
        try:
            response = await client.post("/remote-llm/config", json=config)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def test_remote_llm_connection(self) -> dict[str, Any]:
        """Test connection to the configured remote LLM."""
        client = await self._get_client()
        try:
            response = await client.post("/remote-llm/test", timeout=60.0)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def test_remote_llm_connection_with_config(
        self, config: dict[str, Any]
    ) -> dict[str, Any]:
        """Test connection with a transient config (test-before-save)."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/remote-llm/test/with-config", json=config, timeout=60.0
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def list_remote_llm_models(
        self, provider: str | None = None
    ) -> dict[str, Any]:
        """List available models for a provider."""
        client = await self._get_client()
        try:
            params = {}
            if provider:
                params["provider"] = provider
            response = await client.get("/remote-llm/models", params=params)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"success": False, "models": [], "message": str(e)}

    async def activate_remote_llm_provider(self, provider: str) -> dict[str, Any]:
        """Activate a specific LLM provider."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/remote-llm/activate", json={"provider": provider}
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def set_remote_llm_purpose(
        self, purpose: str, provider: str | None = None, model: str | None = None
    ) -> dict[str, Any]:
        """Set purpose-specific provider/model selection."""
        client = await self._get_client()
        payload: dict[str, Any] = {"purpose": purpose}
        if provider is not None:
            payload["provider"] = provider
        if model is not None:
            payload["model"] = model
        try:
            response = await client.post("/remote-llm/purpose", json=payload)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def remove_remote_llm_provider(self, provider: str) -> dict[str, Any]:
        """Remove a provider configuration by provider id."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/remote-llm/provider/remove", json={"provider": provider}
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def clone_remote_llm_provider(
        self,
        source_provider: str,
        new_provider: str,
        model: str | None = None,
        display_name: str | None = None,
    ) -> dict[str, Any]:
        """Clone an existing provider configuration to a new provider id."""
        client = await self._get_client()
        payload: dict[str, Any] = {
            "source_provider": source_provider,
            "new_provider": new_provider,
        }
        if model is not None:
            payload["model"] = model
        if display_name is not None:
            payload["display_name"] = display_name
        try:
            response = await client.post(
                "/remote-llm/provider/clone",
                json=payload,
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    # =========================================================================
    # App Settings / Knowledge Processing
    # =========================================================================

    async def get_knowledge_processing_settings(self) -> dict[str, Any]:
        """Get knowledge processing settings."""
        client = await self._get_client()
        try:
            response = await client.get("/settings/knowledge-processing")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def update_knowledge_processing_settings(
        self, settings: dict[str, Any]
    ) -> dict[str, Any]:
        """Update knowledge processing settings (partial update)."""
        client = await self._get_client()
        try:
            response = await client.post(
                "/settings/knowledge-processing", json=settings
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    async def get_agent_status(self) -> dict[str, Any]:
        """Get Knowledge Agent status including token budget info."""
        client = await self._get_client()
        try:
            response = await client.get("/agent/status")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    # =========================================================================
    # Access Anywhere (Cloudflare Tunnel)
    # =========================================================================

    async def _remote_access_request(
        self,
        method: str,
        path: str,
        *,
        json_payload: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        client = await self._get_client()
        try:
            response = await client.request(
                method,
                f"/api/remote-access{path}",
                json=json_payload,
                timeout=timeout,
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": self._extract_http_error_message(e)}

    async def get_remote_access_status(self) -> dict[str, Any]:
        """Get Access Anywhere status."""
        return await self._remote_access_request("GET", "/status")

    async def start_remote_access(
        self, *, mode: str | None = None, rotate_api_key: bool = False
    ) -> dict[str, Any]:
        """Start Access Anywhere tunnel."""
        payload: dict[str, Any] = {"rotate_api_key": rotate_api_key}
        if mode:
            payload["mode"] = mode
        # Tunnel startup may need longer time on constrained networks.
        return await self._remote_access_request(
            "POST",
            "/start",
            json_payload=payload,
            timeout=200.0,
        )

    async def configure_remote_access(
        self,
        *,
        mode: str | None = None,
        account_tunnel_url: str | None = None,
        account_tunnel_token: str | None = None,
    ) -> dict[str, Any]:
        """Configure Access Anywhere mode + account tunnel settings."""
        payload: dict[str, Any] = {}
        if mode is not None:
            payload["mode"] = mode
        if account_tunnel_url is not None:
            payload["account_tunnel_url"] = account_tunnel_url
        if account_tunnel_token is not None:
            payload["account_tunnel_token"] = account_tunnel_token
        return await self._remote_access_request(
            "POST",
            "/configure",
            json_payload=payload,
        )

    async def stop_remote_access(self) -> dict[str, Any]:
        """Stop Access Anywhere tunnel and disable auto-start."""
        return await self._remote_access_request("POST", "/stop")

    async def rotate_remote_access_key(self) -> dict[str, Any]:
        """Rotate Access Anywhere API key and return plaintext key."""
        return await self._remote_access_request("POST", "/rotate-key")

    async def reveal_remote_access_key(self) -> dict[str, Any]:
        """Reveal current Access Anywhere API key (if recoverable)."""
        return await self._remote_access_request("POST", "/reveal-key")

    async def set_loopback_auth(self, require_auth: bool) -> dict[str, Any]:
        """Toggle API-key requirement for loopback (localhost) requests."""
        return await self._remote_access_request(
            "POST",
            "/loopback-auth",
            json_payload={"require_auth_loopback": require_auth},
        )
