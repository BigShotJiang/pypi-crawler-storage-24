import joblib
import os

# current working directory where FastAPI is running
BASE_DIR = os.getcwd()

MODEL_PATH = os.path.join(BASE_DIR, "backend", "model.pkl")
VECTORIZER_PATH = os.path.join(BASE_DIR, "backend", "vectorizer.pkl")

model = joblib.load(MODEL_PATH)
vectorizer = joblib.load(VECTORIZER_PATH)

def check_email(email):
    domain = email.split("@")[-1]

    features = vectorizer.transform([domain])
    prediction = model.predict(features)[0]

    if prediction == 1:
        return "Temporary Email"
    else:
        return "Legitimate Email"