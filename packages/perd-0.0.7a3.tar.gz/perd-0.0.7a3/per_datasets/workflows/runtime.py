"""Runtime workflow selector and invocation client for PDS sessions."""

from __future__ import annotations

import json
import queue
import threading
import uuid
from dataclasses import dataclass
from numbers import Integral, Real
from typing import Any, Dict, Iterator, List, Optional, Tuple

from ..utils.api import read_workflow_definition


def _pascal_case(value: str) -> str:
    parts = [part for part in str(value).replace("-", "_").split("_") if part]
    return "".join(part[:1].upper() + part[1:] for part in parts)


def _normalize_mode(mode: str, *, input_streaming: bool, output_streaming: bool) -> str:
    normalized = str(mode or "").strip().lower()
    aliases = {
        "unary": "unary",
        "input_stream": "input_stream",
        "input-stream": "input_stream",
        "output_stream": "output_stream",
        "output-stream": "output_stream",
        "bidi": "bi_di",
        "bi_di": "bi_di",
        "bi-di": "bi_di",
        "bidirectional": "bi_di",
    }
    if normalized in {"client_stream", "client-stream", "server_stream", "server-stream"}:
        raise ValueError(
            f"Unsupported legacy workflow mode '{normalized}'. "
            "Use unary, input_stream, output_stream, or bi_di."
        )

    if normalized:
        if normalized not in aliases:
            raise ValueError(f"Unsupported workflow mode '{normalized}'")
        return aliases[normalized]

    if input_streaming and output_streaming:
        return "bi_di"
    if input_streaming:
        return "input_stream"
    if output_streaming:
        return "output_stream"
    return "unary"


def _proto_type_label(proto_type: str) -> str:
    mapping = {
        "double": "float",
        "int64": "int",
        "bool": "bool",
        "string": "str",
        "bytes": "bytes",
    }
    return mapping.get(str(proto_type or "").strip().lower(), str(proto_type or "value"))


def _is_bool_like(value: Any) -> bool:
    if isinstance(value, bool):
        return True
    return (
        value.__class__.__name__ == "bool_"
        and value.__class__.__module__.startswith("numpy")
    )


def _preview_value(value: Any, *, limit: int = 120) -> str:
    text = repr(value)
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


@dataclass(slots=True)
class OperationSpec:
    """Normalized operation definition from deployment metadata."""

    function_name: str
    rpc_name: str
    mode: str
    param_names: List[str]
    param_proto_types: Dict[str, str]
    input_streaming: bool
    output_streaming: bool
    input_stream_fields: List[str]
    stream_unary_param_names: List[str]
    output_stream_fields: List[str]
    input_stream_arity: int
    output_stream_arity: int

    @classmethod
    def from_manifest(cls, payload: Dict[str, Any]) -> "OperationSpec":
        function_name = str(payload.get("function_name") or "").strip()
        if not function_name:
            raise ValueError("Operation manifest entry missing function_name")

        manifest_input_streaming = bool(payload.get("input_streaming", False))
        manifest_output_streaming = bool(payload.get("output_streaming", False))
        mode = _normalize_mode(
            str(payload.get("mode") or ""),
            input_streaming=manifest_input_streaming,
            output_streaming=manifest_output_streaming,
        )

        rpc_name = str(payload.get("rpc_name") or "").strip() or _pascal_case(function_name)
        params = payload.get("params") if isinstance(payload.get("params"), list) else []
        param_names: List[str] = []
        param_proto_types: Dict[str, str] = {}
        for param in params:
            if not isinstance(param, dict):
                continue
            name = str(param.get("name", "")).strip()
            if not name:
                continue
            param_names.append(name)
            proto_type = str(param.get("proto_type", "")).strip().lower()
            if proto_type:
                param_proto_types[name] = proto_type

        input_streaming = mode in {"input_stream", "bi_di"}
        output_streaming = mode in {"output_stream", "bi_di"}

        raw_input_fields = payload.get("input_stream_fields")
        if isinstance(raw_input_fields, list):
            input_stream_fields = [str(name).strip() for name in raw_input_fields if str(name).strip()]
        else:
            input_stream_fields = []

        if input_streaming and not input_stream_fields:
            input_stream_fields = [name for name in param_names if name.startswith("item_")]
            input_stream_fields.sort(key=lambda value: int(value.split("_", maxsplit=1)[1]) if value.split("_", 1)[1].isdigit() else 999999)

        raw_unary_names = payload.get("stream_unary_param_names")
        if isinstance(raw_unary_names, list):
            stream_unary_param_names = [str(name).strip() for name in raw_unary_names if str(name).strip()]
        else:
            stream_unary_param_names = [name for name in param_names if name not in input_stream_fields]

        raw_output_fields = payload.get("output_stream_fields")
        if isinstance(raw_output_fields, list):
            output_stream_fields = [str(name).strip() for name in raw_output_fields if str(name).strip()]
        else:
            output_stream_fields = ["result"] if output_streaming else ["result"]

        if output_streaming and not output_stream_fields:
            output_stream_fields = ["result"]

        input_stream_arity = int(payload.get("input_stream_arity") or (len(input_stream_fields) if input_streaming else 0))
        output_stream_arity = int(payload.get("output_stream_arity") or (len(output_stream_fields) if output_streaming else 1))

        if input_streaming and (not input_stream_fields or input_stream_arity <= 0):
            raise ValueError(
                f"Operation '{function_name}' manifest missing input_stream_fields/input_stream_arity for mode '{mode}'"
            )

        if output_streaming and output_stream_arity <= 0:
            raise ValueError(
                f"Operation '{function_name}' manifest missing output_stream_arity for mode '{mode}'"
            )

        return cls(
            function_name=function_name,
            rpc_name=rpc_name,
            mode=mode,
            param_names=param_names,
            param_proto_types=param_proto_types,
            input_streaming=input_streaming,
            output_streaming=output_streaming,
            input_stream_fields=input_stream_fields,
            stream_unary_param_names=stream_unary_param_names,
            output_stream_fields=output_stream_fields,
            input_stream_arity=input_stream_arity,
            output_stream_arity=output_stream_arity,
        )


@dataclass(slots=True)
class WorkflowSpec:
    """Runtime workflow metadata resolved from deployment ID."""

    deployment_id: str
    workflow_name: str
    operations: Dict[str, OperationSpec]

    @classmethod
    def from_definition(cls, definition: Dict[str, Any]) -> "WorkflowSpec":
        deployment_id = str(definition.get("deployment_id") or "").strip()
        if not deployment_id:
            raise ValueError("Workflow definition is missing deployment_id")

        workflow_name = str(definition.get("workflow_name") or deployment_id).strip() or deployment_id
        manifest = definition.get("operation_manifest")
        if not isinstance(manifest, list):
            manifest = []

        operations: Dict[str, OperationSpec] = {}
        for entry in manifest:
            if not isinstance(entry, dict):
                continue
            operation = OperationSpec.from_manifest(entry)
            operations[operation.function_name] = operation

        return cls(
            deployment_id=deployment_id,
            workflow_name=workflow_name,
            operations=operations,
        )


class JobTracker:
    """Track socket events and completion for one workflow stream job."""

    def __init__(self, *, output_streaming: bool, output_field_names: Optional[List[str]] = None) -> None:
        self.output_streaming = output_streaming
        self.output_field_names = list(output_field_names or (["result"] if output_streaming else []))
        self.output_arity = len(self.output_field_names) if self.output_field_names else 1
        self._result_queue: "queue.Queue[tuple[str, Any]]" = queue.Queue()
        self._done = threading.Event()
        self._lock = threading.Lock()
        self._error: Optional[str] = None
        self._result: Any = None
        self._has_result = False
        self._completed = False
        self._last_result_seq = 0

    def add_result(self, value: Any, *, seq: Optional[int] = None) -> None:
        with self._lock:
            if self._completed:
                return
            if seq is not None and seq > self._last_result_seq:
                self._last_result_seq = int(seq)
            if self.output_streaming:
                self._result_queue.put(("result", value))
            else:
                self._result = value
                self._has_result = True
                self._done.set()

    def set_error(self, message: str) -> None:
        with self._lock:
            if self._completed:
                return
            self._error = str(message)
            self._completed = True
            self._done.set()
            self._result_queue.put(("error", self._error))

    def set_completed(self) -> None:
        with self._lock:
            if self._completed:
                return
            self._completed = True
            self._done.set()
            if self.output_streaming:
                self._result_queue.put(("done", None))

    def wait_unary_result(self, timeout_seconds: Optional[float]) -> Any:
        if timeout_seconds is None:
            self._done.wait()
        elif not self._done.wait(timeout_seconds):
            raise TimeoutError(f"Workflow call timed out after {timeout_seconds:.1f}s")
        with self._lock:
            if self._error:
                raise RuntimeError(self._error)
            if not self._has_result:
                raise RuntimeError("Workflow call completed without a result")
            return self._result

    def is_terminal(self) -> bool:
        return self._done.is_set()

    def last_result_seq(self) -> int:
        with self._lock:
            return int(self._last_result_seq)

    def stream_results(self, timeout_seconds: Optional[float]) -> Iterator[Any]:
        while True:
            try:
                if timeout_seconds is None:
                    kind, payload = self._result_queue.get()
                else:
                    kind, payload = self._result_queue.get(timeout=timeout_seconds)
            except queue.Empty as exc:
                raise TimeoutError(f"Workflow stream timed out after {timeout_seconds:.1f}s") from exc

            if kind == "result":
                yield payload
                continue
            if kind == "error":
                raise RuntimeError(str(payload))
            if kind == "done":
                return


class WorkflowHandle:
    """Operation selector handle for one workflow specification."""

    def __init__(self, client: "WorkflowsClient", spec: WorkflowSpec):
        self._client = client
        self._spec = spec

    def __getattr__(self, operation_name: str):
        op = self._spec.operations.get(operation_name)
        if op is None:
            known = ", ".join(sorted(self._spec.operations.keys())) or "<none>"
            raise AttributeError(
                f"Workflow '{self._spec.workflow_name}' does not define operation '{operation_name}'. "
                f"Available: {known}"
            )

        def _invoke(*args, **kwargs):
            return self._client.invoke(self._spec, op, *args, **kwargs)

        return _invoke


class WorkflowsClient:
    """Selector API for invoking workflow operations over Socket.IO."""

    def __init__(
        self,
        *,
        session: Any,
        deployment_ids: Optional[List[str]] = None,
        call_timeout: Optional[float] = None,
    ) -> None:
        self._session = session
        if call_timeout is None:
            self._call_timeout = None
        else:
            timeout_seconds = float(call_timeout)
            if timeout_seconds <= 0:
                raise ValueError("call_timeout must be > 0 when provided, or None for no timeout")
            self._call_timeout = timeout_seconds
        self._lock = threading.Lock()
        self._specs_by_id: Dict[str, WorkflowSpec] = {}
        self._ids_by_alias: Dict[str, List[str]] = {}
        self._jobs: Dict[str, JobTracker] = {}
        self._job_workflow_names: Dict[str, str] = {}
        self._connected = threading.Event()
        if getattr(self._session, "connected", False):
            self._connected.set()

        for deployment_id in deployment_ids or []:
            self._ensure_spec(str(deployment_id).strip())

    def _ensure_spec(self, deployment_id: str) -> WorkflowSpec:
        normalized = str(deployment_id or "").strip()
        if not normalized:
            raise ValueError("workflow selector cannot be empty")

        with self._lock:
            existing = self._specs_by_id.get(normalized)
        if existing is not None:
            return existing

        definition = read_workflow_definition(normalized)
        spec = WorkflowSpec.from_definition(definition)

        with self._lock:
            self._specs_by_id[spec.deployment_id] = spec
            self._ids_by_alias.setdefault(spec.workflow_name, [])
            if spec.deployment_id not in self._ids_by_alias[spec.workflow_name]:
                self._ids_by_alias[spec.workflow_name].append(spec.deployment_id)
            return spec

    def __call__(self, selector: str) -> WorkflowHandle:
        selected = str(selector or "").strip()
        if not selected:
            raise ValueError("workflow selector cannot be empty")

        with self._lock:
            by_id = self._specs_by_id.get(selected)
            if by_id is not None:
                return WorkflowHandle(self, by_id)
            matches = list(self._ids_by_alias.get(selected, []))

        if len(matches) > 1:
            ids = ", ".join(sorted(matches))
            raise KeyError(
                f"Workflow alias '{selected}' is ambiguous across deployment IDs: {ids}. "
                "Select by deployment ID."
            )
        if len(matches) == 1:
            with self._lock:
                return WorkflowHandle(self, self._specs_by_id[matches[0]])

        try:
            by_id = self._ensure_spec(selected)
            return WorkflowHandle(self, by_id)
        except Exception as exc:
            raise KeyError(
                f"Workflow selector '{selected}' was not found. "
                "Use a deployment ID from initialize(workflows=[...]) or a unique workflow_name alias."
            ) from exc

    @staticmethod
    def _decode_json(value: Any) -> Any:
        if not isinstance(value, str):
            return value
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value

    def _register_job(self, job_id: str, tracker: JobTracker) -> None:
        with self._lock:
            self._jobs[job_id] = tracker

    def _pop_job(self, job_id: str) -> Optional[JobTracker]:
        with self._lock:
            self._job_workflow_names.pop(job_id, None)
            return self._jobs.pop(job_id, None)

    def _get_job(self, job_id: str) -> Optional[JobTracker]:
        with self._lock:
            return self._jobs.get(job_id)

    @staticmethod
    def _serialize(value: Any) -> str:
        return json.dumps(value, default=str)

    @staticmethod
    def _unwrap_singleton_scalar_wrapper(value: Any) -> Any:
        current = value
        while isinstance(current, (tuple, list)) and len(current) == 1:
            current = current[0]

        # Numpy scalar / 0-d ndarray
        shape = getattr(current, "shape", None)
        if shape == () and hasattr(current, "item"):
            try:
                return current.item()
            except Exception:
                return current

        # Torch single-value tensor
        module_name = current.__class__.__module__
        if module_name.startswith("torch") and hasattr(current, "numel") and hasattr(current, "item"):
            try:
                if int(current.numel()) == 1:
                    return current.item()
            except Exception:
                return current
        return current

    def _validate_value_type(
        self,
        operation: OperationSpec,
        *,
        field_name: str,
        value: Any,
        context: str,
    ) -> None:
        proto_type = operation.param_proto_types.get(field_name)
        if not proto_type:
            return

        expected = _proto_type_label(proto_type)
        valid = True
        if proto_type == "double":
            valid = isinstance(value, Real) and not _is_bool_like(value)
        elif proto_type == "int64":
            valid = isinstance(value, Integral) and not _is_bool_like(value)
        elif proto_type == "bool":
            valid = _is_bool_like(value)
        elif proto_type == "string":
            valid = isinstance(value, str)
        elif proto_type == "bytes":
            valid = isinstance(value, (bytes, bytearray, memoryview))

        if valid:
            return

        actual_type = f"{value.__class__.__module__}.{value.__class__.__name__}"
        hint = ""
        if isinstance(value, (tuple, list)) and len(value) == 1:
            hint = " Hint: got a single-item tuple/list; check for an accidental trailing comma like `epochs = 100,`."
        elif getattr(value, "shape", None) == () and hasattr(value, "item"):
            hint = " Hint: got a 0-d array/tensor wrapper; pass a plain scalar or use `.item()`."
        raise TypeError(
            f"{context} '{field_name}' for operation '{operation.function_name}' "
            f"expects {expected}, got {actual_type} with value {_preview_value(value)}.{hint}"
        )

    def _validate_params(self, operation: OperationSpec, params: Dict[str, Any], *, context: str) -> None:
        for name, value in params.items():
            self._validate_value_type(operation, field_name=name, value=value, context=context)

    def _normalize_scalar_param_wrappers(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return {name: self._unwrap_singleton_scalar_wrapper(value) for name, value in params.items()}

    def _build_unary_params(self, operation: OperationSpec, args: Tuple[Any, ...], kwargs: Dict[str, Any]) -> Dict[str, Any]:
        if args and isinstance(args[0], dict) and len(args) == 1 and not kwargs and not operation.param_names:
            return dict(args[0])

        if len(args) > len(operation.param_names):
            raise TypeError(
                f"Operation '{operation.function_name}' received {len(args)} positional args "
                f"but only {len(operation.param_names)} parameters are defined."
            )

        params: Dict[str, Any] = {}
        for index, value in enumerate(args):
            if index >= len(operation.param_names):
                break
            params[operation.param_names[index]] = value

        for key, value in kwargs.items():
            if operation.param_names and key not in operation.param_names:
                known = ", ".join(operation.param_names)
                raise TypeError(
                    f"Unknown parameter '{key}' for operation '{operation.function_name}'. "
                    f"Expected one of: {known}"
                )
            params[key] = value

        missing = [name for name in operation.param_names if name not in params]
        if missing:
            raise TypeError(
                f"Missing required parameters for '{operation.function_name}': {', '.join(missing)}"
            )

        params = self._normalize_scalar_param_wrappers(params)
        self._validate_params(operation, params, context="Parameter")
        return params

    def _build_input_stream_unary_params(
        self,
        operation: OperationSpec,
        positional_unary_args: Tuple[Any, ...],
        unary_kwargs: Dict[str, Any],
    ) -> Dict[str, Any]:
        unary_param_names = operation.stream_unary_param_names
        if len(positional_unary_args) > len(unary_param_names):
            raise TypeError(
                f"Operation '{operation.function_name}' received {len(positional_unary_args)} stream unary positional args "
                f"but only {len(unary_param_names)} stream unary parameters are defined."
            )

        params: Dict[str, Any] = {}
        for index, value in enumerate(positional_unary_args):
            params[unary_param_names[index]] = value

        for key, value in unary_kwargs.items():
            if key not in unary_param_names:
                known = ", ".join(unary_param_names) or "<none>"
                raise TypeError(
                    f"Unknown stream unary parameter '{key}' for operation '{operation.function_name}'. "
                    f"Expected one of: {known}"
                )
            params[key] = value

        missing = [name for name in unary_param_names if name not in params]
        if missing:
            raise TypeError(
                f"Missing required stream unary parameters for '{operation.function_name}': {', '.join(missing)}"
            )
        params = self._normalize_scalar_param_wrappers(params)
        self._validate_params(operation, params, context="Stream unary parameter")
        return params

    def _coerce_stream_item(
        self,
        operation: OperationSpec,
        item: Any,
        dict_schema_order: Optional[List[str]],
        chunk_index: int,
    ) -> Tuple[Dict[str, Any], Optional[List[str]]]:
        fields = list(operation.input_stream_fields)
        arity = operation.input_stream_arity

        if not fields or arity <= 0:
            raise TypeError(
                f"Operation '{operation.function_name}' is missing input_stream_fields metadata for stream coercion."
            )

        if isinstance(item, dict):
            keys = list(item.keys())
            if dict_schema_order is None:
                if len(keys) != arity:
                    raise TypeError(
                        f"Input stream item {chunk_index} for '{operation.function_name}' must have {arity} fields; got {len(keys)}"
                    )
                dict_schema_order = keys
            else:
                if keys != dict_schema_order:
                    raise TypeError(
                        f"Input stream item {chunk_index} key order mismatch for '{operation.function_name}'. "
                        f"Expected {dict_schema_order}, got {keys}"
                    )

            if len(dict_schema_order) != arity:
                raise TypeError(
                    f"Input stream dict schema arity mismatch for '{operation.function_name}'. "
                    f"Expected {arity} keys, got {len(dict_schema_order)}"
                )
            payload = {field: item[key] for field, key in zip(fields, dict_schema_order)}
            self._validate_params(operation, payload, context=f"Input stream item {chunk_index} field")
            return (payload, dict_schema_order)

        if arity == 1 and not isinstance(item, (tuple, list)):
            payload = {fields[0]: item}
            self._validate_params(operation, payload, context=f"Input stream item {chunk_index} field")
            return (payload, dict_schema_order)

        if isinstance(item, (tuple, list)) and len(item) == arity:
            payload = {name: value for name, value in zip(fields, item)}
            self._validate_params(operation, payload, context=f"Input stream item {chunk_index} field")
            return (payload, dict_schema_order)

        raise TypeError(
            f"Input stream item {chunk_index} for '{operation.function_name}' must be a dict with stable key order, "
            f"a single value (arity=1), or a tuple/list of length {arity}."
        )

    @staticmethod
    def _decode_stream_result(tracker: JobTracker, decoded: Any) -> Any:
        if tracker.output_arity <= 1:
            if isinstance(decoded, dict) and set(decoded.keys()) == {"result"}:
                return decoded["result"]
            return decoded

        if isinstance(decoded, dict):
            keys = list(decoded.keys())
            expected = tracker.output_field_names
            if keys != expected:
                raise TypeError(f"Stream output dict keys mismatch. Expected {expected}, got {keys}")
            return tuple(decoded[name] for name in expected)

        if isinstance(decoded, (list, tuple)) and len(decoded) == tracker.output_arity:
            return tuple(decoded)

        raise TypeError(
            f"Stream output arity mismatch. Expected {tracker.output_arity} items, got value={decoded!r}"
        )

    def _send_input_chunks(self, *, spec: WorkflowSpec, operation: OperationSpec, job_id: str, stream_source: Any, tracker: JobTracker) -> None:
        dict_schema_order: Optional[List[str]] = None
        try:
            chunk_index = 0
            for item in stream_source:
                if tracker.is_terminal():
                    return
                payload, dict_schema_order = self._coerce_stream_item(operation, item, dict_schema_order, chunk_index)
                if tracker.is_terminal():
                    return
                self._session.emit(
                    "workflow_stream_chunk",
                    {
                        "workflow_name": spec.workflow_name,
                        "job_id": job_id,
                        "chunk_id": f"chunk-{chunk_index}",
                        "payload_json": self._serialize(payload),
                        "is_final": False,
                    },
                    require_connected=True,
                )
                chunk_index += 1

            if tracker.is_terminal():
                return
            self._session.emit(
                "workflow_stream_chunk",
                {
                    "workflow_name": spec.workflow_name,
                    "job_id": job_id,
                    "chunk_id": "final",
                    "payload_json": "{}",
                    "is_final": True,
                },
                require_connected=True,
            )
        except Exception as exc:
            if not tracker.is_terminal():
                tracker.set_error(str(exc))

    def invoke(self, spec: WorkflowSpec, operation: OperationSpec, *args, **kwargs):
        if not self._session.connected:
            raise ConnectionError("PDS session is not connected to a workspace master.")

        job_id = f"job-{uuid.uuid4().hex}"
        tracker = JobTracker(
            output_streaming=operation.output_streaming,
            output_field_names=operation.output_stream_fields,
        )
        self._register_job(job_id, tracker)
        with self._lock:
            self._job_workflow_names[job_id] = spec.workflow_name

        sender_thread: Optional[threading.Thread] = None
        try:
            if operation.input_streaming:
                if not args:
                    raise TypeError(
                        f"Operation '{operation.function_name}' expects an input iterable as the first positional argument."
                    )
                stream_source = args[0]
                unary_params = self._build_input_stream_unary_params(operation, args[1:], kwargs)
                params_json = self._serialize(unary_params)
            else:
                params = self._build_unary_params(operation, args, kwargs)
                params_json = self._serialize(params)

            self._session.emit(
                "workflow_stream_start",
                {
                    "workflow_name": spec.workflow_name,
                    "job_id": job_id,
                    "rpc_name": operation.rpc_name,
                    "mode": operation.mode,
                    "params_json": params_json,
                },
                require_connected=True,
            )

            if operation.input_streaming and operation.output_streaming:
                sender_thread = threading.Thread(
                    target=self._send_input_chunks,
                    kwargs={
                        "spec": spec,
                        "operation": operation,
                        "job_id": job_id,
                        "stream_source": stream_source,
                        "tracker": tracker,
                    },
                    daemon=True,
                )
                sender_thread.start()
            elif operation.input_streaming:
                self._send_input_chunks(
                    spec=spec,
                    operation=operation,
                    job_id=job_id,
                    stream_source=stream_source,
                    tracker=tracker,
                )
            else:
                self._session.emit(
                    "workflow_stream_chunk",
                    {
                        "workflow_name": spec.workflow_name,
                        "job_id": job_id,
                        "chunk_id": "final",
                        "payload_json": params_json,
                        "is_final": True,
                    },
                    require_connected=True,
                )

            if operation.output_streaming:

                def _generator():
                    try:
                        for value in tracker.stream_results(self._call_timeout):
                            yield value
                    finally:
                        self._pop_job(job_id)
                        if sender_thread and sender_thread.is_alive():
                            sender_thread.join(timeout=1.0)

                return _generator()

            result = tracker.wait_unary_result(self._call_timeout)
            return result
        finally:
            if not operation.output_streaming:
                self._pop_job(job_id)

    def on_stream_started(self, _payload: Dict[str, Any]) -> None:
        """Socket callback for stream start acknowledgements."""

    def on_stream_update(self, payload: Dict[str, Any]) -> None:
        job_id = str((payload or {}).get("job_id", "")).strip()
        if not job_id:
            return

        tracker = self._get_job(job_id)
        if tracker is None:
            return

        result_json = (payload or {}).get("result_json")
        raw_seq = (payload or {}).get("result_seq")
        seq: Optional[int]
        try:
            seq = int(raw_seq) if raw_seq is not None else None
        except (TypeError, ValueError):
            seq = None
        try:
            decoded = self._decode_json(result_json)
            decoded = self._decode_stream_result(tracker, decoded)
            tracker.add_result(decoded, seq=seq)
        except Exception as exc:
            tracker.set_error(f"Invalid stream response payload: {exc}")

    def on_stream_error(self, payload: Dict[str, Any]) -> None:
        job_id = str((payload or {}).get("job_id", "")).strip()
        message = str((payload or {}).get("message", "Workflow invocation failed"))
        if not job_id:
            return

        tracker = self._pop_job(job_id)
        if tracker is not None:
            tracker.set_error(message)

    def on_stream_completed(self, payload: Dict[str, Any]) -> None:
        job_id = str((payload or {}).get("job_id", "")).strip()
        if not job_id:
            return

        tracker = self._pop_job(job_id)
        if tracker is not None:
            tracker.set_completed()

    def on_socket_disconnected(self) -> None:
        self._connected.clear()

    def on_socket_reconnected(self) -> None:
        self._connected.set()
        with self._lock:
            pending = [(job_id, tracker, self._job_workflow_names.get(job_id, "")) for job_id, tracker in self._jobs.items()]

        for job_id, tracker, workflow_name in pending:
            if tracker.is_terminal() or not workflow_name:
                continue
            try:
                self._session.emit(
                    "workflow_stream_resume",
                    {
                        "workflow_name": workflow_name,
                        "job_id": job_id,
                        "last_result_seq": tracker.last_result_seq(),
                    },
                    require_connected=True,
                )
            except Exception:
                # Resume is best-effort; pending calls will still terminate by error/completion/timeout policies.
                continue

    def fail_all_pending(self, message: str) -> None:
        with self._lock:
            pending = list(self._jobs.items())
            self._jobs.clear()

        for _, tracker in pending:
            tracker.set_error(message)
