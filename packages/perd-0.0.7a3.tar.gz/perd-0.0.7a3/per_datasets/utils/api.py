"""API utilities for the per_datasets module."""

import hashlib
import json
import logging
import shutil
import subprocess
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)

DEFAULT_REGION = "europe-west4"

# Global variable to store API configuration
_API_CONFIG: Dict[str, Any] = {
    "api_key": None,
    "api_key_hash": None,
    "base_url": "https://backend.perd.app",
}


def _detect_region() -> str:
    """Best-effort region detection via gcping, with a stable fallback."""
    gcping_path = shutil.which("gcping")
    if not gcping_path:
        return DEFAULT_REGION

    try:
        region = subprocess.run(
            [gcping_path, "-n", "20", "-t", "1s", "-top"],
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
    except (FileNotFoundError, subprocess.CalledProcessError):
        return DEFAULT_REGION

    return region or DEFAULT_REGION


def get_headers() -> Dict[str, str]:
    """Get standard API headers for authenticated requests."""
    if _API_CONFIG["api_key_hash"] is None:
        raise RuntimeError("per_datasets not initialized. Call pds.initialize(apiKey='your_key') first.")

    return {"X-API-Key-Hash": _API_CONFIG["api_key_hash"]}


def make_request(
    filters: Optional[Dict[str, Any]] = None,
    fields: Optional[List[str]] = None,
    partitions: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Make an authenticated request to the datasets endpoint."""
    try:
        headers = get_headers()
        url = f"{_API_CONFIG['base_url']}/datasets"
        payload = {"api_key_hash": _API_CONFIG["api_key_hash"]}
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as exc:
        raise ConnectionError(f"Failed to connect to API endpoint: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON response from API: {exc}") from exc


def get_api_config() -> Dict[str, Any]:
    """Get the API configuration."""
    return _API_CONFIG


def set_api_key(api_key: str) -> None:
    """Set the API key and precompute its hash."""
    _API_CONFIG["api_key"] = api_key
    if api_key:
        _API_CONFIG["api_key_hash"] = hashlib.sha256(api_key.encode()).hexdigest()
    else:
        _API_CONFIG["api_key_hash"] = None


def validate_api_key(api_key: str) -> Dict[str, Any]:
    """Validate an API key via the server validation endpoint."""
    try:
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        url = f"{_API_CONFIG['base_url']}/internal/validate-key"
        response = requests.post(url, json={"api_key_hash": key_hash})
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as exc:
        logger.error("Validation request failed: %s", exc)
        return {"valid": False, "error": str(exc)}


def initialize_workspace(
    api_key: str,
    *,
    user_id: str,
    deployment_ids: Optional[List[str]] = None,
    default_machine: str = "e2-standard-4",
    machine_overrides: Optional[Dict[str, str]] = None,
    region: Optional[str] = None,
    zone: Optional[str] = None,
    project: Optional[str] = None,
    master_image: Optional[str] = None,
) -> Dict[str, Any]:
    """Initialize a workspace via `/orchestration/initialize` and return the streaming response."""
    try:
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        resolved_region = (region or "").strip() or _detect_region()
        resolved_zone = (zone or "").strip() or f"{resolved_region}-a"

        payload: Dict[str, Any] = {
            "user_id": user_id,
            "region": resolved_region,
            "zone": resolved_zone,
            "deployment_ids": list(deployment_ids or []),
            "default_machine": (default_machine or "e2-standard-4").strip() or "e2-standard-4",
            "machine_overrides": dict(machine_overrides or {}),
            "api_key_hash": key_hash,
        }
        if project:
            payload["project"] = project
        if master_image:
            payload["master_image"] = master_image

        url = f"{_API_CONFIG['base_url']}/orchestration/initialize"
        headers = {"X-API-Key-Hash": key_hash}
        response = requests.post(url, headers=headers, json=payload, stream=True)
        response.raise_for_status()
        return {"status": "started", "response": response}
    except requests.exceptions.RequestException as exc:
        logger.error("Orchestration request failed: %s", exc)
        return {"status": "error", "error": str(exc)}


def get_workspace_status(api_key: str, workspace_id: str) -> Dict[str, Any]:
    """Fetch status and metadata for a specific workspace."""
    try:
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        headers = {"X-API-Key-Hash": key_hash}
        url = f"{_API_CONFIG['base_url']}/orchestration/status/{workspace_id}"
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as exc:
        logger.error("Status check failed: %s", exc)
        return {"error": str(exc)}


def read_workflow_definition(workflow_id: str) -> Dict[str, Any]:
    """Read workflow deployment metadata for runtime invocation setup."""
    if not workflow_id or not str(workflow_id).strip():
        raise ValueError("workflow_id is required")

    normalized_id = str(workflow_id).strip()
    url = f"{_API_CONFIG['base_url']}/workflows/read/{normalized_id}"

    try:
        response = requests.get(url, headers=get_headers())
        response.raise_for_status()
    except requests.exceptions.RequestException as exc:
        raise ConnectionError(f"Failed to read workflow '{normalized_id}': {exc}") from exc

    try:
        payload = response.json()
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid workflow definition response for '{normalized_id}': {exc}") from exc

    data = payload.get("data")
    if not isinstance(data, dict):
        raise ValueError(f"Malformed workflow definition payload for '{normalized_id}'")

    operation_manifest = data.get("operation_manifest")
    if not isinstance(operation_manifest, list):
        operation_manifest = []

    deployment_id = str(data.get("id") or normalized_id).strip() or normalized_id
    workflow_name = str(data.get("workflow_name") or deployment_id).strip() or deployment_id

    return {
        "deployment_id": deployment_id,
        "workflow_name": workflow_name,
        "operation_manifest": operation_manifest,
        "raw": data,
    }


def update_base_url(new_url: str) -> None:
    """Update the global API base URL."""
    normalized_url = new_url.rstrip("/")
    logger.info("Switching API base URL to: %s", normalized_url)
    _API_CONFIG["base_url"] = normalized_url


def process_orchestration_stream(response: requests.Response) -> str:
    """Parse orchestration SSE until terminal event and return `master_url` on success."""
    master_url: Optional[str] = None
    current_event: Optional[str] = None
    done_received = False

    masked_user = (
        f"API Key: {_API_CONFIG['api_key'][:8]}..."
        if _API_CONFIG.get("api_key")
        else "API Key: Authenticating..."
    )

    from .display import digital_screen

    digital_screen(f"{masked_user}\nInitializing orchestration...")

    try:
        for line in response.iter_lines():
            if not line:
                continue

            decoded = line.decode("utf-8")
            if decoded.startswith("event: "):
                current_event = decoded[7:].strip()
                continue

            if not decoded.startswith("data: "):
                continue

            try:
                data = json.loads(decoded[6:])
            except json.JSONDecodeError:
                current_event = None
                continue

            msg = data.get("message", "N/A")
            display_text = f"{masked_user}\n"

            if current_event == "connected":
                display_text += "[SYSTEM] Connected to orchestrator."
                digital_screen(display_text)
            elif current_event == "update":
                if "[" in msg and "elapsed]" in msg:
                    display_text += f"[PROGRESS] {msg}"
                else:
                    display_text += f"[INFO] {msg}"
                digital_screen(display_text)
            elif current_event == "error":
                display_text += f"ERROR: {msg}"
                digital_screen(display_text)
                raise RuntimeError(f"Orchestration failed: {msg}")
            elif current_event == "done":
                display_text += f"DONE: {msg}"
                digital_screen(display_text)
                master_url = data.get("master_url")
                done_received = True
                break
            elif current_event == "delete":
                display_text += f"DELETE: {msg}"
                digital_screen(display_text)
            elif "message" in data:
                display_text += f"[LOG] {msg}"
                digital_screen(display_text)

            current_event = None
    finally:
        response.close()

    if not done_received:
        raise RuntimeError("Orchestration stream ended before completion event.")
    if not master_url:
        raise RuntimeError("Workspace initialized but 'master_url' was missing from the orchestration done event.")

    return master_url


def get_auth_payload() -> Dict[str, str]:
    """Build the auth payload for Socket.IO session authentication."""
    if _API_CONFIG["api_key_hash"] is None:
        raise RuntimeError("per_datasets not initialized. Call pds.initialize(apiKey='your_key') first.")

    return {"api_key_hash": _API_CONFIG["api_key_hash"]}
