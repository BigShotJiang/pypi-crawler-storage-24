import json

import pytest

from per_datasets.utils import api as api_module
from per_datasets.utils import init as init_module


class FakeResponse:
    def __init__(self, *, json_data=None, lines=None, status_code=200):
        self._json_data = json_data
        self._lines = lines or []
        self.status_code = status_code
        self.closed = False

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")

    def json(self):
        if self._json_data is None:
            raise ValueError("No JSON payload configured")
        return self._json_data

    def iter_lines(self):
        for line in self._lines:
            yield line.encode("utf-8")

    def close(self):
        self.closed = True


class FakeSocketClient:
    def __init__(self):
        self.connected = False
        self.handlers = {}
        self.connect_calls = []
        self.emit_calls = []

    def on(self, event):
        def decorator(func):
            self.handlers[event] = func
            return func

        return decorator

    def connect(self, url, auth=None, transports=None, wait_timeout=None):
        self.connect_calls.append(
            {
                "url": url,
                "auth": auth,
                "transports": transports,
                "wait_timeout": wait_timeout,
            }
        )
        self.connected = True

    def disconnect(self):
        self.connected = False

    def emit(self, event, data, callback=None):
        self.emit_calls.append({"event": event, "data": data, "callback": callback})

    def sleep(self, _seconds):
        return None


@pytest.fixture(autouse=True)
def reset_api_config(monkeypatch):
    api_module._API_CONFIG.update(
        {
            "api_key": None,
            "api_key_hash": None,
            "base_url": "https://backend.perd.app",
        }
    )
    monkeypatch.setattr("per_datasets.utils.display.digital_screen", lambda *_args, **_kwargs: None)


@pytest.fixture
def fake_socket(monkeypatch):
    client = FakeSocketClient()
    monkeypatch.setattr(init_module.socketio, "Client", lambda: client)
    return client


def _sse_lines_done(master_url="https://master.example"):
    return [
        "event: update",
        "data: {\"message\": \"starting\"}",
        "event: done",
        f"data: {json.dumps({'message': 'ready', 'master_url': master_url, 'workspace_id': 'ws-1'})}",
    ]


def test_initialize_with_workflows_uses_orchestration_payload(monkeypatch, fake_socket):
    captured = {}

    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        if url.endswith("/orchestration/initialize"):
            captured["payload"] = dict(json or {})
            captured["headers"] = dict(headers or {})
            captured["stream"] = stream
            return FakeResponse(lines=_sse_lines_done("https://master-workflow.example"))
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(api_module.requests, "post", fake_post)
    monkeypatch.setattr(
        api_module.requests,
        "get",
        lambda url, headers=None: FakeResponse(
            json_data={
                "data": {
                    "id": "dep-1",
                    "workflow_name": "rcXP7rD",
                    "operation_manifest": [
                        {
                            "function_name": "add",
                            "rpc_name": "Add",
                            "mode": "unary",
                            "params": [{"name": "a"}, {"name": "b"}],
                        }
                    ],
                }
            }
        ),
    )

    session = init_module.initialize(
        api_key="pk_test_key",
        workflows=["dep-1"],
        machine_overrides={"dep-1": "e2-standard-4"},
        default_machine="e2-standard-4",
        region="europe-west4",
        zone="europe-west4-a",
    )

    assert captured["stream"] is True
    assert captured["payload"] == {
        "user_id": "user-1",
        "region": "europe-west4",
        "zone": "europe-west4-a",
        "deployment_ids": ["dep-1"],
        "default_machine": "e2-standard-4",
        "machine_overrides": {"dep-1": "e2-standard-4"},
        "api_key_hash": api_module._API_CONFIG["api_key_hash"],
    }
    assert session.master_url == "https://master-workflow.example"
    assert fake_socket.connect_calls[0]["url"] == "https://master-workflow.example"
    assert fake_socket.connect_calls[0]["auth"] == {"api_key_hash": api_module._API_CONFIG["api_key_hash"]}
    assert fake_socket.connect_calls[0]["transports"] == ["websocket"]


def test_initialize_without_workflows_sends_empty_deployment_ids(monkeypatch, fake_socket):
    captured = {}

    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        if url.endswith("/orchestration/initialize"):
            captured["payload"] = dict(json or {})
            return FakeResponse(lines=_sse_lines_done("https://master-only.example"))
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(api_module.requests, "post", fake_post)

    session = init_module.initialize(
        api_key="pk_test_key",
        region="europe-west4",
        zone="europe-west4-a",
    )

    assert captured["payload"]["deployment_ids"] == []
    assert session.master_url == "https://master-only.example"
    assert fake_socket.connect_calls[0]["url"] == "https://master-only.example"


def test_initialize_with_master_url_skips_orchestration(monkeypatch, fake_socket):
    calls = {"orchestration": 0}

    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        if url.endswith("/orchestration/initialize"):
            calls["orchestration"] += 1
            return FakeResponse(lines=_sse_lines_done("https://unused.example"))
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(api_module.requests, "post", fake_post)

    session = init_module.initialize(api_key="pk_test_key", master_url="https://direct-master.example")

    assert calls["orchestration"] == 0
    assert session.master_url == "https://direct-master.example"
    assert fake_socket.connect_calls[0]["url"] == "https://direct-master.example"


def test_initialize_rejects_machine_overides_typo():
    with pytest.raises(TypeError, match="machine_overrides"):
        init_module.initialize(api_key="pk_test_key", machine_overides={"dep-1": "e2-standard-4"})


def test_initialize_raises_on_sse_error(monkeypatch, fake_socket):
    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        if url.endswith("/orchestration/initialize"):
            return FakeResponse(
                lines=[
                    "event: error",
                    "data: {\"message\": \"provisioning failed\"}",
                ]
            )
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(api_module.requests, "post", fake_post)

    with pytest.raises(RuntimeError, match="provisioning failed"):
        init_module.initialize(api_key="pk_test_key", workflows=["dep-1"], region="europe-west4", zone="europe-west4-a")

    assert fake_socket.connect_calls == []


def test_initialize_raises_when_done_missing_master_url(monkeypatch, fake_socket):
    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        if url.endswith("/orchestration/initialize"):
            return FakeResponse(
                lines=[
                    "event: done",
                    "data: {\"message\": \"ready\", \"workspace_id\": \"ws-1\"}",
                ]
            )
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(api_module.requests, "post", fake_post)

    with pytest.raises(RuntimeError, match="master_url"):
        init_module.initialize(api_key="pk_test_key", workflows=["dep-1"], region="europe-west4", zone="europe-west4-a")

    assert fake_socket.connect_calls == []


def test_each_session_has_isolated_visualizer_runtime(monkeypatch):
    sockets = []

    def fake_socket_factory():
        client = FakeSocketClient()
        sockets.append(client)
        return client

    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        raise AssertionError(f"Unexpected URL: {url}")

    monkeypatch.setattr(init_module.socketio, "Client", fake_socket_factory)
    monkeypatch.setattr(api_module.requests, "post", fake_post)

    session_a = init_module.initialize(api_key="pk_test_key", master_url="https://master-a.example")
    session_b = init_module.initialize(api_key="pk_test_key", master_url="https://master-b.example")

    assert session_a.visual is not session_b.visual
    assert session_a.visual.runtime is not session_b.visual.runtime
    assert len(sockets) == 2

    session_a.close()
    session_b.close()
