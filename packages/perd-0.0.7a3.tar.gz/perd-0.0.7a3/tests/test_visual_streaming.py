import importlib
import time
import types

import pytest

import per_datasets as pds
from per_datasets.visual import Visualizer

visual_module = importlib.import_module("per_datasets.visual")


class _DummyBatchUpdate:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False


class _DummyTrace:
    def __init__(self, *, x=None, y=None, mode=None, name=None, line=None):
        self.x = x if x is not None else []
        self.y = y if y is not None else []
        color = line.get("color") if isinstance(line, dict) else None
        self.line = types.SimpleNamespace(color=color)
        self.mode = mode
        self.name = name


class _DummyFigureWidget:
    def __init__(self):
        self.data = []

    def update_layout(self, **_kwargs):
        return None

    def update_xaxes(self, **_kwargs):
        return None

    def update_yaxes(self, **_kwargs):
        return None

    def add_trace(self, trace):
        self.data.append(trace)

    def batch_update(self):
        return _DummyBatchUpdate()


@pytest.fixture
def visual_test_env(monkeypatch):
    monkeypatch.setattr(visual_module.go, "FigureWidget", _DummyFigureWidget, raising=False)
    monkeypatch.setattr(visual_module.go, "Scatter", _DummyTrace, raising=False)
    monkeypatch.setattr(visual_module, "display", lambda *_args, **_kwargs: None)
    yield
    pds.visual.shutdown()


def test_tuple_generator_updates_single_visual(visual_test_env):
    def output_stream():
        for item in [(1, 6.7), (2, 6.2), (3, 6.0)]:
            yield item

    vis = Visualizer().line_plot(output_stream(), x="step", y="loss")
    assert vis._thread is not None
    vis._thread.join(timeout=1.0)
    vis._update_plot()

    assert list(vis.figure.data[0].x) == [1.0, 2.0, 3.0]
    assert list(vis.figure.data[0].y) == [6.7, 6.2, 6.0]


def test_multi_series_tuple_mapping(visual_test_env):
    vis = Visualizer().line_plot(
        [(1, 10.0, 0.8), (2, 9.5, 0.82)],
        x="step",
        y=["loss", "accuracy"],
    )
    vis._update_plot()

    assert list(vis.figure.data[0].x) == [1.0, 2.0]
    assert list(vis.figure.data[0].y) == [10.0, 9.5]
    assert list(vis.figure.data[1].x) == [1.0, 2.0]
    assert list(vis.figure.data[1].y) == [0.8, 0.82]


def test_append_updates_buffers_and_marks_dirty(visual_test_env):
    vis = Visualizer().line_plot(None, x="step", y="loss")

    marks = {"count": 0}
    original_mark_dirty = vis.mark_dirty

    def _count_mark_dirty():
        marks["count"] += 1
        original_mark_dirty()

    vis.mark_dirty = _count_mark_dirty
    vis.append((1, 4.5)).append((2, 4.2))
    vis._update_plot()

    assert marks["count"] == 2
    assert list(vis.figure.data[0].x) == [1.0, 2.0]
    assert list(vis.figure.data[0].y) == [4.5, 4.2]


def test_dict_based_inputs_remain_supported(visual_test_env):
    vis_from_list = Visualizer().line_plot(
        [{"step": 1, "loss": 2.0}, {"step": 2, "loss": 1.8}],
        x="step",
        y="loss",
    )
    vis_from_list._update_plot()
    assert list(vis_from_list.figure.data[0].x) == [1.0, 2.0]
    assert list(vis_from_list.figure.data[0].y) == [2.0, 1.8]

    vis_from_dict = Visualizer().line_plot(
        {"step": [1, 2, 3], "loss": [3.0, 2.5, 2.2]},
        x="step",
        y="loss",
    )
    vis_from_dict._update_plot()
    assert list(vis_from_dict.figure.data[0].x) == [1.0, 2.0, 3.0]
    assert list(vis_from_dict.figure.data[0].y) == [3.0, 2.5, 2.2]


def test_invalid_tuple_arity_logs_warning_and_stream_continues(visual_test_env, caplog):
    caplog.set_level("WARNING")

    def output_stream():
        yield (1, 9.0, 99.0)  # Invalid arity for y='loss'
        yield (2, 8.5)

    vis = Visualizer().line_plot(output_stream(), x="step", y="loss")
    assert vis._thread is not None
    vis._thread.join(timeout=1.0)
    vis._update_plot()

    assert list(vis.figure.data[0].x) == [2.0]
    assert list(vis.figure.data[0].y) == [8.5]
    assert "arity mismatch" in caplog.text


def test_scheduler_fallback_thread_updates_item_without_disposed(visual_test_env, monkeypatch):
    updates = {"count": 0}

    class _DummyItem:
        def __init__(self, item_id):
            self.id = item_id

        def _update_plot(self):
            updates["count"] += 1

    def _raise_no_loop():
        raise RuntimeError("no running event loop")

    scheduler = visual_module.RenderScheduler(interval=0.01)
    monkeypatch.setattr(visual_module.asyncio, "get_running_loop", _raise_no_loop)

    item = _DummyItem("item-1")
    scheduler.register(item)
    scheduler.mark_dirty(item.id)

    deadline = time.time() + 0.5
    while updates["count"] == 0 and time.time() < deadline:
        time.sleep(0.02)

    scheduler.stop()
    assert updates["count"] >= 1
