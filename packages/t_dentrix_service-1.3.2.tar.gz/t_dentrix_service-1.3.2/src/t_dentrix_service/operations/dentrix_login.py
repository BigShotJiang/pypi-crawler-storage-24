"""Contains DentrixServiceLogin object."""
import contextlib
import re
import time
from datetime import datetime, timedelta
from email.message import Message
from typing import Any

from fake_useragent import UserAgent
from requests.sessions import Session
from retry import retry
from RPA.Browser.Selenium import Selenium
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver.chrome.options import Options
from SeleniumLibrary.errors import ElementNotFound, NoOpenBrowser
from t_vault import bw_get_item
from twocaptcha import TwoCaptcha

from t_dentrix_service.consts.locators import Locators
from t_dentrix_service.consts.urls.dentrix_urls import DentrixUrls
from t_dentrix_service.exceptions import NoCaptchaException
from t_dentrix_service.utils.logger import logger
from t_dentrix_service.utils import gather_credentials
from t_dentrix_service.utils.outlook import Outlook
from t_dentrix_service.utils.simple_texting import SimpleTexting

USER_AGENT = UserAgent(os="windows", min_percentage=1.3).chrome


class DentrixServiceLogin:
    """Segment of Dentrix Service solely responsible with the authentication process."""

    def __init__(self, dentrix_credentials: dict | tuple | Any, proxy_credentials: dict | tuple | Any = None) -> None:
        """Constructs Dentrix Service.

        Args:
            dentrix_credentials (dict | tuple | Any): Credentials for Dentrix login process, can be a dict with
            "username" and "password" keys, a (username, password) paired tuple or a object with username and password
            attributes.
            proxy_credentials (dict | tuple | Any, optional): _description_. Defaults to None.
        """
        self.session = Session()
        self.dentrix_credentials = dentrix_credentials
        self._set_credentials()
        self.browser = Selenium()
        self.outlook = Outlook()
        self.latest_email = None
        self.sms_service = SimpleTexting(bw_get_item("7767e201-93f8-497e-8dd4-b19200f78653")["API Key"])
        captcha_api_key = bw_get_item("2captcha.com")["api_key"]
        self.captcha_api_key = captcha_api_key

        if proxy_credentials is not None:
            self._set_proxy(proxy_credentials)

    def _set_proxy(self, proxy_credentials: dict | tuple | Any) -> None:
        """Set proxy for Dentrix Session."""
        vpn_username, vpn_password = gather_credentials(proxy_credentials)
        vpn_ip = "us9576.nordvpn.com"
        vpn_port = "89"

        proxies = {
            "https": f"https://{vpn_username}:{vpn_password}@{vpn_ip}:{vpn_port}",
        }

        self.session.proxies = proxies

    def _set_credentials(self) -> None:
        """Set credentials to dentrix login process."""
        self.username, self.password = gather_credentials(self.dentrix_credentials)

    def _click_element_if_exists(self, locator: str) -> None:
        """Clicks the element if it is visible; handles exceptions silently."""
        try:
            self.browser.click_element_when_visible(locator)
        except (ElementNotFound, AssertionError, ElementClickInterceptedException):
            pass

    def _get_index(self) -> dict:
        """Retrieves index information.

        Raises:
            HTTPError: Raised if the GET request fails for any reason.

        Returns:
            dict: The JSON response.
        """
        response = self.session.get(DentrixUrls.INDEX_URL, headers=self._headers())
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _headers(content_type: str = "application/json; charset=UTF-8", add_headers: dict = None) -> dict:
        """Returns the headers for the request with customizable content-type.

        Args:
            content_type (str): The content type of the request.
            add_headers (dict): Additional headers to add to the request.

        Returns:
            dict: The headers for the request.
        """
        headers = {"User-Agent": USER_AGENT, "x-requested-with": "XMLHttpRequest"}
        if content_type:
            headers["Content-Type"] = content_type

        if add_headers:
            headers.update(add_headers)
        return headers

    def _open_browser(self) -> None:
        """Opens a new browser instance, sets its window size, and maximizes it."""
        browser_options = Options()
        browser_options.add_argument("--no-sandbox")
        browser_options.add_argument("--disable-dev-shm-usage")
        self.browser.open_available_browser(
            url=DentrixUrls.LOGIN_URL,
            headless=True,
            browser_selection="Chrome",
            user_agent=USER_AGENT,
            options=browser_options,
        )
        self.browser.set_window_size(1920, 1080)
        self.browser.maximize_browser_window()

    @retry(tries=3, delay=1, backoff=2)
    def login_to_dentrix(self) -> None:
        """Logs into the Dentrix application and sets cookies for the session.

        Raises:
            Exception: Raised if logging into Dentrix fails at any stage, providing details about the specific error.
        """
        try:
            self._login()
            self._set_cookies()
            self._get_index()

        except Exception as error:
            self.browser.capture_page_screenshot("Login_failed_Attempt.png")
            self.browser.close_all_browsers()
            msg = "Logging into Dentrix failed"
            raise Exception(msg) from error

    def _login(self) -> None:
        """Automates the login process into the Dentrix system."""
        if self.is_browser_open():
            self.logout_and_close_browser()
        self._open_browser()
        self.browser.input_text_when_element_is_visible(Locators.Login.ORGANIZATION_XP, "SDP")
        self.browser.input_text_when_element_is_visible(
            Locators.Login.USERNAME_XP, self.dentrix_credentials["username"]
        )
        self.browser.click_element_when_visible(Locators.Login.CONTINUE_XP)

        self.latest_email = self._get_latest_otp_message()

        self.browser.input_text_when_element_is_visible(Locators.Login.PASSWORD_XP, self.password)
        with contextlib.suppress(NoCaptchaException):
            time.sleep(5)
            self._solve_turnstile_captcha()

        self.browser.click_element_when_visible(Locators.Login.SEND_XP)
        self._handle_post_login_mfa()
        logger.info("Logged into Dentrix successfully")

    def _set_cookies(self) -> None:
        """Transfers cookies from the Selenium browser instance to the requests session object."""
        for name, value in self.browser.get_cookies(as_dict=True).items():
            self.session.cookies.set(name, value)

    def is_browser_open(self) -> bool:
        """Check if the browser is open."""
        try:
            return self.browser.driver is not None
        except NoOpenBrowser:
            return False

    def logout_and_close_browser(self) -> None:
        """Logout and close the browser."""
        self.browser.close_browser()

    def handle_unexpected_logout(self) -> bool:
        """Handles the case where the user is logged out of Dentrix."""
        if not self.is_browser_open() or self.browser.does_page_contain_element(Locators.Login.SEND_XP):
            logger.warning("Logged out of Dentrix. Attempting login again.")
            self.login_to_dentrix()
            return True
        return False

    def _solve_turnstile_captcha(self) -> str | None:
        """Solve Cloudflare Turnstile captcha using 2captcha service.

        Returns:
            str | None: The captcha token if solved, None if no captcha found.
        """
        try:
            site_key_element = self.browser.find_element(Locators.Login.SITE_KEY_ELEMENT_XP)
            site_key = site_key_element.get_attribute(Locators.Login.SITE_KEY_ATTRIBUTE)
        except Exception:
            raise NoCaptchaException("No Cloudflare Turnstile captcha found on page")

        page_url = self.browser.get_location()
        logger.info(f"Solving Turnstile captcha with sitekey: {site_key}")

        solver = TwoCaptcha(self.captcha_api_key)
        result = solver.turnstile(sitekey=site_key, url=page_url)
        token = result["code"]

        self.browser.execute_javascript(f"document.querySelector('input[name=\"captcha\"]').value = '{token}';")
        logger.info("Turnstile captcha token injected successfully")
        return token

    def _get_latest_otp_message(self) -> Message | None:
        """Gets the Latest OTP mail from our outlook inbox after logging in.

        Returns:
            str: Otp code needed for authentication.
        """
        emails = self.outlook.search_messages_by_filter(param=Locators.Login.OTP_SENDER)
        if not emails:
            return None
        return emails[0]

    def _get_otp_code(self) -> str:
        """Gets the Latest OTP mail from our outlook inbox after logging in.

        Returns:
            str: Otp code needed for authentication.
        """
        for _ in range(15):
            email = self._get_latest_otp_message()
            if email and (email != self.latest_email or self.latest_email is None):
                match = re.search(Locators.Login.OTP_PATTERN, email.body)
                otp = match.group(1) if match else ""
                return otp
            time.sleep(5)

        raise Exception("No New OTP message received Yet.")

    def _get_otp_code_from_sms(self) -> str:
        """Gets the OTP code from the SMS."""
        base_otp_time_stamp = datetime.utcnow() - timedelta(seconds=10)

        for _ in range(10):
            messages = self.sms_service.get_messages_from_a_sender(
                account_phone=self.sms_service.ACCOUNT_NUMBERS[1],
                contact_phone=Locators.Login.DENTRIX_PHONE_NUMBER,
                since=base_otp_time_stamp,
            )
            if not messages["content"]:
                time.sleep(6)
                continue
            break
        else:
            raise Exception("No OTP message received")

        text = messages["content"][0]["text"]
        match = re.search(Locators.Login.OTP_PATTERN_SMS, text)
        otp = match.group(1) if match else ""
        return otp

    def validate_phone_authentication(self) -> None:
        """Validates the phone authentication."""
        self.browser.wait_until_element_is_visible(Locators.Login.PHONE_NUMBER, timeout=15)
        self.browser.input_text_when_element_is_visible(
            Locators.Login.PHONE_NUMBER, self.sms_service.ACCOUNT_NUMBERS[1]
        )
        self.browser.click_element_when_visible(Locators.Login.SEND_XP)
        self.browser.wait_until_element_is_visible(Locators.Login.OTP_XP, timeout=15)
        self.browser.input_text_when_element_is_visible(Locators.Login.OTP_XP, self._get_otp_code_from_sms())
        self.browser.click_element_when_visible(Locators.Login.SEND_XP)
        logger.info("Successfully Validated Phone Authentication")

    def _detect_post_login_state(self, timeout: int = 60) -> str:
        """Wait for one of the post-login elements and identify which appeared.

        Returns:
            "overview", "otp", or "phone".
        """
        self.browser.wait_until_element_is_visible(Locators.Login.POST_LOGIN_COMBINED_XP, timeout=timeout)

        if self.browser.find_elements(Locators.Login.OVERVIEW_XP):
            return "overview"
        if self.browser.find_elements(Locators.Login.OTP_XP):
            return "otp"
        if self.browser.find_elements(Locators.Login.PHONE_NUMBER):
            return "phone"

        raise AssertionError("Post-login element detected but could not be identified.")

    def _enter_sms_otp(self) -> None:
        """Retrieve an SMS OTP, enter it in the code field, and submit."""
        otp = self._get_otp_code_from_sms()
        self.browser.input_text_when_element_is_visible(Locators.Login.OTP_XP, otp)
        self.browser.click_element_when_visible(Locators.Login.SEND_XP)
        logger.info("Submitted SMS OTP code.")

    def _enter_email_otp(self) -> None:
        """Retrieve an email OTP, enter it in the code field, and submit."""
        otp = self._get_otp_code()
        self.browser.input_text_when_element_is_visible(Locators.Login.OTP_XP, otp)
        self.browser.click_element_when_visible(Locators.Login.SEND_XP)
        logger.info("Submitted email OTP code.")

    def _handle_post_login_mfa(self) -> None:
        """Orchestrate the post-credential-submit MFA flow.

        Handles the three possible screens (overview / OTP / phone-number)
        and the fact that after an email OTP we may land on any of them again.
        """
        state = self._detect_post_login_state()

        if state == "overview":
            return

        if state == "phone":
            self.validate_phone_authentication()
            self.browser.wait_until_element_is_visible(Locators.Login.OVERVIEW_XP, timeout=40)
            return

        # state == "otp"
        if self.browser.does_page_contain("We've sent a text message to:"):
            logger.info("SMS OTP requested.")
            self._enter_sms_otp()
            self.browser.wait_until_element_is_visible(Locators.Login.OVERVIEW_XP, timeout=40)
            return

        logger.info("Email OTP requested.")
        self._enter_email_otp()

        # After email OTP we may see any of the three screens again
        state = self._detect_post_login_state()

        if state == "overview":
            return

        if state == "phone":
            self.validate_phone_authentication()
            self.browser.wait_until_element_is_visible(Locators.Login.OVERVIEW_XP, timeout=40)
            return

        # state == "otp" → SMS this time
        logger.info("SMS OTP requested after email OTP.")
        self._enter_sms_otp()
        self.browser.wait_until_element_is_visible(Locators.Login.OVERVIEW_XP, timeout=40)
