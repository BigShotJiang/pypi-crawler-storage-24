"""File containing the SimpleTexting Class."""
from datetime import datetime
from typing import Optional

import requests

from t_dentrix_service.exceptions import SimpleTextingException


class SimpleTexting:
    """Class to utilize Simple Texting API service."""

    ACCOUNT_NUMBERS = ["2076856594", "6028356431"]

    def __init__(self, api_key: str) -> None:
        """Inialize with the api key."""
        self.api_key = api_key

    def get_messages_from_a_sender(
        self,
        page: int = 0,
        size: int = 50,
        account_phone: Optional[str] = None,
        contact_phone: Optional[str] = None,
        since: Optional[datetime] = None,
    ) -> dict:
        """Get Messages from a specific Sender.

        page (int): The page number of results to retrieve (default is 0).
        size (int): The number of messages to return per page (default is 50, maximum is 500).
        account_phone (str): The phone number on your account to which the messages were sent.
                            If not specified, messages sent to the primary account phone will be returned.
        contact_phone (str): The phone number of the contact whose messages you want to retrieve.
        since (datetime): Starting date from which to start filtering messages.

        Returns:
            A dictionary object that contains list of messages with their metadata
        """
        url = "https://api-app2.simpletexting.com/v2/api/messages"
        params = {
            "page": page,
            "size": size,
            "accountPhone": account_phone,
            "contactPhone": contact_phone,
            "since": f"{since.strftime('%Y-%m-%dT%H:%M:%S')}Z" if isinstance(since, datetime) else None,
        }
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.get(url, params=params, headers=headers)
        if response.status_code == 200:
            data = response.json()
            return data
        else:
            raise SimpleTextingException(f"Request Unsucessful {response.status_code} {response.text}")
