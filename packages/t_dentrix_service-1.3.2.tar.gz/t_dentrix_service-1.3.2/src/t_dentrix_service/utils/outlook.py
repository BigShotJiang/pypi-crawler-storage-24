"""Object for interacting with Outlook."""

from O365 import Account
from O365.message import Message
from t_vault import bw_get_item


class Outlook(object):
    """Class for the working with Google MS 365 graphQL API with O365 lib.

    https://github.com/O365/python-o365#usage

    Credentials must contain the following:
        client_id (str): Azure app client_id
        client_secret (str): Azure app client secret (value)
        tenant_id (str): Azure app tenant_id
        login (str): Email that registered in Azure app with correct access rights
    """

    __slots__ = ["_client_id", "_client_secret", "_tenant_id", "_email", "account"]

    def __init__(self) -> None:
        """Initiation process."""
        sharepoint_vi = bw_get_item("b6172b08-0030-4bbc-a901-afe2017bcc54")
        self._client_id = sharepoint_vi["fields"]["client_id"]
        self._client_secret = sharepoint_vi["fields"]["client_secret"]
        self._tenant_id = sharepoint_vi["fields"]["tenant_id"]
        self._email = sharepoint_vi["username"]
        self.account = self.__authenticate()

    def __authenticate(self):
        """Authenticates the Outlook account using the provided credentials.

        Returns:
            Account or None: The authenticated account object if authentication is successful, None otherwise.
        """
        credentials = (self._client_id, self._client_secret)

        account = Account(
            credentials=credentials,
            auth_flow_type="credentials",
            tenant_id=self._tenant_id,
        )

        if account.authenticate():
            return account
        return None

    def search_messages_by_filter(
        self, folder_name: str = "Inbox", filter: str = "from", param: str = ""
    ) -> list[Message]:
        """Search messages in Outlook by chosen filter.

        Args:
            folder_name (str): The name of the folder to search in.
            filter (str): The filter to use for the search.
            param (str): The string to search for in the messages.

        Returns:
            list[Message]: A list of messages that match the search criteria.
        """
        folder_id = self.account.mailbox(resource=self._email).get_folder(folder_name=folder_name).folder_id
        query = self.account.mailbox(resource=self._email).new_query().on_attribute("parentFolderId").equals(folder_id)
        query = query.chain("and").search(f"{filter}: {param}")
        messages = list(
            self.account.mailbox(resource=self._email).get_messages(query=query, limit=100, download_attachments=True)
        )

        return messages
