from pygitgo.auth.ssh_utils import ensure_github_known_host
from pygitgo.commands.git_operations import (
    git_new_branch, git_commit, git_init, add_remote_origin,
    confirm_remote_link, create_main_branch, check_and_sync_branch,
    git_push, handle_rebase, get_current_branch, is_branch_exist
)
from pygitgo.commands.state import state_operations
from pygitgo.utils.executor import run_command
from pygitgo.auth.manager import login, logout
from pygitgo.auth.account import get_user
from pygitgo.utils.colors import info, success, warning, error, highlight
from pygitgo.exceptions import GitGoError
import subprocess
import shutil
import sys
import re


GITGO_OPERATIONS = ["push", "link", "state", "user"]
HELP_COMMANDS = ["help", "--help", "-h"]
DEFAULT_COMMIT_MSG = "New Project Update"
DEFAULT_MAIN_BRANCH = "main"


def validate_repo_url(url):
    """Validate that the URL looks like a valid Git repository URL."""
    patterns = [
        r'^https?://[\w.-]+/[\w.-]+/[\w.-]+(?:\.git)?/?$',  # HTTPS
        r'^git@[\w.-]+:[\w.-]+/[\w.-]+(?:\.git)?$',          # SSH
    ]
    return any(re.match(p, url.strip()) for p in patterns)


def check_git_installed():
    """Verify that Git is installed and available on PATH."""
    if not shutil.which("git"):
        error("\nGit is not installed or not found on your PATH!")
        info("Install Git from: https://git-scm.com/downloads")
        info("After installing, restart your terminal and try again.\n")
        sys.exit(1)


def link_operation(arguments):
    if len(arguments) < 2:
        error("\nGitHub repository URL required!")
        warning("Usage: gitgo link <github_repo_url> [commit_message]\n")
        sys.exit(1)
    
    if arguments[1] in HELP_COMMANDS:
        warning("\nUsage: gitgo link <github_repo_url> [commit_message]\n")
        warning("github_repo_url: The GitHub repository URL to link")
        warning("commit_message: Custom commit message (default: 'Initial commit')\n")
        sys.exit(0)
    
    repo_url = arguments[1]

    if not validate_repo_url(repo_url):
        error("\nInvalid repository URL!")
        warning("Expected format: https://github.com/username/repo.git")
        warning("             or: git@github.com:username/repo.git\n")
        sys.exit(1)

    commit_message = arguments[2] if len(arguments) > 2 else "Initial commit"
    
    info("\nINITIATING LINK OPERATION...")
    info(f"Target: {repo_url}\n")
    
    if not git_init():
        return
    
    run_command(["git", "add", "."], loading_msg="Staging files...")
    success("Files staged for commit.")
    
    clean_message = commit_message.strip('"\'')
    run_command(["git", "commit", "-m", clean_message], loading_msg="Creating initial commit...")
    success("Initial commit created.")
    
    add_remote_origin(repo_url)
    
    if not confirm_remote_link():
        error("Link operation failed! Check your repository URL.")
        return
    
    current_branch = get_current_branch()
    if current_branch.strip() != DEFAULT_MAIN_BRANCH:
        run_command(["git", "branch", "-m", DEFAULT_MAIN_BRANCH], loading_msg=f"Renaming branch '{current_branch.strip()}' to '{DEFAULT_MAIN_BRANCH}'...")
        current_branch = DEFAULT_MAIN_BRANCH
    
    remote_refs = run_command(["git", "ls-remote", "--heads", "origin", DEFAULT_MAIN_BRANCH], allow_fail=True, loading_msg="Checking remote branches...")
    if not isinstance(remote_refs, subprocess.CalledProcessError) and remote_refs.strip():
        pull_result = run_command(
            ["git", "pull", "origin", DEFAULT_MAIN_BRANCH, "--allow-unrelated-histories", "--no-edit"],
            allow_fail=True, loading_msg="Pulling and merging remote content..."
        )
        if isinstance(pull_result, subprocess.CalledProcessError):
            error("Failed to merge remote content. You may need to resolve conflicts manually.")
            warning("Run: git pull origin main --allow-unrelated-histories")
            warning("Then: gitgo push main 'your message'\n")
            return
        success("Remote content merged successfully.")
    
    print("\n" + ("=" * 90))
    success("LINK OPERATION COMPLETE! REPOSITORY LOCKED AND LOADED!")
    success(f"Ready to push with: gitgo push {DEFAULT_MAIN_BRANCH} 'your message'")
    info("AWAITING FURTHER ORDERS...\n")

    user_choice = input(f"\nDo you want to push now? (y/n): ").lower()
    if user_choice != 'y':
        return
    
    git_push(current_branch)
    
    print("\n" + ("=" * 90))
    success("MISSION COMPLETE — REPOSITORY INITIALIZED AND PUSHED!\nAWAITING FOR YOUR NEXT ORDERS.\n\n")
    

def push_operation(arguments):
    if len(arguments) > 1 and arguments[1] in HELP_COMMANDS:
        warning("\nUsage: gitgo push [branch] [commit_message]\n")
        warning("branch: The branch to push to (default: main)")
        warning("commit_message: The commit message (default: empty string)\n")
        sys.exit(0)
    
    branch = None
    message = None

    if len(arguments) > 1 and arguments[1] in ["-n", "new"]:
        if len(arguments) < 3:
            error("\nBranch name required for new branch creation!\n")
            sys.exit(1)
        elif len(arguments) < 4:
            message = DEFAULT_COMMIT_MSG
        elif len(arguments) > 4:
            error("\nToo many arguments for new branch creation!\n")
            sys.exit(1)

        branch = arguments[2]
        git_new_branch(branch)
    else:
        if len(arguments) < 2:
            branch = get_current_branch()
            message = DEFAULT_COMMIT_MSG
        elif len(arguments) < 3:
            if is_branch_exist(arguments[1]):
                message = DEFAULT_COMMIT_MSG
            else:
                branch = get_current_branch()
                message = arguments[1]
        elif len(arguments) > 3:
            error("\nToo many arguments!\n")
            sys.exit(1)

        branch = branch if branch else arguments[1]
    
    message = message if message else arguments[-1]

    commit_made = git_commit(message)
    
    if commit_made:
        git_push(branch)
    else:
        try:
            unpushed = run_command(["git", "log", "--oneline", f"origin/{branch}..HEAD"], allow_fail=True, loading_msg="Checking for unpushed commits...")
            if not isinstance(unpushed, subprocess.CalledProcessError) and unpushed.strip():
                warning("\nNo changes to commit, but found unpushed commits. Pushing to remote...")
                git_push(branch)
            else:
                info("\nWorking tree is clean and everything is up to date.")
                warning("Make some changes first before using GitGo to commit and push.")
                return
        except:
            warning("\nNo changes to commit. Cannot verify remote status.")
            warning("Make some changes first or check your git remote configuration.")
            return

    print("\n" + ("=" * 90))
    success("MISSION COMPLETE — NO CASUALTIES. ALL TARGETS NEUTRALIZED.\nAWAITING FOR YOUR NEXT ORDERS.\n\n")


def validate_operation(operation):
    if operation not in GITGO_OPERATIONS:
        error(f"\nInvalid operation '{operation}'!")
        warning(f"Supported operations are: {', '.join(GITGO_OPERATIONS)}\n")
        sys.exit(1)

def display_current_user():
    username, email = get_user()
    if username and email:
        print("\n" + "="*40)
        info(f"Git User:  {username}")
        info(f"Git Email: {email}")
        print("="*40 + "\n")
    else:
        warning("\nNo Git user identity configured.")
        info("Run 'gitgo user login'\n")


def user_management(operation):
    if not operation:
        display_current_user()
        exit(0)
    if len(operation) > 1:
        if operation[1] in HELP_COMMANDS:
            if operation[0] == "login":
                info("\nUsage: gitgo user login\n")
                info("Sets up your Git user identity (name and email) for commits.\n")
            elif operation[0] == "logout":
                info("\nUsage: gitgo user logout\n")
                info("Removes your Git user identity configuration.\n")
            else:
                warning("\nUsage: gitgo user <login | logout>\n")
                warning("login: Configure your Git user identity.")
                warning("logout: Remove your Git user identity configuration.\n")
            sys.exit(0)
        else:
            error("\nToo many arguments for user management!\n")
            sys.exit(1)

    if operation[0] == "login":
        login()
    elif operation[0] == "logout":
        logout()
    elif operation[0] in HELP_COMMANDS:
        warning("\nUsage: gitgo user <login | logout>\n")
        warning("login: Configure your Git user identity.")
        warning("logout: Remove your Git user identity configuration.\n")
        sys.exit(0)
    else:
        error(f"\nInvalid user operation '{operation[0]}'!\n")
        sys.exit(1)


def get_version():
    try:
        from importlib.metadata import version
        return version("pygitgo")
    except Exception:
        return "dev"

def display_help():
    print("")
    highlight("       GitGo CLI - Your Fast Git Companion")
    warning("=" * 60)
    info("Usage: gitgo <command> [arguments]\n")
    
    warning("CORE COMMANDS:")
    success("  push")
    print("      gitgo push [branch] [message]       Push branch to remote")
    print("      gitgo push -n <branch> [msg]        Create new branch & push\n")
    
    success("  link")
    print("      gitgo link <url> [message]          Init, commit, and link to repo\n")
    
    warning("STATE MANAGEMENT:")
    success("  state")
    print("      gitgo state list | -l               List all saved states (stashes)")
    print("      gitgo state save | -s [name]        Save the current working state")
    print("      gitgo state load | -o [id]          Load a previously saved state")
    print("      gitgo state delete | -d [id] | -a   Delete a specific or all states\n")
    
    warning("USER CONFIGURATION:")
    success("  user")
    print("      gitgo user login                    Setup Git username and email")
    print("      gitgo user logout                   Remove Git user configuration\n")
    
    
    warning("GLOBAL FLAGS:")
    print("  -h, --help, help                        Show this complete help manual")
    print("  -v, version                             Show GitGo version")
    print("  -r, ready                               Check tool readiness\n")
    sys.exit(0)

def main():
    if len(sys.argv) < 2:
        error("\nInvalid arguments!\n")
        sys.exit(1)

    arguments = sys.argv[1:]

    type_of_operation = arguments[0].lower()

    if type_of_operation in ["-r", "ready"]:
        info("\nALL UNITS ONLINE. GitGo STANDING BY. AWAITING COMMANDS...\n")
        sys.exit(0)

    if type_of_operation in ["-v", "version"]:
        highlight(f"\nGitGo Version {get_version()}\n")
        sys.exit(0)

    if type_of_operation in HELP_COMMANDS:
        display_help()

    check_git_installed()

    validate_operation(type_of_operation)

    ensure_github_known_host()

    try:
        if type_of_operation == "push":
            push_operation(arguments)
        elif type_of_operation == "link":
            link_operation(arguments)
        elif type_of_operation == "state":
            state_operations(arguments[1:])
        elif type_of_operation == "user":
            user_management(arguments[1:])
        else:
            error(f"\nInsufficient arguments for {type_of_operation} operation!\n")
            sys.exit(1)
    except GitGoError as e:
        error(f"\n{e}\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
