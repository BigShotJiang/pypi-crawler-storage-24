from pygitgo.utils.executor import run_command
from pygitgo.utils.colors import info, success, warning, error, BLUE, RESET
import subprocess


def get_user():
    try:
        name = run_command(["git", "config", "--global", "user.name"], allow_fail=True)
        email = run_command(["git", "config", "--global", "user.email"], allow_fail=True)

        if not name or isinstance(name, subprocess.CalledProcessError):
            name = None
        if not email or isinstance(email, subprocess.CalledProcessError):
            email = None
        return name, email
    except:
        return None, None
    
def set_user(name, email):
    run_command(["git", "config", "--global", "user.name", name])
    run_command(["git", "config", "--global", "user.email", email])
    success(f"\nGit user configured Successfully")
    print(f"{BLUE}Username{RESET} : {name}")
    print(f"{BLUE}Email    {RESET}: {email}")

def ensure_user_configure(default_email=None, default_username=None):

    name, email = get_user()

    if name and email:
        return True
    
    if default_username and default_email:
        info(f"\nConfiguring Git identity from GitHub...")
        set_user(default_username, default_email)
        return True
    
    warning("\nGit user identity is not configured!")
    info("This is required for your commits to be attributed correctly.")
    
    if default_username:
        new_username = default_username
        info(f"Using GitHub username: {new_username}")
    else:
        new_username = input("Enter your Username (for commits): ").strip()
    
    prompt_email = "Enter your Email (for commits)"
    if default_email:
        prompt_email += f" [{default_email}]"
    
    new_email = input(f"{prompt_email}: ").strip()
    
    if not new_email and default_email:
        new_email = default_email
        
    if new_username and new_email:
        set_user(new_username, new_email)
        return True
    
    error("Invalid configuration. Name and Email are required.")
    return False
