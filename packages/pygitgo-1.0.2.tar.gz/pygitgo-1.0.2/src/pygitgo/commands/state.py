from pygitgo.utils.executor import run_command
from pygitgo.utils.colors import info, highlight, error, warning, success
import sys


def all_save_state():
    output = run_command([
        "git", "stash", "list",
        "--date=format:%Y-%m-%d %H:%M:%S",
        "--pretty=%gd||%cd||%s"
    ])

    if not output:
        info("\nNo saved states found.\n")
        sys.exit(0)

    save_states = []

    for line in output.splitlines():
        try:
            stash_ref, date, message = line.split("||", 2)

            index = int(
                stash_ref.replace("stash@{", "").replace("}", "")
            )

            save_states.append({
                "id": index + 1,   
                "ref": stash_ref,  
                "date": date,
                "message": message
            })

        except ValueError:
            warning(f"Skipping malformed line: {line}")

    return save_states


def display_save_states():
    save_states = all_save_state()

    print("\nID | Date                | Saved State")
    print("-" * 60)

    for state in save_states:
        highlight(
            f"{state['id']:>2} | {state['date']} | {state['message']}"
        )

    print("-" * 60 + "\n")


def validate_state_id(state_id, save_states):
    if not state_id.isdigit():
        error("\nInvalid input. Please enter a valid state ID.\n")
        return False
    elif (int(state_id) - 1) < 0:
        error("\nState ID cannot be '0' or negative. Please enter a valid state ID.\n")
        return False
    elif (int(state_id) - 1) >= len(save_states):
        error("\nState ID out of range. Please enter a valid state ID.\n")
        return False
    return True


def ask_state_id(save_states):
    proceed = False
    state_id = None

    display_save_states()
    info("\nEnter the ID (or 'q' to cancel): ")

    while not proceed:
        state_id = input(">> ").strip().lower()
        if state_id == 'q':
            warning("\nLoad operation cancelled by user.\n")
            sys.exit(0)
        proceed = validate_state_id(state_id, save_states)
    
    return state_id


def state_list(arguments):
    if len(arguments) > 1:
        if arguments[1] in ("-h", "--help", "help"):
            print("\nDisplay all saved states.\n")
            warning("\nUsage:\n")
            print("  gitgo state list        # Show all saved states")
            print("  gitgo state -l          # Alias\n")
            sys.exit(0)
        error("\nToo many arguments for list operation!\n")
        sys.exit(1)

    display_save_states()


def load_state(arguments):
    if len(arguments) > 2:
        error("\nToo many arguments for load operation!\n")
        sys.exit(1)

    save_states = all_save_state()
    proceed = False
    state_id = None

    if len(arguments) == 2:
        if arguments[1] in ("-h", "--help", "help"):
            print("\nLoad a previously saved working state.\n")
            warning("\nUsage:\n")
            print("  gitgo state load <id>   # Load a specific state by ID")
            print("  gitgo state load        # Show all saved states and prompt for selection")
            print("  gitgo state -o <id>     # Alias\n")
            sys.exit(0)
        elif arguments[1].isdigit():
            state_id = arguments[1]
            proceed = validate_state_id(state_id, save_states)
            if not proceed:
                sys.exit(1)
        else:
            error(f"\nInvalid argument '{arguments[1]}' for load operation. Expected a state ID.\n")
            sys.exit(1)
    
    if not proceed:
        state_id = ask_state_id(save_states)
        
    run_command(["git", "stash", "apply", str(int(state_id) - 1)])

    success(f"\nState '{save_states[int(state_id) - 1]['message']}' loaded successfully.\n")


def save_state(arguments):
    if len(arguments) > 2:
        error("\nToo many arguments for save operation!\n")
        sys.exit(1)
    elif len(arguments) < 2:
        state_name = "Auto-Save"
    
    if len(arguments) == 2:
        if arguments[1] in ("-h", "--help", "help"):
            print("\nSave the current working state with an optional name.\n")
            warning("\nUsage:\n")
            print("  gitgo state save <name>   # Save with a specific name")
            print("  gitgo state save          # Save with default name 'Auto-Save'")
            print("  gitgo state -s <name>     # Alias\n")
            sys.exit(0)
            
        state_name = arguments[1]

    run_command(["git", "stash", "push", "-m", state_name])

    success(f"\nState '{state_name}' saved successfully.\n")


def delete_state(arguments):
    if len(arguments) > 2:
        error("\nToo many arguments for delete operation!\n")
        sys.exit(1)
    elif len(arguments) < 2:
        state_id = ask_state_id(all_save_state())
    else:
        if arguments[1] in ("-h", "--help", "help"):
            print("\nDelete one or all saved working states.\n")
            warning("\nUsage:\n")
            print("  gitgo state delete <id>   # Delete a specific state by ID")
            print("  gitgo state delete -a     # Delete all saved states")
            print("  gitgo state -d <id>       # Alias\n")
            print("  gitgo state -d <id> -a    # Alias for delete all\n")
            sys.exit(0)
        
        elif arguments[1] == '-a':
            confirm = input("\nAre you sure you want to delete all saved states? (y/n): ").strip().lower()
            if confirm.lower() == 'y':
                run_command(["git", "stash", "clear"])
                success("\nAll saved states deleted successfully.\n")
                sys.exit(0)
            else:
                warning("\nDelete operation cancelled by user.\n")
                sys.exit(0)
        
        elif not arguments[1].isdigit():
            error("\nInvalid input. Please enter a valid state ID.\n")
            sys.exit(1)

        state_id = arguments[1]
        if not validate_state_id(state_id, all_save_state()):
            sys.exit(1)
    
    run_command(["git", "stash", "drop", str(int(state_id) - 1)])
    success(f"\nState with ID '{state_id}' deleted successfully.\n")


def state_operations_help():
    warning("\nState Operations Help:\n")
    print("  list, -l      Display all saved states.")
    print("  load, -o      Load a previously saved working state.")
    print("  save, -s      Save the current working state with a given name.")
    print("  delete, -d    Delete a previously saved working state.\n")
    info("Use 'gitgo state <operation> --help' for more information on a specific operation.\n")


def state_operations(arguments):
    if len(arguments) == 0 or arguments[0] in ("-h", "--help", "help"):
        state_operations_help()
        sys.exit(0)

    type_of_operation = arguments[0].lower()
    if type_of_operation in ["list", "-l"]:
        state_list(arguments)
    elif type_of_operation in ["load", "-o"]:
        load_state(arguments)
    elif type_of_operation in ["save", "-s"]:
        save_state(arguments)
    elif type_of_operation in ["delete", "-d"]:
        delete_state(arguments)
    else:
        error(f"\nUnknown state operation: {type_of_operation}\n")
        state_operations_help()
        sys.exit(1)
