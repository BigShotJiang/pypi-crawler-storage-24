"""Core analysis engine components."""
