# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Inbox Monitor — real-time background email watcher.

Polls Gmail or IMAP on a configurable interval, classifies new emails
through the Themis triage engine, and returns priority hits for delivery
to the user's configured notification channel.

State persisted at: ~/.familiar/data/email_monitor.json
  {
    "enabled": false,
    "interval_minutes": 10,
    "last_check_time": null,           # ISO8601 UTC
    "alert_on": ["urgent"],            # priority levels that trigger alerts
    "watch_senders": [],               # always alert on these email addresses or domains
    "watch_topics": [],                # always alert on these keywords in subject/snippet
    "quiet_hours_start": "22:00",
    "quiet_hours_end": "07:00",
    "task_id": null                    # scheduler task ID (set by watch_inbox tool)
  }
"""

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_DEFAULT_CONFIG: dict = {
    "enabled": False,
    "interval_minutes": 10,
    "last_check_time": None,
    "alert_on": ["urgent"],
    "watch_senders": [],
    "watch_topics": [],
    "quiet_hours_start": "22:00",
    "quiet_hours_end": "07:00",
    "task_id": None,
}


# ── Config helpers ─────────────────────────────────────────────────────────────


def _data_dir() -> Path:
    try:
        from familiar.core.paths import DATA_DIR

        return DATA_DIR
    except ImportError:
        return Path.home() / ".familiar" / "data"


def _monitor_file() -> Path:
    return _data_dir() / "email_monitor.json"


def get_monitor_config() -> dict:
    """Load monitor config from disk, filling in defaults for missing keys."""
    path = _monitor_file()
    if path.exists():
        try:
            data = json.loads(path.read_text())
            return {**_DEFAULT_CONFIG, **data}
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load monitor config: %s", e)
    return dict(_DEFAULT_CONFIG)


def save_monitor_config(config: dict):
    """Persist monitor config at chmod 0o600."""
    path = _monitor_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2) + "\n")
    path.chmod(0o600)


# ── Quiet-hours check ──────────────────────────────────────────────────────────


def _in_quiet_hours(config: dict) -> bool:
    """Return True if the current local time falls inside the quiet window."""
    now = datetime.now()
    start_str = config.get("quiet_hours_start", "22:00")
    end_str = config.get("quiet_hours_end", "07:00")
    try:
        qs = datetime.strptime(start_str, "%H:%M").replace(
            year=now.year, month=now.month, day=now.day
        )
        qe = datetime.strptime(end_str, "%H:%M").replace(
            year=now.year, month=now.month, day=now.day
        )
        # Overnight window (e.g. 22:00 – 07:00)
        if qs > qe:
            return now >= qs or now <= qe
        return qs <= now <= qe
    except ValueError:
        return False


# ── Email classification ───────────────────────────────────────────────────────


def _classify_email(
    from_header: str,
    subject: str,
    snippet: str,
    has_list_unsubscribe: bool = False,
) -> tuple:
    """
    Classify an email through the Themis triage engine.
    Returns (category: str, priority: str).
    Falls back to ("Other", "fyi") if triage is unavailable.
    """
    try:
        from familiar.skills.triage.skill import (
            _categorize_email as _cat,
        )
        from familiar.skills.triage.skill import (
            _get_priority as _pri,
        )

        category, _ = _cat(from_header, subject, snippet, has_list_unsubscribe)
        priority = _pri(subject, category, from_header)
        return category, priority
    except Exception as e:
        logger.debug("Triage classification unavailable: %s", e)
        return "Other", "fyi"


def _should_alert(email_data: dict, config: dict) -> bool:
    """Return True if this email warrants a push alert."""
    priority = email_data.get("priority", "fyi")
    alert_on = set(config.get("alert_on", ["urgent"]))

    if priority in alert_on:
        return True

    # Watch-sender match (exact address or domain suffix)
    sender = email_data.get("from_email", "").lower()
    for ws in config.get("watch_senders", []):
        ws_lower = ws.lower().lstrip("@")
        if sender == ws_lower or sender.endswith("@" + ws_lower):
            return True

    # Watch-topic keyword in subject or snippet
    subject_lower = email_data.get("subject", "").lower()
    snippet_lower = email_data.get("snippet", "").lower()
    for wt in config.get("watch_topics", []):
        wt_lower = wt.lower()
        if wt_lower in subject_lower or wt_lower in snippet_lower:
            return True

    return False


# ── Gmail fetch ────────────────────────────────────────────────────────────────


def _fetch_gmail_since(service, since_dt: datetime) -> list:
    """Fetch unread Gmail messages received after since_dt (max 50)."""
    since_epoch = int(since_dt.timestamp())
    query = f"is:unread after:{since_epoch}"

    try:
        result = service.users().messages().list(
            userId="me", q=query, maxResults=50
        ).execute()
    except Exception as e:
        logger.warning("Gmail list failed: %s", e)
        return []

    message_ids = [m["id"] for m in result.get("messages", [])]
    emails = []

    for msg_id in message_ids:
        try:
            msg = service.users().messages().get(
                userId="me",
                id=msg_id,
                format="metadata",
                metadataHeaders=["From", "Subject", "Date", "List-Unsubscribe"],
            ).execute()
            headers = {
                h["name"].lower(): h["value"]
                for h in msg.get("payload", {}).get("headers", [])
            }
            emails.append({
                "id": msg_id,
                "from": headers.get("from", ""),
                "subject": headers.get("subject", "(no subject)"),
                "snippet": msg.get("snippet", "")[:200],
                "has_list_unsubscribe": "list-unsubscribe" in headers,
                "source": "gmail",
            })
        except Exception as e:
            logger.debug("Failed to fetch Gmail message %s: %s", msg_id, e)

    return emails


# ── IMAP fetch ─────────────────────────────────────────────────────────────────


def _fetch_imap_since(imap_cfg: dict, since_dt: datetime) -> list:
    """Fetch unseen IMAP messages received on or after since_dt (max 50)."""
    try:
        from familiar.skills.triage.skill import _decode_header, _imap_connect
    except ImportError as e:
        logger.debug("IMAP helpers not available: %s", e)
        return []

    since_str = since_dt.strftime("%d-%b-%Y")
    emails = []
    mail = None

    try:
        import email as _email_mod

        mail = _imap_connect(imap_cfg)
        mail.login(imap_cfg["address"], imap_cfg["password"])
        mail.select("INBOX", readonly=True)

        _, data = mail.search(None, f'(UNSEEN SINCE "{since_str}")')
        if not data or not data[0]:
            return []

        # Most recent 50 to avoid overwhelming the scheduler
        msg_ids = data[0].split()[-50:]

        for msg_id in msg_ids:
            try:
                _, msg_data = mail.fetch(
                    msg_id,
                    "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT LIST-UNSUBSCRIBE)])",
                )
                raw = msg_data[0][1] if msg_data and msg_data[0] else b""
                msg = _email_mod.message_from_bytes(raw)
                emails.append({
                    "id": msg_id.decode(),
                    "from": _decode_header(msg.get("From", "")),
                    "subject": _decode_header(msg.get("Subject", "(no subject)")),
                    "snippet": "",
                    "has_list_unsubscribe": bool(msg.get("List-Unsubscribe")),
                    "source": "imap",
                })
            except Exception as e:
                logger.debug("Failed to fetch IMAP message %s: %s", msg_id, e)

    except Exception as e:
        logger.warning("IMAP monitor fetch failed: %s", e)
    finally:
        if mail:
            try:
                mail.logout()
            except Exception:
                pass

    return emails


# ── Core check ─────────────────────────────────────────────────────────────────


def check_new_priority_emails() -> list:
    """
    Fetch emails since last check, classify them, and return those that
    match the configured alert criteria.

    Always updates last_check_time on return so the next poll starts fresh.
    Returns an empty list during quiet hours or when no priority hits exist.
    """
    config = get_monitor_config()

    if _in_quiet_hours(config):
        logger.debug("Inbox monitor: quiet hours — skipping")
        return []

    # Determine the look-back window
    last_check_str = config.get("last_check_time")
    if last_check_str:
        try:
            since_dt = datetime.fromisoformat(last_check_str.replace("Z", ""))
        except ValueError:
            since_dt = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(
                minutes=config.get("interval_minutes", 10) + 5
            )
    else:
        since_dt = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(
            minutes=config.get("interval_minutes", 10) + 5
        )

    # Fetch — try Gmail API first, fall back to IMAP
    raw_emails: list = []

    try:
        from familiar.skills.triage.skill import _get_gmail_service, _gmail_available

        if _gmail_available():
            svc = _get_gmail_service()
            raw_emails = _fetch_gmail_since(svc, since_dt)
    except Exception as e:
        logger.debug("Gmail monitor path failed, trying IMAP: %s", e)

    if not raw_emails:
        try:
            from familiar.skills.email.accounts import get_account

            acct = get_account()
            if acct and acct.get("address") and acct.get("password"):
                imap_cfg = {
                    "address": acct["address"],
                    "password": acct["password"],
                    "imap_server": acct.get("imap_server", "imap.gmail.com"),
                    "imap_port": acct.get("imap_port", 993),
                }
                raw_emails = _fetch_imap_since(imap_cfg, since_dt)
        except Exception as e:
            logger.debug("IMAP monitor path failed: %s", e)

    # Always advance the cursor regardless of fetch outcome
    config["last_check_time"] = datetime.now(timezone.utc).replace(tzinfo=None).isoformat()
    save_monitor_config(config)

    if not raw_emails:
        return []

    # Classify and filter for alert-worthy emails
    try:
        from familiar.skills.triage.skill import (
            _extract_email_address,
            _extract_sender_name,
        )
    except ImportError:

        def _extract_email_address(h):
            import re

            m = re.search(r"<([^>]+)>", h)
            return (m.group(1) if m else h).lower().strip()

        def _extract_sender_name(h):
            return h.split("<")[0].strip().strip('"') or h.split("@")[0]

    # Lazy imports for calendar detection and nonprofit signals
    try:
        from familiar.skills.triage.skill import (
            _detect_calendar_event,
            _detect_nonprofit_signals,
        )
        _has_triage_detection = True
    except ImportError:
        _has_triage_detection = False

    hits = []
    cal_emails = []
    np_action_emails = []

    for em in raw_emails:
        from_header = em.get("from", "")
        subject = em.get("subject", "")
        snippet = em.get("snippet", "")

        category, priority = _classify_email(
            from_header, subject, snippet, em.get("has_list_unsubscribe", False)
        )

        email_data = {
            "id": em["id"],
            "from_email": _extract_email_address(from_header),
            "from_name": _extract_sender_name(from_header),
            "subject": subject,
            "snippet": snippet[:120],
            "category": category,
            "priority": priority,
            "source": em.get("source", "unknown"),
        }

        # Calendar event detection on every email
        if _has_triage_detection:
            cal_info = _detect_calendar_event(subject, snippet)
            if cal_info:
                email_data["has_calendar_event"] = True
                email_data["calendar_hint"] = cal_info
                cal_emails.append(email_data)

            np_signals = _detect_nonprofit_signals(subject, snippet, category)
            if np_signals:
                email_data["nonprofit_signals"] = np_signals
                np_action_emails.append(email_data)

        if _should_alert(email_data, config):
            hits.append(email_data)

    # Cache ALL classified emails (not just hits) for dashboard access
    all_classified = []
    for em in raw_emails:
        from_header = em.get("from", "")
        subject = em.get("subject", "")
        snippet = em.get("snippet", "")
        category, priority = _classify_email(
            from_header, subject, snippet, em.get("has_list_unsubscribe", False)
        )
        all_classified.append({
            "id": em["id"],
            "from_email": _extract_email_address(from_header),
            "from_name": _extract_sender_name(from_header),
            "subject": subject,
            "snippet": snippet[:120],
            "category": category,
            "priority": priority,
            "id_source": em.get("source", "gmail"),
        })
    _save_sorted_cache(all_classified)

    # Queue detected calendar events as pending (non-blocking)
    _queue_pending_events(cal_emails)
    # Queue nonprofit action items (non-blocking)
    _queue_email_actions(np_action_emails)

    return hits


# ── Pending event & action queue pipelines ────────────────────────────────────


def _queue_pending_events(cal_emails: list):
    """Queue calendar events detected in emails for user review.

    Best-practice pattern: never auto-create calendar events silently.
    Batch them for confirmation in the next heartbeat/briefing.
    """
    if not cal_emails:
        return

    try:
        from familiar.skills.email.pending_events import get_pending_event_store
        from familiar.skills.triage.skill import _extract_event_details

        store = get_pending_event_store()
        for em in cal_emails:
            cal_hint = em.get("calendar_hint")
            details = _extract_event_details(
                em.get("subject", ""), em.get("snippet", ""), cal_hint,
            )
            if not details:
                continue

            store.add_event(
                email_id=em["id"],
                email_subject=em.get("subject", ""),
                email_from=f"{em.get('from_name', '')} <{em.get('from_email', '')}>",
                title=details["title"],
                start=details["start"],
                duration=details.get("duration", 60),
                location=details.get("location", ""),
                has_rsvp=details.get("has_rsvp", False),
                source_category=em.get("category", ""),
            )
        logger.info("Queued %d pending calendar events from inbox monitor", len(cal_emails))
    except Exception as e:
        logger.debug("Failed to queue pending events: %s", e)


def _queue_email_actions(np_emails: list):
    """Queue nonprofit-specific email actions for follow-up.

    Maps nonprofit signals to action types for the proactive system.
    """
    if not np_emails:
        return

    try:
        from familiar.skills.email.action_queue import get_action_store

        store = get_action_store()
        for em in np_emails:
            signals = em.get("nonprofit_signals", {})
            subject = em.get("subject", "")
            from_str = f"{em.get('from_name', '')} <{em.get('from_email', '')}>"

            if signals.get("donor_gift"):
                amount = signals.get("gift_amount", "")
                store.add_action(
                    email_id=em["id"],
                    email_subject=subject,
                    email_from=from_str,
                    action_type="thank_you",
                    suggested_response=f"Send thank-you for {amount} gift" if amount
                        else "Send donor acknowledgment",
                    category=em.get("category", ""),
                    priority="action",
                )

            if signals.get("grant_deadline"):
                store.add_action(
                    email_id=em["id"],
                    email_subject=subject,
                    email_from=from_str,
                    action_type="grant_report",
                    suggested_response=f"Grant report deadline: {signals['grant_deadline']}",
                    deadline=signals["grant_deadline"],
                    category=em.get("category", ""),
                    priority="urgent",
                )

            if signals.get("board_reference"):
                store.add_action(
                    email_id=em["id"],
                    email_subject=subject,
                    email_from=from_str,
                    action_type="board_prep",
                    suggested_response="Board meeting referenced — review for prep",
                    category=em.get("category", ""),
                    priority="action",
                )

            if signals.get("legislative_action"):
                store.add_action(
                    email_id=em["id"],
                    email_subject=subject,
                    email_from=from_str,
                    action_type="legislative_action",
                    suggested_response="Advocacy action item — review and respond",
                    category=em.get("category", ""),
                    priority="urgent",
                )

            # RSVP detection (from calendar hint, not nonprofit signals)
            cal_hint = em.get("calendar_hint")
            if cal_hint and cal_hint.get("has_rsvp"):
                store.add_action(
                    email_id=em["id"],
                    email_subject=subject,
                    email_from=from_str,
                    action_type="rsvp",
                    suggested_response="RSVP requested — confirm attendance",
                    category=em.get("category", ""),
                    priority="action",
                )

        logger.info("Queued actions from %d nonprofit-signal emails", len(np_emails))
    except Exception as e:
        logger.debug("Failed to queue email actions: %s", e)


# ── Alert formatting ───────────────────────────────────────────────────────────


# ── Classified email cache ─────────────────────────────────────────────────────

_SORTED_CACHE_FILE = "email_sorted_cache.json"


def _sorted_cache_path() -> Path:
    return _data_dir() / _SORTED_CACHE_FILE


def get_sorted_inbox() -> dict:
    """Return the cached pre-sorted inbox, or empty if no cache exists.

    Returns:
        {
            "emails": [{id, from_name, from_email, subject, snippet, category,
                        priority, source, has_calendar_event?, nonprofit_signals?}],
            "summary": {"total": N, "urgent": N, "action": N, "fyi": N},
            "updated_at": "ISO8601",
        }
    """
    path = _sorted_cache_path()
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {"emails": [], "summary": {}, "updated_at": None}


def _save_sorted_cache(classified_emails: list):
    """Persist classified emails to disk for instant dashboard access."""
    urgent = sum(1 for e in classified_emails if e.get("priority") == "urgent")
    action = sum(1 for e in classified_emails if e.get("priority") == "action")
    fyi = len(classified_emails) - urgent - action

    cache = {
        "emails": classified_emails[:50],  # Cap at 50 for file size
        "summary": {
            "total": len(classified_emails),
            "urgent": urgent,
            "action": action,
            "fyi": fyi,
        },
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    path = _sorted_cache_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cache, indent=2, default=str))
    except OSError as e:
        logger.warning("Failed to save sorted inbox cache: %s", e)


def format_alert_message(hits: list) -> str:
    """Format a concise push notification for a list of priority email hits."""
    if not hits:
        return ""

    urgent = [h for h in hits if h["priority"] == "urgent"]
    action = [h for h in hits if h["priority"] == "action"]
    watched = [h for h in hits if h["priority"] == "fyi"]

    count = len(hits)
    noun = "email" if count == 1 else "emails"
    lines = [f"📬 **{count} priority {noun}:**\n"]

    for em in urgent[:4]:
        subj = em["subject"][:52] + ("…" if len(em["subject"]) > 52 else "")
        lines.append(f"  🔴 {em['from_name']} — {subj}")

    for em in action[:3]:
        subj = em["subject"][:52] + ("…" if len(em["subject"]) > 52 else "")
        lines.append(f"  🟡 {em['from_name']} — {subj}")

    for em in watched[:2]:
        subj = em["subject"][:52] + ("…" if len(em["subject"]) > 52 else "")
        lines.append(f"  👁️  {em['from_name']} — {subj}")

    remaining = count - len(urgent[:4]) - len(action[:3]) - len(watched[:2])
    if remaining > 0:
        lines.append(f"  … and {remaining} more")

    lines.append("\nRun `triage_inbox` to see the full list.")
    return "\n".join(lines)
