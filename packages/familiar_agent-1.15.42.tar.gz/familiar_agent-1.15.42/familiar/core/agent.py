# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar - Main Agent Class (Coordinator)

Thin coordinator that delegates to focused managers:
- ToolExecutor       (tool_executor.py)  — tool execution, RBAC, retry, metrics
- ProviderManager    (provider_manager.py) — provider init, routing, fallback
- PromptBuilder      (prompt_builder.py)  — system prompt, context injection
- MemoryManager      (memory_manager.py)  — episodic memory, remember/recall
- StatusReporter     (status_reporter.py) — status, health, metrics, probes

All public attributes remain on Agent for backward compatibility.
Managers read live state through back-references (self._agent).

Phase 1 (v1.6): Multi-user support via UserContext
Phase 2.1 (v2.1): Input sanitization and structured exceptions
"""

import logging
import os
import time
import uuid
from datetime import datetime
from datetime import timezone as _dt_timezone
from pathlib import Path
from typing import Any, Dict, Generator, Optional

from . import defaults
from .backup import (
    BackupConfig,
    BackupManager,
    BackupManifest,
    BackupType,
)
from .bus import (
    SkillBus,
    set_skill_bus,
)
from .config import Config, load_config
from .context import (
    EmbeddingProvider as ContextEmbeddingProvider,
)
from .context import (
    InMemoryVectorStore,
    RetrievalConfig,
    SemanticRetriever,
)
from .embeddings import (
    EmbeddingProvider as RawEmbeddingProvider,
)
from .embeddings import (
    TFIDFEmbeddings,
    get_embedding_provider,
)
from .event_emitter import EventEmitter
from .exceptions import (
    BudgetExceededError,
    SessionExpiredError,
)
from .experiments import (
    ExperimentManager,
    set_experiment_manager,
)
from .guardrails import (
    GuardrailConfig,
    Guardrails,
    GuardrailViolation,
    UsageTracker,
    ViolationType,
)
from .health import (
    DependencyHealth,
    DependencyType,
    HealthChecker,
    create_memory_agent_health_check,
    create_planner_health_check,
)
from .memory import ConversationHistory, Memory
from .memory_agent import MemoryExtractor

# Mesh networking — lazy imports inside methods to avoid port binding at module load
# Full imports happen in start_mesh() and __init__ (gateway object only)
from .mesh import (
    MeshGateway,
)
from .metrics import (
    MetricsCollector,
    get_metrics_collector,
)
from .observability import SpanKind, SpanStatus, calculate_cost, get_tracer
from .orchestration import (
    Orchestrator,
)
from .planner import TaskPlanner
from .providers import (
    LLMResponse,
    StreamEvent,
    StreamEventType,
)

try:
    from .providers import OllamaProvider as _OllamaProvider
except ImportError:
    _OllamaProvider = None
from .agent_response import AgentResponse

# ── Decomposed managers ──────────────────────────────────────────────────────
from .memory_manager import (
    MemoryManager,
    _get_episodic_encryption,  # noqa: F401 — re-export
)
from .prompt_builder import PromptBuilder
from .provider_manager import ProviderManager
from .resilience import RetryConfig
from .saga import (
    InMemorySagaLog,
    Saga,
    SagaExecution,
    SagaOrchestrator,
)

# Phase 2: Input sanitization and exceptions
from .sanitization import SanitizationLevel, sanitize_user_input
from .scheduler import TaskFrequency, get_scheduler
from .security import (
    Capability,
    SecureSession,
    SecurityConfig,
    SecurityMode,
    SessionManager,
    TrustLevel,
    is_encryption_enabled,
)
from .skills import SkillLoader
from .status_reporter import StatusReporter
from .structured_output import (
    ExtractionMethod,
    StructuredGenerator,
    ValidationStrategy,
)

# Re-export _capture_context_from_result so channels can still import it
# from familiar.core.agent (backward compat).
from .tool_executor import (
    ToolExecutor,
    _capture_context_from_result,  # noqa: F401
)
from .tool_router import RouterConfig, ToolRouter
from .tools import get_tool_registry

# Phase 1: Multi-user support
try:
    from .data_store import DataStore, get_data_store
    from .users import User, UserContext, UserRole

    HAS_USER_MANAGEMENT = True
except ImportError:
    HAS_USER_MANAGEMENT = False
    UserContext = None
    UserRole = None
    User = None
    DataStore = None
    get_data_store = None

# Import compliance module (optional)
try:
    from .compliance import (
        ComplianceMode,
        validate_compliance,
    )

    COMPLIANCE_AVAILABLE = True
except ImportError:
    COMPLIANCE_AVAILABLE = False
    ComplianceMode = None

logger = logging.getLogger(__name__)


class _GuardrailBlock(Exception):
    """
    Internal sentinel raised by _setup_request when a guardrail fires before
    the session is established.  Caught in chat() and chat_stream() and
    converted directly to a user-facing string — never propagates to callers.
    """


class Agent:
    """
    The main agent class.

    Usage:
        agent = Agent()
        response = agent.chat("Hello!", user_id="user123", channel="telegram")

    Security:
        Each user gets a SecureSession with trust level, capabilities, and budget.
        Tools are checked against capabilities before execution.
    """

    def __init__(
        self, config: Optional[Config] = None, security_mode: Optional[SecurityMode] = None
    ):
        self.config = config or load_config()

        # ── Security & compliance ─────────────────────────────────────────────
        self._init_security(security_mode)

        # ── Core components ───────────────────────────────────────────────────
        self.memory = Memory() if self.config.agent.memory_enabled else None
        self.history = ConversationHistory(max_per_chat=self.config.agent.max_conversation_history)
        self.tools = get_tool_registry(sandboxed_dirs=self.config.agent.sandboxed_directories)
        self.skills = SkillLoader(self.config.agent.skills_dirs)

        # ── Scheduler ─────────────────────────────────────────────────────────
        self._init_scheduler()

        # ── Tool router ───────────────────────────────────────────────────────
        self._init_tool_router()

        # ── Observability (telemetry, resilience) ─────────────────────────────
        self._init_observability()

        # ── Providers (LLM, planning, extraction) ─────────────────────────────
        self._init_providers()

        # ── Guardrails ────────────────────────────────────────────────────────
        self._init_guardrails()

        # ── MemoryManager ─────────────────────────────────────────────────────
        self._memory_manager = MemoryManager(self)

        # ── Infrastructure (sagas, experiments, orchestrator, bus) ─────────────
        self._init_infrastructure()

        # ── SemanticRetriever (RAG pipeline) ──────────────────────────────────
        self.retriever: SemanticRetriever = self._init_retriever()
        _emb_name = (
            type(self.memory._embedder).__name__
            if (self.memory and self.memory._embedder)
            else "TFIDFEmbeddings"
        )
        logger.debug(f"SemanticRetriever active: {_emb_name} embeddings")

        # ── Metrics, backup, health ───────────────────────────────────────────
        self.metrics: MetricsCollector = get_metrics_collector()
        self.backup: BackupManager = self._init_backup()
        if getattr(self.backup.config, "enabled", False) and self.scheduler is not None:
            self._schedule_backup()
        # HealthChecker MUST come after backup, metrics, retriever, bus, planner
        self.health: HealthChecker = self._init_health_checker()

        # ── Mesh gateway ──────────────────────────────────────────────────────
        self._init_mesh()

        # ── Final wiring ──────────────────────────────────────────────────────
        encryption_status = "encrypted" if is_encryption_enabled() else "unencrypted"
        compliance_status = self.compliance_mode.value if self.compliance_mode else "none"
        logger.info(
            f"Agent initialized: provider={self.provider.name}, "
            f"security={self.security_mode.value}, "
            f"compliance={compliance_status}, "
            f"storage={encryption_status}"
        )
        self._prompt_builder = PromptBuilder(self)

        # Sync job class from creature state
        try:
            from ..creature.state import load_creature as _load_creature

            _creature = _load_creature()
            if _creature and _creature.job_class:
                self.config.agent.job_class = _creature.job_class
        except Exception:
            logger.debug("Failed to sync job_class from creature state", exc_info=True)

        self._status_reporter = StatusReporter(self)
        self.health.mark_startup_complete()
        self._validate_credentials_on_startup()

    # ── __init__ sub-methods (order matters) ──────────────────────────────────

    def _init_security(self, security_mode: Optional[SecurityMode] = None) -> None:
        """Bootstrap security, compliance, sessions."""
        from .security import bootstrap_security

        bootstrap_security()

        self.compliance_mode = None
        self._compliance_profile = None
        self._audit_encrypted_storage = None
        self._compliance_audit_logger = None
        self._validate_compliance()

        self.security_mode = security_mode or SecurityMode(
            getattr(self.config.agent, "security_mode", "balanced")
        )
        self.sessions = SessionManager(self.security_mode)

    def _init_scheduler(self) -> None:
        """Initialize scheduler and register compliance cleanup if needed."""
        self.scheduler = get_scheduler() if self.config.agent.scheduler_enabled else None
        if not self.scheduler:
            return

        self.scheduler.set_agent(self)

        # Register compliance cleanup task when compliance mode is active
        if self.compliance_mode and self._compliance_profile:
            existing = self.scheduler.list_tasks()
            has_cleanup = any(t["name"] == "compliance_cleanup" for t in existing)
            if not has_cleanup:
                from .scheduler import TaskFrequency, TaskType

                retention = self._compliance_profile.data_retention_days or 365
                self.scheduler.add_task(
                    name="compliance_cleanup",
                    description=f"Compliance data retention cleanup (max_age={retention} days)",
                    frequency=TaskFrequency.DAILY,
                    task_type=TaskType.CLEANUP,
                    payload={"max_age_days": retention},
                    time_of_day="03:00",
                )
                logger.info(f"Registered compliance_cleanup task (retention={retention} days)")

        # Auto-enable inbox monitor when email is connected
        try:
            from familiar.skills.email.monitor import get_monitor_config, save_monitor_config
            from .scheduler import TaskFrequency, TaskType

            mon_cfg = get_monitor_config()
            existing_names = {t.name for t in self.scheduler.tasks.values()} if hasattr(
                self.scheduler, 'tasks'
            ) else set()

            if "inbox_watch" not in existing_names:
                # Check if email is configured
                _has_email = False
                try:
                    from familiar.skills.email.accounts import get_all_accounts
                    _has_email = bool(get_all_accounts())
                except Exception:
                    import os as _os
                    _has_email = bool(_os.environ.get("EMAIL_ADDRESS"))

                if _has_email:
                    interval = mon_cfg.get("interval_minutes", 10)
                    self.scheduler.add_task(
                        name="inbox_watch",
                        description=f"Background email sorting (every {interval} min)",
                        frequency=TaskFrequency.HOURLY,
                        task_type=TaskType.HEARTBEAT,
                        interval_minutes=interval,
                    )
                    if not mon_cfg.get("enabled"):
                        mon_cfg["enabled"] = True
                        save_monitor_config(mon_cfg)
                    logger.info("Inbox monitor auto-enabled (every %d min)", interval)
        except Exception as e:
            logger.debug("Inbox monitor auto-enable skipped: %s", e)

        # Auto-start so backup tasks and registered tasks fire on all deployments.
        # Channels can still call start_scheduler() again (idempotent).
        self.scheduler.start()

    def _init_tool_router(self) -> None:
        """Initialize tool router with guidance loader."""
        from .guidance import GuidanceLoader

        self._guidance_loader = GuidanceLoader()

        _is_local = (
            _OllamaProvider is not None
            and hasattr(self, "provider")
            and isinstance(self.provider, _OllamaProvider)
        ) or getattr(getattr(self.config, "llm", None), "default_provider", "") == "ollama"
        self.tool_router = ToolRouter(
            guidance=self._guidance_loader,
            tool_registry=self.tools,
            config=RouterConfig(
                max_tools=(defaults.ROUTER_MAX_TOOLS_LOCAL if _is_local
                           else defaults.ROUTER_MAX_TOOLS_CLOUD),
                fallback_count=(defaults.ROUTER_FALLBACK_COUNT_LOCAL if _is_local
                                else defaults.ROUTER_FALLBACK_COUNT_CLOUD),
                confidence_threshold=defaults.ROUTER_CONFIDENCE_THRESHOLD,
                min_routing_confidence=defaults.ROUTER_MIN_ROUTING_CONFIDENCE,
                enabled=True,
            ),
        )

    def _init_observability(self) -> None:
        """Initialize telemetry tracer and resilience config."""
        try:
            from .observability import ExporterType, NullExporter

            _exp_name = os.environ.get("FAMILIAR_TELEMETRY_EXPORTER", "none").lower()
            _exp_map = {
                "console": ExporterType.CONSOLE,
                "otlp": ExporterType.OTLP,
                "json_file": ExporterType.JSON_FILE,
            }
            if _exp_name in _exp_map:
                from .observability import init_telemetry

                init_telemetry(exporter=_exp_map[_exp_name].value)
            self.tracer = get_tracer()
            if _exp_name == "none":
                self.tracer.exporter = NullExporter()
        except Exception as e:
            logger.debug("Telemetry init skipped: %s", e)
            self.tracer = None

        self.retry_config = (
            RetryConfig(
                max_attempts=self.config.resilience.max_attempts,
                base_delay=self.config.resilience.base_delay,
                max_delay=self.config.resilience.max_delay,
                exponential_base=self.config.resilience.exponential_base,
                jitter=self.config.resilience.jitter,
            )
            if self.config.resilience.enabled
            else None
        )

    def _init_providers(self) -> None:
        """Initialize LLM providers, planner, memory extractor, eval capture."""
        # ── ProviderManager ───────────────────────────────────────────────────
        self._provider_manager = ProviderManager(self)
        self.capacity_tracker = self._provider_manager.capacity_tracker
        self.provider = self._provider_manager.init_provider()
        self._provider_manager.init_model_router()

        # ── ToolExecutor ──────────────────────────────────────────────────────
        self._tool_executor = ToolExecutor(self)

        # Background provider for planning and memory extraction
        planning_enabled = self.config.agent.planning_enabled
        extraction_enabled = self.config.agent.memory_extraction_enabled

        self._lightweight_provider = None
        if planning_enabled or extraction_enabled:
            try:
                from .providers import get_lightweight_provider

                routes = getattr(self.provider_manager, "_manual_routes", None)
                self._lightweight_provider = get_lightweight_provider(self.config, routes)
            except Exception as e:
                logger.debug(f"No lightweight provider: {e}")

        bg_provider = self._lightweight_provider or self.provider

        self.planner = (
            TaskPlanner(provider=bg_provider, enabled=planning_enabled)
            if planning_enabled
            else None
        )
        self.memory_extractor = (
            MemoryExtractor(
                provider=bg_provider,
                memory=self.memory,
                enabled=extraction_enabled and self.memory is not None,
            )
            if extraction_enabled
            else None
        )

        # LLM-powered memory consolidation summarizer
        from .memory_consolidation import create_llm_summarizer

        self._consolidation_summarizer = create_llm_summarizer(bg_provider)

        # Opt-in eval trace capture
        self._eval_dataset_builder = None
        if self.config.agent.eval_capture_enabled:
            try:
                from .evaluation import EvalDatasetBuilder

                self._eval_dataset_builder = EvalDatasetBuilder()
            except Exception as e:
                logger.debug(f"Eval dataset builder not available: {e}")

        # Register eval export tool
        from .tools import Tool

        self.tools.register(
            Tool(
                name="export_eval_dataset",
                description="Export captured conversation traces as an eval test suite",
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Name for the exported dataset (default: production)",
                            "default": "production",
                        },
                    },
                },
                handler=self._handle_export_eval_dataset,
                category="admin",
            )
        )

        # Load skills
        if self.config.agent.skills_enabled:
            self.skills.load_all()
            self._guidance_loader.generate_from_skills(self.skills.skills)
            self.tool_router._build_index()

    def _init_guardrails(self) -> None:
        """Initialize content safety, PII, rate limits, token/cost/iteration caps."""
        guardrail_cfg = GuardrailConfig(
            max_tokens_per_request=self.config.agent.guardrail_max_tokens,
            max_cost_per_request=self.config.agent.guardrail_max_cost_request,
            max_cost_per_hour=self.config.agent.guardrail_max_cost_hour,
            max_cost_per_day=self.config.agent.guardrail_max_cost_day,
            max_iterations=self.config.agent.max_iterations,
            max_requests_per_minute=self.config.agent.guardrail_rpm,
            request_timeout_seconds=self.config.agent.guardrail_timeout,
            enable_content_filter=True,
            enable_pii_detection=self.config.agent.enable_pii_detection,
            blocked_tools=self.config.agent.blocked_tools,
            require_approval_tools=self.config.agent.require_approval_tools,
        )
        self.guardrails = Guardrails(guardrail_cfg)

        if self.compliance_mode:
            self.guardrails.set_compliance_mode(self.compliance_mode)

        logger.debug(
            f"Guardrails active: rpm={guardrail_cfg.max_requests_per_minute} "
            f"max_iter={guardrail_cfg.max_iterations} "
            f"pii={'on' if guardrail_cfg.enable_pii_detection else 'off'}"
        )

    def _init_infrastructure(self) -> None:
        """Initialize sagas, experiments, orchestrator, skill bus."""
        self.sagas = SagaOrchestrator(
            saga_log=InMemorySagaLog(),
            default_timeout=self.config.agent.saga_default_timeout,
        )

        _exp_dir = Path.home() / ".familiar" / "experiments"
        _exp_dir.mkdir(parents=True, exist_ok=True)
        _exp_path = str(_exp_dir / "experiments.json")
        self.experiments = ExperimentManager(persistence_path=_exp_path)
        set_experiment_manager(self.experiments)

        self.orchestrator = Orchestrator()

        self.bus = SkillBus(
            async_processing=True, dead_letter_queue_size=defaults.SKILLBUS_DLQ_SIZE
        )
        set_skill_bus(self.bus)

        self.distributed_bus = None
        if self.config.agent.distributed_bus_enabled:
            try:
                from .distributed import create_distributed_bus

                _redis_url = os.environ.get("REDIS_URL", "redis://localhost:6379")
                self.distributed_bus = create_distributed_bus(redis_url=_redis_url)
                logger.info(f"DistributedSkillBus active: {_redis_url}")
            except Exception as e:
                logger.warning(f"DistributedSkillBus unavailable: {e}")

    def _init_mesh(self) -> None:
        """Configure mesh gateway (not started — call start_mesh() to activate)."""
        _mesh_enabled = self.config.agent.mesh_enabled or os.environ.get(
            "FAMILIAR_MESH_ENABLED", ""
        ).lower() in ("1", "true", "yes")
        _mesh_host = os.environ.get("FAMILIAR_MESH_HOST", defaults.MESH_DEFAULT_HOST)
        _mesh_port = int(os.environ.get("FAMILIAR_MESH_PORT", str(defaults.MESH_DEFAULT_PORT)))

        self.mesh_gateway: Optional[MeshGateway] = None
        self._mesh_enabled = _mesh_enabled
        self._mesh_host = _mesh_host
        self._mesh_port = _mesh_port

        if not _mesh_enabled:
            logger.debug("Mesh disabled. Set FAMILIAR_MESH_ENABLED=true to enable.")
            return

        self.mesh_gateway = MeshGateway(self, host=_mesh_host, port=_mesh_port)
        self.mesh_gateway.set_orchestrator(self.orchestrator)

        hipaa = self.config.agent.hipaa_enabled or os.environ.get(
            "FAMILIAR_HIPAA", ""
        ).lower() in ("1", "true", "yes")

        # Usage tracker with optional Dross ledger
        dross = None
        try:
            from familiar.core.dross import DrossLedger

            dross = DrossLedger()
        except Exception as e:
            logger.warning("Dross ledger unavailable, usage tracking disabled: %s", e)
        self.mesh_gateway.init_usage_tracker(dross_ledger=dross, hipaa_enabled=hipaa)

        # Wire memory bridge if memory is available
        if self.memory is not None:
            md_store = None
            try:
                from familiar.core.markdown_memory import MarkdownMemoryStore, _get_memories_dir

                _user_id = getattr(self, "user_id", "default")
                md_store = MarkdownMemoryStore(_get_memories_dir(), _user_id)
            except Exception as e:
                logger.warning("Markdown memory store unavailable: %s", e)
            self.mesh_gateway.init_memory_bridge(
                self.memory, hipaa_enabled=hipaa, markdown_store=md_store
            )

        self.mesh_gateway.init_model_bridge(hipaa_enabled=hipaa)
        logger.info(
            f"Mesh gateway configured: {_mesh_host}:{_mesh_port} "
            f"(call start_mesh() to activate)"
        )

    # ════════════════════════════════════════════════════════════════
    # BACKWARD-COMPAT DELEGATES — managers now own the logic
    # ════════════════════════════════════════════════════════════════

    # ── ProviderManager properties ────────────────────────────────────────
    @property
    def model_router(self):
        return self._provider_manager.model_router

    @model_router.setter
    def model_router(self, value):
        self._provider_manager.model_router = value

    @property
    def _routing_mode(self):
        return self._provider_manager._routing_mode

    @_routing_mode.setter
    def _routing_mode(self, value):
        self._provider_manager._routing_mode = value

    @property
    def _manual_routes(self):
        return self._provider_manager._manual_routes

    @_manual_routes.setter
    def _manual_routes(self, value):
        self._provider_manager._manual_routes = value

    # ── ToolExecutor delegates ────────────────────────────────────────────
    def set_tool_event_callback(self, user_id, callback):
        self._tool_executor.set_tool_event_callback(user_id, callback)

    def clear_tool_event_callback(self, user_id):
        self._tool_executor.clear_tool_event_callback(user_id)

    def _execute_tool_secure(self, *args, **kwargs):
        return self._tool_executor.execute_tool_secure(*args, **kwargs)

    def _execute_tools(self, *args, **kwargs):
        return self._tool_executor.execute_tools(*args, **kwargs)

    def _get_allowed_tools(self, *args, **kwargs):
        return self._tool_executor.get_allowed_tools(*args, **kwargs)

    def _get_skill_for_tool(self, tool_name):
        return self._tool_executor.get_skill_for_tool(tool_name)

    # ── Eval dataset export ──────────────────────────────────────────────

    def export_eval_dataset(self, name: str = "production") -> str:
        """Export captured conversation traces as an eval test suite."""
        if not self._eval_dataset_builder:
            return "Eval capture not enabled. Set eval_capture_enabled: true in config."
        path = self._eval_dataset_builder.build_dataset(name=name, min_cases=1)
        if path:
            return f"Exported eval dataset to {path}"
        return "No traces captured yet."

    def _handle_export_eval_dataset(self, params: dict) -> str:
        """Tool handler for export_eval_dataset."""
        name = params.get("name", "production")
        return self.export_eval_dataset(name=name)

    # ── ProviderManager delegates ─────────────────────────────────────────
    def _init_provider(self):
        return self._provider_manager.init_provider()

    def _init_model_router(self):
        return self._provider_manager.init_model_router()

    def _select_provider(self, message, session):
        return self._provider_manager.select_provider(message, session)

    def _provider_fallback(self, active_provider, primary_error):
        return self._provider_manager.provider_fallback(active_provider, primary_error)

    def get_routing_config(self):
        return self._provider_manager.get_routing_config()

    def set_routing_config(self, mode, routes=None):
        return self._provider_manager.set_routing_config(mode, routes)

    def get_presets(self):
        return self._provider_manager.get_presets()

    def save_preset(self, slot, name=None):
        return self._provider_manager.save_preset(slot, name)

    def load_preset(self, slot):
        return self._provider_manager.load_preset(slot)

    def set_active_preset(self, slot):
        return self._provider_manager.set_active_preset(slot)

    def rename_preset(self, slot, name):
        return self._provider_manager.rename_preset(slot, name)

    def delete_preset(self, slot):
        return self._provider_manager.delete_preset(slot)

    def switch_provider(self, provider_name):
        return self._provider_manager.switch_provider(provider_name)

    def switch_job_class(self, job_class_key: str) -> str:
        """Switch the active job class. Pass '' to clear."""
        from ..creature.state import load_creature, save_creature
        from ..jobs import get_job_class, list_job_classes

        if job_class_key and not get_job_class(job_class_key):
            valid = [jc.key for jc in list_job_classes()]
            return f"Unknown job class '{job_class_key}'. Valid: {valid}"

        # Persist to creature state
        creature = load_creature()
        if creature:
            creature.job_class = job_class_key
            save_creature(creature)

        # Also update config for consistency
        self.config.agent.job_class = job_class_key

        if not job_class_key:
            return "Job class cleared — running as general assistant."
        jc = get_job_class(job_class_key)
        return f"Switched to {jc.name} ({jc.description})."

    # ── PromptBuilder delegates ───────────────────────────────────────────
    def get_system_prompt(
        self,
        session=None,
        user_context=None,
        current_message=None,
        channel="default",
        is_proactive=False,
        routed_skills=None,
    ):
        return self._prompt_builder.build_system_prompt(
            session, user_context, current_message, channel, is_proactive, routed_skills
        )

    # ── MemoryManager delegates ───────────────────────────────────────────
    @property
    def _episodic_enabled(self):
        return self._memory_manager._episodic_enabled

    @_episodic_enabled.setter
    def _episodic_enabled(self, value):
        self._memory_manager._episodic_enabled = value

    @property
    def _episodic_dir(self):
        return self._memory_manager._episodic_dir

    @_episodic_dir.setter
    def _episodic_dir(self, value):
        self._memory_manager._episodic_dir = value

    @property
    def _episodic_stores(self):
        return self._memory_manager._episodic_stores

    @_episodic_stores.setter
    def _episodic_stores(self, value):
        self._memory_manager._episodic_stores = value

    def _get_episodic_memory(self, user_id):
        return self._memory_manager.get_episodic_memory(user_id)

    def _save_episodic_memory_async(self, user_id):
        return self._memory_manager.save_episodic_memory_async(user_id)

    def remember(self, key, value, category="fact"):
        self._memory_manager.remember(key, value, category)

    def recall(self, query):
        return self._memory_manager.recall(query)

    def clear_history(self, user_id="default", channel="default"):
        self._memory_manager.clear_history(user_id, channel)

    def _get_user_history(self, user_context, channel, limit=20):
        return self._memory_manager.get_user_history(user_context, channel, limit)

    def _save_user_history(self, user_context, channel, user_message, assistant_response):
        self._memory_manager.save_user_history(
            user_context, channel, user_message, assistant_response
        )

    # ── StatusReporter delegates ──────────────────────────────────────────
    def get_status(self):
        return self._status_reporter.get_status()

    def get_health_status(self, include_resources=True):
        return self._status_reporter.get_health_status(include_resources)

    def get_metrics_summary(
        self, tool_name=None, include_llm=True, include_tools=True, include_alerts=True
    ):
        return self._status_reporter.get_metrics_summary(
            tool_name, include_llm, include_tools, include_alerts
        )

    def get_bus_status(self):
        return self._status_reporter.get_bus_status()

    def get_mesh_status(self):
        return self._status_reporter.get_mesh_status()

    def get_retriever_status(self):
        return self._status_reporter.get_retriever_status()

    def mark_ready(self):
        self._status_reporter.mark_ready()

    def liveness(self):
        return self._status_reporter.liveness()

    def readiness(self):
        return self._status_reporter.readiness()

    def startup_probe(self):
        return self._status_reporter.startup_probe()

    # ── Error helpers (backward compat) ───────────────────────────────────
    _ERROR_PREFIXES = ToolExecutor._ERROR_PREFIXES
    _ERROR_SUBSTRINGS = ToolExecutor._ERROR_SUBSTRINGS

    def _is_tool_error(self, result):
        return self._tool_executor._is_tool_error(result)

    # ════════════════════════════════════════════════════════════════
    # ORIGINAL METHODS THAT STAY IN agent.py
    # ════════════════════════════════════════════════════════════════

    def run_saga(
        self,
        saga: "Saga",
        context: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> "SagaExecution":
        """
        Execute a saga synchronously from sync tool-handler context.

        SagaOrchestrator.execute() is async. Tool handlers run in the agent's
        sync call path, so a direct ``await`` is not possible. This bridge
        runs the coroutine in a dedicated thread with its own event loop —
        safe regardless of whether an outer loop is running.

        Args:
            saga:    Saga definition (built with SagaBuilder or inline).
            context: Initial context dict passed to every step.
            timeout: Override saga-level timeout (seconds). None = saga default.

        Returns:
            SagaExecution with .status, .current_context, .step_executions, etc.

        Example (inside a tool handler)::

            def process_donor_intake(input_data, tool_context):
                agent = tool_context["agent"]
                saga = (
                    SagaBuilder("donor_intake")
                    .add_step("validate",  validate_donor,   undo_validate)
                    .add_step("crm_add",   add_to_crm,       remove_from_crm)
                    .add_step("welcome",   send_welcome,      None)
                    .add_step("schedule",  schedule_followup, cancel_followup)
                    .build()
                )
                execution = agent.run_saga(saga, context={
                    "donor": input_data,
                    "user_id": tool_context["user_id"],
                })
                if execution.status == SagaStatus.COMPLETED:
                    return json.dumps({"ok": True, "id": execution.execution_id})
                return json.dumps({"error": execution.error, "status": execution.status})
        """
        import asyncio
        import concurrent.futures

        async def _run():
            if timeout is not None:
                # Temporarily override saga timeout for this call
                original = saga.timeout_seconds
                saga.timeout_seconds = timeout
                try:
                    return await self.sagas.execute(saga, context)
                finally:
                    saga.timeout_seconds = original
            return await self.sagas.execute(saga, context)

        # Always run in a new thread with its own loop — avoids "cannot run
        # nested event loop" errors when called from within an existing loop.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            fut = pool.submit(lambda: asyncio.run(_run()))
            eff_timeout = timeout or saga.timeout_seconds + 5  # +5s grace
            try:
                return fut.result(timeout=eff_timeout)
            except concurrent.futures.TimeoutError:
                logger.error(f"run_saga timed out after {eff_timeout}s: {saga.name}")
                # Return a synthetic timeout execution
                exec_ = SagaExecution(saga_name=saga.name)
                exec_.mark_timeout()
                return exec_

    # ── Mesh lifecycle ──────────────────────────────────────────────────────

    async def start_mesh(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> None:
        """
        Start the mesh gateway WebSocket server.

        Must be called from an async context (e.g. inside an asyncio.run() or
        existing event loop). Binds the port and begins accepting connections.

        If mesh was not enabled at __init__ time (FAMILIAR_MESH_ENABLED not set),
        this method will create and start a gateway on demand.

        Args:
            host: Override the host (default: value from env/config)
            port: Override the port (default: value from env/config)

        Example::

            async def main():
                agent = Agent()
                await agent.start_mesh()          # runs forever
                # or run other tasks alongside:
                await asyncio.gather(
                    agent.start_mesh(),
                    my_telegram_bot.run(),
                )
        """
        import asyncio as _asyncio

        _host = host or self._mesh_host
        _port = port or self._mesh_port

        if self.mesh_gateway is None:
            self.mesh_gateway = MeshGateway(self, host=_host, port=_port)
            self.mesh_gateway.set_orchestrator(self.orchestrator)
            hipaa = self.config.agent.hipaa_enabled or os.environ.get(
                "FAMILIAR_HIPAA", ""
            ).lower() in ("1", "true", "yes")

            # Usage tracker
            dross = None
            try:
                from familiar.core.dross import DrossLedger

                dross = DrossLedger()
            except Exception as e:
                logger.warning("Dross ledger unavailable, usage tracking disabled: %s", e)
            self.mesh_gateway.init_usage_tracker(dross_ledger=dross, hipaa_enabled=hipaa)

            if self.memory is not None:
                md_store = None
                try:
                    from familiar.core.markdown_memory import MarkdownMemoryStore, _get_memories_dir

                    _user_id = getattr(self, "user_id", "default")
                    md_store = MarkdownMemoryStore(_get_memories_dir(), _user_id)
                except Exception as e:
                    logger.warning("Markdown memory store unavailable: %s", e)
                self.mesh_gateway.init_memory_bridge(
                    self.memory, hipaa_enabled=hipaa, markdown_store=md_store
                )

            self.mesh_gateway.init_model_bridge(hipaa_enabled=hipaa)

        logger.info(f"Starting mesh gateway on {_host}:{_port}")
        await self.mesh_gateway.start()

        try:
            while True:
                await _asyncio.sleep(1)
        except (KeyboardInterrupt, _asyncio.CancelledError):
            logger.info("Mesh gateway shutting down...")
            await self.mesh_gateway.stop()

    async def stop_mesh(self) -> None:
        """Stop the mesh gateway and disconnect all peers."""
        if self.mesh_gateway and self.mesh_gateway._running:
            await self.mesh_gateway.stop()
            logger.info("Mesh gateway stopped")

    def get_mesh_context(
        self, query: str, timeout: float = defaults.MESH_CONTEXT_TIMEOUT
    ) -> str:
        """
        Query peer memories relevant to the current conversation turn.

        Called from get_system_prompt() when mesh is active and memory
        bridge is wired. Returns a formatted string injected into the
        LLM system prompt so the model sees cross-device context.

        Returns "" if mesh is not active, HIPAA mode is on, or no
        relevant memories are found within the timeout.

        Args:
            query:   The user's current message (used as search query)
            timeout: Max seconds to wait for peer responses (default 1.5)
        """
        if not self.mesh_gateway:
            return ""
        bridge = getattr(self.mesh_gateway, "memory_bridge", None)
        if bridge is None:
            return ""
        try:
            return bridge.get_mesh_context(query, timeout=timeout)
        except Exception as e:
            logger.debug(f"Mesh context fetch failed: {e}")
            return ""

    # ════════════════════════════════════════════════════════════════
    # BACKUP
    # ════════════════════════════════════════════════════════════════

    def _init_backup(self) -> BackupManager:
        """
        Create and configure the BackupManager for this agent.

        Configuration comes from config.backup (if present) with safe defaults:
          - enabled:          False (opt-in — no surprise disk writes)
          - path:             ~/.familiar/backups
          - encrypt:          False (opt-in — requires cryptography package)
          - retention_days:   30
          - include_history:  True
          - include_audit:    True

        The BackupManager is always created (never None) so agent.backup is safe
        to call even when backup is disabled — create_backup() will still work,
        it just won't be triggered automatically.

        Episodic memory directory is threaded through so the manager knows where
        per-user recalled conversation files live.
        """
        backup_cfg_raw = getattr(self.config, "backup", None)
        if backup_cfg_raw is not None and hasattr(backup_cfg_raw, "__dict__"):
            try:
                raw_dict = {k: v for k, v in vars(backup_cfg_raw).items() if not k.startswith("_")}
                # Convert path string -> Path (BackupConfig expects Path)
                raw_path = raw_dict.get("path", "")
                if not raw_path:
                    raw_dict["path"] = Path.home() / ".familiar" / "backups"
                else:
                    raw_dict["path"] = Path(raw_path)
                # Empty encryption_key -> None so Fernet isn't called with ''
                if not raw_dict.get("encryption_key", ""):
                    raw_dict["encryption_key"] = None
                # Empty s3_bucket -> None
                if not raw_dict.get("s3_bucket", ""):
                    raw_dict["s3_bucket"] = None
                # Only pass fields BackupConfig knows about
                valid_fields = set(BackupConfig.__dataclass_fields__)
                bc = BackupConfig(**{k: v for k, v in raw_dict.items() if k in valid_fields})
            except Exception as _bc_err:
                logger.debug(f"BackupConfig from agent config failed ({_bc_err}), using defaults")
                bc = BackupConfig()
        else:
            bc = BackupConfig()

        manager = BackupManager(config=bc)
        # Pass episodic dir so _backup_episodic knows where to look
        manager._episodic_dir = self._episodic_dir

        return manager

    def create_backup(
        self,
        backup_type: BackupType = BackupType.FULL,
        description: Optional[str] = None,
    ) -> "BackupManifest":
        """
        Create a backup of all agent data immediately.

        Captures:
          - memory.json          (semantic facts per user)
          - episodic/*.json(.enc) (per-user conversation history — highest priority)
          - history.json          (global conversation log)
          - users.db              (user database, if present)
          - analytics.db          (analytics, if present)
          - audit.db              (audit log, if present)
          - skills/               (skill data, if present)
          - config.yaml           (configuration, for FULL backup)

        Args:
            backup_type: FULL (default), DATA_ONLY, or CONFIG_ONLY
            description: Optional label stored in manifest

        Returns:
            BackupManifest with status, file list, checksum, and timing.

        Example::

            manifest = agent.create_backup()
            print(f"Backup {manifest.id}: {manifest.file_count} files, "
                  f"{manifest.total_size} bytes")
        """
        manifest = self.backup.create_backup(
            backup_type=backup_type,
            description=description,
        )
        # Register freshness with health checker
        if hasattr(self, "health"):
            self.health._cached_result = None  # bust cache so next check is fresh
        logger.info(
            f"Backup created: {manifest.id} "
            f"({manifest.file_count} files, {manifest.total_size} bytes, "
            f"status={manifest.status.value})"
        )
        return manifest

    def restore_backup(
        self,
        backup_id: str,
        target_dir: Optional[Path] = None,
        dry_run: bool = False,
    ) -> dict:
        """
        Restore agent data from a backup.

        WARNING: Overwrites current data files. Call create_backup() first to
        snapshot current state before restoring an older backup.

        Args:
            backup_id: Backup ID from list_backups() or create_backup().id
            target_dir: Optional directory to restore into. Default: original
                        data paths (~/.familiar/data, ~./familiar/episodic).
            dry_run:    If True, simulate and count files without writing.

        Returns:
            Dict with files_restored count, errors list, dry_run flag.
        """
        result = self.backup.restore(
            backup_id=backup_id,
            target_dir=target_dir,
            dry_run=dry_run,
        )
        if not dry_run:
            logger.warning(
                f"Backup restored: {backup_id} ({result.get('files_restored', 0)} files written)"
            )
        return result

    def list_backups(self) -> list:
        """
        Return all available backup manifests, newest first.

        Each manifest has:
            id, created_at, backup_type, status, file_count,
            total_size, encrypted, compressed, duration_seconds

        Example::

            for b in agent.list_backups():
                print(f"{b.id}  {b.backup_type.value}  "
                      f"{b.file_count} files  {b.status.value}")
        """
        return self.backup.list_backups()

    def verify_backup(self, backup_id: str) -> dict:
        """
        Verify the integrity of a backup archive.

        Checks that the archive exists on disk and the manifest is readable.
        Returns a result dict with ``valid`` bool, file count, size, and
        encryption flag.  On success, also updates the manifest status to
        VERIFIED so the health probe can report freshness correctly.

        Args:
            backup_id: ID from list_backups() or create_backup().id

        Returns:
            Dict with ``valid``, ``backup_id``, ``created_at``, ``size``,
            ``files``, ``encrypted``.  ``valid=False`` includes an ``error``
            key describing the problem.

        Example::

            result = agent.verify_backup("20260220_030000")
            if result["valid"]:
                print(f"OK — {result['files']} files, {result['size']} bytes")
            else:
                print(f"CORRUPT: {result['error']}")
        """
        return self.backup.verify_backup(backup_id)

    def cleanup_old_backups(self) -> int:
        """
        Delete backups older than config.backup.retention_days (default 30).

        Returns the number of backup archives deleted.  Safe to call at any
        time — only removes archives whose manifest ``created_at`` predates
        the retention window.

        Example::

            deleted = agent.cleanup_old_backups()
            print(f"Pruned {deleted} old backups")
        """
        return self.backup.cleanup_old_backups()

    def _schedule_backup(self) -> None:
        """
        Register a recurring backup task with the scheduler.

        Called from __init__ when both backup.enabled and scheduler are active.
        The schedule is driven by config.backup.schedule:
          daily   → runs at 03:00 each night (TaskFrequency.DAILY, time_of_day="03:00")
          hourly  → runs at the top of each hour (TaskFrequency.HOURLY)
          weekly  → runs at 03:00 on Sundays (TaskFrequency.DAILY every 7 days)

        A cleanup task is also registered to prune backups older than
        retention_days.

        Both tasks are silent if the scheduler has already registered tasks
        with the same name (idempotent on re-init).
        """
        if self.scheduler is None:
            return

        schedule = getattr(self.backup.config, "schedule", "daily")

        # Map schedule string to TaskFrequency
        if schedule == "hourly":
            freq = TaskFrequency.HOURLY
            kwargs: dict = {}
        else:
            # daily and weekly both use DAILY with time_of_day; weekly is
            # handled by cleanup running every day but retention_days controls
            # the window (weekly schedule is just daily with longer retention)
            freq = TaskFrequency.DAILY
            kwargs = {"time_of_day": "03:00"}

        _backup_ref = self.backup

        def _run_scheduled_backup():
            try:
                manifest = _backup_ref.create_backup(BackupType.FULL)
                logger.info(
                    f"Scheduled backup completed: {manifest.id} "
                    f"({manifest.file_count} files, {manifest.total_size} bytes)"
                )
                # Prune old backups after each successful backup
                _backup_ref.cleanup_old_backups()
            except Exception as e:
                logger.error(f"Scheduled backup failed: {e}")

        self.scheduler.add_task(
            name="familiar_auto_backup",
            description=f"Automatic {schedule} backup of all agent data",
            frequency=freq,
            callback=_run_scheduled_backup,
            **kwargs,
        )
        logger.info(f"Scheduled {schedule} backup registered (03:00 daily)")

    # ════════════════════════════════════════════════════════════════
    # HEALTH CHECKER
    # ════════════════════════════════════════════════════════════════

    def _init_health_checker(self) -> HealthChecker:
        """
        Create and configure the HealthChecker with agent-aware dependency checks.

        Built-in checks registered here:
          filesystem   — write/read /tmp, always registered by HealthChecker itself
          llm_provider — verifies provider has API key / is reachable
          memory_agent — background extraction thread liveness + last-error
          planner      — no plans stuck > 30 min
          bus          — SkillBus worker thread alive

        The version string is taken from the package __version__ if available,
        falling back to "unknown". Cache TTL is 10 s — cheap for polling probes.
        """
        try:
            from familiar import __version__ as _ver
        except Exception:
            _ver = "unknown"

        hc = HealthChecker(
            version=_ver,
            check_timeout_seconds=defaults.HEALTH_CHECK_TIMEOUT,
            cache_ttl_seconds=defaults.HEALTH_CACHE_TTL,
        )

        # ── LLM provider ─────────────────────────────────────────────────────
        # Checks that the configured provider has an API key set (or is local).
        provider_name = getattr(self.provider, "name", "unknown")

        def _check_provider() -> DependencyHealth:
            # Local providers (ollama, llamacpp) are always reachable when configured.
            local_names = ("ollama", "llamacpp", "local", "mock")
            if any(n in provider_name.lower() for n in local_names):
                return DependencyHealth(
                    name="llm_provider",
                    healthy=True,
                    message=f"Local provider '{provider_name}' configured",
                    dependency_type=DependencyType.LLM_PROVIDER,
                    details={"provider": provider_name, "local": True},
                )
            # Cloud providers need an API key
            key_env = {
                "anthropic": "ANTHROPIC_API_KEY",
                "openai": "OPENAI_API_KEY",
                "gemini": "GOOGLE_API_KEY",
            }.get(provider_name.lower(), "")
            key_set = bool(os.environ.get(key_env)) if key_env else True
            return DependencyHealth(
                name="llm_provider",
                healthy=key_set,
                message=(
                    f"Provider '{provider_name}' ready"
                    if key_set
                    else f"Provider '{provider_name}' missing {key_env}"
                ),
                dependency_type=DependencyType.LLM_PROVIDER,
                details={"provider": provider_name, "key_env": key_env, "key_set": key_set},
            )

        hc.register_dependency_check("llm_provider", _check_provider, DependencyType.LLM_PROVIDER)

        # ── SkillBus ─────────────────────────────────────────────────────────
        _bus = self.bus

        def _check_bus() -> DependencyHealth:
            running = getattr(_bus, "_running", False) or (
                hasattr(_bus, "_worker") and _bus._worker is not None and _bus._worker.is_alive()
            )
            return DependencyHealth(
                name="bus",
                healthy=running,
                message="SkillBus worker running" if running else "SkillBus worker not running",
                dependency_type=DependencyType.INTERNAL,
                details={"running": running},
            )

        hc.register_dependency_check("bus", _check_bus, DependencyType.INTERNAL)

        # ── Memory agent ─────────────────────────────────────────────────────
        if self.memory is not None:
            _mem_agent = getattr(self.memory, "_memory_agent", None) or getattr(
                self.memory, "_agent", None
            )
            if _mem_agent is not None:
                hc.register_dependency_check(
                    "memory_agent",
                    create_memory_agent_health_check(_mem_agent),
                    DependencyType.INTERNAL,
                )

        # ── Planner ──────────────────────────────────────────────────────────
        if self.planner is not None:
            hc.register_dependency_check(
                "planner",
                create_planner_health_check(self.planner),
                DependencyType.INTERNAL,
            )

        # ── Backup freshness ──────────────────────────────────────────────────
        # Healthy: at least one completed backup exists AND the most recent one
        # is within 2× the configured retention period (generous threshold —
        # we just want to surface "never backed up" and "backup very stale").
        # Reports "no backups yet" on a fresh install, which is informational
        # rather than critical: healthy=True so it doesn't break readiness.
        _backup_mgr = self.backup

        def _check_backup_freshness() -> DependencyHealth:
            try:
                backups = _backup_mgr.list_backups()
            except Exception as e:
                return DependencyHealth(
                    name="backup_freshness",
                    healthy=False,
                    message=f"Could not list backups: {e}",
                    dependency_type=DependencyType.INTERNAL,
                )
            if not backups:
                return DependencyHealth(
                    name="backup_freshness",
                    healthy=True,  # informational — fresh install
                    message="No backups yet. Call agent.create_backup() to protect data.",
                    dependency_type=DependencyType.INTERNAL,
                    details={"backup_count": 0},
                )
            latest = backups[0]
            _now_utc = datetime.now(_dt_timezone.utc)
            _created = latest.created_at
            # Ensure both are tz-aware for safe comparison (M8)
            if _created.tzinfo is None:
                _created = _created.replace(tzinfo=_dt_timezone.utc)
            age_days = (_now_utc - _created).total_seconds() / 86400
            retention = getattr(_backup_mgr.config, "retention_days", 30)
            stale_threshold_days = retention * 2
            healthy = age_days <= stale_threshold_days
            return DependencyHealth(
                name="backup_freshness",
                healthy=healthy,
                message=(
                    f"Latest backup: {latest.id} ({age_days:.1f} days ago, "
                    f"status={latest.status.value})"
                ),
                dependency_type=DependencyType.INTERNAL,
                details={
                    "backup_count": len(backups),
                    "latest_id": latest.id,
                    "latest_status": latest.status.value,
                    "age_days": round(age_days, 1),
                    "stale_threshold_days": stale_threshold_days,
                },
            )

        hc.register_dependency_check(
            "backup_freshness", _check_backup_freshness, DependencyType.INTERNAL
        )

        # ── Credential health checks ─────────────────────────────────────
        try:
            from familiar.core.health import register_credential_checks

            n = register_credential_checks(hc)
            if n:
                logger.debug("Registered %d credential health checks", n)
        except Exception as e:
            logger.debug("Credential health registration skipped: %s", e)

        return hc

    def _validate_credentials_on_startup(self):
        """Run credential validation for all configured services (background).

        Non-blocking — spawns a daemon thread that validates every configured
        credential via ensure_credentials().  Results are logged and feed into
        the health system automatically (cached statuses are read by the
        credential dependency checks registered in _init_health_checker).
        """
        try:
            from familiar.core.health import validate_credentials_background

            validate_credentials_background()
        except Exception as e:
            logger.debug("Startup credential validation skipped: %s", e)

    # ════════════════════════════════════════════════════════════════
    # SEMANTIC RETRIEVER (RAG)
    # ════════════════════════════════════════════════════════════════

    def _init_retriever(self) -> SemanticRetriever:
        """
        Create a SemanticRetriever backed by the same embedding provider
        cascade that memory uses.

        The bridge adapter makes embeddings.EmbeddingProvider satisfy
        context.EmbeddingProvider's interface — they share the same abstract
        surface (embed, embed_batch) but have different ABC hierarchies and
        one uses .dimensions vs .dimension.
        """

        class _EmbeddingBridge(ContextEmbeddingProvider):
            """Adapt embeddings.EmbeddingProvider → context.EmbeddingProvider."""

            def __init__(self, provider: RawEmbeddingProvider):
                self._p = provider

            def embed(self, text: str):
                return self._p.embed(text)

            def embed_batch(self, texts):
                return self._p.embed_batch(texts)

            @property
            def dimension(self) -> int:
                # embeddings.py uses .dimensions; context.py uses .dimension
                if hasattr(self._p, "dimensions") and self._p.dimensions:
                    return self._p.dimensions
                if hasattr(self._p, "_dimensions") and self._p._dimensions:
                    return self._p._dimensions
                return 512  # safe default for TF-IDF and unknown providers

        # Reuse memory's already-initialized embedder when available
        # so we don't double-initialize (or double-probe Ollama).
        raw_provider = None
        if self.memory and getattr(self.memory, "_embedder", None):
            raw_provider = self.memory._embedder
        else:
            try:
                prefer_local = (
                    self.config.agent.get("prefer_local_embeddings", False)
                    if hasattr(self.config.agent, "get")
                    else False
                )
                raw_provider = get_embedding_provider(prefer_local=prefer_local)
            except Exception as e:
                logger.warning(
                    f"Retriever could not initialize embedding provider: {e}. Using TF-IDF."
                )
                raw_provider = TFIDFEmbeddings()

        bridge = _EmbeddingBridge(raw_provider)
        config = RetrievalConfig(
            top_k=defaults.RAG_TOP_K,
            min_score=defaults.RAG_MIN_SCORE,
            max_tokens=defaults.RAG_MAX_TOKENS,
            chunk_size=defaults.RAG_CHUNK_SIZE,
            chunk_overlap=defaults.RAG_CHUNK_OVERLAP,
        )
        return SemanticRetriever(
            embedding_provider=bridge,
            vector_store=InMemoryVectorStore(),
            config=config,
        )

    def _retrieve_rag_context(
        self, query: str, max_tokens: int = defaults.RAG_MAX_TOKENS
    ) -> str:
        """
        Query the RAG retriever with the current user message and return a
        formatted string suitable for injection into the LLM system prompt.

        Returns empty string when:
        - No documents have been indexed
        - Query is empty or too short
        - All results score below min_score threshold

        Always safe to call — exceptions are caught and logged.
        """
        if not query or len(query) < 3:
            return ""
        if self.retriever.count == 0:
            return ""
        try:
            ctx = self.retriever.get_context(
                query,
                max_tokens=max_tokens,
                format="numbered",
            )
            if ctx:
                return "<retrieved_knowledge>\n" + ctx + "\n</retrieved_knowledge>"
            return ""
        except Exception as e:
            logger.debug(f"RAG retrieval skipped: {e}")
            return ""

    def _handle_guardrail_violation(self, gv: GuardrailViolation, user_id: str) -> str:
        """
        Convert a GuardrailViolation into a clean user-facing message and
        log it to the audit trail.

        Never raises — always returns a string the agent can return directly.
        Each violation_type gets a specific, actionable message rather than
        leaking internal limit values to the user.
        """
        vtype = gv.violation_type

        user_messages = {
            ViolationType.RATE_LIMIT: (
                "⚠️ You're sending messages too quickly. Please wait a moment before trying again."
            ),
            ViolationType.COST_LIMIT: (
                "⚠️ You've reached your usage limit for this period. "
                "Limits reset hourly and daily — try again later or contact your admin."
            ),
            ViolationType.TOKEN_LIMIT: (
                "⚠️ This conversation has grown very long and hit a processing limit. "
                "Please start a new conversation to continue."
            ),
            ViolationType.ITERATION_LIMIT: (
                "⚠️ I got stuck in a loop trying to complete that request. "
                "Please try rephrasing or breaking it into smaller steps."
            ),
            ViolationType.TIMEOUT: (
                "⚠️ That request took too long to complete. "
                "Please try a simpler request or try again in a moment."
            ),
            ViolationType.CONTENT_SAFETY: (
                "⚠️ I can't process that message — it triggered a content safety check. "
                "Please rephrase your request."
            ),
            ViolationType.TOOL_BLOCKED: (
                "⚠️ That action requires administrator approval and can't be completed automatically. "
                "Please contact your admin."
            ),
        }

        msg = user_messages.get(vtype, f"⚠️ Request blocked: {vtype.value}")

        # Route to existing audit trail (not the duplicate AuditLogger in guardrails.py)
        try:
            from .audit import get_audit_logger as _get_audit

            _get_audit().log_guardrail_violation(
                user_id=str(user_id),
                violation_type=vtype.value,
                detail=str(gv),
            )
        except Exception:
            # audit.py may not have log_guardrail_violation — fall back to session audit
            logger.warning(f"Guardrail violation [{vtype.value}] for user {user_id}: {gv}")

        return msg

    def _validate_compliance(self):
        """Validate and apply compliance configuration."""
        if not COMPLIANCE_AVAILABLE:
            return

        # Get compliance mode from config
        compliance_config = getattr(self.config, "compliance", None)
        if not compliance_config:
            return

        mode_str = getattr(compliance_config, "mode", "none")
        if mode_str == "none":
            return

        try:
            self.compliance_mode = ComplianceMode(mode_str)
        except ValueError:
            logger.warning(f"Unknown compliance mode: {mode_str}")
            return

        # Store the compliance profile for later use (session timeout, etc.)
        try:
            from .compliance import get_compliance_config as _get_cc

            self._compliance_profile = _get_cc(self.compliance_mode)
        except ImportError:
            self._compliance_profile = None

        # Hard-fail: encryption key required for HIPAA/SOC2/PCI-DSS
        encryption_modes = {"hipaa", "soc2", "pci_dss"}
        if mode_str in encryption_modes:
            if not os.environ.get("FAMILIAR_ENCRYPTION_KEY"):
                raise RuntimeError(
                    f"\n{'=' * 60}\n"
                    f"FATAL: Compliance mode '{mode_str}' requires encryption.\n"
                    f"Set FAMILIAR_ENCRYPTION_KEY before starting the agent.\n\n"
                    f"Generate a key with:\n"
                    f'  python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"\n\n'
                    f"Then export it:\n"
                    f"  export FAMILIAR_ENCRYPTION_KEY=<your-key>\n"
                    f"{'=' * 60}"
                )

        # Convert config to dict for validation
        config_dict = {
            "security": {
                "encrypt_sessions": getattr(self.config.security, "encrypt_sessions", False),
                "encrypt_memory": getattr(self.config.security, "encrypt_memory", False),
                "encrypt_history": getattr(self.config.security, "encrypt_history", False),
                "session_timeout_minutes": getattr(
                    self.config.security, "session_timeout_minutes", 60
                ),
            },
            "observability": {
                "audit_logging": getattr(self.config.observability, "tracing_enabled", False),
                "log_retention_days": 90,  # Default
            },
        }

        # Validate compliance requirements
        errors = validate_compliance(config_dict, self.compliance_mode)
        if errors:
            logger.warning(f"Compliance validation warnings for {self.compliance_mode.value}:")
            for error in errors:
                logger.warning(f"  - {error}")
        else:
            logger.info(f"Compliance mode {self.compliance_mode.value} requirements met")

        # Wire encrypted storage to audit subsystem
        encryption_modes = {"hipaa", "soc2", "pci_dss"}
        if mode_str in encryption_modes:
            try:
                from .encryption import EncryptedStorage

                es = EncryptedStorage()
                if es.is_available:
                    self._audit_encrypted_storage = es
            except Exception:
                logger.debug("EncryptedStorage not available for audit logging")

        # Initialize audit store with encryption if available
        from .audit import get_audit_store

        get_audit_store(encrypted_storage=self._audit_encrypted_storage)

        # Instantiate ComplianceAuditLogger
        try:
            from .compliance import ComplianceAuditLogger
            from .config import DATA_DIR

            self._compliance_audit_logger = ComplianceAuditLogger(
                config=self._compliance_profile,
                base_path=DATA_DIR,
                encrypted_storage=self._audit_encrypted_storage,
            )
        except Exception as e:
            logger.warning(f"ComplianceAuditLogger init failed: {e}")

    # _init_provider, _init_model_router, get_routing_config, set_routing_config,
    # switch_provider — moved to ProviderManager (provider_manager.py)
    # get_system_prompt — moved to PromptBuilder (prompt_builder.py)
    # Backward-compat delegates are defined above.

    def chat(
        self,
        message: str,
        user_id: Any = "default",
        channel: str = "default",
        include_history: bool = True,
        user_context: Optional["UserContext"] = None,
    ) -> str:
        """
        Process a message and return a response.

        Args:
            message: The user's message
            user_id: Unique identifier for the user/chat (ignored if user_context provided)
            channel: Which channel this came from (telegram, discord, cli)
            include_history: Whether to include conversation history
            user_context: Phase 1 - UserContext from authenticated channel user

        Returns:
            The agent's response text

        Raises:
            BudgetExceededError: If user's daily budget is exhausted
            ProviderError: If LLM provider fails
        """
        # _setup_request may raise before session/trace are returned.
        # _GuardrailBlock is caught here and returned as a plain string.
        try:
            session, message, user_id, trace, guardrail_tracker = self._setup_request(
                message, user_id, channel, user_context
            )
        except _GuardrailBlock as gb:
            return str(gb)

        gen = self._run_agent_loop(
            message=message,
            user_id=user_id,
            channel=channel,
            include_history=include_history,
            user_context=user_context,
            session=session,
            trace=trace,
            stream=False,
            emit_tool_events=False,
            guardrail_tracker=guardrail_tracker,
        )
        try:
            # stream=False: loop emits no events, returns result via StopIteration.value
            while True:
                next(gen)
        except StopIteration as done:
            return done.value

    def chat_with_results(
        self,
        message: str,
        user_id: Any = "default",
        channel: str = "default",
        include_history: bool = True,
        user_context: Optional["UserContext"] = None,
        job_class_key: Optional[str] = None,
    ) -> AgentResponse:
        """Like chat(), but returns structured AgentResponse with tool results.

        Args:
            message: The user's message
            user_id: Unique identifier for the user/chat
            channel: Which channel this came from
            include_history: Whether to include conversation history
            user_context: UserContext from authenticated channel user
            job_class_key: Optional job class override for this request (used by Round Table)

        Returns:
            AgentResponse with text and structured tool_results
        """
        collected_tool_results: list = []
        try:
            session, message, user_id, trace, guardrail_tracker = self._setup_request(
                message, user_id, channel, user_context
            )
        except _GuardrailBlock as gb:
            return AgentResponse(text=str(gb))

        gen = self._run_agent_loop(
            message=message,
            user_id=user_id,
            channel=channel,
            include_history=include_history,
            user_context=user_context,
            session=session,
            trace=trace,
            stream=False,
            emit_tool_events=False,
            guardrail_tracker=guardrail_tracker,
            collected_tool_results=collected_tool_results,
            job_class_key=job_class_key,
        )
        try:
            while True:
                next(gen)
        except StopIteration as done:
            return AgentResponse(
                text=done.value,
                tool_results=collected_tool_results,
            )
        except Exception as exc:
            logger.error("chat_with_results failed: %s", exc)
            return AgentResponse(
                text=f"I encountered an error processing your request: {exc}",
                tool_results=collected_tool_results,
            )

    def chat_stream(
        self,
        message: str,
        user_id: Any = "default",
        channel: str = "default",
        include_history: bool = True,
        emit_tool_events: bool = True,
        user_context: Optional["UserContext"] = None,
    ) -> Generator[StreamEvent, None, str]:
        """
        Process a message and stream the response.

        Tool calls are executed synchronously (buffered), but the final
        text response is streamed as it's generated.

        Args:
            message: The user's message
            user_id: Unique identifier for the user/chat
            channel: Which channel this came from
            include_history: Whether to include conversation history
            emit_tool_events: If True, emit TOOL_START/TOOL_END events
            user_context: Phase 1 - UserContext from authenticated channel user

        Yields:
            StreamEvent objects with text chunks and status updates

        Returns:
            The complete response text (accessible after iteration)

        Usage:
            final_text = ""
            for event in agent.chat_stream("Hello!"):
                if event.type == StreamEventType.TEXT:
                    print(event.content, end="", flush=True)
                    final_text += event.content
                elif event.type == StreamEventType.TOOL_START:
                    print(f"\\n[Running {event.tool_name}...]")
            print()  # Final newline
        """
        # Sanitize before checking streaming support (mirrors chat() path)
        sanitization_result = sanitize_user_input(
            message, level=SanitizationLevel.BASIC, max_length=50_000
        )
        if sanitization_result.was_modified:
            logger.debug(f"Input sanitized: {sanitization_result.warnings}")
        message = sanitization_result.sanitized

        # If provider doesn't support streaming, fall through to chat()
        # which has the full pipeline — this is the safe fallback path.
        if not self.provider.supports_streaming:
            result = self.chat(
                message, user_id, channel, include_history, user_context=user_context
            )
            yield StreamEvent(type=StreamEventType.TEXT, content=result)
            yield StreamEvent(type=StreamEventType.DONE)
            return result

        # Derive user_id first so _setup_request gets the right value
        if user_context and HAS_USER_MANAGEMENT:
            user_id = user_context.user.id

        try:
            session, message, user_id, trace, guardrail_tracker = self._setup_request(
                message,
                user_id,
                channel,
                user_context,
                already_sanitized=True,  # we sanitized above
            )
        except _GuardrailBlock as gb:
            yield StreamEvent(type=StreamEventType.TEXT, content=str(gb))
            yield StreamEvent(type=StreamEventType.DONE)
            return str(gb)

        yield from self._run_agent_loop(
            message=message,
            user_id=user_id,
            channel=channel,
            include_history=include_history,
            user_context=user_context,
            session=session,
            trace=trace,
            stream=True,
            emit_tool_events=emit_tool_events,
            guardrail_tracker=guardrail_tracker,
        )

    # ============================================================
    # CORE: UNIFIED AGENT LOOP
    # ============================================================

    def _setup_request(
        self,
        message: str,
        user_id: Any,
        channel: str,
        user_context: Optional["UserContext"],
        already_sanitized: bool = False,
    ):
        """
        Shared pre-flight for chat() and chat_stream().

        Handles: sanitization, user_id derivation, session creation,
        role→trust sync, budget check, interaction recording, trace creation.

        Returns: (session, sanitized_message, resolved_user_id, trace)
        """
        # Sanitize (skip if caller already did it, e.g. chat_stream fallback)
        if not already_sanitized:
            sanitization_result = sanitize_user_input(
                message, level=SanitizationLevel.BASIC, max_length=50_000
            )
            if sanitization_result.was_modified:
                logger.debug(f"Input sanitized: {sanitization_result.warnings}")
            message = sanitization_result.sanitized

        # Resolve user_id early — needed for guardrails before session exists
        resolved_uid = str(
            user_context.user.id if (user_context and HAS_USER_MANAGEMENT) else user_id
        )

        # ── Guardrails: rate limit + hourly/daily cost gate ──────────────────
        # Runs before session creation so blocked requests don't consume budget
        # or record an interaction.  Returns a UsageTracker that must be passed
        # to every subsequent guardrail call for this request.
        try:
            guardrail_tracker: Optional[UsageTracker] = self.guardrails.start_request(resolved_uid)
        except GuardrailViolation as gv:
            raise _GuardrailBlock(self._handle_guardrail_violation(gv, resolved_uid)) from gv

        # ── Guardrails: PII — redact before message reaches LLM ─────────────
        # process_with_pii returns (processed_text, findings, blocked).
        # Default PIIAction is REDACT so findings are replaced with <EMAIL> etc.
        # and the cleaned text is used as the message going forward.
        # If operator configured PIIAction.BLOCK this raises GuardrailViolation.
        try:
            message, pii_findings, _blocked = self.guardrails.process_with_pii(message)
            if pii_findings:
                logger.info(
                    f"PII redacted: {[f.entity_type for f in pii_findings]} for user {resolved_uid}"
                )
                session_pii_note = f"pii_redacted:{len(pii_findings)}_entities"
            else:
                session_pii_note = None
        except GuardrailViolation as gv:
            # PIIAction.BLOCK — content contains PII that must not be processed
            self.guardrails.end_request(resolved_uid, guardrail_tracker)
            raise _GuardrailBlock(self._handle_guardrail_violation(gv, resolved_uid)) from gv

        # Resolve user_id from context (use .id, not .email — email is mutable)
        if user_context and HAS_USER_MANAGEMENT:
            user_id = user_context.user.id
            logger.info(f"Chat from {user_context.user.email} ({user_context.user.role.value})")

        # Session setup
        session = self.sessions.get_or_create_session(str(user_id), channel)

        # Session timeout enforcement — invalidate expired sessions in compliance mode
        if self.compliance_mode and self._compliance_profile:
            timeout = self._compliance_profile.session_timeout_minutes
            if session.is_expired(timeout):
                self.sessions.invalidate_session(str(user_id), channel)
                raise SessionExpiredError(
                    f"Session expired (idle >{timeout} min). Please re-authenticate."
                )

        # Sync role → trust level (must happen before capability checks).
        # Always called: handles both the user_context path and the
        # preauth-only path (no user_context but persisted user_role).
        self._sync_user_to_session(user_context, session)

        # Budget gate — check before recording interaction so over-budget
        # users don't gain trust credit for a request that was blocked
        if session.remaining_budget <= 0:
            raise BudgetExceededError(
                "Daily budget exceeded. Try again tomorrow or contact admin.",
                budget_type="daily",
                spent=session.spent_today,
                budget=session.daily_budget,
            )

        # Record interaction after budget gate passes
        session.record_interaction(positive=True)

        # Interaction tracker (constitutional relationship stage)
        try:
            from .constitution import InteractionTracker

            if not hasattr(self, "_interaction_tracker"):
                self._interaction_tracker = InteractionTracker()
            self._interaction_tracker.record_interaction(str(user_id))
        except ImportError as e:
            logger.debug("Optional dependency not available: %s", e)
        # Trace — create root span for the entire request
        trace = None
        if self.tracer:
            trace = self.tracer.create_span(
                "agent.chat",
                kind=SpanKind.SERVER,
                attributes={
                    "user_id": str(user_id),
                    "channel": channel,
                },
            )

        # Record PII redaction in session audit if it happened
        if session_pii_note:
            session.add_audit("pii_redacted", {"note": session_pii_note})

        return session, message, user_id, trace, guardrail_tracker

    def _finalize_response(
        self,
        message: str,
        final_text: str,
        user_id: Any,
        channel: str,
        user_context,
        session,
        trace,
        response,
        start_time: float,
        guardrail_tracker: Optional[UsageTracker] = None,
    ) -> str:
        """
        Shared post-processing after the agent produces its final text.

        Handles: history save, analytics, trace finish, session save,
        memory extraction, progressive milestone check, guardrail cleanup.

        Returns final_text (may be augmented with achievement banner).
        """
        # Save conversation history
        if user_context and HAS_USER_MANAGEMENT:
            self._save_user_history(user_context, channel, message, final_text)
        else:
            self.history.add_message(user_id, "user", message, channel)
            self.history.add_message(user_id, "assistant", final_text, channel)

        # Analytics
        self._record_analytics(
            user_id=str(user_id),
            channel=channel,
            response=response,
            start_time=start_time,
            user_context=user_context,
            trace=trace,
        )

        # Trace — close root span
        if trace:
            trace.set_status(SpanStatus.OK)
            trace.end()

        # Session
        self.sessions.save_session(session)

        # Async memory extraction
        if self.memory_extractor:
            self.memory_extractor.extract_async(message, final_text, channel)

        # Opt-in eval trace capture
        if getattr(self, "_eval_dataset_builder", None) is not None:
            try:
                # Collect tool names from session audit (covers all tools, not just planned)
                _tools = []
                try:
                    for entry in reversed(session.audit_log):
                        if entry.get("event") == "tool_call":
                            _tool = entry.get("details", {}).get("tool_name", "")
                            if _tool:
                                _tools.append(_tool)
                        elif entry.get("event") in ("chat_start", "session_created"):
                            break  # Only look at current request's entries
                except Exception:
                    logger.debug("Failed to extract tools from eval trace", exc_info=True)
                _tools.reverse()  # Restore chronological order
                self._eval_dataset_builder.add_from_trace(
                    user_input=message,
                    agent_response=final_text,
                    tools_called=_tools,
                    success=True,
                )
            except Exception as e:
                logger.debug(f"Eval trace capture skipped: {e}")

        # Guardrails: finalize request tracking.
        self.guardrails.end_request(str(user_id), guardrail_tracker)

        # EpisodicMemory: store this exchange as a conversation memory.
        # Runs after guardrails so we only store completed, non-blocked requests.
        # Stored as CONVERSATION type with both turns linked — the MemorySystem
        # associates adjacent turns so retrieval surfaces full exchanges.
        # Saved async to disk so it doesn't block response finalization.
        _episodic_ms = self._get_episodic_memory(str(user_id))
        if _episodic_ms is not None and final_text:
            try:
                _episodic_ms.store_conversation(
                    messages=[
                        {"role": "user", "content": message},
                        {"role": "assistant", "content": final_text},
                    ],
                    conversation_id=str(session.session_id),
                    importance=0.6,
                )
                self._save_episodic_memory_async(str(user_id))
            except Exception as e:
                logger.debug(f"EpisodicMemory store skipped: {e}")

        # MemoryTree consolidation (primary — Mem0-style fact extraction)
        _tree_ok = False
        try:
            from familiar.core.memory_consolidation_v2 import auto_consolidate_async

            auto_consolidate_async(
                user_message=message,
                assistant_response=final_text,
                user_id=str(user_id),
                conversation_id=str(session.session_id),
            )
            _tree_ok = True
        except Exception as e:
            logger.debug("MemoryTree consolidation skipped: %s", e)

        # Fallback: legacy markdown auto-curation (runs if tree unavailable)
        if not _tree_ok:
            try:
                from familiar.core.markdown_memory import auto_curate_check

                auto_curate_check(
                    user_message=message,
                    assistant_response=final_text,
                    user_id=str(user_id),
                    conversation_id=str(session.session_id),
                )
            except Exception as e:
                logger.debug("Markdown memory auto-curation skipped: %s", e)

        # Progressive capability milestones
        try:
            from familiar.core.progressive import on_interaction_complete

            if hasattr(self, "_interaction_tracker"):
                count = self._interaction_tracker.get_count(str(user_id))
                achievement = on_interaction_complete(str(user_id), count, self.skills)
                if achievement:
                    final_text = f"{final_text}\n\n---\n{achievement}"
        except (ImportError, AttributeError, Exception) as e:
            logger.debug("Optional dependency not available: %s", e)
        return final_text

    def _build_tool_context(
        self, user_id, channel, session, user_context, trace,
    ) -> dict:
        """Build the tool_context dict passed to every tool handler.

        Extracted from _run_agent_loop to keep the loop focused on
        orchestration. All values are request-scoped.
        """
        _request_emitter = EventEmitter(
            execution_id=f"{str(user_id)[:8]}-{str(uuid.uuid4())[:6]}"
        )
        _tool_cb = self._tool_executor.get_callback(str(user_id))
        if _tool_cb is not None:
            _request_emitter.subscribe(_tool_cb)

        def _make_structured_provider(agent_ref):
            def _provider(messages, model=None, **kw):
                return agent_ref.provider.chat(
                    messages=messages,
                    tools=[],
                    system="You are a precise data extraction assistant. Output only valid JSON.",
                    max_tokens=kw.get("max_tokens", 2048),
                )
            return _provider

        _structured_generator = StructuredGenerator(
            llm_provider=_make_structured_provider(self),
            max_retries=defaults.STRUCTURED_MAX_RETRIES,
            extraction_method=ExtractionMethod.FIRST_JSON,
            validation_strategy=ValidationStrategy.RETRY,
            repair_json=True,
        )

        ctx = {
            "memory": self.memory,
            "user_id": user_id,
            "channel": channel,
            "session": session,
            "session_manager": self.sessions,
            "agent": AgentProxy(self),
            "user_context": user_context,
            "emitter": _request_emitter,
            "structured": _structured_generator,
            "sagas": self.sagas,
            "run_saga": self.run_saga,
            "experiments": self.experiments,
            "mesh": self.mesh_gateway,
            "orchestrator": self.orchestrator,
            "_trace_span": trace,
            "bus": self.bus,
            "retriever": self.retriever,
            "health": self.health,
            "metrics": self.metrics,
            "backup": self.backup,
        }
        if user_context and HAS_USER_MANAGEMENT and get_data_store:
            try:
                ctx["data_store"] = get_data_store(
                    user_id=user_context.user.id,
                    user_role=user_context.user.role.value,
                )
            except Exception as e:
                logger.warning(f"Could not get user data store: {e}")
        return ctx

    def _build_system_context(
        self, session, user_context, message, channel,
        routed_skills, job_class_key, tool_schemas, user_id_str, tool_context,
    ) -> tuple:
        """Build (static, dynamic) system prompt with all context injections.

        Returns the tuple passed to provider.chat(system=...).
        """
        _sys_static, _sys_dynamic = self._prompt_builder.build_system_prompt_parts(
            session, user_context,
            current_message=message,
            channel=channel,
            routed_skills=routed_skills,
            job_class_key=job_class_key,
        )
        _sys_dynamic = self._prompt_builder.inject_memory_tree_context(
            _sys_dynamic, user_id_str
        )
        _sys_dynamic = self._prompt_builder.inject_episodic_context(
            _sys_dynamic, message, user_id_str
        )
        _sys_dynamic = self._prompt_builder.inject_rag_context(_sys_dynamic, message)
        _sys_dynamic = self._prompt_builder.inject_markdown_memory_context(
            _sys_dynamic, message, user_id_str
        )
        _sys_dynamic = self._prompt_builder.inject_mesh_context(_sys_dynamic, message)
        _sys_dynamic = self._prompt_builder.inject_planning_context(
            _sys_dynamic, message, tool_schemas
        )
        # C4: move plan tracker from self to tool_context (request-scoped)
        if self._current_plan_tracker is not None:
            tool_context["_plan_tracker"] = self._current_plan_tracker
            self._current_plan_tracker = None
        return (_sys_static, _sys_dynamic)

    def _record_llm_metrics(
        self, provider, response, start_time, exc_str, exc_obj,
        span, tool_schemas, user_id,
    ) -> None:
        """Record LLM call metrics and close observability span.

        Called from the finally block in _run_agent_loop after every LLM call.
        Never raises — all errors are logged and swallowed.
        """
        try:
            _usage = (response.usage if response else {}) or {}
            _pkey = getattr(provider, "provider_key", None)
            _m_provider = _pkey if isinstance(_pkey, str) else provider.name
            _m_model = getattr(provider, "model_name", "")
            _m_tokens_in = _usage.get("input_tokens", 0)
            _m_tokens_out = _usage.get("output_tokens", 0)
            self.metrics.record_llm_call(
                provider=_m_provider,
                model=_m_model,
                duration_ms=(time.time() - start_time) * 1000,
                success=exc_str is None,
                prompt_tokens=_m_tokens_in,
                completion_tokens=_m_tokens_out,
                error_message=exc_str,
                user_id=str(user_id),
                tools_provided=len(tool_schemas) if tool_schemas else 0,
                tool_calls_produced=(
                    len(response.tool_calls)
                    if response and response.tool_calls
                    else 0
                ),
            )
            logger.info(
                "Metrics recorded: %s/%s tokens=%d+%d success=%s",
                _m_provider, _m_model, _m_tokens_in, _m_tokens_out,
                exc_str is None,
            )
        except Exception as _m_err:
            logger.warning("Metrics record_llm_call skipped: %s", _m_err)
        # Close LLM span
        if span:
            try:
                _usage = (response.usage if response else {}) or {}
                span.record_tokens(
                    _usage.get("input_tokens", 0),
                    _usage.get("output_tokens", 0),
                )
                if exc_obj:
                    span.record_exception(exc_obj)
                else:
                    span.set_status(SpanStatus.OK)
                span.end()
            except Exception as _span_err:
                logger.debug("LLM span finalization failed: %s", _span_err)

    def _run_agent_loop(
        self,
        message: str,
        user_id: Any,
        channel: str,
        include_history: bool,
        user_context,
        session,
        trace,
        stream: bool,
        emit_tool_events: bool,
        guardrail_tracker: Optional[UsageTracker] = None,
        collected_tool_results: Optional[list] = None,
        job_class_key: Optional[str] = None,
    ):
        """
        Unified agent loop used by both chat() and chat_stream().

        In non-stream mode (stream=False): returns final response str.
        In stream mode (stream=True): is a generator that yields StreamEvents
        and returns the final text string via StopIteration.value / return.

        All security, capability filtering, planning, routing, PHI guard,
        self-correction, history, analytics, and memory extraction run
        through this single path regardless of streaming mode.

        guardrail_tracker: UsageTracker returned by guardrails.start_request()
            in _setup_request.  Passed explicitly (not stored on self) so
            concurrent requests don't share state.
        collected_tool_results: Optional request-scoped list for collecting
            structured ToolResult objects.  Passed explicitly (not stored on
            self) so concurrent requests don't share state.
        """
        try:
            fallback_notice = None  # Set if provider fallback occurs
            self._current_plan_tracker = None  # Reset per-request plan tracker (C4: also in tool_context)

            # ── History ──────────────────────────────────────────
            if include_history:
                if user_context and HAS_USER_MANAGEMENT:
                    history = self._get_user_history(user_context, channel)
                else:
                    history = self.history.get_history(user_id, channel)
            else:
                history = []

            history.append({"role": "user", "content": message})

            # ── Tool context + system prompt ───────────────────
            tool_context = self._build_tool_context(
                user_id, channel, session, user_context, trace,
            )
            tool_schemas, routed_skills = self._get_allowed_tools(session, message=message)
            system = self._build_system_context(
                session, user_context, message, channel, routed_skills,
                job_class_key, tool_schemas, str(user_id), tool_context,
            )

            # ── Provider selection + PHI guard ────────────────────
            try:
                active_provider, model_name = self._select_provider(message, session)
            except RuntimeError as phi_err:
                if "PHI_NO_LOCAL_FALLBACK" in str(phi_err):
                    session.add_audit("phi_blocked", {"reason": "PHI detected, no local fallback"})
                    self.sessions.save_session(session)
                    phi_msg = (
                        "⚠️ This message appears to contain protected health "
                        "information (PHI) and cannot be sent to a cloud provider "
                        "under current compliance settings. Please configure a "
                        "local Ollama model or rephrase your request."
                    )
                    if stream:
                        yield StreamEvent(type=StreamEventType.TEXT, content=phi_msg)
                        yield StreamEvent(type=StreamEventType.DONE)
                        return phi_msg
                    return phi_msg
                raise

            # ── Loop setup ────────────────────────────────────────
            security_config = SecurityConfig.from_mode(self.security_mode)
            max_iterations = min(15, security_config.max_iterations)
            start_time = time.time()

            from .self_correction import ToolRetryTracker

            retry_tracker = ToolRetryTracker()
            _empty_tool_retry_done = False

            # ── Agent loop ────────────────────────────────────────
            for i in range(max_iterations):
                # ── Guardrails: iteration cap + timeout ───────────
                # Explicit tracker passed — thread-safe, no shared state.
                try:
                    self.guardrails.check_iteration(i, guardrail_tracker)
                except GuardrailViolation as gv:
                    guard_msg = self._handle_guardrail_violation(gv, user_id)
                    if stream:
                        yield StreamEvent(type=StreamEventType.TEXT, content=guard_msg)
                        yield StreamEvent(type=StreamEventType.DONE)
                        return guard_msg
                    return guard_msg

                # ── Proactive rate limit skip ─────────────────────
                provider_key = active_provider.provider_key
                if self.capacity_tracker.is_rate_limited(provider_key):
                    original_name = active_provider.name
                    fallback = self._provider_fallback(
                        active_provider, RuntimeError("proactive_skip")
                    )
                    if fallback:
                        active_provider = fallback
                        fallback_notice = f"[{original_name} rate limited — using {fallback.name}]"
                        session.add_audit(
                            "proactive_fallback",
                            {"from": original_name, "to": fallback.name},
                        )
                        logger.info(f"Proactive fallback: {original_name} → {fallback.name}")

                # ── LLM call ──────────────────────────────────────
                response = None
                _tool_choice: Optional[str] = None
                _llm_start = time.time()
                _llm_exc: Optional[str] = None
                _llm_exc_obj: Optional[Exception] = None
                _llm_span = None
                if self.tracer and trace:
                    _llm_span = self.tracer.create_llm_span(
                        name=f"llm.{getattr(active_provider, 'provider_key', 'unknown')}",
                        model=getattr(active_provider, "model_name", ""),
                        provider=getattr(active_provider, "provider_key", ""),
                        parent=trace,
                    )
                try:
                    if stream:
                        # Consume the stream, collecting text and the response object.
                        # Providers signal tool_calls via the returned LLMResponse,
                        # which is only accessible via StopIteration.value after the
                        # generator is exhausted (generator.value is not a valid attr).
                        _stream_timeout = int(
                            os.environ.get("FAMILIAR_STREAM_TIMEOUT", "120")
                        )
                        stream_gen = active_provider.chat_stream(
                            messages=history,
                            tools=tool_schemas,
                            system=system,
                            max_tokens=self.config.llm.max_tokens,
                            tool_choice=_tool_choice,
                            trace=trace,
                        )
                        collected_text = ""
                        response = None
                        _last_chunk_time = time.time()
                        try:
                            while True:
                                # Check inter-chunk timeout
                                if time.time() - _last_chunk_time > _stream_timeout:
                                    logger.warning(
                                        "Stream timeout after %ds with no new chunks "
                                        "(%d chars collected so far)",
                                        _stream_timeout, len(collected_text),
                                    )
                                    raise TimeoutError(
                                        f"LLM stream stalled for {_stream_timeout}s"
                                    )
                                event = next(stream_gen)
                                _last_chunk_time = time.time()
                                if event.type == StreamEventType.TEXT:
                                    collected_text += event.content
                                elif event.type == StreamEventType.ERROR:
                                    raise Exception(event.error)
                        except StopIteration as si:
                            response = si.value  # LLMResponse from generator return
                        if response is None:
                            # Provider didn't return an LLMResponse via StopIteration.
                            # Reconstruct from collected text (no tool calls possible).
                            logger.debug(
                                "Stream provider returned no LLMResponse; reconstructing from text"
                            )
                            response = LLMResponse(
                                text=collected_text or None,
                                tool_calls=[],
                                stop_reason="end_turn",
                            )
                    else:
                        response = active_provider.chat(
                            messages=history,
                            tools=tool_schemas,
                            system=system,
                            max_tokens=self.config.llm.max_tokens,
                            tool_choice=_tool_choice,
                            trace=trace,
                            retry_config=self.retry_config,
                        )

                except Exception as e:
                    _llm_exc = str(e)
                    _llm_exc_obj = e
                finally:
                    self._record_llm_metrics(
                        active_provider, response, _llm_start, _llm_exc,
                        _llm_exc_obj, _llm_span, tool_schemas, user_id,
                    )

                if _llm_exc_obj is not None:
                    logger.error(f"LLM call failed: {_llm_exc}")
                    session.add_audit("llm_error", {"error": _llm_exc})

                    original_name = active_provider.name
                    fallback = self._provider_fallback(active_provider, _llm_exc_obj)
                    if fallback:
                        try:
                            session.add_audit(
                                "provider_fallback",
                                {
                                    "from": _llm_exc[:100],
                                    "to": fallback.name,
                                },
                            )
                            active_provider = fallback
                            fallback_notice = (
                                f"[{original_name} unavailable — using {fallback.name}]"
                            )
                            # Always use non-streaming chat() for fallback: avoids
                            # partial-stream recovery complexity, simplifies tool-call
                            # handling, and gives a clean single-response for error paths.
                            response = active_provider.chat(
                                messages=history,
                                tools=tool_schemas,
                                system=system,
                                max_tokens=self.config.llm.max_tokens,
                                trace=trace,
                                retry_config=self.retry_config,
                            )
                        except Exception as e2:
                            logger.error(f"Fallback provider also failed: {e2}")
                            _e1_type = type(_llm_exc_obj).__name__
                            _e2_type = type(e2).__name__
                            error_msg = (
                                f"Both AI providers failed — "
                                f"{original_name} ({_e1_type}) and "
                                f"{fallback.name} ({_e2_type}). "
                                "Check your API keys, network connection, "
                                "or run `ollama serve` for local models."
                            )
                            if trace:
                                trace.end()
                            self.sessions.save_session(session)
                            if stream:
                                yield StreamEvent(type=StreamEventType.ERROR, error=error_msg)
                                return error_msg
                            return error_msg
                    else:
                        logger.error(f"Provider error: {_llm_exc}")
                        _e_type = type(_llm_exc_obj).__name__
                        from .exceptions import ProviderBillingError

                        if isinstance(_llm_exc_obj, ProviderBillingError):
                            billing_url = getattr(_llm_exc_obj, "billing_url", None)
                            url_hint = f" Top up at: {billing_url}" if billing_url else ""
                            error_msg = (
                                f"{active_provider.name} has insufficient credits.{url_hint} "
                                "You can also set up a local Ollama model as a free backup "
                                "with `ollama serve`."
                            )
                        else:
                            error_msg = (
                                f"{active_provider.name} is unavailable ({_e_type}: {_llm_exc}). "
                                "Check your API key and network connection. "
                                "You can set up a local Ollama model as backup with `ollama serve`."
                            )
                        if trace:
                            trace.end()
                        self.sessions.save_session(session)
                        if stream:
                            yield StreamEvent(type=StreamEventType.ERROR, error=error_msg)
                            return error_msg
                        return error_msg

                # ── Budget: charge actual token cost after LLM call ──────
                # Done here (after the call) so we use real token counts
                # rather than a flat estimate. Falls back to a conservative
                # per-iteration floor for providers that don't report usage
                # (e.g. Ollama) so the session budget still enforces limits.
                if response is not None:
                    actual_cost = 0.0
                    in_tokens = 0
                    out_tokens = 0
                    if response.usage:
                        in_tokens = response.usage.get("input_tokens", 0)
                        out_tokens = response.usage.get("output_tokens", 0)
                        actual_cost = calculate_cost(
                            active_provider.model_name,
                            in_tokens,
                            out_tokens,
                        )
                    if actual_cost == 0.0:
                        # Provider returned no usage (Ollama) or unknown model:
                        # charge a conservative floor so budgets still bind.
                        actual_cost = 0.005
                    if not session.charge(actual_cost):
                        self.sessions.save_session(session)
                        budget_msg = "⚠️ Budget limit reached for this request."
                        if stream:
                            yield StreamEvent(type=StreamEventType.TEXT, content=budget_msg)
                            yield StreamEvent(type=StreamEventType.DONE)
                            return budget_msg
                        return budget_msg

                    # Guardrails: track token + cost accumulation for this request.
                    # Raises GuardrailViolation if per-request token/cost cap hit.
                    # Uses same numbers as session.charge() — no second calculation.
                    try:
                        self.guardrails.track_llm_usage(
                            in_tokens, out_tokens, actual_cost, guardrail_tracker
                        )
                    except GuardrailViolation as gv:
                        guard_msg = self._handle_guardrail_violation(gv, user_id)
                        if stream:
                            yield StreamEvent(type=StreamEventType.TEXT, content=guard_msg)
                            yield StreamEvent(type=StreamEventType.DONE)
                            return guard_msg
                        return guard_msg

                # ── Empty tool-call guard ────────────────────────
                # Safety net for providers (e.g. Gemini via OpenAI shim) that
                # ignore tool_choice and return a stub text instead of calling
                # tools. Only triggers when the response looks like an LLM stub
                # (very short, no punctuation suggesting a real answer) and we
                # explicitly requested tool use via tool_choice.
                if (
                    _tool_choice in ("any", "required")
                    and tool_schemas
                    and response is not None
                    and not response.tool_calls
                    and (response.text or "").strip()
                    and len((response.text or "").strip()) < 100
                    and not _empty_tool_retry_done
                ):
                    _empty_tool_retry_done = True
                    _text_len = len((response.text or "").strip())
                    logger.warning(
                        f"LLM returned short text ({_text_len} chars) with no tool "
                        f"calls despite {len(tool_schemas)} tools available. "
                        "Retrying with tool_choice='any'."
                    )
                    try:
                        self.metrics.record_empty_tool_retry(
                            provider=getattr(
                                active_provider, "provider_key", active_provider.name
                            ),
                            model=getattr(active_provider, "model_name", ""),
                        )
                    except Exception as _m_err:
                        logger.debug("Empty tool retry metric skipped: %s", _m_err)
                    session.add_audit("empty_tool_retry", {
                        "text_len": _text_len,
                        "tools_provided": len(tool_schemas),
                    })
                    try:
                        response = active_provider.chat(
                            messages=history,
                            tools=tool_schemas,
                            system=system,
                            max_tokens=self.config.llm.max_tokens,
                            tool_choice="any",
                            trace=trace,
                            retry_config=self.retry_config,
                        )
                    except Exception as e:
                        logger.warning(f"Empty tool-call retry failed: {e}")
                        # Fall through with original response

                # ── Tool calls ────────────────────────────────────
                if response.tool_calls:
                    history.append({"role": "assistant", "content": response})

                    tool_results, tool_events = self._execute_tools(
                        tool_calls=response.tool_calls,
                        session=session,
                        tool_context=tool_context,
                        retry_tracker=retry_tracker,
                        trace=trace,
                        stream=stream,
                        emit_tool_events=emit_tool_events,
                    )

                    # Update plan tracker with tool results (C4: request-scoped)
                    _tracker = tool_context.get("_plan_tracker")
                    if _tracker:
                        for tr in tool_results:
                            if isinstance(tr, dict) and tr.get("tool_name"):
                                _is_success = not (
                                    isinstance(tr.get("content", ""), str)
                                    and tr["content"].startswith("Error")
                                )
                                _tracker.record_tool_call(tr["tool_name"], _is_success)

                    # Yield tool events in stream mode
                    if stream:
                        for ev in tool_events:
                            yield ev

                    # Collect structured tool results for chat_with_results()
                    if collected_tool_results is not None:
                        from .agent_response import ToolResult as _ToolResult

                        for tr in tool_results:
                            if tr.get("tool_name"):
                                collected_tool_results.append(
                                    _ToolResult(
                                        tool_name=tr["tool_name"],
                                        tool_input=tr.get("tool_input", {}),
                                        output=str(tr.get("content", "")),
                                        tool_use_id=tr.get("tool_use_id", ""),
                                    )
                                )

                    # Confirmation pending — return sentinel directly,
                    # skip adding to history (no LLM needed for UI routing)
                    if (
                        tool_results
                        and isinstance(tool_results[0], dict)
                        and tool_results[0].get("type")
                        in ("confirmation_pending", "email_menu_pending", "calendar_menu_pending")
                    ):
                        sentinel = tool_results[0]["sentinel"]
                        if stream:
                            yield StreamEvent(type=StreamEventType.DONE)
                            return sentinel
                        return sentinel

                    # Append plan progress to the last tool result so the LLM
                    # sees updated status. Embedded inside a tool_result content
                    # string so all providers (Anthropic, OpenAI, Ollama) include it.
                    _tracker = tool_context.get("_plan_tracker")
                    if _tracker and not _tracker.is_complete and tool_results:
                        _progress = _tracker.get_progress_prompt()
                        _last_tr = tool_results[-1]
                        if isinstance(_last_tr, dict) and "content" in _last_tr:
                            _last_tr["content"] = str(_last_tr["content"]) + "\n\n" + _progress

                    history.append({"role": "user", "content": tool_results})
                    continue

                # ── Final response ────────────────────────────────
                else:
                    final_text = response.text or "(no response)"

                    final_text = self._finalize_response(
                        message=message,
                        final_text=final_text,
                        user_id=user_id,
                        channel=channel,
                        user_context=user_context,
                        session=session,
                        trace=trace,
                        response=response,
                        start_time=start_time,
                        guardrail_tracker=guardrail_tracker,
                    )

                    if fallback_notice:
                        final_text = f"{fallback_notice}\n\n{final_text}"

                    if stream:
                        # Final TEXT event is intentional: delivers _finalize_response
                        # content (memory saves, session updates) to the stream consumer.
                        yield StreamEvent(type=StreamEventType.TEXT, content=final_text)
                        yield StreamEvent(type=StreamEventType.DONE, usage=response.usage)
                        return final_text
                    return final_text

            # ── Max iterations ────────────────────────────────────
            if trace:
                trace.end()
            self.sessions.save_session(session)
            timeout_msg = "(max iterations reached - task may be too complex)"
            if stream:
                yield StreamEvent(type=StreamEventType.TEXT, content=timeout_msg)
                yield StreamEvent(type=StreamEventType.DONE)
                return timeout_msg
            return timeout_msg

        except Exception as e:
            # Inner error paths (provider fail, budget) already save session and
            # finish trace before returning. This catches anything unexpected that
            # bypasses those paths (e.g. an exception in history loading, planning,
            # or _execute_tools itself).
            if trace:
                try:
                    trace.end()
                except Exception:
                    logger.warning("Failed to finalize trace during error recovery", exc_info=True)
            # H5: finalize guardrail tracking on error path
            try:
                self.guardrails.end_request(str(user_id), guardrail_tracker)
            except Exception:
                logger.debug("Failed to end guardrail request during error recovery")
            self.sessions.save_session(session)
            if stream:
                yield StreamEvent(type=StreamEventType.ERROR, error=str(e))
            raise

    # PHASE 1: MULTI-USER HELPERS
    # ============================================================

    def _sync_user_to_session(self, user_context: "UserContext", session: SecureSession):
        """
        Sync UserContext role to SecureSession trust level.

        This bridges the new multi-user system with the existing
        progressive trust security model.

        Role → Trust mapping:
            ADMIN → OWNER (full access)
            STAFF → TRUSTED (most capabilities)
            READONLY → KNOWN (read-only capabilities)
        """
        if not HAS_USER_MANAGEMENT or not user_context:
            # Check if this user is the configured owner (OWNER_TELEGRAM_ID or equivalent).
            # The Telegram channel does this in _get_session(), but agent.chat() is called
            # directly by tests and non-Telegram callers, so we replicate the check here.
            owner_id = getattr(self.config.channels, "owner_telegram_id", None)
            if owner_id and str(session.user_id) == str(owner_id):
                if session.trust_level != TrustLevel.OWNER:
                    session.set_trust_level(TrustLevel.OWNER)
                    logger.info(
                        f"Auto-promoted owner {session.user_id} to OWNER trust (agent sync)"
                    )
                return

            # Fallback: restore trust from previously persisted role on session.
            # This keeps staff from reverting to STRANGER if users.py fails to
            # import at bot restart (e.g. sqlite3 lock, missing dep).
            if session.user_role:
                _role_to_trust = {
                    "admin": TrustLevel.OWNER,
                    "staff": TrustLevel.TRUSTED,
                    "readonly": TrustLevel.KNOWN,
                }
                restored = _role_to_trust.get(session.user_role)
                if restored and session.trust_level == TrustLevel.STRANGER:
                    session.trust_level = restored
                    logger.warning(
                        f"user_management unavailable; restored trust={restored.value} "
                        f"from persisted role={session.user_role} for user={session.user_id}"
                    )
            return

        role = user_context.user.role

        # Map role to trust level and merge capabilities into _explicit_grants.
        # Use |= (union) so manually granted capabilities are preserved.
        if role == UserRole.ADMIN:
            session.trust_level = TrustLevel.OWNER
            session._explicit_grants |= {c.value for c in Capability}
        elif role == UserRole.STAFF:
            session.trust_level = TrustLevel.TRUSTED
            session._explicit_grants |= {
                c.value
                for c in {
                    Capability.READ_TIME,
                    Capability.READ_WEATHER,
                    Capability.READ_MEMORY,
                    Capability.WRITE_MEMORY,
                    Capability.READ_CALENDAR,
                    Capability.WRITE_CALENDAR,
                    Capability.READ_TASKS,
                    Capability.WRITE_TASKS,
                    Capability.SEND_NOTIFICATIONS,
                    Capability.HTTP_REQUESTS,
                }
            }
        else:  # READONLY
            session.trust_level = TrustLevel.KNOWN
            session._explicit_grants |= {
                c.value
                for c in {
                    Capability.READ_TIME,
                    Capability.READ_WEATHER,
                    Capability.READ_MEMORY,
                    Capability.READ_CALENDAR,
                    Capability.READ_TASKS,
                }
            }

        logger.debug(
            f"Synced {user_context.user.email} role {role.value} to trust {session.trust_level.value}"
        )
        # Persist role to session so trust survives bot restarts even if
        # core/users.py is temporarily unavailable at session load time.
        session.user_role = role.value

    # ============================================================
    # PHASE 2: ANALYTICS HELPERS
    # ============================================================

    def _record_analytics(
        self,
        user_id: str,
        channel: str,
        response: "LLMResponse",
        start_time: float,
        user_context: Optional["UserContext"] = None,
        skill: str = None,
        trace=None,
    ):
        """
        Record usage analytics for this request.

        Called after successful chat completion.
        """
        try:
            from .analytics import record_agent_usage

            # Calculate latency
            latency_ms = int((time.time() - start_time) * 1000)

            # Get token counts from response.usage dict (if available)
            usage = getattr(response, "usage", None) or {}
            tokens_in = usage.get("input_tokens", 0) or 0
            tokens_out = usage.get("output_tokens", 0) or 0

            # Estimate if not provided
            if tokens_in == 0 and tokens_out == 0 and response.text:
                tokens_out = len(response.text) // 4  # Rough estimate

            # Get user email if available
            user_email = None
            if user_context and HAS_USER_MANAGEMENT:
                user_email = user_context.user.email

            _req_id = None
            if trace and hasattr(trace, "context"):
                _req_id = trace.context.span_id

            record_agent_usage(
                user_id=user_id,
                channel=channel,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                latency_ms=latency_ms,
                model=self.provider.name if self.provider else None,
                skill=skill,
                user_email=user_email,
                success=True,
                request_id=_req_id,
            )
        except ImportError:
            # Analytics not available
            pass
        except Exception as e:
            logger.warning(f"Could not record analytics: {e}")

    # ============================================================
    # END PHASE 2 HELPERS
    # ============================================================

    def add_reminder(
        self,
        name: str,
        message: str,
        when: datetime,
        channel: Optional[str] = None,
        chat_id: Optional[str] = None,
        callback: Optional[Any] = None,
    ) -> str:
        """Add a one-time reminder."""
        if not self.scheduler:
            return "Scheduler not enabled"

        minutes_until = (when - datetime.now(_dt_timezone.utc)).total_seconds() / 60

        def reminder_callback(task):
            if callback:
                callback(message, channel, chat_id)

        task_id = self.scheduler.add_task(
            name=name,
            description=message,
            frequency=TaskFrequency.ONCE,
            callback=reminder_callback,
            channel=channel,
            chat_id=chat_id,
            interval_minutes=int(minutes_until),
            payload={"message": message},
        )

        return task_id

    def start_scheduler(self):
        """Start the background scheduler and register default proactive tasks."""
        if self.scheduler:
            self._register_default_tasks()
            self.scheduler.start()

    def _register_default_tasks(self):
        """Register built-in proactive tasks if not already present."""
        if not self.scheduler:
            return

        from .scheduler import TaskFrequency, TaskType

        # Check what's already registered (by name, not ID)
        existing_names = {t.name for t in self.scheduler.tasks.values()}

        defaults = [
            {
                "name": "morning_briefing",
                "description": "Daily morning briefing with calendar, tasks, and weather",
                "frequency": TaskFrequency.DAILY,
                "task_type": TaskType.BRIEFING,
                "time_of_day": "08:00",
                "payload": {
                    "prompt": (
                        "Give me my morning briefing. Include: "
                        "today's calendar events, pending tasks and deadlines, "
                        "weather if available, and any unread messages or notifications."
                    )
                },
            },
            {
                "name": "heartbeat",
                "description": "System health check every 4 hours",
                "frequency": TaskFrequency.HOURLY,
                "task_type": TaskType.HEARTBEAT,
                "interval_minutes": 240,
            },
            {
                "name": "eod_summary",
                "description": "End-of-day summary of completed work",
                "frequency": TaskFrequency.DAILY,
                "task_type": TaskType.BRIEFING,
                "time_of_day": "18:00",
                "payload": {
                    "prompt": (
                        "Give me an end-of-day summary. Include: "
                        "what was accomplished today, tasks completed, "
                        "upcoming deadlines, and anything that needs attention tomorrow."
                    )
                },
            },
            {
                "name": "memory_consolidation",
                "description": "Consolidate weak episodic memories with LLM summarization",
                "frequency": TaskFrequency.DAILY,
                "task_type": TaskType.CLEANUP,
                "time_of_day": "03:00",
            },
        ]

        registered = 0
        for task_def in defaults:
            if task_def["name"] not in existing_names:
                try:
                    self.scheduler.add_task(**task_def)
                    registered += 1
                except Exception as e:
                    logger.debug(f"Could not register {task_def['name']}: {e}")

        if registered:
            logger.info(f"Registered {registered} default proactive task(s)")

    def stop_scheduler(self):
        """Stop the scheduler."""
        if self.scheduler:
            self.scheduler.stop()

    def get_session(self, user_id: str, channel: str) -> SecureSession:
        """Get the secure session for a user."""
        return self.sessions.get_or_create_session(user_id, channel)

    def set_user_trust(self, user_id: str, channel: str, level: TrustLevel):
        """Manually set a user's trust level (admin action)."""
        session = self.sessions.get_or_create_session(user_id, channel)
        session.set_trust_level(level)
        self.sessions.save_session(session)

    def grant_capability(self, user_id: str, channel: str, cap: Capability):
        """Grant a specific capability to a user."""
        session = self.sessions.get_or_create_session(user_id, channel)
        session.grant_capability(cap)
        self.sessions.save_session(session)

    def deny_capability(self, user_id: str, channel: str, cap: Capability):
        """Deny a specific capability from a user."""
        session = self.sessions.get_or_create_session(user_id, channel)
        session.deny_capability(cap)
        self.sessions.save_session(session)


class AgentProxy:
    """Proxy exposed to tool handlers via tool_context['agent'].

    Exposes sessions, memory, tools, skills, metrics, guardrails, config,
    and provider as properties. These are intentionally mutable so tool
    handlers can interact with agent state (e.g. save sessions, record
    metrics). The proxy blocks admin escalation methods (set_user_trust,
    grant_capability, deny_capability) and internal managers by using
    __slots__ to restrict attribute access.
    """

    __slots__ = ("_agent",)

    def __init__(self, agent: "Agent"):
        self._agent = agent

    # ── Allowed read-only attributes ──

    @property
    def sessions(self):
        return self._agent.sessions

    @property
    def memory(self):
        return self._agent.memory

    @property
    def tools(self):
        return self._agent.tools

    @property
    def metrics(self):
        return self._agent.metrics

    @property
    def skills(self):
        return self._agent.skills

    @property
    def guardrails(self):
        return self._agent.guardrails

    @property
    def config(self):
        return self._agent.config

    @property
    def provider(self):
        return self._agent.provider

    @property
    def name(self):
        agent_cfg = getattr(self._agent.config, "agent", None)
        return agent_cfg.name if agent_cfg else None

    def __repr__(self):
        name = self.name or "unknown"
        return f"<AgentProxy for {name!r}>"


# Convenience function
def create_agent(config: Optional[Config] = None) -> Agent:
    """Create and return a configured agent."""
    return Agent(config)
