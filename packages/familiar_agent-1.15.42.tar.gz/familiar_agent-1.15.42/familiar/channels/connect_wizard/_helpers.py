# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Constants and module-level helper functions for the connect wizard."""

from __future__ import annotations

import logging
from pathlib import Path

try:
    import fcntl
except ImportError:
    fcntl = None  # type: ignore[assignment]  # Windows / Android

import yaml

from ..formatting import FormatMode, fmt_bold, fmt_code, fmt_link

logger = logging.getLogger(__name__)

# ── Tab / Card UI constants ───────────────────────────────────────────

TAB_ORDER = ("llm", "integrations", "apis", "social", "selfhosted", "security")

TAB_CATEGORIES: dict[str, dict] = {
    "llm": {
        "label": "LLM",
        "icon": "\u2601\ufe0f",
        "services": ["anthropic", "openai", "gemini", "ollama"],
    },
    "integrations": {
        "label": "Integrations",
        "icon": "\U0001f517",
        "services": [
            "google",
            "calendar",
            "email",
            "sms",
            "browser",
            "voice",
            "websearch",
            "healthcare",
            "github",
            "slack",
        ],
    },
    "apis": {
        "label": "API Services",
        "icon": "\U0001f310",
        "services": [
            "hubspot",
            "todoist",
            "stripe",
            "square",
            "mailerlite",
            "shippo",
            "calcom",
            "brave_search",
            "spoonacular",
            "reddit",
            "etsy",
            "clockify",
            "quickbooks",
            "google_trends",
            "news",
            "cloudinary_img",
            "civicrm",
            "globalgiving",
            "jitsi",
            "kobo",
            "open_referral",
        ],
    },
    "social": {
        "label": "Social",
        "icon": "\U0001f310",
        "services": ["mastodon", "bluesky", "instagram"],
    },
    "selfhosted": {
        "label": "Self-Hosted",
        "icon": "\U0001f3e0",
        "services": [
            "jellyfin",
            "gitea",
            "homeassistant",
            "joplin",
            "pihole",
            "nextcloud",
            "proton",
            "email_server",
            "mealie",
        ],
    },
    "security": {
        "label": "Security",
        "icon": "\U0001f512",
        "services": [
            "vaultwarden",
            "encryption",
            "phi_detection",
            "rbac",
            "user_management",
        ],
    },
}

SERVICE_DISPLAY: dict[str, str] = {
    "anthropic": "Anthropic (Claude)",
    "openai": "OpenAI (GPT)",
    "gemini": "Gemini (Google AI)",
    "ollama": "Ollama (local, free)",
    "google": "Google Workspace",
    "calendar": "Calendar (Google/CalDAV)",
    "email": "Email (IMAP/SMTP)",
    "sms": "SMS (Twilio)",
    "browser": "Browser (Playwright)",
    "voice": "Voice (Whisper)",
    "websearch": "WebSearch (DuckDuckGo)",
    "healthcare": "Healthcare / Compliance",
    "jellyfin": "Jellyfin (media)",
    "gitea": "Forgejo / Gitea (code)",
    "homeassistant": "Home Assistant",
    "joplin": "Joplin (notes)",
    "pihole": "Pi-hole / AdGuard",
    "nextcloud": "Nextcloud",
    "proton": "Proton (Bridge & VPN)",
    "email_server": "Stalwart Mail",
    "vaultwarden": "Vaultwarden (passwords)",
    "encryption": "Encryption (at rest)",
    "phi_detection": "PHI Detection (safe mode)",
    "rbac": "RBAC (role-based access)",
    "user_management": "User Management",
    "github": "GitHub (issues & PRs)",
    "slack": "Slack (Socket Mode)",
    # API services
    "hubspot": "HubSpot (CRM)",
    "todoist": "Todoist (tasks)",
    "stripe": "Stripe (payments)",
    "square": "Square (POS)",
    "mailerlite": "MailerLite (email marketing)",
    "shippo": "Shippo (shipping)",
    "calcom": "Cal.com (scheduling)",
    "brave_search": "Brave Search (web search)",
    "spoonacular": "Spoonacular (recipes)",
    "reddit": "Reddit (social)",
    "etsy": "Etsy (marketplace)",
    "clockify": "Clockify (time tracking)",
    "quickbooks": "QuickBooks (accounting)",
    # Sprint 2-10 API services
    "google_trends": "Google Trends",
    "news": "News (GNews)",
    "cloudinary_img": "Cloudinary (images)",
    "instagram": "Instagram Business",
    "civicrm": "CiviCRM",
    "globalgiving": "GlobalGiving (grants)",
    "jitsi": "Jitsi Meet",
    "kobo": "KoBoToolbox (surveys)",
    "open_referral": "Open Referral (211)",
    # Self-hosted (Mealie)
    "mealie": "Mealie (recipes)",
    # Social platforms
    "mastodon": "Mastodon / GoToSocial",
    "bluesky": "Bluesky (AT Protocol)",
}

SERVICE_BUTTON_LABELS: dict[str, tuple[str, str]] = {
    # key -> (callback_key, button_label)
    "anthropic": ("anthropic", "Claude \u2601\ufe0f"),
    "openai": ("openai", "GPT \u2601\ufe0f"),
    "gemini": ("gemini", "Gemini \u2601\ufe0f"),
    "ollama": ("ollama", "Ollama \U0001f3e0"),
    "google": ("google_menu", "\U0001f4c5 Google"),
    "calendar": ("calendar_menu", "\U0001f4c5 Calendar"),
    "email": ("email_menu", "\U0001f4e7 Email"),
    "sms": ("sms_menu", "\U0001f4f1 SMS"),
    "browser": ("browser_menu", "\U0001f310 Browser"),
    "voice": ("voice_menu", "\U0001f3a4 Voice"),
    "websearch": ("websearch_menu", "\U0001f50d WebSearch"),
    "healthcare": ("healthcare_menu", "\U0001f3e5 Healthcare"),
    "jellyfin": ("jellyfin_menu", "\U0001f3ac Jellyfin"),
    "gitea": ("gitea_menu", "\U0001f419 Forgejo / Gitea"),
    "homeassistant": ("homeassistant_menu", "\U0001f3e0 Home Assistant"),
    "joplin": ("joplin_menu", "\U0001f4dd Joplin"),
    "pihole": ("pihole_menu", "\U0001f6e1\ufe0f Pi-hole"),
    "nextcloud": ("nextcloud_menu", "\u2601\ufe0f Nextcloud"),
    "proton": ("proton_services_menu", "\U0001f512 Proton"),
    "email_server": ("email_server_menu", "\U0001f4ec Stalwart Mail"),
    "vaultwarden": ("vaultwarden_menu", "\U0001f511 Vaultwarden"),
    "encryption": ("encryption_menu", "\U0001f510 Encryption"),
    "phi_detection": ("phi_detection_menu", "\U0001f3e5 PHI Detection"),
    "rbac": ("rbac_menu", "\U0001f6e1\ufe0f RBAC"),
    "user_management": ("user_management_menu", "\U0001f465 Users"),
    "github": ("github_menu", "\U0001f4bb GitHub"),
    "slack": ("slack_menu", "\U0001f4ac Slack"),
    # API services
    "hubspot": ("hubspot_menu", "\U0001f4bc HubSpot"),
    "todoist": ("todoist_menu", "\u2705 Todoist"),
    "stripe": ("stripe_menu", "\U0001f4b3 Stripe"),
    "square": ("square_menu", "\u2b1b Square"),
    "mailerlite": ("mailerlite_menu", "\U0001f4e8 MailerLite"),
    "shippo": ("shippo_menu", "\U0001f4e6 Shippo"),
    "calcom": ("calcom_menu", "\U0001f4c5 Cal.com"),
    "brave_search": ("brave_search_menu", "\U0001f981 Brave Search"),
    "spoonacular": ("spoonacular_menu", "\U0001f372 Spoonacular"),
    "reddit": ("reddit_menu", "\U0001f4e2 Reddit"),
    "etsy": ("etsy_menu", "\U0001f3a8 Etsy"),
    "clockify": ("clockify_menu", "\u23f0 Clockify"),
    "quickbooks": ("quickbooks_menu", "\U0001f4b0 QuickBooks"),
    # Sprint 2-10 API services
    "google_trends": ("google_trends_menu", "\U0001f4c8 Google Trends"),
    "news": ("news_menu", "\U0001f4f0 News"),
    "cloudinary_img": ("cloudinary_img_menu", "\u2601\ufe0f Cloudinary"),
    "instagram": ("instagram_menu", "\U0001f4f7 Instagram"),
    "civicrm": ("civicrm_menu", "\U0001f4cb CiviCRM"),
    "globalgiving": ("globalgiving_menu", "\U0001f30d GlobalGiving"),
    "jitsi": ("jitsi_menu", "\U0001f4f9 Jitsi"),
    "kobo": ("kobo_menu", "\U0001f4dd KoBoToolbox"),
    "open_referral": ("open_referral_menu", "\U0001f4de Open Referral"),
    # Self-hosted (Mealie)
    "mealie": ("mealie_menu", "\U0001f374 Mealie"),
    # Social platforms
    "mastodon": ("mastodon_menu", "#\ufe0f\u20e3 Mastodon"),
    "bluesky": ("bluesky_menu", "\U0001f98b Bluesky"),
}

# ── Tarot display constants ──────────────────────────────────────

TAROT_CARD_ART: dict[str, list[str]] = {
    "mind": [
        " .~*~.",
        "( \u2601\ufe0f  )",
        " `~*~'",
    ],
    "voice": [
        " .~*~.",
        "( \U0001f4ac )",
        " `~*~'",
    ],
    "eye": [
        " .~*~.",
        "(\U0001f441\ufe0f  )",
        " `~*~'",
    ],
    "hearth": [
        " .~*~.",
        "(\U0001f3e0  )",
        " `~*~'",
    ],
    "shield": [
        " .~*~.",
        "(\U0001f512  )",
        " `~*~'",
    ],
}

# ── Service documentation links ──────────────────────────────────

SERVICE_DOCS: dict[str, tuple[str, str]] = {
    # LLM providers
    "anthropic": (
        "https://console.anthropic.com/settings/keys",
        "Get your API key from the Anthropic Console",
    ),
    "openai": (
        "https://platform.openai.com/api-keys",
        "Generate an API key in the OpenAI dashboard",
    ),
    "gemini": (
        "https://aistudio.google.com/apikey",
        "Create an API key in Google AI Studio",
    ),
    "ollama": (
        "https://ollama.com/download",
        "Download and install Ollama for local models",
    ),
    # Self-Hosted
    "jellyfin": (
        "https://jellyfin.org/docs/general/administration/configuration/",
        "Jellyfin admin docs \u2014 find your API key under Dashboard \u2192 API Keys",
    ),
    "gitea": (
        "https://forgejo.org/docs/latest/user/api-usage/",
        "Forgejo API docs \u2014 generate a token under Settings \u2192 Applications",
    ),
    "gitea_alt": (
        "https://about.gitea.com/resources/tutorials/api-key",
        "Gitea API docs \u2014 generate a token under Settings \u2192 Applications",
    ),
    "homeassistant": (
        "https://developers.home-assistant.io/docs/auth_api/#long-lived-access-token",
        "HA docs \u2014 create a Long-Lived Access Token in your Profile",
    ),
    "joplin": (
        "https://joplinapp.org/help/apps/clipper/",
        "Joplin Web Clipper docs \u2014 find your token in Tools \u2192 Options \u2192 Web Clipper",
    ),
    "pihole": (
        "https://docs.pi-hole.net/guides/misc/whitelist-blacklist/",
        "Pi-hole docs \u2014 find your API token under Settings \u2192 API",
    ),
    "nextcloud": (
        "https://docs.nextcloud.com/server/latest/user_manual/en/files/access_webdav.html",
        "Nextcloud WebDAV docs \u2014 use an App Password from Security settings",
    ),
    "email_server": (
        "https://stalw.art/docs/get-started",
        "Stalwart Mail setup guide \u2014 admin UI at localhost:8010",
    ),
    # Security
    "vaultwarden": (
        "https://github.com/dani-garcia/vaultwarden/wiki/Enabling-admin-page",
        "Vaultwarden wiki \u2014 enable admin page to get API token",
    ),
    # Integrations
    "sms": (
        "https://www.twilio.com/docs/sms/quickstart/python",
        "Twilio SMS quickstart \u2014 get Account SID, Auth Token, and a phone number",
    ),
    "browser": (
        "https://playwright.dev/python/docs/intro",
        "Playwright Python docs \u2014 installation and browser setup",
    ),
    "voice": (
        "https://github.com/openai/whisper",
        "OpenAI Whisper GitHub \u2014 speech recognition models",
    ),
    "websearch": (
        "https://docs.searxng.org/admin/installation.html",
        "SearXNG install docs (optional \u2014 DuckDuckGo works out of the box)",
    ),
    "github": (
        "https://github.com/settings/tokens",
        "Create a PAT with repo + notifications scopes",
    ),
    "slack": (
        "https://api.slack.com/apps",
        "Create a Slack App with Socket Mode enabled",
    ),
    # API services
    "hubspot": (
        "https://developers.hubspot.com/docs/api/private-apps",
        "HubSpot Private Apps \u2014 create a private app for API access",
    ),
    "todoist": (
        "https://todoist.com/app/settings/integrations/developer",
        "Todoist Developer settings \u2014 copy your API token",
    ),
    "stripe": (
        "https://dashboard.stripe.com/apikeys",
        "Stripe Dashboard \u2014 copy your Secret key",
    ),
    "square": (
        "https://developer.squareup.com/apps",
        "Square Developer \u2014 create an app and get Access Token",
    ),
    "mailerlite": (
        "https://dashboard.mailerlite.com/integrations/api",
        "MailerLite Dashboard \u2014 generate an API key",
    ),
    "shippo": (
        "https://apps.goshippo.com/settings/api",
        "Shippo Settings \u2014 copy your API Live Token",
    ),
    "calcom": (
        "https://app.cal.com/settings/developer/api-keys",
        "Cal.com Developer \u2014 create an API key",
    ),
    "brave_search": (
        "https://brave.com/search/api/",
        "Brave Search API \u2014 subscribe and get API key",
    ),
    "spoonacular": (
        "https://spoonacular.com/food-api/console",
        "Spoonacular Console \u2014 sign up for an API key",
    ),
    "reddit": (
        "https://www.reddit.com/prefs/apps",
        "Reddit Apps \u2014 create a script-type application",
    ),
    "etsy": (
        "https://www.etsy.com/developers/your-apps",
        "Etsy Developers \u2014 create an app for API access",
    ),
    "clockify": (
        "https://app.clockify.me/user/settings",
        "Clockify Settings \u2014 generate an API key",
    ),
    "quickbooks": (
        "https://developer.intuit.com/app/developer/qbo/docs/get-started",
        "QuickBooks Developer \u2014 create an app for API access",
    ),
    # Sprint 2-10 API services
    "google_trends": (
        "https://developers.google.com/trends/",
        "Google Trends API \u2014 access trending search data",
    ),
    "news": (
        "https://gnews.io/docs/v4",
        "GNews API \u2014 get a free API key for news headlines",
    ),
    "cloudinary_img": (
        "https://cloudinary.com/documentation/admin_api",
        "Cloudinary Console \u2014 find Cloud Name and API Key in Dashboard",
    ),
    "instagram": (
        "https://developers.facebook.com/docs/instagram-api/getting-started",
        "Instagram Graph API \u2014 create an app and get a long-lived token",
    ),
    "civicrm": (
        "https://docs.civicrm.org/sysadmin/en/latest/setup/api/",
        "CiviCRM API docs \u2014 generate an API key in your CiviCRM instance",
    ),
    "globalgiving": (
        "https://www.globalgiving.org/api/",
        "GlobalGiving API \u2014 sign up for API access",
    ),
    "jitsi": (
        "https://jitsi.github.io/handbook/docs/dev-guide/dev-guide-server-occ",
        "Jitsi Meet \u2014 self-hosted video conferencing setup",
    ),
    "kobo": (
        "https://support.kobotoolbox.org/api.html",
        "KoBoToolbox API \u2014 find your token in Account Settings",
    ),
    "open_referral": (
        "https://openreferral.org/documentation/",
        "Open Referral / 211 \u2014 community resource directory API",
    ),
    "mealie": (
        "https://docs.mealie.io/documentation/getting-started/api-usage/",
        "Mealie API docs \u2014 create an API token in User Settings",
    ),
    # Social platforms
    "mastodon": (
        "https://docs.joinmastodon.org/client/token/",
        "Mastodon API docs \u2014 create an application for an access token",
    ),
    "bluesky": (
        "https://bsky.social/about/blog/2-13-2024-atproto-developer-ecosystem",
        "Bluesky AT Protocol \u2014 create an App Password in Settings",
    ),
    # Email/Calendar
    "google": (
        "https://console.cloud.google.com/apis/credentials",
        "Google Cloud Console \u2014 create OAuth 2.0 credentials (Desktop app type)",
    ),
    "caldav": (
        "https://www.calconnect.org/resources/caldav",
        "CalDAV protocol info \u2014 check your provider's docs for the server URL",
    ),
}


def _service_doc_blurb(service_key: str, mode: FormatMode) -> str:
    """Return a one-line doc link for a service, or empty string if none."""
    entry = SERVICE_DOCS.get(service_key)
    if not entry:
        return ""
    url, desc = entry
    link = fmt_link("Setup guide", url, mode)
    lines = f"\n{link} \u2014 {desc}"
    # Show alternate docs link if one exists (e.g. Forgejo + Gitea)
    alt_entry = SERVICE_DOCS.get(f"{service_key}_alt")
    if alt_entry:
        alt_url, alt_desc = alt_entry
        alt_link = fmt_link("Alt docs", alt_url, mode)
        lines += f"\n{alt_link} \u2014 {alt_desc}"
    return lines + "\n"


# Optional: caldav library for CalDAV testing
try:
    import caldav
except ImportError:
    caldav = None  # type: ignore[assignment]

# ── Email provider presets (format-neutral) ─────────────────────────

EMAIL_PRESETS: dict[str, dict] = {
    "gmail": {
        "name": "Gmail",
        "imap_server": "imap.gmail.com",
        "smtp_server": "smtp.gmail.com",
        "imap_port": 993,
        "smtp_port": 587,
        "password_help_plain": (
            "Gmail requires an App Password (not your regular password):\n\n"
            "1. Go to https://myaccount.google.com/apppasswords\n"
            '2. Select "Mail" -> "Other (Familiar)"\n'
            "3. Copy the 16-character password\n"
        ),
    },
    "outlook": {
        "name": "Outlook / Office 365",
        "imap_server": "outlook.office365.com",
        "smtp_server": "smtp.office365.com",
        "imap_port": 993,
        "smtp_port": 587,
        "password_help_plain": (
            "Use your Outlook password or an App Password if MFA is enabled.\n"
        ),
    },
    "yahoo": {
        "name": "Yahoo Mail",
        "imap_server": "imap.mail.yahoo.com",
        "smtp_server": "smtp.mail.yahoo.com",
        "imap_port": 993,
        "smtp_port": 587,
        "password_help_plain": (
            "Generate an App Password at https://login.yahoo.com/account/security\n"
        ),
    },
    "proton": {
        "name": "ProtonMail (Bridge)",
        "imap_server": "127.0.0.1",
        "smtp_server": "127.0.0.1",
        "imap_port": 1143,
        "smtp_port": 1025,
        "password_help_plain": (
            "Proton Mail Bridge runs locally and exposes IMAP/SMTP.\n\n"
            "Setup:\n"
            "1. Install Bridge from https://proton.me/mail/bridge\n"
            "   Linux: flatpak install flathub ch.protonmail.protonmail-bridge\n"
            "   Or download the .deb/.rpm from the link above\n"
            "2. Open Bridge and sign in with your Proton account\n"
            "3. Click your account name -> Mailbox configuration\n"
            "4. Copy the Bridge password (NOT your Proton password)\n"
            "   It looks like: aBcDeFgHiJkLmNoP\n"
            "5. Note your Proton email address\n\n"
            "Bridge must be running whenever Familiar checks email.\n"
            "Ports: IMAP 1143, SMTP 1025 (localhost only, no TLS needed).\n"
        ),
    },
}


def _password_help(provider_key: str, mode: FormatMode) -> str:
    """Render password help text with appropriate formatting."""
    preset = EMAIL_PRESETS[provider_key]
    plain = preset["password_help_plain"]
    if mode is FormatMode.HTML:
        # Re-render with HTML tags for richer presentation
        if provider_key == "gmail":
            return (
                f"Gmail requires an {fmt_bold('App Password', mode)} (not your regular password):\n\n"
                f"1. Go to https://myaccount.google.com/apppasswords\n"
                f'2. Select "Mail" \u2192 "Other (Familiar)"\n'
                f"3. Copy the 16-character password\n"
            )
        if provider_key == "proton":
            return (
                f"{fmt_bold('Proton Mail Bridge', mode)} runs locally and exposes IMAP/SMTP.\n\n"
                f"{fmt_bold('Setup:', mode)}\n"
                f"1. Install Bridge from https://proton.me/mail/bridge\n"
                f"   \u2022 Linux: {fmt_code('flatpak install flathub ch.protonmail.protonmail-bridge', mode)}\n"
                f"   \u2022 Or download the .deb/.rpm from the link above\n"
                f"2. Open Bridge and sign in with your Proton account\n"
                f"3. Click your account name \u2192 {fmt_bold('Mailbox configuration', mode)}\n"
                f"4. Copy the {fmt_bold('Bridge password', mode)} (NOT your Proton password)\n"
                f"   \u2022 It looks like: {fmt_code('aBcDeFgHiJkLmNoP', mode)}\n"
                f"5. Note your Proton email address\n\n"
                f"{fmt_bold('Bridge must be running', mode)} whenever Familiar checks email.\n"
                f"Ports: IMAP 1143, SMTP 1025 (localhost only, no TLS needed).\n"
            )
    return plain


# ── Env file + IMAP helpers (static, no channel dependency) ─────────


def _update_env_file(env_path, updates: dict, *, service_key: str = ""):
    """Update or append key=value pairs in a .env file (with file locking).

    If *service_key* is provided, a credential audit event is logged after
    the file is written (CREATED for new keys, UPDATED for existing ones).
    """
    import shutil
    from datetime import datetime

    env_path = Path(env_path)
    env_path.parent.mkdir(parents=True, exist_ok=True)

    if not env_path.exists():
        env_path.touch()

    # Track which keys already existed for audit event type
    existing_keys: set[str] = set()
    if service_key:
        try:
            with open(env_path) as rf:
                for line in rf:
                    stripped = line.strip()
                    if stripped and not stripped.startswith("#") and "=" in stripped:
                        existing_keys.add(stripped.split("=", 1)[0].strip())
        except OSError:
            pass

    # Back up existing .env before any modifications
    if env_path.stat().st_size > 0:
        backup_dir = env_path.parent / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = backup_dir / f".env.{timestamp}"
        shutil.copy2(env_path, backup_path)
        try:
            backup_path.chmod(0o600)
        except OSError as e:
            logger.debug("I/O error suppressed: %s", e)
    with open(env_path, "r+") as f:
        if fcntl is not None:
            fcntl.flock(f, fcntl.LOCK_EX)
        try:
            existing_lines = f.read().splitlines()

            updated_keys: set[str] = set()
            new_lines: list[str] = []

            for line in existing_lines:
                stripped = line.strip()
                if stripped and not stripped.startswith("#") and "=" in stripped:
                    key = stripped.split("=", 1)[0].strip()
                    if key in updates:
                        new_lines.append(f"{key}={updates[key]}")
                        updated_keys.add(key)
                        continue
                new_lines.append(line)

            for key, value in updates.items():
                if key not in updated_keys:
                    new_lines.append(f"{key}={value}")

            content = "\n".join(new_lines) + "\n"
            f.seek(0)
            f.write(content)
            f.truncate()
        finally:
            if fcntl is not None:
                fcntl.flock(f, fcntl.LOCK_UN)
    env_path.chmod(0o600)

    # Log credential audit event
    if service_key:
        try:
            from familiar.core.credential_audit import (
                CredentialEventType,
                log_credential_event,
            )

            is_update = any(k in existing_keys for k in updates)
            event_type = CredentialEventType.UPDATED if is_update else CredentialEventType.CREATED
            env_key_names = ", ".join(sorted(updates.keys()))
            log_credential_event(
                service_key,
                event_type,
                details=f"Wizard saved credentials: {env_key_names}",
                source="connect_wizard",
            )
        except Exception as exc:
            logger.debug("Credential audit log failed: %s", exc)


def _update_yaml_config(updates: dict[str, dict]) -> None:
    """Merge nested key updates into ~/.familiar/config.yaml.

    *updates* maps top-level section names to dicts of key/value pairs, e.g.
    ``{"compliance": {"mode": "hipaa"}, "agent": {"enable_pii_detection": True}}``.
    """
    config_path = Path.home() / ".familiar" / "config.yaml"
    config_path.parent.mkdir(parents=True, exist_ok=True)

    data: dict = {}
    if config_path.exists():
        data = yaml.safe_load(config_path.read_text()) or {}

    for section, kvs in updates.items():
        if section not in data:
            data[section] = {}
        data[section].update(kvs)

    config_path.write_text(yaml.dump(data, default_flow_style=False))


def _test_imap_connection(env_vars: dict) -> tuple[bool, str]:
    """Test IMAP connection.  Returns (success, message)."""
    import imaplib

    try:
        server = env_vars["EMAIL_IMAP_SERVER"]
        port = int(env_vars["EMAIL_IMAP_PORT"])
        if port == 993:
            mail = imaplib.IMAP4_SSL(server, port)
        else:
            mail = imaplib.IMAP4(server, port)
            mail.starttls()
        mail.login(env_vars["EMAIL_ADDRESS"], env_vars["EMAIL_PASSWORD"])
        mail.select("INBOX")
        status, messages = mail.search(None, "ALL")
        count = len(messages[0].split()) if status == "OK" and messages[0] else 0
        mail.logout()
        return True, f"Inbox: {count} messages"
    except imaplib.IMAP4.error as e:
        return False, f"IMAP auth failed: {e}"
    except Exception as e:
        return False, f"Connection error: {e}"


def _check_pygithub_lib() -> bool:
    try:
        from github import Github  # noqa: F401

        return True
    except ImportError:
        return False


def _check_slack_sdk_lib() -> bool:
    try:
        from slack_sdk import WebClient  # noqa: F401

        return True
    except ImportError:
        return False


def _check_google_libs() -> bool:
    """Check if Google API libraries are installed."""
    try:
        import google.oauth2.credentials  # noqa: F401
        import google_auth_oauthlib.flow  # noqa: F401
        import googleapiclient.discovery  # noqa: F401

        return True
    except ImportError:
        return False


def _check_twilio_lib() -> bool:
    try:
        from twilio.rest import Client  # noqa: F401

        return True
    except ImportError:
        return False


def _test_http_service(
    url: str,
    *,
    headers: dict | None = None,
    params: dict | None = None,
    auth: tuple[str, str] | None = None,
    method: str = "GET",
) -> tuple[bool, str]:
    """Reusable HTTP connectivity test.  Returns (success, message)."""
    import httpx

    try:
        with httpx.Client(timeout=10, verify=True) as client:
            resp = client.request(
                method,
                url,
                headers=headers or {},
                params=params,
                auth=auth,
            )
        if resp.status_code < 400:
            return True, f"OK (HTTP {resp.status_code})"
        if resp.status_code in (401, 403):
            return (
                False,
                f"HTTP {resp.status_code}: Authentication failed. Check your token or credentials.",
            )
        if resp.status_code == 404:
            return False, "HTTP 404: Endpoint not found. Check the URL path."
        if resp.status_code >= 500:
            return False, f"HTTP {resp.status_code}: Server error. Check service logs."
        return False, f"HTTP {resp.status_code}: {resp.text[:200]}"
    except httpx.ConnectError as e:
        err = str(e).lower()
        if "ssl" in err or "certificate" in err:
            return False, "SSL/TLS error: Check URL scheme (http vs https) and certificates."
        if "refused" in err:
            return False, "Connection refused: Is the service running? Check URL and port."
        if "resolve" in err or "name" in err:
            return False, "DNS error: Cannot resolve hostname. Check for typos."
        return False, f"Connection failed: {e}"
    except Exception as e:
        return False, f"Error: {e}"


def _check_tcp_port(host: str, port: int, timeout: float = 2.0) -> bool:
    """Check if a TCP port is reachable."""
    import socket

    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, TimeoutError):
        return False


# ── Generic service provisioning helpers ────────────────────────────


def is_service_provisioned(service_key: str) -> bool:
    """Check if a service is running via Familiar's service manager."""
    try:
        from familiar.services.manager import get_service_manager

        mgr = get_service_manager()
        status = mgr.get_status(service_key)
        return bool(status and status.get("status") == "running")
    except Exception:
        return False


def get_service_url(service_key: str) -> str:
    """Return the localhost URL for a provisioned service."""
    try:
        from familiar.services.specs import SERVICE_SPECS

        spec = SERVICE_SPECS.get(service_key)
        if spec and spec.health_check_port:
            return f"http://localhost:{spec.health_check_port}"
    except Exception:
        pass
    return ""


def is_service_provisionable(service_key: str) -> bool:
    """Check if a service can be auto-provisioned (exists in SERVICE_SPECS as container)."""
    try:
        from familiar.services.specs import SERVICE_SPECS, ServiceType

        spec = SERVICE_SPECS.get(service_key)
        return spec is not None and spec.service_type == ServiceType.CONTAINER
    except Exception:
        return False


async def auto_provision_service(
    host,
    recipient_id: str,
    service_key: str,
) -> bool:
    """Provision and start a service via the service manager.

    Returns True if the service is running after provisioning.
    Sends wizard messages about progress/errors.
    """
    import asyncio as _asyncio

    from ..formatting import fmt_bold, fmt_code

    m = host.format_mode

    try:
        from familiar.services.manager import get_service_manager
        from familiar.services.specs import SERVICE_SPECS

        spec = SERVICE_SPECS.get(service_key)
        if not spec:
            await host.wizard_send(
                recipient_id,
                f"\u274c Unknown service: {fmt_code(service_key, m)}",
            )
            return False

        display = spec.display_name

        await host.wizard_send(
            recipient_id,
            f"\U0001f504 {fmt_bold(f'Installing {display}...', m)}\n"
            f"This may take a minute while the container image downloads.",
        )

        mgr = get_service_manager()
        result = mgr.provision(service_key)
        if not result.get("success", False):
            error = result.get("error", "Unknown error")
            await host.wizard_send(
                recipient_id,
                f"\u274c {fmt_bold('Provisioning failed', m)}\n\n"
                f"  {error}\n\n"
                f"Make sure Podman or Docker is installed, then try again.",
            )
            return False

        start_result = mgr.start(service_key)
        if not start_result.get("success", False):
            await host.wizard_send(
                recipient_id,
                f"\u274c {fmt_bold('Container created but failed to start', m)}\n\n"
                f"  {start_result.get('error', 'Unknown error')}",
            )
            return False

        # Wait for it to come up
        for _ in range(10):
            await _asyncio.sleep(1)
            status = mgr.get_status(service_key)
            if status and status.get("running"):
                return True

        # Timed out but container might still be starting
        return is_service_provisioned(service_key)

    except ImportError:
        await host.wizard_send(
            recipient_id,
            f"\u274c Auto-install requires the server provisioning module.",
        )
        return False
    except Exception as e:
        logger.exception("Auto-provision %s failed", service_key)
        await host.wizard_send(
            recipient_id,
            f"\u274c {fmt_bold('Installation failed', m)}: {e}",
        )
        return False
