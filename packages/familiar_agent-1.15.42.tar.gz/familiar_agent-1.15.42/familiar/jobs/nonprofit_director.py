# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Nonprofit Director job class — donor CRM, grants, bookkeeping, board reporting."""

from . import JobClass, register_job_class

NONPROFIT_DIRECTOR = JobClass(
    key="nonprofit_director",
    name="Nonprofit Director",
    icon="fa-building-columns",
    description="Donor management, grant tracking, bookkeeping, and board reporting",
    prompt_fragment="""You are operating in Nonprofit Director mode. Your focus areas:
- **Donor relations**: Track donations, generate thank-you letters, manage donor history.
- **Grant management**: Track grant pipeline from prospect through completion.
- **Financial oversight**: Monitor income, expenses, and fund balances. Prepare 990 data.
- **Board reporting**: Generate board packets with financial summaries and program updates.
- **Compliance**: Track deadlines for filings, grant reports, and donor acknowledgments.
- **Stewardship**: Flag donors needing follow-up, track engagement touchpoints.""",
    skill_weights={
        "donor_add": 0.9,
        "donor_details": 0.9,
        "donor_search": 0.8,
        "log_donation": 0.9,
        "grant_add": 0.8,
        "grant_update": 0.8,
        "grant_list": 0.7,
        "bookkeeping_add": 0.8,
        "bookkeeping_summary": 0.8,
        "board_packet": 0.9,
        "export_990": 0.7,
        "write_note": 0.7,
        "search_notes": 0.6,
        "send_email": 0.7,
        "draft_email": 0.7,
        "calendar_create": 0.6,
        "remember": 0.6,
        "recall": 0.6,
        "query_chairman": 0.7,
        "review_pending_events": 0.8,
        "confirm_pending_event": 0.8,
        "dismiss_pending_event": 0.7,
        "review_action_queue": 0.8,
        "complete_action": 0.7,
        "delegate_action": 0.7,
        # Events
        "create_event": 0.8,
        "list_events": 0.7,
        "event_details": 0.8,
        "update_event": 0.7,
        "event_timeline": 0.8,
        "add_vendor": 0.7,
        "add_volunteer": 0.7,
        "volunteer_summary": 0.7,
        # Advocacy
        "track_bill": 0.8,
        "list_bills": 0.7,
        "bill_details": 0.8,
        "update_bill": 0.7,
        "add_hearing": 0.7,
        "add_testimony": 0.7,
        "upcoming_hearings": 0.8,
        "draft_action_alert": 0.8,
        "advocacy_dashboard": 0.8,
        # Stewardship
        "stewardship_queue": 0.8,
        "complete_stewardship": 0.7,
        "stewardship_history": 0.7,
        "auto_draft_thankyou": 0.8,
        # Batch comms
        "segment_donors": 0.7,
        "create_batch": 0.7,
        "batch_status": 0.7,
        # Smart Intake
        "smart_intake": 0.8,
        "review_intake": 0.4,
        "batch_intake": 0.7,
        "intake_history": 0.6,
    },
    species_flavor={
        "fox": "Your fox brings charm to donor relations — warm thank-yous, quick follow-ups.",
        "owl": "Your owl brings meticulous oversight — every grant deadline tracked, every dollar accounted.",
        "cat": "Your cat brings quiet competence — elegant board packets, efficient operations.",
        "dragon": "Your dragon brings commanding stewardship — bold fundraising, decisive budgeting.",
        "wolf": "Your wolf brings loyal partnership — building lasting donor relationships.",
        "frog": "Your frog brings creative fundraising — finding grants others miss.",
    },
    recommended_connects=[
        "email",
        "calendar",
        "todoist",
        "hubspot",
        "stripe",
        "mailerlite",
        "civicrm",
        "globalgiving",
    ],
    proactive_focus=[
        "donors needing thank-you letters",
        "upcoming grant deadlines",
        "monthly financial reconciliation",
        "board meeting preparation",
    ],
    workspace={
        "label": "Nonprofit HQ",
        "icon": "fa-building-columns",
        "description": (
            "Your nonprofit command center. Track donors, manage grants,"
            " keep your books, and prepare for board meetings — all in one place."
            " Just tell me what you need in the chat below."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-building-columns",
                    "color": "#60a5fa",
                    "label": "Nonprofit Server",
                    "message": (
                        "Set up your nonprofit's own private server —"
                        " Joplin for board minutes and notes, Nextcloud"
                        " for sharing files with your board and team."
                        " Everything stays on your machine, fully private."
                    ),
                    "button_label": "Set Up Nonprofit Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["joplin", "nextcloud"],
                },
                {
                    "key": "nonprofit_services",
                    "type": "service_status",
                    "icon": "fa-building-columns",
                    "color": "#60a5fa",
                    "label": "Nonprofit Services",
                    "source": "server",
                    "service_keys": [
                        "joplin",
                        "nextcloud",
                    ],
                },
                {
                    "key": "total_donors",
                    "label": "Total Donors",
                    "icon": "fa-users",
                    "color": "#4ade80",
                    "source": "nonprofit",
                    "metric": "donors.count",
                    "format": "number",
                },
                {
                    "key": "ytd_raised",
                    "label": "YTD Raised",
                    "icon": "fa-dollar-sign",
                    "color": "#fbbf24",
                    "source": "bookkeeping",
                    "metric": "ytd_income",
                    "format": "currency",
                },
                {
                    "key": "active_grants",
                    "label": "Active Grants",
                    "icon": "fa-file-contract",
                    "color": "#60a5fa",
                    "source": "nonprofit",
                    "metric": "grants.active_count",
                    "format": "number",
                },
                {
                    "key": "needs_thanks",
                    "label": "Need Thank You",
                    "icon": "fa-envelope-open-text",
                    "color": "#f87171",
                    "source": "nonprofit",
                    "metric": "donors.needs_thanks_count",
                    "format": "number",
                },
                {
                    "key": "unread_emails",
                    "label": "Unread Emails",
                    "icon": "fa-envelope",
                    "color": "#fbbf24",
                    "format": "number",
                    "client_api": "/api/email/triage",
                    "client_metric": "total",
                },
                {
                    "key": "today_events",
                    "label": "Today's Events",
                    "icon": "fa-calendar-day",
                    "color": "#c084fc",
                    "format": "number",
                    "client_api": "/api/calendar/events?days=1&view=day",
                    "client_metric": "events.length",
                },
                {
                    "key": "upcoming_deadlines",
                    "label": "Upcoming Deadlines",
                    "icon": "fa-clock",
                    "color": "#fb923c",
                    "source": "nonprofit",
                    "metric": "grants.deadline_count",
                    "format": "number",
                },
                {
                    "key": "pending_events_count",
                    "label": "Pending Events",
                    "icon": "fa-calendar-plus",
                    "color": "#a78bfa",
                    "source": "pending_events",
                    "metric": "pending_events.count",
                    "format": "number",
                },
                {
                    "key": "action_queue_count",
                    "label": "Action Queue",
                    "icon": "fa-list-check",
                    "color": "#f472b6",
                    "source": "action_queue",
                    "metric": "action_queue.count",
                    "format": "number",
                },
                {
                    "key": "upcoming_events",
                    "label": "Upcoming Events",
                    "icon": "fa-calendar-star",
                    "color": "#34d399",
                    "source": "events",
                    "metric": "events.upcoming_count",
                    "format": "number",
                },
                {
                    "key": "active_bills",
                    "label": "Active Bills",
                    "icon": "fa-landmark",
                    "color": "#818cf8",
                    "source": "advocacy",
                    "metric": "advocacy.active_count",
                    "format": "number",
                },
                {
                    "key": "overdue_stewardship",
                    "label": "Overdue Stewardship",
                    "icon": "fa-heart-pulse",
                    "color": "#f87171",
                    "source": "stewardship",
                    "metric": "stewardship.overdue_count",
                    "format": "number",
                },
                {
                    "key": "intake_count",
                    "label": "Intake Items",
                    "icon": "fa-file-import",
                    "color": "#06b6d4",
                    "source": "intake",
                    "metric": "intake.total_count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "donors",
                "label": "Donors",
                "icon": "fa-users",
                "type": "table",
                "source": "nonprofit",
                "source_key": "donors",
                "empty_message": (
                    "No donors yet. Click 'Add Donor' above, or just tell me"
                    " in the chat: \"Jane Smith donated $100 today\" and I'll"
                    " create her record with automatic RFM scoring."
                ),
                "columns": [
                    {"key": "name", "label": "Name", "type": "text", "sortable": True},
                    {"key": "donor_level", "label": "Level", "type": "badge", "sortable": True},
                    {"key": "email", "label": "Email", "type": "text", "sortable": True},
                    {
                        "key": "total_given",
                        "label": "Total Given",
                        "type": "currency",
                        "sortable": True,
                    },
                    {
                        "key": "rfm_score",
                        "label": "RFM",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "last_gift",
                        "label": "Last Gift",
                        "type": "date",
                        "sortable": True,
                    },
                    {
                        "key": "interactions_count",
                        "label": "Interactions",
                        "type": "number",
                        "sortable": True,
                    },
                ],
                "default_sort": "total_given",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "details",
                        "label": "Details",
                        "icon": "fa-eye",
                        "mode": "tool",
                        "tool": "donor_details",
                    },
                    {
                        "key": "thank",
                        "label": "Thank",
                        "icon": "fa-envelope",
                        "mode": "agent",
                        "prompt_template": "Draft a thank-you email to {name} at {email}"
                        " for their generous support.",
                    },
                ],
            },
            {
                "key": "grants",
                "label": "Grant Pipeline",
                "icon": "fa-file-contract",
                "type": "pipeline",
                "source": "nonprofit",
                "source_key": "grants",
                "empty_message": (
                    "No grants tracked yet. Click 'Add Grant' above, or check"
                    " the 'Find Grants' tab to search Grants.gov for federal"
                    " funding and add opportunities directly to your pipeline."
                ),
                "stages": ["prospect", "applied", "awarded", "declined", "completed"],
                "stage_field": "status",
                "card_title_field": "name",
                "card_subtitle_field": "funder",
                "card_badge_field": "amount",
                "card_badge_format": "currency",
            },
            {
                "key": "pending_events",
                "label": "Inbox Events",
                "icon": "fa-calendar-plus",
                "type": "table",
                "source": "pending_events",
                "source_key": "events",
                "empty_message": (
                    "No pending calendar events detected yet. When emails"
                    " mention meetings, deadlines, or events, they'll"
                    " appear here for you to confirm or dismiss."
                ),
                "columns": [
                    {"key": "title", "label": "Event", "type": "text", "sortable": True},
                    {"key": "start", "label": "Start", "type": "date", "sortable": True},
                    {
                        "key": "email_from",
                        "label": "From",
                        "type": "text",
                        "sortable": True,
                    },
                    {
                        "key": "has_rsvp",
                        "label": "RSVP",
                        "type": "badge",
                        "sortable": True,
                    },
                    {
                        "key": "source_category",
                        "label": "Category",
                        "type": "badge",
                        "sortable": True,
                    },
                ],
                "default_sort": "start",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "confirm",
                        "label": "Add to Calendar",
                        "icon": "fa-calendar-check",
                        "mode": "api",
                        "api_url": "/api/nonprofit/pending-events/{id}/confirm",
                        "api_method": "POST",
                    },
                    {
                        "key": "dismiss",
                        "label": "Dismiss",
                        "icon": "fa-times",
                        "mode": "api",
                        "api_url": "/api/nonprofit/pending-events/{id}/dismiss",
                        "api_method": "POST",
                    },
                ],
            },
            {
                "key": "action_queue",
                "label": "Action Queue",
                "icon": "fa-list-check",
                "type": "table",
                "source": "action_queue",
                "source_key": "actions",
                "empty_message": (
                    "No follow-up actions pending. When emails need replies,"
                    " thank-yous, RSVPs, or delegation, they'll queue here"
                    " sorted by priority."
                ),
                "columns": [
                    {
                        "key": "email_subject",
                        "label": "Email",
                        "type": "text",
                        "sortable": True,
                    },
                    {
                        "key": "action_type",
                        "label": "Action",
                        "type": "badge",
                        "sortable": True,
                    },
                    {
                        "key": "priority",
                        "label": "Priority",
                        "type": "badge",
                        "sortable": True,
                    },
                    {
                        "key": "email_from",
                        "label": "From",
                        "type": "text",
                        "sortable": True,
                    },
                    {
                        "key": "detected_at",
                        "label": "Detected",
                        "type": "date",
                        "sortable": True,
                    },
                ],
                "default_sort": "priority",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "complete",
                        "label": "Complete",
                        "icon": "fa-check",
                        "mode": "api",
                        "api_url": "/api/nonprofit/action-queue/{id}/complete",
                        "api_method": "POST",
                    },
                    {
                        "key": "delegate",
                        "label": "Delegate",
                        "icon": "fa-share",
                        "mode": "agent",
                        "prompt_template": (
                            "Delegate this action to a staff member:"
                            " {email_subject} ({action_type})"
                        ),
                    },
                ],
            },
            {
                "key": "events",
                "label": "Events",
                "icon": "fa-calendar-star",
                "type": "pipeline",
                "source": "events",
                "source_key": "events",
                "empty_message": (
                    "No events planned yet. Click 'Plan Event' above"
                    " to create a gala, fundraiser, pride march, or other event"
                    " with auto-generated milestone timelines."
                ),
                "stages": ["planning", "confirmed", "in_progress", "completed", "cancelled"],
                "stage_field": "status",
                "card_title_field": "name",
                "card_subtitle_field": "event_type",
                "card_badge_field": "budget_total",
                "card_badge_format": "currency",
            },
            {
                "key": "advocacy",
                "label": "Advocacy",
                "icon": "fa-landmark",
                "type": "pipeline",
                "source": "advocacy",
                "source_key": "bills",
                "empty_message": (
                    "No bills tracked yet. Click 'Track Bill' above"
                    " to monitor legislation, coordinate testimony,"
                    " and send action alerts to supporters."
                ),
                "stages": [
                    "introduced", "committee", "floor_vote",
                    "passed_one", "passed_both", "signed", "vetoed", "dead",
                ],
                "stage_field": "status",
                "card_title_field": "bill_number",
                "card_subtitle_field": "title",
                "card_badge_field": "our_position",
                "card_badge_format": "text",
            },
            {
                "key": "legislation",
                "label": "Track Legislation",
                "icon": "fa-landmark",
                "type": "table",
                "source": "legislation",
                "source_key": "results",
                "empty_message": (
                    "Search Congress.gov for federal bills that affect"
                    " your mission. Click 'Search Bills' above to find"
                    " legislation, or set up keyword alerts with 'Watchlist'"
                    " to flag new bills automatically."
                ),
                "columns": [
                    {"key": "bill_id", "label": "Bill", "type": "text", "sortable": True},
                    {"key": "title", "label": "Title", "type": "text", "sortable": True},
                    {"key": "chamber", "label": "Chamber", "type": "text", "sortable": True},
                    {"key": "latest_action_date", "label": "Last Action", "type": "date", "sortable": True},
                    {"key": "latest_action", "label": "Status", "type": "text"},
                ],
                "default_sort": "latest_action_date",
                "default_sort_dir": "desc",
                "row_actions": [],
            },
            {
                "key": "stewardship",
                "label": "Stewardship",
                "icon": "fa-heart-pulse",
                "type": "table",
                "source": "stewardship",
                "source_key": "stewardship",
                "empty_message": (
                    "No stewardship tasks pending. When donations are"
                    " logged or detected in email, thank-you tasks and"
                    " follow-ups will auto-generate here based on gift size."
                ),
                "columns": [
                    {"key": "donor_name", "label": "Donor", "type": "text", "sortable": True},
                    {
                        "key": "action_label",
                        "label": "Action",
                        "type": "text",
                        "sortable": True,
                    },
                    {
                        "key": "trigger_amount",
                        "label": "Gift",
                        "type": "currency",
                        "sortable": True,
                    },
                    {"key": "due_date", "label": "Due", "type": "date", "sortable": True},
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                ],
                "default_sort": "due_date",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "complete",
                        "label": "Done",
                        "icon": "fa-check",
                        "mode": "api",
                        "api_url": "/api/nonprofit/stewardship/{entry_id}/complete",
                        "api_method": "POST",
                    },
                ],
            },
            {
                "key": "batch_comms",
                "label": "Batch Comms",
                "icon": "fa-paper-plane",
                "type": "table",
                "source": "batch_comms",
                "source_key": "batches",
                "empty_message": (
                    "No batch communications yet. Use 'Annual Appeal'"
                    " or 'LYBUNT Outreach' above to create segmented"
                    " donor communications."
                ),
                "columns": [
                    {"key": "name", "label": "Campaign", "type": "text", "sortable": True},
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                    {"key": "channel", "label": "Channel", "type": "badge", "sortable": True},
                    {
                        "key": "recipients_count",
                        "label": "Recipients",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "sent_count",
                        "label": "Sent",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "created_at",
                        "label": "Created",
                        "type": "date",
                        "sortable": True,
                    },
                ],
                "default_sort": "created_at",
                "default_sort_dir": "desc",
                "row_actions": [],
            },
            {
                "key": "grant_search",
                "label": "Find Grants",
                "icon": "fa-magnifying-glass-dollar",
                "type": "table",
                "source": "grants_gov",
                "source_key": "results",
                "empty_message": (
                    "Search Grants.gov for federal funding opportunities."
                    " Click 'Search Grants' above or type keywords like"
                    " 'education', 'housing', or 'health' to find open"
                    " opportunities. Click 'Track' on any result to add it"
                    " to your Grant Pipeline."
                ),
                "columns": [
                    {"key": "title", "label": "Title", "type": "text", "sortable": True},
                    {"key": "agency", "label": "Agency", "type": "text", "sortable": True},
                    {"key": "close_date", "label": "Deadline", "type": "date", "sortable": True},
                    {
                        "key": "award_floor",
                        "label": "Min Award",
                        "type": "currency",
                        "sortable": True,
                    },
                    {
                        "key": "award_ceiling",
                        "label": "Max Award",
                        "type": "currency",
                        "sortable": True,
                    },
                ],
                "default_sort": "close_date",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "track",
                        "label": "Track",
                        "icon": "fa-plus",
                        "mode": "agent",
                        "prompt_template": (
                            "Add this grant to my pipeline: {title}"
                            " from {agency}, deadline {close_date},"
                            " award range ${award_floor}-${award_ceiling}."
                        ),
                    },
                ],
            },
            {
                "key": "email_inbox",
                "label": "Email",
                "icon": "fa-envelope",
                "type": "email",
                "empty_message": (
                    "Email not connected yet. Go to the Connect tab and set up"
                    " email (Gmail, Outlook, or self-hosted) to see your inbox"
                    " here — volunteer replies, donor correspondence, and event"
                    " RSVPs will all show up automatically."
                ),
            },
            {
                "key": "schedule",
                "label": "Schedule",
                "icon": "fa-calendar-day",
                "type": "calendar",
                "empty_message": (
                    "No calendar connected yet. Go to the Connect tab and link"
                    " your Google Calendar or CalDAV calendar to see today's"
                    " events, board meetings, and volunteer schedules here."
                ),
            },
            {
                "key": "financials",
                "label": "Financials",
                "icon": "fa-chart-pie",
                "type": "summary",
                "source": "bookkeeping",
                "stats": [
                    {
                        "key": "ytd_income",
                        "label": "YTD Income",
                        "icon": "fa-arrow-up",
                        "color": "#4ade80",
                        "metric": "ytd_income",
                        "format": "currency",
                    },
                    {
                        "key": "ytd_expense",
                        "label": "YTD Expenses",
                        "icon": "fa-arrow-down",
                        "color": "#f87171",
                        "metric": "ytd_expense",
                        "format": "currency",
                    },
                    {
                        "key": "ytd_net",
                        "label": "Net Position",
                        "icon": "fa-scale-balanced",
                        "color": "#60a5fa",
                        "metric": "ytd_net",
                        "format": "currency",
                    },
                    {
                        "key": "donor_revenue",
                        "label": "Donor Revenue",
                        "icon": "fa-hand-holding-heart",
                        "color": "#fbbf24",
                        "metric": "donor_revenue",
                        "format": "currency",
                    },
                    {
                        "key": "grant_revenue",
                        "label": "Grant Revenue",
                        "icon": "fa-file-invoice-dollar",
                        "color": "#c084fc",
                        "metric": "grant_revenue",
                        "format": "currency",
                    },
                    {
                        "key": "transaction_count",
                        "label": "Transactions",
                        "icon": "fa-receipt",
                        "color": "#fb923c",
                        "metric": "transaction_count",
                        "format": "number",
                    },
                ],
            },
            {
                "key": "notes",
                "label": "Notes",
                "icon": "fa-sticky-note",
                "type": "table",
                "source": "nonprofit",
                "source_key": "notes",
                "empty_message": (
                    "No notes yet. Try saying \"take a note\" in chat —"
                    " board meeting minutes, planning notes, and memos"
                    " will all be organized here."
                ),
                "service_key": "joplin",
                "columns": [
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {"key": "content", "label": "Content", "type": "text", "sortable": False},
                ],
                "default_sort": "date",
                "default_sort_dir": "desc",
                "row_actions": [],
            },
            {
                "key": "intake",
                "label": "Intake",
                "icon": "fa-file-import",
                "type": "table",
                "source": "intake",
                "source_key": "intake_entries",
                "empty_message": (
                    "No documents scanned yet. Use 'Scan Document' above"
                    " or drag a file into the upload area to auto-classify"
                    " receipts, grant docs, invoices, and more."
                ),
                "columns": [
                    {
                        "key": "timestamp",
                        "label": "Date",
                        "type": "date",
                        "sortable": True,
                    },
                    {
                        "key": "content_type",
                        "label": "Type",
                        "type": "badge",
                        "sortable": True,
                    },
                    {
                        "key": "destination",
                        "label": "Routed To",
                        "type": "badge",
                        "sortable": True,
                    },
                    {
                        "key": "confidence",
                        "label": "Confidence",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "summary",
                        "label": "Summary",
                        "type": "text",
                        "sortable": False,
                    },
                ],
                "default_sort": "timestamp",
                "default_sort_dir": "desc",
                "row_actions": [],
            },
        ],
        "quick_actions": [
            {
                "key": "morning_briefing",
                "label": "Morning Briefing",
                "icon": "fa-sun",
                "mode": "agent",
                "prompt": (
                    "Give me my morning briefing — what donors need"
                    " thank-yous, upcoming grant deadlines, any emails"
                    " needing a reply, and today's calendar events."
                ),
            },
            {
                "key": "log_donation",
                "label": "Log Donation",
                "icon": "fa-hand-holding-dollar",
                "mode": "js",
                "js_fn": "npShowDonationModal",
            },
            {
                "key": "log_expense",
                "label": "Log Expense",
                "icon": "fa-receipt",
                "mode": "js",
                "js_fn": "npShowExpenseModal",
            },
            {
                "key": "add_donor",
                "label": "Add Donor",
                "icon": "fa-user-plus",
                "mode": "js",
                "js_fn": "npShowDonorModal",
            },
            {
                "key": "add_grant",
                "label": "Track Grant",
                "icon": "fa-file-contract",
                "mode": "js",
                "js_fn": "npShowGrantModal",
            },
            {
                "key": "search_grants",
                "label": "Find Federal Grants",
                "icon": "fa-magnifying-glass-dollar",
                "mode": "js",
                "js_fn": "npShowGrantSearchModal",
            },
            {
                "key": "sort_inbox",
                "label": "Sort Inbox",
                "icon": "fa-inbox",
                "mode": "agent",
                "prompt": (
                    "Triage my inbox — what emails need a reply?"
                    " Flag anything from donors, board members,"
                    " or grant program officers."
                ),
            },
            {
                "key": "review_pipeline",
                "label": "Review Inbox Pipeline",
                "icon": "fa-list-check",
                "mode": "agent",
                "prompt": (
                    "Review my inbox pipeline — show me pending"
                    " calendar events that need confirmation and"
                    " action items that need follow-up. Prioritize"
                    " anything urgent or time-sensitive."
                ),
            },
            {
                "key": "plan_event",
                "label": "Plan Event",
                "icon": "fa-calendar-star",
                "mode": "agent",
                "prompt": (
                    "I want to plan a new event. Ask me about the"
                    " event name, type, date, venue, and budget,"
                    " then create it with milestone tracking."
                ),
            },
            {
                "key": "track_bill",
                "label": "Track Bill",
                "icon": "fa-landmark",
                "mode": "agent",
                "prompt": (
                    "I need to track a legislative bill."
                    " Ask me for the bill number, title,"
                    " our position, and priority, then add"
                    " it to our advocacy tracker."
                ),
            },
            {
                "key": "stewardship_queue",
                "label": "Stewardship Queue",
                "icon": "fa-heart-pulse",
                "mode": "agent",
                "prompt": (
                    "Show me my stewardship queue — which donors"
                    " need thank-yous, phone calls, or follow-ups?"
                    " Prioritize anything overdue."
                ),
            },
            {
                "key": "annual_appeal",
                "label": "Annual Appeal",
                "icon": "fa-bullhorn",
                "mode": "agent",
                "prompt": (
                    "Help me create an annual appeal."
                    " Segment my active donors, draft the appeal"
                    " letter, and set up the batch send."
                ),
            },
            {
                "key": "lybunt_outreach",
                "label": "LYBUNT Outreach",
                "icon": "fa-user-clock",
                "mode": "agent",
                "prompt": (
                    "Show me lapsed donors (LYBUNT) who gave last"
                    " year but not this year. Help me draft a"
                    " reactivation campaign."
                ),
            },
            {
                "key": "scan_document",
                "label": "Scan Document",
                "icon": "fa-file-import",
                "mode": "agent",
                "prompt": (
                    "I want to scan a document. Ask me for the"
                    " file path or let me upload it, then run"
                    " smart_intake to classify and route it."
                ),
            },
            {
                "key": "import_donors",
                "label": "Import Donors",
                "icon": "fa-file-import",
                "mode": "js",
                "js_fn": "npShowImportModal",
            },
            {
                "key": "thank_you",
                "label": "Thank You Letters",
                "icon": "fa-envelope-open-text",
                "mode": "agent",
                "prompt": (
                    "Which donors need thank-you letters?"
                    " Show me anyone who gave recently but hasn't"
                    " been thanked yet, and help me draft the letters."
                ),
            },
            {
                "key": "board_packet",
                "label": "Board Packet",
                "icon": "fa-file-export",
                "mode": "agent",
                "prompt": (
                    "I need to prepare a board packet."
                    " Generate a summary with financials,"
                    " recent donations, grant status updates,"
                    " and any items needing board approval."
                ),
            },
            {
                "key": "grant_deadlines",
                "label": "Upcoming Deadlines",
                "icon": "fa-calendar-check",
                "mode": "agent",
                "prompt": (
                    "What deadlines are coming up?"
                    " Show me grant deadlines, report due dates,"
                    " and donor acknowledgment timelines."
                ),
            },
            {
                "key": "quick_note",
                "label": "Quick Note",
                "icon": "fa-pen",
                "mode": "js",
                "js_fn": "npShowNoteModal",
            },
            {
                "key": "export_990",
                "label": "990 Data Export",
                "icon": "fa-file-invoice",
                "mode": "agent",
                "prompt": (
                    "I need to prepare data for my 990 filing."
                    " Pull together income, expenses, donor counts,"
                    " and program spending for the fiscal year."
                ),
            },
        ],
    },
)

register_job_class(NONPROFIT_DIRECTOR)
