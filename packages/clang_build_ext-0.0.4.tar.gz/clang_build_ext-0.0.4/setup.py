#!/usr/bin/env python
#   -*- coding: utf-8 -*-

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'clang_build_ext',
        version = '0.0.4',
        description = 'Clang-based extension builder',
        long_description = '# Clang Build Extension\n\n[![Gitter](https://img.shields.io/gitter/room/karellen/lobby?logo=gitter)](https://gitter.im/karellen/Lobby)\n[![Build Status](https://img.shields.io/github/actions/workflow/status/karellen/clang-build-ext/build.yml?branch=master)](https://github.com/karellen/clang-build-ext/actions/workflows/build.yml)\n[![Coverage Status](https://img.shields.io/coveralls/github/karellen/clang-build-ext/master?logo=coveralls)](https://coveralls.io/r/karellen/clang-build-ext?branch=master)\n\n[![clang-build-ext Version](https://img.shields.io/pypi/v/clang-build-ext?logo=pypi)](https://pypi.org/project/clang-build-ext/)\n[![clang-build-ext Python Versions](https://img.shields.io/pypi/pyversions/clang-build-ext?logo=pypi)](https://pypi.org/project/clang-build-ext/)\n[![clang-build-ext Downloads Per Day](https://img.shields.io/pypi/dd/clang-build-ext?logo=pypi)](https://pypi.org/project/clang-build-ext/)\n[![clang-build-ext Downloads Per Week](https://img.shields.io/pypi/dw/clang-build-ext?logo=pypi)](https://pypi.org/project/clang-build-ext/)\n[![clang-build-ext Downloads Per Month](https://img.shields.io/pypi/dm/clang-build-ext?logo=pypi)](https://pypi.org/project/clang-build-ext/)\n\n## Overview\n\n`clang-build-ext` is a setuptools plugin that builds Python C/C++ extensions using the\n[LLVM/Clang](https://clang.llvm.org/) compiler toolchain instead of the system default compiler.\nEither a system-installed LLVM/Clang or the\n[`karellen-llvm-clang`](https://pypi.org/project/karellen-llvm-clang/) package can be used.\n\nThe plugin provides drop-in replacements for setuptools\' `build_ext` and `build_clib` commands,\nalong with features such as glob pattern expansion in source lists, Drakon IR bytecode embedding,\nand thin static library support.\n\n## Basic Usage\n\nAdd the following to your `setup.py`:\n\n```python\nfrom setuptools import setup, Extension\nfrom karellen.clang_build_ext import ClangBuildExt, ClangBuildClib\n\nsetup(\n    ...,\n    ext_modules=[Extension("myext", ["src/*.c"])],\n    cmdclass={\n        "build_ext": ClangBuildExt,\n        "build_clib": ClangBuildClib,\n    },\n)\n```\n\n## LLVM Toolchain\n\nThe compiler uses the full LLVM toolchain:\n\n| Tool         | Command                          |\n|--------------|----------------------------------|\n| C compiler   | `clang`                          |\n| C++ compiler | `clang-cpp`                      |\n| Linker       | `clang -fuse-ld=lld` / `clang-cpp -fuse-ld=lld` |\n| Archiver     | `llvm-ar`                        |\n| Objcopy      | `llvm-objcopy`                   |\n| Readelf      | `llvm-readelf`                   |\n\n## Features\n\n### Glob Pattern Expansion\n\nSource file lists in both extensions and libraries support shell glob patterns. Patterns are\nexpanded at build time, so you don\'t need to enumerate every source file in `setup.py`:\n\n```python\nsetup(\n    ...,\n    ext_modules=[\n        Extension("myext", ["src/module/*.c", "src/module/**/*.c"]),\n    ],\n    libraries=[\n        ("mylib", {"sources": ["src/lib/*.c", "src/lib/**/*.c"]}),\n    ],\n    cmdclass={\n        "build_ext": ClangBuildExt,\n        "build_clib": ClangBuildClib,\n    },\n)\n```\n\n### Drakon Enhancements\n\nDrakon mode embeds LLVM intermediate representation (IR) bytecode into compiled binaries as\ncustom ELF sections. This enables post-compilation IR analysis and transformation of the\nfinal binary.\n\nWhen enabled, the build:\n\n1. Compiles with `--save-temps=obj -fno-discard-value-names` to produce `.bc` (bitcode) files\n   alongside object files\n2. Includes `.bc` files in static libraries created via `build_clib`\n3. After linking, extracts `.bc` files from all linked objects and static libraries and embeds\n   them into the output binary as `.drakon.<name>` ELF sections (marked `noload,readonly`)\n\nEnable via command line or environment variable:\n\n```shell\n# Command line\npython setup.py build_ext --drakon\npython setup.py build_ext -d\n\n# Environment variable\nDRAKON=1 python setup.py build_ext\n```\n\n### Thin Static Libraries\n\nThin static libraries store references to object files rather than copies, reducing build\nartifact size during development.\n\nEnable via command line or environment variable:\n\n```shell\n# Command line\npython setup.py build_ext --thin\npython setup.py build_ext -T\n\n# Environment variable\nTHIN=1 python setup.py build_ext\n```\n\nBoth options can be combined:\n\n```shell\npython setup.py build_ext --drakon --thin\n```\n\nThe `build_clib` command inherits `drakon` and `thin` settings from `build_ext` automatically.\n\n## Setuptools Compatibility\n\n`clang-build-ext` maintains compatibility across setuptools versions, including the API changes\nin setuptools 75+ (new C++ compiler executables) and 82+ (removal of the `dry_run` parameter).\n',
        long_description_content_type = 'text/markdown',
        classifiers = [
            'Programming Language :: Python :: 3',
            'Programming Language :: Python :: 3.10',
            'Programming Language :: Python :: 3.11',
            'Programming Language :: Python :: 3.12',
            'Programming Language :: Python :: 3.13',
            'Programming Language :: Python :: 3.14',
            'Operating System :: POSIX :: Linux',
            'Topic :: System :: Archiving :: Packaging',
            'Topic :: Software Development :: Build Tools',
            'Intended Audience :: Developers',
            'Development Status :: 4 - Beta'
        ],
        keywords = 'setuptools extension cpythonclang c cpp cxx c++ compile',

        author = 'Karellen, Inc.',
        author_email = 'supervisor@karellen.co',
        maintainer = 'Arcadiy Ivanov',
        maintainer_email = 'arcadiy@karellen.co',

        license = 'Apache-2.0',

        url = 'https://github.com/karellen/clang-build-ext',
        project_urls = {
            'Bug Tracker': 'https://github.com/karellen/clang-build-ext/issues',
            'Documentation': 'https://github.com/karellen/clang-build-ext/',
            'Source Code': 'https://github.com/karellen/clang-build-ext/'
        },

        scripts = [],
        packages = ['karellen.clang_build_ext'],
        namespace_packages = [],
        py_modules = [],
        entry_points = {
            'distutils.commands': ['build_ext = karellen.clang_build_ext:ClangBuildExt']
        },
        data_files = [],
        package_data = {
            'karellen/clang_build_ext': ['LICENSE']
        },
        install_requires = [],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        python_requires = '>=3.10',
        obsoletes = [],
    )
