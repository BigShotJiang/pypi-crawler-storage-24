# ruff: noqa
# pylint: disable=missing-class-docstring

from hashlib import sha256
import subprocess


TEST_INPUT = """ # test 123
volumes: []
services:
  foo:
    restart: never
    image: alpine
    foo: "bar"

  bar:
    restart: never
    image: alpine
"""

TEST_OUTPUT_SHA256 = "543e035b0f3d051f03284070118a6747c83d33a63f8ec561da71d36c55bdc36c"


def create_test_file(tmp_path):
    """create testfile with TEST_INPUT as content"""
    testfile = tmp_path / "test.yaml"
    testfile.write_text(TEST_INPUT)


def sha256sum(string: str) -> str:
    """create sha256sum"""
    return sha256(string.encode()).hexdigest()


class TestCli:
    def test_run_stdout(self, tmp_path):
        """test cli with --stdout"""
        create_test_file(tmp_path)
        res = subprocess.check_output(
            f"python src/composefmt/cli.py --stdout {tmp_path}/test.yaml",
            shell=True,
            text=True,
        )
        assert sha256sum(res) == TEST_OUTPUT_SHA256

    def test_run_file_not_found(self, tmp_path):
        """test cli with missing file"""
        create_test_file(tmp_path)
        res = subprocess.run(
            f"python src/composefmt/cli.py --stdout {tmp_path}/test.yaml {tmp_path}/foo.yaml",
            shell=True,
            text=True,
        )
        assert res.returncode == 2

    def test_run_too_many_files(self, tmp_path):
        """test cli with too many files"""
        create_test_file(tmp_path)
        res = subprocess.run(
            f"python src/composefmt/cli.py --stdout {tmp_path}/test.yaml {tmp_path}/test.yaml",
            shell=True,
            text=True,
        )
        assert res.returncode == 2

    def test_run_stdin(self, tmp_path):
        """test cli with stdin input"""
        create_test_file(tmp_path)
        res = subprocess.check_output(
            f"python src/composefmt/cli.py <{tmp_path}/test.yaml",
            shell=True,
            text=True,
        )
        assert sha256sum(res) == TEST_OUTPUT_SHA256

    def test_run_pipe(self, tmp_path):
        """test cli with piped input"""
        create_test_file(tmp_path)
        res = subprocess.check_output(
            f"cat {tmp_path}/test.yaml | python src/composefmt/cli.py",
            shell=True,
            text=True,
        )
        assert sha256sum(res) == TEST_OUTPUT_SHA256

    def test_run_xargs(self, tmp_path):
        """test cli with parameters via xargs"""
        create_test_file(tmp_path)
        res = subprocess.check_output(
            f"echo {tmp_path}/test.yaml | xargs python src/composefmt/cli.py --stdout",
            shell=True,
            text=True,
        )
        assert sha256sum(res) == TEST_OUTPUT_SHA256

    def test_check_mode(self, tmp_path):
        """test cli check mode"""
        create_test_file(tmp_path)
        res = subprocess.run(
            f"python src/composefmt/cli.py --check {tmp_path}/test.yaml",
            shell=True,
            text=True,
        )
        assert res.returncode == 1

    def test_check_and_stdout_mutual_exclusive(self, tmp_path):
        """test cli check mode"""
        create_test_file(tmp_path)
        res = subprocess.run(
            f"python src/composefmt/cli.py --check {tmp_path}/test.yaml --stdout",
            shell=True,
            text=True,
        )
        assert res.returncode == 2

    def test_help(self):
        """test cli help output"""
        res = subprocess.check_output(
            "python src/composefmt/cli.py --help",
            shell=True,
            text=True,
        )
        assert "usage: cli.py" in res
