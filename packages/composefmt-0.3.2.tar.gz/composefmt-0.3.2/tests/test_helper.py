# ruff: noqa
# pylint: disable=missing-class-docstring,too-few-public-methods

from io import StringIO
from ruamel.yaml import YAML

from composefmt.lib import helper

TEST_CFG = """
top_level_order = ["name", "services"]
service_order = ["image"]
yaml_indent = 0
"""


class TestReadConfig:
    def test_config_defaults(self, monkeypatch):
        """Test read_config() with no config file"""
        monkeypatch.setenv("XDG_CONFIG_HOME", "/nonexistent")
        cfg = helper.read_config()
        assert cfg.top_level_order == helper.defaults.TOP_LEVEL_ORDER
        assert cfg.service_order == helper.defaults.SERVICE_ORDER
        assert cfg.yaml_indent == helper.defaults.YAML_INDENT

    def test_config_custom_values(self, monkeypatch, tmp_path):
        """Test read_config() with custom config file"""
        config_file = tmp_path / "composefmt.toml"
        config_file.write_text(TEST_CFG)
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
        cfg = helper.read_config()
        assert cfg.top_level_order == ["name", "services"]
        assert cfg.service_order == ["image"]
        assert cfg.yaml_indent == 0


class TestGenChecksum:
    def test_gen_checksum(self):
        """Test gen_checksum returns consistent checksum"""
        yaml = YAML()
        data = yaml.load("name: foo\nservices: {}")
        checksum = helper.gen_checksum(data)
        assert isinstance(checksum, str)
        assert len(checksum) == 64  # SHA-256 hash length
        assert (
            checksum
            == "55f28ad8080307a075af799d566ff1db42a1e7530363968660267ede8b59d129"
        )


class TestRemoveEmptyLines:
    def test_remove_empty_lines(self):
        """Test remove_empty_lines()"""
        content = "line1\n\nline2\n\n\nline3"
        filehandle = StringIO(content)
        result = helper.remove_empty_lines(filehandle)
        assert result == "line1\nline2\nline3"

    def test_remove_empty_lines_no_empty_lines(self):
        """Test remove_empty_lines() with no empty lines"""
        content = "line1\nline2\nline3"
        filehandle = StringIO(content)
        result = helper.remove_empty_lines(filehandle)
        assert result == content

    def test_remove_empty_lines_all_empty(self):
        """Test remove_empty_lines() with all empty lines"""
        content = "\n\n\n"
        filehandle = StringIO(content)
        result = helper.remove_empty_lines(filehandle)
        assert result == ""
