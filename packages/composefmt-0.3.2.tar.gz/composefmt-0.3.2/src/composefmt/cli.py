#! /usr/bin/env python3

# ruff: noqa: T201,UP015

# Author: Sebastian Mark
# CC-BY-SA-4.0 (https://creativecommons.org/licenses/by-sa/4.0/deed.de)

import argparse
import sys

from ruamel.yaml import YAML, parser

from composefmt import __version__
from composefmt.lib import helper


def reorder_items(data: YAML, preferred_order: list) -> None:
    """Reorder yaml items.

    arrange the keys of the passed yaml in preferred order
    additional keys will be appended in preserved order

    Args:
        data (YAML): yaml data
        preferred_order (list): list of keys in preferred order

    """
    # reverse preferred_order order and move the matching keys to the top,
    # so the remaining keys will drop down at the bottom
    for key in reversed(preferred_order):
        if key in data:
            data.move_to_end(key, last=False)


def format_yaml(data: YAML, top_level_order: list, service_order: list) -> bool:
    """Format passed yaml.

    sort all toplevel keys and sort keys in all services

    Args:
        data (YAML): data
        top_level_order (list): top level keys order
        service_order (list): service keys order

    Returns:
        bool: yaml changed

    """
    chksum_pre = helper.gen_checksum(data)

    # sort top level items
    reorder_items(data, top_level_order)
    # add empty line separators before every items
    for idx, key in enumerate(data):
        if idx > 0:
            data.yaml_set_comment_before_after_key(key, before="\n")

    # sort services keys
    services = data.get("services")
    if services:
        for service in services.values():
            reorder_items(service, service_order)
        # add empty line separators before every service
        for idx, service in enumerate(services):
            if idx > 0:
                services.yaml_set_comment_before_after_key(service, before="\n")

    chksum_post = helper.gen_checksum(data)

    return chksum_pre != chksum_post


def main() -> int:
    """main"""  # noqa
    cfg = helper.read_config()

    # yaml config (mostly for output)
    yaml = YAML(typ="rt")
    yaml.preserve_quotes = True
    yaml.width = float("inf")
    yaml.indent(
        mapping=cfg.yaml_indent,
        sequence=cfg.yaml_indent + 2,
        offset=cfg.yaml_indent,
    )

    # fmt: off
    ap = argparse.ArgumentParser()

    ap.add_argument("-v", "--version", action="version", version=f"%(prog)s v{__version__}")
    ap.add_argument("file", nargs="?", help="docker compose YAML file")

    group = ap.add_mutually_exclusive_group()
    group.add_argument("--stdout", action="store_true", help="output formatted file to stdout")  # noqa
    group.add_argument("--check", action="store_true", help="check mode; don't change any files")  # noqa
    # fmt: on

    args = ap.parse_args()

    # try STDIN if no files are passed
    if not args.file:
        file_content = helper.remove_empty_lines(sys.stdin)
        data = yaml.load(file_content)
        format_yaml(data, cfg.top_level_order, cfg.service_order)
        yaml.dump(data, sys.stdout)
        return 0

    # handle passed files
    filename = args.file
    try:
        with open(filename, "r", encoding="utf-8") as f:
            # load file content as yaml
            file_content = helper.remove_empty_lines(f)
            data = yaml.load(file_content)
    except (FileNotFoundError, parser.ParserError) as e:
        print(f"{filename}: {e}")
        return 1

    # format file content / yaml
    changed = format_yaml(data, cfg.top_level_order, cfg.service_order)

    # check mode enabled?
    if args.check:
        if changed:
            print(f"{filename} needs formatting 🔧")
        else:
            print(f"{filename} is already formatted 🎉")
        return changed

    # print or save
    if args.stdout:
        yaml.dump(data, sys.stdout)
    else:
        with open(args.file, "w", encoding="utf-8") as f:
            yaml.dump(data, f)
            if changed:
                print(f"{filename} formatted and written 💾")
            else:
                print(f"{filename} is already formatted 🎉")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
