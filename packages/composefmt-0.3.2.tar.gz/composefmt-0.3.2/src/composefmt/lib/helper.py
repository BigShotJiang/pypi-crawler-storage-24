import hashlib
import os
import tomllib
from types import SimpleNamespace
from typing import IO

from ruamel.yaml import YAML

from composefmt.lib import defaults


def read_config() -> SimpleNamespace:
    """Read config file.

    this function read the config file at "$XDG_CONFIG_HOME/composefmt.toml"
    the config file is merged with the defaults at `composefmt/lib/defaults.py`

    Args:
        None

    Returns:
        SimpleNamespace: config dict

    """
    # search for `composefmt.toml` file in $XDG_CONFIG_HOME
    configfile = (
        os.getenv("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
        + "/composefmt.toml"
    )

    # try to read file
    try:
        with open(configfile, "rb") as f:
            filedata = tomllib.load(f)
    except FileNotFoundError:
        filedata = {}

    # use config file entries or defaults
    cfg = {}
    cfg["top_level_order"] = filedata.get("top_level_order", defaults.TOP_LEVEL_ORDER)
    cfg["service_order"] = filedata.get("service_order", defaults.SERVICE_ORDER)
    cfg["yaml_indent"] = filedata.get("yaml_indent", defaults.YAML_INDENT)

    return SimpleNamespace(**cfg)


def gen_checksum(data: YAML) -> hashlib:
    """Generate checksum for yaml data.

    Args:
        data (YAML): yaml

    Returns:
        hashlib: sha256 string

    """
    return hashlib.sha256(str(data).encode()).hexdigest()


def remove_empty_lines(filehandle: IO[str]) -> str:
    """Remove empty lines from content.

    Args:
        filehandle (IO[str]): filehandle

    Returns:
        str:

    """
    stripped_content = ""
    for line in filehandle:
        if line.strip():
            stripped_content += line
    return stripped_content
