TOP_LEVEL_ORDER = [
    "name",
    "services",
    "volumes",
    "secrets",
    "configs",
    "networks",
]

SERVICE_ORDER = [
    "image",
    "build",
    "command",
    "entrypoint",
    "restart",
    "user",
    "privileged",
    "cap_add",
    "sysctls",
    "ports",
    "networks",
    "volumes",
    "configs",
    "env_file",
    "environment",
    "healthcheck",
    "labels",
    "depends_on",
]

YAML_INDENT = 2
