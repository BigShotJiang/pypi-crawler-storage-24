from typing import Dict, List, Any
import subprocess
import json
import os

from boto3 import Session

from hmd_cli_tools.hmd_cli_tools import (
    make_standard_name,
    get_secret_cache,
    get_cached_secret,
)


def get_neptune_endpoint(
    session: Session,
    instance_name: str,
    repo_name: str,
    deployment_id: str,
    environment: str,
    hmd_region: str,
    customer_code: str,
):
    client = session.client("neptune")
    cluster_identifier = f"{make_standard_name(instance_name, repo_name, deployment_id, environment, hmd_region, customer_code)}-cluster"
    cluster_info = client.describe_db_cluster_endpoints(
        DBClusterIdentifier=cluster_identifier.replace("_", "-"),
        Filters=[{"Name": "db-cluster-endpoint-type", "Values": ["writer"]}],
    )
    return cluster_info["DBClusterEndpoints"][0]["Endpoint"]


def get_neptune_security_group(
    session: Session,
    instance_name: str,
    repo_name: str,
    deployment_id: str,
    environment: str,
    hmd_region: str,
    customer_code: str,
):
    client = session.client("neptune")
    cluster_identifier = f"{make_standard_name(instance_name, repo_name, deployment_id, environment, hmd_region, customer_code)}-cluster"
    cluster_info = client.describe_db_clusters(
        DBClusterIdentifier=cluster_identifier.replace("_", "-")
    )
    return cluster_info["DBClusters"][0]["VpcSecurityGroups"][0]["VpcSecurityGroupId"]


class DeploymentConfig:
    def __init__(self, config: Dict):
        self.config = config

    def __getitem__(self, path: str) -> Any:
        value = self._do_get_value(path)
        if not value:
            raise KeyError(path)
        return value

    def __contains__(self, item):
        return self.get(item) is not None

    def get(self, path, default=None) -> Any:
        value = self._do_get_value(path)
        if value is None:
            return default
        else:
            return value

    def _do_get_value(self, path):
        in_path = path
        details = self.config.get("details", {})

        def do_get_config_value(
            config: Dict, path: List[str], parent: str = "__base__"
        ):
            if len(path) == 1:
                field = path[0]
                if field in config:
                    return config[field]
                elif parent != "__base__" and field in details.get(parent, {}):
                    return details.get(parent)[field]
                elif field in config["dependencies"]:
                    # it is valid to have a list of dependencies of a given type...
                    dependencies = config["dependencies"][field]
                    if isinstance(dependencies, dict):
                        dependencies = [dependencies]
                    new_configs = []
                    for dependency in dependencies:
                        new_config = {key: value for key, value in dependency.items()}
                        field_config = dependency["instance_name"]
                        for key in details[field_config]:
                            new_config[key] = details[field_config][key]
                        new_config["details"] = details
                        new_configs.append(DeploymentConfig(new_config))
                    return new_configs if len(new_configs) > 1 else new_configs[0]
                else:
                    return None
            else:
                dependency = path[0]
                if dependency in config["dependencies"]:
                    return do_get_config_value(
                        config["dependencies"][dependency],
                        path[1:],
                        config["dependencies"][dependency]["instance_name"],
                    )
                else:
                    return None

        return do_get_config_value(self.config, path.split("."))


def db_secret_name_from_dependencies(
    dp_config: DeploymentConfig, environment, hmd_region, customer_code
):
    standard_name = make_standard_name(
        instance_name=dp_config["database-instance.instance_name"],
        repo_name=dp_config["database-instance.repo_name"],
        deployment_id=dp_config["database-instance.deployment_id"],
        environment=environment,
        hmd_region=hmd_region,
        customer_code=customer_code,
    )
    return f"{standard_name}_{dp_config['db_name']}"


def get_credentials_secret(
    dp_config: DeploymentConfig,
    environment,
    hmd_region,
    customer_code,
    session: Session,
):
    standard_name = make_standard_name(
        instance_name=dp_config["instance_name"],
        repo_name=dp_config["repo_name"],
        deployment_id=dp_config["deployment_id"],
        environment=environment,
        hmd_region=hmd_region,
        customer_code=customer_code,
    )

    secret_name = dp_config.get("secret_name", standard_name)
    secret = get_cached_secret(get_secret_cache(session), secret_name)

    username_prop = dp_config.get("secret_keys.username", "username")
    password_prop = dp_config.get("secret_keys.password", "password")

    return {
        "username": secret.get(username_prop),
        "password": secret.get(password_prop),
    }


class TerraformStateMigrator:
    """
    Helper class to migrate Terraform state when resource IDs change.

    This is particularly useful when upgrading CDKTF versions that change
    how logical IDs are assigned to resources, especially within Terraform modules.

    Usage in your CdkTfStack class:

        def do_migrate_state(self):
            migrator = TerraformStateMigrator()

            # Auto-detect and migrate all module ID changes
            migrator.auto_detect_module_migrations()

            # Or manually specify migrations if needed
            migrator.add_module_migration(
                old_module_address="module.my_eks",
                new_module_address="module.my_eks_new_id"
            )

            # Execute all migrations
            migrator.execute()
    """

    def __init__(self):
        self.migrations: List[Dict[str, str]] = []
        self.tf_binary = os.environ.get("TERRAFORM_BINARY_NAME", "terraform")

    def add_resource_migration(self, old_address: str, new_address: str):
        """
        Add a migration for a single resource.

        Args:
            old_address: The old Terraform resource address (e.g., "aws_s3_bucket.my_bucket")
            new_address: The new Terraform resource address
        """
        self.migrations.append({
            "old": old_address,
            "new": new_address,
            "type": "resource"
        })

    def add_module_migration(self, old_module_address: str, new_module_address: str):
        """
        Add a migration for an entire module and all its resources.

        Args:
            old_module_address: The old module address (e.g., "module.my_eks")
            new_module_address: The new module address
        """
        self.migrations.append({
            "old": old_module_address,
            "new": new_module_address,
            "type": "module"
        })

    def _get_state_resources(self) -> List[Dict[str, Any]]:
        """Get all resources from the current Terraform state."""
        try:
            result = subprocess.run(
                [self.tf_binary, "state", "list"],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip().split("\n") if result.stdout.strip() else []
        except subprocess.CalledProcessError as e:
            print(f"Warning: Could not list Terraform state: {e.stderr}")
            return []

    def _resource_exists_in_state(self, address: str) -> bool:
        """Check if a resource exists in the Terraform state."""
        resources = self._get_state_resources()
        return address in resources

    def _migrate_resource(self, old_address: str, new_address: str):
        """Migrate a single resource in the Terraform state."""
        if not self._resource_exists_in_state(old_address):
            print(f"  Skipping: {old_address} not found in state")
            return

        if self._resource_exists_in_state(new_address):
            print(f"  Skipping: {new_address} already exists in state")
            return

        print(f"  Migrating: {old_address} -> {new_address}")
        try:
            subprocess.run(
                [self.tf_binary, "state", "mv", old_address, new_address],
                capture_output=True,
                text=True,
                check=True
            )
            print(f"  ✓ Successfully migrated {old_address}")
        except subprocess.CalledProcessError as e:
            print(f"  ✗ Failed to migrate {old_address}: {e.stderr}")

    def _migrate_module(self, old_module: str, new_module: str):
        """Migrate all resources within a module."""
        print(f"\nMigrating module: {old_module} -> {new_module}")

        resources = self._get_state_resources()
        module_resources = [r for r in resources if r.startswith(old_module + ".")]

        if not module_resources:
            print(f"  No resources found in module {old_module}")
            return

        print(f"  Found {len(module_resources)} resources to migrate")

        for old_resource in module_resources:
            new_resource = old_resource.replace(old_module, new_module, 1)
            self._migrate_resource(old_resource, new_resource)

    def _extract_module_name(self, address: str) -> str:
        """Extract module name from a resource address."""
        if not address.startswith("module."):
            return None

        # Handle nested modules: module.foo.module.bar.resource -> module.foo
        parts = address.split(".")
        if len(parts) >= 2:
            return f"{parts[0]}.{parts[1]}"
        return None

    def _strip_random_suffix(self, module_name: str) -> str:
        """
        Strip random suffix from module name.

        CDKTF generates random suffixes like: module.my_eks_A1B2C3D4
        This returns: my_eks
        """
        if not module_name.startswith("module."):
            return module_name

        # Remove "module." prefix
        base_name = module_name[7:]

        # Check if it ends with underscore followed by 8 alphanumeric characters (typical CDKTF pattern)
        if len(base_name) > 9 and base_name[-9] == "_":
            potential_suffix = base_name[-8:]
            if potential_suffix.isalnum():
                return base_name[:-9]

        return base_name

    def _find_matching_module_pair(self, old_module: str, new_modules: List[str]) -> str:
        """
        Find the matching new module for an old module by comparing base names.

        Args:
            old_module: Old module address (e.g., "module.my_eks_A1B2C3D4")
            new_modules: List of potential new module addresses

        Returns:
            The matching new module address, or None if no match found
        """
        old_base = self._strip_random_suffix(old_module)

        for new_module in new_modules:
            new_base = self._strip_random_suffix(new_module)
            if old_base == new_base:
                return new_module

        return None

    def _get_config_modules(self) -> List[str]:
        """Get modules defined in the Terraform configuration (cdk.tf.json)."""
        config_modules = []

        # Look for cdk.tf.json in current directory
        config_file = "cdk.tf.json"
        if not os.path.exists(config_file):
            return config_modules

        try:
            with open(config_file, 'r') as f:
                config_data = json.load(f)

            # Modules are defined under "module" key
            if "module" in config_data:
                for module_name in config_data["module"].keys():
                    config_modules.append(f"module.{module_name}")

        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Could not read Terraform configuration: {e}")

        return config_modules

    def auto_detect_module_migrations(self, dry_run: bool = False) -> List[Dict[str, str]]:
        """
        Automatically detect module ID changes by comparing state with configuration.

        This compares modules in the current state with modules in the synthesized
        configuration, and identifies migrations needed based on matching base names.

        This method is faster and more reliable than analyzing the plan, as it
        simply compares what's in the state with what CDKTF has generated.

        Args:
            dry_run: If True, only detect migrations without adding them

        Returns:
            List of detected migrations
        """
        print("\n🔍 Auto-detecting module ID changes...")

        # Get current state modules
        state_resources = self._get_state_resources()
        state_modules = set()
        for resource in state_resources:
            module = self._extract_module_name(resource)
            if module:
                state_modules.add(module)

        if not state_modules:
            print("  No modules found in current state")
            return []

        print(f"  Found {len(state_modules)} module(s) in current state:")
        for mod in sorted(state_modules):
            print(f"    - {mod}")

        # Get modules from the synthesized configuration
        config_modules = self._get_config_modules()

        if not config_modules:
            print("  No modules found in synthesized configuration")
            return []

        print(f"\n  Found {len(config_modules)} module(s) in synthesized config:")
        for mod in sorted(config_modules):
            print(f"    + {mod}")

        # Find matching pairs by comparing base names
        detected_migrations = []
        config_modules_set = set(config_modules)

        for old_module in sorted(state_modules):
            # Skip if the module name hasn't changed
            if old_module in config_modules_set:
                continue

            # Try to find a matching new module based on base name
            matching_new = self._find_matching_module_pair(old_module, config_modules)

            if matching_new and matching_new != old_module:
                migration = {
                    "old": old_module,
                    "new": matching_new,
                    "type": "module"
                }
                detected_migrations.append(migration)

                if not dry_run:
                    self.migrations.append(migration)

                print(f"\n  ✓ Detected migration: {old_module} -> {matching_new}")

        if not detected_migrations:
            print("\n  No module migrations detected")
        else:
            print(f"\n  Total migrations detected: {len(detected_migrations)}")

        return detected_migrations

    def execute(self):
        """Execute all pending migrations."""
        if not self.migrations:
            print("No migrations to execute")
            return

        print(f"\n{'='*60}")
        print(f"Executing Terraform State Migrations")
        print(f"{'='*60}\n")

        for migration in self.migrations:
            if migration["type"] == "module":
                self._migrate_module(migration["old"], migration["new"])
            else:
                self._migrate_resource(migration["old"], migration["new"])

        print(f"\n{'='*60}")
        print(f"Migration Complete")
        print(f"{'='*60}\n")


def create_module_id_migration_map(old_construct_id: str, new_construct_id: str) -> Dict[str, str]:
    """
    Helper function to create a migration map for module ID changes.

    When CDKTF changes how it generates logical IDs, this helps you identify
    what migrations are needed.

    Args:
        old_construct_id: The old construct ID used when creating the module
        new_construct_id: The new construct ID (often with sanitized characters)

    Returns:
        A dictionary with migration information

    Example:
        # If you created a module with ID "my_eks" and CDKTF now generates "my-eks"
        migration_map = create_module_id_migration_map("my_eks", "my-eks")
        # Returns: {"old_module": "module.my_eks", "new_module": "module.my-eks"}
    """
    return {
        "old_module": f"module.{old_construct_id}",
        "new_module": f"module.{new_construct_id}"
    }
