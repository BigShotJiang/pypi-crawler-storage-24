import logging
from datetime import datetime, timezone

from boto3 import Session

logger = logging.getLogger(__name__)


def get_rds_cluster_identifier(base_name: str) -> str:
    """Convert a standard base_name to an RDS-compatible cluster identifier.

    RDS cluster identifiers use hyphens, not underscores.

    :param base_name: The standard name (may contain underscores)
    :return: Hyphenated cluster identifier
    """
    return base_name.replace("_", "-")


def get_current_engine_version(session: Session, cluster_id: str) -> str:
    """Get the current engine version of an RDS cluster.

    :param session: A boto3 session with RDS access
    :param cluster_id: The RDS cluster identifier
    :return: The engine version string, or None if cluster doesn't exist
    """
    client = session.client("rds")
    try:
        response = client.describe_db_clusters(DBClusterIdentifier=cluster_id)
        clusters = response.get("DBClusters", [])
        if clusters:
            return clusters[0]["EngineVersion"]
        return None
    except client.exceptions.DBClusterNotFoundFault:
        return None


def is_major_version_upgrade(current: str, target: str) -> bool:
    """Determine if a version change constitutes a major version upgrade.

    Compares the integer portion before the first dot.

    :param current: Current engine version (e.g., "14.6")
    :param target: Target engine version (e.g., "16.4")
    :return: True if this is a major version upgrade
    """
    current_major = int(current.split(".")[0])
    target_major = int(target.split(".")[0])
    return target_major > current_major


def create_cluster_snapshot(
    session: Session,
    cluster_id: str,
    snapshot_id: str,
    tags: dict = None,
    wait: bool = True,
    timeout: int = 1800,
) -> str:
    """Create a manual RDS cluster snapshot.

    :param session: A boto3 session with RDS access
    :param cluster_id: The RDS cluster identifier
    :param snapshot_id: The snapshot identifier to create
    :param tags: Optional tags to apply to the snapshot
    :param wait: Whether to wait for snapshot completion
    :param timeout: Maximum seconds to wait for completion
    :return: The snapshot ARN
    """
    client = session.client("rds")

    create_kwargs = {
        "DBClusterIdentifier": cluster_id,
        "DBClusterSnapshotIdentifier": snapshot_id,
    }
    if tags:
        create_kwargs["Tags"] = [{"Key": k, "Value": v} for k, v in tags.items()]

    logger.info(f"Creating snapshot {snapshot_id} for cluster {cluster_id}")
    response = client.create_db_cluster_snapshot(**create_kwargs)
    snapshot_arn = response["DBClusterSnapshot"]["DBClusterSnapshotArn"]

    if wait:
        logger.info(
            f"Waiting for snapshot {snapshot_id} to complete (timeout: {timeout}s)"
        )
        waiter = client.get_waiter("db_cluster_snapshot_available")
        waiter.wait(
            DBClusterSnapshotIdentifier=snapshot_id,
            WaiterConfig={"Delay": 15, "MaxAttempts": timeout // 15},
        )
        logger.info(f"Snapshot {snapshot_id} is available")

    return snapshot_arn


def _get_pg8000():
    """Lazily import pg8000, returning None if not installed."""
    try:
        import pg8000

        return pg8000
    except ImportError:
        return None


def get_all_database_names(host: str, port: int, user: str, password: str) -> list:
    """Get all non-template database names from a PostgreSQL cluster.

    :param host: Database host
    :param port: Database port
    :param user: Database user
    :param password: Database password
    :return: List of database names
    :raises ImportError: If pg8000 is not installed
    """
    pg8000 = _get_pg8000()
    if pg8000 is None:
        raise ImportError("pg8000 is required for database row count operations")

    conn = pg8000.connect(
        host=host, port=port, user=user, password=password, database="postgres"
    )
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT datname FROM pg_database "
            "WHERE datistemplate = false AND datname != 'rdsadmin'"
        )
        return [row[0] for row in cursor.fetchall()]
    finally:
        conn.close()


def get_row_counts(
    host: str, port: int, user: str, password: str, databases: list
) -> dict:
    """Get approximate row counts for all user tables across databases.

    Uses pg_stat_user_tables.n_live_tup for fast approximate counts
    without full table scans.

    :param host: Database host
    :param port: Database port
    :param user: Database user
    :param password: Database password
    :param databases: List of database names to query
    :return: Dict of {db_name: {schema.table: count}}
    """
    pg8000 = _get_pg8000()
    if pg8000 is None:
        raise ImportError("pg8000 is required for database row count operations")

    counts = {}
    for db_name in databases:
        db_counts = {}
        try:
            conn = pg8000.connect(
                host=host, port=port, user=user, password=password, database=db_name
            )
            try:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT schemaname, relname, n_live_tup "
                    "FROM pg_stat_user_tables ORDER BY schemaname, relname"
                )
                for schema, table, n_live_tup in cursor.fetchall():
                    db_counts[f"{schema}.{table}"] = n_live_tup
            finally:
                conn.close()
        except Exception as e:
            logger.warning(f"Could not get row counts for database {db_name}: {e}")
        counts[db_name] = db_counts

    return counts


def compare_row_counts(before: dict, after: dict, tolerance_pct: float = 0.0) -> tuple:
    """Compare pre- and post-upgrade row counts.

    :param before: Row counts from before the upgrade
    :param after: Row counts from after the upgrade
    :param tolerance_pct: Allowed deviation percentage (0.0 = exact match)
    :return: Tuple of (passed: bool, mismatches: list[str])
    """
    mismatches = []

    all_dbs = set(list(before.keys()) + list(after.keys()))
    for db_name in sorted(all_dbs):
        before_tables = before.get(db_name, {})
        after_tables = after.get(db_name, {})

        all_tables = set(list(before_tables.keys()) + list(after_tables.keys()))
        for table in sorted(all_tables):
            before_count = before_tables.get(table, 0)
            after_count = after_tables.get(table, 0)

            if before_count == 0 and after_count == 0:
                continue

            if before_count == 0:
                mismatches.append(
                    f"{db_name}.{table}: new table with {after_count} rows (not in pre-upgrade)"
                )
                continue

            if after_count == 0 and table not in after_tables:
                mismatches.append(
                    f"{db_name}.{table}: table missing post-upgrade (had {before_count} rows)"
                )
                continue

            if tolerance_pct > 0.0:
                deviation = abs(after_count - before_count) / before_count * 100
                if deviation > tolerance_pct:
                    mismatches.append(
                        f"{db_name}.{table}: {before_count} -> {after_count} "
                        f"({deviation:.1f}% deviation, tolerance: {tolerance_pct}%)"
                    )
            else:
                if before_count != after_count:
                    mismatches.append(
                        f"{db_name}.{table}: {before_count} -> {after_count}"
                    )

    passed = len(mismatches) == 0
    return passed, mismatches


def generate_snapshot_id(
    cluster_id: str, current_version: str, target_version: str
) -> str:
    """Generate a descriptive snapshot identifier for a major version upgrade.

    :param cluster_id: The RDS cluster identifier
    :param current_version: Current engine version
    :param target_version: Target engine version
    :return: A snapshot identifier string
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    # RDS snapshot IDs: lowercase, hyphens, max 255 chars
    return f"{cluster_id}-pre-upgrade-{current_version}-to-{target_version}-{timestamp}".replace(
        ".", "-"
    )
