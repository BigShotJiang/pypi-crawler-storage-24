# clibib
[![CI](https://github.com/delip/clibib/actions/workflows/ci.yml/badge.svg)](https://github.com/delip/clibib/actions/workflows/ci.yml)

<!--
<img width="2816" height="1536" alt="image" src="https://github.com/user-attachments/assets/bed7c6f8-f5fb-46da-8d4a-2df5b9c1baad" />
-->

<p align="center">
<img width="600" height="470" alt="image" src="https://github.com/user-attachments/assets/0c60331c-dbbd-4ada-92c6-c2df952177cb" />
</p>
A Python-based CLI tool to fetch BibTeX entries from a URL, ISBN, DOI, PMID, arXiv, alphaxiv, huggingface papers, or even just the paper title!



## Installation

```bash
pip install clibib
```

## Usage

```bash
# Fetch BibTeX from a DOI
clibib 10.1038/nature12373

# From an arXiv ID
clibib 2301.07041

# From a URL
clibib https://academic.oup.com/bib/article/25/1/bbad467/7512647

# From an ISBN
clibib 978-0-13-468599-1

# Save BibTeX to a file
clibib -o ~/bibs 10.1038/nature12373

# Title search (less reliable — prefer DOI, arXiv ID, or URL when possible)
clibib "Attention is all you need"

# Only output the best match
clibib --first "Attention is all you need"
```

> **Note:** Title-based searches rely on CrossRef and Zotero databases, which can return incomplete or incorrect matches. For reliable results, use a DOI, arXiv ID, or URL. If you only have a title, search the web for the paper's DOI first.

## Agent Skill

clibib includes an [Agent Skill](https://agentskills.io) for fetching citations through natural language or the `/clibib` slash command. Works with any agent that supports the open standard — Claude Code, Codex CLI, Gemini CLI, OpenHands, GitHub Copilot, and [others](https://agentskills.io).

**Install (Claude Code example):**

```bash
cp -r skill/clibib ~/.claude/skills/clibib
```

**Usage:**

```
Get me the bibtex for 10.1038/nature12373
/clibib 2301.07041
```

See [skill/README.md](skill/README.md) for full details.

## Development

```bash
pip install -e ".[dev]"
pytest
```
