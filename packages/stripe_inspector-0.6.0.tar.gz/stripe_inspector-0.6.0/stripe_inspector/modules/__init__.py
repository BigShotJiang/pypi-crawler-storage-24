"""Stripe inspection modules."""
