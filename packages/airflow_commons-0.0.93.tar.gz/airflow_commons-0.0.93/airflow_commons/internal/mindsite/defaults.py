from datetime import date


def get_default_date() -> str:
    """
    Returns today's date in YYYY-MM-DD format.

    :return: Today's date as string
    """
    return date.today().strftime("%Y-%m-%d")
