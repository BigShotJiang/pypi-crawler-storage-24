from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="iam2excel",
    version="1.0.0",
    author="Your Name",
    description="Convert AWS IAM policy JSON files into beautifully formatted Excel workbooks",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "openpyxl>=3.1.0",
    ],
    entry_points={
        "console_scripts": [
            "iam2excel=iam2excel.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Utilities",
    ],
)
