# iam2excel

Convert AWS IAM policy JSON files into beautifully formatted Excel (`.xlsx`) workbooks.

## Install

```bash
pip install iam2excel
```

Or install directly from source:

```bash
pip install .
```

---

## CLI Usage

```bash
iam2excel path/to/policy.json
# → writes policy.xlsx next to the JSON file

iam2excel path/to/policy.json -o /tmp/my_report.xlsx
```

---

## Python API

```python
from iam2excel import convert

# from a file path
out = convert("my_policy.json")
print(out)  # /absolute/path/to/my_policy.xlsx

# custom output path
out = convert("my_policy.json", output_path="reports/iam_audit.xlsx")

# from a dict (already parsed)
import json
policy = json.load(open("policy.json"))
out = convert(policy, output_path="audit.xlsx")
```

---

## Excel Workbook Structure

The output workbook contains **4 sheets**:

| Sheet | Contents |
|---|---|
| **Policy Summary** | Version, ID, statement count table |
| **Permissions Detail** | Every action × resource row, colour-coded by Effect |
| **By Service** | Actions grouped by AWS service (s3, iam, ec2 …) |
| **Actions Index** | All unique actions sorted A→Z with their Sids & resources |

### Colour legend

| Colour | Meaning |
|---|---|
| 🟢 Green | `Allow` effect |
| 🟠 Orange | `Deny` effect |
| 🟡 Amber | Row has a Condition or Principal |
| 🔵 Blue (light) | Alternating Sid groups |

---

## Example IAM JSON

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowS3ReadOnly",
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:ListBucket"],
      "Resource": ["arn:aws:s3:::my-bucket", "arn:aws:s3:::my-bucket/*"],
      "Condition": {
        "StringEquals": { "aws:RequestedRegion": "us-east-1" }
      }
    },
    {
      "Sid": "DenyDelete",
      "Effect": "Deny",
      "Action": "s3:DeleteObject",
      "Resource": "*"
    }
  ]
}
```
