import json
import re
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter
from openpyxl.styles.numbers import FORMAT_TEXT


# ── Colour palette ────────────────────────────────────────────────────────────
DARK_NAVY    = "1B2A47"
MID_BLUE     = "2E4A7A"
ACCENT_BLUE  = "4472C4"
LIGHT_BLUE   = "D6E4F0"
LIGHTER_BLUE = "EBF3FB"
MINT_GREEN   = "E2EFDA"
AMBER        = "FFF2CC"
ORANGE       = "FCE4D6"
WHITE        = "FFFFFF"
GREY_BORDER  = "B8C8D8"
TEXT_DARK    = "1A1A2E"
TEXT_MID     = "2C3E6B"


def _border(color=GREY_BORDER, style="thin"):
    s = Side(border_style=style, color=color)
    return Border(left=s, right=s, top=s, bottom=s)


def _fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)


def _font(bold=False, color=TEXT_DARK, size=10, italic=False):
    return Font(name="Segoe UI", bold=bold, color=color, size=size, italic=italic)


def _align(h="left", v="top", wrap=True):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)


# ── JSON helpers ──────────────────────────────────────────────────────────────

def _load_policy(source):
    if isinstance(source, (str, Path)):
        with open(source, "r", encoding="utf-8") as f:
            return json.load(f)
    if isinstance(source, dict):
        return source
    raise TypeError("source must be a file path or dict")


def _ensure_list(val):
    if val is None:
        return []
    return val if isinstance(val, list) else [val]


def _fmt_list(val, sep="\n"):
    items = _ensure_list(val)
    return sep.join(str(i) for i in items) if items else "—"


def _fmt_condition(cond):
    if not cond:
        return "—"
    lines = []
    for op, kv in cond.items():
        for key, val in kv.items():
            v = ", ".join(_ensure_list(val))
            lines.append(f"{op}  {key}  =  {v}")
    return "\n".join(lines)


def _fmt_principal(principal):
    if not principal:
        return "—"
    if isinstance(principal, str):
        return principal
    lines = []
    for k, v in principal.items():
        lines.append(f"{k}: {_fmt_list(v)}")
    return "\n".join(lines)


# ── Parse statements ──────────────────────────────────────────────────────────

def _parse_statements(policy):
    stmts = _ensure_list(policy.get("Statement", []))
    rows = []
    for idx, stmt in enumerate(stmts, 1):
        sid        = stmt.get("Sid", f"Statement{idx}")
        effect     = stmt.get("Effect", "Allow")
        principal  = _fmt_principal(stmt.get("Principal"))
        not_princ  = _fmt_principal(stmt.get("NotPrincipal"))
        actions    = sorted(_ensure_list(stmt.get("Action", [])))
        not_acts   = sorted(_ensure_list(stmt.get("NotAction", [])))
        resources  = _ensure_list(stmt.get("Resource", []))
        not_res    = _ensure_list(stmt.get("NotResource", []))
        condition  = _fmt_condition(stmt.get("Condition"))

        display_actions   = actions   or not_acts
        action_label      = "Action" if actions else ("NotAction" if not_acts else "Action")
        display_resources = resources or not_res
        resource_label    = "Resource" if resources else ("NotResource" if not_res else "Resource")

        for action in display_actions:
            service, _, action_name = action.partition(":")
            for resource in (display_resources or ["—"]):
                rows.append({
                    "sid":            sid,
                    "effect":         effect,
                    "principal":      principal   if principal  != "—" else "",
                    "not_principal":  not_princ   if not_princ != "—" else "",
                    "action_label":   action_label,
                    "service":        service if action_name else "—",
                    "action":         action_name if action_name else service,
                    "full_action":    action,
                    "resource_label": resource_label,
                    "resource":       resource,
                    "condition":      condition,
                })
    return rows


# ── Sheet: Policy Summary ─────────────────────────────────────────────────────

def _write_summary(ws, policy):
    ws.title = "Policy Summary"

    # Banner
    ws.merge_cells("A1:F1")
    c = ws["A1"]
    c.value = "IAM Policy Summary"
    c.font  = Font(name="Segoe UI", bold=True, color=WHITE, size=16)
    c.fill  = _fill(DARK_NAVY)
    c.alignment = _align("center", "center")
    ws.row_dimensions[1].height = 36

    # Meta rows
    meta = [
        ("Policy Version",  policy.get("Version", "—")),
        ("Policy ID",       policy.get("Id", "—")),
        ("Statement Count", str(len(_ensure_list(policy.get("Statement", []))))),
    ]
    for r, (label, val) in enumerate(meta, 2):
        ws.row_dimensions[r].height = 20
        lc = ws.cell(row=r, column=1, value=label)
        vc = ws.cell(row=r, column=2, value=val)
        lc.font  = _font(bold=True, color=WHITE)
        lc.fill  = _fill(MID_BLUE)
        lc.alignment = _align("left", "center", wrap=False)
        vc.font  = _font(color=TEXT_DARK)
        vc.fill  = _fill(LIGHTER_BLUE)
        vc.alignment = _align("left", "center", wrap=False)
        for col in range(1, 3):
            ws.cell(row=r, column=col).border = _border()

    # Statement breakdown table
    stmts = _ensure_list(policy.get("Statement", []))
    hdr_row = 6
    ws.row_dimensions[hdr_row].height = 20
    headers = ["#", "Sid", "Effect", "Actions", "Resources", "Has Condition"]
    hdr_fills = [DARK_NAVY, DARK_NAVY, DARK_NAVY, DARK_NAVY, DARK_NAVY, DARK_NAVY]
    for col, (h, f) in enumerate(zip(headers, hdr_fills), 1):
        c = ws.cell(row=hdr_row, column=col, value=h)
        c.font      = _font(bold=True, color=WHITE)
        c.fill      = _fill(f)
        c.alignment = _align("center", "center", wrap=False)
        c.border    = _border()

    for i, stmt in enumerate(stmts, 1):
        r = hdr_row + i
        ws.row_dimensions[r].height = 18
        effect = stmt.get("Effect", "Allow")
        vals = [
            i,
            stmt.get("Sid", f"Statement{i}"),
            effect,
            len(_ensure_list(stmt.get("Action", stmt.get("NotAction", [])))),
            len(_ensure_list(stmt.get("Resource", stmt.get("NotResource", [])))),
            "Yes" if stmt.get("Condition") else "No",
        ]
        row_fill = MINT_GREEN if effect == "Allow" else ORANGE
        for col, val in enumerate(vals, 1):
            c = ws.cell(row=r, column=col, value=val)
            c.fill      = _fill(row_fill)
            c.font      = _font(color=TEXT_DARK)
            c.alignment = _align("center", "center", wrap=False)
            c.border    = _border()

    col_widths = [5, 30, 10, 12, 12, 16]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"


# ── Sheet: Permissions Detail ─────────────────────────────────────────────────

def _write_detail(ws, rows):
    ws.title = "Permissions Detail"

    # Banner
    ws.merge_cells("A1:J1")
    c = ws["A1"]
    c.value = "IAM Permissions — Detailed View"
    c.font  = Font(name="Segoe UI", bold=True, color=WHITE, size=14)
    c.fill  = _fill(DARK_NAVY)
    c.alignment = _align("center", "center")
    ws.row_dimensions[1].height = 32

    headers = [
        "Sid", "Effect", "Service", "Action", "Full Action",
        "Resource", "Principal", "Not Principal", "Condition", "Notes"
    ]
    hdr_row = 2
    ws.row_dimensions[hdr_row].height = 22
    for col, h in enumerate(headers, 1):
        c = ws.cell(row=hdr_row, column=col, value=h)
        c.font      = _font(bold=True, color=WHITE, size=10)
        c.fill      = _fill(ACCENT_BLUE)
        c.alignment = _align("center", "center", wrap=False)
        c.border    = _border()

    prev_sid = None
    sid_start = 3
    sid_group_idx = 0
    sid_fills = [LIGHTER_BLUE, LIGHT_BLUE]

    for i, row in enumerate(rows, 3):
        sid = row["sid"]
        if sid != prev_sid:
            sid_group_idx += 1
            prev_sid = sid
        group_fill = sid_fills[sid_group_idx % 2]
        effect_fill = MINT_GREEN if row["effect"] == "Allow" else ORANGE

        vals = [
            row["sid"],
            row["effect"],
            row["service"],
            row["action"],
            row["full_action"],
            row["resource"],
            row["principal"]     or "—",
            row["not_principal"] or "—",
            row["condition"],
            "",
        ]
        fills = [
            group_fill, effect_fill, group_fill, group_fill, group_fill,
            group_fill, AMBER if row["principal"] else group_fill,
            AMBER if row["not_principal"] else group_fill,
            AMBER if row["condition"] != "—" else group_fill,
            WHITE,
        ]
        # Auto row height based on max newlines
        max_lines = max(v.count("\n") + 1 for v in vals if isinstance(v, str)) if any(isinstance(v, str) for v in vals) else 1
        ws.row_dimensions[i].height = max(18, min(max_lines * 15, 120))

        for col, (val, fill) in enumerate(zip(vals, fills), 1):
            c = ws.cell(row=i, column=col, value=val)
            c.fill      = _fill(fill)
            c.font      = _font(color=TEXT_DARK)
            c.alignment = _align("left", "top", wrap=True)
            c.border    = _border()

    col_widths = [28, 10, 18, 28, 40, 50, 30, 30, 50, 20]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = "A3"
    ws.auto_filter.ref = f"A2:{get_column_letter(len(headers))}2"


# ── Sheet: By Service ─────────────────────────────────────────────────────────

def _write_by_service(ws, rows):
    ws.title = "By Service"

    ws.merge_cells("A1:E1")
    c = ws["A1"]
    c.value = "Actions Grouped by AWS Service"
    c.font  = Font(name="Segoe UI", bold=True, color=WHITE, size=14)
    c.fill  = _fill(DARK_NAVY)
    c.alignment = _align("center", "center")
    ws.row_dimensions[1].height = 32

    # Group by service
    from collections import defaultdict
    svc_map = defaultdict(list)
    for row in rows:
        svc_map[row["service"]].append(row)

    hdr_row = 2
    ws.row_dimensions[hdr_row].height = 22
    headers = ["Service", "Action", "Effect", "Resource", "Condition"]
    for col, h in enumerate(headers, 1):
        c = ws.cell(row=hdr_row, column=col, value=h)
        c.font      = _font(bold=True, color=WHITE)
        c.fill      = _fill(ACCENT_BLUE)
        c.alignment = _align("center", "center", wrap=False)
        c.border    = _border()

    r = 3
    svc_colors = [LIGHTER_BLUE, LIGHT_BLUE]
    for svc_idx, (svc, svc_rows) in enumerate(sorted(svc_map.items())):
        svc_fill = svc_colors[svc_idx % 2]
        svc_start = r
        for row in sorted(svc_rows, key=lambda x: x["action"].lower()):
            effect_fill = MINT_GREEN if row["effect"] == "Allow" else ORANGE
            cond_fill   = AMBER if row["condition"] != "—" else svc_fill
            vals = [svc, row["action"], row["effect"], row["resource"], row["condition"]]
            fills = [svc_fill, svc_fill, effect_fill, svc_fill, cond_fill]
            max_lines = max(v.count("\n") + 1 for v in vals if isinstance(v, str))
            ws.row_dimensions[r].height = max(18, min(max_lines * 15, 100))
            for col, (val, fill) in enumerate(zip(vals, fills), 1):
                c = ws.cell(row=r, column=col, value=val)
                c.fill      = _fill(fill)
                c.font      = _font(color=TEXT_DARK)
                c.alignment = _align("left", "top", wrap=True)
                c.border    = _border()
            r += 1
        if r > svc_start + 1:
            ws.merge_cells(f"A{svc_start}:A{r-1}")
            mc = ws[f"A{svc_start}"]
            mc.alignment = _align("center", "center", wrap=False)
            mc.font = _font(bold=True, color=TEXT_DARK)

    col_widths = [20, 35, 10, 55, 50]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = "A3"
    ws.auto_filter.ref = "A2:E2"


# ── Sheet: Actions Index ──────────────────────────────────────────────────────

def _write_actions_index(ws, rows):
    ws.title = "Actions Index"

    ws.merge_cells("A1:D1")
    c = ws["A1"]
    c.value = "All IAM Actions — Alphabetical Index"
    c.font  = Font(name="Segoe UI", bold=True, color=WHITE, size=14)
    c.fill  = _fill(DARK_NAVY)
    c.alignment = _align("center", "center")
    ws.row_dimensions[1].height = 32

    hdr_row = 2
    ws.row_dimensions[hdr_row].height = 22
    for col, h in enumerate(["Full Action", "Effect", "Sid(s)", "Resource(s)"], 1):
        c = ws.cell(row=hdr_row, column=col, value=h)
        c.font      = _font(bold=True, color=WHITE)
        c.fill      = _fill(ACCENT_BLUE)
        c.alignment = _align("center", "center", wrap=False)
        c.border    = _border()

    # Deduplicate by (action, effect)
    from collections import defaultdict
    action_map = defaultdict(lambda: {"effects": set(), "sids": set(), "resources": set()})
    for row in rows:
        key = row["full_action"]
        action_map[key]["effects"].add(row["effect"])
        action_map[key]["sids"].add(row["sid"])
        action_map[key]["resources"].add(row["resource"])

    for i, (action, data) in enumerate(sorted(action_map.items(), key=lambda x: x[0].lower()), 3):
        effects   = sorted(data["effects"])
        sids      = sorted(data["sids"])
        resources = sorted(data["resources"])
        effect_str = ", ".join(effects)
        fill = MINT_GREEN if effects == ["Allow"] else ORANGE if effects == ["Deny"] else AMBER
        max_lines = max(len(sids), len(resources))
        ws.row_dimensions[i].height = max(18, min(max_lines * 14, 100))
        vals = [action, effect_str, "\n".join(sids), "\n".join(resources)]
        fills = [fill, fill, LIGHTER_BLUE, LIGHTER_BLUE]
        for col, (val, f) in enumerate(zip(vals, fills), 1):
            c = ws.cell(row=i, column=col, value=val)
            c.fill      = _fill(f)
            c.font      = _font(color=TEXT_DARK)
            c.alignment = _align("left", "top", wrap=True)
            c.border    = _border()

    col_widths = [45, 12, 35, 55]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = "A3"
    ws.auto_filter.ref = "A2:D2"


# ── Public API ────────────────────────────────────────────────────────────────

def convert(source, output_path=None):
    """
    Convert an IAM policy JSON to a formatted Excel workbook.

    Parameters
    ----------
    source : str | Path | dict
        Path to an IAM policy JSON file, or the policy dict itself.
    output_path : str | Path | None
        Destination .xlsx path.  Defaults to <source_stem>.xlsx
        (or iam_policy.xlsx when source is a dict).

    Returns
    -------
    Path
        Absolute path of the written .xlsx file.
    """
    policy = _load_policy(source)

    if output_path is None:
        if isinstance(source, (str, Path)):
            output_path = Path(source).with_suffix(".xlsx")
        else:
            output_path = Path("iam_policy.xlsx")
    output_path = Path(output_path)

    rows = _parse_statements(policy)

    wb = Workbook()
    # Remove default sheet
    del wb[wb.sheetnames[0]]

    _write_summary(wb.create_sheet(),    policy)
    _write_detail(wb.create_sheet(),     rows)
    _write_by_service(wb.create_sheet(), rows)
    _write_actions_index(wb.create_sheet(), rows)

    wb.save(output_path)
    return output_path.resolve()
