import argparse
import sys
from pathlib import Path
from .converter import convert


def main():
    parser = argparse.ArgumentParser(
        prog="iam2excel",
        description="Convert an AWS IAM policy JSON file to a pretty Excel (.xlsx) workbook.",
    )
    parser.add_argument(
        "input",
        help="Path to the IAM policy JSON file",
    )
    parser.add_argument(
        "-o", "--output",
        default=None,
        help="Output .xlsx file path (default: <input>.xlsx)",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: file not found — {input_path}", file=sys.stderr)
        sys.exit(1)

    out = convert(input_path, args.output)
    print(f"✅  Written → {out}")


if __name__ == "__main__":
    main()
