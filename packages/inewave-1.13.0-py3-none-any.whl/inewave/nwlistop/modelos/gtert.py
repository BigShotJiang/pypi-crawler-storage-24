from inewave.config import MESES_DF

from cfinterface.components.line import Line
from cfinterface.components.integerfield import IntegerField
from cfinterface.components.literalfield import LiteralField
from cfinterface.components.floatfield import FloatField

from inewave.nwlistop.modelos.blocos.valoresclassetermicaseriepatamar import (
    ValoresClasseTermicaSeriePatamar,
)


class GTAnos(ValoresClasseTermicaSeriePatamar):
    """
    Bloco com as informações das tabelas de geração térmica por classe.
    """

    __slots__: list[str] = []

    HEADER_LINE = Line([IntegerField(4, 10)])
    DATA_LINE = Line(
        [
            IntegerField(3, 2),
            IntegerField(4, 7),
            LiteralField(1, 15),
        ]
        + [FloatField(9, 16 + 9 * i, 1) for i in range(len(MESES_DF))]
    )
