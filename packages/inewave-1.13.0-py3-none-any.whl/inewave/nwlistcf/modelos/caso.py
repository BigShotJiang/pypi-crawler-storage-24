from cfinterface.components.section import Section
from cfinterface.components.line import Line
from cfinterface.components.literalfield import LiteralField
from typing import IO, Any, Optional


class NomeCaso(Section):
    """
    Bloco com o nome do caso do arquivo de
    entrada do NWLISTCF `caso.dat`.
    """

    __slots__ = ["__linha"]

    def __init__(
        self,
        previous: Optional[Any] = None,
        next: Optional[Any] = None,
        data: Optional[Any] = None,
    ) -> None:
        super().__init__(previous, next, data)
        self.__linha = Line([LiteralField(40, 0)])

    def __eq__(self, o: object) -> bool:
        if not isinstance(o, NomeCaso):
            return False
        bloco: NomeCaso = o
        if not all(
            [
                isinstance(self.data, str),
                isinstance(o.data, str),
            ]
        ):
            return False
        else:
            return self.data == bloco.data

    # Override
    def read(self, file: IO[Any], *args: Any, **kwargs: Any) -> None:  # type: ignore[override]  # signature extends base class
        self.data = self.__linha.read(file.readline())[0]

    # Override
    def write(self, file: IO[Any], *args: Any, **kwargs: Any) -> None:  # type: ignore[override]  # signature extends base class
        file.write(self.__linha.write([self.data]))
