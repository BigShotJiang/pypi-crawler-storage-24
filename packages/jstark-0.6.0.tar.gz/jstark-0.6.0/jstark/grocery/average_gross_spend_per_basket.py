"""AvgGrossSpendPerBasket feature"""

import pyspark.sql.functions as f
from pyspark.sql import Column

from jstark.features.feature import DerivedFeature
from jstark.features.gross_spend import GrossSpend
from .basket_count import BasketCount


class AvgGrossSpendPerBasket(DerivedFeature):
    def column_expression(self) -> Column:
        return f.try_divide(
            GrossSpend(
                self.as_at,
                self.feature_period,
                first_day_of_week=self._first_day_of_week,
            ).column,
            BasketCount(
                self.as_at,
                self.feature_period,
                first_day_of_week=self._first_day_of_week,
            ).column,
        )

    @property
    def description_subject(self) -> str:
        return "Average GrossSpend per Basket"

    @property
    def commentary(self) -> str:
        return "Total GrossSpend divided by the number of baskets"

    def default_value(self) -> Column:
        return f.lit(None)
