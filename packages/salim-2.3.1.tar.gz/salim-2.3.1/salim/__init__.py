"""Salim — AI-powered Telegram bot for laptop control."""
__version__ = "2.3.1"
