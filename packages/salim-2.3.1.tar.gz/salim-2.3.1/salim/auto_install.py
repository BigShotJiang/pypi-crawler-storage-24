"""
salim.auto_install — Lazy package installer for optional dependencies.

Handlers that need optional packages call ensure_one() at runtime
rather than at import time, so missing packages don't crash the bot.
"""
from __future__ import annotations

import importlib
import logging
import subprocess
import sys

logger = logging.getLogger("salim.auto_install")


def ensure_one(import_name: str, pip_name: str) -> bool:
    """
    Ensure a single package is available, installing it if needed.

    Args:
        import_name: the name used in `import <name>`
        pip_name:    the pip package spec (e.g. "qrcode[pil]>=7.4")

    Returns:
        True if the package is available after this call.
    """
    try:
        importlib.import_module(import_name)
        return True
    except ImportError:
        pass

    logger.info(f"Auto-installing {pip_name} ...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", pip_name, "--quiet"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode == 0:
            # Re-import to confirm
            importlib.import_module(import_name)
            logger.info(f"Successfully installed {pip_name}")
            return True
        else:
            logger.error(f"pip install {pip_name} failed: {result.stderr[:200]}")
            return False
    except subprocess.TimeoutExpired:
        logger.error(f"Timed out installing {pip_name}")
        return False
    except ImportError:
        logger.error(f"Installed {pip_name} but still cannot import {import_name}")
        return False
    except Exception as e:
        logger.error(f"Auto-install error for {pip_name}: {e}")
        return False


def ensure_many(packages: list[tuple[str, str]]) -> dict[str, bool]:
    """
    Ensure multiple packages are available.

    Args:
        packages: list of (import_name, pip_name) tuples

    Returns:
        dict mapping import_name -> True/False
    """
    return {name: ensure_one(name, pip) for name, pip in packages}
