"""
Salim Auth — Authentication middleware and require_auth decorator.

Provides:
  - require_auth: decorator that blocks unauthorized Telegram users
  - AuthMiddleware: class with is_allowed() and audit log
  - setup_logging: configure logging for the bot
"""
from __future__ import annotations

import functools
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Callable

from salim.config import Config

logger = logging.getLogger("salim.auth")

AUDIT_LOG_PATH = Path.home() / ".salim" / "audit.jsonl"


def require_auth(func: Callable) -> Callable:
    """
    Decorator for Telegram command handlers.
    Blocks execution if the calling user is not in SALIM_ALLOWED_IDS.
    Falls through silently for unauthorized users (no reply).
    """
    @functools.wraps(func)
    async def wrapper(self, update, ctx):
        user = update.effective_user
        if user is None:
            return
        # Use the bot's auth middleware if available
        if hasattr(self, "auth") and not self.auth.is_allowed(user.id):
            logger.warning(f"Blocked user {user.id} ({user.username}) from {func.__name__}")
            return
        # Log command
        if hasattr(self, "auth"):
            self.auth._log(user, func.__name__, " ".join(ctx.args or []))
        return await func(self, update, ctx)
    return wrapper


class AuthMiddleware:
    """Manages allowed users and audit logging."""

    def __init__(self, config: Config):
        self.config = config
        self._audit: list[dict] = []
        AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

    def is_allowed(self, user_id: int) -> bool:
        """Return True if user_id is in the allowed list (or list is empty = allow all)."""
        allowed = self.config.allowed_ids
        if not allowed:
            return True  # No restriction configured
        return user_id in allowed

    def _log(self, user, cmd: str, args: str = ""):
        entry = {
            "ts": datetime.now().isoformat(),
            "user": f"{user.first_name} ({user.id})",
            "cmd": cmd,
            "args": args[:100],
        }
        self._audit.append(entry)
        # Keep last 500 in memory
        if len(self._audit) > 500:
            self._audit = self._audit[-500:]
        # Append to disk log
        try:
            with open(AUDIT_LOG_PATH, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def get_audit_log(self, n: int = 20) -> list[dict]:
        """Return last n audit log entries."""
        return self._audit[-n:]


def setup_logging(verbose: bool = False):
    """Configure root logger for Salim."""
    level = logging.DEBUG if verbose else logging.INFO
    log_path = Path.home() / ".salim" / "salim.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    handlers = [
        logging.StreamHandler(),
        logging.FileHandler(log_path, encoding="utf-8"),
    ]
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
        force=True,
    )
    # Quieten noisy libraries
    for noisy in ("httpx", "httpcore", "telegram", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
