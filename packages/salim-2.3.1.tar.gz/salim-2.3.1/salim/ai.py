"""
Salim AI — Multi-provider AI backend.
Supports NVIDIA NIM, Groq, ZAI, and OpenAI-compatible APIs.
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger("salim.ai")


class SalimAI:
    """AI provider wrapper with fallback chain."""

    PROVIDERS = [
        ("nvidia", "SALIM_NVIDIA_API_KEY", "SALIM_NVIDIA_MODEL",
         "https://integrate.api.nvidia.com/v1", "meta/llama-3.1-70b-instruct"),
        ("groq",   "SALIM_GROQ_API_KEY",   "SALIM_GROQ_MODEL",
         "https://api.groq.com/openai/v1",  "llama3-70b-8192"),
        ("zai",    "SALIM_ZAI_API_KEY",     "SALIM_ZAI_MODEL",
         "https://api.zai.ai/v1",           "gpt-4o"),
        ("openai", "SALIM_OPENAI_API_KEY",  "SALIM_OPENAI_MODEL",
         "https://api.openai.com/v1",       "gpt-4o-mini"),
    ]

    def __init__(self, config):
        self.config = config
        self._active_provider = None
        self._active_key = None
        self._active_model = None
        self._active_base_url = None
        self._init_provider()

    def _init_provider(self):
        for name, key_env, model_env, base_url, default_model in self.PROVIDERS:
            key = self.config.get(key_env, "")
            if key:
                self._active_provider = name
                self._active_key = key
                self._active_model = self.config.get(model_env, "") or default_model
                self._active_base_url = base_url
                return

    def is_configured(self) -> bool:
        return bool(self._active_key)

    def status_line(self) -> str:
        if not self.is_configured():
            return "🤖 AI: not configured (set SALIM_NVIDIA_API_KEY or SALIM_GROQ_API_KEY)"
        model_short = (self._active_model or "").split("/")[-1]
        return f"🤖 AI: {self._active_provider} · {model_short}"

    async def chat(self, messages: list[dict], max_tokens: int = 1024,
                   temperature: float = 0.7, system: Optional[str] = None) -> str:
        """Send chat completion. Returns response text."""
        if not self.is_configured():
            return "⚠️ AI not configured. Set SALIM_NVIDIA_API_KEY in config."

        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(
                api_key=self._active_key,
                base_url=self._active_base_url,
            )
            all_messages = []
            if system:
                all_messages.append({"role": "system", "content": system})
            all_messages.extend(messages)

            resp = await client.chat.completions.create(
                model=self._active_model,
                messages=all_messages,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            return resp.choices[0].message.content or ""
        except Exception as e:
            logger.error(f"AI chat error: {e}")
            return f"❌ AI error: {e}"

    async def complete(self, prompt: str, system: Optional[str] = None,
                       max_tokens: int = 1024) -> str:
        """Simple prompt → completion."""
        return await self.chat(
            [{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            system=system,
        )

    # ── Extended methods used by ai_handler ──────────────────────────────────

    async def parse_intent_with_history(
        self,
        text: str,
        history_ctx: str = "",
        user_id: int = 0,
        max_tokens: int = 512,
    ) -> dict:
        """
        Parse a user message into a structured intent dict.
        Returns JSON with keys: action, message, command, args, keywords,
        file_types, action_hint, topic, format, filename, save_path,
        content_instructions, _provider.

        Actions: reply, execute, search, generate_write, clarify
        """
        system = (
            "You are an AI assistant intent parser. Analyse the user message and return ONLY a JSON object.\n\n"
            "Schema:\n"
            "{\n"
            '  "action": "reply" | "execute" | "search" | "generate_write" | "clarify",\n'
            '  "message": "natural language reply or clarification (if action is reply/clarify)",\n'
            '  "command": "/command_name (if action is execute)",\n'
            '  "args": "arguments string for the command",\n'
            '  "keywords": ["search", "keywords"],\n'
            '  "file_types": ["py", "pdf"],\n'
            '  "action_hint": "download|delete|open|play|...",\n'
            '  "topic": "topic for content generation",\n'
            '  "format": "txt|md|pdf|docx",\n'
            '  "filename": "output_filename.txt",\n'
            '  "save_path": "~/Desktop",\n'
            '  "content_instructions": "detailed instructions for content generation"\n'
            "}\n\n"
            "Rules:\n"
            "- Use action=reply for general conversation and questions\n"
            "- Use action=execute only when user clearly wants to run a bot command\n"
            "- Use action=search when user wants to find files on their computer\n"
            "- Use action=generate_write when user wants to create a document or write content\n"
            "- Use action=clarify when the request is ambiguous\n"
            "- Always return valid JSON only"
        )
        ctx_note = f"\nConversation history:\n{history_ctx}\n" if history_ctx else ""
        messages = [{"role": "user", "content": f"{ctx_note}User says: {text}\n\nReturn ONLY the JSON intent object."}]
        raw = await self.chat(messages, system=system, max_tokens=max_tokens, temperature=0.1)
        import re, json
        raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if m:
            try:
                result = json.loads(m.group(0))
                result["_provider"] = self._active_provider or ""
                return result
            except Exception:
                pass
        # Fallback: treat as plain reply
        return {"action": "reply", "message": raw[:500], "_provider": self._active_provider or ""}

    async def generate_content(
        self,
        topic: str,
        format: str = "txt",
        instructions: str = "",
        max_tokens: int = 2048,
        temperature: float = 0.7,
    ) -> tuple[str, str]:
        """
        Generate long-form content (document, essay, report, etc.).
        Returns (content_string, provider_name).
        """
        fmt_note = {
            "md": "Use Markdown formatting with headers, lists, bold text.",
            "txt": "Use plain text with clear structure.",
            "html": "Use clean HTML with appropriate tags.",
            "docx": "Use structured text with clear sections and headings.",
        }.get(format, "Use clear, well-structured text.")

        system = (
            f"You are an expert writer. {fmt_note}\n"
            "Write complete, high-quality content. No placeholders. Real, substantive text."
        )
        prompt = instructions if instructions else f"Write a comprehensive piece about: {topic}"
        messages = [{"role": "user", "content": prompt}]
        content = await self.chat(messages, system=system, max_tokens=max_tokens, temperature=temperature)
        return content, self._active_provider or ""

    async def _call_with_fallback(
        self,
        messages: list[dict],
        system: str,
        max_tokens: int = 2048,
        temperature: float = 0.7,
    ) -> tuple[str, str]:
        """
        Call AI with the current provider. Returns (response_text, provider_name).
        Used by code_runner and other handlers that need the provider name back.
        """
        response = await self.chat(messages, system=system, max_tokens=max_tokens, temperature=temperature)
        return response, self._active_provider or ""

    async def ask(
        self,
        prompt: str,
        system: Optional[str] = None,
        max_tokens: int = 2048,
        temperature: float = 0.7,
    ) -> str:
        """Alias for complete() — kept for backward compatibility with older handlers."""
        return await self.complete(prompt, system=system, max_tokens=max_tokens, temperature=temperature)
