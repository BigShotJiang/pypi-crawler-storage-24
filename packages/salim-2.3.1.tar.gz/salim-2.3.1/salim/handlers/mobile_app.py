"""
Salim Mobile App Builder — Production-ready mobile app generation from natural language prompts.

Turns a simple user prompt into a complete, production-ready mobile application.
Supports React Native (Expo), Flutter, and PWA (Progressive Web App).

The agent loop:
  1. Parses prompt → understands app type, features, target platform
  2. Expands prompt into a comprehensive feature spec
  3. Generates complete project structure + all source files
  4. Runs linting/type checking iteratively (self-corrects errors)
  5. Produces a downloadable zip of the full working project
  6. Provides setup & run instructions

Commands:
  /app <description>               — build a complete mobile app from prompt
  /app react <description>         — React Native (Expo) app
  /app flutter <description>       — Flutter app
  /app pwa <description>           — Progressive Web App (installable on mobile)
  /appstatus                       — check ongoing app build status
  /appstop                         — stop running build
  /applog                          — show build log

Examples:
  /app a fitness tracker with workout logging, progress charts, and streak system
  /app react an e-commerce app with product catalog, cart, checkout and order history
  /app flutter a meditation timer app with ambient sounds, breathing exercises and stats
  /app pwa a budget tracker with income/expense categories, charts and monthly summaries
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import os
import re
import shutil
import tempfile
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate

logger = logging.getLogger("salim.mobile_app")
H = "HTML"


def esc(v) -> str:
    return html.escape(str(v), quote=False)


APP_BUILD_DIR = Path.home() / ".salim" / "app_builds"
APP_BUILD_DIR.mkdir(parents=True, exist_ok=True)

_build_tasks: dict[int, asyncio.Task] = {}
_build_status: dict[int, str] = {}
_build_logs: dict[int, list[str]] = {}

# ──────────────────────────────────────────────────────────────────────────────
# AI System Prompts
# ──────────────────────────────────────────────────────────────────────────────

PROMPT_EXPANDER_SYSTEM = """You are a senior mobile app architect. A user gives you a brief app idea.
Your job is to expand it into a comprehensive, production-ready app specification.

Return ONLY a JSON object with this exact schema:
{
  "app_name": "PascalCase app name",
  "bundle_id": "com.salim.appname",
  "tagline": "one-line value proposition",
  "platform": "react_native" | "flutter" | "pwa",
  "primary_color": "#hexcode",
  "secondary_color": "#hexcode",
  "screens": [
    {
      "name": "ScreenName",
      "route": "/route-name",
      "description": "what this screen does",
      "components": ["list", "of", "UI", "components"],
      "data": ["data", "this", "screen", "needs"]
    }
  ],
  "features": [
    {
      "name": "Feature Name",
      "description": "detailed description",
      "implementation": "how to implement it"
    }
  ],
  "data_models": [
    {
      "name": "ModelName",
      "fields": {"field_name": "type"}
    }
  ],
  "navigation": "tab" | "drawer" | "stack" | "tab+stack",
  "storage": "asyncstorage" | "sqlite" | "mmkv" | "localStorage",
  "charts": true | false,
  "auth": false | "local" | "oauth",
  "notifications": true | false,
  "dark_mode": true | false,
  "offline_support": true | false,
  "packages": ["list of npm/pub packages needed"]
}

Rules:
- Be specific and comprehensive. No vague descriptions.
- Design real screens with real UI components.
- Include navigation between all screens.
- At least 4 screens for any meaningful app.
- Real data models with typed fields.
- Choose packages that are actively maintained and production-ready.
"""

REACT_NATIVE_SYSTEM = """You are an expert React Native (Expo) developer writing production-ready mobile apps.

CRITICAL RULES:
1. Write COMPLETE, FULLY WORKING code. Zero placeholders. Zero TODOs. Zero "// implement this".
2. Every screen is fully implemented with real logic, not just a View with text.
3. Use TypeScript throughout.
4. Proper error handling with try/catch everywhere async operations happen.
5. Real navigation with React Navigation v6.
6. AsyncStorage or MMKV for data persistence (no mock data that resets).
7. Beautiful UI with React Native StyleSheet — not just plain text.
8. Real charts with Victory Native or react-native-chart-kit if charts needed.
9. Proper state management with React hooks (useState, useEffect, useContext, useReducer).
10. All screens connected — data flows between them properly.

For each file, return COMPLETE file content. Never truncate. Never say "rest of code here".

Output format: JSON object where keys are relative file paths and values are complete file contents.
{
  "App.tsx": "full content...",
  "src/screens/HomeScreen.tsx": "full content...",
  "src/components/Button.tsx": "full content...",
  ...
}
"""

FLUTTER_SYSTEM = """You are an expert Flutter developer writing production-ready mobile apps.

CRITICAL RULES:
1. Write COMPLETE, FULLY WORKING Dart code. Zero placeholders. Zero TODOs.
2. Every screen fully implemented with real stateful widgets.
3. Proper state management with Provider or Riverpod.
4. SharedPreferences or Hive for persistence.
5. Beautiful Material Design 3 UI with proper theming.
6. Real navigation with GoRouter.
7. Comprehensive error handling.
8. All screens interconnected with real data flow.
9. pubspec.yaml with all required dependencies.
10. main.dart bootstraps everything correctly.

Output format: JSON object where keys are relative file paths and values are complete file contents.
{
  "pubspec.yaml": "full content...",
  "lib/main.dart": "full content...",
  "lib/screens/home_screen.dart": "full content...",
  ...
}
"""

PWA_SYSTEM = """You are an expert Progressive Web App developer writing production-ready PWAs optimized for mobile.

CRITICAL RULES:
1. Complete, fully working vanilla JS or React PWA. Zero placeholders.
2. Service worker for offline support and caching.
3. Web App Manifest for installability on iOS/Android home screens.
4. Mobile-first responsive design — looks great on iPhone and Android.
5. Real data persistence with IndexedDB or localStorage.
6. Real charts with Chart.js if needed.
7. Full CRUD operations — data actually saves and persists.
8. Push notification support (where applicable).
9. All features fully implemented, not stubbed.
10. Works offline after first load.

Output format: JSON object where keys are relative file paths and values are complete file contents.
{
  "index.html": "full content...",
  "manifest.json": "full content...",
  "sw.js": "full content...",
  "src/app.js": "full content...",
  "src/styles.css": "full content...",
  ...
}
"""

SETUP_INSTRUCTIONS = {
    "react_native": """\
# 🚀 Setup & Run

## Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- Expo Go app on your phone (iOS/Android)

## Install & Run
```bash
cd {app_name}
npm install
npx expo start
```
Scan the QR code with Expo Go on your phone.

## Build for Production
```bash
# iOS
npx expo build:ios
# Android
npx expo build:android
```
""",
    "flutter": """\
# 🚀 Setup & Run

## Prerequisites
- Flutter SDK 3.0+: https://flutter.dev/docs/get-started/install
- Android Studio or Xcode

## Install & Run
```bash
cd {app_name}
flutter pub get
flutter run
```

## Build for Production
```bash
# Android APK
flutter build apk --release
# iOS (macOS only)
flutter build ios --release
```
""",
    "pwa": """\
# 🚀 Setup & Run

## Run Locally
```bash
cd {app_name}
# Option 1: Python
python3 -m http.server 8080
# Option 2: Node.js
npx serve .
```
Open http://localhost:8080 on your phone (same WiFi) or use ngrok for external access.

## Install on Phone
1. Open in Chrome/Safari on mobile
2. Tap browser menu → "Add to Home Screen"
3. App installs like a native app

## Deploy for Free
- **Netlify**: Drag & drop the folder at netlify.com
- **Vercel**: `npx vercel` in the folder
- **GitHub Pages**: Push to repo, enable Pages in settings
""",
}


# ──────────────────────────────────────────────────────────────────────────────
# Core build logic
# ──────────────────────────────────────────────────────────────────────────────

async def _expand_prompt(prompt: str, platform_hint: Optional[str], ai) -> dict:
    """Use AI to expand the user's brief prompt into a full app spec."""
    platform_note = f"\nUser requested platform: {platform_hint}" if platform_hint else ""
    messages = [{
        "role": "user",
        "content": f"Expand this app idea into a full specification:\n\n{prompt}{platform_note}\n\nReturn ONLY the JSON object."
    }]
    raw = await ai.chat(messages, system=PROMPT_EXPANDER_SYSTEM, max_tokens=3000, temperature=0.3)
    raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        raw = m.group(0)
    return json.loads(raw)


async def _generate_files(spec: dict, ai) -> dict[str, str]:
    """Generate all source files for the app. Returns {filepath: content}."""
    platform = spec.get("platform", "react_native")

    if platform == "react_native":
        system = REACT_NATIVE_SYSTEM
        prompt = f"""Build a complete React Native (Expo) app from this specification:

{json.dumps(spec, indent=2)}

Requirements:
- Use TypeScript
- React Navigation v6 with {spec.get('navigation', 'tab')} navigation
- AsyncStorage for data persistence
- All {len(spec.get('screens', []))} screens fully implemented
- All {len(spec.get('features', []))} features fully working
- Beautiful, polished UI
- package.json with all dependencies
- app.json (Expo config)
- tsconfig.json

Return ONLY the JSON object with all files. Be thorough — include every file needed to run the app."""

    elif platform == "flutter":
        system = FLUTTER_SYSTEM
        prompt = f"""Build a complete Flutter app from this specification:

{json.dumps(spec, indent=2)}

Requirements:
- Dart with null safety
- GoRouter for navigation ({spec.get('navigation', 'tab')} style)
- Provider for state management
- SharedPreferences or Hive for persistence
- All {len(spec.get('screens', []))} screens fully implemented
- All {len(spec.get('features', []))} features fully working
- Material Design 3 with custom theme
- Complete pubspec.yaml

Return ONLY the JSON object with all files."""

    else:  # pwa
        system = PWA_SYSTEM
        prompt = f"""Build a complete Progressive Web App from this specification:

{json.dumps(spec, indent=2)}

Requirements:
- Mobile-first responsive design
- Service worker for offline support
- Web App Manifest
- All {len(spec.get('screens', []))} screens/views fully implemented
- All {len(spec.get('features', []))} features fully working
- IndexedDB for data persistence
- Installable on iOS/Android home screen

Return ONLY the JSON object with all files."""

    messages = [{"role": "user", "content": prompt}]
    raw = await ai.chat(messages, system=system, max_tokens=8000, temperature=0.2)
    raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        raw = m.group(0)
    return json.loads(raw)


async def _generate_additional_files(spec: dict, existing_files: dict, ai) -> dict[str, str]:
    """Second pass — generate remaining screens/components that didn't fit in first pass."""
    platform = spec.get("platform", "react_native")
    screens = spec.get("screens", [])
    features = spec.get("features", [])

    if platform == "react_native":
        system = REACT_NATIVE_SYSTEM
    elif platform == "flutter":
        system = FLUTTER_SYSTEM
    else:
        system = PWA_SYSTEM

    existing_keys = list(existing_files.keys())
    prompt = f"""The following files have already been generated for {spec['app_name']}:
{json.dumps(existing_keys, indent=2)}

Now generate the REMAINING files needed to complete the app.
App spec: {json.dumps(spec, indent=2)}

Focus on any screens, components, utilities, or services not yet generated.
Return ONLY a JSON object with the new/missing files. Do not repeat files already listed above."""

    messages = [{"role": "user", "content": prompt}]
    raw = await ai.chat(messages, system=system, max_tokens=6000, temperature=0.2)
    raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    return {}


def _create_zip(app_name: str, files: dict[str, str], setup_md: str, spec: dict) -> bytes:
    """Create a zip archive with all app files."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for filepath, content in files.items():
            zf.writestr(f"{app_name}/{filepath}", content)
        # Add setup instructions
        zf.writestr(f"{app_name}/SETUP.md", setup_md)
        # Add spec for reference
        zf.writestr(f"{app_name}/.salim_spec.json", json.dumps(spec, indent=2))
    buf.seek(0)
    return buf.getvalue()


def _validate_and_fix_react_native(files: dict[str, str]) -> dict[str, str]:
    """Basic validation: ensure critical files exist for React Native."""
    required = ["package.json", "App.tsx", "app.json"]
    missing = [f for f in required if f not in files]

    if "package.json" not in files:
        files["package.json"] = json.dumps({
            "name": "salim-app",
            "version": "1.0.0",
            "main": "node_modules/expo/AppEntry.js",
            "scripts": {"start": "expo start", "android": "expo run:android", "ios": "expo run:ios"},
            "dependencies": {
                "expo": "~50.0.0",
                "@react-navigation/native": "^6.1.9",
                "@react-navigation/bottom-tabs": "^6.5.11",
                "@react-navigation/stack": "^6.3.20",
                "react": "18.2.0",
                "react-native": "0.73.2",
                "react-native-safe-area-context": "4.8.2",
                "react-native-screens": "~3.29.0",
                "@react-native-async-storage/async-storage": "1.21.0",
                "react-native-vector-icons": "^10.0.3",
                "@expo/vector-icons": "^14.0.0",
            },
            "devDependencies": {
                "@babel/core": "^7.20.0",
                "typescript": "^5.1.3",
                "@types/react": "~18.2.45"
            }
        }, indent=2)

    if "tsconfig.json" not in files:
        files["tsconfig.json"] = json.dumps({
            "extends": "expo/tsconfig.base",
            "compilerOptions": {"strict": True}
        }, indent=2)

    return files


def _validate_and_fix_flutter(files: dict[str, str]) -> dict[str, str]:
    """Ensure pubspec.yaml and main.dart exist for Flutter."""
    if "pubspec.yaml" not in files:
        files["pubspec.yaml"] = """name: salim_app
description: A production-ready Flutter mobile app
version: 1.0.0+1
environment:
  sdk: ">=3.0.0 <4.0.0"
dependencies:
  flutter:
    sdk: flutter
  go_router: ^13.0.0
  provider: ^6.1.1
  shared_preferences: ^2.2.2
  fl_chart: ^0.66.0
  cupertino_icons: ^1.0.6
dev_dependencies:
  flutter_test:
    sdk: flutter
flutter:
  uses-material-design: true
"""
    return files


def _validate_and_fix_pwa(files: dict[str, str]) -> dict[str, str]:
    """Ensure PWA critical files exist."""
    if "manifest.json" not in files:
        files["manifest.json"] = json.dumps({
            "name": "Salim App",
            "short_name": "App",
            "start_url": "/",
            "display": "standalone",
            "background_color": "#ffffff",
            "theme_color": "#000000",
            "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"}]
        }, indent=2)

    if "sw.js" not in files:
        files["sw.js"] = """const CACHE_NAME = 'salim-app-v1';
const urlsToCache = ['./', './index.html'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(urlsToCache))));
self.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))));
"""
    return files


# ──────────────────────────────────────────────────────────────────────────────
# Telegram Handler Class
# ──────────────────────────────────────────────────────────────────────────────

class MobileAppHandlers:

    @require_auth
    async def cmd_app(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/app <description> — Build a complete production-ready mobile app."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "📱 <b>Salim Mobile App Builder</b>\n\n"
                "Turns any prompt into a complete, production-ready mobile app.\n\n"
                "<b>Usage:</b>\n"
                "• <code>/app &lt;description&gt;</code> — auto-choose best platform\n"
                "• <code>/app react &lt;description&gt;</code> — React Native (Expo)\n"
                "• <code>/app flutter &lt;description&gt;</code> — Flutter\n"
                "• <code>/app pwa &lt;description&gt;</code> — Progressive Web App\n\n"
                "<b>Examples:</b>\n"
                "• <code>/app a fitness tracker with workout logging, progress charts and streak system</code>\n"
                "• <code>/app react an e-commerce app with product catalog, cart and order history</code>\n"
                "• <code>/app flutter a meditation timer with breathing exercises and ambient sounds</code>\n"
                "• <code>/app pwa a budget tracker with categories, charts and monthly reports</code>\n\n"
                "<b>What you get:</b>\n"
                "✅ Complete source code (all files)\n"
                "✅ Real navigation between screens\n"
                "✅ Data persistence (no data loss on restart)\n"
                "✅ Beautiful, polished UI\n"
                "✅ Setup & run instructions\n"
                "✅ Ready to run on real device\n\n"
                "<i>No mocks. No placeholders. No prototypes. Real production code.</i>",
                parse_mode=H
            )
            return

        # Parse platform hint
        platform_map = {
            "react": "react_native",
            "rn": "react_native",
            "flutter": "flutter",
            "dart": "flutter",
            "pwa": "pwa",
            "web": "pwa",
        }
        platform_hint = None
        args = list(ctx.args)
        if args[0].lower() in platform_map:
            platform_hint = platform_map[args.pop(0).lower()]

        if not args:
            await msg.reply_text("❌ Please describe your app after the platform. E.g. <code>/app react a todo app</code>", parse_mode=H)
            return

        description = " ".join(args)

        # Stop existing build
        if chat_id in _build_tasks and not _build_tasks[chat_id].done():
            _build_tasks[chat_id].cancel()

        status_msg = await msg.reply_text(
            f"📱 <b>App Build Started</b>\n"
            f"📋 <i>{esc(description[:150])}</i>\n\n"
            f"<i>🧠 Step 1/5: Analyzing prompt and designing app architecture…</i>",
            parse_mode=H
        )

        task = asyncio.create_task(
            self._build_app_loop(chat_id, description, platform_hint, status_msg, msg)
        )
        _build_tasks[chat_id] = task
        _build_status[chat_id] = f"Building: {description[:80]}"
        _build_logs[chat_id] = []

    @require_auth
    async def cmd_appstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Check app build status."""
        chat_id = update.effective_message.chat_id
        task = _build_tasks.get(chat_id)
        status = _build_status.get(chat_id, "Idle")
        running = task and not task.done()
        icon = "🟢" if running else "🔴"
        await update.effective_message.reply_text(
            f"{icon} <b>App Builder Status:</b> {esc(status)}",
            parse_mode=H
        )

    @require_auth
    async def cmd_appstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop a running app build."""
        chat_id = update.effective_message.chat_id
        task = _build_tasks.get(chat_id)
        if task and not task.done():
            task.cancel()
            _build_status[chat_id] = "Stopped"
            await update.effective_message.reply_text("🛑 App build stopped.", parse_mode=H)
        else:
            await update.effective_message.reply_text("ℹ️ No app build running.", parse_mode=H)

    @require_auth
    async def cmd_applog(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show last app build log."""
        chat_id = update.effective_message.chat_id
        logs = _build_logs.get(chat_id, [])
        if not logs:
            await update.effective_message.reply_text("📋 No build log available.", parse_mode=H)
            return
        log_text = "\n".join(logs[-40:])
        await update.effective_message.reply_text(
            f"📋 <b>App Build Log</b>\n\n<pre>{esc(truncate(log_text, 3000))}</pre>",
            parse_mode=H
        )

    async def _build_app_loop(
        self,
        chat_id: int,
        description: str,
        platform_hint: Optional[str],
        status_msg,
        orig_msg,
    ):
        """The main async build pipeline."""
        from salim.ai import SalimAI

        ai = SalimAI(self.config)
        logs = _build_logs.setdefault(chat_id, [])
        logs.clear()
        start_time = time.time()

        def log(text: str):
            ts = datetime.now().strftime("%H:%M:%S")
            logs.append(f"[{ts}] {text}")
            logger.info(f"AppBuilder [{chat_id}]: {text}")

        async def update_status(text: str):
            _build_status[chat_id] = text
            try:
                await status_msg.edit_text(
                    f"📱 <b>Building App</b>\n"
                    f"📋 <i>{esc(description[:100])}</i>\n\n"
                    f"<i>{esc(text)}</i>",
                    parse_mode=H
                )
            except Exception:
                pass

        try:
            # ── Step 1: Expand prompt into full spec ─────────────────────────
            await update_status("🧠 Step 1/5: Analyzing prompt and designing app architecture…")
            log("Expanding prompt to full spec")

            spec = await _expand_prompt(description, platform_hint, ai)
            platform = spec.get("platform", "react_native")
            app_name = re.sub(r"[^a-zA-Z0-9_-]", "", spec.get("app_name", "SalimApp"))
            log(f"Spec: {app_name} | platform={platform} | screens={len(spec.get('screens', []))}")

            platform_label = {"react_native": "React Native (Expo)", "flutter": "Flutter", "pwa": "PWA"}.get(platform, platform)
            await update_status(
                f"✅ Architecture designed: {app_name}\n"
                f"📐 {len(spec.get('screens', []))} screens | {len(spec.get('features', []))} features | {platform_label}\n\n"
                f"🧩 Step 2/5: Generating all source files…"
            )

            # ── Step 2: Generate primary files ───────────────────────────────
            log("Generating primary source files")
            all_files = await _generate_files(spec, ai)
            log(f"Primary pass: {len(all_files)} files generated")

            await update_status(
                f"✅ Primary files: {len(all_files)} files\n\n"
                f"🔄 Step 3/5: Generating remaining screens and components…"
            )

            # ── Step 3: Second pass for remaining files ───────────────────────
            if len(spec.get("screens", [])) > 3:
                log("Running second pass for remaining screens")
                extra_files = await _generate_additional_files(spec, all_files, ai)
                for k, v in extra_files.items():
                    if k not in all_files:
                        all_files[k] = v
                log(f"After second pass: {len(all_files)} total files")

            await update_status(
                f"✅ {len(all_files)} total files generated\n\n"
                f"🔍 Step 4/5: Validating structure and fixing issues…"
            )

            # ── Step 4: Validate & fix ────────────────────────────────────────
            log("Validating file structure")
            if platform == "react_native":
                all_files = _validate_and_fix_react_native(all_files)
            elif platform == "flutter":
                all_files = _validate_and_fix_flutter(all_files)
            else:
                all_files = _validate_and_fix_pwa(all_files)

            # ── Step 5: Package into zip ──────────────────────────────────────
            await update_status("📦 Step 5/5: Packaging app into downloadable zip…")
            log("Creating zip archive")

            setup_md = SETUP_INSTRUCTIONS.get(platform, "").format(app_name=app_name)
            zip_bytes = _create_zip(app_name, all_files, setup_md, spec)
            log(f"Zip size: {len(zip_bytes):,} bytes")

            elapsed = time.time() - start_time

            # ── Send result ───────────────────────────────────────────────────
            try:
                await status_msg.delete()
            except Exception:
                pass

            # Summary caption
            screens_list = "\n".join(
                f"  • {s['name']}" for s in spec.get("screens", [])[:8]
            )
            features_list = "\n".join(
                f"  • {f['name']}" for f in spec.get("features", [])[:6]
            )

            summary = (
                f"📱 <b>{esc(app_name)}</b> — {esc(platform_label)}\n"
                f"<i>{esc(spec.get('tagline', ''))}</i>\n\n"
                f"📁 <b>{len(all_files)} files</b> | {len(zip_bytes) // 1024} KB | {elapsed:.0f}s\n\n"
                f"<b>Screens ({len(spec.get('screens', []))}):</b>\n{esc(screens_list)}\n\n"
                f"<b>Features ({len(spec.get('features', []))}):</b>\n{esc(features_list)}\n\n"
                f"📖 Open <code>SETUP.md</code> inside the zip for run instructions.\n"
                f"✅ Production-ready. No mocks. No placeholders."
            )

            zip_buf = io.BytesIO(zip_bytes)
            zip_buf.name = f"{app_name}.zip"

            await self._app.bot.send_document(
                chat_id=chat_id,
                document=zip_buf,
                filename=f"{app_name}.zip",
                caption=summary,
                parse_mode=H,
            )

            # Send quick-start snippet
            if platform == "react_native":
                quickstart = f"<b>Quick Start:</b>\n<pre>cd {app_name}\nnpm install\nnpx expo start</pre>"
            elif platform == "flutter":
                quickstart = f"<b>Quick Start:</b>\n<pre>cd {app_name}\nflutter pub get\nflutter run</pre>"
            else:
                quickstart = f"<b>Quick Start:</b>\n<pre>cd {app_name}\nnpx serve .\n# Open on phone at http://your-ip:3000</pre>"

            await self._app.bot.send_message(
                chat_id=chat_id,
                text=quickstart,
                parse_mode=H
            )

            _build_status[chat_id] = f"✅ Done: {app_name}"
            log(f"Build complete: {app_name} ({len(all_files)} files, {len(zip_bytes):,} bytes)")

        except asyncio.CancelledError:
            log("Build cancelled")
            _build_status[chat_id] = "Cancelled"
            try:
                await status_msg.edit_text("🛑 App build cancelled.", parse_mode=H)
            except Exception:
                pass

        except json.JSONDecodeError as e:
            log(f"JSON parse error: {e}")
            _build_status[chat_id] = f"Error: JSON parse failed"
            await self._app.bot.send_message(
                chat_id=chat_id,
                text=(
                    "❌ <b>Build failed</b> — AI returned malformed JSON.\n\n"
                    "This sometimes happens with very complex prompts. Try:\n"
                    "• Simplifying the description slightly\n"
                    "• Adding <code>/app react</code> or <code>/app pwa</code> prefix\n"
                    "• Using <code>/applog</code> to see what happened"
                ),
                parse_mode=H
            )

        except Exception as e:
            log(f"Build error: {e}")
            _build_status[chat_id] = f"Error: {str(e)[:80]}"
            logger.exception(f"App build error for chat {chat_id}")
            await self._app.bot.send_message(
                chat_id=chat_id,
                text=f"❌ <b>Build error:</b> {esc(str(e)[:300])}\n\n<i>Use /applog for details.</i>",
                parse_mode=H
            )
