"""
Salim Memory — Persistent user memory and preference profiles.

Stores per-user facts, preferences, and context that persist across sessions.
Used by the AI handler to personalise responses.

Commands:
  /memory              — view your memory profile
  /memory set <k> <v>  — set a memory key
  /memory del <k>      — delete a key
  /memory clear        — wipe all memory
  /memory search <q>   — search memory entries

Module-level functions (used by other handlers):
  update_last_seen(user_id)
  build_memory_context(user_id) -> str
  learn_from_text(user_id, text)
"""
from __future__ import annotations

import html
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.memory")
H = "HTML"


def esc(v) -> str:
    return html.escape(str(v), quote=False)


MEMORY_DIR = Path.home() / ".salim" / "memory"
MEMORY_DIR.mkdir(parents=True, exist_ok=True)


def _memory_path(user_id: int) -> Path:
    return MEMORY_DIR / f"{user_id}.json"


def _load_memory(user_id: int) -> dict:
    p = _memory_path(user_id)
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            return {}
    return {}


def _save_memory(user_id: int, data: dict):
    p = _memory_path(user_id)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False))


def update_last_seen(user_id: int):
    """Record last interaction timestamp for this user."""
    data = _load_memory(user_id)
    data["last_seen"] = datetime.now().isoformat()
    data["message_count"] = data.get("message_count", 0) + 1
    _save_memory(user_id, data)


def build_memory_context(user_id: int) -> str:
    """Build a context string for AI prompts from stored memory."""
    data = _load_memory(user_id)
    if not data:
        return ""
    lines = []
    skip = {"last_seen", "message_count", "learned_facts"}
    for k, v in data.items():
        if k not in skip and v:
            lines.append(f"- {k}: {v}")
    facts = data.get("learned_facts", [])
    for fact in facts[-10:]:
        lines.append(f"- {fact}")
    if not lines:
        return ""
    return "User memory:\n" + "\n".join(lines)


def learn_from_text(user_id: int, text: str):
    """Passively extract and store facts from user messages."""
    data = _load_memory(user_id)
    facts = data.setdefault("learned_facts", [])
    patterns = [
        (r"\bmy name is (\w+)", "name"),
        (r"\bI(?:'m| am) (\w+)", None),
        (r"\bI live in ([\w\s]+?)(?:\.|,|$)", "location"),
        (r"\bI(?:'m| am) from ([\w\s]+?)(?:\.|,|$)", "location"),
        (r"\bI work (?:at|for) ([\w\s]+?)(?:\.|,|$)", "employer"),
    ]
    for pattern, key in patterns:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            fact = m.group(0).strip()
            if fact and fact not in facts:
                facts.append(fact)
                if key:
                    data[key] = m.group(1).strip().title()
    data["learned_facts"] = facts[-50:]
    _save_memory(user_id, data)


class MemoryHandlers:

    @require_auth
    async def cmd_memory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/memory [set|del|clear|search] — manage persistent memory profile."""
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        if not args:
            data = _load_memory(user_id)
            if not data:
                await msg.reply_text(
                    "🧠 <b>Your Memory</b>\n\n"
                    "<i>No memory stored yet.</i>\n\n"
                    "<b>Examples:</b>\n"
                    "• <code>/memory set name Alice</code>\n"
                    "• <code>/memory set timezone UTC+3</code>\n"
                    "• <code>/memory set language English</code>\n\n"
                    "<i>Salim also learns from your messages automatically.</i>",
                    parse_mode=H
                )
                return

            skip = {"learned_facts"}
            lines = [f"• <code>{esc(k)}</code>: {esc(str(v))}" for k, v in data.items() if k not in skip]
            facts = data.get("learned_facts", [])
            facts_text = ""
            if facts:
                facts_text = (
                    f"\n\n<b>Learned ({len(facts)}):</b>\n"
                    + "\n".join(f"• {esc(f)}" for f in facts[-5:])
                    + (f"\n<i>…and {len(facts)-5} more</i>" if len(facts) > 5 else "")
                )
            await msg.reply_text(
                f"🧠 <b>Memory Profile</b>\n\n" + "\n".join(lines) + facts_text,
                parse_mode=H
            )
            return

        sub = args[0].lower()
        if sub == "set" and len(args) >= 3:
            key = args[1].lower()
            value = " ".join(args[2:])
            data = _load_memory(user_id)
            data[key] = value
            _save_memory(user_id, data)
            await msg.reply_text(f"✅ <code>{esc(key)}</code> = <code>{esc(value)}</code>", parse_mode=H)

        elif sub == "del" and len(args) >= 2:
            key = args[1].lower()
            data = _load_memory(user_id)
            if key in data:
                del data[key]
                _save_memory(user_id, data)
                await msg.reply_text(f"🗑 Deleted <code>{esc(key)}</code>", parse_mode=H)
            else:
                await msg.reply_text(f"❌ Key <code>{esc(key)}</code> not found.", parse_mode=H)

        elif sub == "clear":
            p = _memory_path(user_id)
            if p.exists():
                p.unlink()
            await msg.reply_text("🗑 <b>Memory cleared.</b>", parse_mode=H)

        elif sub == "search" and len(args) >= 2:
            query = " ".join(args[1:]).lower()
            data = _load_memory(user_id)
            matches = [f"• <code>{esc(k)}</code>: {esc(str(v))}" for k, v in data.items() if query in k.lower() or query in str(v).lower()]
            if matches:
                await msg.reply_text(f"🔍 <b>Results for '{esc(query)}':</b>\n\n" + "\n".join(matches), parse_mode=H)
            else:
                await msg.reply_text(f"❌ No results for <code>{esc(query)}</code>.", parse_mode=H)

        else:
            await msg.reply_text(
                "🧠 <b>Memory Commands</b>\n\n"
                "• <code>/memory</code> — view profile\n"
                "• <code>/memory set &lt;key&gt; &lt;value&gt;</code>\n"
                "• <code>/memory del &lt;key&gt;</code>\n"
                "• <code>/memory clear</code>\n"
                "• <code>/memory search &lt;query&gt;</code>",
                parse_mode=H
            )
