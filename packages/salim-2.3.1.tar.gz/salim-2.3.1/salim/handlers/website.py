"""
Salim Website Builder — Agentic, production-ready website generation from natural language prompts.

Like Manus AI — turns any prompt into a complete, multi-page website or web app.
Uses a multi-pass agentic loop:
  1. Prompt expansion → full site spec (pages, sections, data, style)
  2. AI generates all HTML/CSS/JS
  3. Self-validation — checks links, consistency
  4. Delivers self-contained zip (open in browser, deploy anywhere)

Commands:
  /website <description>           — generate a complete website from description
  /website landing <product>       — full SaaS landing page
  /website dashboard <title>       — interactive analytics dashboard
  /website portfolio <niche>       — creative portfolio
  /website blog <topic>            — blog/magazine layout
  /website store <n>               — e-commerce store (static)
  /website saas <product>          — full SaaS marketing site
  /website app <description>       — full single-page web application

Examples:
  /website a restaurant for Bella Italia with full menu, gallery, reservations and Google Maps
  /website landing TaskFlow — AI-powered project management for remote teams
  /website app a kanban board with drag-and-drop, labels and due dates
  /website store Luxe Candles with product grid, filters and cart
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import truncate

logger = logging.getLogger("salim.website")
H = "HTML"


def esc(v) -> str:
    return html.escape(str(v), quote=False)


WEBSITE_DIR = Path.home() / ".salim" / "websites"
WEBSITE_DIR.mkdir(parents=True, exist_ok=True)

_website_tasks: dict[int, asyncio.Task] = {}

# ──────────────────────────────────────────────────────────────────────────────
SITE_ARCHITECT_SYSTEM = """You are a senior web architect. Turn a brief into a full website specification.

Return ONLY a JSON object:
{
  "site_name": "Name",
  "site_type": "landing|portfolio|restaurant|dashboard|blog|store|saas|webapp|...",
  "tagline": "one-line description",
  "color_primary": "#hex",
  "color_secondary": "#hex",
  "color_accent": "#hex",
  "font_heading": "Google Font name",
  "font_body": "Google Font name",
  "dark_mode": false,
  "pages": [
    {
      "filename": "index.html",
      "title": "Home",
      "sections": [
        {"type": "hero|nav|features|pricing|cta|footer|gallery|...", "content": "what goes here"}
      ]
    }
  ],
  "features": ["list", "of", "interactive", "features"],
  "animations": true,
  "charts": false,
  "map": false,
  "contact_form": false,
  "cdn_libraries": []
}
"""

WEBSITE_CODER_SYSTEM = """You are a world-class frontend developer creating production-grade websites.

CRITICAL RULES:
1. Write COMPLETE HTML files — every file fully implemented. Zero placeholders. Zero TODOs.
2. All CSS inline in <style> tags. All JS inline in <script> tags. CDN libraries from cdnjs OK.
3. Real, meaningful content — not lorem ipsum. Write actual copy for the site.
4. Beautiful, modern design: gradients, shadows, hover effects, CSS transitions.
5. Fully mobile-responsive with media queries for 320px-1920px.
6. Navigation works — all internal links point to correct filenames.
7. Charts use Chart.js from cdnjs with real, realistic data.
8. Consistent design language across all pages (same fonts, colors, navbar).
9. Contact forms are complete HTML.
10. Include Google Fonts via <link>.

Return ONLY a JSON object where keys = filenames and values = complete HTML content:
{
  "index.html": "<!DOCTYPE html>...",
  "about.html": "<!DOCTYPE html>..."
}
"""

WEBAPP_CODER_SYSTEM = """You are an expert in building single-page web applications with vanilla JS.

CRITICAL RULES:
1. Complete, fully functional SPA — all features work end-to-end.
2. Real data persistence with localStorage or IndexedDB.
3. Beautiful, app-like UI (not just a website).
4. Full CRUD — create, read, update, delete all work.
5. Real-time UI updates — no page reloads.
6. Mobile-friendly touch interactions.
7. Error states and empty states designed properly.

Return: { "index.html": "complete self-contained app..." }
"""


async def _architect_site(description: str, site_type_hint: str, ai) -> dict:
    type_note = f"\nSite type: {site_type_hint}" if site_type_hint else ""
    messages = [{"role": "user", "content": f"Design a website for:\n{description}{type_note}\n\nReturn ONLY JSON."}]
    raw = await ai.chat(messages, system=SITE_ARCHITECT_SYSTEM, max_tokens=2000, temperature=0.3)
    raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    return {"site_name": "Website", "site_type": site_type_hint or "website", "pages": [
        {"filename": "index.html", "title": "Home", "sections": [{"type": "hero", "content": description}]}
    ]}


async def _generate_website_files(spec: dict, description: str, is_app: bool, ai) -> dict[str, str]:
    system = WEBAPP_CODER_SYSTEM if is_app else WEBSITE_CODER_SYSTEM
    pages_desc = "\n".join(
        f"  - {p['filename']} ({p['title']}): {', '.join(s['type'] for s in p.get('sections', []))}"
        for p in spec.get("pages", [])
    )
    prompt = (
        f"Create a complete {'web application' if is_app else 'website'}.\n\n"
        f"Request: {description}\n\n"
        f"Spec:\n"
        f"- Name: {spec.get('site_name')}\n"
        f"- Type: {spec.get('site_type')}\n"
        f"- Colors: primary={spec.get('color_primary','#2563eb')}, secondary={spec.get('color_secondary','#1e40af')}, accent={spec.get('color_accent','#f59e0b')}\n"
        f"- Fonts: {spec.get('font_heading','Inter')} / {spec.get('font_body','Inter')}\n"
        f"- Dark mode: {spec.get('dark_mode', False)}\n"
        f"- Pages:\n{pages_desc}\n"
        f"- Features: {', '.join(spec.get('features', []))}\n"
        f"{'- Use Chart.js from cdnjs for charts with realistic data' if spec.get('charts') else ''}\n"
        f"{'- Embed Google Maps iframe' if spec.get('map') else ''}\n\n"
        f"Generate ALL pages. Complete production code. Return ONLY JSON."
    )
    messages = [{"role": "user", "content": prompt}]
    raw = await ai.chat(messages, system=system, max_tokens=8000, temperature=0.2)
    raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    return {}


async def _fallback_single_file(description: str, spec: dict, ai) -> dict[str, str]:
    system = "You are an expert web developer. Return ONLY valid HTML. No JSON. No markdown fences."
    prompt = (
        f"Create a complete, production-quality website for: {description}\n"
        f"Site name: {spec.get('site_name', 'Website')}\n"
        f"Primary color: {spec.get('color_primary', '#2563eb')}\n"
        f"Include navigation, hero, all relevant sections, footer.\n"
        f"Mobile responsive. Beautiful design. Real content. No lorem ipsum."
    )
    messages = [{"role": "user", "content": prompt}]
    raw = await ai.chat(messages, system=system, max_tokens=6000, temperature=0.2)
    raw = re.sub(r"^```html\s*", "", raw.strip(), flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw.strip())
    if not raw.strip().lower().startswith("<!doctype") and "<html" not in raw.lower():
        raw = (
            f"<!DOCTYPE html><html lang='en'><head>"
            f"<meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>{esc(spec.get('site_name','Website'))}</title></head><body>{raw}</body></html>"
        )
    return {"index.html": raw}


def _create_zip_website(site_name: str, files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    safe = re.sub(r"[^a-zA-Z0-9_-]", "_", site_name)[:30]
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, content in files.items():
            zf.writestr(f"{safe}/{fname}", content)
        page_list = "\n".join(f"- {f}" for f in sorted(files.keys()))
        readme = f"# {site_name}\n\n## View\nOpen `index.html` in any browser.\n\n## Deploy Free\n- Netlify: drag & drop\n- Vercel: `npx vercel`\n- GitHub Pages: push + enable Pages\n\n## Files\n{page_list}\n"
        zf.writestr(f"{safe}/README.md", readme)
    buf.seek(0)
    return buf.getvalue()


class WebsiteHandlers:

    @require_auth
    async def cmd_website(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/website <description> — Agentic production-grade website builder."""
        msg = update.effective_message
        chat_id = msg.chat_id

        if not ctx.args:
            await msg.reply_text(
                "🌐 <b>Salim Website Builder</b>\n\n"
                "Turns any prompt into a complete, multi-page production website.\n\n"
                "<b>Usage:</b> <code>/website &lt;description&gt;</code>\n\n"
                "<b>Templates:</b>\n"
                "• <code>/website landing My SaaS Product</code>\n"
                "• <code>/website store My Online Shop</code>\n"
                "• <code>/website portfolio Photography Studio</code>\n"
                "• <code>/website dashboard Sales Analytics</code>\n"
                "• <code>/website app Kanban Board with drag-and-drop</code>\n"
                "• <code>/website saas AI Writing Tool</code>\n\n"
                "<b>Or describe anything:</b>\n"
                "<code>/website A restaurant with menu, gallery and reservations</code>\n\n"
                "✅ Multi-page | ✅ Real content | ✅ Mobile-responsive | ✅ Deploy-ready",
                parse_mode=H
            )
            return

        args = list(ctx.args)
        description = " ".join(args)
        site_type_map = {
            "landing": "landing", "saas": "saas", "portfolio": "portfolio",
            "blog": "blog", "dashboard": "dashboard", "store": "store",
            "shop": "store", "resume": "portfolio", "app": "webapp",
        }
        site_type_hint = ""
        is_app = False
        if args and args[0].lower() in site_type_map:
            site_type_hint = site_type_map[args[0].lower()]
            is_app = site_type_hint == "webapp"

        if chat_id in _website_tasks and not _website_tasks[chat_id].done():
            _website_tasks[chat_id].cancel()

        status_msg = await msg.reply_text(
            f"🌐 <b>Building Website</b>\n<i>{esc(description[:100])}</i>\n\n"
            f"<i>🧠 Designing architecture…</i>",
            parse_mode=H
        )

        task = asyncio.create_task(
            self._website_build_loop(chat_id, description, site_type_hint, is_app, status_msg)
        )
        _website_tasks[chat_id] = task

    async def _website_build_loop(self, chat_id, description, site_type_hint, is_app, status_msg):
        from salim.ai import SalimAI
        ai = SalimAI(self.config)
        start = time.time()

        async def upd(text):
            try:
                await status_msg.edit_text(
                    f"🌐 <b>Building Website</b>\n<i>{esc(description[:80])}</i>\n\n<i>{esc(text)}</i>",
                    parse_mode=H
                )
            except Exception:
                pass

        try:
            await upd("🧠 Step 1/3: Designing site architecture…")
            spec = await _architect_site(description, site_type_hint, ai)
            site_name = spec.get("site_name", "Website")
            num_pages = len(spec.get("pages", []))

            await upd(f"✅ Architecture: {esc(site_name)} | {num_pages} pages\n\n🎨 Step 2/3: Generating all files…")
            files = await _generate_website_files(spec, description, is_app, ai)
            if not files:
                files = await _fallback_single_file(description, spec, ai)

            await upd(f"✅ {len(files)} files\n\n📦 Step 3/3: Packaging…")
            zip_bytes = _create_zip_website(site_name, files)
            elapsed = time.time() - start

            try:
                await status_msg.delete()
            except Exception:
                pass

            pages = sorted(k for k in files if k.endswith(".html"))
            page_list = "\n".join(f"  • {p}" for p in pages[:10])
            feats = ", ".join(spec.get("features", [])[:5])

            zip_buf = io.BytesIO(zip_bytes)
            zip_buf.name = f"{re.sub(r'[^a-zA-Z0-9_-]', '_', site_name)}.zip"

            await self._app.bot.send_document(
                chat_id=chat_id,
                document=zip_buf,
                filename=zip_buf.name,
                caption=(
                    f"🌐 <b>{esc(site_name)}</b>\n"
                    f"<i>{esc(spec.get('tagline',''))}</i>\n\n"
                    f"📁 <b>{len(files)} files</b> | {len(zip_bytes)//1024} KB | {elapsed:.0f}s\n\n"
                    f"<b>Pages:</b>\n{esc(page_list)}\n\n"
                    f"<b>Features:</b> {esc(feats)}\n\n"
                    f"📖 Open <code>index.html</code> in any browser.\n"
                    f"🚀 Deploy free: Netlify · Vercel · GitHub Pages"
                ),
                parse_mode=H
            )

            # Send raw index.html if single-page
            if len(pages) == 1 and files.get("index.html") and len(files["index.html"]) < 60000:
                hbuf = io.BytesIO(files["index.html"].encode())
                hbuf.name = "index.html"
                await self._app.bot.send_document(
                    chat_id=chat_id, document=hbuf, filename="index.html",
                    caption="⚡ <i>Open directly in browser</i>", parse_mode=H
                )

        except asyncio.CancelledError:
            try:
                await status_msg.edit_text("🛑 Website build cancelled.", parse_mode=H)
            except Exception:
                pass
        except Exception as e:
            logger.exception(f"Website build error: {e}")
            await self._app.bot.send_message(
                chat_id=chat_id,
                text=f"❌ <b>Website build error:</b> {esc(str(e)[:300])}",
                parse_mode=H
            )
