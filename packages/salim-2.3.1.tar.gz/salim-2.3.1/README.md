# Salim v14 — Your AI-Powered Laptop Command Center

Control your entire computer from Telegram. Generate production-ready websites and mobile apps from a single prompt. Run autonomous multi-step agents. Deep research. Code execution. And much more.

---

## What Is Salim?

Salim is a Telegram bot that runs on your laptop and gives you full AI-powered control over it — from anywhere in the world. Think of it as Manus AI + a remote desktop + a code runner, all inside Telegram.

**Key capabilities:**
- **Natural language everything** — just type what you want, the AI handles it
- **Agentic task execution** — multi-step autonomous planning and execution
- **Production app & website generation** — real code, not prototypes
- **Full system control** — shell, files, processes, browser, SSH, screenshots
- **Deep research** — multi-source synthesis into professional reports
- **Code writer + runner** — AI writes and executes code on your machine

---

## Quick Start

```bash
pip install salim
salim setup        # enter your Telegram bot token + AI API key
salim start        # bot goes live
```

Open Telegram → find your bot → send `/start`

---

## Installation

```bash
pip install salim
# For everything (vision AI, offline TTS, etc.):
pip install salim[all]
```

**Requirements:**
- Python 3.9+
- A Telegram Bot Token ([get one from @BotFather](https://t.me/botfather))
- At least one AI API key (NVIDIA NIM, Groq, or OpenAI)

---

## Configuration

```bash
salim setup
```

This walks you through setting:
- `SALIM_BOT_TOKEN` — Telegram bot token
- `SALIM_ALLOWED_IDS` — your Telegram user ID(s) (security)
- `SALIM_NVIDIA_API_KEY` — NVIDIA NIM key (recommended, free tier available)
- `SALIM_GROQ_API_KEY` — Groq key (fast, free)
- `SALIM_OPENAI_API_KEY` — OpenAI fallback

AI providers are tried in order: NVIDIA → Groq → ZAI → OpenAI.

---

## Feature Reference

### 📱 Mobile App Builder (NEW in v14)

Turn any prompt into a complete, production-ready mobile app. No mocks. No placeholders. Real code you can run on a real device.

```
/app <description>               — auto-select best platform
/app react <description>         — React Native (Expo)
/app flutter <description>       — Flutter (iOS + Android)
/app pwa <description>           — Progressive Web App (installable)
/appstatus                       — check build progress
/appstop                         — stop running build
/applog                          — show build log
```

**Examples:**
```
/app a fitness tracker with workout logging, progress charts and streak system
/app react an e-commerce app with product catalog, cart, checkout and order history
/app flutter a meditation timer with breathing exercises, ambient sounds and stats
/app pwa a budget tracker with categories, charts and monthly summaries
```

**What you get:**
- Complete source code ZIP (all files, ready to run)
- Real navigation between all screens
- Data persistence (no data loss on restart)
- Beautiful, polished UI
- Setup & run instructions (`SETUP.md` in the ZIP)

**Supported platforms:**
| Platform | Command | Output |
|----------|---------|--------|
| React Native (Expo) | `/app react ...` | TypeScript project, runs via `npx expo start` |
| Flutter | `/app flutter ...` | Dart project, runs via `flutter run` |
| PWA | `/app pwa ...` | HTML/JS/CSS, installable on iOS & Android |

---

### 🌐 Website Builder (Enhanced in v14)

Agentic multi-pass website generation. Produces multi-page, production-ready sites.

```
/website <description>           — complete website from description
/website landing <product>       — SaaS landing page
/website store <name>            — e-commerce store
/website portfolio <niche>       — creative portfolio
/website dashboard <title>       — interactive analytics dashboard
/website app <description>       — single-page web application
/website saas <product>          — full SaaS marketing site
/website blog <topic>            — blog / magazine
```

**Examples:**
```
/website a restaurant for Bella Italia with full menu, gallery, reservations and map
/website landing TaskFlow — AI project management for remote teams
/website app a kanban board with drag-and-drop, labels and due dates
/website store Luxe Candles — product grid, filters, cart and checkout
```

**What you get:**
- Multi-page HTML/CSS/JS ZIP (open in browser, no server needed)
- Real, meaningful copy (not lorem ipsum)
- Mobile-responsive design
- Working navigation between pages
- Deploy to Netlify / Vercel / GitHub Pages for free

---

### 🤖 Autonomous Agent

Multi-step autonomous task executor. Give it a goal; it plans and executes.

```
/agent <goal>        — start autonomous task
/agentstop           — stop running agent
/agentstatus         — check what's happening
/agentlog            — show execution log
```

**Tools the agent can use:**
- Shell commands
- File read/write
- Python execution
- URL fetching / web browsing
- AI sub-calls

**Examples:**
```
/agent find all Python files modified today and count lines of code
/agent check disk usage, find the 5 largest directories and save a report
/agent research the latest developments in quantum computing and write a summary
/agent monitor CPU usage for 30 seconds and report average and peaks
```

---

### 🔬 Deep Research

Multi-source research synthesis into a comprehensive report.

```
/research <topic>    — deep research (searches + synthesizes)
/researchstop        — stop research
```

**Example:**
```
/research impact of large language models on software engineering productivity
```

Searches multiple angles, fetches full page content, synthesizes into a structured report with sections, findings, and sources.

---

### 🧑‍💻 Code Writer & Runner

AI writes production-quality code, auto-installs dependencies, runs it, and sends you the output + code file.

```
/code <description>   — AI writes + runs code
/code save            — save last code to Desktop
/code last            — re-run last code
/run <bash command>   — run shell command directly
/run python <code>    — run Python snippet
/run js <code>        — run JavaScript via Node.js
```

**Examples:**
```
/code scrape top 10 HackerNews stories and save as CSV
/code analyze disk usage and show largest folders as bar chart
/code generate a PDF report of system statistics
/code find all duplicate files in ~/Downloads
```

---

### 🖥️ System Control

```
/screenshot          — take screenshot
/stream              — live screen stream (updates every N seconds)
/info                — system overview (CPU, RAM, disk, battery)
/top                 — live resource monitor
/ps                  — running processes
/kill <pid>          — kill process
/cpu                 — CPU usage details
/mem                 — memory details
/disk                — disk usage
/battery             — battery status
/network             — network info
```

---

### 📁 File Operations

```
/ls [path]           — list files
/download <path>     — download file from laptop
/upload              — upload file to laptop (send document)
/rm <path>           — delete file (with confirmation)
/mv <src> <dst>      — move/rename file
/cp <src> <dst>      — copy file
/cat <path>          — read file content
/find <pattern>      — search files
/zip <path>          — zip a file or folder
/unzip <file>        — extract zip
```

---

### 🖱️ Desktop Control

```
/type <text>         — type text on screen
/key <shortcut>      — press keyboard shortcut (e.g. ctrl+c)
/click               — mouse click at coordinates
/scroll              — scroll up/down
/notify <msg>        — send desktop notification
/volume [0-100]      — get or set system volume
/copy <text>         — copy to clipboard
/paste               — read clipboard (text or image)
```

---

### 🌍 Browser Automation

```
/browse <url>        — open URL, take screenshot
/browse_click <sel>  — click element (CSS selector)
/browse_type <sel> <text> — type in form field
/browse_js <code>    — execute JavaScript
/browse_close        — close browser session
```

---

### 🔊 Text-to-Speech

```
/tts <text>          — send voice message (online TTS)
/say <text>          — speak aloud on laptop speakers (offline TTS)
/tts_lang <code>     — set TTS language (e.g. ar, es, fr)
/tts_engine          — switch TTS engine
```

---

### 🖥️ SSH Remote Control

```
/ssh_add <name> <host> <user>  — register SSH host
/ssh_list                       — list SSH hosts
/ssh <name> <command>           — run command on remote machine
/ssh_upload <name> <local> <remote> — upload file via SSH
/ssh_download <name> <remote>       — download file from remote
```

---

### 👁️ Vision AI

```
/vision              — analyze last photo (reply to any image)
/askvision <question> — ask question about last photo
```

Send any photo → Salim describes it, reads text, answers questions.

---

### 📊 Data Analyst

```
/analyze <description>  — AI analyzes data and generates charts
/dashboard <title>      — create interactive dashboard
/plotcsv                — plot a CSV file (reply to CSV document)
```

---

### 📧 Email

```
/email setup         — configure email account (IMAP/SMTP)
/email inbox         — read recent emails
/email send <to> <subject> <body>  — send email
/email search <query>              — search emails
```

---

### ⚙️ Workflow Automation

Chain multiple tools into named workflows. Run them on demand.

```
/workflow list                    — list saved workflows
/workflow run <name>              — run a workflow
/workflow save <name> | <steps>   — save a workflow
/workflow template daily_briefing — install daily briefing template
/workflow template system_report  — install system report template
```

---

### 🗓️ Scheduler

```
/at <time> <command>     — schedule a command (e.g. /at 09:00 /screenshot)
/every <interval> <cmd>  — repeat command (e.g. /every 1h /disk)
/jobs                    — list scheduled jobs
/jobcancel <id>          — cancel a job
```

---

### 🧠 Memory & Personalization

```
/memory              — view your persistent profile
/memory set <key> <value>  — set a preference
```

Salim remembers your name, preferences, timezone, habits across sessions.

---

### 📝 Notes

```
/note <text>         — save a quick note
/notes               — list all notes
/notedel <id>        — delete a note
```

---

### 🔌 Skills (Plugins)

```
/skills              — list loaded skill plugins
/skilladd <url>      — install a skill from URL
```

Add custom Python skills to `~/.salim/skills/` to extend Salim's functionality.

---

### Other Features

| Command | Description |
|---------|-------------|
| `/speedtest` | Internet speed test (download/upload/ping) |
| `/qr <text>` | Generate QR code |
| `/qrread` | Read QR code from photo |
| `/cam` | Webcam snapshot |
| `/record <seconds>` | Record screen |
| `/translate <text>` | Translate text |
| `/pdf` | Work with PDF files |
| `/slides` | Create presentations |
| `/doc` | Create Word/Excel documents |
| `/alert set cpu 80` | Alert when CPU exceeds 80% |
| `/guard on` | Intrusion detection (motion alerts) |
| `/watch <path>` | Watch file/folder for changes |
| `/heartbeat` | Enable daily briefings |

---

## AI Provider Setup

### NVIDIA NIM (Recommended — Free Tier)
1. Go to [build.nvidia.com](https://build.nvidia.com)
2. Create account → get API key
3. `salim config set SALIM_NVIDIA_API_KEY <key>`

### Groq (Fast, Free)
1. Go to [console.groq.com](https://console.groq.com)
2. Create account → create API key
3. `salim config set SALIM_GROQ_API_KEY <key>`

### OpenAI
1. Go to [platform.openai.com](https://platform.openai.com)
2. Create API key
3. `salim config set SALIM_OPENAI_API_KEY <key>`

---

## Security

- All commands require authentication — only allowed Telegram IDs can use the bot
- Config stored in `~/.salim/config.env` with `chmod 600` permissions
- Full audit log available via `/logs`
- Intrusion detection with `/guard`

Set your allowed IDs:
```bash
salim config set SALIM_ALLOWED_IDS "123456789,987654321"
```

---

## Architecture

```
salim/
├── bot.py                    # Main bot class (all handlers composed via mixins)
├── ai.py                     # Multi-provider AI backend (NVIDIA/Groq/ZAI/OpenAI)
├── ai_search.py              # AI with web search
├── config.py                 # Configuration management
├── utils.py                  # Shared utilities
└── handlers/
    ├── agent.py              # Autonomous multi-step agent
    ├── ai_handler.py         # Natural language AI handler
    ├── analyst.py            # Data analysis + visualization
    ├── alerts.py             # System threshold alerts
    ├── browser.py            # Browser automation (Playwright)
    ├── camera.py             # Webcam capture
    ├── clipboard_image.py    # Clipboard image support
    ├── code_runner.py        # AI code generation + execution
    ├── document_writer.py    # Word/Excel document creation
    ├── email_handler.py      # Email IMAP/SMTP
    ├── files.py              # File operations
    ├── guard.py              # Intrusion detection
    ├── heartbeat.py          # Proactive daily briefings
    ├── history.py            # Conversation history
    ├── memory.py             # Persistent user memory
    ├── mobile_app.py         # ★ Mobile app builder (React Native/Flutter/PWA)
    ├── notes_handler.py      # Quick notes
    ├── pdf_handler.py        # PDF operations
    ├── power.py              # Shutdown/restart/sleep/lock
    ├── qr_handler.py         # QR code generate/read
    ├── research.py           # Deep multi-source research
    ├── scheduler_handler.py  # Task scheduler
    ├── scraper.py            # Web scraping
    ├── screen.py             # Screenshots + screen recording
    ├── shell.py              # Shell command execution
    ├── skills.py             # Dynamic plugin system
    ├── slides.py             # Presentation creation
    ├── smart_upload.py       # Smart file upload handler
    ├── speedtest_handler.py  # Internet speed test
    ├── ssh_handler.py        # SSH remote control
    ├── stream.py             # Live screen streaming
    ├── system.py             # System info
    ├── translate.py          # Text translation
    ├── tts.py                # Text-to-speech
    ├── vision.py             # Vision AI (image analysis)
    ├── voice.py              # Voice message transcription
    ├── watcher_handler.py    # File system watcher
    ├── website.py            # ★ Agentic website builder
    └── workflow.py           # Multi-step workflow automation
```

---

## What's New in v14

### New: Mobile App Builder (`/app`)
- React Native (Expo), Flutter, and PWA support
- Agentic multi-pass generation (prompt → spec → full code → validation → ZIP)
- All screens fully implemented with real logic
- Data persistence built in
- Beautiful polished UI
- Runnable on real devices

### Enhanced: Website Builder (`/website`)
- Full agentic pipeline (architect → multi-page generation → validation → ZIP)
- Multi-page sites with working navigation
- Real, meaningful content (not lorem ipsum)
- Support for SPAs, dashboards, stores, portfolios, SaaS sites
- Outputs both ZIP and standalone HTML

---

## Comparison with Manus AI

| Feature | Manus AI | Salim v14 |
|---------|----------|-----------|
| Web browsing & research | ✅ | ✅ |
| Autonomous task agent | ✅ | ✅ |
| Website generation | ✅ | ✅ |
| Mobile app generation | ✅ | ✅ **NEW** |
| Code execution | ✅ | ✅ |
| File management | ✅ | ✅ |
| Email integration | ✅ | ✅ |
| System control | ❌ | ✅ |
| SSH remote control | ❌ | ✅ |
| Screen recording | ❌ | ✅ |
| Runs locally (privacy) | ❌ | ✅ |
| Free/self-hosted | ❌ | ✅ |
| Telegram interface | ❌ | ✅ |

---

## License

MIT License. See LICENSE file.

---

## Contributing

PRs welcome. Add skills to `~/.salim/skills/` — they load automatically at startup.
