"""Gauge Coupling Map — Standard Model RG vs Watkins Simplex Flow.

Maps root system conservation triples onto Standard Model gauge coupling
ratios and compares the Watkins simplex flow trajectory to the SM
renormalization group running.

Key idea: The SM gauge couplings (alpha_3, alpha_2, alpha_1) normalized
to sum to 1 trace a curve on the probability simplex — the same space
where the Watkins conservation law lambda + kappa + eta = 1 operates.
This module computes both trajectories and measures their relationship.

Dependencies: math, numpy only (no torch).
"""

import math
from typing import Dict, List, Tuple

import numpy as np

from .constants import (
    PHI,
    PHI_INV,
    T_STAR,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    CONSERVATION_EPSILON,
)
from .bridges import root_system_conservation
from .cascade import EXCEPTIONAL_BCC_EIGENVALUES

# =============================================================================
# STANDARD MODEL CONSTANTS
# =============================================================================

# Z boson mass (GeV)
M_Z = 91.1876

# Inverse couplings at M_Z (PDG values, GUT-normalized alpha_1)
ALPHA1_INV_MZ = 59.0   # alpha_1^{-1}(M_Z), GUT normalized: alpha_1 = (5/3)*alpha_Y
ALPHA2_INV_MZ = 29.6   # alpha_2^{-1}(M_Z)
ALPHA3_INV_MZ = 8.5    # alpha_3^{-1}(M_Z)

# 1-loop beta coefficients (SM with 3 generations)
B1 = 41.0 / 10.0   # b_1 = 41/10 = 4.1
B2 = -19.0 / 6.0   # b_2 = -19/6 ~ -3.167
B3 = -7.0           # b_3 = -7

TWO_PI = 2.0 * math.pi


# =============================================================================
# FUNCTION 1: SM coupling ratios at any scale
# =============================================================================

def sm_inverse_couplings(mu_gev: float) -> Tuple[float, float, float]:
    """Compute raw 1-loop inverse couplings (1/alpha_1, 1/alpha_2, 1/alpha_3) at scale mu.

    Uses 1-loop RG running:
        1/alpha_i(mu) = 1/alpha_i(M_Z) + (b_i / 2*pi) * ln(mu / M_Z)

    Parameters:
        mu_gev: Energy scale in GeV (must be > 0).

    Returns:
        (1/alpha_1, 1/alpha_2, 1/alpha_3) -- may be negative beyond Landau pole.
    """
    if mu_gev <= 0:
        raise ValueError("Energy scale mu must be positive")

    log_ratio = math.log(mu_gev / M_Z)
    a1_inv = ALPHA1_INV_MZ + (B1 / TWO_PI) * log_ratio
    a2_inv = ALPHA2_INV_MZ + (B2 / TWO_PI) * log_ratio
    a3_inv = ALPHA3_INV_MZ + (B3 / TWO_PI) * log_ratio
    return (a1_inv, a2_inv, a3_inv)


# QCD Landau pole: mu where 1/alpha_3 = 0 under 1-loop running
# 8.5 + (-7/2pi)*ln(mu/M_Z) = 0  =>  mu ~ 1.88e5 GeV
_ALPHA3_LANDAU_POLE = M_Z * math.exp(ALPHA3_INV_MZ * TWO_PI / abs(B3))

# Safe upper limit: stay well below the Landau pole
_MU_MAX_PERTURBATIVE = _ALPHA3_LANDAU_POLE * 0.5


def sm_coupling_ratios(mu_gev: float) -> Tuple[float, float, float]:
    """Compute (alpha_3/alpha_tot, alpha_2/alpha_tot, alpha_1/alpha_tot) at energy scale mu (GeV).

    Uses 1-loop RG running:
        1/alpha_i(mu) = 1/alpha_i(M_Z) + (b_i / 2*pi) * ln(mu / M_Z)

    Input values at M_Z = 91.1876 GeV:
        alpha_1^{-1} = 59.0 (GUT normalized: alpha_1 = (5/3)*alpha_Y)
        alpha_2^{-1} = 29.6
        alpha_3^{-1} = 8.5

    Beta coefficients (SM, 3 generations):
        b_1 = 41/10, b_2 = -19/6, b_3 = -7

    Note: 1-loop running is only valid below the QCD Landau pole
    (~1.9e5 GeV). Above that, alpha_3 becomes non-perturbative.
    This function clamps inverse couplings to a small positive
    floor to remain well-defined on the simplex.

    Parameters:
        mu_gev: Energy scale in GeV (must be > 0).

    Returns:
        Normalized triple (r_3, r_2, r_1) on the probability simplex,
        where r_i = alpha_i / (alpha_1 + alpha_2 + alpha_3).
        Ordered as (strong, weak, hypercharge) = (lambda, kappa, eta)
        to match the Watkins convention (largest component first at low energy).
    """
    if mu_gev <= 0:
        raise ValueError("Energy scale mu must be positive")

    a1_inv, a2_inv, a3_inv = sm_inverse_couplings(mu_gev)

    # All inverse couplings must be positive for perturbative result.
    # Beyond the QCD Landau pole (~1.9e5 GeV), 1/alpha_3 goes negative
    # under 1-loop running, which is unphysical.
    #
    # We use inverse-coupling normalized ratios:
    #   s_i = (1/alpha_i) / sum_j (1/alpha_j)
    # These are well-defined everywhere the inverse couplings are positive,
    # and give a smooth trajectory that approaches (1/3,1/3,1/3) at
    # unification.  At low energy, the SMALLEST inverse coupling (alpha_3)
    # has the smallest s_3, reflecting that strong coupling is largest.
    #
    # Convention: We ORDER as (1 - s_3, s_3_adj, ...) to keep lambda
    # = strong, kappa = weak, eta = hypercharge in the Watkins mapping.
    # Specifically: lambda = s_3/s_tot (strong has smallest 1/alpha),
    # but to match the convention where lambda is LARGEST, we use the
    # complementary ratio.
    #
    # SIMPLEST: just use direct coupling ratios with all-positive clamp.
    eps = 0.5  # Keep 1/alpha_i >= 0.5 (alpha_i <= 2)
    a1_inv = max(a1_inv, eps)
    a2_inv = max(a2_inv, eps)
    a3_inv = max(a3_inv, eps)

    a1 = 1.0 / a1_inv
    a2 = 1.0 / a2_inv
    a3 = 1.0 / a3_inv
    total = a1 + a2 + a3
    return (a3 / total, a2 / total, a1 / total)


# =============================================================================
# FUNCTION 2: SM RG trajectory on simplex
# =============================================================================

def sm_rg_trajectory(
    mu_min: float = 1.0,
    mu_max: float = 1e16,
    n_points: int = 1000,
) -> np.ndarray:
    """Compute the SM coupling ratio trajectory on the probability simplex.

    Traces how the normalized gauge coupling triple (r_3, r_2, r_1)
    evolves from mu_min to mu_max GeV under 1-loop RG running.

    Parameters:
        mu_min: Minimum energy scale in GeV (default: 1 GeV).
        mu_max: Maximum energy scale in GeV (default: 10^16 GeV).
        n_points: Number of sample points (default: 1000).

    Returns:
        np.ndarray of shape (n_points, 3) with columns (lambda, kappa, eta)
        = (r_3, r_2, r_1) at logarithmically spaced energy scales.
    """
    log_mu = np.linspace(math.log(mu_min), math.log(mu_max), n_points)
    trajectory = np.zeros((n_points, 3))

    for i, lm in enumerate(log_mu):
        mu = math.exp(lm)
        trajectory[i] = sm_coupling_ratios(mu)

    return trajectory


# =============================================================================
# FUNCTION 3: Root system conservation comparison
# =============================================================================

# Exceptional root systems supported by bcc_grid / root_system_conservation.
# G2 uses a separate formula (g2_bcc_formula) and is handled specially.
_EXCEPTIONAL_SYSTEMS = ['E6', 'E7', 'E8', 'F4']


def _g2_conservation_triple() -> Dict:
    """Compute G2 conservation triple from its known BCC eigenvalues.

    G2 has eigenvalues (2+sqrt(6), 2-sqrt(6), -2). Since it has a
    negative eigenvalue, it does NOT lie on the probability simplex.
    We still compute the normalized triple for comparison.
    """
    eigs = sorted(EXCEPTIONAL_BCC_EIGENVALUES['G2'], reverse=True)
    trace = sum(eigs)
    if abs(trace) < 1e-12:
        return {
            'system': 'G2',
            'lambda_R': float('nan'),
            'kappa_R': float('nan'),
            'eta_R': float('nan'),
            'on_simplex': False,
            'degenerate': True,
        }
    lam = eigs[0] / trace
    kap = eigs[1] / trace
    eta = eigs[2] / trace
    on_simplex = all(v >= -1e-12 for v in [lam, kap, eta])
    return {
        'system': 'G2',
        'lambda_R': lam,
        'kappa_R': kap,
        'eta_R': eta,
        'on_simplex': on_simplex,
        'degenerate': False,
    }


def root_system_gauge_comparison() -> Dict:
    """Compare root system conservation triples to SM coupling ratios.

    For each exceptional root system (E6, E7, E8, F4, G2), computes the
    conservation triple (lambda_R, kappa_R, eta_R) from BCC eigenvalues
    and finds the energy scale where the SM coupling ratios come closest.

    The search uses logarithmic scanning over [1 GeV, 10^5 GeV]
    (the perturbative regime below the QCD Landau pole).

    Returns:
        Dict mapping root system name to:
            - 'triple': (lambda_R, kappa_R, eta_R)
            - 'best_scale_gev': energy scale of closest SM match
            - 'distance': Euclidean distance at best match
            - 'sm_triple_at_match': SM ratios at best match scale
            - 'on_simplex': whether the triple is on the simplex
    """
    # Scan energy scales (perturbative regime only)
    n_scan = 5000
    mu_max = min(_MU_MAX_PERTURBATIVE, 1e5)
    log_mu = np.linspace(math.log(1.0), math.log(mu_max), n_scan)
    scales = np.exp(log_mu)

    sm_points = np.zeros((n_scan, 3))
    for i, mu in enumerate(scales):
        sm_points[i] = sm_coupling_ratios(float(mu))

    results = {}

    # Process E6, E7, E8, F4 via root_system_conservation
    for system in _EXCEPTIONAL_SYSTEMS:
        rc = root_system_conservation(system)

        if rc.get('degenerate', False):
            results[system] = {
                'triple': (float('nan'), float('nan'), float('nan')),
                'best_scale_gev': float('nan'),
                'distance': float('nan'),
                'sm_triple_at_match': (float('nan'), float('nan'), float('nan')),
                'on_simplex': False,
                'degenerate': True,
            }
            continue

        triple = np.array([rc['lambda_R'], rc['kappa_R'], rc['eta_R']])
        diffs = sm_points - triple[np.newaxis, :]
        distances = np.sqrt(np.sum(diffs ** 2, axis=1))
        best_idx = int(np.argmin(distances))

        results[system] = {
            'triple': (rc['lambda_R'], rc['kappa_R'], rc['eta_R']),
            'best_scale_gev': float(scales[best_idx]),
            'distance': float(distances[best_idx]),
            'sm_triple_at_match': tuple(float(x) for x in sm_points[best_idx]),
            'on_simplex': rc['on_simplex'],
            'degenerate': False,
        }

    # G2: use pre-computed eigenvalues (not in bcc_grid)
    g2 = _g2_conservation_triple()
    if g2.get('degenerate', False):
        results['G2'] = {
            'triple': (float('nan'), float('nan'), float('nan')),
            'best_scale_gev': float('nan'),
            'distance': float('nan'),
            'sm_triple_at_match': (float('nan'), float('nan'), float('nan')),
            'on_simplex': False,
            'degenerate': True,
        }
    else:
        triple = np.array([g2['lambda_R'], g2['kappa_R'], g2['eta_R']])
        diffs = sm_points - triple[np.newaxis, :]
        distances = np.sqrt(np.sum(diffs ** 2, axis=1))
        best_idx = int(np.argmin(distances))

        results['G2'] = {
            'triple': (g2['lambda_R'], g2['kappa_R'], g2['eta_R']),
            'best_scale_gev': float(scales[best_idx]),
            'distance': float(distances[best_idx]),
            'sm_triple_at_match': tuple(float(x) for x in sm_points[best_idx]),
            'on_simplex': g2['on_simplex'],
            'degenerate': False,
        }

    return results


# =============================================================================
# FUNCTION 4: Watkins flow vs RG flow comparison
# =============================================================================

def _watkins_simplex_flow_trajectory(n_points: int = 1000) -> np.ndarray:
    """Compute the Watkins gradient flow trajectory from democratic initial condition.

    Uses the same Euler-step gradient flow as flow.py but implemented
    without torch dependency: pure numpy/math.

    Parameters:
        n_points: Number of trajectory points to record.

    Returns:
        np.ndarray of shape (n_points, 3).
    """
    # Start at democratic point
    lam, kap, eta = 1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0

    dt = 0.001
    max_steps = 50000
    record_every = max(1, max_steps // n_points)

    trajectory = []
    T = T_STAR
    eps = 1e-15

    for step in range(max_steps):
        if step % record_every == 0:
            trajectory.append([lam, kap, eta])
            if len(trajectory) >= n_points:
                break

        # Gradient of F = -ln(lam) + T * sum(p_i ln p_i)
        g_lam = -1.0 / max(lam, eps) + T * (math.log(max(lam, eps)) + 1.0)
        g_kap = T * (math.log(max(kap, eps)) + 1.0)
        g_eta = T * (math.log(max(eta, eps)) + 1.0)

        # Project onto simplex tangent plane
        mean_g = (g_lam + g_kap + g_eta) / 3.0
        ng_lam = g_lam - mean_g
        ng_kap = g_kap - mean_g
        ng_eta = g_eta - mean_g

        # Euler step
        lam -= dt * ng_lam
        kap -= dt * ng_kap
        eta -= dt * ng_eta

        # Clamp positive
        lam = max(lam, 1e-12)
        kap = max(kap, 1e-12)
        eta = max(eta, 1e-12)

        # Enforce conservation
        total = lam + kap + eta
        lam /= total
        kap /= total
        eta /= total

    # Pad if needed
    while len(trajectory) < n_points:
        trajectory.append([lam, kap, eta])

    return np.array(trajectory)


def flow_comparison(n_points: int = 1000) -> Dict:
    """Compare Watkins simplex flow trajectory to SM RG trajectory.

    Both flows operate on the probability simplex. The SM flow traces
    how gauge coupling ratios evolve with energy; the Watkins flow
    traces how the free energy gradient drives the system toward
    the golden equilibrium.

    Both trajectories start from (or near) the democratic point
    (1/3, 1/3, 1/3). We compare:
    - Point-by-point distances (after alignment by arc length)
    - Final endpoints
    - Overall trajectory curvature

    Parameters:
        n_points: Number of points in each trajectory.

    Returns:
        Dict with comparison metrics:
            - 'watkins_start': starting point of Watkins flow
            - 'watkins_end': ending point (should be near equilibrium)
            - 'sm_start': SM ratios at GUT scale (near democratic)
            - 'sm_end': SM ratios at low energy
            - 'endpoint_distance': distance between final points
            - 'mean_distance': mean point-by-point distance
            - 'max_distance': maximum point-by-point distance
            - 'watkins_arc_length': total arc length of Watkins trajectory
            - 'sm_arc_length': total arc length of SM trajectory
            - 'arc_length_ratio': ratio of arc lengths
    """
    # Watkins trajectory: democratic -> golden equilibrium
    watkins_traj = _watkins_simplex_flow_trajectory(n_points)

    # SM trajectory: high energy (near democratic) -> low energy (asymmetric)
    # Reverse so both go from democratic toward their attractor
    sm_traj = sm_rg_trajectory(mu_min=1.0, mu_max=1e16, n_points=n_points)
    sm_traj_reversed = sm_traj[::-1].copy()  # GUT scale first

    # Arc lengths
    def arc_length(traj: np.ndarray) -> float:
        diffs = np.diff(traj, axis=0)
        return float(np.sum(np.sqrt(np.sum(diffs ** 2, axis=1))))

    watkins_al = arc_length(watkins_traj)
    sm_al = arc_length(sm_traj_reversed)

    # Point-by-point distances (both have n_points entries)
    distances = np.sqrt(np.sum((watkins_traj - sm_traj_reversed) ** 2, axis=1))

    return {
        'watkins_start': tuple(float(x) for x in watkins_traj[0]),
        'watkins_end': tuple(float(x) for x in watkins_traj[-1]),
        'sm_start': tuple(float(x) for x in sm_traj_reversed[0]),
        'sm_end': tuple(float(x) for x in sm_traj_reversed[-1]),
        'endpoint_distance': float(distances[-1]),
        'mean_distance': float(np.mean(distances)),
        'max_distance': float(np.max(distances)),
        'watkins_arc_length': watkins_al,
        'sm_arc_length': sm_al,
        'arc_length_ratio': watkins_al / sm_al if sm_al > 0 else float('inf'),
        'watkins_trajectory': watkins_traj,
        'sm_trajectory': sm_traj_reversed,
    }


# =============================================================================
# FUNCTION 5: Beta coefficient analysis
# =============================================================================

def beta_phi_analysis() -> Dict:
    """Check if SM beta coefficients relate to the golden ratio phi.

    Computes various ratios of the SM 1-loop beta coefficients:
        b_1 = 41/10 = 4.1
        b_2 = -19/6 ~ -3.167
        b_3 = -7

    and compares them against phi, 1/phi, phi^2, T*, and 1/phi (the
    Watkins universal beta function coefficient from Theorem EB).

    Also examines the SM beta function slopes dg_i/d(ln mu) and checks
    whether any combination reproduces the Watkins universal form
    beta(T) = -T^2/phi.

    Returns:
        Dict with:
            - 'beta_coefficients': the three SM b_i values
            - 'ratios': dict of ratio names to (value, nearest_golden_constant, residual)
            - 'normalized_betas': b_i normalized by sum, product, etc.
            - 'phi_proximity': closest approach of any ratio to phi or 1/phi
            - 'watkins_comparison': comparison to 1/phi universal coefficient
    """
    phi = PHI
    phi_inv = PHI_INV
    phi_sq = phi ** 2

    b1, b2, b3 = B1, B2, B3

    # Golden constants to check against
    golden_constants = {
        'phi': phi,
        '1/phi': phi_inv,
        'phi^2': phi_sq,
        'T*': T_STAR,
        '1': 1.0,
        '2': 2.0,
        'sqrt(5)': math.sqrt(5),
    }

    # Compute pairwise ratios
    raw_ratios = {}
    if abs(b2) > 1e-12:
        raw_ratios['b3/b2'] = b3 / b2
    if abs(b1) > 1e-12:
        raw_ratios['b2/b1'] = b2 / b1
    if abs(b1) > 1e-12:
        raw_ratios['b3/b1'] = b3 / b1
    raw_ratios['|b3/b2|'] = abs(b3 / b2) if abs(b2) > 1e-12 else float('inf')
    raw_ratios['|b2/b1|'] = abs(b2 / b1) if abs(b1) > 1e-12 else float('inf')
    raw_ratios['|b3/b1|'] = abs(b3 / b1) if abs(b1) > 1e-12 else float('inf')

    # Differences between beta coefficients
    raw_ratios['b1 - b2'] = b1 - b2
    raw_ratios['b2 - b3'] = b2 - b3
    raw_ratios['b1 - b3'] = b1 - b3
    raw_ratios['(b1-b2)/(b2-b3)'] = (b1 - b2) / (b2 - b3) if abs(b2 - b3) > 1e-12 else float('inf')
    raw_ratios['(b1-b3)/(b1-b2)'] = (b1 - b3) / (b1 - b2) if abs(b1 - b2) > 1e-12 else float('inf')

    # Sum and product
    raw_ratios['b1+b2+b3'] = b1 + b2 + b3
    raw_ratios['|b1*b2*b3|^(1/3)'] = abs(b1 * b2 * b3) ** (1.0 / 3.0)

    # For each ratio, find nearest golden constant
    ratio_analysis = {}
    for rname, rval in raw_ratios.items():
        if not math.isfinite(rval):
            ratio_analysis[rname] = {
                'value': rval,
                'nearest': 'none',
                'residual': float('inf'),
            }
            continue
        best_name = None
        best_residual = float('inf')
        for gname, gval in golden_constants.items():
            residual = abs(rval - gval)
            if residual < best_residual:
                best_residual = residual
                best_name = gname
        ratio_analysis[rname] = {
            'value': rval,
            'nearest': best_name,
            'residual': best_residual,
        }

    # Closest approach to phi or 1/phi among all ratios
    phi_distances = []
    for rname, rval in raw_ratios.items():
        if math.isfinite(rval):
            phi_distances.append((rname, min(abs(rval - phi), abs(rval - phi_inv))))
    phi_distances.sort(key=lambda x: x[1])
    closest_phi = phi_distances[0] if phi_distances else ('none', float('inf'))

    # Normalized beta coefficients (by total |b|)
    total_abs = abs(b1) + abs(b2) + abs(b3)
    norm_b1 = b1 / total_abs
    norm_b2 = b2 / total_abs
    norm_b3 = b3 / total_abs

    # Watkins comparison: the universal RG coefficient is 1/phi
    # Check how the SM beta coefficients compare
    # The "effective Watkins beta" would be -T^2/phi for each coupling
    watkins_beta_at_mz = -(T_STAR ** 2) / phi

    # SM effective betas at M_Z (in terms of d(alpha_i)/d(ln mu))
    # d(1/alpha_i)/d(ln mu) = b_i/(2*pi)
    # d(alpha_i)/d(ln mu) = -alpha_i^2 * b_i/(2*pi)
    a1_mz = 1.0 / ALPHA1_INV_MZ
    a2_mz = 1.0 / ALPHA2_INV_MZ
    a3_mz = 1.0 / ALPHA3_INV_MZ

    sm_beta_1 = -(a1_mz ** 2) * b1 / TWO_PI
    sm_beta_2 = -(a2_mz ** 2) * b2 / TWO_PI
    sm_beta_3 = -(a3_mz ** 2) * b3 / TWO_PI

    return {
        'beta_coefficients': {'b1': b1, 'b2': b2, 'b3': b3},
        'ratios': ratio_analysis,
        'normalized_betas': {
            'norm_b1': norm_b1,
            'norm_b2': norm_b2,
            'norm_b3': norm_b3,
        },
        'phi_proximity': {
            'closest_ratio_name': closest_phi[0],
            'closest_distance': closest_phi[1],
        },
        'watkins_comparison': {
            'watkins_universal_beta': watkins_beta_at_mz,
            'sm_beta_1_at_MZ': sm_beta_1,
            'sm_beta_2_at_MZ': sm_beta_2,
            'sm_beta_3_at_MZ': sm_beta_3,
            'ratio_sm_beta3_to_watkins': sm_beta_3 / watkins_beta_at_mz if abs(watkins_beta_at_mz) > 1e-15 else float('inf'),
        },
        'golden_checks': {
            'b3_over_b2_vs_phi': abs(b3 / b2 - phi) if abs(b2) > 1e-12 else float('inf'),
            'b_sum_vs_phi': abs((b1 + b2 + b3) - phi_inv),
            'abs_b3_over_b1': abs(b3 / b1),
        },
    }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def sm_coupling_at_mz() -> Tuple[float, float, float]:
    """Return the SM coupling ratios at M_Z as a quick reference.

    Returns:
        (r_3, r_2, r_1) = (strong, weak, hypercharge) normalized to sum = 1.
    """
    return sm_coupling_ratios(M_Z)


def sm_gut_scale_estimate() -> Dict:
    """Analyze SM gauge coupling unification prospects.

    Under 1-loop SM running, the three inverse couplings 1/alpha_i(mu)
    are straight lines in ln(mu):
    - 1/alpha_1 INCREASES (b_1 = 41/10 > 0)
    - 1/alpha_2 DECREASES (b_2 = -19/6 < 0)
    - 1/alpha_3 DECREASES faster (b_3 = -7 < 0)

    In the minimal SM at 1-loop, the couplings DIVERGE at high energy.
    There is no GUT-scale crossing: exact unification requires SUSY
    or other BSM physics. This function reports the divergence rate
    and the Landau pole for alpha_3.

    Returns:
        Dict with:
            - 'no_exact_unification': always True for minimal SM
            - 'landau_pole_alpha3': scale where 1/alpha_3 = 0
            - 'slopes': d(1/alpha_i)/d(ln mu) = b_i/(2pi) for each coupling
            - 'closest_triple': SM simplex ratios at M_Z (for reference)
            - 'distance_from_democratic': distance to (1/3,1/3,1/3) at M_Z
            - 'divergence_rate': how fast the spread grows per e-fold
    """
    # Slopes of inverse couplings in ln(mu)
    slope_1 = B1 / TWO_PI
    slope_2 = B2 / TWO_PI
    slope_3 = B3 / TWO_PI

    # QCD Landau pole: 1/alpha_3(mu) = 0
    landau_mu = _ALPHA3_LANDAU_POLE

    # SM ratios at M_Z
    triple_mz = sm_coupling_ratios(M_Z)
    dem = 1.0 / 3.0
    d_dem = math.sqrt(sum((x - dem) ** 2 for x in triple_mz))

    # Divergence rate: d/d(ln mu) [max(1/alpha) - min(1/alpha)]
    # At M_Z: max = 1/alpha_1 (slope > 0), min = 1/alpha_3 (slope < 0)
    # Rate = slope_1 - slope_3 (both positive/negative contribute to divergence)
    divergence_rate = slope_1 - slope_3

    return {
        'no_exact_unification': True,
        'landau_pole_alpha3': landau_mu,
        'log10_landau_pole': math.log10(landau_mu),
        'slopes': {
            'alpha_1': slope_1,
            'alpha_2': slope_2,
            'alpha_3': slope_3,
        },
        'closest_triple': triple_mz,
        'distance_from_democratic': d_dem,
        'divergence_rate': divergence_rate,
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # SM coupling ratios
    'sm_coupling_ratios',
    'sm_inverse_couplings',
    'sm_rg_trajectory',
    'sm_coupling_at_mz',
    'sm_gut_scale_estimate',
    # Root system comparison
    'root_system_gauge_comparison',
    # Flow comparison
    'flow_comparison',
    # Beta analysis
    'beta_phi_analysis',
    # Constants
    'M_Z',
    'ALPHA1_INV_MZ',
    'ALPHA2_INV_MZ',
    'ALPHA3_INV_MZ',
    'B1',
    'B2',
    'B3',
]
