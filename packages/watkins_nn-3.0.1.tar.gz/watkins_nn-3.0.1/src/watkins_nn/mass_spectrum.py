"""
Mass spectrum analysis for the Watkins framework.

Computes the full 'mass spectrum' from the Watkins Hessian at equilibrium
and compares it to lattice QCD glueball spectra. The Watkins spectral gap
mu_coh = 5.636 is the finite-dimensional, proven analog of the Yang-Mills
mass gap on the probability simplex.

Provides:
  1. watkins_mass_spectrum() — eigenvalues and eigenmodes of the Hessian
  2. glueball_comparison() — comparison to lattice QCD glueball mass ratios
  3. landau_ginzburg_expansion() — LG expansion of Watkins free energy
  4. string_tension_analog() — confinement and string tension analogs
  5. full_spectrum_analysis() — comprehensive spectral/hierarchy analysis

Phase 89.3 | CSID: MASS-SPECTRUM-001
"""

import math
from typing import Dict, List, Tuple, Any

from .constants import (
    PHI,
    PHI_INV,
    PHI_SQUARED,
    T_STAR,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    F_STAR,
    MU_COH,
    MU_ASYM,
    TAU_COH,
    TAU_ASYM,
    CONSERVATION_EPSILON,
)


# =============================================================================
# EIGENVECTORS ON THE SIMPLEX TANGENT PLANE
# =============================================================================

# The 2-simplex tangent plane is spanned by two orthonormal vectors:
#   e_coh  = (2, -1, -1) / sqrt(6)   — coherence mode
#   e_asym = (0, +1, -1) / sqrt(2)   — asymmetry mode
#
# These are the eigenmodes of the Riemannian Hessian at p*.

_SQRT6 = math.sqrt(6)
_SQRT2 = math.sqrt(2)

E_COH = (2.0 / _SQRT6, -1.0 / _SQRT6, -1.0 / _SQRT6)
E_ASYM = (0.0, 1.0 / _SQRT2, -1.0 / _SQRT2)


def _dot(u: Tuple[float, ...], v: Tuple[float, ...]) -> float:
    """Inner product of two tuples."""
    return sum(a * b for a, b in zip(u, v))


def _norm(u: Tuple[float, ...]) -> float:
    """Euclidean norm of a tuple."""
    return math.sqrt(_dot(u, u))


# =============================================================================
# 1. WATKINS MASS SPECTRUM
# =============================================================================

def watkins_mass_spectrum() -> Dict[str, Any]:
    """Compute the full 'mass spectrum' from the Watkins Hessian at equilibrium.

    The Hessian of the free energy F at p* = (1/phi, (1-1/phi)/2, (1-1/phi)/2):

    Riemannian eigenvalues (intrinsic, basis-independent):
      mu_coh  = (2/3) phi^2 (1 + T* phi) ~ 5.636  — coherence mode (2,-1,-1)/sqrt(6)
      mu_asym = 2 T* phi^2               ~ 7.214  — asymmetry mode (0,+1,-1)/sqrt(2)

    These are the 'masses' (inverse correlation lengths) of the two modes.
    The 'mass gap' is mu_coh (smallest nonzero eigenvalue).

    Returns:
        Dict with eigenvalues, eigenvectors, ratios, and physical interpretation.
    """
    # Verify closed-form eigenvalues
    mu_coh_check = (2.0 / 3.0) * PHI_SQUARED * (1 + T_STAR * PHI)
    mu_asym_check = 2.0 * T_STAR * PHI_SQUARED
    assert abs(mu_coh_check - MU_COH) < CONSERVATION_EPSILON
    assert abs(mu_asym_check - MU_ASYM) < CONSERVATION_EPSILON

    # Mass ratio
    mass_ratio = MU_ASYM / MU_COH

    # Verify eigenvector orthogonality
    dot_check = _dot(E_COH, E_ASYM)
    assert abs(dot_check) < CONSERVATION_EPSILON

    # Verify eigenvector normalization
    assert abs(_norm(E_COH) - 1.0) < CONSERVATION_EPSILON
    assert abs(_norm(E_ASYM) - 1.0) < CONSERVATION_EPSILON

    # Verify eigenvectors lie in simplex tangent plane (sum of components = 0)
    assert abs(sum(E_COH)) < CONSERVATION_EPSILON
    assert abs(sum(E_ASYM)) < CONSERVATION_EPSILON

    return {
        # Eigenvalues (masses)
        "mu_coh": MU_COH,
        "mu_asym": MU_ASYM,
        "mass_gap": MU_COH,  # smallest nonzero eigenvalue
        # Eigenvectors (modes)
        "e_coh": E_COH,
        "e_asym": E_ASYM,
        # Decay times (inverse masses)
        "tau_coh": TAU_COH,
        "tau_asym": TAU_ASYM,
        # Ratios
        "mass_ratio": mass_ratio,
        "decay_time_ratio": TAU_COH / TAU_ASYM,
        # Condition number (anisotropy)
        "condition_number": MU_ASYM / MU_COH,
        # Closed-form expressions
        "mu_coh_formula": "(2/3) phi^2 (1 + T* phi)",
        "mu_asym_formula": "2 T* phi^2",
        # Physical interpretation
        "interpretation": {
            "coherence_mode": (
                "Governs relaxation of coherence lambda toward 1/phi. "
                "Slowest mode — sets the mass gap and the mixing time."
            ),
            "asymmetry_mode": (
                "Governs relaxation of asymmetry (kappa - eta) toward 0. "
                "Faster mode — asymmetry decays ~1.28x faster than coherence deficit."
            ),
            "mass_gap_statement": (
                f"The Watkins mass gap mu_coh = {MU_COH:.6f} is the smallest "
                f"nonzero eigenvalue of the Riemannian Hessian on the 2-simplex "
                f"at the golden equilibrium. It is exactly (2/3)phi^2(1 + T*phi), "
                f"a closed-form algebraic number."
            ),
        },
    }


# =============================================================================
# 2. GLUEBALL SPECTRUM COMPARISON
# =============================================================================

# Lattice QCD glueball masses from:
#   Morningstar & Peardon, Phys. Rev. D 60 (1999) 034509
#   Chen et al., Phys. Rev. D 73 (2006) 014516
# All masses in units of string tension sqrt(sigma).

GLUEBALL_DATA = {
    "0++": {"mass": 4.21, "error": 0.11, "name": "scalar", "J_PC": "0++"},
    "2++": {"mass": 5.85, "error": 0.20, "name": "tensor", "J_PC": "2++"},
    "0-+": {"mass": 6.33, "error": 0.20, "name": "pseudoscalar", "J_PC": "0-+"},
    "1+-": {"mass": 7.18, "error": 0.30, "name": "vector", "J_PC": "1+-"},
}


def glueball_comparison() -> Dict[str, Any]:
    """Compare Watkins mass ratios to lattice QCD glueball spectrum.

    Lattice QCD glueball masses (in units of the string tension sqrt(sigma)):
      0++ (scalar):       m = 4.21 +/- 0.11 sqrt(sigma) (ground state)
      2++ (tensor):       m = 5.85 +/- 0.20 sqrt(sigma)
      0-+ (pseudoscalar): m = 6.33 +/- 0.20 sqrt(sigma)
      1+- (vector):       m = 7.18 +/- 0.30 sqrt(sigma)

    Ratios (normalized to 0++):
      m(2++)/m(0++) = 1.39 +/- 0.05
      m(0-+)/m(0++) = 1.50 +/- 0.06

    Watkins ratio: mu_asym/mu_coh = 7.214/5.636 = 1.280

    Compare: 1.280 vs 1.39 — about 8% off from the tensor glueball ratio.

    Returns:
        Comparison dict with all ratios and their proximity measures.

    Data sources:
        Morningstar & Peardon, Phys. Rev. D 60 (1999) 034509
        Chen et al., Phys. Rev. D 73 (2006) 014516
    """
    ground = GLUEBALL_DATA["0++"]["mass"]

    # QCD glueball ratios (normalized to ground state)
    qcd_ratios = {}
    qcd_ratio_errors = {}
    for state, data in GLUEBALL_DATA.items():
        if state == "0++":
            continue
        ratio = data["mass"] / ground
        # Propagate errors: d(m1/m2) = (m1/m2) * sqrt((dm1/m1)^2 + (dm2/m2)^2)
        rel_err = math.sqrt(
            (data["error"] / data["mass"]) ** 2
            + (GLUEBALL_DATA["0++"]["error"] / ground) ** 2
        )
        qcd_ratios[state] = ratio
        qcd_ratio_errors[state] = ratio * rel_err

    # Watkins ratio
    watkins_ratio = MU_ASYM / MU_COH

    # Proximity measures: how close is Watkins ratio to each QCD ratio?
    proximity = {}
    for state, qcd_r in qcd_ratios.items():
        diff = abs(watkins_ratio - qcd_r)
        percent_off = 100.0 * diff / qcd_r
        within_error = diff <= qcd_ratio_errors[state]
        sigma_distance = diff / qcd_ratio_errors[state] if qcd_ratio_errors[state] > 0 else float("inf")
        proximity[state] = {
            "qcd_ratio": qcd_r,
            "qcd_ratio_error": qcd_ratio_errors[state],
            "watkins_ratio": watkins_ratio,
            "absolute_difference": diff,
            "percent_off": percent_off,
            "within_1sigma": within_error,
            "sigma_distance": sigma_distance,
        }

    # Closest QCD state
    closest = min(proximity.keys(), key=lambda s: proximity[s]["absolute_difference"])

    return {
        "watkins_ratio": watkins_ratio,
        "qcd_ratios": qcd_ratios,
        "qcd_ratio_errors": qcd_ratio_errors,
        "proximity": proximity,
        "closest_qcd_state": closest,
        "closest_percent_off": proximity[closest]["percent_off"],
        "glueball_data": GLUEBALL_DATA,
        "assessment": (
            f"Watkins ratio mu_asym/mu_coh = {watkins_ratio:.4f} is closest to "
            f"the {GLUEBALL_DATA[closest]['name']} glueball ratio "
            f"m({closest})/m(0++) = {qcd_ratios[closest]:.4f}, "
            f"off by {proximity[closest]['percent_off']:.1f}%. "
            f"This is a {proximity[closest]['sigma_distance']:.1f}-sigma discrepancy. "
            f"The structural parallel is suggestive but not a quantitative match — "
            f"the Watkins system is a 2-simplex model, not 4D Yang-Mills."
        ),
    }


# =============================================================================
# 3. LANDAU-GINZBURG EXPANSION
# =============================================================================

def _free_energy_at_point(lam: float, kap: float, eta: float) -> float:
    """Watkins free energy F(lam, kap, eta) = -ln(lam) + T* sum p_i ln(p_i)."""
    eps = 1e-300
    lam = max(lam, eps)
    kap = max(kap, eps)
    eta = max(eta, eps)
    return (
        -math.log(lam)
        + T_STAR * (lam * math.log(lam) + kap * math.log(kap) + eta * math.log(eta))
    )


def _numerical_derivative(f, x, h=1e-7):
    """Central difference derivative."""
    return (f(x + h) - f(x - h)) / (2 * h)


def landau_ginzburg_expansion(order: int = 6) -> Dict[str, Any]:
    """Expand the Watkins free energy around the golden equilibrium
    in Landau-Ginzburg form.

    F(delta) = F* + (mu_coh/2) delta^2 + (C3/6) delta^3 + (C4/24) delta^4 + ...

    where delta = displacement along the coherence direction e_coh.

    Compute C3, C4, C5, C6 explicitly from the free energy derivatives.
    Compare to Higgs potential form V = -mu^2 |phi|^2 + lambda_H |phi|^4.

    Key structural difference: Watkins has NO Z_2 symmetry (C3 != 0),
    so it's a first-order-type potential, not Mexican hat.

    Args:
        order: Maximum order of expansion (2 through 6).

    Returns:
        Dict with coefficients, Higgs comparison, and structural analysis.
    """
    if order < 2:
        order = 2
    if order > 6:
        order = 6

    # Free energy along the coherence direction:
    # p(delta) = p* + delta * e_coh
    # F_1d(delta) = F(p(delta))
    def F_1d(delta: float) -> float:
        lam = LAM_STAR + delta * E_COH[0]
        kap = KAP_STAR + delta * E_COH[1]
        eta = ETA_STAR + delta * E_COH[2]
        return _free_energy_at_point(lam, kap, eta)

    # Analytical derivatives of F along e_coh at p*:
    #
    # F(d) = -ln(ls + a*d) + T*[(ls+a*d)ln(ls+a*d) + (ks+b*d)ln(ks+b*d) + (es+c*d)ln(es+c*d)]
    # with a = 2/sqrt6, b = c = -1/sqrt6
    #
    # From -ln(ls + a*d):
    #   d1 = -a/ls
    #   d2 =  a^2/ls^2
    #   d3 = -2 a^3/ls^3
    #   d4 =  6 a^4/ls^4
    #   d5 = -24 a^5/ls^5
    #   d6 =  120 a^6/ls^6
    # General: d^n/dd^n [-ln(ls+a*d)] at d=0 = (-1)^n (n-1)! a^n / ls^n
    #
    # From T*(x + v*d)*ln(x + v*d):
    #   d1 = T*v*(ln(x) + 1)
    #   d2 = T*v^2/x
    #   d3 = -T*v^3/x^2
    #   d4 = 2*T*v^4/x^3
    #   d5 = -6*T*v^5/x^4
    #   d6 = 24*T*v^6/x^5
    # General for n>=2: d^n = (-1)^n (n-2)! T v^n / x^{n-1}

    a = E_COH[0]  # 2/sqrt6
    b = E_COH[1]  # -1/sqrt6
    c = E_COH[2]  # -1/sqrt6

    ls = LAM_STAR
    ks = KAP_STAR
    es = ETA_STAR

    def _entropy_dn(n: int) -> float:
        """n-th derivative of T * sum_i (x_i + v_i d) ln(x_i + v_i d) at d=0."""
        # For n >= 2: d^n = (-1)^n (n-2)! T v^n / x^{n-1}
        sign = (-1) ** n
        factorial = math.factorial(n - 2)
        return sign * factorial * T_STAR * (
            a**n / ls**(n - 1) + b**n / ks**(n - 1) + c**n / es**(n - 1)
        )

    def _neg_ln_dn(n: int) -> float:
        """n-th derivative of -ln(ls + a*d) at d=0."""
        # d^n = (-1)^n (n-1)! a^n / ls^n
        sign = (-1) ** n
        factorial = math.factorial(n - 1)
        return sign * factorial * a**n / ls**n

    # Compute C2 analytically and verify against MU_COH
    C2 = _neg_ln_dn(2) + _entropy_dn(2)
    assert abs(C2 - MU_COH) < 1e-10, (
        f"C2 analytical ({C2}) != MU_COH ({MU_COH})"
    )

    # Use MU_COH for C2 to maintain exact consistency with constants
    C2 = MU_COH

    # Higher-order coefficients
    C3 = _neg_ln_dn(3) + _entropy_dn(3)
    C4 = _neg_ln_dn(4) + _entropy_dn(4)
    C5 = _neg_ln_dn(5) + _entropy_dn(5)
    C6 = _neg_ln_dn(6) + _entropy_dn(6)

    all_coefficients = {2: C2, 3: C3, 4: C4, 5: C5, 6: C6}
    coefficients = {k: v for k, v in all_coefficients.items() if k <= order}

    # Verify C2, C3 numerically with step size where finite differences are accurate
    h = 1e-4
    C2_numerical = (F_1d(h) - 2 * F_1d(0) + F_1d(-h)) / h**2
    assert abs(C2 - C2_numerical) < 1e-4, (
        f"C2 analytical ({C2}) != numerical ({C2_numerical})"
    )

    C3_numerical = (F_1d(2 * h) - 2 * F_1d(h) + 2 * F_1d(-h) - F_1d(-2 * h)) / (2 * h**3)
    assert abs(C3 - C3_numerical) < 1e-2, (
        f"C3 analytical ({C3}) != numerical ({C3_numerical})"
    )

    # LG form coefficients: F(d) = F* + (C2/2)d^2 + (C3/6)d^3 + (C4/24)d^4 + ...
    lg_coefficients = {
        "F_star": F_STAR,
        "quadratic": C2 / 2.0,    # mu_coh / 2
        "cubic": C3 / 6.0,
        "quartic": C4 / 24.0,
    }
    if order >= 5:
        lg_coefficients["quintic"] = C5 / 120.0
    if order >= 6:
        lg_coefficients["sextic"] = C6 / 720.0

    # Higgs potential comparison
    # Standard Higgs: V = -mu_H^2 |phi|^2 + lambda_H |phi|^4
    # Watkins:        F = F* + (mu_coh/2) d^2 + (C3/6) d^3 + (C4/24) d^4
    # Key difference: C3 != 0 => no Z_2 symmetry => not Mexican hat
    has_z2 = abs(C3) < 1e-10

    return {
        "coefficients": coefficients,
        "lg_coefficients": lg_coefficients,
        "C2": C2,
        "C3": C3,
        "C4": C4,
        "C5": C5,
        "C6": C6,
        "has_z2_symmetry": has_z2,
        "higgs_comparison": {
            "watkins_is_mexican_hat": has_z2,
            "watkins_potential_type": "asymmetric (first-order type)" if not has_z2 else "symmetric (Mexican hat)",
            "explanation": (
                "The Watkins potential has C3 != 0 due to the asymmetry between "
                "the coherence direction (lambda) and the entropy directions (kappa, eta). "
                "This breaks Z_2 symmetry, so the potential is NOT a Mexican hat. "
                "The equilibrium at lambda* = 1/phi is a genuine minimum, "
                "not a ring of degenerate vacua."
            ),
        },
        "stability_check": {
            "C2_positive": C2 > 0,
            "is_minimum": C2 > 0,
            "curvature_at_minimum": C2,
        },
        # Useful analytic relations
        "analytic_relations": {
            "C3_expression": "2*a^3/lam*^3 - T*(a^3/lam*^2 + b^3/kap*^2 + c^3/eta*^2)",
            "C3_simplified": (
                f"With a=2/sqrt(6), b=c=-1/sqrt(6): C3 = {C3:.6f}"
            ),
        },
    }


# =============================================================================
# 4. STRING TENSION ANALOG
# =============================================================================

def string_tension_analog() -> Dict[str, Any]:
    """Compute the Watkins 'string tension' analog.

    In QCD, string tension sigma ~ 440 MeV/fm describes the confining flux tube.
    The Watkins analog: perturbations away from equilibrium cost energy
    proportional to mu_coh * displacement.

    Compute: sigma_W = mu_coh * T* and compare structure to QCD.
    Also: confinement radius r_c = 1/mu_coh (correlation length).

    Returns:
        Dict with analog quantities.
    """
    # Watkins string tension: sigma_W = mu_coh * T*
    # This is the energy per unit displacement at the critical temperature.
    sigma_W = MU_COH * T_STAR

    # Confinement radius: correlation length = 1 / mass gap
    r_c = 1.0 / MU_COH

    # Asymmetry correlation length
    r_asym = 1.0 / MU_ASYM

    # "Flux tube" energy: energy cost of displacing by one correlation length
    flux_tube_energy = sigma_W * r_c  # = T* (dimensionless)

    # Debye screening mass analog: the heavier mode screens fluctuations
    debye_mass = MU_ASYM
    debye_length = r_asym

    # Mass gap in "temperature units"
    mass_gap_over_T = MU_COH / T_STAR

    # QCD comparison structure
    # In QCD: m_glueball / sqrt(sigma) ~ 4.21 for 0++
    # Watkins: mu_coh / sqrt(sigma_W) = mu_coh / sqrt(mu_coh * T*)
    #        = sqrt(mu_coh / T*) = sqrt(mass_gap_over_T)
    watkins_mass_over_sqrt_sigma = math.sqrt(MU_COH / T_STAR)

    return {
        # Core quantities
        "sigma_W": sigma_W,
        "confinement_radius": r_c,
        "asymmetry_correlation_length": r_asym,
        # Derived quantities
        "flux_tube_energy": flux_tube_energy,
        "debye_mass": debye_mass,
        "debye_length": debye_length,
        "mass_gap_over_T": mass_gap_over_T,
        # Structural comparison
        "watkins_mass_over_sqrt_sigma": watkins_mass_over_sqrt_sigma,
        "qcd_0pp_mass_over_sqrt_sigma": 4.21,
        # Interpretation
        "interpretation": {
            "sigma_W": (
                f"Watkins string tension sigma_W = mu_coh * T* = {sigma_W:.6f}. "
                f"Measures the energy cost per unit coherence displacement at T*."
            ),
            "confinement": (
                f"Confinement radius r_c = 1/mu_coh = {r_c:.6f}. "
                f"Perturbations beyond this scale are exponentially suppressed."
            ),
            "comparison": (
                f"The structural parallel between Watkins and QCD is in the existence "
                f"of a mass gap and correlation length, not in numerical values. "
                f"Watkins is a 2-simplex model; QCD is a 4D gauge theory."
            ),
        },
        # Positivity checks
        "all_positive": sigma_W > 0 and r_c > 0 and r_asym > 0,
    }


# =============================================================================
# 5. FULL SPECTRUM ANALYSIS
# =============================================================================

def full_spectrum_analysis() -> Dict[str, Any]:
    """Complete spectral analysis connecting Watkins eigenvalues
    to particle physics mass hierarchies.

    Computes eigenvalue ratios, condition numbers, decay time ratios,
    and maps these onto known hierarchies (quark masses, lepton masses, etc.).

    Honest about what matches and what doesn't.

    Returns:
        Comprehensive analysis dict.
    """
    # Watkins mass spectrum
    spectrum = watkins_mass_spectrum()

    # Glueball comparison
    glueball = glueball_comparison()

    # LG expansion
    lg = landau_ginzburg_expansion(order=6)

    # String tension
    string = string_tension_analog()

    # ---- Eigenvalue ratios ----
    mass_ratio = MU_ASYM / MU_COH
    decay_ratio = TAU_COH / TAU_ASYM   # = mu_asym / mu_coh

    # ---- Known particle physics ratios for comparison ----
    # Be explicit: these are at specific energy scales and scheme-dependent.
    physics_ratios = {
        "m_tau / m_muon": {
            "value": 16.82,
            "watkins_match": False,
            "note": "Lepton mass ratio; no structural parallel in 2-simplex model.",
        },
        "m_b / m_c": {
            "value": 3.0,
            "watkins_match": False,
            "note": "Quark mass ratio; no structural parallel in 2-simplex model.",
        },
        "m_W / m_Z": {
            "value": 0.8815,
            "watkins_match": False,
            "note": "Electroweak boson ratio; requires SU(2)xU(1) structure not present.",
        },
        "m(2++) / m(0++)": {
            "value": glueball["qcd_ratios"]["2++"],
            "watkins_match": abs(mass_ratio - glueball["qcd_ratios"]["2++"]) < 0.15,
            "note": (
                f"Tensor glueball ratio = {glueball['qcd_ratios']['2++']:.3f}. "
                f"Watkins ratio = {mass_ratio:.3f}. "
                f"Off by {glueball['proximity']['2++']['percent_off']:.1f}%. "
                f"Suggestive but not a match."
            ),
        },
    }

    # ---- Dimensional analysis ----
    # The Watkins system has one dimensionful scale: T*.
    # All masses are measured in units of 1/T*.
    dimensional = {
        "natural_unit": T_STAR,
        "mu_coh_in_T_units": MU_COH / T_STAR,
        "mu_asym_in_T_units": MU_ASYM / T_STAR,
        "explanation": (
            "The Watkins system is dimensionless on the probability simplex. "
            "T* provides the only energy scale. All 'masses' are dimensionless "
            "eigenvalues of the Hessian, interpretable as inverse correlation lengths."
        ),
    }

    # ---- Spectral summary ----
    spectral_summary = {
        "eigenvalues": [MU_COH, MU_ASYM],
        "mass_gap": MU_COH,
        "condition_number": MU_ASYM / MU_COH,
        "spectral_width": MU_ASYM - MU_COH,
        "geometric_mean": math.sqrt(MU_COH * MU_ASYM),
        "harmonic_mean": 2.0 * MU_COH * MU_ASYM / (MU_COH + MU_ASYM),
        "total_curvature": MU_COH + MU_ASYM,
    }

    # ---- Honest assessment ----
    honest_assessment = (
        "The Watkins mass spectrum is a rigorous result for a specific 2-simplex model. "
        "The mass gap mu_coh = (2/3)phi^2(1 + T*phi) is an exact, closed-form eigenvalue. "
        "Its ratio to mu_asym (1.28) is suggestive of, but does not match, QCD glueball "
        "ratios (closest: tensor 2++ at 1.39, 8% off). The structural parallel — "
        "a mass gap from a Hessian at a symmetry-selected equilibrium — is genuine. "
        "The numerical coincidence is likely accidental and should not be over-interpreted. "
        "What IS proven: the mass gap exists, is nonzero, and has a closed form tied to phi."
    )

    # ---- Conservation check ----
    assert abs(LAM_STAR + KAP_STAR + ETA_STAR - 1.0) < CONSERVATION_EPSILON

    return {
        "spectrum": spectrum,
        "glueball": glueball,
        "landau_ginzburg": lg,
        "string_tension": string,
        "mass_ratio": mass_ratio,
        "decay_time_ratio": decay_ratio,
        "physics_ratios": physics_ratios,
        "dimensional_analysis": dimensional,
        "spectral_summary": spectral_summary,
        "honest_assessment": honest_assessment,
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Core spectrum
    "watkins_mass_spectrum",
    # QCD comparison
    "glueball_comparison",
    "GLUEBALL_DATA",
    # LG expansion
    "landau_ginzburg_expansion",
    # String tension
    "string_tension_analog",
    # Full analysis
    "full_spectrum_analysis",
    # Eigenvectors
    "E_COH",
    "E_ASYM",
]
