"""Tests for Theorem ES — SU(3) Weyl Alcove Identification.

Theorem ES (P0: Weyl Alcove Identification):
The Watkins probability simplex Delta^2 = {(lam, kap, eta) : lam+kap+eta=1, all >= 0}
with S_3 permutation symmetry IS the Weyl alcove of SU(3), and the S_3 symmetry IS
the Weyl group W(A_2).
"""

import math
import pytest

from watkins_nn.constants import (
    PHI,
    PHI_INV,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    CONSERVATION_EPSILON,
)
from watkins_nn.gauge import (
    # Maps
    weyl_alcove_to_cartan,
    cartan_to_weyl_alcove,
    # Golden equilibrium
    golden_equilibrium_cartan,
    symmetry_enhancement_wall,
    # Weyl group
    weyl_group_orbit,
    # Root system
    root_inner_product,
    express_in_root_basis,
    # Color
    color_vertices,
    color_charge_cartan,
    # Verification
    verify_weyl_identification,
    # Data
    SIMPLE_ROOT_1,
    SIMPLE_ROOT_2,
    A2_POSITIVE_ROOTS,
    A2_ROOTS,
    FUNDAMENTAL_WEIGHT_1,
    FUNDAMENTAL_WEIGHT_2,
    CARTAN_MATRIX,
)

ATOL = 1e-15  # exact arithmetic tolerance


# =============================================================================
# WEYL ALCOVE <-> CARTAN ROUND-TRIP
# =============================================================================

class TestWeylAlcoveCartanBijection:

    def test_roundtrip_golden_equilibrium(self):
        """Round-trip at the golden equilibrium p*."""
        h = weyl_alcove_to_cartan(LAM_STAR, KAP_STAR, ETA_STAR)
        lam, kap, eta = cartan_to_weyl_alcove(*h)
        assert lam == pytest.approx(LAM_STAR, abs=ATOL)
        assert kap == pytest.approx(KAP_STAR, abs=ATOL)
        assert eta == pytest.approx(ETA_STAR, abs=ATOL)

    @pytest.mark.parametrize("point", [
        (1.0, 0.0, 0.0),
        (0.0, 1.0, 0.0),
        (0.0, 0.0, 1.0),
        (1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0),
        (0.5, 0.3, 0.2),
        (0.7, 0.2, 0.1),
    ])
    def test_roundtrip_various_points(self, point):
        """Round-trip at various simplex points."""
        h = weyl_alcove_to_cartan(*point)
        recovered = cartan_to_weyl_alcove(*h)
        for orig, rec in zip(point, recovered):
            assert rec == pytest.approx(orig, abs=ATOL)

    def test_cartan_tracelessness(self):
        """Cartan image is traceless: h_1 + h_2 + h_3 = 0."""
        h = weyl_alcove_to_cartan(LAM_STAR, KAP_STAR, ETA_STAR)
        assert sum(h) == pytest.approx(0.0, abs=ATOL)

    def test_barycenter_maps_to_origin(self):
        """The barycenter (1/3, 1/3, 1/3) maps to the origin (0, 0, 0)."""
        h = weyl_alcove_to_cartan(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)
        for hi in h:
            assert hi == pytest.approx(0.0, abs=ATOL)

    def test_conservation_violation_raises(self):
        """Violation of lam + kap + eta = 1 raises ValueError."""
        with pytest.raises(ValueError, match="Conservation law violated"):
            weyl_alcove_to_cartan(0.5, 0.5, 0.5)

    def test_tracelessness_violation_raises(self):
        """Violation of h_1 + h_2 + h_3 = 0 raises ValueError."""
        with pytest.raises(ValueError, match="Tracelessness violated"):
            cartan_to_weyl_alcove(1.0, 1.0, 1.0)

    def test_map_is_affine_shift(self):
        """The map is exactly h_i = lam_i - 1/3 (affine, not approximate)."""
        lam, kap, eta = 0.6, 0.3, 0.1
        h = weyl_alcove_to_cartan(lam, kap, eta)
        assert h[0] == pytest.approx(lam - 1.0 / 3.0, abs=ATOL)
        assert h[1] == pytest.approx(kap - 1.0 / 3.0, abs=ATOL)
        assert h[2] == pytest.approx(eta - 1.0 / 3.0, abs=ATOL)

    def test_inverse_is_affine_shift(self):
        """The inverse map is exactly lam_i = h_i + 1/3."""
        h = (0.2, -0.1, -0.1)
        lam, kap, eta = cartan_to_weyl_alcove(*h)
        assert lam == pytest.approx(h[0] + 1.0 / 3.0, abs=ATOL)
        assert kap == pytest.approx(h[1] + 1.0 / 3.0, abs=ATOL)
        assert eta == pytest.approx(h[2] + 1.0 / 3.0, abs=ATOL)


# =============================================================================
# GOLDEN EQUILIBRIUM ON THE SYMMETRY WALL
# =============================================================================

class TestGoldenEquilibrium:

    def test_golden_equilibrium_values(self):
        """p* = (1/phi, (1-1/phi)/2, (1-1/phi)/2)."""
        h = golden_equilibrium_cartan()
        lam, kap, eta = cartan_to_weyl_alcove(*h)
        assert lam == pytest.approx(1.0 / PHI, abs=ATOL)
        assert kap == pytest.approx((1.0 - 1.0 / PHI) / 2.0, abs=ATOL)
        assert eta == pytest.approx((1.0 - 1.0 / PHI) / 2.0, abs=ATOL)

    def test_golden_on_kap_eta_wall(self):
        """The golden equilibrium lies exactly on the kap = eta wall."""
        assert symmetry_enhancement_wall(LAM_STAR, KAP_STAR, ETA_STAR)

    def test_golden_kap_equals_eta_exact(self):
        """KAP_STAR == ETA_STAR is an identity, not approximate."""
        assert KAP_STAR == ETA_STAR  # exact floating-point equality

    def test_golden_h2_equals_h3(self):
        """In Cartan coordinates, h_2 = h_3 at the golden equilibrium."""
        h = golden_equilibrium_cartan()
        assert h[1] == pytest.approx(h[2], abs=ATOL)

    def test_generic_point_not_on_wall(self):
        """A generic point is NOT on the kap = eta wall."""
        assert not symmetry_enhancement_wall(0.5, 0.3, 0.2)

    def test_permuted_walls(self):
        """Points with any two coordinates equal are on SOME wall."""
        # lam = kap wall
        assert symmetry_enhancement_wall(0.4, 0.4, 0.2) is False  # this checks kap==eta
        # But kap = eta wall:
        assert symmetry_enhancement_wall(0.6, 0.2, 0.2)

    def test_golden_cartan_traceless(self):
        """The golden Cartan element is traceless."""
        h = golden_equilibrium_cartan()
        assert sum(h) == pytest.approx(0.0, abs=ATOL)


# =============================================================================
# WEYL GROUP ORBIT
# =============================================================================

class TestWeylGroupOrbit:

    def test_generic_orbit_has_6_elements(self):
        """For a generic point (all coordinates distinct), orbit has 6 elements."""
        orbit = weyl_group_orbit(0.5, 0.3, 0.2)
        assert len(orbit) == 6

    def test_wall_orbit_has_3_elements(self):
        """For a point on a wall (two coordinates equal), orbit has 3 elements."""
        orbit = weyl_group_orbit(0.6, 0.2, 0.2)
        assert len(orbit) == 3

    def test_barycenter_orbit_has_1_element(self):
        """For the barycenter (all equal), orbit has 1 element."""
        orbit = weyl_group_orbit(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)
        assert len(orbit) == 1

    def test_golden_orbit_has_3_elements(self):
        """The golden equilibrium has kap = eta, so orbit has 3 elements."""
        orbit = weyl_group_orbit(LAM_STAR, KAP_STAR, ETA_STAR)
        assert len(orbit) == 3

    def test_orbit_preserves_simplex(self):
        """All S_3 permutations preserve the simplex (sum = 1, all >= 0)."""
        orbit = weyl_group_orbit(0.5, 0.3, 0.2)
        for p in orbit:
            assert sum(p) == pytest.approx(1.0, abs=ATOL)
            assert all(x >= -ATOL for x in p)

    def test_orbit_preserves_simplex_at_vertices(self):
        """Orbit of a vertex = all 3 vertices."""
        orbit = weyl_group_orbit(1.0, 0.0, 0.0)
        assert len(orbit) == 3
        assert (0.0, 0.0, 1.0) in orbit
        assert (0.0, 1.0, 0.0) in orbit
        assert (1.0, 0.0, 0.0) in orbit

    def test_orbit_sorted_lexicographically(self):
        """Orbit is returned in sorted order."""
        orbit = weyl_group_orbit(0.5, 0.3, 0.2)
        assert orbit == sorted(orbit)


# =============================================================================
# CONSERVATION LAW = COLOR SINGLET CONDITION
# =============================================================================

class TestColorSinglet:

    def test_conservation_law_is_color_singlet(self, assert_conserved):
        """The Watkins conservation law lam + kap + eta = 1 is the color singlet condition."""
        assert_conserved(LAM_STAR, KAP_STAR, ETA_STAR)

    def test_three_color_vertices_exist(self):
        """There are exactly 3 color vertices (R, G, B)."""
        colors = color_vertices()
        assert len(colors) == 3
        assert set(colors.keys()) == {'red', 'green', 'blue'}

    def test_color_vertices_are_simplex_vertices(self):
        """Each color vertex is a pure state (one component = 1, rest = 0)."""
        colors = color_vertices()
        for name, v in colors.items():
            assert sum(v) == pytest.approx(1.0, abs=ATOL)
            assert sorted(v) == pytest.approx([0.0, 0.0, 1.0], abs=ATOL)

    def test_color_charges_in_cartan(self):
        """Color charges map correctly to Cartan subalgebra."""
        charges = color_charge_cartan()
        # Red = (2/3, -1/3, -1/3) = omega_1
        assert charges['red'][0] == pytest.approx(2.0 / 3.0, abs=ATOL)
        assert charges['red'][1] == pytest.approx(-1.0 / 3.0, abs=ATOL)
        assert charges['red'][2] == pytest.approx(-1.0 / 3.0, abs=ATOL)

    def test_all_color_charges_traceless(self):
        """All color charges are traceless."""
        charges = color_charge_cartan()
        for name, h in charges.items():
            assert sum(h) == pytest.approx(0.0, abs=ATOL)


# =============================================================================
# ROOT INNER PRODUCTS AT GOLDEN EQUILIBRIUM
# =============================================================================

class TestRootInnerProducts:

    def test_alpha2_vanishes_at_golden(self):
        """<h*, alpha_2> = 0 at the golden equilibrium (symmetry enhancement)."""
        ips = root_inner_product(LAM_STAR, KAP_STAR, ETA_STAR)
        assert ips['alpha_2'] == pytest.approx(0.0, abs=ATOL)

    def test_negative_alpha2_vanishes_at_golden(self):
        """<h*, -alpha_2> = 0 as well (both signs vanish on the wall)."""
        ips = root_inner_product(LAM_STAR, KAP_STAR, ETA_STAR)
        assert ips['-alpha_2'] == pytest.approx(0.0, abs=ATOL)

    def test_alpha1_nonzero_at_golden(self):
        """<h*, alpha_1> != 0 (lam != kap at golden equilibrium)."""
        ips = root_inner_product(LAM_STAR, KAP_STAR, ETA_STAR)
        assert abs(ips['alpha_1']) > 0.1  # lam* - kap* ~ 0.427

    def test_alpha1_value(self):
        """<h*, alpha_1> = lam* - kap* exactly."""
        ips = root_inner_product(LAM_STAR, KAP_STAR, ETA_STAR)
        assert ips['alpha_1'] == pytest.approx(LAM_STAR - KAP_STAR, abs=ATOL)

    def test_alpha1_plus_alpha2_value(self):
        """<h*, alpha_1 + alpha_2> = lam* - eta* = lam* - kap* (since kap* = eta*)."""
        ips = root_inner_product(LAM_STAR, KAP_STAR, ETA_STAR)
        assert ips['alpha_1+2'] == pytest.approx(LAM_STAR - ETA_STAR, abs=ATOL)

    def test_negative_roots_are_negated(self):
        """<h, -alpha> = -<h, alpha> for all roots."""
        ips = root_inner_product(0.5, 0.3, 0.2)
        assert ips['-alpha_1'] == pytest.approx(-ips['alpha_1'], abs=ATOL)
        assert ips['-alpha_2'] == pytest.approx(-ips['alpha_2'], abs=ATOL)
        assert ips['-(alpha_1+2)'] == pytest.approx(-ips['alpha_1+2'], abs=ATOL)

    def test_inner_product_at_barycenter_all_zero(self):
        """At the barycenter (origin in Cartan), all root inner products vanish."""
        ips = root_inner_product(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)
        for label, val in ips.items():
            assert val == pytest.approx(0.0, abs=ATOL)


# =============================================================================
# A_2 ROOT SYSTEM DATA
# =============================================================================

class TestA2RootSystem:

    def test_six_roots(self):
        """A_2 has exactly 6 roots."""
        assert len(A2_ROOTS) == 6

    def test_three_positive_roots(self):
        """A_2 has exactly 3 positive roots."""
        assert len(A2_POSITIVE_ROOTS) == 3

    def test_roots_in_traceless_hyperplane(self):
        """All roots lie in h_1 + h_2 + h_3 = 0."""
        for r in A2_ROOTS:
            assert sum(r) == pytest.approx(0.0, abs=ATOL)

    def test_roots_have_norm_squared_2(self):
        """All A_2 roots have ||alpha||^2 = 2 (simply-laced)."""
        for r in A2_ROOTS:
            norm_sq = sum(x ** 2 for x in r)
            assert norm_sq == pytest.approx(2.0, abs=ATOL)

    def test_simple_root_inner_product(self):
        """<alpha_1, alpha_2> = -1 for the A_2 simple roots."""
        ip = sum(a * b for a, b in zip(SIMPLE_ROOT_1, SIMPLE_ROOT_2))
        assert ip == pytest.approx(-1.0, abs=ATOL)

    def test_cartan_matrix_from_simple_roots(self):
        """The Cartan matrix A_ij = 2<alpha_i, alpha_j>/||alpha_j||^2."""
        roots = [SIMPLE_ROOT_1, SIMPLE_ROOT_2]
        for i in range(2):
            for j in range(2):
                ip = sum(a * b for a, b in zip(roots[i], roots[j]))
                norm_sq_j = sum(x ** 2 for x in roots[j])
                aij = int(round(2 * ip / norm_sq_j))
                assert aij == CARTAN_MATRIX[i][j]

    def test_cartan_matrix_values(self):
        """A_2 Cartan matrix is [[2, -1], [-1, 2]]."""
        assert CARTAN_MATRIX == ((2, -1), (-1, 2))

    def test_roots_come_in_pairs(self):
        """For each root alpha, -alpha is also a root."""
        root_set = set(A2_ROOTS)
        for r in A2_ROOTS:
            neg_r = tuple(-x for x in r)
            assert neg_r in root_set


# =============================================================================
# FUNDAMENTAL WEIGHTS
# =============================================================================

class TestFundamentalWeights:

    def test_weight_root_duality(self):
        """<omega_i, alpha_j> = delta_ij (Kronecker delta)."""
        # <omega_1, alpha_1> = 1
        ip11 = sum(a * b for a, b in zip(FUNDAMENTAL_WEIGHT_1, SIMPLE_ROOT_1))
        assert ip11 == pytest.approx(1.0, abs=ATOL)
        # <omega_1, alpha_2> = 0
        ip12 = sum(a * b for a, b in zip(FUNDAMENTAL_WEIGHT_1, SIMPLE_ROOT_2))
        assert ip12 == pytest.approx(0.0, abs=ATOL)
        # <omega_2, alpha_1> = 0
        ip21 = sum(a * b for a, b in zip(FUNDAMENTAL_WEIGHT_2, SIMPLE_ROOT_1))
        assert ip21 == pytest.approx(0.0, abs=ATOL)
        # <omega_2, alpha_2> = 1
        ip22 = sum(a * b for a, b in zip(FUNDAMENTAL_WEIGHT_2, SIMPLE_ROOT_2))
        assert ip22 == pytest.approx(1.0, abs=ATOL)

    def test_weights_traceless(self):
        """Fundamental weights lie in the traceless hyperplane."""
        assert sum(FUNDAMENTAL_WEIGHT_1) == pytest.approx(0.0, abs=ATOL)
        assert sum(FUNDAMENTAL_WEIGHT_2) == pytest.approx(0.0, abs=ATOL)

    def test_weight_expansion_roundtrip(self):
        """Express h* in weight basis and reconstruct."""
        basis = express_in_root_basis(LAM_STAR, KAP_STAR, ETA_STAR)
        h_star = golden_equilibrium_cartan()
        h_recon = basis['h_reconstructed']
        for i in range(3):
            assert h_recon[i] == pytest.approx(h_star[i], abs=ATOL)

    def test_dynkin_labels_at_golden(self):
        """Dynkin labels at golden equilibrium: a_1 = lam* - kap*, a_2 = 0."""
        basis = express_in_root_basis(LAM_STAR, KAP_STAR, ETA_STAR)
        assert basis['dynkin_1'] == pytest.approx(LAM_STAR - KAP_STAR, abs=ATOL)
        assert basis['dynkin_2'] == pytest.approx(0.0, abs=ATOL)

    def test_red_vertex_is_omega1(self):
        """The red vertex (1,0,0) maps to the fundamental weight omega_1 in Cartan."""
        h_red = weyl_alcove_to_cartan(1.0, 0.0, 0.0)
        for i in range(3):
            assert h_red[i] == pytest.approx(FUNDAMENTAL_WEIGHT_1[i], abs=ATOL)


# =============================================================================
# IDENTIFICATION IS EXACT (NOT APPROXIMATE)
# =============================================================================

class TestExactIdentification:

    def test_map_is_exact_affine(self):
        """The identification is an EXACT affine map, not a numerical approximation.

        h_i = lam_i - 1/3 is exact arithmetic. The only source of floating-point
        error is the representation of 1/3, which is O(machine epsilon).
        """
        # Test at a rational point where we can verify exactly
        lam, kap, eta = 0.5, 0.25, 0.25
        h = weyl_alcove_to_cartan(lam, kap, eta)
        # h_1 = 0.5 - 1/3 = 1/6
        assert h[0] == pytest.approx(1.0 / 6.0, abs=ATOL)
        # h_2 = h_3 = 0.25 - 1/3 = -1/12
        assert h[1] == pytest.approx(-1.0 / 12.0, abs=ATOL)
        assert h[2] == pytest.approx(-1.0 / 12.0, abs=ATOL)

    def test_conservation_iff_traceless(self):
        """Conservation lam+kap+eta=1 is EQUIVALENT to tracelessness h1+h2+h3=0.

        This is the fundamental structural identity of Theorem ES:
        the two constraints are the SAME constraint under the affine map.
        """
        # Forward: conservation => tracelessness
        h = weyl_alcove_to_cartan(LAM_STAR, KAP_STAR, ETA_STAR)
        assert sum(h) == pytest.approx(0.0, abs=ATOL)

        # Backward: tracelessness => conservation
        h = (0.2, -0.05, -0.15)
        assert sum(h) == pytest.approx(0.0, abs=ATOL)
        lam, kap, eta = cartan_to_weyl_alcove(*h)
        assert lam + kap + eta == pytest.approx(1.0, abs=ATOL)

    def test_s3_is_weyl_a2(self):
        """The S_3 permutation group acting on (lam, kap, eta) IS W(A_2).

        This is a GROUP ISOMORPHISM, not a numerical coincidence:
        - |S_3| = |W(A_2)| = 6
        - Both act by permuting 3 objects
        - The action preserves the simplex/alcove structure
        """
        orbit = weyl_group_orbit(0.5, 0.3, 0.2)
        assert len(orbit) == 6

        # Verify each permutation maps to a valid traceless element
        for p in orbit:
            h = weyl_alcove_to_cartan(*p)
            assert sum(h) == pytest.approx(0.0, abs=ATOL)


# =============================================================================
# COMPREHENSIVE VERIFICATION
# =============================================================================

class TestVerifyWeylIdentification:

    def test_all_checks_pass(self):
        """The comprehensive verification passes all checks."""
        results = verify_weyl_identification()
        for check_name, passed in results.items():
            assert passed, f"Verification check '{check_name}' FAILED"

    def test_verification_returns_all_expected_checks(self):
        """The verification covers all required structural properties."""
        results = verify_weyl_identification()
        expected_checks = {
            'bijection_roundtrip',
            'conservation_tracelessness',
            'weyl_group_order_6',
            'weyl_orbit_preserves_simplex',
            'golden_on_kap_eta_wall',
            'a2_root_count_6',
            'cartan_matrix_correct',
            'weight_expansion_roundtrip',
            'red_vertex_is_omega1',
            'golden_alpha2_massless',
        }
        assert set(results.keys()) == expected_checks


# =============================================================================
# P4: E₈ → ICOSAHEDRON → A₅ → NEUTRINO MIXING
# =============================================================================

from watkins_nn.gauge import (
    icosahedron_vertices as get_icosahedron_vertices,
    icosahedron_edges as get_icosahedron_edges,
    e8_icosahedral_chain,
    neutrino_mixing_prediction,
    golden_pmns_matrix,
    verify_pmns_unitarity,
    cabibbo_angle_analysis,
)


class TestIcosahedron:
    """Tests for the icosahedron geometry and golden ratio content."""

    def test_icosahedron_has_12_vertices(self):
        """The regular icosahedron has exactly 12 vertices."""
        verts = get_icosahedron_vertices()
        assert len(verts) == 12

    def test_icosahedron_has_30_edges(self):
        """The regular icosahedron has exactly 30 edges."""
        verts = get_icosahedron_vertices()
        edges = get_icosahedron_edges(verts)
        assert len(edges) == 30

    def test_icosahedron_euler_formula(self):
        """Euler formula: V - E + F = 2 (12 - 30 + 20 = 2)."""
        V = 12
        E = 30
        F = 20
        assert V - E + F == 2

    def test_all_edges_equal_length(self):
        """All 30 edges of the icosahedron have the same length."""
        verts = get_icosahedron_vertices()
        edges = get_icosahedron_edges(verts)
        assert len(edges) > 0

        # Compute all edge lengths
        edge_lengths = []
        for i, j in edges:
            d = math.sqrt(sum((a - b) ** 2 for a, b in zip(verts[i], verts[j])))
            edge_lengths.append(d)

        # All should be equal
        ref = edge_lengths[0]
        for el in edge_lengths:
            assert el == pytest.approx(ref, abs=1e-10)

    def test_edge_length_is_2(self):
        """The edge length of the standard icosahedron (0, +/-1, +/-phi) is 2."""
        verts = get_icosahedron_vertices()
        edges = get_icosahedron_edges(verts)
        i, j = edges[0]
        d = math.sqrt(sum((a - b) ** 2 for a, b in zip(verts[i], verts[j])))
        assert d == pytest.approx(2.0, abs=1e-10)

    def test_golden_ratio_in_coordinates(self):
        """The golden ratio phi appears in icosahedron vertex coordinates."""
        verts = get_icosahedron_vertices()
        # Every vertex should have coordinates from {0, +/-1, +/-phi}
        valid_abs_values = {0.0, 1.0, PHI}
        for v in verts:
            for c in v:
                abs_c = abs(c)
                matches = any(abs(abs_c - val) < 1e-12 for val in valid_abs_values)
                assert matches, (
                    f"Coordinate {c} (|c| = {abs_c}) not in "
                    f"{{0, 1, phi={PHI}}}"
                )

    def test_each_vertex_has_5_neighbors(self):
        """Each icosahedron vertex is adjacent to exactly 5 others."""
        verts = get_icosahedron_vertices()
        edges = get_icosahedron_edges(verts)
        # Count adjacencies
        from collections import Counter
        adj_count = Counter()
        for i, j in edges:
            adj_count[i] += 1
            adj_count[j] += 1
        for v_idx in range(12):
            assert adj_count[v_idx] == 5, (
                f"Vertex {v_idx} has {adj_count[v_idx]} neighbors, expected 5"
            )

    def test_vertices_on_sphere(self):
        """All 12 vertices lie on a sphere (equal distance from origin)."""
        verts = get_icosahedron_vertices()
        radii = [math.sqrt(sum(c ** 2 for c in v)) for v in verts]
        ref = radii[0]
        for r in radii:
            assert r == pytest.approx(ref, abs=1e-10)

    def test_circumradius(self):
        """The circumradius of (0, 1, phi) is sqrt(1 + phi^2) = sqrt(phi + 2)."""
        # ||(0, 1, phi)|| = sqrt(0 + 1 + phi^2) = sqrt(1 + phi + 1) = sqrt(phi + 2)
        expected = math.sqrt(PHI + 2)
        v = (0.0, 1.0, PHI)
        actual = math.sqrt(sum(c ** 2 for c in v))
        assert actual == pytest.approx(expected, abs=1e-12)


class TestA5SymmetryGroup:
    """Tests for the A₅ = Alt(5) rotation group of the icosahedron."""

    def test_a5_order_is_60(self):
        """A₅ = Alt(5) has order 60 = 5!/2."""
        assert math.factorial(5) // 2 == 60

    def test_a5_is_simple(self):
        """A₅ is the smallest non-abelian simple group (order 60).
        This is a mathematical fact, verified via the chain data."""
        chain = e8_icosahedral_chain()
        assert chain['a5']['is_simple'] is True
        assert chain['a5']['order'] == 60

    def test_a5_is_only_simple_of_order_60(self):
        """A₅ is the ONLY simple group of order 60."""
        chain = e8_icosahedral_chain()
        assert chain['a5']['is_only_simple_group_of_order_60'] is True


class TestE8IcosahedralChain:
    """Tests for the full E₈ → icosahedron → A₅ chain."""

    def test_chain_returns_valid_data(self):
        """The chain function returns a dict with all expected keys."""
        chain = e8_icosahedral_chain()
        assert 'chain' in chain
        assert 'icosahedron' in chain
        assert 'a5' in chain
        assert 'e8' in chain
        assert 'verification' in chain

    def test_chain_has_5_links(self):
        """The derivation chain has 5 links from conservation law to prediction."""
        chain = e8_icosahedral_chain()
        assert len(chain['chain']) == 5

    def test_all_chain_verification_checks_pass(self):
        """All geometric verification checks pass."""
        chain = e8_icosahedral_chain()
        assert chain['verification']['all_checks_pass'] is True

    def test_e8_data_correct(self):
        """E₈ has rank 8, dimension 248, and 240 roots."""
        chain = e8_icosahedral_chain()
        assert chain['e8']['rank'] == 8
        assert chain['e8']['dimension'] == 248
        assert chain['e8']['root_count'] == 240
        assert chain['e8']['contains_icosahedral_symmetry'] is True

    def test_icosahedron_data_correct(self):
        """Icosahedron has 12 vertices, 30 edges, 20 faces."""
        chain = e8_icosahedral_chain()
        ico = chain['icosahedron']
        assert ico['vertices'] == 12
        assert ico['edges'] == 30
        assert ico['faces'] == 20
        assert ico['euler_characteristic'] == 2

    def test_first_link_is_derived(self):
        """The first link (conservation law -> phi) is DERIVED, not assumed."""
        chain = e8_icosahedral_chain()
        link1 = chain['chain']['link_1']
        assert 'DERIVED' in link1['status']

    def test_last_link_is_derived(self):
        """The final link (A₅ -> prediction) is DERIVED from the chain."""
        chain = e8_icosahedral_chain()
        link5 = chain['chain']['link_5']
        assert 'DERIVED' in link5['status'] or 'derived' in link5['status']


class TestNeutrinoMixingPrediction:
    """Tests for the golden ratio neutrino mixing prediction."""

    def test_tan_theta12_equals_phi_inv(self):
        """The prediction is tan(theta_12) = 1/phi."""
        result = neutrino_mixing_prediction()
        assert result['prediction']['tan_theta12'] == pytest.approx(
            1.0 / PHI, abs=1e-15
        )

    def test_theta12_prediction_value(self):
        """theta_12 = arctan(1/phi) ~ 31.717 degrees."""
        result = neutrino_mixing_prediction()
        theta = result['prediction']['theta12_deg']
        assert theta == pytest.approx(31.7174744, abs=1e-5)

    def test_sin2_theta12_prediction(self):
        """sin^2(theta_12) from golden ratio prediction."""
        result = neutrino_mixing_prediction()
        # sin^2(arctan(1/phi)) = 1/(1+phi^2) = 1/(phi+2)
        expected = 1.0 / (PHI + 2.0)
        assert result['prediction']['sin2_theta12'] == pytest.approx(
            expected, abs=1e-12
        )

    def test_tension_is_about_2_sigma(self):
        """The tension with experiment is approximately 2.3 sigma."""
        result = neutrino_mixing_prediction()
        sigma = result['comparison']['tension_sigma']
        # Should be between 1.5 and 3.0 sigma
        assert 1.5 < sigma < 3.0, f"Tension = {sigma:.2f} sigma"

    def test_within_3_sigma(self):
        """The prediction is within 3 sigma of experiment."""
        result = neutrino_mixing_prediction()
        assert result['comparison']['within_3sigma'] is True

    def test_prediction_less_than_experiment(self):
        """The golden ratio prediction gives theta_12 < experimental value."""
        result = neutrino_mixing_prediction()
        assert result['prediction']['theta12_deg'] < result['experiment']['theta12_deg']

    def test_chain_has_7_steps(self):
        """The derivation chain has 7 steps from axioms to prediction."""
        result = neutrino_mixing_prediction()
        assert len(result['chain']) == 7

    def test_prediction_is_derived_not_assumed(self):
        """The prediction status says DERIVED."""
        result = neutrino_mixing_prediction()
        assert 'DERIVED' in result['prediction']['status']

    def test_experiment_source_is_pdg(self):
        """The experimental values come from PDG."""
        result = neutrino_mixing_prediction()
        assert 'PDG' in result['experiment']['source']

    def test_significance_mentions_derived(self):
        """The significance statement explains that phi is derived, not assumed."""
        result = neutrino_mixing_prediction()
        sig = result['significance']
        assert 'DERIVED' in sig
        assert 'ASSUMED' in sig


class TestGoldenPMNSMatrix:
    """Tests for the PMNS mixing matrix with golden ratio mixing."""

    def test_pmns_is_3x3(self):
        """The PMNS matrix is 3x3."""
        u = golden_pmns_matrix()
        assert len(u) == 3
        for row in u:
            assert len(row) == 3

    def test_pmns_is_unitary(self):
        """U^dagger * U = I (unitarity of PMNS matrix)."""
        u = golden_pmns_matrix()
        result = verify_pmns_unitarity(u)
        assert result['is_unitary'], (
            f"PMNS matrix is not unitary: max deviation = {result['max_deviation']:.2e}"
        )

    def test_pmns_rows_normalized(self):
        """Each row of the PMNS matrix has unit norm."""
        u = golden_pmns_matrix()
        for i, row in enumerate(u):
            norm_sq = sum(x ** 2 for x in row)
            assert norm_sq == pytest.approx(1.0, abs=1e-12), (
                f"Row {i} norm^2 = {norm_sq}"
            )

    def test_pmns_columns_normalized(self):
        """Each column of the PMNS matrix has unit norm."""
        u = golden_pmns_matrix()
        for j in range(3):
            col_norm_sq = sum(u[i][j] ** 2 for i in range(3))
            assert col_norm_sq == pytest.approx(1.0, abs=1e-12), (
                f"Column {j} norm^2 = {col_norm_sq}"
            )

    def test_pmns_rows_orthogonal(self):
        """Different rows of the PMNS matrix are orthogonal."""
        u = golden_pmns_matrix()
        for i in range(3):
            for j in range(i + 1, 3):
                dot = sum(u[i][k] * u[j][k] for k in range(3))
                assert dot == pytest.approx(0.0, abs=1e-12), (
                    f"Rows {i} and {j} not orthogonal: dot = {dot}"
                )

    def test_pmns_columns_orthogonal(self):
        """Different columns of the PMNS matrix are orthogonal."""
        u = golden_pmns_matrix()
        for i in range(3):
            for j in range(i + 1, 3):
                dot = sum(u[k][i] * u[k][j] for k in range(3))
                assert dot == pytest.approx(0.0, abs=1e-12), (
                    f"Columns {i} and {j} not orthogonal: dot = {dot}"
                )

    def test_pmns_12_element_golden(self):
        """The (0,0) element is cos(arctan(1/phi)) = phi/sqrt(phi+2)."""
        u = golden_pmns_matrix()
        expected = PHI / math.sqrt(PHI + 2.0)
        assert u[0][0] == pytest.approx(expected, abs=1e-12)

    def test_pmns_12_sin_element(self):
        """The (0,1) element is sin(arctan(1/phi)) = 1/sqrt(phi+2)."""
        u = golden_pmns_matrix()
        expected = 1.0 / math.sqrt(PHI + 2.0)
        assert u[0][1] == pytest.approx(expected, abs=1e-12)

    def test_pmns_13_element_zero(self):
        """The (0,2) element is sin(theta_13) = 0 (tribimaximal)."""
        u = golden_pmns_matrix()
        assert u[0][2] == pytest.approx(0.0, abs=1e-12)

    def test_pmns_det_is_plus_one(self):
        """det(U_PMNS) = +1 for proper rotation."""
        u = golden_pmns_matrix()
        # 3x3 determinant
        det = (
            u[0][0] * (u[1][1] * u[2][2] - u[1][2] * u[2][1])
            - u[0][1] * (u[1][0] * u[2][2] - u[1][2] * u[2][0])
            + u[0][2] * (u[1][0] * u[2][1] - u[1][1] * u[2][0])
        )
        assert det == pytest.approx(1.0, abs=1e-12)


class TestCabibboAngle:
    """Tests for the Cabibbo angle analysis (honest assessment)."""

    def test_cabibbo_returns_valid_data(self):
        """The analysis returns experimental data and candidates."""
        result = cabibbo_angle_analysis()
        assert 'experimental' in result
        assert 'candidates' in result
        assert 'best_match' in result
        assert 'honest_assessment' in result

    def test_cabibbo_experimental_values(self):
        """The experimental Cabibbo angle is about 13 degrees."""
        result = cabibbo_angle_analysis()
        theta = result['experimental']['theta_C_deg']
        assert 12.5 < theta < 13.5

    def test_cabibbo_honest_about_no_clean_match(self):
        """The assessment honestly states there is no clean golden ratio match."""
        result = cabibbo_angle_analysis()
        assessment = result['honest_assessment']
        assert 'does not have a clean golden ratio expression' in assessment

    def test_cabibbo_has_multiple_candidates(self):
        """Multiple golden-ratio formulas are tested."""
        result = cabibbo_angle_analysis()
        assert len(result['candidates']) >= 4

    def test_cabibbo_candidates_have_fractional_errors(self):
        """Each candidate reports its fractional error."""
        result = cabibbo_angle_analysis()
        for name, data in result['candidates'].items():
            assert 'fractional_error' in data
            assert 'matches_within_10pct' in data
