"""Tests for the Watkins mass spectrum analysis (P3).

Verifies:
  - mu_coh matches constant to full precision
  - mu_asym/mu_coh ratio is computed correctly
  - Glueball comparison returns all required ratios
  - Landau-Ginzburg coefficients are correct
  - String tension analog is finite and positive
  - All spectral quantities are real and positive
  - Eigenmode vectors are orthogonal and normalized
  - Conservation law holds at all expansion points
"""

import math
import pytest

from watkins_nn.constants import (
    PHI,
    PHI_INV,
    PHI_SQUARED,
    T_STAR,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    F_STAR,
    MU_COH,
    MU_ASYM,
    TAU_COH,
    TAU_ASYM,
    CONSERVATION_EPSILON,
)
from watkins_nn.mass_spectrum import (
    watkins_mass_spectrum,
    glueball_comparison,
    landau_ginzburg_expansion,
    string_tension_analog,
    full_spectrum_analysis,
    E_COH,
    E_ASYM,
    GLUEBALL_DATA,
)

ATOL = 1e-12  # conservation-grade tolerance
ATOL_NUMERICAL = 1e-6  # for numerically-verified quantities


# =============================================================================
# WATKINS MASS SPECTRUM
# =============================================================================

class TestWatkinsMassSpectrum:

    def test_mu_coh_matches_constant(self):
        """mu_coh from mass_spectrum matches the certified constant."""
        result = watkins_mass_spectrum()
        assert result["mu_coh"] == pytest.approx(MU_COH, abs=ATOL)

    def test_mu_asym_matches_constant(self):
        """mu_asym from mass_spectrum matches the certified constant."""
        result = watkins_mass_spectrum()
        assert result["mu_asym"] == pytest.approx(MU_ASYM, abs=ATOL)

    def test_mass_gap_is_mu_coh(self):
        """Mass gap is the smallest eigenvalue (mu_coh)."""
        result = watkins_mass_spectrum()
        assert result["mass_gap"] == pytest.approx(MU_COH, abs=ATOL)
        assert result["mass_gap"] < result["mu_asym"]

    def test_mu_coh_closed_form(self):
        """mu_coh = (2/3) phi^2 (1 + T* phi) exactly."""
        expected = (2.0 / 3.0) * PHI_SQUARED * (1.0 + T_STAR * PHI)
        assert MU_COH == pytest.approx(expected, abs=ATOL)

    def test_mu_asym_closed_form(self):
        """mu_asym = 2 T* phi^2 exactly."""
        expected = 2.0 * T_STAR * PHI_SQUARED
        assert MU_ASYM == pytest.approx(expected, abs=ATOL)

    def test_mass_ratio(self):
        """mu_asym / mu_coh is computed correctly."""
        result = watkins_mass_spectrum()
        expected_ratio = MU_ASYM / MU_COH
        assert result["mass_ratio"] == pytest.approx(expected_ratio, abs=ATOL)

    def test_mass_ratio_approximate_value(self):
        """Mass ratio is approximately 1.28."""
        result = watkins_mass_spectrum()
        assert result["mass_ratio"] == pytest.approx(1.28, abs=0.01)

    def test_decay_times(self):
        """Decay times are inverse eigenvalues."""
        result = watkins_mass_spectrum()
        assert result["tau_coh"] == pytest.approx(1.0 / MU_COH, abs=ATOL)
        assert result["tau_asym"] == pytest.approx(1.0 / MU_ASYM, abs=ATOL)

    def test_all_positive(self):
        """All spectral quantities are real and positive."""
        result = watkins_mass_spectrum()
        assert result["mu_coh"] > 0
        assert result["mu_asym"] > 0
        assert result["mass_gap"] > 0
        assert result["tau_coh"] > 0
        assert result["tau_asym"] > 0
        assert result["mass_ratio"] > 0
        assert result["condition_number"] > 0


# =============================================================================
# EIGENVECTOR PROPERTIES
# =============================================================================

class TestEigenvectors:

    def test_e_coh_normalized(self):
        """Coherence eigenvector has unit norm."""
        norm = math.sqrt(sum(x**2 for x in E_COH))
        assert norm == pytest.approx(1.0, abs=ATOL)

    def test_e_asym_normalized(self):
        """Asymmetry eigenvector has unit norm."""
        norm = math.sqrt(sum(x**2 for x in E_ASYM))
        assert norm == pytest.approx(1.0, abs=ATOL)

    def test_orthogonal(self):
        """Eigenvectors are orthogonal."""
        dot = sum(a * b for a, b in zip(E_COH, E_ASYM))
        assert dot == pytest.approx(0.0, abs=ATOL)

    def test_e_coh_in_tangent_plane(self):
        """Coherence eigenvector lies in simplex tangent plane (sum = 0)."""
        assert sum(E_COH) == pytest.approx(0.0, abs=ATOL)

    def test_e_asym_in_tangent_plane(self):
        """Asymmetry eigenvector lies in simplex tangent plane (sum = 0)."""
        assert sum(E_ASYM) == pytest.approx(0.0, abs=ATOL)

    def test_e_coh_direction(self):
        """Coherence mode is (2, -1, -1)/sqrt(6)."""
        sqrt6 = math.sqrt(6)
        assert E_COH[0] == pytest.approx(2.0 / sqrt6, abs=ATOL)
        assert E_COH[1] == pytest.approx(-1.0 / sqrt6, abs=ATOL)
        assert E_COH[2] == pytest.approx(-1.0 / sqrt6, abs=ATOL)

    def test_e_asym_direction(self):
        """Asymmetry mode is (0, +1, -1)/sqrt(2)."""
        sqrt2 = math.sqrt(2)
        assert E_ASYM[0] == pytest.approx(0.0, abs=ATOL)
        assert E_ASYM[1] == pytest.approx(1.0 / sqrt2, abs=ATOL)
        assert E_ASYM[2] == pytest.approx(-1.0 / sqrt2, abs=ATOL)

    def test_eigenvectors_span_tangent_plane(self):
        """The two eigenvectors span the 2D tangent plane of the 2-simplex."""
        # Any tangent vector v with sum(v) = 0 should be a linear combination
        # of E_COH and E_ASYM.
        # Test with v = (1, 0, -1): v = a*E_COH + b*E_ASYM
        # a = dot(v, E_COH), b = dot(v, E_ASYM)
        v = (1.0, 0.0, -1.0)
        a = sum(x * y for x, y in zip(v, E_COH))
        b = sum(x * y for x, y in zip(v, E_ASYM))
        reconstructed = tuple(a * E_COH[i] + b * E_ASYM[i] for i in range(3))
        for i in range(3):
            assert reconstructed[i] == pytest.approx(v[i], abs=ATOL)


# =============================================================================
# GLUEBALL COMPARISON
# =============================================================================

class TestGlueballComparison:

    def test_returns_watkins_ratio(self):
        """Glueball comparison includes the Watkins ratio."""
        result = glueball_comparison()
        assert "watkins_ratio" in result
        assert result["watkins_ratio"] == pytest.approx(MU_ASYM / MU_COH, abs=ATOL)

    def test_all_qcd_states_present(self):
        """All QCD glueball states are in the comparison."""
        result = glueball_comparison()
        for state in ["2++", "0-+", "1+-"]:
            assert state in result["qcd_ratios"]
            assert state in result["proximity"]

    def test_qcd_ratios_correct(self):
        """QCD mass ratios are computed correctly from data."""
        result = glueball_comparison()
        ground = GLUEBALL_DATA["0++"]["mass"]
        for state in ["2++", "0-+", "1+-"]:
            expected = GLUEBALL_DATA[state]["mass"] / ground
            assert result["qcd_ratios"][state] == pytest.approx(expected, abs=1e-10)

    def test_closest_is_tensor(self):
        """Closest QCD state to Watkins ratio is the 2++ tensor."""
        result = glueball_comparison()
        assert result["closest_qcd_state"] == "2++"

    def test_percent_off_reasonable(self):
        """Percent off from closest glueball ratio is in the right ballpark."""
        result = glueball_comparison()
        # Should be around 8%
        assert 5.0 < result["closest_percent_off"] < 12.0

    def test_proximity_has_required_fields(self):
        """Each proximity entry has all required fields."""
        result = glueball_comparison()
        for state, prox in result["proximity"].items():
            assert "qcd_ratio" in prox
            assert "qcd_ratio_error" in prox
            assert "watkins_ratio" in prox
            assert "absolute_difference" in prox
            assert "percent_off" in prox
            assert "within_1sigma" in prox
            assert "sigma_distance" in prox

    def test_assessment_is_string(self):
        """Assessment is a non-empty string."""
        result = glueball_comparison()
        assert isinstance(result["assessment"], str)
        assert len(result["assessment"]) > 50


# =============================================================================
# LANDAU-GINZBURG EXPANSION
# =============================================================================

class TestLandauGinzburgExpansion:

    def test_c2_equals_mu_coh(self):
        """C2 (quadratic coefficient) equals mu_coh."""
        result = landau_ginzburg_expansion(order=6)
        assert result["C2"] == pytest.approx(MU_COH, abs=ATOL)

    def test_c3_nonzero(self):
        """C3 is nonzero (no Z_2 symmetry)."""
        result = landau_ginzburg_expansion(order=6)
        assert abs(result["C3"]) > 0.1  # significantly nonzero

    def test_c3_analytic_formula(self):
        """Verify C3 analytically.

        d^3/dd^3 [-ln(ls + a*d)] at d=0 = -2*a^3/ls^3
        d^3/dd^3 [T*(x+v*d)ln(x+v*d)] at d=0 = -T*v^3/x^2
        C3 = -2*a^3/ls^3 + (-T*)(a^3/ls^2 + b^3/ks^2 + c^3/es^2)
        where a = 2/sqrt(6), b = c = -1/sqrt(6).
        """
        sqrt6 = math.sqrt(6)
        a = 2.0 / sqrt6
        b = -1.0 / sqrt6
        c = -1.0 / sqrt6

        # (-1)^3 * 2! * a^3 / ls^3 = -2*a^3/ls^3
        d3_neg_ln_lam = -2.0 * a**3 / LAM_STAR**3
        # (-1)^3 * 1! * T* * (a^3/ls^2 + b^3/ks^2 + c^3/es^2)
        d3_entropy = -T_STAR * (a**3 / LAM_STAR**2 + b**3 / KAP_STAR**2 + c**3 / ETA_STAR**2)
        expected_C3 = d3_neg_ln_lam + d3_entropy

        result = landau_ginzburg_expansion(order=6)
        assert result["C3"] == pytest.approx(expected_C3, abs=ATOL)

    def test_no_z2_symmetry(self):
        """Watkins potential does NOT have Z_2 symmetry."""
        result = landau_ginzburg_expansion(order=6)
        assert result["has_z2_symmetry"] is False

    def test_is_minimum(self):
        """C2 > 0 confirms the equilibrium is a minimum."""
        result = landau_ginzburg_expansion(order=6)
        assert result["stability_check"]["C2_positive"] is True
        assert result["stability_check"]["is_minimum"] is True

    def test_all_coefficients_present(self):
        """All coefficients up to order 6 are present."""
        result = landau_ginzburg_expansion(order=6)
        for k in [2, 3, 4, 5, 6]:
            assert k in result["coefficients"]

    def test_lg_coefficients_structure(self):
        """LG coefficients have the correct factorial normalization."""
        result = landau_ginzburg_expansion(order=6)
        lg = result["lg_coefficients"]
        assert lg["quadratic"] == pytest.approx(result["C2"] / 2.0, abs=ATOL)
        assert lg["cubic"] == pytest.approx(result["C3"] / 6.0, abs=ATOL)
        assert lg["quartic"] == pytest.approx(result["C4"] / 24.0, abs=ATOL)
        assert lg["quintic"] == pytest.approx(result["C5"] / 120.0, abs=ATOL)
        assert lg["sextic"] == pytest.approx(result["C6"] / 720.0, abs=ATOL)

    def test_c4_analytic(self):
        """Verify C4 analytically.

        d^4/dd^4 [-ln(ls+a*d)] at d=0 = (-1)^4 * 3! * a^4/ls^4 = 6*a^4/ls^4
        d^4/dd^4 [T*(x+v*d)ln(x+v*d)] at d=0 = (-1)^4 * 2! * T * v^4/x^3 = 2*T*v^4/x^3
        """
        sqrt6 = math.sqrt(6)
        a = 2.0 / sqrt6
        b = -1.0 / sqrt6
        c = -1.0 / sqrt6

        d4_neg_ln_lam = 6.0 * a**4 / LAM_STAR**4
        d4_entropy = 2.0 * T_STAR * (a**4 / LAM_STAR**3 + b**4 / KAP_STAR**3 + c**4 / ETA_STAR**3)
        expected_C4 = d4_neg_ln_lam + d4_entropy

        result = landau_ginzburg_expansion(order=6)
        assert result["C4"] == pytest.approx(expected_C4, abs=ATOL)

    def test_expansion_reconstructs_free_energy(self):
        """LG expansion at small delta reconstructs the free energy."""
        result = landau_ginzburg_expansion(order=6)
        C2 = result["C2"]
        C3 = result["C3"]
        C4 = result["C4"]
        C5 = result["C5"]
        C6 = result["C6"]

        # Evaluate at a small displacement
        delta = 0.001
        lam = LAM_STAR + delta * E_COH[0]
        kap = KAP_STAR + delta * E_COH[1]
        eta = ETA_STAR + delta * E_COH[2]

        # Actual free energy
        F_actual = (
            -math.log(lam)
            + T_STAR * (lam * math.log(lam) + kap * math.log(kap) + eta * math.log(eta))
        )

        # LG approximation
        F_lg = (
            F_STAR
            + (C2 / 2.0) * delta**2
            + (C3 / 6.0) * delta**3
            + (C4 / 24.0) * delta**4
            + (C5 / 120.0) * delta**5
            + (C6 / 720.0) * delta**6
        )

        # Should match to ~O(delta^7)
        assert F_lg == pytest.approx(F_actual, abs=1e-10)

    def test_conservation_at_displaced_points(self):
        """Conservation law holds at all displaced points."""
        for delta in [0.001, 0.01, 0.05, -0.01, -0.05]:
            lam = LAM_STAR + delta * E_COH[0]
            kap = KAP_STAR + delta * E_COH[1]
            eta = ETA_STAR + delta * E_COH[2]
            assert lam + kap + eta == pytest.approx(1.0, abs=ATOL)

    def test_order_clipping(self):
        """Order parameter is clipped to [2, 6]."""
        result_low = landau_ginzburg_expansion(order=1)
        assert 2 in result_low["coefficients"]
        result_high = landau_ginzburg_expansion(order=10)
        assert max(result_high["coefficients"].keys()) == 6


# =============================================================================
# STRING TENSION ANALOG
# =============================================================================

class TestStringTensionAnalog:

    def test_sigma_W_positive(self):
        """Watkins string tension is positive."""
        result = string_tension_analog()
        assert result["sigma_W"] > 0

    def test_sigma_W_value(self):
        """sigma_W = mu_coh * T*."""
        result = string_tension_analog()
        assert result["sigma_W"] == pytest.approx(MU_COH * T_STAR, abs=ATOL)

    def test_confinement_radius_positive(self):
        """Confinement radius is positive and finite."""
        result = string_tension_analog()
        assert result["confinement_radius"] > 0
        assert math.isfinite(result["confinement_radius"])

    def test_confinement_radius_value(self):
        """r_c = 1 / mu_coh."""
        result = string_tension_analog()
        assert result["confinement_radius"] == pytest.approx(1.0 / MU_COH, abs=ATOL)

    def test_all_positive(self):
        """All quantities are positive."""
        result = string_tension_analog()
        assert result["all_positive"] is True

    def test_debye_mass_is_mu_asym(self):
        """Debye screening mass is mu_asym."""
        result = string_tension_analog()
        assert result["debye_mass"] == pytest.approx(MU_ASYM, abs=ATOL)

    def test_flux_tube_energy(self):
        """Flux tube energy = sigma_W * r_c = T*."""
        result = string_tension_analog()
        assert result["flux_tube_energy"] == pytest.approx(T_STAR, abs=ATOL)

    def test_mass_gap_over_T(self):
        """Mass gap in temperature units."""
        result = string_tension_analog()
        assert result["mass_gap_over_T"] == pytest.approx(MU_COH / T_STAR, abs=ATOL)


# =============================================================================
# FULL SPECTRUM ANALYSIS
# =============================================================================

class TestFullSpectrumAnalysis:

    def test_returns_all_sections(self):
        """Full analysis contains all sub-analyses."""
        result = full_spectrum_analysis()
        assert "spectrum" in result
        assert "glueball" in result
        assert "landau_ginzburg" in result
        assert "string_tension" in result
        assert "spectral_summary" in result
        assert "honest_assessment" in result

    def test_spectral_summary_eigenvalues(self):
        """Spectral summary has correct eigenvalues."""
        result = full_spectrum_analysis()
        ss = result["spectral_summary"]
        assert ss["eigenvalues"] == [MU_COH, MU_ASYM]
        assert ss["mass_gap"] == pytest.approx(MU_COH, abs=ATOL)

    def test_condition_number(self):
        """Condition number = mu_asym / mu_coh."""
        result = full_spectrum_analysis()
        assert result["spectral_summary"]["condition_number"] == pytest.approx(
            MU_ASYM / MU_COH, abs=ATOL
        )

    def test_spectral_width(self):
        """Spectral width = mu_asym - mu_coh."""
        result = full_spectrum_analysis()
        assert result["spectral_summary"]["spectral_width"] == pytest.approx(
            MU_ASYM - MU_COH, abs=ATOL
        )

    def test_geometric_mean(self):
        """Geometric mean of eigenvalues."""
        result = full_spectrum_analysis()
        expected = math.sqrt(MU_COH * MU_ASYM)
        assert result["spectral_summary"]["geometric_mean"] == pytest.approx(expected, abs=ATOL)

    def test_harmonic_mean(self):
        """Harmonic mean of eigenvalues."""
        result = full_spectrum_analysis()
        expected = 2.0 * MU_COH * MU_ASYM / (MU_COH + MU_ASYM)
        assert result["spectral_summary"]["harmonic_mean"] == pytest.approx(expected, abs=ATOL)

    def test_honest_assessment_present(self):
        """Assessment string is present and substantive."""
        result = full_spectrum_analysis()
        assert isinstance(result["honest_assessment"], str)
        assert "proven" in result["honest_assessment"].lower() or "exact" in result["honest_assessment"].lower()

    def test_conservation_at_equilibrium(self):
        """Conservation law holds at the equilibrium point."""
        assert LAM_STAR + KAP_STAR + ETA_STAR == pytest.approx(1.0, abs=ATOL)
