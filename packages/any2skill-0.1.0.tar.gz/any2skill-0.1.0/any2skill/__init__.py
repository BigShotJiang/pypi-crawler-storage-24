"""any2skill - Turn any document into an AI Agent Skill."""

__version__ = "0.1.0"
