# any2skill

Turn any document into an AI Agent Skill.

Upload a PDF, Word doc, or paste a URL. Get back a production-ready `SKILL.md` for Claude Code, Cursor, and any AI agent platform.

## Website

https://any2skill.ai

## Features

- **Multi-format input**: PDF, DOCX, URL
- **Smart clarification**: AI asks targeted questions before generating
- **Quality assurance**: Spec compliance, security scanning, content validation
- **Multi-language**: English and Chinese output
- **AI refinement**: Iterate with natural language instructions

## Status

Early development. Full CLI and SDK coming soon.
