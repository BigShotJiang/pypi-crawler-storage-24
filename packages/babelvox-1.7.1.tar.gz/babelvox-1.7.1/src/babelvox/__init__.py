"""BabelVox: Real-time text-to-speech on Intel NPU/CPU via OpenVINO."""
from importlib.metadata import PackageNotFoundError, version

from babelvox.longform import LongFormSynthesizer, segment_text
from babelvox.pipeline import BabelVox, download_models, mel_spectrogram_np
from babelvox.prosody import ProsodyConfig
from babelvox.server import serve
from babelvox.speakers import (
    SpeakerLibrary,
    SpeakerProfile,
    interpolate_speakers,
    mix_speakers,
)
from babelvox.text import preprocess_text

try:
    __version__ = version("babelvox")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["BabelVox", "download_models", "mel_spectrogram_np", "serve",
           "preprocess_text", "SpeakerProfile", "SpeakerLibrary",
           "mix_speakers", "interpolate_speakers", "ProsodyConfig",
           "LongFormSynthesizer", "segment_text"]
