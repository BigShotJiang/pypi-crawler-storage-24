"""LLM strategy module."""
