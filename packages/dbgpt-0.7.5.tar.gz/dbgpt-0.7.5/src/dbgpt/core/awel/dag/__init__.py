"""The module of DAGs."""
