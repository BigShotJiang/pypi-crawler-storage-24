"""Module for KG."""
