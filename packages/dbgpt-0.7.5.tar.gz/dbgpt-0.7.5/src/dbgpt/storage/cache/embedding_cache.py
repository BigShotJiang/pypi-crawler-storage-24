"""Embeddings cache."""
