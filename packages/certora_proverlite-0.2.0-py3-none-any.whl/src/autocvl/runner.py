"""
AutoCVL subprocess runner for PreAudit.

This module handles asynchronous subprocess execution of AutoCVL scripts,
with full logging of all output to orchestrator.log.
"""

import asyncio
import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from src.autocvl.config_builder import AutoCVLConfigBuilder
from src.utils.types import ContractHandle


@dataclass
class AutoCVLConfig:
    """Configuration for AutoCVL execution."""

    iterative: bool = False
    max_iterations: int = 3


@dataclass
class AutoCVLResult:
    """Result from AutoCVL execution."""

    success: bool
    spec_files: List[Path]
    stdout: str
    stderr: str
    return_code: int
    error_message: Optional[str] = None


class AutoCVLRunner:
    """
    Runs AutoCVL as a subprocess with async execution.

    Supports both single-pass and iterative modes, with full logging
    of all subprocess output.
    """

    def __init__(
        self,
        autocvl_config: AutoCVLConfig,
        certora_dir: Path,
        log_func: Callable[[str, str], None],
    ):
        """
        Initialize AutoCVL runner.

        Args:
            autocvl_config: Configuration for AutoCVL execution
            certora_dir: Path to certora/ directory for output
            log_func: Logging function (message, level)
        """
        self.config = autocvl_config
        self.certora_dir = certora_dir
        self.log = log_func
        self.config_builder = AutoCVLConfigBuilder(certora_dir, log_func)

    def _create_verification_config(
        self,
        contract_handle: ContractHandle,
        spec_file: Path,
        base_config_path: Path,
    ) -> Path:
        """
        Create config file for AutoCVL-generated spec to be picked up by verification.

        For single-pass mode, we need to create a config file in certora_autocvl_checker/
        so that find_generated_configs() will discover it for submission.

        Args:
            contract_handle: Contract the spec was generated for
            spec_file: Path to the generated spec file
            base_config_path: Path to base configuration to copy settings from

        Returns:
            Path to the created config file
        """
        contract_name = contract_handle.contract_name

        # Create output directory following the certora_*_checker pattern
        output_dir = self.certora_dir / "certora_autocvl_checker"
        output_dir.mkdir(parents=True, exist_ok=True)

        # Load base config and update verify field
        base_config = self.config_builder._load_base_config(base_config_path)
        base_config["verify"] = f"{contract_name}:{spec_file}"

        # Write the config file
        conf_path = output_dir / f"autocvl-{contract_name}.conf"
        with open(conf_path, "w") as f:
            json.dump(base_config, f, indent=2)

        self.log(f"Created verification config: {conf_path}", "INFO")
        return conf_path

    async def _execute_subprocess(self, cmd: List[str], timeout_seconds: int = 3600) -> AutoCVLResult:
        """
        Execute a subprocess asynchronously with full output capture.

        Args:
            cmd: Command to execute as list of strings
            timeout_seconds: Timeout in seconds (default 1 hour)

        Returns:
            AutoCVLResult with captured output
        """
        cmd_str = " ".join(cmd)
        self.log(f"Executing AutoCVL command: {cmd_str}", "INFO")

        # Run from project directory (parent of certora/) so remappings resolve correctly
        project_dir = self.certora_dir.parent

        try:
            # Propagate vendored package path to subprocess so auto_cvl is discoverable
            # when running from the release wheel (where it lives under _vendor/).
            env = os.environ.copy()
            vendor_dir = Path(__file__).resolve().parent.parent.parent / "_vendor"
            if vendor_dir.is_dir():
                existing = env.get("PYTHONPATH", "")
                env["PYTHONPATH"] = f"{vendor_dir}:{existing}" if existing else str(vendor_dir)

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(project_dir),
                env=env,
            )

            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout_seconds,
            )

            stdout = stdout_bytes.decode("utf-8", errors="replace")
            stderr = stderr_bytes.decode("utf-8", errors="replace")

            # Log all output with clear markers
            self.log("=== AutoCVL STDOUT START ===", "INFO")
            if stdout.strip():
                for line in stdout.splitlines():
                    self.log(f"  {line}", "INFO")
            else:
                self.log("  (no stdout)", "DEBUG")
            self.log("=== AutoCVL STDOUT END ===", "INFO")

            if stderr.strip():
                self.log("=== AutoCVL STDERR START ===", "WARNING")
                for line in stderr.splitlines():
                    self.log(f"  {line}", "WARNING")
                self.log("=== AutoCVL STDERR END ===", "WARNING")

            success = proc.returncode in (0, 2)
            error_message = None
            if not success:
                error_message = f"AutoCVL exited with code {proc.returncode}"
                self.log(error_message, "ERROR")
            elif proc.returncode == 2:
                self.log("AutoCVL exited with code 2 (non-fatal issues)", "WARNING")

            return AutoCVLResult(
                success=success,
                spec_files=[],  # Will be populated by caller
                stdout=stdout,
                stderr=stderr,
                return_code=proc.returncode if proc.returncode is not None else -1,
                error_message=error_message,
            )

        except asyncio.TimeoutError:
            error_message = f"AutoCVL timed out after {timeout_seconds} seconds"
            self.log(error_message, "ERROR")
            return AutoCVLResult(
                success=False,
                spec_files=[],
                stdout="",
                stderr="",
                return_code=-1,
                error_message=error_message,
            )

        except Exception as e:
            error_message = f"AutoCVL subprocess error: {e}"
            self.log(error_message, "ERROR")
            return AutoCVLResult(
                success=False,
                spec_files=[],
                stdout="",
                stderr="",
                return_code=-1,
                error_message=error_message,
            )

    async def run_single_pass(
        self,
        contract_handle: ContractHandle,
        summaries_spec: Path,
        solc: str,
        remappings: List[str],
        via_ir: bool,
    ) -> AutoCVLResult:
        """
        Run AutoCVL in single-pass mode (no iterative feedback).

        Args:
            contract_handle: Contract to generate specs for
            summaries_spec: Path to summaries-{Contract}.spec file
            solc: Solidity compiler command/path
            remappings: Solidity remappings
            via_ir: Whether to use --via-ir compilation

        Returns:
            AutoCVLResult with generated spec files
        """
        contract_name = contract_handle.contract_name
        # Use absolute paths since subprocess runs with AutoCVL cwd
        contract_file = Path(contract_handle.source_file).resolve()
        output_spec = (self.certora_dir / f"autocvl-{contract_name}.spec").resolve()

        self.log(f"Running AutoCVL single-pass for {contract_name}", "INFO")

        # Build command using installed module
        cmd = [
            sys.executable,
            "-m",
            "auto_cvl.auto_generate_cvl",
            "--contract-file",
            str(contract_file),
            "--contract",
            contract_name,
            "--solc",
            solc,
            "--out",
            str(output_spec),
        ]

        # Add remappings
        if remappings:
            cmd.extend(["--remappings"] + remappings)

        # Add via-ir flag
        if via_ir:
            cmd.append("--via-ir")

        # Add summaries import (use absolute path)
        if summaries_spec.exists():
            cmd.extend(["--cvl-imports", str(summaries_spec.resolve())])

        result = await self._execute_subprocess(cmd)

        # Check for generated spec file
        if result.success and output_spec.exists():
            result.spec_files = [output_spec]
            self.log(f"Generated spec: {output_spec}", "SUCCESS")
        elif result.success:
            result.success = False
            result.error_message = f"AutoCVL completed but no spec file generated at {output_spec}"
            self.log(result.error_message, "ERROR")

        return result

    async def run_iterative(
        self,
        contract_handle: ContractHandle,
        conf_path: Path,
        summaries_spec: Path,
    ) -> AutoCVLResult:
        """
        Run AutoCVL in iterative mode with violation feedback loop.

        Args:
            contract_handle: Contract to generate specs for
            conf_path: Path to AutoCVL configuration file
            summaries_spec: Path to summaries-{Contract}.spec file

        Returns:
            AutoCVLResult with generated spec files
        """
        contract_name = contract_handle.contract_name
        output_spec = self.certora_dir / f"autocvl-{contract_name}.spec"

        self.log(f"Running AutoCVL iterative mode for {contract_name} (max {self.config.max_iterations} iterations)", "INFO")

        # Build command using installed console script
        cmd = [
            "autocvl-flow",
            "--conf",
            str(conf_path),
            "--contract",
            contract_name,
            "--max-iterations",
            str(self.config.max_iterations),
        ]

        # Add summaries import (use absolute path)
        if summaries_spec.exists():
            cmd.extend(["--cvl-imports", str(summaries_spec.resolve())])

        result = await self._execute_subprocess(cmd)

        # Check for generated spec file
        if result.success and output_spec.exists():
            result.spec_files = [output_spec]
            self.log(f"Generated spec: {output_spec}", "SUCCESS")
        elif result.success:
            # Iterative mode may produce output in different location
            # Check standard location
            result.success = False
            result.error_message = f"AutoCVL iterative completed but no spec file found at {output_spec}"
            self.log(result.error_message, "ERROR")

        return result

    async def run_for_contract(
        self,
        contract_handle: ContractHandle,
        base_config_path: Path,
        solc: str = "solc",
        remappings: Optional[List[str]] = None,
        via_ir: bool = False,
        extra_config: Optional[Dict] = None,
    ) -> AutoCVLResult:
        """
        Run AutoCVL for a single contract.

        Args:
            contract_handle: Contract to process
            base_config_path: Path to the base config for this contract
            solc: Solidity compiler command
            remappings: Solidity remappings
            via_ir: Whether to use --via-ir
            extra_config: Additional config parameters (loop_iter, etc.)

        Returns:
            AutoCVLResult for this contract

        Raises:
            RuntimeError: If generation fails
        """
        remappings = remappings or []
        extra_config = extra_config or {}
        contract_name = contract_handle.contract_name

        self.log(f"=== Processing AutoCVL for {contract_name} ===", "INFO")

        # Path to summaries spec
        summaries_spec = self.certora_dir / f"summaries-{contract_name}.spec"

        if self.config.iterative:
            # Build conf file for iterative mode
            if not base_config_path.exists():
                raise RuntimeError(f"Base config not found for {contract_name}: {base_config_path}")

            conf_path = self.config_builder.build_conf(
                contract_handle=contract_handle,
                base_config_path=base_config_path,
                output_spec_name=f"autocvl-{contract_name}.spec",
                extra_config=extra_config,
            )

            result = await self.run_iterative(contract_handle, conf_path, summaries_spec)
        else:
            # Single-pass mode - use direct arguments
            result = await self.run_single_pass(
                contract_handle=contract_handle,
                summaries_spec=summaries_spec,
                solc=solc,
                remappings=remappings,
                via_ir=via_ir,
            )

            # Create verification config for single-pass mode
            # so find_generated_configs() can pick it up
            if result.success and result.spec_files:
                if base_config_path.exists():
                    self._create_verification_config(
                        contract_handle=contract_handle,
                        spec_file=result.spec_files[0],
                        base_config_path=base_config_path,
                    )
                else:
                    self.log(
                        f"Warning: No base config for {contract_name}, skipping verification config creation",
                        "WARNING",
                    )

        if not result.success:
            raise RuntimeError(
                f"AutoCVL generation failed for {contract_name}: {result.error_message}"
            )

        return result
