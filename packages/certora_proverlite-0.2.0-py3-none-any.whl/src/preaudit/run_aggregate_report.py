#!/usr/bin/env python
"""
Standalone script to aggregate checker reports from multiple job URLs with multi-analysis.

This script calls process_aggregated() directly to:
1. Collect all violated rules from all jobs
2. Run N iterations of AI analysis per violated rule
3. Synthesize the iterations into a final conclusion per rule
4. Create an aggregated report combining all syntheses

Usage:
    # Generate aggregated report with multi-analysis (default)
    python run_aggregate_report.py --results-file path/to/orchestrator_results.json

    # Generate simple aggregated report without multi-analysis
    python run_aggregate_report.py --results-file path/to/orchestrator_results.json --simple

    # Customize number of iterations
    python run_aggregate_report.py --results-file path/to/orchestrator_results.json --iterations 5
"""
import logging
import shutil
import sys
import json
import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Protocol

# Import logger early to set up keyring warning filter before certora_login
from src.utils.logger import logger as _preaudit_logger  # noqa: F401

from certora_login import login  # type: ignore[import-untyped]

from src.generic_checkers.reporting.__main__ import AggregatedReportJSON, process_aggregated, render_aggregated_markdown, DEFAULT_MAX_WORKERS
from src.generic_checkers.reporting.base.checker_type import CheckerType
from src.generic_checkers.reporting.html_report import ReportMode, _NON_PROJECT_PREFIXES

# Suppress dashboard tarball_manager logs (too verbose for aggregate report)
from src.dashboard.logger import dashboard_logger as _dashboard_logger
_dashboard_logger.muted = True  # Suppress console output (file logging still works)


class ReportArgsProtocol(Protocol):
    """Protocol for report generation arguments."""

    job_url: Optional[str]
    analyze: bool
    checker: Optional[str]
    include_passing: bool
    format: str
    output: Optional[str]
    skip_ai: bool
    no_cache: bool
    clear_cache: bool
    multi_analysis: bool
    iterations: int
    max_concurrent_rules: int
    aggregate: Optional[List[str]]


@dataclass
class ReportArgs:
    """Arguments for report generation."""

    job_url: Optional[str] = None
    analyze: bool = False
    checker: Optional[str] = None
    rule: Optional[str] = None
    include_passing: bool = False
    format: str = "markdown"
    output: Optional[str] = None
    skip_ai: bool = False
    no_cache: bool = False
    clear_cache: bool = False
    multi_analysis: bool = False
    iterations: int = 3
    max_concurrent_rules: int = DEFAULT_MAX_WORKERS
    aggregate: Optional[List[str]] = None
    ignore_calltrace_errors: bool = False
    project_dir: Optional[str] = None
    rag_db: Optional[str] = None
    contract_name: str = ""


def setup_logging():
    """Set up logging to both file and console."""
    log_dir = Path(".certora_internal")
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / "aggregate_report.log"

    # Create logger
    logger = logging.getLogger("aggregate_report")
    logger.setLevel(logging.INFO)
    logger.propagate = False  # Prevent duplicate messages from parent loggers

    # Clear any existing handlers
    logger.handlers.clear()

    # File handler (append mode)
    file_handler = logging.FileHandler(log_file, mode='a')
    file_handler.setLevel(logging.INFO)
    file_formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(file_formatter)

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(message)s')
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


@dataclass
class OrchestratorJobs:
    """Jobs extracted from orchestrator results, with autocvl identification."""

    jobs: List[Dict[str, Any]]  # Each dict: url, config_name, config_file, violations
    llm_usage: List[Dict[str, Any]]  # Per-call LLM token usage from orchestrator setup_summaries

    @property
    def autocvl_job_urls(self) -> set[str]:
        """URLs of jobs whose config file path contains 'certora_autocvl_checker'."""
        return {j["url"] for j in self.jobs if "certora_autocvl_checker" in j.get("config_file", "")}

    @property
    def job_urls(self) -> list[str]:
        return [j["url"] for j in self.jobs]


def extract_jobs_from_orchestrator(results_file: Path) -> OrchestratorJobs:
    """Extract job URLs with violations from orchestrator results."""
    with open(results_file) as f:
        orchestrator_results = json.load(f)

    jobs = []
    for result in orchestrator_results.get("config_results", []):
        if result.get("success") and result.get("job_url") != "failed":
            violations = result.get("violations", 0)
            if violations > 0:
                config_file = result.get("config_file", "")
                config_name = Path(config_file).stem.replace("-Hub", "")
                jobs.append({
                    "url": result["job_url"],
                    "config_name": config_name,
                    "config_file": config_file,
                    "violations": violations
                })

    llm_usage = orchestrator_results.get("llm_usage", [])
    return OrchestratorJobs(jobs=jobs, llm_usage=llm_usage)


def run_checker_report_aggregate(
    job_urls: List[str],
    output_file: Path,
    logger: logging.Logger,
    multi_analysis: bool = True,
    iterations: int = 3,
    skip_ai: bool = False,
    max_concurrent_rules: int = DEFAULT_MAX_WORKERS,
    checker: Optional[str] = None,
    rule: Optional[str] = None,
    ignore_calltrace_errors: bool = False,
    project_dir: Optional[str] = None,
    rag_db: Optional[str] = None,
    autocvl_job_urls: set[str] | None = None,
    contract_name: str = "",
) -> bool:
    """
    Run process_aggregated() to generate the aggregated report.

    Args:
        job_urls: List of job URLs to aggregate
        output_file: Output file path
        logger: Logger instance
        multi_analysis: If True, run multi-analysis flow (iterations + synthesis per rule)
        iterations: Number of analysis iterations per rule when using multi_analysis
        skip_ai: If True, skip AI analysis entirely (overrides multi_analysis)
        max_concurrent_rules: Max concurrent API tasks in multi-analysis mode
        checker: Filter to a specific checker type (e.g., external_call, privileged_operations)
        rule: Filter to a specific rule name
        ignore_calltrace_errors: If True, skip jobs with SourceLocationExtractionError instead of aborting
        autocvl_job_urls: Set of job URLs that are autocvl jobs (identified by config file path)
    """
    description = "Generating aggregated report"
    if checker:
        description += f" for checker '{checker}'"
    if rule:
        description += f" for rule '{rule}'"
    if multi_analysis and not skip_ai:
        description += f" with multi-analysis ({iterations} iterations per rule)"

    logger.info("\n>>> %s", description)

    # Create typed args object
    args = ReportArgs(
        output=str(output_file),
        skip_ai=skip_ai,
        multi_analysis=multi_analysis,
        iterations=iterations,
        max_concurrent_rules=max_concurrent_rules,
        aggregate=job_urls,
        checker=checker,
        rule=rule,
        ignore_calltrace_errors=ignore_calltrace_errors,
        project_dir=project_dir,
        rag_db=rag_db,
        contract_name=contract_name,
    )

    try:
        process_aggregated(job_urls, args, logger, autocvl_job_urls=autocvl_job_urls or set())
        return True
    except Exception as e:
        logger.error("Failed to generate aggregated report: %s", e)
        return False


def _build_source_pointers(
    report: AggregatedReportJSON,
    logger: logging.Logger,
) -> tuple[Dict[str, Dict[str, Any]], Dict[str, List[Any]]]:
    """Fetch calltrace data for each report entry and build source pointer maps.

    Returns:
        (source_pointers, top_level_methods) where:
        - source_pointers: rule_name → {method_name → SourcePointer}
        - top_level_methods: rule_name → [(method_name, SourcePointer)] for single-output rules only,
          filtered to project-specific files
    """
    from src.generic_checkers.reporting.extractors import JobDataExtractor
    from src.generic_checkers.reporting.html_report import SourcePointer, _walk_calltrace_for_sources

    source_pointers: Dict[str, Dict[str, Any]] = {}
    top_level_methods: Dict[str, List[Any]] = {}

    for entry in report.entries:
        if not entry.job_urls:
            continue

        method_map: Dict[str, SourcePointer] = {}
        all_output_files: list[str] = []

        for job_url in entry.job_urls:
            try:
                extractor = JobDataExtractor(job_url)
                violated_checks = extractor.get_violated_checks_by_rule(entry.rule_name)
                for check in violated_checks:
                    if check.output_files:
                        all_output_files.extend(check.output_files)
                        for output_file in check.output_files:
                            try:
                                calltrace_result = extractor.api.get_calltrace(job_url, output_file)
                                if not hasattr(calltrace_result, "trace_data") or not calltrace_result.trace_data:
                                    continue
                                trace_data = calltrace_result.trace_data
                                if isinstance(trace_data, dict) and "callTrace" in trace_data:
                                    _walk_calltrace_for_sources(trace_data["callTrace"], method_map)
                            except Exception:
                                continue
            except Exception as e:
                logger.debug("Failed to fetch calltrace for %s from %s: %s", entry.rule_name, job_url, e)
                continue

        if method_map:
            source_pointers[entry.rule_name] = method_map

            # Build top_level_methods only for rules with a single output file
            unique_outputs = list(dict.fromkeys(all_output_files))
            if len(unique_outputs) == 1:
                filtered = [
                    (name, ptr)
                    for name, ptr in method_map.items()
                    if not any(ptr["file"].startswith(prefix) for prefix in _NON_PROJECT_PREFIXES)
                ]
                if filtered:
                    top_level_methods[entry.rule_name] = filtered

    return source_pointers, top_level_methods


def _generate_html_report(
    report: AggregatedReportJSON,
    args: argparse.Namespace,
    output_file: Path,
    logger: logging.Logger,
) -> Path:
    """Generate HTML report from an AggregatedReportJSON, if --project-dir is provided."""
    from src.generic_checkers.reporting.html_report import render_aggregated_html

    if not args.project_dir:
        logger.error("--project-dir is required for HTML report generation")
        sys.exit(1)

    project_dir = Path(args.project_dir)
    sources_json_path = project_dir / ".certora_internal" / "all_sources.json"
    if sources_json_path.exists():
        with open(sources_json_path) as f:
            sources = json.load(f)
    else:
        logger.debug("all_sources.json not found at: %s", sources_json_path)
        logger.debug("HTML report will be generated without source file viewer.")
        sources = {}

    # Build source pointers from calltrace data (best-effort)
    # Only if sources are available (source pointers link into file viewer)
    sp: Dict[str, Dict[str, Any]] = {}
    tlm: Dict[str, List[Any]] = {}
    if sources:
        try:
            sp, tlm = _build_source_pointers(report, logger)
            if sp:
                logger.debug("Built source pointers for %d rules", len(sp))
        except Exception as e:
            logger.debug("Source pointer extraction failed (non-fatal): %s", e)

    project_name = project_dir.name
    contract_name = report.contract_name or getattr(args, 'contract_name', '') or ''
    def _render(mode: ReportMode) -> str:
        return render_aggregated_html(
            report=report,
            sources=sources,
            project_dir=project_dir,
            project_name=project_name,
            source_pointers=sp,
            top_level_methods=tlm,
            contract_name=contract_name,
            report_mode=mode,
        )

    # Generate presentable report (main filename)
    html_output = output_file.with_suffix(".html")
    with open(html_output, 'w') as f:
        f.write(_render(ReportMode.PRESENTABLE))
    logger.debug("Presentable HTML report written to: %s", html_output)

    # Generate verbose report (-verbose suffix, stays in reports dir only)
    verbose_output = output_file.with_stem(output_file.stem + "-verbose").with_suffix(".html")
    with open(verbose_output, 'w') as f:
        f.write(_render(ReportMode.VERBOSE))
    logger.debug("Verbose HTML report written to: %s", verbose_output)

    # Copy presentable HTML report to project root with standardized name
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    results_stem = getattr(args, 'results_json_stem', '')
    if contract_name and "," not in contract_name:
        root_report_name = f"proverlite-{project_name}-{contract_name}-{timestamp}.html"
    elif results_stem:
        root_report_name = f"proverlite-{project_name}-{results_stem}-{timestamp}.html"
    else:
        root_report_name = f"proverlite-{project_name}-{timestamp}.html"
    root_report_path = project_dir / root_report_name
    shutil.copy2(html_output, root_report_path)
    logger.debug("Report ready: %s", root_report_path)
    return root_report_path


def main():
    """Main entry point."""
    # Set up logging
    logger = setup_logging()

    parser = argparse.ArgumentParser(
        description="Aggregate checker reports with multi-analysis"
    )
    parser.add_argument(
        "--results-file",
        help="Path to orchestrator_results.json (required unless --from-json is used)"
    )
    parser.add_argument(
        "--simple",
        action="store_true",
        help="Generate simple aggregated report without multi-analysis"
    )
    parser.add_argument(
        "--iterations",
        type=int,
        default=3,
        help="Number of analysis iterations per rule (default: 3)"
    )
    parser.add_argument(
        "--skip-ai",
        action="store_true",
        help="Skip AI analysis entirely (fastest, no insights)"
    )
    parser.add_argument(
        "--max-concurrent-rules",
        type=int,
        default=4,
        help="Max concurrent API tasks in multi-analysis mode (default: 4)"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging for grouping strategy (verbose calltrace inspection)"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file for aggregated report (default: aggregated_findings_report.md in same dir as results)"
    )
    parser.add_argument(
        "--from-json",
        metavar="JSON_FILE",
        help="Regenerate markdown from an existing aggregated JSON report (skip analysis entirely)"
    )
    parser.add_argument(
        "--project-dir",
        metavar="DIR",
        help="Project root directory (for HTML report with source file viewer). "
        "Reads .certora_internal/all_sources.json from this directory."
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Also generate an HTML report with interactive file viewer (requires --project-dir)"
    )
    parser.add_argument(
        "--checker", "-c",
        choices=[ct.value for ct in CheckerType],
        help="Filter to a specific checker type. Available: " + ", ".join(ct.value for ct in CheckerType)
    )
    parser.add_argument(
        "--rule", "-r",
        help="Filter to a specific rule name. Use --list-rules to see available rules."
    )
    parser.add_argument(
        "--list-rules",
        action="store_true",
        help="List all violated rules from the jobs and exit (does not run analysis)"
    )
    parser.add_argument(
        "--ignore-calltrace-errors",
        action="store_true",
        help="Skip rules/jobs where calltrace source location extraction fails instead of aborting"
    )
    parser.add_argument(
        "--rag-db",
        help="RAG database path (ChromaDB directory) or PostgreSQL connection string. "
        "Defaults to bundled ChromaDB from analyzer package."
    )

    args = parser.parse_args()

    # Enable debug logging for grouping strategy if requested
    if args.debug:
        import logging as _logging
        gs_logger = _logging.getLogger("src.generic_checkers.reporting.grouping_strategy")
        gs_logger.setLevel(_logging.DEBUG)
        gs_logger.handlers.clear()

        # Console handler for debug output
        console_handler = _logging.StreamHandler()
        console_handler.setLevel(_logging.DEBUG)
        console_handler.setFormatter(_logging.Formatter('[%(name)s] %(message)s'))
        gs_logger.addHandler(console_handler)

        # File handler - same file as main logger
        log_file = Path(".certora_internal") / "aggregate_report.log"
        file_handler = _logging.FileHandler(log_file, mode='a')
        file_handler.setLevel(_logging.DEBUG)
        file_handler.setFormatter(_logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        gs_logger.addHandler(file_handler)

        logger.info("Debug logging enabled for grouping strategy (also writing to %s)", log_file)

    if args.from_json:
        json_path = Path(args.from_json)
        if not json_path.exists():
            logger.error("JSON file not found: %s", json_path)
            sys.exit(1)

        report = AggregatedReportJSON.model_validate_json(json_path.read_text())

        if args.output:
            md_output = Path(args.output)
        else:
            md_output = json_path.with_suffix(".md")

        with open(md_output, 'w') as f:
            f.write(render_aggregated_markdown(report))
        logger.info("Markdown regenerated from JSON: %s", md_output)

        # Also generate HTML if requested
        if args.html:
            # Login for API access (needed for source pointers); non-fatal if it fails
            try:
                login(env="prod", force_file=True)
            except Exception as e:
                logger.debug("Login failed for --from-json --html (source links will be unavailable): %s", e)
            _generate_html_report(report, args, md_output, logger)

        return

    if not args.results_file:
        parser.error("--results-file is required unless --from-json is used")

    # Authenticate with Certora (only needed for the analysis flow, not --from-json)
    logger.info("Authenticating with Certora...")
    login(env="prod", force_file=True)

    results_file = Path(args.results_file)
    if not results_file.exists():
        logger.error("Results file not found: %s", results_file)
        sys.exit(1)

    reports_dir = results_file.parent

    # Extract jobs with violations
    orch_jobs = extract_jobs_from_orchestrator(results_file)
    job_urls = orch_jobs.job_urls

    # Record orchestrator LLM cost on the global tracker
    if orch_jobs.llm_usage:
        from src.generic_checkers.reporting.token_usage import compute_llm_cost, get_global_tracker
        get_global_tracker().record_orchestrator_llm_cost(compute_llm_cost(orch_jobs.llm_usage))

    logger.info("Found %d jobs with violations:", len(orch_jobs.jobs))
    for job in orch_jobs.jobs:
        logger.info("  - %s: %d violations", job['config_name'], job['violations'])

    # Handle --list-rules: show available rules and exit
    if args.list_rules:
        from src.generic_checkers.reporting.processor import CheckerOutputProcessor

        logger.info("\nCollecting violated rules from all jobs...")
        rules_by_checker: Dict[str, set] = {}

        for job_url in job_urls:
            try:
                processor = CheckerOutputProcessor(
                    job_url=job_url,
                    skip_ai=True,
                    use_cache=True,
                    use_retry=True,
                )
                analysis = processor.analyze_job()
                for dc in analysis.detected_checkers:
                    if not dc.has_violations:
                        continue
                    if dc.checker_type not in rules_by_checker:
                        rules_by_checker[dc.checker_type] = set()
                    rules_by_checker[dc.checker_type].update(dc.violated_rule_names)
            except Exception as e:
                logger.warning("Could not analyze job %s: %s", job_url, e)

        if not rules_by_checker:
            logger.info("No violated rules found.")
            return

        logger.info("\nAvailable violated rules:")
        for checker_type in sorted(rules_by_checker.keys()):
            logger.info("  %s:", checker_type)
            for rule in sorted(rules_by_checker[checker_type]):
                logger.info("    - %s", rule)
        return

    # Determine output path
    if args.output:
        output_file = Path(args.output)
    elif ".CertoraProverLiteReports" in reports_dir.parts:
        output_file = reports_dir / "aggregated_findings_report.md"
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        reports_dir = results_file.parent / ".CertoraProverLiteReports" / timestamp
        reports_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(results_file, reports_dir / results_file.name)
        output_file = reports_dir / "aggregated_findings_report.md"

    # Determine analysis mode
    multi_analysis = not args.simple and not args.skip_ai

    logger.info("\n%s", '='*60)
    if args.skip_ai:
        logger.info("Generating aggregated report (AI analysis disabled)")
    elif multi_analysis:
        logger.info("Generating aggregated report with multi-analysis")
        logger.info("  - %d iterations per violated rule", args.iterations)
        logger.info("  - Synthesis using Claude Opus 4.5")
    else:
        logger.info("Generating simple aggregated report")
    if args.checker:
        logger.info("  - Filtering to checker: %s", args.checker)
    if args.rule:
        logger.info("  - Filtering to rule: %s", args.rule)
    logger.info("%s", '='*60)

    success = run_checker_report_aggregate(
        job_urls=job_urls,
        output_file=output_file,
        logger=logger,
        multi_analysis=multi_analysis,
        iterations=args.iterations,
        skip_ai=args.skip_ai,
        max_concurrent_rules=args.max_concurrent_rules,
        checker=args.checker,
        rule=args.rule,
        ignore_calltrace_errors=args.ignore_calltrace_errors,
        project_dir=args.project_dir,
        rag_db=args.rag_db,
        autocvl_job_urls=orch_jobs.autocvl_job_urls,
    )

    if not success:
        logger.error("\nAggregated report generation failed")
        logger.error("You may need to check your CERTORAKEY environment variable")
        sys.exit(1)

    # Generate HTML report if requested
    if args.html:
        json_output = output_file.with_suffix(".json")
        if json_output.exists():
            report = AggregatedReportJSON.model_validate_json(json_output.read_text())
            _generate_html_report(report, args, output_file, logger)
        else:
            logger.warning("JSON report not found at %s, skipping HTML generation", json_output)

    logger.info("\n%s", '='*60)
    logger.info("Done. Aggregated report: %s", output_file)
    logger.info("%s\n", '='*60)


if __name__ == "__main__":
    main()
