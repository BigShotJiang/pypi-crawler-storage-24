"""Shared constants, types, and utility functions for the HTML report renderer."""

from __future__ import annotations

import html
import json
import re
from enum import Enum
from pathlib import Path
from typing import Any, TypedDict

from pygments import highlight as pygments_highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import SolidityLexer, get_lexer_by_name, get_lexer_for_filename
from pygments.util import ClassNotFound

from src.generic_checkers.reporting.__main__ import AggregatedReportJSON
from src.setup.solidity_utils import DEPENDENCIES


class ReportMode(Enum):
    VERBOSE = "verbose"
    PRESENTABLE = "presentable"


# File path prefixes that indicate non-project files (harnesses, libraries, tests)
_NON_PROJECT_PREFIXES = DEPENDENCIES + ["certora", "test"]

# Certora icon SVG (shield/geometric mark only, extracted from brand kit)
_CERTORA_LOGO_SVG = """\
<svg viewBox="0 0 169 195" fill="none" xmlns="http://www.w3.org/2000/svg" class="header-logo">
<path fill-rule="evenodd" clip-rule="evenodd" d="M86.3038 1L86.258 0.97353C86.2063 0.9435 86.1538 0.914795 86.1007 0.887443C85.8915 0.779849 85.6742 0.694665 85.4521 0.631889C85.1464 0.545453 84.8264 0.5 84.5 0.5C84.4596 0.5 84.4193 0.500696 84.3792 0.50208C84.1225 0.510921 83.8704 0.547822 83.6269 0.610577C83.3234 0.688725 83.0281 0.808297 82.7494 0.969291L82.6962 1H4.00003H1.00003V4V48.191L0.500015 48.4798V50.5V143.434C0.499256 143.476 0.499258 143.518 0.500015 143.56V145.52L2.24937 146.531L82.7494 193.031L84.5 194.042L86.2507 193.031L166.751 146.531C166.753 146.529 166.755 146.528 166.757 146.527L168.5 145.52V143.562C168.501 143.518 168.501 143.475 168.5 143.432V50.5V48.4798L168 48.191V4V1H165H86.3038ZM72.3091 7H7.00003V44.7251L72.3091 7ZM10.9974 143.5L81 183.936V103.064L10.9974 143.5ZM88 103.064V183.936L158.003 143.5L88 103.064ZM162 44.7251L96.6909 7H162V44.7251ZM161.5 130.432L129.53 75.0308L161.5 56.5637V130.432ZM123.469 78.5321L155.44 133.936L91.4974 97L123.469 78.5321ZM119.97 72.4692L88 90.9363V17.0678L119.97 72.4692ZM126.031 68.9679L94.0602 13.5643L158.003 50.5L126.031 68.9679ZM81 90.9363L49.0301 72.4692L81 17.0679V90.9363ZM45.5314 78.5321L77.5026 97L13.5601 133.936L45.5314 78.5321ZM39.47 75.0308L7.50002 130.432V56.5637L39.47 75.0308ZM42.9687 68.9679L10.9974 50.5L74.9399 13.5642L42.9687 68.9679Z" fill="url(#certora_grad)"/>
<defs>
<linearGradient id="certora_grad" x1="0.999512" y1="1" x2="191.542" y2="166.333" gradientUnits="userSpaceOnUse">
<stop stop-color="#79F2A5"/>
<stop offset="1" stop-color="#40DCFF"/>
</linearGradient>
</defs>
</svg>"""

# Favicon SVG: shield on dark background for browser tab icon
_CERTORA_FAVICON_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 220">'
    '<rect width="200" height="220" rx="24" fill="%232d3748"/>'
    '<g transform="translate(16,13)">'
    '<path fill-rule="evenodd" clip-rule="evenodd" d="M86.3038 1L86.258 0.97353C86.2063 0.9435 86.1538'
    " 0.914795 86.1007 0.887443C85.8915 0.779849 85.6742 0.694665 85.4521 0.631889C85.1464 0.545453"
    " 84.8264 0.5 84.5 0.5C84.4596 0.5 84.4193 0.500696 84.3792 0.50208C84.1225 0.510921 83.8704"
    " 0.547822 83.6269 0.610577C83.3234 0.688725 83.0281 0.808297 82.7494 0.969291L82.6962"
    " 1H4.00003H1.00003V4V48.191L0.500015 48.4798V50.5V143.434C0.499256 143.476 0.499258 143.518"
    " 0.500015 143.56V145.52L2.24937 146.531L82.7494 193.031L84.5 194.042L86.2507 193.031L166.751"
    " 146.531C166.753 146.529 166.755 146.528 166.757 146.527L168.5 145.52V143.562C168.501 143.518"
    " 168.501 143.475 168.5 143.432V50.5V48.4798L168 48.191V4V1H165H86.3038ZM72.3091"
    " 7H7.00003V44.7251L72.3091 7ZM10.9974 143.5L81 183.936V103.064L10.9974 143.5ZM88"
    " 103.064V183.936L158.003 143.5L88 103.064ZM162 44.7251L96.6909 7H162V44.7251ZM161.5"
    " 130.432L129.53 75.0308L161.5 56.5637V130.432ZM123.469 78.5321L155.44 133.936L91.4974"
    " 97L123.469 78.5321ZM119.97 72.4692L88 90.9363V17.0678L119.97 72.4692ZM126.031"
    " 68.9679L94.0602 13.5643L158.003 50.5L126.031 68.9679ZM81 90.9363L49.0301"
    " 72.4692L81 17.0679V90.9363ZM45.5314 78.5321L77.5026 97L13.5601 133.936L45.5314"
    " 78.5321ZM39.47 75.0308L7.50002 130.432V56.5637L39.47 75.0308ZM42.9687"
    " 68.9679L10.9974 50.5L74.9399 13.5642L42.9687 68.9679Z\""
    ' fill="url(%23fav_grad)"/>'
    "<defs>"
    '<linearGradient id="fav_grad" x1="1" y1="1" x2="192" y2="166" gradientUnits="userSpaceOnUse">'
    '<stop stop-color="%2379F2A5"/><stop offset="1" stop-color="%2340DCFF"/>'
    "</linearGradient>"
    "</defs>"
    "</g>"
    "</svg>"
)

# Deterministic color palette for rule families
FAMILY_COLORS = [
    "#e3f2fd",  # pastel blue
    "#ede7f6",  # pastel purple
    "#eceff1",  # pastel grey
    "#f3e5f5",  # pastel orchid
    "#efebe9",  # pastel brown
    "#e8eaf6",  # pastel indigo
    "#fce4ec",  # pastel pink
    "#e0e7ee",  # pastel slate
    "#d7ccc8",  # pastel taupe
    "#dcedc8",  # pastel sage
]

FAMILY_BORDER_COLORS = [
    "#1565c0",  # blue
    "#6a1b9a",  # purple
    "#546e7a",  # grey
    "#8e24aa",  # orchid
    "#5d4037",  # brown
    "#283593",  # indigo
    "#ad1457",  # pink
    "#455a64",  # slate
    "#795548",  # taupe
    "#558b2f",  # sage
]

CLASSIFICATION_BADGES = {
    "DEFINITE_ISSUE": ("#d32f2f", "#ffebee", "DEFINITE ISSUE"),
    "LIKELY_ISSUE": ("#e65100", "#fff3e0", "LIKELY ISSUE"),
    "UNCERTAIN": ("#f9a825", "#fffde7", "UNCERTAIN"),
    "LIKELY_NON_ISSUE": ("#2e7d32", "#e8f5e9", "LIKELY NON-ISSUE"),
    "DEFINITE_NON_ISSUE": ("#1b5e20", "#e8f5e9", "DEFINITE NON-ISSUE"),
}


def _score_badge_html(score: int, css_class: str) -> str:
    """Return a <span> badge showing ``score/100`` with a red-to-blue gradient background.

    High scores (100) → red hsl(360, 80%, 65%), low scores (0) → blue hsl(240, 80%, 65%),
    passing through purple at mid-range. The border uses the same hue at lower lightness (40%).
    """
    # Interpolate hue from 240 (blue) to 360 (red), passing through purple (300) at midpoint
    t = score / 100.0
    hue = 240 + 120 * t
    bg_color = f"hsl({hue:.0f}, 80%, 65%)"
    border_color = f"hsl({hue:.0f}, 80%, 40%)"
    return (
        f'<span class="{css_class}" style="background:{bg_color};color:#fff;'
        f'border:2px solid {border_color}">{score}/100</span>'
    )


def _assign_family_colors(report: AggregatedReportJSON) -> dict[str, int]:
    """Assign a color index to each unique rule family, in order of first appearance."""
    family_to_idx: dict[str, int] = {}
    for entry in report.entries:
        if entry.rule_family not in family_to_idx:
            family_to_idx[entry.rule_family] = len(family_to_idx) % len(FAMILY_COLORS)
    return family_to_idx


def _build_file_tree_json(sources: dict[str, object]) -> str:
    """Build a nested tree structure from flat file paths for the JS file tree."""
    tree: dict = {}
    for filepath in sorted(sources.keys()):
        parts = filepath.split("/")
        node = tree
        for part in parts[:-1]:
            if part not in node:
                node[part] = {}
            node = node[part]
        # Leaf node: use None to mark as file
        node[parts[-1]] = None
    return json.dumps(tree)


def _read_sources_content(sources: dict[str, object], project_dir: Path) -> str:
    """Read actual file contents and pre-highlight with Pygments, keyed by path.

    Returns JSON mapping filepath -> highlighted HTML string (spans only, no wrapper).
    """
    formatter = HtmlFormatter(nowrap=True)
    sol_lexer = SolidityLexer()
    contents: dict[str, str] = {}
    for filepath in sorted(sources.keys()):
        full_path = project_dir / filepath
        if full_path.exists():
            try:
                text = full_path.read_text(errors="replace")
                if filepath.endswith(".sol"):
                    lexer = sol_lexer
                else:
                    try:
                        lexer = get_lexer_for_filename(filepath)
                    except ClassNotFound:
                        # No lexer available — store HTML-escaped plain text
                        contents[filepath] = html.escape(text).rstrip("\n")
                        continue
                contents[filepath] = pygments_highlight(text, lexer, formatter).rstrip("\n")
            except Exception:
                contents[filepath] = html.escape(f"// Error reading {filepath}")
        else:
            contents[filepath] = html.escape(f"// File not found: {filepath}")
    return json.dumps(contents)


class SourcePointer(TypedDict):
    file: str
    line: int
    contract: str


def _walk_calltrace_for_sources(node: dict[str, Any], method_map: dict[str, SourcePointer]) -> None:
    """Recursively walk a calltrace node dict and extract method→source mappings.

    For each node with a non-null ``jumpToDefinition`` pointing to a ``.sol`` file
    and a ``message.text`` matching ``(\\w+)\\.(\\w+)\\(``, stores
    ``method_name → {file, line, contract}`` in *method_map*.

    Project-source files (those NOT under ``_NON_PROJECT_PREFIXES``) take priority
    over non-project files (harnesses, specs, tests, libraries).  Among entries of
    the same priority the first occurrence wins.
    """
    jump = node.get("jumpToDefinition")
    msg = node.get("message")
    if jump and msg:
        text = msg.get("text", "") if isinstance(msg, dict) else ""
        file_path = jump.get("file", "")
        if file_path.endswith(".sol") and text:
            m = re.search(r"(\w+)\.(\w+)\(", text)
            if m:
                contract_name = m.group(1)
                method_name = m.group(2)
                is_project_file = not any(file_path.startswith(p) for p in _NON_PROJECT_PREFIXES)
                existing = method_map.get(method_name)
                # Store if: (a) no entry yet, or (b) existing entry is non-project and this one is project
                if existing is None or (
                    is_project_file and any(existing["file"].startswith(p) for p in _NON_PROJECT_PREFIXES)
                ):
                    start = jump.get("start", {})
                    method_map[method_name] = SourcePointer(
                        file=file_path,
                        line=start.get("line", 1),
                        contract=contract_name,
                    )

    for child in node.get("childrenList", []):
        if isinstance(child, dict):
            _walk_calltrace_for_sources(child, method_map)


def _linkify_html(html_text: str, method_map: dict[str, SourcePointer]) -> str:
    """Replace method names inside ``<code class="inline-code">`` spans with clickable source links.

    Only matches method names that appear inside inline-code spans to avoid
    false positives in prose text.  Method names are sorted longest-first to
    prevent partial matches (e.g. ``updateReserveConfig`` before ``update``).
    """
    if not method_map:
        return html_text

    # Sort method names longest-first to avoid partial replacement issues
    sorted_methods = sorted(method_map.keys(), key=len, reverse=True)

    def _replace_in_code_span(match: re.Match[str]) -> str:
        code_content = match.group(1)
        for method_name in sorted_methods:
            # Skip if this method name doesn't even appear in the content
            if method_name not in code_content:
                continue
            ptr = method_map[method_name]
            # Match: methodName, Contract.methodName, Contract.methodName(), methodName()
            # Use word boundary \b to prevent matching substrings of longer identifiers
            pattern = r"(?:\w+\.)?\b" + re.escape(method_name) + r"\b(?:\(\))?"
            escaped_file = html.escape(ptr["file"]).replace("'", "\\'")
            line = ptr["line"]

            def _make_link(m: re.Match[str], _f: str = escaped_file, _l: int = line) -> str:
                return (
                    f'<a class="source-link" onclick="jumpToSource(\'{_f}\',{_l});return false"'
                    f' href="#">{m.group(0)}</a>'
                )

            code_content = re.sub(pattern, _make_link, code_content)
        return f'<code class="inline-code">{code_content}</code>'

    return re.sub(r'<code class="inline-code">(.*?)</code>', _replace_in_code_span, html_text)


def _md_to_html(text: str) -> str:
    """Minimal markdown-to-HTML conversion for synthesis sections.

    Handles: paragraphs, **bold**, `code`, bullet lists, numbered lists, headings,
    fenced code blocks with syntax highlighting, markdown tables, and <details> tags.
    Does NOT attempt full markdown parsing — just enough for the synthesis output.
    """
    if not text:
        return ""

    # First pass: extract <details>...</details> blocks and replace with placeholders
    # This preserves them from being escaped during line-by-line processing
    details_pattern = re.compile(r"(<details>.*?</details>)", re.DOTALL)
    details_blocks: list[str] = []

    def extract_details_block(match: re.Match) -> str:
        block = match.group(1)
        # Process the content inside <details> tags
        # Extract summary and body
        summary_match = re.search(r"<summary>(.*?)</summary>", block, re.DOTALL)
        summary = summary_match.group(1).strip() if summary_match else "Details"

        # Get content after </summary> and before </details>
        body_match = re.search(r"</summary>\s*(.*?)\s*</details>", block, re.DOTALL)
        body = body_match.group(1).strip() if body_match else ""

        # Convert body markdown to HTML using the inner helper
        body_html = _md_to_html_inner(body)

        # Build the HTML details element
        html_block = (
            f'<details class="iteration-details">'
            f"<summary>{html.escape(summary)}</summary>"
            f'<div class="details-body">{body_html}</div>'
            f"</details>"
        )
        placeholder = f"__DETAILS_BLOCK_{len(details_blocks)}__"
        details_blocks.append(html_block)
        return placeholder

    text = details_pattern.sub(extract_details_block, text)

    # Process the remaining content (with details blocks replaced by placeholders)
    result_str = _md_to_html_inner(text)

    # Restore details blocks from placeholders
    for i, block in enumerate(details_blocks):
        result_str = result_str.replace(f"<p>__DETAILS_BLOCK_{i}__</p>", block)
        result_str = result_str.replace(f"__DETAILS_BLOCK_{i}__", block)

    return result_str


def _md_to_html_inner(text: str) -> str:
    """Inner markdown-to-HTML conversion (handles everything except <details> tags).

    Called by _md_to_html after extracting details blocks.
    """
    if not text:
        return ""

    # Extract fenced code blocks and replace with placeholders
    # This prevents the HTML from being escaped during line-by-line processing
    code_block_pattern = re.compile(r"```(\w*)\n(.*?)```", re.DOTALL)
    code_blocks: list[str] = []

    def extract_code_block(match: re.Match) -> str:
        lang = match.group(1) or "solidity"
        code = match.group(2).rstrip("\n")
        formatter = HtmlFormatter(nowrap=True)
        try:
            if lang.lower() in ("sol", "solidity"):
                lexer = SolidityLexer()
            else:
                lexer = get_lexer_by_name(lang)
        except ClassNotFound:
            lexer = SolidityLexer()  # Default to Solidity
        highlighted = pygments_highlight(code, lexer, formatter)
        html_block = f'<pre class="code-block"><code>{highlighted}</code></pre>'
        placeholder = f"__CODE_BLOCK_{len(code_blocks)}__"
        code_blocks.append(html_block)
        return placeholder

    text = code_block_pattern.sub(extract_code_block, text)

    # Helper to detect table separator row (e.g., |---|---|)
    table_sep_pattern = re.compile(r"^\|[-:| ]+\|$")

    def parse_table_row(line: str) -> list[str]:
        """Parse a markdown table row into cells."""
        # Strip leading/trailing pipes and split
        stripped = line.strip()
        if stripped.startswith("|"):
            stripped = stripped[1:]
        if stripped.endswith("|"):
            stripped = stripped[:-1]
        return [cell.strip() for cell in stripped.split("|")]

    def emit_table(table_rows: list[list[str]], table_has_header: bool) -> str:
        """Emit accumulated table rows as HTML."""
        if not table_rows:
            return ""
        html_parts = ['<table class="md-table">']
        start_idx = 0
        if table_has_header and len(table_rows) > 0:
            html_parts.append("<thead><tr>")
            for cell in table_rows[0]:
                html_parts.append(f"<th>{_inline_format(html.escape(cell))}</th>")
            html_parts.append("</tr></thead>")
            start_idx = 1
        html_parts.append("<tbody>")
        for row in table_rows[start_idx:]:
            html_parts.append("<tr>")
            for cell in row:
                html_parts.append(f"<td>{_inline_format(html.escape(cell))}</td>")
            html_parts.append("</tr>")
        html_parts.append("</tbody></table>")
        return "".join(html_parts)

    lines = text.split("\n")
    result: list[str] = []
    in_list = False
    in_ol = False
    in_table = False
    table_rows: list[list[str]] = []
    table_has_header = False

    for line in lines:
        stripped = line.strip()

        # Check if this is a table row (starts with |)
        is_table_row = stripped.startswith("|")
        is_separator = is_table_row and table_sep_pattern.match(stripped)

        # Handle table continuation or end
        if in_table:
            if is_separator:
                # This is the header separator, mark that we have a header
                table_has_header = True
                continue
            elif is_table_row:
                # Continue accumulating table rows
                table_rows.append(parse_table_row(stripped))
                continue
            else:
                # End of table — emit it
                result.append(emit_table(table_rows, table_has_header))
                in_table = False
                table_rows = []
                table_has_header = False
                # Fall through to process the current non-table line

        # Start a new table
        if is_table_row and not is_separator:
            # Close any open lists first
            if in_list:
                result.append("</ul>")
                in_list = False
            if in_ol:
                result.append("</ol>")
                in_ol = False
            in_table = True
            table_rows = [parse_table_row(stripped)]
            continue

        # Empty line: close any open list
        if not stripped:
            if in_list:
                result.append("</ul>")
                in_list = False
            if in_ol:
                result.append("</ol>")
                in_ol = False
            continue

        # Headings
        if stripped.startswith("### "):
            if in_list:
                result.append("</ul>")
                in_list = False
            result.append(f"<h5>{_inline_format(html.escape(stripped[4:]))}</h5>")
            continue
        if stripped.startswith("## "):
            if in_list:
                result.append("</ul>")
                in_list = False
            result.append(f"<h4>{_inline_format(html.escape(stripped[3:]))}</h4>")
            continue

        # Horizontal rules
        if stripped in ("---", "***", "___"):
            continue  # skip, we use section dividers instead

        # Bullet lists
        if stripped.startswith("- ") or stripped.startswith("* "):
            if not in_list:
                result.append("<ul>")
                in_list = True
            result.append(f"<li>{_inline_format(html.escape(stripped[2:]))}</li>")
            continue

        # Numbered lists
        if len(stripped) > 2 and stripped[0].isdigit() and ". " in stripped[:5]:
            dot_pos = stripped.index(". ")
            if not in_ol:
                result.append("<ol>")
                in_ol = True
            result.append(f"<li>{_inline_format(html.escape(stripped[dot_pos + 2:]))}</li>")
            continue

        # Regular paragraph
        if in_list:
            result.append("</ul>")
            in_list = False
        if in_ol:
            result.append("</ol>")
            in_ol = False
        result.append(f"<p>{_inline_format(html.escape(stripped))}</p>")

    # Close any remaining open structures
    if in_table:
        result.append(emit_table(table_rows, table_has_header))
    if in_list:
        result.append("</ul>")
    if in_ol:
        result.append("</ol>")

    result_str = "\n".join(result)

    # Restore code blocks from placeholders
    for i, block in enumerate(code_blocks):
        # Handle both wrapped (in <p> tags) and bare placeholders
        result_str = result_str.replace(f"<p>__CODE_BLOCK_{i}__</p>", block)
        result_str = result_str.replace(f"__CODE_BLOCK_{i}__", block)

    return result_str


def _inline_format(text: str) -> str:
    """Apply inline formatting: **bold** and `code`."""
    # Bold: **text**
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Inline code: `text`
    text = re.sub(r"`(.+?)`", r'<code class="inline-code">\1</code>', text)
    return text


def _get_css() -> str:
    """Return all CSS for the HTML report."""
    return (
        """
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background: #f8fafc;
    color: #333;
    line-height: 1.6;
}

/* Header */
.report-header {
    background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
    color: white;
    padding: 28px 36px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header-left {
    display: flex;
    align-items: center;
    gap: 20px;
}

.header-logo {
    height: 80px;
    width: auto;
    flex-shrink: 0;
}

.report-header h1 {
    font-size: 26px;
    font-weight: 700;
    margin-bottom: 4px;
}

.header-project {
    font-size: 18px;
    opacity: 0.9;
    font-weight: 500;
    margin-bottom: 4px;
}

.header-contract {
    font-size: 15px;
    opacity: 0.85;
    font-weight: 400;
    margin-bottom: 4px;
}

.header-meta {
    font-size: 13px;
    opacity: 0.75;
}

.header-right {
    text-align: center;
}

.summary-stat {
    background: rgba(255,255,255,0.15);
    border-radius: 12px;
    padding: 16px 28px;
}

.stat-number {
    font-size: 36px;
    font-weight: 700;
}

.stat-label {
    font-size: 13px;
    opacity: 0.8;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* ToC Section */
.toc-section {
    background: white;
    margin: 16px 20px;
    border-radius: 10px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.10);
    overflow: hidden;
}

.section-title {
    padding: 14px 20px;
    font-size: 18px;
    cursor: pointer;
    user-select: none;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #eee;
}

.section-title:hover {
    background: #fafafa;
}

.toggle-arrow {
    font-size: 14px;
    transition: transform 0.2s;
}

.toggle-arrow.collapsed {
    transform: rotate(-90deg);
}

.toc-body {
    padding: 12px 16px;
    max-height: 400px;
    overflow-y: auto;
}

.toc-entry {
    padding: 8px 14px;
    margin-bottom: 4px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    cursor: pointer;
    transition: filter 0.15s;
}

.toc-entry:hover {
    filter: brightness(0.95);
}

.toc-num {
    font-weight: 700;
    min-width: 28px;
    color: #555;
}

.toc-rule {
    flex: 1;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 14px;
    font-weight: 500;
}

.toc-badge {
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}

/* ToC source location */
.toc-source {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 11px;
    color: #1565c0;
    background: #e3f2fd;
    padding: 2px 6px;
    border-radius: 3px;
    white-space: nowrap;
    max-width: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.toc-source-unknown {
    color: #888;
    background: #f5f5f5;
    font-style: italic;
}

/* ToC contract badges */
.toc-contracts {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
}

.toc-contract-badge {
    font-size: 10px;
    padding: 1px 6px;
    background: #f3e5f5;
    color: #7b1fa2;
    border-radius: 3px;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
}

/* Two-Pane Layout */
.two-pane {
    display: flex;
    height: calc(100vh - 60px);
    margin: 0;
    position: relative;
}

.left-pane {
    flex: 1 1 55%;
    display: flex;
    flex-direction: column;
    min-width: 400px;
    border-right: 1px solid #dee2e6;
    background: #fafbfc;
}

.pane-divider {
    width: 6px;
    background: #dee2e6;
    cursor: col-resize;
    flex-shrink: 0;
    transition: background 0.15s;
}

.pane-divider:hover, .pane-divider.active {
    background: #3498db;
}

.right-pane {
    flex: 1 1 45%;
    display: flex;
    flex-direction: column;
    min-width: 300px;
    background: white;
}

/* Navigation Toolbar */
.nav-toolbar {
    background: white;
    padding: 8px 16px;
    display: flex;
    align-items: center;
    gap: 6px;
    border-bottom: 1px solid #e0e0e0;
    position: sticky;
    top: 0;
    z-index: 20;
}

.nav-toolbar button {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    padding: 5px 12px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.15s;
    white-space: nowrap;
}

.nav-toolbar button:hover {
    background: #f1f5f9;
    border-color: #cbd5e1;
}

.nav-toolbar button:active {
    background: #d0d7de;
}

.nav-position {
    margin-left: auto;
    font-size: 13px;
    color: #666;
    font-weight: 500;
}

/* Findings Container */
.findings-container {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
}

.finding {
    background: white;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.10);
    overflow: hidden;
}

.finding-header {
    padding: 14px 18px;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.finding-header-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
}

.finding-title {
    display: flex;
    align-items: center;
    gap: 8px;
}

.finding-num {
    font-weight: 700;
    font-size: 15px;
    color: #555;
}

.finding-rule {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 15px;
    font-weight: 600;
}

.finding-family {
    font-size: 12px;
    color: #888;
}

.finding-meta {
    display: flex;
    align-items: center;
    gap: 10px;
}

.finding-badge {
    padding: 3px 12px;
    border-radius: 14px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}

.finding-source-location {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 12px;
    color: #1565c0;
    background: #e3f2fd;
    padding: 3px 8px;
    border-radius: 4px;
    margin-top: 4px;
}

.finding-body {
    padding: 16px 18px;
}

.finding-jobs {
    margin-bottom: 12px;
    font-size: 13px;
}

/* Contracts/methods bar in finding body */
.finding-contracts-bar {
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    padding: 10px 14px;
    margin-bottom: 14px;
}

.contract-entry {
    margin-bottom: 6px;
    font-size: 13px;
    line-height: 1.5;
}

.contract-entry:last-child {
    margin-bottom: 0;
}

.contract-name {
    font-weight: 600;
    color: #7b1fa2;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
}

.contract-methods {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    color: #333;
}

.job-link {
    display: inline-block;
    background: #e3f2fd;
    color: #1565c0;
    padding: 2px 8px;
    border-radius: 4px;
    text-decoration: none;
    font-size: 12px;
    margin-right: 4px;
}

.job-link:hover {
    background: #bbdefb;
}

.finding-section {
    margin-bottom: 16px;
}

.finding-section h4 {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    color: #64748b;
    padding-bottom: 6px;
    border-bottom: 1px solid #eee;
    margin-bottom: 8px;
}

.finding-section h5 {
    font-size: 14px;
    color: #333;
    margin: 10px 0 6px;
}

.section-content {
    font-size: 14px;
    line-height: 1.7;
}

.section-content p {
    margin-bottom: 8px;
}

.section-content ul, .section-content ol {
    margin: 6px 0 10px 20px;
}

.section-content li {
    margin-bottom: 4px;
}

.section-content strong {
    font-weight: 600;
}

.inline-code {
    background: #f0f2f5;
    padding: 1px 5px;
    border-radius: 3px;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 13px;
}

/* Fenced code blocks */
.code-block {
    background: #f6f8fa;
    border: 1px solid #e1e4e8;
    border-radius: 6px;
    padding: 12px 16px;
    margin: 10px 0;
    overflow-x: auto;
    font-family: 'JetBrains Mono', 'Courier New', Consolas, monospace;
    font-size: 13px;
    line-height: 1.5;
}

.code-block code {
    background: none;
    padding: 0;
    border: none;
}

/* Markdown tables */
.md-table {
    border-collapse: collapse;
    margin: 10px 0;
    font-size: 14px;
    width: 100%;
}

.md-table th, .md-table td {
    border: 1px solid #ddd;
    padding: 8px 12px;
    text-align: left;
}

.md-table th {
    background: #f6f8fa;
    font-weight: 600;
}

.md-table tr:nth-child(even) {
    background: #fafbfc;
}

/* Collapsible iteration details */
.iteration-details {
    background: #f8f9fa;
    border: 1px solid #e1e4e8;
    border-radius: 6px;
    margin: 10px 0;
    overflow: hidden;
}

.iteration-details summary {
    padding: 10px 14px;
    cursor: pointer;
    font-weight: 600;
    font-size: 14px;
    background: #f0f2f5;
    border-bottom: 1px solid #e1e4e8;
    user-select: none;
    list-style: none;
}

.iteration-details summary::-webkit-details-marker {
    display: none;
}

.iteration-details summary::before {
    content: "\\25B6";
    display: inline-block;
    margin-right: 8px;
    font-size: 10px;
    transition: transform 0.2s;
}

.iteration-details[open] summary::before {
    transform: rotate(90deg);
}

.iteration-details[open] summary {
    border-bottom: 1px solid #e1e4e8;
}

.iteration-details .details-body {
    padding: 12px 14px;
    font-size: 14px;
    line-height: 1.6;
}

.iteration-details .details-body p {
    margin-bottom: 8px;
}

.iteration-details .details-body p:last-child {
    margin-bottom: 0;
}

/* Judgement/Validation Section */
.judgement-section {
    background: #fff8e1;
    border: 1px solid #ffcc80;
    border-radius: 6px;
    padding: 4px;
    margin-top: 16px;
}

.judgement-section h4 {
    border-bottom: 1px solid #ffcc80;
}

.judgement-warning {
    color: #e65100;
    font-weight: 600;
    margin-left: 8px;
}

.judgement-result-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.judgement-verdict {
    font-size: 18px;
    font-weight: 700;
    padding: 4px 12px;
    border-radius: 4px;
}

.judgement-verdict:contains("YES") {
    background: #ffebee;
    color: #c62828;
}

.judgement-verdict:contains("NO") {
    background: #e8f5e9;
    color: #2e7d32;
}

.judgement-confidence {
    font-size: 14px;
    color: #666;
}

.judgement-scores {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 12px;
    padding-top: 12px;
    border-top: 1px dashed #ccc;
}

.score-original {
    color: #666;
    font-size: 13px;
}

.score-arrow {
    color: #888;
    font-size: 16px;
}

.score-recomputed {
    font-weight: 600;
    font-size: 13px;
    color: #333;
}

/* Impact/Likelihood Section & Badges */
.impact-section {
    background: #f3e5f5;
    border: 1px solid #ce93d8;
    border-radius: 6px;
    padding: 4px;
    margin-top: 16px;
}

.impact-section h4 {
    border-bottom: 1px solid #ce93d8;
}

.il-badges {
    display: flex;
    gap: 8px;
    margin-bottom: 8px;
    flex-wrap: wrap;
}

.il-badge {
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    white-space: nowrap;
}

.il-impact-high {
    background: #ffebee;
    color: #c62828;
    border: 1px solid #c62828;
}

.il-impact-medium {
    background: #fff3e0;
    color: #e65100;
    border: 1px solid #e65100;
}

.il-impact-low {
    background: #e8f5e9;
    color: #2e7d32;
    border: 1px solid #2e7d32;
}

.il-likelihood-high {
    background: #ffebee;
    color: #c62828;
    border: 1px solid #c62828;
}

.il-likelihood-medium {
    background: #fff3e0;
    color: #e65100;
    border: 1px solid #e65100;
}

.il-likelihood-low {
    background: #e8f5e9;
    color: #2e7d32;
    border: 1px solid #2e7d32;
}

/* Fix Section */
.fix-section {
    border: 1px solid #0066cc;
    border-radius: 6px;
    margin-top: 12px;
    overflow: hidden;
}
.fix-section summary {
    padding: 10px 14px;
    cursor: pointer;
    background: #e8f0fe;
    border-bottom: 1px solid #0066cc;
}
.fix-section summary h4 {
    margin: 0;
    color: #0066cc;
    border: none;
    padding: 0;
}
.diff-block {
    background: #1e1e1e;
    color: #d4d4d4;
    padding: 16px;
    border-radius: 4px;
    overflow-x: auto;
    font-family: 'JetBrains Mono', 'Consolas', 'Monaco', monospace;
    font-size: 13px;
    line-height: 1.5;
    white-space: pre;
    margin: 10px 0;
}
.diff-block code {
    background: none;
    padding: 0;
    border: none;
}
.patch-file-info {
    margin-top: 8px;
    font-size: 12px;
    color: #666;
}

/* File Viewer */
.file-viewer-header {
    padding: 10px 16px;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8f9fa;
}

.file-viewer-header h3 {
    font-size: 15px;
    color: #333;
}

.file-count {
    font-size: 12px;
    color: #888;
}

.file-viewer-body {
    display: flex;
    flex: 1;
    overflow: hidden;
}

.file-tree-pane {
    width: 260px;
    min-width: 180px;
    overflow-y: auto;
    overflow-x: auto;
    border-right: 1px solid #e0e0e0;
    padding: 8px;
    background: #f8f9fa;
}

.file-content-pane {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.file-content-header {
    padding: 8px 14px;
    background: #f6f8fa;
    border-bottom: 1px solid #e0e0e0;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 13px;
    font-weight: 600;
    color: #24292f;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.file-content {
    flex: 1;
    overflow: auto;
    margin: 0;
    padding: 12px 16px;
    font-family: 'JetBrains Mono', 'Courier New', Consolas, monospace;
    font-size: 13px;
    line-height: 1.5;
    background: white;
    white-space: pre;
    tab-size: 4;
    counter-reset: line;
}

.file-content .line {
    display: block;
    padding-left: 50px;
    position: relative;
    min-height: 1.5em;
}

.file-content .line::before {
    counter-increment: line;
    content: counter(line);
    position: absolute;
    left: 0;
    width: 40px;
    text-align: right;
    color: #adb5bd;
    font-size: 12px;
    user-select: none;
    padding-right: 8px;
    border-right: 1px solid #eee;
}

/* File tree */
.tree-dir {
    margin-bottom: 2px;
}

.tree-dir-label {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 3px 6px;
    cursor: pointer;
    border-radius: 3px;
    font-size: 13px;
    font-weight: 500;
    color: #495057;
    user-select: none;
}

.tree-dir-label:hover {
    background: rgba(0,0,0,0.05);
}

.tree-toggle {
    width: 14px;
    font-size: 10px;
    text-align: center;
    flex-shrink: 0;
}

.tree-children {
    padding-left: 14px;
}

.tree-children.collapsed {
    display: none;
}

.tree-file {
    padding: 3px 6px 3px 24px;
    cursor: pointer;
    border-radius: 3px;
    font-size: 13px;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    white-space: nowrap;
    color: #333;
}

.tree-file:hover {
    background: rgba(0,0,0,0.05);
}

.tree-file.selected {
    background: #e3f2fd;
    font-weight: 600;
}

/* Source links in findings */
.source-link {
    text-decoration: none;
    border-bottom: 1px dashed #1565c0;
    cursor: pointer;
}

.source-link:hover {
    background: #e3f2fd;
}

.line.highlighted {
    background: #fff3cd !important;
}

.source-methods-bar {
    padding: 8px 12px;
    background: #f8f9fa;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    align-items: center;
}

.source-methods-bar .methods-label {
    font-size: 12px;
    color: #666;
    margin-right: 4px;
}

.source-method-badge {
    font-size: 12px;
    padding: 2px 8px;
    background: #e3f2fd;
    border: 1px solid #90caf9;
    border-radius: 4px;
    cursor: pointer;
    font-family: monospace;
    color: #1565c0;
}

.source-method-badge:hover {
    background: #bbdefb;
}

/* Syntax highlighting — generated by Pygments */
"""
        + HtmlFormatter(style="default").get_style_defs(".file-content")
        + """
"""
        + HtmlFormatter(style="default").get_style_defs(".code-block")
        + """

/* Tab Bar */
.tab-bar {
    display: flex;
    gap: 0;
    background: white;
    border-bottom: 2px solid #e2e8f0;
    padding: 0 36px;
}

.tab-btn {
    padding: 10px 24px;
    border: none;
    background: transparent;
    font-size: 14px;
    font-weight: 600;
    color: #64748b;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    margin-bottom: -2px;
    transition: color 0.15s, border-color 0.15s;
    font-family: inherit;
}

.tab-btn:hover {
    color: #334155;
}

.tab-btn.active {
    color: #1565c0;
    border-bottom-color: #1565c0;
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

/* IV Summary Table */
.iv-summary-section {
    margin: 16px 20px;
    overflow-x: auto;
}

.iv-summary-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    background: white;
    border-radius: 10px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.10);
    overflow: hidden;
    font-size: 14px;
}

.iv-summary-table th {
    background: #f8fafc;
    padding: 10px 16px;
    text-align: left;
    font-weight: 600;
    color: #334155;
    border-bottom: 2px solid #e2e8f0;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.iv-summary-table td {
    padding: 10px 16px;
    border-bottom: 1px solid #f1f5f9;
    vertical-align: middle;
}

.iv-summary-table tr:hover {
    background: #f8fafc;
}

.iv-summary-table .iv-method {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-weight: 500;
    font-size: 13px;
    word-break: break-all;
    overflow-wrap: break-word;
}

.iv-summary-table .iv-param {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 13px;
    color: #555;
    word-break: break-all;
    overflow-wrap: break-word;
}

.iv-source-link {
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 12px;
    color: #1565c0;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px dashed #1565c0;
}

.iv-source-link:hover {
    background: #e3f2fd;
}

.iv-decl-block {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.iv-decl-location {
    font-size: 11px;
    color: #94a3b8;
    font-style: italic;
}

.iv-decl-code {
    display: block;
    font-family: 'JetBrains Mono', 'Courier New', monospace;
    font-size: 12px;
    color: #1e293b;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    padding: 6px 10px;
    margin: 0;
    white-space: pre-wrap;
    overflow-x: auto;
}

.iv-param-highlight {
    text-decoration: underline;
    text-decoration-color: #dc2626;
    text-underline-offset: 3px;
}

.iv-param-highlight-pass {
    text-decoration: underline;
    text-decoration-color: #16a34a;
    text-underline-offset: 3px;
}

/* Print styles */
@media print {
    .tab-bar { display: none; }
    .tab-content { display: block !important; }
    .nav-toolbar, .pane-divider { display: none; }
    .two-pane { display: block; height: auto; }
    .left-pane, .right-pane { width: 100%; min-width: auto; border: none; }
    .finding { page-break-inside: avoid; }
}
"""
    )


def _get_js(file_tree_json: str, file_contents_json: str, total_findings: int, iv_total: int = 0) -> str:
    """Return all JavaScript for the HTML report."""
    return f"""
// Data
const FILE_TREE = {file_tree_json};
const FILE_CONTENTS = {file_contents_json};
const TOTAL_FINDINGS = {total_findings};
const IV_TOTAL = {iv_total};
let currentFinding = 1;
let selectedFile = null;

// --- Tab switching ---
function switchTab(tabName) {{
    document.querySelectorAll('.tab-content').forEach(function(el) {{
        el.classList.remove('active');
    }});
    document.querySelectorAll('.tab-btn').forEach(function(el) {{
        el.classList.remove('active');
    }});
    document.getElementById('tab-' + tabName).classList.add('active');
    // Find the button by matching the tab name in onclick
    document.querySelectorAll('.tab-btn').forEach(function(btn) {{
        if (btn.getAttribute('onclick') && btn.getAttribute('onclick').indexOf(tabName) !== -1) {{
            btn.classList.add('active');
        }}
    }});
}}

// --- ToC toggle ---
function toggleToc() {{
    const body = document.getElementById('toc-body');
    const arrow = document.getElementById('toc-toggle');
    if (body.style.display === 'none') {{
        body.style.display = '';
        arrow.classList.remove('collapsed');
    }} else {{
        body.style.display = 'none';
        arrow.classList.add('collapsed');
    }}
}}

function toggleIvToc() {{
    const body = document.getElementById('iv-toc-body');
    const arrow = document.getElementById('iv-toc-toggle');
    if (body.style.display === 'none') {{
        body.style.display = '';
        arrow.classList.remove('collapsed');
    }} else {{
        body.style.display = 'none';
        arrow.classList.add('collapsed');
    }}
}}

// --- Main tab: Finding navigation ---
function scrollToFinding(n) {{
    const el = document.getElementById('finding-' + n);
    if (!el) return;
    const container = document.getElementById('findings-container');
    container.scrollTop = el.offsetTop - container.offsetTop - 10;
    currentFinding = n;
    updateNavPosition();
}}

function navTo(action) {{
    switch (action) {{
        case 'top':
            window.scrollTo(0, 0);
            currentFinding = 1;
            break;
        case 'first':
            scrollToFinding(1);
            break;
        case 'prev':
            if (currentFinding > 1) scrollToFinding(currentFinding - 1);
            break;
        case 'next':
            if (currentFinding < TOTAL_FINDINGS) scrollToFinding(currentFinding + 1);
            break;
        case 'last':
            scrollToFinding(TOTAL_FINDINGS);
            break;
    }}
    updateNavPosition();
}}

function updateNavPosition() {{
    document.getElementById('nav-position').textContent = currentFinding + ' / ' + TOTAL_FINDINGS;
}}

// --- Track visible finding on scroll (main tab) ---
(function() {{
    const container = document.getElementById('findings-container');
    if (!container) return;
    container.addEventListener('scroll', function() {{
        const containerTop = container.scrollTop;
        for (let i = TOTAL_FINDINGS; i >= 1; i--) {{
            const el = document.getElementById('finding-' + i);
            if (el && (el.offsetTop - container.offsetTop) <= containerTop + 60) {{
                if (currentFinding !== i) {{
                    currentFinding = i;
                    updateNavPosition();
                }}
                break;
            }}
        }}
    }});
}})();

// --- IV tab: Finding navigation ---
let ivCurrentFinding = 1;
let ivSelectedFile = null;

function ivScrollToFinding(n) {{
    const el = document.getElementById('iv-finding-' + n);
    if (!el) return;
    // Open the details element if closed
    if (!el.open) el.open = true;
    const container = document.getElementById('iv-findings-container');
    container.scrollTop = el.offsetTop - container.offsetTop - 10;
    ivCurrentFinding = n;
    ivUpdateNavPosition();
}}

function ivNavTo(action) {{
    switch (action) {{
        case 'top':
            window.scrollTo(0, 0);
            ivCurrentFinding = 1;
            break;
        case 'first':
            ivScrollToFinding(1);
            break;
        case 'prev':
            if (ivCurrentFinding > 1) ivScrollToFinding(ivCurrentFinding - 1);
            break;
        case 'next':
            if (ivCurrentFinding < IV_TOTAL) ivScrollToFinding(ivCurrentFinding + 1);
            break;
        case 'last':
            ivScrollToFinding(IV_TOTAL);
            break;
    }}
    ivUpdateNavPosition();
}}

function ivUpdateNavPosition() {{
    const el = document.getElementById('iv-nav-position');
    if (el) el.textContent = ivCurrentFinding + ' / ' + IV_TOTAL;
}}

// --- Track visible finding on scroll (IV tab) ---
(function() {{
    const container = document.getElementById('iv-findings-container');
    if (!container) return;
    container.addEventListener('scroll', function() {{
        const containerTop = container.scrollTop;
        for (let i = IV_TOTAL; i >= 1; i--) {{
            const el = document.getElementById('iv-finding-' + i);
            if (el && (el.offsetTop - container.offsetTop) <= containerTop + 60) {{
                if (ivCurrentFinding !== i) {{
                    ivCurrentFinding = i;
                    ivUpdateNavPosition();
                }}
                break;
            }}
        }}
    }});
}})();

// --- File tree ---
function renderTree(tree, parentEl, pathPrefix, selectFn) {{
    // Sort: directories first, then files, both alphabetically
    const keys = Object.keys(tree).sort((a, b) => {{
        const aIsDir = tree[a] !== null;
        const bIsDir = tree[b] !== null;
        if (aIsDir && !bIsDir) return -1;
        if (!aIsDir && bIsDir) return 1;
        return a.localeCompare(b);
    }});

    for (const key of keys) {{
        const fullPath = pathPrefix ? pathPrefix + '/' + key : key;
        if (tree[key] === null) {{
            // File
            const div = document.createElement('div');
            div.className = 'tree-file';
            div.textContent = key;
            div.dataset.path = fullPath;
            div.addEventListener('click', function() {{ selectFn(fullPath); }});
            parentEl.appendChild(div);
        }} else {{
            // Directory
            const dirDiv = document.createElement('div');
            dirDiv.className = 'tree-dir';

            const label = document.createElement('div');
            label.className = 'tree-dir-label';

            const toggle = document.createElement('span');
            toggle.className = 'tree-toggle';
            toggle.textContent = '\\u25BC';

            const name = document.createElement('span');
            name.textContent = key + '/';

            label.appendChild(toggle);
            label.appendChild(name);
            dirDiv.appendChild(label);

            const children = document.createElement('div');
            children.className = 'tree-children';
            renderTree(tree[key], children, fullPath, selectFn);
            dirDiv.appendChild(children);

            label.addEventListener('click', function() {{
                if (children.classList.contains('collapsed')) {{
                    children.classList.remove('collapsed');
                    toggle.textContent = '\\u25BC';
                }} else {{
                    children.classList.add('collapsed');
                    toggle.textContent = '\\u25B6';
                }}
            }});

            parentEl.appendChild(dirDiv);
        }}
    }}
}}

// --- Main tab: file selection ---
function selectFile(path) {{
    // Deselect previous in main tree
    document.querySelectorAll('#file-tree .tree-file.selected').forEach(el => el.classList.remove('selected'));

    // Select new
    const fileEl = document.querySelector('#file-tree .tree-file[data-path="' + CSS.escape(path) + '"]');
    if (fileEl) fileEl.classList.add('selected');

    selectedFile = path;

    // Update header
    document.getElementById('file-content-header').textContent = path;

    // Update content — already highlighted server-side by Pygments
    const contentEl = document.getElementById('file-content');
    const raw = FILE_CONTENTS[path];
    if (raw !== undefined) {{
        contentEl.innerHTML = raw.split('\\n').map(function(line) {{
            return '<span class="line">' + line + '</span>';
        }}).join('');
    }} else {{
        contentEl.textContent = 'File not available';
    }}
}}

function jumpToSource(file, line) {{
    selectFile(file);
    setTimeout(function() {{
        var lines = document.querySelectorAll('#file-content .line');
        if (lines[line - 1]) {{
            lines[line - 1].scrollIntoView({{behavior: 'smooth', block: 'center'}});
            document.querySelectorAll('#file-content .line.highlighted').forEach(
                function(el) {{ el.classList.remove('highlighted'); }}
            );
            lines[line - 1].classList.add('highlighted');
        }}
    }}, 100);
}}

// --- IV tab: file selection ---
function ivSelectFile(path) {{
    // Deselect previous in IV tree
    document.querySelectorAll('#iv-file-tree .tree-file.selected').forEach(el => el.classList.remove('selected'));

    // Select new
    const fileEl = document.querySelector('#iv-file-tree .tree-file[data-path="' + CSS.escape(path) + '"]');
    if (fileEl) fileEl.classList.add('selected');

    ivSelectedFile = path;

    document.getElementById('iv-file-content-header').textContent = path;

    const contentEl = document.getElementById('iv-file-content');
    const raw = FILE_CONTENTS[path];
    if (raw !== undefined) {{
        contentEl.innerHTML = raw.split('\\n').map(function(line) {{
            return '<span class="line">' + line + '</span>';
        }}).join('');
    }} else {{
        contentEl.textContent = 'File not available';
    }}
}}

function ivJumpToSource(file, line) {{
    ivSelectFile(file);
    setTimeout(function() {{
        var lines = document.querySelectorAll('#iv-file-content .line');
        if (lines[line - 1]) {{
            lines[line - 1].scrollIntoView({{behavior: 'smooth', block: 'center'}});
            document.querySelectorAll('#iv-file-content .line.highlighted').forEach(
                function(el) {{ el.classList.remove('highlighted'); }}
            );
            lines[line - 1].classList.add('highlighted');
        }}
    }}, 100);
}}

// --- Pane resize (generic) ---
function setupPaneResize(dividerId, leftPaneId, rightPaneId) {{
    const divider = document.getElementById(dividerId);
    const leftPane = document.getElementById(leftPaneId);
    const rightPane = document.getElementById(rightPaneId);
    if (!divider || !leftPane || !rightPane) return;
    let isResizing = false;

    divider.addEventListener('mousedown', function(e) {{
        isResizing = true;
        divider.classList.add('active');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        e.preventDefault();
    }});

    document.addEventListener('mousemove', function(e) {{
        if (!isResizing) return;
        const container = divider.parentElement;
        const containerRect = container.getBoundingClientRect();
        const fraction = (e.clientX - containerRect.left) / containerRect.width;
        const clamped = Math.max(0.25, Math.min(0.75, fraction));
        leftPane.style.flex = '0 0 ' + (clamped * 100) + '%';
        rightPane.style.flex = '0 0 ' + ((1 - clamped) * 100) + '%';
    }});

    document.addEventListener('mouseup', function() {{
        if (isResizing) {{
            isResizing = false;
            divider.classList.remove('active');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        }}
    }});
}}

// --- Init ---
(function() {{
    // Main tab: render file tree
    const treeEl = document.getElementById('file-tree');
    renderTree(FILE_TREE, treeEl, '', selectFile);

    // Count files
    const fileCount = Object.keys(FILE_CONTENTS).length;
    document.getElementById('file-count').textContent = fileCount + ' files';

    // Select first file by default
    const firstFile = document.querySelector('#file-tree .tree-file');
    if (firstFile) {{
        selectFile(firstFile.dataset.path);
    }}

    // Main pane resize
    setupPaneResize('pane-divider', 'left-pane', 'right-pane');

    // IV tab: render file tree (if present)
    const ivTreeEl = document.getElementById('iv-file-tree');
    if (ivTreeEl) {{
        renderTree(FILE_TREE, ivTreeEl, '', ivSelectFile);
        const ivFileCountEl = document.getElementById('iv-file-count');
        if (ivFileCountEl) ivFileCountEl.textContent = fileCount + ' files';
        // Select first file in IV tree
        const ivFirstFile = document.querySelector('#iv-file-tree .tree-file');
        if (ivFirstFile) {{
            ivSelectFile(ivFirstFile.dataset.path);
        }}
        // IV pane resize
        setupPaneResize('iv-pane-divider', 'iv-left-pane', 'iv-right-pane');
    }}

    // --- Diff syntax coloring ---
    document.querySelectorAll('.diff-block code').forEach(function(codeEl) {{
        const lines = codeEl.textContent.split('\\n');
        codeEl.innerHTML = lines.map(function(line) {{
            const escaped = line.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            if (/^\\+(?!\\+\\+)/.test(line)) {{
                return '<span style="color:#4ec94e">' + escaped + '</span>';
            }} else if (/^-(?!--)/.test(line)) {{
                return '<span style="color:#f44">' + escaped + '</span>';
            }} else if (/^@@/.test(line)) {{
                return '<span style="color:#6bf">' + escaped + '</span>';
            }} else if (/^(diff |---|\\/+\\+\\+)/.test(line)) {{
                return '<span style="color:#fff;font-weight:bold">' + escaped + '</span>';
            }}
            return escaped;
        }}).join('\\n');
    }});
}})();
"""
