"""Input Validation tab builder for the HTML report."""

from __future__ import annotations

import html
import re
from pathlib import Path

from src.generic_checkers.reporting.__main__ import AggregatedReportJSON, AggregatedReportRuleEntry, PassingReportEntry
from src.generic_checkers.reporting.html_shared import (
    FAMILY_BORDER_COLORS,
    FAMILY_COLORS,
    ReportMode,
    SourcePointer,
    _linkify_html,
    _md_to_html,
    _score_badge_html,
)
from src.generic_checkers.reporting.synthesize_analyses import _compute_voting_breakdown


def _extract_method_signature_from_spec(project_dir: Path, rule_name: str) -> str | None:
    """Parse the @method_signature comment from the spec file containing this rule."""
    spec_dir = project_dir / "certora" / "certora_input_validation_checker"
    if not spec_dir.exists():
        return None
    for spec_file in spec_dir.glob("input_validation_*.spec"):
        content = spec_file.read_text(errors="replace")
        pattern = r"/\*\*\s*@method_signature:\s*(.+?)\s*\*/\s*\n\s*rule\s+" + re.escape(rule_name) + r"\b"
        m = re.search(pattern, content)
        if m:
            return m.group(1).strip()
    return None


def _extract_method_location_from_spec(project_dir: Path, rule_name: str) -> tuple[str, int] | None:
    """Parse the @method_location comment from the spec file containing this rule.

    Returns (file_path, line_number) or None.
    """
    spec_dir = project_dir / "certora" / "certora_input_validation_checker"
    if not spec_dir.exists():
        return None
    for spec_file in spec_dir.glob("input_validation_*.spec"):
        content = spec_file.read_text(errors="replace")
        pattern = (
            r"/\*\*[^*]*(?:\*(?!/)[^*]*)*@method_location:\s*(.+?)\s*\*/\s*\n\s*rule\s+"
            + re.escape(rule_name)
            + r"\b"
        )
        m = re.search(pattern, content)
        if m:
            loc = m.group(1).strip()
            if ":" in loc:
                file_part, line_part = loc.rsplit(":", 1)
                try:
                    return file_part, int(line_part)
                except ValueError:
                    pass
    return None


def _extract_function_declaration_at(
    project_dir: Path, file_path: str, line: int
) -> tuple[str, str, int] | None:
    """Extract the Solidity function declaration at a known file and line.

    Returns (declaration_text, filepath, line_number) or None.
    """
    full_path = project_dir / file_path
    if not full_path.exists():
        return None
    try:
        lines = full_path.read_text(errors="replace").splitlines()
    except Exception:
        return None
    # line is 1-based; search from that line for 'function'
    start = max(0, line - 1)
    for i in range(start, min(len(lines), start + 3)):
        if "function" not in lines[i]:
            continue
        parts = []
        for j in range(i, min(len(lines), i + 30)):
            brace_pos = lines[j].find("{")
            if brace_pos != -1:
                parts.append(lines[j][:brace_pos].rstrip())
                break
            parts.append(lines[j])
        else:
            continue
        raw = "\n".join(parts)
        func_match = re.search(r"\bfunction\b", raw)
        if func_match:
            raw = raw[func_match.start():]
        raw_lines = raw.splitlines()
        non_empty = [ln for ln in raw_lines if ln.strip()]
        if non_empty:
            min_indent = min(len(ln) - len(ln.lstrip()) for ln in non_empty)
            raw_lines = [ln[min_indent:] if len(ln) >= min_indent else ln for ln in raw_lines]
        raw = "\n".join(raw_lines).rstrip()
        if raw:
            return raw, file_path, i + 1
    return None


def _extract_function_declaration(
    project_dir: Path, sources: dict[str, object], method_name: str
) -> tuple[str, str, int] | None:
    """Extract the Solidity function declaration for a method from source files.

    Searches .sol files listed in sources for a function matching method_name,
    then returns (declaration_text, filepath, line_number) where declaration_text
    preserves the original multi-line formatting from 'function' to the first '{'.
    """
    for filepath in sources:
        if not filepath.endswith(".sol"):
            continue
        full_path = project_dir / filepath
        if not full_path.exists():
            continue
        try:
            lines = full_path.read_text(errors="replace").splitlines()
        except Exception:
            continue
        for i, line in enumerate(lines):
            if not re.search(r"\bfunction\s+" + re.escape(method_name) + r"\b", line):
                continue
            # Found the function line — accumulate to the first '{'
            parts = []
            for j in range(i, min(len(lines), i + 30)):
                brace_pos = lines[j].find("{")
                if brace_pos != -1:
                    parts.append(lines[j][:brace_pos].rstrip())
                    break
                parts.append(lines[j])
            else:
                continue  # no '{' found within 30 lines
            raw = "\n".join(parts)
            func_match = re.search(r"\bfunction\b", raw)
            if func_match:
                raw = raw[func_match.start():]
            # Dedent: find minimum leading whitespace and strip it
            raw_lines = raw.splitlines()
            non_empty = [ln for ln in raw_lines if ln.strip()]
            if non_empty:
                min_indent = min(len(ln) - len(ln.lstrip()) for ln in non_empty)
                raw_lines = [ln[min_indent:] if len(ln) >= min_indent else ln for ln in raw_lines]
            raw = "\n".join(raw_lines).rstrip()
            if raw:
                return raw, filepath, i + 1  # 1-based line number
    return None


def _highlight_param_in_declaration(declaration: str, param_index: int, css_class: str = "iv-param-highlight") -> str:
    """Wrap the Nth parameter in the function declaration with a highlight span.

    param_index is 0-based. Finds the parameter list between the first '(' and its
    matching ')', splits by commas (respecting nested parens), and wraps the Nth
    parameter in <span class="{css_class}">.
    """
    # Find the opening paren
    open_pos = declaration.find("(")
    if open_pos == -1:
        return html.escape(declaration)

    # Find the matching closing paren
    depth = 0
    close_pos = -1
    for k in range(open_pos, len(declaration)):
        if declaration[k] == "(":
            depth += 1
        elif declaration[k] == ")":
            depth -= 1
            if depth == 0:
                close_pos = k
                break
    if close_pos == -1:
        return html.escape(declaration)

    param_str = declaration[open_pos + 1 : close_pos]

    # Split by commas at depth 0
    params: list[str] = []
    current = ""
    depth = 0
    for ch in param_str:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            params.append(current)
            current = ""
            continue
        current += ch
    params.append(current)

    if param_index < 0 or param_index >= len(params):
        return html.escape(declaration)

    # Rebuild with highlight on the target param
    highlighted_params = []
    for idx, p in enumerate(params):
        if idx == param_index:
            stripped = html.escape(p.strip())
            leading = html.escape(p[: len(p) - len(p.lstrip())])
            trailing = html.escape(p[len(p.rstrip()) :])
            escaped = f'{leading}<span class="{css_class}">{stripped}</span>{trailing}'
        else:
            escaped = html.escape(p)
        highlighted_params.append(escaped)

    before = html.escape(declaration[: open_pos + 1])
    after = html.escape(declaration[close_pos:])
    return before + ",".join(highlighted_params) + after


_IV_SUFFIX_KEYWORDS = {"field", "length", "element"}


def _format_iv_param_display(raw: str) -> str:
    """Convert encoded parameter suffix from rule name into human-readable syntax.

    The rule generator encodes: []->Array, .->_, space->_
    Suffix tokens: field_{name}->.name, index{N}->[N], length->.length, element->[*].
    """
    parts = raw.split("_")
    result = ""
    i = 0
    # Accumulate type name tokens (before first known suffix keyword)
    while i < len(parts):
        token = parts[i]
        if token in _IV_SUFFIX_KEYWORDS or re.match(r"index\d+$", token) or re.match(r"level\d+$", token):
            break
        # Handle "Array" suffix within a token (e.g. "uint256Array" or standalone "Array")
        if token.endswith("Array"):
            result += token[: -len("Array")] + "[]"
        elif token == "Array":
            result += "[]"
        else:
            result += token
        i += 1
    # Process suffix tokens
    while i < len(parts):
        token = parts[i]
        if token == "field":
            # field_{path_components...} — rest of tokens form a dot-separated field path
            field_path = ".".join(parts[i + 1 :])
            if field_path:
                result += "." + field_path
            break
        elif token == "element":
            result += "[*]"
            # element_{path_components...} — remaining tokens form field path
            field_path = ".".join(parts[i + 1 :])
            if field_path:
                result += "." + field_path
            break
        elif (m := re.match(r"index(\d+)$", token)):
            result += f"[{m.group(1)}]"
        elif token == "length":
            result += ".length"
        elif re.match(r"level\d+$", token):
            pass
        i += 1
    return result or raw


def _parse_iv_method_and_param_from_rule_name(
    rule_name: str, project_dir: Path | None = None
) -> tuple[str, str]:
    """Extract method name and parameter display from an input_validation rule name.

    Returns (method_display, param_display). Works with just a rule name — no entry needed.
    """
    method_display = ""
    if project_dir:
        sig = _extract_method_signature_from_spec(project_dir, rule_name)
        if sig:
            method_display = sig
    if not method_display:
        m = re.match(r"input_validation_(.+?)_param\d+", rule_name)
        if m:
            method_display = m.group(1)
        else:
            method_display = rule_name
    param_display = ""
    pm = re.search(r"_param\d+_(.+)$", rule_name)
    if pm:
        param_display = _format_iv_param_display(pm.group(1))
    else:
        param_display = "\u2014"
    return method_display, param_display


def _parse_iv_method_and_param(
    entry: AggregatedReportRuleEntry, project_dir: Path | None = None
) -> tuple[str, str]:
    """Extract method name and parameter description from an input_validation rule entry.

    Returns (method_display, param_display).
    """
    # Method: prefer methods_by_contract values (skip "?" placeholders)
    method_display = ""
    if entry.methods_by_contract:
        for methods in entry.methods_by_contract.values():
            for m in methods:
                if m and m != "?":
                    method_display = m
                    break
            if method_display:
                break

    if method_display:
        # Have method from entry; just need param
        pm = re.search(r"_param\d+_(.+)$", entry.rule_name)
        param_display = _format_iv_param_display(pm.group(1)) if pm else "\u2014"
        return method_display, param_display

    # Fall back to rule-name-only parsing
    return _parse_iv_method_and_param_from_rule_name(entry.rule_name, project_dir)


def _build_iv_decl_html(
    rule_name: str, method_display: str, project_dir: Path, sources: dict[str, object],
    css_class: str = "iv-param-highlight",
) -> str:
    """Build the Declaration column HTML for an IV summary row."""
    result: tuple[str, str, int] | None = None
    location = _extract_method_location_from_spec(project_dir, rule_name)
    if location:
        result = _extract_function_declaration_at(project_dir, location[0], location[1])
    if not result:
        short_name = method_display.split("(")[0] if "(" in method_display else method_display
        if short_name and short_name != rule_name:
            result = _extract_function_declaration(project_dir, sources, short_name)
    if not result:
        return "\u2014"
    decl_text, decl_file, decl_line = result
    param_match = re.search(r"_param(\d+)_", rule_name)
    if param_match:
        param_idx = int(param_match.group(1))
        decl_code = _highlight_param_in_declaration(decl_text, param_idx, css_class)
    else:
        decl_code = html.escape(decl_text)
    return (
        f'<div class="iv-decl-block">'
        f'<span class="iv-decl-location">{html.escape(decl_file)}:{decl_line}</span>'
        f'<pre class="iv-decl-code">{decl_code}</pre>'
        f"</div>"
    )


def build_iv_summary_table(
    entries: list[tuple[int, AggregatedReportRuleEntry]],
    project_dir: Path,
    sources: dict[str, object],
    passing_iv_entries: list[PassingReportEntry] | None = None,
) -> str:
    """Build the HTML summary table for input_validation entries (violated + passing).

    Args:
        entries: list of (iv_index_1based, entry) tuples for violated IV rules.
        project_dir: Path to the project root (for reading source files).
        sources: The all_sources.json content (keys are file paths).
        passing_iv_entries: passing IV rules (all checks VERIFIED).
    """
    if not entries and not passing_iv_entries:
        return '<p style="padding:20px;color:#888">No input validation findings.</p>'

    # Build unified row data for sorting
    # Each row: (has_severity, score, method_display, param_index, row_html)
    row_data: list[tuple[bool, int, str, int, str]] = []

    # Violated entries
    for iv_idx, entry in entries:
        method_display, param_display = _parse_iv_method_and_param(entry, project_dir)
        if entry.impact_likelihood:
            impact = entry.impact_likelihood.impact.lower()
            sev_html = f'<span class="il-badge il-impact-{impact}">{impact.upper()}</span>'
            has_severity = True
        else:
            sev_html = "\u2014"
            has_severity = False
        display_score = entry.synthesis.computed_confidence_score
        if entry.judgement_result:
            display_score = entry.judgement_result.recomputed_score
        decl_html = _build_iv_decl_html(entry.rule_name, method_display, project_dir, sources)
        param_match = re.search(r"_param(\d+)_", entry.rule_name)
        param_index = int(param_match.group(1)) if param_match else 0
        row_html = (
            f"<tr onclick=\"ivScrollToFinding({iv_idx})\" style=\"cursor:pointer\">"
            f'<td class="iv-method">{html.escape(method_display)}</td>'
            f'<td class="iv-param">{html.escape(param_display) if param_display != "\u2014" else param_display}</td>'
            f"<td>{sev_html}</td>"
            f"<td>{display_score}/100</td>"
            f"<td>{decl_html}</td>"
            f"</tr>"
        )
        row_data.append((has_severity, display_score, method_display, param_index, row_html))

    # Passing entries
    for pe in (passing_iv_entries or []):
        method_display, param_display = _parse_iv_method_and_param_from_rule_name(pe.rule_name, project_dir)
        decl_html = _build_iv_decl_html(pe.rule_name, method_display, project_dir, sources, "iv-param-highlight-pass")
        param_match = re.search(r"_param(\d+)_", pe.rule_name)
        param_index = int(param_match.group(1)) if param_match else 0
        row_html = (
            f"<tr>"
            f'<td class="iv-method">{html.escape(method_display)}</td>'
            f'<td class="iv-param">{html.escape(param_display) if param_display != "\u2014" else param_display}</td>'
            f"<td>\u2014</td>"
            f"<td>\u2014</td>"
            f"<td>{decl_html}</td>"
            f"</tr>"
        )
        row_data.append((False, -1, method_display, param_index, row_html))

    # Sort: severity first (by score desc), then by method name + param index
    row_data.sort(key=lambda r: (
        0 if r[0] else 1,
        -r[1],
        r[2].lower(),
        r[3],
    ))

    rows_html = "\n".join(r[4] for r in row_data)
    return (
        '<table class="iv-summary-table">'
        "<colgroup>"
        '<col style="width:15%">'
        '<col style="width:15%">'
        '<col style="width:10%">'
        '<col style="width:8%">'
        '<col style="width:52%">'
        "</colgroup>"
        "<thead><tr>"
        "<th>Method</th><th>Parameter</th><th>Impact</th><th>Score</th><th>Declaration</th>"
        "</tr></thead>"
        "<tbody>" + rows_html + "</tbody>"
        "</table>"
    )


def build_iv_findings_html(
    report: AggregatedReportJSON,
    family_colors: dict[str, int],
    source_pointers: dict[str, dict[str, SourcePointer]] | None,
    top_level_methods: dict[str, list[tuple[str, SourcePointer]]] | None,
    report_mode: ReportMode,
) -> tuple[str, str, int, list[tuple[int, AggregatedReportRuleEntry]]]:
    """Build findings HTML for input_validation entries only.

    Returns (findings_html, toc_html, iv_count, iv_entries_indexed).
    iv_entries_indexed is list of (1-based IV index, entry) for the summary table.
    """
    iv_entries = [(i, e) for i, e in enumerate(report.entries, 1) if e.rule_family == "input_validation"]
    iv_count = len(iv_entries)

    toc_parts: list[str] = []
    findings_parts: list[str] = []
    iv_entries_indexed: list[tuple[int, AggregatedReportRuleEntry]] = []

    for j, (_orig_idx, entry) in enumerate(iv_entries, 1):
        iv_entries_indexed.append((j, entry))
        fidx = family_colors.get(entry.rule_family, 0)
        bg = FAMILY_COLORS[fidx]
        border = FAMILY_BORDER_COLORS[fidx]

        display_score = entry.synthesis.computed_confidence_score
        if entry.judgement_result:
            display_score = entry.judgement_result.recomputed_score

        # ToC entry
        il_toc_html = ""
        if entry.impact_likelihood:
            il = entry.impact_likelihood
            il_toc_html = (
                f'<span class="il-badge il-impact-{il.impact}">Impact: {il.impact.upper()}</span>'
                f'<span class="il-badge il-likelihood-{il.likelihood}">Likelihood: {il.likelihood.upper()}</span>'
            )

        source_html = ""
        if entry.source_location:
            source_html = f'<span class="toc-source">{html.escape(entry.source_location)}</span>'

        toc_parts.append(
            f'<div class="toc-entry" style="background:{bg};border-left:4px solid {border}" '
            f'onclick="ivScrollToFinding({j})">'
            f'<span class="toc-num">{j}.</span>'
            f'<span class="toc-rule">{html.escape(entry.rule_name)}</span>'
            f"{source_html}"
            f"{_score_badge_html(display_score, 'toc-badge')}"
            f"{il_toc_html}"
            f"</div>"
        )

        # Finding body — reuse the same rendering logic as main, but lighter
        syn = entry.synthesis
        method_map = (source_pointers or {}).get(entry.rule_name, {})
        evidence_html = _md_to_html(syn.evidence_synthesis)
        if method_map:
            evidence_html = _linkify_html(evidence_html, method_map)

        is_single = getattr(syn, "is_single_iteration", False)

        if is_single:
            sections_html = f"""
            <div class="finding-section">
                <h4>ANALYSIS</h4>
                <div class="section-content">{evidence_html}</div>
            </div>"""
        else:
            if entry.vote_counts:
                voting_html = _md_to_html(_compute_voting_breakdown(*entry.vote_counts))
            else:
                voting_html = "<em>Vote counts unavailable</em>"
            reasoning_html = _md_to_html(syn.consolidated_reasoning)
            action_html = _md_to_html(syn.recommended_action)
            if method_map:
                voting_html = _linkify_html(voting_html, method_map)
                reasoning_html = _linkify_html(reasoning_html, method_map)
                action_html = _linkify_html(action_html, method_map)

            if report_mode is ReportMode.PRESENTABLE:
                sections_html = f"""
                <div class="finding-section">
                    <h4>SUMMARY</h4>
                    <div class="section-content">{reasoning_html}</div>
                </div>
                <div class="finding-section">
                    <h4>RECOMMENDED ACTION</h4>
                    <div class="section-content">{action_html}</div>
                </div>
                <details class="finding-section">
                    <summary><h4 style="display:inline">DETAILED ANALYSIS</h4></summary>
                    <div class="section-content">{evidence_html}</div>
                </details>"""
            else:
                sections_html = f"""
                <div class="finding-section">
                    <h4>VOTING BREAKDOWN</h4>
                    <div class="section-content">{voting_html}</div>
                </div>
                <div class="finding-section">
                    <h4>EVIDENCE SYNTHESIS</h4>
                    <div class="section-content">{evidence_html}</div>
                </div>
                <div class="finding-section">
                    <h4>CONSOLIDATED REASONING</h4>
                    <div class="section-content">{reasoning_html}</div>
                </div>
                <div class="finding-section">
                    <h4>RECOMMENDED ACTION</h4>
                    <div class="section-content">{action_html}</div>
                </div>"""

        # Contracts bar
        contracts_bar_html = ""
        if entry.methods_by_contract:
            contract_entries = []
            for contract, methods in entry.methods_by_contract.items():
                job_url = entry.job_url_by_contract.get(contract, "")
                job_link = (
                    f' <a href="{html.escape(job_url)}" target="_blank" class="job-link">Job</a>' if job_url else ""
                )
                methods_str = ", ".join(html.escape(m) for m in methods)
                contract_entries.append(
                    f'<div class="contract-entry">'
                    f'<span class="contract-name">{html.escape(contract)}</span>: '
                    f'<span class="contract-methods">{methods_str}</span>'
                    f"{job_link}"
                    f"</div>"
                )
            contracts_bar_html = '<div class="finding-contracts-bar">' + "".join(contract_entries) + "</div>"

        # Methods bar
        methods_bar_html = ""
        rule_methods = (top_level_methods or {}).get(entry.rule_name, [])
        if rule_methods:
            badges = []
            for mname, ptr in rule_methods:
                escaped_file = html.escape(ptr["file"]).replace("'", "\\'")
                display = f'{html.escape(ptr["contract"])}.{html.escape(mname)}'
                badges.append(
                    f'<span class="source-method-badge" '
                    f"onclick=\"ivJumpToSource('{escaped_file}',{ptr['line']})\">"
                    f"{display}</span>"
                )
            methods_bar_html = (
                '<div class="source-methods-bar">'
                '<span class="methods-label">Referenced Methods:</span>' + "".join(badges) + "</div>"
            )

        # Impact/likelihood header badges
        il_header_html = ""
        if entry.impact_likelihood:
            il = entry.impact_likelihood
            il_header_html = (
                f'<span class="il-badge il-impact-{il.impact}">Impact: {il.impact.upper()}</span>'
                f'<span class="il-badge il-likelihood-{il.likelihood}">Likelihood: {il.likelihood.upper()}</span>'
            )

        source_loc_html = ""
        if entry.source_location:
            source_loc_html = f'<div class="finding-source-location">{html.escape(entry.source_location)}</div>'

        # Fix section
        fix_section_html = ""
        if entry.fix_result:
            fr = entry.fix_result
            patch_escaped = html.escape(fr.patch_content)
            fix_section_html = f"""
            <details class="finding-section fix-section" open>
                <summary><h4 style="display:inline">SUGGESTED FIX</h4></summary>
                <div class="section-content">
                    <p>{html.escape(fr.explanation)}</p>
                    <pre class="diff-block"><code>{patch_escaped}</code></pre>
                    <div class="patch-file-info">Patch file: <code>{html.escape(fr.patch_file)}</code></div>
                </div>
            </details>"""

        # Wrap finding in <details> (collapsed by default)
        findings_parts.append(
            f'<details class="finding" id="iv-finding-{j}" style="border-left:4px solid {border}">'
            f'<summary class="finding-header" style="background:{bg}">'
            f'<div class="finding-header-row">'
            f'<div class="finding-title">'
            f'<span class="finding-num">#{j}</span>'
            f'<span class="finding-rule">{html.escape(entry.rule_name)}</span>'
            f'<span class="finding-family">({html.escape(entry.rule_family)})</span>'
            f"</div>"
            f'<div class="finding-meta">'
            f"{_score_badge_html(display_score, 'finding-badge')}"
            f"{il_header_html}"
            f"</div>"
            f"</div>"
            f"{source_loc_html}"
            f"</summary>"
            f'<div class="finding-body">'
            f"{contracts_bar_html}"
            f"{methods_bar_html}"
            f"{sections_html}"
            f"{fix_section_html}"
            f"</div>"
            f"</details>"
        )

    return "\n".join(findings_parts), "\n".join(toc_parts), iv_count, iv_entries_indexed
