"""Main findings tab builder for the HTML report."""

from __future__ import annotations

import html

from src.generic_checkers.reporting.html_shared import (
    FAMILY_COLORS,
    FAMILY_BORDER_COLORS,
    CLASSIFICATION_BADGES,
    ReportMode,
    SourcePointer,
    _score_badge_html,
    _md_to_html,
    _linkify_html,
)
from src.generic_checkers.reporting.__main__ import AggregatedReportJSON, AggregatedReportRuleEntry
from src.generic_checkers.reporting.synthesize_analyses import _compute_voting_breakdown


def build_main_toc_html(
    report: AggregatedReportJSON,
    family_colors: dict[str, int],
    report_mode: ReportMode,
) -> str:
    """Build the Table of Contents HTML for the main findings tab."""
    toc_entries = []
    for i, entry in enumerate(report.entries, 1):
        fidx = family_colors.get(entry.rule_family, 0)
        bg = FAMILY_COLORS[fidx]
        border = FAMILY_BORDER_COLORS[fidx]

        # Source location display
        source_loc = entry.source_location if entry.source_location else ""
        source_html = ""
        if source_loc:
            source_html = f'<span class="toc-source">{html.escape(source_loc)}</span>'

        # Contract badges
        contracts_html = ""
        if entry.contracts:
            contract_badges = " ".join(
                f'<span class="toc-contract-badge">{html.escape(c)}</span>' for c in entry.contracts
            )
            contracts_html = f'<span class="toc-contracts">{contract_badges}</span>'

        # Use recomputed score for display when judgement exists
        display_score = entry.synthesis.computed_confidence_score
        if entry.judgement_result:
            display_score = entry.judgement_result.recomputed_score

        # Impact/likelihood badges for ToC
        il_toc_html = ""
        if entry.impact_likelihood:
            il = entry.impact_likelihood
            il_toc_html = (
                f'<span class="il-badge il-impact-{il.impact}">Impact: {il.impact.upper()}</span>'
                f'<span class="il-badge il-likelihood-{il.likelihood}">Likelihood: {il.likelihood.upper()}</span>'
            )

        toc_entries.append(
            f'<div class="toc-entry" style="background:{bg};border-left:4px solid {border}" '
            f'onclick="scrollToFinding({i})">'
            f'<span class="toc-num">{i}.</span>'
            f'<span class="toc-rule">{html.escape(entry.rule_name)}</span>'
            f"{source_html}"
            f"{contracts_html}"
            f"{_score_badge_html(display_score, 'toc-badge')}"
            f"{il_toc_html}"
            f"</div>"
        )
    toc_html = "\n".join(toc_entries)
    return toc_html


def build_main_findings_html(
    report: AggregatedReportJSON,
    family_colors: dict[str, int],
    source_pointers: dict[str, dict[str, SourcePointer]] | None,
    top_level_methods: dict[str, list[tuple[str, SourcePointer]]] | None,
    report_mode: ReportMode,
) -> str:
    """Build the findings HTML for the main findings tab."""
    findings_html_parts = []
    for i, entry in enumerate(report.entries, 1):
        fidx = family_colors.get(entry.rule_family, 0)
        bg = FAMILY_COLORS[fidx]
        border = FAMILY_BORDER_COLORS[fidx]
        confidence = entry.synthesis.computed_confidence_score

        # Render the synthesis sections
        syn = entry.synthesis
        method_map = (source_pointers or {}).get(entry.rule_name, {})

        evidence_html = _md_to_html(syn.evidence_synthesis)
        if method_map:
            evidence_html = _linkify_html(evidence_html, method_map)

        # Check if this is a single-iteration result
        is_single = getattr(syn, "is_single_iteration", False)

        if is_single:
            # Single analysis: just show the analysis content (stored in evidence_synthesis)
            sections_html = f"""
            <div class="finding-section">
                <h4>ANALYSIS</h4>
                <div class="section-content">{evidence_html}</div>
            </div>
            """
        else:
            # Multi-analysis: show all synthesis sections
            if entry.vote_counts:
                voting_html = _md_to_html(_compute_voting_breakdown(*entry.vote_counts))
            else:
                voting_html = "<em>Vote counts unavailable</em>"
            reasoning_html = _md_to_html(syn.consolidated_reasoning)
            action_html = _md_to_html(syn.recommended_action)

            if method_map:
                voting_html = _linkify_html(voting_html, method_map)
                reasoning_html = _linkify_html(reasoning_html, method_map)
                action_html = _linkify_html(action_html, method_map)

            if report_mode is ReportMode.PRESENTABLE:
                # Presentable: SUMMARY → RECOMMENDED ACTION → (fix inserted later) → collapsed DETAILED ANALYSIS
                sections_html = f"""
                <div class="finding-section">
                    <h4>SUMMARY</h4>
                    <div class="section-content">{reasoning_html}</div>
                </div>
                <div class="finding-section">
                    <h4>RECOMMENDED ACTION</h4>
                    <div class="section-content">{action_html}</div>
                </div>
                """
                sections_html += f"""
                <details class="finding-section">
                    <summary><h4 style="display:inline">DETAILED ANALYSIS</h4></summary>
                    <div class="section-content">{evidence_html}</div>
                </details>
                """
            else:
                sections_html = f"""
                <div class="finding-section">
                    <h4>VOTING BREAKDOWN</h4>
                    <div class="section-content">{voting_html}</div>
                </div>
                <div class="finding-section">
                    <h4>EVIDENCE SYNTHESIS</h4>
                    <div class="section-content">{evidence_html}</div>
                </div>
                <div class="finding-section">
                    <h4>CONSOLIDATED REASONING</h4>
                    <div class="section-content">{reasoning_html}</div>
                </div>
                <div class="finding-section">
                    <h4>RECOMMENDED ACTION</h4>
                    <div class="section-content">{action_html}</div>
                </div>
                """

        # Build "Referenced Methods" bar for rules with top-level methods (from calltrace)
        methods_bar_html = ""
        rule_methods = (top_level_methods or {}).get(entry.rule_name, [])
        if rule_methods:
            badges = []
            for mname, ptr in rule_methods:
                escaped_file = html.escape(ptr["file"]).replace("'", "\\'")
                display = f'{html.escape(ptr["contract"])}.{html.escape(mname)}'
                badges.append(
                    f'<span class="source-method-badge" '
                    f"onclick=\"jumpToSource('{escaped_file}',{ptr['line']})\">"
                    f"{display}</span>"
                )
            methods_bar_html = (
                '<div class="source-methods-bar">'
                '<span class="methods-label">Referenced Methods:</span>' + "".join(badges) + "</div>"
            )

        # Build contracts/methods bar from entry metadata (new field)
        contracts_bar_html = ""
        if entry.methods_by_contract:
            contract_entries = []
            for contract, methods in entry.methods_by_contract.items():
                job_url = entry.job_url_by_contract.get(contract, "")
                job_link = (
                    f' <a href="{html.escape(job_url)}" target="_blank" class="job-link">Job</a>' if job_url else ""
                )
                methods_str = ", ".join(html.escape(m) for m in methods)
                contract_entries.append(
                    f'<div class="contract-entry">'
                    f'<span class="contract-name">{html.escape(contract)}</span>: '
                    f'<span class="contract-methods">{methods_str}</span>'
                    f"{job_link}"
                    f"</div>"
                )
            contracts_bar_html = '<div class="finding-contracts-bar">' + "".join(contract_entries) + "</div>"

        job_urls_html = ""
        if entry.job_urls:
            links = " ".join(
                f'<a href="{html.escape(u)}" target="_blank" class="job-link">Job</a>' for u in entry.job_urls
            )
            job_urls_html = f'<div class="finding-jobs">Jobs: {links}</div>'

        # Judgement result section (for high-confidence findings that went through validation)
        # Skipped in presentable mode — too detailed for client-facing reports
        judgement_html = ""
        if entry.judgement_result and report_mode is not ReportMode.PRESENTABLE:
            jr = entry.judgement_result
            change_marker = (
                ' <span class="judgement-warning">⚠️ Classification Changed</span>' if jr.classification_changed else ""
            )
            original_score = confidence
            original_class = entry.synthesis.computed_classification

            judgement_html = f"""
            <div class="finding-section judgement-section">
                <h4>JUDGE VALIDATION (2× weight){change_marker}</h4>
                <div class="section-content">
                    <div class="judgement-result-row">
                        <span class="judgement-verdict">{jr.is_defect}</span>
                        <span class="judgement-confidence">({jr.confidence} confidence)</span>
                    </div>
                    <p><strong>Reasoning:</strong> {html.escape(jr.reasoning)}</p>
                    <div class="judgement-scores">
                        <span class="score-original">Original: {original_class} ({original_score}/100)</span>
                        <span class="score-arrow">→</span>
                        <span class="score-recomputed">Recomputed: {jr.recomputed_classification} ({jr.recomputed_score}/100)</span>
                    </div>
                </div>
            </div>
            """

        # Impact/likelihood section
        il_section_html = ""
        if entry.impact_likelihood:
            il = entry.impact_likelihood
            il_section_html = f"""
            <div class="finding-section impact-section">
                <h4>IMPACT & LIKELIHOOD</h4>
                <div class="section-content">
                    <div class="il-badges">
                        <span class="il-badge il-impact-{il.impact}">Impact: {il.impact.upper()}</span>
                        <span class="il-badge il-likelihood-{il.likelihood}">Likelihood: {il.likelihood.upper()}</span>
                    </div>
                    <p>{html.escape(il.reasoning)}</p>
                </div>
            </div>
            """

        # Fix section
        fix_section_html = ""
        if entry.fix_result:
            fr = entry.fix_result
            patch_escaped = html.escape(fr.patch_content)
            fix_section_html = f"""
            <details class="finding-section fix-section" open>
                <summary><h4 style="display:inline">SUGGESTED FIX</h4></summary>
                <div class="section-content">
                    <p>{html.escape(fr.explanation)}</p>
                    <pre class="diff-block"><code>{patch_escaped}</code></pre>
                    <div class="patch-file-info">Patch file: <code>{html.escape(fr.patch_file)}</code></div>
                </div>
            </details>
            """

        # Impact/likelihood badges for finding header
        il_header_html = ""
        if entry.impact_likelihood:
            il = entry.impact_likelihood
            il_header_html = (
                f'<span class="il-badge il-impact-{il.impact}">Impact: {il.impact.upper()}</span>'
                f'<span class="il-badge il-likelihood-{il.likelihood}">Likelihood: {il.likelihood.upper()}</span>'
            )

        # Source location display for finding header
        source_loc_html = ""
        if entry.source_location:
            source_loc_html = f'<div class="finding-source-location">{html.escape(entry.source_location)}</div>'

        # Use recomputed score for display when judgement exists
        finding_display_score = confidence
        if entry.judgement_result:
            finding_display_score = entry.judgement_result.recomputed_score

        findings_html_parts.append(
            f'<div class="finding" id="finding-{i}" style="border-left:4px solid {border}">'
            f'<div class="finding-header" style="background:{bg}">'
            f'<div class="finding-header-row">'
            f'<div class="finding-title">'
            f'<span class="finding-num">#{i}</span>'
            f'<span class="finding-rule">{html.escape(entry.rule_name)}</span>'
            f'<span class="finding-family">({html.escape(entry.rule_family)})</span>'
            f"</div>"
            f'<div class="finding-meta">'
            f"{_score_badge_html(finding_display_score, 'finding-badge')}"
            f"{il_header_html}"
            f"</div>"
            f"</div>"
            f"{source_loc_html}"
            f"</div>"
            f'<div class="finding-body">'
            f"{job_urls_html}"
            f"{contracts_bar_html}"
            f"{methods_bar_html}"
            f"{sections_html}"
            f"{judgement_html}"
            f"{il_section_html}"
            f"{fix_section_html}"
            f"</div>"
            f"</div>"
        )
    findings_html = "\n".join(findings_html_parts)
    return findings_html
