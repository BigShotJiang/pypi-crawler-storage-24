"""
Main processor for checker outputs.

Orchestrates the full pipeline from prover URL to structured findings.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]
from src.utils.logger import logger

from .analyzer import AIViolationAnalyzer
from .base.checker_type import CheckerType
from .base.interfaces import RuleMatcher
from .checkers import get_all_matchers
from .extractors import CalltraceResult, JobDataExtractor, SourceMapExtractor, TraceExtractor
from .grouping_strategy import (
    CalltraceSourceExtractor,
    GroupingCategory,
    GroupingStrategyFactory,
    SourceLocationExtractionError,
    get_grouping_category,
    get_hook_type,
)


@dataclass(frozen=True)
class RuleSourceKey:
    """Identifies a unique finding by rule name and grouping key.

    For Category 1 rules (default): source_location is "method:<method_name>"
    For Category 2 rules: source_location is "file.sol:line-line"

    Used as an aggregation key to create separate report entries.
    """
    rule_name: str
    source_location: str  # e.g., "contracts/Token.sol:42-45", "method:transfer", or "<unknown>:0-0"

    def __hash__(self) -> int:
        return hash((self.rule_name, self.source_location))

    @property
    def is_unknown_location(self) -> bool:
        """True if this key has no meaningful location information."""
        return (
            not self.source_location
            or self.source_location.startswith("<unknown>")
            or self.source_location == "method:<unknown>"
        )

    @property
    def is_method_based(self) -> bool:
        """True if this is a Category 1 (method-based) grouping key."""
        return self.source_location.startswith("method:")

    @property
    def method_name(self) -> Optional[str]:
        """Extract method name for Category 1 keys, None otherwise."""
        if self.is_method_based:
            return self.source_location[7:]  # Strip "method:" prefix
        return None


@dataclass
class GroupedViolationData:
    """Pre-grouped violation data for a single finding.

    Contains all the data needed to run analysis for this specific group,
    avoiding the need to re-fetch and re-filter later.
    """
    checks: List[CheckResult]           # Checks in this group
    calltraces: List[CalltraceResult]   # Calltraces with XML and locations for these checks
    job_url: str                        # Job URL (for caching)
    rule_name: str                      # Rule name
    source_location: str                # Source location key (e.g., "method:transfer")
    precomputed_snippets: Optional[str] = None  # Cached code snippets from pre-scan (Step 1.5)
    checker_type: Optional[CheckerType] = None  # Set for autocvl jobs to thread through to template resolution


@dataclass(frozen=True)
class PassingInstance:
    """A single verified (rule, method) pair."""
    rule_name: str
    method_name: str
    contract_name: str = ""

    def __hash__(self) -> int:
        return hash((self.rule_name, self.method_name, self.contract_name))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, PassingInstance):
            return False
        return (
            self.rule_name == other.rule_name
            and self.method_name == other.method_name
            and self.contract_name == other.contract_name
        )


@dataclass
class JobPassingData:
    """Passing data collected from a single prover job.

    job_url: the prover job URL this data came from.
    passing_rules: rules where ALL checks are VERIFIED (existing behavior).
        Maps checker_type -> set of rule names.
    passing_instances: individual verified (rule, method) pairs for RULE_METHOD rules,
        including methods that pass within partially-violated rules.
        Maps checker_type -> set of PassingInstance.
    """
    job_url: str = ""
    passing_rules: Dict[str, Set[str]] = field(default_factory=dict)
    passing_instances: Dict[str, Set[PassingInstance]] = field(default_factory=dict)


@dataclass
class JobUnmatchedData:
    """Rules from a job that didn't match any checker matcher.

    These rules exist in the prover output but are not recognized by any
    of the registered RuleMatchers, so they are neither analyzed nor
    tracked as passing.
    """
    job_url: str = ""
    unmatched_rules: List[str] = field(default_factory=list)


@dataclass
class DetectedChecker:
    """Information about a detected checker in the job."""
    checker_type: CheckerType
    rule_names: List[str]
    violated_rule_names: List[str]
    total_checks: int
    violated_checks: int
    # Map violated rule name -> list of source location keys
    source_locations_by_rule: Dict[str, List[str]] = field(default_factory=dict)

    @property
    def has_violations(self) -> bool:
        return self.violated_checks > 0


@dataclass
class JobAnalysis:
    """Analysis of what checkers are present in a job."""
    job_url: str
    job_id: str
    detected_checkers: List[DetectedChecker] = field(default_factory=list)
    unmatched_rules: List[str] = field(default_factory=list)

    @property
    def checker_types_present(self) -> List[CheckerType]:
        """List of checker types that have rules in this job."""
        return [dc.checker_type for dc in self.detected_checkers]

    @property
    def checker_types_with_violations(self) -> List[CheckerType]:
        """List of checker types that have violations in this job."""
        return [dc.checker_type for dc in self.detected_checkers if dc.has_violations]


class CheckerOutputProcessor:
    """
    Main processor for checker outputs.

    Orchestrates the full pipeline from prover URL to structured findings.
    Auto-detects which checker rules are present in the job.
    """

    def __init__(
        self,
        job_url: str,
        extracted_dir: Optional[Path] = None,
        debug_recorder=None,
        skip_ai: bool = False,
        use_cache: bool = True,
        use_retry: bool = True,
        rule_filter: Optional[str] = None,
        method_filter: Optional[str] = None,
        iteration_index: Optional[int] = None,
        ext_logger=None,
        progress=None,
    ):
        """
        Initialize the checker output processor.

        Args:
            job_url: Prover job URL
            extracted_dir: Optional pre-extracted report directory
            debug_recorder: Optional debug recorder for crash dumps
            skip_ai: Skip AI analysis entirely (use placeholders)
            use_cache: Enable caching of AI analysis results
            use_retry: Enable retry logic for AI API calls
            rule_filter: Optional rule name filter for multi-analysis (process only this rule)
            method_filter: Optional method name filter for multi-analysis (process only this method)
            iteration_index: Optional iteration index for multi-analysis (included in cache key)
            progress: Optional tqdm progress bar for logging via tqdm.write()
        """
        self.job_url = job_url
        self.debug_recorder = debug_recorder
        self.skip_ai = skip_ai
        self.rule_filter = rule_filter
        self.method_filter = method_filter

        self.data_extractor = JobDataExtractor(job_url)
        self.source_map_extractor = SourceMapExtractor(self.data_extractor.api)
        self.trace_extractor = TraceExtractor(self.data_extractor.api, job_url, debug_recorder=debug_recorder)
        self.grouping_factory = GroupingStrategyFactory(self.trace_extractor)

        # Initialize AI analyzer with cache and retry settings
        self.ai_analyzer = AIViolationAnalyzer(
            job_url=job_url,
            extracted_dir=extracted_dir,
            debug_recorder=debug_recorder,
            use_cache=use_cache,
            use_retry=use_retry,
            iteration_index=iteration_index,
            ext_logger=ext_logger,
            progress=progress,
        )

        self.matchers: List[RuleMatcher] = get_all_matchers()
        self._job_analysis: Optional[JobAnalysis] = None

    def analyze_job(self) -> JobAnalysis:
        """
        Analyze the job to detect which checkers are present.

        Returns a JobAnalysis with information about detected checkers.
        """
        if self._job_analysis is not None:
            return self._job_analysis

        all_checks = self.data_extractor.get_all_checks()
        violated_checks = self.data_extractor.get_violated_checks()

        # Build sets of rule names
        all_rule_names: Set[str] = {c.rule_name for c in all_checks}
        violated_rule_names: Set[str] = {c.rule_name for c in violated_checks}

        # Track which rules have been matched
        matched_rules: Set[str] = set()
        detected_checkers: List[DetectedChecker] = []

        for matcher in self.matchers:
            # Find rules that match this checker
            matching_rules = [r for r in all_rule_names if matcher.matches(r)]
            if not matching_rules:
                continue

            matching_violated = [r for r in matching_rules if r in violated_rule_names]
            matched_rules.update(matching_rules)

            # Count checks for this checker
            total = sum(1 for c in all_checks if c.rule_name in matching_rules)
            violated = sum(1 for c in violated_checks if c.rule_name in matching_rules)

            # Extract source locations for each violated rule
            source_locations_by_rule: Dict[str, List[str]] = {}
            for rule in matching_violated:
                locs: Set[str] = set()
                category = get_grouping_category(rule)
                hook_type = get_hook_type(rule)

                for check in violated_checks:
                    if check.rule_name == rule:
                        if category == GroupingCategory.SOURCE_LOCATION and hook_type is not None:
                            # Category 2: extract from calltrace to get Solidity location
                            try:
                                calltrace_extractor = CalltraceSourceExtractor(
                                    self.trace_extractor
                                )
                                loc = calltrace_extractor.extract_hook_source_location(
                                    check, hook_type, rule
                                )
                                locs.add(loc.location_key)
                            except SourceLocationExtractionError as e:
                                logger.warning(f"Failed to extract calltrace location for {rule}: {e}")
                                # Fall back to source_map_extractor
                                loc = self.source_map_extractor.extract_source_location(check)
                                if loc:
                                    locs.add(loc.location_key)
                        else:
                            # Category 1 or 3: use source_map_extractor
                            loc = self.source_map_extractor.extract_source_location(check)
                            if loc:
                                locs.add(loc.location_key)

                source_locations_by_rule[rule] = sorted(locs) if locs else ["<unknown>:0-0"]

            detected_checkers.append(DetectedChecker(
                checker_type=matcher.checker_type,
                rule_names=sorted(matching_rules),
                violated_rule_names=sorted(matching_violated),
                total_checks=total,
                violated_checks=violated,
                source_locations_by_rule=source_locations_by_rule,
            ))

        # Find unmatched rules
        unmatched = sorted(all_rule_names - matched_rules)

        self._job_analysis = JobAnalysis(
            job_url=self.job_url,
            job_id=self.data_extractor.job_id,
            detected_checkers=detected_checkers,
            unmatched_rules=unmatched
        )

        return self._job_analysis

    def get_detected_checker_types(self) -> List[CheckerType]:
        """Get list of checker types that have rules in this job."""
        return self.analyze_job().checker_types_present

    def get_checker_types_with_violations(self) -> List[CheckerType]:
        """Get list of checker types that have violations in this job."""
        return self.analyze_job().checker_types_with_violations

    def get_matching_rule_names(self, checker_type: CheckerType | str) -> List[str]:
        """Get all rule names that match a specific checker type."""
        analysis = self.analyze_job()
        for dc in analysis.detected_checkers:
            if dc.checker_type == checker_type:
                return dc.rule_names
        return []

    def get_violated_rule_names(self, checker_type: CheckerType | str) -> List[str]:
        """Get violated rule names for a specific checker type."""
        analysis = self.analyze_job()
        for dc in analysis.detected_checkers:
            if dc.checker_type == checker_type:
                return dc.violated_rule_names
        return []

    def identify_checker_type(self, rule_name: str) -> Optional[CheckerType]:
        """Identify which checker type a rule belongs to."""
        for matcher in self.matchers:
            if matcher.matches(rule_name):
                return matcher.checker_type
        return None
