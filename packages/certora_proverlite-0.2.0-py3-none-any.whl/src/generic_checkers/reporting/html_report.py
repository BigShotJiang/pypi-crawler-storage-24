"""
HTML report renderer for aggregated multi-analysis reports.

Produces a self-contained HTML file with:
- Executive summary header with project metadata and findings breakdown
- Table of contents sorted by severity, color-coded by rule family
- Two-pane layout:
  - Left: findings with navigation toolbar (top, first, prev, next, last)
  - Right: file viewer with folder tree from all_sources.json
"""

from __future__ import annotations

import html
from pathlib import Path

from src.generic_checkers.reporting.__main__ import AggregatedReportJSON
from src.generic_checkers.reporting.html_iv_tab import build_iv_findings_html, build_iv_summary_table
from src.generic_checkers.reporting.html_main_tab import build_main_findings_html, build_main_toc_html
from src.generic_checkers.reporting.html_shared import (
    ReportMode,
    SourcePointer,
    _CERTORA_FAVICON_SVG,
    _CERTORA_LOGO_SVG,
    _NON_PROJECT_PREFIXES,
    _assign_family_colors,
    _build_file_tree_json,
    _get_css,
    _get_js,
    _read_sources_content,
    _walk_calltrace_for_sources,
)

# Re-export public API so external callers don't need to change their imports.
__all__ = [
    "ReportMode",
    "SourcePointer",
    "_NON_PROJECT_PREFIXES",
    "_walk_calltrace_for_sources",
    "render_aggregated_html",
]


def render_aggregated_html(
    report: AggregatedReportJSON,
    sources: dict[str, object],
    project_dir: Path,
    project_name: str = "",
    source_pointers: dict[str, dict[str, SourcePointer]] | None = None,
    top_level_methods: dict[str, list[tuple[str, SourcePointer]]] | None = None,
    contract_name: str = "",
    report_mode: ReportMode = ReportMode.VERBOSE,
) -> str:
    """Render an AggregatedReportJSON to a self-contained HTML report.

    Args:
        report: The aggregated report data.
        sources: The all_sources.json content (keys are file paths).
        project_dir: Path to the project root (for reading source files).
        project_name: Display name for the project.
        report_mode: VERBOSE for full details (VERBOSE in title), PRESENTABLE for cleaner output.
        source_pointers: rule_name → {method_name → SourcePointer} for clickable method links.
        top_level_methods: rule_name → [(method_name, SourcePointer)] for method badge bar.
    """
    family_colors = _assign_family_colors(report)
    file_tree_json = _build_file_tree_json(sources)
    file_contents_json = _read_sources_content(sources, project_dir)

    # Build main tab content
    toc_html = build_main_toc_html(report, family_colors, report_mode)
    findings_html = build_main_findings_html(report, family_colors, source_pointers, top_level_methods, report_mode)

    # Build Input Validation tab content
    iv_findings_html, iv_toc_html, iv_count, iv_entries_indexed = build_iv_findings_html(
        report, family_colors, source_pointers, top_level_methods, report_mode
    )
    passing_iv = [e for e in report.passing_entries if e.rule_family == "input_validation"]
    iv_summary_table_html = build_iv_summary_table(iv_entries_indexed, project_dir, sources, passing_iv)

    total_findings = len(report.entries)
    project_display = html.escape(project_name) if project_name else "ProverLite Report"
    contract_display = f'<div class="header-contract">Contract: {html.escape(contract_name)}</div>' if contract_name else ""
    verbose_suffix = " (VERBOSE)" if report_mode is ReportMode.VERBOSE else ""

    # Only show IV tab if there are input_validation findings (violated or passing)
    iv_tab_button = ""
    iv_total = iv_count + len(passing_iv)
    if iv_total > 0:
        iv_tab_button = f'<button class="tab-btn" onclick="switchTab(\'input-validation\')">Input Validation ({iv_total})</button>'

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Certora ProverLite Report{verbose_suffix} — {project_display}</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,{_CERTORA_FAVICON_SVG.replace(chr(34), '%22')}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
{_get_css()}
</style>
</head>
<body>

<!-- Executive Summary Header -->
<header class="report-header">
    <div class="header-left">
        {_CERTORA_LOGO_SVG}
        <div class="header-text">
            <h1>Certora ProverLite Report{verbose_suffix}</h1>
            <div class="header-project">{project_display}</div>
            {contract_display}
            <div class="header-meta">
                Generated: {html.escape(report.generated_at)}
                &middot; Jobs analyzed: {len(report.job_urls)}
                &middot; Iterations per rule: {report.iterations_per_rule}
            </div>
        </div>
    </div>
    <div class="header-right">
        <div class="summary-stat">
            <div class="stat-number">{total_findings}</div>
            <div class="stat-label">Findings</div>
        </div>
    </div>
</header>

<!-- Tab Bar -->
<div class="tab-bar">
    <button class="tab-btn active" onclick="switchTab('main')">Main</button>
    {iv_tab_button}
</div>

<!-- Main Tab -->
<div id="tab-main" class="tab-content active">

<!-- Table of Contents -->
<div class="toc-section" id="toc-section">
    <h2 class="section-title" onclick="toggleToc()">
        Table of Contents
        <span id="toc-toggle" class="toggle-arrow">&#x25BC;</span>
    </h2>
    <div id="toc-body" class="toc-body">
        {toc_html}
    </div>
</div>

<!-- Two-Pane Layout -->
<div class="two-pane" id="main-two-pane">
    <!-- Left Pane: Findings -->
    <div class="left-pane" id="left-pane">
        <div class="nav-toolbar" id="nav-toolbar">
            <button onclick="navTo('top')" title="Back to top">&#x23EB; Top</button>
            <button onclick="navTo('first')" title="First finding">&#x23EE; First</button>
            <button onclick="navTo('prev')" title="Previous finding">&#x25C0; Prev</button>
            <button onclick="navTo('next')" title="Next finding">Next &#x25B6;</button>
            <button onclick="navTo('last')" title="Last finding">Last &#x23ED;</button>
            <span class="nav-position" id="nav-position">1 / {total_findings}</span>
        </div>
        <div class="findings-container" id="findings-container">
            {findings_html}
        </div>
    </div>

    <!-- Resize Handle -->
    <div class="pane-divider" id="pane-divider"></div>

    <!-- Right Pane: File Viewer -->
    <div class="right-pane" id="right-pane">
        <div class="file-viewer-header">
            <h3>Source Files</h3>
            <span class="file-count" id="file-count"></span>
        </div>
        <div class="file-viewer-body">
            <div class="file-tree-pane" id="file-tree-pane">
                <div id="file-tree"></div>
            </div>
            <div class="file-content-pane" id="file-content-pane">
                <div class="file-content-header" id="file-content-header">
                    Select a file to view
                </div>
                <pre class="file-content" id="file-content">Select a file from the tree on the left.</pre>
            </div>
        </div>
    </div>
</div>

</div><!-- end tab-main -->

<!-- Input Validation Tab -->
<div id="tab-input-validation" class="tab-content">

<!-- IV Summary Table -->
<div class="iv-summary-section">
    <h2 style="font-size:18px;margin-bottom:12px">Input Validation Summary</h2>
    {iv_summary_table_html}
</div>

<!-- IV ToC -->
<div class="toc-section" id="iv-toc-section">
    <h2 class="section-title" onclick="toggleIvToc()">
        Table of Contents
        <span id="iv-toc-toggle" class="toggle-arrow">&#x25BC;</span>
    </h2>
    <div id="iv-toc-body" class="toc-body">
        {iv_toc_html}
    </div>
</div>

<!-- IV Two-Pane Layout -->
<div class="two-pane" id="iv-two-pane">
    <!-- Left Pane: IV Findings -->
    <div class="left-pane" id="iv-left-pane">
        <div class="nav-toolbar" id="iv-nav-toolbar">
            <button onclick="ivNavTo('top')" title="Back to top">&#x23EB; Top</button>
            <button onclick="ivNavTo('first')" title="First finding">&#x23EE; First</button>
            <button onclick="ivNavTo('prev')" title="Previous finding">&#x25C0; Prev</button>
            <button onclick="ivNavTo('next')" title="Next finding">Next &#x25B6;</button>
            <button onclick="ivNavTo('last')" title="Last finding">Last &#x23ED;</button>
            <span class="nav-position" id="iv-nav-position">1 / {iv_count}</span>
        </div>
        <div class="findings-container" id="iv-findings-container">
            {iv_findings_html}
        </div>
    </div>

    <!-- Resize Handle -->
    <div class="pane-divider" id="iv-pane-divider"></div>

    <!-- Right Pane: IV File Viewer -->
    <div class="right-pane" id="iv-right-pane">
        <div class="file-viewer-header">
            <h3>Source Files</h3>
            <span class="file-count" id="iv-file-count"></span>
        </div>
        <div class="file-viewer-body">
            <div class="file-tree-pane" id="iv-file-tree-pane">
                <div id="iv-file-tree"></div>
            </div>
            <div class="file-content-pane" id="iv-file-content-pane">
                <div class="file-content-header" id="iv-file-content-header">
                    Select a file to view
                </div>
                <pre class="file-content" id="iv-file-content">Select a file from the tree on the left.</pre>
            </div>
        </div>
    </div>
</div>

</div><!-- end tab-input-validation -->

<script>
{_get_js(file_tree_json, file_contents_json, total_findings, iv_count)}
</script>
</body>
</html>"""
