#!/usr/bin/env python3
"""
Prover Result Analyzer for PreAudit.

Provides unified analysis of ProverResult objects, extracting and categorizing
warnings, errors, and issues from rule results and alerts.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from prover_output_utility import AlertType, ParsedAlert

from src.utils.runner_types import ProverResult, RuleResult


# =============================================================================
# Data classes for analysis results
# =============================================================================


@dataclass
class AnalysisResult:
    """
    Complete analysis result for a ProverResult.

    Provides detailed breakdowns for reports like SetupCompletenessReport.
    """

    # Detailed breakdowns
    unresolved_calls: List[Dict[str, Any]] = field(default_factory=list)
    timeout_rules: List[RuleResult] = field(default_factory=list)
    error_rules: List[RuleResult] = field(default_factory=list)
    sanity_failures: List[RuleResult] = field(default_factory=list)

    # Categorized alerts
    alerts_by_type: Dict[AlertType, List[ParsedAlert]] = field(default_factory=dict)

    # Overall sanity status
    sanity_passed: bool = True

    # Job metadata
    job_url: Optional[str] = None

    @property
    def unresolved_call_count(self) -> int:
        return len(self.unresolved_calls)

    @property
    def timeout_count(self) -> int:
        return len(self.timeout_rules)

    @property
    def error_count(self) -> int:
        return len(self.error_rules)

    @property
    def sanity_failure_count(self) -> int:
        return len(self.sanity_failures)

    @property
    def alert_count(self) -> int:
        return sum(len(alerts) for alerts in self.alerts_by_type.values())


# =============================================================================
# Main analyzer class
# =============================================================================


class ProverResultAnalyzer:
    """
    Analyzes ProverResult objects to extract and categorize issues.
    """

    # Rule statuses that indicate errors
    ERROR_STATUSES = {"ERROR", "UNKNOWN", "KILLED"}

    def analyze(self, result: ProverResult) -> AnalysisResult:
        """
        Analyze a ProverResult and return structured analysis.

        Args:
            result: ProverResult from a prover run

        Returns:
            AnalysisResult with counts, breakdowns, and categorized issues
        """
        analysis = AnalysisResult(job_url=result.job_url)

        # Analyze unresolved calls
        self._analyze_unresolved_calls(result, analysis)

        # Analyze rule results
        self._analyze_rule_results(result, analysis)

        # Analyze alerts
        self._analyze_alerts(result, analysis)

        # Determine overall sanity status
        analysis.sanity_passed = result.success and analysis.sanity_failure_count == 0

        return analysis

    def _analyze_unresolved_calls(self, result: ProverResult, analysis: AnalysisResult) -> None:
        """Extract unresolved calls."""
        unresolved_calls = result.output_data.get("unresolved_calls", [])

        for call_info in unresolved_calls:
            # Handle both CallResolutionInfo objects and dicts (from cache)
            if isinstance(call_info, dict):
                is_unresolved = call_info.get("is_unresolved", True)
                if is_unresolved:
                    analysis.unresolved_calls.append(call_info)
            else:
                if call_info.is_unresolved:
                    analysis.unresolved_calls.append(call_info.to_dict())

    def _analyze_rule_results(self, result: ProverResult, analysis: AnalysisResult) -> None:
        """Analyze rule results for timeouts, errors, and sanity failures."""
        for rule in result.rule_results:
            status_upper = rule.status.upper()

            # Check for timeout
            if status_upper == "TIMEOUT":
                analysis.timeout_rules.append(rule)

            # Check for error/unknown/killed
            elif status_upper in self.ERROR_STATUSES:
                analysis.error_rules.append(rule)

            # Check for sanity failure
            if rule.rule_name == "sanity" and status_upper in {"VIOLATED", "FAILED"}:
                analysis.sanity_failures.append(rule)

    def _analyze_alerts(self, result: ProverResult, analysis: AnalysisResult) -> None:
        """Analyze alerts for categorized alerts."""
        for alert in result.alerts:
            # alert is already a ParsedAlert from ProverOutputAPI
            if alert.alert_type not in analysis.alerts_by_type:
                analysis.alerts_by_type[alert.alert_type] = []
            analysis.alerts_by_type[alert.alert_type].append(alert)
