"""
Platform management commands for VarityKit

List, inspect, and check health of supported deployment platforms.
"""

import click
import requests
from rich.console import Console
from rich.table import Table

console = Console()

# Chain configurations — single source of truth for CLI
CHAIN_CONFIGS = {
    "varity": {
        "name": "Varity Platform (Testnet)",
        "chain_id": 33529,
        "rpc_url": "https://rpc-varity-testnet-rroe52pwjp.t.conduit.xyz",
        "explorer_url": "https://explorer-varity-testnet-rroe52pwjp.t.conduit.xyz",
        "native_token": "USDC",
        "native_decimals": 6,
        "type": "Varity (Conduit)",
        "privacy": "none",
        "testnet": True,
        "gas_price_gwei": "0.1",
        "block_time_sec": "~0.25",
    },
    "avalanche": {
        "name": "Avalanche Platform (Testnet)",
        "chain_id": 43214,
        "rpc_url": "http://81.15.150.164:9654/ext/bc/MZqKVUw3VeGVjL3DDgzRwWoKGXxJ4F168GKewvKt6CruzDpAH/rpc",
        "explorer_url": "http://81.15.150.164:4000",
        "native_token": "USDC",
        "native_decimals": 18,
        "type": "Avalanche (Fluence)",
        "privacy": "sovereign",
        "testnet": True,
        "gas_price_gwei": "0.5",
        "block_time_sec": "~2",
        "contracts": {
            "entrypoint": "0xA4cD3b0Eb6E5Ab5d8CE4065BcCD70040ADAB1F00",
            "account_factory": "0xa4DfF80B4a1D748BF28BC4A271eD834689Ea3407",
            "paymaster": "0xe336d36FacA76840407e6836d26119E1EcE0A2b4",
            "app_registry": "0x55a4eDd8A2c051079b426E9fbdEe285368824a89",
            "template_marketplace": "0x8B3BC4270BE2abbB25BC04717830bd1Cc493a461",
            "template_registry": "0x7B4982e1F7ee384F206417Fb851a1EB143c513F9",
            "multicall3": "0xE3573540ab8A1C4c754Fd958Dc1db39BBE81b208",
        },
        "bundler_url": "http://81.15.150.164:4337",
    },
}

DEFAULT_CHAIN = "varity"


@click.group()
def platforms():
    """
    Manage and inspect supported platforms

    \b
    Commands:
      varitykit platforms list          # List all supported platforms
      varitykit platforms info avalanche  # Show platform details
      varitykit platforms health        # Check platform health
    """
    pass


@platforms.command("list")
def list_chains():
    """List all supported platforms"""
    table = Table(title="Supported Platforms", show_lines=True)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("Environment", justify="center")
    table.add_column("Default", justify="center")

    for chain_key, config in CHAIN_CONFIGS.items():
        is_default = "Y" if chain_key == DEFAULT_CHAIN else ""
        env_label = "Testnet" if config["testnet"] else "Production"
        table.add_row(
            chain_key,
            config["name"],
            env_label,
            is_default,
        )

    console.print()
    console.print(table)
    console.print()
    console.print(f"  Default platform: [cyan]{DEFAULT_CHAIN}[/cyan]")
    console.print(f"  Use [bold]--target[/bold] flag with deploy: varitykit app deploy --target avalanche")
    console.print()


@platforms.command()
@click.argument("chain_id", required=True)
def info(chain_id):
    """Show detailed platform information"""
    config = CHAIN_CONFIGS.get(chain_id)
    if not config:
        console.print(f"[red]Unknown platform: {chain_id}[/red]")
        console.print(f"Available: {', '.join(CHAIN_CONFIGS.keys())}")
        return

    console.print()
    console.print(f"[bold cyan]{config['name']}[/bold cyan]")
    console.print()

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="dim", no_wrap=True)
    table.add_column("Value")

    table.add_row("CLI Identifier", chain_id)
    table.add_row("Full Name", config["name"])
    table.add_row("Type", config["type"])
    table.add_row("API URL", config["rpc_url"])
    table.add_row("Explorer", config["explorer_url"])
    table.add_row("Currency", f"{config['native_token']} ({config['native_decimals']} decimals)")
    table.add_row("Transaction Cost", f"{config['gas_price_gwei']} units")
    table.add_row("Block Time", config["block_time_sec"])
    table.add_row("Privacy", config["privacy"])
    table.add_row("Environment", "Testnet" if config["testnet"] else "Production")
    table.add_row("Default", str(chain_id == DEFAULT_CHAIN))

    console.print(table)
    console.print()


@platforms.command()
@click.argument("chain_id", required=False)
def health(chain_id):
    """Check platform health"""
    targets = {}
    if chain_id:
        config = CHAIN_CONFIGS.get(chain_id)
        if not config:
            console.print(f"[red]Unknown platform: {chain_id}[/red]")
            return
        targets[chain_id] = config
    else:
        targets = CHAIN_CONFIGS

    console.print()
    console.print("[bold]Platform Health Check[/bold]")
    console.print()

    for _, config in targets.items():
        rpc_url = config["rpc_url"]
        try:
            # eth_chainId
            resp = requests.post(
                rpc_url,
                json={"jsonrpc": "2.0", "method": "eth_chainId", "params": [], "id": 1},
                timeout=10,
            )
            data = resp.json()
            chain_id_hex = data.get("result", "0x0")
            chain_id_int = int(chain_id_hex, 16) if chain_id_hex else 0

            if chain_id_int == config["chain_id"]:
                console.print(f"  [green]PASS[/green]  {config['name']} (platform {chain_id_int})")
            else:
                console.print(
                    f"  [yellow]WARN[/yellow]  {config['name']} — platform ID mismatch "
                    f"(expected {config['chain_id']}, got {chain_id_int})"
                )

            # eth_blockNumber
            resp2 = requests.post(
                rpc_url,
                json={"jsonrpc": "2.0", "method": "eth_blockNumber", "params": [], "id": 2},
                timeout=10,
            )
            block_data = resp2.json()
            block_hex = block_data.get("result", "0x0")
            block_num = int(block_hex, 16) if block_hex else 0
            console.print(f"         Block height: {block_num:,}")

        except requests.exceptions.Timeout:
            console.print(f"  [red]FAIL[/red]  {config['name']} — RPC timeout ({rpc_url})")
        except requests.exceptions.ConnectionError:
            console.print(f"  [red]FAIL[/red]  {config['name']} — Connection refused ({rpc_url})")
        except Exception as e:
            console.print(f"  [red]FAIL[/red]  {config['name']} — {e}")

    console.print()
