"""Setup script for bio-simulagent-client."""
from setuptools import setup, find_packages
import os

# Read long description from README
readme_path = "bio_simulagent_client/README.md"
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "Python client library for bio-simulagent MCP backend"

setup(
    name="bio-simulagent-client",
    version="0.3.0",
    description="Python client library for bio-simulagent MCP backend",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="surplus96",
    author_email="surplus96@example.com",
    url="https://github.com/surplus96/bio-simulagent",
    packages=find_packages(exclude=["tests", "tests.*", "backend", "backend.*", "docs", "docs.*"]),
    package_data={
        "bio_simulagent_client": [
            "py.typed",
            "examples/*.ipynb",
            "examples/*.md",
        ],
    },
    python_requires=">=3.9",
    install_requires=[
        "mcp>=0.9.0",
        "pydantic>=2.0",
        "aiohttp>=3.9.0",
    ],
    extras_require={
        "jupyter": [
            "ipython>=8.0",
            "nglview>=3.0",
            "mdtraj>=1.9",
            "plotly>=5.0",
            "pyyaml>=6.0",
        ],
        "dev": [
            "pytest>=9.0",
            "pytest-asyncio>=0.23",
            "pytest-cov>=4.0",
            "mypy>=1.8",
            "black>=24.0",
            "ruff>=0.3",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "Topic :: Scientific/Engineering :: Chemistry",
    ],
    keywords="computational-biology drug-discovery jupyter mcp reproducible-research",
)
