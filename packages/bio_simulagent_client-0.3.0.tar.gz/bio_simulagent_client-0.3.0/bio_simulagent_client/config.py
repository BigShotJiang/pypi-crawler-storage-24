"""Configuration management for bio-simulagent-client."""
from typing import Optional
from pydantic import BaseModel, Field


class ClientConfig(BaseModel):
    """Client configuration settings.

    Attributes:
        backend_path: Python module path to backend (default: "backend.main")
        python_executable: Python interpreter path (default: auto-detect)
        connection_timeout: Connection timeout in seconds (default: 30)
        tool_timeout: Tool execution timeout in seconds (default: 60)
        resource_timeout: Resource read timeout in seconds (default: 30)
        workflow_poll_interval: Workflow status poll interval in seconds (default: 2.0)
        max_retries: Maximum number of retries for failed requests (default: 3)
        retry_delay: Delay between retries in seconds (default: 1.0)
        log_level: Logging level (default: "INFO")
        enable_progress_tracking: Enable workflow progress tracking (default: True)
    """

    backend_path: str = Field(
        default="backend.main",
        description="Python module path to MCP backend"
    )

    python_executable: Optional[str] = Field(
        default=None,
        description="Python interpreter path (auto-detect if None)"
    )

    connection_timeout: int = Field(
        default=30,
        ge=1,
        le=300,
        description="Connection timeout in seconds"
    )

    tool_timeout: int = Field(
        default=60,
        ge=1,
        le=600,
        description="Tool execution timeout in seconds"
    )

    resource_timeout: int = Field(
        default=30,
        ge=1,
        le=300,
        description="Resource read timeout in seconds"
    )

    workflow_poll_interval: float = Field(
        default=2.0,
        ge=0.1,
        le=60.0,
        description="Workflow status poll interval in seconds"
    )

    max_retries: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Maximum number of retries for failed requests"
    )

    retry_delay: float = Field(
        default=1.0,
        ge=0.1,
        le=10.0,
        description="Delay between retries in seconds"
    )

    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)"
    )

    enable_progress_tracking: bool = Field(
        default=True,
        description="Enable workflow progress tracking"
    )

    class Config:
        """Pydantic config."""
        validate_assignment = True


# Default configuration instance
DEFAULT_CONFIG = ClientConfig()


def get_config() -> ClientConfig:
    """Get default configuration.

    Returns:
        ClientConfig: Default configuration instance

    Example:
        >>> config = get_config()
        >>> print(f"Timeout: {config.connection_timeout}s")
    """
    return DEFAULT_CONFIG


def create_config(**kwargs) -> ClientConfig:
    """Create custom configuration.

    Args:
        **kwargs: Configuration overrides

    Returns:
        ClientConfig: Custom configuration instance

    Example:
        >>> config = create_config(
        ...     connection_timeout=60,
        ...     log_level="DEBUG"
        ... )
    """
    return ClientConfig(**kwargs)
