"""Workflow execution and monitoring."""
import asyncio
import logging
from typing import TYPE_CHECKING, Dict, Any, Optional, Callable, List

from .types import WorkflowResult, WorkflowStatus, WorkflowStep

if TYPE_CHECKING:
    from .client import BioSimulagent

logger = logging.getLogger(__name__)


class WorkflowRunner:
    """Workflow execution and monitoring."""

    def __init__(self, client: "BioSimulagent"):
        self._client = client

    async def run(
        self,
        name: str,
        objective: str,
        params: Optional[Dict[str, Any]] = None,
        on_progress: Optional[Callable[[WorkflowStep], None]] = None,
        poll_interval: float = 2.0,
    ) -> WorkflowResult:
        """Execute workflow with progress tracking.

        Args:
            name: Workflow name (ligand_optimization, md_simulation, etc.)
            objective: Natural language objective
            params: Optional workflow parameters
            on_progress: Optional callback for progress updates
            poll_interval: Status polling interval in seconds

        Returns:
            WorkflowResult: Final workflow result

        Example:
            >>> result = await client.workflow.run(
            ...     name="ligand_optimization",
            ...     objective="Design EGFR inhibitor",
            ...     params={"target": "EGFR"},
            ...     on_progress=lambda step: print(f"Step: {step.name}")
            ... )
        """
        logger.info(f"Starting workflow: {name}")

        # Start workflow
        response = await self._client._call_tool(
            name="workflow_run",
            arguments={
                "name": name,
                "objective": objective,
                "params": params or {},
            },
        )

        workflow_id = response["workflow_id"]
        logger.info(f"Workflow started: {workflow_id}")

        # Poll for status updates
        while True:
            status = await self.status(workflow_id)

            # Call progress callback
            if on_progress:
                for step in status.steps:
                    on_progress(step)

            # Check if completed
            if status.status in [
                WorkflowStatus.COMPLETED,
                WorkflowStatus.FAILED,
                WorkflowStatus.CANCELLED,
            ]:
                logger.info(f"Workflow {workflow_id} finished with status: {status.status}")
                return status

            # Wait before next poll
            await asyncio.sleep(poll_interval)

    async def status(self, workflow_id: str) -> WorkflowResult:
        """Get workflow status.

        Args:
            workflow_id: Workflow identifier

        Returns:
            WorkflowResult: Current workflow status

        Example:
            >>> status = await client.workflow.status(workflow_id)
            >>> print(f"Status: {status.status}")
            >>> for step in status.steps:
            ...     print(f"  {step.name}: {step.status}")
        """
        result = await self._client._call_tool(
            name="workflow_status",
            arguments={"workflow_id": workflow_id},
        )
        return WorkflowResult.model_validate(result)

    async def cancel(self, workflow_id: str) -> dict:
        """Cancel running workflow.

        Args:
            workflow_id: Workflow identifier

        Returns:
            dict: Cancellation result

        Example:
            >>> await client.workflow.cancel(workflow_id)
        """
        result = await self._client._call_tool(
            name="workflow_cancel",
            arguments={"workflow_id": workflow_id},
        )
        logger.info(f"Workflow {workflow_id} cancelled")
        return result

    async def list_available(self) -> List[str]:
        """List available workflow templates.

        Returns:
            List[str]: Workflow names

        Example:
            >>> workflows = await client.workflow.list_available()
            >>> print(f"Available workflows: {workflows}")
        """
        resource = await self._client._read_resource("workflow://templates")
        workflows = resource.get("workflows", {})
        return list(workflows.keys())
