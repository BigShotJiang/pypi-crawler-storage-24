"""Internal implementation modules for bio-simulagent-client.

This package contains low-level implementation details:
- subprocess_manager: Backend process lifecycle management
- mcp_protocol: MCP JSON-RPC communication over stdio

These modules are not part of the public API and should not be imported directly.
"""
