"""Subprocess lifecycle management."""
import asyncio
import logging
from typing import Optional
from asyncio.subprocess import Process

logger = logging.getLogger(__name__)


class SubprocessManager:
    """Manages Python backend subprocess lifecycle."""

    def __init__(self):
        self.process: Optional[Process] = None

    async def spawn(
        self,
        command: str,
        args: list[str],
        timeout: int = 30,
    ) -> Process:
        """Spawn subprocess.

        Args:
            command: Executable path (e.g., "python3")
            args: Command arguments (e.g., ["-m", "backend.main"])
            timeout: Spawn timeout in seconds

        Returns:
            Process: Running subprocess

        Raises:
            ConnectionError: If subprocess fails to start
            TimeoutError: If spawn exceeds timeout
        """
        try:
            logger.info(f"Spawning subprocess: {command} {' '.join(args)}")

            self.process = await asyncio.wait_for(
                asyncio.create_subprocess_exec(
                    command,
                    *args,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                ),
                timeout=timeout,
            )

            # Check if process started successfully
            if self.process.returncode is not None:
                raise ConnectionError(f"Subprocess exited immediately with code {self.process.returncode}")

            logger.info(f"Subprocess spawned successfully (PID: {self.process.pid})")
            return self.process

        except asyncio.TimeoutError as e:
            raise TimeoutError(f"Subprocess spawn timed out after {timeout}s") from e
        except Exception as e:
            logger.exception("Failed to spawn subprocess")
            raise ConnectionError(f"Failed to spawn subprocess: {e}") from e

    async def terminate(self, timeout: int = 5):
        """Terminate subprocess gracefully.

        Args:
            timeout: Grace period before force kill (seconds)
        """
        if self.process is None:
            return

        try:
            logger.info(f"Terminating subprocess (PID: {self.process.pid})")

            # Send SIGTERM
            self.process.terminate()

            # Wait for graceful shutdown
            try:
                await asyncio.wait_for(self.process.wait(), timeout=timeout)
                logger.info("Subprocess terminated gracefully")
            except asyncio.TimeoutError:
                # Force kill
                logger.warning(f"Subprocess did not terminate within {timeout}s, killing...")
                self.process.kill()
                await self.process.wait()
                logger.info("Subprocess killed")

        except Exception as e:
            logger.exception(f"Error during subprocess termination: {e}")
        finally:
            self.process = None

    def is_alive(self) -> bool:
        """Check if subprocess is still running."""
        if self.process is None:
            return False
        return self.process.returncode is None

    async def monitor(self) -> Optional[int]:
        """Monitor subprocess and return exit code if crashed.

        Returns:
            Optional[int]: Exit code if crashed, None if still running
        """
        if self.process is None:
            return None

        # Check if process has exited
        return_code = self.process.returncode
        if return_code is not None:
            logger.error(f"Subprocess crashed with exit code {return_code}")
            return return_code

        return None
