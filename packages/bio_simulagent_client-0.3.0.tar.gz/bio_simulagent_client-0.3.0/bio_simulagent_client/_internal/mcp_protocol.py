"""MCP protocol implementation (JSON-RPC over stdio)."""
import asyncio
import json
import logging
from typing import Any, Dict, Optional
from asyncio.subprocess import Process

logger = logging.getLogger(__name__)


class MCPProtocol:
    """Handles MCP JSON-RPC communication."""

    def __init__(self, process: Process):
        self.process = process
        self._request_id = 0
        self._initialized = False

    async def initialize(self, timeout: int = 30) -> Dict[str, Any]:
        """Initialize MCP connection (handshake).

        Args:
            timeout: Initialization timeout in seconds

        Returns:
            Dict: Server info and capabilities

        Raises:
            ConnectionError: If handshake fails
            TimeoutError: If initialization times out
        """
        try:
            logger.info("Initializing MCP connection...")

            # Send initialize request
            init_request = {
                "jsonrpc": "2.0",
                "id": self._next_id(),
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {
                        "name": "bio-simulagent-client",
                        "version": "0.2.0",
                    },
                },
            }

            response = await asyncio.wait_for(
                self._send_request(init_request),
                timeout=timeout,
            )

            if "error" in response:
                raise ConnectionError(f"MCP initialization failed: {response['error']}")

            self._initialized = True
            logger.info("MCP connection initialized successfully")
            return response.get("result", {})

        except asyncio.TimeoutError as e:
            raise TimeoutError(f"MCP initialization timed out after {timeout}s") from e
        except Exception as e:
            logger.exception("MCP initialization failed")
            raise ConnectionError(f"MCP initialization failed: {e}") from e

    async def call_tool(
        self,
        name: str,
        arguments: Dict[str, Any],
        timeout: int = 60,
    ) -> Dict[str, Any]:
        """Call MCP tool.

        Args:
            name: Tool name (e.g., "literature.search")
            arguments: Tool arguments
            timeout: Call timeout in seconds

        Returns:
            Dict: Tool result

        Raises:
            ToolExecutionError: If tool execution fails
            TimeoutError: If call times out
        """
        if not self._initialized:
            raise ConnectionError("MCP not initialized. Call initialize() first.")

        try:
            logger.debug(f"Calling tool: {name}")

            request = {
                "jsonrpc": "2.0",
                "id": self._next_id(),
                "method": "tools/call",
                "params": {
                    "name": name,
                    "arguments": arguments,
                },
            }

            response = await asyncio.wait_for(
                self._send_request(request),
                timeout=timeout,
            )

            if "error" in response:
                error = response["error"]
                from ..exceptions import ToolExecutionError

                raise ToolExecutionError(
                    tool_name=name,
                    error_code=error.get("code", "UNKNOWN"),
                    message=error.get("message", "Tool execution failed"),
                    details=error.get("data", {}),
                )

            result = response.get("result", {})
            logger.debug(f"Tool {name} completed successfully")
            return result

        except asyncio.TimeoutError as e:
            raise TimeoutError(f"Tool {name} timed out after {timeout}s") from e

    async def read_resource(self, uri: str, timeout: int = 30) -> Dict[str, Any]:
        """Read MCP resource.

        Args:
            uri: Resource URI (e.g., "workflow://templates")
            timeout: Read timeout in seconds

        Returns:
            Dict: Resource contents

        Raises:
            ConnectionError: If read fails
            TimeoutError: If read times out
        """
        if not self._initialized:
            raise ConnectionError("MCP not initialized. Call initialize() first.")

        try:
            logger.debug(f"Reading resource: {uri}")

            request = {
                "jsonrpc": "2.0",
                "id": self._next_id(),
                "method": "resources/read",
                "params": {"uri": uri},
            }

            response = await asyncio.wait_for(
                self._send_request(request),
                timeout=timeout,
            )

            if "error" in response:
                raise ConnectionError(f"Resource read failed: {response['error']}")

            return response.get("result", {})

        except asyncio.TimeoutError as e:
            raise TimeoutError(f"Resource read timed out after {timeout}s") from e

    async def close(self):
        """Close MCP connection gracefully."""
        if not self._initialized:
            return

        try:
            logger.info("Closing MCP connection...")

            # Send shutdown notification (no response expected)
            shutdown_request = {
                "jsonrpc": "2.0",
                "method": "shutdown",
                "params": {},
            }

            await self._send_notification(shutdown_request)
            self._initialized = False
            logger.info("MCP connection closed")

        except Exception as e:
            logger.warning(f"Error during MCP close: {e}")

    async def _send_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Send JSON-RPC request and wait for response."""
        # Send request
        request_json = json.dumps(request) + "\n"
        self.process.stdin.write(request_json.encode())
        await self.process.stdin.drain()

        # Read response
        response_line = await self.process.stdout.readline()
        if not response_line:
            raise ConnectionError("MCP server closed connection")

        response = json.loads(response_line.decode())
        return response

    async def _send_notification(self, notification: Dict[str, Any]):
        """Send JSON-RPC notification (no response expected)."""
        notification_json = json.dumps(notification) + "\n"
        self.process.stdin.write(notification_json.encode())
        await self.process.stdin.drain()

    def _next_id(self) -> int:
        """Generate next request ID."""
        self._request_id += 1
        return self._request_id
