"""BioSimulagent - Python MCP client for reproducible research workflows.

This library provides a Pythonic async API for interacting with the BioSimulagent
backend's MCP tools for literature search, molecular simulation, ligand design,
and neural modeling.

Example:
    >>> from bio_simulagent_client import BioSimulagent
    >>>
    >>> async with BioSimulagent.connect() as client:
    ...     # Search literature
    ...     results = await client.literature.search("EGFR inhibitor")
    ...
    ...     # Run workflow
    ...     result = await client.workflow.run(
    ...         name="ligand_optimization",
    ...         objective="Design EGFR inhibitor"
    ...     )
"""

from .client import BioSimulagent
from .workflows import WorkflowRunner
from .config import ClientConfig, get_config, create_config

# Types
from .types import (
    Article,
    LiteratureSearchResult,
    SimulationResult,
    MoleculeCandidate,
    DesignResult,
    CNSProfile,
    TrajectoryAnalysis,
    SimulationConfig,
    NeuralResult,
    WorkflowStatus,
    WorkflowStep,
    WorkflowResult,
)

# Exceptions
from .exceptions import (
    BioSimulagentError,
    ConnectionError,
    ToolExecutionError,
    ValidationError,
    TimeoutError,
    SubprocessCrashError,
)

# Tool wrappers
from .tools import Literature, Simulation, Design, Neural

__version__ = "0.3.0"
__all__ = [
    # Main client
    "BioSimulagent",
    "WorkflowRunner",
    # Configuration
    "ClientConfig",
    "get_config",
    "create_config",
    # Types
    "Article",
    "LiteratureSearchResult",
    "SimulationResult",
    "MoleculeCandidate",
    "DesignResult",
    "CNSProfile",
    "TrajectoryAnalysis",
    "SimulationConfig",
    "NeuralResult",
    "WorkflowStatus",
    "WorkflowStep",
    "WorkflowResult",
    # Exceptions
    "BioSimulagentError",
    "ConnectionError",
    "ToolExecutionError",
    "ValidationError",
    "TimeoutError",
    "SubprocessCrashError",
    # Tool wrappers
    "Literature",
    "Simulation",
    "Design",
    "Neural",
]
