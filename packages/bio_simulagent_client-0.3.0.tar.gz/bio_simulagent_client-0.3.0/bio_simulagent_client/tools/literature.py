"""Literature search and analysis tools."""
from typing import List, Optional, TYPE_CHECKING

from .base import BaseTool
from ..types import Article, LiteratureSearchResult

if TYPE_CHECKING:
    from ..client import BioSimulagent


class Literature(BaseTool):
    """Literature search and analysis tools.

    Provides access to literature databases including PubMed,
    ArXiv, and patent databases with RAG query capabilities.
    """

    tool_prefix = "literature"

    async def search(
        self,
        query: str,
        max_results: int = 10,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> LiteratureSearchResult:
        """Search PubMed for articles.

        Args:
            query: Search query (e.g., "EGFR inhibitors")
            max_results: Maximum number of results (default: 10)
            date_from: Start date YYYY-MM-DD (optional)
            date_to: End date YYYY-MM-DD (optional)

        Returns:
            LiteratureSearchResult: Search results with articles

        Raises:
            ValidationError: If query is empty or max_results < 1
            ToolExecutionError: If PubMed API fails

        Example:
            >>> result = await client.literature.search("EGFR inhibitors", max_results=5)
            >>> print(f"Found {result.total_count} articles")
            >>> for article in result.articles:
            ...     print(f"{article.title} ({article.year})")
        """
        # Validate inputs using base class helpers
        self._validate_not_empty(query, "query")
        self._validate_positive(max_results, "max_results")

        # Call MCP tool using base class method
        result = await self._call_tool(
            tool_name="search",
            arguments={
                "query": query,
                "max_results": max_results,
                "date_from": date_from,
                "date_to": date_to,
            },
        )

        # Parse and return typed result
        return LiteratureSearchResult.model_validate(result)

    async def index(self, articles: List[Article]) -> dict:
        """Index articles into vector store for RAG queries.

        Args:
            articles: List of articles to index

        Returns:
            dict: Index status with index_id

        Example:
            >>> articles = (await client.literature.search("EGFR")).articles
            >>> index_result = await client.literature.index(articles)
            >>> index_id = index_result["index_id"]
        """
        result = await self._call_tool(
            tool_name="index",
            arguments={"articles": [article.model_dump() for article in articles]},
        )
        return result

    async def query(self, question: str, index_id: str) -> dict:
        """RAG query against indexed articles.

        Args:
            question: Natural language question
            index_id: Index ID from index()

        Returns:
            dict: Answer with citations

        Example:
            >>> answer = await client.literature.query(
            ...     question="What are the side effects?",
            ...     index_id=index_id
            ... )
            >>> print(answer["answer"])
        """
        result = await self._call_tool(
            tool_name="rag_query",
            arguments={"question": question, "index_id": index_id},
        )
        return result

    async def search_patents(self, query: str, max_results: int = 10) -> dict:
        """Search patent databases.

        Args:
            query: Patent search query
            max_results: Maximum results (default: 10)

        Returns:
            dict: Patent search results

        Example:
            >>> patents = await client.literature.search_patents("EGFR inhibitor")
        """
        result = await self._call_tool(
            tool_name="search_patents",
            arguments={"query": query, "max_results": max_results},
        )
        return result
