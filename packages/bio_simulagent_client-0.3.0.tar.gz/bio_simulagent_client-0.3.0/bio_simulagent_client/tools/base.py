"""Base class for tool wrappers."""
from typing import TYPE_CHECKING, Dict, Any, Optional
from abc import ABC

if TYPE_CHECKING:
    from ..client import BioSimulagent


class BaseTool(ABC):
    """Base class for all MCP tool wrappers.

    Provides common functionality for tool execution, error handling,
    and result parsing.

    Args:
        client: BioSimulagent client instance

    Attributes:
        _client: Reference to parent client
        tool_prefix: MCP tool name prefix (e.g., 'literature', 'simulation')
    """

    tool_prefix: str = ""

    def __init__(self, client: "BioSimulagent"):
        """Initialize tool wrapper.

        Args:
            client: BioSimulagent client instance
        """
        self._client = client

    async def _call_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Call MCP tool with consistent error handling.

        Args:
            tool_name: Tool name without prefix (e.g., 'search')
            arguments: Tool arguments
            timeout: Optional timeout in seconds

        Returns:
            Tool execution result

        Raises:
            ToolExecutionError: If tool execution fails
            TimeoutError: If execution times out

        Example:
            >>> result = await self._call_tool("search", {"query": "EGFR"})
        """
        full_tool_name = f"{self.tool_prefix}.{tool_name}" if self.tool_prefix else tool_name
        return await self._client._call_tool(full_tool_name, arguments)

    def _validate_not_empty(self, value: str, field_name: str) -> None:
        """Validate that string field is not empty.

        Args:
            value: String value to validate
            field_name: Field name for error message

        Raises:
            ValidationError: If value is empty or whitespace
        """
        from ..exceptions import ValidationError

        if not value or value.strip() == "":
            raise ValidationError(f"{field_name} cannot be empty")

    def _validate_positive(self, value: int, field_name: str) -> None:
        """Validate that numeric field is positive.

        Args:
            value: Numeric value to validate
            field_name: Field name for error message

        Raises:
            ValidationError: If value is not positive
        """
        from ..exceptions import ValidationError

        if value <= 0:
            raise ValidationError(f"{field_name} must be positive, got {value}")

    def _validate_in_range(
        self,
        value: float,
        min_val: float,
        max_val: float,
        field_name: str
    ) -> None:
        """Validate that numeric field is within range.

        Args:
            value: Numeric value to validate
            min_val: Minimum allowed value
            max_val: Maximum allowed value
            field_name: Field name for error message

        Raises:
            ValidationError: If value is out of range
        """
        from ..exceptions import ValidationError

        if not min_val <= value <= max_val:
            raise ValidationError(
                f"{field_name} must be between {min_val} and {max_val}, got {value}"
            )
