"""Molecular design and optimization tools."""
from typing import TYPE_CHECKING, Optional, List

from ..types import DesignResult, MoleculeCandidate

if TYPE_CHECKING:
    from ..client import BioSimulagent


class Design:
    """Molecular design and optimization tools."""

    def __init__(self, client: "BioSimulagent"):
        self._client = client

    async def predict_structure(self, sequence: str) -> dict:
        """Predict protein structure using AlphaFold.

        Args:
            sequence: Amino acid sequence

        Returns:
            dict: Predicted structure info
        """
        result = await self._client._call_tool(
            name="design.predict_structure",
            arguments={"sequence": sequence},
        )
        return result

    async def design_ligand(self, target: str) -> DesignResult:
        """Generate ligand candidates for target.

        Args:
            target: Target protein name

        Returns:
            DesignResult: Designed ligand candidates
        """
        result = await self._client._call_tool(
            name="design.generate_ligand",
            arguments={"target": target},
        )
        return DesignResult.model_validate(result)

    async def optimize(self, smiles: str) -> dict:
        """Optimize ligand structure.

        Args:
            smiles: SMILES string

        Returns:
            dict: Optimized structure
        """
        result = await self._client._call_tool(
            name="design.optimize_structure",
            arguments={"smiles": smiles},
        )
        return result

    async def scaffold_hopping(self, smiles: str) -> List[MoleculeCandidate]:
        """Find alternative scaffolds.

        Args:
            smiles: Original SMILES

        Returns:
            List[MoleculeCandidate]: Alternative scaffolds
        """
        result = await self._client._call_tool(
            name="design.scaffold_hopping",
            arguments={"smiles": smiles},
        )
        return [MoleculeCandidate.model_validate(c) for c in result["candidates"]]

    async def enumerate(self, scaffold: str, num_analogs: int = 100) -> DesignResult:
        """Generate analog library.

        Args:
            scaffold: Base scaffold SMILES
            num_analogs: Number of analogs to generate

        Returns:
            DesignResult: Analog library
        """
        result = await self._client._call_tool(
            name="design.enumerate_analogs",
            arguments={"scaffold": scaffold, "num_analogs": num_analogs},
        )
        return DesignResult.model_validate(result)

    async def similarity_search(self, query: str, top_k: int = 10) -> List[MoleculeCandidate]:
        """Find similar compounds.

        Args:
            query: Query SMILES
            top_k: Number of results

        Returns:
            List[MoleculeCandidate]: Similar compounds
        """
        result = await self._client._call_tool(
            name="design.similarity_search",
            arguments={"query": query, "top_k": top_k},
        )
        return [MoleculeCandidate.model_validate(c) for c in result["candidates"]]
