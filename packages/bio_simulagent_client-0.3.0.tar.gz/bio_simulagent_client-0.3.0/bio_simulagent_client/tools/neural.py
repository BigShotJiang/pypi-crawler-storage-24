"""Neural dynamics and CNS profiling tools."""
from typing import TYPE_CHECKING

from ..types import CNSProfile

if TYPE_CHECKING:
    from ..client import BioSimulagent


class Neural:
    """Neural dynamics and CNS profiling tools."""

    def __init__(self, client: "BioSimulagent"):
        self._client = client

    async def predict_bbb(self, smiles: str) -> dict:
        """Predict blood-brain barrier permeability.

        Args:
            smiles: Molecule SMILES

        Returns:
            dict: BBB permeability score
        """
        result = await self._client._call_tool(
            name="neural.bbb_prediction",
            arguments={"smiles": smiles},
        )
        return result

    async def simulate_circuit(self, circuit_config: dict) -> dict:
        """Simulate neural circuit dynamics.

        Args:
            circuit_config: Circuit configuration

        Returns:
            dict: Simulation results
        """
        result = await self._client._call_tool(
            name="neural.circuit_simulation",
            arguments=circuit_config,
        )
        return result

    async def drug_effect(self, smiles: str, circuit_id: str) -> dict:
        """Simulate drug effect on neural activity.

        Args:
            smiles: Drug SMILES
            circuit_id: Circuit identifier

        Returns:
            dict: Drug effect results
        """
        result = await self._client._call_tool(
            name="neural.drug_effect_simulation",
            arguments={"smiles": smiles, "circuit_id": circuit_id},
        )
        return result

    async def phenotype_analysis(self, data: dict) -> dict:
        """Analyze neural phenotype.

        Args:
            data: Phenotype data

        Returns:
            dict: Analysis results
        """
        result = await self._client._call_tool(
            name="neural.phenotype_analysis",
            arguments=data,
        )
        return result

    async def cns_profile(self, smiles: str) -> CNSProfile:
        """Generate CNS drug profile.

        Args:
            smiles: Molecule SMILES

        Returns:
            CNSProfile: Complete CNS profile
        """
        result = await self._client._call_tool(
            name="neural.cns_profile",
            arguments={"smiles": smiles},
        )
        return CNSProfile.model_validate(result)
