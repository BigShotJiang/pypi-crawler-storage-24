"""Custom exceptions for bio-simulagent-client."""
from typing import Optional, List


class BioSimulagentError(Exception):
    """Base exception for all client errors.

    All exceptions inherit from this base class and provide detailed
    error messages with actionable suggestions when possible.
    """

    def __init__(self, message: str, suggestion: Optional[str] = None):
        """Initialize exception with message and optional suggestion.

        Args:
            message: Error message describing what went wrong
            suggestion: Optional suggestion for how to fix the error
        """
        self.message = message
        self.suggestion = suggestion

        full_message = message
        if suggestion:
            full_message = f"{message}\n\nSuggestion: {suggestion}"

        super().__init__(full_message)


class ConnectionError(BioSimulagentError):
    """Backend subprocess connection failed.

    Raised when the client cannot connect to the backend subprocess.
    This typically indicates the backend is not running or not accessible.

    Attributes:
        backend_path: Path to backend module that failed to connect
        python_executable: Python interpreter used
        error_details: Additional error details
    """

    def __init__(
        self,
        backend_path: str,
        python_executable: str,
        error_details: Optional[str] = None
    ):
        """Initialize connection error.

        Args:
            backend_path: Path to backend module
            python_executable: Python interpreter path
            error_details: Additional error details
        """
        self.backend_path = backend_path
        self.python_executable = python_executable
        self.error_details = error_details

        message = f"Failed to connect to backend '{backend_path}' using Python '{python_executable}'"
        if error_details:
            message += f": {error_details}"

        suggestion = (
            "1. Verify the backend module is installed and accessible\n"
            "2. Check that the Python interpreter path is correct\n"
            "3. Ensure all backend dependencies are installed\n"
            "4. Try running the backend manually to check for errors"
        )

        super().__init__(message, suggestion)


class TimeoutError(BioSimulagentError):
    """Operation timed out.

    Raised when an operation exceeds its timeout duration.

    Attributes:
        operation: Name of the operation that timed out
        timeout_seconds: Timeout duration in seconds
    """

    def __init__(self, operation: str, timeout_seconds: float):
        """Initialize timeout error.

        Args:
            operation: Name of the operation
            timeout_seconds: Timeout duration
        """
        self.operation = operation
        self.timeout_seconds = timeout_seconds

        message = f"Operation '{operation}' timed out after {timeout_seconds}s"
        suggestion = (
            f"1. Increase the timeout using config (e.g., create_config(tool_timeout={int(timeout_seconds * 2)}))\n"
            "2. Check if the backend is responding (might be overloaded)\n"
            "3. Verify network connectivity if using remote backend"
        )

        super().__init__(message, suggestion)


class ToolExecutionError(BioSimulagentError):
    """MCP tool execution failed.

    Raised when an MCP tool execution fails on the backend.

    Attributes:
        tool_name: Name of the tool that failed
        error_code: Error code from the backend
        error_message: Detailed error message
        details: Additional error details
    """

    def __init__(
        self,
        tool_name: str,
        error_code: str,
        error_message: str,
        details: Optional[dict] = None,
    ):
        """Initialize tool execution error.

        Args:
            tool_name: Name of the failed tool
            error_code: Error code
            error_message: Error message
            details: Additional details
        """
        self.tool_name = tool_name
        self.error_code = error_code
        self.error_message = error_message
        self.details = details or {}

        message = f"Tool '{tool_name}' failed with error [{error_code}]: {error_message}"

        # Add details if available
        if self.details:
            details_str = "\n".join(f"  {k}: {v}" for k, v in self.details.items())
            message += f"\nDetails:\n{details_str}"

        suggestion = self._generate_suggestion()
        super().__init__(message, suggestion)

    def _generate_suggestion(self) -> str:
        """Generate contextual suggestion based on error code."""
        suggestions = {
            "INVALID_INPUT": "Check that all required parameters are provided with correct types",
            "NOT_FOUND": "Verify that the requested resource exists (e.g., article PMID, workflow ID)",
            "RATE_LIMIT": "Wait before retrying or reduce request frequency",
            "API_ERROR": "External API may be down; try again later or check API status",
            "PERMISSION_DENIED": "Check authentication credentials and access permissions",
            "INTERNAL_ERROR": "Backend encountered an error; check backend logs for details",
        }

        base_suggestion = suggestions.get(
            self.error_code,
            "Check the error message for details and verify input parameters"
        )

        return (
            f"{base_suggestion}\n"
            f"Tool: {self.tool_name}\n"
            f"Error Code: {self.error_code}"
        )


class ValidationError(BioSimulagentError):
    """Input validation failed.

    Raised when client-side input validation fails before making a request.

    Attributes:
        field_name: Name of the field that failed validation
        invalid_value: The invalid value provided
        constraints: Validation constraints that were violated
    """

    def __init__(
        self,
        field_name: str,
        invalid_value: any,
        constraints: Optional[List[str]] = None
    ):
        """Initialize validation error.

        Args:
            field_name: Name of invalid field
            invalid_value: The invalid value
            constraints: List of violated constraints
        """
        self.field_name = field_name
        self.invalid_value = invalid_value
        self.constraints = constraints or []

        message = f"Validation failed for '{field_name}': invalid value '{invalid_value}'"

        if self.constraints:
            constraints_str = "\n".join(f"  - {c}" for c in self.constraints)
            message += f"\nConstraints:\n{constraints_str}"

        suggestion = (
            f"Provide a valid value for '{field_name}' that meets the constraints"
        )

        super().__init__(message, suggestion)


class SubprocessCrashError(BioSimulagentError):
    """Backend subprocess crashed unexpectedly.

    Raised when the backend process terminates unexpectedly.

    Attributes:
        exit_code: Process exit code
        stderr_output: Contents of stderr at crash
        last_request: Last request made before crash (if available)
    """

    def __init__(
        self,
        exit_code: int,
        stderr_output: str,
        last_request: Optional[str] = None
    ):
        """Initialize subprocess crash error.

        Args:
            exit_code: Process exit code
            stderr_output: stderr output
            last_request: Last request made
        """
        self.exit_code = exit_code
        self.stderr_output = stderr_output
        self.last_request = last_request

        message = f"Backend subprocess crashed with exit code {exit_code}"

        if stderr_output:
            # Show last 500 chars of stderr
            stderr_preview = stderr_output[-500:] if len(stderr_output) > 500 else stderr_output
            message += f"\n\nStderr output:\n{stderr_preview}"

        if last_request:
            message += f"\n\nLast request: {last_request}"

        suggestion = (
            "1. Check backend logs for detailed error information\n"
            "2. Verify all backend dependencies are correctly installed\n"
            "3. Try restarting the client and backend\n"
            "4. If the issue persists, report it with the stderr output"
        )

        super().__init__(message, suggestion)
