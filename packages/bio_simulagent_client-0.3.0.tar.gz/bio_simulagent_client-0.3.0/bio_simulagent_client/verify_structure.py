"""Verify package structure is correct."""
import sys
import importlib.util

def check_module(module_path, module_name):
    """Check if a module can be loaded."""
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec and spec.loader:
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
            print(f"✓ {module_name} loads successfully")
            return True
        except Exception as e:
            print(f"✗ {module_name} failed to load: {e}")
            return False
    return False

modules = [
    ("bio_simulagent_client/exceptions.py", "exceptions"),
    ("bio_simulagent_client/types.py", "types"),
    ("bio_simulagent_client/_internal/subprocess_manager.py", "subprocess_manager"),
    ("bio_simulagent_client/_internal/mcp_protocol.py", "mcp_protocol"),
    ("bio_simulagent_client/tools/literature.py", "literature"),
    ("bio_simulagent_client/tools/simulation.py", "simulation"),
    ("bio_simulagent_client/tools/design.py", "design"),
    ("bio_simulagent_client/tools/neural.py", "neural"),
    ("bio_simulagent_client/workflows.py", "workflows"),
    ("bio_simulagent_client/client.py", "client"),
]

print("Verifying package structure...\n")

success_count = 0
for module_path, module_name in modules:
    if check_module(module_path, module_name):
        success_count += 1

print(f"\n{success_count}/{len(modules)} modules loaded successfully")

if success_count == len(modules):
    print("\n✓ Package structure is correct!")
    sys.exit(0)
else:
    print("\n✗ Some modules failed to load")
    sys.exit(1)
