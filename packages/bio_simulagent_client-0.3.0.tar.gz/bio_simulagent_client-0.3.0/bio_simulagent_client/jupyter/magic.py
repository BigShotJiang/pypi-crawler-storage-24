"""IPython magic commands for BioSimulagent.

This module provides magic commands for convenient use in Jupyter notebooks:
- %bio_connect: Connect to backend
- %%bio_workflow: Execute workflow in cell
- %bio_status: Show connection status
- %bio_close: Close connection
"""
import asyncio
from typing import Optional
from IPython.core.magic import Magics, magics_class, line_magic, cell_magic
from IPython.core.magic_arguments import (
    argument,
    magic_arguments,
    parse_argstring,
)
from IPython.display import display, Markdown, HTML

from ..client import BioSimulagent
from ..config import ClientConfig, create_config


@magics_class
class BioSimulagentMagics(Magics):
    """IPython magic commands for BioSimulagent.

    Provides convenient magic commands for connecting to the backend,
    executing workflows, and managing the client lifecycle in Jupyter notebooks.

    Attributes:
        client: Active BioSimulagent client instance (None if not connected)
        config: Client configuration
    """

    def __init__(self, shell):
        """Initialize magic commands.

        Args:
            shell: IPython shell instance
        """
        super().__init__(shell)
        self.client: Optional[BioSimulagent] = None
        self.config: Optional[ClientConfig] = None

    @line_magic
    @magic_arguments()
    @argument(
        "--backend",
        "-b",
        type=str,
        default="backend.main",
        help="Backend module path (default: backend.main)",
    )
    @argument(
        "--python",
        "-p",
        type=str,
        default=None,
        help="Python executable path (default: auto-detect)",
    )
    @argument(
        "--timeout",
        "-t",
        type=int,
        default=30,
        help="Connection timeout in seconds (default: 30)",
    )
    def bio_connect(self, line):
        """Connect to BioSimulagent backend.

        Usage:
            %bio_connect
            %bio_connect --backend custom.backend
            %bio_connect --python /path/to/python --timeout 60

        Example:
            >>> %bio_connect
            ✓ Connected to bio-simulagent backend (v0.2.0)
        """
        args = parse_argstring(self.bio_connect, line)

        async def _connect():
            if self.client is not None:
                display(Markdown("⚠️ Already connected. Use `%bio_close` to disconnect first."))
                return

            # Create config
            self.config = create_config(
                backend_path=args.backend,
                python_executable=args.python,
                connection_timeout=args.timeout,
            )

            # Connect
            try:
                display(Markdown(f"🔄 Connecting to backend `{args.backend}`..."))
                self.client = await BioSimulagent.connect(
                    backend_path=self.config.backend_path,
                    python_executable=self.config.python_executable,
                    timeout=self.config.connection_timeout,
                )

                # Get backend info
                display(Markdown(
                    f"✅ **Connected to BioSimulagent**\n"
                    f"- Backend: `{args.backend}`\n"
                    f"- Python: `{self.config.python_executable or 'auto-detected'}`\n"
                    f"- Client Version: `0.2.0`"
                ))

                # Store client in IPython namespace
                self.shell.user_ns['bio_client'] = self.client

            except Exception as e:
                display(Markdown(f"❌ **Connection failed**: {str(e)}"))
                self.client = None

        # Run async function
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # In Jupyter, loop is already running
            import nest_asyncio
            nest_asyncio.apply()

        asyncio.run(_connect())

    @line_magic
    def bio_close(self, line):
        """Close connection to backend.

        Usage:
            %bio_close

        Example:
            >>> %bio_close
            ✓ Connection closed
        """
        async def _close():
            if self.client is None:
                display(Markdown("⚠️ No active connection."))
                return

            try:
                await self.client.close()
                self.client = None
                self.config = None

                # Remove from IPython namespace
                if 'bio_client' in self.shell.user_ns:
                    del self.shell.user_ns['bio_client']

                display(Markdown("✅ **Connection closed**"))

            except Exception as e:
                display(Markdown(f"❌ **Error closing connection**: {str(e)}"))

        asyncio.run(_close())

    @line_magic
    def bio_status(self, line):
        """Show connection status and backend information.

        Usage:
            %bio_status

        Example:
            >>> %bio_status
            ✓ Connected (19 tools available)
        """
        if self.client is None:
            display(Markdown("❌ **Not connected**\n\nUse `%bio_connect` to connect."))
            return

        # Check if connection is alive
        is_connected = self.client.is_connected()

        if is_connected:
            display(Markdown(
                "✅ **Connected to BioSimulagent**\n\n"
                f"**Configuration:**\n"
                f"- Backend: `{self.config.backend_path}`\n"
                f"- Tool Timeout: `{self.config.tool_timeout}s`\n"
                f"- Workflow Poll Interval: `{self.config.workflow_poll_interval}s`\n\n"
                f"**Available Tools:**\n"
                f"- Literature: `bio_client.literature` (4 methods)\n"
                f"- Simulation: `bio_client.simulation` (4 methods)\n"
                f"- Design: `bio_client.design` (6 methods)\n"
                f"- Neural: `bio_client.neural` (5 methods)\n"
                f"- Workflow: `bio_client.workflow` (4 methods)\n\n"
                f"**Total**: 23 tool methods + 4 workflows"
            ))
        else:
            display(Markdown(
                "⚠️ **Connection lost**\n\n"
                "Backend subprocess is not responding. Use `%bio_close` and reconnect."
            ))

    @cell_magic
    @magic_arguments()
    @argument(
        "workflow_name",
        type=str,
        help="Workflow name (ligand_optimization, md_simulation, bbb_prediction, drug_discovery)",
    )
    @argument(
        "--params",
        "-p",
        type=str,
        default="{}",
        help="Workflow parameters as JSON string (default: {})",
    )
    @argument(
        "--poll",
        type=float,
        default=2.0,
        help="Status poll interval in seconds (default: 2.0)",
    )
    def bio_workflow(self, line, cell):
        """Execute workflow with progress tracking.

        The cell content is used as the workflow objective.

        Usage:
            %%bio_workflow ligand_optimization --params '{"target": "EGFR"}'
            Design a high-affinity EGFR inhibitor with good drug-like properties

        Example:
            >>> %%bio_workflow ligand_optimization
            >>> Optimize ligand for EGFR target
            🔄 Starting workflow...
            ✓ Step 1/4: Literature search (15s)
            ✓ Step 2/4: Ligand design (45s)
            ...
        """
        args = parse_argstring(self.bio_workflow, line)
        objective = cell.strip()

        async def _run_workflow():
            if self.client is None:
                display(Markdown("❌ **Not connected**. Use `%bio_connect` first."))
                return

            try:
                # Parse parameters
                import json
                params = json.loads(args.params) if args.params else {}

                display(Markdown(
                    f"🔄 **Starting Workflow**: `{args.workflow_name}`\n\n"
                    f"**Objective:** {objective}\n\n"
                    f"**Parameters:** `{params}`"
                ))

                # Progress callback
                from IPython.display import clear_output

                def on_progress(step):
                    display(Markdown(
                        f"⏳ **Step {step.name}**: {step.status}"
                    ))

                # Execute workflow
                result = await self.client.workflow.run(
                    name=args.workflow_name,
                    objective=objective,
                    params=params,
                    on_progress=on_progress,
                    poll_interval=args.poll,
                )

                # Display result
                if result.status == "completed":
                    display(Markdown(
                        f"✅ **Workflow Completed** ({result.workflow_id})\n\n"
                        f"**Duration:** {result.completed_at}\n\n"
                        f"**Steps:** {len(result.steps)}\n\n"
                        f"**Result:**"
                    ))
                    display(result.output)
                elif result.status == "failed":
                    display(Markdown(
                        f"❌ **Workflow Failed** ({result.workflow_id})\n\n"
                        f"Check workflow steps for error details."
                    ))
                else:
                    display(Markdown(
                        f"⚠️ **Workflow Status**: {result.status} ({result.workflow_id})"
                    ))

                # Store result in namespace
                self.shell.user_ns['bio_workflow_result'] = result

            except Exception as e:
                display(Markdown(f"❌ **Workflow execution failed**: {str(e)}"))

        asyncio.run(_run_workflow())


def load_ipython_extension(ipython):
    """Load IPython extension.

    Args:
        ipython: IPython instance

    Usage:
        %load_ext bio_simulagent_client.jupyter.magic
    """
    ipython.register_magics(BioSimulagentMagics)
