"""Jupyter notebook integration for BioSimulagent.

This package provides:
- Magic commands for convenient notebook interaction
- Visualization helpers for molecular structures and trajectories
- Display utilities for results and progress tracking

Usage:
    # Load magic commands
    %load_ext bio_simulagent_client.jupyter.magic

    # Connect to backend
    %bio_connect

    # Run workflow
    %%bio_workflow ligand_optimization
    Design EGFR inhibitor
"""

# Optional import - only available when IPython is installed
try:
    from .magic import BioSimulagentMagics, load_ipython_extension
    __all__ = ["BioSimulagentMagics", "load_ipython_extension"]
except ImportError:
    # IPython not installed - jupyter features not available
    # Install with: pip install bio-simulagent-client[jupyter]
    __all__ = []
