"""Visualization helpers for Jupyter notebooks.

This module provides visualization utilities for molecular structures,
MD trajectories, and analysis results using NGL Viewer, MDTraj, and Plotly.
"""
from typing import Optional, List, Dict, Any, Union
from pathlib import Path

try:
    import nglview as nv
    HAS_NGLVIEW = True
except ImportError:
    HAS_NGLVIEW = False

try:
    import mdtraj as md
    HAS_MDTRAJ = True
except ImportError:
    HAS_MDTRAJ = False

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

from IPython.display import display, HTML, Markdown


def show_structure(
    structure: Union[str, Path],
    representation: str = "cartoon",
    color_scheme: str = "chainid",
    width: str = "100%",
    height: str = "600px",
) -> Optional[Any]:
    """Display 3D molecular structure using NGL Viewer.

    Args:
        structure: Path to PDB/CIF file or structure data
        representation: Representation style (cartoon, ball+stick, surface, ribbon)
        color_scheme: Coloring scheme (chainid, residueindex, element, sstruc)
        width: Viewer width (default: 100%)
        height: Viewer height (default: 600px)

    Returns:
        NGLWidget viewer instance or None if nglview not available

    Example:
        >>> # Display protein structure
        >>> show_structure("protein.pdb", representation="cartoon")

        >>> # Display ligand
        >>> show_structure("ligand.sdf", representation="ball+stick", color_scheme="element")

    Raises:
        ImportError: If nglview is not installed
        FileNotFoundError: If structure file doesn't exist
    """
    if not HAS_NGLVIEW:
        display(Markdown(
            "❌ **nglview not installed**\n\n"
            "Install with: `pip install nglview`"
        ))
        return None

    try:
        # Load structure
        if isinstance(structure, (str, Path)):
            structure_path = Path(structure)
            if not structure_path.exists():
                raise FileNotFoundError(f"Structure file not found: {structure}")

            view = nv.show_file(str(structure_path))
        else:
            # Assume it's already a structure object
            view = nv.show_structure_file(structure)

        # Clear default representations
        view.clear_representations()

        # Add custom representation
        view.add_representation(representation, color_scheme=color_scheme)

        # Set viewer size
        view._remote_call('setSize', target='Widget', args=[width, height])

        # Center and zoom
        view.center()

        display(Markdown(f"**3D Structure Viewer** ({representation}, {color_scheme})"))
        return view

    except Exception as e:
        display(Markdown(f"❌ **Error displaying structure**: {str(e)}"))
        return None


def show_trajectory(
    trajectory: Union[str, Path],
    topology: Union[str, Path],
    frame: Optional[int] = None,
    representation: str = "cartoon",
    color_scheme: str = "residueindex",
    width: str = "100%",
    height: str = "600px",
) -> Optional[Any]:
    """Display MD trajectory using NGL Viewer and MDTraj.

    Args:
        trajectory: Path to trajectory file (DCD, XTC, TRR, etc.)
        topology: Path to topology file (PDB, GRO, etc.)
        frame: Specific frame to display (None for all frames)
        representation: Representation style
        color_scheme: Coloring scheme
        width: Viewer width
        height: Viewer height

    Returns:
        NGLWidget viewer instance or None if dependencies not available

    Example:
        >>> # Show trajectory
        >>> show_trajectory("trajectory.dcd", "topology.pdb")

        >>> # Show specific frame
        >>> show_trajectory("trajectory.dcd", "topology.pdb", frame=100)

    Raises:
        ImportError: If nglview or mdtraj not installed
        FileNotFoundError: If trajectory or topology file doesn't exist
    """
    if not HAS_NGLVIEW:
        display(Markdown(
            "❌ **nglview not installed**\n\n"
            "Install with: `pip install nglview`"
        ))
        return None

    if not HAS_MDTRAJ:
        display(Markdown(
            "❌ **mdtraj not installed**\n\n"
            "Install with: `pip install mdtraj`"
        ))
        return None

    try:
        # Load trajectory
        traj_path = Path(trajectory)
        top_path = Path(topology)

        if not traj_path.exists():
            raise FileNotFoundError(f"Trajectory file not found: {trajectory}")
        if not top_path.exists():
            raise FileNotFoundError(f"Topology file not found: {topology}")

        traj = md.load(str(traj_path), top=str(top_path))

        # Extract specific frame if requested
        if frame is not None:
            if frame < 0 or frame >= traj.n_frames:
                raise ValueError(f"Frame {frame} out of range (0-{traj.n_frames-1})")
            traj = traj[frame]

        # Create NGL view
        view = nv.show_mdtraj(traj)

        # Clear and set representation
        view.clear_representations()
        view.add_representation(representation, color_scheme=color_scheme)

        # Set viewer size
        view._remote_call('setSize', target='Widget', args=[width, height])

        # Center
        view.center()

        frame_info = f"frame {frame}" if frame is not None else f"{traj.n_frames} frames"
        display(Markdown(
            f"**MD Trajectory Viewer** ({frame_info})\n\n"
            f"- Trajectory: `{traj_path.name}`\n"
            f"- Topology: `{top_path.name}`\n"
            f"- Atoms: {traj.n_atoms}\n"
            f"- Representation: {representation}"
        ))

        return view

    except Exception as e:
        display(Markdown(f"❌ **Error displaying trajectory**: {str(e)}"))
        return None


def plot_binding_affinity(
    data: Union[List[float], Dict[str, List[float]]],
    labels: Optional[List[str]] = None,
    title: str = "Binding Affinity",
    ylabel: str = "ΔG (kcal/mol)",
    xlabel: str = "Frame / Compound",
    show_std: bool = True,
    width: int = 800,
    height: int = 500,
) -> Optional[Any]:
    """Plot binding affinity data using Plotly.

    Args:
        data: Binding affinity values (list) or multiple series (dict)
        labels: Labels for data points
        title: Plot title
        ylabel: Y-axis label
        xlabel: X-axis label
        show_std: Show standard deviation bands (if dict with multiple runs)
        width: Plot width in pixels
        height: Plot height in pixels

    Returns:
        Plotly Figure object or None if plotly not available

    Example:
        >>> # Single series
        >>> plot_binding_affinity([-8.5, -9.2, -8.8, -9.5])

        >>> # Multiple compounds
        >>> data = {
        ...     "Compound A": [-8.5, -8.3, -8.7],
        ...     "Compound B": [-9.2, -9.0, -9.4],
        ... }
        >>> plot_binding_affinity(data)

    Raises:
        ImportError: If plotly not installed
    """
    if not HAS_PLOTLY:
        display(Markdown(
            "❌ **plotly not installed**\n\n"
            "Install with: `pip install plotly`"
        ))
        return None

    try:
        fig = go.Figure()

        # Handle single list
        if isinstance(data, list):
            x_vals = labels if labels else list(range(len(data)))
            fig.add_trace(go.Scatter(
                x=x_vals,
                y=data,
                mode='lines+markers',
                name='Binding Affinity',
                line=dict(width=2),
                marker=dict(size=8),
            ))

        # Handle dictionary of series
        elif isinstance(data, dict):
            import numpy as np

            for series_name, values in data.items():
                x_vals = labels if labels else list(range(len(values)))

                # If values is 2D (multiple runs), show mean and std
                if isinstance(values[0], (list, tuple)):
                    values_array = np.array(values)
                    mean_vals = np.mean(values_array, axis=1)
                    std_vals = np.std(values_array, axis=1)

                    # Mean line
                    fig.add_trace(go.Scatter(
                        x=x_vals,
                        y=mean_vals,
                        mode='lines+markers',
                        name=series_name,
                        line=dict(width=2),
                        marker=dict(size=8),
                    ))

                    # Standard deviation band
                    if show_std:
                        fig.add_trace(go.Scatter(
                            x=x_vals + x_vals[::-1],
                            y=list(mean_vals + std_vals) + list((mean_vals - std_vals)[::-1]),
                            fill='toself',
                            fillcolor='rgba(0,100,200,0.2)',
                            line=dict(color='rgba(255,255,255,0)'),
                            showlegend=False,
                            name=f'{series_name} ±std',
                        ))
                else:
                    # Simple line
                    fig.add_trace(go.Scatter(
                        x=x_vals,
                        y=values,
                        mode='lines+markers',
                        name=series_name,
                        line=dict(width=2),
                        marker=dict(size=8),
                    ))

        # Update layout
        fig.update_layout(
            title=title,
            xaxis_title=xlabel,
            yaxis_title=ylabel,
            width=width,
            height=height,
            hovermode='x unified',
            template='plotly_white',
            legend=dict(
                yanchor="top",
                y=0.99,
                xanchor="right",
                x=0.99
            )
        )

        # Add horizontal line at y=0
        fig.add_hline(y=0, line_dash="dash", line_color="gray", opacity=0.5)

        fig.show()
        return fig

    except Exception as e:
        display(Markdown(f"❌ **Error plotting data**: {str(e)}"))
        return None


def plot_rmsd(
    rmsd_data: List[float],
    time_step: float = 1.0,
    title: str = "RMSD over Time",
    ylabel: str = "RMSD (Å)",
    xlabel: str = "Time (ns)",
    reference_line: Optional[float] = None,
    width: int = 800,
    height: int = 400,
) -> Optional[Any]:
    """Plot RMSD trajectory data.

    Args:
        rmsd_data: RMSD values over time
        time_step: Time step between frames in ns
        title: Plot title
        ylabel: Y-axis label
        xlabel: X-axis label
        reference_line: Optional reference RMSD line
        width: Plot width
        height: Plot height

    Returns:
        Plotly Figure object or None

    Example:
        >>> from bio_simulagent_client import TrajectoryAnalysis
        >>> analysis = TrajectoryAnalysis(...)
        >>> plot_rmsd(analysis.rmsd, time_step=0.002)
    """
    if not HAS_PLOTLY:
        display(Markdown("❌ **plotly not installed**"))
        return None

    try:
        import numpy as np

        time = np.arange(len(rmsd_data)) * time_step

        fig = go.Figure()

        # RMSD line
        fig.add_trace(go.Scatter(
            x=time,
            y=rmsd_data,
            mode='lines',
            name='RMSD',
            line=dict(color='blue', width=2),
        ))

        # Reference line
        if reference_line is not None:
            fig.add_hline(
                y=reference_line,
                line_dash="dash",
                line_color="red",
                annotation_text=f"Reference: {reference_line:.2f} Å",
            )

        # Layout
        fig.update_layout(
            title=title,
            xaxis_title=xlabel,
            yaxis_title=ylabel,
            width=width,
            height=height,
            template='plotly_white',
        )

        fig.show()
        return fig

    except Exception as e:
        display(Markdown(f"❌ **Error plotting RMSD**: {str(e)}"))
        return None


def plot_energy_landscape(
    x_values: List[float],
    y_values: List[float],
    z_values: List[float],
    title: str = "Energy Landscape",
    xlabel: str = "Coordinate 1",
    ylabel: str = "Coordinate 2",
    zlabel: str = "Energy (kcal/mol)",
    width: int = 800,
    height: int = 600,
) -> Optional[Any]:
    """Plot 3D energy landscape.

    Args:
        x_values: X coordinates
        y_values: Y coordinates
        z_values: Energy values
        title: Plot title
        xlabel: X-axis label
        ylabel: Y-axis label
        zlabel: Z-axis label (energy)
        width: Plot width
        height: Plot height

    Returns:
        Plotly Figure object or None

    Example:
        >>> plot_energy_landscape(pca1, pca2, energies)
    """
    if not HAS_PLOTLY:
        display(Markdown("❌ **plotly not installed**"))
        return None

    try:
        fig = go.Figure(data=[go.Surface(
            x=x_values,
            y=y_values,
            z=z_values,
            colorscale='Viridis',
            colorbar=dict(title=zlabel),
        )])

        fig.update_layout(
            title=title,
            scene=dict(
                xaxis_title=xlabel,
                yaxis_title=ylabel,
                zaxis_title=zlabel,
            ),
            width=width,
            height=height,
        )

        fig.show()
        return fig

    except Exception as e:
        display(Markdown(f"❌ **Error plotting energy landscape**: {str(e)}"))
        return None


# Check dependencies on import
def check_dependencies() -> None:
    """Check visualization dependencies and display status."""
    status = []

    if HAS_NGLVIEW:
        status.append("✅ nglview (molecular structures)")
    else:
        status.append("❌ nglview - install with `pip install nglview`")

    if HAS_MDTRAJ:
        status.append("✅ mdtraj (MD trajectories)")
    else:
        status.append("❌ mdtraj - install with `pip install mdtraj`")

    if HAS_PLOTLY:
        status.append("✅ plotly (data visualization)")
    else:
        status.append("❌ plotly - install with `pip install plotly`")

    display(Markdown(
        "**Visualization Dependencies:**\n\n" + "\n".join(f"- {s}" for s in status)
    ))
