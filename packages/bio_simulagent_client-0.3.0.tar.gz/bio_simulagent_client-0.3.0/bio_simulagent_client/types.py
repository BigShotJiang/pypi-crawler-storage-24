"""Type definitions for bio-simulagent-client."""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel
from enum import Enum


# Literature Types
class Article(BaseModel):
    """PubMed article result."""

    pmid: str
    title: str
    authors: List[str]
    abstract: str
    journal: str
    year: int
    doi: Optional[str] = None


class LiteratureSearchResult(BaseModel):
    """Literature search result."""

    query: str
    articles: List[Article]
    total_count: int
    search_time: float


# Workflow Types
class WorkflowStatus(str, Enum):
    """Workflow execution status."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class WorkflowStep(BaseModel):
    """Single workflow step."""

    name: str
    agent: str
    status: WorkflowStatus
    duration: Optional[float] = None
    error: Optional[str] = None


class WorkflowResult(BaseModel):
    """Workflow execution result."""

    workflow_id: str
    name: str
    status: WorkflowStatus
    steps: List[WorkflowStep]
    started_at: str
    completed_at: Optional[str] = None
    output: Dict[str, Any]


# Simulation Types
class SimulationResult(BaseModel):
    """MD simulation result."""

    trajectory_file: str
    topology_file: str
    total_energy: float
    rmsd: float
    duration: float


# Design Types
class MoleculeCandidate(BaseModel):
    """Designed molecule candidate."""

    smiles: str
    name: str
    score: float
    properties: Dict[str, Any]


class DesignResult(BaseModel):
    """Ligand design result."""

    candidates: List[MoleculeCandidate]
    design_time: float


# Neural Types
class CNSProfile(BaseModel):
    """CNS drug profile."""

    bbb_permeability: float
    neural_activity: Dict[str, Any]
    safety_score: float


class TrajectoryAnalysis(BaseModel):
    """MD trajectory analysis result."""

    rmsd: List[float]
    rmsf: List[float]
    hydrogen_bonds: Dict[str, Any]
    contacts: Dict[str, Any]
    energy: List[float]


class SimulationConfig(BaseModel):
    """MD simulation configuration."""

    temperature: float
    pressure: float
    duration_ns: float
    timestep_fs: float
    ensemble: str


class NeuralResult(BaseModel):
    """Neural modeling result."""

    activity: Dict[str, float]
    binding_sites: List[str]
    confidence: float
