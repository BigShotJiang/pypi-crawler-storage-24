"""Tests for component encoding and decoding."""

from pydantic import field_serializer
import pytest
import datetime
import logging
import zoneinfo
from typing import Optional, Union

from ical.component import ComponentModel
from ical.exceptions import CalendarParseError, ParameterValueError
from ical.parsing.component import ParsedComponent
from ical.parsing.property import ParsedProperty, ParsedPropertyParameter
from ical.types.data_types import serialize_field


def test_encode_component() -> None:
    """Test for a text property value."""

    class OtherComponent(ComponentModel):
        """Model used as a sub-component."""

        other_value: str
        second_value: Optional[str] = None

    class TestModel(ComponentModel):
        """Model with a Text value."""

        text_value: str
        repeated_text_value: list[str]
        some_component: list[OtherComponent]
        single_component: OtherComponent
        dt: datetime.datetime

        serialize_fields = field_serializer("*")(serialize_field)  # type: ignore[pydantic-field]

    model = TestModel.model_validate(
        {
            "text_value": "Example text",
            "repeated_text_value": ["a", "b", "c"],
            "some_component": [
                {"other_value": "value1", "second_value": "valuez"},
                {"other_value": "value2"},
            ],
            "single_component": {
                "other_value": "value3",
            },
            "dt": [ParsedProperty(name="dt", value="20220724T120000")],
        }
    )
    component = model.__encode_component_root__()
    assert component.name == "TestModel"
    assert component.properties == [
        ParsedProperty(name="text_value", value="Example text"),
        ParsedProperty(name="repeated_text_value", value="a"),
        ParsedProperty(name="repeated_text_value", value="b"),
        ParsedProperty(name="repeated_text_value", value="c"),
        ParsedProperty(name="dt", value="20220724T120000"),
    ]
    assert component.components == [
        ParsedComponent(
            name="some_component",
            properties=[
                ParsedProperty(name="other_value", value="value1"),
                ParsedProperty(name="second_value", value="valuez"),
            ],
        ),
        ParsedComponent(
            name="some_component",
            properties=[
                ParsedProperty(name="other_value", value="value2"),
            ],
        ),
        ParsedComponent(
            name="single_component",
            properties=[
                ParsedProperty(name="other_value", value="value3"),
            ],
        ),
    ]


def test_list_parser() -> None:
    """Test for a repeated property value."""

    class TestModel(ComponentModel):
        """Model under test."""

        dt: list[datetime.datetime]

    model = TestModel.model_validate(
        {
            "dt": [
                ParsedProperty(name="dt", value="20220724T120000"),
                ParsedProperty(name="dt", value="20220725T130000"),
            ],
        }
    )
    assert model.dt == [
        datetime.datetime(2022, 7, 24, 12, 0, 0),
        datetime.datetime(2022, 7, 25, 13, 0, 0),
    ]


def test_list_union_parser() -> None:
    """Test for a repeated union value."""

    class TestModel(ComponentModel):
        """Model under test."""

        dt: list[Union[datetime.datetime, datetime.date]]

    model = TestModel.model_validate(
        {
            "dt": [
                ParsedProperty(name="dt", value="20220724T120000"),
                ParsedProperty(name="dt", value="20220725"),
            ],
        }
    )
    assert model.dt == [
        datetime.datetime(2022, 7, 24, 12, 0, 0),
        datetime.date(2022, 7, 25),
    ]


def test_optional_field_parser() -> None:
    """Test for an optional field parser."""

    class TestModel(ComponentModel):
        """Model under test."""

        dt: Optional[datetime.datetime] = None

    model = TestModel.model_validate(
        {"dt": [ParsedProperty(name="dt", value="20220724T120000")]}
    )
    assert model.dt == datetime.datetime(2022, 7, 24, 12, 0, 0)


def test_union_parser() -> None:
    """Test for a union value."""

    class TestModel(ComponentModel):
        """Model under test."""

        dt: Union[datetime.datetime, datetime.date]

    with pytest.raises(CalendarParseError, match=".*Expected one value for field: dt"):
        model = TestModel.model_validate(
            {
                "dt": [
                    ParsedProperty(name="dt", value="20220724T120000"),
                    ParsedProperty(name="dt", value="20220725"),
                ],
            },
        )

    model = TestModel.model_validate(
        {
            "dt": [
                ParsedProperty(name="dt", value="20220724T120000"),
            ],
        }
    )
    assert model.dt == datetime.datetime(2022, 7, 24, 12, 0, 0)

    model = TestModel.model_validate(
        {
            "dt": [
                ParsedProperty(name="dt", value="20220725"),
            ],
        }
    )
    assert model.dt == datetime.date(2022, 7, 25)

    model = TestModel.model_validate(
        {
            "dt": [
                ParsedProperty(
                    name="dt",
                    value="20220724T120000",
                    params=[ParsedPropertyParameter("TZID", ["America/New_York"])],
                ),
            ],
        }
    )
    assert model.dt == datetime.datetime(
        2022, 7, 24, 12, 0, 0, tzinfo=zoneinfo.ZoneInfo(key="America/New_York")
    )
    assert model.dt != datetime.datetime(2022, 7, 24, 12, 0, 0)

    with pytest.raises(
        CalendarParseError,
        match="Expected DATE-TIME TZID value 'America/New_Mork' to be valid timezone.*",
    ):
        model = TestModel.model_validate(
            {
                "dt": [
                    ParsedProperty(
                        name="dt",
                        value="20220724T120000",
                        params=[ParsedPropertyParameter("TZID", ["America/New_Mork"])],
                    ),
                ],
            }
        )

    with pytest.raises(
        CalendarParseError,
        match=".*Failed to validate: .* as datetime or date, due to: .*Expected value to match DATE-TIME pattern: .*Expected value to match DATE pattern: .*",
    ):
        model = TestModel.model_validate(
            {
                "dt": [
                    ParsedProperty(name="dt", value="2025NotADateOrADateTime"),
                ],
            }
        )


def test_unknown_value_type_proton_mail_example() -> None:
    """Test the real-world Proton Mail example from issue #567."""

    class TestModel(ComponentModel):
        """Model under test."""

        summary: str

    # Use the actual failing case from Proton Mail
    model = TestModel.model_validate(
        {
            "summary": [
                ParsedProperty(
                    name="summary",
                    value="IBE150 NAME NAMESON\\n A285\\n",
                    params=[
                        ParsedPropertyParameter(
                            "VALUE", ["IBE150 NAME NAMESON^n A285^n"]
                        )
                    ],
                ),
            ],
        }
    )
    assert model.summary == "IBE150 NAME NAMESON\n A285\n"


def test_multiple_unknown_value_types() -> None:
    """Test handling of multiple properties with unknown VALUE types."""

    class TestModel(ComponentModel):
        """Model under test."""

        summary: str
        description: str

    model = TestModel.model_validate(
        {
            "summary": [
                ParsedProperty(
                    name="summary",
                    value="Test summary",
                    params=[ParsedPropertyParameter("VALUE", ["CUSTOM-TYPE-1"])],
                ),
            ],
            "description": [
                ParsedProperty(
                    name="description",
                    value="Test description",
                    params=[ParsedPropertyParameter("VALUE", ["CUSTOM-TYPE-2"])],
                ),
            ],
        }
    )
    assert model.summary == "Test summary"
    assert model.description == "Test description"


def test_unknown_value_type_text_escaping() -> None:
    """Test that TEXT escape sequences are properly handled in fallback."""

    class TestModel(ComponentModel):
        """Model under test."""

        summary: str

    model = TestModel.model_validate(
        {
            "summary": [
                ParsedProperty(
                    name="summary",
                    value="Line 1\\nLine 2\\;semicolon\\,comma\\\\backslash",
                    params=[ParsedPropertyParameter("VALUE", ["X-CUSTOM"])],
                ),
            ],
        }
    )
    assert model.summary == "Line 1\nLine 2;semicolon,comma\\backslash"


def test_unknown_value_type_warning_logged(caplog) -> None:
    """Test that a warning is logged when encountering unknown VALUE types."""

    class TestModel(ComponentModel):
        """Model under test."""

        summary: str

    with caplog.at_level(logging.DEBUG):
        model = TestModel.model_validate(
            {
                "summary": [
                    ParsedProperty(
                        name="summary",
                        value="Test",
                        params=[ParsedPropertyParameter("VALUE", ["UNKNOWN-TYPE"])],
                    ),
                ],
            }
        )

    assert model.summary == "Test"
    # Check that debug log was logged
    assert any(
        "unsupported VALUE type" in record.message and "UNKNOWN-TYPE" in record.message
        for record in caplog.records
    )
    assert any("falling back to TEXT" in record.message for record in caplog.records)
