"""
The module computes ETAs predictability through one single indicator that ranges from 0 to 1.
"""
