"""
Module to compute predictability, as one single indicator ranging from 0 to 1 to measure how projections effectively anticipated executions.

Predictability can be computed for:
- ETAs
- Budgets
- Scopes
- Etc.
"""
