"""
Retrieve issues from Jira.
"""
