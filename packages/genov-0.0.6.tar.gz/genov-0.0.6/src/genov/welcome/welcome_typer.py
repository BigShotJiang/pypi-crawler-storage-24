"""
A simple and vanilla command to welcome users through a Typer command.
"""

import typer
from rich import print as rich_print
from rich.console import Console
from rich.panel import Panel
from rich.tree import Tree

from genov.welcome.welcome import welcome


def welcome_typer(name: str):
    """
    The command welcomes to the Genovation toolbox!
    This command will greet NAME, and return welcome message.
    It experiments the rich library that can be used across other commands.
    """

    # Typer.secho function...
    typer.secho("Welcome", blink=True, bold=True)

    # A panel: fit
    panel = Panel.fit("Just a panel", border_style="red")
    rich_print(panel)

    # Another panel
    rich_print(Panel(f"[bold red]Welcome![/bold red]\n[green]{welcome(name=name)}[/green]\nshooting! :boom:"))

    # A tree...
    root = Tree("[b green]Rich Tree", highlight=True, hide_root=True)
    node = root.add(":file_folder: Renderables", guide_style="red")
    node.add(":file_folder: [bold yellow]Atomic", guide_style="uu green")
    node.add(":file_folder: [bold magenta]Containers", guide_style="bold magenta")
    rich_print(Panel(root))

    # Error...
    err_console = Console(stderr=True)
    err_console.print("Here is something written to standard error")
