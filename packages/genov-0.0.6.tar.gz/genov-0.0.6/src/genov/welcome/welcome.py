"""
A simple and vanilla command to welcome users.
"""


def welcome(name: str) -> str:
    """
    Welcome to the Genovation toolbox!
    """
    return f"Welcome, dear '{name}', to the Genovation toolbox."
