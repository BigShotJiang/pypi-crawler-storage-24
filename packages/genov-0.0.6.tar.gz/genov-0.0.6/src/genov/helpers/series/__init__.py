"""
Helpers utilities used across the genov toolbox to manipulate Pandas Series.

Helpers could be:

- Utility to print a Series to stdout [NOT YET IMPLEMENTED]
- Utility to type a series
- Utility to export a Series as an MS Excel spreadsheet on the file system [NOT YET IMPLEMENTED]
- Etc.
"""
