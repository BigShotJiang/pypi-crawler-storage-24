// ============================================================================
// Snapshot - Copy code snapshot functionality
// ============================================================================

import { state } from './state.js';
import { getAllExcludedPaths } from './children-preview.js';
import { getAllExcludedFrontendPaths } from './frontend-preview.js';

let metricsRefreshTimer = null;
let metricsAbortController = null;
let metricsRequestSeq = 0;

function buildSnapshotRequestBody() {
    return {
        path: state.selectedFile._path,
        parent_depth: state.parentDepth,
        include_chain: state.includeChain,
        chain_length: state.chainLength > 0 ? state.chainLength : null,
        child_depth: state.childDepth,
        child_max_tokens: state.childMaxTokens,
        excluded_children: getAllExcludedPaths(),
        include_frontend: state.includeFrontend,
        excluded_frontend: getAllExcludedFrontendPaths(),
        extra_files: Array.from(state.extraFiles)
    };
}

function setSidebarSnapshotCounter(text, subtext = '', stateClass = '') {
    const valueEl = document.getElementById('sidebar-snapshot-tokens');
    const subEl = document.getElementById('sidebar-snapshot-meta');
    if (!valueEl || !subEl) return;

    valueEl.textContent = text;
    subEl.textContent = subtext;
    valueEl.classList.remove('loading', 'warning', 'danger');
    if (stateClass) valueEl.classList.add(stateClass);
}

function getCounterSeverity(tokens) {
    if (tokens >= 12000) return 'danger';
    if (tokens >= 8000) return 'warning';
    return '';
}

async function refreshSidebarSnapshotMetrics() {
    if (!state.selectedFile) {
        setSidebarSnapshotCounter('No file selected');
        return;
    }

    if (metricsAbortController) {
        metricsAbortController.abort();
    }

    metricsAbortController = new AbortController();
    const requestId = ++metricsRequestSeq;
    setSidebarSnapshotCounter('Calculating...', 'Using current snapshot selections', 'loading');

    try {
        const response = await fetch('/api/snapshot-metrics', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(buildSnapshotRequestBody()),
            signal: metricsAbortController.signal
        });
        const data = await response.json();
        if (requestId !== metricsRequestSeq) return;
        if (data.error || !data.metrics) {
            setSidebarSnapshotCounter('Unavailable', data.error || 'Failed to calculate snapshot tokens', 'danger');
            return;
        }

        const m = data.metrics;
        const tokenText = `~${(m.token_estimate || 0).toLocaleString()} tokens`;
        const metaText = `${m.total_files || 0} files | ${(m.total_lines || 0).toLocaleString()} lines`;
        setSidebarSnapshotCounter(tokenText, metaText, getCounterSeverity(m.token_estimate || 0));
    } catch (err) {
        if (err && err.name === 'AbortError') return;
        setSidebarSnapshotCounter('Unavailable', 'Snapshot metrics request failed', 'danger');
    }
}

export function scheduleSnapshotTokenRefresh(delayMs = 250) {
    if (metricsRefreshTimer) {
        clearTimeout(metricsRefreshTimer);
    }
    metricsRefreshTimer = setTimeout(() => {
        metricsRefreshTimer = null;
        refreshSidebarSnapshotMetrics();
    }, delayMs);
}

export function clearSnapshotTokenCounter() {
    if (metricsRefreshTimer) {
        clearTimeout(metricsRefreshTimer);
        metricsRefreshTimer = null;
    }
    if (metricsAbortController) {
        metricsAbortController.abort();
        metricsAbortController = null;
    }
    setSidebarSnapshotCounter('No file selected');
}

export function copySnapshot() {
    if (!state.selectedFile) return;

    const statusEl = document.getElementById('copy-status');
    const metricsEl = document.getElementById('copy-metrics');
    statusEl.textContent = 'Generating...';
    statusEl.classList.remove('error');
    statusEl.classList.add('visible');

    fetch('/api/copy-snapshot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildSnapshotRequestBody())
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            statusEl.textContent = data.error;
            statusEl.classList.add('error');
            return;
        }

        navigator.clipboard.writeText(data.content).then(() => {
            const m = data.metrics;
            metricsEl.textContent = `${m.total_files} files | ${m.total_lines} lines | ~${m.token_estimate.toLocaleString()} tokens`;
            setSidebarSnapshotCounter(
                `~${m.token_estimate.toLocaleString()} tokens`,
                `${m.total_files} files | ${m.total_lines.toLocaleString()} lines`,
                getCounterSeverity(m.token_estimate || 0)
            );
            statusEl.textContent = 'Copied!';
            setTimeout(() => statusEl.classList.remove('visible'), 2000);
        }).catch(err => {
            statusEl.textContent = 'Failed: ' + err;
            statusEl.classList.add('error');
        });
    })
    .catch(err => {
        statusEl.textContent = 'Error: ' + err;
        statusEl.classList.add('error');
    });
}

export function formatPath(pathArray) {
    return pathArray.map((p, i) => {
        const isLast = i === pathArray.length - 1;
        const cls = isLast ? 'current' : 'file';
        const arrow = i < pathArray.length - 1 ? '<span class="arrow">→</span>' : '';
        return `<span class="${cls}">${p.split('/').pop()}</span>${arrow}`;
    }).join('');
}

export function toggleChain() {
    state.includeChain = !state.includeChain;
    document.getElementById('toggle-chain').classList.toggle('active', state.includeChain);
    scheduleSnapshotTokenRefresh();
}

export async function generateSnapshotForChat() {
    if (!state.selectedFile) return null;

    try {
        const response = await fetch('/api/copy-snapshot', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(buildSnapshotRequestBody())
        });
        const data = await response.json();
        return data.content || null;
    } catch (e) {
        console.error('Failed to generate snapshot:', e);
        return null;
    }
}

// Make functions available globally for onclick handlers
window.copySnapshot = copySnapshot;
window.toggleChain = toggleChain;
window.scheduleSnapshotTokenRefresh = scheduleSnapshotTokenRefresh;
window.clearSnapshotTokenCounter = clearSnapshotTokenCounter;
