#!/usr/bin/env python3
"""Prism CLI — dependency scan, tree view, snapshot export, and web UI."""
import argparse
import sys
import time
from pathlib import Path
from collections import defaultdict, deque

DEFAULT_MAX_TOKENS = 800_000

MAP_STRATEGY_GUIDE = """
STRATEGY GUIDE — Using `prism map` for AI-assisted development
================================================================

Prism's `map` command sends a dependency snapshot (tree + source code) to
Claude Code as a sub-agent. Think of it as sending a drone up over the
codebase to gather intelligence before making decisions.

CORE IDEA:
  Prism traces every import from an entry point, builds a tree of all
  reachable files with their sizes, then bundles the actual source code.
  Claude reads it all in one shot and answers your questions.

WHEN TO USE IT:
  - Before writing a new feature (understand what exists, where to put it)
  - Before refactoring (map all the connections that will be affected)
  - Investigating a bug (trace the data flow end to end)
  - Onboarding to a codebase (get the bird's eye view)
  - Planning a PR (know the blast radius)

STRATEGIES:

  1. RECONNAISSANCE — Ask 10-20 questions in a single prompt:
     prism map main.py -q "Where is auth handled?" \\
       -q "What database ORM is used and where?" \\
       -q "How do API routes connect to business logic?" \\
       -q "What external services are called?" \\
       -q "Where would I add a new API endpoint?"

  2. FULL PROJECT MAP — Get a file-by-file breakdown:
     prism map main.py --include-map
     # Returns: what each file does, how they connect, data flows

  3. FOCUSED INVESTIGATION — Zoom into a specific area:
     prism map main.py --focus "authentication and session management" \\
       -q "What is the auth flow from login to session creation?" \\
       -q "How are tokens validated on each request?"

  4. CUSTOM MAP — Ask for a specific kind of map:
     prism map main.py --prompt "Generate an API endpoint reference: \\
       list every route, its HTTP method, auth requirements, and which \\
       service function it calls"

  5. PLANNING — Use it to plan before writing code:
     prism map main.py -q "I need to add WebSocket support for live \\
       notifications. Which files would I need to modify? What patterns \\
       does this codebase use for real-time features? Where should the \\
       WebSocket handler live? What existing infrastructure can I reuse?"

  6. FRONTEND + BACKEND — Include the full stack:
     prism map main.py --frontend -q "How does the frontend call the \\
       backend? What JS modules handle API communication?"

TIPS:
  - Use --max-tokens to control snapshot size (default 200k is good for
    most projects, increase for monorepos)
  - Use --print-only to preview what gets sent before calling Claude
  - Use -o to save the response for reference
  - Batch your questions — one map call with 15 questions is better than
    15 separate calls (Claude sees the full context each time)
  - Use --focus to steer Claude toward specific subsystems
  - The tree structure is ALWAYS included so Claude can see every file
    name and size even beyond the token limit of included source code
"""


def parse_args():
    p = argparse.ArgumentParser(
        prog="prism",
        description="Python dependency analyzer — scan, visualize, and export.",
    )
    sub = p.add_subparsers(dest="command")

    # --- scan ---
    scan_p = sub.add_parser("scan", help="Scan dependencies from an entry point.")
    scan_p.add_argument(
        "entry_point",
        help="Entry point file (e.g. backend/main.py). Absolute or relative to --project.",
    )
    scan_p.add_argument("-p", "--project", help="Project root directory. Default: auto-detected from .git.")
    scan_p.add_argument("-o", "--output", help="Write snapshot (code with separators) to this file.")
    scan_p.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS,
                        help=f"Max tokens for child dependencies. Default: {DEFAULT_MAX_TOKENS:,}.")
    scan_p.add_argument("--depth", type=int, default=0, help="Max child depth. 0 = unlimited BFS (default).")
    scan_p.add_argument("--parent-depth", type=int, default=1, help="Levels of parent (imported-by) files. Default: 1.")
    scan_p.add_argument("--frontend", action="store_true", help="Include frontend files (HTML/JS/CSS).")
    scan_p.add_argument("--no-tree", action="store_true", help="Skip the dependency tree printout.")
    scan_p.add_argument("--orphans", action="store_true", help="List orphan files.")
    scan_p.add_argument("--dry-run", action="store_true", help="Show full scan stats without writing output.")
    scan_p.add_argument("-q", "--quiet", action="store_true", help="Suppress tree/stats — only write output file.")
    scan_p.add_argument("-x", "--exclude", action="append", default=[], help="Exclude directory patterns (repeatable).")

    # --- map ---
    map_p = sub.add_parser(
        "map",
        help="Send a snapshot to Claude Code for analysis.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=MAP_STRATEGY_GUIDE,
    )
    map_p.add_argument(
        "entry_point",
        help="Entry point file (e.g. backend/main.py).",
    )
    map_p.add_argument("-p", "--project", help="Project root directory.")
    map_p.add_argument("--max-tokens", type=int, default=200_000,
                       help="Max tokens for snapshot source code. Default: 200,000.")
    map_p.add_argument("--depth", type=int, default=0, help="Max child depth. 0 = unlimited.")
    map_p.add_argument("--parent-depth", type=int, default=1, help="Parent depth. Default: 1.")
    map_p.add_argument("--frontend", action="store_true", help="Include frontend files.")
    map_p.add_argument("-x", "--exclude", action="append", default=[], help="Exclude patterns.")
    map_p.add_argument(
        "-q", "--questions", action="append", default=[],
        metavar="QUESTION",
        help="Questions to ask about the codebase (repeatable). "
             "e.g. -q 'Where is auth handled?' -q 'What ORM is used?'",
    )
    map_p.add_argument(
        "--include-map", action="store_true",
        help="Ask Claude to produce a full project map (file-by-file breakdown, "
             "architecture, data flows). Without this, Claude just answers your questions.",
    )
    map_p.add_argument(
        "--focus", default=None,
        help="Focus the analysis on a specific area. "
             "e.g. --focus 'authentication and session management'",
    )
    map_p.add_argument(
        "--prompt", default=None,
        help="Fully custom prompt (overrides --include-map, --questions, --focus).",
    )
    map_p.add_argument("-o", "--output", help="Save Claude's response to this file.")
    map_p.add_argument(
        "--print-only", action="store_true",
        help="Print the assembled prompt + snapshot without calling Claude.",
    )

    # --- diff ---
    diff_p = sub.add_parser(
        "diff",
        help="Compare a saved snapshot against current state — find what changed and what broke.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "WORKFLOW:\n"
            "  1. Before refactoring:  prism diff --save before.prism backend/main.py\n"
            "  2. Make your changes\n"
            "  3. After refactoring:   prism diff before.prism backend/main.py\n\n"
            "  Or use git to diff against a previous commit:\n"
            "  prism diff --git HEAD~1 backend/main.py\n"
        ),
    )
    diff_p.add_argument("baseline", nargs="?", default=None,
                         help="Baseline snapshot file (.prism). Not needed with --save or --git.")
    diff_p.add_argument("entry_point", help="Entry point file for the current snapshot.")
    diff_p.add_argument("-p", "--project", help="Project root directory.")
    diff_p.add_argument("--max-tokens", type=int, default=200_000, help="Max tokens per snapshot. Default: 200,000.")
    diff_p.add_argument("--depth", type=int, default=0, help="Max child depth. 0 = unlimited.")
    diff_p.add_argument("--parent-depth", type=int, default=1, help="Parent depth. Default: 1.")
    diff_p.add_argument("--frontend", action="store_true", help="Include frontend files.")
    diff_p.add_argument("-x", "--exclude", action="append", default=[], help="Exclude patterns.")
    diff_p.add_argument(
        "--save", metavar="FILE",
        help="Save the current snapshot to FILE instead of diffing. Use this to create the baseline.",
    )
    diff_p.add_argument(
        "--git", metavar="COMMIT",
        help="Use a git commit/ref as the baseline instead of a saved file. "
             "Checks out that ref in a temp worktree, snapshots it, then diffs.",
    )
    diff_p.add_argument(
        "-q", "--questions", action="append", default=[],
        metavar="QUESTION",
        help="Additional questions to ask about the diff (repeatable).",
    )
    diff_p.add_argument(
        "--prompt", default=None,
        help="Fully custom prompt (overrides default diff analysis).",
    )
    diff_p.add_argument("-o", "--output", help="Save Claude's response to this file.")
    diff_p.add_argument("--print-only", action="store_true", help="Print the payload without calling Claude.")

    # --- snap ---
    snap_p = sub.add_parser(
        "snap",
        help="Symbol-level snapshot — get a function/class and everything that touches it.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "EXAMPLES:\n"
            "  prism snap AuthManager                   # Find and snapshot a class\n"
            "  prism snap validate_token                # Find and snapshot a function\n"
            "  prism snap AuthManager.validate           # Snapshot a specific method\n"
            "  prism snap auth.py::AuthManager           # Disambiguate by file\n"
            "  prism snap AuthManager --impact           # Show blast radius only\n"
            "  prism snap AuthManager --callers          # Include caller source code\n"
            "  prism snap AuthManager -q 'Is this safe to refactor?'\n"
        ),
    )
    snap_p.add_argument("symbol", nargs="?", default=None,
                         help="Symbol to snapshot: ClassName, func_name, Class.method, or file::name")
    snap_p.add_argument("-p", "--project", help="Project root directory.")
    snap_p.add_argument("-x", "--exclude", action="append", default=[], help="Exclude patterns.")
    snap_p.add_argument("--impact", action="store_true",
                        help="Show impact summary only (no source code).")
    snap_p.add_argument("--callers", action="store_true",
                        help="Include full source code of all callers.")
    snap_p.add_argument("-o", "--output", help="Write snapshot to file.")
    snap_p.add_argument(
        "-q", "--questions", action="append", default=[],
        metavar="QUESTION",
        help="Send snapshot to Claude with questions (repeatable).",
    )
    snap_p.add_argument("--print-only", action="store_true",
                        help="Print the payload without calling Claude.")
    snap_p.add_argument("--list", action="store_true", dest="list_symbols",
                        help="List all symbols in the codebase.")

    # --- serve ---
    serve_p = sub.add_parser("serve", help="Start the Prism web UI.")
    serve_p.add_argument("--host", default="0.0.0.0", help="Host to bind to. Default: 0.0.0.0.")
    serve_p.add_argument("--port", type=int, default=5042, help="Port to serve on. Default: 5042.")
    serve_p.add_argument("--debug", action="store_true", help="Enable Flask debug mode.")

    # If first arg isn't a known subcommand, treat it as `scan <args>`
    if len(sys.argv) > 1 and sys.argv[1] not in ("scan", "serve", "map", "diff", "snap", "-h", "--help"):
        return scan_p.parse_args(sys.argv[1:])

    args = p.parse_args()

    if args.command is None:
        p.print_help()
        sys.exit(0)

    return args


def resolve_paths(args):
    """Figure out project root and relative entry point path."""
    ep_raw = Path(args.entry_point)

    if ep_raw.is_absolute():
        ep_abs = ep_raw.resolve()
        if args.project:
            project_root = Path(args.project).resolve()
        else:
            candidate = ep_abs.parent
            while candidate != candidate.parent:
                if (candidate / ".git").exists():
                    break
                candidate = candidate.parent
            else:
                candidate = ep_abs.parent
            project_root = candidate
        try:
            ep_rel = str(ep_abs.relative_to(project_root))
        except ValueError:
            print(f"Error: entry point {ep_abs} is not inside project root {project_root}", file=sys.stderr)
            sys.exit(1)
    else:
        project_root = Path(args.project).resolve() if args.project else Path.cwd().resolve()
        ep_rel = str(ep_raw)
        ep_abs = (project_root / ep_raw).resolve()

    if not ep_abs.exists():
        print(f"Error: entry point not found: {ep_abs}", file=sys.stderr)
        sys.exit(1)

    if not project_root.exists():
        print(f"Error: project root not found: {project_root}", file=sys.stderr)
        sys.exit(1)

    return project_root, ep_rel


def bfs_full(graph, root_node, include_frontend=False):
    """Full BFS with no limits. Returns list of (node, depth) tuples."""
    from prism.models import NodeType
    visited = {root_node.path}
    queue = deque([(root_node, 0)])
    result = []

    while queue:
        node, depth = queue.popleft()
        result.append((node, depth))

        children_paths = graph._forward_index.get(node.path, set())
        for cp in sorted(children_paths):
            cn = graph._nodes.get(cp)
            if cn and cn.path not in visited:
                if not include_frontend and cn.node_type not in (NodeType.PYTHON, NodeType.HTML):
                    continue
                visited.add(cn.path)
                queue.append((cn, depth + 1))

    return result


def build_tree_lines(graph, root_node, include_frontend=False, max_tokens=0, depth_limit=0):
    """BFS the graph and return (ordered_nodes, tree_display_lines, token_total)."""
    from prism.models import NodeType
    visited = {root_node.path}
    queue = deque([(root_node, 0)])
    levels = []

    while queue:
        node, depth = queue.popleft()
        if depth_limit > 0 and depth > depth_limit:
            continue

        children_paths = graph._forward_index.get(node.path, set())
        children = []
        for cp in sorted(children_paths):
            cn = graph._nodes.get(cp)
            if cn and cn.path not in visited:
                if not include_frontend and cn.node_type not in (NodeType.PYTHON, NodeType.HTML):
                    continue
                visited.add(cn.path)
                children.append(cn)

        levels.append((node, depth, children))

        for child in children:
            queue.append((child, depth + 1))

    lines = []
    nodes_ordered = []
    token_total = 0

    for node, depth, children in levels:
        if max_tokens > 0 and token_total + node.tokens > max_tokens and depth > 0:
            remaining_tokens = sum(
                n.tokens for n, d, _ in levels
                if n not in set(nodes_ordered) and n != levels[0][0]
            )
            remaining_files = len(levels) - len(nodes_ordered)
            lines.append(
                f"{'    ' * depth}... truncated ({remaining_files} more files, "
                f"~{remaining_tokens:,} more tokens exceed {max_tokens:,} limit)"
            )
            break

        token_total += node.tokens
        nodes_ordered.append(node)

        type_char = {
            NodeType.PYTHON: "py",
            NodeType.HTML: "html",
            NodeType.JAVASCRIPT: "js",
            NodeType.TYPESCRIPT: "ts",
            NodeType.CSS: "css",
        }.get(node.node_type, "?")

        indent = "    " * depth
        connector = "-> " if depth > 0 else ""
        meta = f"[{type_char}] {node.lines}L {node.tokens}tok"
        lines.append(f"{indent}{connector}{node.relative_path}  ({meta})")

    return nodes_ordered, lines, token_total


def build_full_tree_text(graph, root_node, include_frontend=False):
    """Build the complete BFS tree text (no token limit) for the map header."""
    from prism.models import NodeType
    all_nodes = bfs_full(graph, root_node, include_frontend)

    type_counts = defaultdict(int)
    total_tokens = 0
    total_lines = 0
    max_depth = 0

    lines = []
    for node, depth in all_nodes:
        type_char = {
            NodeType.PYTHON: "py",
            NodeType.HTML: "html",
            NodeType.JAVASCRIPT: "js",
            NodeType.TYPESCRIPT: "ts",
            NodeType.CSS: "css",
        }.get(node.node_type, "?")

        indent = "    " * depth
        connector = "-> " if depth > 0 else ""
        lines.append(f"{indent}{connector}{node.relative_path}  [{type_char}] {node.lines}L {node.tokens}tok")

        type_counts[node.node_type.value] += 1
        total_tokens += node.tokens
        total_lines += node.lines
        max_depth = max(max_depth, depth)

    types_str = ", ".join(f"{v} {k}" for k, v in sorted(type_counts.items(), key=lambda x: -x[1]))
    header = (
        f"DEPENDENCY TREE — {len(all_nodes)} files reachable, "
        f"{total_lines:,} lines, {total_tokens:,} tokens, "
        f"max depth {max_depth} ({types_str})"
    )

    return header + "\n" + "-" * len(header) + "\n" + "\n".join(lines)


def print_tree(lines, token_total, file=sys.stdout):
    print("\nDependency Tree (BFS):", file=file)
    print("-" * 60, file=file)
    for line in lines:
        print(line, file=file)
    print("-" * 60, file=file)
    print(f"Total tokens: {token_total:,}", file=file)


def print_dry_run(graph, root_node, include_frontend, max_tokens):
    """Print full scan overview: depth breakdown, totals, then what the cap keeps."""
    all_nodes = bfs_full(graph, root_node, include_frontend)

    depth_stats = defaultdict(lambda: {"files": 0, "tokens": 0, "lines": 0})
    type_counts = defaultdict(int)
    max_depth = 0

    for node, depth in all_nodes:
        depth_stats[depth]["files"] += 1
        depth_stats[depth]["tokens"] += node.tokens
        depth_stats[depth]["lines"] += node.lines
        type_counts[node.node_type.value] += 1
        max_depth = max(max_depth, depth)

    total_files = len(all_nodes)
    total_tokens = sum(d["tokens"] for d in depth_stats.values())
    total_lines = sum(d["lines"] for d in depth_stats.values())

    print("\n" + "=" * 64)
    print("  DRY RUN — Full Scan Overview")
    print("=" * 64)
    print(f"  Total reachable files:  {total_files}")
    print(f"  Total tokens:           {total_tokens:,}")
    print(f"  Total lines:            {total_lines:,}")
    print(f"  Max depth:              {max_depth}")
    types_str = ", ".join(f"{v} {k}" for k, v in sorted(type_counts.items(), key=lambda x: -x[1]))
    print(f"  Types:                  {types_str}")

    print(f"\n  {'Depth':<7} {'Files':>6} {'Tokens':>10} {'Lines':>8}  {'Cumulative Tokens':>18}")
    print("  " + "-" * 55)
    cumulative_tokens = 0
    for d in range(max_depth + 1):
        s = depth_stats[d]
        cumulative_tokens += s["tokens"]
        marker = ""
        if max_tokens > 0 and cumulative_tokens > max_tokens:
            prev_cum = cumulative_tokens - s["tokens"]
            if prev_cum <= max_tokens:
                marker = "  <-- cap hits here"
        print(f"  {d:<7} {s['files']:>6} {s['tokens']:>10,} {s['lines']:>8,}  {cumulative_tokens:>18,}{marker}")

    if max_tokens > 0:
        print(f"\n  Token cap: {max_tokens:,}")
        kept_files = 0
        kept_tokens = 0
        kept_lines = 0
        kept_max_depth = 0
        for node, depth in all_nodes:
            if kept_tokens + node.tokens > max_tokens and kept_files > 0:
                break
            kept_files += 1
            kept_tokens += node.tokens
            kept_lines += node.lines
            kept_max_depth = max(kept_max_depth, depth)

        cut_files = total_files - kept_files
        cut_tokens = total_tokens - kept_tokens

        print(f"  Keeping:  {kept_files} files, {kept_tokens:,} tokens, {kept_lines:,} lines (depth 0-{kept_max_depth})")
        print(f"  Cutting:  {cut_files} files, {cut_tokens:,} tokens")
        pct = (kept_tokens / total_tokens * 100) if total_tokens else 0
        print(f"  Coverage: {pct:.1f}% of reachable code")
    else:
        print(f"\n  No token cap — all {total_files} files included.")

    sorted_by_size = sorted(all_nodes, key=lambda x: -x[0].tokens)
    print(f"\n  Top 10 largest files:")
    for node, depth in sorted_by_size[:10]:
        print(f"    {node.tokens:>7,} tok  d{depth}  {node.relative_path}")

    print("=" * 64)


def write_snapshot(session, ep_rel, nodes, project_root, output_path, args):
    """Write the snapshot file using the same format as the web app."""
    from prism.models import SnapshotConfig

    config = SnapshotConfig(
        target_path=ep_rel,
        parent_depth=args.parent_depth,
        child_depth=args.depth if args.depth > 0 else 0,
        child_max_tokens=args.max_tokens,
        include_frontend=args.frontend,
    )

    result = session.create_snapshot(config)

    if "error" in result:
        print(f"Snapshot error: {result['error']}", file=sys.stderr)
        return False

    out = Path(output_path)
    out.write_text(result["content"], encoding="utf-8")

    metrics = result["metrics"]
    print(f"\nSnapshot written to: {out}")
    print(f"  Files: {metrics['total_files']}")
    print(f"  Lines: {metrics['total_lines']:,}")
    print(f"  Tokens: ~{metrics['token_estimate']:,}")

    return True


def build_map_prompt(args, tree_text):
    """Assemble the prompt for the map command from flags."""

    # If fully custom prompt, use it directly
    if args.prompt:
        return args.prompt

    parts = []

    # System context — always present
    parts.append(
        "You are analyzing a Python project's dependency snapshot generated by Prism.\n"
        "Below you will find:\n"
        "  1. The FULL DEPENDENCY TREE — every reachable file with its relative path,\n"
        "     type, line count, and token count (this covers the entire project scope)\n"
        "  2. The SOURCE CODE of files within the token budget\n\n"
        "The dependency tree shows the complete picture. The source code section may be\n"
        "truncated by a token limit, but the tree always shows ALL reachable files.\n"
        "Use the tree to understand scope and structure. Use the source code for details."
    )

    # Focus
    if args.focus:
        parts.append(
            f"\nFOCUS AREA: Concentrate your analysis on: {args.focus}\n"
            f"You may reference other parts of the codebase for context, but prioritize\n"
            f"depth of analysis in the focus area over breadth elsewhere."
        )

    # Include-map mode
    if args.include_map:
        parts.append(
            "\nGENERATE A PROJECT MAP with the following sections:\n"
            "1. HIGH-LEVEL OVERVIEW — What this project does in 2-3 sentences\n"
            "2. ARCHITECTURE DIAGRAM — ASCII art showing the main layers and data flow\n"
            "3. FILE-BY-FILE BREAKDOWN — For each file in the dependency tree:\n"
            "   - Its role and responsibility (1 line)\n"
            "   - Key functions/classes it exports\n"
            "   - What it depends on and what depends on it\n"
            "4. DATA FLOWS — Trace 2-3 key operations end-to-end through the codebase\n"
            "5. EXTERNAL INTEGRATIONS — APIs, databases, message queues, third-party services\n"
            "6. PATTERNS — Architectural patterns, conventions, notable design decisions\n\n"
            "Be specific — reference actual file names and function names from the code.\n"
            "Use the relative paths from the dependency tree."
        )

    # Questions
    if args.questions:
        parts.append("\nQUESTIONS — Answer each of these thoroughly:\n")
        for i, q in enumerate(args.questions, 1):
            parts.append(f"  {i}. {q}")
        parts.append(
            "\nFor each answer, reference specific files and functions from the snapshot.\n"
            "If a question requires information not in the snapshot, say so explicitly."
        )

    # If neither --include-map nor --questions, default to a project map
    if not args.include_map and not args.questions:
        parts.append(
            "\nGENERATE A PROJECT MAP that shows:\n"
            "1. A high-level architecture overview — what this project does\n"
            "2. The main layers/modules and their responsibilities\n"
            "3. How files connect: entry point -> routers/controllers -> services -> models -> utils\n"
            "4. Key data flows — how a request/action moves through the codebase\n"
            "5. External integrations (APIs, databases, message queues)\n"
            "6. Any notable patterns (dependency injection, event systems, plugin architectures)\n\n"
            "Format it as a clean, readable document with sections.\n"
            "Use indented trees or ASCII diagrams for the connection maps.\n"
            "Be specific — reference actual file names and function names from the code."
        )

    return "\n".join(parts)


def cmd_scan(args):
    """Handle the scan subcommand."""
    from prism.session import PrismSession

    project_root, ep_rel = resolve_paths(args)

    if not args.quiet:
        print(f"Project:     {project_root}")
        print(f"Entry point: {ep_rel}")

    t0 = time.perf_counter()
    session = PrismSession(str(project_root), exclude_patterns=args.exclude or None)
    session.scan(parallel=True)
    scan_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    trace = session.trace_from_entry_point(ep_rel)
    trace_ms = (time.perf_counter() - t0) * 1000

    if "error" in trace:
        print(f"Error: {trace['error']}", file=sys.stderr)
        sys.exit(1)

    connected = trace["total_connected"]

    type_counts = defaultdict(int)
    for f in trace["connected_files"]:
        type_counts[f["type"]] += 1

    if not args.quiet:
        types_str = ", ".join(f"{v} {k}" for k, v in sorted(type_counts.items(), key=lambda x: -x[1]))
        print(f"\nScan: {scan_ms:.0f}ms | Trace: {trace_ms:.0f}ms | {connected} files reachable ({types_str})")

    ep_path = (project_root / ep_rel).resolve()
    ep_node = session.graph.get_node(ep_path)

    if args.dry_run:
        print_dry_run(session.graph, ep_node, args.frontend, args.max_tokens)
        return

    if not args.no_tree and not args.quiet:
        nodes, tree_lines, token_total = build_tree_lines(
            session.graph, ep_node,
            include_frontend=args.frontend,
            max_tokens=args.max_tokens,
            depth_limit=args.depth,
        )
        print_tree(tree_lines, token_total)

    if args.orphans and not args.quiet:
        orphans = session.get_orphans([{"path": ep_rel, "label": "main"}])
        total = len(session.graph.get_nodes())
        print(f"\nOrphans: {orphans['total_orphans']}/{total} files ({orphans['orphan_rate']}%)")
        for o in sorted(orphans["orphans"], key=lambda x: x["relative_path"]):
            print(f"  {o['relative_path']}")

    if args.output:
        nodes, _, _ = build_tree_lines(
            session.graph, ep_node,
            include_frontend=args.frontend,
            max_tokens=args.max_tokens,
            depth_limit=args.depth,
        )
        write_snapshot(session, ep_rel, nodes, project_root, args.output, args)


def cmd_map(args):
    """Generate a project map by piping a Prism snapshot to Claude Code."""
    import shutil
    import subprocess
    import tempfile
    from prism.session import PrismSession
    from prism.models import SnapshotConfig

    # Check claude is available
    claude_bin = shutil.which("claude")
    if not claude_bin and not args.print_only:
        print("Error: 'claude' CLI not found in PATH.", file=sys.stderr)
        print("Install it: https://docs.anthropic.com/en/docs/claude-code", file=sys.stderr)
        sys.exit(1)

    project_root, ep_rel = resolve_paths(args)

    print(f"Project:     {project_root}", file=sys.stderr)
    print(f"Entry point: {ep_rel}", file=sys.stderr)

    # Scan
    print("Scanning dependencies...", file=sys.stderr)
    session = PrismSession(str(project_root), exclude_patterns=args.exclude or None)
    session.scan(parallel=True)

    ep_path = (project_root / ep_rel).resolve()
    ep_node = session.graph.get_node(ep_path)
    if not ep_node:
        print(f"Error: entry point not found in graph: {ep_rel}", file=sys.stderr)
        sys.exit(1)

    # Build the full tree (always included, no token limit)
    tree_text = build_full_tree_text(session.graph, ep_node, include_frontend=args.frontend)

    # Build the code snapshot (token-limited)
    config = SnapshotConfig(
        target_path=ep_rel,
        parent_depth=args.parent_depth,
        child_depth=args.depth if args.depth > 0 else 0,
        child_max_tokens=args.max_tokens,
        include_frontend=args.frontend,
    )

    result = session.create_snapshot(config)
    if "error" in result:
        print(f"Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    snapshot = result["content"]
    metrics = result["metrics"]
    print(
        f"Snapshot: {metrics['total_files']} files, ~{metrics['token_estimate']:,} tokens",
        file=sys.stderr
    )

    # Assemble prompt
    prompt_text = build_map_prompt(args, tree_text)

    full_payload = f"{prompt_text}\n\n{'=' * 70}\n{tree_text}\n{'=' * 70}\n\n{snapshot}"

    if args.print_only:
        print(full_payload)
        return

    # Send to Claude Code
    if args.questions:
        print(f"Sending {len(args.questions)} questions to Claude Code...", file=sys.stderr)
    elif args.include_map:
        print("Requesting full project map from Claude Code...", file=sys.stderr)
    else:
        print("Sending to Claude Code...", file=sys.stderr)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write(full_payload)
        tmp_path = f.name

    try:
        proc = subprocess.run(
            [claude_bin, "-p", "--input-file", tmp_path],
            capture_output=True,
            text=True,
            timeout=300,
        )

        if proc.returncode != 0:
            # Fallback: pipe via stdin
            with open(tmp_path, "r") as f:
                proc = subprocess.run(
                    [claude_bin, "-p"],
                    input=f.read(),
                    capture_output=True,
                    text=True,
                    timeout=300,
                )

        output = proc.stdout

        if proc.returncode != 0:
            print(f"Claude exited with code {proc.returncode}", file=sys.stderr)
            if proc.stderr:
                print(proc.stderr, file=sys.stderr)

        if output:
            print(output)
            if args.output:
                Path(args.output).write_text(output, encoding="utf-8")
                print(f"\nSaved to: {args.output}", file=sys.stderr)
        else:
            print("No output from Claude.", file=sys.stderr)
            if proc.stderr:
                print(proc.stderr, file=sys.stderr)
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def _take_snapshot(project_root, ep_rel, args):
    """Take a snapshot and return (tree_text, snapshot_content, metrics, file_list)."""
    from prism.session import PrismSession
    from prism.models import SnapshotConfig

    session = PrismSession(str(project_root), exclude_patterns=args.exclude or None)
    session.scan(parallel=True)

    ep_path = (project_root / ep_rel).resolve()
    ep_node = session.graph.get_node(ep_path)
    if not ep_node:
        print(f"Error: entry point not found in graph: {ep_rel}", file=sys.stderr)
        sys.exit(1)

    tree_text = build_full_tree_text(session.graph, ep_node, include_frontend=args.frontend)

    config = SnapshotConfig(
        target_path=ep_rel,
        parent_depth=args.parent_depth,
        child_depth=args.depth if args.depth > 0 else 0,
        child_max_tokens=args.max_tokens,
        include_frontend=args.frontend,
    )
    result = session.create_snapshot(config)
    if "error" in result:
        print(f"Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    # Build a file->content map for structural diff
    all_nodes = bfs_full(session.graph, ep_node, include_frontend=args.frontend)
    file_list = {}
    for node, depth in all_nodes:
        try:
            content = node.path.read_text(encoding="utf-8", errors="replace")
            file_list[str(node.relative_path)] = {
                "lines": node.lines,
                "tokens": node.tokens,
                "depth": depth,
                "content_hash": __import__('hashlib').md5(content.encode()).hexdigest(),
                "type": node.node_type.value,
            }
        except Exception:
            file_list[str(node.relative_path)] = {
                "lines": node.lines,
                "tokens": node.tokens,
                "depth": depth,
                "content_hash": 0,
                "type": node.node_type.value,
            }

    return tree_text, result["content"], result["metrics"], file_list


def _build_structural_diff(before_files, after_files):
    """Compare two file lists and return a human-readable structural diff."""
    before_set = set(before_files.keys())
    after_set = set(after_files.keys())

    added = sorted(after_set - before_set)
    removed = sorted(before_set - after_set)
    common = sorted(before_set & after_set)

    modified = []
    for f in common:
        if before_files[f]["content_hash"] != after_files[f]["content_hash"]:
            delta_lines = after_files[f]["lines"] - before_files[f]["lines"]
            delta_tokens = after_files[f]["tokens"] - before_files[f]["tokens"]
            modified.append((f, delta_lines, delta_tokens))

    lines = ["STRUCTURAL DIFF", "=" * 50]

    if added:
        lines.append(f"\n  ADDED ({len(added)} files):")
        for f in added:
            info = after_files[f]
            lines.append(f"    + {f}  ({info['lines']}L, {info['tokens']}tok)")

    if removed:
        lines.append(f"\n  REMOVED ({len(removed)} files):")
        for f in removed:
            info = before_files[f]
            lines.append(f"    - {f}  ({info['lines']}L, {info['tokens']}tok)")

    if modified:
        lines.append(f"\n  MODIFIED ({len(modified)} files):")
        for f, dl, dt in modified:
            sign_l = f"+{dl}" if dl >= 0 else str(dl)
            sign_t = f"+{dt}" if dt >= 0 else str(dt)
            lines.append(f"    ~ {f}  ({sign_l} lines, {sign_t} tokens)")

    unchanged = len(common) - len(modified)
    lines.append(f"\n  UNCHANGED: {unchanged} files")

    total_before = sum(f["tokens"] for f in before_files.values())
    total_after = sum(f["tokens"] for f in after_files.values())
    delta = total_after - total_before
    sign = f"+{delta}" if delta >= 0 else str(delta)
    lines.append(f"  TOKEN DELTA: {sign} ({total_before:,} -> {total_after:,})")

    return "\n".join(lines)


def cmd_diff(args):
    """Compare a baseline snapshot against the current state."""
    import shutil
    import subprocess
    import tempfile
    import json
    from prism.session import PrismSession
    from prism.models import SnapshotConfig

    # If baseline looks like a file path and entry_point is missing, swap them
    # This handles: prism diff --save out.prism entry.py  (baseline=None, entry_point=entry.py)
    # But also needs to catch: prism diff baseline.prism entry.py (both provided)
    if not args.save and not args.git and not args.baseline:
        print("Error: provide a baseline file, --git ref, or --save to create one.", file=sys.stderr)
        sys.exit(1)

    project_root, ep_rel = resolve_paths(args)

    # --save mode: just save current snapshot and exit
    if args.save:
        print(f"Saving baseline snapshot...", file=sys.stderr)
        tree_text, snapshot, metrics, file_list = _take_snapshot(project_root, ep_rel, args)

        save_data = {
            "version": 1,
            "entry_point": ep_rel,
            "project_root": str(project_root),
            "tree_text": tree_text,
            "snapshot": snapshot,
            "metrics": metrics,
            "file_list": file_list,
        }

        out = Path(args.save)
        out.write_text(json.dumps(save_data, indent=2), encoding="utf-8")
        print(f"Baseline saved: {out}", file=sys.stderr)
        print(f"  Files: {metrics['total_files']}, Tokens: ~{metrics['token_estimate']:,}", file=sys.stderr)
        print(f"\nNow make your changes, then run:", file=sys.stderr)
        print(f"  prism diff {out} {ep_rel}", file=sys.stderr)
        return

    # --git mode: checkout old ref in a temp worktree
    if args.git:
        print(f"Creating baseline from git ref: {args.git}", file=sys.stderr)
        import shutil as _shutil

        worktree_dir = tempfile.mkdtemp(prefix="prism-diff-")
        try:
            subprocess.run(
                ["git", "worktree", "add", "--detach", worktree_dir, args.git],
                cwd=str(project_root), check=True, capture_output=True, text=True,
            )

            # Take snapshot from the worktree
            old_project = Path(worktree_dir)

            # We need a separate args-like object for the old snapshot
            class OldArgs:
                pass
            old_args = OldArgs()
            old_args.exclude = args.exclude
            old_args.frontend = args.frontend
            old_args.parent_depth = args.parent_depth
            old_args.depth = args.depth
            old_args.max_tokens = args.max_tokens

            from prism.session import PrismSession as PS2
            old_session = PS2(str(old_project), exclude_patterns=args.exclude or None)
            old_session.scan(parallel=True)

            old_ep_path = (old_project / ep_rel).resolve()
            old_ep_node = old_session.graph.get_node(old_ep_path)
            if not old_ep_node:
                print(f"Error: entry point {ep_rel} not found in {args.git}", file=sys.stderr)
                sys.exit(1)

            before_tree = build_full_tree_text(old_session.graph, old_ep_node, include_frontend=args.frontend)

            config = SnapshotConfig(
                target_path=ep_rel,
                parent_depth=args.parent_depth,
                child_depth=args.depth if args.depth > 0 else 0,
                child_max_tokens=args.max_tokens,
                include_frontend=args.frontend,
            )
            old_result = old_session.create_snapshot(config)
            if "error" in old_result:
                print(f"Error snapshotting {args.git}: {old_result['error']}", file=sys.stderr)
                sys.exit(1)

            before_snapshot = old_result["content"]
            before_metrics = old_result["metrics"]

            old_nodes = bfs_full(old_session.graph, old_ep_node, include_frontend=args.frontend)
            before_files = {}
            for node, depth in old_nodes:
                try:
                    content = node.path.read_text(encoding="utf-8", errors="replace")
                    before_files[str(node.relative_path)] = {
                        "lines": node.lines, "tokens": node.tokens,
                        "depth": depth, "content_hash": hash(content),
                        "type": node.node_type.value,
                    }
                except Exception:
                    before_files[str(node.relative_path)] = {
                        "lines": node.lines, "tokens": node.tokens,
                        "depth": depth, "content_hash": 0,
                        "type": node.node_type.value,
                    }

        finally:
            subprocess.run(
                ["git", "worktree", "remove", "--force", worktree_dir],
                cwd=str(project_root), capture_output=True, text=True,
            )
    else:
        # Load baseline from file
        baseline_path = Path(args.baseline)
        if not baseline_path.exists():
            print(f"Error: baseline file not found: {baseline_path}", file=sys.stderr)
            sys.exit(1)

        import json
        save_data = json.loads(baseline_path.read_text(encoding="utf-8"))
        if save_data.get("version") != 1:
            print(f"Error: unsupported baseline version", file=sys.stderr)
            sys.exit(1)

        before_tree = save_data["tree_text"]
        before_snapshot = save_data["snapshot"]
        before_metrics = save_data["metrics"]
        before_files = save_data["file_list"]

    # Take current snapshot
    print(f"Scanning current state...", file=sys.stderr)
    after_tree, after_snapshot, after_metrics, after_files = _take_snapshot(project_root, ep_rel, args)

    # Build structural diff
    struct_diff = _build_structural_diff(before_files, after_files)
    print(f"\n{struct_diff}", file=sys.stderr)

    # Build the prompt
    if args.prompt:
        prompt_text = args.prompt
    else:
        parts = [
            "You are analyzing a BEFORE and AFTER snapshot of a Python project's dependency graph.\n"
            "A refactor or change was made between these two snapshots. Your job is to:\n\n"
            "1. IDENTIFY what changed — new files, removed files, modified files, changed imports\n"
            "2. ASSESS what might have broken — broken imports, missing dependencies, circular refs,\n"
            "   functions that were called but are now gone, changed signatures, renamed modules\n"
            "3. FLAG risks — any behavioral changes that could cause bugs at runtime even if the\n"
            "   code technically runs (changed return types, reordered operations, lost side effects)\n"
            "4. SUMMARIZE the refactor — what was the intent? Did it achieve its goal cleanly?\n\n"
            "Be specific: reference file names, function names, and line numbers where possible.\n"
            "If something looks fine, say so briefly. Spend your analysis budget on the risky parts.",
        ]

        if args.questions:
            parts.append("\nADDITIONAL QUESTIONS:\n")
            for i, q in enumerate(args.questions, 1):
                parts.append(f"  {i}. {q}")

        prompt_text = "\n".join(parts)

    # Assemble full payload
    sep = "=" * 70
    full_payload = (
        f"{prompt_text}\n\n"
        f"{struct_diff}\n\n"
        f"{sep}\n"
        f"BEFORE SNAPSHOT (baseline)\n"
        f"{sep}\n"
        f"{before_tree}\n\n"
        f"{before_snapshot}\n\n"
        f"{sep}\n"
        f"AFTER SNAPSHOT (current)\n"
        f"{sep}\n"
        f"{after_tree}\n\n"
        f"{after_snapshot}\n"
    )

    if args.print_only:
        print(full_payload)
        return

    # Send to Claude
    claude_bin = shutil.which("claude")
    if not claude_bin:
        print("Error: 'claude' CLI not found in PATH.", file=sys.stderr)
        sys.exit(1)

    print(f"\nSending diff to Claude Code...", file=sys.stderr)
    print(f"  Before: {before_metrics['total_files']} files, ~{before_metrics['token_estimate']:,} tokens", file=sys.stderr)
    print(f"  After:  {after_metrics['total_files']} files, ~{after_metrics['token_estimate']:,} tokens", file=sys.stderr)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write(full_payload)
        tmp_path = f.name

    try:
        proc = subprocess.run(
            [claude_bin, "-p", "--input-file", tmp_path],
            capture_output=True, text=True, timeout=300,
        )

        if proc.returncode != 0:
            with open(tmp_path, "r") as f:
                proc = subprocess.run(
                    [claude_bin, "-p"],
                    input=f.read(),
                    capture_output=True, text=True, timeout=300,
                )

        output = proc.stdout

        if proc.returncode != 0:
            print(f"Claude exited with code {proc.returncode}", file=sys.stderr)
            if proc.stderr:
                print(proc.stderr, file=sys.stderr)

        if output:
            print(output)
            if args.output:
                Path(args.output).write_text(output, encoding="utf-8")
                print(f"\nSaved to: {args.output}", file=sys.stderr)
        else:
            print("No output from Claude.", file=sys.stderr)
            if proc.stderr:
                print(proc.stderr, file=sys.stderr)
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def cmd_snap(args):
    """Symbol-level snapshot — find a symbol and everything that touches it."""
    import shutil
    import subprocess
    import tempfile
    from prism.session import PrismSession
    from prism.symbols import build_symbol_index, format_symbol_snapshot, format_impact_summary

    # Resolve project root
    if args.project:
        project_root = Path(args.project).resolve()
    else:
        project_root = Path.cwd().resolve()
        candidate = project_root
        while candidate != candidate.parent:
            if (candidate / ".git").exists():
                project_root = candidate
                break
            candidate = candidate.parent

    print(f"Project: {project_root}", file=sys.stderr)

    # Scan for all Python files
    session = PrismSession(str(project_root), exclude_patterns=args.exclude or None)
    session.scan(parallel=True)

    # Get all Python files from the graph
    py_files = [n.path for n in session.graph.get_nodes() if n.path.suffix == ".py"]

    print(f"Indexing {len(py_files)} Python files...", file=sys.stderr)
    t0 = time.perf_counter()
    index = build_symbol_index(py_files, project_root)
    index_ms = (time.perf_counter() - t0) * 1000
    total_defs = sum(len(v) for v in index.definitions.values())
    total_refs = sum(len(v) for v in index.references.values())
    print(f"Indexed: {total_defs} symbols, {total_refs} references ({index_ms:.0f}ms)", file=sys.stderr)

    # --list mode
    if args.list_symbols or not args.symbol:
        print(f"\nSymbols in {project_root.name}:")
        print("-" * 60)
        for name, syms in sorted(index.definitions.items()):
            for s in syms:
                kind_badge = {"class": "CLS", "function": "FN ", "method": "MTH"}.get(s.kind, "???")
                print(f"  [{kind_badge}] {s.qualified_name}  ({s.location})")
        return

    # Find the symbol
    results = index.find(args.symbol)

    if not results:
        # Fuzzy search: try partial match
        partial = []
        for name, syms in index.definitions.items():
            if args.symbol.lower() in name.lower():
                partial.extend(syms)
        if len(partial) == 1:
            # Only one match — just use it
            results = partial
            print(f"Matched: {results[0].qualified_name}", file=sys.stderr)
        elif partial:
            print(f"Symbol '{args.symbol}' not found. Did you mean:", file=sys.stderr)
            for s in partial[:10]:
                print(f"  {s.qualified_name}  ({s.location})", file=sys.stderr)
            sys.exit(1)
        else:
            print(f"Symbol '{args.symbol}' not found.", file=sys.stderr)
            sys.exit(1)

    if len(results) > 1:
        print(f"Found {len(results)} matches for '{args.symbol}':", file=sys.stderr)
        for i, s in enumerate(results):
            print(f"  [{i+1}] {s.qualified_name}  ({s.location}, {s.kind})", file=sys.stderr)
        print(f"Using first match. Disambiguate with file::name syntax.", file=sys.stderr)

    symbol = results[0]

    # --impact mode: just show impact summary
    if args.impact:
        print(format_impact_summary(symbol, index))
        return

    # Build full snapshot
    snapshot = format_symbol_snapshot(symbol, index)

    # If no questions, just print the snapshot
    if not args.questions:
        if args.output:
            Path(args.output).write_text(snapshot, encoding="utf-8")
            print(f"\nSnapshot written to: {args.output}", file=sys.stderr)
        else:
            print(snapshot)
        return

    # Questions mode: send to Claude
    prompt_parts = [
        "You are analyzing a SYMBOL-LEVEL SNAPSHOT from a Python codebase.\n"
        "Below you'll find:\n"
        "  1. The symbol definition (the actual source code)\n"
        "  2. All references to this symbol across the codebase\n"
        "  3. Source code of the most important callers\n\n"
        "This gives you precise context about this symbol and everything that touches it.\n",
    ]

    if args.questions:
        prompt_parts.append("QUESTIONS — Answer each thoroughly:\n")
        for i, q in enumerate(args.questions, 1):
            prompt_parts.append(f"  {i}. {q}")
        prompt_parts.append(
            "\nReference specific files, functions, and line numbers in your answers."
        )

    prompt_text = "\n".join(prompt_parts)
    full_payload = f"{prompt_text}\n\n{snapshot}"

    if args.print_only:
        print(full_payload)
        return

    claude_bin = shutil.which("claude")
    if not claude_bin:
        print("Error: 'claude' CLI not found in PATH.", file=sys.stderr)
        sys.exit(1)

    print(f"\nSending symbol snapshot to Claude Code...", file=sys.stderr)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write(full_payload)
        tmp_path = f.name

    try:
        proc = subprocess.run(
            [claude_bin, "-p", "--input-file", tmp_path],
            capture_output=True, text=True, timeout=300,
        )
        if proc.returncode != 0:
            with open(tmp_path, "r") as f:
                proc = subprocess.run(
                    [claude_bin, "-p"], input=f.read(),
                    capture_output=True, text=True, timeout=300,
                )

        output = proc.stdout
        if output:
            print(output)
            if args.output:
                Path(args.output).write_text(output, encoding="utf-8")
                print(f"\nSaved to: {args.output}", file=sys.stderr)
        else:
            print("No output from Claude.", file=sys.stderr)
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def cmd_serve(args):
    """Handle the serve subcommand — start the web UI."""
    from zdeps2.api.app_prism import app
    from zdeps2.core.config import get_project_root, get_config_path

    print()
    print("=" * 55)
    print("  Prism — Dependency Viewer (Web UI)")
    print("=" * 55)
    print(f"\n  Project Root: {get_project_root()}")
    print(f"  Config File:  {get_config_path()}")
    print(f"\n  Open in browser: http://localhost:{args.port}")
    print("\n  Press Ctrl+C to stop\n")

    app.run(host=args.host, port=args.port, debug=args.debug)


def main():
    args = parse_args()

    cmd = getattr(args, "command", None)
    if cmd == "serve":
        cmd_serve(args)
    elif cmd == "map":
        cmd_map(args)
    elif cmd == "diff":
        cmd_diff(args)
    elif cmd == "snap":
        cmd_snap(args)
    else:
        cmd_scan(args)


if __name__ == "__main__":
    main()
