"""Symbol-level analysis — index definitions and references across a Python codebase."""
import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Set, Optional, Tuple


@dataclass
class Symbol:
    """A named code entity: function, class, or method."""
    name: str               # Short name: "validate_token"
    qualified_name: str     # Full name: "auth.AuthManager.validate_token"
    kind: str               # "function", "class", "method"
    file_path: Path         # Absolute path
    relative_path: str      # Relative to project root
    line_start: int
    line_end: int
    source: str = ""        # The actual code
    parent_class: Optional[str] = None  # For methods: the class they belong to
    decorators: List[str] = field(default_factory=list)
    bases: List[str] = field(default_factory=list)  # For classes: base classes
    signature: str = ""     # Function/method signature line

    @property
    def location(self) -> str:
        return f"{self.relative_path}:{self.line_start}"


@dataclass
class Reference:
    """A place where a symbol is used."""
    symbol_name: str        # What's being referenced
    kind: str               # "call", "import", "attribute", "inherit", "instantiate"
    file_path: Path
    relative_path: str
    line: int
    context_func: Optional[str] = None   # Enclosing function/method name
    context_class: Optional[str] = None  # Enclosing class name
    line_text: str = ""     # The source line


@dataclass
class SymbolIndex:
    """Complete symbol table for a codebase."""
    definitions: Dict[str, List[Symbol]] = field(default_factory=dict)  # name -> [Symbol, ...]
    references: Dict[str, List[Reference]] = field(default_factory=dict)  # name -> [Reference, ...]
    # Reverse: file -> symbols defined in it
    file_symbols: Dict[str, List[Symbol]] = field(default_factory=dict)

    def find(self, query: str) -> List[Symbol]:
        """Find symbols matching a query. Supports name, Class.method, or file::name."""
        if "::" in query:
            file_hint, name = query.split("::", 1)
            results = []
            for sym in self.definitions.get(name, []):
                if file_hint in sym.relative_path:
                    results.append(sym)
            return results

        if "." in query:
            # Could be Class.method
            parts = query.split(".")
            class_name, method_name = parts[0], parts[-1]
            results = []
            for sym in self.definitions.get(method_name, []):
                if sym.parent_class == class_name:
                    results.append(sym)
            if results:
                return results
            # Fall through to direct name match
            for sym in self.definitions.get(query, []):
                results.append(sym)
            return results

        return self.definitions.get(query, [])

    def get_references(self, name: str) -> List[Reference]:
        """Get all references to a symbol name."""
        refs = list(self.references.get(name, []))
        # Also check for Class references if this is a class
        for sym in self.definitions.get(name, []):
            if sym.kind == "class":
                # Find method references too
                for method_sym in self.definitions.values():
                    for s in method_sym:
                        if s.parent_class == name and s.name in self.references:
                            refs.extend(self.references[s.name])
        return refs

    def get_impact(self, name: str) -> Tuple[List[Reference], Set[str]]:
        """Get all references to a symbol and the files affected."""
        refs = self.get_references(name)
        files = {r.relative_path for r in refs}
        return refs, files


def build_symbol_index(file_paths: List[Path], project_root: Path) -> SymbolIndex:
    """Build a complete symbol index from a list of Python files."""
    index = SymbolIndex()

    for file_path in file_paths:
        if not file_path.suffix == ".py":
            continue
        try:
            source = file_path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source)
        except (SyntaxError, UnicodeDecodeError, FileNotFoundError):
            continue

        source_lines = source.splitlines()
        try:
            rel_path = str(file_path.relative_to(project_root))
        except ValueError:
            rel_path = str(file_path)

        # Module name from path
        module_name = rel_path.replace("/", ".").removesuffix(".py")
        if module_name.endswith(".__init__"):
            module_name = module_name.removesuffix(".__init__")

        # Extract definitions
        _extract_definitions(tree, file_path, rel_path, module_name, source_lines, index)

        # Extract references
        _extract_references(tree, file_path, rel_path, source_lines, index)

    return index


def _get_source_segment(source_lines: List[str], start: int, end: int) -> str:
    """Extract source code lines (1-indexed)."""
    return "\n".join(source_lines[start - 1:end])


def _get_end_line(node: ast.AST) -> int:
    """Get the end line of an AST node."""
    return getattr(node, "end_lineno", node.lineno) or node.lineno


def _extract_definitions(
    tree: ast.Module,
    file_path: Path,
    rel_path: str,
    module_name: str,
    source_lines: List[str],
    index: SymbolIndex,
):
    """Walk AST and extract all function/class/method definitions."""
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            end_line = _get_end_line(node)
            # For class, get just the class header + method signatures
            decorators = [_decorator_name(d) for d in node.decorator_list]
            bases = []
            for base in node.bases:
                if isinstance(base, ast.Name):
                    bases.append(base.id)
                elif isinstance(base, ast.Attribute):
                    bases.append(ast.unparse(base))

            sym = Symbol(
                name=node.name,
                qualified_name=f"{module_name}.{node.name}",
                kind="class",
                file_path=file_path,
                relative_path=rel_path,
                line_start=node.lineno,
                line_end=end_line,
                source=_get_source_segment(source_lines, node.lineno, end_line),
                decorators=decorators,
                bases=bases,
                signature=source_lines[node.lineno - 1].strip() if node.lineno <= len(source_lines) else "",
            )
            index.definitions.setdefault(node.name, []).append(sym)
            index.file_symbols.setdefault(rel_path, []).append(sym)

            # Extract methods
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    m_end = _get_end_line(item)
                    m_decorators = [_decorator_name(d) for d in item.decorator_list]
                    sig_line = source_lines[item.lineno - 1].strip() if item.lineno <= len(source_lines) else ""

                    msym = Symbol(
                        name=item.name,
                        qualified_name=f"{module_name}.{node.name}.{item.name}",
                        kind="method",
                        file_path=file_path,
                        relative_path=rel_path,
                        line_start=item.lineno,
                        line_end=m_end,
                        source=_get_source_segment(source_lines, item.lineno, m_end),
                        parent_class=node.name,
                        decorators=m_decorators,
                        signature=sig_line,
                    )
                    index.definitions.setdefault(item.name, []).append(msym)
                    index.file_symbols.setdefault(rel_path, []).append(msym)

        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Only top-level functions (not methods — those are handled above)
            # Check if parent is module (not class)
            if _is_top_level(tree, node):
                end_line = _get_end_line(node)
                decorators = [_decorator_name(d) for d in node.decorator_list]
                sig_line = source_lines[node.lineno - 1].strip() if node.lineno <= len(source_lines) else ""

                sym = Symbol(
                    name=node.name,
                    qualified_name=f"{module_name}.{node.name}",
                    kind="function",
                    file_path=file_path,
                    relative_path=rel_path,
                    line_start=node.lineno,
                    line_end=end_line,
                    source=_get_source_segment(source_lines, node.lineno, end_line),
                    decorators=decorators,
                    signature=sig_line,
                )
                index.definitions.setdefault(node.name, []).append(sym)
                index.file_symbols.setdefault(rel_path, []).append(sym)


def _is_top_level(tree: ast.Module, target: ast.AST) -> bool:
    """Check if a node is a direct child of the module (not nested in a class)."""
    for node in tree.body:
        if node is target:
            return True
    return False


def _decorator_name(node: ast.AST) -> str:
    """Extract decorator name from AST node."""
    if isinstance(node, ast.Name):
        return node.id
    elif isinstance(node, ast.Attribute):
        return ast.unparse(node)
    elif isinstance(node, ast.Call):
        return _decorator_name(node.func)
    return ast.unparse(node)


def _extract_references(
    tree: ast.Module,
    file_path: Path,
    rel_path: str,
    source_lines: List[str],
    index: SymbolIndex,
):
    """Walk AST and extract all references (calls, attribute access, imports)."""

    # Build a map of line -> enclosing function/class for context
    context_map = _build_context_map(tree)

    for node in ast.walk(tree):
        line = getattr(node, "lineno", 0)
        ctx_func, ctx_class = context_map.get(line, (None, None))
        line_text = source_lines[line - 1].strip() if 0 < line <= len(source_lines) else ""

        # Function/method calls
        if isinstance(node, ast.Call):
            names = _extract_call_names(node)
            for name, kind in names:
                ref = Reference(
                    symbol_name=name,
                    kind=kind,
                    file_path=file_path,
                    relative_path=rel_path,
                    line=line,
                    context_func=ctx_func,
                    context_class=ctx_class,
                    line_text=line_text,
                )
                index.references.setdefault(name, []).append(ref)

        # Class inheritance
        elif isinstance(node, ast.ClassDef):
            for base in node.bases:
                base_name = None
                if isinstance(base, ast.Name):
                    base_name = base.id
                elif isinstance(base, ast.Attribute):
                    base_name = base.attr
                if base_name:
                    ref = Reference(
                        symbol_name=base_name,
                        kind="inherit",
                        file_path=file_path,
                        relative_path=rel_path,
                        line=node.lineno,
                        context_func=None,
                        context_class=node.name,
                        line_text=line_text,
                    )
                    index.references.setdefault(base_name, []).append(ref)

        # Import references
        elif isinstance(node, ast.ImportFrom):
            if node.names:
                for alias in node.names:
                    if alias.name != "*":
                        ref = Reference(
                            symbol_name=alias.name,
                            kind="import",
                            file_path=file_path,
                            relative_path=rel_path,
                            line=line,
                            context_func=ctx_func,
                            context_class=ctx_class,
                            line_text=line_text,
                        )
                        index.references.setdefault(alias.name, []).append(ref)


def _extract_call_names(node: ast.Call) -> List[Tuple[str, str]]:
    """Extract the callable name(s) from a Call node."""
    results = []
    func = node.func

    if isinstance(func, ast.Name):
        # Direct call: foo()
        results.append((func.id, "call"))
    elif isinstance(func, ast.Attribute):
        # Method call: obj.method()
        results.append((func.attr, "call"))
        # Also track the object if it's a name: Class.method() or instance.method()
        if isinstance(func.value, ast.Name):
            results.append((func.value.id, "attribute"))

    return results


def _build_context_map(tree: ast.Module) -> Dict[int, Tuple[Optional[str], Optional[str]]]:
    """Build a map of line_number -> (enclosing_function, enclosing_class)."""
    context = {}

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for line in range(node.lineno, _get_end_line(node) + 1):
                existing = context.get(line, (None, None))
                context[line] = (existing[0], node.name)

            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    for line in range(item.lineno, _get_end_line(item) + 1):
                        context[line] = (item.name, node.name)

        elif isinstance(item := node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if _is_top_level(tree, item):
                for line in range(item.lineno, _get_end_line(item) + 1):
                    existing = context.get(line, (None, None))
                    if existing[0] is None:  # Don't overwrite method context
                        context[line] = (item.name, existing[1])

    return context


def format_symbol_snapshot(
    symbol: Symbol,
    index: SymbolIndex,
    mode: str = "full",
    max_refs: int = 50,
) -> str:
    """Format a symbol and its references as a readable snapshot.

    Args:
        symbol: The target symbol
        index: The full symbol index
        mode: "full" includes source, "impact" focuses on references
        max_refs: Maximum number of references to include
    """
    lines = []
    sep = "=" * 70

    # Header
    lines.append(sep)
    lines.append(f"SYMBOL: {symbol.qualified_name}")
    lines.append(f"  Kind: {symbol.kind}")
    lines.append(f"  Location: {symbol.location}")
    if symbol.decorators:
        lines.append(f"  Decorators: {', '.join(symbol.decorators)}")
    if symbol.bases:
        lines.append(f"  Inherits: {', '.join(symbol.bases)}")
    lines.append(sep)

    # Source code
    lines.append(f"\n# --- DEFINITION: {symbol.location} ---")
    lines.append(symbol.source)
    lines.append(f"# --- END DEFINITION ---\n")

    # If it's a class, show methods summary
    if symbol.kind == "class":
        methods = [s for s in index.definitions.get(symbol.name, [])
                   if s is not symbol]  # other symbols with same name won't be methods
        # Get actual methods from file_symbols
        file_syms = index.file_symbols.get(symbol.relative_path, [])
        methods = [s for s in file_syms if s.parent_class == symbol.name]
        if methods:
            lines.append(f"METHODS ({len(methods)}):")
            for m in methods:
                lines.append(f"  {m.signature}  # line {m.line_start}")
            lines.append("")

    # References (callers / usage)
    refs = index.get_references(symbol.name)
    # Filter out self-references (same file, same definition)
    refs = [r for r in refs
            if not (r.file_path == symbol.file_path
                    and symbol.line_start <= r.line <= symbol.line_end)]

    if refs:
        # Group by file
        by_file: Dict[str, List[Reference]] = {}
        for r in refs:
            by_file.setdefault(r.relative_path, []).append(r)

        lines.append(f"REFERENCED BY ({len(refs)} references in {len(by_file)} files):")
        lines.append("-" * 50)

        ref_count = 0
        for file_path, file_refs in sorted(by_file.items()):
            lines.append(f"\n  {file_path}:")
            for r in sorted(file_refs, key=lambda x: x.line):
                if ref_count >= max_refs:
                    lines.append(f"\n  ... and {len(refs) - max_refs} more references")
                    break
                ctx = ""
                if r.context_class and r.context_func:
                    ctx = f" in {r.context_class}.{r.context_func}"
                elif r.context_func:
                    ctx = f" in {r.context_func}()"
                elif r.context_class:
                    ctx = f" in class {r.context_class}"
                lines.append(f"    L{r.line} [{r.kind}]{ctx}: {r.line_text}")
                ref_count += 1
            if ref_count >= max_refs:
                break

        # Extract caller source code for the most important references
        lines.append(f"\n{'=' * 70}")
        lines.append("CALLER SOURCE CODE")
        lines.append(f"{'=' * 70}")

        seen_funcs = set()
        caller_count = 0
        for r in refs:
            if caller_count >= 10:
                break
            # Find the enclosing function/method definition
            caller_key = (r.relative_path, r.context_func, r.context_class)
            if caller_key in seen_funcs or not r.context_func:
                continue
            seen_funcs.add(caller_key)

            # Find the caller's symbol definition
            caller_sym = None
            for s in index.definitions.get(r.context_func, []):
                if s.file_path == r.file_path:
                    if r.context_class is None or s.parent_class == r.context_class:
                        caller_sym = s
                        break

            if caller_sym:
                lines.append(f"\n# --- CALLER: {caller_sym.qualified_name} ({caller_sym.location}) ---")
                lines.append(caller_sym.source)
                lines.append(f"# --- END CALLER ---")
                caller_count += 1
    else:
        lines.append("NO REFERENCES FOUND (this symbol may be unused or only called dynamically)")

    return "\n".join(lines)


def format_impact_summary(symbol: Symbol, index: SymbolIndex) -> str:
    """Format a concise impact summary for terminal output."""
    refs, files = index.get_impact(symbol.name)

    # Filter self-references
    refs = [r for r in refs
            if not (r.file_path == symbol.file_path
                    and symbol.line_start <= r.line <= symbol.line_end)]
    files = {r.relative_path for r in refs}

    lines = []
    lines.append(f"\n  {symbol.kind}: {symbol.qualified_name}")
    lines.append(f"  Defined: {symbol.location}")
    lines.append(f"  Impact: {len(refs)} references in {len(files)} files")

    if files:
        lines.append(f"\n  Affected files:")
        for f in sorted(files):
            file_refs = [r for r in refs if r.relative_path == f]
            kinds = set(r.kind for r in file_refs)
            lines.append(f"    {f}  ({', '.join(sorted(kinds))})")

    return "\n".join(lines)
