import{ap as o,aq as n}from"./index-C2-Qex3s.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
