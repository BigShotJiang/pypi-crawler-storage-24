import{b as r}from"./graph-D4O7klco.js";var e=4;function a(o){return r(o,e)}export{a as c};
