"""Utilities for ospx."""
