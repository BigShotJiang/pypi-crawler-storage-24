"""Custom exceptions for the data package."""

from __future__ import annotations

from typing import Optional

from bitfount.data.types import RangeBound
from bitfount.exceptions import BitfountError


class BitfountSchemaError(BitfountError):
    """Errors related to BitfountSchema."""

    pass


class DataStructureError(BitfountError):
    """Errors related to Datastructure."""

    pass


class DataSourceError(BitfountError):
    """Errors related to Datasource."""

    pass


class IterableDataSourceError(DataSourceError):
    """Errors related to IterableSource-specific functionality."""

    pass


class ElevatedPermissionsError(DataSourceError):
    """Errors related to datasource connections having elevated write permissions.

    This exception is raised when a datasource connection is detected to have
    write permissions (INSERT, UPDATE, DELETE, CREATE, etc.) when read-only
    access is required for security purposes.
    """

    pass


class DataNotLoadedError(BitfountError):
    """Raised if a data operation is attempted prior to data loading.

    This is usually raised because `load_data` has not been called yet.
    """

    pass


class DuplicateColumnError(BitfountError):
    """Raised if the column names are duplicated in the data.

    This can be raised by the sql algorithms with multi-table pods.
    """

    pass


class DataCacheError(BitfountError):
    """Error related to data cache interaction."""

    pass


class DataNotAvailableError(BitfountError):
    """Error when data is not available.

    This is raised when data is initially expected from the first read of a datasource,
    but an error is raised during the subsequent reads rendering no data available.
    """

    pass


class InterMineServiceUnavailableError(DataSourceError):
    """Error raised when the InterMine service is temporarily unavailable.

    This exception is raised when the InterMine service returns an HTTP 500 error
    or similar server-side error, indicating that the service is temporarily down
    but the configuration may still be valid.

    This is distinct from configuration errors (wrong URL, missing template) which
    indicate a permanent problem that requires user intervention.
    """

    pass


class ImpossibleConstraintsFilterError(DataSourceError):
    """Base class for impossible filter constraint errors.

    This occurs when task-level filters and datasource-level filters are merged
    using intersection logic and the resulting constraint cannot be satisfied.
    """

    def __init__(self, filter_name: str, message: str) -> None:
        self.filter_name = filter_name
        super().__init__(message)


class ImpossibleRangeFilterError(ImpossibleConstraintsFilterError):
    """Raised when merged range filters result in min > max.

    For range filters (e.g., bscan count, file size, dates) where the merged
    minimum exceeds the merged maximum, making it impossible to satisfy.
    """

    def __init__(
        self,
        filter_name: str,
        *,
        merged_min: RangeBound,
        merged_max: RangeBound,
        datasource_min: Optional[RangeBound] = None,
        datasource_max: Optional[RangeBound] = None,
        task_min: Optional[RangeBound] = None,
        task_max: Optional[RangeBound] = None,
    ) -> None:
        self.merged_min = merged_min
        self.merged_max = merged_max
        self.datasource_min = datasource_min
        self.datasource_max = datasource_max
        self.task_min = task_min
        self.task_max = task_max

        message = (
            f"Filter '{filter_name}' results in impossible range: "
            f"merged min ({merged_min}) > merged max ({merged_max}). "
            f"No data can match these constraints. "
            f"Datasource config: min={datasource_min}, max={datasource_max}. "
            f"Task filter: min={task_min}, max={task_max}."
        )
        super().__init__(filter_name, message)


class ImpossibleValueFilterError(ImpossibleConstraintsFilterError):
    """Raised when merged value filters have conflicting values.

    For value filters (e.g., modality) where datasource and task specify
    incompatible values that cannot be merged.
    """

    def __init__(
        self,
        filter_name: str,
        *,
        datasource_value: str,
        task_value: str,
    ) -> None:
        self.datasource_value = datasource_value
        self.task_value = task_value

        message = (
            f"Filter '{filter_name}' has conflicting values. "
            f"Datasource is configured for '{datasource_value}' "
            f"but task filter requests '{task_value}'. "
            f"These values are incompatible and cannot be merged."
        )
        super().__init__(filter_name, message)
