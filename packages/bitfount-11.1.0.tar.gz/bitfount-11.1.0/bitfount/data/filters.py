"""Task-level filter types for runtime data filtering.

This module provides the data structures for specifying filters at task runtime
that work alongside existing datasource-level filters. Task filters are defined
in `DataStructure`, serialized to workers, and merged with datasource config
using intersection logic (most restrictive bounds win).

Example:
    >>> from bitfount.data.filters import TaskFilter
    >>> filter = TaskFilter(
    ...     filter_type="min-frames",
    ...     value=49,
    ... )
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
import logging
import math
from types import MappingProxyType
from typing import Any, ClassVar, Literal, Optional, Union, cast

from marshmallow import fields

from bitfount.data.datasources.types import Date, DateTD, OphthalmologyModalityType
from bitfount.data.exceptions import (
    ImpossibleRangeFilterError,
    ImpossibleValueFilterError,
)
from bitfount.data.types import (
    RangeBound,
    RangeBoundInput,
    SerializedTaskFilterValue,
    TaskFilterValue,
)
from bitfount.types import T_FIELDS_DICT, T_NESTED_FIELDS, _BaseSerializableObjectMixIn
from bitfount.utils.logging_utils import SampleFilter

logger = logging.getLogger(__name__)


def _check_type_compatibility(
    value: RangeBound,
    bound: RangeBound,
    bound_name: str,
) -> None:
    """Validate that value and bound have compatible types.

    Args:
        value: The value being checked.
        bound: The bound (min or max) to compare against.
        bound_name: Name of the bound for error message ('min_value' or 'max_value').

    Raises:
        TypeError: If value and bound have incompatible types.
    """
    value_is_numeric = isinstance(value, (int, float))
    bound_is_numeric = isinstance(bound, (int, float))
    value_is_date = isinstance(value, date)
    bound_is_date = isinstance(bound, date)

    if value_is_numeric and bound_is_date:
        raise TypeError(
            f"Type mismatch: numeric value {value!r} cannot be compared "
            f"with date {bound_name}={bound!r}"
        )
    if value_is_date and bound_is_numeric:
        raise TypeError(
            f"Type mismatch: date value {value!r} cannot be compared "
            f"with numeric {bound_name}={bound!r}"
        )


def should_persist_skip_to_cache(
    *,
    value: Optional[RangeBoundInput] = None,
    datasource_min: Optional[RangeBoundInput] = None,
    datasource_max: Optional[RangeBoundInput] = None,
    missing_fields: Optional[set[str]] = None,
    datasource_required_fields: Optional[set[str]] = None,
    file_modality: Optional[OphthalmologyModalityType] = None,
    datasource_modality: Optional[OphthalmologyModalityType] = None,
    file_series_description: Optional[str] = None,
    datasource_series_description: Optional[str] = None,
) -> bool:
    """Determine if a skipped file should be persisted to the skip cache.

    Checks whether a file that failed the merged filter would also fail the
    datasource-only filter. If yes, cache the skip. If no, don't cache.

    Assumes the file has ALREADY failed the merged filter check.

    Args:
        value: File's value for range filters (e.g., num_frames, file_size).
        datasource_min: Minimum bound from datasource config.
        datasource_max: Maximum bound from datasource config.
        missing_fields: Field names the file is missing.
        datasource_required_fields: Fields required by datasource config.
        file_modality: The file's actual modality (e.g., "OCT", "SLO").
        datasource_modality: Modality required by datasource config.
        file_series_description: The file's actual series description.
        datasource_series_description: Series description required by datasource config.

    Raises:
        ValueError: If multiple filter categories provided or none provided.
    """
    has_range = value is not None
    has_required_fields = missing_fields is not None
    has_modality = file_modality is not None
    has_series_description = file_series_description is not None

    categories_provided = sum(
        [has_range, has_required_fields, has_modality, has_series_description]
    )

    if categories_provided == 0:
        raise ValueError(
            "Must provide arguments for at least one filter category: "
            "range (value), required_fields (missing_fields), "
            "modality (file_modality), or series_description (file_series_description)"
        )
    if categories_provided > 1:
        raise ValueError(
            "Cannot mix filter categories. Provide arguments for only one of: "
            "range (value), required_fields (missing_fields), "
            "modality (file_modality), or series_description (file_series_description)"
        )

    if has_range:
        passes_datasource = meets_range_criteria(
            value,
            min_value=datasource_min,
            max_value=datasource_max,
        )
        return not passes_datasource

    if has_required_fields:
        if not datasource_required_fields:
            return False
        return bool(missing_fields & datasource_required_fields)

    if has_modality:
        if datasource_modality is None:
            return False
        return file_modality != datasource_modality

    if has_series_description:
        if datasource_series_description is None:
            return False
        return file_series_description != datasource_series_description

    # should not reach here
    return False


def meets_range_criteria(
    value: RangeBoundInput,
    min_value: Optional[RangeBoundInput] = None,
    max_value: Optional[RangeBoundInput] = None,
) -> bool:
    """Check if a value falls within an optional min/max range.

    This helper is used by filter methods to determine if a data value
    meets the configured filter criteria. Both bounds are inclusive.

    Args:
        value: The value to check. Must not be NaN.
        min_value: Optional minimum bound (inclusive). If None, no lower bound.
        max_value: Optional maximum bound (inclusive). If None, no upper bound.

    Returns:
        True if value is within the range, False otherwise.

    Raises:
        TypeError: If value and bounds have incompatible types (e.g., int vs date).
        ValueError: If value is NaN.

    Note:
        datetime values (for value or bounds) are automatically converted to date
        (time component is discarded) for consistent comparison.

    Examples:
        >>> meets_range_criteria(50, min_value=10, max_value=100)
        True
        >>> meets_range_criteria(5, min_value=10, max_value=100)
        False
        >>> meets_range_criteria(50, min_value=10)  # No upper bound
        True
        >>> meets_range_criteria(50)  # No bounds, always True
        True
    """
    if isinstance(value, float) and math.isnan(value):
        raise ValueError("NaN values cannot be used in range comparisons")

    # Normalize datetime to date for consistent comparison
    checked_value = value.date() if isinstance(value, datetime) else value
    checked_min = min_value.date() if isinstance(min_value, datetime) else min_value
    checked_max = max_value.date() if isinstance(max_value, datetime) else max_value

    if checked_min is not None:
        _check_type_compatibility(checked_value, checked_min, "min_value")
        # Type-narrow for comparison (compatibility already validated above)
        if isinstance(checked_value, date) and isinstance(checked_min, date):
            if checked_value < checked_min:
                return False
        elif isinstance(checked_value, (int, float)) and isinstance(
            checked_min, (int, float)
        ):
            if checked_value < checked_min:
                return False
        else:
            logger.error(
                f"Unexpected types after compatibility check: "
                f"value={checked_value}, min_value={checked_min}",
            )
            return False
    if checked_max is not None:
        _check_type_compatibility(checked_value, checked_max, "max_value")
        # Type-narrow for comparison (compatibility already validated above)
        if isinstance(checked_value, date) and isinstance(checked_max, date):
            if checked_value > checked_max:
                return False
        elif isinstance(checked_value, (int, float)) and isinstance(
            checked_max, (int, float)
        ):
            if checked_value > checked_max:
                return False

        else:
            logger.error(
                f"Unexpected types after compatibility check: "
                f"value={checked_value}, max_value={checked_max}",
            )
            return False
    return True


logger = logging.getLogger(__name__)
logger.addFilter(SampleFilter())


def resolve_int_filter(
    ds_value: Optional[int],
    task_value: Optional[TaskFilterValue],
    is_min: bool,
) -> Optional[int]:
    """Resolve an integer filter value using intersection logic.

    Args:
        ds_value: Datasource filter value
        task_value: Task filter value (should be int if not None)
        is_min: True for minimum filters (take max), False for maximum (take min)

    Returns:
        Resolved integer value or None
    """
    if task_value is None and ds_value is None:
        return None
    if task_value is None and ds_value is not None:
        return ds_value
    if task_value is not None and ds_value is None:
        return int(cast(int, task_value))

    task_value_as_int = int(cast(int, task_value))
    ds_value_as_int = int(cast(int, ds_value))

    is_more_restrictive = (is_min and task_value_as_int >= ds_value_as_int) or (
        not is_min and task_value_as_int <= ds_value_as_int
    )

    if is_more_restrictive:
        return task_value_as_int

    logger.warning(
        f"Task filter value {task_value_as_int} is less restrictive than "
        f"datasource filter value {ds_value_as_int}. Using datasource filter value."
    )
    return ds_value_as_int


def resolve_float_filter(
    ds_value: Optional[float],
    task_value: Optional[TaskFilterValue],
    is_min: bool,
) -> Optional[float]:
    """Resolve a float filter value using intersection logic.

    Args:
        ds_value: Datasource filter value
        task_value: Task filter value (should be float/int if not None)
        is_min: True for minimum filters (take max), False for maximum (take min)

    Returns:
        Resolved float value or None
    """
    if task_value is None and ds_value is None:
        return None
    if task_value is None and ds_value is not None:
        return ds_value
    if task_value is not None and ds_value is None:
        return float(cast(float, task_value))

    task_value_as_float = float(cast(float, task_value))
    ds_value_as_float = float(cast(float, ds_value))

    is_more_restrictive = (is_min and task_value_as_float >= ds_value_as_float) or (
        not is_min and task_value_as_float <= ds_value_as_float
    )

    if is_more_restrictive:
        return task_value_as_float

    logger.warning(
        f"Task filter value {task_value_as_float} is less restrictive than "
        f"datasource filter value {ds_value_as_float}. "
        "Using datasource filter value."
    )
    return ds_value_as_float


def to_date(value: Union[Date, DateTD, dict[str, int], None]) -> Optional[date]:
    """Convert a Date or DateTD object to a datetime.date object."""
    if value is None:
        return None
    if isinstance(value, Date):
        return value.get_date()
    if isinstance(value, dict):
        return Date(**value).get_date()
    return None


def resolve_date_filter(
    ds_value: Union[Date, DateTD, None],
    task_value: Optional[TaskFilterValue],
    is_min: bool,
) -> Optional[date]:
    """Resolve a date filter value using intersection logic.

    Converts Date/DateTD objects to datetime.date objects.

    Args:
        ds_value: Datasource filter value (Date or DateTD)
        task_value: Task filter value (should be Date or DateTD if not None)
        is_min: True for minimum filters (take max), False for maximum (take min)

    Returns:
        Resolved date value or None
    """
    ds_date = to_date(ds_value)
    task_date = to_date(task_value) if isinstance(task_value, (Date, dict)) else None

    if task_date is None and ds_date is None:
        return None
    if task_date is None and ds_date is not None:
        return ds_date
    if task_date is not None and ds_date is None:
        return task_date

    task_date_as_date = cast(date, task_date)
    ds_date_as_date = cast(date, ds_date)

    is_more_restrictive = (is_min and task_date_as_date >= ds_date_as_date) or (
        not is_min and task_date_as_date <= ds_date_as_date
    )

    if is_more_restrictive:
        return task_date_as_date

    logger.warning(
        f"Task filter value {task_date_as_date} is less restrictive than "
        f"datasource filter value {ds_date_as_date}. Using datasource filter value."
    )
    return ds_date_as_date


def resolve_list_filter(
    ds_value: Optional[list[str]],
    task_value: Optional[TaskFilterValue],
) -> Optional[list[str]]:
    """Resolve a list filter value by taking the union of both lists.

    Args:
        ds_value: Datasource filter value
        task_value: Task filter value (should be list[str] if not None)

    Returns:
        Union of the two lists or None
    """
    if task_value is None and ds_value is None:
        return None
    if task_value is None and ds_value is not None:
        return ds_value
    if task_value is not None and ds_value is None:
        return cast(list[str], task_value)

    task_value_as_list = cast(list[str], task_value)
    ds_value_as_list = cast(list[str], ds_value)

    return list(set(ds_value_as_list + task_value_as_list))


def resolve_bool_filter(
    ds_value: bool,
    task_value: Optional[TaskFilterValue],
) -> bool:
    """Resolve a bool filter - task can enable if datasource has disabled.

    Args:
        ds_value: Datasource filter value (defaults to False if not set)
        task_value: Task filter value (should be bool if not None)

    Returns:
        True if either datasource or task enables the filter, False otherwise
    """
    if task_value is True:
        return True
    return ds_value


def resolve_modality_filter(
    ds_value: Optional[Literal["OCT", "SLO"]],
    task_value: Optional[TaskFilterValue],
) -> Optional[Literal["OCT", "SLO"]]:
    """Resolve a modality filter value - must match if both present.

    Args:
        ds_value: Datasource filter value
        task_value: Task filter value (should be str if not None)

    Returns:
        Resolved modality value or None

    Raises:
        ValueError: If both values present but don't match
    """
    if task_value is None and ds_value is None:
        return None
    if task_value is None and ds_value is not None:
        return ds_value
    if task_value is not None and ds_value is None:
        return cast(Literal["OCT", "SLO"], task_value)

    task_value_as_modality = cast(Literal["OCT", "SLO"], task_value)
    ds_value_as_modality = cast(Literal["OCT", "SLO"], ds_value)

    if task_value_as_modality != ds_value_as_modality:
        raise ImpossibleValueFilterError(
            filter_name="modality",
            datasource_value=ds_value_as_modality,
            task_value=task_value_as_modality,
        )
    return ds_value_as_modality


def resolve_str_filter(
    filter_name: str,
    ds_value: Optional[str],
    task_value: Optional[TaskFilterValue],
) -> Optional[str]:
    """Resolve a string filter value - must match if both present."""
    if task_value is None and ds_value is None:
        return None
    if task_value is None and ds_value is not None:
        return ds_value
    if task_value is not None and ds_value is None:
        return str(task_value)
    if task_value is not None and ds_value is not None:
        task_value_as_str = str(task_value)
        ds_value_as_str = str(ds_value)
        if task_value_as_str != ds_value_as_str:
            raise ImpossibleValueFilterError(
                filter_name=filter_name,
                datasource_value=ds_value_as_str,
                task_value=task_value_as_str,
            )
        return ds_value_as_str
    return None


class _TaskFilterValueField(fields.Field):
    """Custom field that serializes Date objects to dicts for msgpack compatibility."""

    def _serialize(
        self,
        value: TaskFilterValue,
        attr: Optional[str],
        obj: Any,
        **kwargs: Any,
    ) -> SerializedTaskFilterValue:
        """Serialize Date objects to dicts; pass through other types unchanged."""
        if isinstance(value, Date):
            date_dict: dict[str, int] = {"year": value.year}
            if value.month is not None:
                date_dict["month"] = value.month
            if value.day is not None:
                date_dict["day"] = value.day
            return date_dict
        return value


_registry: dict[str, type["TaskFilter"]] = {}
registry: Mapping[str, type["TaskFilter"]] = MappingProxyType(_registry)


class TaskFilterType(Enum):
    """Types of task-level filters available at runtime.

    Each filter type maps to an existing filter capability in the codebase.
    Values use kebab-case for FE compatibility.
    """

    FILE_CREATION_MIN_DATE = "file-creation-min-date"
    FILE_CREATION_MAX_DATE = "file-creation-max-date"
    FILE_MODIFICATION_MIN_DATE = "file-modification-min-date"
    FILE_MODIFICATION_MAX_DATE = "file-modification-max-date"
    MIN_DOB = "min-dob"
    MAX_DOB = "max-dob"
    MIN_FILE_SIZE = "min-file-size"
    MAX_FILE_SIZE = "max-file-size"
    MIN_FRAMES = "min-frames"
    MAX_FRAMES = "max-frames"
    CHECK_REQUIRED_FIELDS = "check-required-fields"
    REQUIRED_FIELD_NAMES = "required-field-names"
    MODALITY = "modality"
    SCAN_ACQUISITION_MIN_DATE = "scan-acquisition-min-date"
    SCAN_ACQUISITION_MAX_DATE = "scan-acquisition-max-date"
    SERIES_DESCRIPTION = "series-description"


_INT_FILTER_TYPES = {TaskFilterType.MIN_FRAMES.value, TaskFilterType.MAX_FRAMES.value}
_FLOAT_FILTER_TYPES = {
    TaskFilterType.MIN_FILE_SIZE.value,
    TaskFilterType.MAX_FILE_SIZE.value,
}
_DATE_FILTER_TYPES = {
    TaskFilterType.FILE_CREATION_MIN_DATE.value,
    TaskFilterType.FILE_CREATION_MAX_DATE.value,
    TaskFilterType.FILE_MODIFICATION_MIN_DATE.value,
    TaskFilterType.FILE_MODIFICATION_MAX_DATE.value,
    TaskFilterType.MIN_DOB.value,
    TaskFilterType.MAX_DOB.value,
    TaskFilterType.SCAN_ACQUISITION_MIN_DATE.value,
    TaskFilterType.SCAN_ACQUISITION_MAX_DATE.value,
}
_STR_FILTER_TYPES = {TaskFilterType.SERIES_DESCRIPTION.value}
_BOOL_FILTER_TYPES = {TaskFilterType.CHECK_REQUIRED_FIELDS.value}
_LIST_FILTER_TYPES = {TaskFilterType.REQUIRED_FIELD_NAMES.value}
_MODALITY_FILTER_TYPES = {TaskFilterType.MODALITY.value}
_VALID_MODALITIES = {"OCT", "SLO"}


@dataclass
class TaskFilter(_BaseSerializableObjectMixIn):
    """A single task-level filter to apply at runtime.

    Task-level filters work with datasource-level filters using intersection
    logic. They can only further restrict data selection, not expand it.

    Args:
        filter_type: The type of filter (kebab-case string matching TaskFilterType).
        value: The filter value. Type depends on filter_type:
            - Date filters: dict with year (required), month (optional), day (optional)
            - Size filters: float (MB)
            - Frame filters: int
            - check-required-fields: bool to enable required field checking
            - required-field-names: list[str] of required field names to check
            - modality: str, either "OCT" or "SLO"

    Example:
        >>> filter1 = TaskFilter(filter_type="min-frames", value=49)
        >>> filter2 = TaskFilter(
        ...     filter_type="file-creation-min-date",
        ...     value={"year": 2024, "month": 1, "day": 1},
        ... )
        >>> filter3 = TaskFilter(
        ...     filter_type="check-required-fields",
        ...     value=True,
        ... )
        >>> filter4 = TaskFilter(
        ...     filter_type="required-field-names",
        ...     value=["Slice Thickness", "Pixel Spacing"],
        ... )
        >>> filter5 = TaskFilter(filter_type="modality", value="OCT")
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "class_name": fields.String(),
        "filter_type": fields.String(required=True),
        "value": _TaskFilterValueField(required=True),
    }
    nested_fields: ClassVar[T_NESTED_FIELDS] = {}

    filter_type: str
    value: TaskFilterValue

    def __post_init__(self) -> None:
        """Validate filter configuration after initialization."""
        self.class_name = type(self).__name__
        valid_types = {t.value for t in TaskFilterType}
        if self.filter_type not in valid_types:
            raise ValueError(
                f"Invalid filter_type '{self.filter_type}'. "
                f"Must be one of: {sorted(valid_types)}"
            )
        self._validate_value_type()

    def _validate_value_type(self) -> None:
        """Validate that the value matches the expected type for the filter_type."""
        if self.filter_type in _INT_FILTER_TYPES:
            if not isinstance(self.value, int) or isinstance(self.value, bool):
                raise TypeError(
                    f"Filter '{self.filter_type}' requires int value, "
                    f"got {type(self.value).__name__}"
                )
        elif self.filter_type in _FLOAT_FILTER_TYPES:
            if not isinstance(self.value, (int, float)) or isinstance(self.value, bool):
                raise TypeError(
                    f"Filter '{self.filter_type}' requires numeric value, "
                    f"got {type(self.value).__name__}"
                )
        elif self.filter_type in _DATE_FILTER_TYPES:
            if isinstance(self.value, Date):
                pass
            elif isinstance(self.value, dict):
                if "year" not in self.value:
                    raise TypeError(
                        f"Filter '{self.filter_type}' requires 'year' key in value"
                    )
            else:
                raise TypeError(
                    f"Filter '{self.filter_type}' requires Date or dict with "
                    f"year/month/day, got {type(self.value).__name__}"
                )
        elif self.filter_type in _STR_FILTER_TYPES:
            if not isinstance(self.value, str):
                raise TypeError(
                    f"Filter '{self.filter_type}' requires string value, "
                    f"got {type(self.value).__name__}"
                )
        elif self.filter_type in _BOOL_FILTER_TYPES:
            if not isinstance(self.value, bool):
                raise TypeError(
                    f"Filter '{self.filter_type}' requires bool value, "
                    f"got {type(self.value).__name__}"
                )
        elif self.filter_type in _LIST_FILTER_TYPES:
            if not isinstance(self.value, list):
                raise TypeError(
                    f"Filter '{self.filter_type}' requires list value, "
                    f"got {type(self.value).__name__}"
                )
            if not all(isinstance(item, str) for item in self.value):
                raise TypeError(f"Filter '{self.filter_type}' requires list of strings")
        elif self.filter_type in _MODALITY_FILTER_TYPES:
            if not isinstance(self.value, str):
                raise TypeError(
                    f"Filter '{self.filter_type}' requires string value, "
                    f"got {type(self.value).__name__}"
                )
            if self.value not in _VALID_MODALITIES:
                raise ValueError(
                    f"Filter '{self.filter_type}' value must be one of "
                    f"{sorted(_VALID_MODALITIES)}, got '{self.value}'"
                )
        else:
            raise ValueError(f"Unknown filter_type '{self.filter_type}'")


_registry["TaskFilter"] = TaskFilter


@dataclass
class MergedFilterConfig:
    """Effective filter configuration after merging task and datasource filters.

    This represents the final, resolved filter values that should be applied
    when loading data. It is produced by merging task-level filters with
    datasource-level filters using intersection logic (most restrictive wins).

    All fields are optional as different datasource types support different
    filter capabilities.
    """

    # Frame/B-scan count (ophthalmology)
    min_num_frames: Optional[int] = None
    max_num_frames: Optional[int] = None

    # Date of birth range
    minimum_dob: Optional[date] = None
    maximum_dob: Optional[date] = None

    # Required fields
    check_required_fields: bool = False
    required_field_names: Optional[list[str]] = field(default=None)

    # File system date filters
    file_creation_min_date: Optional[date] = None
    file_creation_max_date: Optional[date] = None
    file_modification_min_date: Optional[date] = None
    file_modification_max_date: Optional[date] = None

    # File size filters (MB)
    min_file_size: Optional[float] = None
    max_file_size: Optional[float] = None

    # Modality (ophthalmology)
    modality: Optional[Literal["OCT", "SLO"]] = None

    # Scan acquisition date filters (ophthalmology - DICOM AcquisitionDateTime)
    min_acquisition_date: Optional[date] = None
    max_acquisition_date: Optional[date] = None

    # Series description (ophthalmology)
    series_description: Optional[str] = None

    def __post_init__(self) -> None:
        """Validate the filter configuration after initialization."""
        if self.min_file_size is not None and self.max_file_size is not None:
            if self.min_file_size > self.max_file_size:
                raise ImpossibleRangeFilterError(
                    filter_name="min_file_size",
                    merged_min=self.min_file_size,
                    merged_max=self.max_file_size,
                )
        if self.min_num_frames is not None and self.max_num_frames is not None:
            if self.min_num_frames > self.max_num_frames:
                raise ImpossibleRangeFilterError(
                    filter_name="min_num_frames",
                    merged_min=self.min_num_frames,
                    merged_max=self.max_num_frames,
                )
        if self.minimum_dob is not None and self.maximum_dob is not None:
            if self.minimum_dob > self.maximum_dob:
                raise ImpossibleRangeFilterError(
                    filter_name="minimum_dob",
                    merged_min=self.minimum_dob,
                    merged_max=self.maximum_dob,
                )
        if (
            self.file_creation_min_date is not None
            and self.file_creation_max_date is not None
        ):
            if self.file_creation_min_date > self.file_creation_max_date:
                raise ImpossibleRangeFilterError(
                    filter_name="file_creation_min_date",
                    merged_min=self.file_creation_min_date,
                    merged_max=self.file_creation_max_date,
                )
        if (
            self.file_modification_min_date is not None
            and self.file_modification_max_date is not None
        ):
            if self.file_modification_min_date > self.file_modification_max_date:
                raise ImpossibleRangeFilterError(
                    filter_name="file_modification_min_date",
                    merged_min=self.file_modification_min_date,
                    merged_max=self.file_modification_max_date,
                )
        if (
            self.min_acquisition_date is not None
            and self.max_acquisition_date is not None
        ):
            if self.min_acquisition_date > self.max_acquisition_date:
                raise ImpossibleRangeFilterError(
                    filter_name="min_acquisition_date",
                    merged_min=self.min_acquisition_date,
                    merged_max=self.max_acquisition_date,
                )
