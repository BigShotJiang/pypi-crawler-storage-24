"""Module containing NIFTISource class.

NIFTISource class handles loading of NIfTI neuroimaging data.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Optional, Union

import nibabel as nib
import numpy as np
import pandas as pd

from bitfount.data.datasources.base_source import FileSystemIterableSourceInferrable
from bitfount.data.datasources.utils import FileSkipReason, FileSystemFilter
from bitfount.utils import delegates

logger = logging.getLogger(__name__)

NIFTI_FILE_EXTENSIONS: list[str] = [".nii", ".nii.gz"]
NIFTI_IMAGE_ATTRIBUTE = "Pixel Data"

# MONAI-compatible metadata column names
# These are used by MONAI transforms (Orientationd, Spacingd, SaveImaged, etc.)
MONAI_AFFINE_KEY = "Affine"
MONAI_ORIGINAL_AFFINE_KEY = "OriginalAffine"
MONAI_PIXDIM_KEY = "Pixdim"
MONAI_SPATIAL_SHAPE_KEY = "SpatialShape"
MONAI_FILEPATH_KEY = "FilePath"
MONAI_ORIGINAL_CHANNEL_DIM_KEY = "OriginalChannelDim"


def _is_nifti_file(filename: str, extensions: list[str]) -> bool:
    """Check if a file has a NIfTI extension.

    Handles compound extensions like .nii.gz properly.

    Args:
        filename: The filename to check.
        extensions: List of allowed extensions.

    Returns:
        True if the file has an allowed NIfTI extension.
    """
    filename_lower = filename.lower()
    for ext in extensions:
        if filename_lower.endswith(ext.lower()):
            return True
    return False


@delegates()
class NIFTISource(FileSystemIterableSourceInferrable):
    """Data source for loading NIfTI neuroimaging files.

    NIfTI (Neuroimaging Informatics Technology Initiative) is a common file format
    for storing brain imaging data from MRI and fMRI scans.

    Args:
        path: The path to the directory containing the NIfTI files.
        file_extensions: The file extensions to look for.
            If None, defaults to ['.nii', '.nii.gz'].
        **kwargs: Keyword arguments passed to the parent base classes.
    """

    def __init__(
        self,
        # pyrefly: ignore [implicit-any]
        path: Union[os.PathLike, str],
        file_extensions: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> None:
        if file_extensions is None:
            file_extensions = NIFTI_FILE_EXTENSIONS
        self.file_extensions = file_extensions

        # Handle the filter - we need special handling for .nii.gz compound extension
        # FileSystemFilter can't handle compound extensions like .nii.gz properly
        # (it only looks at the last suffix), so we use .nii and .gz for the filter
        # and then apply our own datasource filter for proper NIfTI matching
        filter_: Optional[FileSystemFilter] = kwargs.pop("filter", None)
        if filter_ is None:
            # Use both .nii and .gz to allow the filesystem filter to pass through
            # both uncompressed and compressed NIfTI files
            filter_ = FileSystemFilter(file_extension=[".nii", ".gz"])

        super().__init__(path=path, filter=filter_, **kwargs)
        self.image_columns = {NIFTI_IMAGE_ATTRIBUTE}

        # Add a datasource filter to properly filter NIfTI files
        # This handles .nii.gz properly by checking the full filename
        self._datasource_filters_to_apply.append(self._filter_nifti_files)

    def _filter_nifti_files(self, file_names: list[str]) -> list[str]:
        """Filter files to only include valid NIfTI files.

        Args:
            file_names: List of file names to filter.

        Returns:
            Filtered list containing only NIfTI files.
        """
        return [f for f in file_names if _is_nifti_file(f, self.file_extensions)]

    def _process_file(
        self,
        filename: str,
        skip_non_tabular_data: bool = False,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Loads the NIfTI file specified by `filename`.

        Args:
            filename: The name of the file to process. Can be an absolute path or
                a relative path/filename which will be resolved relative to self.path.
            skip_non_tabular_data: Whether we can avoid loading non-tabular data,
                e.g. image data (can be set to True when generating schemas).
            **kwargs: Additional keyword arguments.

        Returns:
            The processed NIfTI data as a dictionary of keys and values within a list
            containing just that element.
        """
        # Ensure we have a full path - if filename is not absolute, resolve it
        # relative to the datasource's base path
        filepath = filename
        if not os.path.isabs(filename):
            filepath = os.path.join(self.path, filename)

        try:
            data = self._process_nifti_file(
                filepath, skip_non_tabular_data=skip_non_tabular_data
            )
        except FileNotFoundError as e:
            logger.warning(
                f"File no longer exists (moved/deleted?): {filepath}. Skipping. ({e})"
            )
            # Use task_skip_file so this is not persisted to cache; the file may
            # reappear (e.g. network path back) and will be retried in later runs.
            self.task_skip_file(filepath, FileSkipReason.FILE_NOT_FOUND)
            return []
        except Exception as e:
            logger.warning(f"Unexpected error when processing file {filepath}: {e}.")
            data = None

        if not data:
            logger.warning(f"Skipping file {filepath}.")
            self.skip_file(filepath, FileSkipReason.IMAGE_EMPTY_DATA)
            return []

        return [data]

    def _process_nifti_file(
        self,
        filename: str,
        skip_non_tabular_data: bool = False,
    ) -> Optional[dict[str, Any]]:
        """Read and process the NIfTI file.

        Args:
            filename: The filename of the file to be processed.
            skip_non_tabular_data: Don't load voxel data from file. Header metadata
                is still extracted since nibabel loads headers lazily (voxel data
                is only loaded when explicitly accessed via np.asarray(img.dataobj)).

        Returns:
            The processed NIfTI data as a dictionary.

        Raises:
            FileNotFoundError: If the file is missing. Callers are expected to
                handle this (e.g. to skip without persisting to cache).
        """
        data: dict[str, Any] = {}

        # Add basic file metadata
        data["Filename"] = os.path.basename(filename)
        # Handle .nii.gz extension properly (case-insensitive to match _is_nifti_file)
        if filename.lower().endswith(".nii.gz"):
            data["FileExtension"] = ".nii.gz"
        else:
            data["FileExtension"] = os.path.splitext(filename)[1].lower()

        try:
            # Load NIfTI file using nibabel
            # nibabel loads headers lazily - voxel data is only loaded when
            # explicitly accessed via np.asarray(img.dataobj), so we can safely
            # extract all header metadata without loading the expensive voxel data.
            # Type check ensures proper type hints (works for NIfTI-1 and NIfTI-2)
            img = nib.load(filename)
            if not isinstance(img, (nib.Nifti1Image, nib.Nifti2Image)):
                img_type = type(img).__name__
                logger.warning(f"File {filename} is not a NIfTI file, got {img_type}")
                return None

            header = img.header

            # Extract image shape using header method for type safety
            shape = img.header.get_data_shape()
            data["ImageShape"] = str(shape)
            data["ImageDimensions"] = len(shape)

            # Extract voxel dimensions (zooms) - typically in mm
            zooms = header.get_zooms()
            data["VoxelDimensions"] = str(zooms)

            # Extract spatial dimensions separately for convenience
            if len(zooms) >= 3:
                data["VoxelSizeX"] = float(zooms[0])
                data["VoxelSizeY"] = float(zooms[1])
                data["VoxelSizeZ"] = float(zooms[2])
            if len(zooms) >= 4:
                data["TemporalResolution"] = float(zooms[3])

            # Get data type
            data["DataType"] = str(header.get_data_dtype())

            # Get affine transformation matrix (4x4)
            affine = img.affine
            if affine is None:
                raise ValueError(f"Affine matrix is None for file {filename}")
            data["AffineMatrix"] = affine.flatten().tolist()

            # Add MONAI-compatible metadata for transforms
            self._add_monai_metadata(data, affine, zooms, shape, filename)

            # Get spatial and temporal units
            xyzt_units = header.get_xyzt_units()
            data["SpatialUnits"] = xyzt_units[0] if xyzt_units else "unknown"
            data["TemporalUnits"] = (
                xyzt_units[1] if xyzt_units and len(xyzt_units) > 1 else "unknown"
            )

            # Calculate number of volumes (for 4D+ data like fMRI, diffusion MRI)
            # NIfTI supports up to 7 dimensions - shape[3] is the number of volumes
            # for any data with 4 or more dimensions
            if len(shape) >= 4:
                data["NumberOfVolumes"] = shape[3]
            else:
                data["NumberOfVolumes"] = 1

            # Get the actual voxel data as numpy array, or skip if requested
            # This is the expensive operation - voxel data is loaded lazily
            if skip_non_tabular_data:
                data[NIFTI_IMAGE_ATTRIBUTE] = "<SKIPPED>"
            else:
                arr = np.asarray(img.dataobj)
                data[NIFTI_IMAGE_ATTRIBUTE] = arr

        except FileNotFoundError:
            raise
        except Exception as e:
            logger.warning(f"Error when reading NIfTI file {filename}: {e}")
            return None

        return data

    def _add_monai_metadata(
        self,
        data: dict[str, Any],
        affine: np.ndarray[Any, Any],
        zooms: tuple[float, ...],
        shape: tuple[int, ...],
        filename: str,
    ) -> None:
        """Add MONAI-compatible metadata to the data dictionary.

        This metadata is used by MONAI transforms (Orientationd, Spacingd,
        SaveImaged, EnsureChannelFirstd, etc.) for spatial operations.

        Args:
            data: The data dictionary to add metadata to.
            affine: The 4x4 affine transformation matrix.
            zooms: The voxel dimensions (spacing) tuple.
            shape: The image shape tuple.
            filename: The full path to the NIfTI file.
        """
        # Affine as numpy array (not flattened) for MONAI spatial transforms
        data[MONAI_AFFINE_KEY] = affine.copy()
        # OriginalAffine preserved for inverse transforms and SaveImaged
        data[MONAI_ORIGINAL_AFFINE_KEY] = affine.copy()

        # Pixdim as numpy array for MONAI Spacingd compatibility
        # This is the voxel spacing in physical units (typically mm)
        data[MONAI_PIXDIM_KEY] = np.array(zooms, dtype=np.float32)

        # SpatialShape as tuple (excluding time dimension for 4D data)
        # Used by MONAI CropForegroundd and spatial transforms
        spatial_ndim = min(3, len(shape))
        data[MONAI_SPATIAL_SHAPE_KEY] = shape[:spatial_ndim]

        # Full absolute file path for MONAI SaveImaged
        data[MONAI_FILEPATH_KEY] = os.path.abspath(filename)

        # Channel dimension index for MONAI EnsureChannelFirstd
        # None for standard 3D medical images without explicit channel dimension
        data[MONAI_ORIGINAL_CHANNEL_DIM_KEY] = None

    def _process_dataset(self, dataframe: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        """Process the dataset after loading.

        Args:
            dataframe: The dataframe to process.
            **kwargs: Additional keyword arguments.

        Returns:
            The processed dataframe.
        """
        return dataframe

    def _extract_file_metadata_for_telemetry(
        self, data: Optional[dict[str, Any]]
    ) -> dict[str, Any]:
        """Extracts file metadata for telemetry.

        Args:
            data: The data to extract metadata from.

        Returns:
            A dictionary of file metadata.
        """
        telemetry_data: dict[str, Any] = {}
        if data is None:
            return telemetry_data

        telemetry_data.update(
            {
                # Override base class file_extension which uses os.path.splitext
                # and returns ".gz" for compound extensions like ".nii.gz"
                "file_extension": data.get("FileExtension"),
                "image_shape": data.get("ImageShape"),
                "image_dimensions": data.get("ImageDimensions"),
                "voxel_dimensions": data.get("VoxelDimensions"),
                "data_type": data.get("DataType"),
                "spatial_units": data.get("SpatialUnits"),
                "temporal_units": data.get("TemporalUnits"),
                "number_of_volumes": data.get("NumberOfVolumes"),
            }
        )

        return telemetry_data
