"""Data source for loading ophthalmology files using private-eye."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from dataclasses import dataclass
import datetime
import logging
import os
from pathlib import Path
from typing import Any, NotRequired, Optional, TypedDict, Union

import desert
from marshmallow import fields, validate
import numpy as np

from bitfount import config
from bitfount.data.datasources.base_source import FileSystemIterableSourceInferrable
from bitfount.data.datasources.ophthalmology.ophth_ds_types import (
    DEFAULT_REQUIRED_FIELDS_FOR_CALCULATIONS,
)
from bitfount.data.datasources.types import (
    Date,
    DateTD,
    FilterConfig,
    OphthalmologyModalityType,
)
from bitfount.data.datasources.utils import FileSkipReason, get_datetime
from bitfount.data.exceptions import DataNotAvailableError
from bitfount.data.filters import should_persist_skip_to_cache
from bitfount.types import UsedForConfigSchemas
from bitfount.utils import delegates

logger = logging.getLogger(__name__)

OPHTHALMOLOGY_MODALITIES: list[str] = ["OCT", "SLO"]
OCT_ACQUISITION_DEVICE_TYPE = "Optical Coherence Tomography Scanner"
SLO_ACQUISITION_DEVICE_TYPE = "Scanning Laser Ophthalmoscope"
ACQUISITION_DEVICE_TYPE_MODALITY_MAPPING: dict[str, OphthalmologyModalityType] = {
    OCT_ACQUISITION_DEVICE_TYPE: "OCT",
    "OCT": "OCT",
    SLO_ACQUISITION_DEVICE_TYPE: "SLO",
    "SLO": "SLO",
}
IMAGE_COLUMN_PREFIX: str = "Pixel Data"
SLO_IMAGE_ATTRIBUTE: str = "SLO Image Data"


@dataclass
class OphthalmologyDataSourceArgs(UsedForConfigSchemas):
    """Arguments for ophthalmology modality data.

    More information about the acquisition device types can be found in the
    DICOM standard supplements 91 and 110.

    Args:
        modality: The modality of the data. Must be either 'OCT', 'SLO' or None. OCT
            refers to Optical Coherence Tomography (OCT), typically these are a series
            of 2D images used to show a cross-section of the tissue layers in the
            retina (specifically the macula), combined to form a 3D image. SLO
            refers to Scanning Laser Ophthalmoscope (SLO), typically referred
            to as an 'en-face' image of the retina (specifically the macula). Defaults
            to None.
        match_slo: Only relevant if `modality` is 'OCT'. Whether to match SLO files
            to OCT files on a best effort basis. If true, patient name, date of birth
            and laterality must be an exact match on the OCT and SLO files. Acquistion
            date and time must be within 24 hours of each other. Defaults to True.
        drop_row_on_missing_slo: Only relevant if `modality` is 'OCT' and `match_slo`
            is True. Whether to drop the OCT row if the corresponding SLO file is
            missing i.e. ignore the OCT file. Defaults to False.
        minimum_dob: The minimum date of birth to consider. If not None, only patients
            with a date of birth greater than or equal to this value will be considered.
            Defaults to None.
        maximum_dob: The maximum date of birth to consider. If not None, only patients
            with a date of birth less than or equal to this value will be considered.
            Defaults to None.
        minimum_num_bscans: The minimum number of B-scans to consider. If not None, only
            files with a number of B-scans greater than or equal to this value will be
            considered. Defaults to None.
        maximum_num_bscans: The maximum number of B-scans to consider. If not None, only
            files with a number of B-scans less than or equal to this value will be
            considered. Defaults to None.
        check_required_fields: Whether to filter out files that are missing required
            fields for calculations. Defaults to False.
        required_field_names: List of required field names to check for. If None,
            uses default required fields for calculations. If specified, overrides the
            default required fields for calculations.
        minimum_acquisition_date: The minimum scan acquisition date to consider. If not
            None, only files with an acquisition date greater than or equal to this
            value will be considered. Defaults to None.
        maximum_acquisition_date: The maximum scan acquisition date to consider. If not
            None, only files with an acquisition date less than or equal to this
            value will be considered. Defaults to None.
        series_description: The series description to consider. If not None, only files
            with a series description matching this value will be considered. Defaults
            to None.
    """

    modality: OphthalmologyModalityType = desert.field(
        fields.String(validate=validate.OneOf(("OCT", "SLO")), allow_none=True),
        default=None,
    )
    match_slo: bool = False
    drop_row_on_missing_slo: bool = False

    # desert typing is actually stricter than the type checking as Date and DateTD will
    # look the same when serialized so we restrict to Date only
    minimum_dob: Optional[Union[Date, DateTD]] = desert.field(
        fields.Nested(desert.schema_class(Date), allow_none=True), default=None
    )
    maximum_dob: Optional[Union[Date, DateTD]] = desert.field(
        fields.Nested(desert.schema_class(Date), allow_none=True), default=None
    )

    minimum_num_bscans: Optional[int] = None
    maximum_num_bscans: Optional[int] = None

    check_required_fields: bool = False
    required_field_names: Optional[list[str]] = None

    minimum_acquisition_date: Optional[Union[Date, DateTD]] = desert.field(
        fields.Nested(desert.schema_class(Date), allow_none=True), default=None
    )
    maximum_acquisition_date: Optional[Union[Date, DateTD]] = desert.field(
        fields.Nested(desert.schema_class(Date), allow_none=True), default=None
    )
    series_description: Optional[str] = desert.field(
        fields.String(allow_none=True), default=None
    )

    def __post_init__(self) -> None:
        # OCT/SLO strings kept for private-eye source compatibility
        self.oct_string = "OCT"
        self.slo_string = "SLO"

        if self.modality is None:
            if self.match_slo or self.drop_row_on_missing_slo:
                raise ValueError(
                    "If `modality` is not specified, then `match_slo` and "
                    "`drop_row_on_missing_slo` must be False."
                )
        elif self.modality == self.oct_string:
            if not self.match_slo and self.drop_row_on_missing_slo:
                logger.warning(
                    "`drop_row_on_missing_slo` is only relevant if `match_slo` is True."
                    " It will be ignored."
                )

        elif self.modality == self.slo_string:
            if self.match_slo or self.drop_row_on_missing_slo:
                raise ValueError(
                    "If `modality` is 'SLO', then `match_slo` and "
                    "`drop_row_on_missing_slo` must be False."
                )
        else:
            raise ValueError(
                f"Unsupported modality: '{self.modality}'. "
                "If specified, must be one of "
                f"{', '.join(OPHTHALMOLOGY_MODALITIES)}."
            )

        # Set default required field names if not specified
        if self.required_field_names is None:
            self.required_field_names = DEFAULT_REQUIRED_FIELDS_FOR_CALCULATIONS.copy()


class _OphthalmologyDataSourceArgsTD(TypedDict):
    """Typed dict form of OphthalmologyDataSourceArgs dataclass."""

    modality: OphthalmologyModalityType
    match_slo: NotRequired[bool]
    drop_row_on_missing_slo: NotRequired[bool]
    minimum_dob: NotRequired[DateTD]
    maximum_dob: NotRequired[DateTD]
    minimum_num_bscans: NotRequired[int]
    maximum_num_bscans: NotRequired[int]
    check_required_fields: NotRequired[bool]
    required_field_names: NotRequired[list[str]]
    minimum_acquisition_date: NotRequired[DateTD]
    maximum_acquisition_date: NotRequired[DateTD]
    series_description: NotRequired[str]


@delegates()
class _OphthalmologySource(FileSystemIterableSourceInferrable, ABC):
    """Base OphthalmologySource.

    Args:
        path: Path to the directory which contains the data files. Subdirectories
            will be searched recursively.
        ophthalmology_args: Arguments for ophthalmology modality data.
        **kwargs: Additional keyword arguments to pass to the base class.

    Raises:
        ValueError: If the minimum DOB is greater than the maximum DOB.
        ValueError: If the minimum number of B-scans is greater than the maximum number
            of B-scans.
        ValueError: If the minimum acquisition date is greater than the maximum
            acquisition date.
    """

    def __init__(
        self,
        path: Union[str, os.PathLike[str]],
        ophthalmology_args: Optional[
            Union[OphthalmologyDataSourceArgs, _OphthalmologyDataSourceArgsTD]
        ] = None,
        **kwargs: Any,
    ) -> None:
        # Parse the ophthalmology arguments, converting from the dict-form to
        # dataclass-form if needed
        if ophthalmology_args is None:
            self.ophthalmology_args = OphthalmologyDataSourceArgs()
        elif isinstance(ophthalmology_args, OphthalmologyDataSourceArgs):
            self.ophthalmology_args = ophthalmology_args
        else:
            self.ophthalmology_args = OphthalmologyDataSourceArgs(**ophthalmology_args)

        # DOB conversion and validation
        self.minimum_dob_date: Optional[datetime.date] = get_datetime(
            self.ophthalmology_args.minimum_dob
        )
        self.maximum_dob_date: Optional[datetime.date] = get_datetime(
            self.ophthalmology_args.maximum_dob
        )
        if (
            self.minimum_dob_date
            and self.maximum_dob_date
            and self.minimum_dob_date > self.maximum_dob_date
        ):
            raise ValueError(
                "The minimum DOB must be less than or equal to the maximum DOB."
            )

        # B-scan validation
        self.minimum_num_bscans: Optional[int] = (
            self.ophthalmology_args.minimum_num_bscans
        )
        self.maximum_num_bscans: Optional[int] = (
            self.ophthalmology_args.maximum_num_bscans
        )
        if (
            self.minimum_num_bscans
            and self.maximum_num_bscans
            and self.minimum_num_bscans > self.maximum_num_bscans
        ):
            raise ValueError(
                "The minimum number of B-scans must be less than or equal to the "
                "maximum number of B-scans."
            )

        self.minimum_acquisition_date: Optional[datetime.date] = get_datetime(
            self.ophthalmology_args.minimum_acquisition_date
        )
        self.maximum_acquisition_date: Optional[datetime.date] = get_datetime(
            self.ophthalmology_args.maximum_acquisition_date
        )
        if (
            self.minimum_acquisition_date
            and self.maximum_acquisition_date
            and self.minimum_acquisition_date > self.maximum_acquisition_date
        ):
            raise ValueError(
                "The minimum acquisition date must be less than or equal to the "
                "maximum acquisition date."
            )
        self.series_description: Optional[str] = (
            self.ophthalmology_args.series_description
        )

        super().__init__(path=path, **kwargs)

        # Cache for expensive additional_metrics calculation
        self._cached_additional_metrics: Optional[dict[str, Any]] = None

        # Required fields configuration (must be after super().__init__)
        self.check_required_fields: bool = self.ophthalmology_args.check_required_fields
        # Only initialize required field names if the filter is enabled
        self.required_field_names: list[str]
        if self.check_required_fields:
            # Use configured required field names, or default if not provided
            self.required_field_names = (
                self.ophthalmology_args.required_field_names
                if self.ophthalmology_args.required_field_names is not None
                else DEFAULT_REQUIRED_FIELDS_FOR_CALCULATIONS.copy()
            )
        else:
            self.required_field_names = []

        self._datasource_filters_to_apply.append(self._filter_files_by_dob)
        self._datasource_filters_to_apply.append(self._filter_files_by_acquisition_date)
        self._datasource_filters_to_apply.append(self._filter_files_by_num_bscans)
        self._datasource_filters_to_apply.append(self._filter_files_by_required_fields)
        self._datasource_filters_to_apply.append(
            self._filter_files_by_series_description
        )

    @abstractmethod
    def _get_dob_from_cache(self, file_names: list[str]) -> dict[str, datetime.date]:
        """Get the date of birth from the cache.

        Args:
            file_names: The filenames of the files to be processed.

        Returns:
            The date of birth of the patient or None if the field is missing.
        """
        raise NotImplementedError

    @abstractmethod
    def _get_num_bscans_from_cache(self, file_names: list[str]) -> dict[str, int]:
        """Get the number of B-scans from the cache.

        Args:
            file_names: The filenames of the files to be processed.

        Returns:
            The number of B-scans in the file or None if the field is missing.
        """
        raise NotImplementedError

    @abstractmethod
    def _get_acquisition_date_from_cache(
        self, file_names: list[str]
    ) -> dict[str, datetime.date]:
        """Get the acquisition date from the cache.

        Args:
            file_names: The filenames of the files to be processed.

        Returns:
            A dict mapping file names to their acquisition dates.
        """
        raise NotImplementedError

    @abstractmethod
    def _get_series_description_from_cache(
        self, file_names: list[str]
    ) -> dict[str, str]:
        """Get the series description from the cache.

        Args:
            file_names: The filenames of the files to be processed.

        Returns:
            A dict mapping file names to their series descriptions.
        """
        raise NotImplementedError

    @staticmethod
    def _convert_string_to_datetime(
        date_str: str, fmt: str = "%Y%m%d"
    ) -> datetime.datetime:
        """Convert a date string to a datetime object.

        Args:
            date_str: The date string to be converted.
            fmt: The format to use to parse the date string.

        Returns:
            The datetime object.
        """
        return datetime.datetime.strptime(date_str, fmt)

    def _get_oct_images_from_paths(
        self, save_path: Path, file_prefix: str
    ) -> list[Path]:
        """Retrieve OCT PNG images that were generated from `file_prefix`.

        NOTE: This method of getting the OCT images is deprecated and only
        kept for private-eye compatibility.
        """
        oct_file_pattern = f"*{file_prefix}"
        if self.ophthalmology_args:
            oct_file_pattern += f"*-{self.ophthalmology_args.oct_string}*"
        return [
            x
            for x in save_path.glob(oct_file_pattern)
            if x.is_file() and x.suffix == ".png"
        ]

    def _get_images_from_dict(
        self,
        image_arrays: list[Mapping[str, np.ndarray]],  # pyrefly: ignore[implicit-any]
    ) -> dict[str, np.ndarray]:  # pyrefly: ignore[implicit-any]
        """Retrieve OCT and SLO image arrays.

        NOTE: This method of getting the OCT images is deprecated and only
        kept for private-eye compatibility.
        """
        data = {}
        if self.ophthalmology_args and self.ophthalmology_args.oct_string:
            for item in image_arrays:
                for key, value in item.items():
                    modality, idx = key.split("-")
                    if (
                        self.ophthalmology_args.oct_string
                        and self.ophthalmology_args.oct_string in modality
                    ):
                        img_col_name = f"{IMAGE_COLUMN_PREFIX} {idx}"
                        data[img_col_name] = value
                        self.image_columns.add(img_col_name)
                    elif (
                        self.ophthalmology_args.slo_string
                        and self.ophthalmology_args.slo_string in modality
                    ):
                        slo_img_col_name = f"{SLO_IMAGE_ATTRIBUTE} {idx}"
                        data[slo_img_col_name] = value
                        self.image_columns.add(slo_img_col_name)
        else:
            logger.warning("Ophthalmology args not set, no images will be loaded.")

        return data

    def _get_slo_images_from_paths(
        self, save_path: Path, file_prefix: str
    ) -> list[Path]:
        """Retrieve SLO PNG images that were generated from `file_prefix`.

        NOTE: This method of getting the OCT images is deprecated and only
        kept for private-eye compatibility.
        """
        slo_file_pattern = f"*{file_prefix}"
        if self.ophthalmology_args:
            slo_file_pattern += f"*-{self.ophthalmology_args.slo_string}*"
        return [
            x
            for x in save_path.glob(slo_file_pattern)
            if x.is_file() and x.suffix == ".png"
        ]

    def _filter_files_by_dob(self, file_names: list[str]) -> list[str]:
        """Filter the files by date of birth.

        Note that the min_dob and max_dob from the merged filter config
        take precedence over the minimum_dob and maximum_dob
        from the ophthalmology_args.

        Args:
            file_names: The list of file names to be filtered.

        Returns:
            The filtered list of file names.
        """
        merged = self.merged_filter_config
        minimum_dob: Optional[datetime.date] = (
            merged.minimum_dob
            if merged is not None and merged.minimum_dob is not None
            else self.minimum_dob_date
        )
        maximum_dob: Optional[datetime.date] = (
            merged.maximum_dob
            if merged is not None and merged.maximum_dob is not None
            else self.maximum_dob_date
        )

        if not minimum_dob and not maximum_dob:
            return file_names

        filtered_file_names: list[str] = []
        dob_datetimes = self._get_dob_from_cache(file_names)

        for file_name in file_names:
            dob_datetime = dob_datetimes.get(file_name)
            if dob_datetime is not None:
                meets_dob_criteria = True
                if minimum_dob is not None:
                    meets_dob_criteria = dob_datetime >= minimum_dob
                if meets_dob_criteria and maximum_dob is not None:
                    meets_dob_criteria = dob_datetime <= maximum_dob
                if meets_dob_criteria:
                    filtered_file_names.append(file_name)
                else:
                    persist = should_persist_skip_to_cache(
                        value=dob_datetime,
                        datasource_min=self.minimum_dob_date,
                        datasource_max=self.maximum_dob_date,
                    )
                    if persist:
                        self.skip_file(
                            file_name,
                            FileSkipReason.OPHTH_DOB_OUT_OF_RANGE,
                        )
                    else:
                        self.task_skip_file(
                            file_name, FileSkipReason.OPHTH_DOB_OUT_OF_RANGE
                        )
            else:
                if self.minimum_dob_date or self.maximum_dob_date:
                    self.skip_file(file_name, FileSkipReason.OPHTH_DOB_UNAVAILABLE)
                else:
                    self.task_skip_file(file_name, FileSkipReason.OPHTH_DOB_UNAVAILABLE)

        return filtered_file_names

    def _filter_files_by_acquisition_date(self, file_names: list[str]) -> list[str]:
        """Filter the files by scan acquisition date.

        Note that the min_acquisition_date and max_acquisition_date from the merged
        filter config take precedence over the minimum_acquisition_date and
        maximum_acquisition_date from the ophthalmology_args.

        Args:
            file_names: The list of file names to be filtered.

        Returns:
            The filtered list of file names.
        """
        merged = self.merged_filter_config
        minimum_acquisition: Optional[datetime.date] = (
            merged.min_acquisition_date
            if merged is not None and merged.min_acquisition_date is not None
            else self.minimum_acquisition_date
        )
        maximum_acquisition: Optional[datetime.date] = (
            merged.max_acquisition_date
            if merged is not None and merged.max_acquisition_date is not None
            else self.maximum_acquisition_date
        )

        if not minimum_acquisition and not maximum_acquisition:
            return file_names

        filtered_file_names: list[str] = []
        acquisition_dates = self._get_acquisition_date_from_cache(file_names)

        for file_name in file_names:
            acquisition_date = acquisition_dates.get(file_name)
            if acquisition_date is not None:
                meets_criteria = True
                if minimum_acquisition is not None:
                    meets_criteria = acquisition_date >= minimum_acquisition
                if meets_criteria and maximum_acquisition is not None:
                    meets_criteria = acquisition_date <= maximum_acquisition
                if meets_criteria:
                    filtered_file_names.append(file_name)
                else:
                    persist = should_persist_skip_to_cache(
                        value=acquisition_date,
                        datasource_min=self.minimum_acquisition_date,
                        datasource_max=self.maximum_acquisition_date,
                    )
                    if persist:
                        self.skip_file(
                            file_name,
                            FileSkipReason.OPHTH_ACQUISITION_DATE_OUT_OF_RANGE,
                        )
                    else:
                        self.task_skip_file(
                            file_name,
                            FileSkipReason.OPHTH_ACQUISITION_DATE_OUT_OF_RANGE,
                        )
            else:
                if self.minimum_acquisition_date or self.maximum_acquisition_date:
                    self.skip_file(
                        file_name, FileSkipReason.OPHTH_ACQUISITION_DATE_UNAVAILABLE
                    )
                else:
                    self.task_skip_file(
                        file_name, FileSkipReason.OPHTH_ACQUISITION_DATE_UNAVAILABLE
                    )
        return filtered_file_names

    def _filter_files_by_series_description(self, file_names: list[str]) -> list[str]:
        """Filter the files by series description.

        Args:
            file_names: The list of file names to be filtered.

        Returns:
            The filtered list of file names.
        """
        merged = self.merged_filter_config
        series_description: Optional[str] = (
            merged.series_description
            if merged is not None and merged.series_description is not None
            else self.series_description
        )

        if not series_description:
            return file_names

        filtered_file_names: list[str] = []
        series_descriptions = self._get_series_description_from_cache(file_names)

        for file_name in file_names:
            series_description_file = series_descriptions.get(file_name)
            if series_description_file is not None:
                meets_criteria = series_description_file == series_description
                if meets_criteria:
                    filtered_file_names.append(file_name)
                else:
                    persist = should_persist_skip_to_cache(
                        file_series_description=series_description_file,
                        datasource_series_description=self.series_description,
                    )
                    if persist:
                        self.skip_file(
                            file_name, FileSkipReason.OPHTH_SERIES_DESCRIPTION_MISMATCH
                        )
                    else:
                        self.task_skip_file(
                            file_name, FileSkipReason.OPHTH_SERIES_DESCRIPTION_MISMATCH
                        )
            else:
                if self.series_description is not None:
                    self.skip_file(
                        file_name, FileSkipReason.OPHTH_SERIES_DESCRIPTION_UNAVAILABLE
                    )
                else:
                    self.task_skip_file(
                        file_name, FileSkipReason.OPHTH_SERIES_DESCRIPTION_UNAVAILABLE
                    )
        return filtered_file_names

    def _filter_files_by_num_bscans(self, file_names: list[str]) -> list[str]:
        """Filter the files by number of B-scans.

        Note that the min_num_frames and max_num_frames from the merged filter config
        take precedence over the minimum_num_bscans and maximum_num_bscans
        from the ophthalmology_args.

        Args:
            file_names: The list of file names to be filtered.

        Returns:
            The filtered list of file names.
        """
        merged = self.merged_filter_config
        minimum_num_bscans: Optional[int] = (
            merged.min_num_frames
            if merged is not None and merged.min_num_frames is not None
            else self.minimum_num_bscans
        )
        maximum_num_bscans: Optional[int] = (
            merged.max_num_frames
            if merged is not None and merged.max_num_frames is not None
            else self.maximum_num_bscans
        )

        if minimum_num_bscans is None and maximum_num_bscans is None:
            return file_names

        filtered_file_names: list[str] = []
        num_bscans = self._get_num_bscans_from_cache(file_names)

        for file_name in file_names:
            num_bscans_file = num_bscans.get(file_name)
            if num_bscans_file is None:
                # If the number of B-scans is retrieved as None,
                # then we have to open the file to extract the number of frames.
                # This field gets processed and added to the cache when using
                # the `_get_data` call.
                try:
                    self.get_data([file_name])
                except DataNotAvailableError:
                    # If the file cannot be loaded (e.g., no pixel data),
                    # skip it instead of aborting the entire task.
                    self.skip_file(file_name, FileSkipReason.DICOM_LOAD_FAILED)
                    continue
                num_bscans_file = self._get_num_bscans_from_cache([file_name]).get(
                    file_name
                )
            if num_bscans_file is not None:
                meets_criteria = True
                if minimum_num_bscans is not None:
                    meets_criteria = num_bscans_file >= minimum_num_bscans
                if meets_criteria and maximum_num_bscans is not None:
                    meets_criteria = num_bscans_file <= maximum_num_bscans
                if meets_criteria:
                    filtered_file_names.append(file_name)
                else:
                    # If the number of B-scans is retrieved but not within the
                    # specified range, then we skip the file.
                    persist = should_persist_skip_to_cache(
                        value=num_bscans_file,
                        datasource_min=self.minimum_num_bscans,
                        datasource_max=self.maximum_num_bscans,
                    )
                    if persist:
                        self.skip_file(
                            file_name, FileSkipReason.OPHTH_BSCAN_COUNT_OUT_OF_RANGE
                        )
                    else:
                        self.task_skip_file(
                            file_name, FileSkipReason.OPHTH_BSCAN_COUNT_OUT_OF_RANGE
                        )
            else:
                if (
                    self.minimum_num_bscans is not None
                    or self.maximum_num_bscans is not None
                ):
                    self.skip_file(
                        file_name, FileSkipReason.OPHTH_BSCAN_COUNT_UNAVAILABLE
                    )
                else:
                    self.task_skip_file(
                        file_name, FileSkipReason.OPHTH_BSCAN_COUNT_UNAVAILABLE
                    )
        return filtered_file_names

    def _filter_files_by_required_fields(self, file_names: list[str]) -> list[str]:
        """Filter the files by checking for required fields.

        Uses merged_filter_config to determine whether to check required fields
        and which fields to check. The check is enabled if either:
        - The datasource has check_required_fields=True, OR
        - The task has check-required-fields=True (via merged config), OR
        - There are required_field_names specified (from either datasource or task)

        When enabled, uses merged_filter_config.required_field_names (union of
        datasource + task required field names). A skip should only persist to
        cache if the missing field is in the datasource config (not task-only).

        Args:
            file_names: The list of file names to be filtered.

        Returns:
            The filtered list of file names.
        """
        merged = self.merged_filter_config

        required_fields: list[str] = (
            merged.required_field_names
            if merged is not None and merged.required_field_names
            else self.required_field_names
        )

        check_enabled = (
            (merged.check_required_fields if merged is not None else False)
            or self.check_required_fields
            or bool(required_fields)
        )

        if not check_enabled:
            return file_names

        if not required_fields:
            return file_names

        # Track which fields are from datasource config for cache decisions
        datasource_required_fields: set[str] = set(self.required_field_names or [])
        filtered_file_names: list[str] = []

        # Single targeted SQL query for just the required field columns
        cached_values: dict[str, dict[str, Any]] = {}
        if self.data_cache:
            cached_values = self.data_cache.get_column_values_for_files(
                file_names, required_fields
            )

        for file_name in file_names:
            try:
                file_values = cached_values.get(file_name)

                # If file not in cache, fall back to full pipeline load
                if file_values is None:
                    data = self.get_data([file_name])
                    if data is None:
                        self.skip_file(
                            file_name,
                            FileSkipReason.OPHTH_PROPERTY_EXTRACTION_FAILED,
                        )
                        continue
                    # Convert DataFrame row to dict for uniform handling
                    file_values = {}
                    for req_field in required_fields:
                        if req_field in data.columns:
                            field_values = data[req_field].dropna()
                            if not field_values.empty:
                                file_values[req_field] = field_values.iloc[0]

                missing_fields: set[str] = set()
                for req_field in required_fields:
                    value = file_values.get(req_field)
                    if value is None:
                        missing_fields.add(req_field)
                        continue
                    # NaN from cache (float stored in SQLite) must be
                    # treated as missing, matching the .dropna() semantics
                    # used in the get_data() fallback path.
                    try:
                        if np.isnan(value):
                            missing_fields.add(req_field)
                            continue
                    except (TypeError, ValueError):
                        pass
                    if isinstance(value, str) and value == "":
                        missing_fields.add(req_field)

                if not missing_fields:
                    filtered_file_names.append(file_name)
                else:
                    if missing_fields & datasource_required_fields:
                        self.skip_file(
                            file_name, FileSkipReason.OPHTH_MISSING_REQUIRED_FIELD
                        )
                    else:
                        self.task_skip_file(
                            file_name, FileSkipReason.OPHTH_MISSING_REQUIRED_FIELD
                        )
            except DataNotAvailableError:
                self.skip_file(file_name, FileSkipReason.DICOM_LOAD_FAILED)
            except Exception as e:
                logger.warning(
                    f"Error checking required fields for file {file_name}: {e}"
                )
                self.skip_file(
                    file_name, FileSkipReason.OPHTH_PROPERTY_EXTRACTION_FAILED
                )

        return filtered_file_names

    @abstractmethod
    def _extract_metadata_from_skipped_file(
        self, file_path: str
    ) -> list[dict[str, Any]]:
        """Extract metadata from a skipped file for metrics purposes.

        This method should attempt to read basic metadata from a file that was
        previously skipped, without fully processing it. Different ophthalmology
        sources implement this differently:
        - DICOM sources use _attempt_best_effort_metadata_read()
        - Private-eye sources use _process_file(skip_non_tabular_data=True)

        Args:
            file_path: Path to the skipped file.

        Returns:
            A list of metadata dictionaries. May contain multiple entries if a
            file contains data for multiple records (e.g., both eyes). Returns
            empty list if metadata cannot be extracted.
        """
        raise NotImplementedError

    def _get_metrics_from_skipped_files(
        self, fields_to_count: dict[str, str]
    ) -> dict[str, dict[str, int]]:
        """Helper method to retrieve and count metrics from skipped files.

        This shared implementation eliminates code duplication across ophthalmology
        datasources. It handles the common logic of:
        1. Getting list of skipped files from cache
        2. Extracting metadata from each file
        3. Converting to telemetry format
        4. Accumulating counts

        Results are cached to avoid expensive file I/O on repeated calls.

        Args:
            fields_to_count: Dictionary mapping telemetry keys to raw field names.
                Example: {"manufacturer": "Manufacturer", ...}

        Returns:
            Dictionary of accumulated counts per field, or empty dict if no
            metadata could be retrieved.
        """
        # New feature flag to disable the collection of skipped file metadata
        if not config.settings.enable_skipped_file_metadata_collection:
            return {}

        # Return cached metrics if available
        if self._cached_additional_metrics is not None:
            logger.debug("Returning cached additional metrics from skipped files")
            return self._cached_additional_metrics

        if not self.data_cache:
            return {}

        logger.debug(
            "No successfully processed data available. "
            "Attempting to retrieve metadata from skipped files."
        )

        # Get list of skipped files from cache
        skipped_files = self.data_cache.get_all_skipped_files()
        if not skipped_files:
            # Cache empty result
            self._cached_additional_metrics = {}
            return {}

        # Directly accumulate counts from telemetry data
        accumulated_counts: dict[str, dict[str, int]] = {
            key: {} for key in fields_to_count
        }
        successful_reads = 0

        for file_path in skipped_files:
            try:
                # Extract metadata from skipped file (implementation varies by source)
                metadata_list = self._extract_metadata_from_skipped_file(file_path)

                if not metadata_list:
                    continue

                # Process each metadata record (may be multiple per file)
                for metadata in metadata_list:
                    # Extract telemetry data using the same method as skip_file
                    telemetry_data = self._extract_file_metadata_for_telemetry(metadata)
                    successful_reads += 1

                    # Accumulate counts for each field we're tracking
                    for key in fields_to_count:
                        value = telemetry_data.get(key)
                        # Convert None to "Unknown" for consistency
                        value_str = str(value) if value is not None else "Unknown"
                        accumulated_counts[key][value_str] = (
                            accumulated_counts[key].get(value_str, 0) + 1
                        )
            except Exception as e:
                logger.debug(
                    f"Could not extract metadata from skipped file {file_path}: {e}"
                )
                continue

        if successful_reads > 0:
            logger.debug(
                f"Successfully retrieved metadata from {successful_reads} "
                f"records from skipped files out of {len(skipped_files)} total."
            )
            # Filter out empty dicts and cache the result
            result = {k: v for k, v in accumulated_counts.items() if v}
            self._cached_additional_metrics = result
            return result

        # Cache empty result
        self._cached_additional_metrics = {}
        return {}

    def get_filter_config(self) -> FilterConfig:
        """Get the filter configuration for the datasource."""
        return {
            "file_creation_min_date": Date.from_datetime_date(
                self.filter.file_creation_min_date
            )
            if self.filter.file_creation_min_date
            else None,
            "file_creation_max_date": Date.from_datetime_date(
                self.filter.file_creation_max_date
            )
            if self.filter.file_creation_max_date
            else None,
            "file_modification_min_date": Date.from_datetime_date(
                self.filter.file_modification_min_date
            )
            if self.filter.file_modification_min_date
            else None,
            "file_modification_max_date": Date.from_datetime_date(
                self.filter.file_modification_max_date
            )
            if self.filter.file_modification_max_date
            else None,
            "min_file_size": self.filter.min_file_size,
            "max_file_size": self.filter.max_file_size,
            "modality": self.ophthalmology_args.modality,
            "minimum_dob": self.ophthalmology_args.minimum_dob,
            "maximum_dob": self.ophthalmology_args.maximum_dob,
            "min_num_frames": self.ophthalmology_args.minimum_num_bscans,
            "max_num_frames": self.ophthalmology_args.maximum_num_bscans,
            "minimum_acquisition_date": (
                self.ophthalmology_args.minimum_acquisition_date
            ),
            "maximum_acquisition_date": (
                self.ophthalmology_args.maximum_acquisition_date
            ),
            "check_required_fields": self.ophthalmology_args.check_required_fields,
            "required_field_names": self.ophthalmology_args.required_field_names,
            "series_description": self.ophthalmology_args.series_description,
        }
