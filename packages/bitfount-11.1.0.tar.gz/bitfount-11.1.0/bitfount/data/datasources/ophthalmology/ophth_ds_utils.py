"""Utility functions for interacting with ophthalmology datasources."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Final, Union

from bitfount.utils.fs_utils import normalize_path, path_relative_to_base

SLO_ORIGINAL_FILENAME_METADATA_COLUMN: Final[str] = "_slo_original_filename"


class NoParserForFileExtension(KeyError):
    """Indicates no parser was specified for a file extension."""

    pass


def make_path_absolute(
    file_path: Union[str, os.PathLike[str]],
    parent_folder: Union[str, os.PathLike[str]],
) -> Path:
    """Makes a relative file path absolute with respect to a parent folder.

    Does not change an already absolute file path.
    """
    file_path = Path(file_path)
    parent_folder = Path(parent_folder)
    return normalize_path(
        file_path if file_path.is_absolute() else parent_folder / file_path
    )


def make_path_relative(
    file_path: Union[str, os.PathLike[str]],
    parent_folder: Union[str, os.PathLike[str]],
) -> Path:
    """Makes an absolute file path relative with respect to a parent folder.

    Does not change an already relative file path.

    Uses path_relative_to_base so that paths under symlinked subfolders of
    parent_folder are still correctly expressed as relative (resolve first,
    then symlink-aware fallback when enabled in config).
    """
    file_path = Path(file_path)
    parent_folder = Path(parent_folder)
    if not file_path.is_absolute():
        return file_path
    return path_relative_to_base(parent_folder, file_path)
