"""Datasource related types."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from enum import Enum
from typing import (
    Any,
    Dict,
    Literal,
    NamedTuple,
    NotRequired,
    Optional,
    Protocol,
    TypedDict,
    Union,
)

from bitfount.types import UsedForConfigSchemas


class AccessibilityErrorCode(str, Enum):
    """Standard error codes for datasource accessibility checks.

    These codes provide consistent error reporting across all datasource types.
    """

    # File/Directory errors
    PATH_NOT_FOUND = "PATH_NOT_FOUND"
    NOT_A_DIRECTORY = "NOT_A_DIRECTORY"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    EMPTY_DIRECTORY = "EMPTY_DIRECTORY"
    EMPTY_FILE = "EMPTY_FILE"
    READ_TIMEOUT = "READ_TIMEOUT"
    OS_ERROR = "OS_ERROR"

    # Database/Connection errors
    CONNECTION_REFUSED = "CONNECTION_REFUSED"
    AUTH_FAILED = "AUTH_FAILED"
    DATABASE_NOT_FOUND = "DATABASE_NOT_FOUND"
    CONNECTION_TIMEOUT = "CONNECTION_TIMEOUT"
    DB_ERROR = "DB_ERROR"

    # API/Service errors
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    TEMPLATE_NOT_FOUND = "TEMPLATE_NOT_FOUND"
    HTTP_ERROR = "HTTP_ERROR"
    CONNECTION_ERROR = "CONNECTION_ERROR"

    # Generic errors
    CHECK_ERROR = "CHECK_ERROR"
    CHECK_TIMEOUT = "CHECK_TIMEOUT"
    UNKNOWN = "UNKNOWN"


class AccessibilityDetails(TypedDict):
    """Error details returned by accessibility_details when source is inaccessible.

    Attributes:
        error_code: The error code indicating the type of accessibility failure.
        message: Human-readable error description.
        path: (Optional) Resolved path, included for file-based sources.
    """

    error_code: AccessibilityErrorCode
    message: str
    path: NotRequired[str]


@dataclass
class Date(UsedForConfigSchemas):
    """Simple date class used for filtering files based on date headers.

    This is used by `FileSystemIterableSource` to filter files based on
    their creation and modification dates.

    Args:
        year: The oldest possible year to consider.
        month: The oldest possible month to consider. If None, all months
            in the given year are considered. Defaults to None.
        day: The oldest possible day to consider. If None, all days in the
            given month are considered. If month is None, this is ignored.
            Defaults to None.
    """

    year: int
    month: Optional[int] = None
    day: Optional[int] = None

    def get_date(self) -> date:
        """Get a datetime.date object from the date components year, month and day."""
        if self.month:
            if self.day:
                min_datetime = datetime(self.year, self.month, self.day)
            else:
                min_datetime = datetime(self.year, self.month, 1)
        else:
            min_datetime = datetime(self.year, 1, 1)

        return min_datetime.date()

    @staticmethod
    def from_datetime_date(date: date) -> Date:
        """Create a Date object from a datetime.date object."""
        return Date(year=date.year, month=date.month, day=date.day)


class DateTD(TypedDict):
    """Typed dict form of Date dataclass."""

    year: int
    month: NotRequired[int]
    day: NotRequired[int]


# DICOM TYPES

OphthalmologyModalityType = Literal["OCT", "SLO", None]


class _DICOMField(NamedTuple):
    """Type definition for a DICOM field."""

    name: str
    value: Any


class _DICOMSequenceField(NamedTuple):
    """Named tuple for DICOM sequence field.

    Args:
        name: The name of the sequence field.
        elements: The elements of the sequence field.
    """

    name: str
    value: list[_DICOMSequenceElement]


class _DICOMSequenceElement(Protocol):
    """Typed dict form of DICOM sequence element."""

    def elements(self) -> list[Union[_DICOMField, _DICOMSequenceField]]: ...


class _DICOMImage(TypedDict):
    """Type definition for a DICOM image.

    None of the fields are required. The only other field-related assumption we are
    making is that if there is a field called "Pixel Data", that must mean there is
    also an attribute called `pixel_array` which is a numpy array. This should be a
    safe assumption based on the pydicom documentation.
    """

    NumberOfFrames: NotRequired[_DICOMField]
    PatientID: NotRequired[_DICOMField]
    StudyDate: NotRequired[_DICOMField]
    StudyTime: NotRequired[_DICOMField]
    pixel_array: NotRequired[Any]


class DataSourceFileFilter(Protocol):
    """A datasource-level filter that can be applied to files.

    Provides a datasource-level filter (i.e. one that does not rely solely on
    filesystem information, but instead on contents of the data) that can be applied
    to files to include/exclude it from a datasource.
    """

    def __call__(self, file_names: list[str]) -> list[str]:
        """Filter a list of files for those that match a criteria."""
        ...


class DatasourceSummaryStats(TypedDict):
    """Dictionary with datasource summary statistics."""

    total_files_found: int
    total_files_successfully_processed: int
    total_files_skipped: int
    files_with_errors: int
    skip_reasons: Dict[str, int]
    task_skip_reasons: NotRequired[Dict[str, int]]
    total_task_files_skipped: NotRequired[int]
    additional_metrics: dict[str, Any]


class FilterConfig(TypedDict):
    """Filter configurations for a datasource."""

    # From FileSystemIterableSource
    file_creation_min_date: Optional[DateTD | Date]
    file_creation_max_date: Optional[DateTD | Date]
    file_modification_min_date: Optional[DateTD | Date]
    file_modification_max_date: Optional[DateTD | Date]
    min_file_size: Optional[float]
    max_file_size: Optional[float]

    # From OphthalmologySource
    modality: Optional[OphthalmologyModalityType]
    minimum_dob: Optional[DateTD | Date]
    maximum_dob: Optional[DateTD | Date]
    min_num_frames: Optional[int]
    max_num_frames: Optional[int]
    check_required_fields: Optional[bool]
    required_field_names: Optional[list[str]]
    minimum_acquisition_date: Optional[DateTD | Date]
    maximum_acquisition_date: Optional[DateTD | Date]
    series_description: Optional[str]
