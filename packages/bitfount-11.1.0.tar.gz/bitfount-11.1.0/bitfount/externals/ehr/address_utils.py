"""Shared utilities for EHR address handling."""

from __future__ import annotations

from typing import Iterable, Optional, Union


def _extract_from_address(
    address: Union[object, dict[str, object]],
) -> tuple[Optional[str], Optional[str]]:
    """Extract and normalize postal code and country from a single address.

    Accepts either dict-like (with 'postalCode' and 'country' keys) or
    object-like (with postalCode and country attributes) address.

    Args:
        address: A single address (dict or object with postalCode/country).

    Returns:
        Tuple of (postal_code, country), with whitespace stripped.
        Either may be None if not present or empty after stripping.
    """
    if hasattr(address, "get") and callable(address.get):
        postal_code = address.get("postalCode")
        country = address.get("country")
    else:
        postal_code = getattr(address, "postalCode", None)
        country = getattr(address, "country", None)

    if postal_code is not None:
        postal_code = str(postal_code).strip() or None
    if country is not None:
        country = str(country).strip() or None

    return postal_code, country


def extract_postal_code_and_country(
    addresses: Iterable[Union[object, dict[str, object]]],
) -> tuple[Optional[str], Optional[str]]:
    """Extract postal code and country from addresses.

    Iterates through the addresses and prefers the first that has both
    a non-empty postal code and country. If no such address exists,
    falls back to the first address with at least a postal code (country
    may be None). This ensures valid postal codes are not dropped when
    country is missing, allowing downstream distance filtering to work
    (e.g. with a default country).

    Args:
        addresses: Iterable of address objects (dict or object with
            postalCode and country).

    Returns:
        Tuple of (postal_code, country). Either may be None if no address
        has a postal code.
    """
    fallback: tuple[Optional[str], Optional[str]] = (None, None)
    for address in addresses:
        postal_code, country = _extract_from_address(address)
        if postal_code and country:
            return postal_code, country
        if postal_code and fallback == (None, None):
            fallback = (postal_code, country)
    return fallback
