"""FHIR Client implementation."""

from __future__ import annotations

from datetime import datetime
import json
import logging
from typing import Any, Callable, Union

from fhirpy import SyncFHIRClient
from fhirpy.base.exceptions import MultipleResourcesFound, ResourceNotFound
from fhirpy.base.utils import AttrDict
import requests

from bitfount.externals.ehr.fhir_r4.exceptions import (
    FHIRR4AuthenticationError,
    FHIRR4HTTPError,
    FHIRR4OperationOutcomeError,
    FHIRR4RateLimitError,
    FHIRR4ServerError,
)
from bitfount.utils.pii_redaction import redact_query_params
from bitfount.utils.token_fingerprint import token_fingerprint

_logger = logging.getLogger(__name__)


class FHIRClient(SyncFHIRClient):
    """Implementation of FHIR Client for error handling."""

    def __init__(
        self,
        url: str,
        authorization: Union[str, None] = None,
        extra_headers: Union[dict[str, Any], None] = None,
        requests_config: Union[dict[str, Any], None] = None,
        *,
        dump_resource: Callable[[Any], dict[str, Any]] = lambda x: dict(x),
    ) -> None:
        super().__init__(
            url,
            authorization,
            extra_headers,
            requests_config,
            dump_resource=dump_resource,
        )
        self._ehr_token_details: tuple[str, datetime | None] | None = None

    def set_authorization(self, token: str, expires: datetime | None = None) -> None:
        """Set the bearer token (and optional expiry) for EHR requests.

        Call this when using externally managed JWT so the client can log
        fingerprint and expiry on request failure. Also sets .authorization
        as required by the parent class.
        """
        self.authorization = f"Bearer {token}" if token else None
        self._ehr_token_details = (token, expires) if token else None

    def _get_bearer_token(self) -> str | None:
        """Return the raw bearer token from self.authorization, or None."""
        auth = self.authorization
        if auth and len(auth) > 7 and auth[:7].lower() == "bearer ":
            return auth[7:]
        return auth

    def _do_request(
        self,
        method: str,
        path: str,
        data: Union[dict[str, Any], None] = None,
        params: Union[dict[str, Any], None] = None,
        returning_status: bool = False,
    ) -> Union[tuple[Any, int], Any]:
        """This method overrides the fhirpy _do_request method.

        This was implemented to handle more types of responses returned by
        servers that were not expected by the fhirpy method. Notably,
        results cannot be expected even when a 200 is received, and we
        would need to log the reasons in the OperationOutcome in order to
        diagnose any issues.
        """
        token = self._get_bearer_token()
        headers = self._build_request_headers()
        url = self._build_request_url(path, params)
        resp = requests.request(
            method, url, json=data, headers=headers, **self.requests_config
        )
        # Success responses (2xx)
        if 200 <= resp.status_code < 300:
            r_data = (
                json.loads(resp.content.decode(), object_hook=AttrDict)
                if resp.content
                else None
            )

            # It is possible that even with a 200 response, the resp content
            # contains OperationOutcome. When this happens even though there
            # are entries, the total is 0
            if isinstance(r_data, dict) and r_data.get("total") == 0:
                for entry in r_data.get("entry", []):
                    resource = entry.get("resource", {})
                    if resource.get("resourceType") == "OperationOutcome":
                        redacted = redact_query_params(params)
                        msg = f"FHIR R4 OperationOutcome received: {resource}"
                        if redacted:
                            msg += f". Query params (redacted): {redacted}"
                        _logger.warning(msg)
                        diagnostic_string = self._build_diagnostic_string(resource)
                        raise FHIRR4OperationOutcomeError(diagnostic_string)

            return (r_data, resp.status_code) if returning_status else r_data

        # Handle non-success status codes with proper logging and exceptions
        raw_data = resp.content.decode() if resp.content else ""
        body_preview = raw_data if raw_data else "(empty response body)"

        # Token details for logging: use stored expiry only if fingerprint matches
        auth_fp = token_fingerprint(token)
        expiry_str = "unknown"
        if self._ehr_token_details is not None:
            stored_token, stored_expires = self._ehr_token_details
            stored_fp = token_fingerprint(stored_token)
            if stored_fp != auth_fp:
                _logger.warning(
                    f"EHR token fingerprint does not match stored token details"
                    f" ({auth_fp} vs {stored_fp});"
                    f" authorization may have been set outside set_authorization"
                )
            elif stored_expires is not None:
                expiry_str = stored_expires.isoformat()
        token_log = f" token fingerprint={auth_fp}, expiry={expiry_str}"

        # Log the error with redacted query params and token fingerprint (PII safe).
        redacted = redact_query_params(params)
        _logger.error(
            f"FHIR API request failed: {method} {path} -> HTTP {resp.status_code}."
            + (f" Query params (redacted): {redacted}" if redacted else "")
            + token_log
        )

        # Try to parse if it is an Operation Outcome
        try:
            parsed_data = json.loads(raw_data)
            if (
                isinstance(parsed_data, dict)
                and parsed_data.get("resourceType") == "OperationOutcome"
            ):
                diagnostic_string = self._build_diagnostic_string(parsed_data)
            else:
                diagnostic_string = ""
        except (KeyError, json.JSONDecodeError):
            # Not valid JSON or not an OperationOutcome
            parsed_data = None
            diagnostic_string = ""

        # Handle specific status codes
        if resp.status_code == 400:  # Bad Request
            _logger.warning(f"Bad request to FHIR API: {raw_data}")
            raise FHIRR4HTTPError(
                resp.status_code,
                f"Bad request - invalid parameters or malformed request"
                f" – {diagnostic_string}",
                raw_data,
            )

        elif resp.status_code == 401:  # Unauthorized
            _logger.error("Encounter 401: Authentication failed for FHIR API request")
            raise FHIRR4AuthenticationError(
                resp.status_code,
                f"Authentication required or invalid credentials – {diagnostic_string}",
                raw_data,
            )

        elif resp.status_code == 403:  # Forbidden
            _logger.error("Access forbidden for FHIR API request")
            raise FHIRR4AuthenticationError(
                resp.status_code,
                f"Access forbidden - insufficient permissions – {diagnostic_string}",
                raw_data,
            )

        elif resp.status_code in (404, 410):  # Not Found / Gone
            _logger.debug(f"Resource not found: {raw_data}")
            raise ResourceNotFound(raw_data)

        elif resp.status_code == 412:  # Precondition Failed
            _logger.warning(f"Multiple resources found: {raw_data}")
            raise MultipleResourcesFound(raw_data)

        elif resp.status_code == 422:  # Unprocessable Entity
            _logger.warning(f"Unprocessable entity in FHIR request: {raw_data}")
            raise FHIRR4HTTPError(
                resp.status_code,
                f"Unprocessable entity - request understood "
                f"but contains semantic errors – {diagnostic_string}",
                raw_data,
            )

        elif resp.status_code == 429:  # Too Many Requests
            _logger.warning("Rate limit exceeded for FHIR API")
            raise FHIRR4RateLimitError(
                resp.status_code,
                f"Rate limit exceeded - too many requests – {diagnostic_string}",
                raw_data,
            )

        elif 500 <= resp.status_code < 600:  # Server errors
            _logger.error(
                f"FHIR server error {resp.status_code} for {method} {path}: "
                f"{body_preview}"
            )
            raise FHIRR4ServerError(
                resp.status_code,
                f"Server error - the FHIR server encountered an internal error"
                f" – {diagnostic_string}",
                raw_data,
            )

        if diagnostic_string:
            # We know there was an OperationOutcome resource
            raise FHIRR4OperationOutcomeError(diagnostic_string)
        else:
            # Generic fallback for unhandled status codes
            _logger.error(
                f"Unhandled FHIR API error with status {resp.status_code} for "
                f"{method} {path}: {body_preview}"
            )
            raise FHIRR4HTTPError(
                resp.status_code,
                f"Unexpected HTTP status code {resp.status_code}",
                raw_data,
            )

    def _build_diagnostic_string(self, resource: dict[str, Any]) -> str:
        """Extract diagnostics text from an OperationOutcome resource."""
        if resource.get("resourceType") == "OperationOutcome":
            diagnostics = []
            for issue in resource.get("issue", []):
                if diagnostic := issue.get("diagnostics"):
                    diagnostics.append(diagnostic)
            return ", ".join(diagnostics)
        return ""
