"""FHIR R4 resource types.

We import from fhir.resources.R4B (not the default R5) so that element names
match FHIR R4, e.g. Procedure.performedDateTime rather than occurrenceDateTime.

Our subclasses set extra="ignore" so server-specific or extra fields in API
responses are dropped rather than causing ValidationError.
"""

from typing import ClassVar

from fhir.resources.R4B.appointment import Appointment
from fhir.resources.R4B.condition import Condition
from fhir.resources.R4B.patient import Patient
from fhir.resources.R4B.practitioner import Practitioner
from fhir.resources.R4B.procedure import Procedure
from pydantic import ConfigDict


class FHIRR4Appointment(Appointment):
    """Type for Appointment resource from FHIR endpoint."""

    model_config = ConfigDict(extra="ignore")

    resourceType: ClassVar[str] = "Appointment"
    __init__ = Appointment.__init__


class FHIRR4Condition(Condition):
    """Type for Condition resource from FHIR endpoint."""

    model_config = ConfigDict(extra="ignore")

    resourceType: ClassVar[str] = "Condition"
    __init__ = Condition.__init__


class FHIRR4Patient(Patient):
    """Type for Patient resource from FHIR endpoint."""

    model_config = ConfigDict(extra="ignore")

    resourceType: ClassVar[str] = "Patient"
    __init__ = Patient.__init__


class FHIRR4Practitioner(Practitioner):
    """Type for Practitioner resource from FHIR endpoint."""

    model_config = ConfigDict(extra="ignore")

    resourceType: ClassVar[str] = "Practitioner"
    __init__ = Practitioner.__init__


class FHIRR4Procedure(Procedure):
    """Type for Procedure resource from FHIR endpoint."""

    model_config = ConfigDict(extra="ignore")

    resourceType: ClassVar[str] = "Procedure"
    __init__ = Procedure.__init__


# Backwards compatible old-style names; should prefer to use new, clearer names to
# indicate expected FHIR version
FHIRAppointment = FHIRR4Appointment
FHIRCondition = FHIRR4Condition
FHIRPatient = FHIRR4Patient
FHIRPractitioner = FHIRR4Practitioner
FHIRProcedure = FHIRR4Procedure
