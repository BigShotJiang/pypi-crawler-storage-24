"""Provides a high-level abstraction for extracting patient info from FHIR R4 APIs."""

from __future__ import annotations

import base64
from datetime import date, datetime
import hashlib
import json
import logging
from pathlib import Path
from typing import (
    Any,
    Container,
    Final,
    Iterable,
    Mapping,
    NotRequired,
    Optional,
    Sequence,
    TypedDict,
    Union,
    cast,
)

from dateutil.relativedelta import relativedelta
from dateutil.tz import tzutc
from fhir.resources.R4B.humanname import HumanName
from fhirpy.base.exceptions import (
    InvalidResponse,
    MultipleResourcesFound,
    OperationOutcome,
    ResourceNotFound,
)
from slugify import slugify

from bitfount.data.persistence.caching import (
    EncryptedDiskcacheFunctionCache,
    FunctionCache,
)
from bitfount.externals.ehr.address_utils import extract_postal_code_and_country
from bitfount.externals.ehr.base_querier import (
    DEFAULT_DUMP_ELEMENTS,
    BaseEHRQuerier,
    CodeSystems,
)
from bitfount.externals.ehr.exceptions import GetPatientInfoError
from bitfount.externals.ehr.fhir_r4.exceptions import (
    FHIRR4APIError,
    FHIRR4AuthenticationError,
    FHIRR4DataError,
    NoFHIRR4PatientIDError,
    NoMatchingFHIRR4PatientError,
    NonSpecificFHIRR4PatientError,
)
from bitfount.externals.ehr.fhir_r4.fhir_client import FHIRClient
from bitfount.externals.ehr.fhir_r4.types import (
    FHIRR4Appointment,
    FHIRR4Condition,
    FHIRR4Patient,
    FHIRR4Practitioner,
    FHIRR4Procedure,
)
from bitfount.externals.ehr.nextgen.types import (
    PatientCodeDetails,
    RetrievedPatientDetailsJSON,
)
from bitfount.externals.ehr.types import (
    EHR_CACHE_TTL,
    ClinicalStatus,
    Condition,
    DownloadedEHRDocumentInfo,
    EHRAppointmentEncounter,
    EHRDocumentInfo,
    FailedEHRDocumentInfo,
    Observation,
    Procedure,
    ProcedureStatus,
    dedupe_dataclass_list,
)
from bitfount.federated.types import EHRProvider
from bitfount.utils.pii_redaction import redact_query_params

_logger = logging.getLogger(__name__)

func_cache: FunctionCache = EncryptedDiskcacheFunctionCache()


ICD_10_SYSTEM_IDENTIFIER: Final[str] = "http://hl7.org/fhir/sid/icd-10-cm"
SNOMED_SYSTEM_IDENTIFIER: Final[str] = "http://snomed.info/sct"
CPT_4_SYSTEM_IDENTIFIER: Final[str] = "http://www.ama-assn.org/go/cpt"
LOINC_SYSTEM_IDENTIFIER: Final[str] = "http://loinc.org"

CODE_SYSTEM_TO_IDENTIFIER: dict[str, str] = {
    "icd10": ICD_10_SYSTEM_IDENTIFIER,
    "snomed": SNOMED_SYSTEM_IDENTIFIER,
    "cpt4": CPT_4_SYSTEM_IDENTIFIER,
    "loinc": LOINC_SYSTEM_IDENTIFIER,
}

# R4B Procedure allows only one of performedDateTime, performedPeriod, etc.
# Servers may send multiple; we keep performedDateTime when present for parsing.
_PERFORMED_KEYS: Final[tuple[str, ...]] = (
    "performedDateTime",
    "performedPeriod",
    "performedRange",
    "performedString",
    "performedAge",
)


def _procedure_dict_for_validation(resource_dict: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of the procedure dict with at most one performed* field.

    FHIR R4B Procedure validates that only one of performedDateTime,
    performedPeriod, performedRange, performedString, performedAge is set.
    Some servers send both performedDateTime and performedPeriod; we keep
    performedDateTime when present so our extraction logic can use it.
    """
    out = dict(resource_dict)
    for key in _PERFORMED_KEYS:
        out.pop(key, None)
    if "performedDateTime" in resource_dict:
        out["performedDateTime"] = resource_dict["performedDateTime"]
    elif "performedPeriod" in resource_dict:
        out["performedPeriod"] = resource_dict["performedPeriod"]
    elif "performedRange" in resource_dict:
        out["performedRange"] = resource_dict["performedRange"]
    elif "performedString" in resource_dict:
        out["performedString"] = resource_dict["performedString"]
    elif "performedAge" in resource_dict:
        out["performedAge"] = resource_dict["performedAge"]
    return out


# Add EHR Provider here to not try appointments endpoint
EHR_PROVIDER_WITHOUT_APPOINTMENTS: set[str] = {
    "nextech intellechartpro r4",
}


class _FHIRR4PatientJSONDump(TypedDict):
    """FHIR R4 Data Transfer JSON dump object."""

    patientInfo: NotRequired[dict[str, Any]]
    appointments: NotRequired[list[dict[str, Any]]]
    conditions: NotRequired[list[dict[str, Any]]]
    encounters: NotRequired[list[dict[str, Any]]]
    medications: NotRequired[list[dict[str, Any]]]
    procedures: NotRequired[list[dict[str, Any]]]


def _get_token_hash(
    fhir_client: FHIRClient,
) -> str:
    """Get a hashed token to use as cache key."""
    token = fhir_client.authorization
    if token is None:
        return ""
    return hashlib.sha256(token.encode("UTF-8")).hexdigest()


@func_cache.memoize(
    # NOTE: EHR cache is only persisted for a single process run; restarting the
    #       app/SDK process will effectively clear the cache
    expire=EHR_CACHE_TTL,
    ignore=(0, "fhir_client"),
)
def _cached_search_resources(
    fhir_client: FHIRClient,
    resource_type: str,
    token_hash: str,
    search_params: Mapping[str, Union[str, Sequence[str]]],
) -> list[dict[str, Any]]:
    """Cached search for FHIR resources.

    Only successful results are cached. Transient errors (FHIRR4APIError,
    OperationOutcome) are allowed to propagate as exceptions, which
    diskcache.memoize does NOT cache — ensuring they can be retried.

    Args:
        fhir_client: The FHIR client instance (ignored in cache key).
        resource_type: The type of FHIR resource to search for.
        token_hash: Hash of current token as cache key, cache will be
          invalidated when token is refreshed.
        search_params: JSON-serializable search parameters.

    Returns:
        List of serialized FHIR resources.

    Raises:
        FHIRR4APIError: On transient API errors (auth, rate limit, server).
        OperationOutcome: On FHIR operation errors.
    """
    resources = fhir_client.resources(resource_type).search(**search_params).fetch_all()
    return [dict(resource) for resource in resources]


def _search_resources(
    fhir_client: FHIRClient,
    resource_type: str,
    token_hash: str,
    search_params: Mapping[str, Union[str, Sequence[str]]],
) -> list[dict[str, Any]]:
    """Search for FHIR resources with error handling.

    Wraps _cached_search_resources to handle transient errors without
    caching the error results. Successful responses are cached by the
    inner function; errors return an empty list without being cached.

    Args:
        fhir_client: The FHIR client instance.
        resource_type: The type of FHIR resource to search for.
        token_hash: Hash of current token as cache key.
        search_params: JSON-serializable search parameters.

    Returns:
        List of serialized FHIR resources, or empty list on error.
    """
    try:
        return _cached_search_resources(
            fhir_client=fhir_client,
            resource_type=resource_type,
            token_hash=token_hash,
            search_params=search_params,
        )
    except FHIRR4AuthenticationError:
        raise
    except (FHIRR4APIError, OperationOutcome):
        _logger.error(
            f"FHIR search failed for resource_type={resource_type}, "
            f"search params (redacted): {redact_query_params(search_params)}"
        )
        return []


@func_cache.memoize(
    # NOTE: EHR cache is only persisted for a single process run; restarting the
    #       app/SDK process will effectively clear the cache
    expire=EHR_CACHE_TTL,
    ignore=(0, "fhir_client"),
)
def _cached_get_resource(
    fhir_client: FHIRClient,
    resource_type: str,
    token_hash: str,
    search_params: dict[str, str],
) -> Optional[dict[str, Any]]:
    """Cached get for a single FHIR resource.

    Only successful results and legitimate "not found" results are cached.
    Transient errors (FHIRR4APIError, OperationOutcome) propagate as
    exceptions so diskcache does NOT cache them.

    ResourceNotFound is a legitimate result (patient genuinely doesn't exist)
    and IS cached as None.

    Args:
        fhir_client: The FHIR client instance (ignored in cache key).
        resource_type: The type of FHIR resource to search for.
        token_hash: Hash of current token as cache key, cache will be
          invalidated when token is refreshed.
        search_params: JSON-serializable search parameters.

    Returns:
        Serialized FHIR resource, or None if not found.

    Raises:
        FHIRR4APIError: On transient API errors.
        OperationOutcome: On FHIR operation errors.
        MultipleResourcesFound: If more than one resource matches.
    """
    try:
        resource = fhir_client.resources(resource_type).search(**search_params).get()
        return dict(resource) if resource else None
    except ResourceNotFound:
        _logger.info(f"No {resource_type} found with given search params.")
        _logger.warning(
            f"Resource not found for resource_type={resource_type}, "
            f"search params (redacted): {redact_query_params(search_params)}"
        )
        return None
    except MultipleResourcesFound:
        _logger.info(
            f"More than one {resource_type} found with given search params, "
            f"when not more than one was expected."
        )
        _logger.warning(
            f"Multiple resources found for resource_type={resource_type}, "
            f"search params (redacted): {redact_query_params(search_params)}"
        )
        raise


def _get_resource(
    fhir_client: FHIRClient,
    resource_type: str,
    token_hash: str,
    search_params: dict[str, str],
) -> Optional[dict[str, Any]]:
    """Get a single FHIR resource with error handling.

    Wraps _cached_get_resource so transient errors are not cached.
    """
    try:
        return _cached_get_resource(
            fhir_client=fhir_client,
            resource_type=resource_type,
            token_hash=token_hash,
            search_params=search_params,
        )
    except FHIRR4AuthenticationError:
        raise
    except (FHIRR4APIError, OperationOutcome):
        _logger.error(
            f"FHIR get failed for resource_type={resource_type}, "
            f"search params (redacted): {redact_query_params(search_params)}"
        )
        return None


@func_cache.memoize(
    # NOTE: EHR cache is only persisted for a single process run; restarting the
    #       app/SDK process will effectively clear the cache
    expire=EHR_CACHE_TTL,
    ignore=(0, "fhir_client"),
)
def _cached_first_resource(
    fhir_client: FHIRClient,
    resource_type: str,
    token_hash: str,
    search_params: Mapping[str, Union[str, Sequence[str]]],
) -> Optional[dict[str, Any]]:
    """Cached first for a single FHIR resource.

    Only successful results and legitimate "not found" are cached.
    Transient errors propagate as exceptions (not cached by diskcache).

    Args:
        fhir_client: The FHIR client instance (ignored in cache key).
        resource_type: The type of FHIR resource to search for.
        token_hash: Hash of current token as cache key, cache will be
          invalidated when token is refreshed.
        search_params: JSON-serializable search parameters.

    Returns:
        Serialized FHIR resource or None if not found.

    Raises:
        FHIRR4APIError: On transient API errors.
        OperationOutcome: On FHIR operation errors.
    """
    try:
        resource = fhir_client.resources(resource_type).search(**search_params).first()
    except ResourceNotFound:
        _logger.warning(
            f"Resource not found (first) for resource_type={resource_type}, "
            f"search params (redacted): {redact_query_params(search_params)}"
        )
        return None

    return dict(resource) if resource else None


def _first_resource(
    fhir_client: FHIRClient,
    resource_type: str,
    token_hash: str,
    search_params: Mapping[str, Union[str, Sequence[str]]],
) -> Optional[dict[str, Any]]:
    """Get first matching FHIR resource with error handling.

    Wraps _cached_first_resource so transient errors are not cached.
    """
    try:
        return _cached_first_resource(
            fhir_client=fhir_client,
            resource_type=resource_type,
            token_hash=token_hash,
            search_params=search_params,
        )
    except FHIRR4AuthenticationError:
        raise
    except (FHIRR4APIError, OperationOutcome):
        _logger.error(
            f"FHIR first failed for resource_type={resource_type}, "
            f"search params (redacted): {redact_query_params(search_params)}"
        )
        return None


class FHIRR4PatientQuerier(BaseEHRQuerier):
    """Provides query/data extraction methods for a given patient.

    This class is a higher-level abstraction than the direct API interactions,
    providing methods for extracting/munging data from the API responses.

    NOTE: This querier is used by all FHIR R4 providers. The "generic r4" provider
          serves as the baseline FHIR R4 implementation that adheres strictly to
          the FHIR standard without any provider-specific customizations. If
          provider-specific elements (e.g., Epic-specific) are added to this class
          or its methods, ensure that "generic r4" continues to work as the baseline
          standard FHIR R4 provider.

    Args:
        patient_id: The patient ID this querier corresponds to.
        fhir_client: FHIRClient instance.
        fhir_patient_info: FHIR Patient Info with contact details.
        ehr_provider: The EHR provider e.g. "nextech", "epic", "generic r4"
        patient_dict: Optional patient details. If we've created this class
          with from_patient_query, we'll store the obtained patient_dict
          for later reference.
    """

    def __init__(
        self,
        patient_id: str,
        *,
        fhir_client: FHIRClient,
        fhir_patient_info: Optional[RetrievedPatientDetailsJSON] = None,
        ehr_provider: Optional[str] = None,
        patient_dict: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(patient_id=patient_id)
        self.fhir_client = fhir_client
        self.fhir_patient_info: Optional[RetrievedPatientDetailsJSON] = (
            fhir_patient_info
        )
        self.ehr_provider = ehr_provider
        self.patient_dict = patient_dict

    @classmethod
    def from_patient_query(
        cls,
        patient_dob: str | date,
        given_name: Optional[str] = None,
        family_name: Optional[str] = None,
        *,
        fhir_client: FHIRClient,
        ehr_provider: Optional[EHRProvider] = None,
    ) -> FHIRR4PatientQuerier:
        """Build a FHIRR4PatientQuerier from patient query details.

        Args:
            patient_dob: Patient date of birth.
            given_name: Patient given name.
            family_name: Patient family name.
            fhir_client: FHIRClient instance
            ehr_provider: The EHR provider

        Returns:
            NextGenPatientQuerier for the target patient.

        Raises:
            NoMatchingFHIRR4PatientError: No patients matching the name/dob criteria
               could be found
            NonSpecificFHIRR4PatientError: Multiple patients match the criteria, could
               not determine the correct one
            NoFHIRR4PatientIDError: Patient matching the criteria was found, but no
               patient ID was associated
        """
        try:
            patient_dict = cls.get_patient_response_by_name(
                fhir_client, patient_dob, given_name, family_name
            )
            if patient_dict is None:
                fhir_patient = None
            else:
                fhir_patient = fhir_client.resource(FHIRR4Patient, **patient_dict)
        except MultipleResourcesFound as e:
            raise NonSpecificFHIRR4PatientError(
                "Multiple patients found based on name and dob"
            ) from e

        if fhir_patient is None:
            _logger.warning("Unable to find patient record based on name and dob")
            raise NoMatchingFHIRR4PatientError(
                "Unable to find patient record based on name and dob"
            )

        patient_id = fhir_patient.id

        if not patient_id:
            raise NoFHIRR4PatientIDError(
                "Found matching patient information but could not extract patient ID."
            )

        dob_string: Optional[str] = None
        if isinstance(patient_dob, str):
            dob_string = patient_dob
        elif isinstance(patient_dob, date):
            dob_string = patient_dob.strftime("%Y-%m-%d")

        postal_code, country = cls._get_postal_code_and_country_from_patient(
            fhir_patient
        )
        patient_info = RetrievedPatientDetailsJSON(
            id=patient_id,
            given_name=given_name,
            family_name=family_name,
            date_of_birth=dob_string,
            gender=fhir_patient.gender,
            home_numbers=cls._get_phone_number_from_patient(fhir_patient, use="home"),
            cell_numbers=cls._get_phone_number_from_patient(fhir_patient, use="mobile"),
            emails=[
                tel.value for tel in fhir_patient.telecom or [] if tel.system == "email"
            ],
            mailing_address=cls._get_address_from_patient(fhir_patient),
            medical_record_number=cls._extract_mrn(fhir_patient),
            postal_code=postal_code,
            country=country,
        )

        return cls(
            patient_id,
            fhir_client=fhir_client,
            fhir_patient_info=patient_info,
            ehr_provider=ehr_provider,
            patient_dict=patient_dict,
        )

    @classmethod
    def from_mrn(
        cls,
        mrn: str,
        *,
        fhir_client: FHIRClient,
        ehr_provider: Optional[EHRProvider] = None,
    ) -> FHIRR4PatientQuerier:
        """Build a FHIRR4PatientQuerier from MRN.

        Args:
            mrn: Medical Record Number
            fhir_client: FHIRClient instance
            ehr_provider: The EHR provider

        Returns:
            FHIRR4PatientQuerier for the target patient.

        Raises:
            NoMatchingFHIRR4PatientError: No patient matching the MRN could be found
            NonSpecificFHIRR4PatientError: Multiple patients match the MRN
            NoFHIRR4PatientIDError: Patient matching the MRN was found, but no
               patient ID was associated
        """
        try:
            patient_dict = cls.get_patient_response_by_mrn(fhir_client, mrn)
            if patient_dict is None:
                fhir_patient = None
            else:
                fhir_patient = fhir_client.resource(FHIRR4Patient, **patient_dict)
        except MultipleResourcesFound as e:
            raise NonSpecificFHIRR4PatientError(
                "Multiple patients found based on MRN"
            ) from e

        if fhir_patient is None:
            _logger.warning("Unable to find patient record based on MRN")
            raise NoMatchingFHIRR4PatientError(
                "Unable to find patient record based on MRN"
            )

        patient_id = fhir_patient.id

        if not patient_id:
            raise NoFHIRR4PatientIDError(
                "Found matching patient information but could not extract patient ID."
            )

        # Extract name(s) from the patient object
        given_name, family_name = cls._extract_name_fields(fhir_patient)

        postal_code, country = cls._get_postal_code_and_country_from_patient(
            fhir_patient
        )
        patient_info = RetrievedPatientDetailsJSON(
            id=patient_id,
            given_name=given_name,
            family_name=family_name,
            date_of_birth=(cls._extract_dob(fhir_patient)),
            gender=fhir_patient.gender,
            home_numbers=cls._get_phone_number_from_patient(fhir_patient, use="home"),
            cell_numbers=cls._get_phone_number_from_patient(fhir_patient, use="mobile"),
            emails=[
                tel.value for tel in fhir_patient.telecom or [] if tel.system == "email"
            ],
            mailing_address=cls._get_address_from_patient(fhir_patient),
            medical_record_number=cls._extract_mrn(fhir_patient),
            postal_code=postal_code,
            country=country,
        )

        return cls(
            patient_id,
            fhir_client=fhir_client,
            fhir_patient_info=patient_info,
            ehr_provider=ehr_provider,
            patient_dict=patient_dict,
        )

    @classmethod
    def get_patient_response_by_name(
        cls,
        fhir_client: FHIRClient,
        patient_dob: str | date,
        given_name: Optional[str] = None,
        family_name: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        """Get JSON response from /Patient endpoint given name and DOB."""
        # There also exists a Patient/$match operation in FHIR R4
        # Which exists for services that have an MPI (Master Patient Index)
        # However it's not a first class operation in most FHIR clients,
        # probably as most servers don't have an MPI.
        # So we'll use the Patient.where operation for now until we know how to identify
        # if $match is supported.
        if isinstance(patient_dob, str):
            patient_dob_str = patient_dob
        else:
            patient_dob_str = patient_dob.strftime("%Y-%m-%d")

        # Use cached search for patient lookup
        search_params = {}
        if given_name:
            search_params["name"] = given_name
        if family_name:
            search_params["family"] = family_name
        search_params["birthdate"] = patient_dob_str

        return cls._query_patient_endpoint(
            fhir_client=fhir_client, search_params=search_params
        )

    def get_patient_response_by_id(self) -> Optional[dict[str, Any]]:
        """Get JSON response from /Patient endpoint given a Patient ID."""
        search_params = {"_id": self.patient_id}
        return self._query_patient_endpoint(
            fhir_client=self.fhir_client, search_params=search_params
        )

    @classmethod
    def get_patient_response_by_mrn(
        cls,
        fhir_client: FHIRClient,
        mrn: str,
    ) -> Optional[dict[str, Any]]:
        """Get JSON response from /Patient endpoint given an MRN.

        Args:
            fhir_client: FHIRClient instance
            mrn: Medical Record Number

        Returns:
            Patient resource dict if found, None otherwise
        """
        # Search by identifier - FHIR supports identifier search parameter
        # Format: identifier={system}|{value} or identifier={value}
        search_params = {"identifier": mrn}
        return cls._query_patient_endpoint(
            fhir_client=fhir_client, search_params=search_params
        )

    @classmethod
    def _query_patient_endpoint(
        cls, fhir_client: FHIRClient, search_params: dict[str, str]
    ) -> Optional[dict[str, Any]]:
        """Given a set of search params, return a raw Patient resource.

        This is a class method as it is used by from_patient_query
        before instantiation.
        """
        return _get_resource(
            fhir_client=fhir_client,
            resource_type="Patient",
            token_hash=_get_token_hash(fhir_client),
            search_params=search_params,
        )

    @staticmethod
    def _get_phone_number_from_patient(patient: FHIRR4Patient, use: str) -> list[str]:
        """Extract phone number from FHIRPatient object."""
        # Refer to https://build.fhir.org/datatypes.html#ContactPoint
        # use values: home | work | temp | old | mobile
        # system values: phone | fax | email | pager | url | sms | other
        return [
            tel.value
            for tel in patient.telecom
            if tel.use == use and tel.system not in ("email", "url")
        ]

    @staticmethod
    def _get_address_from_patient(patient: FHIRR4Patient) -> Optional[str]:
        """Extract address from FHIRPatient object."""
        if not patient.address:
            return None

        # Refer to https://build.fhir.org/datatypes.html#Address
        address_object = patient.address[0]

        # It might already exist fully constructed
        if address_object.text:
            address_string: Optional[str] = address_object.text
            return address_string

        # If text is not available, build it from its parts.
        if not address_object.line:
            address_string = ""
        else:
            address_string = " ".join(address_object.line)

        for address_part in [
            getattr(address_object, "city", ""),
            getattr(address_object, "district", ""),
            getattr(address_object, "state", ""),
            getattr(address_object, "postalCode", ""),
        ]:
            if address_part:
                address_string += f" {address_part}"

        return address_string

    @staticmethod
    def _get_postal_code_and_country_from_patient(
        patient: FHIRR4Patient,
    ) -> tuple[Optional[str], Optional[str]]:
        """Extract postal code and country from FHIR Patient address.

        Iterates through all addresses, returning the first that has both
        postal code and country. Prefers a complete address over an incomplete
        one, even if it is further down the list.

        Args:
            patient: FHIR Patient object.

        Returns:
            Tuple of (postal_code, country). Either may be None if not present.
        """
        if not patient.address:
            return None, None

        return extract_postal_code_and_country(patient.address)

    @staticmethod
    def _extract_name_fields(
        patient: FHIRR4Patient,
    ) -> tuple[Optional[str], Optional[str]]:
        """Extract name fields from FHIRPatient object.

        Args:
            patient: FHIRPatient object

        Returns:
            Tuple of (given_name, family_name)
        """
        if not patient.name:
            _logger.info("No name found in FHIR Patient entry.")
            return None, None

        if len(patient.name) > 1:
            # This may happen if there are nicknames and aliases
            # See HumanName:
            # https://www.hl7.org/fhir/R4/datatypes.html#HumanName
            _logger.info("Found more than 1 name, returning the first one.")

        name_entry = patient.name[0]
        given_name = None
        family_name = None

        if name_entry.given:
            # given is a list, take the first one (should be "first name")
            given_name = name_entry.given[0]
        if name_entry.family:
            family_name = name_entry.family

        return given_name, family_name

    @staticmethod
    def _extract_dob(patient: FHIRR4Patient) -> Optional[str]:
        """Extract date of birth from FHIRPatient object.

        Args:
            patient: FHIRPatient object

        Returns:
            Date of birth as string in YYYY-MM-DD format, or None if not found
        """
        birth_date = patient.birthDate
        if birth_date is None:
            _logger.info("No birth date found in FHIR Patient entry.")
            return None

        # birthDate can be a date or datetime object, or a string
        if isinstance(birth_date, str):
            return birth_date
        elif hasattr(birth_date, "strftime"):
            return cast(str, birth_date.strftime("%Y-%m-%d"))
        else:
            return str(birth_date)

    @staticmethod
    def _extract_mrn(patient_entry: FHIRR4Patient) -> Optional[list[str]]:
        """Extract MRN from FHIRPatient object.

        Looks for MRN identifiers in multiple formats:
        1. type.text == "Medical Record Number" or
           "Temporary Medical Record Number"
        2. type.coding[].code == "MR" (Medical Record Number) or "MRT"
           (Temporary Medical Record Number), regardless of system
        """
        identifiers = getattr(patient_entry, "identifier", [])
        if not identifiers:
            _logger.info("No identifiers found in patient entry.")
            return None

        mrns = []
        # MRN codes from HL7 v2-0203: MR (Medical Record Number) and
        # MRT (Temporary Medical Record Number)
        mrn_codes = {"MR", "MRT"}
        # MRN text values to check for
        mrn_text_values = {
            "Medical Record Number",
            "Temporary Medical Record Number",
        }

        def get_object_value(object: Any, key: str) -> Any:
            """Access value in either Pydantic objects or dicts."""
            attr = getattr(object, key, None)
            if attr is not None:
                return attr

            if isinstance(object, dict):
                attr = object.get(key)
                return attr

            return None

        for identifier in identifiers:
            # Handle both Pydantic objects and dicts
            identifier_type = get_object_value(identifier, "type")
            if identifier_type:
                # Check for type.text == "Medical Record Number" or
                # "Temporary Medical Record Number"
                type_text = get_object_value(identifier_type, "text")
                if type_text in mrn_text_values:
                    mrns.append(identifier)
                    continue

                # Check for type.coding[].code == "MR" or "MRT" (regardless of system)
                coding_list = get_object_value(identifier_type, "coding")
                if coding_list:
                    for coding in coding_list:
                        # Handle both Pydantic objects and dicts
                        code = get_object_value(coding, "code")

                        if code in mrn_codes:
                            mrns.append(identifier)
                            break

        if len(mrns) == 0:
            log_values: list[dict[str, None | list[str] | str]] = []

            # Only log available fields if no MRNs were found
            for identifier in identifiers:
                identifier_type = get_object_value(identifier, "type")
                codes = []
                type_text = ""
                if identifier_type:
                    type_text = get_object_value(identifier_type, "text")
                    coding_list = get_object_value(identifier_type, "coding")
                    if coding_list:
                        codes = [
                            get_object_value(coding, "code") for coding in coding_list
                        ]

                log_values.append(
                    {
                        "use": get_object_value(identifier, "use"),
                        "system": get_object_value(identifier, "system"),
                        "type_text": type_text,
                        "codes": codes,
                    }
                )

            _logger.info(f"No MRN identifier found: {log_values}")
            return []

        # Extract all MRN values
        mrn_values = []
        for mrn_identifier in mrns:
            mrn_value = getattr(mrn_identifier, "value", None)
            if mrn_value is None and isinstance(mrn_identifier, dict):
                mrn_value = mrn_identifier.get("value")

            if mrn_value is not None:
                mrn_values.append(str(mrn_value))

        if len(mrn_values) > 1:
            _logger.info(f"Found {len(mrn_values)} MRN identifiers: {mrn_values}")

        return mrn_values

    def get_patient_conditions(
        self,
        statuses_filter: Optional[list[ClinicalStatus]] = None,
        code_types_filter: Optional[list[CodeSystems]] = None,
    ) -> list[Condition]:
        """Get conditions related to this patient.

        Args:
            statuses_filter: If provided, returns only conditions of that status
               e.g. ['active','recurrence']
            code_types_filter: If provided, returns only conditions with codes
               of a specific code system (ICD10, Snomed) e.g. ["icd10"]

        Returns:
            A list of Condition objects relevant for the patient, detailing its
            status and dates, sorted by condition onset date.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient condition
            information.
        """
        params = {}
        if statuses_filter:
            params["clinical_status"] = ",".join(statuses_filter)
        if code_types_filter:
            params["code"] = ",".join(
                CODE_SYSTEM_TO_IDENTIFIER[code_type] + "|"
                for code_type in code_types_filter
            )

        try:
            # Use cached search for conditions
            search_params = {"patient": self.patient_id}
            search_params.update(params)

            condition_dicts = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Condition",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=search_params,
            )
        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            # If an error occurred, raise an exception for this
            _logger.error(
                f"Unable to retrieve conditions information for patient: {str(e)}"
            )
            raise FHIRR4GetPatientInfoError(
                "Unable to retrieve conditions information for patient"
            ) from e

        try:
            patient_conditions = [
                self.fhir_client.resource(FHIRR4Condition, **resource_dict)
                for resource_dict in condition_dicts
            ]
        except Exception as e:
            _logger.error(
                f"Unable to deserialise conditions information for patient: {str(e)}"
            )
            raise FHIRR4DataError(
                "Unable to deserialise conditions information for patient"
            ) from e

        # Extract all codes from each condition
        all_conditions: list[Condition] = []
        _conditions_missing_onset_count = 0
        for resource_dict, condition in zip(condition_dicts, patient_conditions):
            onset_date_raw = getattr(condition, "onsetDateTime", None)
            if onset_date_raw is None:
                onset_date_raw = resource_dict.get("onsetDateTime")

            # Fallback: try onsetPeriod.start (common FHIR R4 pattern)
            if onset_date_raw is None:
                onset_period = getattr(condition, "onsetPeriod", None)
                if onset_period is None:
                    onset_period_dict = resource_dict.get("onsetPeriod")
                    if isinstance(onset_period_dict, dict):
                        onset_date_raw = onset_period_dict.get("start")
                else:
                    onset_date_raw = getattr(onset_period, "start", None)
                if onset_date_raw is not None:
                    _logger.debug(
                        "Condition onsetDateTime absent; "
                        "using onsetPeriod.start as fallback."
                    )

            # Fallback: try recordedDate
            if onset_date_raw is None:
                recorded = getattr(condition, "recordedDate", None)
                if recorded is None:
                    recorded = resource_dict.get("recordedDate")
                if recorded is not None:
                    onset_date_raw = recorded
                    _logger.debug(
                        "Condition onsetDateTime and onsetPeriod absent; "
                        "using recordedDate as fallback."
                    )

            if isinstance(onset_date_raw, str):
                # NOTE: This path may return a naive datetime if the timezone is not
                # provided
                onset_datetime = self._parse_timestamp(onset_date_raw, "condition")
            elif isinstance(onset_date_raw, datetime):
                onset_datetime = onset_date_raw.astimezone(tzutc())
            elif isinstance(onset_date_raw, date):
                # fhir-core 1.1.5+ returns date for date-only strings
                # (e.g. "2012-05-24")
                onset_datetime = datetime.combine(
                    onset_date_raw, datetime.min.time(), tzinfo=tzutc()
                )
            else:
                if onset_date_raw is not None:
                    _logger.warning(
                        f"Unexpected type for condition onsetDateTime:"
                        f" {type(onset_date_raw).__name__} (value={onset_date_raw}),"
                        f" using None."
                    )
                onset_datetime = None
                _conditions_missing_onset_count += 1

            clinical_status = None
            clinical_status_raw = getattr(condition, "clinicalStatus", None)
            if clinical_status_raw:
                clinical_status_codings = getattr(clinical_status_raw, "coding", None)
                if clinical_status_codings:
                    clinical_status = getattr(clinical_status_codings[0], "code", None)

            code = getattr(condition, "code", None)
            if not code:
                continue

            codings = code.coding
            if not codings:
                continue

            # a condition can have multiple codes
            # likely to handle different systems of coding
            # We'll represent them as separate Condition
            for coding in codings:
                new_condition = Condition(
                    onset_datetime=onset_datetime,
                    code_system=getattr(coding, "system", None),
                    code_code=getattr(coding, "code", None),
                    code_display=getattr(coding, "display", None),
                    code_text=getattr(code, "text", None),
                    clinical_status=clinical_status,
                )
                all_conditions.append(new_condition)

        if _conditions_missing_onset_count > 0:
            _logger.warning(
                f"{_conditions_missing_onset_count} of {len(condition_dicts)} "
                f"condition(s) have no onset date "
                f"(checked onsetDateTime, onsetPeriod.start, recordedDate). "
                f"Available top-level keys on first resource: "
                f"{list(condition_dicts[0].keys()) if condition_dicts else '[]'}."
            )

        return sorted(
            dedupe_dataclass_list(all_conditions),
            # Only really care about the date, not the time. This allows us to avoid
            # timezone issues.
            # Secondary sort by code_code to ensure deterministic ordering when
            # multiple conditions have the same onset date.
            key=lambda cond: (
                (cond.onset_datetime.date() if cond.onset_datetime else None)
                or date(1900, 1, 1),
                cond.code_code or "",
            ),
        )

    def get_patient_procedures(
        self,
        statuses_filter: Optional[list[ProcedureStatus]] = None,
        code_types_filter: Optional[list[CodeSystems]] = None,
    ) -> list[Procedure]:
        """Get information of procedure codes this patient has.

        Args:
            statuses_filter: If provided, returns only procedures of that status
               e.g. ['completed', 'in-progress']
            code_types_filter: If provided, returns only conditions with codes
               of a specific code system (CPT4, Snomed) e.g. ["cpt4", "snomed"]

        Returns:
            A list of Procedure objects relevant for the patient, detailing its
            status and dates, sorted by procedure date.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient procedures
            information.
        """
        params = {}
        if statuses_filter:
            params["status"] = ",".join(statuses_filter)
        if code_types_filter:
            params["code"] = ",".join(
                CODE_SYSTEM_TO_IDENTIFIER[code_type] + "|"
                for code_type in code_types_filter
            )

        try:
            # Use cached search for procedures
            search_params = {"patient": self.patient_id}
            search_params.update(params)

            procedure_dicts = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Procedure",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=search_params,
            )
        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            # If an error occurred, raise an exception for this
            _logger.error(
                f"Unable to retrieve procedures information for patient: {str(e)}"
            )
            raise FHIRR4GetPatientInfoError(
                "Unable to retrieve procedures information for patient"
            ) from e

        try:
            patient_procedures = [
                self.fhir_client.resource(
                    FHIRR4Procedure,
                    **_procedure_dict_for_validation(resource_dict),
                )
                for resource_dict in procedure_dicts
            ]
        except Exception as e:
            _logger.error(
                f"Unable to deserialise procedures information for patient: {str(e)}"
            )
            raise FHIRR4DataError(
                "Unable to deserialise procedures information for patient"
            ) from e

        # Extract the codes from each procedure
        all_procedures: list[Procedure] = []
        _procedures_missing_performed_count = 0
        for resource_dict, procedure in zip(procedure_dicts, patient_procedures):
            # NOTE: This field is different in R5, called occurrenceDateTime instead
            #       of performedDateTime; we are explicitly expecting R4/R4B here.
            performed_date_raw = getattr(procedure, "performedDateTime", None)
            if performed_date_raw is None:
                performed_date_raw = resource_dict.get("performedDateTime")

            # Fallback: try performedPeriod.start
            if performed_date_raw is None:
                performed_period = getattr(procedure, "performedPeriod", None)
                if performed_period is None:
                    performed_period_dict = resource_dict.get("performedPeriod")
                    if isinstance(performed_period_dict, dict):
                        performed_date_raw = performed_period_dict.get("start")
                else:
                    performed_date_raw = getattr(performed_period, "start", None)
                if performed_date_raw is not None:
                    _logger.debug(
                        "Procedure performedDateTime absent; "
                        "using performedPeriod.start as fallback."
                    )

            if isinstance(performed_date_raw, str):
                # NOTE: This path may return a naive datetime if the timezone is not
                # provided
                performed_datetime = self._parse_timestamp(
                    performed_date_raw, "procedure"
                )
            elif isinstance(performed_date_raw, datetime):
                performed_datetime = performed_date_raw.astimezone(tzutc())
            elif isinstance(performed_date_raw, date):
                # fhir-core 1.1.5+ returns date for date-only strings
                # (e.g. "2023-01-15")
                performed_datetime = datetime.combine(
                    performed_date_raw, datetime.min.time(), tzinfo=tzutc()
                )
            else:
                if performed_date_raw is not None:
                    _logger.warning(
                        f"Unexpected type for procedure performedDateTime:"
                        f" {type(performed_date_raw).__name__}"
                        f" (value={performed_date_raw}),"
                        f" using None."
                    )
                performed_datetime = None
                _procedures_missing_performed_count += 1

            code = getattr(procedure, "code", None)
            if not code:
                continue

            codings: list[Any] = code.coding
            if not codings:
                continue

            # a procedure can have multiple codes
            # likely to handle different systems of coding
            # We'll represent them as separate Procedure
            for coding in codings:
                new_procedure = Procedure(
                    performed_datetime=performed_datetime,
                    code_system=getattr(coding, "system", None),
                    code_code=getattr(coding, "code", None),
                    code_display=getattr(coding, "display", None),
                    code_text=getattr(code, "text", None),
                )
                all_procedures.append(new_procedure)

        if _procedures_missing_performed_count > 0:
            _logger.warning(
                f"{_procedures_missing_performed_count} of {len(procedure_dicts)} "
                f"procedure(s) have no performed date "
                f"(checked performedDateTime, performedPeriod.start). "
                f"Available top-level keys on first resource: "
                f"{list(procedure_dicts[0].keys()) if procedure_dicts else '[]'}."
            )

        return sorted(
            dedupe_dataclass_list(all_procedures),
            # Only really care about the date, not the time. This allows us to avoid
            # timezone issues.
            key=lambda proc: (
                (proc.performed_datetime.date() if proc.performed_datetime else None)
                or date(1900, 1, 1)
            ),
        )

    def get_patient_code_states(self) -> PatientCodeDetails:
        """Get information of Conditions and Procedures codes this patient has.

        Sugar method that combines get_patient_condition_code_states() and
        get_patient_procedure_code_states() and returns a pre-constructed
        PatientCodeDetails container.

        Returns:
            A PatientCodeDetails instance detailing the presence or absence of the
            provided Conditions and Procedures codes for the patient.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve condition information.
        """
        try:
            condition_code_states = self.get_patient_conditions()
        except FHIRR4GetPatientInfoError:
            # If error occurred, mark all entries as unknown, carry on
            condition_code_states = None

        # Extract CPT4 Code details for patient
        try:
            procedure_code_states = self.get_patient_procedures()
        except FHIRR4GetPatientInfoError:
            # If error occurred, mark all entries as unknown, carry on
            procedure_code_states = None

        # Construct code details object
        return PatientCodeDetails(
            condition_codes=condition_code_states, procedure_codes=procedure_code_states
        )

    def get_next_appointment(self) -> Optional[date]:
        """Get the next appointment date for the patient.

        Falls back to encounters if appointments are not available or empty.

        Returns:
            The next appointment date for the patient from today, or None if they
            have no future appointment. Any cancelled or errored appointments
            are ignored.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient information.
        """
        if self.ehr_provider not in EHR_PROVIDER_WITHOUT_APPOINTMENTS:
            try:
                appointment_date = (
                    self._get_next_appointment_from_appointments_endpoint()
                )
                if appointment_date:
                    return appointment_date
            except FHIRR4AuthenticationError:
                raise
            except Exception as e:
                _logger.warning(
                    f"Failed to retrieve next appointment, trying encounters: {str(e)}"
                )
            else:
                _logger.info(
                    "Did not find a next appointment date, trying encounters endpoint."
                )

        # Fallback to encounters if appointments failed or returned None or empty list
        try:
            encounter_date = self._get_next_appointment_from_encounters_endpoint()
            return encounter_date
        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            _logger.error(
                f"Unable to retrieve upcoming appointments/encounters"
                f" for patient: {str(e)}"
            )
            raise FHIRR4GetPatientInfoError(
                "Unable to retrieve upcoming appointments/encounters for patient"
            ) from e

    def _get_next_appointment_from_appointments_endpoint(self) -> Optional[date]:
        """Get next appointment from Appointment resources."""
        search_params = {
            "patient": self.patient_id,
            "date__gt": datetime.now().date().strftime("%Y-%m-%d"),
            "status__not": ["cancelled", "entered-in-error"],
            "_sort": "date",
        }

        appointment_dict = _first_resource(
            fhir_client=self.fhir_client,
            resource_type="Appointment",
            token_hash=_get_token_hash(self.fhir_client),
            search_params=search_params,
        )

        if appointment_dict is None:
            return None

        next_appointment = self.fhir_client.resource(
            FHIRR4Appointment, **appointment_dict
        )
        appointment_date: Optional[datetime] = next_appointment.start

        if appointment_date is None:
            # start date may be None if status is proposed/waitlist/cancelled
            return None

        return appointment_date.date()

    def _get_next_appointment_from_encounters_endpoint(self) -> Optional[date]:
        """Get next appointment from Encounter resources."""
        # We use period.start instead of date, and different status values
        # planned | arrived | triaged | in-progress | onleave | finished | cancelled
        search_params = {
            "patient": self.patient_id,
            "date__gt": datetime.now().date().strftime("%Y-%m-%d"),
            "status__not": "cancelled",
            "_sort": "date",
        }
        encounter_dict = _first_resource(
            fhir_client=self.fhir_client,
            resource_type="Encounter",
            token_hash=_get_token_hash(self.fhir_client),
            search_params=search_params,
        )

        if encounter_dict is None:
            return None

        # Extract the start date from the encounter period
        period = encounter_dict.get("period")
        if period and period.get("start"):
            next_encounter_date = self._parse_timestamp(period["start"], "encounter")
            if next_encounter_date:
                return next_encounter_date.date()

        return None

    def _get_previous_appointment_details(
        self,
        include_maybe_attended: bool = True,
    ) -> list[FHIRR4Appointment]:
        """Get the FHIRAppointment details of previous appointments.

        Returns:
            The list of previous appointments for the patient, sorted
            chronologically, or an empty list if they have no
            previous appointments.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient information.
        """
        appointments: list[FHIRR4Appointment] = []
        try:
            appointments = self._get_previous_appointments_from_appointments_endpoint(
                include_maybe_attended
            )
        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            _logger.warning(f"Failed to retrieve past appointments: {str(e)}")
        return appointments

    def _get_previous_encounter_details(
        self,
        include_maybe_attended: bool = True,
    ) -> list[dict[str, Any]]:
        """Get the details of previous encounters.

        Returns:
            The list of previous encounters for the patient, sorted
            chronologically, or an empty list if they have no
            previous encounters.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient information.
        """
        try:
            encounters: list[dict[str, Any]] = (
                self._get_previous_appointments_from_encounters(include_maybe_attended)
            )
        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            _logger.error(
                f"Unable to retrieve past appointments/encounters for patient: {str(e)}"
            )
            raise FHIRR4GetPatientInfoError(
                "Unable to retrieve past appointments/encounters for patient"
            ) from e

        return encounters

    def _get_previous_appointments_from_appointments_endpoint(
        self,
        include_maybe_attended: bool = True,
    ) -> list[FHIRR4Appointment]:
        """Get previous appointments from Appointment resources."""
        # Definitely attended: arrived | fulfilled | checked-in
        # Maybe attended: waitlist | booked | pending | proposed
        # Not attended: cancelled | entered-in-error | noshow

        if include_maybe_attended:
            excluded_status = ["cancelled", "entered-in-error", "noshow"]
        else:
            excluded_status = [
                "cancelled",
                "entered-in-error",
                "noshow",
                "waitlist",
                "booked",
                "pending",
                "proposed",
            ]

        # Use cached search for previous appointments
        search_params = {
            "patient": self.patient_id,
            "date__lt": datetime.now().date().strftime("%Y-%m-%d"),
            "status__not": excluded_status,
            "_sort": "date",
        }

        appointment_dicts = _search_resources(
            fhir_client=self.fhir_client,
            resource_type="Appointment",
            token_hash=_get_token_hash(self.fhir_client),
            search_params=search_params,
        )

        # Creates FHIRAppointment object from dict
        previous_appointments: list[FHIRR4Appointment] = [
            self.fhir_client.resource(FHIRR4Appointment, **resource_dict)
            for resource_dict in appointment_dicts
        ]

        return previous_appointments

    def _get_previous_appointments_from_encounters(
        self,
        include_maybe_attended: bool = True,
    ) -> list[dict[str, Any]]:
        """Get previous appointments from Encounters."""
        # Definitely attended: arrived | finished
        # Maybe attended: planned | in-progress | triaged
        # Not attended: cancelled | onleave

        if include_maybe_attended:
            excluded_status = ["cancelled", "onleave"]
        else:
            excluded_status = [
                "cancelled",
                "onleave",
                "planned",
                "in-progress",
                "triaged",
            ]

        # Use cached search for previous encounters
        search_params = {
            "patient": self.patient_id,
            "date__lt": datetime.now().date().strftime("%Y-%m-%d"),
            "status__not": excluded_status,
            "_sort": "date",
        }

        encounter_dicts = _search_resources(
            fhir_client=self.fhir_client,
            resource_type="Encounter",
            token_hash=_get_token_hash(self.fhir_client),
            search_params=search_params,
        )

        return encounter_dicts

    def get_previous_appointment_details(
        self,
        include_maybe_attended: bool = True,
    ) -> list[EHRAppointmentEncounter]:
        """Get list of previous appointments for the patient.

        Returns:
            A list of EHRAppointmentEncounter for the patient, sorted
            chronologically (oldest first), or an empty list if they have no
            previous appointments.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient information.
        """
        previous_appointments: list[FHIRR4Appointment] = (
            self._get_previous_appointment_details(
                include_maybe_attended=include_maybe_attended
            )
        )

        appointments_list: list[EHRAppointmentEncounter] = []
        for appt in previous_appointments:
            appointment_date: Optional[date] = None
            if getattr(appt, "start", None):
                appointment_date = appt.start.date()
            event_name = getattr(appt, "description", "")

            appointments_list.append(
                EHRAppointmentEncounter(
                    appointment_date=appointment_date,
                    location_name=None,
                    event_name=event_name,
                )
            )

        # Sort appointments chronologically (oldest first) to ensure consistent
        # ordering across all providers, even if the API's _sort parameter
        # is not honored correctly or when falling back to encounters
        appointments_list.sort(key=lambda x: x.appointment_date or date.min)

        return appointments_list

    def get_previous_encounter_details(
        self,
        include_maybe_attended: bool = True,
    ) -> list[EHRAppointmentEncounter]:
        """Get list of previous encounters for the patient.

        Returns:
            A list of EHRAppointmentEncounter for the patient, sorted
            chronologically (oldest first), or an empty list if they have no
            previous appointments.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient information.
        """
        previous_encounters: list[dict[str, Any]] = (
            self._get_previous_encounter_details(
                include_maybe_attended=include_maybe_attended
            )
        )

        appointments_list: list[EHRAppointmentEncounter] = []
        for appt in previous_encounters:
            appointment_date: Optional[date] = None
            event_name = ""
            # if it was a dict, it was retrieved from Encounters
            if start := appt.get("period", {}).get("start", None):
                if isinstance(start, str):
                    appointment_datetime = self._parse_timestamp(start, "encounter")
                else:
                    appointment_datetime = start

                if appointment_datetime is not None:
                    appointment_date = appointment_datetime.date()

            # We use the encounter type display as an event name, eg.
            # "type" : [{
            #     "coding" : [{
            #       "system" : "http://snomed.info/sct",
            #       "code" : "183807002",
            #       "display" : "Inpatient stay 9 days"
            #     }]
            #   }],
            if appt_type := appt.get("type"):
                if coding := appt_type[0].get("coding"):
                    event_name = coding[0].get("display", "")

            appointments_list.append(
                EHRAppointmentEncounter(
                    appointment_date=appointment_date,
                    location_name=None,
                    event_name=event_name,
                )
            )

        # Sort appointments chronologically (oldest first) to ensure consistent
        # ordering across all providers, even if the API's _sort parameter
        # is not honored correctly or when falling back to encounters
        appointments_list.sort(key=lambda x: x.appointment_date or date.min)

        return appointments_list

    def get_patient_latest_medical_practitioner(self) -> Optional[str]:
        """Retrieves the latest medical practitioner for the patient.

        This is the rendering provider for the patient's last encounter.

        Returns:
            The name of the latest medical practitioner for the patient, or None if
            there is no name listed on the latest encounter.

        Raises:
            FHIRR4GetPatientInfoError: If unable to retrieve patient encounter
            information.
        """
        previous_appointments: list[FHIRR4Appointment] = (
            self._get_previous_appointment_details()
        )
        try:
            previous_encounters: list[dict[str, Any]] = (
                self._get_previous_encounter_details()
            )
        except FHIRR4GetPatientInfoError:
            previous_encounters = []

        # Iterate through list of appointment/encounter starting from latest
        #  to find a Practitioner
        # Practitioners will be found amongst list of participants of the appointment
        # and can be identified by the actor.reference "Practitioner/{practitioner-id}"
        # See https://build.fhir.org/appointment.html
        practitioner_id = None
        for appt in previous_appointments[::-1] + previous_encounters[::-1]:
            if isinstance(appt, FHIRR4Appointment):
                participants = getattr(appt, "participant", [])
                for participant in participants:
                    actor = getattr(participant, "actor", None)
                    if actor and (
                        practitioner := getattr(actor, "reference", "")
                    ).startswith("Practitioner"):
                        practitioner_id = practitioner.split("/")[1]
                        break
            elif isinstance(appt, dict):
                participants = appt.get("participant", [])
                for participant in participants:
                    individual = participant.get("individual")
                    if individual and (
                        practitioner := individual.get("reference", "")
                    ).startswith("Practitioner"):
                        practitioner_id = practitioner.split("/")[1]
                        break

            if practitioner_id is not None:
                break

        if practitioner_id is None:
            # We were unable to find any Practitioner records in previous appts/encts
            return None

        try:
            # Use cached search for practitioner
            search_params = {"_id": practitioner_id}

            practitioner_dict = _first_resource(
                fhir_client=self.fhir_client,
                resource_type="Practitioner",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=search_params,
            )

            if practitioner_dict is None:
                result = None
            else:
                result = self.fhir_client.resource(
                    FHIRR4Practitioner, **practitioner_dict
                )

        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            # If an error occurred, raise an exception for this
            _logger.error(
                f"Unable to retrieve latest medical practitioner for patient: {str(e)}"
            )
            raise FHIRR4GetPatientInfoError(
                "Unable to retrieve latest medical practitioner for patient"
            ) from e

        if result is None:
            # Could not find any Practitioners with this reference id
            return None

        if result.name:
            # result.name is a list of HumanName, we'll use the first one
            # https://build.fhir.org/datatypes.html#HumanName
            return self._format_practitioner_name(result.name[0])

        return None

    def _format_practitioner_name(self, practitioner_name: HumanName) -> str:
        """Formats name of practitioner by prefix-given-family name.

        See HumanName https://build.fhir.org/datatypes.html#HumanName
        """
        prefix = (practitioner_name.prefix or [""])[0]
        given = (practitioner_name.given or [""])[0]
        family = practitioner_name.family or ""

        name_parts = [p for p in (prefix, given, family) if p]
        return " ".join(name_parts)

    def get_document_infos(self) -> Iterable[list[EHRDocumentInfo]]:
        """Yields document items related to this patient."""
        try:
            for document_ref_obj in iter(
                self.fhir_client.resources("DocumentReference").search(
                    patient=self.patient_id,
                )
            ):
                document_infos = []
                # Note: one DocumentReference resource can contain more than one content
                for content in document_ref_obj.content:
                    if hasattr(content.attachment, "url"):
                        binary_id = content.attachment.url.split("/")[-1]
                        extension = content.attachment.contentType
                        if "/" in extension:
                            extension = extension.split("/")[-1]
                        document_date = document_ref_obj.get("date")

                        document_date_str = ""
                        if document_date:
                            document_date = self._parse_timestamp(
                                document_date, "document"
                            )
                            if isinstance(document_date, datetime):
                                document_date_str = document_date.strftime("%Y-%m-%d")

                        document_infos.append(
                            EHRDocumentInfo(
                                document_id=binary_id,
                                document_date=document_date_str,
                                # pyrefly: ignore[missing-attribute]
                                document_description=document_ref_obj.get(
                                    "type", {}
                                ).get("text"),
                                extension=extension,
                            )
                        )
                yield document_infos
        except InvalidResponse as e:
            _logger.warning(f"Unable to fetch document references: {e}")

    def download_all_documents(
        self, save_path: Path
    ) -> tuple[list[DownloadedEHRDocumentInfo], list[FailedEHRDocumentInfo]]:
        """Download PDF documents for the current patient.

        Args:
            save_path: Documents path for the PDF documents to be saved.
        """
        all_success_doc_infos: list[DownloadedEHRDocumentInfo] = []
        all_failed_doc_infos: list[FailedEHRDocumentInfo] = []

        for batch_document_infos in self.get_document_infos():
            success_documents, failed_documents = self.download_documents_batch(
                save_path, batch_document_infos
            )

            all_success_doc_infos += success_documents
            all_failed_doc_infos += failed_documents

        if all_failed_doc_infos:
            all_failed_doc_ids = [doc.document_id for doc in all_failed_doc_infos]
            _logger.info(
                f"The following documents failed to download: {all_failed_doc_ids}"
            )
        if all_success_doc_infos:
            _logger.info(
                f"Successfully downloaded {len(all_success_doc_infos)} documents"
            )
        else:
            _logger.info("No documents downloaded for patient.")

        return all_success_doc_infos, all_failed_doc_infos

    def download_documents_batch(
        self, save_path: Path, batch_document_infos: list[EHRDocumentInfo]
    ) -> tuple[list[DownloadedEHRDocumentInfo], list[FailedEHRDocumentInfo]]:
        """Downloads a batch of documents.

        Returns:
            A tuple containing:
              - list of info of documents that were successfully downloaded.
              - list of info of documents that could not be downloaded.
        """
        success_documents = []
        failed_documents = []
        for document_info in batch_document_infos:
            processed_doc_info: EHRDocumentInfo = self._download_single_document(
                save_path=save_path, document_info=document_info
            )

            if isinstance(processed_doc_info, DownloadedEHRDocumentInfo):
                success_documents.append(processed_doc_info)
            elif isinstance(processed_doc_info, FailedEHRDocumentInfo):
                failed_documents.append(processed_doc_info)

        return success_documents, failed_documents

    def _download_single_document(
        self, save_path: Path, document_info: EHRDocumentInfo
    ) -> EHRDocumentInfo:
        """Download a single document."""
        document_id = document_info.document_id
        try:
            # Note: we will not be caching these queries
            document_response = self.fhir_client.get("Binary", document_id)
        except (FHIRR4APIError, OperationOutcome) as e:
            _logger.warning(f"Failed to download {document_id}: {e}")
            return FailedEHRDocumentInfo.from_instance(
                document_info,
                failed_reason=f"Failed to download document from EHR: {e}",
            )

        encoded_data = document_response.get("data")

        if not encoded_data:
            _logger.warning(
                f"Failed to download {document_id}: got response {document_response}"
            )
            return FailedEHRDocumentInfo.from_instance(
                document_info,
                failed_reason=f"Failed to download {document_id}:"
                f" got response {document_response}",
            )

        try:
            decoded_data = base64.b64decode(encoded_data)
        except Exception as e:
            _logger.warning(f"Encountered error decoding data: {e}")
            return FailedEHRDocumentInfo.from_instance(
                document_info,
                failed_reason=f"Encountered error decoding data: {e}",
            )

        truncated_doc_id = document_id[:15]
        extension = document_info.extension or "txt"

        filename_elements = []
        if document_info.document_date:
            filename_elements.append(document_info.document_date)
        if document_info.document_description:
            filename_elements.append(document_info.document_description)
        file_name = slugify("_".join(filename_elements))

        if len(file_name) > 40:
            file_name = file_name[:40]

        if file_name:
            download_path: Path = (
                save_path / f"{file_name}_{truncated_doc_id}.{extension}"
            )
        else:
            download_path = save_path / f"{truncated_doc_id}.{extension}"

        with open(download_path, "wb") as f:
            f.write(decoded_data)
        return DownloadedEHRDocumentInfo.from_instance(
            document_info, local_path=download_path
        )

    def produce_json_dump(
        self, save_path: Path, elements_to_dump: Container[str] = DEFAULT_DUMP_ELEMENTS
    ) -> None:
        """Produce a JSON dump of patient information for the target patient.

        Saves the JSON dump out to file and the contents can be controlled by
        `elements_to_dump`.

        The following options are recognised:
            - "patientInfo": /Patient
            - "appointments": `/Appointment` (not always available)
            - "conditions": `/Conditions`
            - "encounters": `/Encounters`
            - "medications": `/MedicationRequest`
            - "procedures": `/Procedures`

        Args:
            save_path: The file location to save the JSON dump to.
            elements_to_dump: Collection of elements to include in the dump.
                See above for what options can be included.
        """

        output_json: _FHIRR4PatientJSONDump = {}

        # patientInfo
        if "patientInfo" in elements_to_dump:
            if self.patient_dict:
                # Already populated when instantiated, no need to call /Patient endpoint
                output_json["patientInfo"] = self.patient_dict
            else:
                patient_info_json = self.get_patient_response_by_id()
                if patient_info_json is not None:
                    output_json["patientInfo"] = patient_info_json
                else:
                    _logger.warning(
                        f"Failed to retrieve patient information, "
                        f"got {patient_info_json}"
                    )

        # encounters
        if "encounters" in elements_to_dump:
            # We want to get all encounters for the patient
            # However some providers do not like when no filters are included
            # in the query. Hence, here we set a wide boundary of -30 years
            # to +10 years from today.
            encounter_search_params = {
                "patient": self.patient_id,
                "date__gt": (datetime.now() - relativedelta(years=30))
                .date()
                .strftime("%Y-%m-%d"),
                "date__lt": (datetime.now() + relativedelta(years=10))
                .date()
                .strftime("%Y-%m-%d"),
                "_sort": "date",
            }
            encounter_dicts = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Encounter",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=encounter_search_params,
            )
            if encounter_dicts:
                output_json["encounters"] = encounter_dicts
            else:
                _logger.warning("Failed to retrieve patient encounters information")

        # appointments
        if "appointments" in elements_to_dump:
            # We want to get all appointments for the patient
            # However some providers do not like when no filters are included
            # in the query. Hence, here we set a wide boundary of -30 years
            # to +10 years from today.
            appts_search_params = {
                "patient": self.patient_id,
                "date__gt": (datetime.now() - relativedelta(years=30))
                .date()
                .strftime("%Y-%m-%d"),
                "date__lt": (datetime.now() + relativedelta(years=10))
                .date()
                .strftime("%Y-%m-%d"),
                "_sort": "date",
            }
            appointment_dicts = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Appointment",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=appts_search_params,
            )
            if appointment_dicts:
                output_json["appointments"] = appointment_dicts
            else:
                _logger.warning("Failed to retrieve patient appointments information")

        # conditions
        if "conditions" in elements_to_dump:
            all_conditions = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Condition",
                token_hash=_get_token_hash(self.fhir_client),
                search_params={"patient": self.patient_id},
            )  # it is possible that this may fail for some EHRs
            # due to the lack of search filters
            if all_conditions:
                output_json["conditions"] = all_conditions
            else:
                _logger.warning("Failed to retrieve patient conditions information")

        # procedures
        if "procedures" in elements_to_dump:
            all_procedures = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Procedure",
                token_hash=_get_token_hash(self.fhir_client),
                search_params={"patient": self.patient_id},
            )
            if all_procedures:
                output_json["procedures"] = all_procedures
            else:
                _logger.warning("Failed to retrieve patient procedures information")

        # medications
        if "medications" in elements_to_dump:
            medication_req_search_params = {
                "patient": self.patient_id,
                "_sort": "date",
            }
            medication_req_dict = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="MedicationRequest",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=medication_req_search_params,
            )
            if medication_req_dict:
                output_json["medications"] = medication_req_dict
            else:
                _logger.warning("Failed to retrieve patient medications information")

        # Save out the generated JSON dump
        with open(save_path, "w") as f:
            json.dump(output_json, f, indent=2)

    def get_visual_acuity(self) -> Optional[Observation]:
        """Get Visual Acuity observation for a patient."""
        loinc_bcva_codes = [
            CODE_SYSTEM_TO_IDENTIFIER["loinc"] + "|" + bcva_code
            for bcva_code in [
                "98498-9",
                "98499-7",  # VA (uncorrected)
                "65897-1",
                "65893-0",  # Best corrected VA
                "79877-7",
                "79876-9",  # Best corrected VA by ETDRS eye chart
                "79881-9",
                "79880-1",  # Best corrected VA by Snellen eye chart
                "98511-9",
                "98512-7",  # Far best corrected VA
                "98508-5",
                "98509-3",  # Near best corrected VA
            ]
        ]
        snomed_bcva_codes = [
            CODE_SYSTEM_TO_IDENTIFIER["snomed"] + "|" + bcva_code
            for bcva_code in [
                "363983007",  # Visual Acuity
                "397536007",  # Corrected VA
                "419775003",  # Best Corrected VA
                "397534005",  # Corrected VA (left)
                "397535006",  # Corrected VA (right)
            ]
        ]

        search_params = {
            "patient": self.patient_id,
            "code": ",".join(loinc_bcva_codes + snomed_bcva_codes),
            "_sort": "date",
        }

        try:
            observations = _search_resources(
                fhir_client=self.fhir_client,
                resource_type="Observation",
                token_hash=_get_token_hash(self.fhir_client),
                search_params=search_params,
            )
        except FHIRR4AuthenticationError:
            raise
        except Exception as e:
            # If an error occurred, raise an exception for this
            _logger.error(
                f"Unable to retrieve Observation information for patient"
                f" when getting BCVA: {str(e)}"
            )
            raise FHIRR4GetPatientInfoError(
                "Unable to retrieve Observation information for patient"
                " when getting BCVA"
            ) from e

        # observations are sorted by timestamp, we take the latest one
        if not observations:
            return None

        latest_obs = observations[-1]

        # obs.code is of the format: {'coding': [{'system': 'http://loinc.org',
        # 'code': '65897-1',
        # 'display': 'Best corrected visual acuity - right eye'}],
        # 'text': 'Best corrected visual acuity - right eye'}
        coding = latest_obs.get("code", {}).get("coding")
        if coding:
            code = coding[0]
        else:
            code = None

        effectiveDateTime = latest_obs.get("effectiveDateTime")
        if isinstance(effectiveDateTime, str):
            # NOTE: This path may return a naive datetime if the timezone is not
            # provided
            obs_date = self._parse_timestamp(effectiveDateTime, "observation")
        else:
            obs_date = None

        return Observation(
            date=obs_date,
            code_system=code.get("system") if code else None,
            code_code=code.get("code") if code else None,
            code_display=code.get("display") if code else None,
            code_text=latest_obs.get("code", {}).get("text"),
            value=latest_obs.get("valueQuantity", {}).get("value"),
            unit=latest_obs.get("valueQuantity", {}).get("unit"),
        )


# DEV: This exception is here because it is explicitly tied to this class. If
#      they begin to be used externally they should be moved to a common exceptions.py.
class FHIRR4GetPatientInfoError(GetPatientInfoError, FHIRR4APIError):
    """Could not retrieve patient info."""

    pass
