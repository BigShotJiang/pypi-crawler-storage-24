"""Authentication classes for NextGen interactions."""

from __future__ import annotations

import logging
from typing import Any, MutableMapping, Optional
from urllib.parse import urlparse

import requests
from requests import Response

from bitfount.externals.ehr.nextgen.exceptions import NextGenQuotaExceeded
from bitfount.hub.api import SMARTOnFHIR
from bitfount.hub.types import SMARTOnFHIRAccessToken
from bitfount.utils.token_fingerprint import token_fingerprint
from bitfount.utils.web_utils import _auto_retry_request

logger = logging.getLogger(__name__)


class NextGenAuthSession(requests.Session):
    """Session that uses bearer authentication and auto-retry for NextGen APIs.

    Differs from BearerAuthSession in that it contains functionality to auto-retrieve
    a new NextGen token from SMARTOnFHIR if the other is found to be expired.
    """

    def __init__(
        self,
        smart_on_fhir: SMARTOnFHIR,
    ) -> None:
        super().__init__()
        self.smart_on_fhir = smart_on_fhir
        self._token: Optional[SMARTOnFHIRAccessToken] = None

    @property
    def token(self) -> str:
        """Returns the current NextGen token or gets one if necessary."""
        if self._token is None:
            self._token = self.smart_on_fhir.get_access_token()
        return self._token.token

    def _token_fingerprint_and_expiry(self) -> tuple[str, str]:
        """Return (fingerprint, expiry_str) for current token for logging."""
        fp = token_fingerprint(self._token.token if self._token else None)
        expiry = (
            self._token.valid_until.isoformat()
            if self._token and self._token.valid_until
            else "unknown"
        )
        return (fp, expiry)

    # We only wrap this method in _auto_retry_request as any calls to the others
    # (post, get, etc) will make use of this. Wrapping them all would result in
    # a double retry loop, but we can't _not_ wrap request as it is often used
    # directly.
    @_auto_retry_request
    def request(  # pyrefly: ignore[bad-param-name-override]
        self,
        method: str | bytes,
        url: str | bytes,
        params: Optional[MutableMapping[str, Any]] = None,
        data: Any = None,
        headers: Optional[MutableMapping[str, str]] = None,
        **kwargs: Any,
    ) -> Response:
        """Performs an HTTP request.

        Overrides requests.session.request, appending our access token
        to the request headers or API keys if present.
        """
        # Create headers if they don't exist already
        if not headers:
            headers = {}

        headers["authorization"] = f"Bearer {self.token}"

        # Try the request once
        resp = super().request(
            method, url, params=params, data=data, headers=headers, **kwargs
        )
        path = urlparse(str(url)).path

        # If we get a 401 (which could indicate token expired), refresh and retry
        if resp.status_code != 401:
            if not (200 <= resp.status_code < 300):
                fp, expiry_str = self._token_fingerprint_and_expiry()
                logger.warning(
                    f"EHR NextGen request failed: {method} {path} -> HTTP"
                    f" {resp.status_code}; token fingerprint={fp}, expiry={expiry_str}"
                )
            return self._check_for_quota_limits(resp)

        # 401: log token details with existing warning, then refresh and retry
        fp, expiry_str = self._token_fingerprint_and_expiry()
        token_info = f" token fingerprint={fp}, expiry={expiry_str}"
        resp_body = resp.text
        if resp_body == "invalid access token":
            logger.warning(
                f"NextGen request {method} {path} -> HTTP 401: invalid access token,"
                f" refreshing from SMART on FHIR...{token_info}"
            )
        else:
            body_log_str = (
                resp_body
                if len(resp_body) <= 40
                else f"{resp_body[:40]}... (truncated)"
            )
            logger.warning(
                f"NextGen request {method} {path} -> HTTP 401, but body didn't indicate"
                f" expired token. Attempting to refresh token from SMART on"
                f" FHIR anyway... Body was: {body_log_str}.{token_info}"
            )

        self._token = None
        headers["authorization"] = f"Bearer {self.token}"

        new_fp, new_expiry = self._token_fingerprint_and_expiry()
        logger.info(
            f"New EHR token received (after 401 refresh): token fingerprint={new_fp},"
            f" expiry={new_expiry}"
        )

        retry_resp = super().request(
            method, url, params=params, data=data, headers=headers, **kwargs
        )
        if not (200 <= retry_resp.status_code < 300):
            retry_fp, retry_expiry = self._token_fingerprint_and_expiry()
            logger.warning(
                f"EHR NextGen request failed (after 401 retry): {method} {path} -> HTTP"
                f" {retry_resp.status_code}; token fingerprint={retry_fp},"
                f" expiry={retry_expiry}"
            )
        return self._check_for_quota_limits(retry_resp)

    @staticmethod
    def _check_for_quota_limits(resp: Response) -> Response:
        """Perform check for quota limits being exceeded.

        This limit is detailed at https://developer.nextgen.com/wiki/pages/999bfa5c-947d-43df-a9ed-591d6690884f/intro-to-api-dev-portal
        and applies across the _entirety_ of Bitfount applications.

        It is indicated by receiving "a 200 status code but an empty payload".
        """
        if resp.status_code == 200 and not resp.content:
            req = resp.request
            if (method := req.method) and (url := req.url):
                # Get something of the form GET:/path/to/api/endpoint
                parsed_url = urlparse(url)
                request_details = f"{method.upper()}:{parsed_url.path}"
            else:
                request_details = None

            err_msg = (
                "Received response indicating NextGen daily quota exceeded"
                " (200, empty payload)"
            )
            if request_details:
                err_msg += f" when performing {request_details}"
            raise NextGenQuotaExceeded(err_msg)
        return resp
