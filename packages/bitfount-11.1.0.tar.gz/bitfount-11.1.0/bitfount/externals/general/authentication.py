"""General authentication classes for external service interactions."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import logging
import threading
import time
from typing import Any, Callable, Final, MutableMapping, Optional

import requests
from requests import Response

from bitfount import config
from bitfount.config import _USER_AGENT_STRING
from bitfount.externals.general.exceptions import AuthenticationError
from bitfount.utils.web_utils import _auto_retry_request

_logger = logging.getLogger(__name__)

# Retry configuration for token refresh race condition handling
_TOKEN_REFRESH_MAX_RETRIES: Final[int] = 3
_TOKEN_REFRESH_INITIAL_DELAY: Final[float] = 1.0

# Token expiry buffer: how far before expiry we consider a token invalid.
# This MUST be less than the Desktop App's EHR token refresh threshold
# (REFRESH_TOKEN_THRESHOLD_SECONDS in bitfount-web:
#  packages/desktop/src-tauri/src/task_scheduler.rs)
# which is currently 30s. If this buffer >= that threshold, the App will
# hand the SDK a token it considers valid while the SDK rejects it.
_TOKEN_EXPIRY_BUFFER_SECONDS: Final[int] = 20


def is_token_valid(expires: datetime) -> bool:
    """Check if a token is still valid with a buffer before expiry."""
    return expires > datetime.now(timezone.utc) + timedelta(
        seconds=_TOKEN_EXPIRY_BUFFER_SECONDS
    )


class BearerAuthSession(requests.Session):
    """Session implementation that uses bearer authentication and auto-retry.

    Has no notion of token expiration or (re)authentication, simply using the
    provided token as-is. If reauthentication is required,
    see `ExternallyManagedJWTSession`.
    """

    def __init__(
        self,
        bearer_token: str,
    ) -> None:
        """Initializes a BearerAuthSession with the provided bearer token."""
        super().__init__()
        self.token = bearer_token

    # We only wrap this method in _auto_retry_request as any calls to the others
    # (post, get, etc) will make use of this. Wrapping them all would result in
    # a double retry loop, but we can't _not_ wrap request as it is often used
    # directly.
    @_auto_retry_request
    def request(  # pyrefly: ignore[bad-param-name-override]
        self,
        method: str | bytes,
        url: str | bytes,
        params: Optional[MutableMapping[str, Any]] = None,
        data: Any = None,
        headers: Optional[MutableMapping[str, str]] = None,
        **kwargs: Any,
    ) -> Response:
        """Performs an HTTP request.

        Overrides requests.session.request, appending our access token
        to the request headers or API keys if present.
        """
        # Create headers if they don't exist already
        if not headers:
            headers = {}

        headers["authorization"] = f"Bearer {self.token}"

        return super().request(
            method, url, params=params, data=data, headers=headers, **kwargs
        )


@dataclass
class JWT:
    """Thin container for JSON web token and its expiry."""

    jwt: str
    expires: datetime


@dataclass(kw_only=True)
class ExternallyManagedJWT:
    """Externally managed JWT.

    The get_token callable may raise (e.g. AuthenticationError) if the external
    source cannot provide a token; GenericExternallyManagedJWTHandler will
    propagate that as AuthenticationError.
    """

    jwt: Optional[str] = None
    expires: Optional[datetime] = None
    get_token: Callable[[], tuple[str, datetime]]


class GenericExternallyManagedJWTHandler:
    """Authenticates user via JWT from an external source.

    The Bitfount library hands responsibility for management of the
    token to the external source.

    Whenever a new token is needed it makes a call to the `get_token`
    hook which provides one.
    """

    def __init__(
        self,
        jwt: Optional[str],
        expires: Optional[datetime],
        get_token: Callable[[], tuple[str, datetime]],
        **kwargs: Any,
    ) -> None:
        """Creates a new instance of GenericExternallyManagedJWTHandler.

        Can be supplied an initial JWT and expiration time to use or ignore these and
        rely on the provided hook to get the first token.

        Args:
            jwt: Optional. Initial JWT token to use. If provided, `expires` must also
                be provided.
            expires: Optional. Initial expiration time to use. If provided, `jwt` must
                also be provided.
            get_token: Callable that returns a tuple of a JWT and its expiration time.
            **kwargs: Other kwargs to be passed to the superclass.
        """
        super().__init__(**kwargs)

        self._get_token: Callable[[], tuple[str, datetime]] = get_token

        self._jwt_container: Optional[JWT]
        if jwt is not None and expires is not None:
            self._jwt_container = JWT(jwt=jwt, expires=expires)
        elif jwt is not None:
            _logger.warning(
                "JWT provided without expiration time. Will retrieve new JWT."
            )
            self._jwt_container = None
        elif expires is not None:
            _logger.warning(
                "Expiration time provided without JWT. Will retrieve new JWT."
            )
            self._jwt_container = None
        else:
            self._jwt_container = None

    def authenticate(self, max_retries: int = _TOKEN_REFRESH_MAX_RETRIES) -> None:
        """Retrieves a token from the token source.

        Calls the hook provided on object creation to retrieve a new token.
        Any exception from get_token (e.g. retrieval timeout, no credentials)
        is re-raised as AuthenticationError. Includes retry logic with
        exponential backoff for the case where the token source returns an
        expired token while refreshing.

        Raises:
            AuthenticationError: If get_token raises or authentication fails
                after all retries.
        """
        if self.authenticated:
            return

        _logger.info("Authenticating...")
        retry_delay = _TOKEN_REFRESH_INITIAL_DELAY

        for attempt in range(max_retries):
            try:
                token, expires = self._get_token()
            except AuthenticationError:
                raise
            except Exception as e:
                raise AuthenticationError(f"Token retrieval failed: {e}") from e

            self._jwt_container = JWT(jwt=token, expires=expires)

            if is_token_valid(self._jwt_container.expires):
                return

            if attempt < max_retries - 1:
                _logger.warning(
                    f"Received expired token (attempt {attempt + 1}/"
                    f"{max_retries}), retrying in {retry_delay}s..."
                )
                time.sleep(retry_delay)
                retry_delay *= 2

        _logger.error(f"Failed to authenticate after {max_retries} retries")
        expiry_info = (
            self._jwt_container.expires.isoformat()
            if self._jwt_container
            else "unknown"
        )
        raise AuthenticationError(
            f"Failed to authenticate after {max_retries} retries: "
            f"token expired at {expiry_info}"
        )

    @property
    def authenticated(self) -> bool:
        """Whether the token is still valid."""
        if self._jwt_container is None:
            _logger.info("Not Authenticated: no JWT found")
            return False
        elif not is_token_valid(self._jwt_container.expires):
            _logger.info(
                f"Not Authenticated: token expired at"
                f" {self._jwt_container.expires.isoformat()}"
            )
            return False
        else:
            return True

    @property
    def request_headers(self) -> dict[str, Any]:
        """Header for authenticated requests.

        Checking that the call is authenticated is the responsibility of the calling
        code.

        Raises:
            AuthenticationError: If the JWT is not present or is expired.
        """
        if not self.authenticated:
            raise AuthenticationError("JWT is not present or is expired.")
        else:
            if self._jwt_container is None:
                # We should not get here. The `self.authenticated` check above
                # ensures self._jwt_container is not None
                raise ValueError("JWT container should be set.")

            return {
                "authorization": f"Bearer {self._jwt_container.jwt}",
                "user-agent": _USER_AGENT_STRING,
            }

    def get_valid_token(self) -> str:
        """Get a valid token to use."""
        token, _ = self.get_valid_token_with_expiry()
        return token

    def get_valid_token_with_expiry(self) -> tuple[str, datetime]:
        """Get a valid token and its expiry time."""
        if not self.authenticated:
            self.authenticate()

        if self._jwt_container is None:
            # We should not get here.`self.authenticate()` above
            # ensures self._jwt_container is not None
            raise ValueError("JWT container should be set.")

        return (self._jwt_container.jwt, self._jwt_container.expires)


class ExternallyManagedJWTSession(requests.Session):
    """Manages session-based interactions with authentication handled externally.

    Extends `requests.Session`, appending an access token to the
    authorization of any requests made if an access token is present

    When the token expires it will request a new token prior to
    sending the web request.
    """

    def __init__(
        self,
        authentication_handler: GenericExternallyManagedJWTHandler,
    ) -> None:
        super().__init__()

        self._reauthentication_lock = threading.Lock()

        self.authentication_handler = authentication_handler

    @property
    def request_headers(self) -> dict[str, Any]:
        """Returns metadata for authenticating external service.

        Handles (re)authentication against the external service if needed.
        """
        with self._reauthentication_lock:
            if not self.authenticated:
                self.authenticate()

            return self.authentication_handler.request_headers

    @property
    def authenticated(self) -> bool:
        """Returns true if we have an unexpired access token."""
        return self.authentication_handler.authenticated

    def authenticate(self) -> None:
        """Authenticates session to allow protected requests."""
        _logger.debug("Calling authenticate on authentication handler")
        self.authentication_handler.authenticate()

    # We only wrap this method in _auto_retry_request as any calls to the others
    # (post, get, etc) will make use of this. Wrapping them all would result in
    # a double retry loop, but we can't _not_ wrap request as it is often used
    # directly.
    @_auto_retry_request
    def request(  # pyrefly: ignore[bad-param-name-override]
        self,
        method: str | bytes,
        url: str | bytes,
        params: Optional[MutableMapping[str, Any]] = None,
        data: Any = None,
        headers: Optional[MutableMapping[str, str]] = None,
        **kwargs: Any,
    ) -> Response:
        """Performs an HTTP request.

        Overrides requests.session.request, appending our access token
        to the request headers or API keys if present.
        """
        # Create headers if they don't exist already
        if not headers:
            headers = {}

        # [LOGGING-IMPROVEMENTS]
        if config.settings.logging.log_authentication_headers:
            _logger.debug(f"Adding authentication to request headers for {url}")

        headers.update(self.request_headers)

        return super().request(
            method, url, params=params, data=data, headers=headers, **kwargs
        )
