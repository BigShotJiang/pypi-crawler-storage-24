"""Config YAML specification classes related to algorithms."""

from __future__ import annotations

from dataclasses import dataclass
import logging
from pathlib import Path
import typing
from typing import Any, Optional, Union
import warnings

import desert
from marshmallow import ValidationError, fields, validate
from marshmallow.validate import OneOf
from marshmallow_union import Union as M_Union

from bitfount.data.types import DataFormat
from bitfount.federated.algorithms.csv_report_algorithm import (
    DFSortType,
    MatchPatientVisit,
)
from bitfount.federated.algorithms.filtering_algorithm import FilterStrategy
from bitfount.federated.algorithms.hugging_face_algorithms.hugging_face_perplexity import (  # noqa: E501
    DEFAULT_STRIDE,
)
from bitfount.federated.algorithms.hugging_face_algorithms.utils import (
    DEFAULT_MAX_LENGTH,
    DEFAULT_MIN_NEW_TOKENS,
    DEFAULT_NUM_BEAMS,
    DEFAULT_NUM_RETURN_SEQUENCES,
    DEFAULT_REPETITION_PENALTY,
    TIMMTrainingConfig,
)
from bitfount.federated.algorithms.ophthalmology import (
    bscan_image_and_mask_generation_algorithm as bscan_mod,
)
from bitfount.federated.algorithms.ophthalmology.ga_trial_calculation_algorithm_base import (  # noqa: E501
    _get_overlap_include_exclude_area,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    ALL_SEGMENTATION_LABELS,
    CNV_THRESHOLD,
    DISTANCE_FROM_FOVEA_LOWER_BOUND,
    DISTANCE_FROM_FOVEA_UPPER_BOUND,
    EXCLUDE_FOVEAL_GA,
    FOVEA_CENTRE_LANDMARK_INDEX,
    LARGEST_GA_LESION_LOWER_BOUND,
    MACULA_CENTRE_LANDMARK_INDEX,
    TOTAL_GA_AREA_LOWER_BOUND,
    TOTAL_GA_AREA_UPPER_BOUND,
    OCTImageMetadataColumns,
    ReportMetadata,
    SLOImageMetadataColumns,
    SLOSegmentationLocationPrefix,
)
from bitfount.federated.algorithms.ophthalmology.trial_inclusion_filters import (
    ColumnFilter,
)
from bitfount.federated.algorithms.private_sql_query import _validate_aggregation_func
from bitfount.federated.algorithms.s3_upload_algorithm import (
    DEFAULT_URL_EXPIRY_IN_HOURS,
)
from bitfount.federated.types import AlgorithmType
from bitfount.runners.config_schemas.common_schemas import FilePath, TemplatedOrTyped
from bitfount.runners.config_schemas.model_schemas import ModelConfig
from bitfount.runners.utils import get_concrete_config_subclasses
from bitfount.types import _JSONDict
from bitfount.utils import DEFAULT_SEED

_logger = logging.getLogger(__name__)


@dataclass
class AggregatorConfig:
    """Configuration for the Aggregator."""

    secure: bool
    weights: Optional[dict[str, Union[int, float]]] = None

    def __post_init__(self) -> None:
        if self.secure and self.weights:
            # TODO: [BIT-1486] Remove this constraint
            raise NotImplementedError(
                "SecureAggregation does not support update weighting"
            )


@dataclass
class AlgorithmConfig:
    """Configuration for the Algorithm."""

    name: str
    arguments: Optional[Any] = None

    @classmethod
    def _get_subclasses(cls) -> tuple[type[AlgorithmConfig], ...]:
        """Get all the concrete subclasses of this config class."""
        return get_concrete_config_subclasses(cls)


@dataclass
class ModelAlgorithmConfig(AlgorithmConfig):
    """Configuration for the Model algorithms."""

    __config_type: typing.ClassVar[str] = "intermediate"

    model: Optional[ModelConfig] = None
    pretrained_file: Optional[Path] = desert.field(
        FilePath(allow_none=True), default=None
    )


@dataclass
class FederatedModelTrainingArgumentsConfig:
    """Configuration for the FederatedModelTraining algorithm arguments."""

    modeller_checkpointing: bool = True
    checkpoint_filename: Optional[str] = None


@dataclass
class FederatedModelTrainingAlgorithmConfig(ModelAlgorithmConfig):
    """Configuration for the FederatedModelTraining algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.FederatedModelTraining.value)
        )
    )

    arguments: Optional[FederatedModelTrainingArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(FederatedModelTrainingArgumentsConfig)),
        default_factory=FederatedModelTrainingArgumentsConfig,
    )


@dataclass
class ModelTrainingAndEvaluationArgumentsConfig:
    """Configuration for the ModelTrainingAndEvaluation algorithm arguments."""

    # Currently there are no arguments


@dataclass
class ModelTrainingAndEvaluationAlgorithmConfig(ModelAlgorithmConfig):
    """Configuration for the ModelTrainingAndEvaluation algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.ModelTrainingAndEvaluation.value)
        )
    )

    arguments: Optional[ModelTrainingAndEvaluationArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(ModelTrainingAndEvaluationArgumentsConfig))
    )


@dataclass
class ModelEvaluationArgumentsConfig:
    """Configuration for the ModelEvaluation algorithm arguments."""

    # Currently there are no arguments


@dataclass
class ModelEvaluationAlgorithmConfig(ModelAlgorithmConfig):
    """Configuration for the ModelEvaluation algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.ModelEvaluation.value))
    )

    arguments: Optional[ModelEvaluationArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(ModelEvaluationArgumentsConfig))
    )


@dataclass
class ModelInferenceArgumentsConfig:
    """Configuration for the ModelInference algorithm arguments."""

    class_outputs: Optional[list[str]] = None
    postprocessors: Optional[list[dict[str, Any]]] = None


@dataclass
class ModelInferenceAlgorithmConfig(ModelAlgorithmConfig):
    """Configuration for the ModelInference algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.ModelInference.value))
    )
    # pyrefly: ignore[bad-override]
    arguments: ModelInferenceArgumentsConfig = desert.field(
        fields.Nested(desert.schema_class(ModelInferenceArgumentsConfig)),
        default_factory=ModelInferenceArgumentsConfig,
    )


@dataclass
class SqlQueryArgumentsConfig:
    """Configuration for the SqlQuery algorithm arguments."""

    query: str
    table: Optional[str] = None


@dataclass
class SqlQueryAlgorithmConfig(AlgorithmConfig):
    """Configuration for the SqlQuery algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.SqlQuery.value))
    )
    # pyrefly: ignore[bad-override]
    arguments: SqlQueryArgumentsConfig = desert.field(
        fields.Nested(desert.schema_class(SqlQueryArgumentsConfig))
    )


@dataclass
class PrivateSqlQueryColumnArgumentsConfig:
    """Configuration for the PrivateSqlQuery algorithm column arguments."""

    lower: Optional[int] = None
    upper: Optional[int] = None


PrivateSqlQueryColumnArgumentsConfigSchema = desert.schema_class(
    PrivateSqlQueryColumnArgumentsConfig
)


@dataclass
class PrivateSqlQueryArgumentsConfig:
    """Configuration for the PrivateSqlQuery algorithm arguments."""

    epsilon: float
    delta: float
    query: Optional[str] = None
    column_ranges: Optional[
        Union[
            dict[str, PrivateSqlQueryColumnArgumentsConfig],
            dict[str, dict[str, PrivateSqlQueryColumnArgumentsConfig]],
        ]
    ] = desert.field(
        M_Union(
            [
                fields.Dict(
                    keys=fields.String(),
                    values=fields.Nested(
                        PrivateSqlQueryColumnArgumentsConfigSchema,
                    ),
                    allow_none=True,
                ),
                fields.Dict(
                    keys=fields.String(),
                    values=fields.Dict(
                        keys=fields.String(),
                        values=fields.Nested(
                            PrivateSqlQueryColumnArgumentsConfigSchema,
                        ),
                    ),
                    allow_none=True,
                ),
            ],
            allow_none=True,
        ),
        default=None,
    )
    table: Optional[str] = None
    db_schema: Optional[str] = None
    aggregate_columns: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)),
        default=None,
    )
    group_by_columns: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)),
        default=None,
    )
    aggregation_func: Optional[str] = desert.field(
        TemplatedOrTyped(
            fields.String(
                allow_none=True,
                validate=_validate_aggregation_func,
            )
        ),
        default=None,
    )


@dataclass
class PrivateSqlQueryAlgorithmConfig(AlgorithmConfig):
    """Configuration for the PrivateSqlQuery algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.PrivateSqlQuery.value))
    )
    # pyrefly: ignore[bad-override]
    arguments: PrivateSqlQueryArgumentsConfig = desert.field(
        fields.Nested(desert.schema_class(PrivateSqlQueryArgumentsConfig))
    )


@dataclass
class HuggingFacePerplexityEvaluationArgumentsConfig:
    """Configuration for the HuggingFacePerplexityEvaluation algorithm arguments."""

    model_id: str
    stride: int = DEFAULT_STRIDE
    seed: int = DEFAULT_SEED
    access_token: Optional[str] = None


@dataclass
class HuggingFacePerplexityEvaluationAlgorithmConfig(AlgorithmConfig):
    """Configuration for the HuggingFacePerplexityEvaluation algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.HuggingFacePerplexityEvaluation.value)
        )
    )

    arguments: Optional[HuggingFacePerplexityEvaluationArgumentsConfig] = desert.field(
        fields.Nested(
            desert.schema_class(HuggingFacePerplexityEvaluationArgumentsConfig)
        )
    )


@dataclass
class HuggingFaceTextGenerationInferenceArgumentsConfig:
    """Configuration for the HuggingFaceTextGenerationInference algorithm arguments."""

    model_id: str
    prompt_format: Optional[str] = None
    max_length: int = DEFAULT_MAX_LENGTH
    num_return_sequences: int = DEFAULT_NUM_RETURN_SEQUENCES
    seed: int = DEFAULT_SEED
    min_new_tokens: int = DEFAULT_MIN_NEW_TOKENS
    repetition_penalty: float = DEFAULT_REPETITION_PENALTY
    num_beams: int = DEFAULT_NUM_BEAMS
    early_stopping: bool = True
    pad_token_id: Optional[int] = None
    eos_token_id: Optional[int] = None
    device: Optional[str] = None
    torch_dtype: str = "float32"
    access_token: Optional[str] = None

    def __post_init__(self) -> None:
        if self.torch_dtype not in ("bfloat16", "float16", "float32", "float64"):
            raise ValueError(
                f"Invalid torch_dtype {self.torch_dtype}. Must be one of "
                "'bfloat16', 'float16', 'float32', 'float64'."
            )


@dataclass
class HuggingFaceTextGenerationInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for the HuggingFaceTextGenerationInference algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.HuggingFaceTextGenerationInference.value
            )
        )
    )

    arguments: Optional[HuggingFaceTextGenerationInferenceArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(HuggingFaceTextGenerationInferenceArgumentsConfig)
            )
        )
    )


@dataclass
class HuggingFaceImageTextGenerationInferenceArgumentsConfig:
    """Configuration for HuggingFaceImageTextGenerationInference arguments."""

    model_id: str = desert.field(TemplatedOrTyped(fields.String(), required=True))
    max_new_tokens: int = desert.field(TemplatedOrTyped(fields.Integer()), default=2000)
    seed: int = DEFAULT_SEED
    batch_size: int = desert.field(TemplatedOrTyped(fields.Integer()), default=1)
    torch_dtype: str = "bfloat16"
    prompt_template: Optional[str] = desert.field(
        TemplatedOrTyped(fields.String(allow_none=True)), default=None
    )
    access_token: Optional[str] = None

    def __post_init__(self) -> None:
        if self.torch_dtype not in ("bfloat16", "float16", "float32", "float64"):
            raise ValueError(
                f"Invalid torch_dtype {self.torch_dtype}. Must be one of "
                "'bfloat16', 'float16', 'float32', 'float64'."
            )


@dataclass
class HuggingFaceImageTextGenerationInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for HuggingFaceImageTextGenerationInference."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.HuggingFaceImageTextGenerationInference.value
            )
        )
    )

    arguments: Optional[HuggingFaceImageTextGenerationInferenceArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    HuggingFaceImageTextGenerationInferenceArgumentsConfig
                )
            )
        )
    )


@dataclass
class OphthalmologyArgsConfig:
    """Configuration for ophthalmology-specific arguments.

    This groups ophthalmology-related options for CSVReportAlgorithm.
    """

    trial_name: Optional[str] = desert.field(
        fields.String(allow_none=True), default=None
    )
    aux_cols: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )
    match_patient_visit: Optional[MatchPatientVisit] = desert.field(
        fields.Nested(desert.schema_class(MatchPatientVisit), allow_none=True),
        default=None,
    )
    produce_matched_only: bool = True
    produce_trial_notes_csv: bool = False
    csv_extensions: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )


@dataclass
class CSVReportAlgorithmArgumentsConfig:
    """Configuration for CSVReportAlgorithm arguments."""

    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    original_cols: Optional[list[str]] = None
    rename_columns: Optional[dict[str, str]] = desert.field(
        fields.Dict(keys=fields.Str(), values=fields.Str(), allow_none=True),
        default=None,
    )
    columns_to_drop: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )
    columns_to_drop_prefix: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )
    columns_to_include: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )
    filter: Optional[list[ColumnFilter]] = desert.field(
        fields.Nested(desert.schema_class(ColumnFilter), many=True, allow_none=True),
        default=None,
    )
    sorting_columns: Optional[dict[str, str]] = desert.field(
        fields.Dict(
            keys=fields.Str(),
            values=fields.Str(validate=validate.OneOf(typing.get_args(DFSortType))),
            allow_none=True,
        ),
        default=None,
    )
    decimal_places: int = desert.field(
        fields.Int(validate=validate.Range(min=0)),
        default=2,
    )
    # Nested ophthalmology args (preferred format)
    ophthalmology_args: Optional[OphthalmologyArgsConfig] = desert.field(
        fields.Nested(desert.schema_class(OphthalmologyArgsConfig), allow_none=True),
        default=None,
    )
    # Flat ophthalmology args (deprecated, for backward compatibility)
    trial_name: Optional[str] = desert.field(
        fields.String(allow_none=True), default=None
    )
    aux_cols: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )
    match_patient_visit: Optional[MatchPatientVisit] = desert.field(
        fields.Nested(desert.schema_class(MatchPatientVisit), allow_none=True),
        default=None,
    )
    matched_csv_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    produce_matched_only: bool = True
    produce_trial_notes_csv: bool = False
    csv_extensions: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default=None,
    )

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None
        if self.matched_csv_path is not None:
            warnings.warn(
                f"The `matched_csv_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.matched_csv_path = None


@dataclass
class CSVReportAlgorithmConfig(AlgorithmConfig):
    """Configuration for CSVReportAlgorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.CSVReportAlgorithm.value))
    )

    arguments: Optional[CSVReportAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(CSVReportAlgorithmArgumentsConfig)),
        default_factory=CSVReportAlgorithmArgumentsConfig,
    )


@dataclass
class HuggingFaceImageClassificationInferenceArgumentsConfig:
    """Configuration for HuggingFaceImageClassificationInference arguments."""

    model_id: str
    model_input_format: str = desert.field(
        fields.String(
            allow_none=False,
            validate=validate.OneOf([format.value for format in DataFormat]),
        ),
        default=DataFormat.TORCH_TENSOR.value,
    )
    apply_softmax_to_predictions: bool = True
    batch_size: int = desert.field(TemplatedOrTyped(fields.Integer()), default=1)
    seed: int = DEFAULT_SEED
    top_k: int = desert.field(TemplatedOrTyped(fields.Integer()), default=5)
    subfolder: Optional[str] = desert.field(
        fields.String(allow_none=True),
        default=None,
    )
    postprocessors: Optional[list[dict[str, Any]]] = desert.field(
        fields.List(
            fields.Dict(keys=fields.String(), values=fields.Raw()),
            allow_none=True,
        ),
        default=None,
    )
    access_token: Optional[str] = None


@dataclass
class HuggingFaceImageClassificationInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for HuggingFaceImageClassificationInference."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.HuggingFaceImageClassificationInference.value
            )
        )
    )

    arguments: Optional[HuggingFaceImageClassificationInferenceArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    HuggingFaceImageClassificationInferenceArgumentsConfig
                )
            ),
        )
    )


@dataclass
class HuggingFaceImageSegmentationInferenceArgumentsConfig:
    """Configuration for HuggingFaceImageSegmentationInference arguments."""

    model_id: str
    alpha: float = 0.3
    batch_size: int = desert.field(TemplatedOrTyped(fields.Integer()), default=1)
    dataframe_output: bool = False
    mask_threshold: float = 0.5
    overlap_mask_area_threshold: float = 0.5
    seed: int = DEFAULT_SEED
    save_path: Optional[str] = desert.field(
        fields.String(allow_none=True, load_only=True), default=None
    )
    subtask: Optional[str] = None
    threshold: float = 0.9
    access_token: Optional[str] = None

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class HuggingFaceImageSegmentationInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for HuggingFaceImageSegmentationInference."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.HuggingFaceImageSegmentationInference.value
            )
        )
    )

    arguments: Optional[HuggingFaceImageSegmentationInferenceArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    HuggingFaceImageSegmentationInferenceArgumentsConfig
                )
            ),
        )
    )


@dataclass
class HuggingFaceTextClassificationInferenceArgumentsConfig:
    """Configuration for HuggingFaceTextClassificationInference arguments."""

    model_id: str
    batch_size: int = desert.field(TemplatedOrTyped(fields.Integer()), default=1)
    function_to_apply: Optional[str] = None
    seed: int = DEFAULT_SEED
    top_k: int = desert.field(TemplatedOrTyped(fields.Integer()), default=5)
    access_token: Optional[str] = None


@dataclass
class HuggingFaceTextClassificationInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for HuggingFaceTextClassificationInference."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.HuggingFaceTextClassificationInference.value
            )
        )
    )

    arguments: Optional[HuggingFaceTextClassificationInferenceArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    HuggingFaceTextClassificationInferenceArgumentsConfig
                )
            ),
        )
    )


@dataclass
class TemplatedTimmTrainingConfig(TIMMTrainingConfig):
    """Configuration for TIMMFineTuning algorithm arguments."""

    batch_size: int = desert.field(TemplatedOrTyped(fields.Integer()), default=16)

    lr: Optional[float] = desert.field(
        TemplatedOrTyped(fields.Float(allow_none=True)), default=1e-5
    )

    epochs: int = desert.field(TemplatedOrTyped(fields.Integer()), default=300)


@dataclass
class TIMMFineTuningArgumentsConfig:
    """Configuration for TIMMFineTuning algorithm arguments."""

    model_id: str
    args: Optional[TemplatedTimmTrainingConfig] = desert.field(
        fields.Nested(
            desert.schema_class(TemplatedTimmTrainingConfig), allow_none=True
        ),
        default=None,
    )
    batch_transformations: Optional[dict[str, list[Union[str, _JSONDict]]]] = (
        desert.field(
            fields.Dict(
                keys=fields.Str(validate=OneOf(["train", "validation"])),
            ),
            default=None,
        )
    )
    labels: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    return_weights: bool = False
    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class TIMMFineTuningAlgorithmConfig(AlgorithmConfig):
    """Configuration for TIMMFineTuning algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.TIMMFineTuning.value))
    )

    arguments: Optional[TIMMFineTuningArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(TIMMFineTuningArgumentsConfig)),
    )


@dataclass
class TIMMFederatedTrainingArgumentsConfig:
    """Configuration for TIMMFederatedTraining algorithm arguments."""

    model_id: str
    args: Optional[TemplatedTimmTrainingConfig] = desert.field(
        fields.Nested(
            desert.schema_class(TemplatedTimmTrainingConfig), allow_none=True
        ),
        default=None,
    )
    labels: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    pretrained_file: Optional[str] = desert.field(
        fields.String(allow_none=True), default=None
    )
    lora_rank: Optional[Union[int, str]] = desert.field(
        M_Union([fields.Integer(), fields.String()], allow_none=True), default=None
    )


@dataclass
class TIMMFederatedTrainingAlgorithmConfig(AlgorithmConfig):
    """Configuration for TIMMFederatedTraining algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.TIMMFederatedTraining.value)
        )
    )

    arguments: Optional[TIMMFederatedTrainingArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(TIMMFederatedTrainingArgumentsConfig)),
    )


@dataclass
class TIMMInferenceArgumentsConfig:
    """Configuration for TIMMInference algorithm arguments."""

    model_id: str
    num_classes: Optional[int] = None
    checkpoint_path: Optional[Path] = desert.field(
        FilePath(allow_none=True), default=None
    )
    class_outputs: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    batch_transformations: Optional[list[Union[str, _JSONDict]]] = desert.field(
        fields.List(M_Union([fields.String(), fields.Dict()]), allow_none=True),
        default=None,
    )
    hf_checkpoint_repo_id: Optional[str] = desert.field(
        fields.String(allow_none=True), default=None
    )
    hf_checkpoint_filename: Optional[str] = desert.field(
        fields.String(allow_none=True), default=None
    )

    # TODO: [BIT-7451] Move the model download logic to pod side
    def __post_init__(self) -> None:
        if bool(self.hf_checkpoint_repo_id) != bool(self.hf_checkpoint_filename):
            provided = (
                "`hf_checkpoint_repo_id`"
                if self.hf_checkpoint_repo_id
                else "`hf_checkpoint_filename`"
            )
            raise ValueError(
                "`hf_checkpoint_repo_id` and `hf_checkpoint_filename`"
                " must be provided together. Currently, only "
                f"{provided} is set."
            )

        if self.hf_checkpoint_repo_id and self.hf_checkpoint_filename:
            from huggingface_hub import hf_hub_download

            self.checkpoint_path = Path(
                hf_hub_download(
                    repo_id=self.hf_checkpoint_repo_id,
                    filename=self.hf_checkpoint_filename,
                )
            )


@dataclass
class TIMMInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for TIMMInference algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.TIMMInference.value))
    )

    arguments: Optional[TIMMInferenceArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(TIMMInferenceArgumentsConfig)),
    )


@dataclass
class MONAIBundleInferenceArgumentsConfig:
    """Configuration for MONAIBundleInference algorithm arguments."""

    bundle_name: str
    bundle_version: Optional[str] = None
    dataframe_output: bool = True
    nifti_output: bool = False
    batch_size: int = desert.field(TemplatedOrTyped(fields.Integer()), default=1)
    num_workers: int = desert.field(TemplatedOrTyped(fields.Integer()), default=1)
    inference_config_overrides: Optional[dict[str, Any]] = desert.field(
        fields.Dict(keys=fields.Str(), allow_none=True), default=None
    )
    restore_spatial: bool = True
    invert_orientation: bool = True


@dataclass
class MONAIBundleInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for MONAIBundleInference algorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.MONAIBundleInference.value))
    )

    arguments: Optional[MONAIBundleInferenceArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(MONAIBundleInferenceArgumentsConfig))
    )


@dataclass
class HuggingFaceNERInferenceArgumentsConfig:
    """Configuration for HuggingFaceNERInference algorithm arguments."""

    model_id: Optional[str] = desert.field(
        TemplatedOrTyped(fields.String(allow_none=False)),
        default="OpenMed/OpenMed-NER-PathologyDetect-PubMed-v2-109M",
    )
    batch_size: Optional[int] = desert.field(
        TemplatedOrTyped(fields.Integer(allow_none=True)), default=16
    )
    aggregation_strategy: Optional[str] = desert.field(
        TemplatedOrTyped(fields.String(allow_none=True)), default="simple"
    )
    seed: Optional[int] = desert.field(
        fields.Integer(allow_none=True), default=DEFAULT_SEED
    )
    postprocessors: Optional[list[dict[str, Any]]] = desert.field(
        fields.List(
            fields.Dict(keys=fields.String(), values=fields.Raw()),
            allow_none=True,
        ),
        default=None,
    )
    access_token: Optional[str] = None


@dataclass
class HuggingFaceNERInferenceAlgorithmConfig(AlgorithmConfig):
    """Configuration for HuggingFaceNERInference algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.HuggingFaceNERInference.value)
        )
    )
    arguments: Optional[HuggingFaceNERInferenceArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(HuggingFaceNERInferenceArgumentsConfig)),
        default=None,
    )


@dataclass
class EHRPatientQueryArgumentsConfig:
    """Configuration for EHRPatientQuery algorithm arguments."""

    pass


@dataclass
class EHRPatientQueryAlgorithmConfig(AlgorithmConfig):
    """Configuration for EHRPatientQuery algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.EHRPatientQueryAlgorithm.value)
        )
    )
    # pyrefly: ignore[bad-override]
    arguments: EHRPatientQueryArgumentsConfig = desert.field(
        fields.Nested(desert.schema_class(EHRPatientQueryArgumentsConfig)),
        default_factory=EHRPatientQueryArgumentsConfig,
    )


@dataclass
class EHRPatientInfoDownloadArgumentsConfig:
    """Configuration for EHRPatientInfoDownloadAlgorithm arguments."""

    pass


@dataclass
class EHRPatientInfoDownloadAlgorithmConfig(AlgorithmConfig):
    """Configuration for EHRPatientInfoDownloadAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.EHRPatientInfoDownloadAlgorithm.value)
        )
    )

    arguments: Optional[EHRPatientInfoDownloadArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(EHRPatientInfoDownloadArgumentsConfig)),
        default_factory=EHRPatientInfoDownloadArgumentsConfig,
    )


@dataclass
class CodeNormalisationAlgorithmArgumentsConfig:
    """Configuration for CodeNormalisationAlgorithm arguments."""

    pass


@dataclass
class CodeNormalisationAlgorithmConfig(AlgorithmConfig):
    """Configuration for CodeNormalisationAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.CodeNormalisationAlgorithm.value)
        )
    )

    arguments: Optional[CodeNormalisationAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(CodeNormalisationAlgorithmArgumentsConfig)),
        default_factory=CodeNormalisationAlgorithmArgumentsConfig,
    )


@dataclass
class TrialMatchingAlgorithmArgumentsConfig:
    """Configuration for TrialMatchingAlgorithm arguments."""

    top_n: int = desert.field(TemplatedOrTyped(fields.Integer()), default=5)
    max_distance_km: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(
                allow_none=True,
                validate=validate.Range(min=0.0, min_inclusive=False),
            )
        ),
        default=None,
    )
    default_country: str = "us"


@dataclass
class TrialMatchingAlgorithmConfig(AlgorithmConfig):
    """Configuration for TrialMatchingAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.TrialMatchingAlgorithm.value)
        )
    )
    # pyrefly: ignore[bad-override]
    arguments: TrialMatchingAlgorithmArgumentsConfig = desert.field(
        fields.Nested(desert.schema_class(TrialMatchingAlgorithmArgumentsConfig)),
        default_factory=TrialMatchingAlgorithmArgumentsConfig,
    )


@dataclass
class RecordFilterAlgorithmArgumentsConfig:
    """Configuration for RecordFilter algorithm arguments."""

    strategies: list[FilterStrategy] = desert.field(
        fields.List(fields.Enum(FilterStrategy, by_value=True), required=True),
    )
    filter_args_list: list[dict[str, Any]] = desert.field(
        fields.List(fields.Dict(keys=fields.Str()), required=True)
    )


@dataclass
class RecordFilterAlgorithmConfig(AlgorithmConfig):
    """Configuration for RecordFilter algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.RecordFilterAlgorithm.value)
        )
    )

    arguments: Optional[RecordFilterAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(RecordFilterAlgorithmArgumentsConfig))
    )


@dataclass
class GenericAlgorithmConfig(AlgorithmConfig):
    """Configuration for unspecified algorithm plugins.

    Raises:
        ValueError: if the algorithm name starts with `bitfount.`
    """

    __config_type: typing.ClassVar[str] = "fallback"

    name: str
    # pyrefly: ignore[bad-override]
    arguments: _JSONDict = desert.field(
        fields.Dict(keys=fields.Str), default_factory=dict
    )

    def __post_init__(self) -> None:
        _logger.warning(
            f"Algorithm configuration was parsed as {self.__class__.__name__};"
            f" was this intended?"
        )

        if self.name.startswith("bitfount."):
            _logger.error(
                f"Unexpected algorithm config; was parsed as GenericAlgorithm:\n{self}"
            )
            raise ValidationError(
                "Algorithm names starting with 'bitfount.' are reserved for built-in "
                "algorithms. It is likely the provided arguments don't match the "
                "expected schema for the algorithm. Please check the documentation "
            )


#############################################################################
#  _____       _     _   _           _                 _                    #
# |  _  |     | |   | | | |         | |               | |                   #
# | | | |_ __ | |__ | |_| |__   __ _| |_ __ ___   ___ | | ___   __ _ _   _  #
# | | | | '_ \| '_ \| __| '_ \ / _` | | '_ ` _ \ / _ \| |/ _ \ / _` | | | | #
# \ \_/ / |_) | | | | |_| | | | (_| | | | | | | | (_) | | (_) | (_| | |_| | #
#  \___/| .__/|_| |_|\__|_| |_|\__,_|_|_| |_| |_|\___/|_|\___/ \__, |\__, | #
#       | |                                                     __/ | __/ | #
#       |_|                                                    |___/ |___/  #
#############################################################################
@dataclass
class BscanImageAndMaskGenerationAlgorithmArgumentsConfig:
    """Configuration for BscanImageAndMaskGenerationAlgorithm arguments."""

    segmentation_configs: list[bscan_mod.SegmentationConfig] = desert.field(
        fields.List(
            fields.Nested(desert.schema_class(bscan_mod.SegmentationConfig)),
            required=True,
        )
    )
    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    output_original_bscans: Optional[bool] = desert.field(
        fields.Bool(allow_none=True), default=False
    )
    image_format: Optional[bscan_mod.ImageFormats] = desert.field(
        fields.Enum(bscan_mod.ImageFormats, by_value=True, allow_none=True),
        default=bscan_mod.ImageFormats.JPEG,
    )
    image_optimize: Optional[bool] = desert.field(
        fields.Bool(allow_none=True), default=True
    )
    image_quality: Optional[int] = desert.field(fields.Int(allow_none=True), default=90)
    image_subsampling: Optional[int] = desert.field(
        fields.Int(allow_none=True), default=0
    )
    image_progressive: Optional[bool] = desert.field(
        fields.Bool(allow_none=True), default=True
    )
    image_transparency: Optional[bool] = desert.field(
        fields.Bool(allow_none=True), default=False
    )

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class BscanImageAndMaskGenerationAlgorithmConfig(AlgorithmConfig):
    """Configuration for BscanImageAndMaskGenerationAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.BscanImageAndMaskGenerationAlgorithm.value
            )
        )
    )

    arguments: Optional[BscanImageAndMaskGenerationAlgorithmArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(BscanImageAndMaskGenerationAlgorithmArgumentsConfig)
            )
        )
    )


@dataclass
class CSVReportGeneratorOphthalmologyAlgorithmArgumentsConfig:
    """Configuration for CSVReportGeneratorOphthalmologyAlgorithm arguments."""

    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    trial_name: Optional[str] = desert.field(fields.String(), default=None)
    original_cols: Optional[list[str]] = None
    aux_cols: Optional[list[str]] = desert.field(
        fields.List(fields.String(), allow_none=True),
        default_factory=list,
    )
    rename_columns: Optional[dict[str, str]] = desert.field(
        fields.Dict(keys=fields.Str(), values=fields.Str()), default=None
    )
    filter: Optional[list[ColumnFilter]] = desert.field(
        fields.Nested(desert.schema_class(ColumnFilter), many=True, allow_none=True),
        default=None,
    )
    match_patient_visit: Optional[MatchPatientVisit] = desert.field(
        fields.Nested(desert.schema_class(MatchPatientVisit), allow_none=True),
        default=None,
    )
    matched_csv_path: Optional[Path] = desert.field(
        FilePath(allow_none=True), default=None
    )
    produce_matched_only: bool = True
    csv_extensions: Optional[list[str]] = None
    produce_trial_notes_csv: bool = False
    sorting_columns: Optional[dict[str, str]] = desert.field(
        fields.Dict(
            keys=fields.Str(),
            values=fields.Str(validate=validate.OneOf(typing.get_args(DFSortType))),
        ),
        default=None,
    )

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class CSVReportGeneratorOphthalmologyAlgorithmConfig(AlgorithmConfig):
    """Configuration for CSVReportGeneratorOphthalmologyAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.CSVReportGeneratorOphthalmologyAlgorithm.value,
                    AlgorithmType.CSVReportGeneratorAlgorithm.value,  # Kept for backwards compatibility # noqa: E501
                    # Without "bitfount." prefix for backwards compatibility
                    "CSVReportGeneratorOphthalmologyAlgorithm",
                    "CSVReportGeneratorAlgorithm",  # Kept for backwards compatibility
                ]
            )
        )
    )

    arguments: Optional[CSVReportGeneratorOphthalmologyAlgorithmArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    CSVReportGeneratorOphthalmologyAlgorithmArgumentsConfig
                )
            ),
            default_factory=CSVReportGeneratorOphthalmologyAlgorithmArgumentsConfig,
        )
    )


@dataclass
class ETDRSAlgorithmArgumentsConfig:
    """Configuration for ETDRSAlgorithm arguments."""

    laterality: str
    slo_photo_location_prefixes: Optional[SLOSegmentationLocationPrefix] = desert.field(
        fields.Nested(
            desert.schema_class(SLOSegmentationLocationPrefix), allow_none=True
        ),
        default=None,
    )
    slo_image_metadata_columns: Optional[SLOImageMetadataColumns] = desert.field(
        fields.Nested(desert.schema_class(SLOImageMetadataColumns), allow_none=True),
        default=None,
    )
    oct_image_metadata_columns: Optional[OCTImageMetadataColumns] = desert.field(
        fields.Nested(
            desert.schema_class(OCTImageMetadataColumns),
            allow_none=True,
        ),
        default=None,
    )
    threshold: float = 0.7
    calculate_on_oct: bool = False
    slo_mm_width: float = 8.8
    slo_mm_height: float = 8.8


@dataclass
class ETDRSAlgorithmConfig(AlgorithmConfig):
    """Configuration for ETDRSAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.ETDRSAlgorithm.value,
                    # Without "bitfount." prefix for backwards compatibility
                    "ETDRSAlgorithm",
                ]
            )
        )
    )

    arguments: Optional[ETDRSAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(ETDRSAlgorithmArgumentsConfig)),
    )


@dataclass
class FluidVolumeCalculationAlgorithmArgumentsConfig:
    """Configuration for FluidVolumeCalculationAlgorithm arguments."""

    fluid_volume_include_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )


@dataclass
class FluidVolumeCalculationAlgorithmConfig(AlgorithmConfig):
    """Configuration for FluidVolumeCalculationAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.FluidVolumeCalculationAlgorithm.value)
        )
    )

    arguments: Optional[FluidVolumeCalculationAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(
            desert.schema_class(FluidVolumeCalculationAlgorithmArgumentsConfig)
        ),
        default_factory=FluidVolumeCalculationAlgorithmArgumentsConfig,
    )


@dataclass
class FoveaCoordinatesAlgorithmArgumentsConfig:
    """Configuration for FoveaCoordinatesAlgorithm arguments."""

    bscan_width_col: str = "size_width"
    location_prefixes: Optional[SLOSegmentationLocationPrefix] = desert.field(
        fields.Nested(
            desert.schema_class(SLOSegmentationLocationPrefix),
            allow_none=True,
        ),
        default=None,
    )


@dataclass
class FoveaCoordinatesAlgorithmConfig(AlgorithmConfig):
    """Configuration for FoveaCoordinatesAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.FoveaCoordinatesAlgorithm.value,
                    # Without "bitfount." prefix for backwards compatibility
                    "FoveaCoordinatesAlgorithm",
                ]
            )
        )
    )

    arguments: Optional[FoveaCoordinatesAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(FoveaCoordinatesAlgorithmArgumentsConfig)),
        default_factory=FoveaCoordinatesAlgorithmArgumentsConfig,
    )


@dataclass
class _SimpleCSVAlgorithmArgumentsConfig:
    """Configuration for _SimpleCSVAlgorithm arguments."""

    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class _SimpleCSVAlgorithmAlgorithmConfig(AlgorithmConfig):
    """Configuration for _SimpleCSVAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType._SimpleCSVAlgorithm.value,
                    # Without "bitfount." prefix for backwards compatibility
                    "_SimpleCSVAlgorithm",
                ]
            )
        )
    )

    arguments: Optional[_SimpleCSVAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(_SimpleCSVAlgorithmArgumentsConfig)),
        default_factory=_SimpleCSVAlgorithmArgumentsConfig,
    )


@dataclass
class ReduceCSVAlgorithmCharcoalArgumentsConfig:
    """Configuration for ReduceCSVAlgorithmCharcoal arguments."""

    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    eligible_only: bool = desert.field(
        TemplatedOrTyped(fields.Bool(load_default=True, dump_default=True)),
        default=True,
    )
    # TODO: [BIT-7207] Remove delete_intermediate field.
    delete_intermediate: Optional[bool] = desert.field(
        TemplatedOrTyped(
            fields.Bool(allow_none=True, load_default=None, dump_default=None)
        ),
        default=None,
    )

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None

        # TODO: [BIT-7207] Remove delete_intermediate field.
        if self.delete_intermediate is not None:
            warnings.warn(
                "The `delete_intermediate` field is deprecated and has no effect."
                " Intermediate CSV files are never deleted. This field will be"
                " removed in a future version.",
                DeprecationWarning,
                stacklevel=2,
            )
            self.delete_intermediate = None


@dataclass
class ReduceCSVAlgorithmCharcoalConfig(AlgorithmConfig):
    """Configuration for ReduceCSVAlgorithmCharcoal."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.ReduceCSVAlgorithmCharcoal.value,
                    # Without "bitfount." prefix for backwards compatibility
                    "ReduceCSVAlgorithmCharcoal",
                ]
            )
        )
    )

    arguments: Optional[ReduceCSVAlgorithmCharcoalArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(ReduceCSVAlgorithmCharcoalArgumentsConfig)),
        default_factory=ReduceCSVAlgorithmCharcoalArgumentsConfig,
    )


@dataclass
class _GATrialCalculationAlgorithmBaseArgumentsConfig:
    """Configuration for GATrialCalculationAlgorithmBase arguments."""

    ga_area_include_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(
            fields.List(
                fields.String(validate=validate.OneOf(ALL_SEGMENTATION_LABELS)),
                allow_none=True,
            )
        ),
        default=None,
    )
    ga_area_exclude_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(
            fields.List(
                fields.String(validate=validate.OneOf(ALL_SEGMENTATION_LABELS)),
                allow_none=True,
            )
        ),
        default=None,
    )
    extra_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(
            fields.List(
                fields.String(validate=validate.OneOf(ALL_SEGMENTATION_LABELS)),
                allow_none=True,
            )
        ),
        default=None,
    )

    def __post_init__(self) -> None:
        overlap = _get_overlap_include_exclude_area(
            self.ga_area_include_segmentations, self.ga_area_exclude_segmentations
        )

        if overlap:
            _logger.error(
                f"GA Trial Calculation Algo init with overlapping "
                f"include and exclude segmentation: {overlap}"
            )
            raise ValidationError(
                f"GA Trial Calculation Algo init with overlapping "
                f"include and exclude segmentation: {overlap}"
            )


@dataclass
class GATrialCalculationAlgorithmJadeArgumentsConfig(
    _GATrialCalculationAlgorithmBaseArgumentsConfig
):
    """Configuration for GATrialCalculationAlgorithmJade arguments."""

    pass


@dataclass
class GATrialCalculationAlgorithmJadeConfig(AlgorithmConfig):
    """Configuration for GATrialCalculationAlgorithmJade."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.GATrialCalculationAlgorithmJade.value,
                    AlgorithmType.GATrialCalculationAlgorithm.value,  # Kept for backwards compatibility # noqa: E501
                    # Without "bitfount." prefix for backwards compatibility
                    "GATrialCalculationAlgorithmJade",
                    "GATrialCalculationAlgorithm",  # Kept for backwards compatibility
                ]
            )
        )
    )

    arguments: Optional[GATrialCalculationAlgorithmJadeArgumentsConfig] = desert.field(
        fields.Nested(
            desert.schema_class(GATrialCalculationAlgorithmJadeArgumentsConfig)
        ),
        default_factory=GATrialCalculationAlgorithmJadeArgumentsConfig,
    )


@dataclass
class GATrialCalculationAlgorithmAmethystArgumentsConfig(
    _GATrialCalculationAlgorithmBaseArgumentsConfig
):
    """Configuration for GATrialCalculationAlgorithmAmethyst arguments."""

    pass


@dataclass
class GATrialCalculationAlgorithmAmethystConfig(AlgorithmConfig):
    """Configuration for GATrialCalculationAlgorithmAmethyst."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.GATrialCalculationAlgorithmAmethyst.value,
                    AlgorithmType.GATrialCalculationAlgorithmJade.value,  # Kept for backwards compatibility # noqa: E501
                    AlgorithmType.GATrialCalculationAlgorithm.value,  # Kept for backwards compatibility # noqa: E501
                    # Without "bitfount." prefix for backwards compatibility
                    "GATrialCalculationAlgorithmAmethyst",
                    "GATrialCalculationAlgorithmJade",  # Kept for backwards compatibility # noqa: E501
                    "GATrialCalculationAlgorithm",  # Kept for backwards compatibility
                ]
            )
        )
    )

    arguments: Optional[GATrialCalculationAlgorithmAmethystArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(GATrialCalculationAlgorithmAmethystArgumentsConfig)
            ),
            default_factory=GATrialCalculationAlgorithmAmethystArgumentsConfig,
        )
    )


@dataclass
class _GATrialCalculationWithFoveaAlgorithmBaseArgumentsConfig:
    """Configuration for GATrialCalculationAlgorithmWithFoveaBase arguments."""

    ga_area_include_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(
            fields.List(
                fields.String(validate=validate.OneOf(ALL_SEGMENTATION_LABELS)),
                allow_none=True,
            )
        ),
        default=None,
    )
    ga_area_exclude_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(
            fields.List(
                fields.String(validate=validate.OneOf(ALL_SEGMENTATION_LABELS)),
                allow_none=True,
            )
        ),
        default=None,
    )
    extra_segmentations: Optional[list[str]] = desert.field(
        TemplatedOrTyped(
            fields.List(
                fields.String(validate=validate.OneOf(ALL_SEGMENTATION_LABELS)),
                allow_none=True,
            )
        ),
        default=None,
    )
    fovea_landmark_idx: Optional[int] = FOVEA_CENTRE_LANDMARK_INDEX

    def __post_init__(self) -> None:
        overlap = _get_overlap_include_exclude_area(
            self.ga_area_include_segmentations, self.ga_area_exclude_segmentations
        )

        if overlap:
            _logger.error(
                f"GA Trial Calculation Algo init with overlapping "
                f"include and exclude segmentation: {overlap}"
            )
            raise ValidationError(
                f"GA Trial Calculation Algo init with overlapping "
                f"include and exclude segmentation: {overlap}"
            )


@dataclass
class GATrialCalculationAlgorithmBronzeArgumentsConfig(
    _GATrialCalculationWithFoveaAlgorithmBaseArgumentsConfig
):
    """Configuration for GATrialCalculationAlgorithmBronze arguments."""

    pass


@dataclass
class GATrialCalculationAlgorithmBronzeConfig(AlgorithmConfig):
    """Configuration for GATrialCalculationAlgorithmBronze."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.GATrialCalculationAlgorithmBronze.value,
                    # Without "bitfount." prefix for backwards compatibility
                    "GATrialCalculationAlgorithmBronze",
                ]
            )
        )
    )

    arguments: Optional[GATrialCalculationAlgorithmBronzeArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(GATrialCalculationAlgorithmBronzeArgumentsConfig)
            ),
            default_factory=GATrialCalculationAlgorithmBronzeArgumentsConfig,
        )
    )


@dataclass
class GATrialCalculationAlgorithmCharcoalArgumentsConfig(
    _GATrialCalculationWithFoveaAlgorithmBaseArgumentsConfig
):
    """Configuration for GATrialCalculationAlgorithmCharcoal arguments."""

    pass


@dataclass
class GATrialCalculationAlgorithmCharcoalConfig(AlgorithmConfig):
    """Configuration for GATrialCalculationAlgorithmCharcoal."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.GATrialCalculationAlgorithmCharcoal.value,
                ]
            )
        )
    )

    arguments: Optional[GATrialCalculationAlgorithmCharcoalArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(GATrialCalculationAlgorithmCharcoalArgumentsConfig)
            ),
            default_factory=GATrialCalculationAlgorithmCharcoalArgumentsConfig,
        )
    )


@dataclass
class GATrialPDFGeneratorAlgorithmJadeArgumentsConfig:
    """Configuration for GATrialPDFGeneratorAlgorithmJade arguments."""

    # TODO: [BIT-2926] ReportMetadata should not be optional
    report_metadata: Optional[ReportMetadata] = desert.field(
        fields.Nested(desert.schema_class(ReportMetadata)),
        default=None,
    )
    filename_prefix: Optional[str] = desert.field(
        fields.String(validate=validate.Regexp("[a-zA-Z]+")), default=None
    )
    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    filter: Optional[list[ColumnFilter]] = desert.field(
        fields.Nested(desert.schema_class(ColumnFilter), many=True, allow_none=True),
        default=None,
    )
    pdf_filename_columns: Optional[list[str]] = None
    trial_name: Optional[str] = desert.field(fields.String(), default=None)

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class GATrialPDFGeneratorAlgorithmJadeConfig(AlgorithmConfig):
    """Configuration for GATrialPDFGeneratorAlgorithmJade."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.GATrialPDFGeneratorAlgorithmJade.value,
                    AlgorithmType.GATrialPDFGeneratorAlgorithm.value,  # Kept for backwards compatibility # noqa: E501
                    # Without "bitfount." prefix for backwards compatibility
                    "GATrialPDFGeneratorAlgorithmJade",
                    "GATrialPDFGeneratorAlgorithm",  # Kept for backwards compatibility
                ]
            )
        )
    )

    arguments: Optional[GATrialPDFGeneratorAlgorithmJadeArgumentsConfig] = desert.field(
        fields.Nested(
            desert.schema_class(GATrialPDFGeneratorAlgorithmJadeArgumentsConfig)
        ),
        default_factory=GATrialPDFGeneratorAlgorithmJadeArgumentsConfig,
    )


@dataclass
class GATrialPDFGeneratorAlgorithmAmethystArgumentsConfig:
    """Configuration for GATrialPDFGeneratorAlgorithmAmethyst arguments."""

    # TODO: [BIT-2926] ReportMetadata should not be optional
    report_metadata: Optional[ReportMetadata] = desert.field(
        fields.Nested(desert.schema_class(ReportMetadata)),
        default=None,
    )
    filename_prefix: Optional[str] = desert.field(
        fields.String(validate=validate.Regexp("[a-zA-Z]+")), default=None
    )
    save_path: Optional[Path] = desert.field(
        FilePath(allow_none=True, load_only=True), default=None
    )
    filter: Optional[list[ColumnFilter]] = desert.field(
        fields.Nested(desert.schema_class(ColumnFilter), many=True, allow_none=True),
        default=None,
    )
    pdf_filename_columns: Optional[list[str]] = None
    trial_name: Optional[str] = desert.field(fields.String(), default=None)

    def __post_init__(self) -> None:
        if self.save_path is not None:
            warnings.warn(
                f"The `save_path` field is deprecated in {type(self).__name__}."
                "Use the BITFOUNT_OUTPUT_DIR,"
                " BITFOUNT_TASK_RESULTS,"
                " or BITFOUNT_PRIMARY_RESULTS_DIR"
                " environment variables instead.",
                DeprecationWarning,
            )
            self.save_path = None


@dataclass
class GATrialPDFGeneratorAlgorithmAmethystConfig(AlgorithmConfig):
    """Configuration for GATrialPDFGeneratorAlgorithmAmethyst."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.GATrialPDFGeneratorAlgorithmAmethyst.value,
                    # Without "bitfount." prefix for backwards compatibility
                    "GATrialPDFGeneratorAlgorithmAmethyst",
                ]
            )
        )
    )

    arguments: Optional[GATrialPDFGeneratorAlgorithmAmethystArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(GATrialPDFGeneratorAlgorithmAmethystArgumentsConfig)
            ),
            default_factory=GATrialPDFGeneratorAlgorithmAmethystArgumentsConfig,
        )
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmJadeArgumentsConfig:
    """Configuration for TrialInclusionCriteriaMatchAlgorithmJade arguments."""

    # Jade exposes nothing here, using the defaults instead.
    pass


@dataclass
class TrialInclusionCriteriaMatchAlgorithmJadeConfig(AlgorithmConfig):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmJade."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithmJade.value,
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithm.value,  # Kept for backwards compatibility # noqa: E501
                    # Without "bitfount." prefix for backwards compatibility
                    "TrialInclusionCriteriaMatchAlgorithmJade",
                    "TrialInclusionCriteriaMatchAlgorithm",  # Kept for backwards compatibility # noqa: E501
                ]
            )
        )
    )

    arguments: Optional[TrialInclusionCriteriaMatchAlgorithmJadeArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    TrialInclusionCriteriaMatchAlgorithmJadeArgumentsConfig
                )
            ),
            default_factory=TrialInclusionCriteriaMatchAlgorithmJadeArgumentsConfig,
        )
    )


@dataclass
class _TrialInclusionCriteriaMatchAlgorithmBaseArgumentsConfig:
    """Shared base arguments for trial inclusion algorithms."""

    cnv_threshold: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=CNV_THRESHOLD
    )
    largest_ga_lesion_lower_bound: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=LARGEST_GA_LESION_LOWER_BOUND
    )
    largest_ga_lesion_upper_bound: Optional[float] = desert.field(
        TemplatedOrTyped(fields.Float(allow_none=True)), default=None
    )
    total_ga_area_lower_bound: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=TOTAL_GA_AREA_LOWER_BOUND
    )
    total_ga_area_upper_bound: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=TOTAL_GA_AREA_UPPER_BOUND
    )
    patient_age_lower_bound: Optional[int] = desert.field(
        TemplatedOrTyped(fields.Integer(allow_none=True)), default=None
    )
    patient_age_upper_bound: Optional[int] = desert.field(
        TemplatedOrTyped(fields.Integer(allow_none=True)), default=None
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmAmethystArgumentsConfig(
    _TrialInclusionCriteriaMatchAlgorithmBaseArgumentsConfig
):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmAmethyst arguments."""

    pass


@dataclass
class TrialInclusionCriteriaMatchAlgorithmAmethystConfig(AlgorithmConfig):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmAmethyst."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithmAmethyst.value,
                    # without "bitfount." prefix for backward compatibility
                    "TrialInclusionCriteriaMatchAlgorithmAmethyst",
                ],
            )
        )
    )

    arguments: Optional[TrialInclusionCriteriaMatchAlgorithmAmethystArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    TrialInclusionCriteriaMatchAlgorithmAmethystArgumentsConfig
                )
            ),
            default_factory=TrialInclusionCriteriaMatchAlgorithmAmethystArgumentsConfig,
        )
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmBronzeArgumentsConfig(
    _TrialInclusionCriteriaMatchAlgorithmBaseArgumentsConfig
):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmBronze arguments."""

    distance_from_fovea_lower_bound: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=DISTANCE_FROM_FOVEA_LOWER_BOUND
    )
    distance_from_fovea_upper_bound: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=DISTANCE_FROM_FOVEA_UPPER_BOUND
    )
    exclude_foveal_ga: bool = desert.field(
        TemplatedOrTyped(fields.Bool()), default=EXCLUDE_FOVEAL_GA
    )
    conditions_inclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    conditions_exclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    procedures_exclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmBronzeConfig(AlgorithmConfig):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmBronze."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithmBronze.value,
                    # without "bitfount." prefix for backward compatibility
                    "TrialInclusionCriteriaMatchAlgorithmBronze",
                ],
            )
        )
    )

    arguments: Optional[TrialInclusionCriteriaMatchAlgorithmBronzeArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    TrialInclusionCriteriaMatchAlgorithmBronzeArgumentsConfig
                )
            ),
            default_factory=TrialInclusionCriteriaMatchAlgorithmBronzeArgumentsConfig,
        )
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmCharcoalArgumentsConfig(
    _TrialInclusionCriteriaMatchAlgorithmBaseArgumentsConfig
):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmCharcoal arguments."""

    conditions_inclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    conditions_exclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    procedures_exclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    hypertransmission_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0))
        ),
        default=None,
    )
    neurosensory_retina_atrophy_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0))
        ),
        default=None,
    )
    drusen_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(
                allow_none=True,
                validate=validate.Range(min=0.0, max=1.0),
            )
        ),
        default=None,
    )
    diffuse_edema_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(
                allow_none=True,
                validate=validate.Range(min=0.0, max=1.0),
            )
        ),
        default=None,
    )
    epiretinal_fibrosis_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )
    hard_exudates_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )
    intraretinal_cystoid_fluid_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )
    serous_rpe_detachment_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )
    subretinal_fluid_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )
    subretinal_hyperreflective_material__shrm__threshold: Optional[float] = (
        desert.field(
            TemplatedOrTyped(
                fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
            ),
            default=None,
        )
    )

    diabetic_macular_edema_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )
    wet_amd_threshold: Optional[float] = desert.field(
        TemplatedOrTyped(
            fields.Float(allow_none=True, validate=validate.Range(min=0.0, max=1.0))
        ),
        default=None,
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmCharcoalConfig(AlgorithmConfig):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmCharcoal."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithmCharcoal.value,
                ],
            )
        )
    )

    arguments: Optional[TrialInclusionCriteriaMatchAlgorithmCharcoalArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    TrialInclusionCriteriaMatchAlgorithmCharcoalArgumentsConfig
                )
            ),
            default_factory=TrialInclusionCriteriaMatchAlgorithmCharcoalArgumentsConfig,
        )
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoalArgumentsConfig:
    """Configuration for TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoal arguments."""  # noqa: E501

    conditions_inclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    conditions_exclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    procedures_exclusion_codes: Optional[list[str]] = desert.field(
        TemplatedOrTyped(fields.List(fields.String(), allow_none=True)), default=None
    )
    patient_age_lower_bound: Optional[int] = desert.field(
        TemplatedOrTyped(fields.Integer(allow_none=True)), default=None
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoalConfig(AlgorithmConfig):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoal."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoal.value,
                ],
            )
        )
    )

    arguments: Optional[
        TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoalArgumentsConfig
    ] = desert.field(
        fields.Nested(
            desert.schema_class(
                TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoalArgumentsConfig
            )
        ),
        default_factory=(
            TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoalArgumentsConfig
        ),
    )


@dataclass
class TrialInclusionCriteriaMatchAlgorithmSapphireArgumentsConfig(
    _TrialInclusionCriteriaMatchAlgorithmBaseArgumentsConfig
):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmSapphire arguments."""

    pass


@dataclass
class TrialInclusionCriteriaMatchAlgorithmSapphireConfig(AlgorithmConfig):
    """Configuration for TrialInclusionCriteriaMatchAlgorithmSapphire."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.TrialInclusionCriteriaMatchAlgorithmSapphire.value,
                ],
            )
        )
    )

    arguments: Optional[TrialInclusionCriteriaMatchAlgorithmSapphireArgumentsConfig] = (
        desert.field(
            fields.Nested(
                desert.schema_class(
                    TrialInclusionCriteriaMatchAlgorithmSapphireArgumentsConfig
                )
            ),
            default_factory=TrialInclusionCriteriaMatchAlgorithmSapphireArgumentsConfig,
        )
    )


@dataclass
class S3UploadAlgorithmArgumentsConfig:
    """Configuration for S3UploadAlgorithm arguments."""

    s3_bucket: Optional[str] = desert.field(
        TemplatedOrTyped(fields.String(allow_none=True)), default=None
    )
    aws_region: Optional[str] = desert.field(
        TemplatedOrTyped(fields.String(allow_none=True)), default=None
    )
    aws_profile: str = desert.field(
        TemplatedOrTyped(fields.String(allow_none=True)), default="default"
    )
    # Note: upload_url_expiration is specified in HOURS, not seconds.
    # It will be converted to seconds when used (e.g., when calling AWS S3 API).
    # Only integer (whole number) values are "accepted" (will truncate floats to
    # int). Minimum value is 1.
    upload_url_expiration: int = desert.field(
        TemplatedOrTyped(fields.Integer(validate=validate.Range(min=1))),
        default=DEFAULT_URL_EXPIRY_IN_HOURS,
    )


@dataclass
class S3UploadAlgorithmConfig(AlgorithmConfig):
    """Configuration for S3UploadAlgorithm."""

    name: str = desert.field(
        fields.String(validate=validate.Equal(AlgorithmType.S3UploadAlgorithm.value))
    )

    arguments: Optional[S3UploadAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(S3UploadAlgorithmArgumentsConfig)),
    )


@dataclass
class S3UploadAlgorithmWithMRNTrackingConfig(AlgorithmConfig):
    """Configuration for S3UploadAlgorithmWithMRNTracking."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(
                AlgorithmType.S3UploadAlgorithmWithMRNTracking.value
            )
        )
    )

    arguments: Optional[S3UploadAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(S3UploadAlgorithmArgumentsConfig)),
    )


@dataclass
class PatientIDExchangeAlgorithmArgumentsConfig:
    """Configuration for PatientIDExchangeAlgorithm arguments."""

    patient_ids_file: Optional[Path] = desert.field(
        TemplatedOrTyped(FilePath(allow_none=True)), default=None
    )

    def __post_init__(self) -> None:
        if self.patient_ids_file is None:
            _logger.error("Must supply `patient_ids_file` in task input.")
            raise ValueError("Must supply `patient_ids_file` in task input.")


@dataclass
class PatientIDExchangeAlgorithmConfig(AlgorithmConfig):
    """Configuration for PatientIDExchangeAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.PatientIDExchangeAlgorithm.value)
        )
    )

    arguments: Optional[PatientIDExchangeAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(PatientIDExchangeAlgorithmArgumentsConfig)),
    )


@dataclass
class ImageSelectionAlgorithmArgumentsConfig:
    """Configuration for ImageSelectionAlgorithm arguments."""

    pass


@dataclass
class ImageSelectionAlgorithmConfig(AlgorithmConfig):
    """Configuration for ImageSelectionAlgorithm algorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.ImageSelectionAlgorithm.value)
        )
    )
    # pyrefly: ignore[bad-override]
    arguments: ImageSelectionAlgorithmArgumentsConfig = desert.field(
        fields.Nested(desert.schema_class(ImageSelectionAlgorithmArgumentsConfig)),
        default_factory=ImageSelectionAlgorithmArgumentsConfig,
    )


@dataclass
class CSTCalculationAlgorithmArgumentsConfig:
    """Configuration for CSTCalculationAlgorithm arguments."""

    cst_radius_mm: float = desert.field(TemplatedOrTyped(fields.Float()), default=0.5)
    ilm_layer_name: str = desert.field(TemplatedOrTyped(fields.String()), default="ILM")
    rpe_layer_name: str = desert.field(
        TemplatedOrTyped(fields.String()), default="RPE Layer"
    )
    fovea_landmark_idx: int = desert.field(
        TemplatedOrTyped(fields.Integer()), default=FOVEA_CENTRE_LANDMARK_INDEX
    )
    strict_measurement: bool = desert.field(
        TemplatedOrTyped(fields.Boolean()), default=False
    )


@dataclass
class CSTCalculationAlgorithmConfig(AlgorithmConfig):
    """Configuration for CSTCalculationAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.CSTCalculationAlgorithm.value)
        )
    )

    arguments: Optional[CSTCalculationAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(CSTCalculationAlgorithmArgumentsConfig)),
        default_factory=CSTCalculationAlgorithmArgumentsConfig,
    )


@dataclass
class GCCCalculationAlgorithmArgumentsConfig:
    """Configuration for GCCCalculationAlgorithm arguments."""

    region_radius_mm: float = desert.field(
        TemplatedOrTyped(fields.Float()), default=3.0
    )
    inner_layer_name: str = desert.field(
        TemplatedOrTyped(fields.String()), default="RNFL"
    )
    outer_layer_name: str = desert.field(
        TemplatedOrTyped(fields.String()), default="IPL"
    )
    macula_landmark_idx: int = desert.field(
        TemplatedOrTyped(fields.Integer()), default=MACULA_CENTRE_LANDMARK_INDEX
    )
    strict_measurement: bool = desert.field(
        TemplatedOrTyped(fields.Boolean()), default=True
    )


@dataclass
class GCCCalculationAlgorithmConfig(AlgorithmConfig):
    """Configuration for GCCCalculationAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.Equal(AlgorithmType.GCCCalculationAlgorithm.value)
        )
    )

    arguments: Optional[GCCCalculationAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(GCCCalculationAlgorithmArgumentsConfig)),
        default_factory=GCCCalculationAlgorithmArgumentsConfig,
    )


@dataclass
class LongitudinalAlgorithmArgumentsConfig:
    """Configuration for LongitudinalAlgorithm arguments."""

    pass


@dataclass
class LongitudinalAlgorithmConfig(AlgorithmConfig):
    """Configuration for LongitudinalAlgorithm."""

    name: str = desert.field(
        fields.String(
            validate=validate.OneOf(
                [
                    AlgorithmType.LongitudinalAlgorithm.value,
                ]
            )
        )
    )

    arguments: Optional[LongitudinalAlgorithmArgumentsConfig] = desert.field(
        fields.Nested(desert.schema_class(LongitudinalAlgorithmArgumentsConfig)),
        default_factory=LongitudinalAlgorithmArgumentsConfig,
    )
