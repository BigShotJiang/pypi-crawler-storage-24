"""Config schemas for task template upload configuration.

This module provides an SDK mirror for the task template configuration schemas used
when uploading task templates to the Bitfount Hub, _but_ the source of truth is the
web repo.
"""

from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel


class TaskTemplateModelConfig(BaseModel):
    """Model config for task template upload configuration.

    This is used when uploading models as part of task template uploads.
    For model configuration in task YAML files, see ModelConfig in model_schemas.

    This doesn't have a direct equivalent in the web repo, but it serves as a
    description for uploading/linking models to task templates.
    """

    model_file: str
    private: bool = True
    weights_file: Optional[str] = None


# Task template types
# Corresponds to packages/components/modules/types/TaskTemplateTypes.ts::{TaskTemplateTypes,TaskTemplateTypesUIResources} # noqa: E501
# in the web repo. Any changes should be reflected in the web repo as well.
TaskTemplateType = (
    Literal["image-classification"]
    | Literal["image-segmentation"]
    | Literal["text-classification"]
    | Literal["text-generation"]
    | Literal["object-detection"]
    | Literal["tabular-classification"]
    | Literal["tabular-regression"]
    | Literal["tabular-analytics"]
    | Literal["data-transfer"]
    | Literal["token-classification"]
    | Literal["image-text-to-text"]
    | Literal["recommender-system"]
    # Not in use
    # | Literal["oct-scan-segmentation"]
)

# Task template tags
# Corresponds to packages/components/modules/types/TaskTemplateTypes.ts::TaskTemplateTags # noqa: E501
# in the web repo. Any changes should be reflected in the web repo as well.
TaskTemplateTag = (
    Literal["Prediction"]
    | Literal["Training"]
    | Literal["Evaluation"]
    | Literal["Querying"]
    | Literal["Comparison"]
    | Literal["File Selection"]
    # Domain
    | Literal["Ophthalmology"]
)


class BasicTaskTemplateConfig(BaseModel):
    """Base task template config model for operations that only require a slug.

    This minimal configuration is used for operations that only need to identify
    a task template by its slug, such as archiving or unarchiving templates.
    For operations that require full template metadata (uploading, updating),
    use TaskTemplateConfig instead.

    Attributes:
        slug: The unique identifier for the task template. Used to identify
            templates in the Bitfount Hub for operations like archiving.
    """

    slug: str


class TaskTemplateConfig(BasicTaskTemplateConfig):
    """Full task template config model for uploading and updating task templates.

    This extends BasicTaskTemplateConfig with all metadata required to create
    or update a task template on the Bitfount Hub. Use this when uploading
    new templates or updating existing ones with their full configuration.

    Corresponds to packages/hub/specs/task-template.swagger.yaml::components["schemas"]["TaskTemplateInput"]
    in the web repo. Any changes should be reflected in the web repo as well.

    Attributes:
        title: The display name for the task template.
        type: The type of task (e.g., "image-classification", "text-generation").
            Must be one of the TaskTemplateType values.
        description: A description of what the task template does.
        template: Path to the YAML file containing the task definition.
        tags: List of tags for categorising the template (e.g., ["Prediction",
            "Ophthalmology"]). Must be values from TaskTemplateTag.
        sampleDatasetDownloadUrl: Optional URL to a sample dataset that can be used
            with this task template for testing or demonstration purposes.
    """  # noqa: E501

    title: str
    type: TaskTemplateType
    description: str
    template: str
    tags: list[TaskTemplateTag]
    sampleDatasetDownloadUrl: Optional[str] = None
