"""Generate a PDF report from a template using ReportLab."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import io
import math
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Final, Optional, Union

from PIL.Image import Image
from reportlab.lib.colors import Color
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    TOTAL_GA_AREA_LOWER_BOUND,
    TOTAL_GA_AREA_UPPER_BOUND,
    GAMetrics,
    GAMetricsWithFovea,
)
from bitfount.hub.helper import get_hub_url
from bitfount.visualisation import ASSETS_DIR
from bitfount.visualisation.utils import generate_slider

BITFOUNT_BLUE: tuple[int, int, int] = (25, 33, 77)
GREY: tuple[int, int, int] = (118, 134, 158)
BLACK: tuple[int, int, int] = (0, 0, 0)

_LOGO_PATH: Final[Path] = ASSETS_DIR / "bitfount_logo_horizontal.png"
_ALTRIS_LOGO_PATH: Final[Path] = ASSETS_DIR / "Altris_600x300.png"
_REGULAR_FONT_PATH: Final[Path] = ASSETS_DIR / "Inter-Regular.ttf"
_SEMIBOLD_FONT_PATH: Final[Path] = ASSETS_DIR / "Inter-SemiBold.ttf"
GA_DICT_KEYS_TO_LABELS = {
    "total_ga_area": "Total GA area",
    "smallest_lesion_size": "Smallest lesion size",
    "largest_lesion_size": "Largest lesion size",
    "num_bscans_with_ga": "Slices with GA",
    "num_ga_lesions": "Number of GA lesions",
    "distance_from_image_centre": "Distance from image centre",
    "distance_from_fovea_centre": "Distance from fovea",
    "subfoveal_indicator": "Subfoveal lesion",
}
GA_METRICS_UNITS = {
    "total_ga_area": "mm\u00b2",
    "smallest_lesion_size": "mm\u00b2",
    "largest_lesion_size": "mm\u00b2",
    "distance_from_image_centre": "mm",
    "distance_from_fovea_centre": "mm",
}
SUMMARY_TABLE_COLUMN_COUNT = 2
SUMMARY_TABLE_KEYS = [
    "total_ga_area",
    "smallest_lesion_size",
    "largest_lesion_size",
    "distance_from_image_centre",
    "distance_from_fovea_centre",
    "subfoveal_indicator",
]

HUB_TASK_URL_PATH_PREFIX = "tasks/task/"


def _rgb_to_color(rgb: tuple[int, int, int]) -> Color:
    """Convert RGB tuple (0-255) to ReportLab Color."""
    return Color(rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0)


def _register_fonts() -> None:
    """Register custom Inter fonts with ReportLab."""
    if "Inter" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont("Inter", str(_REGULAR_FONT_PATH)))
    if "Inter-Bold" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont("Inter-Bold", str(_SEMIBOLD_FONT_PATH)))


@dataclass
class AltrisRecordInfo:
    """Patient/scan information for the report.

    Args:
        text_fields: A list of tuples of heading and value for the pdf top table.
        heading: The heading for the pdf. Defaults to None.
    """

    text_fields: list[tuple[str, str]]
    heading: Optional[str] = "GA OCT REPORT"


@dataclass
class AltrisScan:
    """Scan information for the report.

    Args:
        name: Name of the scan.
        en_face_image_path: Path to the en-face image.
        bscan_image_path: Path to the B-scan image. This should be the bscan that
            corresponds to the location of the fovea.
    """

    bscan_image: Union[str, os.PathLike[str], Image]
    bscan_idx: int
    bscan_total: int
    bscan_w_mask: Union[str, os.PathLike[str], Image]
    legend2color: dict[str, tuple[int, int, int]]
    laterality: Optional[str] = None
    bscan_en_face: Optional[Union[str, os.PathLike[str], Image]] = None
    # Placeholder for en face image


class ReportJade:
    """Generate a PDF report from a template using ReportLab.

    Args:
        report_info: Patient/scan information for the report.
        scan: List of scans to include in the report.
        metrics: List of GA metrics to include in the report.
        total_ga_area_lower_bound: The lower bound for the GA area. This is used to
            generate the slider. Defaults to 2.5.
        total_ga_area_upper_bound: The upper bound for the GA area. This is used to
            generate the slider. Defaults to 17.5.
        task_id: The task ID.
    """

    def __init__(
        self,
        record_info: AltrisRecordInfo,
        scan: Union[AltrisScan, list[AltrisScan]],
        metrics: Union[GAMetrics, list[GAMetrics]],
        task_id: str,
        total_ga_area_lower_bound: float = TOTAL_GA_AREA_LOWER_BOUND,
        total_ga_area_upper_bound: float = TOTAL_GA_AREA_UPPER_BOUND,
        **kwargs: Any,
    ) -> None:
        _register_fonts()

        self.report_info = record_info.text_fields
        self.heading = record_info.heading
        self.scan = scan if isinstance(scan, list) else [scan]
        self.metrics = metrics if isinstance(metrics, list) else [metrics]
        self.total_ga_area_lower_bound = total_ga_area_lower_bound
        self.total_ga_area_upper_bound = total_ga_area_upper_bound
        self.task_id = task_id

        # Page setup - A4 dimensions
        self.page_width, self.page_height = A4
        self.l_margin = 10 * mm
        self.r_margin = 10 * mm
        self.t_margin = 10 * mm
        self.b_margin = 10 * mm

        # Helper attributes
        self._right_x = self.page_width - self.r_margin
        self._left_x = self.l_margin
        self._top_y = self.page_height - self.t_margin
        self._bottom_y = self.b_margin

        self.laterality_added = False
        self._summary_heading_added = False
        self._scan_details_table_added = False

        # Canvas will be created during output
        self._canvas: Optional[canvas.Canvas] = None
        self._output_buffer: Optional[io.BytesIO] = None

    def _draw_header(self) -> None:
        """Adds the header to the report.

        Adds the Altris logo to the top right of every page.
        """
        if self._canvas is None:
            return

        logo_width = 40 * mm
        logo_x = self._right_x - logo_width
        logo_y = self._top_y - 10 * mm

        img_reader = ImageReader(str(_ALTRIS_LOGO_PATH))
        img_height = self._calculate_image_height(img_reader, logo_width)
        self._canvas.drawImage(
            img_reader,
            logo_x,
            logo_y,
            width=logo_width,
            height=img_height,
            preserveAspectRatio=True,
            mask="auto",
        )

    def _draw_footer(self) -> None:
        """Adds the footer to the report."""
        if self._canvas is None:
            return

        self._canvas.setStrokeColor(_rgb_to_color(GREY))
        self._canvas.setLineWidth(0.35 * mm)
        self._canvas.line(
            self._left_x,
            self._bottom_y + 1.5 * mm,
            self._right_x,
            self._bottom_y + 1.5 * mm,
        )

        logo_width = 20 * mm
        logo_height = 4.5 * mm
        self._canvas.drawImage(
            str(_LOGO_PATH),
            self._left_x,
            3 * mm,
            width=logo_width,
            height=logo_height,
            preserveAspectRatio=True,
            mask="auto",
        )

        self._canvas.setFont("Inter", 8)
        self._canvas.setFillColor(_rgb_to_color(BLACK))
        center_x = (self._left_x + self._right_x) / 2
        self._canvas.drawCentredString(center_x, 5 * mm, "Research Use Only")

        timestamp = (
            datetime.now().strftime("%d %B %Y %I:%M")
            + datetime.now().strftime("%p").lower()
        )
        self._canvas.drawRightString(self._right_x, 5 * mm, timestamp)

    def generate(self) -> None:
        """Generates the report.

        This should be called by the user.
        """
        if self._canvas is None:
            return

        self._draw_header()

        # Set up initial position
        self._canvas.setFont("Inter-Bold", 20)
        self._canvas.setFillColor(_rgb_to_color(BITFOUNT_BLUE))

        y = self._top_y - 10 * mm
        hub_url = get_hub_url()
        link = f"{hub_url}/{HUB_TASK_URL_PATH_PREFIX}/{self.task_id}"

        if self.heading:
            self._canvas.drawString(self._left_x, y, self.heading)
            # Add link annotation
            text_width = self._canvas.stringWidth(self.heading, "Inter-Bold", 20)
            self._canvas.linkURL(
                link,
                (self._left_x, y - 2 * mm, self._left_x + text_width, y + 6 * mm),
                relative=0,
            )
            y -= 10 * mm

        # Draw separator line
        self._canvas.setLineWidth(0.35 * mm)
        self._canvas.setStrokeColor(_rgb_to_color(GREY))

        y = self._details_table(y - 6 * mm)
        y -= 4 * mm
        self._canvas.line(self._left_x, y, self._right_x, y)

        for metric, scan in zip(self.metrics, self.scan):
            self._scan_details_table_added = False
            y = self._summary_table(y - 4 * mm, metric=metric, scan=scan)
            y = self._add_slider(y, ga_metric=metric.total_ga_area)
            y = self._add_scans(y, scan)
            if not self._scan_details_table_added:
                y = self._scan_details_table(y - 4 * mm, metric=metric, scan=scan)

        self._draw_footer()

    def output(self, filename: Union[str, os.PathLike[str]]) -> None:
        """Save the PDF to a file.

        Args:
            filename: The path to save the PDF.
        """
        self._output_buffer = io.BytesIO()
        self._canvas = canvas.Canvas(self._output_buffer, pagesize=A4)

        self.generate()

        if self._canvas is not None:
            self._canvas.save()

        if self._output_buffer is not None:
            with open(filename, "wb") as f:
                f.write(self._output_buffer.getvalue())

    def _add_slider(self, y: float, ga_metric: float) -> float:
        """Adds the slider to the report.

        Args:
            y: The y-coordinate of the top left corner of the table.
            ga_metric: The GA metric.
        """
        if self._canvas is None:
            return y

        slider_height = 30 * mm

        # To ensure that the location for the slider PNG is writeable, we use a temp
        # directory. We use this in preference to (Named)TemporaryFile as we cannot
        # guarantee that calls further down the stack will not close the file
        # prematurely.
        with TemporaryDirectory() as tmpdir:
            slider_file: str = str(Path(tmpdir) / "slider.png")
            generate_slider(
                ga_metric,
                filename=slider_file,
                total_ga_area_lower_bound=self.total_ga_area_lower_bound,
                total_ga_area_upper_bound=self.total_ga_area_upper_bound,
            )
            slider_width = self._right_x - self._left_x - 1 * mm
            self._canvas.drawImage(
                slider_file,
                self._left_x + 1 * mm,
                y - slider_height,
                width=slider_width,
                height=slider_height,
                preserveAspectRatio=True,
                mask="auto",
            )

        y -= slider_height
        return y

    def _scan_details_table(
        self, y: float, metric: GAMetrics, scan: AltrisScan
    ) -> float:
        """Adds the scan details table to the report.

        This is the part of the report that includes the slice number,
        number of total slices, and slices with GA.

        Args:
            y: The y-coordinate of the top left corner of the table.
            metric: The GA metrics.
            scan: The scan.
        """
        if self._canvas is None:
            return y

        x = self._left_x
        self._canvas.setFont("Inter", 8)
        self._canvas.setFillColor(_rgb_to_color(BLACK))

        if metric.total_ga_area > 0:
            ga_bscan_text = (
                f"Slice with largest amount of GA: "
                f"{scan.bscan_idx + 1}/{scan.bscan_total}"
            )
        else:
            ga_bscan_text = f"Central slice: {scan.bscan_idx + 1}/{scan.bscan_total}"

        self._canvas.drawString(x, y, ga_bscan_text)

        x = x + 60 * mm
        analysed_slices_text = f"Analysed slices: {scan.bscan_total}/{scan.bscan_total}"
        self._canvas.drawString(x, y, analysed_slices_text)

        x = x + 40 * mm
        self._canvas.drawString(x, y, f"Slices with GA: {metric.num_bscans_with_ga}")

        self._scan_details_table_added = True
        return y

    def _get_image_reader(
        self, image: Union[str, os.PathLike[str], Image]
    ) -> ImageReader:
        """Convert image path or PIL Image to ImageReader.

        Args:
            image: Path to image file or PIL Image object.

        Returns:
            ImageReader object for use with ReportLab.
        """
        if isinstance(image, Image):
            # Convert PIL Image to bytes
            img_buffer = io.BytesIO()
            image.save(img_buffer, format="PNG")
            img_buffer.seek(0)
            return ImageReader(img_buffer)
        else:
            return ImageReader(str(image))

    def _add_scans(self, y: float, scan: AltrisScan) -> float:
        """Adds the scans to the report.

        Returns:
            The y value after all scans added.
        """
        x = self._left_x
        new_y = self._add_scan(scan=scan, x=x, y=y)
        return new_y

    def _add_scan(self, scan: AltrisScan, x: float, y: float) -> float:
        """Adds a single scan to the report.

        Args:
            scan: The scan to add.
            x: x-coordinate of the top left corner of the scan.
            y: y-coordinate of the top left corner of the scan.

        Returns:
            The y value after all scans added.
        """
        if self._canvas is None:
            return y

        img_width = 55 * mm

        # Draw bscan_image
        img_reader = self._get_image_reader(scan.bscan_image)
        img_height = self._calculate_image_height(img_reader, img_width)
        self._canvas.drawImage(
            img_reader,
            x,
            y - img_height,
            width=img_width,
            height=img_height,
            preserveAspectRatio=True,
            mask="auto",
        )

        # Draw bscan_w_mask
        img_reader_mask = self._get_image_reader(scan.bscan_w_mask)
        img_height_mask = self._calculate_image_height(img_reader_mask, img_width)
        self._canvas.drawImage(
            img_reader_mask,
            x + 60 * mm,
            y - img_height_mask,
            width=img_width,
            height=img_height_mask,
            preserveAspectRatio=True,
            mask="auto",
        )

        # Draw legend
        self._image_colour_legend(
            x=x + 120 * mm, y=y - 3 * mm, legend2color=scan.legend2color
        )

        img_height = max(img_height, img_height_mask) + 1 * mm
        y -= img_height
        return y

    def _calculate_image_height(
        self, img_reader: ImageReader, target_width: float
    ) -> float:
        """Calculate the height of an image given a target width.

        Args:
            img_reader: ImageReader object.
            target_width: Desired width.

        Returns:
            Calculated height maintaining aspect ratio.
        """
        img_width, img_height = img_reader.getSize()
        aspect_ratio = img_height / img_width
        return target_width * aspect_ratio

    def _add_cell(
        self,
        header: str,
        body: str,
        x: float,
        y: float,
        horizontal_distance: float,
        font_sizes: tuple[int, int] = (8, 10),
        fixed_spacing: Optional[float] = None,
    ) -> None:
        """Add a cell to the report.

        Args:
            header: The header of the cell.
            body: The body of the cell.
            x: x-coordinate of the top left corner of the cell.
            y: y-coordinate of the top left corner of the cell.
            horizontal_distance: The horizontal distance to the next cell.
            font_sizes: The font sizes for the label and text.
            fixed_spacing: The fixed spacing between the label and text.
        """
        if self._canvas is None:
            return

        # Draw header
        self._canvas.setFont("Inter-Bold", font_sizes[0])
        self._canvas.setFillColor(_rgb_to_color(GREY))
        self._canvas.drawString(x, y, header)

        # Calculate spacing
        if fixed_spacing:
            spacing = fixed_spacing * mm
        else:
            spacing = len(header) * 2 * mm

        # Draw body
        self._canvas.setFont("Inter", font_sizes[1])
        self._canvas.setFillColor(_rgb_to_color(BLACK))
        self._canvas.drawString(x + spacing, y, body)

    def _details_table(self, y: float) -> float:
        """Adds the top table to the report.

        Returns:
            The y value where the table finishes.
        """
        table_vertical_distance = 6 * mm

        for index in range(len(self.report_info)):
            if self.report_info[index][0].isupper():
                cell_header = self.report_info[index][0]
            else:
                cell_header = self.report_info[index][0].title()
            self._add_cell(
                cell_header,
                self.report_info[index][1],
                x=self._left_x,
                y=y,
                horizontal_distance=200 * mm,
                fixed_spacing=32,
            )
            y -= table_vertical_distance
        return y

    def _add_laterality(self, y: float, scan: AltrisScan) -> float:
        """Add the laterality to the report.

        Args:
            y: The y-coordinate of the top left corner of the table.
            scan: The scan.
        """
        if self._canvas is None:
            return y

        self._canvas.setFont("Inter-Bold", 10)
        self._canvas.setFillColor(_rgb_to_color(BITFOUNT_BLUE))

        if scan.laterality in ["right", "r", "Right", "R"]:
            laterality = "Right eye"
        elif scan.laterality in ["left", "l", "Left", "L"]:
            laterality = "Left eye"
        else:
            # If nothing is found, still print a header
            laterality = "Eye Scans"

        self._canvas.drawString(self._left_x, y, laterality)
        y -= 6 * mm
        self.laterality_added = True
        return y

    def _summary_table(
        self, y: float, metric: Union[GAMetrics, GAMetricsWithFovea], scan: AltrisScan
    ) -> float:
        """Generate Summary table for the report.

        Args:
            y: The y-coordinate of the top left corner of the table.
            metric: The GA metrics.
            scan: The scan.
        """
        if self._canvas is None:
            return y

        table_vertical_distance = 6 * mm
        table_horizontal_distance = 80 * mm
        y -= 4 * mm
        y = self._add_laterality(y, scan)
        y -= 2 * mm

        index = 0
        for key in SUMMARY_TABLE_KEYS:
            # Skip if the key is not in the metric
            if not hasattr(metric, key):
                continue
            if key == "subfoveal_indicator":
                if getattr(metric, key, None) is None:
                    continue
            if index % SUMMARY_TABLE_COLUMN_COUNT == 0:
                x = self._left_x
                fixed_spacing = 32
            else:
                x = self._left_x + table_horizontal_distance
                fixed_spacing = 42
            if index > 0 and index % SUMMARY_TABLE_COLUMN_COUNT == 0:
                y -= table_vertical_distance

            if (
                key
                in (
                    "distance_from_fovea_centre",
                    "distance_from_image_centre",
                    "smallest_lesion_size",
                    "largest_lesion_size",
                    "subfoveal_indicator",
                )
                and metric.total_ga_area == 0
            ):
                self._add_cell(
                    GA_DICT_KEYS_TO_LABELS[key],
                    "N/A",
                    x=x,
                    y=y,
                    horizontal_distance=table_horizontal_distance,
                    fixed_spacing=fixed_spacing,
                )
            else:
                if key == "subfoveal_indicator":
                    # If the subfoveal lesion is not detected, we show "Not detected"
                    if getattr(metric, key, None) is None:
                        self._add_cell(
                            GA_DICT_KEYS_TO_LABELS[key],
                            "N/A",
                            x=x,
                            y=y,
                            horizontal_distance=table_horizontal_distance,
                            fixed_spacing=fixed_spacing,
                        )
                        index += 1
                        continue
                    else:
                        self._add_cell(
                            GA_DICT_KEYS_TO_LABELS[key],
                            str(getattr(metric, key)),
                            x=x,
                            y=y,
                            horizontal_distance=table_horizontal_distance,
                            fixed_spacing=fixed_spacing,
                        )
                else:
                    self._add_cell(
                        GA_DICT_KEYS_TO_LABELS[key],
                        (
                            str(round(float(getattr(metric, key)), 3))
                            + GA_METRICS_UNITS.get(key, "")
                            if getattr(metric, key, None) is not None
                            and not math.isnan(getattr(metric, key))
                            else "Not detected"
                        ),
                        x=x,
                        y=y,
                        horizontal_distance=table_horizontal_distance,
                        fixed_spacing=fixed_spacing,
                    )
            index += 1

        y -= table_vertical_distance
        return y

    def _image_colour_legend(
        self, x: float, y: float, legend2color: dict[str, tuple[int, int, int]]
    ) -> None:
        """Draws the colour legend for the image.

        Args:
            x: x-coordinate of the top left corner of the legend.
            y: y-coordinate of the top left corner of the legend.
            legend2color: A dictionary mapping legend to colour.
        """
        if self._canvas is None:
            return

        self._canvas.setFont("Inter", 8)
        self._canvas.setFillColor(_rgb_to_color(GREY))

        box_size = 3 * mm
        for legend, colour in legend2color.items():
            # Draw colored box
            self._canvas.setFillColor(_rgb_to_color(colour))
            self._canvas.rect(
                x, y - box_size, box_size, box_size, fill=True, stroke=False
            )

            # Draw legend text
            self._canvas.setFillColor(_rgb_to_color(GREY))
            self._canvas.drawString(
                x + box_size + 1 * mm, y - box_size + 1 * mm, legend
            )

            y -= box_size * 2


def generate_pdf(
    file_name: Union[str, os.PathLike[str]],
    report_info: AltrisRecordInfo,
    scans: Union[AltrisScan, list[AltrisScan]],
    metrics: Union[GAMetrics, list[GAMetrics]],
    task_id: str,
    total_ga_area_lower_bound: float = TOTAL_GA_AREA_LOWER_BOUND,
    total_ga_area_upper_bound: float = TOTAL_GA_AREA_UPPER_BOUND,
) -> None:
    """Generates a PDF report.

    Args:
        file_name: The name of the file to save the report to.
        report_info: The report info.
        scans: The scans.
        metrics: The GA metrics.
        total_ga_area_lower_bound: The lower bound for the GA area. This is used to
            generate the slider. Defaults to 2.5.
        total_ga_area_upper_bound: The upper bound for the GA area. This is used to
            generate the slider. Defaults to 17.5.
        task_id: The task ID.
    """
    pdf = ReportJade(
        report_info,
        scans,
        metrics,
        task_id=task_id,
        total_ga_area_lower_bound=total_ga_area_lower_bound,
        total_ga_area_upper_bound=total_ga_area_upper_bound,
    )
    pdf.output(str(file_name))
