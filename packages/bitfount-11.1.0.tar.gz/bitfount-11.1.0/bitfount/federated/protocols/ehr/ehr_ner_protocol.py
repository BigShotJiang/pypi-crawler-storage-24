"""Protocol for combining EHR patient query with NER inference and CSV reporting.

This protocol:
1. Queries EHR for patient conditions and procedures
2. Extracts condition/procedure text as separate entries (one per condition/procedure)
3. Runs NER inference on each text entry separately
4. Aggregates entities per patient and generates a CSV report with NER results linked
    to patient IDs
"""

from __future__ import annotations

from collections.abc import Sequence
import json
import os
import tempfile
import time
from typing import (
    TYPE_CHECKING,
    Any,
    Optional,
    Protocol,
    Union,
    cast,
    runtime_checkable,
)

import pandas as pd

from bitfount.data.datasources.csv_source import CSVSource
from bitfount.data.types import DataSplit
from bitfount.federated.algorithms.base import FinalStepAlgorithm
from bitfount.federated.algorithms.csv_report_algorithm import CSVReportAlgorithm
from bitfount.federated.algorithms.ehr.ehr_patient_query_algorithm import (
    EHRPatientQueryAlgorithm,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    _BITFOUNT_PATIENT_ID_KEY,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.protocols.base import (
    BaseCompatibleAlgoFactory,
    BaseCompatibleModellerAlgorithm,
    BaseCompatibleWorkerAlgorithm,
    BaseModellerProtocol,
    BaseProtocolFactory,
    BaseWorkerProtocol,
    FinalStepProtocol,
)
from bitfount.federated.transport.modeller_transport import _ModellerMailbox
from bitfount.federated.transport.worker_transport import _WorkerMailbox
from bitfount.federated.types import ProtocolContext

if TYPE_CHECKING:
    from bitfount.federated.pod_vitals import _PodVitals
    from bitfount.hub.api import BitfountHub

_logger = _get_federated_logger(__name__)


@runtime_checkable
class _EHRNERCompatibleModellerAlgorithm(BaseCompatibleModellerAlgorithm, Protocol):
    """Defines modeller-side algorithm compatibility."""

    pass


@runtime_checkable
class _EHRNERCompatibleWorkerAlgorithm(BaseCompatibleWorkerAlgorithm, Protocol):
    """Defines worker-side algorithm compatibility."""

    pass


class _ModellerSide(BaseModellerProtocol):
    """Modeller side of the EHR NER protocol.

    Args:
        algorithm: A list of algorithms to be run by the protocol. This should be
            a list of three algorithms: EHR query, NER inference, and CSV report.
        mailbox: The mailbox to use for communication with the Workers.
        **kwargs: Additional keyword arguments.
    """

    algorithm: Sequence[_EHRNERCompatibleModellerAlgorithm]  # type: ignore[assignment]

    def __init__(
        self,
        *,
        algorithm: Sequence[_EHRNERCompatibleModellerAlgorithm],
        mailbox: _ModellerMailbox,
        **kwargs: Any,
    ) -> None:
        super().__init__(algorithm=algorithm, mailbox=mailbox, **kwargs)

    async def run(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> None:
        """Runs Modeller side of the protocol.

        This receives results from the workers and signals completion.

        Args:
            context: Run-time context for the protocol.
            **kwargs: Additional keyword arguments.
        """
        # Wait for results from all three algorithm steps
        await self.mailbox.get_evaluation_results_from_workers()  # EHR query
        await self.mailbox.get_evaluation_results_from_workers()  # NER inference
        await self.mailbox.get_evaluation_results_from_workers()  # CSV report


class _WorkerSide(BaseWorkerProtocol, FinalStepProtocol[FinalStepAlgorithm]):
    """Worker side of the EHR NER protocol.

    Args:
        algorithm: A list of algorithms to be run by the protocol. This should be
            a list of three algorithms: EHR query, NER inference, and CSV report.
        mailbox: The mailbox to use for communication with the Modeller.
        **kwargs: Additional keyword arguments.
    """

    algorithm: Sequence[BaseCompatibleWorkerAlgorithm]  # type: ignore[assignment]

    def __init__(
        self,
        *,
        algorithm: Sequence[BaseCompatibleWorkerAlgorithm],
        mailbox: _WorkerMailbox,
        **kwargs: Any,
    ) -> None:
        super().__init__(algorithm=algorithm, mailbox=mailbox, **kwargs)

    async def run(
        self,
        *,
        pod_vitals: Optional[_PodVitals] = None,
        context: ProtocolContext,
        final_batch: bool = False,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Runs the protocol on worker side.

        This orchestrates:
        1. Querying EHR for patient conditions and procedures
        2. Extracting text from conditions/procedures as separate entries
        3. Running NER on each text entry separately
        4. Aggregating entities per patient and generating CSV report with results

        Args:
            pod_vitals: Optional. Pod vitals instance for recording run-time details
                from the protocol run.
            context: Run-time context for the protocol.
            final_batch: If this run of the protocol represents the final run within
                a task.
            **kwargs: Additional keyword arguments.

        Returns:
            DataFrame containing NER results with patient identifiers.
        """
        from bitfount.federated.algorithms.csv_report_algorithm import (
            _WorkerSide as _CSVWorkerSide,
        )
        from bitfount.federated.algorithms.ehr.ehr_patient_query_algorithm import (
            _WorkerSide as _EHRQueryWorkerSide,
        )
        from bitfount.federated.algorithms.hugging_face_algorithms.hugging_face_ner import (  # noqa: E501
            _WorkerSide as _NERWorkerSide,
        )

        if pod_vitals:
            pod_vitals.last_task_execution_time = time.time()

        # Unpack the three algorithms
        ehr_query_algo, ner_algo, csv_report_algo = self.algorithm
        ehr_query_algo = cast(_EHRQueryWorkerSide, ehr_query_algo)
        ner_algo = cast(_NERWorkerSide, ner_algo)
        csv_report_algo = cast(_CSVWorkerSide, csv_report_algo)

        # Step 1: Query EHR for patient data
        _logger.info("Querying EHR for patient conditions and procedures")

        # Get the patient list from the datasource
        # The datasource should be a CSV with patient identifiers (names, DOBs)
        # Use yield_data to get all data from the datasource
        dfs = list(ehr_query_algo.datasource.yield_data(use_cache=True))
        if any(not df.empty for df in dfs):
            patient_df_maybe = pd.concat(dfs, axis="index")
        else:
            patient_df_maybe = None

        if patient_df_maybe is None:
            _logger.warning("No patient data available; returning empty results")
            # Still need to send results to modeller for all three steps
            await self.mailbox.send_evaluation_results({})
            await self.mailbox.send_evaluation_results({})
            await self.mailbox.send_evaluation_results({})
            return pd.DataFrame()

        patient_df = patient_df_maybe

        # Query EHR for each patient
        query_results = ehr_query_algo.run(
            patient_df,
            get_appointments=False,
            get_conditions_and_procedures=True,
            get_practitioner=False,
            get_visual_acuity=False,
        )

        _logger.info(f"Retrieved EHR data for {len(query_results)} patients")

        # Send empty results to modeller to move to next algorithm
        await self.mailbox.send_evaluation_results({})

        # Step 2: Extract text from conditions and procedures as separate entries
        _logger.info("Extracting text from conditions and procedures")
        text_data = self._extract_text_from_query_results(query_results)

        if text_data.empty:
            _logger.warning("No text data extracted from EHR; returning empty results")
            # Still need to send results to modeller for NER and CSV steps
            await self.mailbox.send_evaluation_results({})
            await self.mailbox.send_evaluation_results({})
            return pd.DataFrame()

        # Step 3: Run NER on each text entry separately
        _logger.info(f"Running NER inference on {len(text_data)} text samples")

        # Temporarily replace the datasource with our text data
        # Save original datasource
        original_datasource = ner_algo.datasource

        # Write text_data to a temporary CSV file
        with tempfile.NamedTemporaryFile(
            mode="w", delete=False, suffix=".csv", newline=""
        ) as tmp_file:
            temp_csv_path = tmp_file.name
        try:
            text_data.to_csv(temp_csv_path, index=False)

            # Create a new CSVSource from the temporary file
            temp_datasource = CSVSource(temp_csv_path)

            # Temporarily swap the datasource
            ner_algo.datasource = temp_datasource

            # Re-initialize the NER algorithm with the new datasource
            ner_algo.initialise_data(datasource=temp_datasource)

            # Re-create the test dataloader with the text data
            from bitfount.data.huggingface.utils import get_data_factory_dataset

            data_factory, dataset = get_data_factory_dataset(
                datasource=temp_datasource,
                data_splitter=None,
                data_split=DataSplit.TEST,
                selected_cols=[ner_algo.target_column_name],
                selected_cols_semantic_types=ner_algo.target_col_with_semantic_type,
                batch_transforms=[],
            )
            ner_algo.test_dataloader = data_factory.create_dataloader(
                dataset, batch_size=ner_algo.batch_size
            )

            # Run NER inference
            ner_results = ner_algo.run(return_data_keys=True, final_batch=final_batch)

        finally:
            # Clean up: restore original datasource and remove temp file
            ner_algo.datasource = original_datasource
            if os.path.exists(temp_csv_path):
                os.remove(temp_csv_path)

        _logger.info("NER inference complete")

        # Send empty results to modeller to move to next algorithm
        await self.mailbox.send_evaluation_results({})

        # Step 4: Merge NER results with patient information
        _logger.info("Merging NER results with patient information")
        # Ensure ner_results is a DataFrame
        if not isinstance(ner_results, pd.DataFrame):
            _logger.error(f"Unexpected NER results type: {type(ner_results)}")
            # Still need to send results to modeller
            await self.mailbox.send_evaluation_results({})
            return pd.DataFrame()

        final_results = self._merge_ner_results_with_patients(
            ner_results, text_data, query_results
        )

        # Step 5: Generate CSV report
        _logger.info("Generating CSV report")
        csv_report_algo.run(
            results_df=final_results,
            task_id=self.mailbox._task_id,
            final_batch=final_batch,
        )

        # Send empty results to modeller to signal completion
        await self.mailbox.send_evaluation_results({})

        return final_results

    @staticmethod
    def _extract_text_from_query_results(
        query_results: dict[Any, Any],
    ) -> pd.DataFrame:
        """Extract text from patient conditions and procedures as separate entries.

        Creates one row per condition/procedure text so that NER can process
        them separately, preventing concatenation artifacts.

        Args:
            query_results: Dictionary mapping PatientDetails to PatientQueryResults.

        Returns:
            DataFrame with columns:
                - BitfountPatientID: Patient identifier
                - concatenated_text: Individual condition or procedure text
        """
        text_records = []

        for patient, patient_query_result in query_results.items():
            # Extract condition text - one record per condition
            if patient_query_result.codes.condition_codes is not None:
                for condition in patient_query_result.codes.condition_codes:
                    condition_text = None
                    if hasattr(condition, "code_text") and condition.code_text:
                        condition_text = condition.code_text
                    elif hasattr(condition, "code_display") and condition.code_display:
                        condition_text = condition.code_display

                    if condition_text:
                        text_records.append(
                            # pyrefly: ignore[bad-argument-type]
                            {
                                _BITFOUNT_PATIENT_ID_KEY: patient.bitfount_patient_id,
                                "concatenated_text": condition_text,
                            }
                        )

            # Extract procedure text - one record per procedure
            if patient_query_result.codes.procedure_codes is not None:
                for procedure in patient_query_result.codes.procedure_codes:
                    procedure_text = None
                    if hasattr(procedure, "code_text") and procedure.code_text:
                        procedure_text = procedure.code_text
                    elif hasattr(procedure, "code_display") and procedure.code_display:
                        procedure_text = procedure.code_display

                    if procedure_text:
                        text_records.append(
                            # pyrefly: ignore[bad-argument-type]
                            {
                                _BITFOUNT_PATIENT_ID_KEY: patient.bitfount_patient_id,
                                "concatenated_text": procedure_text,
                            }
                        )

        return pd.DataFrame.from_records(text_records)

    @staticmethod
    def _merge_ner_results_with_patients(
        ner_results: pd.DataFrame,
        text_data: pd.DataFrame,
        query_results: dict[Any, Any],
    ) -> pd.DataFrame:
        """Merge NER results with patient information.

        Aggregates entities from multiple condition/procedure texts per patient
        into a single list of entities.

        Args:
            ner_results: DataFrame with NER entities (one row per input text).
            text_data: DataFrame with patient IDs and individual text entries.
            query_results: Original EHR query results.

        Returns:
            DataFrame with aggregated NER results and patient information
            (one row per patient).
        """
        # Add patient IDs to NER results by matching row order
        # (assuming NER results are in the same order as text_data)
        if len(ner_results) != len(text_data):
            _logger.warning(
                f"NER results count ({len(ner_results)}) does not match "
                f"text data count ({len(text_data)}); data loss may occur. "
                f"Rows without matching patient IDs will be dropped."
            )

        # Reset indices to ensure alignment
        ner_results = ner_results.reset_index(drop=True)
        text_data = text_data.reset_index(drop=True)

        # Add patient ID column to NER results by matching row positions
        # Use iloc to safely handle length mismatches
        min_length = min(len(ner_results), len(text_data))
        # Create a Series with None values, then assign matching patient IDs
        patient_id_series = pd.Series([None] * len(ner_results), dtype=object)
        if min_length > 0:
            patient_id_series.iloc[:min_length] = (
                text_data[_BITFOUNT_PATIENT_ID_KEY].iloc[:min_length].values
            )
        ner_results[_BITFOUNT_PATIENT_ID_KEY] = patient_id_series.values

        # Filter out rows with NaN/None patient IDs before aggregation
        # These represent NER results that couldn't be matched to patient data
        # (either because ner_results has more rows, or because of alignment issues)
        rows_before_filter = len(ner_results)
        ner_results = ner_results[
            ~pd.isna(ner_results[_BITFOUNT_PATIENT_ID_KEY])
        ].copy()
        rows_after_filter = len(ner_results)
        rows_dropped = rows_before_filter - rows_after_filter

        if rows_dropped > 0:
            _logger.warning(
                f"Dropping {rows_dropped} NER result row(s) with missing patient IDs. "
                f"These rows' entities will not be included in the final results."
            )

        # Aggregate entities per patient
        # Group by patient ID and combine all entities from all rows
        aggregated_records = []
        # Get unique patient IDs, filtering out any remaining NaN values
        unique_patient_ids = [
            pid
            for pid in ner_results[_BITFOUNT_PATIENT_ID_KEY].unique()
            if not pd.isna(pid)
        ]
        for patient_id in unique_patient_ids:
            patient_ner_rows = ner_results[
                ner_results[_BITFOUNT_PATIENT_ID_KEY] == patient_id
            ]

            # Collect all entities from all rows for this patient
            all_entities = []
            for _, row in patient_ner_rows.iterrows():
                entities_json = row["entities"]
                try:
                    entities = json.loads(entities_json)
                    if isinstance(entities, list):
                        all_entities.extend(entities)
                except (json.JSONDecodeError, TypeError) as e:
                    _logger.warning(
                        f"Failed to parse entities JSON for patient {patient_id}: {e}"
                    )

            aggregated_records.append(
                # pyrefly: ignore[bad-argument-type]
                {
                    _BITFOUNT_PATIENT_ID_KEY: patient_id,
                    "entities": json.dumps(all_entities),
                }
            )

        aggregated_ner_results = pd.DataFrame.from_records(aggregated_records)

        # Add patient demographic info
        patient_info_records = []
        for patient, patient_query_result in query_results.items():
            patient_info_records.append(
                # pyrefly: ignore[bad-argument-type]
                {
                    _BITFOUNT_PATIENT_ID_KEY: patient.bitfount_patient_id,
                    "given_name": patient_query_result.given_name,
                    "family_name": patient_query_result.family_name,
                    "date_of_birth": patient_query_result.date_of_birth,
                    "gender": patient_query_result.gender,
                }
            )

        patient_info_df = pd.DataFrame.from_records(patient_info_records)

        # Merge aggregated NER results with patient info
        final_results = aggregated_ner_results.merge(
            patient_info_df,
            on=_BITFOUNT_PATIENT_ID_KEY,
            how="left",
        )

        return final_results


class EHRNERProtocol(BaseProtocolFactory):
    """Protocol for running EHR patient query, NER inference, and CSV reporting.

    This protocol:
    1. Queries EHR for patient conditions and procedures
    2. Extracts text from medical codes as separate entries
        (one per condition/procedure)
    3. Runs NER inference on each text entry separately
    4. Aggregates entities per patient and generates a CSV report with NER results
        linked to patient IDs

    Args:
        algorithm: A sequence of three algorithms:
            1. EHRPatientQueryAlgorithm
            2. HuggingFaceNERInference
            3. CSVReportAlgorithm
    """

    def __init__(
        self,
        *,
        algorithm: Sequence[BaseCompatibleAlgoFactory],
        **kwargs: Any,
    ) -> None:
        super().__init__(algorithm=algorithm, **kwargs)

    @classmethod
    def _validate_algorithm(cls, algorithm: BaseCompatibleAlgoFactory) -> None:
        """Validates the algorithm."""
        if algorithm.class_name not in (
            "bitfount.EHRPatientQueryAlgorithm",
            "bitfount.HuggingFaceNERInference",
            "bitfount.CSVReportAlgorithm",
        ):
            raise TypeError(
                f"The {cls.__name__} protocol does not support "
                + f"the {type(algorithm).__name__} algorithm.",
            )

    def modeller(
        self,
        *,
        mailbox: _ModellerMailbox,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _ModellerSide:
        """Returns the Modeller side of the protocol."""
        # Import here to avoid circular import
        from bitfount.federated.algorithms.hugging_face_algorithms.hugging_face_ner import (  # noqa: E501
            HuggingFaceNERInference,
        )

        algorithms = cast(
            Sequence[
                Union[
                    EHRPatientQueryAlgorithm,
                    HuggingFaceNERInference,
                    CSVReportAlgorithm,
                ]
            ],
            self.algorithms,
        )
        modeller_algos = [algo.modeller(context=context) for algo in algorithms]
        return _ModellerSide(
            algorithm=modeller_algos,
            mailbox=mailbox,
            **kwargs,
        )

    def worker(
        self,
        *,
        mailbox: _WorkerMailbox,
        hub: BitfountHub,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Returns worker side of the EHR NER protocol.

        Args:
            mailbox: Worker mailbox instance to allow communication to the modeller.
            hub: `BitfountHub` object to use for communication with the hub.
            context: Run-time protocol context details for running.
            **kwargs: Additional keyword arguments.
        """
        return _WorkerSide(
            algorithm=[
                algo.worker(hub=hub, context=context) for algo in self.algorithms
            ],
            mailbox=mailbox,
            **kwargs,
        )
