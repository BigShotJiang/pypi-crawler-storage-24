"""Protocol for patient-to-clinical-trial matching.

This protocol:
1. Queries EHR for patient conditions and demographics
2. Runs CodeNormalisationAlgorithm to map SNOMED and other codes to ICD-10
3. Runs SqlQuery to load trials from the trials database
4. Runs TrialMatchingAlgorithm to score and rank trials per patient via ICD-10
5. Generates a CSV report with matched trial results
"""

from __future__ import annotations

from collections.abc import Sequence
import time
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Optional,
    Protocol,
    Union,
    cast,
    runtime_checkable,
)

from marshmallow import fields
import pandas as pd

from bitfount import config
from bitfount.data.datasources.sql_source import _SQLSource
from bitfount.federated.algorithms.base import FinalStepAlgorithm
from bitfount.federated.algorithms.csv_report_algorithm import (
    CSVReportAlgorithm,
    _WorkerSide as _CSVWorkerSide,
)
from bitfount.federated.algorithms.ehr.code_normalisation import (
    _MAPPING_DB_FILENAME,
    CodeNormalisationAlgorithm,
    _WorkerSide as _CodeNormalisationWorkerSide,
)
from bitfount.federated.algorithms.ehr.ehr_patient_query_algorithm import (
    EHRPatientQueryAlgorithm,
    _WorkerSide as _EHRQueryWorkerSide,
)
from bitfount.federated.algorithms.ehr.trial_matching_algorithm import (
    TrialMatchingAlgorithm,
    _WorkerSide as _TrialMatchingWorkerSide,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    _BITFOUNT_PATIENT_ID_KEY,
    ICD10_COLUMN,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.protocols.base import (
    BaseCompatibleAlgoFactory,
    BaseCompatibleModellerAlgorithm,
    BaseCompatibleWorkerAlgorithm,
    BaseModellerProtocol,
    BaseProtocolFactory,
    BaseWorkerProtocol,
    FinalStepProtocol,
)
from bitfount.federated.transport.modeller_transport import _ModellerMailbox
from bitfount.federated.transport.worker_transport import _WorkerMailbox
from bitfount.federated.types import ProtocolContext
from bitfount.types import T_FIELDS_DICT
from bitfount.utils.download_utils import download_file_from_url

if TYPE_CHECKING:
    from bitfount.data.datasources.base_source import BaseSource
    from bitfount.data.datasplitters import DatasetSplitter
    from bitfount.externals.general.authentication import ExternallyManagedJWT
    from bitfount.federated.pod_vitals import _PodVitals
    from bitfount.federated.privacy.differential import DPPodConfig
    from bitfount.federated.types import EHRConfig
    from bitfount.hub.api import BitfountHub

_logger = _get_federated_logger(__name__)

# Algorithm class names allowed by this protocol; length defines number of steps
_ALLOWED_ALGORITHM_CLASS_NAMES = (
    "bitfount.EHRPatientQueryAlgorithm",
    "bitfount.CodeNormalisationAlgorithm",
    "bitfount.SqlQuery",
    "bitfount.TrialMatchingAlgorithm",
    "bitfount.CSVReportAlgorithm",
)


@runtime_checkable
class _TrialMatchCompatibleModellerAlgorithm(BaseCompatibleModellerAlgorithm, Protocol):
    """Defines modeller-side algorithm compatibility."""

    pass


@runtime_checkable
class _TrialMatchCompatibleWorkerAlgorithm(BaseCompatibleWorkerAlgorithm, Protocol):
    """Defines worker-side algorithm compatibility."""

    pass


class _ModellerSide(BaseModellerProtocol):
    """Modeller side of the PatientTrialMatchingProtocol.

    Args:
        algorithm: A list of algorithms to be run by the protocol.
        mailbox: The mailbox to use for communication with the Workers.
        **kwargs: Additional keyword arguments.
    """

    algorithm: Sequence[_TrialMatchCompatibleModellerAlgorithm]  # type: ignore[assignment]

    def __init__(
        self,
        *,
        algorithm: Sequence[_TrialMatchCompatibleModellerAlgorithm],
        mailbox: _ModellerMailbox,
        **kwargs: Any,
    ) -> None:
        super().__init__(algorithm=algorithm, mailbox=mailbox, **kwargs)

    async def run(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> None:
        """Runs Modeller side of the protocol.

        Waits for results from the workers for each algorithm step.

        Args:
            context: Run-time context for the protocol.
            **kwargs: Additional keyword arguments.
        """
        for _ in _ALLOWED_ALGORITHM_CLASS_NAMES:
            await self.mailbox.get_evaluation_results_from_workers()


class _WorkerSide(BaseWorkerProtocol, FinalStepProtocol[FinalStepAlgorithm]):
    """Worker side of the PatientTrialMatchingProtocol.

    Orchestrates the full pipeline:
    1. EHR query for patient conditions and demographics
    2. Code normalisation (SNOMED→ICD-10)
    3. SqlQuery for trials
    4. Trial matching (ICD-10 code overlap, scoring + top N)
    5. CSV report output

    Args:
        algorithm: A list of algorithms to be run by the protocol.
        mailbox: The mailbox to use for communication with the Modeller.
        trials_connection_string: Optional SQLAlchemy connection string for the
            clinical trials database.
        trials_database_url: Optional public URL to download the trials database
            from (e.g. S3). If provided and trials_connection_string is not, the
            database is downloaded to cache_dir and used. Supports .gz files
            (decompressed automatically).
        **kwargs: Additional keyword arguments.
    """

    algorithm: Sequence[BaseCompatibleWorkerAlgorithm]  # type: ignore[assignment]

    def __init__(
        self,
        *,
        algorithm: Sequence[BaseCompatibleWorkerAlgorithm],
        mailbox: _WorkerMailbox,
        trials_connection_string: Optional[str] = None,
        trials_database_url: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(algorithm=algorithm, mailbox=mailbox, **kwargs)
        self.trials_connection_string = trials_connection_string
        self.trials_database_url = trials_database_url

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        project_id: Optional[str] = None,
        ehr_secrets: Optional[ExternallyManagedJWT] = None,
        ehr_config: Optional[EHRConfig] = None,
        parent_pod_identifier: Optional[str] = None,
        datasource_name: Optional[str] = None,
        data_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialise the protocol, ensuring trials database is available before algos.

        When trials_database_url is set, downloads the database to cache_dir before
        initialising algorithms. CodeNormalisationAlgorithm.initialise() reads from
        the same file (snomed_to_icd10_mapping table), so the download must complete
        before super().initialise() invokes each algorithm's initialise().
        """
        if self.trials_database_url and not self.trials_connection_string:
            db_path = config.settings.paths.cache_dir / _MAPPING_DB_FILENAME
            download_file_from_url(
                self.trials_database_url,
                db_path,
                decompress_gzip=True,
                skip_if_exists=True,
            )
            self.trials_connection_string = f"sqlite:///{db_path.as_posix()}"

        super().initialise(
            datasource=datasource,
            task_id=task_id,
            data_splitter=data_splitter,
            pod_dp=pod_dp,
            pod_identifier=pod_identifier,
            project_id=project_id,
            ehr_secrets=ehr_secrets,
            ehr_config=ehr_config,
            parent_pod_identifier=parent_pod_identifier,
            datasource_name=datasource_name,
            data_identifier=data_identifier,
            **kwargs,
        )

    async def run(
        self,
        *,
        pod_vitals: Optional[_PodVitals] = None,
        context: ProtocolContext,
        final_batch: bool = False,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Runs the protocol on worker side.

        Args:
            pod_vitals: Optional. Pod vitals instance for recording run-time details.
            context: Run-time context for the protocol.
            final_batch: If this run of the protocol represents the final run.
            **kwargs: Additional keyword arguments.

        Returns:
            DataFrame containing matched trial results with patient identifiers.
        """
        # Import here to avoid circular imports
        # sql_query -> mixins -> protocols
        from bitfount.federated.algorithms.sql_query import (
            _WorkerSide as _SqlQueryWorkerSide,
        )

        if pod_vitals:
            pod_vitals.last_task_execution_time = time.time()

        # Unpack the five algorithms
        (
            ehr_query_algo,
            code_norm_algo,
            sql_query_algo,
            trial_matching_algo,
            csv_report_algo,
        ) = self.algorithm
        ehr_query_algo = cast(_EHRQueryWorkerSide, ehr_query_algo)
        code_norm_algo = cast(_CodeNormalisationWorkerSide, code_norm_algo)
        sql_query_algo = cast(_SqlQueryWorkerSide, sql_query_algo)
        trial_matching_algo = cast(_TrialMatchingWorkerSide, trial_matching_algo)
        csv_report_algo = cast(_CSVWorkerSide, csv_report_algo)

        # ── Step 1: Query EHR for patient data ──────────────────────────
        _logger.info("Step 1: Querying EHR for patient conditions and procedures")

        dfs = list(ehr_query_algo.datasource.yield_data(use_cache=True))
        if any(not df.empty for df in dfs):
            patient_df_maybe = pd.concat(dfs, axis="index")
        else:
            patient_df_maybe = None

        if patient_df_maybe is None:
            _logger.warning("No patient data available; returning empty results")
            for _ in _ALLOWED_ALGORITHM_CLASS_NAMES:
                await self.mailbox.send_evaluation_results({})
            return pd.DataFrame()

        patient_df = patient_df_maybe

        query_results = ehr_query_algo.run(
            patient_df,
            get_appointments=False,
            get_conditions_and_procedures=True,
            get_practitioner=False,
            get_visual_acuity=False,
        )
        _logger.info(f"Retrieved EHR data for {len(query_results)} patients")
        await self.mailbox.send_evaluation_results({})

        # ── Step 2: Code normalisation (SNOMED→ICD-10) ─────────────────────
        _logger.info("Step 2: Normalising condition codes to ICD-10")
        normalised_icd10 = code_norm_algo.run(
            patient_query_results=query_results,
        )
        await self.mailbox.send_evaluation_results({})

        # Build patient DataFrame with normalised ICD-10 codes for trial matching
        patient_for_matching = _build_patient_df_from_normalised_codes(
            normalised_icd10, query_results, patient_df
        )

        if patient_for_matching.empty:
            _logger.warning("No patient data with conditions; returning empty results")
            for _ in _ALLOWED_ALGORITHM_CLASS_NAMES[2:]:  # sql, trial_matching, csv
                await self.mailbox.send_evaluation_results({})
            return pd.DataFrame()

        # ── Step 3: SqlQuery to load trials from DB ─────────────────────
        _logger.info("Step 3: Loading trials from database via SqlQuery")

        # If a trials_connection_string is provided, create a dedicated
        # _SQLSource for the SqlQuery algorithm so it can query the trials
        # database directly rather than using the pod's datasource.
        original_sql_datasource = sql_query_algo.datasource
        if self.trials_connection_string:
            trials_datasource = _SQLSource(
                connection_string=self.trials_connection_string
            )
            sql_query_algo.datasource = trials_datasource

        try:
            trials_df = sql_query_algo.run()
        except Exception as e:
            _logger.error(f"SqlQuery failed: {type(e).__name__}: {e}")
            raise
        finally:
            sql_query_algo.datasource = original_sql_datasource

        _logger.info(f"Loaded {len(trials_df)} trial-condition rows from database")
        await self.mailbox.send_evaluation_results({})

        # ── Step 4: Trial matching ──────────────────────────────────────
        _logger.info("Step 4: Matching patients to trials")
        matched_df = trial_matching_algo.run(
            patient_df=patient_for_matching,
            trials_df=trials_df,
        )
        _logger.info("Trial matching complete")
        await self.mailbox.send_evaluation_results({})

        # ── Step 5: CSV report ──────────────────────────────────────────
        _logger.info("Step 5: Generating CSV report")

        # Drop columns from matched_df that already exist in the pod's
        # datasource so that CSVReportAlgorithm._extract_source_data can
        # join them without a pandas "columns overlap" ValueError.
        try:
            source_cols = set(
                next(csv_report_algo.datasource.yield_data(use_cache=True)).columns
            )
        except StopIteration:
            source_cols = set()
        overlap = source_cols & set(matched_df.columns)
        if overlap:
            _logger.info(f"Dropping overlapping columns before CSV report: {overlap}")
            csv_results_df = matched_df.drop(columns=list(overlap))
        else:
            csv_results_df = matched_df

        csv_report_algo.run(
            results_df=csv_results_df,
            task_id=self.mailbox._task_id,
            final_batch=final_batch,
        )
        await self.mailbox.send_evaluation_results({})

        return matched_df


def _build_patient_df_from_normalised_codes(
    normalised_icd10: dict[Any, list[str]],
    query_results: dict[Any, Any],
    patient_df: pd.DataFrame,
) -> pd.DataFrame:
    """Build a per-patient DataFrame with normalised ICD-10 codes for trial matching.

    Args:
        normalised_icd10: Dictionary mapping PatientDetails to list of ICD-10 codes.
        query_results: Dictionary mapping PatientDetails to PatientQueryResults
            (for demographics).
        patient_df: Original patient DataFrame from datasource (for location).

    Returns:
        DataFrame with one row per patient: BitfountPatientID, ICD10
        (list of ICD-10 code strings), date_of_birth, gender, postal_code,
        country, and optionally location columns from patient_df.
    """
    records = []
    for patient, icd10_codes in normalised_icd10.items():
        patient_query_result = query_results.get(patient)
        if patient_query_result is None:
            continue
        records.append(
            {
                _BITFOUNT_PATIENT_ID_KEY: patient.bitfount_patient_id,
                ICD10_COLUMN: icd10_codes,
                "given_name": patient_query_result.given_name,
                "family_name": patient_query_result.family_name,
                "date_of_birth": patient_query_result.date_of_birth,
                "gender": patient_query_result.gender,
                "postal_code": patient_query_result.postal_code,
                "country": patient_query_result.country,
            }
        )
    if not records:
        return pd.DataFrame()
    result = pd.DataFrame.from_records(records)

    _location_cols = [
        c
        for c in ("latitude", "longitude", "postal_code", "postcode", "country")
        if c in patient_df.columns
        and c not in result.columns
        and _BITFOUNT_PATIENT_ID_KEY in patient_df.columns
    ]
    if _location_cols:
        loc_df = patient_df[
            [_BITFOUNT_PATIENT_ID_KEY] + _location_cols
        ].drop_duplicates(subset=[_BITFOUNT_PATIENT_ID_KEY])
        result = result.merge(loc_df, on=_BITFOUNT_PATIENT_ID_KEY, how="left")
    return result


class PatientTrialMatchingProtocol(BaseProtocolFactory):
    """Protocol for matching patients to clinical trials via ICD-10 codes.

    This protocol chains five algorithms:
    1. EHRPatientQueryAlgorithm - queries EHR for patient conditions and demographics
    2. CodeNormalisationAlgorithm - maps SNOMED and other codes to ICD-10
    3. SqlQuery - loads recruiting trials from the trials database
    4. TrialMatchingAlgorithm - scores and ranks trials per patient via ICD-10
    5. CSVReportAlgorithm - writes results to CSV

    Args:
        algorithm: A sequence of five algorithms in the order listed above.
        trials_connection_string: Optional SQLAlchemy connection string for the
            clinical trials database. If provided, SqlQuery and the mapping load
            will use this connection instead of the pod's datasource.
        trials_database_url: Optional public URL to download the trials database
            from (e.g. S3). If provided and trials_connection_string is not, the
            database is downloaded to cache_dir and used. Supports .gz files
            (decompressed automatically).
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "trials_connection_string": fields.Str(allow_none=True),
        "trials_database_url": fields.Str(allow_none=True),
    }

    def __init__(
        self,
        *,
        algorithm: Sequence[BaseCompatibleAlgoFactory],
        trials_connection_string: Optional[str] = None,
        trials_database_url: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(algorithm=algorithm, **kwargs)
        self.trials_connection_string = trials_connection_string
        self.trials_database_url = trials_database_url

    @classmethod
    def _validate_algorithm(cls, algorithm: BaseCompatibleAlgoFactory) -> None:
        """Validates the algorithm."""
        if algorithm.class_name not in _ALLOWED_ALGORITHM_CLASS_NAMES:
            raise TypeError(
                f"The {cls.__name__} protocol does not support "
                + f"the {type(algorithm).__name__} algorithm.",
            )

    def modeller(
        self,
        *,
        mailbox: _ModellerMailbox,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _ModellerSide:
        """Returns the Modeller side of the protocol."""
        from bitfount.federated.algorithms.sql_query import SqlQuery

        algorithms = cast(
            Sequence[
                Union[
                    EHRPatientQueryAlgorithm,
                    CodeNormalisationAlgorithm,
                    SqlQuery,
                    TrialMatchingAlgorithm,
                    CSVReportAlgorithm,
                ]
            ],
            self.algorithms,
        )
        modeller_algos = [algo.modeller(context=context) for algo in algorithms]
        return _ModellerSide(
            algorithm=modeller_algos,
            mailbox=mailbox,
            **kwargs,
        )

    def worker(
        self,
        *,
        mailbox: _WorkerMailbox,
        hub: BitfountHub,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Returns worker side of the PatientTrialMatchingProtocol.

        Args:
            mailbox: Worker mailbox instance to allow communication to the modeller.
            hub: `BitfountHub` object to use for communication with the hub.
            context: Run-time protocol context details for running.
            **kwargs: Additional keyword arguments.
        """
        return _WorkerSide(
            algorithm=[
                algo.worker(hub=hub, context=context) for algo in self.algorithms
            ],
            mailbox=mailbox,
            trials_connection_string=self.trials_connection_string,
            trials_database_url=self.trials_database_url,
            **kwargs,
        )
