"""Protocols related to EHR interactions."""

from bitfount.federated.protocols.ehr.data_extraction_protocol_charcoal import (
    DataExtractionProtocolCharcoal,
)
from bitfount.federated.protocols.ehr.ehr_ner_protocol import EHRNERProtocol
from bitfount.federated.protocols.ehr.nextgen_search_protocol import (
    NextGenSearchProtocol,
)
from bitfount.federated.protocols.ehr.patient_trial_matching_protocol import (
    PatientTrialMatchingProtocol,
)

__all__: list[str] = [
    "DataExtractionProtocolCharcoal",
    "EHRNERProtocol",
    "NextGenSearchProtocol",
    "PatientTrialMatchingProtocol",
]

# See top level `__init__.py` for an explanation
__pdoc__ = {"data_extraction_protocol_charcoal": False}
for _obj in __all__:
    __pdoc__[_obj] = False
