"""MONAI transform utilities for Bitfount integration.

This module provides transforms for converting Bitfount datasource output
to MONAI MetaTensor format, enabling seamless integration between
Bitfount's data pipeline and MONAI's preprocessing transforms.

Also provides the Restored transform for spatial restoration of predictions
back to the original image space after inference.
"""

from __future__ import annotations

import logging
from typing import Any, Hashable, Mapping, Optional, Sequence, Union

from monai.config import KeysCollection
from monai.data import MetaTensor
from monai.transforms import MapTransform, Orientation, Resize
from monai.utils import InterpolateMode, ensure_tuple_rep
import nibabel as nib
import numpy as np
import numpy.typing as npt
import torch

from bitfount.data.datasources.nifti_source import (
    MONAI_AFFINE_KEY,
    MONAI_FILEPATH_KEY,
    MONAI_ORIGINAL_AFFINE_KEY,
    MONAI_ORIGINAL_CHANNEL_DIM_KEY,
    MONAI_PIXDIM_KEY,
    MONAI_SPATIAL_SHAPE_KEY,
)

logger = logging.getLogger(__name__)


class BitfountToMetaTensord(MapTransform):
    """Convert Bitfount NIFTISource output to MONAI MetaTensor format.

    This transform converts numpy arrays and metadata from Bitfount's NIFTISource
    into MONAI MetaTensors with complete metadata for downstream MONAI transforms
    such as Orientationd, Spacingd, and SaveImaged.

    Follows MONAI's LoadImaged pattern: for each key, creates a MetaTensor and
    optionally stores metadata in a separate ``{key}_meta_dict`` dictionary.

    The transform expects the following metadata keys from NIFTISource:
    - Affine: 4x4 numpy array (spatial transformation matrix)
    - OriginalAffine: 4x4 numpy array (preserved for inverse transforms)
    - Pixdim: numpy array of voxel spacings
    - SpatialShape: tuple of spatial dimensions
    - FilePath: full absolute path to the source file
    - OriginalChannelDim: channel dimension index (None for standard 3D images)

    Legacy fallback support is provided for older NIFTISource metadata:
    - AffineMatrix: flattened 4x4 list (if Affine not available)

    Args:
        keys: Keys of the data dictionary to convert to MetaTensor.
        meta_key_postfix: Postfix for metadata dictionary key. If set, stores
            metadata in ``{key}_{meta_key_postfix}``. Defaults to "meta_dict"
            to match MONAI's LoadImaged pattern.
        affine_key: Key for the 4x4 affine matrix. Defaults to "Affine".
        original_affine_key: Key for the original affine. Defaults to "OriginalAffine".
        pixdim_key: Key for voxel spacing array. Defaults to "Pixdim".
        spatial_shape_key: Key for spatial shape tuple. Defaults to "SpatialShape".
        filepath_key: Key for full file path. Defaults to "FilePath".
        channel_dim_key: Key for channel dimension. Defaults to "OriginalChannelDim".
        allow_missing_keys: Don't raise error if keys are missing.

    Example:
        >>> from bitfount.federated.algorithms.monai_algorithms.transforms import (
        ...     BitfountToMetaTensord
        ... )
        >>> # Assuming data is output from NIFTISource
        >>> transform = BitfountToMetaTensord(keys=["Pixel Data"])
        >>> output = transform(data)
        >>> # output["Pixel Data"] is now a MetaTensor with metadata
        >>> # output["Pixel Data_meta_dict"] contains the metadata dictionary
    """

    def __init__(
        self,
        keys: KeysCollection,
        meta_key_postfix: str = "meta_dict",
        affine_key: str = MONAI_AFFINE_KEY,
        original_affine_key: str = MONAI_ORIGINAL_AFFINE_KEY,
        pixdim_key: str = MONAI_PIXDIM_KEY,
        spatial_shape_key: str = MONAI_SPATIAL_SHAPE_KEY,
        filepath_key: str = MONAI_FILEPATH_KEY,
        channel_dim_key: str = MONAI_ORIGINAL_CHANNEL_DIM_KEY,
        allow_missing_keys: bool = False,
    ) -> None:
        super().__init__(keys, allow_missing_keys)
        self.meta_key_postfix = meta_key_postfix
        self.affine_key = affine_key
        self.original_affine_key = original_affine_key
        self.pixdim_key = pixdim_key
        self.spatial_shape_key = spatial_shape_key
        self.filepath_key = filepath_key
        self.channel_dim_key = channel_dim_key

    def _get_affine(
        self, data: Mapping[Hashable, Any]
    ) -> tuple[npt.NDArray[Any], npt.NDArray[Any]]:
        """Extract affine matrices from data, with legacy fallback.

        Args:
            data: Data dictionary from NIFTISource.

        Returns:
            Tuple of (affine, original_affine) as numpy arrays.
        """
        affine = data.get(self.affine_key)
        if affine is None:
            # Fallback for legacy AffineMatrix (flattened list)
            legacy_affine = data.get("AffineMatrix")
            if legacy_affine is not None:
                affine = np.array(legacy_affine, dtype=np.float64).reshape(4, 4)
            else:
                affine = np.eye(4, dtype=np.float64)
        else:
            affine = np.asarray(affine, dtype=np.float64)

        original_affine = data.get(self.original_affine_key)
        if original_affine is None:
            original_affine = affine.copy()
        else:
            original_affine = np.asarray(original_affine, dtype=np.float64)

        return affine, original_affine

    def _get_filename(self, data: Mapping[Hashable, Any]) -> str:
        """Extract filename (full path when available) from data.

        Args:
            data: Data dictionary from NIFTISource.

        Returns:
            Filename string (full path if available), or "unknown" if not available.
        """
        filepath = data.get(self.filepath_key)
        if filepath is not None:
            return str(filepath)

        return "unknown"

    def __call__(self, data: Mapping[Hashable, Any]) -> dict[Hashable, Any]:
        """Convert specified keys to MetaTensor format.

        Args:
            data: Data dictionary from NIFTISource containing image arrays
                and metadata.

        Returns:
            Dictionary with specified keys converted to MetaTensor objects
            containing complete metadata for MONAI transforms. Also includes
            ``{key}_{meta_key_postfix}`` entries with metadata dictionaries.
        """
        d = dict(data)

        for key in self.key_iterator(d):
            img_array = d[key]

            # Get affine matrices
            affine, original_affine = self._get_affine(d)
            affine_tensor = torch.tensor(affine, dtype=torch.float64)

            # Get pixdim (voxel spacing)
            pixdim = d.get(self.pixdim_key)
            if pixdim is None:
                # Fallback: try to extract from individual VoxelSize fields
                voxel_x = d.get("VoxelSizeX", 1.0)
                voxel_y = d.get("VoxelSizeY", 1.0)
                voxel_z = d.get("VoxelSizeZ", 1.0)
                pixdim = np.array([voxel_x, voxel_y, voxel_z], dtype=np.float32)
            else:
                pixdim = np.asarray(pixdim, dtype=np.float32)

            # Get spatial shape
            spatial_shape = d.get(self.spatial_shape_key)
            if spatial_shape is None:
                # Fallback: use first 3 dimensions of image array
                spatial_shape = img_array.shape[:3]

            # Determine original_channel_dim
            # MONAI uses float("nan") to indicate "no channel" for standard 3D images
            # See NibabelReader.get_data() in MONAI source
            original_channel_dim = d.get(self.channel_dim_key)
            if original_channel_dim is None:
                # If image shape matches spatial shape, there's no channel dimension
                # Otherwise, assume channel is last dimension (-1)
                if len(img_array.shape) == len(spatial_shape):
                    original_channel_dim = float("nan")  # No channel
                else:
                    original_channel_dim = -1  # Channel is last
                # Update the original dict key so collate doesn't fail on None
                if self.channel_dim_key in d:
                    d[self.channel_dim_key] = original_channel_dim

            # Build complete metadata dict matching MONAI LoadImaged output
            # Note: affine is passed separately to MetaTensor constructor,
            # so we don't include it in meta to avoid the warning about overwriting
            meta: dict[str, Any] = {
                "filename_or_obj": self._get_filename(d),
                "original_affine": torch.tensor(original_affine, dtype=torch.float64),
                "pixdim": pixdim,
                "spatial_shape": spatial_shape,
                "original_channel_dim": original_channel_dim,
            }

            # Create MetaTensor with metadata (matches LoadImaged with image_only=True)
            # affine is passed separately - MetaTensor stores it in meta["affine"]
            d[key] = MetaTensor(img_array, affine=affine_tensor, meta=meta)

            # Also store metadata dict separately (matches LoadImaged pattern)
            meta_key = f"{key}_{self.meta_key_postfix}"
            d[meta_key] = meta

        return d


class Restored(MapTransform):
    """Restore predictions to original image space.

    This transform restores prediction outputs (e.g., segmentation masks) back to
    the original image space by reversing spatial transformations applied during
    preprocessing. It handles:

    1. **Spacing restoration**: Resizes predictions back to original spatial shape
       if they were resampled during preprocessing (e.g., by Spacingd).
    2. **Orientation restoration**: Optionally inverts orientation changes to match
       the original image orientation (e.g., if Orientationd was applied).
    3. **Affine restoration**: Updates the prediction's metadata to use the original
       affine matrix for correct world-space alignment when saving.

    This is modeled after MONAILabel's Restored transform but adapted for
    Bitfount's inference pipeline.

    Args:
        keys: Keys of the prediction data to restore (e.g., ["pred"]).
        ref_image: Key of the reference image containing original metadata.
        has_channel: Whether predictions have a channel dimension. Defaults to True.
        invert_orient: Whether to invert orientation changes. Defaults to True
            for full spatial restoration.
        mode: Interpolation mode for resizing. Use "nearest" for segmentation
            masks to avoid interpolation artifacts. Defaults to InterpolateMode.NEAREST.
        align_corners: Align corners parameter for interpolation. Defaults to None.
        meta_key_postfix: Postfix for metadata dictionary key. Defaults to "meta_dict".

    Example:
        >>> from bitfount.federated.algorithms.monai_algorithms.transforms import (
        ...     Restored,
        ... )
        >>> # After inference, restore prediction to original space
        >>> restore = Restored(keys=["pred"], ref_image="image")
        >>> data = restore({"pred": prediction, "image": original_image})
        >>> # data["pred"] is now in original image space
        >>> # data["pred_meta_dict"]["affine"] contains the original affine

    Note:
        For segmentation outputs, always use mode="nearest" to prevent
        interpolation artifacts that could introduce invalid label values.
    """

    def __init__(
        self,
        keys: KeysCollection,
        ref_image: str,
        has_channel: bool = True,
        invert_orient: bool = True,
        mode: Union[str, InterpolateMode] = InterpolateMode.NEAREST,
        align_corners: Union[Sequence[Optional[bool]], Optional[bool]] = None,
        meta_key_postfix: str = "meta_dict",
    ) -> None:
        super().__init__(keys)
        self.ref_image = ref_image
        self.has_channel = has_channel
        self.invert_orient = invert_orient
        self.mode = ensure_tuple_rep(mode, len(self.keys))
        self.align_corners = ensure_tuple_rep(align_corners, len(self.keys))
        self.meta_key_postfix = meta_key_postfix

    def _get_meta_dict(self, data: dict[str, Any]) -> dict[str, Any]:
        """Extract metadata dictionary from reference image.

        Args:
            data: Data dictionary containing reference image.

        Returns:
            Metadata dictionary with spatial information.
        """
        ref_data = data.get(self.ref_image)

        # Try to get metadata from MetaTensor
        if ref_data is not None and isinstance(ref_data, MetaTensor):
            return dict(ref_data.meta)

        # Fallback to separate meta_dict key
        meta_key = f"{self.ref_image}_{self.meta_key_postfix}"
        meta_dict = data.get(meta_key, {})

        return dict(meta_dict) if meta_dict else {}

    def __call__(self, data: dict[str, Any]) -> dict[str, Any]:
        """Restore predictions to original image space.

        Args:
            data: Data dictionary containing predictions and reference image.

        Returns:
            Dictionary with predictions restored to original spatial dimensions
            and orientation, with updated metadata.
        """
        d: dict[str, Any] = data.copy()
        meta_dict = self._get_meta_dict(d)

        for idx, hashable_key in enumerate(self.keys):
            key = str(hashable_key)
            if key not in d:
                logger.warning(f"Key '{key}' not found in data, skipping restoration")
                continue

            result = d[key]

            # Ensure result is a tensor for processing
            if isinstance(result, np.ndarray):
                result = torch.from_numpy(result)

            # Determine current and target spatial sizes
            current_size = result.shape[1:] if self.has_channel else result.shape
            spatial_shape = meta_dict.get("spatial_shape", current_size)

            # Handle spatial_shape that might be a tensor
            if isinstance(spatial_shape, torch.Tensor):
                spatial_shape = spatial_shape.numpy()
            if isinstance(spatial_shape, np.ndarray):
                spatial_shape = tuple(spatial_shape.astype(int).tolist())
            # Fallback if spatial_shape is None (key existed with None value)
            if spatial_shape is None:
                spatial_shape = current_size

            # Get the last N dimensions to match current_size dimensionality
            spatial_size = spatial_shape[-len(current_size) :]

            # Step 1: Undo Spacing - resize back to original spatial shape
            if not np.array_equal(current_size, spatial_size):
                logger.debug(
                    f"Restoring spatial shape: {current_size} -> {spatial_size}"
                )
                resizer = Resize(spatial_size=spatial_size, mode=self.mode[idx])
                result = resizer(result, align_corners=self.align_corners[idx])

            # Step 2: Undo Orientation (if requested and original_affine available)
            if self.invert_orient:
                original_affine = meta_dict.get("original_affine")
                if original_affine is not None:
                    # Convert to numpy if tensor
                    if isinstance(original_affine, torch.Tensor):
                        original_affine = original_affine.numpy()

                    try:
                        # Get original orientation from affine
                        # aff2axcodes returns tuple, Orientation expects string
                        orig_axcodes = "".join(
                            nib.orientations.aff2axcodes(original_affine)
                        )
                        inverse_orient = Orientation(axcodes=orig_axcodes)

                        # Apply inverse orientation
                        # trace_transform(False) prevents recording this transform
                        with inverse_orient.trace_transform(False):
                            result = inverse_orient(result)
                        logger.debug(f"Restored orientation to: {orig_axcodes}")
                    except Exception as e:
                        logger.warning(f"Failed to invert orientation: {e}")
                else:
                    logger.debug(
                        "Skipping orientation inversion - original_affine not available"
                    )

            # Handle output dimensions - squeeze if needed
            if len(result.shape) > 3:
                if result.shape[0] == 1:
                    # Single channel, can squeeze
                    result = result[0]
                # Otherwise keep multi-channel output

            d[key] = result

            # Update metadata with original affine for correct file saving
            pred_meta_key = f"{key}_{self.meta_key_postfix}"
            pred_meta = d.get(pred_meta_key)
            if pred_meta is None:
                pred_meta = {}
                d[pred_meta_key] = pred_meta

            # Store original affine so NIfTI writer uses correct world coordinates
            original_affine = meta_dict.get("original_affine")
            if original_affine is not None:
                pred_meta["affine"] = original_affine
                pred_meta["original_affine"] = original_affine
            else:
                # Fallback to current affine if original not available
                affine = meta_dict.get("affine")
                if affine is not None:
                    pred_meta["affine"] = affine

            # Copy spatial shape for reference
            pred_meta["spatial_shape"] = spatial_shape

        return d


__all__ = [
    "BitfountToMetaTensord",
    "Restored",
    # Re-export MONAI metadata key constants for convenience
    "MONAI_AFFINE_KEY",
    "MONAI_ORIGINAL_AFFINE_KEY",
    "MONAI_PIXDIM_KEY",
    "MONAI_SPATIAL_SHAPE_KEY",
    "MONAI_FILEPATH_KEY",
    "MONAI_ORIGINAL_CHANNEL_DIM_KEY",
]
