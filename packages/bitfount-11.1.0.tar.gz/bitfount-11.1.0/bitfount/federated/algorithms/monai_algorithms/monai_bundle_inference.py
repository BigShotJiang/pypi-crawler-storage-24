"""MONAI Bundle Inference Algorithm.

This module provides an algorithm for running inference using pre-trained
MONAI bundles from the MONAI Model Zoo on medical imaging data. The algorithm
is datasource-agnostic and works with any file-based medical imaging format
supported by a FileSystemIterableSourceInferrable datasource (e.g., NIFTISource,
DICOMSource).

Supports both segmentation bundles (e.g., wholeBrainSeg_Large_UNEST_segmentation)
and detection bundles (e.g., lung_nodule_ct_detection) which output bounding boxes
with classification scores.
"""

from __future__ import annotations

import gc
import json
import os
from pathlib import Path
import sys
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    ClassVar,
    Literal,
    Optional,
    Union,
    cast,
)

from marshmallow import fields
import nibabel as nib
import numpy as np
import pandas as pd

from bitfount.backends.pytorch.utils import autodetect_gpu
from bitfount.config import _PYTORCH_ENGINE, BITFOUNT_ENGINE, settings
from bitfount.data.datasources.base_source import (
    BaseSource,
    FileSystemIterableSourceInferrable,
)
from bitfount.data.datasources.utils import ORIGINAL_FILENAME_METADATA_COLUMN
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
)
from bitfount.federated.algorithms.monai_algorithms.base import _MONAIModellerSide
from bitfount.federated.algorithms.monai_algorithms.transforms import (
    BitfountToMetaTensord,
    Restored,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.privacy.differential import DPPodConfig
from bitfount.federated.types import ProtocolContext, get_task_results_directory
from bitfount.types import T_FIELDS_DICT
from bitfount.utils import delegates

if TYPE_CHECKING:
    from monai.inferers import Inferer
    from monai.transforms import Compose
    from torch import nn

if BITFOUNT_ENGINE == _PYTORCH_ENGINE:
    from monai.bundle import ConfigParser, download
    from monai.data import DataLoader as MONAIDataLoader, Dataset as MONAIDataset
    from monai.data.utils import no_collation, pad_list_data_collate
    from monai.transforms import Compose, LoadImaged
    import torch

logger = _get_federated_logger(__name__)

# Default bundle download directory (uses Bitfount's controlled cache directory)
DEFAULT_BUNDLE_DIR = settings.paths.cache_dir / "monai_bundles"


class _MONAIWorkerSide(BaseWorkerAlgorithm):
    """Worker side of the MONAIBundleInference algorithm.

    This class handles downloading MONAI bundles, loading models,
    and running inference on medical imaging data using efficient
    batched DataLoader-based processing. Supports any file-based
    datasource that extends FileSystemIterableSourceInferrable
    (e.g., NIFTISource, DICOMSource).

    Args:
        bundle_name: Name of the MONAI bundle to use.
        bundle_version: Specific version of the bundle (optional).
        image_column_name: Name of the column containing image data.
        dataframe_output: Whether to return results in DataFrame format.
        nifti_output: Whether to save segmentation masks as NIfTI files.
        json_output: Whether to save detection results as JSON files.
        output_dir: Directory to save output NIfTI files. Set internally by
            the factory to the task results directory; not user-configurable.
        batch_size: Batch size for inference. Defaults to 1. Higher values
            improve GPU utilization but require more memory.
        num_workers: Number of worker processes for data loading. Defaults to 1
            (single-process loading for maximum compatibility). Set to 2-4 on
            Linux/macOS for improved throughput with large datasets.
        inference_config_overrides: Dictionary of config overrides for inference.
        restore_spatial: Whether to restore predictions to original image space.
            When True, predictions are resized and re-oriented to match the
            original input image dimensions and affine. Defaults to True.
        invert_orientation: Whether to invert orientation changes during
            restoration. Only used when restore_spatial=True. Defaults to True.
        **kwargs: Additional keyword arguments.

    Raises:
        RuntimeError: If the Bitfount engine is not set to PyTorch.
        ValueError: If bundle_name is empty, batch_size < 1, or num_workers < 1.
    """

    def __init__(
        self,
        bundle_name: str,
        image_column_name: str,
        bundle_version: Optional[str] = None,
        dataframe_output: bool = True,
        nifti_output: bool = False,
        json_output: bool = False,
        output_dir: Optional[Union[os.PathLike[str], str]] = None,
        batch_size: int = 1,
        num_workers: int = 1,
        inference_config_overrides: Optional[dict[str, Any]] = None,
        restore_spatial: bool = True,
        invert_orientation: bool = True,
        **kwargs: Any,
    ) -> None:
        if BITFOUNT_ENGINE != _PYTORCH_ENGINE:
            raise RuntimeError(
                "MONAIBundleInference requires the PyTorch engine. "
                f"Current engine is '{BITFOUNT_ENGINE}'. "
                "Please set BITFOUNT_ENGINE='pytorch' or ensure PyTorch is installed."
            )

        # Validate parameters
        if not bundle_name or not bundle_name.strip():
            raise ValueError("bundle_name must be a non-empty string")
        if batch_size < 1:
            raise ValueError(f"batch_size must be at least 1, got {batch_size}")
        if num_workers < 1:
            raise ValueError(f"num_workers must be at least 1, got {num_workers}")

        super().__init__(**kwargs)
        self.bundle_name = bundle_name
        self.bundle_version = bundle_version
        self.image_column_name = image_column_name
        self.dataframe_output = dataframe_output
        self.nifti_output = nifti_output
        self.json_output = json_output
        self.output_dir: Optional[Path] = Path(output_dir) if output_dir else None
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.inference_config_overrides = inference_config_overrides or {}
        self.restore_spatial = restore_spatial
        self.invert_orientation = invert_orientation

        # Auto-detect device
        gpu_config = autodetect_gpu()
        accelerator = gpu_config.get("accelerator", "cpu")
        if accelerator == "gpu":
            self._device_str = "cuda"
        elif accelerator == "mps":
            self._device_str = "mps"
        else:
            self._device_str = "cpu"

        # Will be populated during initialise()
        self.bundle_dir: Optional[Path] = None
        self.network: Optional[nn.Module] = None
        self.preprocessing: Optional[Compose] = None
        self.postprocessing: Optional[Callable[[dict[str, Any]], dict[str, Any]]] = None
        self.inferer: Optional[Inferer] = None

        # Spatial restoration transform - created during initialise()
        self._restore_transform: Optional[Restored] = None

        # Bundle type, determined during config parsing
        self.bundle_type: Literal["segmentation", "detection"]
        self.detector: Optional[Any] = None
        self.anchor_generator: Optional[Any] = None

    def _download_bundle(self) -> Path:
        """Download the MONAI bundle from Model Zoo.

        Returns:
            Path to the downloaded bundle directory.
        """
        version_str = f" (version {self.bundle_version})" if self.bundle_version else ""
        logger.info(f"Downloading MONAI bundle: {self.bundle_name}{version_str}")

        # Create bundle root directory structure
        # Include version in path when specified to enable version-specific caching
        # Structure: <cache_dir>/monai_bundles/<version>/<bundle_name>/ (versioned)
        #            <cache_dir>/monai_bundles/<bundle_name>/ (latest/unversioned)
        if self.bundle_version:
            bundle_root = DEFAULT_BUNDLE_DIR / self.bundle_version
        else:
            bundle_root = DEFAULT_BUNDLE_DIR
        bundle_root.mkdir(parents=True, exist_ok=True)

        # Expected bundle directory path (MONAI downloads to bundle_root/bundle_name/)
        expected_bundle_dir = bundle_root / self.bundle_name

        # Check if bundle already exists at version-specific path
        if expected_bundle_dir.exists():
            logger.info(f"Bundle already exists at: {expected_bundle_dir}")
            return expected_bundle_dir

        # Download bundle
        try:
            bundle_dir = download(
                name=self.bundle_name,
                version=self.bundle_version if self.bundle_version else None,
                bundle_dir=str(bundle_root),
            )
        except Exception as e:
            logger.error(f"Error downloading bundle: {e}")
            raise RuntimeError(
                f"Failed to download MONAI bundle '{self.bundle_name}': {e}"
            ) from e

        # The download function may return None but still download successfully
        # Check if the expected directory now exists
        if bundle_dir is not None:
            logger.info(f"Bundle downloaded to: {bundle_dir}")
            return Path(bundle_dir)
        elif expected_bundle_dir.exists():
            logger.info(f"Bundle downloaded to: {expected_bundle_dir}")
            return expected_bundle_dir
        else:
            raise RuntimeError(
                f"Failed to download MONAI bundle: {self.bundle_name}. "
                f"Expected directory not found: {expected_bundle_dir}"
            )

    def _load_bundle_components(self) -> None:
        """Load the network, preprocessing, postprocessing, and inferer from bundle.

        This method temporarily adds the bundle directory to sys.path to allow
        importing custom network modules defined in the bundle. After loading,
        it cleans up sys.path and removes any bundle-specific modules from
        sys.modules to prevent conflicts when loading different bundles with
        identically-named modules (e.g., both having scripts/network.py).
        """
        # Download bundle if not already downloaded
        if self.bundle_dir is None:
            self.bundle_dir = self._download_bundle()

        bundle_dir_str = str(self.bundle_dir)

        # Track modules before loading to identify bundle-specific imports
        modules_before = set(sys.modules.keys())

        # Add bundle directory to Python path for custom scripts/networks
        # Many MONAI bundles include custom network definitions in scripts/
        path_added = bundle_dir_str not in sys.path
        try:
            if path_added:
                sys.path.insert(0, bundle_dir_str)
                logger.info(f"Added bundle directory to Python path: {bundle_dir_str}")

            self._parse_and_load_bundle_config()
        finally:
            # Clean up sys.path - remove the bundle directory we added
            if path_added and bundle_dir_str in sys.path:
                sys.path.remove(bundle_dir_str)
                logger.debug(
                    f"Removed bundle directory from Python path: {bundle_dir_str}"
                )

            # Clean up sys.modules - remove any modules that were imported from
            # this bundle directory to prevent caching issues when loading
            # different bundles with identically-named modules
            self._cleanup_bundle_modules(modules_before, self.bundle_dir)

    def _cleanup_bundle_modules(
        self, modules_before: set[str], bundle_dir: Path
    ) -> None:
        """Remove bundle-specific modules from sys.modules.

        This prevents module caching issues when loading different bundles
        that may have identically-named custom modules (e.g., scripts/network.py).

        Args:
            modules_before: Set of module names present before bundle loading.
            bundle_dir: The bundle directory path.

        Note:
            In PyInstaller-bundled executables, module __file__ attributes may
            point to temporary extraction directories. We use Path.is_relative_to()
            for robust path comparison that handles normalization and edge cases.
        """
        resolved_bundle_dir = bundle_dir.resolve()
        modules_to_remove = []
        for module_name, module in sys.modules.items():
            # Skip modules that existed before loading
            if module_name in modules_before:
                continue

            # Check if this module was loaded from the bundle directory
            module_file = getattr(module, "__file__", None)
            if module_file is None:
                continue

            try:
                module_path = Path(module_file).resolve()
                if module_path.is_relative_to(resolved_bundle_dir):
                    modules_to_remove.append(module_name)
                    logger.debug(f"Marking bundle module for cleanup: {module_name}")
            except (ValueError, OSError):
                # Path resolution or comparison failed - skip this module
                # This can happen with unusual __file__ values in frozen apps
                continue

        # Remove the modules
        for module_name in modules_to_remove:
            del sys.modules[module_name]

        if modules_to_remove:
            logger.info(
                f"Cleaned up {len(modules_to_remove)} bundle-specific module(s) "
                "from sys.modules to prevent caching conflicts"
            )

    def _parse_and_load_bundle_config(self) -> None:
        """Parse bundle config and load network components.

        This is the core loading logic, separated from path management
        for cleaner code organization. Auto-detects bundle type based on
        whether the config contains a "detector" key.
        """
        if self.bundle_dir is None:
            raise ValueError("Bundle directory not set.")

        # Find inference config file (json or yaml)
        inference_config = None
        for ext in [".json", ".yaml", ".yml"]:
            config_path = self.bundle_dir / "configs" / f"inference{ext}"
            if config_path.exists():
                inference_config = config_path
                break

        if inference_config is None:
            raise FileNotFoundError(
                f"No inference config found in {self.bundle_dir / 'configs'}"
            )

        logger.info(f"Loading inference config from: {inference_config}")

        # Parse the config
        parser = ConfigParser()
        parser.read_config(str(inference_config))

        # Apply any config overrides
        parser.update(self.inference_config_overrides)

        # Set bundle root for relative paths in config
        parser["bundle_root"] = str(self.bundle_dir)

        # Override device
        parser["device"] = torch.device(self._device_str)

        # Detect bundle type based on config keys
        if "detector" in parser:
            self.bundle_type = "detection"
            logger.info("Detected detection bundle type")
            self._load_detection_components(parser)
        elif "network" in parser:
            self.bundle_type = "segmentation"
            logger.info("Detected segmentation bundle type")
            self._load_segmentation_components(parser)
        else:
            raise ValueError(
                "Unable to determine bundle type from inference config. "
                "Expected 'detector' (detection) or 'network' (segmentation) "
                "key in the bundle's inference.json."
            )

    def _load_preprocessing(self, parser: ConfigParser) -> None:
        """Load preprocessing transforms from bundle config.

        Args:
            parser: The parsed bundle ConfigParser.

        Raises:
            ValueError: If preprocessing is not defined in the bundle config.
        """
        try:
            self.preprocessing = parser.get_parsed_content("preprocessing")
            logger.info("Preprocessing transforms loaded from bundle config")
        except KeyError as e:
            raise ValueError(
                "Bundle config does not define 'preprocessing'. "
                "The inference.json config must specify preprocessing transforms."
            ) from e

    def _load_inferer(self, parser: ConfigParser) -> None:
        """Load inferer from bundle config (optional).

        Args:
            parser: The parsed bundle ConfigParser.
        """
        try:
            self.inferer = parser.get_parsed_content("inferer")
            logger.info("Inferer loaded from bundle config")
        except KeyError:
            logger.info("No inferer defined in bundle config")
            self.inferer = None

    def _load_postprocessing(self, parser: ConfigParser) -> None:
        """Load postprocessing transforms from bundle config (optional).

        Args:
            parser: The parsed bundle ConfigParser.
        """
        try:
            self.postprocessing = parser.get_parsed_content("postprocessing")
            logger.info("Postprocessing transforms loaded from bundle config")
        except KeyError:
            logger.info("No postprocessing defined in bundle config")
            self.postprocessing = None

    def _load_segmentation_components(self, parser: ConfigParser) -> None:
        """Load segmentation-specific components from bundle config.

        Args:
            parser: The parsed bundle ConfigParser.
        """
        try:
            self.network = parser.get_parsed_content("network")
            self.network.eval()
            logger.info("Network loaded and set to eval mode")
        except KeyError as e:
            raise ValueError("Bundle config does not define 'network'") from e

        self._load_preprocessing(parser)
        self._load_inferer(parser)
        self._load_postprocessing(parser)
        self._load_pretrained_weights(parser)

    def _load_detection_components(self, parser: ConfigParser) -> None:
        """Load detection-specific components from bundle config.

        For detection bundles like lung_nodule_ct_detection, this loads:
        - anchor_generator: Generates anchor boxes for detection
        - network: The backbone network (e.g., RetinaNet)
        - detector: RetinaNetDetector that wraps the network
        - detector_ops: Config ops (set_target_keys, set_box_selector_params)
        - preprocessing, postprocessing: Shared transform pipelines

        Args:
            parser: The parsed bundle ConfigParser.
        """
        try:
            self.anchor_generator = parser.get_parsed_content("anchor_generator")
            logger.info("Anchor generator loaded")
        except KeyError as e:
            raise ValueError(
                "Detection bundle config does not define 'anchor_generator'"
            ) from e

        try:
            self.network = parser.get_parsed_content("network")
            self.network.eval()
            logger.info("Network loaded and set to eval mode")
        except KeyError as e:
            raise ValueError("Bundle config does not define 'network'") from e

        try:
            self.detector = parser.get_parsed_content("detector")
            self.detector.eval()
            logger.info("Detector loaded and set to eval mode")
        except KeyError as e:
            raise ValueError(
                "Detection bundle config does not define 'detector'"
            ) from e

        # Execute detector_ops to configure the detector
        # These are typically set_target_keys, set_box_selector_params, etc.
        # Operations are executed during parsing via $@ syntax in the config
        _ = parser.get_parsed_content("detector_ops", default=[])
        logger.info("Detector ops executed")

        self._load_preprocessing(parser)
        self._load_inferer(parser)
        self._load_postprocessing(parser)
        self._load_pretrained_weights(parser)

    def _load_pretrained_weights(self, parser: ConfigParser) -> None:
        """Load pretrained weights from bundle config if specified.

        Args:
            parser: The parsed bundle ConfigParser.
        """
        try:
            load_pretrain = parser.get_parsed_content("load_pretrain", default=True)
            if load_pretrain:
                checkpoint_loader = parser.get_parsed_content("checkpointloader")
                # The checkpoint loader is typically a callable that loads weights
                if callable(checkpoint_loader):
                    checkpoint_loader(None)  # Some loaders don't need an engine
                    logger.info("Pretrained weights loaded")
        except KeyError:
            # checkpointloader not defined in bundle config - skip weight loading
            logger.debug("No checkpointloader defined in bundle config, skipping")
        except (OSError, RuntimeError, ValueError) as e:
            # OSError: checkpoint file not found or inaccessible
            # RuntimeError: PyTorch model loading errors (e.g., state dict mismatch)
            # ValueError: config parsing or checkpoint format errors
            logger.warning(f"Could not load pretrained weights: {e}")

    def _strip_loadimaged_from_preprocessing(self, preprocessing: Compose) -> Compose:
        """Remove LoadImaged from preprocessing pipeline.

        When using Bitfount's dataloader, image data is already loaded by the
        datasource (e.g., NIFTISource). This method strips LoadImaged from the
        bundle's preprocessing so images aren't re-loaded from file paths.

        Args:
            preprocessing: The bundle's preprocessing Compose pipeline.

        Returns:
            A new Compose pipeline with LoadImaged removed.
        """
        new_transforms = []
        removed_count = 0

        for transform in preprocessing.transforms:
            if isinstance(transform, LoadImaged):
                removed_count += 1
                logger.debug(f"Stripping LoadImaged transform: {transform}")
            else:
                new_transforms.append(transform)

        if removed_count > 0:
            logger.info(
                f"Stripped {removed_count} LoadImaged transform(s) from preprocessing "
                "for Bitfount dataloader mode"
            )
        else:
            logger.warning(
                "No LoadImaged transform found in preprocessing. "
                "The bundle may not be compatible with Bitfount dataloader mode."
            )

        return Compose(new_transforms)

    def _get_monai_dataloader(self) -> MONAIDataLoader:
        """Create a MONAI DataLoader by directly iterating the Bitfount datasource.

        This method bypasses Bitfount's HuggingFace data pipeline and directly
        iterates through the datasource to get image data and metadata. It then
        applies BitfountToMetaTensord to create proper MetaTensors, followed by
        the bundle's preprocessing (minus LoadImaged).

        This approach:
        1. Directly iterates through the datasource's _process_file method
        2. Converts data to MONAI MetaTensor format via BitfountToMetaTensord
        3. Applies the bundle's spatial transforms (Orientation, Spacing, etc.)

        Returns:
            A MONAI DataLoader configured for batched inference.

        Raises:
            ValueError: If datasource or preprocessing is not initialized.
            TypeError: If datasource is not a FileSystemIterableSourceInferrable.
        """
        if self.datasource is None:
            raise ValueError("Datasource not initialised.")
        if self.preprocessing is None:
            raise ValueError("Preprocessing not initialised.")
        if not isinstance(self.datasource, FileSystemIterableSourceInferrable):
            raise TypeError(
                f"Expected FileSystemIterableSourceInferrable datasource, "
                f"got {type(self.datasource).__name__}"
            )

        # Load all data using public yield_data API
        # yield_data returns DataFrames, convert to list of dicts for MONAI
        data_list: list[dict[str, Any]] = []
        # Avoid cached placeholders
        for df_chunk in self.datasource.yield_data(use_cache=False):
            records = cast(list[dict[str, Any]], df_chunk.to_dict(orient="records"))
            data_list.extend(records)

        if not data_list:
            logger.warning("No data loaded from datasource")
            return MONAIDataLoader(MONAIDataset([]), batch_size=1)

        logger.info(f"Loaded {len(data_list)} samples from datasource")

        # Build transform pipeline:
        # 1. BitfountToMetaTensord - converts datasource dict to MetaTensor
        # 2. Bundle preprocessing (minus LoadImaged) - spatial transforms
        image_col = self.image_column_name
        stripped_preprocessing = self._strip_loadimaged_from_preprocessing(
            self.preprocessing
        )

        # Rename image column to "image" for MONAI compatibility
        # MONAI expects the image key to be "image"
        # The subsequent stripped_preprocessing would fail,
        # because it's looking for the "image" key, not "Pixel Data"
        renamed_data_list = []
        for sample in data_list:
            renamed_sample = {"image": sample.get(image_col)}
            # Copy all metadata fields needed for MetaTensor creation
            for key, value in sample.items():
                if key != image_col:
                    renamed_sample[key] = value
            renamed_data_list.append(renamed_sample)

        # Create MONAI Dataset with transforms
        # BitfountToMetaTensord converts the image array + metadata to MetaTensor
        # Then stripped_preprocessing applies spatial transforms (Orientation, etc.)
        dataset: MONAIDataset = MONAIDataset(
            data=renamed_data_list,
            transform=Compose(
                [
                    BitfountToMetaTensord(keys=["image"]),
                    stripped_preprocessing,
                ]
            ),
        )

        # Create DataLoader
        pin_memory = self._device_str.startswith("cuda")

        # Map user-facing num_workers (1-based) to PyTorch DataLoader (0-based):
        # User's 1 → 0 (single-process), User's 2 → 1, etc.
        # Note: Currently kept at 0 because batch data is already loaded in memory.
        # Using workers > 0 would spawn processes that serialize in-memory numpy
        # arrays, which is inefficient and can cause pickling issues.
        actual_num_workers = max(0, self.num_workers - 1)

        # Detection outputs have variable-length results per image (different
        # number of bounding boxes), so standard collation cannot stack them.
        # Use no_collation and batch_size=1 to process one volume at a time.
        if self.bundle_type == "detection":
            collate_fn = no_collation
            effective_batch_size = 1
        else:
            collate_fn = pad_list_data_collate
            effective_batch_size = self.batch_size

        dataloader: MONAIDataLoader = MONAIDataLoader(
            dataset,
            batch_size=effective_batch_size,
            num_workers=actual_num_workers,
            pin_memory=pin_memory,
            collate_fn=collate_fn,
            shuffle=False,
        )

        logger.info(
            f"Created Bitfount dataloader (batch_size={effective_batch_size}, "
            f"samples={len(dataset)}, bundle_type={self.bundle_type})"
        )

        return dataloader

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialise the algorithm by downloading the bundle and loading the model.

        Args:
            datasource: The data source to use.
            task_id: The ID of the task.
            data_splitter: Optional data splitter.
            pod_dp: Pod-level differential privacy config (not supported).
            pod_identifier: Identifier for the pod.
            **kwargs: Additional keyword arguments.
        """
        if pod_dp:
            logger.warning("Differential privacy is not supported for MONAI inference.")

        if not isinstance(datasource, FileSystemIterableSourceInferrable):
            raise TypeError(
                "MONAIBundleInference requires a file-based datasource "
                "(FileSystemIterableSourceInferrable), "
                f"got {type(datasource).__name__}. "
                "Supported datasources include NIFTISource, DICOMSource, etc."
            )

        self.initialise_data(datasource=datasource, data_splitter=data_splitter)

        # Download and load bundle
        self.bundle_dir = self._download_bundle()
        self._load_bundle_components()

        # Set up spatial restoration transform if enabled
        if self.restore_spatial:
            self._restore_transform = Restored(
                keys=["pred"],
                ref_image="image",
                has_channel=True,
                invert_orient=self.invert_orientation,
            )
            logger.info(
                "Spatial restoration enabled "
                f"(invert_orientation={self.invert_orientation})"
            )

        # Set up output directory if saving NIfTI or JSON files
        if self.nifti_output or self.json_output:
            if self.output_dir is None:
                self.output_dir = self.bundle_dir / "output"
            self.output_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Output directory set to: {self.output_dir}")

    # pyrefly: ignore[bad-override]
    def run(
        self, return_data_keys: bool = False, final_batch: bool = False
    ) -> pd.DataFrame:
        """Run batched inference on all images using MONAI DataLoader.

        Automatically dispatches to the appropriate inference method based
        on the detected bundle type (segmentation or detection).

        Args:
            return_data_keys: Unused. Present for interface compatibility.
            final_batch: Unused. Present for interface compatibility.

        Returns:
            DataFrame containing inference results.
        """
        if self.datasource is None:
            raise ValueError("Datasource not initialised. Call initialise() first.")

        if self.network is None:
            raise RuntimeError("Network not initialized. Call initialise() first.")

        if self.bundle_type == "detection":
            return self._run_detection()

        # Create MONAI DataLoader using Bitfount's datasource
        # This loads data via NIFTISource and converts to MetaTensor format
        dataloader = self._get_monai_dataloader()
        if len(dataloader) == 0:
            logger.warning("No data in dataloader")
            return pd.DataFrame()

        results: list[dict[str, Any]] = []
        num_processed = 0
        batch_idx = 0

        # Process batches
        with torch.no_grad():
            for batch in dataloader:
                try:
                    batch_idx += 1
                    batch_size_actual = batch["image"].shape[0]
                    logger.info(
                        f"Processing batch {batch_idx}/{len(dataloader)} "
                        f"({batch_size_actual} images)"
                    )

                    # Move batch to device
                    inputs = batch["image"].to(self._device_str)

                    # Run inference
                    if self.inferer is not None:
                        outputs = self.inferer(inputs, self.network)
                    else:
                        outputs = self.network(inputs)

                    # Move outputs to CPU for post-processing
                    outputs = outputs.cpu()

                    # Process each item in the batch
                    for i in range(batch_size_actual):
                        # Extract single output from batch
                        output = outputs[i : i + 1]  # Keep batch dim for consistency

                        # Get filename from metadata
                        # MONAI stores original filename in image_meta_dict
                        meta_dict = batch.get("image_meta_dict", {})
                        filename_or_obj = meta_dict.get("filename_or_obj", [])
                        if isinstance(filename_or_obj, (list, tuple)) and i < len(
                            filename_or_obj
                        ):
                            filename = str(filename_or_obj[i])
                        else:
                            filename = f"image_{num_processed}"

                        # Prepare data dict for post-processing and restoration
                        # Include both prediction and reference image with metadata
                        data_dict: dict[str, Any] = {
                            "pred": output,
                            "image": batch["image"][i : i + 1],
                        }

                        # Copy image metadata for restoration transform
                        # The Restored transform needs original_affine and spatial_shape
                        if meta_dict:
                            image_meta: dict[str, Any] = {}
                            # Extract per-item metadata (batched metadata is lists)
                            for key, value in meta_dict.items():
                                if isinstance(value, (list, tuple)) and i < len(value):
                                    image_meta[key] = value[i]
                                elif isinstance(value, torch.Tensor):
                                    if value.dim() > 0 and value.shape[0] > i:
                                        image_meta[key] = value[i]
                                    else:
                                        image_meta[key] = value
                                else:
                                    image_meta[key] = value
                            data_dict["image_meta_dict"] = image_meta

                        # Apply post-processing if available
                        if self.postprocessing is not None:
                            try:
                                result = self.postprocessing(data_dict)
                                output = result.get("pred", output)
                                data_dict["pred"] = output
                            except Exception as e:
                                logger.warning(
                                    f"Postprocessing failed for {filename}: {e}"
                                )

                        # Apply spatial restoration to return prediction to original
                        # This undoes Spacingd, Orientationd, etc. from preprocessing
                        restored_affine: Optional[np.ndarray[Any, Any]] = None
                        if self._restore_transform is not None:
                            try:
                                restored_data = self._restore_transform(data_dict)
                                output = restored_data.get("pred", output)

                                # Get restored affine for NIfTI saving
                                pred_meta = restored_data.get("pred_meta_dict", {})
                                affine = pred_meta.get("affine")
                                if affine is not None:
                                    if isinstance(affine, torch.Tensor):
                                        restored_affine = affine.numpy()
                                    else:
                                        restored_affine = np.asarray(affine)
                            except Exception as e:
                                logger.warning(
                                    f"Spatial restoration failed for {filename}: {e}"
                                )

                        # Convert to numpy
                        if torch.is_tensor(output):
                            output_np = output.numpy()
                        else:
                            output_np = np.array(output)

                        # Build result record
                        result_record: dict[str, Any] = {
                            ORIGINAL_FILENAME_METADATA_COLUMN: filename,
                            "shape": str(output_np.shape),
                        }

                        # Save as NIfTI file if requested
                        if self.nifti_output:
                            output_path = self._save_nifti_output(
                                output_np, filename, affine=restored_affine
                            )
                            result_record["output_path"] = output_path

                        # Include prediction array if dataframe_output is enabled
                        if self.dataframe_output:
                            result_record["prediction"] = output_np

                        results.append(result_record)
                        num_processed += 1

                except Exception as e:
                    logger.error(f"Error processing batch {batch_idx}: {e}")
                    # Record error for batch - we don't know which specific images
                    # failed, so record the batch number
                    results.append(
                        {
                            ORIGINAL_FILENAME_METADATA_COLUMN: f"batch_{batch_idx}",
                            "error": str(e),
                        }
                    )
                    # Clean up GPU memory after failed batch to recover resources
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()

                # Free GPU memory between batches (less aggressive than per-image)
                if batch_idx % 10 == 0 and torch.cuda.is_available():
                    torch.cuda.empty_cache()

        logger.info(f"Processed {num_processed} images successfully")

        # Final cleanup
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return pd.DataFrame.from_records(results)

    def _save_nifti_output(
        self,
        prediction: np.ndarray[Any, Any],
        original_filename: str,
        affine: Optional[np.ndarray[Any, Any]] = None,
    ) -> Path:
        """Save prediction as NIfTI file.

        NIfTI is used as the output format regardless of input format because
        it's a widely supported format for 3D medical imaging data and
        preserves the full volumetric structure of segmentation masks.

        When spatial restoration is enabled, the prediction is saved with the
        original affine matrix, allowing it to be correctly overlaid on the
        original image in world coordinates.

        Args:
            prediction: The prediction array to save.
            original_filename: Original filename for naming the output.
            affine: Optional 4x4 affine transformation matrix for world-space
                alignment. If provided (typically from spatial restoration),
                the saved NIfTI will have correct world coordinates matching
                the original input image. If None, an identity affine is used.

        Returns:
            Path to the saved file.
        """
        # Create output filename
        base_name = Path(original_filename).stem
        if base_name.endswith(".nii"):
            base_name = Path(base_name).stem  # Handle .nii.gz
        output_filename = f"{base_name}_pred.nii.gz"

        if self.output_dir is None:
            raise ValueError("output_dir must be set when saving NIfTI output")
        output_path = self.output_dir / output_filename
        if output_path.exists():
            logger.warning(
                "NIfTI output path already exists for %s. "
                "Adding a numeric suffix to avoid overwriting.",
                output_path,
            )
            base_stem = output_filename[: -len(".nii.gz")]
            i = 1
            while output_path.exists():
                output_filename = f"{base_stem} ({i}).nii.gz"
                output_path = self.output_dir / output_filename
                i += 1

        # Remove batch and channel dimensions if present for saving
        if prediction.ndim == 5:
            # Shape: (batch, channels, D, H, W)
            prediction = prediction[0]  # Remove batch dimension -> (channels, D, H, W)
            if prediction.shape[0] > 1:
                # Multi-channel output (e.g., per-class probabilities)
                # Apply argmax to convert to single segmentation mask
                num_channels = prediction.shape[0]
                logger.warning(
                    f"Multi-channel prediction detected with {num_channels} channels. "
                    "Applying argmax to convert to single-channel segmentation mask. "
                    "If raw probabilities are needed, use dataframe_output=True."
                )
                prediction = np.argmax(prediction, axis=0)
            else:
                # Single channel, just squeeze
                prediction = prediction[0]
        elif prediction.ndim == 4:
            # Could be (batch, D, H, W) or (channels, D, H, W)
            # Assume first dimension is batch or single channel
            if prediction.shape[0] > 1:
                # Likely multi-channel, apply argmax
                num_channels = prediction.shape[0]
                logger.warning(
                    f"Multi-channel prediction detected with {num_channels} channels. "
                    "Applying argmax to convert to single-channel segmentation mask."
                )
                prediction = np.argmax(prediction, axis=0)
            else:
                prediction = prediction[0]

        # Use provided affine or fall back to identity
        # When spatial restoration is enabled, the affine will be the original
        # image's affine matrix, allowing correct world-space alignment.
        # Without restoration, identity affine is used (legacy behavior).
        if affine is None:
            logger.debug(
                "No affine provided, using identity matrix. "
                "Enable restore_spatial=True for world-space alignment."
            )
            affine = np.eye(4)
        else:
            logger.debug("Using restored affine for world-space alignment")

        nifti_img = nib.Nifti1Image(prediction.astype(np.float32), affine)

        # Save
        nib.save(nifti_img, output_path)
        logger.info(f"Saved prediction to: {output_path}")

        return output_path

    def _run_detection(self) -> pd.DataFrame:
        """Run detection inference returning bounding boxes.

        Detection bundles (e.g., lung_nodule_ct_detection) output:
        - boxes: Nx6 bounding boxes in format specified by bundle
        - labels: Nx1 classification labels
        - label_scores: Nx1 classification scores

        The detector expects a list of tensors, not a batched tensor.

        Returns:
            DataFrame with detection results per image.
        """
        dataloader = self._get_monai_dataloader()
        if len(dataloader) == 0:
            logger.warning("No data in dataloader")
            return pd.DataFrame()

        results: list[dict[str, Any]] = []
        num_processed = 0
        batch_idx = 0

        with torch.no_grad():
            for batch in dataloader:
                try:
                    batch_idx += 1

                    # Detection bundles use no_collation, so batch is a list of dicts
                    # Each item is a single sample dict with "image" key
                    if isinstance(batch, list):
                        # no_collation returns list of sample dicts
                        sample_list = batch
                    else:
                        # Fallback: if collated, wrap in list
                        sample_list = [batch]

                    logger.info(
                        f"Processing batch {batch_idx}/{len(dataloader)} "
                        f"({len(sample_list)} images)"
                    )

                    # Prepare inputs as list of tensors for detector
                    inputs = []
                    for sample in sample_list:
                        img = sample["image"]
                        if not isinstance(img, torch.Tensor):
                            img = torch.as_tensor(img)
                        inputs.append(img.to(self._device_str))

                    # Run detection inference
                    # The detector (e.g. RetinaNetDetector) has its own
                    # internal inferer set during config parsing. We call
                    # detector directly with use_inferer=True.
                    if self.detector is not None:
                        outputs = self.detector(inputs, use_inferer=True)
                    else:
                        raise RuntimeError(
                            "Detector not available for detection inference"
                        )

                    # Process detection outputs
                    for i, detection in enumerate(outputs):
                        sample = sample_list[i]

                        # Get filename from metadata
                        meta_dict = sample.get("image_meta_dict", {})
                        filename = meta_dict.get(
                            "filename_or_obj", f"image_{num_processed}"
                        )
                        if isinstance(filename, (list, tuple)):
                            filename = str(filename[0])
                        else:
                            filename = str(filename)

                        # Apply postprocessing if available
                        if self.postprocessing is not None:
                            try:
                                post_input = {
                                    **detection,
                                    "image": sample.get("image", inputs[i]),
                                }
                                detection = self.postprocessing(post_input)
                            except Exception as e:
                                logger.warning(
                                    f"Postprocessing failed for {filename}: {e}"
                                )

                        # Extract detection results
                        boxes = detection.get("box", torch.tensor([]))
                        labels = detection.get("label", torch.tensor([]))
                        scores = detection.get("label_scores", torch.tensor([]))

                        # Convert to lists
                        boxes_list = boxes.cpu().numpy().tolist()
                        labels_list = labels.cpu().numpy().tolist()
                        scores_list = scores.cpu().numpy().tolist()

                        result_record: dict[str, Any] = {
                            ORIGINAL_FILENAME_METADATA_COLUMN: filename,
                            "num_detections": len(boxes_list),
                            "boxes": boxes_list,
                            "labels": labels_list,
                            "scores": scores_list,
                        }

                        # Save as JSON if requested
                        if self.json_output:
                            output_path = self._save_json_output(
                                {
                                    "box": boxes,
                                    "label": labels,
                                    "label_scores": scores,
                                },
                                filename,
                            )
                            result_record["output_path"] = output_path

                        results.append(result_record)
                        num_processed += 1

                except Exception as e:
                    logger.error(f"Error processing batch {batch_idx}: {e}")
                    results.append(
                        {
                            ORIGINAL_FILENAME_METADATA_COLUMN: f"batch_{batch_idx}",
                            "error": str(e),
                        }
                    )
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()

                if batch_idx % 10 == 0 and torch.cuda.is_available():
                    torch.cuda.empty_cache()

        logger.info(f"Processed {num_processed} images successfully")

        # Final cleanup
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return pd.DataFrame.from_records(results)

    def _save_json_output(
        self, detections: dict[str, Any], original_filename: str
    ) -> Path:
        """Save detection results as JSON file.

        Args:
            detections: Dict with 'box', 'label', 'label_scores' tensors.
            original_filename: Original filename for naming the output.

        Returns:
            Path to the saved JSON file.
        """
        base_name = Path(original_filename).stem
        if base_name.endswith(".nii"):
            base_name = Path(base_name).stem  # Handle .nii.gz
        output_filename = f"{base_name}_detections.json"

        if self.output_dir is None:
            raise ValueError("output_dir must be set when saving JSON output")

        output_path = self.output_dir / output_filename

        # Avoid overwriting
        if output_path.exists():
            base_stem = base_name + "_detections"
            i = 1
            while output_path.exists():
                output_filename = f"{base_stem} ({i}).json"
                output_path = self.output_dir / output_filename
                i += 1

        # Convert tensors to lists for JSON serialization
        json_data: dict[str, Any] = {}
        for key, value in detections.items():
            if isinstance(value, torch.Tensor):
                json_data[key] = value.cpu().numpy().tolist()
            else:
                json_data[key] = value

        with open(output_path, "w") as f:
            json.dump(json_data, f, indent=2)

        logger.info(f"Saved detection results to: {output_path}")
        return output_path


@delegates()
class MONAIBundleInference(
    BaseNonModelAlgorithmFactory[_MONAIModellerSide, _MONAIWorkerSide]
):
    """MONAI Bundle Inference Algorithm.

    This algorithm runs inference using pre-trained MONAI bundles from the
    MONAI Model Zoo on medical imaging data. It uses MONAI's DataLoader for
    efficient batched inference with GPU parallelism and data prefetching.

    The algorithm is datasource-agnostic and works with any file-based medical
    imaging datasource that extends FileSystemIterableSourceInferrable, including:
    - NIFTISource: For NIfTI neuroimaging data (.nii, .nii.gz)
    - DICOMSource: For DICOM medical images (.dcm)

    Args:
        datastructure: The data structure defining the data to use.
        bundle_name: Name of the MONAI bundle from Model Zoo
            (e.g., "wholeBrainSeg_Large_UNEST_segmentation").
        bundle_version: Specific version of the bundle (default: latest).
        dataframe_output: Whether to include prediction arrays in the output
            DataFrame for CSV generation. Defaults to True.
        nifti_output: Whether to save segmentation masks as NIfTI files.
            Defaults to False. When enabled, files are saved to the task
            results directory (same location as CSVReportAlgorithm output).
        json_output: Whether to save detection results as JSON files.
            Defaults to False. Only applicable to detection bundles.
        batch_size: Batch size for inference. Defaults to 1. Higher values
            improve GPU utilization but require more memory. Medical images
            are often large, so start with small batch sizes (1-4).
        num_workers: Number of worker processes for data loading. Defaults to 0
            (single-process loading for maximum compatibility). Set to 2-4 on
            Linux/macOS for improved throughput with large datasets.
        inference_config_overrides: Dictionary of config values to override
            in the bundle's inference config.
        restore_spatial: Whether to restore predictions to original image space.
            When True (default), predictions are resized and re-oriented to match
            the original input image dimensions and affine matrix. This ensures
            output NIfTI files can be correctly overlaid on original images.
            Disable only if you need predictions in the preprocessed canonical
            space (e.g., 1mm isotropic, RAS orientation).
        invert_orientation: Whether to invert orientation changes during
            restoration. Only used when restore_spatial=True. Defaults to True.
            Disable if the bundle's preprocessing doesn't change orientation.

    Attributes:
        bundle_name: Name of the MONAI bundle.
        bundle_version: Version of the bundle.
        dataframe_output: Whether to include predictions in DataFrame.
        nifti_output: Whether to save NIfTI files.
        json_output: Whether to save detection JSON files.
        batch_size: Batch size for DataLoader.
        num_workers: Number of DataLoader workers.
        inference_config_overrides: Config overrides.
        restore_spatial: Whether spatial restoration is enabled.
        invert_orientation: Whether orientation inversion is enabled.

    Raises:
        RuntimeError: If the Bitfount engine is not set to PyTorch.
        ValueError: If bundle_name is empty, batch_size < 1, or num_workers < 1.
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "bundle_name": fields.String(required=True),
        "bundle_version": fields.String(required=False, allow_none=True),
        "dataframe_output": fields.Bool(required=False, missing=True),
        "nifti_output": fields.Bool(required=False, missing=False),
        "json_output": fields.Bool(required=False, missing=False),
        "batch_size": fields.Int(required=False, missing=1),
        "num_workers": fields.Int(required=False, missing=1),
        "inference_config_overrides": fields.Dict(
            keys=fields.String(), required=False, allow_none=True
        ),
        "restore_spatial": fields.Bool(required=False, missing=True),
        "invert_orientation": fields.Bool(required=False, missing=True),
    }

    def __init__(
        self,
        datastructure: DataStructure,
        bundle_name: str,
        bundle_version: Optional[str] = None,
        dataframe_output: bool = True,
        nifti_output: bool = False,
        json_output: bool = False,
        batch_size: int = 1,
        num_workers: int = 1,
        inference_config_overrides: Optional[dict[str, Any]] = None,
        restore_spatial: bool = True,
        invert_orientation: bool = True,
        **kwargs: Any,
    ) -> None:
        if BITFOUNT_ENGINE != _PYTORCH_ENGINE:
            raise RuntimeError(
                "MONAIBundleInference requires the PyTorch engine. "
                f"Current engine is '{BITFOUNT_ENGINE}'. "
                "Please set BITFOUNT_ENGINE='pytorch' or ensure PyTorch is installed."
            )

        # Validate parameters
        if not bundle_name or not bundle_name.strip():
            raise ValueError("bundle_name must be a non-empty string")
        if batch_size < 1:
            raise ValueError(f"batch_size must be at least 1, got {batch_size}")
        if num_workers < 1:
            raise ValueError(f"num_workers must be at least 1, got {num_workers}")

        super().__init__(datastructure=datastructure, **kwargs)
        self.bundle_name = bundle_name
        self.bundle_version = bundle_version
        self.dataframe_output = dataframe_output
        self.nifti_output = nifti_output
        self.json_output = json_output
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.inference_config_overrides = inference_config_overrides
        self.restore_spatial = restore_spatial
        self.invert_orientation = invert_orientation

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _MONAIModellerSide:
        """Returns the modeller side of the MONAIBundleInference algorithm.

        Args:
            context: The protocol context.
            **kwargs: Additional keyword arguments.

        Returns:
            The modeller side instance.
        """
        return _MONAIModellerSide(bundle_name=self.bundle_name, **kwargs)

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _MONAIWorkerSide:
        """Returns the worker side of the MONAIBundleInference algorithm.

        Args:
            context: The protocol context.
            **kwargs: Additional keyword arguments.

        Returns:
            The worker side instance.
        """
        # "Pixel Data" is the canonical column name used by medical imaging
        # datasources (NIFTISource, DICOMSource, etc.). The task template
        # hardcodes this column, and schema-datastructure validation ensures
        # it exists when linking the dataset.
        image_column_name = "Pixel Data"

        # NIfTI/JSON outputs go to the task results directory
        output_dir = (
            get_task_results_directory(context)
            if self.nifti_output or self.json_output
            else None
        )

        return _MONAIWorkerSide(
            bundle_name=self.bundle_name,
            bundle_version=self.bundle_version,
            image_column_name=image_column_name,
            dataframe_output=self.dataframe_output,
            nifti_output=self.nifti_output,
            json_output=self.json_output,
            output_dir=output_dir,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            inference_config_overrides=self.inference_config_overrides,
            restore_spatial=self.restore_spatial,
            invert_orientation=self.invert_orientation,
            **kwargs,
        )
