"""Algorithms for MONAI medical imaging models.

This package provides algorithms for running inference using pre-trained
MONAI bundles from the MONAI Model Zoo on medical imaging data.
"""

from __future__ import annotations

from bitfount.federated.algorithms.monai_algorithms.monai_bundle_inference import (
    MONAIBundleInference,
)
from bitfount.federated.algorithms.monai_algorithms.transforms import (
    BitfountToMetaTensord,
)

__all__ = [
    "MONAIBundleInference",
    "BitfountToMetaTensord",
]

# Hide monai algorithms subpackage from pdoc-generated documentation
# to prevent duplicate documentation entries in pdoc-generated docs.
# The actual documentation for MONAIBundleInference would be generated
# from its original module (monai_bundle_inference.py),
# not from the init.py that re-exports it
__pdoc__ = {}
# See top level `__init__.py` for an explanation
for _obj in __all__:
    __pdoc__[_obj] = False
