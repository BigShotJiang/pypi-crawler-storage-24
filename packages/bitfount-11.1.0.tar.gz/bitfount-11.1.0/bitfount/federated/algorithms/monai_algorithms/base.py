"""Base classes for MONAI algorithms."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Optional

import pandas as pd

from bitfount.federated.algorithms.base import BaseModellerAlgorithm
from bitfount.federated.logging import _get_federated_logger

logger = _get_federated_logger(__name__)


class _MONAIModellerSide(BaseModellerAlgorithm):
    """Modeller side for MONAI algorithms.

    This class handles receiving and returning results from workers
    that run MONAI bundle inference.

    Args:
        bundle_name: The name of the MONAI bundle being used.
    """

    def __init__(self, bundle_name: Optional[str] = None) -> None:
        super().__init__()
        self.bundle_name = bundle_name

    def initialise(self, *, task_id: str, **kwargs: Any) -> None:
        """Nothing to initialise here."""
        pass

    # pyrefly: ignore[bad-override]
    def run(self, results: Mapping[str, Any], log: bool = False) -> dict[str, Any]:
        """Simply returns results and optionally logs them.

        Args:
            results: The results from the workers.
            log: Whether to log the results.

        Returns:
            The results as a dictionary.
        """
        if log and self.bundle_name:
            for pod_name, response in results.items():
                logger.info(
                    f"MONAI inference completed for pod {pod_name} "
                    f"using bundle {self.bundle_name}"
                )
                num_results: Optional[int] = None
                if isinstance(response, pd.DataFrame):
                    num_results = len(response)
                elif isinstance(response, dict):
                    num_results = response.get("num_images_processed")
                    if not isinstance(num_results, int):
                        num_results = None

                if num_results is not None:
                    logger.info(f"  Processed {num_results} images")

        return dict(results)
