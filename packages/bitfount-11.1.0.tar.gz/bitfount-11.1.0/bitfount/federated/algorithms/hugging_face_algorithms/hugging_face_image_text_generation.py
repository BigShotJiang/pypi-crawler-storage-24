"""Hugging Face Image-Text Generation Algorithm."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
import gc
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Optional, Union, cast

from marshmallow import fields
import pandas as pd

from bitfount.config import _PYTORCH_ENGINE, BITFOUNT_ENGINE
from bitfount.data.datasources.utils import ORIGINAL_FILENAME_METADATA_COLUMN
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.data.huggingface.dataloaders import (
    HuggingFaceBitfountDataLoader,
    HuggingFaceIterableBitfountDataLoader,
)
from bitfount.federated.algorithms.hugging_face_algorithms.utils import (
    _build_hf_auth_kwargs,
    get_device_for_model,
)
from bitfount.federated.types import ProtocolContext

if BITFOUNT_ENGINE == _PYTORCH_ENGINE:
    import torch
    from transformers import pipeline, set_seed

    _TORCH_DTYPES: dict[str, torch.dtype] = {
        "bfloat16": torch.bfloat16,
        "float16": torch.float16,
        "float32": torch.float32,
        "float64": torch.float64,
    }

from bitfount.data.huggingface.utils import get_data_factory_dataset
from bitfount.data.types import DataSplit, SingleOrMulti, _SemanticTypeValue
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
    FinalStepAlgorithm,
)
from bitfount.federated.algorithms.hugging_face_algorithms.base import _HFModellerSide
from bitfount.federated.logging import _get_federated_logger
from bitfount.hooks import HookType, get_hooks
from bitfount.utils import DEFAULT_SEED, delegates

if TYPE_CHECKING:
    from bitfount.data.datasources.base_source import BaseSource
    from bitfount.federated.privacy.differential import DPPodConfig
    from bitfount.types import T_FIELDS_DICT

logger = _get_federated_logger(__name__)

# Default values for generation parameters
DEFAULT_MAX_NEW_TOKENS = 2000


class _WorkerSide(BaseWorkerAlgorithm, FinalStepAlgorithm):
    """Worker side of the HuggingFaceImageTextGenerationInference algorithm."""

    def __init__(
        self,
        model_id: str,
        image_path_column_name: str,
        context_column_name: str,
        max_new_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        seed: int = DEFAULT_SEED,
        torch_dtype: Literal["bfloat16", "float16", "float32", "float64"] = "bfloat16",
        batch_size: int = 1,
        prompt_template: Optional[str] = None,
        access_token: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.model_id = model_id
        self.batch_size = batch_size
        self.max_new_tokens = max_new_tokens
        self.seed = seed
        self.image_path_column_name = image_path_column_name
        self.context_column_name = context_column_name
        self.torch_dtype = torch_dtype
        self.prompt_template = prompt_template
        self.access_token = access_token
        self.device = get_device_for_model()
        self.test_dataloader: Union[
            HuggingFaceBitfountDataLoader, HuggingFaceIterableBitfountDataLoader
        ]
        self.pipe: Optional[Any] = None

        # Image paths are inputed as text to the pipeline.
        # TODO: [BIT-3512] Consider adding PIL image handling to the dataloader
        self.selected_cols_semantic_types: Mapping[_SemanticTypeValue, list[str]] = {
            "text": [self.image_path_column_name, self.context_column_name],
        }

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialises the model and pipeline."""
        if pod_dp:
            logger.warning("The use of DP is not supported, ignoring set `pod_dp`.")

        self.initialise_data(datasource=datasource)

        # Get selected columns for dataloader
        selected_cols = [self.image_path_column_name, self.context_column_name]

        data_factory, dataset = get_data_factory_dataset(
            datasource=datasource,
            data_splitter=data_splitter,
            data_split=DataSplit.TEST,
            selected_cols=selected_cols,
            selected_cols_semantic_types=self.selected_cols_semantic_types,
            batch_transforms=[],
        )

        self.test_dataloader: Union[
            HuggingFaceBitfountDataLoader, HuggingFaceIterableBitfountDataLoader
        ] = data_factory.create_dataloader(
            dataset, batch_size=self.batch_size, **kwargs
        )

        set_seed(self.seed)

        auth_kwargs = _build_hf_auth_kwargs(self.access_token)
        if auth_kwargs:
            logger.info(
                "Using Hugging Face access token from config for model authentication."
            )
        else:
            logger.warning(
                "Hugging Face access token not set. "
                "Some models may require authentication."
            )

        for hook in get_hooks(HookType.POD):
            hook.on_model_download_start(
                task_id=task_id,
                model_id=self.model_id,
                source="Hugging Face",
            )
        self.pipe = pipeline(
            "image-text-to-text",
            model=self.model_id,
            torch_dtype=_TORCH_DTYPES[self.torch_dtype],
            device=self.device,
            **auth_kwargs,
        )
        for hook in get_hooks(HookType.POD):
            hook.on_model_download_end(
                task_id=task_id,
                model_id=self.model_id,
                source="Hugging Face",
            )

    # pyrefly: ignore[bad-override]
    def run(
        self, return_data_keys: bool = False, final_batch: bool = False
    ) -> pd.DataFrame:
        """Runs inference on the given image-text-to-text HuggingFace model.

        Args:
            return_data_keys: Whether to return data keys (filenames).
            final_batch: Whether this is the final batch of the algo run. Deprecated.
        """
        dataframe_records = []

        gc.collect()

        for _batch_idx, batch in enumerate(
            cast(Iterable[list[Any]], self.test_dataloader)
        ):
            # Expected shapes:
            # - text_values can be [image_path, context] for a single row or a batch
            text_values = batch[0]

            # Extract images and contexts from text values (CSV has no targets)
            if isinstance(text_values, (list, tuple)) and len(text_values) == 2:
                images, contexts = text_values
            else:
                raise ValueError(
                    "Expected CSV text values to contain [image_path, context]."
                )

            # Handle single item vs batch
            images_list = (
                list(images) if isinstance(images, (list, tuple)) else [images]
            )
            contexts_list = (
                list(contexts) if isinstance(contexts, (list, tuple)) else [contexts]
            )

            # Get data keys if available
            keys: Optional[list[str]] = None
            if self.test_dataloader.expect_key_in_iter():
                keys_: SingleOrMulti[str] = cast(SingleOrMulti[str], batch[-1])
                if isinstance(keys_, str):
                    keys = [keys_]
                else:
                    keys = list(keys_)

            # Process each image-context pair
            if len(images_list) != len(contexts_list):
                raise ValueError("The number of images and contexts must be the same.")

            for idx, (image, context) in enumerate(zip(images_list, contexts_list)):
                # Apply prompt template if provided, otherwise use context as-is
                if self.prompt_template:
                    prompt_text = self.prompt_template.format_map(
                        {"context": str(context)}
                    )
                else:
                    prompt_text = str(context)

                # Construct message format expected by the pipeline
                messages = [
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "image": str(image)},
                            {"type": "text", "text": prompt_text},
                        ],
                    }
                ]

                # Run inference (typing stubs don't cover message format)
                pipe = cast(Any, self.pipe)
                output = pipe(text=messages, max_new_tokens=self.max_new_tokens)

                # Extract the generated text from the response
                generated_text = output[0]["generated_text"][-1]["content"]

                record: dict[str, Any] = {"generated_text": generated_text}

                # Add data key if available
                if keys and return_data_keys:
                    record[ORIGINAL_FILENAME_METADATA_COLUMN] = keys[idx]

                # pyrefly: ignore[bad-argument-type]
                dataframe_records.append(record)

            # Clean up GPU memory
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        df = pd.DataFrame.from_records(dataframe_records)
        return df

    def run_final_step(self, *, context: ProtocolContext, **kwargs: Any) -> Any:
        """Final model cleanup step."""
        if hasattr(self, "pipe"):
            del self.pipe
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


@delegates()
class HuggingFaceImageTextGenerationInference(
    BaseNonModelAlgorithmFactory[_HFModellerSide, _WorkerSide]
):
    """Inference for pre-trained Hugging Face image-text-to-text generation models.

    This algorithm processes images with text context using vision-language models
    like MedGemma. It takes an image and a context (e.g., clinical notes) as input
    and generates text responses based on the visual content and the context.

    The datastructure should include two columns: an image column and a context column.
    If a prompt_template is provided, the context is inserted into the template to
    create the final prompt. Otherwise, the context is used as-is.

    Args:
        datastructure: The datastructure to use for the algorithm.
        model_id: The model id to use for image-text generation inference.
            The model id is of a pretrained model hosted inside a model
            repo on huggingface.co. Accepts models compatible with the
            "image-text-to-text" pipeline task (e.g., google/medgemma-1.5-4b-it).
        max_new_tokens: The maximum number of new tokens to generate.
            Defaults to 2000.
        batch_size: The batch size for inference. Defaults to 1.
        seed: Sets the seed of the algorithm. For reproducible behavior
            it defaults to 42.
        torch_dtype: The torch dtype to use for the model. Defaults to "bfloat16".
        prompt_template: Optional template string for formatting the context column
            value into a prompt. Use `{context}` as a placeholder for where the
            context will be inserted. For example:
            `"Describe this image given the notes: {context}"`.
            Defaults to None (context column value used as the prompt directly).

    Attributes:
        model_id: The model id to use for image-text generation inference.
        max_new_tokens: The maximum number of new tokens to generate.
        batch_size: The batch size for inference.
        seed: Sets the seed of the algorithm.
        torch_dtype: The torch dtype to use for the model.
        prompt_template: Optional template string to format the context into a prompt.

    Note:
        For gated models (like MedGemma), set the HF_TOKEN environment variable
        with your HuggingFace access token.

    Raises:
        ValueError: If `prompt_template` is provided without a `{context}` placeholder.

    """

    def __init__(
        self,
        datastructure: DataStructure,
        model_id: str,
        max_new_tokens: int = DEFAULT_MAX_NEW_TOKENS,
        seed: int = DEFAULT_SEED,
        batch_size: int = 1,
        torch_dtype: Literal["bfloat16", "float16", "float32", "float64"] = "bfloat16",
        prompt_template: Optional[str] = None,
        access_token: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(datastructure=datastructure, **kwargs)
        self.model_id = model_id
        self.access_token = access_token
        self.max_new_tokens = max_new_tokens
        self.batch_size = batch_size
        self.seed = seed
        self.torch_dtype = torch_dtype
        self.prompt_template = prompt_template

        if self.prompt_template and "{context}" not in self.prompt_template:
            raise ValueError(
                "`prompt_template` must contain a `{context}` placeholder."
            )

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "model_id": fields.Str(required=True),
        "max_new_tokens": fields.Int(required=False, missing=DEFAULT_MAX_NEW_TOKENS),
        "batch_size": fields.Int(required=False, missing=1),
        "seed": fields.Int(required=False, missing=DEFAULT_SEED),
        "torch_dtype": fields.Str(required=False, missing="bfloat16"),
        "prompt_template": fields.Str(required=False, missing=None, allow_none=True),
        "access_token": fields.Str(required=False, allow_none=True),
    }

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _HFModellerSide:
        """Returns the modeller side of the algorithm."""
        return _HFModellerSide(task_name="generated_text", **kwargs)

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Returns the worker side of the algorithm."""
        # Get the selected columns from datastructure
        # First column should be image, second should be context
        selected_cols = self.datastructure.selected_cols
        if len(selected_cols) < 2:
            raise ValueError(
                "HuggingFaceImageTextGenerationInference requires at least "
                "two columns in the datastructure: image column and context column."
            )

        image_path_column_name = selected_cols[0]
        context_column_name = selected_cols[1]

        return _WorkerSide(
            model_id=self.model_id,
            image_path_column_name=image_path_column_name,
            context_column_name=context_column_name,
            max_new_tokens=self.max_new_tokens,
            batch_size=self.batch_size,
            seed=self.seed,
            torch_dtype=self.torch_dtype,
            prompt_template=self.prompt_template,
            access_token=self.access_token,
            **kwargs,
        )
