"""HuggingFace TIMM Federated Training Algorithm.

Borrowed with permission from https://github.com/huggingface/pytorch-image-models.
Copyright 2020 Ross Wightman (https://github.com/rwightman)
"""

from __future__ import annotations

from contextlib import suppress
import copy
from functools import partial
import gc
import logging
import os
from pathlib import Path
from typing import Any, ClassVar, Literal, Mapping, Optional, Union

import desert
from marshmallow import fields
import numpy as np

from bitfount.config import _PYTORCH_ENGINE, BITFOUNT_ENGINE
from bitfount.data.datasources.base_source import BaseSource
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DEFAULT_IMAGE_TRANSFORMATIONS, DataStructure
from bitfount.federated.algorithms.base import (
    BaseModellerAlgorithm,
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
)
from bitfount.federated.algorithms.hugging_face_algorithms.utils import (
    TIMMTrainingConfig,
    create_loss_functions,
    create_train_eval_dataloaders,
    train_one_epoch,
    validate,
)
from bitfount.federated.algorithms.model_algorithms.base import (
    _registry as _model_alg_registry,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.privacy.differential import DPPodConfig
from bitfount.federated.types import ProtocolContext, get_task_results_directory
from bitfount.runners.utils import setup_loggers
from bitfount.types import T_FIELDS_DICT, _JSONDict, _SerializedWeights, _Weights
from bitfount.utils import delegates

if BITFOUNT_ENGINE == _PYTORCH_ENGINE:
    from peft import LoraConfig, get_peft_model
    from timm import utils as timm_utils
    from timm.data import Mixup
    from timm.models import create_model, load_checkpoint, safe_model_name
    from timm.optim import create_optimizer_v2, optimizer_kwargs
    from timm.scheduler import create_scheduler_v2, scheduler_kwargs
    from timm.utils import ApexScaler, NativeScaler
    import torch

    from bitfount.backends.pytorch.types import _AdaptorForPyTorchTensor

    try:
        # pyrefly: ignore[missing-import]
        from apex import amp

        has_apex = True
    except ImportError:
        has_apex = False

    try:
        if torch.cuda.amp.autocast is not None:
            has_native_amp = True
    except AttributeError:
        has_native_amp = False

logger = _get_federated_logger(__name__)

# Enable logging for timm checkpoint saver
timm_logger = logging.getLogger("timm.utils.checkpoint_saver")
setup_loggers([timm_logger])

# Sentinel value used in place of the string literal "auto" for type narrowing.
_LORA_RANK_AUTO = "auto"

# Recommended LoRA ranks by model size.  Small models (<20 M params) fall back to
# full fine-tuning (None) because:
#   • CNNs (ResNet18, 11 M): nearly all parameters are in Conv2d layers;
#     target_modules="all-linear" only reaches the final fc head (~2 K params),
#     making LoRA adaptation negligible.
#   • Small ViTs (ViT-Ti, 5 M): full fine-tuning is cheap and fast; LoRA overhead
#     is not worth it at this scale.
# Transformer-based models benefit significantly once parameter counts pass ~20 M:
#   • Communication cost: full DINOv2 ViT-B/14 (86 M params) → ~344 MB/round/pod;
#     LoRA r=8 reduces this to ~3 MB — a ~100× improvement on WAN links between fabs.
#   • Overfitting: per-fab datasets are typically small (hundreds of wafer maps);
#     adapting only ~1–2 M parameters avoids overfitting the backbone.
#   • Averaging quality: FedAvg over adapter weights captures the shared
#     cross-fab signal while leaving the ImageNet backbone unchanged.
_LORA_AUTO_RANK_TABLE: list[tuple[int, Optional[int]]] = [
    (20_000_000, None),  # < 20 M params (e.g. ResNet18 11 M, ViT-Ti 5 M) → full FT
    (100_000_000, 8),  # 20–100 M (e.g. ViT-S/16 22 M, DINOv2 ViT-B/14 86 M) → r=8
    (400_000_000, 16),  # 100–400 M (e.g. DINOv2 ViT-L/14 307 M) → r=16
    # 400 M+ (e.g. DINOv2 ViT-H/14 632 M, large LLMs) → r=32
    # No upper bound: this entry is the unconditional fallback for very large models.
]
_LORA_AUTO_RANK_FALLBACK: int = 32


def _resolve_lora_rank(
    lora_rank: Optional[Union[int, Literal["auto"]]],
    model: Any,
) -> Optional[int]:
    """Resolve `lora_rank` to a concrete integer or `None` (full fine-tuning).

    Args:
        lora_rank: `None` (full fine-tuning), a positive integer, or the string
            `"auto"` to select the rank automatically from the model's total
            parameter count.
        model: The TIMM model whose parameter count determines the auto rank.

    Returns:
        A positive integer rank or `None` when full fine-tuning is requested.
    """
    if lora_rank is None:
        return None
    if lora_rank != _LORA_RANK_AUTO:
        rank = int(lora_rank)
        if rank <= 0:
            raise ValueError(
                f"lora_rank must be a positive integer, got {lora_rank!r}. "
                "Use lora_rank=None for full fine-tuning or lora_rank='auto' "
                "for automatic rank selection."
            )
        return rank
    # "auto" — pick from the table above, then fall back for very large models
    n_params = sum(p.numel() for p in model.parameters())
    for threshold, rank in _LORA_AUTO_RANK_TABLE:
        if n_params < threshold:
            if rank is None:
                logger.info(
                    f"lora_rank='auto': model has {n_params:,} parameters ->"
                    f"full fine-tuning (too small to benefit from LoRA)"
                )
            else:
                logger.info(
                    f"lora_rank='auto': model has {n_params:,} parameters ->rank={rank}"
                )
            return rank
    # Model exceeds all table thresholds (400 M+ params): use the maximum rank.
    logger.info(
        f"lora_rank='auto': model has {n_params:,} parameters ->"
        f"rank={_LORA_AUTO_RANK_FALLBACK} (very large model fallback)"
    )
    return _LORA_AUTO_RANK_FALLBACK


def _apply_lora(model: Any, rank: int) -> Any:
    """Wrap *model* with PEFT LoRA adapters and return the wrapped model.

    Targets all `nn.Linear` layers (`target_modules="all-linear"`), which
    covers attention QKV / projection / MLP layers in ViT-based models and the
    final classifier in CNN-based models.  The backbone weights are frozen by
    PEFT; only the adapter matrices are trainable.

    Args:
        model: A TIMM model instance.
        rank: LoRA rank `r`.  Higher rank → more expressive adapters but
            larger weight exchange per federated round.

    Returns:
        A PEFT-wrapped model with LoRA adapters applied.
    """
    config = LoraConfig(
        r=rank,
        lora_alpha=rank * 2,  # alpha = 2r is a common default (effective LR scale = 1)
        target_modules="all-linear",  # covers qkv/proj/mlp in ViTs; fc in ResNets
        lora_dropout=0.05,
        bias="none",
    )
    wrapped = get_peft_model(model, config)
    trainable, total = wrapped.get_nb_trainable_parameters()
    pct = 100 * trainable / total
    mb_per_round = trainable * 4 / 1e6
    logger.info(
        f"LoRA r={rank}: {trainable:,} trainable / {total:,} total params "
        f"({pct:.2f}% — exchange ~{mb_per_round:.1f} MB/round)"
    )
    return wrapped


def _lora_state_dict(model: Any) -> dict[str, Any]:
    """Return only the LoRA adapter entries from `model.state_dict()`.

    Filters by `requires_grad` rather than key-name substring matching so the
    result is correct even if a natural layer name happens to contain `"lora_"`,
    or if PEFT introduces non-adapter keys with that substring in future.
    With `bias="none"` (our `LoraConfig`), only the adapter matrices (`lora_A`
    / `lora_B`) are trainable, so the filter is exact.  Keys are preserved as-is
    from `state_dict()` so they remain compatible with the load logic that matches
    against `model.state_dict()` keys.
    """
    trainable_keys = {
        name for name, param in model.named_parameters() if param.requires_grad
    }
    return {k: v for k, v in model.state_dict().items() if k in trainable_keys}


class _FedModellerSide(BaseModellerAlgorithm):
    """Modeller side of the TIMMFederatedTraining algorithm.

    Maintains the global DINOv2 model on the modeller (OEM) machine. On each
    federated round it receives the aggregated weight update from all fabs, applies
    it to the global model, and returns the serialized parameters to broadcast back.

    Args:
        model_id: The TIMM / HuggingFace model identifier.
        args: Training configuration dataclass.
        labels: Class label names for the classification head.
        pretrained_file: Optional path to a local checkpoint to load instead of
            downloading from HuggingFace Hub. Loaded after `create_model` and
            before LoRA adapters are applied.
        lora_rank: LoRA rank for parameter-efficient fine-tuning. `None` (default)
            uses full fine-tuning; `"auto"` selects rank from model size; an
            integer sets the rank directly. See module-level comments for guidance.
        **kwargs: Additional keyword arguments passed to the base class.
    """

    def __init__(
        self,
        model_id: str,
        args: TIMMTrainingConfig,
        labels: Optional[list[str]],
        pretrained_file: Optional[Union[str, os.PathLike[str]]] = None,
        lora_rank: Optional[Union[int, Literal["auto"]]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.model_id = f"hf_hub:{model_id}" if "/" in model_id else model_id
        self.args = args
        self.labels = labels
        self.pretrained_file = pretrained_file
        self.lora_rank = lora_rank
        self._num_classes: Optional[int] = len(labels) if labels else None
        # Attributes set by initialise()
        self.device: Any = None
        self.model: Any = None
        self._effective_lora_rank: Optional[int] = None

    @property
    def epochs(self) -> Optional[int]:
        """Total number of training epochs configured for federated training."""
        return self.args.epochs

    @property
    def steps(self) -> Optional[int]:
        """Total training steps. Not used; epoch-based training only."""
        return None

    @property
    def tensor_precision(self) -> Any:
        """Tensor dtype for parameter aggregation."""
        return torch.float32

    def initialise(self, *, task_id: str, **kwargs: Any) -> None:
        """Creates the global DINOv2 model on the modeller side.

        The modeller manages global model state on CPU — no training happens
        here; only weight bookkeeping and serialization.

        Args:
            task_id: Unique identifier for the federated task.
            **kwargs: Additional keyword arguments.
        """
        # Backfill num_classes from the factory's label list when the user omitted it
        # from TIMMTrainingConfig directly; create_model requires a concrete integer.
        if self._num_classes is not None and self.args.num_classes is None:
            self.args.num_classes = self._num_classes

        self.device = torch.device("cpu")
        # Seed before create_model so that any randomly initialised layers
        # (e.g. the classification head when num_classes differs from the
        # pretrained checkpoint) are identical across modeller and all workers.
        # Without this, LoRA adapters would be built on top of different base
        # weights and FedAvg would produce an incorrect global model.
        timm_utils.random_seed(self.args.seed, 0)
        self.model = create_model(
            self.model_id,
            pretrained=self.args.pretrained,
            num_classes=self.args.num_classes,
            drop_rate=self.args.drop,
            drop_path_rate=self.args.drop_path,
            drop_block_rate=self.args.drop_block,
            global_pool=self.args.gp,
        )
        self.model.to(self.device)
        if self.pretrained_file is not None:
            load_checkpoint(self.model, str(self.pretrained_file))
            logger.info(
                f"Modeller: loaded pretrained weights from '{self.pretrained_file}'."
            )
        param_count = sum(p.numel() for p in self.model.parameters())
        logger.info(
            f"Modeller: global model '{safe_model_name(self.model_id)}' created "
            f"with {self.args.num_classes} classes, {param_count:,} parameters."
        )
        self._effective_lora_rank = _resolve_lora_rank(self.lora_rank, self.model)
        if self._effective_lora_rank is not None:
            self.model = _apply_lora(self.model, self._effective_lora_rank)

    # pyrefly: ignore[bad-override]
    def run(
        self,
        iteration: int = 0,
        update: Optional[_Weights] = None,
        validation_metrics: Optional[Mapping[str, float]] = None,
    ) -> _SerializedWeights:
        """Applies the aggregated weight update and serializes the global model state.

        On the first call (`update=None`) the pretrained weights are returned
        unchanged for the initial broadcast. On subsequent calls the aggregated weight
        update from all fabs is loaded into the global model before serialization.

        Args:
            iteration: Current federated round index (0-based for the initial call).
            update: Aggregated weight update from all workers as a dict of
                `{param_name: tensor_or_array}`, or `None` for the initial
                parameter broadcast.
            validation_metrics: Optional validation metrics from the previous round.
                Logged for observability but not used to modify the model.

        Returns:
            Serialized global model state as a mapping of parameter names to flat
            lists of floats, suitable for transmission to worker pods.
        """
        if update is not None:
            with torch.no_grad():
                current_sd = self.model.state_dict()
                new_sd: dict[str, torch.Tensor] = {}
                for name, buf in current_sd.items():
                    if name in update:
                        new_weight = update[name]
                        if isinstance(new_weight, np.ndarray):
                            tensor = torch.from_numpy(new_weight.copy()).to(buf.dtype)
                        elif isinstance(new_weight, torch.Tensor):
                            tensor = new_weight.to(buf.dtype)
                        elif hasattr(new_weight, "torchtensor"):
                            # _AdaptorForPyTorchTensor from the aggregator
                            tensor = new_weight.torchtensor.to(buf.dtype)
                        else:
                            tensor = torch.tensor(new_weight, dtype=buf.dtype)
                        new_sd[name] = tensor.reshape(buf.shape).to(self.device)
                    else:
                        new_sd[name] = buf
                self.model.load_state_dict(new_sd)

            if validation_metrics:
                logger.federated_info(
                    f"Round {iteration}: aggregated validation metrics: "
                    f"{validation_metrics}"
                )

        if self._effective_lora_rank is not None:
            # LoRA mode: broadcast only adapter keys so the modeller→worker payload
            # matches the ~100× reduction achieved on the worker→modeller direction.
            # Workers fall back to their local frozen-backbone copies for absent keys.
            state_dict = _lora_state_dict(self.model)
        else:
            state_dict = self.model.state_dict()
        serialized: _SerializedWeights = {
            name: buf.cpu().flatten().tolist() for name, buf in state_dict.items()
        }
        logger.debug(f"Modeller: serialized {len(serialized)} parameter tensors.")
        return serialized


class _FedWorkerSide(BaseWorkerAlgorithm):
    """Worker side of the TIMMFederatedTraining algorithm.

    Each fab runs this side locally. On every federated round it receives the
    global model parameters from the OEM modeller, trains locally for the
    requested number of epochs, and returns the updated model weights for
    aggregation. Wafer images never leave the fab.

    Args:
        model_id: The TIMM / HuggingFace model identifier.
        args: Training configuration dataclass.
        save_path: Directory for local checkpoints and artefacts.
        image_column_name: Name of the image column in the datasource.
        target_column_name: Name of the label column in the datasource.
        labels: Ordered list of class label names.
        lora_rank: LoRA rank for parameter-efficient fine-tuning. `None` (default)
            uses full fine-tuning; `"auto"` selects rank from model size; an
            integer sets the rank directly. See module-level comments for guidance.
        batch_transformations: Albumentations batch transforms to apply. Defaults
            to 224×224 resize + normalise + ToTensorV2 for both train and validation.
        **kwargs: Additional keyword arguments passed to the base class.
    """

    def __init__(
        self,
        model_id: str,
        args: TIMMTrainingConfig,
        save_path: Union[str, os.PathLike[str]],
        image_column_name: Optional[str] = None,
        target_column_name: Optional[str] = None,
        labels: Optional[list[str]] = None,
        lora_rank: Optional[Union[int, Literal["auto"]]] = None,
        batch_transformations: Optional[list[dict[str, _JSONDict]]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.model_id = f"hf_hub:{model_id}" if "/" in model_id else model_id
        self.args = args
        self.args.model = self.model_id
        self.save_path = save_path
        self.image_column_name = image_column_name
        self.target_column_name = target_column_name
        self.lora_rank = lora_rank

        if labels:
            self.labels2id = {
                target_column_name: {label: i for i, label in enumerate(labels)}
            }
            self.num_labels: Optional[int] = len(labels)
        else:
            # pyrefly: ignore[bad-assignment]
            self.labels2id = None
            self.num_labels = None

        if batch_transformations is not None:
            self.batch_transformations = batch_transformations
        else:
            self.batch_transformations = [
                {
                    "albumentations": {
                        "arg": self.image_column_name,
                        "output": True,
                        "transformations": DEFAULT_IMAGE_TRANSFORMATIONS,
                        "step": "train",
                    }
                },
                {
                    "albumentations": {
                        "arg": self.image_column_name,
                        "output": True,
                        "transformations": DEFAULT_IMAGE_TRANSFORMATIONS,
                        "step": "validation",
                    }
                },
            ]

        # Cumulative epoch count for this worker across federated rounds, used to
        # advance the LR scheduler monotonically (round 1: 0..N-1, round 2: N..2N-1).
        self._global_epoch: int = 0
        # Attributes set by initialise()
        self.device: Any = None
        self.model: Any = None
        self._effective_lora_rank: Optional[int] = None
        self.optimizer: Any = None
        self.amp_autocast: Any = suppress
        self.loss_scaler: Optional[Any] = None
        self.mixup_fn: Optional[Any] = None
        self.train_loss_fn: Any = None
        self.validate_loss_fn: Any = None
        self.semantic_types: dict[str, list[Optional[str]]] = {}
        self.train_dataloader: Any = None
        self.eval_dataloader: Any = None
        self.lr_scheduler: Any = None

    @property
    def epochs(self) -> Optional[int]:
        """Total number of training epochs configured for federated training."""
        return self.args.epochs

    @property
    def steps(self) -> Optional[int]:
        """Total training steps. Not used; epoch-based training only."""
        return None

    @property
    def tensor_precision(self) -> Any:
        """Tensor dtype for parameter aggregation."""
        return torch.float32

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialises the DINOv2 model, optimizer, loss function and data loaders.

        Args:
            datasource: The pod's local datasource (wafer map images).
            task_id: Unique identifier for the federated task.
            data_splitter: Optional splitter defining train/val/test partition.
            pod_dp: Differential privacy config. Not supported; logs a warning if set.
            pod_identifier: Identifier of this pod/fab.
            **kwargs: Additional keyword arguments.
        """
        if Path(self.save_path).name != task_id:
            self.save_path = Path(self.save_path) / task_id
        else:
            self.save_path = Path(self.save_path)
        self.save_path.mkdir(parents=True, exist_ok=True)

        # TODO: [BIT-3097] Resolve initialise without DP
        if pod_dp:
            logger.warning(
                "DP is not supported in TIMMFederatedTraining; ignoring `pod_dp`."
            )

        if torch.cuda.is_available():
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.benchmark = True

        self.device = timm_utils.init_distributed_device(self.args)
        logger.info(f"Worker ({pod_identifier}): training on device '{self.device}'.")

        if self.num_labels is not None and self.args.num_classes is None:
            self.args.num_classes = self.num_labels

        # Seed before create_model so that any randomly initialised layers
        # (e.g. the classification head when num_classes differs from the
        # pretrained checkpoint) are identical across the modeller and all
        # workers.  Always use rank 0 here: this code does not wrap the model
        # in DistributedDataParallel, so there is no DDP broadcast to
        # normalise divergent initialisations across ranks.  Using
        # self.args.rank (which init_distributed_device may set to a non-zero
        # value via the RANK env var or a process group) would produce a
        # different seed than the modeller's fixed rank-0 seed, causing LoRA
        # adapters to be built on top of different frozen base weights and
        # FedAvg to silently produce an incorrect global model.
        timm_utils.random_seed(self.args.seed, 0)
        self.model = create_model(
            self.model_id,
            pretrained=self.args.pretrained,
            num_classes=self.args.num_classes,
            drop_rate=self.args.drop,
            drop_path_rate=self.args.drop_path,
            drop_block_rate=self.args.drop_block,
            global_pool=self.args.gp,
        )
        self.model.to(device=self.device)

        param_count = sum(p.numel() for p in self.model.parameters())
        logger.info(
            f"Worker: model '{safe_model_name(self.model_id)}' created, "
            f"{param_count:,} parameters."
        )
        self._effective_lora_rank = _resolve_lora_rank(self.lora_rank, self.model)
        if self._effective_lora_rank is not None:
            self.model = _apply_lora(self.model, self._effective_lora_rank)

        # Setup optimizer — all hyperparameters (type, lr, weight decay, momentum,
        # etc.) are read from TIMMTrainingConfig via optimizer_kwargs().
        # See bitfount/federated/algorithms/hugging_face_algorithms/utils.py.
        self.optimizer = create_optimizer_v2(
            self.model,
            **optimizer_kwargs(cfg=self.args),
            **self.args.opt_kwargs,
        )

        # Setup AMP (Automatic Mixed Precision).
        # Two backends are supported:
        #   - "apex": NVIDIA APEX library (legacy, float16 only).
        #   - "native": PyTorch built-in torch.autocast (float16 or bfloat16).
        # When AMP is disabled, amp_autocast is a no-op context manager (suppress)
        # and loss_scaler is None (no gradient unscaling needed).
        self.amp_autocast = suppress
        self.loss_scaler = None
        use_amp = None
        amp_dtype = torch.float16

        if self.args.amp:
            if self.args.amp_impl == "apex":
                assert has_apex, "AMP impl specified as APEX but APEX is not installed."  # nosec[assert_used]
                use_amp = "apex"
                assert self.args.amp_dtype == "float16"  # nosec[assert_used]
            else:
                assert (  # nosec[assert_used]
                    has_native_amp
                ), "Please update PyTorch to a version with native AMP (or use APEX)."
                use_amp = "native"
                assert self.args.amp_dtype in ("float16", "bfloat16")  # nosec[assert_used]
            if self.args.amp_dtype == "bfloat16":
                amp_dtype = torch.bfloat16

        if use_amp == "apex":
            assert self.device.type == "cuda"  # nosec[assert_used]
            self.model, self.optimizer = amp.initialize(
                self.model, self.optimizer, opt_level="O1"
            )
            self.loss_scaler = ApexScaler()
            logger.info("Using NVIDIA APEX AMP. Training in mixed precision.")
        elif use_amp == "native":
            try:
                self.amp_autocast = partial(
                    torch.autocast, device_type=self.device.type, dtype=amp_dtype
                )
            except (AttributeError, TypeError):
                # Older PyTorch versions don't support the device_type kwarg;
                # fall back to the CUDA-specific autocast API.
                assert self.device.type == "cuda"  # nosec[assert_used]
                self.amp_autocast = torch.cuda.amp.autocast
            # Loss scaling is only needed for float16; bfloat16 has a wider
            # dynamic range and doesn't require it.
            if self.device.type == "cuda" and amp_dtype == torch.float16:
                self.loss_scaler = NativeScaler()
            logger.info("Using native Torch AMP. Training in mixed precision.")
        else:
            logger.info("AMP not enabled. Training in float32.")

        # Setup Mixup / CutMix augmentation and loss function.
        # Mixup interpolates two training samples; CutMix pastes a patch from one
        # sample into another. Both are controlled by TIMMTrainingConfig fields
        # (mixup, cutmix, cutmix_minmax). When active, the loss function uses soft
        # targets (label smoothing applied inside Mixup); when inactive it uses
        # hard targets.
        mixup_active = (
            self.args.mixup > 0
            or self.args.cutmix > 0.0
            or self.args.cutmix_minmax is not None
        )
        self.mixup_fn = None
        if mixup_active:
            self.mixup_fn = Mixup(
                mixup_alpha=self.args.mixup,
                cutmix_alpha=self.args.cutmix,
                cutmix_minmax=self.args.cutmix_minmax,
                prob=self.args.mixup_prob,
                switch_prob=self.args.mixup_switch_prob,
                mode=self.args.mixup_mode,
                label_smoothing=self.args.smoothing,
                num_classes=self.args.num_classes,
            )
        self.train_loss_fn, self.validate_loss_fn = create_loss_functions(
            self.args,
            self.device,
            mixup_active=mixup_active,
            aug_splits=self.args.aug_splits,
        )

        # Setup data loaders — delegates fully to the shared helper which handles
        # train/validation splitting, transforms, and batch collation.
        (
            self.train_dataloader,
            self.eval_dataloader,
            self.semantic_types,
        ) = create_train_eval_dataloaders(
            datasource=datasource,
            data_splitter=data_splitter,
            args=self.args,
            image_column_name=self.image_column_name,
            target_column_name=self.target_column_name,
            batch_transformations=self.batch_transformations,
            labels2id=self.labels2id,
        )

        # Setup learning rate scheduler.
        # `updates_per_epoch` is the number of optimiser steps per epoch, accounting
        # for gradient accumulation (ceiling division so partial batches are counted).
        # The scheduler uses this to convert epoch-based milestones to step counts.
        updates_per_epoch = (
            len(self.train_dataloader) + self.args.grad_accum_steps - 1
        ) // self.args.grad_accum_steps
        self.lr_scheduler, _ = create_scheduler_v2(
            self.optimizer,
            # pyrefly: ignore[bad-argument-type]
            **scheduler_kwargs(self.args),
            updates_per_epoch=updates_per_epoch,
        )

    # pyrefly: ignore[bad-override]
    def run(
        self,
        model_params: _SerializedWeights,
        iterations: int,
    ) -> tuple[_Weights, Optional[dict[str, str]]]:
        """Trains locally for `iterations` epochs and returns the updated weights.

        Loads the global model parameters broadcast from the OEM modeller, runs
        local training on the fab's private wafer map images for the specified number
        of epochs, validates, then returns the updated model weights and metrics.
        Wafer images never leave the fab — only the model weights are transmitted.

        Args:
            model_params: Serialized global model parameters from the modeller,
                as a mapping of `{param_name: flat_list_of_floats}`.
            iterations: Number of local training epochs to run this federated round.

        Returns:
            A tuple of:

            - `updated_weights`: Updated model state dict as a mapping of
              `{param_name: torch.Tensor}` for aggregation by the modeller.
            - `val_metrics`: Validation metrics from the final local epoch,
              as a `{metric_name: str_value}` mapping, or `None`.
        """
        # Load global params broadcast from OEM into the local model
        with torch.no_grad():
            current_sd = self.model.state_dict()
            new_sd: dict[str, torch.Tensor] = {}
            for name, buf in current_sd.items():
                if name in model_params:
                    flat = torch.tensor(
                        model_params[name], dtype=buf.dtype, device=self.device
                    )
                    new_sd[name] = flat.reshape(buf.shape)
                else:
                    new_sd[name] = buf
            self.model.load_state_dict(new_sd)

        # Local training for this federated round
        for epoch_idx in range(iterations):
            global_epoch = self._global_epoch + epoch_idx
            train_one_epoch(
                global_epoch,
                self.model,
                self.train_dataloader,
                self.optimizer,
                self.train_loss_fn,
                self.args,
                device=self.device,
                lr_scheduler=self.lr_scheduler,
                output_dir=str(self.save_path),
                amp_autocast=self.amp_autocast,
                loss_scaler=self.loss_scaler,
                mixup_fn=self.mixup_fn,
            )
            if self.lr_scheduler is not None:
                # Step epoch-based LR schedulers (cosine, step, etc.).
                # Metric is omitted since validation runs once per round, not per epoch.
                self.lr_scheduler.step(global_epoch + 1)
        self._global_epoch += iterations

        # Validate after local training
        eval_metrics = validate(
            self.model,
            self.eval_dataloader,
            self.validate_loss_fn,
            self.args,
            device=self.device,
            amp_autocast=self.amp_autocast,
        )

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        # Return weights for FedAvg aggregation.  Values must be
        # _AdaptorForPyTorchTensor (not raw torch.Tensor) so that the protocol
        # shim's to_list() can serialize them for transmission.
        if self._effective_lora_rank is not None:
            # LoRA mode: only exchange adapter matrices (~100× smaller than full
            # state dict).  The frozen backbone is identical across all pods so
            # it does not need to be transmitted; the modeller applies only the
            # averaged adapter deltas.
            updated_weights: _Weights = {
                name: _AdaptorForPyTorchTensor(buf.detach().cpu())
                for name, buf in _lora_state_dict(self.model).items()
            }
        else:
            # Full fine-tuning: transmit the entire state dict.
            updated_weights = {
                name: _AdaptorForPyTorchTensor(buf.detach().cpu())
                for name, buf in self.model.state_dict().items()
            }
        val_metrics_str: dict[str, str] = {k: str(v) for k, v in eval_metrics.items()}
        top1 = eval_metrics.get("top1")
        top1_str = f"{top1:.2f}" if top1 is not None else "n/a"

        logger.info(
            f"Round complete — local epochs: {iterations}, val top1: {top1_str}%"
        )
        return updated_weights, val_metrics_str

    def save_final_parameters(
        self, model_params: _SerializedWeights, save_path: Path
    ) -> None:
        """Saves the final aggregated global model weights as a PyTorch checkpoint.

        Called by the FederatedAveraging protocol after the last round. The saved
        checkpoint (`dinov2_wafer_final.pt`) contains the final globally-averaged
        DINOv2 model weights and can be used directly for inference.

        Args:
            model_params: Final serialized global model parameters from the modeller.
            save_path: Directory where the checkpoint file will be written.
        """
        save_path.mkdir(parents=True, exist_ok=True)
        if self._effective_lora_rank is not None:
            # Load the final globally-averaged PEFT weights back into the model
            # before merging.  model_params keys are PEFT-prefixed
            # (e.g. "base_model.model.head.weight") while merge_and_unload()
            # produces clean keys ("head.weight"), so the lookup must happen
            # against the still-wrapped model first.
            with torch.no_grad():
                peft_sd = self.model.state_dict()
                new_peft_sd: dict[str, torch.Tensor] = {}
                for name, buf in peft_sd.items():
                    if name in model_params:
                        new_peft_sd[name] = torch.tensor(
                            model_params[name], dtype=buf.dtype
                        ).reshape(buf.shape)
                    else:
                        new_peft_sd[name] = buf
                self.model.load_state_dict(new_peft_sd)
            # Merge LoRA adapters into the backbone weights and unload PEFT
            # scaffolding so the saved checkpoint can be loaded without peft.
            # Reassign self.model explicitly so callers can see that the model
            # is now a plain (unwrapped) model; reset _effective_lora_rank to
            # keep instance state consistent with the actual model object.
            self.model = self.model.merge_and_unload()
            self._effective_lora_rank = None
            state_dict: dict[str, torch.Tensor] = self.model.state_dict()
        else:
            current_sd = self.model.state_dict()
            state_dict = {}
            for name, buf in current_sd.items():
                if name in model_params:
                    state_dict[name] = torch.tensor(
                        model_params[name], dtype=buf.dtype
                    ).reshape(buf.shape)
                else:
                    state_dict[name] = buf.cpu()
        checkpoint_path = save_path / "dinov2_wafer_final.pt"
        torch.save(state_dict, checkpoint_path)
        logger.federated_info(
            f"Final global DINOv2 model checkpoint saved to: {checkpoint_path}"
        )

    async def run_final_step(self, *, context: ProtocolContext, **kwargs: Any) -> Any:
        """Cleans up model resources after federated training completes.

        Args:
            context: Protocol context for the current task.
            **kwargs: Additional keyword arguments.

        Returns:
            None.
        """
        if getattr(self, "model", None) is not None:
            del self.model
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


@delegates()
class TIMMFederatedTraining(
    BaseNonModelAlgorithmFactory[_FedModellerSide, _FedWorkerSide]
):
    """TIMM-based federated training algorithm compatible with FederatedAveraging.

    Enables collaborative DINOv2 fine-tuning across multiple fabs (pods) without
    any fab sharing its raw wafer map images. Each fab trains locally on its private
    data and sends only model weight updates to the OEM (modeller), which aggregates
    them using Federated Averaging.

    This algorithm is designed for use with the `FederatedAveraging` protocol.
    Use `TIMMFineTuning` with `ResultsOnly` instead for per-fab local fine-tuning
    without weight exchange.

    Args:
        datastructure: Data structure describing the image and label columns.
        model_id: The HuggingFace / TIMM model identifier, e.g.
            `"timm/vit_base_patch14_dinov2.lvd142m"`.
        labels: Ordered list of class label strings corresponding to the
            classification head outputs (e.g. wafer defect types).
        args: Training configuration. Defaults to `TIMMTrainingConfig()`.
        pretrained_file: Optional path to a local pretrained checkpoint to start
            from instead of downloading from HuggingFace Hub. Defaults to `None`.
        lora_rank: LoRA rank for parameter-efficient fine-tuning. `None` (default)
            uses full fine-tuning; `"auto"` selects rank from model size (recommended
            for DINOv2 and other large ViTs); an integer sets the rank directly.
            See module-level comments for guidance on rank selection.
        **kwargs: Additional keyword arguments.
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "model_id": fields.Str(required=True),
        "labels": fields.List(fields.Str(), allow_none=True, load_default=None),
        "pretrained_file": fields.Str(allow_none=True, load_default=None),
        "lora_rank": fields.Raw(allow_none=True, load_default=None),
        "args": fields.Nested(desert.schema_class(TIMMTrainingConfig), allow_none=True),
    }

    _inference_algorithm: bool = False

    def __init__(
        self,
        datastructure: DataStructure,
        model_id: str,
        labels: Optional[list[str]] = None,
        args: Optional[TIMMTrainingConfig] = None,
        pretrained_file: Optional[Union[str, os.PathLike[str]]] = None,
        lora_rank: Optional[Union[int, Literal["auto"]]] = None,
        **kwargs: Any,
    ) -> None:
        if pretrained_file is not None and lora_rank is not None:
            raise ValueError(
                "Cannot use 'pretrained_file' together with 'lora_rank'. "
                "In LoRA mode only adapter keys are broadcast; the custom backbone "
                "from 'pretrained_file' is never transmitted to workers, so each pod "
                "would train adapters on a different backbone and FedAvg would be "
                "incorrect. Use lora_rank=None for full fine-tuning when "
                "'pretrained_file' is set."
            )
        super().__init__(datastructure=datastructure, **kwargs)
        self.model_id = model_id
        self.labels = labels
        self.args = args or TIMMTrainingConfig()
        self.pretrained_file = pretrained_file
        self.lora_rank = lora_rank
        self.batch_transformations = self.datastructure.batch_transforms

        logger.debug(f"TIMMFederatedTraining arguments: {self.args}.")

    @property
    def model(self) -> str:
        """Returns the model identifier string.

        This property satisfies the structural requirement of the
        `_FederatedAveragingCompatibleAlgoFactory` Protocol. The Protocol check
        is `@runtime_checkable` and only verifies that the attribute exists, not
        its type.
        """
        return self.model_id

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _FedModellerSide:
        """Returns the modeller side of the TIMMFederatedTraining algorithm.

        Args:
            context: Protocol context for the current task.
            **kwargs: Additional keyword arguments.

        Returns:
            The modeller-side algorithm instance.
        """
        return _FedModellerSide(
            model_id=self.model_id,
            args=copy.copy(self.args),
            labels=self.labels,
            lora_rank=self.lora_rank,
            **kwargs,
        )

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _FedWorkerSide:
        """Returns the worker side of the TIMMFederatedTraining algorithm.

        The `hub` keyword argument passed by `FederatedAveraging` is accepted
        via `**kwargs` and forwarded to the worker side (currently unused since
        weights are downloaded from HuggingFace Hub directly via TIMM).

        Args:
            context: Protocol context for the current task.
            **kwargs: Additional keyword arguments (includes `hub` from the
                FederatedAveraging protocol).

        Returns:
            The worker-side algorithm instance.
        """
        task_results_dir = get_task_results_directory(context)

        if not self.datastructure.selected_cols:
            raise ValueError(
                "TIMMFederatedTraining requires at least one column in "
                "datastructure.selected_cols (the image column name)."
            )
        image_column_name = self.datastructure.selected_cols[0]

        target = self.datastructure.target
        if target is None:
            raise ValueError(
                "TIMMFederatedTraining requires datastructure.target to be set "
                "(the label column name)."
            )
        target_column_name = target if isinstance(target, str) else target[0]

        return _FedWorkerSide(
            model_id=self.model_id,
            args=copy.copy(self.args),
            labels=self.labels,
            lora_rank=self.lora_rank,
            image_column_name=image_column_name,
            target_column_name=target_column_name,
            batch_transformations=self.batch_transformations,
            save_path=task_results_dir,
            **kwargs,
        )


# FederatedAveraging.nested_fields["algorithm"] is hard-wired to
# model_algorithms.base.registry, which only auto-populates via
# BaseModelAlgorithmFactory.__init_subclass__. The correct fix is to widen that
# registry (or switch FederatedAveraging to a shared registry covering all
# _FederatedAveragingCompatibleAlgoFactory implementations) so that non-model
# algorithms like this one are discovered automatically. Until then we manually
# insert here to avoid the pod failing to deserialize an incoming task.
# pyrefly: ignore[unsupported-operation]
_model_alg_registry[TIMMFederatedTraining.__name__] = TIMMFederatedTraining
