"""Hugging Face Named Entity Recognition (NER) Algorithm."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import json
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Optional, Union, cast

from marshmallow import fields
import pandas as pd

from bitfount.config import _PYTORCH_ENGINE, BITFOUNT_ENGINE
from bitfount.data.datasources.utils import ORIGINAL_FILENAME_METADATA_COLUMN
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.data.huggingface.dataloaders import (
    HuggingFaceBitfountDataLoader,
    HuggingFaceIterableBitfountDataLoader,
)
from bitfount.federated.algorithms.hugging_face_algorithms.base import _HFModellerSide
from bitfount.federated.algorithms.hugging_face_algorithms.utils import (
    _build_hf_auth_kwargs,
)
from bitfount.federated.algorithms.post_processing_base import (
    apply_postprocessors,
    create_postprocessors,
)
from bitfount.federated.types import ProtocolContext

if BITFOUNT_ENGINE == _PYTORCH_ENGINE:
    import torch
    from transformers import pipeline, set_seed

from bitfount.data.datasources.base_source import BaseSource
from bitfount.data.huggingface.utils import get_data_factory_dataset
from bitfount.data.types import DataSplit, SingleOrMulti, _SemanticTypeValue
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.hooks import HookType, get_hooks
from bitfount.types import T_FIELDS_DICT
from bitfount.utils import DEFAULT_SEED, delegates

if TYPE_CHECKING:
    from bitfount.federated.privacy.differential import DPPodConfig


logger = _get_federated_logger(__name__)

# Aggregation strategy type for NER pipeline
_AggregationStrategy = Literal["simple", "first", "average", "max", "none"]

# Default batch size for NER processing
DEFAULT_NER_BATCH_SIZE = 16

# Default aggregation strategy
DEFAULT_AGGREGATION_STRATEGY: _AggregationStrategy = "simple"


class _WorkerSide(BaseWorkerAlgorithm):
    """Worker side of the HuggingFaceNERInference algorithm."""

    # Define attributes to avoid implicit-definition-attribute errors
    test_dataloader: Union[
        HuggingFaceBitfountDataLoader, HuggingFaceIterableBitfountDataLoader
    ]
    ner_pipeline: Any

    def __init__(
        self,
        model_id: str,
        target_column_name: str,
        batch_size: int = DEFAULT_NER_BATCH_SIZE,
        aggregation_strategy: _AggregationStrategy = DEFAULT_AGGREGATION_STRATEGY,
        seed: int = DEFAULT_SEED,
        access_token: Optional[str] = None,
        postprocessors: Optional[list[dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.model_id = model_id
        self.target_column_name = target_column_name
        self.target_col_with_semantic_type: Mapping[_SemanticTypeValue, list[str]] = {
            "text": [self.target_column_name]
        }
        self.batch_size = batch_size
        self.aggregation_strategy = aggregation_strategy
        self.seed = seed
        self.access_token = access_token
        self.postprocessors = create_postprocessors(postprocessors, access_token)

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialises the NER pipeline."""
        # TODO: [BIT-3097] Resolve initialise without DP
        if pod_dp:
            logger.warning("The use of DP is not supported, ignoring set `pod_dp`.")
        self.initialise_data(datasource=datasource)
        data_factory, dataset = get_data_factory_dataset(
            datasource=datasource,
            data_splitter=data_splitter,
            data_split=DataSplit.TEST,
            selected_cols=[self.target_column_name],
            selected_cols_semantic_types=self.target_col_with_semantic_type,
            batch_transforms=[],
        )
        self.test_dataloader: Union[
            HuggingFaceBitfountDataLoader, HuggingFaceIterableBitfountDataLoader
        ] = data_factory.create_dataloader(
            dataset, batch_size=self.batch_size, **kwargs
        )
        set_seed(self.seed)
        auth_kwargs = _build_hf_auth_kwargs(self.access_token)
        for hook in get_hooks(HookType.POD):
            hook.on_model_download_start(
                task_id=task_id,
                model_id=self.model_id,
                source="Hugging Face",
            )
        self.ner_pipeline = pipeline(
            "token-classification",
            model=self.model_id,
            aggregation_strategy=self.aggregation_strategy,
            **auth_kwargs,
        )
        for hook in get_hooks(HookType.POD):
            hook.on_model_download_end(
                task_id=task_id,
                model_id=self.model_id,
                source="Hugging Face",
            )

    def run(
        self,
        *args: Any,
        return_data_keys: bool = False,
        final_batch: bool = False,
        **kwargs: Any,
    ) -> Union[pd.DataFrame, list[list[dict[str, Union[str, float]]]], dict[str, Any]]:
        """Runs the NER pipeline to extract named entities."""
        dataframe_records = []
        for _batch_idx, batch in enumerate(
            self.test_dataloader  # pyrefly: ignore[bad-argument-type]
        ):
            batch = cast(
                Union[
                    list[SingleOrMulti[torch.Tensor]],
                    list[Union[SingleOrMulti[torch.Tensor], Sequence[str]]],
                ],
                batch,
            )

            input_: SingleOrMulti[torch.Tensor] = cast(
                SingleOrMulti[torch.Tensor], batch[0]
            )

            keys: Optional[list[str]]
            if self.test_dataloader.expect_key_in_iter():
                # If key is in iteration, the last element in the batch will be the
                # data keys
                keys_: SingleOrMulti[str] = cast(SingleOrMulti[str], batch[-1])
                if isinstance(keys_, str):
                    keys = [keys_]
                else:
                    keys = list(keys_)
            else:
                keys = None

            # Handle tuple inputs
            if isinstance(input_[0], tuple):
                input_ = [item[0] for item in input_]

            # Process each text in the batch through the NER pipeline
            if isinstance(input_, list):
                texts = input_
            else:
                texts = [input_]

            # Run NER pipeline on the batch
            # Cast texts to list[str] for type checker
            texts_list: list[str] = [str(t) for t in texts]
            ner_results = self.ner_pipeline(texts_list, batch_size=self.batch_size)

            # Handle single text case (pipeline returns list of entities, not list of
            # lists)
            # When a single text produces no entities, ner_results is [] (falsy),
            # so we need to check if it's a list (not a list of lists) rather than
            # checking if it's truthy
            if (
                texts
                and len(texts) == 1
                and isinstance(ner_results, list)
                and (not ner_results or isinstance(ner_results[0], dict))
            ):
                ner_results = [ner_results]

            # Process results for each text
            for idx, entities in enumerate(ner_results):
                # Convert entities to serializable format
                serializable_entities = []
                for entity in entities:
                    serializable_entity = {
                        "entity_group": entity.get(
                            "entity_group", entity.get("entity", "")
                        ),
                        "word": entity.get("word", ""),
                        "score": float(entity.get("score", 0.0)),
                        "start": int(entity.get("start", 0)),
                        "end": int(entity.get("end", 0)),
                    }
                    serializable_entities.append(serializable_entity)

                record: dict[str, Any] = {
                    "entities": json.dumps(serializable_entities),
                    "original_text": texts_list[idx],
                }

                # If keys are provided and requested, add them to the dataframe
                # as a new column.
                if keys and return_data_keys:
                    record[ORIGINAL_FILENAME_METADATA_COLUMN] = keys[idx]

                # pyrefly: ignore[bad-argument-type]
                dataframe_records.append(record)

        df = pd.DataFrame.from_records(dataframe_records)

        if self.postprocessors:
            df = apply_postprocessors(self.postprocessors, df)

        return cast(pd.DataFrame, df)


@delegates()
class HuggingFaceNERInference(
    BaseNonModelAlgorithmFactory[_HFModellerSide, _WorkerSide]
):
    """Inference for pre-trained Hugging Face Named Entity Recognition (NER) models.

    This algorithm extracts named entities from text using HuggingFace's
    token-classification pipeline.

    Args:
        datastructure: The data structure to use for the algorithm.
        model_id: HuggingFace model identifier for the NER model.
        batch_size: The batch size for inference. Defaults to 16.
        aggregation_strategy: Strategy to aggregate tokens into entities.
            Options are: "simple", "first", "average", "max", "none".
            Defaults to "simple".
        seed: Sets the seed of the algorithm for reproducibility. Defaults to 42.

    Attributes:
        model_id: The HuggingFace model identifier being used.
        batch_size: The batch size for inference.
        aggregation_strategy: The token aggregation strategy.
        seed: The random seed for reproducibility.
    """

    def __init__(
        self,
        datastructure: DataStructure,
        model_id: str,
        batch_size: int = DEFAULT_NER_BATCH_SIZE,
        aggregation_strategy: _AggregationStrategy = DEFAULT_AGGREGATION_STRATEGY,
        seed: int = DEFAULT_SEED,
        access_token: Optional[str] = None,
        postprocessors: Optional[list[dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(datastructure=datastructure, **kwargs)
        self.model_id = model_id
        self.access_token = access_token
        self.batch_size = batch_size
        self.aggregation_strategy = aggregation_strategy
        self.seed = seed
        self.postprocessors = postprocessors

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "model_id": fields.Str(required=True),
        "batch_size": fields.Int(required=False, missing=DEFAULT_NER_BATCH_SIZE),
        "aggregation_strategy": fields.Str(
            required=False, missing=DEFAULT_AGGREGATION_STRATEGY
        ),
        "seed": fields.Int(required=False, missing=DEFAULT_SEED),
        "access_token": fields.Str(required=False, allow_none=True),
        "postprocessors": fields.List(
            fields.Dict(
                keys=fields.String(),
            ),
            allow_none=True,
        ),
    }

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _HFModellerSide:
        """Returns the modeller side of the HuggingFaceNERInference algorithm."""
        return _HFModellerSide(task_name="ner", **kwargs)

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Returns the worker side of the HuggingFaceNERInference algorithm."""
        return _WorkerSide(
            model_id=self.model_id,
            target_column_name=self.datastructure.selected_cols[0],
            batch_size=self.batch_size,
            aggregation_strategy=self.aggregation_strategy,
            seed=self.seed,
            access_token=self.access_token,
            postprocessors=self.postprocessors,
            **kwargs,
        )
