"""Postprocessing for Hugging Face models."""

import json
from typing import Any, Optional, Union

import huggingface_hub as hf
import pandas as pd

from bitfount.data.datasources.utils import ORIGINAL_FILENAME_METADATA_COLUMN
from bitfount.federated.algorithms.post_processing_base import (
    PostProcessor,
    PostprocessorType,
)
from bitfount.types import PredictReturnType

__all__: list[str] = [
    "HuggingFaceApplyIdToLabelsPostProcessor",
    "NERDeidentificationPostProcessor",
]


class HuggingFaceApplyIdToLabelsPostProcessor(PostProcessor):
    """Apply ID to labels for Hugging Face models."""

    _processor_type = PostprocessorType.HUGGINGFACE_APPLY_ID_TO_LABELS

    def __init__(
        self,
        model_id: str,
        filepath: str,
        key: Optional[str] = None,
        access_token: Optional[str] = None,
    ) -> None:
        """Initialize the Hugging Face apply ID to labels processor.

        Args:
            model_id: The model ID to use for the Hugging Face model
            filepath: The filepath to the ID to labels mapping file
            key: The key to use for the ID to labels mapping
            access_token: Optional Hugging Face access token. If not provided,
                defaults to BITFOUNT_HUGGINGFACE_USER_ACCESS_TOKEN env var.
        """
        from bitfount.federated.algorithms.hugging_face_algorithms.utils import (
            _build_hf_auth_kwargs,
        )

        self.model_id = model_id
        self.filepath = filepath
        self.key = key
        self.id_to_labels: Optional[dict[str, Any]] = None

        try:
            labels_path = hf.hf_hub_download(
                repo_id=self.model_id,
                filename=self.filepath,
                **_build_hf_auth_kwargs(access_token),
            )
        except Exception as e:
            raise ValueError(
                f"Error downloading file {self.filepath} from "
                f"repository {self.model_id}: {e}"
            ) from e

        try:
            with open(labels_path, "r") as f:
                self.id_to_labels = json.load(f)
        except Exception as e:
            raise ValueError(f"Error loading file {labels_path}: {e}") from e

    def process(self, predictions: Any) -> Any:
        """Process predictions by applying ID to labels."""
        if self.id_to_labels is None:
            raise ValueError(
                "id_to_labels must be loaded before process(). "
                "Ensure __init__() has been called."
            )

        # Get the mapping for the classification head
        if self.key is not None:
            if self.key not in self.id_to_labels:
                raise ValueError(
                    f"Key '{self.key}' not found in id_to_labels. "
                    f"Available keys: {list(self.id_to_labels.keys())}"
                )
            mapping = self.id_to_labels[self.key]
        else:
            mapping = self.id_to_labels

        if isinstance(predictions, pd.DataFrame):
            predictions = self._apply_id_to_labels(predictions, mapping)
        elif isinstance(predictions, PredictReturnType):
            if isinstance(predictions.preds, pd.DataFrame):
                processed_preds = self.process(predictions.preds)
                return PredictReturnType(preds=processed_preds, keys=predictions.keys)

        return predictions

    def _apply_id_to_labels(
        self, predictions: pd.DataFrame, mapping: dict[str, Any]
    ) -> pd.DataFrame:
        """Apply ID to labels to a DataFrame."""
        # Import here to avoid circular imports
        from bitfount.federated.utils import _LABEL_PATTERN, _id2label_lookup

        # Build column rename dict and identify unresolved LABEL_X columns to drop
        rename_map: dict[Union[str, int], str] = {}
        cols_to_drop: list[str] = []
        for col in predictions.columns:
            if col == ORIGINAL_FILENAME_METADATA_COLUMN:
                continue
            new_name = _id2label_lookup(mapping, col)
            if _LABEL_PATTERN.match(col) and new_name == col:
                # Unresolved LABEL_X columns (no mapping in id_to_labels) - drop them
                # since they are generic placeholders with no meaningful label
                cols_to_drop.append(col)
            else:
                rename_map[col] = new_name

        if cols_to_drop:
            predictions = predictions.drop(columns=cols_to_drop, errors="ignore")
        return predictions.rename(columns=rename_map)


class NERDeidentificationPostProcessor(PostProcessor):
    """De-identify text by replacing named entities with placeholders."""

    _processor_type = PostprocessorType.NER_DEIDENTIFICATION

    def process(self, predictions: Any) -> Any:
        """Process predictions by redacting entities from original text."""
        if isinstance(predictions, pd.DataFrame):
            return self._deidentify_dataframe(predictions)
        elif isinstance(predictions, PredictReturnType):
            if isinstance(predictions.preds, pd.DataFrame):
                processed_preds = self._deidentify_dataframe(predictions.preds)
                return PredictReturnType(preds=processed_preds, keys=predictions.keys)
        return predictions

    def _deidentify_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """De-identify text in a DataFrame by replacing entities with placeholders."""
        if "entities" not in df.columns or "original_text" not in df.columns:
            raise ValueError(
                "DataFrame must contain 'entities' and 'original_text' columns "
                "for de-identification. Ensure the NER algorithm includes "
                "original_text in its output."
            )

        redacted_texts = []
        for _, row in df.iterrows():
            original_text = row["original_text"]
            entities_json = row["entities"]

            entities = (
                json.loads(entities_json)
                if isinstance(entities_json, str)
                else entities_json
            )

            redacted_text = self._redact_text(original_text, entities)
            redacted_texts.append(redacted_text)

        result_df = pd.DataFrame({"redacted_text": redacted_texts})

        if ORIGINAL_FILENAME_METADATA_COLUMN in df.columns:
            result_df[ORIGINAL_FILENAME_METADATA_COLUMN] = df[
                ORIGINAL_FILENAME_METADATA_COLUMN
            ].values

        return result_df

    def _redact_text(self, text: str, entities: list[dict[str, Any]]) -> str:
        """Replace entities in text with placeholders while preserving spacing."""
        if not entities:
            return text

        def _normalize_entity_span(entity: dict[str, Any]) -> tuple[int, int]:
            start = int(entity.get("start", 0))
            end = int(entity.get("end", start))
            if end < start:
                end = start

            word = entity.get("word")
            if not isinstance(word, str) or not word:
                return start, end

            if text[start:end] == word:
                return start, end

            for offset in (-1, 1, -2, 2):
                candidate_start = start + offset
                if candidate_start < 0:
                    continue
                candidate_end = candidate_start + len(word)
                if text[candidate_start:candidate_end] == word:
                    return candidate_start, candidate_end

            window_start = max(0, start - 10)
            window_end = min(len(text), start + 10 + len(word))
            found = text.find(word, window_start, window_end)
            if found != -1:
                return found, found + len(word)

            return start, end

        sorted_entities = sorted(entities, key=lambda e: e["start"])

        result_parts = []
        current_pos = 0

        for entity in sorted_entities:
            start, end = _normalize_entity_span(entity)
            entity_group = entity["entity_group"].upper()

            if start < current_pos:
                # Skip overlapping entity but consume its span to avoid PII leak
                current_pos = max(current_pos, end)
                continue

            result_parts.append(text[current_pos:start])

            placeholder = f"<{entity_group}>"
            result_parts.append(placeholder)

            current_pos = end

        result_parts.append(text[current_pos:])

        return "".join(result_parts)
