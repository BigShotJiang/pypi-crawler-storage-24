"""Private SQL query algorithm."""

from __future__ import annotations

from collections.abc import Mapping
import math
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Final,
    NotRequired,
    Optional,
    TypedDict,
    Union,
    cast,
)

from marshmallow import ValidationError, fields
import numpy as np
import pandas as pd
from scipy.stats.mstats import winsorize

from bitfount.config import DP_AVAILABLE
from bitfount.data.datasources.base_source import BaseSource, FileSystemIterableSource
from bitfount.data.datasources.utils import load_data_in_memory
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.data.schema import BitfountSchema
from bitfount.data.types import SemanticType, _SemanticTypeValue
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
    ResultsOnlyModellerAlgorithm,
)
from bitfount.federated.exceptions import PrivateSqlError
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.mixins import _ModellessAlgorithmMixIn
from bitfount.federated.privacy.differential import (
    DPModellerConfig,
    DPPodConfig,
    _DifferentiallyPrivate,
)
from bitfount.federated.types import ProtocolContext
from bitfount.types import T_FIELDS_DICT
from bitfount.utils import delegates

if TYPE_CHECKING:
    from bitfount.hub.api import BitfountHub

logger = _get_federated_logger(__name__)

if DP_AVAILABLE:
    import snsql
    from snsql import Privacy


class ColumnRanges(TypedDict):
    """Column ranges for the PrivateSqlQuery algorithm.

    SmartNoise SQL accepts both int and float bounds. For int columns,
    bounds must be integers. For float columns, float bounds are preferred
    as they provide more precise sensitivity calculations (less noise).
    """

    lower: NotRequired[Optional[Union[int, float]]]
    upper: NotRequired[Optional[Union[int, float]]]
    type: NotRequired[Optional[str]]  # Added at runtime


# Either a mapping of column names to their ranges, or a mapping of table names to
# a mapping of column names to their ranges for multi-table datasets.
ColumnRangesType = Union[dict[str, ColumnRanges], dict[str, dict[str, ColumnRanges]]]

# Valid aggregation functions for structured SQL queries
# These match the functions supported by SmartNoise SQL (snsql)
VALID_AGGREGATION_FUNCTIONS: Final[frozenset[str]] = frozenset(
    {"AVG", "SUM", "COUNT", "MIN", "MAX", "VAR", "VARIANCE", "STD", "STDDEV", "STDEV"}
)


def _validate_aggregation_func(value: str) -> None:
    """Validate aggregation_func is one of the valid functions (case-insensitive).

    Args:
        value: The aggregation function to validate.

    Raises:
        ValidationError: If value is not a valid aggregation function.
    """
    if value.upper() not in VALID_AGGREGATION_FUNCTIONS:
        valid_funcs = ", ".join(sorted(VALID_AGGREGATION_FUNCTIONS))
        raise ValidationError(f"aggregation_func must be one of: {valid_funcs}")


def _validate_structured_sql_params(
    query: Optional[str],
    aggregate_columns: Optional[list[str]],
    group_by_columns: Optional[list[str]],
    aggregation_func: Optional[str],
) -> None:
    """Validate structured SQL parameters for mutual exclusivity and completeness.

    Raises:
        ValueError: If validation fails.
    """
    has_raw_query = bool(query)
    has_structured_params = any([aggregate_columns, group_by_columns, aggregation_func])

    if has_raw_query and has_structured_params:
        raise ValueError(
            "Cannot provide both 'query' and structured parameters "
            "(aggregate_columns, group_by_columns, aggregation_func). "
            "Use one or the other."
        )

    if not has_raw_query and not has_structured_params:
        raise ValueError(
            "Must provide either 'query' or all structured parameters "
            "(aggregate_columns, group_by_columns, aggregation_func)."
        )

    if has_structured_params:
        if not all([aggregate_columns, group_by_columns, aggregation_func]):
            raise ValueError(
                "When using structured parameters, all of "
                "aggregate_columns, group_by_columns, and aggregation_func "
                "must be provided."
            )
        agg_func_upper = aggregation_func.upper()  # type: ignore[union-attr]
        if agg_func_upper not in VALID_AGGREGATION_FUNCTIONS:
            raise ValueError(
                f"Invalid aggregation function '{aggregation_func}'. "
                f"Must be one of: {', '.join(sorted(VALID_AGGREGATION_FUNCTIONS))}"
            )


class _WorkerSide(BaseWorkerAlgorithm):
    """Worker side of the PrivateSqlQuery algorithm."""

    _SMART_NOISE_TYPE: Final[Mapping[str, tuple[str, Optional[int]]]] = {
        "int": ("int", 1_000),
        "int32": ("int", 1_000),
        "int64": ("int", 1_000),
        "float": ("float", 1),
        "float32": ("float", 1),
        "float64": ("float", 1),
        "string": ("string", None),
    }

    _CONSTANT_VALUE_MARGIN_FRACTION: Final[float] = 0.1

    def __init__(
        self,
        *,
        query: Optional[str],
        epsilon: float,
        delta: float,
        hub: BitfountHub,
        column_ranges: Optional[ColumnRangesType] = None,
        db_schema: Optional[str] = None,
        table: Optional[str] = None,
        lower_percentile: float = 1.0,
        upper_percentile: float = 99.0,
        aggregate_columns: Optional[list[str]] = None,
        group_by_columns: Optional[list[str]] = None,
        aggregation_func: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        self.datasource: BaseSource
        self.pod_identifier: Optional[str] = None
        self.pod_dp: Optional[DPPodConfig] = None
        self.query = query
        self.epsilon = epsilon
        self.delta = delta
        self.column_ranges = column_ranges
        self.hub = hub
        self.table = table
        self.db_schema = db_schema
        self.lower_percentile = lower_percentile
        self.upper_percentile = upper_percentile
        self.aggregate_columns = aggregate_columns
        self.group_by_columns = group_by_columns
        self.aggregation_func = aggregation_func
        super().__init__(**kwargs)

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Sets Datasource."""
        self.initialise_data(datasource=datasource, data_splitter=data_splitter)
        if pod_identifier:
            self.pod_identifier = pod_identifier
        if pod_dp:
            self.pod_dp = pod_dp

        if self.table is None and self.pod_identifier is not None:
            self.table = self.pod_identifier.split("/")[1]

    def map_types(self, schema: BitfountSchema) -> None:
        """Map from Pandas DataTypes to SmartNoise types.

        For the features that were user-specified in the single-table dataset,
        map from the Pandas DataTypes to the equivalent SmartNoise types.
        """
        self.column_ranges = cast(dict[str, ColumnRanges], self.column_ranges)
        for column in self.column_ranges:
            mapped_type = None
            default_max = None
            # Determine what type we have in the schema for the column
            for stype in SemanticType:
                for feature in schema.get_feature_names(stype):
                    if feature == column:
                        stype_features = schema.features[
                            # pyrefly: ignore[not-required-key-access]
                            cast(_SemanticTypeValue, stype.value)
                        ]
                        feature_details = stype_features[feature]
                        mapped_type = feature_details.dtype_name
                        break

            if mapped_type is None:
                logger.warning(
                    f"No field named '{column}' present in the schema."
                    " Will proceed assuming it is a string."
                )
                mapped_type = "str"

            # Map the type we have to an equivalent for SmartNoise SQL
            sn_mapped_type, default_max = self._SMART_NOISE_TYPE.get(
                mapped_type.lower(), (None, None)
            )
            if not sn_mapped_type:
                logger.warning(
                    f"type {mapped_type} for column '{column}' is not supported."
                    " Defaulting to string type."
                )
                sn_mapped_type = "string"

            self.column_ranges[column]["type"] = sn_mapped_type
            # if there is no specified lower/upper for int/float set defaults
            if (
                self.column_ranges[column].get("lower") is None
                and default_max is not None
            ):
                logger.warning(
                    "Using default lower and upper bound of "
                    f"(0, {default_max}) for field [{column}]"
                )
                self.column_ranges[column]["lower"] = 0
                self.column_ranges[column]["upper"] = default_max

    def _compute_bounds_with_winsorization(
        self,
        df: pd.DataFrame,
        schema: BitfountSchema,
    ) -> dict[str, ColumnRanges]:
        """Compute column bounds and clip data using Winsorization.

        Uses scipy.stats.mstats.winsorize to clip numeric column values to
        lower_percentile/upper_percentile (default 1st/99th). Clipping is
        required for DP correctness: SmartNoise calibrates noise based on
        the stated bounds (sensitivity = upper - lower). If data exceeds
        those bounds, the added noise is insufficient to protect outliers.

        The DataFrame is modified in-place to clip values to the computed bounds.

        Args:
            df: The dataframe to compute bounds from and clip. Modified in-place.
            schema: The BitfountSchema for type information.

        Returns:
            Dictionary of column names to ColumnRanges with computed bounds.
        """
        bounds: dict[str, ColumnRanges] = {}

        continuous_features = schema.features.get("continuous", {})
        if not continuous_features:
            return bounds

        # Convert percentiles to scipy winsorize limits format.
        # scipy expects (lower_fraction, upper_fraction) as proportions to clip.
        # e.g., lower_percentile=1.0 -> clip bottom 1% -> limit=0.01
        # e.g., upper_percentile=99.0 -> clip top 1% -> limit=0.01
        lower_limit = self.lower_percentile / 100.0
        upper_limit = (100.0 - self.upper_percentile) / 100.0

        for column, feature_details in continuous_features.items():
            if column not in df.columns:
                continue

            # Map dtype to SmartNoise type
            dtype_name = feature_details.dtype_name
            sn_type, default_max = self._SMART_NOISE_TYPE.get(
                dtype_name.lower(), ("string", None)
            )

            # Skip non-numeric columns
            if sn_type not in ("int", "float"):
                bounds[column] = ColumnRanges(type=sn_type)
                continue

            # Handle empty columns
            non_nan_mask = df[column].notna()
            if non_nan_mask.sum() == 0:
                bounds[column] = ColumnRanges(lower=0, upper=default_max, type=sn_type)
                logger.warning(
                    f"Column '{column}' has no data, using default bounds "
                    f"(0, {default_max})"
                )
                continue

            # Apply winsorization to clip data to percentile bounds.
            # This is for DP correctness, as the data must be within
            # stated bounds.
            winsorized = winsorize(
                df.loc[non_nan_mask, column].values,
                limits=(lower_limit, upper_limit),
            )
            df.loc[non_nan_mask, column] = np.asarray(winsorized)

            # Extract bounds from winsorized data (min/max ARE the percentile bounds)
            col_data = df.loc[non_nan_mask, column]
            lower = float(col_data.min())
            upper = float(col_data.max())

            # SmartNoise requires lower < upper so add a margin of error
            if lower == upper:
                margin = (
                    abs(lower) * self._CONSTANT_VALUE_MARGIN_FRACTION
                    if lower != 0
                    else self._CONSTANT_VALUE_MARGIN_FRACTION
                )
                lower = lower - margin
                upper = upper + margin

            # SmartNoise requires int bounds for int columns, float for float columns.
            # For DP correctness, bounds MUST contain all data values:
            # - lower bound must be <= min(data), so use floor()
            # - upper bound must be >= max(data), so use ceil()
            if sn_type == "int":
                lower_val: Union[int, float] = math.floor(lower)
                upper_val: Union[int, float] = math.ceil(upper)
                if lower_val == upper_val:
                    upper_val = lower_val + 1
            else:
                # Float columns: keep precise bounds (less noise than rounding to int)
                lower_val = lower
                upper_val = upper

            bounds[column] = ColumnRanges(
                lower=lower_val, upper=upper_val, type=sn_type
            )
            logger.info(
                f"Winsorized '{column}' to "
                f"({self.lower_percentile}th/{self.upper_percentile}th "
                f"percentile) and clipped data to bounds: [{lower_val}, {upper_val}]"
            )

        return bounds

    def _validate_run_preconditions(self) -> BitfountSchema:
        """Validate preconditions and return schema."""
        if self.table is None:
            raise ValueError(
                "No table specified on which to execute the query on. "
                "Please specify the table on which to execute the query "
                "in the algorithm definition."
            )
        if self.pod_identifier is None:
            raise ValueError("No pod identifier - cannot get schema to infer types.")
        if isinstance(self.datasource, FileSystemIterableSource):
            # TODO: [BIT-3486] Address this exclusion by adding path that works
            #       with iteration
            raise TypeError(
                f"PrivateSQLQuery does not support iterable datasources that"
                f" are not databases; got {type(self.datasource)}"
            )
        return self.hub.get_pod_schema(self.pod_identifier)

    def _validate_columns_against_schema(self, df: pd.DataFrame) -> None:
        """Validate that structured param columns exist in the dataframe."""
        if not self.aggregate_columns and not self.group_by_columns:
            return

        available_columns = set(df.columns)
        all_requested_columns = set()

        if self.aggregate_columns:
            all_requested_columns.update(self.aggregate_columns)
        if self.group_by_columns:
            all_requested_columns.update(self.group_by_columns)

        missing_columns = all_requested_columns - available_columns
        if missing_columns:
            raise ValueError(
                f"Columns not found in dataset: {sorted(missing_columns)}. "
                f"Available columns: {sorted(available_columns)}"
            )

    def _configure_dp(self) -> _DifferentiallyPrivate:
        """Configure differential privacy settings and return DP instance."""
        dp = _DifferentiallyPrivate({"epsilon": self.epsilon, "delta": self.delta})
        # We initialise dp explicitly above, so dp._dp_config will be of
        # type DPModellerConfig, making it safe to cast.
        dp._dp_config = cast(DPModellerConfig, dp._dp_config)
        if self.pod_dp:
            dp.apply_pod_dp(self.pod_dp)
        else:
            # If there is no pod_pd, we assign to it the epsilon and delta values
            # from the Modeller, as they have been previously checked by the AM.
            self.pod_dp = DPPodConfig(epsilon=self.epsilon, delta=self.delta)
        return dp

    def _sanitize_identifier(self, name: str) -> str:
        """Remove hyphens and backticks from identifiers for SQL compatibility."""
        return name.replace("-", "").replace("`", "")

    def _check_sanitized_column_collisions(self, columns: list[str]) -> None:
        """Raise if sanitizing columns would cause name collisions."""
        seen: dict[str, str] = {}
        for original in columns:
            sanitized_name = self._sanitize_identifier(original)
            if sanitized_name in seen:
                raise ValueError(
                    f"Column name collision after sanitization: "
                    f"'{seen[sanitized_name]}' and '{original}' both become "
                    f"'{sanitized_name}'. Rename columns to avoid ambiguity."
                )
            seen[sanitized_name] = original

    def _prepare_query_and_metadata(
        self,
        df: pd.DataFrame,
        schema: BitfountSchema,
        bounds_from_winsorization: bool,
    ) -> tuple[str, dict[str, dict[str, dict[str, dict[str, Any]]]]]:
        """Prepare query and metadata for SmartNoise SQL execution."""
        if self.table is None:
            raise ValueError("Table must be set before preparing query")

        if self.query is None:
            raise ValueError("Query must be set before preparing query")

        if (f"from `{self.table}`" not in self.query) and (
            f"FROM `{self.table}`" not in self.query
        ):
            err_msg = """The default table for single table datasource is the pod
                identifier without the username, in between backticks(``),
                repeated twice, separated by a dot.
                (e.g. `census-income-demo`.`census-income-demo`)
                Please ensure your SQL query operates on that table. The
                table name should be put inside backticks(``) in the
                query statement, to make sure it is correctly parsed."""
            logger.error(err_msg)
            raise ValueError(err_msg)

        table_name = self._sanitize_identifier(self.table)
        query = self._sanitize_identifier(self.query)

        if schema.name in (self.table, table_name):
            schema.name = table_name

        if not bounds_from_winsorization:
            self.map_types(schema)

        # Sanitize column_ranges keys to match sanitized query identifiers
        sanitized_column_ranges: Optional[dict[str, ColumnRanges]] = None
        if self.column_ranges is not None:
            col_names = list(cast(dict[str, ColumnRanges], self.column_ranges).keys())
            self._check_sanitized_column_collisions(col_names)
            sanitized_column_ranges = {
                self._sanitize_identifier(col): ranges
                for col, ranges in cast(
                    dict[str, ColumnRanges], self.column_ranges
                ).items()
            }

        meta: dict[str, dict[str, dict[str, dict[str, Any]]]] = {
            "": {
                table_name: {
                    table_name: {"row_privacy": True, "rows": int(len(df.index))}
                }
            }
        }
        if sanitized_column_ranges is not None:
            meta[""][table_name][table_name].update(sanitized_column_ranges)

        # Add group_by_columns to metadata as string type if not already present.
        # snsql requires ALL columns referenced in a query to be declared in metadata.
        if self.group_by_columns:
            for col in self.group_by_columns:
                sanitized_col = self._sanitize_identifier(col)
                if sanitized_col not in meta[""][table_name][table_name]:
                    meta[""][table_name][table_name][sanitized_col] = {"type": "string"}

        return query, meta

    def _execute_dp_query(
        self,
        df: pd.DataFrame,
        query: str,
        meta: dict[str, dict[str, dict[str, dict[str, Any]]]],
        dp: _DifferentiallyPrivate,
    ) -> pd.DataFrame:
        """Execute the differentially private SQL query with privacy budget loop."""
        if self.pod_dp is None:
            raise ValueError("pod_dp must be configured before executing query")
        if dp._dp_config is None:
            raise ValueError("DP config must be set before executing query")
        # Set default values for the used_epsilon and used_delta
        used_epsilon = float("inf")
        used_delta = float("inf")
        # Initialise epsilon and delta divisors as 1
        delta_div = 1.0
        epsilon_div = 1.0
        # Parameters used for rounding up the divisors
        delta_n = 10
        epsilon_n = 10

        try:
            while used_epsilon > self.pod_dp.epsilon or used_delta > self.pod_dp.delta:
                # Configure privacy
                # Note that the parameters are per-column maximums
                privacy = Privacy(
                    epsilon=dp._dp_config.epsilon / epsilon_div,
                    delta=dp._dp_config.delta / delta_div,
                )
                # Pre-flight the sql query, and compute the privacy cost
                reader = snsql.from_df(df, privacy=privacy, metadata=meta)
                used_epsilon, used_delta = reader.get_privacy_cost(query)

                if used_epsilon > self.pod_dp.epsilon:
                    # Update epsilon_div to be the result of dividing the used_epsilon
                    # by the maximum allowed value by the pod, rounded up to eps_n
                    # decimals
                    epsilon_div = (
                        math.ceil(used_epsilon / self.pod_dp.epsilon * 10**epsilon_n)
                        / 10**epsilon_n
                    )
                    epsilon_n -= 1

                if used_delta > self.pod_dp.delta and delta_n > 1:
                    # Update delta_div to be the result of dividing the used_delta
                    # by the maximum allowed value by the pod, rounded up to delta_n
                    # decimals
                    delta_div = (
                        math.ceil(used_delta / self.pod_dp.delta * 10**delta_n)
                        / 10**delta_n
                    )
                    delta_n -= 1
                elif used_delta > self.pod_dp.delta and delta_n <= 1:
                    # On the last loop, do a bigger division for the delta.
                    delta_div = (
                        math.ceil(used_delta / self.pod_dp.delta * 10**delta_n)
                        / 10**delta_n
                    ) * 10
                    delta_n -= 1
                # If any of delta_n or epsilon_n are 0, then we have reached
                # the end of our loop, and we raise an error to the user.
                if delta_n < 0:
                    raise PrivateSqlError(
                        "Cannot execute current query given the provided privacy "
                        f"parameter delta={self.delta}). Try again using a "
                        f"smaller value of delta."
                    )
                if epsilon_n < 0:
                    raise PrivateSqlError(
                        "Cannot execute current query given the provided privacy "
                        f"parameter epsilon={self.epsilon}. Try again using a "
                        f"smaller epsilon value."
                    )

            logger.federated_info(
                "Total privacy cost for query will be "
                f"(epsilon={used_epsilon}, delta={used_delta})"
            )
            logger.federated_info(
                # pyrefly: ignore[unbound-name]
                f"Executing SQL query with epsilon {privacy.epsilon} "
                # pyrefly: ignore[unbound-name]
                f"and delta {privacy.delta} applied on each queried column."
            )
            # pyrefly: ignore[unbound-name]
            output = reader.execute(query)

        except Exception as ex:
            if isinstance(ex, PrivateSqlError):
                raise
            raise PrivateSqlError(
                f"Error executing PrivateSQL query: [{self.query}], got error [{ex}]"
            ) from ex

        return pd.DataFrame(output[1:], columns=output[0])

    def _generate_sql(self, table_name: str) -> str:
        """Generate SQL from structured parameters.

        The table_name should be the original (unsanitized) name. This method
        will wrap it in backticks for the initial query. The query will be
        sanitized later by _prepare_query_and_metadata() which removes both
        hyphens and backticks.

        Args:
            table_name: The name of the table to query (original, with hyphens).

        Returns:
            Generated SQL query string with backticks around identifiers.

        Raises:
            ValueError: If structured parameters are incomplete or invalid.
        """
        _validate_structured_sql_params(
            self.query,
            self.aggregate_columns,
            self.group_by_columns,
            self.aggregation_func,
        )

        agg_func = self.aggregation_func.upper()  # type: ignore[union-attr]

        agg_exprs = [
            f"{agg_func}(`{col}`) AS {agg_func.lower()}_{self._sanitize_identifier(col)}"  # noqa: E501
            for col in self.aggregate_columns  # type: ignore[union-attr]
        ]

        group_by_cols = ", ".join(
            f"`{col}`"
            for col in self.group_by_columns  # type: ignore[union-attr]
        )
        agg_cols = ", ".join(agg_exprs)

        # SmartNoise SQL expects table reference as `schema`.`table` format.
        # We use `table`.`table` to match the metadata structure.
        # SQL constructed from validated schema columns, not user input
        return (
            f"SELECT {group_by_cols}, {agg_cols} "  # nosec hardcoded_sql_expressions
            f"FROM `{table_name}`.`{table_name}` "
            f"GROUP BY {group_by_cols}"
        )

    def _get_effective_query(self) -> str:
        """Get the SQL query to execute, either from raw query or generated."""
        if self.query:
            return self.query

        if self.table is None:
            raise ValueError(
                "Table name required for SQL generation. "
                "Specify 'table' parameter or use raw 'query'."
            )
        return self._generate_sql(self.table)

    # pyrefly: ignore[bad-override]
    def run(self, **kwargs: Any) -> pd.DataFrame:
        """Executes the SQL query on the `BaseSource`."""
        logger.info("Executing query...")
        schema = self._validate_run_preconditions()
        dp = self._configure_dp()

        df = load_data_in_memory(self.datasource)

        self._validate_columns_against_schema(df)

        if not self.query:
            self.query = self._get_effective_query()

        bounds_from_winsorization = False
        if not self.column_ranges:
            logger.info(
                "column_ranges not provided, computing bounds using Winsorization "
                f"({self.lower_percentile}th/{self.upper_percentile}th percentile)"
            )
            self.column_ranges = self._compute_bounds_with_winsorization(df, schema)
            bounds_from_winsorization = True

        query, meta = self._prepare_query_and_metadata(
            df, schema, bounds_from_winsorization
        )
        # Check for collisions before sanitizing DataFrame column names
        self._check_sanitized_column_collisions(list(df.columns))
        # Sanitize DataFrame column names to match sanitized query identifiers
        df.columns = [self._sanitize_identifier(col) for col in df.columns]
        return self._execute_dp_query(df, query, meta, dp)


@delegates()
class PrivateSqlQuery(
    BaseNonModelAlgorithmFactory[ResultsOnlyModellerAlgorithm, _WorkerSide],
    _ModellessAlgorithmMixIn,
):
    """Simple algorithm for running a SQL query on a table, with privacy.

    :::note

    The values provided for the privacy budget (i.e. epsilon and delta)
    will be applied individually to all columns included in the SQL query provided.
    If the total values of the epsilon and delta exceed the maximum allowed by the pod,
    the provided values will be reduced to the maximum values required to remain
    within the allowed privacy budget.

    :::

    Args:
        datastructure: The data structure to use for the algorithm.
        query: The SQL query to execute. Note that smartnoise SQL requires
            the table name to be specified in backticks (``) in the query,
            and it does not allow expressions in the query.
        epsilon: The maximum epsilon to use for the privacy budget.
        delta: The target delta to use for the privacy budget.
        column_ranges: Optional dictionary of column names and their ranges.
            If not provided, bounds are computed using Winsorization.
        table: The target table name. For single table pod datasources,
            this will default to the pod name.
        db_schema: The name of the schema for a database connection. If
            not provided, it will be set to the default schema name
            for the database.
        lower_percentile: Lower percentile for Winsorization bounds (default: 1.0).
        upper_percentile: Upper percentile for Winsorization bounds (default: 99.0).

    Attributes:
        query: The SQL query to execute.
        epsilon: The maximum epsilon to use for the privacy budget.
        delta: The target delta to use for the privacy budget.
        column_ranges: A dictionary of column names and their ranges.
        table: The target table name. For single table pod datasources,
            this will default to the pod name.
        db_schema: The name of the schema for a database connection. If
            not provided, it will be set to the default schema name
            for the database.
        lower_percentile: Lower percentile for Winsorization bounds.
            Should be a number between 0 and 100. Defaults to 1.0.
        upper_percentile: Upper percentile for Winsorization bounds.
             Should be a number between 0 and 100. Defaults to 99.0.

    Raises:
        PrivateSqlError: If there is an error executing the private SQL query (e.g. DP
            misconfiguration or bad query specified).
        ValueError: If a pod identifier is not supplied, or if a join is attempted.
        DatabaseSchemaNotFoundError: If a non-existent db_schema name is provided.
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "query": fields.Str(allow_none=True),
        "epsilon": fields.Float(allow_nan=True),
        "delta": fields.Float(allow_nan=True),
        "column_ranges": fields.Dict(allow_none=True),
        "table": fields.Str(allow_none=True),
        "db_schema": fields.Str(allow_none=True),
        "lower_percentile": fields.Float(allow_none=True),
        "upper_percentile": fields.Float(allow_none=True),
        "aggregate_columns": fields.List(fields.Str(), allow_none=True),
        "group_by_columns": fields.List(fields.Str(), allow_none=True),
        "aggregation_func": fields.Str(
            allow_none=True,
            validate=_validate_aggregation_func,
        ),
    }

    _inference_algorithm: bool = False

    def __init__(
        self,
        *,
        datastructure: DataStructure,
        query: Optional[str] = None,
        epsilon: float,
        delta: float,
        column_ranges: Optional[ColumnRangesType] = None,
        table: Optional[str] = None,
        db_schema: Optional[str] = None,
        lower_percentile: Optional[float] = None,
        upper_percentile: Optional[float] = None,
        aggregate_columns: Optional[list[str]] = None,
        group_by_columns: Optional[list[str]] = None,
        aggregation_func: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(datastructure=datastructure, **kwargs)

        _validate_structured_sql_params(
            query, aggregate_columns, group_by_columns, aggregation_func
        )

        self.query = query
        self.epsilon = epsilon
        self.delta = delta
        self.column_ranges = column_ranges
        self.table = table
        self.db_schema = db_schema
        self.aggregate_columns = aggregate_columns
        self.group_by_columns = group_by_columns
        self.aggregation_func = aggregation_func

        resolved_lower = lower_percentile if lower_percentile is not None else 1.0
        resolved_upper = upper_percentile if upper_percentile is not None else 99.0

        if not 0 <= resolved_lower <= 100:
            logger.warning(
                f"lower_percentile must be between 0 and 100, got {resolved_lower}. "
                "Using default value of 1.0"
            )
            resolved_lower = 1.0

        if not 0 <= resolved_upper <= 100:
            logger.warning(
                f"upper_percentile must be between 0 and 100, got {resolved_upper}. "
                "Using default value of 99.0"
            )
            resolved_upper = 99.0
        if resolved_lower >= resolved_upper:
            logger.warning(
                f"lower_percentile ({resolved_lower}) must be less than "
                f"upper_percentile ({resolved_upper}). "
                "Using default values of 1.0 and 99.0"
            )
            resolved_lower = 1.0
            resolved_upper = 99.0

        self.lower_percentile = resolved_lower
        self.upper_percentile = resolved_upper

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> ResultsOnlyModellerAlgorithm:
        """Returns the modeller side of the PrivateSqlQuery algorithm.

        Args:
            context: Optional. Run-time protocol context details for running.
            **kwargs: Additional keyword arguments to pass to the modeller side.
        """
        return ResultsOnlyModellerAlgorithm(**kwargs)

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Returns the worker side of the PrivateSqlQuery algorithm.

        Args:
            context: Optional. Run-time protocol context details for running.
            **kwargs: Additional keyword arguments to pass to the worker side. `hub`
                must be one of these keyword arguments which provides a `BitfountHub`
                instance.
        """
        return _WorkerSide(
            query=self.query,
            epsilon=self.epsilon,
            delta=self.delta,
            column_ranges=self.column_ranges,
            table=self.table,
            db_schema=self.db_schema,
            lower_percentile=self.lower_percentile,
            upper_percentile=self.upper_percentile,
            aggregate_columns=self.aggregate_columns,
            group_by_columns=self.group_by_columns,
            aggregation_func=self.aggregation_func,
            **kwargs,
        )
