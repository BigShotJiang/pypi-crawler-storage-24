"""Base classes and utilities for post-processors."""

from __future__ import annotations

import ast
from enum import Enum, unique
import inspect
import json
import logging
import re
from typing import Any, ClassVar, Optional, Type, TypeVar, Union

import pandas as pd

from bitfount.types import PredictReturnType

logger = logging.getLogger(__name__)


__all__: list[str] = [
    "PostProcessor",
    "PostprocessorType",
    "CompoundPostProcessor",
    "create_postprocessor",
    "create_postprocessors",
    "apply_postprocessors",
    "parse_json",
    "get_matching_columns",
    "POSTPROCESSING_PRESETS",
]


@unique
class PostprocessorType(str, Enum):
    """Types of built-in postprocessors."""

    RENAME = "rename"  # Rename DataFrame columns
    TRANSFORM = (
        "transform"  # Apply transformations from bitfount.transformations # noqa: E501
    )
    JSON_RESTRUCTURE = (
        "json_restructure"  # Restructure JSON data by moving fields between levels
    )
    STRING_TO_JSON = "string_to_json"  # Convert string columns to JSON objects
    JSON_KEY_RENAME = (
        "json_key_rename"  # Rename keys within JSON data stored in columns
    )
    JSON_WRAP_IN_LIST = (
        "json_wrap_in_list"  # Wrap JSON data in an additional list layer
    )
    HUGGINGFACE_APPLY_ID_TO_LABELS = (
        "huggingface_apply_id_to_labels"  # Apply ID to labels for Hugging Face models
    )
    NER_DEIDENTIFICATION = (
        "ner_deidentification"  # De-identify by replacing entities with placeholders
    )
    COMPOUND = "compound"  # Apply multiple postprocessors in sequence


#############################################################################
# Compound Postprocessor Presets
#############################################################################

PATHOLOGY_TO_SEGMENTATION_TRANSFORMATION = {
    "type": "compound",
    "name": "pathology_to_segmentation",
    "postprocessing_sequence": [
        {
            "type": "string_to_json",
            "column_patterns": [r"Pixel_Data_\d+_prediction"],
        },
        {
            "type": "json_restructure",
            "column_patterns": [r"Pixel_Data_\d+_prediction"],
            "field_mappings": [
                {"source_path": "metadata", "target_path": "mask.metadata"},
                {
                    "source_path": "classes.choroidal_neovascularization",
                    "target_path": "choroidal_neovascularization",
                },
            ],
        },
        {
            "type": "json_key_rename",
            "column_patterns": [r"Pixel_Data_\d+_prediction"],
            "key_mappings": [
                {
                    "source_key": "choroidal_neovascularization",
                    "target_key": "cnv_probability",
                }
            ],
            "recursive": True,
        },
    ],
}


RETINAL_LAYERS_TO_SEGMENTATION_TRANSFORMATION = {
    "type": "compound",
    "name": "retinal_layers_to_segmentation",
    "postprocessing_sequence": [
        {
            "type": "string_to_json",
            "column_patterns": [r"Pixel_Data_\d+_prediction"],
        },
        {
            "type": "json_restructure",
            "column_patterns": [r"Pixel_Data_\d+_prediction"],
            "field_mappings": [
                {
                    "source_path": "instances",
                    "target_path": "mask.instances",
                },
                {
                    "source_path": "metadata",
                    "target_path": "mask.metadata",
                },
            ],
        },
    ],
}


# Global registry for transformation presets
POSTPROCESSING_PRESETS: dict[str, Any] = {
    "pathology_to_segmentation": PATHOLOGY_TO_SEGMENTATION_TRANSFORMATION,
    "retinal_layers_to_segmentation": RETINAL_LAYERS_TO_SEGMENTATION_TRANSFORMATION,
}

#############################################################################
# Postprocessor base class
#############################################################################

# Global registry for postprocessors
POSTPROCESSOR_REGISTRY: dict[PostprocessorType, Type] = {}

# TypeVar for the postprocessor class
T = TypeVar("T", bound="PostProcessor")


class PostProcessor:
    """Base class that all postprocessors inherit from."""

    _processor_type: ClassVar[Optional[PostprocessorType]] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Automatically register subclasses when they are defined."""
        super().__init_subclass__(**kwargs)

        if not inspect.isabstract(cls):
            processor_type = getattr(cls, "_processor_type", None)
            if processor_type is not None:
                if processor_type in POSTPROCESSOR_REGISTRY:
                    logger.warning(
                        f"Postprocessor type {processor_type} already "
                        f"registered. Overwriting."
                    )
                logger.debug(f"Adding {cls.__name__}: {cls} to PostProcessor registry")
                POSTPROCESSOR_REGISTRY[processor_type] = cls

    def process(
        self, predictions: Union[PredictReturnType, pd.DataFrame]
    ) -> Union[PredictReturnType, pd.DataFrame, Any]:
        """Process the model predictions."""
        raise NotImplementedError("Subclasses must implement process()")


#############################################################################
# Factory functions
#############################################################################


def create_postprocessor(
    config: dict[str, Any],
    access_token: Optional[str] = None,
) -> Optional[PostProcessor]:
    """Create a postprocessor from a configuration dictionary.

    Args:
        config: Postprocessor configuration with 'type' and other parameters
        access_token: An optional HuggingFace access token

    Returns:
        An instance of the requested postprocessor or None if there is an
            error when creating it.
    """
    if "type" not in config:
        logger.error("Postprocessor configuration must include 'type'")
        return None

    processor_type = config["type"]
    post_processor_type: Optional[PostprocessorType] = None

    # Convert string to enum if needed
    if isinstance(processor_type, str):
        try:
            post_processor_type = PostprocessorType(processor_type.lower())
        except ValueError:
            logger.error(f"Unknown postprocessor type: {processor_type}")
            return None
    elif isinstance(processor_type, PostprocessorType):
        post_processor_type = processor_type
    else:
        logger.error(f"Unknown postprocessor type: {processor_type}")
        return None

    if post_processor_type not in POSTPROCESSOR_REGISTRY or post_processor_type is None:
        logger.error(f"Unsupported postprocessor type: {processor_type}")
        return None

    processor_class = POSTPROCESSOR_REGISTRY[post_processor_type]

    # Create a copy of the config to modify
    config_copy = config.copy()
    # Remove 'type' to avoid passing it to constructor, this is not used
    config_copy.pop("type")

    # Inject HuggingFace access token to post processors that accept it
    if "huggingface" in post_processor_type.value and access_token is not None:
        config_copy["access_token"] = access_token

    try:
        processor: PostProcessor = processor_class(**config_copy)
        return processor
    except TypeError as e:
        logger.error(f"Failed to instantiate {processor_type} postprocessor: {e}")
        return None


def create_postprocessors(
    postprocessor_configs: Optional[list[dict[str, Any]]] = None,
    access_token: Optional[str] = None,
) -> list[PostProcessor]:
    """Create a list of postprocessors from configurations.

    Args:
        postprocessor_configs: Configuration for postprocessors, either:
            - None (returns an empty list)
            - A list of dicts, each with 'type' and other parameters
        access_token: An optional HuggingFace access token

    Returns:
        List of PostProcessors.
    """
    if postprocessor_configs is None:
        return []
    # Create postprocessors from each config
    postprocessors = []
    for config in postprocessor_configs:
        if (
            config.get("type") == "compound"
            and config.get("name") in POSTPROCESSING_PRESETS
        ):
            preset_name = config.get("name")
            if isinstance(preset_name, str):
                # Use preset if available
                preset = POSTPROCESSING_PRESETS[preset_name]
                postprocessor = create_postprocessor(preset, access_token)
            else:
                postprocessor = None
                logger.warning("Preset name is not a string, skipping.")
        else:
            postprocessor = create_postprocessor(config, access_token)

        if postprocessor is not None:
            postprocessors.append(postprocessor)
    return postprocessors


def apply_postprocessors(postprocessors: list[PostProcessor], predictions: Any) -> Any:
    """Apply a list of postprocessors to predictions in sequence.

    Args:
        postprocessors: List of postprocessors to apply.
        predictions: Model predictions to process.

    Returns:
        Processed predictions
    """
    result = predictions
    for i, postprocessor in enumerate(postprocessors):
        try:
            result = postprocessor.process(result)
        except Exception as e:
            # Continue with current result rather than failing
            logger.error(f"Error in postprocessor {i + 1}: {e}")
    return result


#############################################################################
# Common utility methods for postprocessors
#############################################################################


def parse_json(value: Any) -> Any:
    """Parse JSON data from various formats.

    Args:
        value: The value to parse.

    Returns:
        Parsed JSON object or original value if parsing fails.
    """
    if isinstance(value, str):
        try:
            # Try standard JSON parsing
            return json.loads(value)
        except json.JSONDecodeError:
            try:
                # Try parsing as Python literal (with single quotes)
                return ast.literal_eval(value)
            except (ValueError, SyntaxError):
                logger.warning(
                    f"Failed to parse as JSON or Python literal: {value[:100]}..."
                )
                return value
    else:
        logger.debug("Value is not a string, returning as is.")
        # Already parsed or not a string
        return value


def get_matching_columns(all_columns: list[str], patterns: list[str]) -> list[str]:
    """Get column names matching the given patterns.

    Args:
        all_columns: List of all column names.
        patterns: List of regex patterns to match.

    Returns:
        List of column names that match at least one pattern.
    """
    target_columns = []

    for pattern in patterns:
        try:
            regex = re.compile(pattern)
            matches = [col for col in all_columns if regex.search(col)]
            target_columns.extend(matches)
        except re.error as e:
            logger.error(f"Invalid regex pattern '{pattern}': {e}")

    # Deduplicate columns
    return list(set(target_columns))


#############################################################################
# Compound postprocessor class
#############################################################################


class CompoundPostProcessor(PostProcessor):
    """Applies multiple postprocessors in sequence."""

    _processor_type = PostprocessorType.COMPOUND

    def __init__(
        self,
        postprocessing_sequence: list[dict[str, Any]],
        name: Optional[str] = None,
    ) -> None:
        """Initialize the compound postprocessor.

        Args:
            postprocessing_sequence: List of postprocessor configurations
                to apply in a sequence
            name: Name as a string for the for this transformation
                pipeline. Default to None.
        """
        self.postprocessing_sequence = postprocessing_sequence
        self.name = name or "CompoundTransformation"

        # Create all the postprocessors
        self.processors: list[PostProcessor] = []
        for config in self.postprocessing_sequence:
            try:
                processor = create_postprocessor(config)
                if processor is not None:
                    self.processors.append(processor)
            except Exception as e:
                logger.error(f"Failed to create postprocessor: {e}")
                continue

    def process(self, predictions: Any) -> Any:
        """Apply all postprocessors in sequence."""
        logger.debug(f"Processing with CompoundPostProcessor: {self.name}")
        logger.debug(f"Input type: {type(predictions)}")

        result = predictions
        # Apply each postprocessor in sequence
        for i, processor in enumerate(self.processors):
            if processor is not None:
                processor_name = processor.__class__.__name__
                try:
                    logger.debug(
                        f"Applying processor {i + 1}/{len(self.processors)}:"
                        f" {processor_name}"
                    )

                    result = processor.process(result)
                    logger.debug(
                        f"After processor {i + 1}: {processor_name}, "
                        f"result type: {type(result)}"
                    )
                except Exception as e:
                    logger.error(
                        f"Error in processor {i + 1}: {e}. "
                        f"Skipping processor {processor_name}."
                    )
                    continue
        return result
