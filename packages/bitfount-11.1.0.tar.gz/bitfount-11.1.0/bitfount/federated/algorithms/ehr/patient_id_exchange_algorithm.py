"""Patient ID Exchange algorithm for initial setup.

This algorithm handles the exchange of patient IDs from modeller to worker
during the initial setup phase, before any batching occurs.
"""

from __future__ import annotations

import io
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Optional, cast

import pandas as pd

from bitfount.data.datasources.base_source import BaseSource
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
    NoResultsModellerAlgorithm,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.privacy.differential import DPPodConfig
from bitfount.federated.types import ProtocolContext
from bitfount.types import T_FIELDS_DICT
from bitfount.utils.encoding_utils import (
    read_text_with_encoding_fallback,
    strip_bom_from_text,
)
from bitfount.utils.pandas_utils import find_patient_id_column
from bitfount.utils.pii_redaction import anonymise_patient_id

_logger = _get_federated_logger(__name__)


class _ModellerSide(NoResultsModellerAlgorithm):
    """Modeller side of the patient ID exchange algorithm.

    This class implements InitialSetupModellerAlgorithm protocol by providing
    the required methods (remote_modeller property and values_to_send_to_worker
    method).
    """

    def __init__(
        self,
        patient_ids_file: Optional[os.PathLike[str] | str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the modeller-side algorithm.

        Args:
            patient_ids_file: Path to CSV file containing patient IDs (with or
                without a "Patient ID" header).
            **kwargs: Additional keyword arguments.
        """
        super().__init__(log_message="Patient ID Exchange", **kwargs)

        if patient_ids_file is None:
            raise ValueError(f"Missing Patient IDs File {patient_ids_file=}.")

        self._patient_ids = self._extract_patient_ids_from_file(patient_ids_file)

        if not self._patient_ids:
            _logger.error("No valid (non-empty) patient IDs found")
            raise ValueError(
                "No valid (non-empty) patient IDs found. "
                "Please provide at least one non-empty patient ID."
            )
        else:
            _logger.info(
                f"Initiating data transfer for {len(self._patient_ids)} patients."
            )

    @classmethod
    def _extract_patient_ids_from_file(
        cls,
        patient_ids_file: os.PathLike[str] | str,
    ) -> list[str]:
        """Extract patient IDs from a CSV file.

        Supports CSV with or without a header row. If present, a column named
        "Patient ID", "patient_id", or similar is used; otherwise the first
        column is used.

        Encoding is inferred via read_text_with_encoding_fallback
        (utf-8-sig, utf-8, cp1252, latin-1) so the file can be saved in any of these.

        Args:
            patient_ids_file: Path to CSV file containing patient ID strings.

        Returns:
            List of patient ID strings extracted from the file.
        """
        # Read file and decode in fallback manner
        path = Path(patient_ids_file)
        _logger.debug(f"Extracting patient IDs from {path}")
        text, encoding_used = read_text_with_encoding_fallback(path)
        _logger.debug(f"Decoded patient IDs file with encoding: {encoding_used}")

        try:
            df_raw = pd.read_csv(
                io.StringIO(text),
                header=None,
                dtype=str,
                keep_default_na=False,
            )
        except pd.errors.EmptyDataError:
            _logger.warning("CSV has no data rows")
            return []

        if df_raw.empty:
            _logger.warning("CSV has no data rows")
            return []

        # Build a DataFrame with first row as column names so we can
        # use find_patient_id_column()
        first_row_as_names = [str(v).strip() for v in df_raw.iloc[0].tolist()]
        df_header = pd.DataFrame(columns=first_row_as_names)
        patient_col_name = find_patient_id_column(df_header)
        if patient_col_name is not None:
            # First row is a header; use that column and drop the header row
            col_idx = first_row_as_names.index(patient_col_name)
            series = df_raw.iloc[1:, col_idx]
            _logger.debug(f"Using column '{patient_col_name}' for patient IDs")
        else:
            # No header row; use first column for all rows
            series = df_raw.iloc[:, 0]
            _logger.debug("No header row detected; using first column for all rows")

        # Strip whitespace, drop empty, unique (BOM already stripped by decoding)
        values = (str(v).strip() for v in series.dropna().astype(str))
        result = list({v for v in values if v})
        _logger.debug(f"Extracted {len(result)} patient ID(s) from file")
        return result

    @property
    def remote_modeller(self) -> bool:
        """Whether the algorithm needs to accommodate a remote modeller.

        Always True for this algorithm as patient IDs are always sent from
        modeller to worker.
        """
        return True

    def values_to_send_to_worker(self) -> dict[str, Any]:
        """Get the patient IDs to send to the worker side."""
        return {"patient_ids": self._patient_ids}


class _WorkerSide(BaseWorkerAlgorithm):
    """Worker side of the patient ID exchange algorithm.

    This class implements InitialSetupWorkerAlgorithm protocol by providing
    the required methods (remote_modeller property, setup_run method, and
    update_values_from_modeller method).
    """

    def __init__(
        self,
        **kwargs: Any,
    ) -> None:
        """Initialize the worker-side algorithm.

        Args:
            **kwargs: Additional keyword arguments.
        """
        super().__init__(**kwargs)
        self._patient_ids: Optional[list[str]] = None

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Does nothing for this algorithm."""
        pass

    @property
    def remote_modeller(self) -> bool:
        """Whether the algorithm needs to accommodate a remote modeller.

        Always True for this algorithm as patient IDs are always sent from
        modeller to worker.
        """
        return True

    def setup_run(self, **kwargs: Any) -> None:
        """Run setup operations before batching begins.

        This method is called by protocols tagged with InitialSetupWorkerProtocol
        before any batching occurs. For this algorithm, it's a no-op as the
        patient IDs are received via update_values_from_modeller().
        """
        # No setup needed - patient IDs are received via update_values_from_modeller
        pass

    @property
    def should_output_data(self) -> bool:
        """Indicates whether the initial setup algorithm should output data.

        For the most part initial setup algorithms will set up data, filtering it,
        grouping it, etc., and so this property should return True. However, there are
        some algorithms that don't produce any data (e.g., algorithms that use the
        initial setup phase to exchange runtime information) and so this property
        should return False.'
        """
        # This algorithm doesn't produce/set any data, is just used to exchange the
        # patient IDs before running. Return False.
        return False

    def update_values_from_modeller(self, values: dict[str, Any]) -> None:
        """Update the patient IDs sent from the modeller side."""
        if "patient_ids" not in values:
            _logger.error(
                "No patient_ids found in values from modeller. "
                "This may cause issues downstream."
            )
            self._patient_ids = []
        else:
            raw = cast(list[str], values["patient_ids"])
            # Log anonymised IDs; hyphens/underscores kept to help debug encoding
            _logger.info(
                "Patient IDs received from modeller (anonymised): %s",
                [anonymise_patient_id(pid) for pid in raw],
            )
            # Defensively strip BOM and BOM mojibake on each ID (in case modeller
            # sent BOM-prefixed or file was decoded as Latin-1 so ï»¿ appears)
            self._patient_ids = [
                strip_bom_from_text(pid) if pid else pid for pid in raw
            ]
            self._patient_ids = [pid for pid in self._patient_ids if pid]
            _logger.info(
                f"Received {len(self._patient_ids)} patient ID(s) from modeller"
            )

    def run(self, *args: Any, **kwargs: Any) -> None:
        """Regular run method - does nothing as this is only for initial setup."""
        pass

    @property
    def patient_ids(self) -> Optional[list[str]]:
        """Get the patient IDs received from the modeller."""
        return self._patient_ids


class PatientIDExchangeAlgorithm(
    BaseNonModelAlgorithmFactory[_ModellerSide, _WorkerSide]
):
    """Algorithm for exchanging patient IDs during initial setup.

    This algorithm handles the exchange of patient IDs from modeller to worker
    during the initial setup phase, before any batching occurs. It should be
    used as the first algorithm in protocols that need to send patient IDs to
    workers.

    Args:
        datastructure: The data structure definition.
        patient_ids_file: Path to CSV file containing patient IDs (with or without
            a header).
        **kwargs: Additional keyword arguments.
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        # Note: patient_ids_file are intentionally NOT in fields_dict
        # to prevent them from being serialized in the task definition.
        # They are only used on the modeller side and sent via initial setup exchange.
    }

    def __init__(
        self,
        datastructure: DataStructure,
        patient_ids_file: Optional[os.PathLike[str] | str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the algorithm.

        Args:
            datastructure: The data structure definition.
            patient_ids_file: Path to CSV file containing patient IDs (with or without
                a header).
            **kwargs: Additional keyword arguments.
        """
        super().__init__(datastructure=datastructure, **kwargs)
        self.patient_ids_file = patient_ids_file

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _ModellerSide:
        """Modeller-side of the algorithm."""
        return _ModellerSide(
            patient_ids_file=self.patient_ids_file,
            **kwargs,
        )

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Worker-side of the algorithm."""
        return _WorkerSide(**kwargs)


if TYPE_CHECKING:
    # Type checking to verify that the classes correctly implement the Protocol
    # interfaces. These assertions will be checked by type checkers.
    from bitfount.federated.algorithms.base import (
        InitialSetupModellerAlgorithm,
        InitialSetupWorkerAlgorithm,
    )

    # Verify _ModellerSide implements InitialSetupModellerAlgorithm
    _modeller_side_check: InitialSetupModellerAlgorithm = _ModellerSide(
        patient_ids_file="test.csv", log_message="test"
    )

    # Verify _WorkerSide implements InitialSetupWorkerAlgorithm
    _worker_side_check: InitialSetupWorkerAlgorithm = _WorkerSide()
