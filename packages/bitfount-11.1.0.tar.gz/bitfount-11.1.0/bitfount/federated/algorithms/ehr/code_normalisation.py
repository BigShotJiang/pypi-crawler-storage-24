"""Normalise patient condition codes to ICD10."""

from __future__ import annotations

import re
import sqlite3
from typing import Any, ClassVar, Optional, cast

from bitfount import config
from bitfount.data.datasources.base_source import BaseSource
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.externals.ehr.types import Condition
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
    NoResultsModellerAlgorithm,
)
from bitfount.federated.algorithms.ehr.ehr_base_algorithm import PatientDetails
from bitfount.federated.algorithms.ehr.ehr_patient_query_algorithm import (
    PatientQueryResults,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.privacy.differential import DPPodConfig
from bitfount.federated.types import ProtocolContext
from bitfount.types import T_FIELDS_DICT
from bitfount.utils.db_connector import DbConnector

_logger = _get_federated_logger(__name__)

_CODE_SYSTEM_NORMALISER = re.compile(r"[^a-z0-9]+")
_MAPPING_DB_FILENAME = "clinical_trials.db"
_VALID_CLINICAL_STATUSES = ["active", "recurrence", "relapse"]


def _normalise_code_system(code_system: Optional[str]) -> str:
    """Return a normalised code-system string for matching."""
    if not code_system:
        return ""
    return _CODE_SYSTEM_NORMALISER.sub("", code_system.lower())


def _dedupe_preserve_order(values: list[str]) -> list[str]:
    """Return values with duplicates removed, preserving order."""
    seen = set()
    deduped: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


class _WorkerSide(BaseWorkerAlgorithm):
    """Worker side of the code normalisation algorithm."""

    def __init__(
        self,
        **kwargs: Any,
    ) -> None:
        """Initialise the worker algorithm."""
        super().__init__(**kwargs)
        self._mapping: dict[str, list[str]] = {}

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: str,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialise worker data context."""
        self.initialise_data(datasource=datasource, data_splitter=data_splitter)
        self._mapping = self._load_snomed_to_icd10_mapping()

    def run(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> dict[PatientDetails, list[str]]:
        """Return ICD10 codes per patient from query results."""
        patient_query_results = self._get_patient_query_results(*args, **kwargs)
        missing_snomed_codes: set[str] = set()
        normalised_codes: dict[PatientDetails, list[str]] = {}

        for patient, query_results in patient_query_results.items():
            codes = self._extract_icd10_codes(
                patient=patient,
                condition_codes=query_results.codes.condition_codes,
                mapping=self._mapping,
                missing_snomed_codes=missing_snomed_codes,
            )
            normalised_codes[patient] = codes

        return normalised_codes

    def _get_patient_query_results(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> dict[PatientDetails, PatientQueryResults]:
        """Extract patient query results from positional or keyword arguments."""
        if args:
            patient_query_results = args[0]
        else:
            patient_query_results = kwargs.get("patient_query_results")
        if patient_query_results is None:
            raise ValueError("Missing patient_query_results for code normalisation")
        return cast(dict[PatientDetails, PatientQueryResults], patient_query_results)

    def _load_snomed_to_icd10_mapping(self) -> dict[str, list[str]]:
        """Load SNOMED to ICD10 mapping table into memory."""
        db_path = config.settings.paths.cache_dir / _MAPPING_DB_FILENAME
        if not db_path.exists():
            _logger.error(
                "SNOMED mapping database not found at %s",
                db_path,
            )
            raise FileNotFoundError(f"SNOMED mapping database not found at {db_path}")

        connector = DbConnector()
        try:
            connection = connector._get_db_connection(str(db_path))
        except sqlite3.Error as exc:
            _logger.error("Failed to open SNOMED mapping DB: %s", exc)
            raise

        try:
            cursor = connection.cursor()
            cursor.execute(
                "SELECT snomed_code, icd10_code FROM snomed_to_icd10_mapping"
            )
            mapping: dict[str, list[str]] = {}
            for snomed_code, icd10_code in cursor.fetchall():
                if snomed_code is None or icd10_code is None:
                    continue
                snomed_str = str(snomed_code).strip()
                icd10_str = str(icd10_code).strip()
                if not snomed_str or not icd10_str:
                    continue
                mapping.setdefault(snomed_str, []).append(icd10_str)
            return mapping
        except sqlite3.Error as exc:
            _logger.error(
                "Failed to read SNOMED mapping table "
                f"snomed_to_icd10_mapping from {db_path}: {exc}",
            )
            raise
        finally:
            connection.close()

    def _extract_icd10_codes(
        self,
        *,
        patient: PatientDetails,
        condition_codes: Optional[list[Condition]],
        mapping: dict[str, list[str]],
        missing_snomed_codes: set[str],
    ) -> list[str]:
        """Extract ICD10 codes for a patient from condition codes."""
        if not condition_codes:
            return []

        icd10_codes: list[str] = []
        for condition in condition_codes:
            code_system = _normalise_code_system(condition.code_system)
            code_value = condition.code_code

            if code_value is None or not str(code_value).strip():
                _logger.warning(
                    "Missing condition code for patient %s",
                    patient.bitfount_patient_id,
                )
                continue

            # We treat the absence of a clinical status as if the Patient
            # has the Condition, as this is a more conservative approach
            if (
                condition.clinical_status is not None
                and condition.clinical_status.lower() not in _VALID_CLINICAL_STATUSES
            ):
                continue

            code_value_str = str(code_value).strip()

            if "icd10" in code_system:
                icd10_codes.append(code_value_str)
                continue

            elif "snomed" in code_system:
                mapped = mapping.get(code_value_str)
                if not mapped:
                    if code_value_str not in missing_snomed_codes:
                        _logger.warning(
                            "No ICD10 mapping found for SNOMED code %s",
                            code_value_str,
                        )
                        missing_snomed_codes.add(code_value_str)
                    continue
                icd10_codes.extend(mapped)

            else:
                _logger.warning(f"Got unknown code system: {code_system}")

        return _dedupe_preserve_order(icd10_codes)


class CodeNormalisationAlgorithm(
    BaseNonModelAlgorithmFactory[NoResultsModellerAlgorithm, _WorkerSide]
):
    """Factory for the code normalisation algorithm."""

    fields_dict: ClassVar[T_FIELDS_DICT] = {}

    def __init__(
        self,
        datastructure: DataStructure,
        **kwargs: Any,
    ) -> None:
        """Initialise the algorithm factory."""
        super().__init__(datastructure=datastructure, **kwargs)

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> NoResultsModellerAlgorithm:
        """Return the modeller-side algorithm instance."""
        return NoResultsModellerAlgorithm(
            log_message="Running Code Normalisation Algorithm",
            **kwargs,
        )

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Return the worker-side algorithm instance."""
        return _WorkerSide(**kwargs)
