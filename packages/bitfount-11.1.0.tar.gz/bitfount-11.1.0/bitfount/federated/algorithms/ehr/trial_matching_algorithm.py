"""Algorithm for matching patients to clinical trials.

This algorithm takes a per-patient DataFrame (with ICD-10 condition codes
and demographics) and a trials DataFrame (from SqlQuery) and computes a match
score for each patient-trial pair. Score is normalized to [0, 1]: 1 = all
inclusion codes matched and no exclusion codes matched; 0 = vice versa.
Returns the top N trials per patient.
"""

from __future__ import annotations

from datetime import date, datetime
import json
import re
from typing import Any, ClassVar, Optional, Union, cast

import iso3166
from marshmallow import fields, validate
import pandas as pd
import pgeocode

from bitfount.data.datasources.base_source import BaseSource
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.datastructure import DataStructure
from bitfount.externals.ehr.fhir_r4.querier import ICD_10_SYSTEM_IDENTIFIER
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    BaseWorkerAlgorithm,
    NoResultsModellerAlgorithm,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    DOB_COL,
    ICD10_COLUMN,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.privacy.differential import DPPodConfig
from bitfount.federated.types import ProtocolContext
from bitfount.types import T_FIELDS_DICT
from bitfount.utils import delegates

logger = _get_federated_logger(__name__)

ICD10TrialCode = Union[str, frozenset[str]]

# Default number of top trials to return per patient
DEFAULT_TOP_N = 5

# Common country name aliases that iso3166 does not resolve.
# Keyed by ISO alpha-2 code (uppercase); values are uppercase aliases.
# ClinicalTrials.gov and other sources use short/colloquial names
# (e.g. "United States") that differ from the official ISO 3166 names
# (e.g. "United States of America").  The iso3166 library only recognises
# official names, so without this map those countries silently resolve to
# None and distance filtering drops every site in that country.
_COUNTRY_ALIASES: dict[str, list[str]] = {
    "US": ["UNITED STATES", "USA", "U.S.A.", "U.S."],
    "GB": ["UNITED KINGDOM", "UK", "GREAT BRITAIN", "ENGLAND", "SCOTLAND", "WALES"],
    "KR": ["SOUTH KOREA", "KOREA", "S. KOREA", "S KOREA"],
    "KP": ["NORTH KOREA", "N. KOREA", "N KOREA"],
    "RU": ["RUSSIA"],
    "CZ": ["CZECH REPUBLIC"],
    "TR": ["TURKEY"],
    "IR": ["IRAN", "PERSIA"],
    "SY": ["SYRIA"],
    "VE": ["VENEZUELA"],
    "BO": ["BOLIVIA"],
    "TZ": ["TANZANIA"],
    "VN": ["VIETNAM"],
    "LA": ["LAOS"],
    "MD": ["MOLDOVA"],
    "MK": ["MACEDONIA", "NORTH MACEDONIA"],
    "CI": ["IVORY COAST", "COTE D'IVOIRE"],
    "MM": ["BURMA"],
    "TL": ["EAST TIMOR"],
    "SZ": ["SWAZILAND"],
    "CV": ["CAPE VERDE"],
    "FM": ["MICRONESIA"],
    "MO": ["MACAU"],
    "BN": ["BRUNEI"],
    "GM": ["THE GAMBIA"],
    "TW": ["TAIWAN"],
}

# Reverse lookup: uppercase alias -> lowercase ISO alpha-2.
_ALIAS_TO_ISO: dict[str, str] = {}
for _code, _aliases in _COUNTRY_ALIASES.items():
    for _alias in _aliases:
        _ALIAS_TO_ISO[_alias] = _code.lower()


def _is_icd10_system(system: Optional[str]) -> bool:
    """Return True if the code system is ICD-10."""
    if not system:
        return False
    s = str(system).lower()
    return "icd-10" in s or "icd10" in s or s == ICD_10_SYSTEM_IDENTIFIER.lower()


def _resolve_codes_to_icd10(
    code_system: Optional[str], code: Optional[str]
) -> set[str]:
    """Resolve a (code_system, code) pair to ICD-10 codes.

    Args:
        code_system: The code system (e.g. ICD-10 URI).
        code: The code value.

    Returns:
        Set of ICD-10 code strings. Returns {code} if ICD-10 system,
        else empty.
    """
    if not code or not str(code).strip():
        return set()
    if _is_icd10_system(code_system):
        return {str(code).strip().upper()}
    return set()


def _normalize_is_inclusion(value: Any, default: bool = True) -> bool:
    """Normalize is_inclusion to bool, handling string representations.

    SQL/CSV sources often provide boolean flags as strings (e.g. "False").
    Using bool() directly treats any non-empty string as True, which would
    misclassify exclusion rows as inclusion.

    Args:
        value: Raw value (bool, str, int, float, etc).
        default: Value to use when None, pd.isna, or empty.

    Returns:
        True for inclusion, False for exclusion.
    """
    if value is None or pd.isna(value):
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        s = value.strip().lower()
        if not s:
            return default
        if s in ("false", "0", "no", "n"):
            return False
        if s in ("true", "1", "yes", "y"):
            return True
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    return default


def _normalize_country_to_iso(
    country: Optional[str],
    *,
    default_country: str,
) -> Optional[str]:
    """Map country to ISO alpha-2 for pgeocode using iso3166.

    Returns default_country when missing. Unknown values return None so that
    distance filtering is skipped rather than computed against the wrong country.

    Args:
        country: Country name or ISO alpha-2/alpha-3 code.
        default_country: Value to return when country is missing or empty.
            Injected from algorithm args; do not hardcode.

    Returns:
        ISO alpha-2 country code (lowercase).
    """
    if (
        not country
        or pd.isna(country)
        or not str(country).strip()
        or str(country).strip().upper() == "N/A"
    ):
        return default_country
    c_upper = str(country).strip().upper()

    try:
        match = iso3166.countries.get(c_upper)
        return match.alpha2.lower()
    except KeyError:
        pass

    match = iso3166.countries_by_name.get(c_upper)
    if match is not None:
        return match.alpha2.lower()

    alias_match = _ALIAS_TO_ISO.get(c_upper)
    if alias_match is not None:
        return alias_match

    return None


def _normalize_postal_for_pgeocode(postal: str, country: str) -> str:
    """Normalize postal code for pgeocode lookup.

    pgeocode/GeoNames uses 5-digit US ZIP codes; ZIP+4 (e.g. 11598-1739)
    is not in the database and returns nan. Extract the base 5-digit code.

    Args:
        postal: Raw postal or ZIP code.
        country: ISO alpha-2 country code (e.g. 'us').

    Returns:
        Normalized postal code suitable for pgeocode.
    """
    s = str(postal).strip()
    if not s:
        return s
    if country.lower() == "us":
        match = re.match(r"^(\d{5})", s)
        if match:
            return match.group(1)
    return s


def _postal_code_distance_km(
    patient_postal: str,
    patient_country: str,
    site_postal: str,
    site_country: str,
    distance_calculator: pgeocode.GeoDistance,
) -> Optional[float]:
    """Compute distance in km between two postal codes using pgeocode.

    Only works when both postal codes are in the same country.

    Args:
        patient_postal: Patient postal or ZIP code.
        patient_country: Patient country (ISO alpha-2).
        site_postal: Trial site postal or ZIP code.
        site_country: Trial site country (ISO alpha-2).
        distance_calculator: pgeocode.GeoDistance instance for the patient country.

    Returns:
        Distance in kilometres, or None if different countries or lookup failed.
    """
    if patient_country.lower() != site_country.lower():
        return None
    patient_pc = _normalize_postal_for_pgeocode(patient_postal, patient_country)
    site_pc = _normalize_postal_for_pgeocode(site_postal, site_country)
    if not patient_pc or not site_pc:
        return None
    try:
        d = distance_calculator.query_postal_code(patient_pc, site_pc)
        if d is not None and pd.notna(d):
            return float(d)
    except Exception as e:
        logger.debug(
            "Postal code distance failed for %s/%s vs %s/%s: %s",
            patient_postal,
            patient_country,
            site_postal,
            site_country,
            e,
        )
    return None


def _is_demographically_compatible(
    patient_age: Optional[int],
    patient_gender: str,
    trial: dict[str, Any],
) -> bool:
    """Check if a patient is demographically compatible with a trial."""
    if patient_age is not None:
        min_age = trial.get("minimum_age_years")
        max_age = trial.get("maximum_age_years")
        if min_age is not None and pd.notna(min_age):
            try:
                if int(patient_age) < int(min_age):
                    return False
            except (ValueError, TypeError):
                pass
        if max_age is not None and pd.notna(max_age):
            try:
                if int(patient_age) > int(max_age):
                    return False
            except (ValueError, TypeError):
                pass

    sex_eligible_raw = trial.get("sex_eligible", "ALL")
    sex_eligible = str(sex_eligible_raw).strip().upper() if sex_eligible_raw else "ALL"
    # Treat missing/NaN/empty as no sex restriction (ALL)
    if sex_eligible and sex_eligible != "ALL" and sex_eligible != "NAN":
        if patient_gender and patient_gender not in ("", "UNKNOWN", "NONE", "NAN"):
            if patient_gender != sex_eligible:
                return False

    return True


class _WorkerSide(BaseWorkerAlgorithm):
    """Worker side of the TrialMatchingAlgorithm.

    Performs in-memory matching of patient ICD-10 codes against trial
    inclusion/exclusion ICD-10 codes. Exclusion matches reduce the score.
    """

    def __init__(
        self,
        *,
        top_n: int = DEFAULT_TOP_N,
        max_distance_km: Optional[float] = None,
        default_country: str = "us",
        **kwargs: Any,
    ) -> None:
        if top_n < 0:
            raise ValueError(f"top_n must be non-negative, got {top_n}")
        if max_distance_km is not None and max_distance_km <= 0:
            raise ValueError(
                f"max_distance_km must be positive when set, got {max_distance_km}"
            )
        super().__init__(**kwargs)
        self.top_n = top_n
        self.max_distance_km = max_distance_km
        self.default_country = default_country

    def initialise(
        self,
        *,
        datasource: BaseSource,
        task_id: Optional[str] = None,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialise the algorithm.

        This algorithm does not need a datasource; data is passed at run time.

        Args:
            datasource: The datasource (unused by this algorithm).
            task_id: The task identifier.
            data_splitter: Optional data splitter.
            pod_dp: Optional differential privacy configuration.
            pod_identifier: Optional pod identifier.
            **kwargs: Additional keyword arguments.
        """
        pass

    # pyrefly: ignore[bad-override]
    def run(
        self,
        *,
        patient_df: pd.DataFrame,
        trials_df: pd.DataFrame,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Match patients to trials and return top N per patient.

        Args:
            patient_df: Per-patient DataFrame with columns:
                - BitfountPatientID
                - ICD10 (list of Condition objects with code_system, code_code)
                - date_of_birth, gender, postal_code, country
            trials_df: Trials DataFrame from SqlQuery. Supports two schemas:
                - trial_match_codes: nct_id, code_system, code, is_inclusion
                - trial_conditions: nct_id, icd10_code, is_inclusion
            **kwargs: Additional keyword arguments.

        Returns:
            DataFrame with one row per patient, with added columns for top N
            matched trials (JSON).
        """
        if patient_df.empty:
            logger.warning("Empty patient DataFrame; returning empty results")
            return patient_df

        if trials_df.empty:
            logger.warning("Empty trials DataFrame; no trials to match against")
            patient_df = patient_df.copy()
            patient_df["matched_trials"] = json.dumps([])
            return patient_df

        trials_grouped = self._group_trials(
            trials_df, default_country=self.default_country
        )

        results = []
        for _, patient_row in patient_df.iterrows():
            patient_profile = self._build_patient_profile(
                patient_row, default_country=self.default_country
            )
            matched = self._match_patient_to_trials(
                patient_profile,
                trials_grouped,
                max_distance_km=self.max_distance_km,
            )
            top_trials = matched[: self.top_n]
            results.append(
                # pyrefly: ignore[bad-argument-type]
                {
                    **{col: patient_row[col] for col in patient_df.columns},
                    "matched_trials": json.dumps(top_trials),
                }
            )

        return pd.DataFrame.from_records(results)

    @staticmethod
    def _group_trials(
        trials_df: pd.DataFrame,
        *,
        default_country: str,
    ) -> dict[str, dict[str, Any]]:
        """Group trial codes by nct_id, split by inclusion vs exclusion.

        Supports trial_match_codes schema (code_system, code, is_inclusion) and
        trial_conditions schema (icd10_code, is_inclusion).

        Args:
            trials_df: Raw trials DataFrame.
            default_country: Default when site country is missing (from algorithm args).

        Returns:
            Dictionary mapping nct_id to trial metadata + ICD-10 code sets.
        """
        has_match_codes = (
            "code_system" in trials_df.columns and "code" in trials_df.columns
        )
        has_conditions = "icd10_code" in trials_df.columns
        has_postal = "zip" in trials_df.columns or "postal_code" in trials_df.columns

        grouped: dict[str, dict[str, Any]] = {}

        for _, row in trials_df.iterrows():
            nct_id_raw = row.get("nct_id", "")
            if nct_id_raw is None or pd.isna(nct_id_raw):
                continue
            nct_id = str(nct_id_raw).strip()
            if not nct_id or nct_id.lower() in ("nan", "none", "<na>"):
                continue

            if nct_id not in grouped:
                sex_raw = row.get("sex_eligible")
                if sex_raw is None or pd.isna(sex_raw):
                    sex_eligible = "ALL"
                else:
                    sex_str = str(sex_raw).strip()
                    sex_eligible = (
                        "ALL" if not sex_str or sex_str.lower() == "nan" else sex_str
                    )
                grouped[nct_id] = {
                    "nct_id": nct_id,
                    "title": str(row.get("title", "")),
                    "status": str(row.get("status", "")),
                    "minimum_age_years": row.get("minimum_age_years"),
                    "maximum_age_years": row.get("maximum_age_years"),
                    "sex_eligible": sex_eligible,
                    "inclusion_icd10_codes": set(),
                    "exclusion_icd10_codes": set(),
                    "locations": [],
                }

            is_inclusion = _normalize_is_inclusion(row.get("is_inclusion"))

            codes_to_add: set[str] = set()

            if has_match_codes:
                code_system = row.get("code_system")
                code = row.get("code")
                if code and pd.notna(code):
                    codes_to_add.update(
                        _resolve_codes_to_icd10(
                            str(code_system).strip() if code_system else None,
                            str(code).strip(),
                        )
                    )

            if has_conditions:
                icd10_code = row.get("icd10_code")
                if icd10_code and pd.notna(icd10_code):
                    codes_to_add.add(str(icd10_code).strip())

            for c in codes_to_add:
                if is_inclusion:
                    grouped[nct_id]["inclusion_icd10_codes"].add(c)
                else:
                    grouped[nct_id]["exclusion_icd10_codes"].add(c)

            if has_postal:
                site_postal = row.get("zip") or row.get("postal_code")
                if site_postal is not None and pd.notna(site_postal):
                    site_pc = str(site_postal).strip()
                    if site_pc:
                        site_country_raw = row.get("country")
                        raw_for_norm: Optional[str] = None
                        if site_country_raw is not None and pd.notna(site_country_raw):
                            site_country = str(site_country_raw).strip()
                            if site_country:
                                raw_for_norm = site_country
                        site_cc = _normalize_country_to_iso(
                            raw_for_norm,
                            default_country=default_country,
                        )
                        loc: tuple[str, Optional[str]] = (site_pc, site_cc)
                        if loc not in grouped[nct_id]["locations"]:
                            grouped[nct_id]["locations"].append(loc)

        for trial in grouped.values():
            trial["inclusion_icd10_codes"] = _WorkerSide._expand_icd10_trial_ranges(
                trial["inclusion_icd10_codes"]
            )
            trial["exclusion_icd10_codes"] = _WorkerSide._expand_icd10_trial_ranges(
                trial["exclusion_icd10_codes"]
            )

        return grouped

    @staticmethod
    def _build_patient_profile(
        patient_row: pd.Series[Any],
        *,
        default_country: str,
    ) -> dict[str, Any]:
        """Build a patient profile from a patient row.

        Extracts ICD-10 codes from the ICD10 column (list of Condition objects).

        Args:
            patient_row: A row from the patient DataFrame.
            default_country: Default when patient country is missing
                (from algorithm args).

        Returns:
            Dictionary with patient profile including icd10_codes set.
        """
        icd10_codes: set[str] = set()
        conditions = patient_row.get(ICD10_COLUMN)
        if conditions is not None and isinstance(conditions, list):
            for cond in conditions:
                if isinstance(cond, str):
                    code = cond.strip().upper()
                    if code:
                        icd10_codes.add(code)
                    continue
                code_system = getattr(cond, "code_system", None)
                code = getattr(cond, "code_code", None)
                if code is not None:
                    icd10_codes.update(
                        _resolve_codes_to_icd10(code_system, str(code).strip())
                    )

        age: Optional[int] = None
        dob = patient_row.get("date_of_birth") or patient_row.get(DOB_COL)
        if dob and pd.notna(dob):
            try:
                if isinstance(dob, str):
                    dob_date = datetime.strptime(dob, "%Y-%m-%d").date()
                elif isinstance(dob, (datetime, date)):
                    dob_date = dob.date() if isinstance(dob, datetime) else dob
                else:
                    dob_date = None
                if dob_date:
                    today = date.today()
                    age = (
                        today.year
                        - dob_date.year
                        - ((today.month, today.day) < (dob_date.month, dob_date.day))
                    )
            except (ValueError, TypeError):
                pass

        gender_raw = patient_row.get("gender", "")
        if (
            gender_raw is None
            or pd.isna(gender_raw)
            or (isinstance(gender_raw, str) and not str(gender_raw).strip())
        ):
            gender = ""
        else:
            g = str(gender_raw).strip().upper()
            # Treat NONE, NAN, UNKNOWN as unknown (don't filter by sex).
            gender = "" if g in ("NONE", "NAN", "UNKNOWN") else g
        patient_postal_code: Optional[str] = None
        patient_country: Optional[str] = None
        postal_raw = patient_row.get("postal_code") or patient_row.get("postcode")
        if postal_raw is not None and pd.notna(postal_raw):
            pc = str(postal_raw).strip()
            if pc:
                patient_postal_code = pc
                country_raw = patient_row.get("country")
                patient_country = _normalize_country_to_iso(
                    country_raw, default_country=default_country
                )

        return {
            "icd10_codes": icd10_codes,
            "age": age,
            "gender": gender,
            "postal_code": patient_postal_code,
            "country": patient_country,
        }

    @staticmethod
    def _expand_icd10_trial_ranges(
        icd10_codes: set[str],
    ) -> set[ICD10TrialCode]:
        """Takes an ICD10 code range string and creates a frozenset of codes from it."""

        def _parse_block(block: str) -> Optional[tuple[str, int]]:
            block = block.strip().upper()
            if not block:
                return None
            letter = block[0]
            digits = block[1:]
            if not letter.isalpha() or not digits.isdigit():
                return None
            return letter, int(digits)

        output: set[ICD10TrialCode] = set()
        for raw_code in icd10_codes:
            if raw_code is None:
                continue
            code = str(raw_code).strip().upper()
            if not code:
                continue
            if "-" not in code:
                output.add(code)
                continue

            start_raw, end_raw = [part.strip().upper() for part in code.split("-", 1)]
            start_block = start_raw.split(".", 1)[0]
            end_block = end_raw.split(".", 1)[0]
            start_parsed = _parse_block(start_block)
            end_parsed = _parse_block(end_block)
            if start_parsed is None or end_parsed is None:
                logger.warning("Unable to parse ICD-10 range '%s'", code)
                output.add(code)
                continue

            start_letter, start_num = start_parsed
            end_letter, end_num = end_parsed
            if (start_letter, start_num) > (end_letter, end_num):
                logger.warning("ICD-10 range start after end: '%s'", code)
                output.add(code)
                continue

            expanded_range: set[str] = set()
            for letter_ord in range(ord(start_letter), ord(end_letter) + 1):
                letter = chr(letter_ord).upper()
                if letter == start_letter and letter == end_letter:
                    num_start = start_num
                    num_end = end_num
                elif letter == start_letter:
                    num_start = start_num
                    num_end = 99
                elif letter == end_letter:
                    num_start = 0
                    num_end = end_num
                else:
                    num_start = 0
                    num_end = 99
                for num in range(num_start, num_end + 1):
                    expanded_range.add(f"{letter}{num:02d}.*")
            output.add(frozenset(expanded_range))

        return output

    @staticmethod
    def _flatten_icd10_trial_codes(
        icd10_codes: set[ICD10TrialCode],
    ) -> set[str]:
        """Flattens any nested sets before matching."""
        flat: set[str] = set()
        for code in icd10_codes:
            if isinstance(code, str):
                if code:
                    flat.add(code)
                continue
            if isinstance(code, frozenset):
                flat.update({entry for entry in code if entry})
                continue
            logger.warning(
                "Unexpected ICD-10 code entry type: %s",
                type(code),
            )
        return flat

    @staticmethod
    def _match_icd10_codes(
        patient_codes: set[str],
        trial_codes: set[str],
    ) -> set[str]:
        """Matches patient ICD10 codes to trial ICD10 codes, with wildcard support."""
        matched: set[str] = set()
        for patient_code in patient_codes:
            if patient_code in trial_codes:
                matched.add(patient_code)
                continue
            prefix = patient_code.split(".", 1)[0]
            wildcard = f"{prefix}.*"
            if wildcard in trial_codes:
                matched.add(patient_code)
        return matched

    @staticmethod
    def _match_patient_to_trials(
        patient_profile: dict[str, Any],
        trials_grouped: dict[str, dict[str, Any]],
        *,
        max_distance_km: Optional[float] = None,
    ) -> list[dict[str, Any]]:
        """Match a single patient to all trials via ICD-10 code overlap.

        Args:
            patient_profile: Patient profile with icd10_codes, age, gender, etc.
            trials_grouped: Grouped trial data from _group_trials.
            max_distance_km: Optional max distance to nearest trial site.

        Returns:
            Sorted list of trial match results (highest score first).
        """
        patient_icd10: set[str] = patient_profile["icd10_codes"]
        patient_age = patient_profile["age"]
        patient_gender = patient_profile["gender"]
        patient_postal: Optional[str] = patient_profile.get("postal_code")
        patient_country: Optional[str] = patient_profile.get("country")

        check_distance = (
            max_distance_km is not None
            and patient_postal is not None
            and patient_country is not None
        )
        distance_calculator = (
            pgeocode.GeoDistance(patient_country)
            if check_distance and patient_country is not None
            else None
        )

        scored_trials: list[dict[str, Any]] = []

        for nct_id, trial in trials_grouped.items():
            # 1. Demographic filter (cheap — no I/O).
            if not _is_demographically_compatible(patient_age, patient_gender, trial):
                continue

            # 2. ICD-10 code matching (cheap — set operations).
            #    Done BEFORE distance so the expensive pgeocode lookups only
            #    run on the small subset of trials whose conditions match.
            inclusion_icd10_raw = trial.get("inclusion_icd10_codes", set())
            if not inclusion_icd10_raw:
                continue

            inclusion_icd10 = _WorkerSide._flatten_icd10_trial_codes(
                cast(set[ICD10TrialCode], inclusion_icd10_raw)
            )
            if not inclusion_icd10:
                continue

            matched_inclusion = _WorkerSide._match_icd10_codes(
                patient_icd10,
                inclusion_icd10,
            )
            if not matched_inclusion:
                continue

            exclusion_icd10_raw = trial.get("exclusion_icd10_codes", set())
            exclusion_icd10 = _WorkerSide._flatten_icd10_trial_codes(
                cast(set[ICD10TrialCode], exclusion_icd10_raw)
            )
            matched_exclusion = _WorkerSide._match_icd10_codes(
                patient_icd10,
                exclusion_icd10,
            )

            # 3. Distance filter (expensive — pgeocode disk/network lookups).
            #    Only reached for trials that already passed demographic and
            #    ICD-10 checks, so typically a handful per patient.
            min_distance: Optional[float] = None
            if check_distance and distance_calculator is not None:
                trial_locations: list[tuple[str, Optional[str]]] = trial.get(
                    "locations", []
                )
                if trial_locations:
                    distances: list[float] = []
                    for site_pc, site_cc in trial_locations:
                        if site_cc is None:
                            # Unknown site country: skip distance computation to avoid
                            # incorrectly treating international sites as domestic.
                            continue
                        d = _postal_code_distance_km(
                            cast(str, patient_postal),
                            cast(str, patient_country),
                            site_pc,
                            site_cc,
                            distance_calculator,
                        )
                        if d is not None:
                            distances.append(d)
                    if distances:
                        min_distance = min(distances)
                        if (
                            max_distance_km is not None
                            and min_distance > max_distance_km
                        ):
                            continue
                    else:
                        continue
                else:
                    # No locations when distance filtering is on: skip trial.
                    continue

            # 4. Compute score.
            raw_score = len(matched_inclusion) - len(matched_exclusion)

            # Note that we use the raw sets here prior to expansion as we don't want
            # to negatively affect the matching score by increasing the denominator
            n_incl = len(inclusion_icd10_raw)
            n_excl = len(exclusion_icd10_raw)

            # Normalize to [0, 1]: best = all inclusion matched, none exclusion;
            # worst = no inclusion matched, all exclusion matched.
            denom = n_incl + n_excl
            score = min(((raw_score + n_excl) / denom), 1.0) if denom > 0 else 0.0
            explanation_parts = [
                f"Matched inclusion codes: {', '.join(sorted(matched_inclusion))}"
            ]
            if matched_exclusion:
                explanation_parts.append(
                    f"Matched exclusion codes: {', '.join(sorted(matched_exclusion))}"
                )
            if min_distance is not None:
                explanation_parts.append(f"Nearest site: {min_distance:.0f} km")

            scored_trials.append(
                {
                    "nct_id": nct_id,
                    "title": trial["title"],
                    "score": score,
                    "nearest_site_km": min_distance,
                    "explanation": "; ".join(explanation_parts),
                }
            )

        scored_trials.sort(key=lambda x: x["score"], reverse=True)
        return scored_trials


@delegates()
class TrialMatchingAlgorithm(
    BaseNonModelAlgorithmFactory[NoResultsModellerAlgorithm, _WorkerSide],
):
    """Algorithm for matching patients to clinical trials via ICD-10 codes.

    Uses patient condition codes (ICD-10 only) and trial inclusion/exclusion
    codes to compute match scores. Score is normalized to [0, 1]:
    1 = perfect match (all inclusion matched, no exclusion matched); 0 = worst.

    Patient postal code and country enable distance filtering via pgeocode.

    Trial matching logic (exact sequence):

    1. Group trials by nct_id: aggregate inclusion/exclusion ICD-10 codes,
       demographics (age range, sex_eligible), and site locations from trials_df.

    2. For each patient row:
       a. Build patient profile: extract ICD-10 codes from Conditions,
          compute age from date_of_birth, normalize gender and country.

    3. For each patient, match against all trials. For each trial, in order:
       a. Demographic check: skip if patient age outside trial min/max, or
          sex does not match sex_eligible (when restricted).
       b. ICD-10 code matching (done before distance for performance):
          skip trials with no inclusion ICD-10 codes; compute
          matched_inclusion = patient_icd10 ∩ trial inclusion codes;
          skip if matched_inclusion is empty; compute matched_exclusion.
       c. Distance check (if max_distance_km set): skip if nearest trial
          site is farther than max_distance_km; skip trials with no sites
          in same country as patient.
       d. Score = (len(matched_inclusion) - len(matched_exclusion)
          + n_excl) / (n_incl + n_excl), range [0, 1], where n_incl/n_excl
          are trial inclusion/exclusion code counts.
       e. Append result with nct_id, title, score, nearest_site_km, explanation.

    4. Sort matched trials by score descending; return top N per patient.

    Args:
        datastructure: The data structure to use for the algorithm.
        top_n: Number of top trials to return per patient. Defaults to 5.
        max_distance_km: Optional maximum distance in km to the nearest trial
            site. Ignored when ``None``.
        default_country: ISO alpha-2 code used when patient or site country is
            missing. Defaults to "us". Injected into country normalization.

    Attributes:
        top_n: Number of top trials to return per patient.
        max_distance_km: Maximum allowed distance to trial site in km, or None.
        default_country: Default when country is missing (from task/algorithm args).
    """

    def __init__(
        self,
        *,
        datastructure: Optional[DataStructure] = None,
        top_n: int = DEFAULT_TOP_N,
        max_distance_km: Optional[float] = None,
        default_country: str = "us",
        **kwargs: Any,
    ) -> None:
        if top_n < 0:
            raise ValueError(f"top_n must be non-negative, got {top_n}")
        if max_distance_km is not None and max_distance_km <= 0:
            raise ValueError(
                f"max_distance_km must be positive when set, got {max_distance_km}"
            )
        if datastructure is None:
            datastructure = DataStructure(table="trial-matching")
        super().__init__(datastructure=datastructure, **kwargs)
        self.top_n = top_n
        self.max_distance_km = max_distance_km
        self.default_country = default_country

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "top_n": fields.Int(
            required=False,
            missing=DEFAULT_TOP_N,
            validate=validate.Range(min=0),
        ),
        "max_distance_km": fields.Float(
            required=False,
            load_default=None,
            allow_none=True,
            validate=validate.Range(min=0.0, min_inclusive=False),
        ),
        "default_country": fields.Str(required=False, load_default="us"),
    }

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> NoResultsModellerAlgorithm:
        """Returns the modeller side of the TrialMatchingAlgorithm."""
        return NoResultsModellerAlgorithm(**kwargs)

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Returns the worker side of the TrialMatchingAlgorithm."""
        return _WorkerSide(
            top_n=self.top_n,
            max_distance_km=self.max_distance_km,
            default_country=self.default_country,
            **kwargs,
        )
