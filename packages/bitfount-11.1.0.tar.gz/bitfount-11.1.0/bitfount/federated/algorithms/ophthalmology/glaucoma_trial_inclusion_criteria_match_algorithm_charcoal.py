"""Algorithm for establishing number of results that match a given criteria."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, Mapping, Optional

from marshmallow import fields
import pandas as pd

from bitfount.externals.ehr.types import Condition
from bitfount.federated.algorithms.ophthalmology.ga_trial_inclusion_criteria_match_algorithm_base import (  # noqa: E501
    BaseGATrialInclusionAlgorithmFactorySingleEye,
    BaseGATrialInclusionWorkerAlgorithmSingleEye,
    CodeFilterMixIn,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    AGE_COL,
    CPT4_COLUMN,
    ICD10_COLUMN,
    PREV_APPOINTMENTS_COL,
)
from bitfount.federated.algorithms.ophthalmology.trial_inclusion_filters import (
    ColumnFilter,
    MethodFilter,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.types import ProtocolContext

if TYPE_CHECKING:
    from bitfount.types import T_FIELDS_DICT


PATIENT_AGE_LOWER_BOUND_GLAUCOMA = 40
YEARS_OF_APPOINTMENT_HISTORY: int = 3
MIN_APPOINTMENTS_PER_HISTORY_YEAR: int = 2
CURRENT_PATIENT_MONTHS_THRESHOLD: int = 12

logger = _get_federated_logger(__name__)


class _WorkerSide(CodeFilterMixIn, BaseGATrialInclusionWorkerAlgorithmSingleEye):
    """Worker side of the algorithm."""

    def __init__(
        self,
        *,
        patient_age_lower_bound: Optional[int] = None,
        renamed_columns: Optional[Mapping[str, str]] = None,
        conditions_inclusion_codes: Optional[list[str]] = None,
        conditions_exclusion_codes: Optional[list[str]] = None,
        procedures_exclusion_codes: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> None:
        if patient_age_lower_bound is not None:
            logger.warning(
                "Glaucoma algorithm explicitly sets patient_age_lower_bound;"
                f" received value of {patient_age_lower_bound}."
                f" Using {PATIENT_AGE_LOWER_BOUND_GLAUCOMA} instead."
            )
        super().__init__(
            patient_age_lower_bound=PATIENT_AGE_LOWER_BOUND_GLAUCOMA,
            renamed_columns=renamed_columns,
            conditions_inclusion_codes=conditions_inclusion_codes,
            conditions_exclusion_codes=conditions_exclusion_codes,
            procedures_exclusion_codes=procedures_exclusion_codes,
            **kwargs,
        )

    def run_and_return_dataframe(
        self,
        dataframe: pd.DataFrame,
    ) -> pd.DataFrame:
        """Finds number of patients that match the clinical criteria.

        Args:
            dataframe: The dataframe to process.

        Returns:
            A dataframe with eligibility details for each patient.
        """
        if dataframe.empty:
            return dataframe

        dataframe = self._add_age_col(dataframe)
        dataframe = self._filter_by_criteria(dataframe)

        return dataframe

    def get_filters(self) -> list[ColumnFilter | MethodFilter]:
        """Returns the eligibility filters for the algorithm."""
        age_column = self._get_column_name(AGE_COL)
        filters: list[ColumnFilter | MethodFilter] = [
            ColumnFilter(
                column=age_column,
                operator=">=",
                value=PATIENT_AGE_LOWER_BOUND_GLAUCOMA,
            ),
            MethodFilter(
                method=self.appointment_history_filter,
                required_columns={PREV_APPOINTMENTS_COL},
                filter_name=f">{YEARS_OF_APPOINTMENT_HISTORY} years of history",
                filter_failed_message="patient did not have sufficiently long history",
            ),
            MethodFilter(
                method=self.is_current_patient,
                required_columns={PREV_APPOINTMENTS_COL},
                filter_name=(
                    "Had appointment within last"
                    f" {CURRENT_PATIENT_MONTHS_THRESHOLD} months"
                ),
                filter_failed_message="patient is not a current patient",
            ),
        ]

        if self.conditions_inclusion_codes:
            filters.append(
                MethodFilter(
                    method=self.included_conditions_filter,
                    required_columns={ICD10_COLUMN},
                    filter_name="Included Conditions",
                    filter_failed_message="patient does not have included conditions",
                )
            )

        if self.conditions_excl_codes_literal or self.conditions_excl_regex_pattern:
            filters.append(
                MethodFilter(
                    method=self.excluded_conditions_filter,
                    required_columns={ICD10_COLUMN},
                    filter_name="Excluded Conditions",
                    filter_failed_message="patient diagnosed with one of the"
                    " excluded conditions",
                )
            )

        if self.procedures_exclusion_codes:
            filters.append(
                MethodFilter(
                    method=self.excluded_procedures_filter,
                    required_columns={CPT4_COLUMN},
                    filter_name="Excluded Treatments",
                    filter_failed_message="patient has had treatment that"
                    " precludes them from the trial",
                )
            )

        return filters

    def included_conditions_filter(
        self,
        row: pd.Series[Any],
    ) -> tuple[bool, Optional[str]]:
        """Filter to include only patients with matching diagnosis codes."""
        if row[ICD10_COLUMN] and self.conditions_inclusion_codes:
            patient_conditions: list[Condition] = row[ICD10_COLUMN]
            patient_conditions_str = set(i.code_code for i in patient_conditions)
            for code in self.conditions_inclusion_codes:
                if code in patient_conditions_str:
                    return True, None

        return False, None

    def appointment_history_filter(
        self,
        row: pd.Series[Any],
    ) -> tuple[bool, Optional[str]]:
        """Filter to check patient appointment history length."""
        return self._appointment_history_filter(
            row,
            years_of_history=YEARS_OF_APPOINTMENT_HISTORY,
            min_appointments_per_year=MIN_APPOINTMENTS_PER_HISTORY_YEAR,
        )

    def is_current_patient(self, row: pd.Series[Any]) -> tuple[bool, Optional[str]]:
        """Checks if the patient has had an appointment in the last X months."""
        return self._current_patient_filter(
            row,
            months_threshold=CURRENT_PATIENT_MONTHS_THRESHOLD,
        )


class TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoal(
    BaseGATrialInclusionAlgorithmFactorySingleEye
):
    """Algorithm for establishing number of patients that match clinical criteria."""

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "patient_age_lower_bound": fields.Integer(allow_none=True),
        "conditions_inclusion_codes": fields.List(fields.Str(), allow_none=True),
        "conditions_exclusion_codes": fields.List(fields.Str(), allow_none=True),
        "procedures_exclusion_codes": fields.List(fields.Str(), allow_none=True),
    }

    def __init__(
        self,
        patient_age_lower_bound: Optional[int] = None,
        conditions_inclusion_codes: Optional[list[str]] = None,
        conditions_exclusion_codes: Optional[list[str]] = None,
        procedures_exclusion_codes: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            patient_age_lower_bound=patient_age_lower_bound,
            **kwargs,
        )
        self.conditions_inclusion_codes = conditions_inclusion_codes
        self.conditions_exclusion_codes = conditions_exclusion_codes
        self.procedures_exclusion_codes = procedures_exclusion_codes

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Worker-side of the algorithm."""
        return _WorkerSide(
            patient_age_lower_bound=self.patient_age_lower_bound,
            conditions_inclusion_codes=self.conditions_inclusion_codes,
            conditions_exclusion_codes=self.conditions_exclusion_codes,
            procedures_exclusion_codes=self.procedures_exclusion_codes,
            **kwargs,
        )
