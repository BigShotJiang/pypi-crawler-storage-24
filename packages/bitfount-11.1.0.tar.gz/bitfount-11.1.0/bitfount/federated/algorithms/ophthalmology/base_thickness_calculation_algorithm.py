"""Base Algorithm for calculating metrics requiring a thickness map."""

from __future__ import annotations

from abc import ABCMeta, abstractmethod
from bisect import bisect_left
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    List,
    Literal,
    Mapping,
    Optional,
    Type,
    TypedDict,
    TypeVar,
    cast,
)

from natsort import natsorted
import numpy as np
import pandas as pd

from bitfount.data.datasources.base_source import BaseSource, FileSystemIterableSource
from bitfount.data.datasources.utils import ORIGINAL_FILENAME_METADATA_COLUMN
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.federated.algorithms.base import BaseWorkerAlgorithm
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    CSTMetrics,
    GCCMetrics,
    RetinalLayer,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_utils import (
    get_data_for_files,
    is_file_iterable_source,
)
from bitfount.federated.exceptions import DataProcessingError
from bitfount.federated.logging import _get_federated_logger

if TYPE_CHECKING:
    from bitfount.federated.privacy.differential import DPPodConfig

logger = _get_federated_logger("bitfount.federated")

CENTRAL_SLICE = "central_slice"
FOVEA_LANDMARK = "landmarks"

CENTER_LANDMARK_TYPE = Literal["fovea", "macula"]


class RLInstance(TypedDict, total=False):
    """Typed Dict for Retinal Layer instance."""

    type: Literal["polygon"]
    className: str
    points: List[float] | List[int]
    attributes: List[Any]
    classId: int
    probability: float


class RLMask(TypedDict, total=False):
    """Typed Dict for Retinal Layer mask."""

    instances: List[RLInstance]
    metadata: dict[str, Any]


class RLPrediction(TypedDict, total=False):
    """Typed Dict for Retinal Layer prediction."""

    mask: RLMask


T = TypeVar("T")


class _BaseThicknessWorkerSide(BaseWorkerAlgorithm, Generic[T], metaclass=ABCMeta):
    def __init__(
        self,
        region_radius_mm: float,
        inner_layer_name: str,
        outer_layer_name: str,
        landmark_idx: int,
        strict_measurement: bool,
        center_landmark_type: CENTER_LANDMARK_TYPE,
        **kwargs: Any,
    ) -> None:
        """Initialize algorithm for calculating thickness with segmentations.

        Args:
            region_radius_mm: Radius of the circular region for thickness calculation.
            inner_layer_name: Name of the desired inner layer for thickness calculation.
            outer_layer_name: Name of the desired outer layer for thickness calculation.
            landmark_idx: Index of the landmark to use
                (0=start, 1=end, 2=middle).
            strict_measurement: If True, only calculate if both desired inner and outer
                layers are available. If False, use next available layer as fallback
                (default: False).
            center_landmark_type: Describes the nature of the center around which
                to calculate average thickness. This is either "fovea" or "macula"
                for now. Defaults to "fovea".
            **kwargs: Additional keyword arguments.
        """
        # These are expected to raise a ValueError if inner_layer_name/outer_layer_name
        # are not valid
        self.inner_layer: RetinalLayer = RetinalLayer.from_str(inner_layer_name)
        self.outer_layer: RetinalLayer = RetinalLayer.from_str(outer_layer_name)

        self.region_radius_mm = region_radius_mm
        self.landmark_idx = landmark_idx
        self.strict_measurement = strict_measurement
        self.center_landmark_type = center_landmark_type
        super().__init__(**kwargs)

    def initialise(
        self,
        *,
        datasource: BaseSource,
        data_splitter: Optional[DatasetSplitter] = None,
        pod_dp: Optional[DPPodConfig] = None,
        pod_identifier: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the algorithm with datasource."""
        self.initialise_data(datasource=datasource, data_splitter=data_splitter)

    @property
    @abstractmethod
    def metric_name(self) -> str:
        """Name of the metric to be calculated. Used for logging."""
        raise NotImplementedError

    @abstractmethod
    def _calculate_metric(
        self,
        layer_pred: pd.Series,
        file_row: pd.Series,
    ) -> T:
        """Calculation of thickness metric."""
        raise NotImplementedError

    # pyrefly: ignore[bad-override]
    def run(
        self,
        layer_predictions: pd.DataFrame,
        center_predictions: pd.DataFrame,
        filenames: Optional[list[str]] = None,
    ) -> dict[str, Optional[T]]:
        """Calculate average thickness metrics for each file from model predictions.

        Args:
            layer_predictions: DataFrame with retinal layer segmentation predictions.
            center_predictions: DataFrame with predictions for landmark centre for
                calculating average thickness, usually fovea or macular center.
                Should contain 'central_slice' and 'landmarks' columns.
            filenames: List of files that the results correspond to. If not
                provided, will use filenames from predictions.

        Returns:
            Dictionary of original filenames to CSTMetrics or GCCMetrics objects.
        """
        # Fail fast if there are no predictions
        if layer_predictions.empty:
            logger.warning("No layer predictions provided")
            return {}

        if center_predictions.empty:
            logger.warning("No landmark center predictions provided")
            return {}
        # Get filenames if not provided
        if filenames is None:
            if ORIGINAL_FILENAME_METADATA_COLUMN not in layer_predictions.columns:
                raise DataProcessingError(
                    f"Column '{ORIGINAL_FILENAME_METADATA_COLUMN}' not found "
                    f"in predictions"
                )
            filenames = layer_predictions[ORIGINAL_FILENAME_METADATA_COLUMN].tolist()

        # Verify center predictions have the filename column for merging
        if ORIGINAL_FILENAME_METADATA_COLUMN not in center_predictions.columns:
            raise DataProcessingError(
                f"Column '{ORIGINAL_FILENAME_METADATA_COLUMN}' not found "
                f"in landmark model predictions."
            )

        if not is_file_iterable_source(self.datasource):
            raise DataProcessingError(
                f"{self.metric_name} calculation requires a FileSystemIterableSource."
            )

        datasource_df = get_data_for_files(
            cast(FileSystemIterableSource, self.datasource),
            filenames,
        )
        # Check that we have the expected number of results for the number of files
        if len(filenames) != len(datasource_df):
            raise DataProcessingError(
                f"Length of results ({len(datasource_df)}"
                f" does not match the number of files ({len(filenames)})"
                f" while processing trial calculations."
            )

        # Merge center predictions with metadata
        merged_df = datasource_df.merge(
            center_predictions,
            on=ORIGINAL_FILENAME_METADATA_COLUMN,
            how="left",
            suffixes=("", f"_{self.center_landmark_type}"),
        )

        results: dict[str, Optional[T]] = {}
        if ORIGINAL_FILENAME_METADATA_COLUMN not in layer_predictions.columns:
            raise DataProcessingError(
                f"Column '{ORIGINAL_FILENAME_METADATA_COLUMN}' not found "
                f"in Retinal Layer model predictions."
            )
        # Null keys are not allowed since filenames this is a strict key
        null_mask = layer_predictions[ORIGINAL_FILENAME_METADATA_COLUMN].isna()
        if null_mask.any():
            n_null = int(null_mask.sum())
            raise DataProcessingError(
                f"Found {n_null} row(s) with null "
                f"'{ORIGINAL_FILENAME_METADATA_COLUMN}' in layer_predictions"
            )

        try:
            layer_predictions_indexed = layer_predictions.set_index(
                ORIGINAL_FILENAME_METADATA_COLUMN,
                verify_integrity=True,  # ensures uniqueness
            )
        except ValueError as e:
            # Diagnose duplicates and report the top offenders
            dup_counts = (
                layer_predictions[ORIGINAL_FILENAME_METADATA_COLUMN]
                .value_counts()
                .loc[lambda s: s > 1]
                .sort_values(ascending=False)
            )
            top = ", ".join([f"{k} x{int(v)}" for k, v in dup_counts.head(10).items()])
            logger.error(
                "Duplicate _original_filename values in layer_predictions. "
                f"Top duplicates: {top}"
            )
            raise DataProcessingError(
                f"Duplicate keys in '{ORIGINAL_FILENAME_METADATA_COLUMN}' in "
                f"layer_predictions. Resolve duplicates before running. "
                f"Top duplicates: {top}"
            ) from e
        for filename in filenames:
            try:
                layer_pred_obj = layer_predictions_indexed.loc[filename]

                # Ensure a single-row Series (pandas typing: Series | DataFrame)
                if isinstance(layer_pred_obj, pd.DataFrame):
                    layer_pred = layer_pred_obj.iloc[0]
                else:
                    layer_pred = layer_pred_obj

                # Get metadata and center landmark prediction for this file
                file_data = merged_df[
                    merged_df[ORIGINAL_FILENAME_METADATA_COLUMN] == filename
                ]

                if file_data.empty:
                    logger.warning(f"No metadata found for {filename}")
                    results[filename] = None
                    continue

                file_row = file_data.iloc[0]

                # Calculate metrics
                metrics = self._calculate_metric(layer_pred, file_row)
                results[filename] = metrics

            except Exception as e:
                logger.error(
                    f"Error calculating {self.metric_name} for {filename}: {e}"
                )
                logger.debug(e, exc_info=True)
                results[filename] = None

        return results

    def _parse_center_coordinates(
        self,
        file_row: pd.Series,
    ) -> Optional[tuple[float, float, float]]:
        """Parse center coordinates from landmark model predictions.

        This follows the same approach as the GA trial calculation algorithm,
        extracting a specific landmark from the central slice. Assumes landmarks
        are contiguous triples per slice: [start, end, middle].

        Args:
            file_row: Row containing 'central_slice' and 'landmarks' columns.

        Returns:
            Tuple of (slice, x, y) coordinates, or None if parsing fails.
        """
        try:
            # Get central slice & landmarks from the file row
            central_slice = file_row.get(CENTRAL_SLICE, None)
            # TODO: [BIT-7356] when Macula landmark output is determined,
            #  adapt this to work for fovea and macula
            landmarks_list = file_row.get(FOVEA_LANDMARK, None)

            if central_slice is None or pd.isna(central_slice):
                logger.warning(
                    f"Central slice prediction missing. Skipping {self.metric_name}"
                    f" calculation."
                )
                return None
            # The model should always output at least 3 landmarks (start, end, middle)
            if landmarks_list is None or len(landmarks_list) < 3:
                logger.warning(
                    f"{self.center_landmark_type.capitalize()} landmarks missing"
                    f"/invalid. Skipping {self.metric_name} calculation."
                )
                return None
            cs = int(central_slice)
            # landmarks_list is a list of [slice, x, y] coordinates
            # Example: [[62, 467, 694], [62, 585, 685], [62, 515, 700], ...]
            # There are typically 3 landmarks per slice (start, end, middle)
            if not landmarks_list or not isinstance(landmarks_list, list):
                logger.warning("Invalid landmarks_list format")
                return None

            # Get the index of the first landmark at central_slice
            central_slice_column_idx = bisect_left(
                landmarks_list, cs, key=lambda x: x[0]
            )

            # Ensure the index found truly corresponds to the desired slice.
            if (
                central_slice_column_idx >= len(landmarks_list)
                or int(landmarks_list[central_slice_column_idx][0]) != cs
            ):
                logger.warning(
                    f"Central slice {central_slice} not found in landmarks. "
                    f"Skipping {self.metric_name} calculation."
                )
                return None

            # With contiguous triples per slice, the start entry is at
            # central_slice_column_idx, so the target entry is offset
            # by fovea_landmark_idx (0=start, 1=end, 2=middle).
            # TODO: [BIT-7356] When implementing for Macula check if we
            # also need this offset
            landmark_idx = self.landmark_idx + central_slice_column_idx

            if (
                landmark_idx >= len(landmarks_list)
                or int(landmarks_list[landmark_idx][0]) != cs
            ):
                logger.warning(
                    f"Landmark index {landmark_idx} not found at central slice"
                    f" {central_slice}.  Skipping distance calculation."
                )
                return None

            # Get the landmark coordinates [slice, x, y]
            landmark_center = landmarks_list[landmark_idx]

            center_slice = float(landmark_center[0])
            center_x = float(landmark_center[1])
            center_y = float(landmark_center[2])

            logger.debug(
                f"Parsed landmark center from central_slice={central_slice}, "
                f"landmark_idx={landmark_idx}: ({center_slice}, {center_x}, {center_y})"
            )

            return (center_slice, center_x, center_y)

        except Exception as e:
            logger.error(f"Error parsing center coordinates: {e}")
            logger.debug(e, exc_info=True)
            return None

    def _parse_bscan_prediction(self, bscan_prediction: Any) -> Optional[RLPrediction]:
        """Preprocess B-scan prediction string for JSON parsing."""
        if bscan_prediction is None or bscan_prediction is pd.NA:
            return None
        if isinstance(bscan_prediction, float) and np.isnan(bscan_prediction):
            return None
        # Normalize to dict root with "instances"
        if isinstance(bscan_prediction, list):
            if len(bscan_prediction) == 0:
                return None
            bscan_prediction = bscan_prediction[0]
        if isinstance(bscan_prediction, dict) and "mask" in bscan_prediction:
            mask = bscan_prediction.get("mask", None)
            if isinstance(mask, dict) and "instances" in mask:
                return cast(RLPrediction, bscan_prediction)
        logger.warning(
            f"B-scan prediction has unexpected structure: {type(bscan_prediction)}"
        )
        return None

    def _get_available_layers(
        self, bscan_prediction: RLPrediction, available_layers: set[RetinalLayer]
    ) -> set[RetinalLayer]:
        """Collect unique layer names from a B-scan prediction into available_layers."""
        # bscan_prediction expected format is {'mask': {'instances': [...]}}
        # the layer names can then be found in each instance's 'className' field
        mask = (bscan_prediction or {}).get("mask") or {}
        instances: List[RLInstance] = mask.get("instances") or []
        for instance in instances:
            layer_name = instance.get("className", "")
            if layer_name:
                try:
                    available_layers.add(RetinalLayer.from_str(layer_name))
                except ValueError as e:
                    logger.error(
                        f"Layers model output contains unexpected layer name "
                        f"'{layer_name}'. Raised ValueError: {str(e)}. The "
                        f"segmentation from this layer may be ignored."
                    )
        return available_layers

    def _build_thickness_map(
        self,
        layer_pred: pd.Series,
        pixel_spacing_row_mm: float,
    ) -> Optional[
        tuple[np.ndarray, str, str]  # pyrefly: ignore[implicit-any]
    ]:
        """Build thickness map from layer segmentations with fallback support.

        Args:
            layer_pred: Layer predictions for one file.
            pixel_spacing_row_mm: Pixel spacing in row direction (mm/pixel).

        Returns:
            - None if no valid thickness map can be built.
            - Otherwise, a tuple containing:
                - thickness_map_um: of shape (num_slices, width) in micrometers.
                - inner_layer_name: Name of inner layer for thickness map.
                - outer_layer_name: Name of outer layer for thickness map.

        """
        # Extract prediction columns based on altris model assumptions
        pred_cols = [
            col
            for col in layer_pred.index
            if col.startswith("Pixel_Data_") and col.endswith("_prediction")
        ]
        if not pred_cols:
            logger.warning("No prediction columns found")
            return None

        # Sort columns to maintain B-scan order
        pred_cols_sorted = natsorted(pred_cols)

        # Collect available layers across B-scans
        parsed_predictions: list[Optional[RLPrediction]] = []
        available_layers: set[RetinalLayer] = set()
        for col in pred_cols_sorted:
            bscan_prediction = layer_pred[col]
            bscan_prediction = self._parse_bscan_prediction(bscan_prediction)
            parsed_predictions.append(bscan_prediction)

            if bscan_prediction is not None and len(available_layers) < len(
                RetinalLayer
            ):
                available_layers = self._get_available_layers(
                    bscan_prediction, available_layers
                )
        if not available_layers:
            logger.warning("No layers found in any predictions")
            return None

        # Determine which layers to use for thickness measurement
        inner_layer_name, outer_layer_name = self._select_measurement_layers(
            available_layers
        )
        # if no suitable layer pair found, return None and log warning
        if inner_layer_name is None or outer_layer_name is None:
            if self.strict_measurement:
                logger.warning(
                    f"Strict measurement enabled: both {self.inner_layer.to_string()}"
                    f" and {self.outer_layer.to_string()} required but not available."
                    f" Available layers are "
                    f"{[layer.to_string() for layer in available_layers]}"
                )
            else:
                logger.warning(
                    f"No suitable layer pair found for thickness measurement."
                    f" Available layers are "
                    f"{[layer.to_string() for layer in available_layers]}"
                )
            return None
        # Second pass: parse layer boundaries using cached predictions
        # pyrefly: ignore[implicit-any]
        all_layers_per_bscan: list[dict[str, np.ndarray]] = []
        for bscan_prediction in parsed_predictions:
            if bscan_prediction is None:
                # Add empty dict for missing B-scans to maintain alignment
                all_layers_per_bscan.append({})
            else:
                # Parse using the already-loaded prediction
                layers = self._parse_layer_prediction(
                    bscan_prediction, inner_layer_name, outer_layer_name
                )
                all_layers_per_bscan.append(layers)
        # Determine maximum width from all B-scans
        max_width = 0
        for layers_dict in all_layers_per_bscan:
            inner_boundary = layers_dict.get(inner_layer_name)
            outer_boundary = layers_dict.get(outer_layer_name)

            # Check both boundaries
            for boundary in [inner_boundary, outer_boundary]:
                if (
                    boundary is not None
                    and isinstance(boundary, np.ndarray)
                    and len(boundary) > 0
                ):
                    max_x = int(np.max(boundary[:, 0]))  # X is first column
                    max_width = max(max_width, max_x + 1)

        if max_width == 0:
            logger.warning(
                "Could not determine image width - no valid boundaries found"
            )
            return None

        logger.debug(f"Interpolating boundaries to common grid with width={max_width}")

        # Only calculate thickness where BOTH layers have valid data
        # pyrefly: ignore[implicit-any]
        inner_boundaries: list[np.ndarray] = []
        # pyrefly: ignore[implicit-any]
        outer_boundaries: list[np.ndarray] = []
        num_valid_bscans = 0
        num_partial_overlap = 0

        for i, layers_dict in enumerate(all_layers_per_bscan):
            inner_boundary = layers_dict.get(inner_layer_name)
            outer_boundary = layers_dict.get(outer_layer_name)

            # Initialize with NaN (invalid by default)
            inner_interp = np.full(max_width, np.nan)
            outer_interp = np.full(max_width, np.nan)

            # Check if both boundaries present and valid
            if (
                inner_boundary is not None
                and isinstance(inner_boundary, np.ndarray)
                and len(inner_boundary) > 1
                and outer_boundary is not None
                and isinstance(outer_boundary, np.ndarray)
                and len(outer_boundary) > 1
            ):
                # Extract X and Y coordinates
                inner_x, inner_y = inner_boundary[:, 0], inner_boundary[:, 1]
                outer_x, outer_y = outer_boundary[:, 0], outer_boundary[:, 1]

                # Find the overlapping X-range where both layers have data
                inner_x_min, inner_x_max = int(np.min(inner_x)), int(np.max(inner_x))
                outer_x_min, outer_x_max = int(np.min(outer_x)), int(np.max(outer_x))

                # Calculate overlap range
                overlap_min = max(inner_x_min, outer_x_min)
                overlap_max = min(inner_x_max, outer_x_max)

                if overlap_max >= overlap_min:
                    # Interpolate only within the overlapping region
                    overlap_x_range = np.arange(overlap_min, overlap_max + 1)
                    inner_interp[overlap_min : overlap_max + 1] = np.interp(
                        overlap_x_range, inner_x, inner_y
                    )
                    outer_interp[overlap_min : overlap_max + 1] = np.interp(
                        overlap_x_range, outer_x, outer_y
                    )

                    num_valid_bscans += 1

                    # Log if we have partial coverage (not full width)
                    if overlap_min > 0 or overlap_max < max_width - 1:
                        num_partial_overlap += 1
                        logger.debug(
                            f"B-scan {i}: Partial overlap [{overlap_min}:{overlap_max}]"
                            f" of {max_width} (inner: [{inner_x_min}:{inner_x_max}], "
                            f"outer: [{outer_x_min}:{outer_x_max}])"
                        )
                else:
                    # No overlap between the two layers
                    logger.debug(
                        f"B-scan {i}: No overlap between inner and outer layer X-ranges"
                        f" (inner: [{inner_x_min}:{inner_x_max}], outer: "
                        f"[{outer_x_min}:{outer_x_max}])"
                    )
            else:
                # One or both boundaries missing or invalid
                logger.debug(
                    f"B-scan {i}: Missing or invalid boundary "
                    f"(inner="
                    f"{'valid' if inner_boundary is not None and len(inner_boundary) > 1 else 'invalid'}, "  # noqa: E501
                    f"outer="
                    f"{'valid' if outer_boundary is not None and len(outer_boundary) > 1 else 'invalid'})"  # noqa: E501
                )

            inner_boundaries.append(inner_interp)
            outer_boundaries.append(outer_interp)

        logger.info(
            f"Using {num_valid_bscans}/{len(all_layers_per_bscan)} B-scans "
            f"for thickness calculation"
        )
        if num_partial_overlap > 0:
            logger.info(
                f"{num_partial_overlap} B-scan(s) have partial X-range overlap "
                f"(thickness only calculated where both layers detected)"
            )

        # Try to convert to numpy arrays of shape: (num_slices, width)
        try:
            inner_array = np.array(inner_boundaries)
            outer_array = np.array(outer_boundaries)
        except Exception as e:
            logger.error(f"Error creating boundary arrays: {e}")
            logger.debug(
                f"Inner boundaries shapes: "
                f"{[b.shape if isinstance(b, np.ndarray) else len(b) for b in inner_boundaries]}"  # noqa: E501
            )
            logger.debug(
                f"Outer boundaries shapes: "
                f"{[b.shape if isinstance(b, np.ndarray) else len(b) for b in outer_boundaries]}"  # noqa: E501
            )
            return None

        # Calculate thickness in pixels (outer - inner, absolute value)
        # NaN values will propagate through this calculation
        thickness_pixels = np.abs(outer_array - inner_array)

        # Convert to micrometers (1 mm = 1000 µm)
        thickness_um = thickness_pixels * pixel_spacing_row_mm * 1000.0

        # Count how many valid thickness values we have
        num_valid_thickness = int(np.sum(~np.isnan(thickness_um)))
        total_possible = thickness_um.size

        logger.info(
            f"Built thickness map using {inner_layer_name} to {outer_layer_name}: "
            f"shape={thickness_um.shape}, mean={np.nanmean(thickness_um):.1f}µm, "
            f"valid_points={num_valid_thickness}/{total_possible} "
            f"({100 * num_valid_thickness / total_possible:.1f}%)"
        )
        return (
            thickness_um,
            inner_layer_name,
            outer_layer_name,
        )

    def _select_measurement_layers(
        self,
        available_layers: set[RetinalLayer],
    ) -> tuple[Optional[str], Optional[str]]:
        """Select which layers to use for thickness measurement with fallback logic.

        Args:
            available_layers: Set of available layer names.

        Returns:
            Tuple of (inner_layer_name, outer_layer_name) or (None, None)
            if no suitable pair found.
        """
        desired_inner_present = self.inner_layer in available_layers
        desired_outer_present = self.outer_layer in available_layers

        if desired_inner_present and desired_outer_present:
            return self.inner_layer.to_string(), self.outer_layer.to_string()
        else:
            if self.strict_measurement:
                # If strict measurement is enabled, only use desired layers
                return None, None

        # Non-strict: use fallback logic
        # Falling back towards the layers in the middle i.e. should become thinner
        inner_layer: Optional[RetinalLayer] = self._find_fallback_layer(
            self.inner_layer, available_layers, search_direction="outer"
        )
        outer_layer: Optional[RetinalLayer] = self._find_fallback_layer(
            self.outer_layer, available_layers, search_direction="inner"
        )

        if inner_layer is not None and outer_layer is not None:
            # Verify that inner layer comes before outer layer in the retinal order
            if inner_layer.value < outer_layer.value:
                if inner_layer != self.inner_layer or outer_layer != self.outer_layer:
                    logger.info(
                        f"Using fallback layers: {inner_layer.to_string()} to"
                        f" {outer_layer.to_string()} "
                        f"(requested: {self.inner_layer.to_string()} to "
                        f"{self.outer_layer.to_string()})"
                    )
                return inner_layer.to_string(), outer_layer.to_string()
            else:
                logger.warning(
                    f"Invalid layer order: {inner_layer.to_string()}"
                    f" (depth {inner_layer.value}) "
                    f"should come before {outer_layer.to_string()}"
                    f" (depth {outer_layer.value})"
                )

        return None, None

    def _find_fallback_layer(
        self,
        preferred_layer: RetinalLayer,
        available_layers: set[RetinalLayer],
        search_direction: Literal["inner", "outer"],
    ) -> Optional[RetinalLayer]:
        """Find a fallback layer if the preferred layer is not available."""
        # If preferred layer is available, use it
        if preferred_layer in available_layers:
            return preferred_layer

        # Get enum value for preferred layer
        preferred_enum = preferred_layer.value

        # Search in the specified direction
        if search_direction == "inner":
            # Search towards ILM (decreasing depth)
            candidate_enums = sorted(
                [e for e in RetinalLayer if e < preferred_enum],
                reverse=True,  # Start from closest to preferred
            )
        else:  # "outer"
            # Search towards Bruch's Membrane (increasing depth)
            candidate_enums = sorted([e for e in RetinalLayer if e > preferred_enum])

        # Find first available candidate
        for candidate_layer in candidate_enums:
            if candidate_layer in available_layers:
                logger.debug(
                    f"Fallback: using {candidate_layer}"
                    f" (depth {candidate_layer.value}) "
                    f"instead of {preferred_layer}"
                    f" (depth {preferred_enum})"
                )
                return candidate_layer

        logger.warning(
            f"No fallback layer found for {preferred_layer} in direction "
            f"{search_direction}"
        )
        return None

    # pyrefly: ignore[implicit-any]
    def _split_points(self, points: np.ndarray) -> List[np.ndarray]:
        """Split flat points array into Nx2 coordinate array with [x, y] per row.

        Args:
            points: Flat array [x0, y0, x1, y1, ..., xN, yN]

        Returns:
            List containing single Nx2 array where each row is [x, y].
            Returns empty list if insufficient points.
        """
        if len(points) < 4:  # Need at least 2 coordinate pairs
            return []

        # Reshape flat array to Nx2: [[x0, y0], [x1, y1], ..., [xN, yN]]
        # Keep as float64 for sub-pixel precision (don't convert to int32)
        points_2d = points.reshape(-1, 2)

        # For closed polygons, extract only the boundary (from start to max X)
        x_coords = points_2d[:, 0]
        max_x_idx = np.argmax(x_coords)

        # Take from start to max_x (the forward boundary)
        boundary = points_2d[: max_x_idx + 1]

        # If boundary goes right-to-left, reverse it to be left-to-right
        if len(boundary) > 1 and boundary[0, 0] > boundary[-1, 0]:
            boundary = boundary[::-1]

        return [boundary]

    def _parse_layer_prediction(
        self,
        pred_data: RLPrediction | str,
        inner_layer_name: str,
        outer_layer_name: str,
        # pyrefly: ignore[implicit-any]
    ) -> dict[str, np.ndarray]:
        """Parse layer segmentation prediction and extract boundary coordinates.

        Handles multiple polygon instances per layer (combines their points).

        Args:
            pred_data: Prediction dict with key 'mask' → 'instances'.
            inner_layer_name: Name of the inner layer to extract (e.g., "ILM").
            outer_layer_name: Name of the outer layer to extract (e.g., "RPE Layer").

        Returns:
            Dictionary mapping layer names to lists of Nx2 arrays.
            Each array has rows of [x, y] coordinates representing the boundary.
            Format: {'ILM': [array([[x0, y0], [x1, y1], ...])], 'RPE Layer': [...]}
            Only returns the two requested layers.
        """

        required_layers = [inner_layer_name, outer_layer_name]

        try:
            # pyrefly: ignore[implicit-any]
            layers: dict[str, np.ndarray] = {}

            instances: List[RLInstance] = []
            # Extract instances from the prediction structure
            if isinstance(pred_data, dict) and "mask" in pred_data:
                instances = pred_data["mask"].get("instances", [])
            # Collect points for inner and outer layers separately
            inner_layer_points: list[float] = []
            outer_layer_points: list[float] = []
            for instance in instances:
                if instance.get("type") != "polygon":
                    continue
                layer_name = instance.get("className", "")
                if layer_name not in required_layers:
                    continue
                points = instance.get("points", [])
                if not points or len(points) < 4:  # Need at least 2 coordinate pairs
                    continue
                # There might be more than one instance per layer - need to combine them
                if layer_name == inner_layer_name:
                    inner_layer_points.extend(points)
                if layer_name == outer_layer_name:
                    outer_layer_points.extend(points)
            # Process inner layer if we have points
            if len(inner_layer_points) >= 4:
                pts = self._split_points(np.array(inner_layer_points, dtype=np.float64))
                layers[inner_layer_name] = self._dedupe_layer_points(
                    pts[0], keep_mode="min"
                )
            else:
                layers[inner_layer_name] = np.array([], dtype=np.float64).reshape(
                    0, 2
                )  # Empty Nx2 array

            # Process outer layer if we have points
            if len(outer_layer_points) >= 4:
                pts = self._split_points(np.array(outer_layer_points, dtype=np.float64))
                layers[outer_layer_name] = self._dedupe_layer_points(
                    pts[0], keep_mode="max"
                )
            else:
                layers[outer_layer_name] = np.array([], dtype=np.float64).reshape(
                    0, 2
                )  # Empty Nx2 array
            return layers

        except Exception as e:
            logger.error(f"Error parsing layer prediction: {e}")
            logger.debug(e, exc_info=True)
            return {}

    def _dedupe_layer_points(
        self,
        points: np.ndarray,  # pyrefly: ignore[implicit-any]
        keep_mode: Literal["min", "max"] = "min",
    ) -> np.ndarray:  # pyrefly: ignore[implicit-any]
        """Remove duplicate X coordinates, keeping only one Y value per X.

        For retinal layer boundaries, when multiple Y values exist at the same X:
        - Inner layers (ILM, RNFL, etc.): keep minimum Y
        - Outer layers (RPE, Bruch's, etc.): keep maximum Y

        Args:
            points: Nx2 array where each row is [x, y]
            keep_mode: "min" to keep minimum Y, "max" to keep maximum Y

        Returns:
            Mx2 array with unique X values (M <= N)
        """
        if len(points) == 0:
            return points

        # Sort by X coordinate first (ensures proper ordering)
        points = points[points[:, 0].argsort()]

        # Find unique X values and their indices
        unique_x, inverse_indices = np.unique(points[:, 0], return_inverse=True)

        # For each unique X, select the appropriate Y value
        unique_points = np.zeros((len(unique_x), 2), dtype=points.dtype)
        unique_points[:, 0] = unique_x

        for i, _x_val in enumerate(unique_x):
            # Get all Y values for this X coordinate
            mask = inverse_indices == i
            y_values = points[mask, 1]

            # Keep min or max Y depending on mode
            if keep_mode == "min":
                unique_points[i, 1] = np.min(y_values)
            else:  # "max"
                unique_points[i, 1] = np.max(y_values)

        return unique_points

    @classmethod
    @abstractmethod
    def metric_class(cls) -> Type[GCCMetrics] | Type[CSTMetrics]:
        """Metric dataclass used by this algorithm."""
        raise NotImplementedError

    @classmethod
    def convert_metrics_to_df(
        cls,
        file_to_metric: Mapping[str, Optional[GCCMetrics | CSTMetrics]],
    ) -> pd.DataFrame:
        """Convert a dict of Metrics objects into a dataframe.

        Args:
            file_to_metric: Mapping of original filename to Metric (or None).

        Returns:
            A dataframe with each row representing the Metric for a single file.
        """
        metrics_df = pd.DataFrame.from_records(
            (m.to_record() if m is not None else dict())
            for m in file_to_metric.values()
        )
        metrics_df[ORIGINAL_FILENAME_METADATA_COLUMN] = list(file_to_metric.keys())

        expected_cols = cls.metric_class().expected_cols()
        existing_cols = metrics_df.columns.to_list()
        missing_cols = sorted(list(set(expected_cols) - set(existing_cols)))
        if missing_cols:
            logger.warning(
                f"Columns were missing from the calculated metrics: "
                f" {', '.join(missing_cols)}."
                f" Adding empty columns for these."
            )
            metrics_df = metrics_df.reindex(columns=existing_cols + expected_cols)

        return metrics_df
