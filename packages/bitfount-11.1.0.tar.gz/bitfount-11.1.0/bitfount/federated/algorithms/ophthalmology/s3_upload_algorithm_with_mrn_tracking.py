"""S3 Upload Algorithm with MRN tracking for Charcoal protocols.

This extends the base S3UploadAlgorithm to add MRN tracking functionality
that tracks which MRNs have been successfully uploaded to S3. This is used in
scenarios where we need to track which patients have been uploaded already
across multiple runs.
"""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any, cast

import pandas as pd
from requests import HTTPError, RequestException

from bitfount.federated.algorithms.filtering_algorithm import _extract_mrns_from_value
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    _BITFOUNT_PATIENT_ID_KEY,
    MRN_COL,
    MRN_TRACKING_STORE_NAME,
)
from bitfount.federated.algorithms.s3_upload_algorithm import (
    S3_UPLOAD_RETRY_ATTEMPTS,
    S3UploadAlgorithm,
    _WorkerSide as _BaseWorkerSide,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.types import ProtocolContext
from bitfount.persistence.string_store import StringStore
from bitfount.storage import _upload_file_to_s3
from bitfount.types import _S3PresignedPOSTFields, _S3PresignedPOSTURL

logger = _get_federated_logger(__name__)


class _WorkerSide(_BaseWorkerSide):
    """Worker side with MRN tracking functionality."""

    def __init__(self, *, context: ProtocolContext, **kwargs: Any) -> None:
        """Initialize worker side with context for MRN tracking.

        Args:
            context: ProtocolContext containing project_id and task_id.
            **kwargs: Additional arguments passed to base class.
        """
        super().__init__(**kwargs)
        self._context = context

    def run(
        self,
        files_to_upload: Mapping[Path, str],
        presigned_url: _S3PresignedPOSTURL,
        presigned_fields: _S3PresignedPOSTFields,
        retry_attempts: int = S3_UPLOAD_RETRY_ATTEMPTS,
    ) -> tuple[dict[Path, str], list[Path]]:
        """Uploads a list of files to a bucket with optional MRN tracking.

        This method uploads files to S3 and attempts to track MRNs from
        successfully uploaded CSV files. MRN tracking is optional and only
        works for CSV files that contain an MRN column with valid MRN values.
        Non-CSV files or CSV files without MRN data are still uploaded
        successfully, but MRN tracking is skipped.

        Args:
            files_to_upload: dict of local paths of files to be uploaded,
              to desired uploaded S3 key+filename for this file.
              If desired file name is an empty string, will upload as
              local file name.
            presigned_url: Pre-signed URL received from modeller.
            presigned_fields: Pre-signed fields for uploading file.
            retry_attempts: Number of retry attempts for a failed upload.

        Returns:
            A tuple containing:
            - A dictionary of local file paths to s3 key that were successfully
              uploaded
            - A list of file paths that failed to upload.

        Note:
            Files are uploaded regardless of file type. MRN tracking is only
            performed for CSV files with an MRN column containing valid MRN values.
        """
        current_upload_dict = files_to_upload
        current_attempt = 1

        failed_files = {}
        successful_files = {}
        skipped_files = []

        subdirectory_for_upload = presigned_fields["key"].replace("/${filename}", "")

        while current_attempt <= retry_attempts and current_upload_dict:
            logger.info(
                f"Uploading files (attempt {current_attempt} of"
                f" {retry_attempts}):"
                f" uploading {len(current_upload_dict)} file(s)."
            )

            for file_name, upload_name in current_upload_dict.items():
                if not file_name.exists():
                    logger.warning(f"{file_name} does not exist, skipping.")
                    skipped_files.append(file_name)
                    continue

                if not upload_name:
                    upload_name = Path(file_name).name
                elif (
                    "." not in upload_name.split("/")[-1]
                ):  # a directory is provided instead of file name
                    upload_name = (Path(upload_name) / Path(file_name).name).as_posix()

                full_upload_path: str = (
                    Path(subdirectory_for_upload) / upload_name
                ).as_posix()

                upload_presigned_fields: _S3PresignedPOSTFields = cast(
                    _S3PresignedPOSTFields, presigned_fields.copy()
                )
                upload_presigned_fields["key"] = full_upload_path

                # Update MRN tracking and upload atomically using transaction
                # If upload fails, transaction automatically rolls back
                try:
                    self._update_mrns_and_upload(
                        file_name=file_name,
                        upload_url=presigned_url,
                        presigned_fields=upload_presigned_fields,
                        full_upload_path=full_upload_path,
                    )
                    # Upload succeeded
                    logger.info(
                        f"Successfully uploaded file {file_name} to bucket,"
                        f" s3 key: {full_upload_path}"
                    )
                    successful_files[file_name] = full_upload_path
                except (HTTPError, RequestException) as upload_error:
                    # Upload failed - transaction automatically rolled back
                    logger.error(
                        f"Encountered error uploading file {file_name}: {upload_error}"
                    )
                    failed_files[file_name] = upload_name
                except Exception as tracking_error:
                    # MRN tracking update failed - treat as upload failure
                    # since we can't track upload success
                    logger.error(
                        f"Failed to update MRN tracking"
                        f" for {file_name}: {tracking_error}."
                        f" Treating as upload failure."
                    )
                    failed_files[file_name] = upload_name

            current_upload_dict = failed_files
            failed_files = {}
            current_attempt += 1

        if current_upload_dict:
            logger.info(
                f"Failed to upload {len(current_upload_dict)} files"
                f" after maximum retries ({retry_attempts}):"
                f" {[str(file) for file in current_upload_dict.keys()]}"
            )
        if skipped_files:
            file_names_list = [str(file) for file in skipped_files]
            logger.info(
                f"Skipped {len(skipped_files)} missing files: "
                f"{', '.join(file_names_list)}"
            )

        logger.info(f"Successfully uploaded {len(successful_files)} file(s).")

        failed_files_list: list[Path] = list(current_upload_dict.keys())

        return (successful_files, failed_files_list)

    def _update_mrns_and_upload(
        self,
        file_name: Path,
        upload_url: _S3PresignedPOSTURL,
        presigned_fields: _S3PresignedPOSTFields,
        full_upload_path: str,
    ) -> None:
        """Update MRN tracking store and upload file atomically.

        This method attempts to extract MRNs from the file and update the
        tracking store, then uploads the file to S3. The method uses a transaction
        to ensure atomicity: if the S3 upload fails, the MRN tracking update is
        automatically rolled back. This maintains consistency between MRN tracking
        and actual upload success.

        **Important:** MRN tracking is optional and only works for CSV files
        with an MRN column containing valid MRN values. The file is **always**
        uploaded regardless of whether MRN tracking can be performed:
        - Non-CSV files: Uploaded successfully, MRN tracking skipped
        - CSV files without MRN column: Uploaded successfully, MRN tracking skipped
        - CSV files with MRN column but no MRN values: Uploaded successfully,
          MRN tracking skipped
        - CSV files with MRN column and MRN values: Uploaded successfully,
          MRN tracking performed

        The tracking store uses StringStore from
        bitfount/persistence/string_store.py (SQLite-backed via diskcache),
        stored in the project directory (central store for all task runs).

        Args:
            file_name: Path to the file being uploaded. Can be any file type,
              but MRN tracking only works for CSV files with an MRN column.
            upload_url: Presigned S3 upload URL.
            presigned_fields: Presigned POST fields for S3 upload.
            full_upload_path: Full S3 path where file will be uploaded.

        Raises:
            Exception: If S3 upload fails. If S3 upload fails, the transaction
                automatically rolls back any MRN tracking updates.
        """
        # Attempt to read the file as a CSV to extract MRNs.
        # If the file is not a CSV or cannot be parsed, skip MRN tracking
        # but still upload the file.
        try:
            df = pd.read_csv(file_name, index_col=False)
        except Exception as csv_error:
            # File is not a valid CSV - upload it anyway without MRN tracking
            logger.debug(
                f"File {file_name} is not a valid CSV file"
                f" (error: {csv_error}), skipping MRN tracking"
            )
            # Still attempt upload even if MRN tracking is skipped
            _upload_file_to_s3(
                upload_url=upload_url,
                presigned_fields=presigned_fields,
                file_path=file_name,
            )
            return

        # Check if MRN/Bitfount Patient ID column exists in the CSV.
        # If not, skip Patient tracking but still upload the file.
        if MRN_COL not in df.columns and _BITFOUNT_PATIENT_ID_KEY not in df.columns:
            # CSV file but no required columns for de-duplicating
            # upload it anyway without patient tracking
            logger.warning(
                f"MRN column {MRN_COL} and PID column {_BITFOUNT_PATIENT_ID_KEY}"
                f" not found in {file_name}, skipping Patient tracking"
            )
            # Still attempt upload even if MRN tracking is skipped
            _upload_file_to_s3(
                upload_url=upload_url,
                presigned_fields=presigned_fields,
                file_path=file_name,
            )
            return
        elif MRN_COL not in df.columns:
            logger.info(
                f"MRN column {MRN_COL} not found in {file_name}, "
                f"using Bitfount Patient ID to deduplicate."
            )
        elif _BITFOUNT_PATIENT_ID_KEY not in df.columns:
            logger.info(
                f"Patient ID column {_BITFOUNT_PATIENT_ID_KEY}"
                f" not found in {file_name}, using MRN to deduplicate."
            )

        # Extract all MRN/PIDs from the CSV.
        # MRNs can be stored as lists or strings, so we need to handle both.
        current_mrns_pids: set[str] = set()
        if MRN_COL in df.columns:
            for mrn_value in df[MRN_COL].dropna():
                mrn_list = _extract_mrns_from_value(mrn_value)
                current_mrns_pids.update(mrn_list)
        if _BITFOUNT_PATIENT_ID_KEY in df.columns:
            for pid_value in df[_BITFOUNT_PATIENT_ID_KEY].dropna():
                current_mrns_pids.add(pid_value)

        # If no MRN/PIDs found, skip Patient tracking but still upload the file.
        if not current_mrns_pids:
            # CSV has MRN column but no valid MRN values - upload it anyway
            logger.debug(
                f"No MRNs/PIDs found in {file_name}, skipping patient tracking"
            )
            # Still attempt upload even if MRN tracking is skipped
            _upload_file_to_s3(
                upload_url=upload_url,
                presigned_fields=presigned_fields,
                file_path=file_name,
            )
            return

        # In test run, upload the file but do not update MRN tracking so
        # test runs don't affect future production runs.
        if self._context.test_run:
            logger.debug("Test run: skipping Patient tracking store update.")
            _upload_file_to_s3(
                upload_url=upload_url,
                presigned_fields=presigned_fields,
                file_path=file_name,
            )
            return

        # Get the project directory for central store storage
        if self._context.project_id is None:
            raise ValueError(
                "project_id not available on ProtocolContext."
                " Cannot update MRN/Patient ID tracking store."
            )

        project_dir = self._context.get_project_results_dir()
        store_dir = project_dir
        store_name = MRN_TRACKING_STORE_NAME

        # Use transaction to wrap both MRN update and S3 upload
        # If S3 upload fails, transaction automatically rolls back
        with StringStore.open(store_dir, store_name) as store:
            # Read existing MRN/BPIDs from store
            existing_mrns_pids = store.get_all()

            # Check if there are any new MRNs (not already in store)
            new_mrns_pids = current_mrns_pids - existing_mrns_pids

            # Only update the store if there are new MRNs to add
            if new_mrns_pids:
                # Use transaction to ensure atomicity: if S3 upload fails,
                # MRN tracking update is automatically rolled back
                with store.transact():
                    # Add new MRNs to store (StringStore handles duplicates
                    # by overwriting)
                    store.add_many(new_mrns_pids)

                    # Attempt S3 upload inside transaction
                    # If this fails, exception is raised and transaction
                    # automatically rolls back the MRN additions
                    _upload_file_to_s3(
                        upload_url=upload_url,
                        presigned_fields=presigned_fields,
                        file_path=file_name,
                    )

                # Get total count after successful insertion and upload
                all_mrns_pids = store.get_all()

                logger.debug(
                    f"Updated MRN tracking store in {store_dir} with"
                    f" {len(new_mrns_pids)} new MRN(s) (total: {len(all_mrns_pids)})"
                )
            else:
                # All MRNs already tracked - no need to update store, but still upload
                logger.debug(
                    f"No new MRN/PIDs to add to tracking store in {store_dir}"
                    f" (all {len(current_mrns_pids)} MRN(s) already tracked)"
                )
                # Still attempt upload even if no new MRNs to track
                _upload_file_to_s3(
                    upload_url=upload_url,
                    presigned_fields=presigned_fields,
                    file_path=file_name,
                )


class S3UploadAlgorithmWithMRNTracking(S3UploadAlgorithm):
    """S3 Upload Algorithm with MRN tracking for Charcoal protocols.

    This extends S3UploadAlgorithm to automatically track which MRNs have been
    successfully uploaded to S3. This is used in per-batch reduce/upload
    scenarios where we need to track which MRNs have been uploaded across
    multiple batches.

    **Important Notes:**
    - MRN tracking is **optional** and only works for CSV files that contain
      an MRN column with valid MRN values.
    - Non-CSV files are still uploaded successfully, but MRN tracking is skipped.
    - CSV files without an MRN column are still uploaded successfully, but
      MRN tracking is skipped.
    - CSV files with an MRN column but no MRN values are still uploaded
      successfully, but MRN tracking is skipped.
    - The upload functionality works for **any file type**, regardless of whether
      MRN tracking can be performed.

    Args:
        datastructure: The data structure to use for the algorithm.
        s3_bucket: AWS S3 Bucket name to upload files into.
        aws_region: AWS region in which the bucket resides.
        aws_profile: Name of AWS profile with which to generate the
          pre-signed POST.
        upload_url_expiration: Expiration time in hours for the presigned
          S3 URLs. Defaults to 3 hours.
    """

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _WorkerSide:
        """Worker-side of the algorithm with MRN tracking."""
        return _WorkerSide(
            context=context,
            **kwargs,
        )
