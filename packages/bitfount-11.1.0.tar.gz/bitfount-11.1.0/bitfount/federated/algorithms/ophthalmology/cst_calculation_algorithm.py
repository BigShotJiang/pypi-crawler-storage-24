"""Algorithm for calculating Central Subfield Thickness (CST)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, Optional, Type

from marshmallow import fields
import numpy as np
import pandas as pd

from bitfount.data.datastructure import DataStructure
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    NoResultsModellerAlgorithm,
)
from bitfount.federated.algorithms.ophthalmology.base_thickness_calculation_algorithm import (  # noqa: E501
    CENTER_LANDMARK_TYPE,
    _BaseThicknessWorkerSide,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    CST_DEFAULT_ILM_LAYER_NAME,
    CST_DEFAULT_RADIUS_MM,
    CST_DEFAULT_RPE_LAYER_NAME,
    FOVEA_CENTRE_LANDMARK_INDEX,
    CSTMetrics,
    RetinalLayer,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.types import ProtocolContext

if TYPE_CHECKING:
    from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import GCCMetrics
    from bitfount.types import T_FIELDS_DICT

logger = _get_federated_logger("bitfount.federated")


class _CSTWorkerSide(_BaseThicknessWorkerSide[CSTMetrics]):
    """Worker side of the algorithm for CST/CRT calculation.

    Sets default values for CST calculations if not set.

    Args:
        region_radius_mm: Radius of the circular region for CST calculations.
        inner_layer_name: Name of the desired inner layer for thickness calculation.
        outer_layer_name: Name of the desired outer layer for thickness calculation.
        landmark_idx: Index of the landmark to use
            (0=start, 1=end, 2=middle).
        strict_measurement: If True, only calculate if both desired inner and outer
            layers are available. If False, use next available layer as fallback
            (default: False).
        center_landmark_type: Describes the nature of the center around which
            to calculate average thickness. This is either "fovea" or "macula"
            for now. Defaults to "fovea".
        **kwargs: Additional keyword arguments.
    """

    def __init__(
        self,
        region_radius_mm: float = CST_DEFAULT_RADIUS_MM,
        inner_layer_name: str = CST_DEFAULT_ILM_LAYER_NAME,
        outer_layer_name: str = CST_DEFAULT_RPE_LAYER_NAME,
        landmark_idx: int = FOVEA_CENTRE_LANDMARK_INDEX,
        strict_measurement: bool = False,
        center_landmark_type: CENTER_LANDMARK_TYPE = "fovea",
        **kwargs: Any,
    ) -> None:
        super().__init__(
            region_radius_mm=region_radius_mm,
            inner_layer_name=inner_layer_name,
            outer_layer_name=outer_layer_name,
            landmark_idx=landmark_idx,
            strict_measurement=strict_measurement,
            center_landmark_type=center_landmark_type,
            **kwargs,
        )

    @property
    def metric_name(self) -> str:
        """Name of the metric to be calculated. Used for logging."""
        return "CST/CRT"

    @classmethod
    def metric_class(cls) -> Type[GCCMetrics] | Type[CSTMetrics]:
        """Metric dataclass used by this algorithm."""
        return CSTMetrics

    def _calculate_metric(
        self,
        layer_pred: pd.Series,
        file_row: pd.Series,
    ) -> CSTMetrics:
        """Calculate CST or CRT for a single file.

        Args:
            layer_pred: Layer segmentation predictions for one file.
            file_row: Row containing DICOM metadata and fovea predictions.

        Returns:
            CSTMetrics object with calculated values.
        """
        # Parse fovea coordinates from the fovea model output
        fovea_coords = self._parse_center_coordinates(file_row)

        if fovea_coords is None:
            logger.warning("Fovea coordinates not available")
            return CSTMetrics()

        # Extract DICOM metadata
        slice_thickness_mm = file_row.get("Slice Thickness", None)
        pixel_spacing_row_mm = file_row.get("Pixel Spacing Row", None)
        pixel_spacing_column_mm = file_row.get("Pixel Spacing Column", None)

        if (
            slice_thickness_mm is None
            or pd.isna(slice_thickness_mm)
            or pixel_spacing_row_mm is None
            or pd.isna(pixel_spacing_row_mm)
            or pixel_spacing_column_mm is None
            or pd.isna(pixel_spacing_column_mm)
        ):
            logger.warning(
                f"Required DICOM metadata not available: "
                f"slice_thickness={slice_thickness_mm}, "
                f"pixel_spacing_row={pixel_spacing_row_mm}, "
                f"pixel_spacing_column={pixel_spacing_column_mm}"
            )
            return CSTMetrics(fovea_coordinates=fovea_coords)

        # Parse layer segmentations and build thickness map
        thickness_result = self._build_thickness_map(
            layer_pred, float(pixel_spacing_row_mm)
        )

        if thickness_result is None or thickness_result[0] is None:
            return CSTMetrics(
                fovea_coordinates=fovea_coords,
                ilm_layer_present=False,
                rpe_layer_present=False,
            )
        thickness_map_um, inner_layer, outer_layer = thickness_result

        # Calculate CST or CRT based on radius. If radius is 0, calculate
        # only CRT (Central Retinal Thickness at single center point)
        # Otherwise, calculate CST (Central Subfield Thickness)
        cst_metrics: dict[str, Optional[float]] = (
            self._compute_average_thickness_around_center(
                thickness_map_um,
                fovea_coords,
                float(slice_thickness_mm),
                float(pixel_spacing_column_mm),
                self.region_radius_mm,
            )
        )

        # Create measurement type description
        measurement_type = f"{inner_layer} to {outer_layer}"
        # Ensure n_samples is an integer or None
        cst_n_samples: Optional[int] = (
            int(n_samples)
            if (n_samples := cst_metrics.get("n_samples")) is not None
            else None
        )
        return CSTMetrics(
            cst_mean_um=cst_metrics.get("mean_um"),
            cst_median_um=cst_metrics.get("median_um"),
            cst_std_um=cst_metrics.get("std_um"),
            cst_n_samples=cst_n_samples,
            cst_radius_mm=cst_metrics.get("radius_mm"),
            fovea_coordinates=fovea_coords,
            ilm_layer_present=(RetinalLayer.from_str(inner_layer) is RetinalLayer.ILM),
            rpe_layer_present=(
                RetinalLayer.from_str(outer_layer) is RetinalLayer.RPE_LAYER
            ),
            inner_layer_used=inner_layer,
            outer_layer_used=outer_layer,
            measurement_type=measurement_type,
        )

    def _compute_average_thickness_around_center(
        self,
        # pyrefly: ignore[implicit-any]
        thickness_um: np.ndarray,
        center_coords: tuple[float, float, float],
        slice_thickness_mm: float,
        pixel_spacing_x_mm: float,
        radius_mm: float = 0.5,
    ) -> dict[str, Optional[float]]:
        """Compute CST and/or CRT based on radius setting.

            - If radius_mm == 0: This measures the thickness of single center point.
                (In CST calculations, this measurement is specifically referred
                to as CRT)
            - If radius_mm > 0: We measure the average thickness, using a circular
                region within the provided radius. If using thickness of ILM to RPE,
                this is referred to as CST.

        Args:
            thickness_um: Thickness map in micrometers, shape (num_slices, width).
            center_coords: Center coordinates (slice, x, y). Only slice and x are used.
            slice_thickness_mm: Slice thickness in mm.
            pixel_spacing_x_mm: Pixel spacing in x direction in mm.
            radius_mm: radius of circular region in mm.
                If 0, uses single center point.

        Returns:
            Dictionary with mean_um, median_um, std_um, n_samples, and radius_mm.
        """
        # Use only slice and x coordinates (en-face projection)
        cz, cx, _ = center_coords  # Ignore y coordinate
        num_slices, width = thickness_um.shape

        # Special case: radius_mm == 0 means CRT only (single center point)
        if radius_mm == 0:
            # Get integer indices for the center point
            slice_idx = int(round(cz))
            x_idx = int(round(cx))

            # Validate indices
            if not (0 <= slice_idx < num_slices and 0 <= x_idx < width):
                logger.warning(
                    f"Fovea center ({slice_idx}, {x_idx}) is outside image bounds "
                    f"({num_slices}, {width})"
                )
                return {
                    "mean_um": None,
                    "median_um": None,
                    "std_um": None,
                    "n_samples": 0,
                    "radius_mm": radius_mm,
                }

            # Get thickness at center point
            center_value = thickness_um[slice_idx, x_idx]

            # Check for NaN
            if np.isnan(center_value):
                logger.warning("Thickness value at fovea center is NaN")
                return {
                    "mean_um": None,
                    "median_um": None,
                    "std_um": None,
                    "n_samples": 0,
                    "radius_mm": radius_mm,
                }

            # For radius=0, mean/median is just the center point value
            center_value_float = float(center_value)
            logger.debug(
                f"Center point thickness at ({slice_idx}, {x_idx}): "
                f"{center_value_float:.1f}µm"
            )

            return {
                "mean_um": center_value_float,
                "median_um": center_value_float,
                "std_um": 0.0,  # No variance for single point
                "n_samples": 1,
                "radius_mm": radius_mm,
            }
        else:
            # Otherwise, calculate average thickness using circular region
            # Build mm coordinate grids
            z_coords_mm = (np.arange(num_slices) - cz) * slice_thickness_mm
            x_coords_mm = (np.arange(width) - cx) * pixel_spacing_x_mm

            # Create meshgrid
            Z, X = np.meshgrid(z_coords_mm, x_coords_mm, indexing="ij")

            # Calculate distance from center (Euclidean distance in en-face plane)
            d_mm = np.sqrt(Z**2 + X**2)

            # Create circular mask
            mask = d_mm <= radius_mm

            # Extract values within mask
            values = thickness_um[mask]

            # Calculate statistics
            n_valid = int(np.sum(~np.isnan(values)))

            if n_valid == 0:
                logger.warning(
                    "No valid thickness values within center circular region"
                )
                return {
                    "mean_um": None,
                    "median_um": None,
                    "std_um": None,
                    "n_samples": 0,
                    "radius_mm": radius_mm,
                }

            result: dict[str, Optional[float]] = {
                "mean_um": float(np.nanmean(values)),
                "median_um": float(np.nanmedian(values)),
                "std_um": float(np.nanstd(values)),
                "n_samples": n_valid,
                "radius_mm": radius_mm,
            }

            logger.debug(
                f"{self.metric_name} (radius={radius_mm}mm): "
                f"mean={result['mean_um']:.1f}µm, "
                f"n={result['n_samples']}"
            )

            return result


class CSTCalculationAlgorithm(
    BaseNonModelAlgorithmFactory[NoResultsModellerAlgorithm, _CSTWorkerSide]
):
    """Algorithm for calculating Central Subfield Thickness (CST).

    This algorithm calculates:
    - CST: Mean thickness within a circular region (default 0.5mm radius)
        centered on the fovea
    - CRT: Thickness at the single fovea center point, if the radius
        is set to 0.

    The algorithm builds a 2D thickness map from B-scan layer segmentations
    (ILM to RPE distance) and samples this map using a circular region (CST)
    or single point (CRT) centered on the fovea coordinates. Measurements
    follow ETDRS grid standards.

    The algorithm supports fallback layer selection: if ILM or RPE are not
    available, it will automatically use the next closest layer in the retinal
    layer order (unless strict_measurement is enabled). The actual layers used
    are reported in the output.

    Args:
        datastructure: The data structure to use for the algorithm.
        cst_radius_mm: Radius of circular region for CST calculation in mm
            (default: 1.0).
        ilm_layer_name: Name of the Inner Limiting Membrane layer (default: "ILM").
        rpe_layer_name: Name of the Retinal Pigment Epithelium layer (default: "RPE").
        fovea_landmark_idx: Index of fovea landmark to use: 0=start, 1=end, 2=middle
            (default: 2).
        strict_measurement: If True, only calculate if both ILM and RPE are available.
            If False, use next available layer as fallback (default: False).
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "cst_radius_mm": fields.Float(allow_none=True),
        "ilm_layer_name": fields.String(allow_none=True),
        "rpe_layer_name": fields.String(allow_none=True),
        "fovea_landmark_idx": fields.Integer(allow_none=True),
        "strict_measurement": fields.Boolean(allow_none=True),
    }

    def __init__(
        self,
        datastructure: DataStructure,
        cst_radius_mm: float = CST_DEFAULT_RADIUS_MM,
        ilm_layer_name: str = CST_DEFAULT_ILM_LAYER_NAME,
        rpe_layer_name: str = CST_DEFAULT_RPE_LAYER_NAME,
        fovea_landmark_idx: int = FOVEA_CENTRE_LANDMARK_INDEX,
        strict_measurement: bool = False,
        **kwargs: Any,
    ) -> None:
        # Validation for input layer names
        try:
            RetinalLayer.from_str(ilm_layer_name)
        except ValueError as e:
            raise ValueError(
                f"ilm_layer_name input for CSTCalculationAlgorithm is invalid. "
                f"Raised ValueError: {str(e)}"
            ) from e

        try:
            RetinalLayer.from_str(rpe_layer_name)
        except ValueError as e:
            raise ValueError(
                f"rpe_layer_name input for CSTCalculationAlgorithm is invalid. "
                f"Raised ValueError: {str(e)}"
            ) from e

        self.cst_radius_mm = cst_radius_mm
        self.ilm_layer_name = ilm_layer_name
        self.rpe_layer_name = rpe_layer_name
        self.fovea_landmark_idx = fovea_landmark_idx
        self.strict_measurement = strict_measurement
        super().__init__(datastructure=datastructure, **kwargs)

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> NoResultsModellerAlgorithm:
        """Modeller-side of the algorithm."""
        return NoResultsModellerAlgorithm(
            log_message="Running CST Calculation Algorithm",
            **kwargs,
        )

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _CSTWorkerSide:
        """Worker-side of the algorithm."""
        return _CSTWorkerSide(
            region_radius_mm=self.cst_radius_mm,
            inner_layer_name=self.ilm_layer_name,
            outer_layer_name=self.rpe_layer_name,
            landmark_idx=self.fovea_landmark_idx,
            strict_measurement=self.strict_measurement,
            **kwargs,
        )
