"""Algorithm for calculating Ganglion Cell Complex (GCC)."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any, ClassVar, Type

from marshmallow import fields
import numpy as np
import pandas as pd

from bitfount.data.datastructure import DataStructure
from bitfount.federated.algorithms.base import (
    BaseNonModelAlgorithmFactory,
    NoResultsModellerAlgorithm,
)
from bitfount.federated.algorithms.ophthalmology.base_thickness_calculation_algorithm import (  # noqa: E501
    CENTER_LANDMARK_TYPE,
    _BaseThicknessWorkerSide,
)
from bitfount.federated.algorithms.ophthalmology.ophth_algo_types import (
    GCC_DEFAULT_INNER_LAYER_NAME,
    GCC_DEFAULT_OUTER_LAYER_NAME,
    GCC_DEFAULT_RADIUS_MM,
    MACULA_CENTRE_LANDMARK_INDEX,
    CSTMetrics,
    GCCMetrics,
    RetinalLayer,
)
from bitfount.federated.logging import _get_federated_logger
from bitfount.federated.types import ProtocolContext

if TYPE_CHECKING:
    from bitfount.types import T_FIELDS_DICT

logger = _get_federated_logger("bitfount.federated")


class GlaucomaStage(Enum):
    """Enum to indicate stage of Glaucoma."""

    UNKNOWN = 0
    GREEN = 1
    YELLOW = 2
    ORANGE = 3
    RED = 4

    def next_level(self) -> GlaucomaStage:
        """Get one stage worse than current stage."""
        if self is GlaucomaStage.RED:
            return GlaucomaStage.RED
        if self is GlaucomaStage.UNKNOWN:
            return GlaucomaStage.UNKNOWN
        return GlaucomaStage(self.value + 1)


class _GCCWorkerSide(_BaseThicknessWorkerSide[GCCMetrics]):
    """Worker side of the algorithm for GCC calculation.

    Sets default values for GCC calculations if not set.

    Args:
        region_radius_mm: Radius of the circular region for GCC calculations.
        inner_layer_name: Name of the desired inner layer for thickness calculation.
        outer_layer_name: Name of the desired outer layer for thickness calculation.
        landmark_idx: Index of the landmark to use
            (0=start, 1=end, 2=middle).
        strict_measurement: If True, only calculate if both desired inner and outer
            layers are available. If False, use next available layer as fallback
            (default: False).
        center_landmark_type: Describes the nature of the center around which
            to calculate average thickness. This is either "fovea" or "macula"
            for now. Defaults to "fovea".
        **kwargs: Additional keyword arguments.
    """

    def __init__(
        self,
        region_radius_mm: float = GCC_DEFAULT_RADIUS_MM,
        inner_layer_name: str = GCC_DEFAULT_INNER_LAYER_NAME,
        outer_layer_name: str = GCC_DEFAULT_OUTER_LAYER_NAME,
        landmark_idx: int = MACULA_CENTRE_LANDMARK_INDEX,
        strict_measurement: bool = True,
        center_landmark_type: CENTER_LANDMARK_TYPE = "macula",
        **kwargs: Any,
    ) -> None:
        super().__init__(
            region_radius_mm=region_radius_mm,
            inner_layer_name=inner_layer_name,
            outer_layer_name=outer_layer_name,
            landmark_idx=landmark_idx,
            strict_measurement=strict_measurement,
            center_landmark_type=center_landmark_type,
            **kwargs,
        )

    @property
    def metric_name(self) -> str:
        """Name of the metric to be calculated. Used for logging."""
        return "GCC"

    @classmethod
    def metric_class(cls) -> Type[GCCMetrics] | Type[CSTMetrics]:
        """Metric dataclass used by this algorithm."""
        return GCCMetrics

    def _calculate_metric(
        self,
        layer_pred: pd.Series,
        file_row: pd.Series,
    ) -> GCCMetrics:
        """Calculate GCC for a single file.

        Args:
            layer_pred: Layer segmentation predictions for one file.
            file_row: Row containing DICOM metadata and macula predictions.

        Returns:
            GCCMetrics object with calculated values.
        """
        # Parse macula coordinates from the Landmarks model output
        macula_coords = self._parse_center_coordinates(file_row)

        if macula_coords is None:
            logger.warning("Macula coordinates not available")
            return GCCMetrics()

        # Extract DICOM metadata
        slice_thickness_mm = file_row.get("Slice Thickness", None)
        pixel_spacing_row_mm = file_row.get("Pixel Spacing Row", None)
        pixel_spacing_column_mm = file_row.get("Pixel Spacing Column", None)

        if (
            slice_thickness_mm is None
            or pd.isna(slice_thickness_mm)
            or pixel_spacing_row_mm is None
            or pd.isna(pixel_spacing_row_mm)
            or pixel_spacing_column_mm is None
            or pd.isna(pixel_spacing_column_mm)
        ):
            logger.warning(
                f"Required DICOM metadata not available: "
                f"slice_thickness={slice_thickness_mm}, "
                f"pixel_spacing_row={pixel_spacing_row_mm}, "
                f"pixel_spacing_column={pixel_spacing_column_mm}"
            )
            return GCCMetrics(macula_coordinates=macula_coords)

        # Parse layer segmentations and build thickness map
        thickness_result = self._build_thickness_map(
            layer_pred, float(pixel_spacing_row_mm)
        )

        if thickness_result is None or thickness_result[0] is None:
            return GCCMetrics(
                macula_coordinates=macula_coords,
                rnfl_layer_present=False,
                ipl_layer_present=False,
            )
        thickness_map_um, inner_layer, outer_layer = thickness_result

        gcc_metrics: GCCMetrics = self._compute_gcc(
            thickness_map_um,
            macula_coords,
            float(slice_thickness_mm),
            float(pixel_spacing_column_mm),
            radius_mm=self.region_radius_mm,
        )

        gcc_metrics.gcc_radius_mm = self.region_radius_mm
        gcc_metrics.macula_coordinates = macula_coords
        gcc_metrics.rnfl_layer_present = (
            RetinalLayer.from_str(inner_layer) is RetinalLayer.RNFL
        )
        gcc_metrics.ipl_layer_present = (
            RetinalLayer.from_str(outer_layer) is RetinalLayer.IPL
        )
        gcc_metrics.inner_layer_used = inner_layer
        gcc_metrics.outer_layer_used = outer_layer
        gcc_metrics.measurement_type = f"{inner_layer} to {outer_layer}"

        return gcc_metrics

    def _compute_gcc(
        self,
        # pyrefly: ignore[implicit-any]
        thickness_um: np.ndarray,
        center_coords: tuple[float, float, float],
        slice_thickness_mm: float,
        pixel_spacing_x_mm: float,
        radius_mm: float = 1.0,
    ) -> GCCMetrics:
        """Compute partial GCC asymmetry index and related metrics.

        Args:
            thickness_um: Thickness map in micrometers, shape (num_slices, width).
            center_coords: Center coordinates (slice, x, y). Only slice and x are used.
            slice_thickness_mm: Slice thickness in mm.
            pixel_spacing_x_mm: Pixel spacing in x direction in mm.
            radius_mm: Radius of circular region in mm.

        Returns:
            Partially calculated GCCMetrics with:
             - gcc_mean_superior
             - gcc_mean_inferior
             - gcc_asymmetry_index
             - min_thickness
             - glaucoma_stage
        """

        if radius_mm == 0:
            logger.warning("Radius is zero, unable to calculate GCC Metrics.")
            return GCCMetrics()

        # Use only slice and x coordinates (en-face projection)
        cz, cx, _ = center_coords  # Ignore y coordinate
        num_slices, width = thickness_um.shape

        # Otherwise, calculate average thickness using circular region
        # Build mm coordinate grids
        z_coords_mm = (np.arange(num_slices) - cz) * slice_thickness_mm
        x_coords_mm = (np.arange(width) - cx) * pixel_spacing_x_mm

        # Create meshgrid
        Z, X = np.meshgrid(z_coords_mm, x_coords_mm, indexing="ij")

        # Calculate distance from center (Euclidean distance in en-face plane)
        d_mm = np.sqrt(Z**2 + X**2)

        # Create circular mask including superior + inferior region
        mask = d_mm <= radius_mm

        # Get minimum thickness in this circular region
        values = thickness_um[mask]
        n_valid = int(np.sum(~np.isnan(values)))

        if n_valid == 0:
            logger.warning("No valid thickness values within center circular region")
            return GCCMetrics()

        minimum_thickness = float(np.nanmin(values))

        # Initial Glaucoma stages
        # Stage, Min Thickness Range (in um)
        # Green, 105 – 130
        # Yellow, 92 – 105
        # Orange, 87 – 92
        # Red, <= 87
        if 105 < minimum_thickness <= 130:
            glaucoma_stage = GlaucomaStage.GREEN
        elif 92 < minimum_thickness <= 105:
            glaucoma_stage = GlaucomaStage.YELLOW
        elif 87 < minimum_thickness <= 92:
            glaucoma_stage = GlaucomaStage.ORANGE
        elif minimum_thickness <= 87:
            glaucoma_stage = GlaucomaStage.RED
        else:
            # >130 : Unknown, other pathologies might be present
            glaucoma_stage = GlaucomaStage.UNKNOWN

        # Create mask for superior region
        # (Note that the thickness along the line Z=0 is ignored)
        superior_mask = (mask * Z) > 0
        inferior_mask = (mask * Z) < 0

        # Get average thickness in superior and inferior regions
        superior_mean = float(np.nanmean(thickness_um[superior_mask]))
        inferior_mean = float(np.nanmean(thickness_um[inferior_mask]))

        # GCC Asymmetry index = ratio of Superior / Inferior
        if np.isnan(superior_mean):
            superior_mean = None
        if np.isnan(inferior_mean):
            inferior_mean = None

        if inferior_mean == 0 or superior_mean is None or inferior_mean is None:
            asym_index = None
        else:
            asym_index = superior_mean / inferior_mean

        # Stage
        # The normal asymmetry range is [0.95, 1.05]
        # If the asymmetry index lies outside this range, the severity is
        # increased by one stage, provided a higher-severity stage exists.
        if asym_index is not None and glaucoma_stage is not GlaucomaStage.UNKNOWN:
            if asym_index < 0.95 or asym_index > 1.05:
                glaucoma_stage = glaucoma_stage.next_level()

        result = GCCMetrics(
            gcc_mean_superior=superior_mean,
            gcc_mean_inferior=inferior_mean,
            gcc_asymmetry_index=asym_index,
            min_thickness=minimum_thickness,
            glaucoma_stage=glaucoma_stage.name,
        )

        asym_index_log = None if asym_index is None else round(asym_index, 1)
        superior_mean = None if superior_mean is None else round(superior_mean, 1)
        inferior_mean = None if inferior_mean is None else round(inferior_mean, 1)
        logger.debug(
            f"{self.metric_name} computed (radius={radius_mm}mm): "
            f"min_thickness={minimum_thickness:.1f}µm,"
            f"superior mean={superior_mean}µm, "
            f"inferior mean={inferior_mean}µm, "
            f"gcc asymmetry index={asym_index_log}, "
            f"n={n_valid}"
        )

        return result


class GCCCalculationAlgorithm(
    BaseNonModelAlgorithmFactory[NoResultsModellerAlgorithm, _GCCWorkerSide]
):
    """Algorithm for calculating Ganglion Cell Complex (GCC).

    The GCC is the complex of the three innermost retinal layers that are
    particularly affected by glaucoma because they contain all parts of
    the ganglion cells (axons, cell bodies, and dendrites). It is composed
    of the RNFL + GCL + IPL layers.

    The GCC asymmetry index is the ratio of thickness of the superior region
    to the inferior region, in a 3mm radius around the macula center.

    The algorithm uses the _BaseThicknessCalculationAlgo to build a 2D thickness
    map from B-scan layer segmentations, based on (RNFL to IPL distance) and
    samples this map using a circular region centered on the macula coordinates.

    The algorithm supports fallback layer selection: if RNFL or IPL are not
    available, it will automatically use the next closest layer in the retinal
    layer order (unless strict_measurement is enabled). The actual layers used
    are reported in the output.

    Args:
        datastructure: The data structure to use for the algorithm.
        region_radius_mm: Radius of circular region for GCC calculation in mm
            (default: 1.0).
        inner_layer_name: Name of the innermost layer to use (default: "RNFL").
        outer_layer_name: Name of the outermost layer to yse (default: "IPL").
        macula_landmark_idx: Index of macula landmark to use: 0=start, 1=end, 2=middle
            (default: 2).
        strict_measurement: If True, only calculate if both RNFL and IPL are available.
            If False, use next available layer as fallback (default: True).
    """

    fields_dict: ClassVar[T_FIELDS_DICT] = {
        "region_radius_mm": fields.Float(allow_none=True),
        "inner_layer_name": fields.String(allow_none=True),
        "outer_layer_name": fields.String(allow_none=True),
        "macula_landmark_idx": fields.Integer(allow_none=True),
        "strict_measurement": fields.Boolean(allow_none=True),
    }

    def __init__(
        self,
        datastructure: DataStructure,
        region_radius_mm: float = GCC_DEFAULT_RADIUS_MM,
        inner_layer_name: str = GCC_DEFAULT_INNER_LAYER_NAME,
        outer_layer_name: str = GCC_DEFAULT_OUTER_LAYER_NAME,
        macula_landmark_idx: int = MACULA_CENTRE_LANDMARK_INDEX,
        strict_measurement: bool = True,
        **kwargs: Any,
    ) -> None:
        # Validation for input layer names
        try:
            RetinalLayer.from_str(inner_layer_name)
        except ValueError as e:
            raise ValueError(
                f"inner_layer_name input for GCCCalculationAlgorithm is invalid. "
                f"Raised ValueError: {str(e)}"
            ) from e

        try:
            RetinalLayer.from_str(outer_layer_name)
        except ValueError as e:
            raise ValueError(
                f"outer_layer_name input for GCCCalculationAlgorithm is invalid. "
                f"Raised ValueError: {str(e)}"
            ) from e

        if region_radius_mm <= 0:
            raise ValueError(
                f"region_radius_mm for GCCCalculationAlgorithm must be a positive "
                f"number, got {region_radius_mm=}"
            )

        self.region_radius_mm = region_radius_mm
        self.inner_layer_name = inner_layer_name
        self.outer_layer_name = outer_layer_name
        self.macula_landmark_idx = macula_landmark_idx
        self.strict_measurement = strict_measurement
        super().__init__(datastructure=datastructure, **kwargs)

    def modeller(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> NoResultsModellerAlgorithm:
        """Modeller-side of the algorithm."""
        return NoResultsModellerAlgorithm(
            log_message="Running GCC Calculation Algorithm",
            **kwargs,
        )

    def worker(
        self,
        *,
        context: ProtocolContext,
        **kwargs: Any,
    ) -> _GCCWorkerSide:
        """Worker-side of the algorithm."""
        return _GCCWorkerSide(
            region_radius_mm=self.region_radius_mm,
            inner_layer_name=self.inner_layer_name,
            outer_layer_name=self.outer_layer_name,
            landmark_idx=self.macula_landmark_idx,
            strict_measurement=self.strict_measurement,
            **kwargs,
        )
