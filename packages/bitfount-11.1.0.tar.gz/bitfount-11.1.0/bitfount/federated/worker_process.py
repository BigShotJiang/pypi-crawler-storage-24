"""Contains classes and methods for spawning the Worker in a dedicated process."""

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from functools import partial
import logging
import multiprocessing
import pickle  # nosec: B403 # pickle usage
from sqlite3 import Connection
from typing import Any, Callable, Literal, Optional, cast

import pandas as pd

from bitfount.data.datasources.base_source import BaseSource, FileSystemIterableSource
from bitfount.data.datasources.utils import ORIGINAL_FILENAME_METADATA_COLUMN
from bitfount.data.datasplitters import DatasetSplitter
from bitfount.data.schema import BitfountSchema
from bitfount.externals.general.authentication import ExternallyManagedJWT
from bitfount.federated.exceptions import TaskAbortError
from bitfount.federated.helper import _create_message_service
from bitfount.federated.pod_db_utils import get_failed_files_cache
from bitfount.federated.pod_vitals import _PodVitals
from bitfount.federated.privacy.differential import DPPodConfig
from bitfount.federated.protocols.base import BaseWorkerProtocol
from bitfount.federated.protocols.model_protocols.federated_averaging import (
    _WorkerSide as _FederatedAveragingWorkerSide,
)
from bitfount.federated.transport.config import MessageServiceConfig
from bitfount.federated.transport.message_service import _BitfountMessageType
from bitfount.federated.transport.worker_transport import _WorkerMailbox
from bitfount.federated.types import (
    EHRConfig,
    InferenceLimits,
    ModelURLs,
    ProtocolContext,
    TaskContext,
)
from bitfount.federated.utils import get_ehr_secrets
from bitfount.hub.api import BitfountHub
from bitfount.hub.helper import _create_bitfount_session, get_hub_url
from bitfount.runners.config_schemas.common_schemas import SecretsUse
from bitfount.runners.config_schemas.hub_schemas import APIKeys
from bitfount.runners.utils import get_secrets_for_use
from bitfount.utils.db_connector import ProjectDbConnector

__all__ = ["_WorkerIPCMessage", "_WorkerProcessConfig", "_run_protocol_in_child"]

logger = logging.getLogger(__name__)


@dataclass(kw_only=True)
class _WorkerProcessConfig:
    """A serialisable Dataclass that holds config to reinstantiate a Worker process.

    All fields are picklable. The only _Worker attribute intentionally absent is
    ``mailbox`` - the subprocess builds a fresh _WorkerMailbox from the fields below.
    """

    # Transport (mailbox reconstruction)
    ms_config: MessageServiceConfig
    modeller_mailbox_id: str
    modeller_name: str
    pod_mailbox_ids: dict[str, str]
    task_id: str
    aes_encryption_key: bytes

    # Worker attributes
    datasource: BaseSource
    datasource_name: str
    serialized_protocol: bytes
    parent_pod_identifier: str
    schema: BitfountSchema
    batched_execution: bool
    test_run: bool
    project_id: str | None
    run_on_new_data_only: bool
    force_rerun_failed_files: bool
    inference_limits: dict[str, InferenceLimits]
    model_urls: dict[str, ModelURLs]

    # Optional Worker attributes
    pod_vitals: _PodVitals | None = None
    pod_dp: DPPodConfig | None = None
    project_db_connector: ProjectDbConnector | None = None
    data_identifier: str | None = None
    secrets: (
        APIKeys
        | ExternallyManagedJWT
        | dict[SecretsUse, APIKeys | ExternallyManagedJWT]
        | None
    ) = None
    ehr_config: EHRConfig | None = None
    data_splitter: DatasetSplitter | None = None
    task_hash: str | None = None


@dataclass
class _WorkerIPCMessage:
    """Base class for messages placed on the worker IPC result queue."""

    datasource_state: dict[str, Any] | None = None


@dataclass
class _WorkerIPCOkMessage(_WorkerIPCMessage):
    """Placed on the queue when the worker protocol completes successfully."""

    status: Literal["ok"] = "ok"


@dataclass
class _WorkerIPCAbortMessage(_WorkerIPCMessage):
    """Placed on the queue when the worker protocol is aborted via TaskAbortError."""

    status: Literal["abort"] = "abort"
    message_already_sent: bool = False


@dataclass
class _WorkerIPCErrorMessage(_WorkerIPCMessage):
    """Placed on the queue when the worker protocol raises an unexpected exception."""

    status: Literal["error"] = "error"
    exc: BaseException = field(default_factory=RuntimeError)


def _capture_datasource_state(worker_protocol: BaseWorkerProtocol) -> dict[str, Any]:
    """Extract mutable file-tracking fields from the datasource after a run.

    These fields are mutated by ``_cleanup_after_task`` in the parent, so we
    capture their values in the child and ship them back on the result queue so
    the parent can apply the same mutations before calling cleanup.

    Returns an empty dict if the datasource is not a FileSystemIterableSource.
    """
    datasource = getattr(worker_protocol, "datasource", None)
    if not isinstance(datasource, FileSystemIterableSource):
        return {}
    return {
        "selected_file_names_override": list(datasource.selected_file_names_override),
        "skipped_files": set(datasource.skipped_files),
        "new_file_names_only_set": (
            set(datasource.new_file_names_only_set)
            if datasource.new_file_names_only_set is not None
            else None
        ),
    }


# TODO: [BIT-7749] Consolidate these when this module is called in worker.py
def _get_processed_files_cache(
    project_db_con: Connection,
    task_hash: str,
    datasource: FileSystemIterableSource,
) -> dict[str, datetime]:
    """Gets processed files info from db for filtering during batched execution.

    Returns:
        Dictionary mapping filename -> last_modified_datetime for processed files.
    """
    logger.debug("Loading processed files info from database")
    try:
        run_records = pd.read_sql(
            f'SELECT * FROM "{task_hash}-v2"',  # nosec hardcoded_sql_expressions # noqa: E501
            project_db_con,
        )
        if run_records.empty:
            logger.debug("No processed files found in database")
            return {}

        columns = datasource.get_project_db_sqlite_columns()
        run_records_dict = dict(zip(run_records[columns[0]], run_records[columns[1]]))

        # Convert to datetime objects for comparison
        processed_files = {}
        for filename, last_modified_str in run_records_dict.items():
            processed_files[filename] = datetime.fromisoformat(last_modified_str)

        logger.debug(f"Loaded {len(processed_files)} processed files from database")
        return processed_files

    except Exception as e:
        logger.warning(
            f"Error loading processed files: {e}. Treating all files as new."
        )
        return {}


# TODO: [BIT-7749] Consolidate these when this module is called in worker.py
def _get_failed_files_cache(
    project_db_con: Connection,
    task_hash: str,
    datasource: FileSystemIterableSource,
    force_rerun_failed_files: bool,
) -> Optional[dict[str, dict[str, str]]]:
    """Retrieves failed files cache from database.

    Returns:
        Dictionary mapping filename -> failure info for previously failed files.
        Returns None if force_rerun_failed_files is True.
    """
    if force_rerun_failed_files:
        logger.debug("Force rerun enabled, returning empty failed files cache")
        return None
    logger.debug("Loading failed files info from database")
    return get_failed_files_cache(project_db_con, task_hash, datasource)


# TODO: [BIT-7749] Consolidate these when this module is called in worker.py
def _get_results_from_cache_for_batch(
    files_in_batch: list[str],
    project_db_con: Connection,
    task_hash: str,
) -> pd.DataFrame:
    """Gets the cached results for files in the batch.

    Returns:
        DataFrame containing all the required columns for Longitudinal Algo,
        for the required files in the batch.
    """
    logger.debug("Loading cached results for the batch")
    files_in_quotes = [f"'{filename}'" for filename in files_in_batch]
    file_list = ",".join(files_in_quotes)
    try:
        run_records = pd.read_sql(
            f'SELECT * FROM "{task_hash}-v2" '
            f"where {ORIGINAL_FILENAME_METADATA_COLUMN} in ({file_list})",  # nosec hardcoded_sql_expressions # noqa: E501
            project_db_con,
        )

        if run_records.empty:
            logger.debug("No records found in database for required files")
            return pd.DataFrame()

        logger.debug(
            f"Loaded {len(run_records)} for {len(files_in_batch)} files "
            f"required in batch."
        )
        return run_records

    except Exception as e:
        logger.warning(
            f"Error loading processed files: {e} "
            f"No cached results from previous runs returned."
        )
        return pd.DataFrame()


def _setup_worker_process(
    config: _WorkerProcessConfig,
) -> tuple[
    BaseWorkerProtocol,
    _WorkerMailbox,
    dict[str, Any],
    Optional[dict[str, datetime]],
    Optional[dict[str, dict[str, str]]],
    Optional[Callable[[list[str]], pd.DataFrame]],
]:
    """Reconstruct all runtime objects the child process needs before running.

    Separated from ``_run_protocol_in_child`` so the setup logic can be tested
    and reasoned about independently.

    Returns:
        A tuple of
        ``(worker_protocol, worker_mailbox, hook_kwargs,
        processed_files_cache, failed_files_cache, cache_getter)``.
    """
    # Reconstruct message service from config primitives.
    secrets = get_secrets_for_use(config.secrets, "bitfount")
    hub_url = get_hub_url()
    session = _create_bitfount_session(url=hub_url, secrets=secrets)
    message_service = _create_message_service(
        session=session,
        ms_config=config.ms_config,
    )
    # Build a fresh _WorkerMailbox.
    # The mailbox __init__ calls _setup_federated_logging() which
    # registers a LOG_MESSAGE handler. We delete it immediately so
    # the parent mailbox remains the sole consumer of those messages.
    worker_mailbox = _WorkerMailbox(
        pod_identifier=config.parent_pod_identifier,
        modeller_mailbox_id=config.modeller_mailbox_id,
        modeller_name=config.modeller_name,
        aes_encryption_key=config.aes_encryption_key,
        message_service=message_service,
        pod_mailbox_ids=config.pod_mailbox_ids,
        task_id=config.task_id,
        handlers=None,
    )
    # Suppress LOG_MESSAGE handling in the child — the parent owns it.
    worker_mailbox.delete_all_handlers(_BitfountMessageType.LOG_MESSAGE)

    # Deserialize the protocol (arrives with mailbox=None).
    worker_protocol = cast(
        BaseWorkerProtocol,
        pickle.loads(config.serialized_protocol),  # nosec: B301 # pickle usage
    )
    # Re-inject the fresh mailbox.
    worker_protocol.mailbox = worker_mailbox

    # Re-inject hub onto algorithm objects that embed it.
    hub = BitfountHub(session=session, url=hub_url)
    for alg in worker_protocol.algorithms:
        if hasattr(alg, "hub"):
            setattr(alg, "hub", hub)  # noqa: B010 - dynamic injection; alg.hub rejected by pyrefly (Protocol type)
        model = getattr(alg, "model", None)
        if model is not None and hasattr(model, "hub"):
            setattr(model, "hub", hub)  # noqa: B010 - dynamic injection; model.hub rejected by pyrefly (Protocol type)

    # Datasource — use directly from config (picklable path).
    datasource = config.datasource

    # hook_kwargs — reconstruct the minimal data the hooks need from config
    # so that _Worker (which cannot cross the process boundary) is not required.
    def _get_project_db_con_if_allowed() -> Any | None:
        """Reconstruct the DB connection check using config fields."""
        if (
            config.project_db_connector is None
            or config.project_id is None
            or not datasource.supports_project_db
        ):
            return None
        if isinstance(worker_protocol, _FederatedAveragingWorkerSide):
            return None
        return config.project_db_connector.get_project_db_connection(config.project_id)

    hook_kwargs: dict[str, Any] = {
        "worker": config,
        "db_con": _get_project_db_con_if_allowed,
    }

    # Load file-processing caches from the project DB when run_on_new_data_only
    # is enabled, mirroring the logic in _Worker.run_protocol() so the child
    # process skips already-processed files instead of reprocessing all of them.
    processed_files_cache: Optional[dict[str, datetime]] = None
    failed_files_cache: Optional[dict[str, dict[str, str]]] = None
    cache_getter: Optional[Callable[[list[str]], pd.DataFrame]] = None

    project_db_con = _get_project_db_con_if_allowed()
    if project_db_con is not None and config.task_hash is not None:
        cache_getter = partial(
            _get_results_from_cache_for_batch,
            project_db_con=project_db_con,
            task_hash=config.task_hash,
        )

        if config.run_on_new_data_only and isinstance(
            datasource, FileSystemIterableSource
        ):
            processed_files_cache = _get_processed_files_cache(
                project_db_con, config.task_hash, datasource
            )
            failed_files_cache = _get_failed_files_cache(
                project_db_con,
                config.task_hash,
                datasource,
                config.force_rerun_failed_files,
            )

    return (
        worker_protocol,
        worker_mailbox,
        hook_kwargs,
        processed_files_cache,
        failed_files_cache,
        cache_getter,
    )


def _run_protocol_in_child(
    config: _WorkerProcessConfig,
    result_queue: "multiprocessing.Queue[_WorkerIPCMessage]",
) -> None:
    """Target function for the child worker ``multiprocessing.Process``.

    Must be a plain module-level function (not a method) so it can be pickled
    by the ``spawn`` start method.

    All exceptions are caught and placed on ``result_queue``; this function
    must never raise.
    """
    logger.debug("Child worker process starting (task_id=%s)", config.task_id)

    worker_protocol: BaseWorkerProtocol | None = None

    try:
        (
            worker_protocol,
            worker_mailbox,
            hook_kwargs,
            processed_files_cache,
            failed_files_cache,
            cache_getter,
        ) = _setup_worker_process(config)

        # Initialise the protocol with worker-specific data.
        worker_protocol.initialise(
            datasource=config.datasource,
            task_id=config.task_id,
            data_splitter=config.data_splitter,
            pod_dp=config.pod_dp,
            pod_identifier=worker_mailbox.pod_identifier,
            project_id=config.project_id,
            ehr_config=config.ehr_config,
            parent_pod_identifier=config.parent_pod_identifier,
            datasource_name=config.datasource_name,
            data_identifier=config.data_identifier,
            ehr_secrets=get_ehr_secrets(config.secrets),
        )
        # Build ProtocolContext from config fields; the child owns task-level metadata.
        protocol_context = ProtocolContext(
            task_id=config.task_id,
            task_context=TaskContext.WORKER,
            inference_limits=config.inference_limits,
            model_urls=config.model_urls,
            project_id=config.project_id,
            test_run=config.test_run,
        )
        # Run the protocol; cancellation is handled by the parent via SIGTERM/SIGKILL.
        asyncio.run(
            worker_protocol.run(
                pod_vitals=config.pod_vitals,
                context=protocol_context,
                batched_execution=config.batched_execution,
                test_run=config.test_run,
                hook_kwargs=hook_kwargs,
                processed_files_cache=processed_files_cache,
                failed_files_cache=failed_files_cache,
                cache_getter=cache_getter,
            )
        )

        # Handle success case
        result_queue.put_nowait(
            _WorkerIPCOkMessage(
                datasource_state=_capture_datasource_state(worker_protocol),
            )
        )

    # Handle TaskAbortError case
    except TaskAbortError as tae:
        result_queue.put_nowait(
            _WorkerIPCAbortMessage(
                message_already_sent=tae.message_already_sent,
                datasource_state=_capture_datasource_state(worker_protocol)
                if worker_protocol is not None
                else None,
            )
        )

    # Any other exception — serialize and ship; never raise.
    except BaseException as e:
        exc_to_send: BaseException
        try:
            pickle.dumps(e)
            exc_to_send = e
        except Exception:
            exc_to_send = RuntimeError(str(e))

        result_queue.put_nowait(
            _WorkerIPCErrorMessage(
                exc=exc_to_send,
            )
        )
