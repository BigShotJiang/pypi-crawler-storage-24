"""Useful objects/functions for federated learning.

This is primarily intended for use by modules outside of the `federated` package.
It cannot be imported by most modules in the `federated` package because it would
introduce circular imports.
"""

from __future__ import annotations

from collections.abc import Mapping
import inspect
import re
import threading
from types import ModuleType
from typing import Any, Optional, Union

from bitfount.exceptions import BitfountError
from bitfount.externals.general.authentication import ExternallyManagedJWT
import bitfount.federated.aggregators.base as aggregators
import bitfount.federated.algorithms.base as algorithms
from bitfount.federated.logging import _get_federated_logger
import bitfount.federated.protocols.base as protocols
from bitfount.models.base_models import _BaseModel
from bitfount.runners.config_schemas.common_schemas import SecretsUse
from bitfount.runners.config_schemas.hub_schemas import APIKeys
from bitfount.runners.utils import get_secrets_for_use

_logger = _get_federated_logger(__name__)

__all__: list[str] = []

# This is a read-only dictionary mapping the name of an aggregator to the class itself
_AGGREGATORS: Mapping[str, type[aggregators._BaseAggregatorFactory]] = (
    aggregators.registry
)


# This is a read-only dictionary mapping the name of an algorithm to the class itself
# pyrefly: ignore[implicit-any]
_ALGORITHMS: Mapping[str, type[algorithms.BaseAlgorithmFactory]] = algorithms.registry


# This is a read-only dictionary mapping the name of a protocol to the class itself
_PROTOCOLS: Mapping[str, type[protocols.BaseProtocolFactory]] = protocols.registry


# Pattern for Hugging Face default labels (LABEL_0, LABEL_1, etc.) when model
# config lacks proper id2label mapping for an index
_LABEL_PATTERN = re.compile(r"^LABEL_(\d+)$")


def _load_models_from_module(module: ModuleType) -> dict[str, type[_BaseModel]]:
    """Load all concrete classes subclassing _BaseModel from a module.

    Args:
        module (ModuleType): The module to load models from.

    Returns:
        dict[str, type[_BaseModel]]: A dict of class name to class for all models found
    """
    found_models: dict[str, type[_BaseModel]] = {}

    # Load any concrete classes that extend DistributedModelMixIn and _BaseModel
    for cls_name, class_ in vars(module).items():
        if (
            inspect.isclass(class_)
            and issubclass(class_, _BaseModel)
            and not inspect.isabstract(class_)
        ):
            found_models[cls_name] = class_

    return found_models


class _StoppableThead(threading.Thread):
    """Stoppable thread by using a stop `threading.Event`.

    Args:
        stop_event: This is a `threading.Event` which when set, should stop the thread.
            The function that is being executed in the thread is required to regularly
            check the status of this event.
        **kwargs: Keyword arguments passed to parent constructor.
    """

    def __init__(self, stop_event: threading.Event, **kwargs: Any) -> None:
        self._stop_event = stop_event
        super().__init__(**kwargs)

    @property
    def stopped(self) -> bool:
        """Returns whether or not the stop event has been set."""
        return self._stop_event.is_set()

    def stop(self) -> None:
        """Sets the stop event."""
        self._stop_event.set()


def _id2label_lookup(id2label: Mapping[Any, str], index: Union[int, str]) -> str:
    r"""Resolve label from id2label, supporting both int and string keys.

    Configs loaded from JSON (e.g. from the Hub) often have id2label with string
    keys (e.g. \"0\", \"1\") because JSON object keys are always strings.

    For Hugging Face default labels (LABEL_0, LABEL_1, etc.) produced when the
    model config lacks proper id2label mapping, also tries looking up by the
    numeric ID (LABEL_X corresponds to index X per Hugging Face convention).
    """
    if index in id2label:
        return id2label[index]
    # Try string key for configs loaded from JSON
    if str(index) in id2label:
        return id2label[str(index)]
    # For Hugging Face default labels (LABEL_0, LABEL_1, etc.), try mapping by
    # numeric ID since id_to_labels typically uses "0", "1", "2" as keys
    if isinstance(index, str):
        match = _LABEL_PATTERN.match(index)
        if match:
            numeric_id = match.group(1)
            if numeric_id in id2label:
                return id2label[numeric_id]
            try:
                int_id = int(numeric_id)
                if int_id in id2label:
                    return id2label[int_id]
            except (ValueError, TypeError):
                pass
    return str(index)


def get_ehr_secrets(
    secrets: Optional[
        APIKeys
        | ExternallyManagedJWT
        | dict[SecretsUse, APIKeys | ExternallyManagedJWT]
    ],
) -> Optional[ExternallyManagedJWT]:
    """Gets EHR secrets from config if it exists."""
    ehr_secrets: Optional[ExternallyManagedJWT] = None
    try:
        ehr_secrets_tmp = get_secrets_for_use(secrets, "ehr")
    except BitfountError:
        # EHR secrets are not present
        ehr_secrets = None
    else:
        # Only ExternallyManagedJWT is currently supported for EHR secrets
        if ehr_secrets_tmp is None or isinstance(ehr_secrets_tmp, ExternallyManagedJWT):
            ehr_secrets = ehr_secrets_tmp
        else:
            raise TypeError(
                f"EHR secrets must be an ExternallyManagedJWT or None."
                f" Got: {type(ehr_secrets_tmp)}"
            )
    return ehr_secrets
