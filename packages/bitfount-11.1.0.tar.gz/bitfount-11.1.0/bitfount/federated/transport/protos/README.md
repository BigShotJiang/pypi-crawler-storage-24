# `.proto` file modification

This file defines the API contract between the Message Service and our Python clients.
Any changes to it need to be replicated in the Message Service and vice versa.
Usually changes to this file will be made in the message service first,
which makes it easier to ensure backwards compatibility where needed.

# Python Proto Compilation

The proto file (`messages.proto`) needs to be compiled to be used in python.
This can be done using GRPC-Tools from the root directory of the sdk package:

```bash
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. --mypy_out=. bitfount/federated/transport/protos/messages.proto
```

Note: `--mypy_out` uses mypy-protobuf to generate `.pyi` type stub files that work with any Python type checker.

You may need to update the `messages_pb2_grpc.pyi` stubs manually if the service
definitions have changed.

## Warning

This directory is not covered by coverage! This directory is for generated code only.
