"""String store for persisting sets of strings on disk.

This module provides a simple store implementation for tracking strings (e.g.,
MRNs) that persist across multiple runs. The store is backed by SQLite via
diskcache and acts as a Container, so you can use `x in store` to check
membership.
"""

from __future__ import annotations

from collections.abc import Container, Iterator, MutableSet
from contextlib import AbstractContextManager
import logging
import os
from pathlib import Path
import shutil
from types import TracebackType
from typing import Self

import diskcache

logger = logging.getLogger(__name__)


class StringStore(
    MutableSet[str], Container[str], AbstractContextManager["StringStore"]
):
    """A persistent store for strings backed by SQLite via diskcache.

    This store acts as a set-like container for strings, allowing membership
    testing with `x in store`. The store persists to disk and can be used
    across multiple runs.

    The store uses diskcache (SQLite-backed) with no compression, optimized
    for simple string storage.

    Items in this store are never implicitly removed. All removal mechanisms
    are disabled:
    - Eviction is disabled (eviction_policy="none")
    - Size limits are disabled (size_limit=None)
    - Automatic culling is disabled (cull_limit=0)
    - Items never expire (no expire parameter on set operations)

    Items can only be removed by explicit calls to discard() or remove_many().
    """

    def __init__(self, store_dir: Path, store_name: str) -> None:
        """Initialize string store.

        Args:
            store_dir: Directory where the store should be stored.
            store_name: Name for the store (used as subdirectory name).
        """
        store_dir.mkdir(parents=True, exist_ok=True)
        store_path = store_dir / store_name
        logger.debug(f"Creating string store at {store_path}")
        self._db = diskcache.Cache(
            directory=str(store_path),
            disk=diskcache.JSONDisk,
            disk_compress_level=0,  # No compression for simple strings
            eviction_policy="none",  # Disable eviction
            size_limit=None,  # No size limit - prevent size-based eviction
            cull_limit=0,  # Disable automatic culling
        )
        self._store_dir = store_dir
        self._store_name = store_name

    def __contains__(self, x: object) -> bool:
        """Check if string is in the store.

        Args:
            x: String to check for membership.

        Returns:
            True if string is in the store, False otherwise.
        """
        if not isinstance(x, str):
            return False
        return x in self._db

    def __iter__(self) -> Iterator[str]:
        """Iterate over all strings in the store."""
        return iter(self._db)

    def __len__(self) -> int:
        """Get the number of strings in the store."""
        return len(self._db)

    def add(self, value: str) -> None:
        """Add a string to the store.

        Args:
            value: String to add.
        """
        if not isinstance(value, str):
            raise TypeError(f"StringStore only supports strings, got {type(value)}")
        # Store with a sentinel value since we only care about membership
        # No expire parameter - items never expire automatically
        self._db[value] = True

    def discard(self, value: str) -> None:
        """Remove a string from the store if present.

        Args:
            value: String to remove.

        Raises:
            TypeError: If value is not a string.
        """
        if not isinstance(value, str):
            raise TypeError(f"StringStore only supports strings, got {type(value)}")
        try:
            del self._db[value]
        except KeyError:
            pass

    def __enter__(self) -> Self:
        """Enter the context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
        /,
    ) -> None:
        """Exit the context manager, closing the store."""
        self.close()

    def close(self) -> None:
        """Close the store."""
        self._db.close()

    def transact(self) -> AbstractContextManager[None]:
        """Get a transaction context manager for atomic operations.

        All operations within the transaction block are atomic - either all
        succeed or all are rolled back if an exception occurs.

        Example:
            ```python
            with store.transact():
                store.add("value1")
                store.add("value2")
                # If any exception occurs here, both adds are rolled back
            ```

        Returns:
            Context manager that provides transaction semantics.
        """
        return self._db.transact()

    def delete_store(self) -> None:
        """Delete the store from disk.

        This closes the store and removes the entire store directory from disk.
        """
        # Ensure closed first
        try:
            self.close()
        except Exception as e:
            logger.warning(
                f"Error when trying to close string store at"
                f" {self._db.directory}. Got: {e}"
            )

        # Delete the store directory
        try:
            target_path = self._db.directory
            if os.path.exists(target_path):
                if os.path.isfile(target_path):
                    target_path = os.path.dirname(target_path)
                if os.path.isdir(target_path):
                    shutil.rmtree(target_path)
                    logger.debug(f"Deleted string store at {target_path}")
        except OSError as ose:
            logger.error(
                f"Error when trying to delete string store directory:"
                f" {self._db.directory}. Got: {ose}"
            )

    def get_all(self) -> set[str]:
        """Get all strings from the store.

        Returns:
            Set of all strings in the store.
        """
        try:
            return set(self)
        except Exception as e:
            store_path = Path(self._db.directory)
            logger.warning(
                f"Error reading string store {store_path}: {e}. Returning empty set."
            )
            return set()

    def add_many(self, values: set[str]) -> None:
        """Add multiple strings to the store.

        This is a thin wrapper around :meth:`add` that performs "best efforts"
        adding of the set. If an exception occurs partway through, some values
        may have been added while others were not. For atomic "all-or-nothing"
        behavior, use :meth:`transact` to wrap the operation.

        Args:
            values: Set of strings to add.

        Raises:
            TypeError: If any value in values is not a string.
        """
        if not values:
            return
        for value in values:
            self.add(value)

    def remove_many(self, values: set[str]) -> None:
        """Remove multiple strings from the store.

        This is a thin wrapper around :meth:`discard` that performs "best efforts"
        removal of the set. If an exception occurs partway through, some values
        may have been removed while others were not. For atomic "all-or-nothing"
        behavior, use :meth:`transact` to wrap the operation.

        Args:
            values: Set of strings to remove.

        Raises:
            TypeError: If any value in values is not a string.
        """
        if not values:
            return
        for value in values:
            self.discard(value)

    @classmethod
    def open(cls, store_dir: Path, store_name: str) -> StringStore:
        """Get or create a string store for a given directory and name.

        The returned store is a context manager and should be used with `with`:

        ```python
        with StringStore.open(store_dir, store_name) as store:
            store.add("value")
        ```

        Args:
            store_dir: Directory where the store should be stored.
            store_name: Name for the store.

        Returns:
            StringStore instance that can be used as a context manager.
        """
        return cls(store_dir, store_name)

    @classmethod
    def get_all_from_store_in_dir(cls, store_dir: Path, store_name: str) -> set[str]:
        """Get all strings from a store in a directory.

        Args:
            store_dir: Directory where the store is stored.
            store_name: Name of the store.

        Returns:
            Set of all strings in the store.
        """
        store_path = store_dir / store_name
        if not store_path.exists():
            return set()

        try:
            with cls.open(store_dir, store_name) as store:
                return store.get_all()
        except Exception as e:
            logger.warning(
                f"Error reading string store {store_path}: {e}. Returning empty set."
            )
            return set()

    @classmethod
    def add_many_to_store_in_dir(
        cls,
        store_dir: Path,
        store_name: str,
        values: set[str],
    ) -> None:
        """Add multiple strings to a store in a directory.

        This is a thin wrapper around :meth:`add` that performs "best efforts"
        adding of the set. If an exception occurs partway through, some values
        may have been added while others were not. For atomic "all-or-nothing"
        behavior, use :meth:`transact` to wrap the operation.

        Args:
            store_dir: Directory where the store is stored.
            store_name: Name of the store.
            values: Set of strings to add.

        Raises:
            TypeError: If any value in values is not a string.
        """
        if not values:
            return

        with cls.open(store_dir, store_name) as store:
            store.add_many(values)

    @classmethod
    def remove_many_from_store_in_dir(
        cls,
        store_dir: Path,
        store_name: str,
        values: set[str],
    ) -> None:
        """Remove multiple strings from a store in a directory.

        This is a thin wrapper around :meth:`discard` that performs "best efforts"
        removal of the set. If an exception occurs partway through, some values
        may have been removed while others were not. For atomic "all-or-nothing"
        behavior, use :meth:`transact` to wrap the operation.

        Args:
            store_dir: Directory where the store is stored.
            store_name: Name of the store.
            values: Set of strings to remove.

        Raises:
            TypeError: If any value in values is not a string.
        """
        if not values:
            return

        store_path = store_dir / store_name
        if not store_path.exists():
            return

        with cls.open(store_dir, store_name) as store:
            store.remove_many(values)
