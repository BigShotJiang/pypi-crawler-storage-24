"""Version information for `setup.py`."""

# ruff: noqa: E501
#   ____  _ _    __                   _
#  | __ )(_) |_ / _| ___  _   _ _ __ | |_
#  |  _ \| | __| |_ / _ \| | | | '_ \| __|
#  | |_) | | |_|  _| (_) | |_| | | | | |_
#  |____/|_|\__|_|  \___/ \__,_|_| |_|\__|
from __future__ import annotations

from datetime import datetime, timezone

current_year = datetime.now(timezone.utc).year

__author__ = "Bitfount"
__author_email__ = "info@bitfount.com"
__copyright__ = f"Copyright {current_year} Bitfount Ltd"
__description__ = "Machine Learning and Federated Learning Library."
__title__ = "bitfount"
__url__ = "https://github.com/bitfount/bitfount"
__version__ = "11.1.0"

# Legacy combined version list - maintained for backward compatibility
# YAML versions must be all on one line for the breaking changes script to work
__yaml_versions__ = ["2.0.0", "3.0.0", "4.0.0", "4.0.1", "4.1.0", "5.0.0", "6.0.0", "6.1.0", "6.2.0", "6.2.1", "6.3.0", "6.4.0", "6.5.0", "6.6.0"]  # fmt: off

# Role-specific version lists - starting fresh with 7.0.0
__modeller_yaml_versions__ = ["7.0.0", "7.1.0", "7.2.0", "7.3.0", "7.4.0", "7.5.0", "7.6.0", "7.7.0", "7.8.0", "7.9.0", "7.10.0", "7.11.0", "7.12.0", "7.13.0", "7.14.0", "7.15.0", "7.16.0", "7.17.0", "7.17.1", "7.18.0", "7.19.0", "7.20.0", "7.21.0", "7.22.0", "7.23.0", "7.24.0", "7.25.0", "7.26.0", "7.27.0", "7.28.0", "7.29.0", "7.30.0", "7.30.1", "7.31.0", "7.32.0", "7.33.0", "7.34.0", "7.35.0", "7.36.0", "7.37.0", "7.37.1", "7.38.0", "7.39.0", "7.40.0", "7.41.0", "7.42.0", "7.43.0", "7.44.0", "7.45.0", "7.46.0", "7.47.0", "7.48.0", "7.49.0", "7.50.0", "7.51.0", "7.52.0", "7.53.0", "7.54.0", "7.55.0", "7.56.0", "7.57.0", "7.58.0", "7.59.0", "7.60.0", "7.61.0", "7.62.0", "7.63.0", "8.0.0", "8.0.1", "8.1.0", "8.1.1", "8.1.2", "8.2.0", "8.3.0", "8.4.0", "8.5.0", "8.6.0", "8.7.0", "8.8.0", "8.9.0", "8.9.1", "8.10.0", "8.11.0", "8.12.0", "8.12.1", "8.13.0", "8.14.0", "8.14.1", "8.14.2", "8.14.3", "8.14.4", "8.15.0", "8.15.1", "8.16.0", "8.17.0", "8.17.1", "8.18.0", "8.18.1", "8.19.0", "8.19.1", "8.20.0"]  # fmt: off

# Use semver conventions for the YAML versions
# YAML Version Changes
__changelog__ = """
- 8.20.0:
    - Added TIMMFederatedTraining algorithm for federated fine-tuning of TIMM models
      (e.g. DINOv2) with FederatedAveraging. Supports optional LoRA via lora_rank.
    - Added wafer_map_federated_dinov2 and wafer_map_dinov2_finetune task templates.
- 8.19.1:
    - Add series_description_latest filter strategy.
- 8.19.0:
    - Add trials_database_url to PatientTrialMatchingProtocol for downloading trials database from public URL (e.g. S3) to cache_dir with gzip decompression.
- 8.18.1:
    - Added patient-to-clinical-trial matching protocol.
- 8.18.0:
    - Added CodeNormalisation algo.
- 8.17.1:
    - Add templated params to PSQL algo.
- 8.17.0:
    - Added structured query parameters to PSQL.
- 8.16.0:
   - Added TrialInclusionCriteriaMatchAlgorithmGlaucomaCharcoal.
- 8.15.1:
    - Add optional hf_checkpoint_repo_id and hf_checkpoint_filename to TIMMInference algorithm.
- 8.15.0:
    - Added postprocessors to HuggingFaceNER algorithm
- 8.14.4:
    - Add ability to delete downloaded EHR files in DataExtractionProtocolCharcoal
- 8.14.3:
    - Changed access_token handling in HF algorithms.
- 8.14.2:
    - Added new `requires_ehr` param to task template.
- 8.14.1:
    - Added optional seed to PercentageSplitter as a fix for deterministic splitting.
    - Modified federated task parameters to be templatable.
- 8.14.0:
    - Split check-required-fields task filter into two filters:
      - check-required-fields (bool): enables required field checking using datasource config
      - required-field-names (list[str]): specifies exact field names to check
- 8.13.0:
    - Added GCCCalculationAlgorithm.
    - Changed input to CSTCalculationAlgorithm from cst_diameter_mm to cst_radius_mm
- 8.12.1:
    - Re-generate tasks specs after adding postprocessing to HuggingFaceImageClassificationInference algorithm.
    - Added access_token field to HF algorithms.
- 8.12.0:
    - Added radiological interpretation task.
    - Added subfolder field to HuggingFaceImageClassificationInference algorithm.
    - Added postprocessing to HuggingFaceImageClassificationInference algorithm.
- 8.11.0:
    - Add new `task_filters` variable for templating task filters.
- 8.10.0:
    - Added HuggingFaceImageTextGenerationInference algorithm.
- 8.9.1:
    - Adds enum field support to TemplateVariablesEntryString.
- 8.9.0:
    - Added MONAIBundleInference algorithm for running inference with MONAI bundles from Model Zoo.
- 8.8.0:
    - Added HuggingFaceNERInference algorithm.
    - Added HuggingFaceNERTemplate task template.
- 8.7.0:
    - Add series description task filter (series-description).
- 8.6.0:
    - Rename min/max-bscan task filters to min/max-frames for consistency.
- 8.5.0:
    - Added scan acquisition date task filters (scan-acquisition-min-date, scan-acquisition-max-date).
- 8.4.0:
    - Introduce previous run MRN filtering strategy.
    - Change Charcoal task to use this new strategy.
- 8.3.0:
    - Addition of NIFTISource.
- 8.2.0:
    - Deprecate delete_intermediate in ReduceCSVAlgorithmCharcoal.
- 8.1.2:
    - Addition of batch grouping to GAScreeningProtocolCharcoal.
- 8.1.1:
    - Addition of minLength to TemplateVariablesEntryString to allow optional string fields
    - Allow S3UploadAlgorithm inputs to be optional.
- 8.1.0:
    - Added task filters to the DataStructure.
- 8.0.1:
    - Removal of patient_ids from PatientIDExchangeAlgorithm.
- 8.0.0:
    - Some additionalProperties have now been removed in the move to uv.
- 7.63.0:
    - Add ability to skip S3 upload in GAScreeningProtocolCharcoal.
- 7.62.0:
    - Revert _primary_results_path changes.
- 7.61.0:
    - Minor changes to template variable schemas.
- 7.60.0:
    - Add ability to skip S3 upload in DataExtractionProtocolCharcoal.
- 7.59.0:
    - Add configurable presigned URL expiration for S3 upload algorithm.
    - Enforce integer-only validation for S3 upload URL expiration with minimum value of 1.
    - Fix type consistency for s3_bucket and aws_region parameters in S3UploadAlgorithm.
    - Update S3UploadAlgorithm validation to ensure s3_bucket is required on modeller side.
    - Align JSON schema with Python schema for aws_region to allow null values.
- 7.58.0:
    - Added validation to extension field in file_path template variables: extension must not start with a leading dot (e.g., "csv" not ".csv"). The leading dot is added automatically when constructing file paths.
    - Made extension field optional in file_path template variables: can be None or a string without leading dot.
    - Added default field to TemplateVariablesEntryFilePath to allow template variables to have default: null, enabling optional file path template variables.
    - Updated RecordFilterAlgorithm to support None filename when remote_modeller: true. When filename is None, an empty list is sent from Modeller to Worker, excluding no patients.
    - Updated _PatientIDFilterStrategy to handle None filename gracefully, returning an empty list of patient IDs when no exclusion file is provided.
- 7.57.0:
    - Merged CSVReportAlgorithm and CSVReportGeneratorOphthalmologyAlgorithm into a single unified algorithm.
    - Added ophthalmology_args parameter for grouping ophthalmology-specific options.
    - Added rename_columns and columns_to_drop parameters to CSVReportAlgorithm.
    - Deprecated CSVReportGeneratorOphthalmologyAlgorithm (now an alias for CSVReportAlgorithm).
    - Deprecated flat ophthalmology args in favor of nested ophthalmology_args.
- 7.56.0:
    - Added transfer receipt generation to DataExtractionProtocolCharcoal.
- 7.55.0:
    - Added PatientIDExchangeAlgorithm for exchanging patient IDs during initial setup phase.
    - Updated DataExtractionProtocolCharcoal to use PatientIDExchangeAlgorithm instead of requiring patient IDs as protocol arguments.
    - Updated data_extraction_charcoal.yaml task template to include PatientIDExchangeAlgorithm as the first algorithm with patient_ids and patient_ids_file template variables.
    - Added FHIR capabilities to EHRPatientInfoDownloadAlgorithm.
    - DataExtractionProtocolCharcoal now uses S3UploadAlgorithm to upload the results.
- 7.54.0:
    - Added Scan Frequency Filter Strategy to Record Filter Algorithm.
- 7.53.0:
    - Added NullSource.
- 7.52.0:
    - Added Patient ID Filter Strategy to Record Filter Algorithm.
    - Improved typing by replacing types with enums where relevant
- 7.51.0:
    - Added PrivateSqlQuery Algorithm.
- 7.50.0:
    - Made group_by a required arg from batch grouping.
- 7.49.0:
    - _WetAMDScreeningProtocolSapphire is now WetAMDScreeningProtocolSapphire.
- 7.48.0:
    - Changed batch grouping to be a template field in _WetAMDScreeningProtocolSapphire.
- 7.47.0:
    - Added Sapphire Trial Inclusion Algorithm
- 7.46.0:
    - Added Longitudinal Algorithm
- 7.45.0:
    - Expanded the Charcoal Trial Inclusion Criteria to include more criteria.
- 7.44.0:
    - Add batch grouping to _WetAMDScreeningProtocolSapphire.
- 7.43.0:
    - Added Topcon datasource
- 7.42.0:
    - Added InterMine datasource
- 7.41.0:
    - Added CSTCalculationAlgorithm for Central Subfield Thickness calculation.
- 7.40.0:
    - Added _WetAMDScreeningProtocolSapphire protocol for Wet-AMD screening
- 7.39.0:
    - Renaming of NextGenPatientInfoDownloadAlgorithm to EHRPatientInfoDownloadAlgorithm
- 7.38.0:
    - Introduction of ImageSelectionAlgorithm.
- 7.37.1:
    - Allow ReduceCSVAlgorithmCharcoal to have templated variables.
- 7.37.0:
    - Added parameters to ReduceCSVAlgorithmCharcoal: eligible_only and delete_intermediate
- 7.36.0:
    - Introduction of S3UploadAlgorithm.
- 7.35.0:
    - Added enable_anonymized_tracker_upload to task definition. If missing, it will default to False.
- 7.34.0:
    - Deprecated save_path arguments in various algorithm schemas.
- 7.33.0:
    - Addition of argument back to EHRPatientQueryAlgo
- 7.32.0:
    - Added ehr_config in pod config
    - Removal of URL arguments to EHRPatientQueryAlgo
- 7.31.0:
    - Added exclusion codes to TrialInclusionCriteriaMatchAlgorithmBronze
- 7.30.1:
    - Fixed a bug in the types of some templated fields.
- 7.30.0:
    - Added support for templated strings in the YAML configs.
- 7.29.0:
    - Added support for saving results to a file to ResultsOnly protocol
    - Added support for running SQL query remotely to SqlQuery algorithm
- 7.28.0:
    - Changed NextGenPatientQueryAlgo to generic EHRPatientQueryAlgo (not a breaking change
      as there are no references to NextGenPatientQueryAlgo are out in the wild yet)
- 7.27.0:
    - Added support for indicating whether to re-run or not a task on previously failed files.
- 7.26.0:
    - Add FluidVolumeScreeningProtocol
- 7.25.0:
    - Added OMOP datasource
- 7.24.0:
    - Adds the ability for multiple secrets to be supplied in the YAML configs, with
      their intended usage being specified in the YAML.
- 7.23.0:
    - Removes JWT-based authentication from the YAML configs. This is not a breaking
      change as this was never actually working from the YAML due to the need for the
      JWT to have a callback specified.
- 7.22.0:
    - Add FluidVolumeCalculationAlgorithm
- 7.21.0:
    - Added new protocol GAScreeningProtocolBronzeWithEHRConfig
    - Added aux_col as argument to CSVReportGeneratorOphthalmologyAlgorithmArgumentsConfig
- 7.20.0:
    - Added inclusion and exclusion codes as input to TrialInclusionCriteriaMatchAlgorithmCharcoal
- 7.19.0:
    - Add InSite Insights protocol
- 7.18.0:
    - Add user defined primary_results_path
- 7.17.1:
    - Removed ICD10/CPT4 arguments from NextGenPatientQueryAlgorithm
- 7.17.0:
    - Add GAScreeningProtocolCharcoal protocol
- 7.16.0:
    - Add more configurable options to BscanImageAndMaskGenerationAlgorithm
- 7.15.0:
    - Add DataExtractionProtocolCharcoal protocol
- 7.14.0:
    - Add NextGenPatientInfoDownloadAlgorithm
- 7.13.0:
    - Add support for iterative splitting to PercentageSplitter
- 7.12.0:
    - Add support for test_runs as part of the modeller config.
- 7.11.0:
    - Add Reduced CSV Algorithm for Charcoal
- 7.10.0:
    - Add fovea capabilities to Charcoal algorithm
- 7.9.0:
    - Add Config for Charcoal Trial Inclusion
- 7.8.0:
    - Adds support for boolean as task template variables.
- 7.7.0:
  - Added InferenceAndImageOutput protocol
- 7.6.0:
  - Introduced new bscan image and mask generation algorithm.
- 7.5.0:
  - Add largest lesion upper size bound and patient age bounds to trial inclusion algorithms.
- 7.4.0:
   - Added post-processing to ModelInference Algorithm.
- 7.3.0:
  - Amethyst to use Amethyst Trial Calculation
  - Addition of Charcoal Trial Calculation
- 7.2.0:
  - Adding Image Source
- 7.1.0:
    Modeller:
        - Introduced new pre-filtering algorithm.
- 7.0.0:
  - Complete redesign of YAML versioning system
  - Introduced role-specific version lists (__pod_yaml_versions__ and __modeller_yaml_versions__)
  - Decoupled pod and modeller configuration schemas
  - Maintained backward compatibility with __yaml_versions__ for legacy code
  - Reset version numbering for role-specific schemas to provide a clean starting point
- 6.6.0:
  - Add specifications for datasource and datasplitter (kw)arg dictionaries,
    to provide tighter specification of these items.
  - Fix typing of "save path", etc., instances to correctly be specced as string/null
    rather than types inferred from fields.Function()
  - Fix Optional[Union[X, Y]] specs to correctly allow None/null
  - Change Union parsing to export to anyOf instead of oneOf, to better match
    the expected Marshmallow behaviour.
  - Fix issue with Union[dict[...],...] fields not being correctly written to
    the spec if they didn't contain enums.
  - Fix enum dicts to ensure they are valid JSON Schema components.
  - Introduce typing for template elements to ensure that those are also adhered to.
- 6.5.0:
  - Added NextGenSearchProtocol protocol
  - Fix incorrect args config for _SimpleCSVAlgorithm
- 6.4.0:
  - Added NextGenPatientQuery algorithm
"""
