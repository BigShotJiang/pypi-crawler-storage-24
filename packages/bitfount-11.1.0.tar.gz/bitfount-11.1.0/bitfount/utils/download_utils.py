"""Utilities for downloading files from URLs."""

from __future__ import annotations

import gzip
import logging
from pathlib import Path

from bitfount.utils import web_utils

_logger = logging.getLogger(__name__)


def download_file_from_url(
    url: str,
    target_path: Path,
    *,
    decompress_gzip: bool = True,
    skip_if_exists: bool = True,
) -> Path:
    """Download a file from a public URL to a local path.

    Supports gzip decompression when the URL ends with .gz. Skips download
    if the target file already exists (when skip_if_exists is True).

    Args:
        url: The URL to download from (e.g. public S3 URL or any HTTP(S) URL).
        target_path: Local path where the file will be saved.
        decompress_gzip: If True and URL ends with .gz, decompress before saving.
            Defaults to True.
        skip_if_exists: If True and target_path exists, skip download. Defaults
            to True.

    Returns:
        The path to the downloaded (or existing) file.

    Raises:
        requests.HTTPError: If the response code is not 200.
        requests.RequestException: If the request fails.
    """
    target_path = target_path.resolve()
    if skip_if_exists and target_path.exists():
        _logger.debug("File already exists at %s, skipping download", target_path)
        return target_path

    target_path.parent.mkdir(parents=True, exist_ok=True)

    _logger.info("Downloading from %s to %s", url, target_path)
    response = web_utils.get(url=url)
    response.raise_for_status()
    data: bytes = response.content

    if decompress_gzip and url.rstrip("/").lower().endswith(".gz"):
        _logger.debug("Decompressing gzip content")
        data = gzip.decompress(data)

    target_path.write_bytes(data)
    _logger.info("Downloaded and saved to %s", target_path)
    return target_path
