"""Utilities for reading text files when encoding is unknown or external.

Useful for user-provided or cross-platform files (e.g. CSV/JSON/YAML saved
on Windows) where the encoding may be UTF-8 with BOM, cp1252, or similar.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Union

# Order expresses preference: UTF-8 first for interchange; latin-1 last as fallback
# (never raises). utf-8-sig handles BOM so it is tried before utf-8.
_DEFAULT_ENCODINGS: tuple[str, ...] = ("utf-8-sig", "utf-8", "cp1252", "latin-1")

# Unicode BOM (U+FEFF) when text is decoded as UTF-8
_BOM_CHAR = "\ufeff"
# UTF-8 BOM bytes (EF BB BF) decoded as Latin-1/CP1252 produce this 3-char sequence
_UTF8_BOM_MOJIBAKE = "\u00ef\u00bb\u00bf"  # ï»¿


def read_text_with_encoding_fallback(
    path: Union[os.PathLike[str], str],
    encodings: tuple[str, ...] = _DEFAULT_ENCODINGS,
) -> tuple[str, str]:
    """Read a file and decode using the first successful encoding.

    Tries each encoding in order; the first that does not raise
    UnicodeDecodeError is used. Encodings are not disjoint (e.g. ASCII is
    valid in both UTF-8 and cp1252), so order expresses preference (UTF-8
    first).

    Args:
        path: Path to the file to read.
        encodings: Tuple of encoding names to try. Defaults to utf-8-sig,
            utf-8, cp1252, latin-1.

    Returns:
        (decoded_text, encoding_used).

    Raises:
        UnicodeDecodeError: Only if the last encoding in the sequence fails
            (latin-1 accepts every byte, so this should not occur with the
            default encodings).
    """
    raw = Path(path).read_bytes()
    for enc in encodings:
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1"), "latin-1"


def strip_bom_from_text(text: str) -> str:
    """Strip BOM and UTF-8 BOM mojibake from the start and end of text.

    Removes:
    - The Unicode BOM character (U+FEFF), which appears when UTF-8 BOM
      is decoded with a BOM-aware encoding.
    - The three-character sequence ï»¿ (U+00EF U+00BB U+00BF), which appears
      when UTF-8 BOM bytes are decoded as Latin-1/CP1252 (mojibake).

    Then strips surrounding whitespace. Use when processing strings that may
    have been decoded with an encoding that did not consume the BOM (e.g.
    patient IDs received from another party).

    Args:
        text: String that may have leading/trailing BOM or BOM mojibake.

    Returns:
        Text with BOM and BOM mojibake removed from both ends, then stripped.
    """
    if not text:
        return text
    # Strip surrounding whitespace first so BOM/mojibake at edges are visible
    s = text.strip()
    # Strip Unicode BOM from start and end
    while s.startswith(_BOM_CHAR):
        s = s[len(_BOM_CHAR) :]
    while s.endswith(_BOM_CHAR):
        s = s[: -len(_BOM_CHAR)]
    # Strip UTF-8 BOM mojibake sequence from start and end (whole sequence only)
    while s.startswith(_UTF8_BOM_MOJIBAKE):
        s = s[len(_UTF8_BOM_MOJIBAKE) :]
    while s.endswith(_UTF8_BOM_MOJIBAKE):
        s = s[: -len(_UTF8_BOM_MOJIBAKE)]
    return s.strip()
