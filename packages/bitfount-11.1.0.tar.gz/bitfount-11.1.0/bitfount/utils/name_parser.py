"""Name parser for parsing human names into components.

This module provides functionality to parse western-style names (including
Latin-style names common in the USA) into their component parts: title,
first name, middle name(s), last name, suffix, and nickname.

Architecture:
-------------
The parser is organized into logical sections:

1. Configuration Constants: Sets of known titles, suffixes, prefixes, etc.
2. Utility Functions: Helper functions for classification (is_title, is_suffix, etc.)
3. Name Component Extraction: Functions to extract titles, suffixes, nicknames
4. Format-Specific Parsing:
   - Comma format: "Last [Suffix], Title First Middle [Suffix]"
   - Standard format: "Title First Middle Last Suffix"
5. Public API: Main parse_name() function

Parsing Flow:
-------------
1. Extract nickname from quotes/parentheses
2. Normalize whitespace and clean input
3. Detect format (comma-separated vs standard)
4. Parse according to format:
   - Extract titles from start
   - Extract suffixes from end
   - Identify first, middle, and last names
   - Handle prefixes (e.g., "de la", "van der")
5. Apply post-processing rules (e.g., handle_firstnames logic)
"""

import re
from typing import Dict, List, Optional, Tuple

# ============================================================================
# Configuration Constants
# ============================================================================

# Common titles that appear before names
# This is a subset of common titles - not exhaustive but covers most cases
# Note: We exclude "Earl" as it's commonly a first name in US contexts
COMMON_TITLES = {
    "mr",
    "mrs",
    "ms",
    "miss",
    "dr",
    "doctor",
    "prof",
    "professor",
    "do",  # "DO" can be a title (Doctor of Osteopathy)
    "sir",
    "madam",
    "rev",
    "reverend",
    "hon",
    "honorable",
    "judge",
    "capt",
    "captain",
    "col",
    "colonel",
    "gen",
    "general",
    "lt",
    "lieutenant",
    "sgt",
    "sergeant",
    "cpl",
    "corporal",
    "pvt",
    "private",
    "king",
    "queen",
    "prince",
    "princess",
    "duke",
    "duchess",
    "lord",
    "lady",
    "baron",
    "baroness",
    "count",
    "countess",
    "marquis",
    "goodman",
    "junior",
}

# Common suffixes that appear after names
GENERATIONAL_SUFFIXES = {"jr", "junior", "senior", "sr", "ii", "iii", "iv", "v"}

# Common suffix acronyms (degrees, certifications, etc.)
# Note: This list includes common suffixes but is not exhaustive
SUFFIX_ACRONYMS = {
    "ba",
    "bs",
    "caro",
    "cpa",
    "dc",
    "dds",
    "dmd",
    "do",
    "esq",
    "esquire",
    "jd",
    "llm",
    "lpn",
    "ma",
    "mba",
    "md",
    "ms",
    "oca",
    "phd",
    "rn",
}

# Name prefixes that are part of last names
# Includes both single-word and multi-word prefixes
NAME_PREFIXES = {
    # Single-word prefixes
    "abu",
    "al",
    "bin",
    "da",
    "de",
    "degli",
    "dei",
    "del",
    "della",
    "delle",
    "delli",
    "dello",
    "der",
    "di",
    "dos",
    "du",
    "ibn",
    "la",
    "le",
    "mac",
    "mc",
    "o",
    "o'",
    "san",
    "santa",
    "st",
    "ste",
    "van",
    "vander",
    "von",
    # Multi-word prefixes (must be checked first to match correctly)
    "de la",
    "de las",
    "de los",
    "del la",
    "van de",
    "van den",
    "van der",
}

# Titles that indicate the following name is a first name
FIRST_NAME_TITLES = {"dame", "king", "pope", "queen", "sir"}

# Titles that are commonly used as first names and should be treated as such
# in ambiguous cases (especially in comma format "Last, First")
# These are titles that are more likely to be encountered as names than actual titles
COMMON_NAME_TITLES = {
    "baron",
    "baroness",
    "count",
    "countess",
    "dame",
    "duchess",
    "duke",
    "earl",
    "goodman",
    "judge",
    "king",
    "lady",
    "lord",
    "marchioness",
    "marquess",
    "marquis",
    "marquise",
    "prince",
    "princess",
    "queen",
}


# ============================================================================
# Utility Functions
# ============================================================================


def _normalize(text: str) -> str:
    """Normalize text for comparison.

    Converts to lowercase and strips whitespace for consistent comparison
    against configuration constants.

    Args:
        text: Text to normalize

    Returns:
        Normalized text (lowercase, stripped), or empty string if input is falsy
    """
    return text.strip().lower() if text else ""


def _is_initial(part: str) -> bool:
    """Check if a name part is an initial.

    An initial is:
    - A single letter (e.g., "V", "A")
    - A single letter followed by a period (e.g., "V.", "A.")

    Args:
        part: The name part to check

    Returns:
        True if the part is an initial, False otherwise
    """
    part = part.strip()
    if len(part) == 0:
        return False
    if len(part) == 1:
        return part.isalpha()
    if len(part) == 2 and part.endswith("."):
        return part[0].isalpha()
    return False


def _is_roman_numeral(text: str) -> bool:
    """Check if text is a valid Roman numeral.

    Supports common Roman numerals typically used in names:
    - I, II, III, IV, V, VI, VII, VIII, IX (1-9)
    - X, XI, XII, XIII, XIV, XV, XVI, XVII, XVIII, XIX, XX (10-20)

    This covers most generational suffixes (I, II, III, IV, V) and some
    potential first names (Vi, Vii, Ix, Xi, etc.).

    Args:
        text: The text to check (case-insensitive)

    Returns:
        True if the text is a valid Roman numeral, False otherwise
    """
    text = text.strip().upper()
    if not text:
        return False
    # Pattern matches standard Roman numeral format up to XX (20)
    roman_pattern = re.compile(r"^(X{0,2}(IX|IV|V?I{0,3})|X{1,2})$")
    return bool(roman_pattern.match(text))


def _is_roman_numeral_that_could_be_first_name(text: str) -> bool:
    """Check if a Roman numeral could reasonably be a first name.

    Common generational suffixes (I, II, III, IV, V) are not first names.
    Less common ones (Vi, Vii, Ix, Xi, etc.) could potentially be first names.

    IMPORTANT: Case matters! Only all-uppercase Roman numerals are considered. Mixed
    case or lowercase (e.g., "Vi", "vi") are treated as regular names, not Roman
    numerals.

    Args:
        text: The text to check

    Returns:
        True if it's an all-uppercase Roman numeral that could be a first name
    """
    original_text = text.strip().rstrip(".")
    if not original_text:
        return False

    # Case check: Only all-uppercase Roman numerals are considered
    # Mixed case or lowercase (e.g., "Vi", "vi") are regular names
    if not original_text.isupper():
        return False

    text = original_text.upper()

    # Common generational suffixes - these are never first names
    common_suffixes = {"I", "II", "III", "IV", "V"}
    if text in common_suffixes:
        return False

    # Check if it's a valid Roman numeral (but not a common suffix)
    if _is_roman_numeral(text):
        return True

    return False


def _is_title(part: str) -> bool:
    """Check if a name part is a title or honorific.

    Handles titles with or without periods (e.g., "Dr." or "Dr", "Mr." or "Mr").
    Only known titles from COMMON_TITLES are recognized.

    Note: Abbreviated first names like "Wm." (William) or single words like "Baba"
    are not titles - they're treated as first names.

    Args:
        part: The name part to check

    Returns:
        True if the part is a recognized title, False otherwise
    """
    # Remove period for comparison (titles can have periods)
    normalized = _normalize(part.replace(".", ""))

    # Check if it's a known title
    if normalized in COMMON_TITLES:
        return True

    # Special case: Single letter + period (e.g., "W.") is an initial, not a title
    if len(normalized) == 1 and part.endswith("."):
        return False

    # Not a recognized title
    return False


def _is_suffix(part: str, allow_initial: bool = False) -> bool:
    """Check if a name part is a suffix.

    Recognizes:
    - Generational suffixes: JR, SR, II, III, IV, V, etc.
    - Suffix acronyms: Ph.D., M.D., Esq., etc.
    - Roman numerals (only all-uppercase)

    Args:
        part: The name part to check
        allow_initial: If True, single letter initials are never treated as suffixes
            (they're considered middle names)

    Returns:
        True if the part is a recognized suffix, False otherwise
    """
    # Single letter initials are not suffixes when in middle position
    if allow_initial and _is_initial(part):
        return False

    # Remove periods for comparison (suffixes can have periods like "JR.")
    normalized = _normalize(part.replace(".", ""))

    # Check known suffix sets
    if normalized in GENERATIONAL_SUFFIXES or normalized in SUFFIX_ACRONYMS:
        return True

    # For Roman numerals: only all-uppercase are treated as suffixes
    # Mixed case or lowercase (e.g., "Vi", "vi") are regular names
    if part.isupper() and _is_roman_numeral(part):
        return True

    return False


def _is_generational_suffix(part: str) -> bool:
    """Check if a part is a generational suffix (JR, SR, II, III, etc.).

    Generational suffixes should always be treated as suffixes, never as titles.

    For Roman numerals: only all-uppercase are treated as generational suffixes.
    Mixed case or lowercase (e.g., "Vi", "vi") are regular names.

    Args:
        part: The part to check

    Returns:
        True if the part is a generational suffix
    """
    normalized = _normalize(part.replace(".", ""))

    # Check known generational suffixes
    if normalized in GENERATIONAL_SUFFIXES:
        return True

    # For Roman numerals: only all-uppercase are treated as generational suffixes
    if part.isupper() and _is_roman_numeral(part):
        return True

    return False


def _is_prefix(part: str) -> bool:
    """Check if a name part is a single-word prefix.

    Prefixes are part of last names (e.g., "de", "van", "Mc", "St.").
    For multi-word prefixes like "van der" or "de la", use _is_multi_word_prefix().

    Handles prefixes with or without periods (e.g., "St." or "St").

    Args:
        part: The name part to check

    Returns:
        True if the part is a recognized single-word prefix, False otherwise
    """
    # Remove period for comparison (prefixes can have periods like "St.")
    normalized = _normalize(part.replace(".", ""))
    return normalized in NAME_PREFIXES


def _is_multi_word_prefix(words: List[str], start_idx: int) -> Tuple[bool, int]:
    """Check if words starting at start_idx form a multi-word prefix.

    Multi-word prefixes include "van der", "de la", "van den", etc. Checks longer
    prefixes first to avoid partial matches (e.g., "van der" before "van").

    Args:
        words: List of words to check
        start_idx: Index to start checking from

    Returns:
        Tuple of (is_prefix, end_idx) where:
        - is_prefix: True if a multi-word prefix was found
        - end_idx: Index after the prefix (start_idx + number of prefix words)
    """
    if start_idx >= len(words):
        return False, start_idx

    # Try to match multi-word prefixes (check longer ones first)
    # Sort by length descending to match "van der" before "van"
    multi_word_prefixes = sorted(
        [p for p in NAME_PREFIXES if " " in p], key=len, reverse=True
    )

    remaining = " ".join(words[start_idx:]).lower()

    for prefix in multi_word_prefixes:
        if remaining.startswith(prefix.lower()):
            # Check if prefix ends at word boundary
            prefix_words = prefix.split()
            if start_idx + len(prefix_words) <= len(words):
                # Verify it matches word boundaries
                matched_words = " ".join(
                    words[start_idx : start_idx + len(prefix_words)]
                ).lower()
                if matched_words == prefix.lower():
                    return True, start_idx + len(prefix_words)

    return False, start_idx


def _join_name_with_prefixes(parts: List[str]) -> str:
    """Join name parts, handling prefixes correctly.

    Prefixes like "de", "van", "mc" should be joined with following name parts
    to form a single last name unit. Multi-word prefixes like "van der" are
    handled as a single unit.

    Examples:
    - ["de", "la", "Vega"] -> "de la Vega"
    - ["van", "der", "Hoek"] -> "van der Hoek"
    - ["Mc", "Donald"] -> "McDonald"
    - ["St", "Amant"] -> "St Amant"

    Args:
        parts: List of name parts to join (may include prefixes and name words)

    Returns:
        Joined string with prefixes properly grouped with following name parts
    """
    if not parts:
        return ""

    result_parts = []
    i = 0

    while i < len(parts):
        # Check for multi-word prefix first
        is_multi_prefix, end_idx = _is_multi_word_prefix(parts, i)

        if is_multi_prefix:
            # Multi-word prefix found - collect it and following name parts
            prefix_group = parts[i:end_idx]
            i = end_idx

            # Add following name parts until we hit another prefix or end
            while i < len(parts):
                # Check if next word(s) form a prefix
                is_next_prefix, next_end = _is_multi_word_prefix(parts, i)
                if is_next_prefix or (i < len(parts) and _is_prefix(parts[i])):
                    break
                prefix_group.append(parts[i])
                i += 1

            result_parts.append(" ".join(prefix_group))
        elif _is_prefix(parts[i]):
            # Single-word prefix - collect it and following name parts
            prefix_group = [parts[i]]
            i += 1

            # Add following name parts until we hit another prefix or end
            while i < len(parts):
                # Check for multi-word prefix first
                is_next_multi, next_end = _is_multi_word_prefix(parts, i)
                if is_next_multi:
                    break
                if _is_prefix(parts[i]):
                    break
                prefix_group.append(parts[i])
                i += 1

            result_parts.append(" ".join(prefix_group))
        else:
            result_parts.append(parts[i])
            i += 1

    return " ".join(result_parts)


# ============================================================================
# Name Component Extraction
# ============================================================================


def _extract_nickname(name: str) -> Tuple[str, Optional[str]]:
    """Extract nickname from name string (in quotes or parentheses).

    Checks for nicknames in the following formats (in order of precedence):
    1. Double quotes: John "Johnny" Smith
    2. Single quotes: John 'Johnny' Smith (only if surrounded by spaces to avoid
       O'Connor)
    3. Parentheses: John (Johnny) Smith

    The nickname is extracted and removed from the name string, with quotes/parentheses
    stripped from the nickname value.

    Args:
        name: The name string to extract from

    Returns:
        Tuple of (name_without_nickname, nickname) where:
        - name_without_nickname: Original name with nickname removed
        - nickname: Extracted nickname (quotes/parentheses stripped), or None if not
          found
    """
    nickname = None

    # Check for double quotes
    double_quote_match = re.search(r'"([^"]*)"', name)
    if double_quote_match:
        nickname = double_quote_match.group(1).strip()
        name = re.sub(r'"([^"]*)"', "", name)

    # Check for single quotes (but be careful with names like O'Connor)
    # Only treat as nickname if there are spaces around the quotes
    # This avoids matching O'Connor, D'Angelo, etc. where the quote is part of the word
    # Pattern: space or start, then quote, content, quote, then space or end
    single_quote_match = re.search(r"(^|\s)'([^']*)'(\s|$)", name)
    if single_quote_match:
        quoted_content = single_quote_match.group(2)
        nickname = quoted_content.strip()
        # Remove the quotes and surrounding spaces
        name = re.sub(r"(^|\s)'([^']*)'(\s|$)", r"\1\3", name)

    # Check for parentheses
    paren_match = re.search(r"\(([^)]*)\)", name)
    if paren_match:
        # Parentheses always indicate a nickname
        nickname = paren_match.group(1).strip()
        name = re.sub(r"\([^)]*\)", "", name)

    # Strip quotes from nickname if present (shouldn't happen, but just in case)
    if nickname:
        nickname = nickname.strip("'\"")

    return name, nickname


def _extract_titles_from_start(words: List[str]) -> Tuple[List[str], int]:
    """Extract titles from the beginning of a word list.

    Extracts consecutive titles from the start of the word list.
    Common name titles (like "King", "Queen", "Marquis") are NOT extracted as titles
    because they're more likely to be first names in ambiguous contexts.

    Args:
        words: List of words to extract from

    Returns:
        Tuple of (title_parts, name_start_idx) where:
        - title_parts: List of extracted title words
        - name_start_idx: Index where the actual name begins (after titles)
    """
    title_parts = []
    name_start_idx = 0

    for i, word in enumerate(words):
        if _is_title(word):
            # Skip common name titles - treat them as names, not titles
            normalized = _normalize(word)
            if normalized in COMMON_NAME_TITLES:
                # This is a common name title - don't extract as title, treat as name
                break
            title_parts.append(word)
            name_start_idx = i + 1
        else:
            break

    return title_parts, name_start_idx


def _extract_suffixes_from_end(
    words: List[str], start_idx: int = 0, treat_initials_as_middle: bool = True
) -> Tuple[List[str], int]:
    """Extract suffixes from the end of a word list.

    Iterates backwards from the end of the word list, extracting consecutive
    suffixes. Stops when a non-suffix word is encountered.

    Args:
        words: List of words to extract from
        start_idx: Index to start checking from (to avoid checking titles/prefixes)
        treat_initials_as_middle: If True, single letter initials are never
            treated as suffixes (they're considered middle names)

    Returns:
        Tuple of (suffix_parts, name_end_idx) where:
        - suffix_parts: List of extracted suffix words (in order)
        - name_end_idx: Index where the name ends (exclusive, suffixes removed)
    """
    suffix_parts = []
    name_end_idx = len(words)

    # Iterate backwards from the end
    for i in range(len(words) - 1, start_idx - 1, -1):
        word = words[i]
        word_without_period = word.rstrip(".")
        is_suffix_word = _is_suffix(word_without_period, allow_initial=False)

        # Single letter initials are middle names, not suffixes
        if treat_initials_as_middle and _is_initial(word) and not word.endswith("."):
            break
        elif is_suffix_word:
            # Casing check: if it's a suffix acronym and not all uppercase,
            # it's probably a name, not a suffix (e.g., "Ma" is a name, "MA" could be
            # suffix)
            # Generational suffixes (JR, SR, II, III) can be any case
            is_generational = _is_generational_suffix(word_without_period)
            is_all_uppercase = word.isupper() and len(word) > 1

            # For suffix acronyms (not generational), require all uppercase
            # Generational suffixes can be any case
            if is_generational or is_all_uppercase:
                suffix_parts.insert(0, word)
                name_end_idx = i
            else:
                # Mixed case or lowercase suffix acronym - probably a name, not a suffix
                break
        else:
            break

    return suffix_parts, name_end_idx


def _detect_suffix_period_initial_pattern(
    words: List[str],
) -> Tuple[Optional[str], Optional[str], bool]:
    """Detect special pattern where a suffix with period is followed by an initial.

    This pattern appears in names like "Smith, JR. C" where "JR." is a suffix
    and "C" is a middle initial. The suffix and initial should be separated.

    Examples:
    - "JR. C" -> suffix="JR.", initial="C"
    - "II F" -> suffix="II", initial="F"

    Args:
        words: List of words to check (typically the last 2 words)

    Returns:
        Tuple of (suffix_word, initial_word, found) where:
        - suffix_word: The suffix word if pattern found, None otherwise
        - initial_word: The initial word if pattern found, None otherwise
        - found: True if the pattern was detected, False otherwise
    """
    if len(words) < 2:
        return None, None, False

    last_word = words[-1]
    prev_word = words[-2]

    # Check if last word is an initial
    if not (_is_initial(last_word) and not last_word.endswith(".")):
        return None, None, False

    # Check if previous word is a suffix with period
    if prev_word.endswith(".") and _is_suffix(
        prev_word.rstrip("."), allow_initial=False
    ):
        return prev_word, last_word, True

    # Check if previous word is a Roman numeral suffix
    if _is_suffix(prev_word, allow_initial=False) and _is_roman_numeral(prev_word):
        return prev_word, last_word, True

    return None, None, False


# ============================================================================
# Comma Format Parsing - Last Name Extraction
# ============================================================================


def _parse_last_name_part_comma_format(
    last_part: str, comma_parts: List[str]
) -> Tuple[str, str]:
    """Parse the last name part in comma-separated format.

    In comma format "Last [Suffix], First Middle", this parses the part before
    the comma, extracting the last name and any suffixes.

    Handles cases like:
    - "Smith" -> ("Smith", "")
    - "Smith JR" -> ("Smith", "JR")
    - "DI CARO" -> ("DI", "CARO")  # Special case: prefix + suffix pattern
    - "MONTES DE OCA" -> ("MONTES DE", "OCA")  # Multi-word prefix + suffix

    Args:
        last_part: The part before the comma (may contain last name and suffix)
        comma_parts: All comma-separated parts (for context, e.g., to determine
            if a single word could be a suffix)

    Returns:
        Tuple of (last_name, suffix) where suffix may be empty string
    """
    last_words = last_part.split()

    if not last_words:
        return "", ""

    # Special case: Check for prefix + suffix pattern (e.g., "DI CARO", "MONTES DE OCA")
    # Only split if we have a prefix AND the last word is a suffix
    if len(last_words) >= 2:
        last_word = last_words[-1]
        has_prefix = any(_is_prefix(word) for word in last_words[:-1])

        if (
            has_prefix
            and _is_suffix(last_word, allow_initial=False)
            and not _is_initial(last_word)
            and _normalize(last_word) not in {"ba"}
        ):  # "BA" can be a last name
            # Pattern like "DI CARO" or "MONTES DE OCA"
            return " ".join(last_words[:-1]), last_word

    # Single word case
    if len(last_words) == 1:
        word = last_words[0]
        # If it's a known suffix but we have more parts after comma, treat as last name
        if len(comma_parts) > 1:
            return word, ""
        # No parts after comma - could be suffix
        if _is_suffix(word, allow_initial=False):
            return "", word
        return word, ""

    # Multiple words: extract suffixes from the end
    suffix_parts = []
    last_name_parts = []

    # Process from the end backwards
    i = len(last_words) - 1
    while i >= 0:
        word = last_words[i]
        if _is_suffix(word, allow_initial=False) and not _is_initial(word):
            suffix_parts.insert(0, word)
        else:
            last_name_parts = last_words[: i + 1]
            break
        i -= 1

    last_name = _join_name_with_prefixes(last_name_parts) if last_name_parts else ""
    suffix = ", ".join(suffix_parts) if suffix_parts else ""

    return last_name, suffix


# ============================================================================
# ParsedName Class
# ============================================================================


class ParsedName:
    """Represents a parsed human name with its components.

    This class holds the result of parsing a full name string into its
    constituent parts. All fields are strings and may be empty if that
    component was not found in the input.

    Attributes:
        title: Title or honorific (e.g., "Dr.", "Mr.", "Prof.")
        first: First name (given name)
        middle: Middle name(s) or initial(s), space-separated if multiple
        last: Last name (family name, may include prefixes like "de la", "van", "Mc")
        suffix: Suffix (e.g., "JR", "III", "Ph.D."), comma-separated if multiple
        nickname: Nickname extracted from quotes or parentheses
    """

    def __init__(
        self,
        title: str = "",
        first: str = "",
        middle: str = "",
        last: str = "",
        suffix: str = "",
        nickname: str = "",
    ) -> None:
        self.title = title
        self.first = first
        self.middle = middle
        self.last = last
        self.suffix = suffix
        self.nickname = nickname

    def as_dict(self) -> Dict[str, str]:
        """Return the parsed name as a dictionary.

        All fields are normalized to empty strings if None, ensuring consistent
        output format for serialization and comparison.

        Returns:
            Dictionary with keys: title, first, middle, last, suffix, nickname
        """
        return {
            "title": self.title or "",
            "first": self.first or "",
            "middle": self.middle or "",
            "last": self.last or "",
            "suffix": self.suffix or "",
            "nickname": self.nickname or "",
        }

    def __repr__(self) -> str:
        """Return a string representation of the parsed name."""
        return (
            f"ParsedName(title={self.title!r}, first={self.first!r}, "
            f"middle={self.middle!r}, last={self.last!r}, "
            f"suffix={self.suffix!r}, nickname={self.nickname!r})"
        )


# ============================================================================
# Comma Format Parsing - First/Middle Name Extraction
# ============================================================================


def _parse_first_middle_comma_format(
    remaining_words: List[str], result: ParsedName
) -> None:
    """Parse first and middle names from the remaining words after comma.

    Handles special cases like single letters, initials, Roman numerals, and
    suffix patterns before applying normal suffix detection.

    Args:
        remaining_words: Words after the comma (and after titles)
        result: ParsedName object to update
    """
    if not remaining_words:
        return

    first_word = remaining_words[0]

    # Special case: Single letter after comma (e.g., "V", "A")
    # Should be treated as first name, not suffix (matches nameparser behavior)
    # Example: "ALDANA, V F" -> first="V", middle="F"
    first_word_clean = first_word.strip(".,;:")
    if len(first_word_clean) == 1 and first_word_clean.isalpha():
        result.first = first_word
        if len(remaining_words) > 1:
            result.middle = " ".join(remaining_words[1:])
        return

    # Special case: Initials with periods (e.g., "I.V.", "J.R.")
    # Should be treated as first name, not suffix (matches nameparser behavior)
    # Example: "PEELE, I.V. L" -> first="I.V.", middle="L"
    if "." in first_word and len(first_word.replace(".", "").replace(" ", "")) <= 5:
        result.first = first_word
        if len(remaining_words) > 1:
            result.middle = " ".join(remaining_words[1:])
        return

    # Special case: Roman numeral that could be a first name
    # Only if followed by other words (indicates it's not a suffix)
    # Example: "LA, VI C" -> first="VI", middle="C"
    if len(remaining_words) > 1 and _is_roman_numeral_that_could_be_first_name(
        first_word
    ):
        result.first = first_word
        result.middle = " ".join(remaining_words[1:])
        return

    # Check for special suffix + initial pattern (e.g., "JR. C", "II F")
    suffix_word, initial_word, found = _detect_suffix_period_initial_pattern(
        remaining_words
    )

    if found:
        # Pattern detected: suffix is separate, initial is middle
        # suffix_word and initial_word are guaranteed to be str when found=True
        assert suffix_word is not None and initial_word is not None  # nosec[assert_used] # See comment # noqa: E501

        current_suffix = result.suffix or ""
        if current_suffix:
            result.suffix = current_suffix + ", " + suffix_word
        else:
            result.suffix = suffix_word

        # Extract first/middle from words before the suffix
        name_words = remaining_words[:-2]
        if name_words:
            result.first = name_words[0]
            if len(name_words) > 1:
                result.middle = " ".join(name_words[1:])
        # Add the initial as middle
        current_middle = result.middle or ""
        if current_middle:
            result.middle = current_middle + " " + initial_word
        else:
            result.middle = initial_word
        return

    # Normal suffix detection
    suffix_parts, name_end_idx = _extract_suffixes_from_end(
        remaining_words, treat_initials_as_middle=True
    )

    if suffix_parts:
        current_suffix = result.suffix or ""
        if current_suffix:
            result.suffix = current_suffix + ", " + ", ".join(suffix_parts)
        else:
            result.suffix = ", ".join(suffix_parts)

    # Remaining words are first and middle names
    name_parts = remaining_words[:name_end_idx]

    if name_parts:
        result.first = name_parts[0]
        if len(name_parts) > 1:
            result.middle = " ".join(name_parts[1:])


def _apply_handle_firstnames_logic(result: ParsedName) -> None:
    """Apply nameparser's handle_firstnames logic for ambiguous cases.

    When we have a title and only one other name part (no first or middle name),
    and the title is not a first_name_title, swap the last name to first name.
    This handles cases like "Mr. Johnson" where "Johnson" should be the first name.

    Examples:
    - "Mr. Johnson" -> first="Johnson", last=""
    - "MORGAN, QUEEN" -> title="QUEEN", last="MORGAN" (QUEEN is first_name_title,
      no swap)
    - "LANDON, MARQUIS" -> title="MARQUIS", first="LANDON" (MARQUIS is not
      first_name_title, swap)

    Args:
        result: ParsedName object to potentially modify (modified in place)
    """
    if result.title and result.last and not result.first and not result.middle:
        if _normalize(result.title) not in FIRST_NAME_TITLES:
            # Swap: last becomes first
            result.first = result.last
            result.last = ""
        # else: keep as is (last stays as last, title stays as title)


# ============================================================================
# Format-Specific Parsing Functions
# ============================================================================


def _parse_comma_format(comma_parts: List[str], nickname: Optional[str]) -> ParsedName:
    """Parse name, comma-separated format: "Last [Suffix], Title First Middle [Suffix]".

    This is the more complex format that requires careful handling of:
    - Last name with potential prefixes and suffixes (before comma)
    - Titles that might need swapping with first/last names (after comma)
    - Suffixes that might appear in multiple places (before or after comma)
    - Special patterns like "JR. C" where suffix has period followed by initial
    - Single letters and initials that should be treated as first names

    Processing order:
    1. Parse last name part (before comma)
    2. Handle special cases for first word after comma (single letters, initials,
       Roman numerals)
    3. Extract titles (if any)
    4. Extract suffixes (if any)
    5. Parse first and middle names from remaining words

    Args:
        comma_parts: List of comma-separated parts (e.g., ["Smith JR", "John M"])
        nickname: Extracted nickname (if any)

    Returns:
        ParsedName object with parsed components
    """
    result = ParsedName(nickname=nickname or "")

    # Parse last name part (before comma)
    last_part = comma_parts[0]
    result.last, result.suffix = _parse_last_name_part_comma_format(
        last_part, comma_parts
    )

    # Parse remaining parts (after comma)
    if len(comma_parts) > 1:
        remaining = " ".join(comma_parts[1:])
        remaining_words = remaining.split()

        # Handle special cases for first word after comma before title extraction
        # These checks must happen before title/suffix extraction to match nameparser
        # behavior
        if remaining_words:
            first_word = remaining_words[0]
            first_word_clean = first_word.strip(".,;:")

            # Check for generational suffix
            # - If there's already a suffix from last name part: always append
            # - If no existing suffix: only treat as suffix if it has no period
            #   (suffixes with periods like "Jr." are treated as first names via
            #   "initials with periods" check)
            # This handles cases like:
            # - "Smith III, Sr. John" -> suffix="III, Sr." (append to existing suffix)
            # - "Brown, Jr. Elizabeth" -> first="Jr.", middle="Elizabeth" (treat
            #   as first name, has period)
            # - "Anderson, IV Terry" -> suffix="IV" (treat as suffix, no period)
            is_single_letter = len(first_word_clean) == 1 and first_word_clean.isalpha()
            is_short_roman_as_first = len(
                remaining_words
            ) > 1 and _is_roman_numeral_that_could_be_first_name(first_word)
            has_period = "." in first_word

            # Treat as suffix if:
            # 1. There's already a suffix from last name part (always append), OR
            # 2. No existing suffix but the generational suffix has no period (e.g.,
            #    "IV", "JR")
            # Exclude single letters and short Romans that could be first names
            if (
                _is_generational_suffix(first_word)
                and not is_single_letter
                and not is_short_roman_as_first
                and (result.suffix or not has_period)
            ):
                # First word is a generational suffix
                if result.suffix:
                    # Append to existing suffix
                    result.suffix = result.suffix + ", " + first_word
                else:
                    # Set as new suffix
                    result.suffix = first_word
                name_words = remaining_words[1:]
            else:
                # Single letter: treat as first name (e.g., "ALDANA, V F")
                if len(first_word_clean) == 1 and first_word_clean.isalpha():
                    result.first = first_word
                    if len(remaining_words) > 1:
                        result.middle = " ".join(remaining_words[1:])
                    return result

                # Initials with periods: treat as first name (e.g., "PEELE, I.V. L")
                if (
                    "." in first_word
                    and len(first_word.replace(".", "").replace(" ", "")) <= 5
                ):
                    result.first = first_word
                    if len(remaining_words) > 1:
                        result.middle = " ".join(remaining_words[1:])
                    return result

                # Roman numeral that could be first name (if followed by other words)
                if len(
                    remaining_words
                ) > 1 and _is_roman_numeral_that_could_be_first_name(first_word):
                    _parse_first_middle_comma_format(remaining_words, result)
                    return result

                # Special case: Common name titles in comma format should be treated
                # as first names.
                # In comma format "Last, First", titles like "King", "Marquis" are
                # more likely to be first names than actual titles.
                # Examples:
                #   "LANDON, MARQUIS" -> last="LANDON", first="MARQUIS"
                #   "BROWN, KING JOHN" -> last="BROWN", first="KING", middle="JOHN"
                if result.last and _is_title(first_word):
                    normalized_title = _normalize(first_word)
                    if normalized_title in COMMON_NAME_TITLES:
                        result.first = first_word
                        if len(remaining_words) > 1:
                            result.middle = " ".join(remaining_words[1:])
                        return result

                # Extract titles from the beginning (for non-generational suffixes,
                # follow nameparser)
                title_parts, name_start_idx = _extract_titles_from_start(
                    remaining_words
                )
                if title_parts:
                    result.title = " ".join(title_parts)

                # Get name words (after titles)
                name_words = remaining_words[name_start_idx:]
        else:
            # Extract titles from the beginning (for non-generational suffixes,
            # follow nameparser)
            title_parts, name_start_idx = _extract_titles_from_start(remaining_words)
            if title_parts:
                result.title = " ".join(title_parts)

            # Get name words (after titles)
            name_words = remaining_words[name_start_idx:]

        if not name_words:
            # No name words left after title extraction
            # Special case: If we have a title and last name but no first name,
            # treat the title as first name (e.g., "CHEN, DO" -> first=DO, last=CHEN)
            # This differs from nameparser which would swap them
            if result.title and result.last and not result.first:
                result.first = result.title
                result.title = ""
                return result

            # Apply standard handle_firstnames logic for other cases
            _apply_handle_firstnames_logic(result)
            return result

        # Parse first and middle names
        _parse_first_middle_comma_format(name_words, result)

    return result


def _parse_standard_format(full_name: str, nickname: Optional[str]) -> ParsedName:
    """Parse name in standard format: "Title First Middle Last Suffix".

    This format is simpler than comma format - components appear in order from
    left to right. Processing order:
    1. Extract titles from the beginning
    2. Handle 2-word names specially (treat as "First Last")
    3. Extract suffixes from the end (for 3+ word names)
    4. Parse first, middle, and last names from remaining words
    5. Handle prefixes in last names (e.g., "de la", "van der")

    Args:
        full_name: The full name string (without nickname, already normalized)
        nickname: Extracted nickname (if any)

    Returns:
        ParsedName object with parsed components
    """
    result = ParsedName(nickname=nickname or "")

    words = full_name.split()

    if not words:
        return result

    # Extract titles from the beginning
    title_parts, name_start_idx = _extract_titles_from_start(words)
    if title_parts:
        result.title = " ".join(title_parts)

    if name_start_idx >= len(words):
        return result

    # Extract suffixes from the end
    # Special handling for 2-word names: always treat as "First Last"
    # Even if the last word could be a suffix acronym, in a 2-word name it's
    # more likely to be a last name (e.g., "Ellen Do" not "Ellen" with suffix "Do")
    name_words_before_suffix = words[name_start_idx:]

    if len(name_words_before_suffix) == 2:
        result.first = name_words_before_suffix[0]
        result.last = name_words_before_suffix[1]
        return result

    # For names with 3+ words, extract suffixes normally
    suffix_parts, name_end_idx = _extract_suffixes_from_end(
        words, start_idx=name_start_idx, treat_initials_as_middle=True
    )

    if suffix_parts:
        result.suffix = ", ".join(suffix_parts)

    # Remaining words are first, middle, and last names
    name_words = words[name_start_idx:name_end_idx]

    if not name_words:
        return result

    # Handle single word case: treat as first name
    if len(name_words) == 1:
        result.first = name_words[0]
        return result

    # Parse multi-word names: first, middle(s), and last
    result.first = name_words[0]

    if len(name_words) == 2:
        # Two words: first and last
        result.last = name_words[1]
    else:
        # Three or more words: need to identify where last name starts
        # (may include prefixes like "de la", "St.", etc.)
        _parse_last_name_with_prefixes(name_words, result)

    # Ensure last name handles prefixes correctly
    if result.last:
        last_parts = result.last.split()
        result.last = _join_name_with_prefixes(last_parts)

    return result


def _parse_last_name_with_prefixes(name_words: List[str], result: ParsedName) -> None:
    """Parse last name from name words, handling prefixes and middle initials.

    For multi-word names (3+ words), identifies where the last name starts,
    accounting for:
    - Multi-word prefixes (e.g., "de la", "van der", "van den")
    - Single-word prefixes (e.g., "de", "St.", "Mc")
    - Middle initials (e.g., "O." in "Wesley O. Johnson")

    Checks patterns in order:
    1. Last 3 words forming multi-word prefix + name
    2. Second-to-last word being a middle initial
    3. Last 2 words forming multi-word prefix + name
    4. Second-to-last word being a single-word prefix
    5. Default: last word is last name, everything else is middle

    Args:
        name_words: List of name words (first word already assigned to result.first)
        result: ParsedName object to update with middle and last names (modified in
            place)
    """
    # Check if last 3 words form a multi-word prefix + name pattern
    # Example: "John van der Hoek" -> last 3 words "van der Hoek" are last name
    # The prefix might be 2 words (e.g., "van der") followed by 1 name word
    if len(name_words) >= 3:
        start_idx = len(name_words) - 3
        is_multi_prefix, prefix_end = _is_multi_word_prefix(name_words, start_idx)
        # If we found a multi-word prefix starting at the third-to-last word,
        # and it's followed by at least one more word, the last 3 words form the last
        # name
        if is_multi_prefix and prefix_end > start_idx and prefix_end <= len(name_words):
            result.last = " ".join(name_words[-3:])
            if len(name_words) > 3:
                result.middle = " ".join(name_words[1:-3])
            return

    # Check if second-to-last word is a middle initial
    # Example: "Wesley O. Johnson" -> middle="O.", last="Johnson"
    if (
        len(name_words) >= 3
        and _is_initial(name_words[-2])
        and name_words[-2].endswith(".")
    ):
        result.last = name_words[-1]
        result.middle = " ".join(name_words[1:-1])
        return

    # Check if last 2 words form a multi-word prefix + name
    # Example: "... de la Vega" -> last="de la Vega"
    if len(name_words) >= 3:
        is_multi_prefix_2, prefix_end_2 = _is_multi_word_prefix(
            name_words, len(name_words) - 2
        )
        if is_multi_prefix_2 and prefix_end_2 == len(name_words):
            result.last = " ".join(name_words[-2:])
            result.middle = " ".join(name_words[1:-2])
            return

    # Check if second-to-last word is a single-word prefix
    # Example: "... St. Amant" -> last="St. Amant"
    if len(name_words) >= 3 and _is_prefix(name_words[-2]):
        result.last = " ".join(name_words[-2:])
        result.middle = " ".join(name_words[1:-2])
        return

    # Default: last word is last name, everything else is middle
    result.last = name_words[-1]
    if len(name_words) > 2:
        result.middle = " ".join(name_words[1:-1])


# ============================================================================
# Public API
# ============================================================================


def parse_name(full_name: str) -> ParsedName:
    """Parse a full name string into its components.

    Supports formats like:
    - "John Smith"
    - "Smith, John"
    - "Dr. John M. Smith"
    - "Smith, John M., JR"
    - "John 'Johnny' Smith"
    - "De la Vega, Juan"
    - "McDonald, James"

    The parsing process:
    1. Extract nickname from quotes/parentheses
    2. Normalize whitespace and clean input
    3. Detect format (comma-separated vs standard)
    4. Parse according to format
    5. Apply post-processing rules

    Args:
        full_name: The full name string to parse

    Returns:
        ParsedName object with parsed components
    """
    if not full_name or not full_name.strip():
        return ParsedName()

    # Step 1: Extract nickname first (before other processing)
    name_without_nickname, nickname = _extract_nickname(full_name)
    full_name = name_without_nickname

    # Step 2: Normalize whitespace (collapse multiple spaces to single space)
    full_name = re.sub(r"\s+", " ", full_name.strip())

    # Step 3: Remove trailing commas (common formatting issue)
    full_name = full_name.rstrip(",").strip()

    # Step 4: Split on comma to detect format
    comma_parts = [p.strip() for p in full_name.split(",")]

    # Step 5: Parse according to format
    if len(comma_parts) > 1:
        # Comma-separated format: "Last [Suffix], Title First Middle [Suffix]"
        return _parse_comma_format(comma_parts, nickname)
    else:
        # Standard format: "Title First Middle Last Suffix"
        return _parse_standard_format(full_name, nickname)
