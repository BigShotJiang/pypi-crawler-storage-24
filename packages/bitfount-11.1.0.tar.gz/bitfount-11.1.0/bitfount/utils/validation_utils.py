"""Validation and type conversion utilities.

This module provides utilities for type conversion and validation,
leveraging, for instance, Pydantic's validation capabilities for
consistent type handling across the codebase.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic import TypeAdapter

logger = logging.getLogger(__name__)


def normalize_boolean(value: Any) -> bool:
    """Convert string booleans to actual booleans using Pydantic's logic.

    This is defensive programming to handle cases where string
    representations of booleans (e.g., "false", "False", "true", "True")
    might be passed instead of actual boolean values. This can happen if
    template replacement doesn't work correctly, or if values come from a
    different code path.

    Uses Pydantic's TypeAdapter for boolean validation, which handles
    common string representations like "true"/"false", "yes"/"no",
    "1"/"0", etc.

    NOTE: non-empty, "non-boolean" strings will be converted to True as they are
          inherently truthy. This means that even "false"-like strings might be
          converted to True if they are not of a type that Pydantic can validate
          as a boolean. See Pydantic's documentation for more details.

    Args:
        value: Value that should be a boolean (may be bool, str, or
            other type).

    Returns:
        Boolean value. Uses Pydantic's boolean validation which handles
        strings like "true", "false", "yes", "no", "1", "0", etc. Falls
        back to bool() conversion if Pydantic can't validate it.

    Examples:
        >>> normalize_boolean("false")
        False
        >>> normalize_boolean("true")
        True
        >>> normalize_boolean("yes")
        True
        >>> normalize_boolean("0")
        False
        >>> normalize_boolean(True)
        True
    """
    # Use Pydantic's TypeAdapter for boolean validation
    # This handles common string representations automatically
    bool_adapter = TypeAdapter(bool)
    try:
        return bool_adapter.validate_python(value)
    except Exception:
        # If Pydantic can't validate it (e.g., invalid string like
        # "maybe"), fall back to bool() conversion and log a warning
        # This is defensive - we prefer Pydantic's logic but don't want
        # to crash on unexpected values
        logger.warning(
            f"Expected boolean value but got '{value}' "
            f"(type: {type(value).__name__}). "
            f"Pydantic couldn't validate it. "
            f"Falling back to bool() conversion."
        )
        return bool(value)
