"""Installation-related utilities."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional
from uuid import UUID, uuid4

from bitfount import config

_logger = logging.getLogger(__name__)


def get_installation_uuid(
    storage_path: Optional[Path] = None,
) -> str:
    """Return the installation UUID.

    Uses config.settings.paths.storage_path by default.
    """
    if storage_path is None:
        storage_path = config.settings.paths.storage_path

    uuid_path = storage_path / ".uuid"
    if uuid_path.exists():
        with open(uuid_path, encoding="utf-8") as f:
            uuid = f.read()
            try:
                UUID(uuid)
                return uuid
            except ValueError:
                _logger.warning(
                    f"Could not parse contents of {uuid_path} as UUID: {uuid}"
                )
    uuid = str(uuid4())
    _logger.info(
        f"Installation UUID not found at {uuid_path} - "
        f"generated new UUID ({uuid}) and will store it there"
    )
    with open(uuid_path, mode="w", encoding="utf-8") as f:
        f.write(uuid)

    return uuid
