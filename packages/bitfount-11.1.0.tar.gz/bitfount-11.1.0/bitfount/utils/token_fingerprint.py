"""Token fingerprint for safe logging (no token value)."""

from __future__ import annotations

import hashlib


def token_fingerprint(token: str | None) -> str:
    """Short fingerprint of a token for log correlation without exposing it.

    Returns the first 8 hex chars of SHA-256 of the token, or "none" if token
    is None or empty. Use when logging EHR/OAuth token usage (e.g. on request
    issue or when a new token is received).
    """
    if not token or not token.strip():
        return "none"
    return hashlib.sha256(token.encode("UTF-8")).hexdigest()[:8]
