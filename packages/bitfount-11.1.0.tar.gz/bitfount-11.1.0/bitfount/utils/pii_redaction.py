"""Redact PII in query parameters and log messages.

For logging request details (e.g. FHIR/EHR query params) without exposing
identifiers, names, or dates. Non-printable escaping: use
``safe_str_for_log`` in ``bitfount.data.datasources.utils``.

Rules: Only alphanumeric chars are replaced with ``'*'``; punctuation and
whitespace are kept (length preserved). Default strategy is ``"partial"``;
use ``strategy="full"`` to mask all alphanumeric. Partial keeps up to 3
chars at each end, min 1 (except length <=2 → 0), scaled so ≤25% visible
from length 8 onward.

Param key → redaction type (for ``redact_value`` / ``redact_query_params``):

- **name**: ``name``, ``given``, ``family``
- **identifier**: ``identifier``, ``_id``, ``patient``
- **date**: ``birthdate``
- **datetime**: ``date``, ``date__gt``, ``date__lt``, ``onset-date``, ``performed-date``
- **fallback**: any other key in ``pii_keys``, or any key not in ``pii_keys`` when
  ``pass_through_unknown_keys`` is False (default: unknown keys are redacted).

If a type-specific redactor leaves the string unchanged, fallback redaction is applied.

Examples (partial unless noted)
--------------------------------

Name (1–2 chars: 0 kept; 3+ scaled by n)::

    "X"             → "*"              (n=1)
    "ab"            → "**"             (n=2)
    "Joe"           → "J*e"
    "John"          → "J**n"
    "Smith"         → "S***h"
    "O'Brien"       → "O'****n"        (apostrophe kept)
    "Mary-Jane"     → "M***-***e"      (hyphen kept)
    "Christopher"   → "C*********r"

Name (full)::

    "John"          → "****"
    "O'Brien"       → "*'*****"

Identifier (same partial rule; punctuation kept)::

    "a"             → "*"             (n=1)
    "12"            → "**"
    "MRN-123"       → "M**-**3"
    "MRN-12345678"  → "M**-*******8"
    "patient-42"    → "p******-*2"
    "id_abc_123"    → "i*_***_**3"

Date (year and month kept; day redacted; else fallback)::

    "1990-01-15"    → "1990-01-**"
    "19900101"      → "199001**"
    "2005"          → "****"           (no month/day → fallback)
    "1990-01"       → "1***-*1"        (no day → fallback)

Datetime (year and month kept; day and time redacted)::

    "2024-03-15T14:30:00"   → "2024-03-**T**:**:**"
    "2024-03-15"            → "2024-03-**"

Fallback (unknown key; partial / full)::

    ""              → ""               (empty kept as empty)
    "a"             → "*"             (n=1)
    "ab"            → "**"
    "xyz"           → "x*z"
    "unknown_key"   → "u******_**y"
    "xyz" (full)    → "***"
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
import re
from typing import Any, Callable, Literal

DEFAULT_PII_PARAM_KEYS: frozenset[str] = frozenset(
    {
        "name",
        "given",
        "family",
        "birthdate",
        "identifier",
        "_id",
        "patient",
        "date",
        "date__gt",
        "date__lt",
        "onset-date",
        "performed-date",
    }
)

_NAME_KEYS: frozenset[str] = frozenset({"name", "given", "family"})
_ID_KEYS: frozenset[str] = frozenset({"identifier", "_id", "patient"})
_DATE_KEYS: frozenset[str] = frozenset({"birthdate"})
_DATETIME_KEYS: frozenset[str] = frozenset(
    {
        "date",
        "date__gt",
        "date__lt",
        "onset-date",
        "performed-date",
    }
)

RedactionStrategy = Literal["full", "partial"]


def _to_str(value: Any) -> str:
    """Normalise to string; None becomes "" so we can mask empty values consistently."""
    if value is None:
        return ""
    return value if isinstance(value, str) else str(value)


def _alphanumeric_indices(s: str) -> list[int]:
    """Indices of chars masked in full redaction (letters and digits only)."""
    return [i for i, c in enumerate(s) if c.isalnum()]


def _partial_keep_count(n: int) -> int:
    """How many alphanumeric chars to keep at each end. Max 3, min 0 for n<=2."""
    if n <= 0:
        return 0
    if n <= 2:
        return 0  # "5" → "*", "55" → "**"
    # n >= 3: scale so ≤25% visible from n >= 8 (2*k ≤ n/4); lengths 3–7 -> 1 kept
    return max(1, min(3, n // 8))


def _partial_keep_indices(s: str) -> set[int]:
    """Indices to leave visible: first k and last k alphanumeric (by scaled k)."""
    indices = _alphanumeric_indices(s)
    k = _partial_keep_count(len(indices))
    if k <= 0:
        return set()
    return set(indices[:k]) | set(indices[-k:])


def _redact_alphanumeric(s: str, keep_indices: set[int] | None = None) -> str:
    """Replace alphanumeric with '*'; keep punctuation. None → redact all."""
    keep = keep_indices if keep_indices is not None else set()
    return "".join(
        c if (not c.isalnum() or i in keep) else "*" for i, c in enumerate(s)
    )


def _redact_alphanumeric_partial_or_full(s: str, strategy: RedactionStrategy) -> str:
    """Full: mask every alphanumeric. Partial: keep scaled start/end, mask the rest."""
    if strategy == "full":
        return _redact_alphanumeric(s, set())
    return _redact_alphanumeric(s, _partial_keep_indices(s))


def _redact_digits_only(s: str) -> str:
    """Replace digits with '*'; leave hyphens, colons, 'T', etc. unchanged."""
    return "".join("*" if c.isdigit() else c for c in s)


def _redact_date_day_onwards(s: str) -> str:
    """Keep year and month; redact day and any time (digits only)."""
    if not s:
        return s
    # YYYY-MM-DD or YYYY-MM-DDThh:mm:ss: keep first 7 chars, redact digits in rest
    if len(s) >= 7 and re.match(r"^\d{4}-\d{2}", s):
        return s[:7] + _redact_digits_only(s[7:])
    # YYYYMMDD (compact): keep first 6 chars, redact digits in rest
    if len(s) >= 6 and s[:4].isdigit() and s[4:6].isdigit():
        return s[:6] + _redact_digits_only(s[6:])
    # No recognised date shape: redact all digits (caller may fall back to fallback)
    return _redact_digits_only(s)


def redact_fallback(value: Any, strategy: RedactionStrategy = "partial") -> str:
    """Redact unknown PII: partial keeps scaled ends, full masks all alphanumeric."""
    s = _to_str(value)
    if not s:
        return s
    return _redact_alphanumeric_partial_or_full(s, strategy)


def _redact_with_fallback(
    value: Any,
    strategy: RedactionStrategy,
    core_redactor: Callable[[str], str],
) -> str:
    """Apply core_redactor to string form of value; if unchanged, use fallback."""
    s = _to_str(value)
    if not s:
        return s
    result = core_redactor(s)
    return result if result != s else redact_fallback(value, strategy)


def redact_name(value: Any, strategy: RedactionStrategy = "partial") -> str:
    """Redact name-like value. Falls back to fallback redaction if unchanged."""
    return _redact_with_fallback(
        value, strategy, lambda s: _redact_alphanumeric_partial_or_full(s, strategy)
    )


def redact_identifier(value: Any, strategy: RedactionStrategy = "partial") -> str:
    """Redact identifier (MRN, patient id). Falls back if unchanged."""
    return _redact_with_fallback(
        value, strategy, lambda s: _redact_alphanumeric_partial_or_full(s, strategy)
    )


def redact_date(value: Any, strategy: RedactionStrategy = "partial") -> str:
    """Redact date: keep year and month, redact day onward. Falls back if unchanged."""
    return _redact_with_fallback(value, strategy, _redact_date_day_onwards)


def redact_datetime(value: Any, strategy: RedactionStrategy = "partial") -> str:
    """Redact datetime: keep year, month; redact day, time. Fallback if unchanged."""
    return _redact_with_fallback(value, strategy, _redact_date_day_onwards)


def redact_value(
    key: str,
    value: Any,
    strategy: RedactionStrategy = "partial",
) -> str:
    """Redact a single value by key (name, identifier, date, datetime, or fallback)."""
    # Dispatch by param name to the appropriate redactor
    if key in _NAME_KEYS:
        return redact_name(value, strategy)
    if key in _ID_KEYS:
        return redact_identifier(value, strategy)
    if key in _DATE_KEYS:
        return redact_date(value, strategy)
    if key in _DATETIME_KEYS:
        return redact_datetime(value, strategy)
    return redact_fallback(value, strategy)


def redact_query_params(
    params: Mapping[str, Any] | None,
    *,
    pii_keys: frozenset[str] | None = None,
    strategy: RedactionStrategy = "partial",
    pass_through_unknown_keys: bool = False,
) -> dict[str, Any]:
    """Return a copy of params with PII values redacted.

    Keys in pii_keys get type-specific redaction (name, identifier, date, etc.).
    Keys not in pii_keys are redacted with fallback by default; set
    pass_through_unknown_keys=True to leave them unchanged.
    """
    if params is None:
        return {}
    keys = pii_keys or DEFAULT_PII_PARAM_KEYS
    out: dict[str, Any] = {}
    for k, v in params.items():
        if k not in keys:
            if pass_through_unknown_keys:
                out[k] = v
                continue
            if v is None:
                out[k] = redact_fallback(v, strategy)
            elif isinstance(v, Sequence) and not isinstance(v, str):
                out[k] = [redact_fallback(item, strategy) for item in v]
            else:
                out[k] = redact_fallback(v, strategy)
            continue
        if v is None:
            out[k] = redact_fallback(v, strategy)
            continue
        # List/tuple of values (e.g. multiple identifiers): redact each element
        if isinstance(v, Sequence) and not isinstance(v, str):
            out[k] = [redact_value(k, item, strategy) for item in v]
        else:
            out[k] = redact_value(k, v, strategy)
    return out


def _is_patient_id_char(c: str) -> bool:
    """True for ASCII alnum and - _; used so BOM/whitespace stay in prefix/suffix."""
    return c in "-_" or (c.isascii() and c.isalnum())


def anonymise_patient_id(patient_id: str) -> str:
    """Anonymise a patient ID for logging by masking middle alphanumeric chars.

    Use this when you need anonymised IDs to remain *distinguishable* in logs
    (e.g. during patient ID exchange) and when prefix/suffix (BOM, spaces)
    should stay visible for debugging. For general PII in request/error logs,
    use ``redact_identifier`` instead.

    Difference from ``redact_identifier``:
    - **Strictness**: This function keeps more characters visible
      (k = min(3, max(1, n//3))), so e.g. "aa12345" → "aa***45". ``redact_identifier``
      uses k = max(1, min(3, n//8)), so the same string → "a*****5" (stricter;
      ≤25% visible from length 8 onward; lengths 3–7 show >25% due to floor).
      Use ``redact_identifier`` wherever minimal exposure is enough.
    - **Prefix/suffix**: This function preserves leading/trailing content that is
      not part of the "core" ID (BOM mojibake, spaces), so encoding and
      formatting issues remain visible in logs. ``redact_identifier`` redacts the
      whole string and does not special-case prefix/suffix.
    - **When to use which**: Use ``redact_identifier`` for query params,
      error messages, and any log line where you only need to show that an ID
      was present. Use this function when you need to tell multiple anonymised
      IDs apart (e.g. "aa***45" vs "ab***45") or when debugging ID format/encoding.

    Preserves hyphens and underscores inside the core; only alphanumeric in the
    middle are replaced with ``*``.
    """
    if not patient_id:
        return patient_id
    start = next((i for i, c in enumerate(patient_id) if _is_patient_id_char(c)), None)
    if start is None:
        return patient_id
    end = next(
        (
            i
            for i in range(len(patient_id) - 1, -1, -1)
            if _is_patient_id_char(patient_id[i])
        ),
        start,
    )
    prefix = patient_id[:start]
    core = patient_id[start : end + 1]
    suffix = patient_id[end + 1 :]
    n = len(core)
    keep = min(3, max(1, n // 3))
    anonymised_core: list[str] = []
    for i, c in enumerate(core):
        if i < keep or i >= n - keep:
            anonymised_core.append(c)
        elif c in "-_":
            anonymised_core.append(c)
        else:
            anonymised_core.append("*")
    return prefix + "".join(anonymised_core) + suffix
