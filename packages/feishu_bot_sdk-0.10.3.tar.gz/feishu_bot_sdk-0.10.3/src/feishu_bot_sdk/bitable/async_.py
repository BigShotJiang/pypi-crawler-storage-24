import csv
import os
from typing import Any, AsyncIterator, Dict, Mapping, Optional

from ..drive import AsyncDrivePermissionService
from ..feishu import AsyncFeishuClient
from ..types import DriveResourceType, MemberIdType
from ._common import _drop_none, _has_more, _iter_page_items, _next_page_token, _unwrap_data
from ._csv import _chunked, _detect_url_indices, _iter_csv_rows, _prepare_headers


class AsyncBitableService:
    def __init__(self, feishu_client: AsyncFeishuClient) -> None:
        self._client = feishu_client
        self._drive_permissions = AsyncDrivePermissionService(feishu_client)

    async def create_from_csv(self, csv_path: str, app_name: str, table_name: str) -> tuple[str, str]:
        if not os.path.exists(csv_path):
            raise FileNotFoundError(csv_path)

        with open(csv_path, newline="", encoding="utf-8-sig") as file:
            reader = csv.reader(file)
            raw_headers = next(reader, [])

        headers = _prepare_headers(raw_headers)
        url_indices = _detect_url_indices(csv_path, len(headers))

        app_resp = await self._client.request_json(
            "POST",
            "/bitable/v1/apps",
            payload={"name": app_name},
        )
        app_token = app_resp["data"]["app"]["app_token"]
        app_url = app_resp["data"]["app"]["url"]

        fields = []
        for index, name in enumerate(headers):
            if index in url_indices:
                fields.append({"field_name": name, "type": 15, "ui_type": "Url"})
            else:
                fields.append({"field_name": name, "type": 1})
        table_payload: Dict[str, Dict[str, object]] = {"table": {"name": table_name}}
        if fields:
            table_payload["table"]["default_view_name"] = "Grid"
            table_payload["table"]["fields"] = fields
        table_resp = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables",
            payload=table_payload,
        )
        table_id = table_resp["data"]["table_id"]

        await self._cleanup_default_tables(app_token, table_id)

        rows = _iter_csv_rows(csv_path, headers, url_indices)
        for batch in _chunked(rows, 1000):
            await self._client.request_json(
                "POST",
                f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_create",
                payload={"records": [{"fields": row} for row in batch]},
            )
        return app_token, app_url

    async def grant_edit_permission(
        self,
        app_token: str,
        member_id: str,
        member_id_type: str = MemberIdType.OPEN_ID.value,
    ) -> None:
        await self._drive_permissions.grant_edit_permission(
            app_token,
            member_id,
            member_id_type,
            resource_type=DriveResourceType.BITABLE,
            permission=self._client.config.member_permission,
        )

    async def list_tables(
        self,
        app_token: str,
        *,
        page_size: Optional[int] = None,
        page_token: Optional[str] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none({"page_size": page_size, "page_token": page_token})
        response = await self._client.request_json(
            "GET",
            f"/bitable/v1/apps/{app_token}/tables",
            params=params,
        )
        return _unwrap_data(response)

    async def iter_tables(
        self,
        app_token: str,
        *,
        page_size: int = 100,
    ) -> AsyncIterator[Mapping[str, Any]]:
        page_token: Optional[str] = None
        while True:
            data = await self.list_tables(app_token, page_size=page_size, page_token=page_token)
            for item in _iter_page_items(data):
                yield item
            if not _has_more(data):
                return
            page_token = _next_page_token(data)
            if not page_token:
                return

    async def create_table(self, app_token: str, table: Mapping[str, object]) -> Mapping[str, Any]:
        response = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables",
            payload={"table": dict(table)},
        )
        return _unwrap_data(response)

    async def batch_create_tables(
        self,
        app_token: str,
        tables: list[Mapping[str, object]],
    ) -> Mapping[str, Any]:
        response = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/batch_create",
            payload={"tables": [dict(table) for table in tables]},
        )
        return _unwrap_data(response)

    async def update_table(
        self,
        app_token: str,
        table_id: str,
        *,
        name: str,
    ) -> Mapping[str, Any]:
        response = await self._client.request_json(
            "PATCH",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}",
            payload={"name": name},
        )
        return _unwrap_data(response)

    async def delete_table(self, app_token: str, table_id: str) -> None:
        await self._client.request_json("DELETE", f"/bitable/v1/apps/{app_token}/tables/{table_id}")

    async def batch_delete_tables(self, app_token: str, table_ids: list[str]) -> None:
        await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/batch_delete",
            payload={"table_ids": list(table_ids)},
        )

    async def list_fields(
        self,
        app_token: str,
        table_id: str,
        *,
        view_id: Optional[str] = None,
        page_size: Optional[int] = None,
        page_token: Optional[str] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "view_id": view_id,
                "page_size": page_size,
                "page_token": page_token,
            }
        )
        response = await self._client.request_json(
            "GET",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/fields",
            params=params,
        )
        return _unwrap_data(response)

    async def iter_fields(
        self,
        app_token: str,
        table_id: str,
        *,
        view_id: Optional[str] = None,
        page_size: int = 100,
    ) -> AsyncIterator[Mapping[str, Any]]:
        page_token: Optional[str] = None
        while True:
            data = await self.list_fields(
                app_token,
                table_id,
                view_id=view_id,
                page_size=page_size,
                page_token=page_token,
            )
            for item in _iter_page_items(data):
                yield item
            if not _has_more(data):
                return
            page_token = _next_page_token(data)
            if not page_token:
                return

    async def create_field(
        self,
        app_token: str,
        table_id: str,
        field: Mapping[str, object],
        *,
        client_token: Optional[str] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none({"client_token": client_token})
        response = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/fields",
            params=params,
            payload=dict(field),
        )
        return _unwrap_data(response)

    async def update_field(
        self,
        app_token: str,
        table_id: str,
        field_id: str,
        field: Mapping[str, object],
        *,
        client_token: Optional[str] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none({"client_token": client_token})
        response = await self._client.request_json(
            "PUT",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}",
            params=params,
            payload=dict(field),
        )
        return _unwrap_data(response)

    async def delete_field(
        self,
        app_token: str,
        table_id: str,
        field_id: str,
    ) -> None:
        await self._client.request_json(
            "DELETE",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}",
        )

    async def list_records(
        self,
        app_token: str,
        table_id: str,
        *,
        page_size: Optional[int] = None,
        page_token: Optional[str] = None,
        view_id: Optional[str] = None,
        user_id_type: Optional[str] = None,
        filter: Optional[str] = None,
        sort: Optional[str] = None,
        field_names: Optional[str] = None,
        text_field_as_array: Optional[bool] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "page_size": page_size,
                "page_token": page_token,
                "view_id": view_id,
                "user_id_type": user_id_type,
                "filter": filter,
                "sort": sort,
                "field_names": field_names,
                "text_field_as_array": text_field_as_array,
            }
        )
        response = await self._client.request_json(
            "GET",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records",
            params=params,
        )
        return _unwrap_data(response)

    async def iter_records(
        self,
        app_token: str,
        table_id: str,
        *,
        page_size: int = 500,
        view_id: Optional[str] = None,
        user_id_type: Optional[str] = None,
        filter: Optional[str] = None,
        sort: Optional[str] = None,
        field_names: Optional[str] = None,
        text_field_as_array: Optional[bool] = None,
    ) -> AsyncIterator[Mapping[str, Any]]:
        page_token: Optional[str] = None
        while True:
            data = await self.list_records(
                app_token,
                table_id,
                page_size=page_size,
                page_token=page_token,
                view_id=view_id,
                user_id_type=user_id_type,
                filter=filter,
                sort=sort,
                field_names=field_names,
                text_field_as_array=text_field_as_array,
            )
            for item in _iter_page_items(data):
                yield item
            if not _has_more(data):
                return
            page_token = _next_page_token(data)
            if not page_token:
                return

    async def get_record(
        self,
        app_token: str,
        table_id: str,
        record_id: str,
        *,
        user_id_type: Optional[str] = None,
        text_field_as_array: Optional[bool] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "user_id_type": user_id_type,
                "text_field_as_array": text_field_as_array,
            }
        )
        response = await self._client.request_json(
            "GET",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}",
            params=params,
        )
        return _unwrap_data(response)

    async def create_record(
        self,
        app_token: str,
        table_id: str,
        fields: Mapping[str, object],
        *,
        user_id_type: Optional[str] = None,
        client_token: Optional[str] = None,
        ignore_consistency_check: Optional[bool] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "user_id_type": user_id_type,
                "client_token": client_token,
                "ignore_consistency_check": ignore_consistency_check,
            }
        )
        response = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records",
            params=params,
            payload={"fields": dict(fields)},
        )
        return _unwrap_data(response)

    async def batch_create_records(
        self,
        app_token: str,
        table_id: str,
        records: list[Mapping[str, object]],
        *,
        user_id_type: Optional[str] = None,
        client_token: Optional[str] = None,
        ignore_consistency_check: Optional[bool] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "user_id_type": user_id_type,
                "client_token": client_token,
                "ignore_consistency_check": ignore_consistency_check,
            }
        )
        payload_records = [dict(record) for record in records]
        response = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_create",
            params=params,
            payload={"records": payload_records},
        )
        return _unwrap_data(response)

    async def update_record(
        self,
        app_token: str,
        table_id: str,
        record_id: str,
        fields: Mapping[str, object],
        *,
        user_id_type: Optional[str] = None,
        client_token: Optional[str] = None,
        ignore_consistency_check: Optional[bool] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "user_id_type": user_id_type,
                "client_token": client_token,
                "ignore_consistency_check": ignore_consistency_check,
            }
        )
        response = await self._client.request_json(
            "PUT",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}",
            params=params,
            payload={"fields": dict(fields)},
        )
        return _unwrap_data(response)

    async def batch_update_records(
        self,
        app_token: str,
        table_id: str,
        records: list[Mapping[str, object]],
        *,
        user_id_type: Optional[str] = None,
        client_token: Optional[str] = None,
        ignore_consistency_check: Optional[bool] = None,
    ) -> Mapping[str, Any]:
        params = _drop_none(
            {
                "user_id_type": user_id_type,
                "client_token": client_token,
                "ignore_consistency_check": ignore_consistency_check,
            }
        )
        payload_records = [dict(record) for record in records]
        response = await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_update",
            params=params,
            payload={"records": payload_records},
        )
        return _unwrap_data(response)

    async def delete_record(
        self,
        app_token: str,
        table_id: str,
        record_id: str,
    ) -> None:
        await self._client.request_json(
            "DELETE",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}",
        )

    async def batch_delete_records(
        self,
        app_token: str,
        table_id: str,
        record_ids: list[str],
    ) -> None:
        await self._client.request_json(
            "POST",
            f"/bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_delete",
            payload={"records": list(record_ids)},
        )

    async def get_app(self, app_token: str) -> Mapping[str, Any]:
        response = await self._client.request_json("GET", f"/bitable/v1/apps/{app_token}")
        return _unwrap_data(response)

    async def update_app(self, app_token: str, *, name: Optional[str] = None, is_advanced: Optional[bool] = None) -> Mapping[str, Any]:
        payload = _drop_none({"name": name, "is_advanced": is_advanced})
        response = await self._client.request_json("PUT", f"/bitable/v1/apps/{app_token}", payload=payload)
        return _unwrap_data(response)

    async def copy_app(self, app_token: str, *, name: Optional[str] = None, folder_token: Optional[str] = None, without_content: Optional[bool] = None, time_zone: Optional[str] = None) -> Mapping[str, Any]:
        payload = _drop_none({"name": name, "folder_token": folder_token, "without_content": without_content, "time_zone": time_zone})
        response = await self._client.request_json("POST", f"/bitable/v1/apps/{app_token}/copy", payload=payload)
        return _unwrap_data(response)

    async def list_views(self, app_token: str, table_id: str, *, page_size: Optional[int] = None, page_token: Optional[str] = None, user_id_type: Optional[str] = None) -> Mapping[str, Any]:
        params = _drop_none({"page_size": page_size, "page_token": page_token, "user_id_type": user_id_type})
        response = await self._client.request_json("GET", f"/bitable/v1/apps/{app_token}/tables/{table_id}/views", params=params)
        return _unwrap_data(response)

    async def iter_views(self, app_token: str, table_id: str, *, page_size: int = 100, user_id_type: Optional[str] = None) -> AsyncIterator[Mapping[str, Any]]:
        page_token: Optional[str] = None
        while True:
            data = await self.list_views(app_token, table_id, page_size=page_size, page_token=page_token, user_id_type=user_id_type)
            for item in _iter_page_items(data):
                yield item
            if not _has_more(data):
                return
            page_token = _next_page_token(data)
            if not page_token:
                return

    async def get_view(self, app_token: str, table_id: str, view_id: str) -> Mapping[str, Any]:
        response = await self._client.request_json("GET", f"/bitable/v1/apps/{app_token}/tables/{table_id}/views/{view_id}")
        return _unwrap_data(response)

    async def create_view(self, app_token: str, table_id: str, view: Mapping[str, object]) -> Mapping[str, Any]:
        response = await self._client.request_json("POST", f"/bitable/v1/apps/{app_token}/tables/{table_id}/views", payload=dict(view))
        return _unwrap_data(response)

    async def update_view(self, app_token: str, table_id: str, view_id: str, view: Mapping[str, object]) -> Mapping[str, Any]:
        response = await self._client.request_json("PATCH", f"/bitable/v1/apps/{app_token}/tables/{table_id}/views/{view_id}", payload=dict(view))
        return _unwrap_data(response)

    async def delete_view(self, app_token: str, table_id: str, view_id: str) -> Mapping[str, Any]:
        response = await self._client.request_json("DELETE", f"/bitable/v1/apps/{app_token}/tables/{table_id}/views/{view_id}")
        return _unwrap_data(response)

    async def get_field(self, app_token: str, table_id: str, field_id: str) -> Mapping[str, Any]:
        response = await self._client.request_json("GET", f"/bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}")
        return _unwrap_data(response)

    async def _cleanup_default_tables(self, app_token: str, keep_table_id: str) -> None:
        try:
            tables_resp = await self._client.request_json(
                "GET",
                f"/bitable/v1/apps/{app_token}/tables",
                params={"page_size": 100},
            )
        except Exception:
            return

        items = (tables_resp.get("data") or {}).get("items") or []
        for item in items:
            table_id = item.get("table_id")
            if not table_id or table_id == keep_table_id:
                continue
            try:
                await self._client.request_json("DELETE", f"/bitable/v1/apps/{app_token}/tables/{table_id}")
            except Exception:
                continue

