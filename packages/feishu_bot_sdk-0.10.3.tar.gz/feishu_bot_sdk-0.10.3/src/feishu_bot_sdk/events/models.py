from dataclasses import dataclass, field
from typing import Any, Mapping, Optional

from .message_content import (
    ParsedMessageContent,
    extract_text_from_parsed_message,
    parse_received_message_content,
)
from .types import EventContext


def _as_mapping(value: Any) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    return {}


def _as_optional_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return str(value)


def _as_optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return int(stripped)
        except ValueError:
            return None
    return None


def _as_mapping_list(value: Any) -> list[Mapping[str, Any]]:
    if not isinstance(value, list):
        return []
    items: list[Mapping[str, Any]] = []
    for item in value:
        if isinstance(item, Mapping):
            items.append(dict(item))
    return items


def _as_string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    items: list[str] = []
    for item in value:
        parsed = _as_optional_str(item)
        if parsed is not None:
            items.append(parsed)
    return items


@dataclass(frozen=True)
class P2ImMessageReceiveV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    message_id: Optional[str]
    chat_id: Optional[str]
    chat_type: Optional[str]
    message_type: Optional[str]
    content_raw: str
    content: ParsedMessageContent
    text: Optional[str]
    sender_open_id: Optional[str]
    sender_user_id: Optional[str]
    sender_union_id: Optional[str]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2ImMessageReceiveV1":
        event = _as_mapping(context.event)
        message = _as_mapping(event.get("message"))
        sender = _as_mapping(event.get("sender"))
        sender_id = _as_mapping(sender.get("sender_id"))
        message_type = _as_optional_str(message.get("message_type"))
        content_raw = _as_optional_str(message.get("content")) or ""
        content = parse_received_message_content(
            message_type=message_type,
            content_raw=content_raw,
        )
        text = extract_text_from_parsed_message(content)
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            message_id=_as_optional_str(message.get("message_id")),
            chat_id=_as_optional_str(message.get("chat_id")),
            chat_type=_as_optional_str(message.get("chat_type")),
            message_type=message_type,
            content_raw=content_raw,
            content=content,
            text=text,
            sender_open_id=_as_optional_str(sender_id.get("open_id")),
            sender_user_id=_as_optional_str(sender_id.get("user_id")),
            sender_union_id=_as_optional_str(sender_id.get("union_id")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2ImMessageReadV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    reader_open_id: Optional[str]
    reader_user_id: Optional[str]
    reader_union_id: Optional[str]
    read_time: Optional[str]
    reader_tenant_key: Optional[str]
    message_id_list: list[str] = field(default_factory=list)
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2ImMessageReadV1":
        event = _as_mapping(context.event)
        reader = _as_mapping(event.get("reader"))
        reader_id = _as_mapping(reader.get("reader_id"))
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            reader_open_id=_as_optional_str(reader_id.get("open_id")),
            reader_user_id=_as_optional_str(reader_id.get("user_id")),
            reader_union_id=_as_optional_str(reader_id.get("union_id")),
            read_time=_as_optional_str(reader.get("read_time")),
            reader_tenant_key=_as_optional_str(reader.get("tenant_key")),
            message_id_list=_as_string_list(event.get("message_id_list")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2ImMessageRecalledV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    message_id: Optional[str]
    chat_id: Optional[str]
    recall_time: Optional[str]
    recall_type: Optional[str]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2ImMessageRecalledV1":
        event = _as_mapping(context.event)
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            message_id=_as_optional_str(event.get("message_id")),
            chat_id=_as_optional_str(event.get("chat_id")),
            recall_time=_as_optional_str(event.get("recall_time")),
            recall_type=_as_optional_str(event.get("recall_type")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2ImMessageReactionCreatedV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    message_id: Optional[str]
    emoji_type: Optional[str]
    operator_type: Optional[str]
    operator_open_id: Optional[str]
    operator_user_id: Optional[str]
    operator_union_id: Optional[str]
    operator_app_id: Optional[str]
    action_time: Optional[str]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2ImMessageReactionCreatedV1":
        event = _as_mapping(context.event)
        reaction_type = _as_mapping(event.get("reaction_type"))
        operator = _as_mapping(event.get("user_id"))
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            message_id=_as_optional_str(event.get("message_id")),
            emoji_type=_as_optional_str(reaction_type.get("emoji_type")),
            operator_type=_as_optional_str(event.get("operator_type")),
            operator_open_id=_as_optional_str(operator.get("open_id")),
            operator_user_id=_as_optional_str(operator.get("user_id")),
            operator_union_id=_as_optional_str(operator.get("union_id")),
            operator_app_id=_as_optional_str(event.get("app_id")),
            action_time=_as_optional_str(event.get("action_time")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2ImMessageReactionDeletedV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    message_id: Optional[str]
    emoji_type: Optional[str]
    operator_type: Optional[str]
    operator_open_id: Optional[str]
    operator_user_id: Optional[str]
    operator_union_id: Optional[str]
    operator_app_id: Optional[str]
    action_time: Optional[str]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2ImMessageReactionDeletedV1":
        event = _as_mapping(context.event)
        reaction_type = _as_mapping(event.get("reaction_type"))
        operator = _as_mapping(event.get("user_id"))
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            message_id=_as_optional_str(event.get("message_id")),
            emoji_type=_as_optional_str(reaction_type.get("emoji_type")),
            operator_type=_as_optional_str(event.get("operator_type")),
            operator_open_id=_as_optional_str(operator.get("open_id")),
            operator_user_id=_as_optional_str(operator.get("user_id")),
            operator_union_id=_as_optional_str(operator.get("union_id")),
            operator_app_id=_as_optional_str(event.get("app_id")),
            action_time=_as_optional_str(event.get("action_time")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2ApplicationBotMenuV6:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    event_key: Optional[str]
    operator_open_id: Optional[str]
    operator_user_id: Optional[str]
    operator_union_id: Optional[str]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2ApplicationBotMenuV6":
        event = _as_mapping(context.event)
        operator = _as_mapping(event.get("operator"))
        operator_id = _as_mapping(operator.get("operator_id"))
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            event_key=_as_optional_str(event.get("event_key")),
            operator_open_id=_as_optional_str(operator.get("open_id"))
            or _as_optional_str(operator_id.get("open_id")),
            operator_user_id=_as_optional_str(operator.get("user_id"))
            or _as_optional_str(operator_id.get("user_id")),
            operator_union_id=_as_optional_str(operator.get("union_id"))
            or _as_optional_str(operator_id.get("union_id")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2CardActionTrigger:
    event_id: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    open_id: Optional[str]
    user_id: Optional[str]
    union_id: Optional[str]
    action_tag: Optional[str]
    action_value: Mapping[str, Any]
    action: Mapping[str, Any] = field(default_factory=dict)
    operator: Mapping[str, Any] = field(default_factory=dict)
    open_message_id: Optional[str] = None
    open_chat_id: Optional[str] = None
    trigger_time: Optional[str] = None
    token: Optional[str] = None
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2CardActionTrigger":
        event = _as_mapping(context.event)
        operator = _as_mapping(event.get("operator"))
        action = _as_mapping(event.get("action"))
        action_value = _as_mapping(action.get("value"))
        event_context = _as_mapping(event.get("context"))
        return cls(
            event_id=context.envelope.event_id,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            open_id=_as_optional_str(operator.get("open_id")),
            user_id=_as_optional_str(operator.get("user_id")),
            union_id=_as_optional_str(operator.get("union_id")),
            action_tag=_as_optional_str(action.get("tag")),
            action_value=dict(action_value),
            action=dict(action),
            operator=dict(operator),
            open_message_id=_as_optional_str(event_context.get("open_message_id"))
            or _as_optional_str(event.get("open_message_id")),
            open_chat_id=_as_optional_str(event_context.get("open_chat_id"))
            or _as_optional_str(event.get("open_chat_id")),
            trigger_time=_as_optional_str(event.get("action_time"))
            or context.envelope.create_time,
            token=context.envelope.token,
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2URLPreviewGet:
    event_id: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    open_id: Optional[str]
    user_id: Optional[str]
    url: Optional[str]
    preview_token: Optional[str]
    open_chat_id: Optional[str]
    open_message_id: Optional[str]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2URLPreviewGet":
        event = _as_mapping(context.event)
        operator = _as_mapping(event.get("operator"))
        details = _as_mapping(event.get("context"))
        return cls(
            event_id=context.envelope.event_id,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            open_id=_as_optional_str(operator.get("open_id")),
            user_id=_as_optional_str(operator.get("user_id")),
            url=_as_optional_str(details.get("url")),
            preview_token=_as_optional_str(details.get("preview_token")),
            open_chat_id=_as_optional_str(details.get("open_chat_id")),
            open_message_id=_as_optional_str(details.get("open_message_id")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P1CustomizedEvent:
    event_type: str
    event_id: Optional[str]
    token: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    ts: Optional[str]
    event: Mapping[str, Any]
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P1CustomizedEvent":
        event = _as_mapping(context.event)
        return cls(
            event_type=context.envelope.event_type,
            event_id=context.envelope.event_id,
            token=context.envelope.token,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            ts=context.envelope.create_time,
            event=dict(event),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2DriveFileBitableRecordChangedV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    file_type: Optional[str]
    file_token: Optional[str]
    table_id: Optional[str]
    revision: Optional[int]
    operator_union_id: Optional[str]
    operator_user_id: Optional[str]
    operator_open_id: Optional[str]
    action_list: list[Mapping[str, Any]] = field(default_factory=list)
    subscriber_id_list: list[Mapping[str, Any]] = field(default_factory=list)
    update_time: Optional[int] = None
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2DriveFileBitableRecordChangedV1":
        event = _as_mapping(context.event)
        operator = _as_mapping(event.get("operator_id"))
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            file_type=_as_optional_str(event.get("file_type")),
            file_token=_as_optional_str(event.get("file_token")),
            table_id=_as_optional_str(event.get("table_id")),
            revision=_as_optional_int(event.get("revision")),
            operator_union_id=_as_optional_str(operator.get("union_id")),
            operator_user_id=_as_optional_str(operator.get("user_id")),
            operator_open_id=_as_optional_str(operator.get("open_id")),
            action_list=_as_mapping_list(event.get("action_list")),
            subscriber_id_list=_as_mapping_list(event.get("subscriber_id_list")),
            update_time=_as_optional_int(event.get("update_time")),
            raw=dict(context.payload),
        )


@dataclass(frozen=True)
class P2DriveFileBitableFieldChangedV1:
    event_id: Optional[str]
    create_time: Optional[str]
    tenant_key: Optional[str]
    app_id: Optional[str]
    file_type: Optional[str]
    file_token: Optional[str]
    table_id: Optional[str]
    revision: Optional[int]
    operator_union_id: Optional[str]
    operator_user_id: Optional[str]
    operator_open_id: Optional[str]
    action_list: list[Mapping[str, Any]] = field(default_factory=list)
    subscriber_id_list: list[Mapping[str, Any]] = field(default_factory=list)
    update_time: Optional[int] = None
    raw: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_context(cls, context: EventContext) -> "P2DriveFileBitableFieldChangedV1":
        event = _as_mapping(context.event)
        operator = _as_mapping(event.get("operator_id"))
        return cls(
            event_id=context.envelope.event_id,
            create_time=context.envelope.create_time,
            tenant_key=context.envelope.tenant_key,
            app_id=context.envelope.app_id,
            file_type=_as_optional_str(event.get("file_type")),
            file_token=_as_optional_str(event.get("file_token")),
            table_id=_as_optional_str(event.get("table_id")),
            revision=_as_optional_int(event.get("revision")),
            operator_union_id=_as_optional_str(operator.get("union_id")),
            operator_user_id=_as_optional_str(operator.get("user_id")),
            operator_open_id=_as_optional_str(operator.get("open_id")),
            action_list=_as_mapping_list(event.get("action_list")),
            subscriber_id_list=_as_mapping_list(event.get("subscriber_id_list")),
            update_time=_as_optional_int(event.get("update_time")),
            raw=dict(context.payload),
        )
