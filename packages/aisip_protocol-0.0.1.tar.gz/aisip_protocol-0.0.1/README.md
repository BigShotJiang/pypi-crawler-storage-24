# aisip-protocol

AISIP Protocol — AI Structured Instruction Protocol specification

- Protocol: https://aisip.dev
- License: MIT
