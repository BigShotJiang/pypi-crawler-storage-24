from pathlib import Path
import textwrap

#### 项目结构 ####
PROJECT_STRUCTURE = {
    # 模块文件
    "models": [
        "__init__.py",
    ],
    "train": [
        "__init__.py",
    ],
    "visualization": [
        "__init__.py",
    ],
    "utils": [
        "__init__.py",
    ],
    "configs": [
        "config.yaml",
    ],
    "scripts": [
        "run_pipeline_1.py",
        "run_pipeline_2.py",
        "run_pipeline_3.py",
    ],

    # 非模块文件
    "data": [],
    "logs": [],
    "outputs": [],
}

ROOT_FILES = [
    ".gitignore",
    "README.md",
    "requirements.txt",
]

#### 具体内容 ####
GITIGNORE_CONTENT = textwrap.dedent("""
    # Python
    __pycache__/
    *.pyc
    *.pyo
    *.pyd

    # virtual env
    .venv/
    venv/
    env/

    # logs
    logs/

    # outputs
    outputs/

    # dataset
    data/*

    # IDE
    .vscode/
    .idea/

    # mac
    .DS_Store
""")

INIT_CONTENT = textwrap.dedent("""


    __all__ = [

    ]
""")

CONFIG_YAML_CONTENT = textwrap.dedent("""
    # =========================
    # seed
    # =========================
    seed: 2026

    # =========================
    # Paths
    # =========================
    paths:
      output_dir: outputs
      log_dir: logs

    # =========================
    # Train
    # =========================
    train:
      batch_size: 64
      epochs: 50
      learning_rate: 0.001
      weight_decay: 0.0001
""")

PIPELINE_CONTENT = textwrap.dedent("""
    def main():
        pass

    if __name__ == "__main__":
        main()
""")


def _strip_once(s: str) -> str:
    if s.startswith("\n"):
        s = s[1:]
    if s.endswith("\n"):
        s = s[:-1]
    return s


def _make(file_path, content=None, overwrite=False):
    # 删去旧的, 创建新的
    if file_path.exists() and overwrite:
        print(f"Overwriting {file_path}...")
        file_path.unlink()
        if content:
            file_path.write_text(_strip_once(content) + "\n", encoding="utf-8")
        else:
            file_path.touch(exist_ok=True)
    # 保持不变
    elif file_path.exists():
        pass
    # 创建新的
    else:
        if content:
            file_path.write_text(_strip_once(content) + "\n", encoding="utf-8")
        else:
            file_path.touch(exist_ok=True)


def _makes(file: str, file_path: Path, overwrite=False):
    if file == "__init__.py":
        _make(file_path, content=INIT_CONTENT, overwrite=overwrite)

    elif file == ".gitignore":
        _make(file_path, content=GITIGNORE_CONTENT, overwrite=overwrite)

    elif file == "config.yaml":
        _make(file_path, content=CONFIG_YAML_CONTENT, overwrite=overwrite)

    elif file in ["run_pipeline_1.py", "run_pipeline_2.py", "run_pipeline_3.py"]:
        _make(file_path, content=PIPELINE_CONTENT, overwrite=overwrite)

    else:
        _make(file_path, overwrite=overwrite)


def b_create_project(project_dir: Path, overwrite=False):
    """
    创建项目目录结构
    """
    project_dir = Path(project_dir)

    # 创建根目录内文件夹
    for folder, files in PROJECT_STRUCTURE.items():
        folder_path = project_dir / folder
        folder_path.mkdir(parents=True, exist_ok=True)

        for file in files:
            file_path = (folder_path / file)
            _makes(file, file_path, overwrite=overwrite)

    # 创建根目录内文件
    for file in ROOT_FILES:
        file_path = project_dir / file
        _makes(file, file_path, overwrite=overwrite)


def main():
    base_path = Path(".").resolve()
    print(f"Creating project structure in: {base_path}")

    b_create_project(base_path)
    print("Project structure created successfully!")


if __name__ == "__main__":
    main()