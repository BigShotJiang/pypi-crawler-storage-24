# Build Data, automatisch generiert, nicht manuell ändern!
SIMSTB_VERSION='0.6.0a1'
SIMSTB_VERSION_DATE='22.03.2026'
