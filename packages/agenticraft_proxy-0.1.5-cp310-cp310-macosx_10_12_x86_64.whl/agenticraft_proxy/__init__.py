"""AgentiCraft Proxy — high-performance LLM proxy algorithms.

Re-exports from the native Rust extension for a clean public API.
"""

from agenticraft_proxy._native import (
    # Router
    ThompsonRouter,
    RouterConfig,
    ProviderProfile,
    RoutingDecision,
    # Circuit breaker
    CircuitBreaker,
    CircuitBreakerConfig,
    # Rate limiter
    TokenBucket,
    RateLimitConfig,
    # Key pool
    KeyPool,
    KeySummary,
    # Retry
    RetryPolicy,
    # Exceptions
    ProxyError,
    CircuitOpenError,
    RateLimitedError,
    NoAvailableKeysError,
    NoProvidersError,
    ProviderNotFoundError,
    InvalidParameterError,
    SamplingError,
)

__all__ = [
    # Router
    "ThompsonRouter",
    "RouterConfig",
    "ProviderProfile",
    "RoutingDecision",
    # Circuit breaker
    "CircuitBreaker",
    "CircuitBreakerConfig",
    # Rate limiter
    "TokenBucket",
    "RateLimitConfig",
    # Key pool
    "KeyPool",
    "KeySummary",
    # Retry
    "RetryPolicy",
    # Exceptions
    "ProxyError",
    "CircuitOpenError",
    "RateLimitedError",
    "NoAvailableKeysError",
    "NoProvidersError",
    "ProviderNotFoundError",
    "InvalidParameterError",
    "SamplingError",
    # gRPC control plane (lazy import — requires grpcio)
    "grpc",
    # Policy compiler (lazy import — requires agenticraft)
    "policy",
]

__version__ = "0.1.5"
