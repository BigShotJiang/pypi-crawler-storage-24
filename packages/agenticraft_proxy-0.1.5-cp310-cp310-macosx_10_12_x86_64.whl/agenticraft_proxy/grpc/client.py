"""Async gRPC client for the AgentiCraft proxy control plane.

Wraps generated stubs with a clean Python API and async context manager
hygiene (ensures HTTP/2 sockets are freed even on task cancellation).

Usage:
    async with ProxyControlClient("localhost:50051") as client:
        ack = await client.push_config(config)
        snapshot = await client.export_metrics()
        async for snap in client.stream_metrics(interval_ms=500):
            print(snap.timestamp_ms)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, AsyncIterator

import grpc.aio  # type: ignore[import-untyped]

from . import config_pb2, config_pb2_grpc
from . import context_pb2, context_pb2_grpc
from . import keypool_pb2, keypool_pb2_grpc
from . import metrics_pb2, metrics_pb2_grpc
from . import policy_pb2, policy_pb2_grpc
from . import broker_pb2, broker_pb2_grpc
from . import orchestration_pb2, orchestration_pb2_grpc
from . import compliance_pb2, compliance_pb2_grpc
from . import budgets_pb2, budgets_pb2_grpc
from . import sla_pb2, sla_pb2_grpc
from . import hitl_pb2, hitl_pb2_grpc
from . import federation_pb2, federation_pb2_grpc
from . import governance_pb2, governance_pb2_grpc
from . import guardrails_pb2, guardrails_pb2_grpc
from . import memory_pb2, memory_pb2_grpc
from . import zero_trust_pb2, zero_trust_pb2_grpc
from . import inference_routing_pb2, inference_routing_pb2_grpc

if TYPE_CHECKING:
    pass


class _BearerAuthInterceptor(
    grpc.aio.UnaryUnaryClientInterceptor,
    grpc.aio.UnaryStreamClientInterceptor,
):
    """Injects Bearer auth metadata into every gRPC call."""

    __slots__ = ("_metadata",)

    def __init__(self, token: str) -> None:
        self._metadata = grpc.aio.Metadata(("authorization", f"Bearer {token}"))

    async def intercept_unary_unary(self, continuation, client_call_details, request):
        new_details = grpc.aio.ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            self._metadata if client_call_details.metadata is None
            else client_call_details.metadata + self._metadata,
            client_call_details.credentials,
            client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)

    async def intercept_unary_stream(self, continuation, client_call_details, request):
        new_details = grpc.aio.ClientCallDetails(
            client_call_details.method,
            client_call_details.timeout,
            self._metadata if client_call_details.metadata is None
            else client_call_details.metadata + self._metadata,
            client_call_details.credentials,
            client_call_details.wait_for_ready,
        )
        return await continuation(new_details, request)


class ProxyControlClient:
    """Async gRPC client for the proxy control plane.

    Implements ``__aenter__``/``__aexit__`` for async context manager
    hygiene — ensures HTTP/2 sockets are freed even on task cancellation.
    """

    def __init__(
        self,
        target: str = "localhost:50051",
        ssl_credentials: "grpc.ChannelCredentials | None" = None,
        auth_token: str | None = None,
    ) -> None:
        self._target = target
        self._ssl_credentials = ssl_credentials
        self._interceptors: list[grpc.aio.ClientInterceptor] = []
        if auth_token:
            self._interceptors.append(_BearerAuthInterceptor(auth_token))
        self._channel: grpc.aio.Channel | None = None
        self._control_stub: config_pb2_grpc.ProxyControlStub | None = None
        self._keypool_stub: keypool_pb2_grpc.KeyPoolServiceStub | None = None
        self._metrics_stub: metrics_pb2_grpc.MetricsServiceStub | None = None
        self._policy_stub: policy_pb2_grpc.PolicyServiceStub | None = None
        self._context_stub: context_pb2_grpc.ContextServiceStub | None = None
        self._identity_stub: "identity_pb2_grpc.IdentityServiceStub | None" = None
        self._broker_stub: broker_pb2_grpc.BrokerServiceStub | None = None
        self._orchestration_stub: orchestration_pb2_grpc.OrchestrationServiceStub | None = None
        self._compliance_stub: compliance_pb2_grpc.ComplianceServiceStub | None = None
        self._budgets_stub: budgets_pb2_grpc.BudgetServiceStub | None = None
        self._sla_stub: sla_pb2_grpc.SlaServiceStub | None = None
        self._hitl_stub: hitl_pb2_grpc.HitlServiceStub | None = None
        self._federation_stub: federation_pb2_grpc.FederationServiceStub | None = None
        self._governance_stub: governance_pb2_grpc.GovernanceServiceStub | None = None
        self._guardrails_stub: guardrails_pb2_grpc.GuardrailsServiceStub | None = None
        self._memory_stub: memory_pb2_grpc.MemoryServiceStub | None = None
        self._zero_trust_stub: zero_trust_pb2_grpc.ZeroTrustServiceStub | None = None
        self._inference_routing_stub: inference_routing_pb2_grpc.InferenceRoutingServiceStub | None = None

    def channel_state(self) -> "grpc.ChannelConnectivity | None":
        """Return the current channel connectivity state, or None if no channel."""
        if self._channel is None:
            return None
        return self._channel.get_state(try_to_connect=False)

    def _ensure_channel(self) -> None:
        if self._channel is None:
            if self._ssl_credentials is not None:
                self._channel = grpc.aio.secure_channel(
                    self._target,
                    self._ssl_credentials,
                    interceptors=self._interceptors or None,
                )
            else:
                self._channel = grpc.aio.insecure_channel(
                    self._target,
                    interceptors=self._interceptors or None,
                )
            self._control_stub = config_pb2_grpc.ProxyControlStub(self._channel)
            self._keypool_stub = keypool_pb2_grpc.KeyPoolServiceStub(self._channel)
            self._metrics_stub = metrics_pb2_grpc.MetricsServiceStub(self._channel)
            self._policy_stub = policy_pb2_grpc.PolicyServiceStub(self._channel)
            self._context_stub = context_pb2_grpc.ContextServiceStub(self._channel)
            self._broker_stub = broker_pb2_grpc.BrokerServiceStub(self._channel)
            self._orchestration_stub = orchestration_pb2_grpc.OrchestrationServiceStub(
                self._channel
            )
            self._compliance_stub = compliance_pb2_grpc.ComplianceServiceStub(
                self._channel
            )
            self._budgets_stub = budgets_pb2_grpc.BudgetServiceStub(self._channel)
            self._sla_stub = sla_pb2_grpc.SlaServiceStub(self._channel)
            self._hitl_stub = hitl_pb2_grpc.HitlServiceStub(self._channel)
            self._federation_stub = federation_pb2_grpc.FederationServiceStub(
                self._channel
            )
            self._governance_stub = governance_pb2_grpc.GovernanceServiceStub(
                self._channel
            )
            self._guardrails_stub = guardrails_pb2_grpc.GuardrailsServiceStub(
                self._channel
            )
            self._memory_stub = memory_pb2_grpc.MemoryServiceStub(self._channel)
            self._zero_trust_stub = zero_trust_pb2_grpc.ZeroTrustServiceStub(
                self._channel
            )
            self._inference_routing_stub = (
                inference_routing_pb2_grpc.InferenceRoutingServiceStub(self._channel)
            )
            try:
                from . import identity_pb2_grpc

                self._identity_stub = identity_pb2_grpc.IdentityServiceStub(
                    self._channel
                )
            except ImportError:
                self._identity_stub = None

    async def __aenter__(self) -> ProxyControlClient:
        self._ensure_channel()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    # -----------------------------------------------------------------
    # Config push
    # -----------------------------------------------------------------

    async def push_config(
        self,
        config: config_pb2.ProxyConfig,
    ) -> config_pb2.ConfigAck:
        """Push configuration to the proxy data plane."""
        self._ensure_channel()
        assert self._control_stub is not None
        return await self._control_stub.PushConfig(config)

    # -----------------------------------------------------------------
    # Policy
    # -----------------------------------------------------------------

    async def update_policy(
        self,
        graph: policy_pb2.CompiledPolicyGraph,
    ) -> policy_pb2.PolicyAck:
        """Push a compiled policy graph to the proxy."""
        self._ensure_channel()
        assert self._policy_stub is not None
        return await self._policy_stub.UpdatePolicy(graph)

    # -----------------------------------------------------------------
    # Metrics
    # -----------------------------------------------------------------

    async def export_metrics(self) -> metrics_pb2.MetricsSnapshot:
        """Pull a single metrics snapshot from the proxy."""
        self._ensure_channel()
        assert self._metrics_stub is not None
        req = metrics_pb2.MetricsRequest()
        return await self._metrics_stub.ExportMetrics(req)

    async def stream_metrics(
        self,
        interval_ms: int = 1000,
    ) -> AsyncIterator[metrics_pb2.MetricsSnapshot]:
        """Stream metrics snapshots at the given interval.

        Yields ``MetricsSnapshot`` messages until the caller breaks or
        the server disconnects.
        """
        self._ensure_channel()
        assert self._metrics_stub is not None
        req = metrics_pb2.MetricsRequest(interval_ms=interval_ms)
        stream = self._metrics_stub.StreamMetrics(req)
        async for snapshot in stream:
            yield snapshot

    # -----------------------------------------------------------------
    # Key pool
    # -----------------------------------------------------------------

    async def add_key(
        self,
        provider: str,
        key: str,
        weight: float = 1.0,
        daily_limit: int = 0,
    ) -> "keypool_pb2.KeyPoolAck":
        """Add an API key to a provider's key pool."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.AddKey(
            keypool_pb2.AddKeyRequest(
                provider=provider,
                key=key,
                weight=weight,
                daily_limit=daily_limit,
            ),
        )

    async def remove_key(
        self,
        provider: str,
        key: str,
    ) -> "keypool_pb2.KeyPoolAck":
        """Remove an API key from a provider's key pool."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.RemoveKey(
            keypool_pb2.RemoveKeyRequest(provider=provider, key=key),
        )

    async def enable_key(
        self,
        provider: str,
        key: str,
    ) -> "keypool_pb2.KeyPoolAck":
        """Re-enable a disabled API key."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.EnableKey(
            keypool_pb2.EnableKeyRequest(provider=provider, key=key),
        )

    async def disable_key(
        self,
        provider: str,
        key: str,
    ) -> "keypool_pb2.KeyPoolAck":
        """Disable an API key."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.DisableKey(
            keypool_pb2.DisableKeyRequest(provider=provider, key=key),
        )

    async def list_key_metrics(
        self,
        provider: str = "",
    ) -> "keypool_pb2.ListKeyMetricsResponse":
        """List key metrics for a provider (or all providers if empty)."""
        self._ensure_channel()
        assert self._keypool_stub is not None
        return await self._keypool_stub.ListKeyMetrics(
            keypool_pb2.ListKeyMetricsRequest(provider=provider),
        )

    # -----------------------------------------------------------------
    # Context store
    # -----------------------------------------------------------------

    async def store_context(
        self,
        key: str,
        value: bytes,
        ttl_secs: int = 0,
    ) -> context_pb2.ContextAck:
        """Store a context entry."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Store(
            context_pb2.ContextStoreRequest(key=key, value=value, ttl_secs=ttl_secs),
        )

    async def retrieve_context(
        self,
        key: str,
    ) -> context_pb2.ContextRetrieveResponse:
        """Retrieve a context entry by key."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Retrieve(
            context_pb2.ContextRetrieveRequest(key=key),
        )

    async def delete_context(
        self,
        key: str,
    ) -> context_pb2.ContextAck:
        """Delete a context entry."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Delete(
            context_pb2.ContextDeleteRequest(key=key),
        )

    async def context_info(self) -> context_pb2.ContextInfoResponse:
        """Get context store information."""
        self._ensure_channel()
        assert self._context_stub is not None
        return await self._context_stub.Info(
            context_pb2.ContextInfoRequest()
        )

    # -----------------------------------------------------------------
    # Identity
    # -----------------------------------------------------------------

    async def push_identities(
        self,
        agents: list[dict],
        full_sync: bool = True,
    ) -> "identity_pb2.PushIdentitiesResponse":
        """Push agent identities to the Rust proxy."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        request = identity_pb2.PushIdentitiesRequest(
            agents=[identity_pb2.AgentIdentity(**a) for a in agents],
            full_sync=full_sync,
        )
        return await self._identity_stub.PushIdentities(
            request
        )

    async def push_session_policy(
        self,
        policy: dict,
    ) -> "identity_pb2.PushSessionPolicyResponse":
        """Push session policy to the Rust proxy."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        request = identity_pb2.SessionPolicy(**policy)
        return await self._identity_stub.PushSessionPolicy(
            request
        )

    async def remove_agent_identity(
        self,
        agent_id: str,
    ) -> "identity_pb2.RemoveAgentResponse":
        """Remove an agent from the Rust proxy's identity registry."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        request = identity_pb2.RemoveAgentRequest(agent_id=agent_id)
        return await self._identity_stub.RemoveAgent(
            request
        )

    async def get_identity_state(self) -> "identity_pb2.IdentityState":
        """Query current identity state from the Rust proxy."""
        self._ensure_channel()
        assert self._identity_stub is not None
        from . import identity_pb2

        return await self._identity_stub.GetIdentityState(
            identity_pb2.GetIdentityStateRequest()
        )

    # -----------------------------------------------------------------
    # Broker
    # -----------------------------------------------------------------

    async def register_agent(
        self,
        agent_id: str,
        metadata: dict[str, str] | None = None,
    ) -> broker_pb2.RegisterAgentResponse:
        """Register an agent with the mesh broker."""
        self._ensure_channel()
        assert self._broker_stub is not None
        return await self._broker_stub.RegisterAgent(
            broker_pb2.RegisterAgentRequest(
                agent_id=agent_id,
                metadata=metadata or {},
            ),
        )

    async def unregister_agent(
        self,
        agent_id: str,
    ) -> broker_pb2.BrokerAck:
        """Unregister an agent from the mesh broker."""
        self._ensure_channel()
        assert self._broker_stub is not None
        return await self._broker_stub.UnregisterAgent(
            broker_pb2.UnregisterAgentRequest(agent_id=agent_id),
        )

    async def send_message(
        self,
        target_agent_id: str,
        sender_agent_id: str,
        payload: bytes,
        content_type: str = "application/octet-stream",
        correlation_id: str = "",
        ttl_secs: int = 0,
        headers: dict[str, str] | None = None,
    ) -> broker_pb2.SendMessageResponse:
        """Send a message from one agent to another."""
        self._ensure_channel()
        assert self._broker_stub is not None
        return await self._broker_stub.SendMessage(
            broker_pb2.SendMessageRequest(
                target_agent_id=target_agent_id,
                sender_agent_id=sender_agent_id,
                payload=payload,
                content_type=content_type,
                correlation_id=correlation_id,
                ttl_secs=ttl_secs,
                headers=headers or {},
            ),
        )

    async def broadcast_message(
        self,
        target_agent_ids: list[str],
        sender_agent_id: str,
        payload: bytes,
        content_type: str = "application/octet-stream",
        correlation_id: str = "",
        ttl_secs: int = 0,
        headers: dict[str, str] | None = None,
    ) -> broker_pb2.BroadcastMessageResponse:
        """Broadcast a message to multiple agents."""
        self._ensure_channel()
        assert self._broker_stub is not None
        return await self._broker_stub.BroadcastMessage(
            broker_pb2.BroadcastMessageRequest(
                target_agent_ids=target_agent_ids,
                sender_agent_id=sender_agent_id,
                payload=payload,
                content_type=content_type,
                correlation_id=correlation_id,
                ttl_secs=ttl_secs,
                headers=headers or {},
            ),
        )

    async def subscribe_messages(
        self,
        agent_id: str,
        batch_size: int = 1,
        timeout_ms: int = 0,
    ) -> AsyncIterator[broker_pb2.AgentMessage]:
        """Subscribe to messages for an agent (server-streaming)."""
        self._ensure_channel()
        assert self._broker_stub is not None
        stream = self._broker_stub.SubscribeMessages(
            broker_pb2.SubscribeMessagesRequest(
                agent_id=agent_id,
                batch_size=batch_size,
                timeout_ms=timeout_ms,
            ),
        )
        async for msg in stream:
            yield msg

    async def ack_message(
        self,
        agent_id: str,
        sequence: int,
        action: int = 0,
    ) -> broker_pb2.BrokerAck:
        """Acknowledge a message (ACK=0, NAK=1, TERM=2)."""
        self._ensure_channel()
        assert self._broker_stub is not None
        return await self._broker_stub.AckMessage(
            broker_pb2.AckMessageRequest(
                agent_id=agent_id,
                sequence=sequence,
                action=action,
            ),
        )

    async def list_agents(
        self,
        filter: str = "",
    ) -> broker_pb2.ListAgentsResponse:
        """List agents registered with the broker."""
        self._ensure_channel()
        assert self._broker_stub is not None
        return await self._broker_stub.ListAgents(
            broker_pb2.ListAgentsRequest(filter=filter),
        )

    # -----------------------------------------------------------------
    # Orchestration
    # -----------------------------------------------------------------

    async def create_workflow(
        self,
        workflow_id: str,
        steps: list[orchestration_pb2.WorkflowStep],
        metadata: dict[str, str] | None = None,
    ) -> orchestration_pb2.CreateWorkflowResponse:
        """Create a workflow with the given steps."""
        self._ensure_channel()
        assert self._orchestration_stub is not None
        return await self._orchestration_stub.CreateWorkflow(
            orchestration_pb2.CreateWorkflowRequest(
                workflow_id=workflow_id,
                steps=steps,
                metadata=metadata or {},
            ),
        )

    async def execute_workflow(
        self,
        workflow_id: str,
        step_id: str = "",
        parameters: bytes = b"",
    ) -> orchestration_pb2.ExecuteWorkflowResponse:
        """Execute a workflow (or a specific step)."""
        self._ensure_channel()
        assert self._orchestration_stub is not None
        return await self._orchestration_stub.ExecuteWorkflow(
            orchestration_pb2.ExecuteWorkflowRequest(
                workflow_id=workflow_id,
                step_id=step_id,
                parameters=parameters,
            ),
        )

    async def get_workflow_status(
        self,
        workflow_id: str,
    ) -> orchestration_pb2.WorkflowStatusResponse:
        """Get the current status of a workflow."""
        self._ensure_channel()
        assert self._orchestration_stub is not None
        return await self._orchestration_stub.GetWorkflowStatus(
            orchestration_pb2.GetWorkflowStatusRequest(
                workflow_id=workflow_id,
            ),
        )

    async def stream_workflow_events(
        self,
        workflow_id: str,
    ) -> AsyncIterator[orchestration_pb2.WorkflowEvent]:
        """Stream workflow events (server-streaming)."""
        self._ensure_channel()
        assert self._orchestration_stub is not None
        stream = self._orchestration_stub.StreamWorkflowEvents(
            orchestration_pb2.StreamWorkflowEventsRequest(
                workflow_id=workflow_id,
            ),
        )
        async for event in stream:
            yield event

    # -----------------------------------------------------------------
    # Metrics (additional RPCs)
    # -----------------------------------------------------------------

    async def get_provider_health(
        self,
        provider: str = "",
    ) -> metrics_pb2.ProviderHealthResponse:
        """Get health info for a provider (or all if empty)."""
        self._ensure_channel()
        assert self._metrics_stub is not None
        return await self._metrics_stub.GetProviderHealth(
            metrics_pb2.ProviderHealthRequest(provider=provider),
        )

    async def stream_events(
        self,
        subject_filter: str = "",
    ) -> AsyncIterator[metrics_pb2.EventEnvelope]:
        """Stream NATS events matching the subject filter."""
        self._ensure_channel()
        assert self._metrics_stub is not None
        stream = self._metrics_stub.StreamEvents(
            metrics_pb2.StreamEventsRequest(subject_filter=subject_filter),
        )
        async for envelope in stream:
            yield envelope

    # -----------------------------------------------------------------
    # Compliance
    # -----------------------------------------------------------------

    async def configure_compliance(
        self,
        config: compliance_pb2.ComplianceConfig,
    ) -> compliance_pb2.ComplianceConfigAck:
        """Push compliance configuration."""
        self._ensure_channel()
        assert self._compliance_stub is not None
        return await self._compliance_stub.Configure(config)

    async def get_compliance_stats(self) -> compliance_pb2.ComplianceStats:
        """Get compliance audit statistics."""
        self._ensure_channel()
        assert self._compliance_stub is not None
        return await self._compliance_stub.GetStats(compliance_pb2.ComplianceStatsRequest())

    async def verify_chain(
        self,
        entries: list[compliance_pb2.AuditEntry],
    ) -> compliance_pb2.VerifyResponse:
        """Verify tamper-evidence chain on audit entries."""
        self._ensure_channel()
        assert self._compliance_stub is not None
        return await self._compliance_stub.VerifyChain(
            compliance_pb2.VerifyRequest(entries=entries),
        )

    async def stream_audit_entries(
        self,
        entries: list[compliance_pb2.AuditEntry],
    ) -> compliance_pb2.StreamAck:
        """Client-stream audit entries to the compliance engine."""
        self._ensure_channel()
        assert self._compliance_stub is not None

        async def _iter():
            for entry in entries:
                yield entry

        return await self._compliance_stub.StreamAuditEntries(_iter())

    async def export_audit(
        self,
        format: str = "json",
        tenant_id: str = "",
    ) -> AsyncIterator[compliance_pb2.ExportResponse]:
        """Server-stream exported audit data."""
        self._ensure_channel()
        assert self._compliance_stub is not None
        stream = self._compliance_stub.ExportAudit(
            compliance_pb2.ExportRequest(format=format, tenant_id=tenant_id),
        )
        async for resp in stream:
            yield resp

    # -----------------------------------------------------------------
    # Budgets
    # -----------------------------------------------------------------

    async def set_org_budget(
        self,
        org_budget: budgets_pb2.OrgBudget,
    ) -> budgets_pb2.BudgetAck:
        """Set hierarchical budget for an org."""
        self._ensure_channel()
        assert self._budgets_stub is not None
        return await self._budgets_stub.SetOrgBudget(org_budget)

    async def reset_budgets(self) -> budgets_pb2.BudgetAck:
        """Reset all budget counters."""
        self._ensure_channel()
        assert self._budgets_stub is not None
        return await self._budgets_stub.ResetBudgets(budgets_pb2.ResetRequest())

    async def get_budget_usage(
        self,
        id: str,
        level: str = "org",
    ) -> budgets_pb2.BudgetUsage:
        """Get current budget usage for an entity."""
        self._ensure_channel()
        assert self._budgets_stub is not None
        return await self._budgets_stub.GetUsage(
            budgets_pb2.UsageRequest(id=id, level=level),
        )

    # -----------------------------------------------------------------
    # SLA
    # -----------------------------------------------------------------

    async def set_sla(
        self,
        definition: sla_pb2.SlaDefinition,
    ) -> sla_pb2.SlaAck:
        """Set SLA definition for an entity."""
        self._ensure_channel()
        assert self._sla_stub is not None
        return await self._sla_stub.SetSla(definition)

    async def get_sla_stats(
        self,
        entity_id: str,
    ) -> sla_pb2.SlaStats:
        """Get SLA statistics for an entity."""
        self._ensure_channel()
        assert self._sla_stub is not None
        return await self._sla_stub.GetStats(
            sla_pb2.StatsRequest(entity_id=entity_id),
        )

    async def reset_sla_trackers(self) -> sla_pb2.SlaAck:
        """Reset all SLA trackers."""
        self._ensure_channel()
        assert self._sla_stub is not None
        return await self._sla_stub.ResetTrackers(sla_pb2.ResetTrackersRequest())

    async def get_recommended_action(
        self,
        entity_id: str,
    ) -> sla_pb2.ActionResponse:
        """Get recommended action for an SLA violation."""
        self._ensure_channel()
        assert self._sla_stub is not None
        return await self._sla_stub.GetRecommendedAction(
            sla_pb2.ActionRequest(entity_id=entity_id),
        )

    # -----------------------------------------------------------------
    # HITL (Human-in-the-Loop)
    # -----------------------------------------------------------------

    async def configure_hitl(
        self,
        config: hitl_pb2.HitlConfig,
    ) -> hitl_pb2.HitlAck:
        """Push HITL configuration."""
        self._ensure_channel()
        assert self._hitl_stub is not None
        return await self._hitl_stub.Configure(config)

    async def approve(
        self,
        approval_id: str,
        approved_by: str,
    ) -> hitl_pb2.ResumeToken:
        """Approve a pending HITL request."""
        self._ensure_channel()
        assert self._hitl_stub is not None
        return await self._hitl_stub.Approve(
            hitl_pb2.HitlApproveRequest(
                approval_id=approval_id,
                approved_by=approved_by,
            ),
        )

    async def reject(
        self,
        approval_id: str,
        rejected_by: str,
        reason: str,
    ) -> hitl_pb2.HitlAck:
        """Reject a pending HITL request."""
        self._ensure_channel()
        assert self._hitl_stub is not None
        return await self._hitl_stub.Reject(
            hitl_pb2.RejectRequest(
                approval_id=approval_id,
                rejected_by=rejected_by,
                reason=reason,
            ),
        )

    async def list_pending(self) -> hitl_pb2.ListPendingResponse:
        """List pending HITL approval requests."""
        self._ensure_channel()
        assert self._hitl_stub is not None
        return await self._hitl_stub.ListPending(hitl_pb2.ListPendingRequest())

    async def get_hitl_stats(self) -> hitl_pb2.HitlStats:
        """Get HITL statistics."""
        self._ensure_channel()
        assert self._hitl_stub is not None
        return await self._hitl_stub.GetStats(hitl_pb2.HitlStatsRequest())

    # -----------------------------------------------------------------
    # Federation
    # -----------------------------------------------------------------

    async def add_trusted_org(
        self,
        org: federation_pb2.TrustedOrganization,
    ) -> federation_pb2.FederationAck:
        """Add a trusted organization to the federation."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.AddTrustedOrg(
            federation_pb2.AddTrustedOrgRequest(org=org),
        )

    async def remove_trusted_org(
        self,
        org_did: str,
    ) -> federation_pb2.RemoveOrgResponse:
        """Remove a trusted organization."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.RemoveTrustedOrg(
            federation_pb2.RemoveTrustedOrgRequest(org_did=org_did),
        )

    async def create_agreement(
        self,
        agreement: federation_pb2.FederationAgreement,
    ) -> federation_pb2.FederationAck:
        """Create a federation agreement."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.CreateAgreement(
            federation_pb2.CreateAgreementRequest(agreement=agreement),
        )

    async def register_remote_agent(
        self,
        agent: federation_pb2.RemoteAgent,
    ) -> federation_pb2.FederationAck:
        """Register a remote agent in the federation."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.RegisterRemoteAgent(
            federation_pb2.RegisterRemoteAgentRequest(agent=agent),
        )

    async def verify_agent(
        self,
        agent_did: str,
        org_did: str,
    ) -> federation_pb2.VerifyAgentResponse:
        """Verify an agent's federation status."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.VerifyAgent(
            federation_pb2.VerifyAgentRequest(agent_did=agent_did, org_did=org_did),
        )

    async def find_agents_by_capability(
        self,
        capability: str,
    ) -> federation_pb2.FindAgentsResponse:
        """Find agents by capability across the federation."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.FindAgentsByCapability(
            federation_pb2.FindAgentsRequest(capability=capability),
        )

    async def list_trusted_orgs(self) -> federation_pb2.ListOrgsResponse:
        """List all trusted organizations."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.ListTrustedOrgs(
            federation_pb2.ListOrgsRequest(),
        )

    async def list_agreements(self) -> federation_pb2.ListAgreementsResponse:
        """List all federation agreements."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.ListAgreements(
            federation_pb2.ListAgreementsRequest(),
        )

    async def get_federation_stats(self) -> federation_pb2.FederationStats:
        """Get federation statistics."""
        self._ensure_channel()
        assert self._federation_stub is not None
        return await self._federation_stub.GetStats(
            federation_pb2.GetStatsRequest(),
        )

    # -----------------------------------------------------------------
    # Governance
    # -----------------------------------------------------------------

    async def create_draft(
        self,
        policy_id: str,
        content: str,
        description: str,
        author: str,
    ) -> governance_pb2.CreateDraftResponse:
        """Create a draft policy version."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.CreateDraft(
            governance_pb2.CreateDraftRequest(
                policy_id=policy_id,
                content=content,
                description=description,
                author=author,
            ),
        )

    async def submit_for_approval(
        self,
        policy_id: str,
        version: int,
    ) -> governance_pb2.GovernanceAck:
        """Submit a policy version for approval."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.SubmitForApproval(
            governance_pb2.SubmitForApprovalRequest(
                policy_id=policy_id,
                version=version,
            ),
        )

    async def approve_policy(
        self,
        policy_id: str,
        version: int,
    ) -> governance_pb2.GovernanceAck:
        """Approve a policy version."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.Approve(
            governance_pb2.ApproveRequest(
                policy_id=policy_id,
                version=version,
            ),
        )

    async def rollback_policy(
        self,
        policy_id: str,
        target_version: int,
    ) -> governance_pb2.GovernanceAck:
        """Rollback a policy to a previous version."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.Rollback(
            governance_pb2.RollbackRequest(
                policy_id=policy_id,
                target_version=target_version,
            ),
        )

    async def get_active_policy(
        self,
        policy_id: str,
    ) -> governance_pb2.PolicyVersion:
        """Get the active version of a policy."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.GetActive(
            governance_pb2.GetActivePolicyRequest(policy_id=policy_id),
        )

    async def get_policy_history(
        self,
        policy_id: str,
    ) -> governance_pb2.PolicyVersionList:
        """Get the version history of a policy."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.GetHistory(
            governance_pb2.GetPolicyHistoryRequest(policy_id=policy_id),
        )

    async def get_governance_report(self) -> governance_pb2.GovernanceReport:
        """Get a summary governance report."""
        self._ensure_channel()
        assert self._governance_stub is not None
        return await self._governance_stub.GetReport(
            governance_pb2.GovernanceReportRequest(),
        )

    # -----------------------------------------------------------------
    # Guardrails
    # -----------------------------------------------------------------

    async def configure_guardrails(
        self,
        config: guardrails_pb2.OutputGuardrailsConfig,
    ) -> guardrails_pb2.GuardrailsAck:
        """Push output guardrails configuration."""
        self._ensure_channel()
        assert self._guardrails_stub is not None
        return await self._guardrails_stub.Configure(config)

    async def scan_text(
        self,
        text: str,
        action: int = 0,
    ) -> guardrails_pb2.GuardrailResult:
        """Scan text for PII and apply the given action."""
        self._ensure_channel()
        assert self._guardrails_stub is not None
        return await self._guardrails_stub.ScanText(
            guardrails_pb2.ScanRequest(text=text, action=action),
        )

    # -----------------------------------------------------------------
    # Memory
    # -----------------------------------------------------------------

    async def write_memory(
        self,
        agent_id: str,
        content: str,
        metadata: dict[str, str] | None = None,
    ) -> memory_pb2.WriteMemoryResponse:
        """Write a memory entry for an agent."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.WriteMemory(
            memory_pb2.WriteMemoryRequest(
                agent_id=agent_id,
                content=content,
                metadata=metadata or {},
            ),
        )

    async def read_memory(
        self,
        agent_id: str,
    ) -> memory_pb2.ReadMemoryResponse:
        """Read hot-tier memory entries for an agent."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.ReadMemory(
            memory_pb2.ReadMemoryRequest(agent_id=agent_id),
        )

    async def search_memory(
        self,
        agent_id: str,
        query_embedding: list[float],
        threshold: float = 0.7,
        max_results: int = 10,
    ) -> memory_pb2.SearchMemoryResponse:
        """Search agent memory by embedding similarity."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.SearchMemory(
            memory_pb2.SearchMemoryRequest(
                agent_id=agent_id,
                query_embedding=query_embedding,
                threshold=threshold,
                max_results=max_results,
            ),
        )

    async def cross_agent_search(
        self,
        requesting_agent_id: str,
        target_agent_id: str,
        query_embedding: list[float],
        threshold: float = 0.7,
        max_results: int = 10,
    ) -> memory_pb2.SearchMemoryResponse:
        """Search another agent's memory (subject to sharing rules)."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.CrossAgentSearch(
            memory_pb2.CrossAgentSearchRequest(
                requesting_agent_id=requesting_agent_id,
                target_agent_id=target_agent_id,
                query_embedding=query_embedding,
                threshold=threshold,
                max_results=max_results,
            ),
        )

    async def set_sharing_rule(
        self,
        agent_id: str,
        rule: int = 0,
    ) -> memory_pb2.SetSharingRuleResponse:
        """Set memory sharing rule for an agent."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.SetSharingRule(
            memory_pb2.SetSharingRuleRequest(agent_id=agent_id, rule=rule),
        )

    async def get_memory_stats(
        self,
        agent_id: str,
    ) -> memory_pb2.MemoryStatsResponse:
        """Get memory statistics for an agent."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.GetMemoryStats(
            memory_pb2.MemoryStatsRequest(agent_id=agent_id),
        )

    async def get_gateway_stats(self) -> memory_pb2.GatewayStatsResponse:
        """Get global memory gateway statistics."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.GetGatewayStats(
            memory_pb2.GatewayStatsRequest(),
        )

    async def triage_memory(
        self,
        agent_id: str,
    ) -> memory_pb2.TriageResponse:
        """Triage memory tiers for an agent."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.Triage(
            memory_pb2.TriageRequest(agent_id=agent_id),
        )

    async def delete_agent_memory(
        self,
        agent_id: str,
    ) -> memory_pb2.DeleteAgentMemoryResponse:
        """Delete all memory for an agent."""
        self._ensure_channel()
        assert self._memory_stub is not None
        return await self._memory_stub.DeleteAgentMemory(
            memory_pb2.DeleteAgentMemoryRequest(agent_id=agent_id),
        )

    # -----------------------------------------------------------------
    # Zero Trust
    # -----------------------------------------------------------------

    async def configure_zero_trust(
        self,
        config: zero_trust_pb2.ZeroTrustConfig,
    ) -> zero_trust_pb2.ZeroTrustAck:
        """Push zero-trust configuration."""
        self._ensure_channel()
        assert self._zero_trust_stub is not None
        return await self._zero_trust_stub.Configure(config)

    async def evaluate_zero_trust(
        self,
        agent_id: str,
        rps: float = 0.0,
        tokens: int = 0,
        tool_name: str = "",
        hour: int = 0,
    ) -> zero_trust_pb2.ZeroTrustAction:
        """Evaluate an observation against zero-trust behavioral baselines."""
        self._ensure_channel()
        assert self._zero_trust_stub is not None
        return await self._zero_trust_stub.Evaluate(
            zero_trust_pb2.EvaluateRequest(
                agent_id=agent_id,
                rps=rps,
                tokens=tokens,
                tool_name=tool_name,
                hour=hour,
            ),
        )

    async def get_baseline(
        self,
        agent_id: str,
    ) -> zero_trust_pb2.AgentBaseline:
        """Get the behavioral baseline for an agent."""
        self._ensure_channel()
        assert self._zero_trust_stub is not None
        return await self._zero_trust_stub.GetBaseline(
            zero_trust_pb2.GetBaselineRequest(agent_id=agent_id),
        )

    async def get_zero_trust_stats(self) -> zero_trust_pb2.ZeroTrustStats:
        """Get zero-trust engine statistics."""
        self._ensure_channel()
        assert self._zero_trust_stub is not None
        return await self._zero_trust_stub.GetStats(
            zero_trust_pb2.ZeroTrustStatsRequest(),
        )

    # -----------------------------------------------------------------
    # Inference Routing
    # -----------------------------------------------------------------

    async def configure_inference_routing(
        self,
        config: inference_routing_pb2.InferenceRoutingConfig,
    ) -> inference_routing_pb2.InferenceRoutingAck:
        """Push inference routing configuration."""
        self._ensure_channel()
        assert self._inference_routing_stub is not None
        return await self._inference_routing_stub.Configure(config)

    async def set_backend_health(
        self,
        backend_id: str,
        healthy: bool = True,
    ) -> inference_routing_pb2.InferenceRoutingAck:
        """Set health status for an inference backend."""
        self._ensure_channel()
        assert self._inference_routing_stub is not None
        return await self._inference_routing_stub.SetBackendHealth(
            inference_routing_pb2.BackendHealthRequest(
                backend_id=backend_id,
                healthy=healthy,
            ),
        )

    async def get_backend_metrics(
        self,
    ) -> AsyncIterator[inference_routing_pb2.InferenceBackendMetrics]:
        """Stream backend metrics from the inference router."""
        self._ensure_channel()
        assert self._inference_routing_stub is not None
        stream = self._inference_routing_stub.GetBackendMetrics(
            inference_routing_pb2.BackendMetricsRequest(),
        )
        async for snap in stream:
            yield snap

    # -----------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------

    async def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._control_stub = None
            self._keypool_stub = None
            self._metrics_stub = None
            self._policy_stub = None
            self._context_stub = None
            self._identity_stub = None
            self._broker_stub = None
            self._orchestration_stub = None
            self._compliance_stub = None
            self._budgets_stub = None
            self._sla_stub = None
            self._hitl_stub = None
            self._federation_stub = None
            self._governance_stub = None
            self._guardrails_stub = None
            self._memory_stub = None
            self._zero_trust_stub = None
            self._inference_routing_stub = None
