"""
CLI 入口

子命令模式：
  roborock-mcp          → 默认启动 stdio server
  roborock-mcp auth     → 运行交互式认证
  roborock-mcp --help   → 显示帮助
"""

import argparse
import sys

from . import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="roborock-mcp",
        description="Roborock MCP Server — 让 Claude 控制石头扫地机",
        epilog="不带子命令时默认启动 MCP server（stdio 模式）",
    )
    parser.add_argument("--version", "-V", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("auth", help="首次认证（交互式邮箱验证码）")

    args = parser.parse_args()

    if args.command == "auth":
        from .setup_auth import main as auth_main
        auth_main()
    elif args.command is None:
        # 默认行为：启动 server
        import anyio
        from .server import mcp

        # Windows 的 ProactorEventLoop 不支持 add_reader/add_writer，
        # 而 aiomqtt (paho-mqtt) 依赖这些方法。
        # mcp.run() 内部调用 anyio.run() 但不传 loop_factory，
        # 所以直接调用 anyio.run() 显式指定 SelectorEventLoop。
        # MCP stdio transport 用 anyio.wrap_file()（线程模式），不受影响。
        if sys.platform == "win32":
            import asyncio
            backend_options = {"loop_factory": asyncio.SelectorEventLoop}
        else:
            backend_options = {}

        anyio.run(mcp.run_stdio_async, backend_options=backend_options)
    else:
        # 防御性编程：argparse 通常会拦截未知子命令
        parser.error(f"未知子命令: {args.command}")


if __name__ == "__main__":
    main()
