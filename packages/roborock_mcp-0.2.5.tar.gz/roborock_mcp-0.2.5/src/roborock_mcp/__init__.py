"""roborock-mcp - MCP 服务器，让 Claude 控制石头扫地机"""

__version__ = "0.2.5"
