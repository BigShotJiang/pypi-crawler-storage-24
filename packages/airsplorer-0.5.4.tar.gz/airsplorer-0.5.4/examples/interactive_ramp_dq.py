"""
Using a _ramp .fits, explore the datacube, click on a pixel to see its integration and correspondant group flags.
Select group and integration to see the corresponding image.
"""

import matplotlib.pyplot as plt
from astropy.io import fits

import airsplorer

filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2025_05_RADIO_LIRA\Ref15_Flux_Monochromateur\260218_180840_15254_iFPA_BBM_H1RG_ramp.fits"

with fits.open(filename) as hdulist:
    datacube = hdulist["SCI"].data

    if "GROUPDQ" in hdulist:
        groupdq = hdulist['GROUPDQ'].data
    else:
        groupdq = None

# interactive_ramp = airsplorer.plot.InteractiveRampDQ(datacube, groupdq)
interactive_ramp = airsplorer.plot.InteractiveRampDQ(datacube, dqcube=groupdq, ypos=59, xpos=32, intpos=1)

plt.show()
