"""
Using a _ramp .fits, explore the datacube, click on a pixel to see its integration and correspondant group flags.
Select group and integration to see the corresponding image.
"""

import matplotlib.pyplot as plt

import airsplorer

filename = r"C:\Users\ccossou\LocalStorage\data\ariel\AVM_functional_test_2026_02\260216_164943_61004.0_iFPA_BBM_H1RG"

interactive_ramp = airsplorer.ql.interactive_super_raw(filename, ypos=100, xpos=15)

plt.show()
