import numpy as np

from airsplorer import lib


def test_radial_profile():
    """
    Test radial_profile
    """
    size = 25
    center = size // 2

    x_line = np.arange(size) - center
    y_line = np.arange(size) - center

    xv, yv = np.meshgrid(x_line, y_line)

    # Radial profile is simply 'R'
    image = np.sqrt(xv**2 + yv**2)

    # Test default function
    r, profile = lib.radial_profile(image, center=(center, center), bin_width=1)

    np.testing.assert_almost_equal(r, profile)

    # Test custom function
    constant = 2
    tmp_func = lambda x: constant
    r, profile = lib.radial_profile(image, center=(center, center), func=tmp_func)
    np.testing.assert_almost_equal(profile, [constant] * len(profile))

    # Test mask
    mask = np.full_like(image, False, dtype=bool)
    mask[10:12, :] = True
    image[10:12, :] = 0

    image = np.ma.MaskedArray(image, mask=mask, fill_value=np.nan)

    r, profile = lib.radial_profile(image, center=(center, center), bin_width=1)
    np.testing.assert_almost_equal(r, profile)


def test_radial_profile_center():
    """
    Test radial_profile center coordinate (x,y or y,x)

    Non regression test because a bug was found in the function when we realized that the actual centre required was
    (x,y) and not (y,x)
    """
    size = 25
    x_center = 3
    y_center = 10
    center = (y_center, x_center)

    # Radial profile is simply 'R'
    image = np.zeros((size, size))
    # non zero value only for r=1
    image[y_center+1, x_center] = 1
    image[y_center, x_center+1] = 1
    image[y_center-1, x_center] = 1
    image[y_center, x_center-1] = 1

    # Test default function
    r, profile = lib.radial_profile(image, center=center, bin_width=1)

    # If we have the correct center, profile value at r~1 (i.e second value with bin_width=1) must be non-zero due
    # to the 4 pixels set to 1 earlier
    assert profile[1] != 0., 'The center given as input in radial_profile is not the one used by the function'


def test_radial_profile_rmax():
    """
    Test radial_profile rmax if set

    Non regression test because a bug was found in the function. When rmax was set, the indices where not applied
    to the correct array (x instead of x[mask])
    """
    rmax = 5
    size = 25
    center = size // 2

    x_line = np.arange(size) - center
    y_line = np.arange(size) - center

    xv, yv = np.meshgrid(x_line, y_line)

    # Radial profile is simply 'R'
    image = np.sqrt(xv ** 2 + yv ** 2)

    # Test default function
    full_r, full_profile = lib.radial_profile(image, center=(center, center))
    r, profile = lib.radial_profile(image, center=(center, center), rmax=rmax)

    # We don't compare last bin since the truncation can impact part of its values
    n_points = len(r) - 1

    np.testing.assert_almost_equal(r[:n_points], full_r[:n_points],
                                   err_msg="Rmax parameter doesn't truncate radius array correctly")
    np.testing.assert_almost_equal(profile[:n_points], full_profile[:n_points],
                                   err_msg="Rmax parameter doesn't truncate profile array correctly")


def test_radial_profiles():
    """
    Test radial_profiles
    """
    ref_keys = set(["r", "mean", "std", "median", "variance", "max", "sum", "size"])
    x_size = 25
    y_size = 30
    x_center = x_size // 2
    y_center = y_size // 2

    x_line = np.arange(x_size) - x_center
    y_line = np.arange(y_size) - y_center

    xv, yv = np.meshgrid(x_line, y_line)

    # Radial profile is simply 'R'
    image = np.sqrt(xv**2 + yv**2)

    # Test default function
    radial_profile = lib.radial_profiles(image, center=(y_center, x_center))

    assert set(radial_profile.keys()) == ref_keys, f"Output of radial_profiles don't have expected set of keys"

    np.testing.assert_almost_equal(radial_profile["r"], radial_profile["mean"])
