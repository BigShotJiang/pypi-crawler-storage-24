"""
Functions to parse, compare and analyze FITS files
"""

import logging

import tabulate
from astropy.io import fits

LOG = logging.getLogger(__name__)



def compare_headers(filenames, exclude_keywords=None):
    """
    Take a list of FITS filenames and return an analysis of the first headers.

    Part I: Common values
    Display the key / values that are identical for all the files

    Part II: Values that differ
    Display as a nice table the list of keys and the corresponding values for each files

    :param list(str) filenames:
    :param list(str) exclude_keywords: [Optional] List of keywords to hide in Part II (nothing is hidden in part I).
                                       By default, this is the list of keywords hidden:
                                       ['BENDTIME', 'BMIDTIME', 'BSTRTIME', 'DATE', 'DATE-BEG', 'DATE-END', 'EPH_TIME',
                                       'EXPEND', 'EXPMID', 'EXPSTART', 'FILENAME', 'HENDTIME', 'HMIDTIME', 'HSTRTIME',
                                       'OSF_FILE', 'TIME-OBS']
    :return:
    """

    string_report = ""

    if exclude_keywords is None:
        exclude_keywords = ['BENDTIME', 'BMIDTIME', 'BSTRTIME', 'DATE', 'DATE-OBS', 'DATE-BEG', 'DATE-END', 'EPH_TIME',
                            'EXPEND', 'EXPMID', 'EXPSTART', 'FILENAME', 'HENDTIME', 'HMIDTIME', 'HSTRTIME', 'OSF_FILE',
                            'TIME-OBS']

    headers = []

    all_keys = []  # Prepare the list of all keys for all fits files (need to use set() before using this variable after the loop)
    for file in filenames:
        hdulist = fits.open(file)
        header = hdulist[0].header

        all_keys.extend(header.keys())

        headers.append(header)
        hdulist.close()
    all_keys = set(all_keys)

    # Find the list of keys whose values don't change from one file to the other
    header_sets = [set(d.items()) for d in headers]

    common_set = header_sets[0] & header_sets[1]
    for s in header_sets[2:]:
        common_set = common_set & s

    common_keys = list(set([k for k, v in common_set]))
    common_keys.sort()

    # Delete empty string that correspond to section title in FITS header
    try:
        common_keys.remove("")
    except ValueError:
        pass

    changing_keys = list(all_keys - set(common_keys) - set(exclude_keywords))
    changing_keys.sort()

    # Delete empty string that correspond to section title in FITS header
    try:
        changing_keys.remove("")
    except ValueError:
        pass

    string_report += "Common values:\n"
    header = headers[0]  # Just choose one, values are all the same anyway
    for k in common_keys:

        string_report += f"\t{k}: {header[k]}\n"

    string_report += "\nUnique values:\n"

    values = []
    for file, header in zip(filenames, headers):
        tmp = [file]
        for k in changing_keys:
            try:
                value = header[k]
            except KeyError:
                # N/A if key don't exist
                value = "N/A"

            tmp.append(value)
        values.append(tmp)


    columns = ["Filename"]
    columns.extend(changing_keys)


    string_report += tabulate.tabulate(values, headers=columns)

    return string_report


def inspect_datamodel_schema(model):
    """
    The input objet must be a datamodel, e.g. miri.datamodels.miri_psf_models.MiriImagingPointSpreadFunctionModel()

    :param jwst.datamodels.JwstDataModel model: object datamodel for any of the MIRI datamodels
    :return: str
    """

    table = __recursive_inspect(model.schema)

    # sort all lines (except the first one)
    new_table = table[1:]
    new_table.sort()

    new_table.insert(0, table[0])

    string_report = tabulate.tabulate(table, headers="firstrow")

    return string_report


def __recursive_inspect(schema, key=""):
    columns = ["fits_keyword", "type", "title"]
    table = []

    # Add the header if it's the main call
    if not key:
        tmp = ["Keyword"]
        tmp.extend(columns)
        table.append(tmp)

    if "fits_keyword" in schema:
        tmp = [key.replace("properties.", "")]

        for k in columns:
            tmp.append(schema[k])

        table.append(tmp)
    else:
        for (k, v) in schema.items():
            if not isinstance(v, dict):
                continue

            if not key:
                new_key = k
            else:
                new_key = f"{key}.{k}"

            table.extend(__recursive_inspect(v, key=new_key))

    return table
