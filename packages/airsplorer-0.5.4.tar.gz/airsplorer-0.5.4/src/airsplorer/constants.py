import logging

LOG = logging.getLogger(__name__)

# wref in microns and zeropoint in Jy
band_info = {
    "2MASS J": {'wref': 1.235, 'zeropoint': 1594},
    "2MASS H": {'wref': 1.662, 'zeropoint': 1024},
    "2MASS Ks": {'wref': 2.159, 'zeropoint': 666.7},
    "Johnson U": {'wref': 0.36, 'zeropoint': 1823},
    "Johnson B": {'wref': 0.44, 'zeropoint': 4130},
    "Johnson V": {'wref': 0.55, 'zeropoint': 3781},
    "Johnson R": {'wref': 0.71, 'zeropoint': 2941},
    "Johnson I": {'wref': 0.97, 'zeropoint': 2635},
    "Johnson J": {'wref': 1.25, 'zeropoint': 1603},
    "Johnson H": {'wref': 1.60, 'zeropoint': 1075},
    "Johnson K": {'wref': 2.22, 'zeropoint': 667},
    "Johnson L": {'wref': 3.54, 'zeropoint': 288},
    "Johnson M": {'wref': 4.80, 'zeropoint': 170},
    "Johnson N": {'wref': 10.6, 'zeropoint': 36},
    "Johnson O": {'wref': 21.0, 'zeropoint': 9.4},
    "UKIRT V": {'wref': 0.5556, 'zeropoint': 3540},
    "UKIRT I": {'wref': 0.9, 'zeropoint': 2250},
    "UKIRT J": {'wref': 1.25, 'zeropoint': 1600},
    "UKIRT H": {'wref': 1.65, 'zeropoint': 1020},
    "UKIRT K": {'wref': 2.20, 'zeropoint': 657},
    "UKIRT L": {'wref': 3.45, 'zeropoint': 290},
    "UKIRT L'": {'wref': 3.80, 'zeropoint': 252},
    "UKIRT M": {'wref': 4.8, 'zeropoint': 163},
    "UKIRT N": {'wref': 10.1, 'zeropoint': 39.8},
    "UKIRT Q": {'wref': 20.0, 'zeropoint': 10.4},
    "MIRLIN N": {'wref': 10.79, 'zeropoint': 33.4},
    "MIRLIN Q-s": {'wref': 17.90, 'zeropoint': 12.4},
    "MIRLIN N0": {'wref': 7.91, 'zeropoint': 60.9},
    "MIRLIN N1": {'wref': 8.81, 'zeropoint': 49.4},
    "MIRLIN N2": {'wref': 9.69, 'zeropoint': 41.1},
    "MIRLIN N3": {'wref': 10.27, 'zeropoint': 36.7},
    "MIRLIN N4": {'wref': 11.70, 'zeropoint': 28.5},
    "MIRLIN N5": {'wref': 12.49, 'zeropoint': 25.1},
    "MIRLIN Q0": {'wref': 17.20, 'zeropoint': 13.4},
    "MIRLIN Q1": {'wref': 17.93, 'zeropoint': 12.3},
    "MIRLIN Q2": {'wref': 18.64, 'zeropoint': 11.4},
    "MIRLIN Q3": {'wref': 20.81, 'zeropoint': 9.2},
    "MIRLIN Q4": {'wref': 22.81, 'zeropoint': 7.7},
    "MIRLIN Q5": {'wref': 24.48, 'zeropoint': 6.7},
    "MIRLIN K": {'wref': 2.2, 'zeropoint': 650.0},
    "MIRLIN M": {'wref': 4.68, 'zeropoint': 165.0},
    "WISE W1": {'wref': 3.4, 'zeropoint':309.54},
    "WISE W2": {'wref': 4.6, 'zeropoint':171.787},
    "WISE W3": {'wref': 12., 'zeropoint':31.674},
    "WISE W4": {'wref': 22., 'zeropoint':8.363},
}

# pixel_flags and pixel_flags_description copied from airspipe 0.21.0
pixel_flags = {'GOOD':             0,      # No bits set, all is good
         'DO_NOT_USE':       2**0,   # Bad pixel. Do not use.
         'SATURATED':        2**1,   # Pixel saturated during exposure
         'JUMP_DET':         2**2,   # Jump detected during exposure
         'DROPOUT':          2**3,   # Data lost in transmission
         'OUTLIER':          2**4,   # Flagged by outlier detection (was RESERVED_1)
         'PERSISTENCE':      2**5,   # High persistence (was RESERVED_2)
         'AD_FLOOR':         2**6,   # Below A/D floor (0 DN, was RESERVED_3)
         'CHARGELOSS':       2**7,   # Charge Migration
         'UNRELIABLE_ERROR': 2**8,   # Uncertainty exceeds quoted error
         'NON_SCIENCE':      2**9,   # Pixel not on science portion of detector
         'DEAD':             2**10,  # Dead pixel
         'HOT':              2**11,  # Hot pixel
         'WARM':             2**12,  # Warm pixel
         'LOW_QE':           2**13,  # Low quantum efficiency
         'RC':               2**14,  # RC pixel
         'TELEGRAPH':        2**15,  # Telegraph pixel
         'NONLINEAR':        2**16,  # Pixel highly nonlinear
         'BAD_REF_PIXEL':    2**17,  # Reference pixel cannot be used
         'NO_FLAT_FIELD':    2**18,  # Flat field cannot be measured
         'NO_GAIN_VALUE':    2**19,  # Gain cannot be measured
         'NO_LIN_CORR':      2**20,  # Linearity correction not available
         'NO_SAT_CHECK':     2**21,  # Saturation check not available
         'UNRELIABLE_BIAS':  2**22,  # Bias variance large
         'UNRELIABLE_DARK':  2**23,  # Dark variance large
         'UNRELIABLE_SLOPE': 2**24,  # Slope variance large (i.e., noisy pixel)
         'UNRELIABLE_FLAT':  2**25,  # Flat variance large
         'OPEN':             2**26,  # Open pixel (counts move to adjacent pixels)
         'ADJ_OPEN':         2**27,  # Adjacent to open pixel
         'UNRELIABLE_RESET': 2**28,  # Sensitive to reset anomaly
         'MSA_FAILED_OPEN':  2**29,  # Pixel sees light from failed-open shutter
         'OTHER_BAD_PIXEL':  2**30,  # A catch-all flag
         'REFERENCE_PIXEL':  2**31,  # Pixel is a reference pixel
         }

pixel_flags_description = {
'GOOD':             "No bits set, all is good",
'DO_NOT_USE':       "Bad pixel. Do not use.",
'SATURATED':        "Pixel saturated during exposure",
'JUMP_DET':         "Jump detected during exposure",
'DROPOUT':          "Data lost in transmission",
'OUTLIER':          "Flagged by outlier detection (was RESERVED_1)",
'PERSISTENCE':      "High persistence (was RESERVED_2)",
'AD_FLOOR':         "Below A/D floor (0 DN, was RESERVED_3)",
'CHARGELOSS':          "Charge Migration",
'UNRELIABLE_ERROR': "Uncertainty exceeds quoted error",
'NON_SCIENCE':      "Pixel not on science portion of detector",
'DEAD':             "Dead pixel",
'HOT':              "Hot pixel",
'WARM':             "Warm pixel",
'LOW_QE':           "Low quantum efficiency",
'RC':               "RC pixel",
'TELEGRAPH':        "Telegraph pixel",
'NONLINEAR':        "Pixel highly nonlinear",
'BAD_REF_PIXEL':    "Reference pixel cannot be used",
'NO_FLAT_FIELD':    "Flat field cannot be measured",
'NO_GAIN_VALUE':    "Gain cannot be measured",
'NO_LIN_CORR':      "Linearity correction not available",
'NO_SAT_CHECK':     "Saturation check not available",
'UNRELIABLE_BIAS':  "Bias variance large",
'UNRELIABLE_DARK':  "Dark variance large",
'UNRELIABLE_SLOPE': "Slope variance large (i.e., noisy pixel)",
'UNRELIABLE_FLAT':  "Flat variance large",
'OPEN':             "Open pixel (counts move to adjacent pixels)",
'ADJ_OPEN':         "Adjacent to open pixel",
'UNRELIABLE_RESET': "Sensitive to reset anomaly",
'MSA_FAILED_OPEN':  "Pixel sees light from failed-open shutter",
'OTHER_BAD_PIXEL':  "A catch-all flag",
'REFERENCE_PIXEL':  "Pixel is a reference pixel",
}

# Autogenerate the description from the flag dictionary (so any update just need to copy paste the 2 previous dict from airspipe
# DQ flags for the pipeline: key=flag; value=description. flag is 2*i where i is the bit_flag.
status_pipeline = {pixel_flags[k]:pixel_flags_description[k] for k in pixel_flags.keys()}

# Force include all flags from DQ_INIT expect bad pixels and reference pixels
include_all = [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288,
               1048576, 2097152, 4194304, 8388608, 16777216, 33554432, 67108864, 134217728, 268435456, 536870912,
               1073741824]
