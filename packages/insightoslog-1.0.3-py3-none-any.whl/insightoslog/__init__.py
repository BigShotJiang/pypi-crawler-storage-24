#!/usr/bin/env python3
"""
@file __init__.py
@brief InsightOS Logging SDK - Python 公共入口

使用方式:
    import insightoslog as ios

    ios.init({"service_name": "my-service"})
    ios.info("Hello World")

    # 或使用类封装
    from insightoslog import Logger, Trace
    Logger.init({"service_name": "my-service"})
    Logger.info("Hello World")
"""

# 从 wrapper 模块导入所有公共接口
from .wrapper import (
    # 日志函数
    trace, debug, info, warn, error, fatal,
    tracef, debugf, infof, warnf, errorf, fatalf,
    # Python 风格别名
    trace_f, debug_f, info_f, warn_f, error_f, fatal_f,
    # 初始化函数
    init, init_from_config,
    # Trace 函数
    generate_trace_id, generate_span_id,
    current_context, make_context,
    global_resource, refresh_pid, set_global_resource,
    # 类型
    LogLevel,
    LogContext,
    InsightOSLogContext,
    Trace,
    Logger,
    Context,
    Resource,
    Caller,
    Meta,
    Data,
    EventRequest,
    LogError,
    InitParam,
    LogBuilder,
    ContextWithLog,
    # HTTP Header 常量
    HEADER_TRACE_ID,
    HEADER_SPAN_ID,
    HEADER_PARENT_SPAN_ID,
    # 工具函数
    mask_sensitive,
)

__all__ = [
    # 日志函数
    "trace", "debug", "info", "warn", "error", "fatal",
    "tracef", "debugf", "infof", "warnf", "errorf", "fatalf",
    "trace_f", "debug_f", "info_f", "warn_f", "error_f", "fatal_f",
    # 初始化
    "init", "init_from_config",
    # Trace
    "generate_trace_id", "generate_span_id",
    "current_context", "make_context",
    "global_resource", "refresh_pid", "set_global_resource",
    # 类型
    "LogLevel", "LogContext", "InsightOSLogContext", "Trace", "Logger",
    "Context", "Resource", "Caller", "Meta", "Data",
    "EventRequest", "LogError", "InitParam",
    "LogBuilder", "ContextWithLog",
    # 常量
    "HEADER_TRACE_ID", "HEADER_SPAN_ID", "HEADER_PARENT_SPAN_ID",
    # 工具
    "mask_sensitive",
]

__version__ = "1.0.0"
