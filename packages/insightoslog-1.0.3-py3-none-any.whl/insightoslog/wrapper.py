#!/usr/bin/env python3
"""
@file __init__.py
@brief InsightOS Logging SDK - Python 统一入口

使用方式:
    import insightoslog as ios
    
    ios.init({"service_name": "my-service"})
    ios.info("Hello World")
    
    # 或使用类封装
    from insightoslog import Logger, Trace
    Logger.init({"service_name": "my-service"})
    Logger.info("Hello World")
"""

import sys
from . import _impl

# 挂载常用函数到模块级别，实现 import insightoslog as ios
trace = _impl.trace
debug = _impl.debug
info = _impl.info
warn = _impl.warn
error = _impl.error
fatal = _impl.fatal
tracef = _impl.tracef
debugf = _impl.debugf
infof = _impl.infof
warnf = _impl.warnf
errorf = _impl.errorf
fatalf = _impl.fatalf
# Python 风格别名 (带下划线)
trace_f = _impl.tracef
debug_f = _impl.debugf
info_f = _impl.infof
warn_f = _impl.warnf
error_f = _impl.errorf
fatal_f = _impl.fatalf
init = _impl.init
init_from_config = _impl.init_from_config
generate_trace_id = _impl.generate_trace_id
generate_span_id = _impl.generate_span_id
current_context = _impl.current_context
make_context = _impl.make_context
global_resource = _impl.global_resource
refresh_pid = _impl.refresh_pid
set_global_resource = _impl.set_global_resource
LogLevel = _impl.LogLevel
InsightOSLogContext = _impl.InsightOSLogContext
LogContext = _impl.InsightOSLogContext  # 别名
Trace = _impl.Trace
Logger = _impl.Logger
Context = _impl.Context
Resource = _impl.Resource
Caller = _impl.Caller
Meta = _impl.Meta
Data = _impl.Data
EventRequest = _impl.EventRequest
LogError = _impl.LogError
InitParam = _impl.InitParam
LogBuilder = _impl.LogBuilder
ContextWithLog = _impl.ContextWithLog
HEADER_TRACE_ID = _impl.HEADER_TRACE_ID
HEADER_SPAN_ID = _impl.HEADER_SPAN_ID
HEADER_PARENT_SPAN_ID = _impl.HEADER_PARENT_SPAN_ID
mask_sensitive = _impl.mask_sensitive

# 挂载到当前模块
sys.modules[__name__].trace = trace
sys.modules[__name__].debug = debug
sys.modules[__name__].info = info
sys.modules[__name__].warn = warn
sys.modules[__name__].error = error
sys.modules[__name__].fatal = fatal
sys.modules[__name__].tracef = tracef
sys.modules[__name__].debugf = debugf
sys.modules[__name__].infof = infof
sys.modules[__name__].warnf = warnf
sys.modules[__name__].errorf = errorf
sys.modules[__name__].fatalf = fatalf
sys.modules[__name__].trace_f = trace_f
sys.modules[__name__].debug_f = debug_f
sys.modules[__name__].info_f = info_f
sys.modules[__name__].warn_f = warn_f
sys.modules[__name__].error_f = error_f
sys.modules[__name__].fatal_f = fatal_f
sys.modules[__name__].init = init
sys.modules[__name__].init_from_config = init_from_config
sys.modules[__name__].generate_trace_id = generate_trace_id
sys.modules[__name__].generate_span_id = generate_span_id
sys.modules[__name__].current_context = current_context
sys.modules[__name__].make_context = make_context
sys.modules[__name__].global_resource = global_resource
sys.modules[__name__].refresh_pid = refresh_pid
sys.modules[__name__].set_global_resource = set_global_resource
sys.modules[__name__].LogLevel = LogLevel
sys.modules[__name__].InsightOSLogContext = InsightOSLogContext
sys.modules[__name__].LogContext = LogContext
sys.modules[__name__].Trace = Trace
sys.modules[__name__].Logger = Logger
sys.modules[__name__].Context = Context
sys.modules[__name__].Resource = Resource
sys.modules[__name__].Caller = Caller
sys.modules[__name__].Meta = Meta
sys.modules[__name__].Data = Data
sys.modules[__name__].EventRequest = EventRequest
sys.modules[__name__].LogError = LogError
sys.modules[__name__].InitParam = InitParam
sys.modules[__name__].LogBuilder = LogBuilder
sys.modules[__name__].ContextWithLog = ContextWithLog
sys.modules[__name__].HEADER_TRACE_ID = HEADER_TRACE_ID
sys.modules[__name__].HEADER_SPAN_ID = HEADER_SPAN_ID
sys.modules[__name__].HEADER_PARENT_SPAN_ID = HEADER_PARENT_SPAN_ID
sys.modules[__name__].mask_sensitive = mask_sensitive
