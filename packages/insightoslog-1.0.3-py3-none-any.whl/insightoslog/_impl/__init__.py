#!/usr/bin/env python3
"""
@file __init__.py
@brief InsightOS Logging SDK - Python 统一入口

使用方式:
    from insightoslog import init, info, LogLevel
    
    init({
        "service_name": "my-service",
        "level": LogLevel.INFO
    })
    
    info("Hello World")

或者使用子模块导入:
    from insightoslog.logging import init, info, LogLevel
"""

import json
import logging
import logging.handlers
import queue
import os
import socket
import threading
import traceback as tb_module
import re
from typing import Optional, Any, Dict, List

# ==================== 级别 ====================

class LogLevel:
    """日志级别"""
    TRACE = 0
    DEBUG = 1
    INFO = 2
    WARN = 3
    ERROR = 4
    FATAL = 5

    _LEVELS = {
        TRACE: "TRACE",
        DEBUG: "DEBUG",
        INFO: "INFO",
        WARN: "WARN",
        ERROR: "ERROR",
        FATAL: "FATAL"
    }

    _COLORS = {
        TRACE: "\033[90m",
        DEBUG: "\033[94m",
        INFO: "\033[92m",
        WARN: "\033[93m",
        ERROR: "\033[91m",
        FATAL: "\033[95m"
    }

    _RESET = "\033[0m"

    @staticmethod
    def to_string(level: int) -> str:
        return LogLevel._LEVELS.get(level, "UNKNOWN")

    @staticmethod
    def to_color(level: int) -> str:
        return LogLevel._COLORS.get(level, "")


# ==================== 消息数据结构 ====================

class Caller:
    """调用者信息"""
    def __init__(self, file: str = "", line: int = 0, function: str = ""):
        self.file = file
        self.line = line
        self.function = function

    def to_dict(self) -> Dict:
        return {"file": self.file, "line": self.line, "function": self.function}


class Context:
    """链路上下文"""
    def __init__(self, trace_id: str = "", span_id: str = "", parent_span_id: str = ""):
        self.trace_id = trace_id
        self.span_id = span_id
        self.parent_span_id = parent_span_id

    def to_dict(self) -> Dict:
        return {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id
        }


class Resource:
    """资源信息"""
    def __init__(self, type: str = "", name: str = "", instance_id: str = "",
                 host: str = "", pid: int = 0):
        self.type = type
        self.name = name
        self.instance_id = instance_id
        self.host = host
        self.pid = pid

    def to_dict(self) -> Dict:
        return {
            "type": self.type,
            "name": self.name,
            "instance_id": self.instance_id,
            "host": self.host,
            "pid": self.pid
        }


class Meta:
    """元数据"""
    @staticmethod
    def now_rfc3339() -> str:
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class Data:
    """数据"""
    def __init__(self, params: Any = None, result: Any = None, truncate: bool = False):
        self.param = params
        self.res = result
        self.truncate = truncate

    def to_dict(self) -> Dict:
        result = {}
        if self.param is not None:
            result["param"] = self.param
        if self.res is not None:
            result["res"] = self.res
        if self.truncate:
            result["truncate"] = self.truncate
        return result


class EventRequest:
    """请求信息"""
    def __init__(self, method: str = "", url: str = "", latency_ms: int = 0):
        self.method = method
        self.url = url
        self.latency_ms = latency_ms

    def to_dict(self) -> Dict:
        return {"method": self.method, "url": self.url, "latency_ms": self.latency_ms}


class LogError:
    """错误信息"""
    def __init__(self, error_msg: str = "", error_stack: str = ""):
        self.msg = error_msg
        self.stack = error_stack

    def to_dict(self) -> Dict:
        return {"msg": self.msg, "stack": self.stack}


# ==================== 初始化配置 ====================

class InitParam:
    """初始化参数 (与 C++/Go 统一)"""
    def __init__(self,
                 # 日志级别
                 level: int = LogLevel.INFO,
                 # 服务信息
                 service_type: str = "service",
                 service_name: str = "insightoslog",
                 instance_id: str = "",
                 # 日志配置
                 output: str = "stdout",
                 log_root: str = "/root/InsightOSLog/logs",
                 # 缓冲区配置
                 buffer_size: int = 4096,
                 flush_interval: float = 2.0,
                 # 文件配置 (支持多种命名)
                 max_size: int = None,
                 max_bytes: int = None,
                 max_files: int = None,
                 backup_count: int = None,
                 # 队列配置 (别名)
                 queue_size: int = 4096,
                 # 追踪配置
                 enable_tracing: bool = True,
                 # stdout 输出时包含的域字段（默认 ["event", "caller"]）
                 stdout_fields: List[str] = None):
        self.level = level
        self.service_type = service_type
        self.service_name = service_name
        self.instance_id = instance_id or f"{socket.gethostname()}-{os.getpid()}"
        self.output = output
        self.log_root = log_root
        self.buffer_size = queue_size  # queue_size 是 buffer_size 的别名
        self.flush_interval = flush_interval
        # 处理 max_size / max_bytes 兼容
        if max_bytes is not None:
            self.max_size = max_bytes
        elif max_size is not None:
            self.max_size = max_size
        else:
            self.max_size = 5*1024*1024
        # 处理 max_files / backup_count 兼容
        if backup_count is not None:
            self.max_files = backup_count
        elif max_files is not None:
            self.max_files = max_files
        else:
            self.max_files = 3
        self.queue_size = queue_size
        self.enable_tracing = enable_tracing
        # stdout 域过滤：event 始终输出，其他域按配置
        self.stdout_fields = stdout_fields if stdout_fields else ["meta", "event"]

    @property
    def max_bytes(self) -> int:
        return self.max_size

    @max_bytes.setter
    def max_bytes(self, value: int):
        self.max_size = value

    @property
    def backup_count(self) -> int:
        return self.max_files

    @backup_count.setter
    def backup_count(self, value: int):
        self.max_files = value

    @property
    def queue_size(self) -> int:
        return self.buffer_size

    @queue_size.setter
    def queue_size(self, value: int):
        self.buffer_size = value


HEADER_TRACE_ID = "X-InsightOSLog-TraceID"
HEADER_SPAN_ID = "X-InsightOSLog-SpanID"
HEADER_PARENT_SPAN_ID = "X-InsightOSLog-ParentSpanID"


# ==================== 上下文管理 ====================

class InsightOSLogContext:
    """线程局部存储的上下文"""
    _context = threading.local()
    _prepared_context = None

    @classmethod
    def set_current_context(cls, ctx: Context) -> None:
        cls._context.ctx = ctx

    @classmethod
    def get_current_context(cls) -> Context:
        return getattr(cls._context, 'ctx', Context())

    @classmethod
    def clear_context(cls) -> None:
        if hasattr(cls._context, 'ctx'):
            del cls._context.ctx

    @classmethod
    def start_new_trace(cls) -> str:
        """开始新的追踪链路"""
        trace_id = generate_trace_id()
        span_id = generate_span_id()
        cls.set_current_context(Context(trace_id, span_id, ""))
        return trace_id

    @classmethod
    def continue_trace(cls, trace_id: str, span_id: str) -> None:
        """继续已有链路"""
        parent_span_id = cls.get_current_context().span_id
        cls.set_current_context(Context(trace_id, span_id, parent_span_id))

    @classmethod
    def inject(cls, trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """手动注入上下文"""
        cls.set_current_context(Context(trace_id, span_id, parent_span_id))

    @classmethod
    def extract_and_inject_from_headers(cls, trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """从 HTTP Header 提取并注入上下文"""
        cls.set_current_context(Context(trace_id, span_id, parent_span_id))

    @classmethod
    def prepare_for_child_thread(cls) -> None:
        """准备子线程的上下文"""
        cls._prepared_context = cls.get_current_context()

    @classmethod
    def inherit_from_prepared(cls) -> None:
        """从准备好的上下文继承"""
        if cls._prepared_context:
            cls.set_current_context(cls._prepared_context)

    @classmethod
    def inherit_from_parent(cls) -> None:
        """从父线程继承上下文（用于子线程）"""
        cls.inherit_from_prepared()


# ==================== ID 生成器 ====================

def generate_trace_id() -> str:
    """生成 Trace ID"""
    import uuid
    return uuid.uuid4().hex[:16]


def generate_span_id() -> str:
    """生成 Span ID"""
    import uuid
    return uuid.uuid4().hex[:8]


# ==================== 日志建造者 ====================

class LogBuilder:
    """日志建造者"""
    def __init__(self, message: str = ""):
        self._message = message
        self._level = LogLevel.INFO
        self._ctx = InsightOSLogContext.get_current_context()
        self._request: Optional[EventRequest] = None
        self._params: Any = None
        self._result: Any = None
        self._latency_ms: Optional[int] = None
        self._error: Optional[LogError] = None
        self._truncate: bool = False

    def msg(self, message: str) -> 'LogBuilder':
        self._message = message
        return self

    def level(self, level: int) -> 'LogBuilder':
        self._level = level
        return self

    def context(self, ctx: Context) -> 'LogBuilder':
        self._ctx = ctx
        return self

    def request(self, method: str, url: str, latency_ms: int = 0) -> 'LogBuilder':
        self._request = EventRequest(method, url, latency_ms)
        return self

    def with_params(self, params: Any) -> 'LogBuilder':
        self._params = params
        return self

    def with_result(self, result: Any) -> 'LogBuilder':
        self._result = result
        return self

    def with_data(self, params: Any, result: Any) -> 'LogBuilder':
        self._params = params
        self._result = result
        return self

    def latency(self, ms: int) -> 'LogBuilder':
        self._latency_ms = ms
        return self

    def truncate(self, enable: bool = True) -> 'LogBuilder':
        self._truncate = enable
        return self

    def with_error(self, err: LogError) -> 'LogBuilder':
        self._error = err
        return self

    def send(self) -> None:
        _log_message(self._level, self._ctx, self._message,
                    request=self._request, params=self._params,
                    result=self._result, latency_ms=self._latency_ms,
                    error=self._error, truncate=self._truncate)

    def params(self, params: Any) -> 'LogBuilder':
        return self.with_params(params)

    def result(self, result: Any) -> 'LogBuilder':
        return self.with_result(result)

    def error(self, msg: str, stack: str = "") -> 'LogBuilder':
        self._error = LogError(msg, stack)
        return self

    def log(self) -> None:
        self.send()


class ContextWithLog:
    """上下文管理器 - 自动设置和清理上下文"""
    def __init__(self, trace_id: str = "", span_id: str = "", parent_span_id: str = ""):
        self._ctx = Context(trace_id, span_id, parent_span_id)
        self._previous_ctx: Optional[Context] = None

    def __enter__(self) -> Context:
        self._previous_ctx = InsightOSLogContext.get_current_context()
        InsightOSLogContext.set_current_context(self._ctx)
        return self._ctx

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        InsightOSLogContext.set_current_context(self._previous_ctx)


# ==================== 配置加载器 ====================

def init_from_config(config_path: str) -> None:
    """从配置文件初始化"""
    import yaml
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    init(InitParam(**config))


# ==================== 敏感信息过滤 ====================

SENSITIVE_PATTERNS = [
    (re.compile(r'("|)(password|passwd|pwd|secret|token|key|api_key|apikey)("|)\s*[:=]\s*["\']?([^"\'\s,}]+)["\']?', re.I), r'\1\2\3: "***"'),
    (re.compile(r'(password|passwd|pwd|secret|token)\s*=\s*([^\s&]+)', re.I), r'\1=***'),
]


def mask_sensitive(text: str) -> str:
    """过滤敏感信息"""
    for pattern, replacement in SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


# ==================== 全局变量 ====================

_global_resource: Optional[Any] = None
_initialized: bool = False
_global_logger: Optional[logging.Logger] = None
_global_output_mode: str = "stdout"
_flush_timer: Optional[threading.Timer] = None
_global_stdout_fields: set = {"meta", "event"}  # stdout 域过滤集合，event 始终包含


# ==================== 核心日志函数 ====================

def _to_python_level(level: int) -> int:
    """转换日志级别到 Python 级别"""
    mapping = {
        LogLevel.TRACE: logging.DEBUG,
        LogLevel.DEBUG: logging.DEBUG,
        LogLevel.INFO: logging.INFO,
        LogLevel.WARN: logging.WARNING,
        LogLevel.ERROR: logging.ERROR,
        LogLevel.FATAL: logging.CRITICAL,
    }
    return mapping.get(level, logging.INFO)


def _from_python_level(level: int) -> LogLevel:
    """转换 Python 级别到日志级别"""
    mapping = {
        logging.DEBUG: LogLevel.DEBUG,
        logging.INFO: LogLevel.INFO,
        logging.WARNING: LogLevel.WARN,
        logging.ERROR: LogLevel.ERROR,
        logging.CRITICAL: LogLevel.FATAL,
    }
    return mapping.get(level, LogLevel.INFO)


def _log_message(level: int, ctx: Any, msg: str,
                 request: Optional[EventRequest] = None,
                 params: Any = None, result: Any = None,
                 latency_ms: Optional[int] = None,
                 error: Optional[LogError] = None,
                 truncate: bool = False,
                 caller: Optional[Caller] = None) -> None:
    """核心日志函数"""
    if not _initialized:
        return

    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    timestamp_local = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+08:00"

    log_msg = {
        "meta": {
            "level": LogLevel.to_string(level),
            "time": timestamp_local
        },
        "resource": _global_resource.to_dict() if _global_resource else {},
        "context": ctx.to_dict() if hasattr(ctx, 'to_dict') else {},
        "event": {
            "msg": msg
        }
    }

    if caller:
        log_msg["caller"] = caller.to_dict()

    if request:
        log_msg["event"]["request"] = request.to_dict()

    if params is not None or result is not None or latency_ms is not None:
        data = Data(params, result, truncate)

        if params is not None:
            params_str = json.dumps(params, ensure_ascii=False)
            params_str = mask_sensitive(params_str)
            data.param = json.loads(params_str)
        if result is not None:
            result_str = json.dumps(result, ensure_ascii=False)
            result_str = mask_sensitive(result_str)
            data.res = json.loads(result_str)

        log_msg["data"] = data.to_dict()

        if latency_ms is not None:
            if "request" not in log_msg["event"]:
                log_msg["event"]["request"] = {}
            log_msg["event"]["request"]["latency_ms"] = latency_ms

    if error:
        log_msg["error"] = error.to_dict()

    json_str = json.dumps(log_msg, indent=2, ensure_ascii=False)

    global _global_output_mode
    level_str = LogLevel.to_string(level)

    if _global_output_mode == "stdout":
        color_prefix = LogLevel.to_color(level)
        color_suffix = LogLevel._RESET
        pid = _global_resource.pid if _global_resource else 0
        # 按 stdout_fields 过滤，只保留 event 和已配置的域
        filtered = {k: v for k, v in log_msg.items()
                    if k == "event" or k in _global_stdout_fields}
        json_str = json.dumps(filtered, indent=2, ensure_ascii=False)
        output = f"{color_prefix}{level_str} {timestamp_local} [{pid}] {json_str}{color_suffix}"
        print(output)
    else:
        _file_log(level_str, json_str)


def _get_caller_info(depth: int = 2) -> Caller:
    """获取调用者信息"""
    try:
        stack = tb_module.extract_stack()
        if len(stack) >= depth:
            frame = stack[-depth]
            return Caller(
                file=os.path.basename(frame.filename),
                line=frame.lineno,
                function=frame.name
            )
        return Caller()
    except:
        return Caller()


# ==================== 便捷日志函数 ====================

def trace(msg: str) -> None:
    ctx = InsightOSLogContext.get_current_context()
    caller = _get_caller_info(3)
    _log_message(LogLevel.TRACE, ctx, msg, caller=caller)


def debug(msg: str) -> None:
    ctx = InsightOSLogContext.get_current_context()
    caller = _get_caller_info(3)
    _log_message(LogLevel.DEBUG, ctx, msg, caller=caller)


def info(msg: str) -> None:
    ctx = InsightOSLogContext.get_current_context()
    caller = _get_caller_info(3)
    _log_message(LogLevel.INFO, ctx, msg, caller=caller)


def warn(msg: str) -> None:
    ctx = InsightOSLogContext.get_current_context()
    caller = _get_caller_info(3)
    _log_message(LogLevel.WARN, ctx, msg, caller=caller)


def error(msg: str) -> None:
    ctx = InsightOSLogContext.get_current_context()
    caller = _get_caller_info(3)
    _log_message(LogLevel.ERROR, ctx, msg, caller=caller)


def fatal(msg: str) -> None:
    ctx = InsightOSLogContext.get_current_context()
    caller = _get_caller_info(3)
    _log_message(LogLevel.FATAL, ctx, msg, caller=caller)


def tracef(msg: str, *args) -> None:
    formatted = msg.format(*args) if args else msg
    trace(formatted)


def debugf(msg: str, *args) -> None:
    formatted = msg.format(*args) if args else msg
    debug(formatted)


def infof(msg: str, *args) -> None:
    formatted = msg.format(*args) if args else msg
    info(formatted)


def warnf(msg: str, *args) -> None:
    formatted = msg.format(*args) if args else msg
    warn(formatted)


def errorf(msg: str, *args) -> None:
    formatted = msg.format(*args) if args else msg
    error(formatted)


def fatalf(msg: str, *args) -> None:
    formatted = msg.format(*args) if args else msg
    fatal(formatted)


# ==================== 带 Context 的日志函数 ====================

def trace_with_context(ctx: Context, msg: str,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    caller = _get_caller_info(3)
    _log_message(LogLevel.TRACE, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def debug_with_context(ctx: Context, msg: str,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    caller = _get_caller_info(3)
    _log_message(LogLevel.DEBUG, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def info_with_context(ctx: Context, msg: str,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    caller = _get_caller_info(3)
    _log_message(LogLevel.INFO, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def warn_with_context(ctx: Context, msg: str,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None) -> None:
    caller = _get_caller_info(3)
    _log_message(LogLevel.WARN, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, caller=caller)


def error_with_context(ctx: Context, msg: str,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None,
                       error: Optional[LogError] = None) -> None:
    caller = _get_caller_info(3)
    _log_message(LogLevel.ERROR, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, error=error, caller=caller)


def fatal_with_context(ctx: Context, msg: str,
                       params: Any = None, result: Any = None,
                       latency_ms: Optional[int] = None,
                       error: Optional[LogError] = None) -> None:
    caller = _get_caller_info(3)
    _log_message(LogLevel.FATAL, ctx, msg, params=params, result=result,
                 latency_ms=latency_ms, error=error, caller=caller)


# ==================== 便捷函数 ====================

def current_context():
    """获取当前 Context"""
    return InsightOSLogContext.get_current_context()


def make_context(trace_id: str, span_id: str, parent_span_id: str = ""):
    """创建 Context"""
    return Context(trace_id, span_id, parent_span_id)


def extract_from_headers(trace_id: str, span_id: str, parent_span_id: str = "") -> None:
    """从 HTTP Header 提取并注入上下文"""
    InsightOSLogContext.set_current_context(Context(trace_id, span_id, parent_span_id))


# ==================== 文件输出 ====================

def _file_log(level_str: str, json_str: str) -> None:
    """输出到文件"""
    global _global_logger, _global_output_mode

    if _global_output_mode == "rotate_file" and _global_logger:
        _global_logger.info(f"{level_str}\n{json_str}")
    else:
        print(level_str)
        print(json_str)


def global_resource() -> Optional[Any]:
    """获取全局 Resource"""
    return _global_resource


def refresh_pid() -> None:
    """刷新 PID"""
    global _global_resource
    if _global_resource:
        _global_resource.pid = os.getpid()


# ==================== 控制函数 ====================

def is_initialized() -> bool:
    """检查是否已初始化"""
    return _initialized


_global_log_level: int = LogLevel.INFO


def set_level(level: int) -> None:
    """设置日志级别"""
    global _global_log_level
    _global_log_level = level


def get_level() -> int:
    """获取当前日志级别"""
    global _global_log_level
    return _global_log_level


# ==================== 资源管理 ====================

_global_config: Optional[InitParam] = None


def set_global_resource(resource: Resource) -> None:
    """设置全局资源信息"""
    global _global_resource
    _global_resource = resource


def GlobalResource() -> Optional[Resource]:
    """获取全局资源"""
    return _global_resource


def SetGlobalResource(resource: Resource) -> None:
    """设置全局资源"""
    set_global_resource(resource)


# ==================== ID 生成 ====================

def GenerateTraceID() -> str:
    """生成 Trace ID"""
    return generate_trace_id()


def GenerateSpanID() -> str:
    """生成 Span ID"""
    return generate_span_id()


# ==================== 初始化 ====================

def init(config: InitParam) -> None:
    """初始化 SDK"""
    global _global_resource, _initialized, _global_output_mode, _global_logger, _flush_timer, _global_log_level, _global_stdout_fields

    hostname = socket.gethostname()
    pid = os.getpid()

    _global_log_level = config.level

    _global_resource = Resource(
        type=config.service_type,
        name=config.service_name,
        instance_id=config.instance_id,
        host=hostname,
        pid=pid
    )

    _global_output_mode = config.output
    _global_stdout_fields = {"event"}  # event 始终包含
    for f in config.stdout_fields:
        _global_stdout_fields.add(f)

    if config.output == "rotate_file":
        log_dir = os.path.join(config.log_root, config.service_type)
        os.makedirs(log_dir, exist_ok=True)

        log_file = os.path.join(log_dir, f"{config.service_name}.log")

        _global_logger = logging.getLogger("insightoslog")
        _global_logger.setLevel(logging.DEBUG)

        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=config.max_size,
            backupCount=config.max_files,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)

        formatter = logging.Formatter('%(message)s')
        file_handler.setFormatter(formatter)

        if config.buffer_size > 0:
            log_queue = queue.Queue(maxsize=config.buffer_size)
            queue_handler = logging.handlers.QueueHandler(log_queue)
            _global_logger.addHandler(queue_handler)

            listener = logging.handlers.QueueListener(
                log_queue,
                file_handler,
                respect_handler_level=True
            )
            listener.start()

            _global_logger._queue_listener = listener

            print(f"[InsightOSLog] SDK init: output={config.output}, log_file={log_file}, buffer_size={config.buffer_size}")
        else:
            _global_logger.addHandler(file_handler)
            print(f"[InsightOSLog] SDK init: output={config.output}, log_file={log_file}")
    else:
        print(f"[InsightOSLog] SDK init: output={config.output}")

    if config.flush_interval > 0:
        def _flush_loop():
            global _global_logger, _flush_timer
            if _global_logger:
                for h in _global_logger.handlers:
                    h.flush()
            _flush_timer = threading.Timer(config.flush_interval, _flush_loop)
            _flush_timer.daemon = True
            _flush_timer.start()

        _flush_timer = threading.Timer(config.flush_interval, _flush_loop)
        _flush_timer.daemon = True
        _flush_timer.start()
        print(f"[InsightOSLog] SDK init: flush_interval={config.flush_interval}s")

    _initialized = True


# ==================== Logger 类封装 ====================

class Logger:
    """Logger 类封装"""

    @staticmethod
    def init(param: dict) -> None:
        """初始化日志系统"""
        if isinstance(param, dict):
            param = InitParam(**param)
        init(param)

    @staticmethod
    def init_from_config(config_path: str = "./InsightOSLogConfig.yaml") -> None:
        """从配置文件初始化"""
        init_from_config(config_path)

    @staticmethod
    def flush() -> None:
        """刷新日志缓冲区"""
        if _global_logger:
            for h in _global_logger.handlers:
                h.flush()

    @staticmethod
    def refresh_pid() -> None:
        """刷新进程 ID"""
        pass

    @staticmethod
    def is_initialized() -> bool:
        """检查是否已初始化"""
        return _initialized

    @staticmethod
    def set_level(level: LogLevel) -> None:
        """设置日志级别"""
        global _global_log_level
        _global_log_level = level

    @staticmethod
    def get_level() -> LogLevel:
        """获取当前日志级别"""
        return LogLevel.INFO

    @staticmethod
    def get_resource() -> Resource:
        """获取全局资源信息"""
        return global_resource()

    @staticmethod
    def set_resource(resource: Resource) -> None:
        """设置全局资源信息"""
        set_global_resource(resource)

    @staticmethod
    def trace(msg: str) -> None:
        """记录 trace 级别日志"""
        trace(msg)

    @staticmethod
    def tracef(fmt: str, *args) -> None:
        """记录格式化 trace 级别日志"""
        tracef(fmt, *args)

    @staticmethod
    def debug(msg: str) -> None:
        """记录 debug 级别日志"""
        debug(msg)

    @staticmethod
    def debugf(fmt: str, *args) -> None:
        """记录格式化 debug 级别日志"""
        debugf(fmt, *args)

    @staticmethod
    def info(msg: str) -> None:
        """记录 info 级别日志"""
        info(msg)

    @staticmethod
    def infof(fmt: str, *args) -> None:
        """记录格式化 info 级别日志"""
        infof(fmt, *args)

    @staticmethod
    def warn(msg: str) -> None:
        """记录 warn 级别日志"""
        warn(msg)

    @staticmethod
    def warnf(fmt: str, *args) -> None:
        """记录格式化 warn 级别日志"""
        warnf(fmt, *args)

    @staticmethod
    def error(msg: str) -> None:
        """记录 error 级别日志"""
        error(msg)

    @staticmethod
    def errorf(fmt: str, *args) -> None:
        """记录格式化 error 级别日志"""
        errorf(fmt, *args)

    @staticmethod
    def fatal(msg: str) -> None:
        """记录 fatal 级别日志"""
        fatal(msg)

    @staticmethod
    def fatalf(fmt: str, *args) -> None:
        """记录格式化 fatal 级别日志"""
        fatalf(fmt, *args)


# ==================== Trace 类封装 ====================

class Trace:
    """Trace 类封装"""

    @staticmethod
    def start_new_trace() -> str:
        """开始新的追踪链路"""
        return InsightOSLogContext.start_new_trace()

    @staticmethod
    def continue_trace(trace_id: str, span_id: str) -> None:
        """继续已有链路"""
        InsightOSLogContext.continue_trace(trace_id, span_id)

    @staticmethod
    def inject(trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """手动注入上下文"""
        InsightOSLogContext.inject(trace_id, span_id, parent_span_id)

    @staticmethod
    def get_current_context() -> Context:
        """获取当前 Trace 上下文"""
        return InsightOSLogContext.get_current_context()

    @staticmethod
    def get_trace_id() -> str:
        """获取 Trace ID"""
        ctx = InsightOSLogContext.get_current_context()
        return ctx.trace_id if ctx else ""

    @staticmethod
    def get_span_id() -> str:
        """获取 Span ID"""
        ctx = InsightOSLogContext.get_current_context()
        return ctx.span_id if ctx else ""

    @staticmethod
    def get_parent_span_id() -> str:
        """获取父 Span ID"""
        ctx = InsightOSLogContext.get_current_context()
        return ctx.parent_span_id if ctx else ""

    @staticmethod
    def get_propagation_headers() -> dict:
        """获取需要传播到下游的 HTTP Header"""
        return {
            'trace_id': Trace.get_trace_id(),
            'span_id': Trace.get_span_id(),
            'parent_span_id': Trace.get_parent_span_id()
        }

    @staticmethod
    def extract_from_headers(trace_id: str, span_id: str, parent_span_id: str = "") -> None:
        """从 HTTP Header 提取并注入上下文"""
        InsightOSLogContext.extract_and_inject_from_headers(trace_id, span_id, parent_span_id)

    @staticmethod
    def prepare_for_child_thread() -> None:
        """准备子线程的上下文"""
        InsightOSLogContext.prepare_for_child_thread()

    @staticmethod
    def inherit_from_prepared() -> None:
        """从准备好的上下文继承"""
        InsightOSLogContext.inherit_from_prepared()

    @staticmethod
    def inherit_from_parent() -> None:
        """从父线程继承上下文"""
        InsightOSLogContext.inherit_from_parent()

    @staticmethod
    def clear_context() -> None:
        """清除当前上下文"""
        InsightOSLogContext.clear_context()

    @staticmethod
    def set_current_context(context: Context) -> None:
        """设置当前上下文"""
        InsightOSLogContext.set_current_context(context)


# ==================== 全局实例 ====================

Logger = Logger()
Trace = Trace()


# ==================== 导出 ====================

__all__ = [
    'LogLevel',
    'Caller', 'Meta', 'Resource', 'Context',
    'EventRequest', 'Event', 'Data', 'LogError',
    'InitParam',
    'HEADER_TRACE_ID', 'HEADER_SPAN_ID', 'HEADER_PARENT_SPAN_ID',
    'InsightOSLogContext',
    'generate_trace_id', 'generate_span_id',
    'LogBuilder', 'ContextWithLog',
    'trace', 'debug', 'info', 'warn', 'error', 'fatal',
    'tracef', 'debugf', 'infof', 'warnf', 'errorf', 'fatalf',
    'trace_with_context', 'debug_with_context', 'info_with_context',
    'warn_with_context', 'error_with_context', 'fatal_with_context',
    'current_context', 'make_context', 'extract_from_headers',
    'init', 'init_from_config', 'refresh_pid',
    'mask_sensitive',
    'is_initialized', 'flush', 'set_level', 'get_level',
    'global_resource', 'GlobalResource', 'set_global_resource', 'SetGlobalResource',
    'GenerateTraceID', 'GenerateSpanID',
    'Logger', 'Trace',
]
