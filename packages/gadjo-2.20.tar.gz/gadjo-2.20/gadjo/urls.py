from django.urls import path
from django.views.i18n import JavaScriptCatalog

app_name = 'gadjo'
urlpatterns = [
    path('jsi18n/', JavaScriptCatalog.as_view(), name='javascript-catalog'),
]
