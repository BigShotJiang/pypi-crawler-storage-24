from django.urls import include, path

urlpatterns = [
    path('', include('gadjo.urls', namespace='gadjo')),
]
