#include "utils.h"

int
gmp_parse_pyargs(const gmp_pyargs *fnargs, Py_ssize_t argidx[],
                 PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames)
{
    if (nargs > fnargs->maxpos) {
        PyErr_Format(PyExc_TypeError,
                     "%s() takes at most %zu positional arguments",
                     fnargs->fname, fnargs->maxpos);
        return -1;
    }
    for (Py_ssize_t i = 0; i < nargs; i++) {
        argidx[i] = i;
    }

    Py_ssize_t nkws = 0;

    if (kwnames) {
        nkws = PyTuple_Size(kwnames);
    }
    if (nkws > fnargs->maxpos) {
        PyErr_Format(PyExc_TypeError,
                     "%s() takes at most %zu keyword arguments", fnargs->fname,
                     fnargs->maxargs);
        return -1;
    }
    if (nkws + nargs < fnargs->minargs) {
        PyErr_Format(PyExc_TypeError,
                     ("%s() takes at least %zu positional or "
                      "keyword arguments"),
                     fnargs->fname, fnargs->minargs);
        return -1;
    }
    for (Py_ssize_t i = 0; i < nkws; i++) {
        const char *kwname = PyUnicode_AsUTF8AndSize(PyTuple_GetItem(kwnames,
                                                                     i), NULL);
        Py_ssize_t j = 0;

        for (; j < fnargs->maxargs; j++) {
            if (strcmp(kwname, fnargs->keywords[j]) == 0) {
                if (j > fnargs->maxpos || nargs <= j) {
                    argidx[j] = (int)(nargs + i);
                    break;
                }
                else {
                    PyErr_Format(PyExc_TypeError,
                                 ("argument for %s() given by name "
                                  "('%s') and position (%zu)"),
                                 fnargs->fname, fnargs->keywords[j], j + 1);
                    return -1;
                }
            }
        }
        if (j == fnargs->maxargs) {
            PyErr_Format(PyExc_TypeError,
                         "%s() got an unexpected keyword argument '%s'",
                         fnargs->fname, kwname);
            return -1;
        }
    }
    return 0;
}

/* copied from CPython internals */
PyObject *
gmp_PyUnicode_TransformDecimalAndSpaceToASCII(PyObject *unicode)
{
    assert(PyUnicode_Check(unicode));
    if (PyUnicode_IS_ASCII(unicode)) {
        return Py_NewRef(unicode);
    }

    Py_ssize_t len = PyUnicode_GetLength(unicode);
    PyObject *result = PyUnicode_New(len, 127);

    if (result == NULL) {
        return NULL; /* LCOV_EXCL_LINE */
    }

    Py_UCS1 *out = PyUnicode_1BYTE_DATA(result);
#if defined(__GNUC__) || defined(__clang__)
#  pragma GCC diagnostic push /* XXX: oracle/graalpython#580 */
#  pragma GCC diagnostic ignored "-Wsign-conversion"
#endif
    int kind = PyUnicode_KIND(unicode);
#if defined(__GNUC__) || defined(__clang__)
#  pragma GCC diagnostic pop
#endif
    const void *data = PyUnicode_DATA(unicode);

    for (Py_ssize_t i = 0; i < len; ++i) {
        Py_UCS4 ch = PyUnicode_READ(kind, data, i);

        if (ch < 127) {
            out[i] = (Py_UCS1)ch;
        }
        else if (Py_UNICODE_ISSPACE(ch)) {
            out[i] = ' ';
        }
        else {
            int decimal = Py_UNICODE_TODECIMAL(ch);

            if (decimal < 0) {
                out[i] = '?';
                out[i + 1] = '\0';
                break;
            }
            assert(decimal < 127);
            out[i] = '0' + (Py_UCS1)decimal;
        }
    }
    return result;
}

#if PY_VERSION_HEX < 0x030D00A0
static PyObject *
PyType_GetModuleName(PyTypeObject *type)
{
    return PyObject_GetAttrString((PyObject *)type, "__module__");
}

PyObject *
_PyType_GetFullyQualifiedName(PyTypeObject *type)
{
    PyObject *qualname = PyType_GetQualName(type);
    if (qualname == NULL) {
        return NULL; /* LCOV_EXCL_LINE */
    }

    PyObject *module = PyType_GetModuleName(type);
    if (module == NULL) {
        /* LCOV_EXCL_START */
        Py_DECREF(qualname);
        return NULL;
        /* LCOV_EXCL_STOP */
    }

    PyObject *result;

    if (PyUnicode_Check(module)
        && !PyUnicode_EqualToUTF8(module, "builtins")
        && !PyUnicode_EqualToUTF8(module, "__main__"))
    {
        result = PyUnicode_FromFormat("%U.%U", module, qualname);
    }
    else {
        result = Py_NewRef(qualname);
    }
    Py_XDECREF(module);
    Py_XDECREF(qualname);
    return result;
}
#endif
