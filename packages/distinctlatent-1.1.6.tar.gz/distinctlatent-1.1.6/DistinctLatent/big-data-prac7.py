from collections import defaultdict
from multiprocessing import Pool

def map_function(document):
    word_count = defaultdict(int)
    for word in document.split():
        word_count[word] += 1
    return word_count


def reduce_function(results):
    final_word_count = defaultdict(int)
    for word_count in results:
        for word, count in word_count.items():
            final_word_count[word] += count
    return final_word_count


def main(documents, num_processes=4):
    with Pool(num_processes) as pool:
        mapped_results = pool.map(map_function, documents)

    reduced_result = reduce_function(mapped_results)
    return reduced_result


if __name__ == "__main__":
    documents = [
        "Dear", "Bear", "River", "Car", "Car",
        "River", "Deer", "Car", "Car", "Bear"
    ]

    word_counts = main(documents)
    print(word_counts)
