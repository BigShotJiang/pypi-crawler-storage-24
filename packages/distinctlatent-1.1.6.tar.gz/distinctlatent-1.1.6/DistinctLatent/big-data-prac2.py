

import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')

sia = SentimentIntensityAnalyzer()

texts = [
    "I love this product, it's amazing",
    "This is the worst experience I ever had",
    "The movie was okay, not too good, not too bad"
]

for text in texts:
    sentiment_score = sia.polarity_scores(text)
    compound_score = sentiment_score['compound']

    if compound_score >= 0.05:
        sentiment_label='Positive'
    elif compound_score <= -0.05:
        sentiment_label = 'Negative'
    else:
        sentiment_label='Neutral'

    print(f"Texts: {text}")
    print(f"Sentiment Scores: {sentiment_score}")
    print(f"Overall Sentiment: {sentiment_label}")
    print("-"*60)
    
    
