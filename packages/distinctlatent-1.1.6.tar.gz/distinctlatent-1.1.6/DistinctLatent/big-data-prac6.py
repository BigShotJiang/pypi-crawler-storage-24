import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = pd.read_csv("dataset.csv")

le = LabelEncoder()

for column in data.columns:
    data[column] = le.fit_transform(data[column])

X = data.drop("Buy", axis=1)
y = data["Buy"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=1
)

model = GaussianNB()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

# Example: Age=Young, Income=Low, MaritalStatus=Single
new_data = [[0, 1, 1]]  # encoded values
result = model.predict(new_data)

print("Prediction (0 = No, 1 = Yes):", result)
