import math
import pandas as pd

n = int(input("Enter number of documents: "))

docs = []
for i in range(n):
    text = input(f"Enter text for Document {i+1}: ").lower()
    docs.append(text)

tokens = [doc.split() for doc in docs]

vocab = sorted(set(word for doc in tokens for word in doc))

N = len(docs)

tf = []
for doc in tokens:
    total_terms = len(doc)
    tf_doc = {}
    for term in vocab:
        tf_doc[term] = doc.count(term) / total_terms
    tf.append(tf_doc)

df = {}
for term in vocab:
    df[term] = sum(1 for doc in tokens if term in doc)

idf = {}
for term in vocab:
    idf[term] = math.log(N / df[term])

tfidf = []

for tf_doc in tf:
    tfidf_doc = {}
    for term in vocab:
        tfidf_doc[term] = tf_doc[term] * idf[term]
    tfidf.append(tfidf_doc)

tfidf_df = pd.DataFrame(tfidf)
tfidf_df.index = [f"Doc{i+1}" for i in range(N)]

print("\nTF-IDF Matrix:\n")
print(tfidf_df)
