from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

import requests
from requests import RequestException


BASE_URL = "https://www.tradera.com"


class TraderaApiError(RuntimeError):
    pass


@dataclass
class TraderaClient:
    base_url: str = BASE_URL
    timeout_seconds: int = 20

    def __post_init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(
            {
                "accept": "application/json, text/plain, */*",
                "user-agent": "tradera-cli/0.1.0",
            }
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        headers = dict(kwargs.pop("headers", {}))
        if "json" in kwargs:
            headers.setdefault("content-type", "application/json")

        needs_token = path.startswith("/api/webapi/") or path.startswith("/ajax/")
        if needs_token and path != "/api/webapi/auth/web/client/token":
            self._ensure_client_token()

        url = f"{self.base_url}{path}"
        try:
            response = self.session.request(method, url, timeout=self.timeout_seconds, headers=headers, **kwargs)
        except RequestException as exc:
            raise TraderaApiError(f"Request failed for {path}: {exc}") from exc

        if response.status_code in {400, 401} and needs_token:
            self._ensure_client_token(force=True)
            try:
                response = self.session.request(method, url, timeout=self.timeout_seconds, headers=headers, **kwargs)
            except RequestException as exc:
                raise TraderaApiError(f"Request retry failed for {path}: {exc}") from exc

        if response.status_code >= 400:
            raise TraderaApiError(f"{response.status_code} {response.reason}: {path}")
        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            try:
                return response.json()
            except ValueError as exc:
                raise TraderaApiError(f"Invalid JSON response from {path}") from exc
        return response.text

    def _ensure_client_token(self, force: bool = False) -> None:
        if not force and self.session.cookies.get("trd_at"):
            return
        try:
            response = self.session.post(
                f"{self.base_url}/api/webapi/auth/web/client/token",
                timeout=self.timeout_seconds,
                headers={"content-type": "application/json", "accept": "application/json"},
            )
        except RequestException as exc:
            raise TraderaApiError(f"Failed to establish anonymous client token: {exc}") from exc
        if response.status_code >= 400:
            raise TraderaApiError("Failed to establish anonymous client token")

    def search(
        self,
        query: str,
        page: int = 1,
        page_size: int = 50,
        sort_by: str = "Relevance",
        language_code_iso2: str = "sv",
        shipping_country_code_iso2: str = "SE",
        automatic_translation_preferred: bool = True,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "isCsaSearchQuery": False,
            "query": query,
            "page": page,
            "pageSize": page_size,
            "sortBy": sort_by,
            "languageCodeIso2": language_code_iso2.lower(),
            "shippingCountryCodeIso2": shipping_country_code_iso2.upper(),
            "automaticTranslationPreferred": automatic_translation_preferred,
            "attributeFilters": [],
            "categoryPath": [],
            "currentCategoryId": 0,
            "filterCounties": None,
            "filterCategories": {},
            "filterPrice": {},
            "filters": {},
            "headerText": None,
            "internalSearch": {"showSearchBar": False},
            "introText": None,
            "isSavedSearchEmailEnabled": False,
            "isShopOwnedByCurrentMember": False,
            "items": [],
            "relatedItems": [],
            "itemsOnDisplay": [],
            "mainText": None,
            "pagination": None,
            "totalItems": 0,
            "searchLanguages": [],
            "itemsMatchedViewModel": None,
            "suggestion": None,
        }
        return self._request("POST", "/api/webapi/discover/web/independent-search", json=payload)

    def item(self, item_id: int) -> dict[str, Any]:
        data = self._request("GET", f"/ajax/item/{item_id}")
        if not isinstance(data, dict):
            raise TraderaApiError(f"Unexpected item response for item {item_id}")
        return data

    def categories(self, level: int = 1, lang: str = "sv") -> Any:
        return self._request("GET", f"/api/categories/{level}?languageCodeIso2={lang}&next=1")


def parse_item_id(value: str) -> int:
    if value.isdigit():
        return int(value)
    match = re.search(r"/(\d{6,})", value)
    if not match:
        raise ValueError(f"Could not parse item id from: {value}")
    return int(match.group(1))
