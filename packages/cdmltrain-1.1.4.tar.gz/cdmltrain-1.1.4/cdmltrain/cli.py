import argparse
import os
import sys

def main():
    parser = argparse.ArgumentParser(description="CDMLTrain CLI - Profile Zips quickly")
    parser.add_argument('--path', type=str, required=True, help='Path to the .zip or .zst dataset file')
    
    args = parser.parse_args()
    zip_path = args.path
    
    print("\n" + "="*50)
    print(" 🔍 CDMLTrain Quick Scanner")
    print("="*50)
    
    if not os.path.exists(zip_path):
        print(f"❌ Error: File not found -> {zip_path}")
        sys.exit(1)
        
    print(f"📄 Analyzing File: {os.path.basename(zip_path)}...")
    
    try:
        from cdmltrain.dataset import CDMLStreamDataset
        
        # Initialize reader (is_image False string output to just get names quickly)
        dataset = CDMLStreamDataset(zip_path, transform=None, is_image=False)
        
        filenames = dataset.get_filenames()
        total_files = len(filenames)
        
        if total_files == 0:
            print("❌ Status: INVALID (Zero files found inside archive)")
            sys.exit(1)
            
        print(f"✅ Total Items Found : {total_files}")
        
        print("\n📂 Top 3 Files Preview:")
        for idx in range(min(3, total_files)):
            print(f"   {idx+1}. {filenames[idx]}")
            
        print("\n🟢 Status: TRAINING-READY!")
        print("💡 Tip: Use `from cdmltrain.dataset import CDMLStreamDataset` to load this directly in PyTorch.\n")
        
    except Exception as e:
        print(f"❌ Error during scanning: {e}")
        print("💡 Hint: Ensure this is a valid .zip or .zst formatted file!")
        sys.exit(1)

if __name__ == "__main__":
    main()
