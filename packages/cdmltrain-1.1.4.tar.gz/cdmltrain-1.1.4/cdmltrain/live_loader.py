"""
CDMLTrain - Live Universal Dataset Loader (v2.0)
=================================================
Full support for ALL data types:
  - Images   (.jpg, .jpeg, .png, .bmp, .tiff) -> PIL Image objects
  - Audio    (.wav, .mp3, .flac, .ogg)        -> MFCC features (numpy) OR raw bytes
  - CSV      (.csv)                            -> List of dicts (rows)
  - JSON     (.json)                           -> Full nested support, flat or array
  - Text     (.txt)                            -> Cleaned token lists

Usage:
    from cdmltrain.live_loader import LiveBatchLoader

    loader = LiveBatchLoader("live_batch_20260227_143000.zip")
    print(loader.summary())

    images  = loader.get_images()     # PIL Images
    audio   = loader.get_audio()      # MFCC numpy arrays (or raw bytes fallback)
    sensor  = loader.get_tabular()    # CSV rows as list of dicts
    jdata   = loader.get_json()       # Full nested JSON
    text    = loader.get_text()       # Cleaned text lines
    all_d   = loader.get_all()        # Everything at once
"""

import io
import csv
import json
import zipfile
from typing import Optional, List, Dict, Any

# ─── Optional Imports ─────────────────────────────────────────────────────────
try:
    from PIL import Image
    _HAS_PIL = True
except ImportError:
    _HAS_PIL = False

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False

try:
    import librosa
    _HAS_LIBROSA = True
except ImportError:
    _HAS_LIBROSA = False

try:
    import soundfile as sf
    _HAS_SOUNDFILE = True
except ImportError:
    _HAS_SOUNDFILE = False

# ─── Supported File Extensions ───────────────────────────────────────────────
_IMAGE_EXTS   = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff'}
_AUDIO_EXTS   = {'.wav', '.mp3', '.flac', '.ogg', '.m4a', '.aac', '.mp4'}
_CSV_EXTS     = {'.csv'}
_JSON_EXTS    = {'.json'}
_TEXT_EXTS    = {'.txt'}


def _detect_ext(filename: str) -> str:
    """Returns the lowercase extension of a filename."""
    if '.' not in filename:
        return ''
    return '.' + filename.rsplit('.', 1)[-1].lower()


def _detect_type(filename: str) -> str:
    """Returns semantic data type of a file based on its extension."""
    ext = _detect_ext(filename)
    if ext in _IMAGE_EXTS:   return 'image'
    if ext in _AUDIO_EXTS:   return 'audio'
    if ext in _CSV_EXTS:     return 'csv'
    if ext in _JSON_EXTS:    return 'json'
    if ext in _TEXT_EXTS:    return 'text'
    return 'unknown'


# ─── JSON Helper: Flatten nested JSON recursively ────────────────────────────
def _flatten_json(obj: Any, prefix: str = '', sep: str = '.') -> dict:
    """
    Converts deeply nested JSON into a flat dict.
    Example:
        {"sensor": {"temp": 36.5, "unit": "C"}}
        → {"sensor.temp": 36.5, "sensor.unit": "C"}
    """
    items = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            new_key = f"{prefix}{sep}{k}" if prefix else k
            if isinstance(v, (dict, list)):
                items.update(_flatten_json(v, new_key, sep))
            else:
                items[new_key] = v
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            new_key = f"{prefix}{sep}{i}" if prefix else str(i)
            if isinstance(v, (dict, list)):
                items.update(_flatten_json(v, new_key, sep))
            else:
                items[new_key] = v
    else:
        items[prefix] = obj
    return items


class LiveBatchLoader:
    """
    Universal loader for CDMLTrain live data batches (ZIP archives).

    Reads a ZIP, parses manifest.json, and returns data in the correct typed format.
    Supports: Images, Audio (MFCC), CSV, JSON (nested), Text
    """

    def __init__(self, zip_path: str):
        """
        Args:
            zip_path: Path to the ZIP file created by live_connector.py
        """
        self.zip_path  = zip_path
        self.manifest  = None
        self._filenames: List[str] = []
        self._type_map: Dict[str, str] = {}

        self._load_manifest()

    # ─── Internal: Read manifest + build index ────────────────────────────────
    def _load_manifest(self):
        try:
            with zipfile.ZipFile(self.zip_path, 'r') as zf:
                all_names = zf.namelist()

                if 'manifest.json' in all_names:
                    with zf.open('manifest.json') as mf:
                        self.manifest = json.loads(mf.read().decode('utf-8'))
                    print(f"[CDML LiveLoader] Manifest found.")
                    print(f"[CDML LiveLoader]   Data types  : {self.manifest.get('data_types_present', [])}")
                    print(f"[CDML LiveLoader]   Total files : {self.manifest.get('total_files', '?')}")

                    for finfo in self.manifest.get('files', []):
                        fname = finfo['filename']
                        # Use manifest type but refine between csv/json/text
                        raw_type = finfo.get('type', 'unknown')
                        # Override with extension-based type for precision
                        detected = _detect_type(fname)
                        ftype = detected if detected != 'unknown' else raw_type
                        self._type_map[fname] = ftype
                        self._filenames.append(fname)
                else:
                    # Fallback: no manifest, detect from extensions
                    print("[CDML LiveLoader] No manifest.json. Auto-detecting types...")
                    for name in all_names:
                        if name == 'manifest.json':
                            continue
                        ftype = _detect_type(name)
                        if ftype != 'unknown':
                            self._type_map[name] = ftype
                            self._filenames.append(name)
                        else:
                            print(f"[CDML LiveLoader] Skipping unknown file: {name}")

        except zipfile.BadZipFile:
            raise ValueError(f"[CDML LiveLoader] Invalid or corrupted ZIP: {self.zip_path}")
        except FileNotFoundError:
            raise FileNotFoundError(f"[CDML LiveLoader] ZIP not found: {self.zip_path}")

    # ─── Public: Summary ──────────────────────────────────────────────────────
    def summary(self) -> dict:
        """Returns a summary dictionary of what's in this batch."""
        counts = {}
        for ftype in self._type_map.values():
            counts[ftype] = counts.get(ftype, 0) + 1
        return {
            "zip_path"        : self.zip_path,
            "total_files"     : len(self._filenames),
            "images"          : counts.get('image', 0),
            "audio_files"     : counts.get('audio', 0),
            "csv_files"       : counts.get('csv', 0),
            "json_files"      : counts.get('json', 0),
            "text_files"      : counts.get('text', 0),
            "manifest_present": self.manifest is not None,
            "tabular_files"   : counts.get('csv', 0) + counts.get('json', 0),
        }

    # ─── Load Images ──────────────────────────────────────────────────────────
    def get_images(self) -> list:
        """
        Returns a list of PIL Image objects (RGB format).
        Requires: pip install Pillow
        """
        if not _HAS_PIL:
            raise ImportError("[CDML LiveLoader] Install Pillow: pip install Pillow")

        images = []
        with zipfile.ZipFile(self.zip_path, 'r') as zf:
            for fname in self._filenames:
                if self._type_map.get(fname) == 'image':
                    try:
                        raw  = zf.read(fname)
                        img  = Image.open(io.BytesIO(raw)).convert('RGB')
                        images.append(img)
                    except Exception as e:
                        print(f"[CDML LiveLoader] Could not decode image '{fname}': {e}")

        print(f"[CDML LiveLoader] Loaded {len(images)} image(s).")
        return images

    # ─── Load Audio (with MFCC feature extraction) ────────────────────────────
    def get_audio(self, n_mfcc: int = 40, as_features: bool = True) -> list:
        """
        Returns audio data from the batch.

        Args:
            n_mfcc     : Number of MFCC coefficients to extract (default: 40)
            as_features: If True (default), returns MFCC numpy arrays.
                         If False, returns raw bytes (no librosa needed).

        Returns:
            List of dicts: [{"filename": ..., "mfcc": np.array, "sr": 22050}, ...]
            OR if as_features=False:
            List of dicts: [{"filename": ..., "raw_bytes": bytes}, ...]

        Requires for features: pip install librosa soundfile numpy
        """
        results = []
        with zipfile.ZipFile(self.zip_path, 'r') as zf:
            for fname in self._filenames:
                if self._type_map.get(fname) != 'audio':
                    continue

                raw = zf.read(fname)

                if not as_features:
                    # Simple mode: just return raw bytes
                    results.append({"filename": fname, "raw_bytes": raw})
                    continue

                if not _HAS_LIBROSA:
                    print(f"[CDML LiveLoader] librosa not found. Returning raw bytes for '{fname}'.")
                    print(f"[CDML LiveLoader]   To enable MFCC features: pip install librosa soundfile")
                    results.append({"filename": fname, "raw_bytes": raw})
                    continue

                if not _HAS_NUMPY:
                    raise ImportError("[CDML LiveLoader] numpy required: pip install numpy")

                try:
                    # Load audio from bytes using librosa
                    audio_buffer = io.BytesIO(raw)
                    y, sr = librosa.load(audio_buffer, sr=None)  # sr=None keeps original sample rate

                    # Extract MFCC features
                    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
                    # Mean across time axis → shape (n_mfcc,) — a single feature vector
                    mfcc_mean = np.mean(mfcc, axis=1)

                    results.append({
                        "filename"   : fname,
                        "mfcc"       : mfcc_mean,      # numpy array shape (n_mfcc,)
                        "mfcc_full"  : mfcc,            # full MFCC matrix
                        "sample_rate": sr,
                        "duration_s" : len(y) / sr,
                    })
                except Exception as e:
                    print(f"[CDML LiveLoader] Could not process audio '{fname}': {e}")
                    results.append({"filename": fname, "raw_bytes": raw})

        print(f"[CDML LiveLoader] Loaded {len(results)} audio file(s).")
        return results

    # ─── Load CSV ─────────────────────────────────────────────────────────────
    def get_csv(self) -> list:
        """
        Returns rows from all CSV files as a flat list of dicts.
        Example: [{"temp": "36.5", "label": "NORMAL"}, ...]
        """
        all_rows = []
        with zipfile.ZipFile(self.zip_path, 'r') as zf:
            for fname in self._filenames:
                if self._type_map.get(fname) != 'csv':
                    continue
                try:
                    raw    = zf.read(fname).decode('utf-8', errors='replace')
                    reader = csv.DictReader(io.StringIO(raw))
                    rows   = [dict(row) for row in reader]
                    all_rows.extend(rows)
                    print(f"[CDML LiveLoader] CSV '{fname}': {len(rows)} row(s).")
                except Exception as e:
                    print(f"[CDML LiveLoader] Could not parse CSV '{fname}': {e}")

        print(f"[CDML LiveLoader] Total CSV rows: {len(all_rows)}")
        return all_rows

    # ─── Load JSON (Full nested support) ──────────────────────────────────────
    def get_json(self, flatten: bool = False) -> list:
        """
        Full JSON support — handles arrays, nested objects, single dicts.

        Args:
            flatten: If True, deeply nested JSON is flattened to a single-level dict.
                     Example: {"sensor": {"temp": 36}} → {"sensor.temp": 36}

        Returns:
            List of parsed objects (dicts or lists).
            Each JSON file yields one item in the list.

        Examples of what this handles:

        # Case 1: JSON Array (most common from APIs)
        [{"id":1,"temp":36},{"id":2,"temp":37}]
        → returns: [{"id":1,"temp":36}, {"id":2,"temp":37}]

        # Case 2: Single dict
        {"machine": "M-001", "status": "OK"}
        → returns: [{"machine": "M-001", "status": "OK"}]

        # Case 3: Deeply nested
        {"sensor": {"gps": {"lat": 28.6, "lng": 77.2}, "temp": 36}}
        → with flatten=True:
           [{"sensor.gps.lat": 28.6, "sensor.gps.lng": 77.2, "sensor.temp": 36}]
        """
        all_parsed = []

        with zipfile.ZipFile(self.zip_path, 'r') as zf:
            for fname in self._filenames:
                if self._type_map.get(fname) != 'json':
                    continue
                try:
                    raw  = zf.read(fname).decode('utf-8', errors='replace')
                    data = json.loads(raw)

                    # ── Handle top-level arrays ──
                    if isinstance(data, list):
                        if flatten:
                            flat_rows = [_flatten_json(item) for item in data]
                            all_parsed.extend(flat_rows)
                        else:
                            all_parsed.extend(data)
                        print(f"[CDML LiveLoader] JSON '{fname}': array of {len(data)} item(s).")

                    # ── Handle top-level dict ──
                    elif isinstance(data, dict):
                        if flatten:
                            all_parsed.append(_flatten_json(data))
                        else:
                            all_parsed.append(data)
                        print(f"[CDML LiveLoader] JSON '{fname}': dict with {len(data)} key(s).")

                    # ── Handle primitives (number, string, bool) ──
                    else:
                        all_parsed.append({"value": data})
                        print(f"[CDML LiveLoader] JSON '{fname}': primitive value.")

                except json.JSONDecodeError as e:
                    print(f"[CDML LiveLoader] Invalid JSON in '{fname}': {e}")
                except Exception as e:
                    print(f"[CDML LiveLoader] Could not parse JSON '{fname}': {e}")

        print(f"[CDML LiveLoader] Total JSON records: {len(all_parsed)}")
        return all_parsed

    # ─── Load Text ────────────────────────────────────────────────────────────
    def get_text(self, clean: bool = True) -> list:
        """
        Returns text data from .txt files.

        Args:
            clean: If True (default), removes empty lines and strips whitespace.

        Returns:
            List of dicts: [{"filename": ..., "lines": [...], "word_count": N}, ...]
        """
        results = []

        with zipfile.ZipFile(self.zip_path, 'r') as zf:
            for fname in self._filenames:
                if self._type_map.get(fname) != 'text':
                    continue
                try:
                    raw   = zf.read(fname).decode('utf-8', errors='replace')
                    lines = raw.split('\n')

                    if clean:
                        lines = [line.strip() for line in lines if line.strip()]

                    words = sum(len(line.split()) for line in lines)

                    results.append({
                        "filename"  : fname,
                        "lines"     : lines,
                        "line_count": len(lines),
                        "word_count": words,
                        "raw_text"  : raw,
                    })
                    print(f"[CDML LiveLoader] Text '{fname}': {len(lines)} line(s), {words} word(s).")
                except Exception as e:
                    print(f"[CDML LiveLoader] Could not read text '{fname}': {e}")

        print(f"[CDML LiveLoader] Loaded {len(results)} text file(s).")
        return results

    # ─── Legacy: get_tabular (CSV + JSON combined) ───────────────────────────
    def get_tabular(self) -> list:
        """
        Legacy method: returns CSV rows + flattened JSON records as a combined list.
        For separate access, use get_csv() or get_json().
        """
        combined = []
        combined.extend(self.get_csv())
        for record in self.get_json(flatten=True):
            if isinstance(record, dict):
                combined.append(record)
        return combined

    # ─── Get Everything at Once ───────────────────────────────────────────────
    def get_all(self) -> dict:
        """
        Returns ALL data types in a single dict:
        {
            "images"  : [PIL Image, ...],
            "audio"   : [{"filename": ..., "mfcc": np.array, ...}, ...],
            "csv"     : [{"col1": "val1", ...}, ...],
            "json"    : [dict or list, ...],
            "text"    : [{"filename": ..., "lines": [...], ...}, ...],
        }
        """
        s = self.summary()
        return {
            "images" : self.get_images()  if s['images']      > 0 else [],
            "audio"  : self.get_audio()   if s['audio_files'] > 0 else [],
            "csv"    : self.get_csv()     if s['csv_files']   > 0 else [],
            "json"   : self.get_json()    if s['json_files']  > 0 else [],
            "text"   : self.get_text()    if s['text_files']  > 0 else [],
        }
