import torch
import torch.nn as nn
import torch.optim as optim

class DifferentiableEncoder(nn.Module):
    """
    Tier 2: Differentiable Learned Compression - Encoder
    Maps raw data space D into a compressed latent space Z.
    """
    def __init__(self, input_dim: int, latent_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        
    def forward(self, x):
        return self.net(x)


class DifferentiableDecoder(nn.Module):
    """
    Tier 2: Differentiable Learned Compression - Decoder
    Reconstructs the original data D from the latent space Z.
    """
    def __init__(self, latent_dim: int, output_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
            nn.Sigmoid() # Assuming normalized inputs
        )
        
    def forward(self, z):
        return self.net(z)


class NeuralCompressor(nn.Module):
    """
    Combines Encoder and Decoder for joint training.
    """
    def __init__(self, input_dim: int, latent_dim: int):
        super().__init__()
        self.encoder = DifferentiableEncoder(input_dim, latent_dim)
        self.decoder = DifferentiableDecoder(latent_dim, input_dim)
        
    def forward(self, x):
        z = self.encoder(x)
        reconstructed = self.decoder(z)
        return reconstructed, z


def train_jointly(compressor: NeuralCompressor, task_model: nn.Module, 
                 dataloader, epochs: int, alpha: float = 0.5, beta: float = 0.5):
    """
    Trains the compressor and a downstream task model jointly.
    
    L = α · ||D - D̂||² + β · L_task(ŷ, y)
    """
    optimizer = optim.Adam(
        list(compressor.parameters()) + list(task_model.parameters()), 
        lr=1e-3
    )
    mse_loss = nn.MSELoss()
    task_criterion = nn.CrossEntropyLoss()
    
    compressor.train()
    task_model.train()
    
    for epoch in range(epochs):
        for inputs, targets in dataloader:
            optimizer.zero_grad()
            
            # 1. Forward pass through compressor
            # z is the latent compressed code
            reconstructed, z = compressor(inputs)
            
            # 2. Forward pass through downstream task model (using reconstructed or z)
            # Typically task model trains on reconstructed or directly on latent space
            preds = task_model(reconstructed)
            
            # 3. Calculate Joint Loss
            loss_compression = mse_loss(reconstructed, inputs)
            loss_task = task_criterion(preds, targets)
            
            total_loss = (alpha * loss_compression) + (beta * loss_task)
            
            # 4. Backward & Step
            total_loss.backward()
            optimizer.step()
            
    return compressor, task_model
