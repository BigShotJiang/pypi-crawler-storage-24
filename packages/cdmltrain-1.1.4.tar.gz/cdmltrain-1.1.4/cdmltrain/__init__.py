from .dataset import CDMLStreamDataset
from .core import CoreStreamEngine
from .tier2_differentiable import NeuralCompressor, train_jointly
from .tier3_cda import CompressedDomainAlgebra
from .tier2_complete import (CDMLTrainTier2, CDMLLoss, CDMLEncoder,
                              CDMLDecoder, CDMLClassifier, CDMLTrainer,
                              CDMLTrainerDDP, make_ddp_loaders)
from .tier2_multimodal import (AudioEncoder, AudioDecoder,
                                TabularEncoder, TabularDecoder,
                                TimeSeriesEncoder, TimeSeriesDecoder,
                                MultiModalLoss, MultiModalTrainer)

__all__ = [
    # Tier 1 — Streaming
    "CDMLStreamDataset", "CoreStreamEngine",
    # Tier 2 — Original
    "NeuralCompressor", "train_jointly",
    # Tier 2 — Production (single GPU)
    "CDMLTrainTier2", "CDMLLoss", "CDMLEncoder",
    "CDMLDecoder", "CDMLClassifier", "CDMLTrainer",
    # Tier 2 — Multi-GPU DDP
    "CDMLTrainerDDP", "make_ddp_loaders",
    # Tier 2 — Multi-Modal (Audio, Tabular, Time-Series)
    "AudioEncoder", "AudioDecoder",
    "TabularEncoder", "TabularDecoder",
    "TimeSeriesEncoder", "TimeSeriesDecoder",
    "MultiModalLoss", "MultiModalTrainer",
    # Tier 3 — Theory
    "CompressedDomainAlgebra",
]
