import os
import json
import torch
from datetime import datetime
import glob

def save_smart_checkpoint(model, save_dir="model_checkpoints", file_prefix="model", max_backups=5):
    """
    Saves the model weights with a timestamp and deletes older backups to prevent disk overflow.
    This approach prevents catastrophic forgetting.
    Every version is saved, and old ones are automatically deleted.
    Smart checkpoint = last N models always safe.

    Args:
        model: PyTorch model object.
        save_dir (str): Folder to save the checkpoints.
        file_prefix (str): Prefix for the saved files (e.g. 'dogcat_model').
        max_backups (int): Maximum number of past versions to keep.
    """
    os.makedirs(save_dir, exist_ok=True)
    
    # 1. Create new timestamped filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{file_prefix}_{timestamp}.pth"
    filepath = os.path.join(save_dir, filename)
    
    # 2. Save the model
    torch.save(model.state_dict(), filepath)
    print(f"  [SAVED] Smart Version Record -> {filepath}")
    
    # 3. Auto-Cleanup (Queue / FIFO logic)
    search_pattern = os.path.join(save_dir, f"{file_prefix}_*.pth")
    # Sort by file creation/modification time
    existing_files = sorted(glob.glob(search_pattern), key=os.path.getmtime)
    
    if len(existing_files) > max_backups:
        files_to_delete = existing_files[:-max_backups]
        for old_file in files_to_delete:
            try:
                os.remove(old_file)
                print(f"  [CLEANUP] Deleted old version -> {os.path.basename(old_file)}")
            except Exception as e:
                print(f"  [WARNING] Could not delete old version: {e}")



def log_metrics(loss_val, avg_confidence, filepath="metrics.json"):
    """
    Logs training metrics (Loss and Confidence) to a JSON file.
    Gives visibility into whether the model is getting better or suffering from catastrophic forgetting.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    record = {
        "timestamp": timestamp,
        "loss": round(loss_val, 4),
        "avg_confidence": round(avg_confidence * 100, 2)
    }
    
    # Read existing or create new
    data = []
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
        except (json.JSONDecodeError, IOError, ValueError):
            data = []
            
    data.append(record)
    
    # Write back
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=4)

