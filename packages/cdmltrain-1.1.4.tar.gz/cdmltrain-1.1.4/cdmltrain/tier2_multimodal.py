"""
CDMLTrain — Tier 2 Multi-Modal Extension
=========================================
Extends Tier 2 Neural Compression beyond images to ALL data types:

  Model            Use Case
  ─────────────────────────────────────────────────────────
  AudioEncoder     Smart speakers, voice commands, earbuds
  TabularEncoder   Device telemetry logs, sensor CSVs
  TimeSeriesEncoder Wearable data, IoT sensors, temperature

All encoders share the same CDMLLoss (task + reconstruction + bottleneck)
and the same MultiModalTrainer API — making CDMLTrain a universal
"Data Acceleration Layer for Device Intelligence".

from cdmltrain import AudioEncoder, TabularEncoder, TimeSeriesEncoder
"""

import torch
import torch.nn as nn
from typing import Tuple, Dict, Optional


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  1. AUDIO ENCODER / DECODER  (1D CNN)                               ║
# ║  Input: (batch, 1, samples) — raw waveform or audio frame           ║
# ╚══════════════════════════════════════════════════════════════════════╝
class AudioEncoder(nn.Module):
    """
    1D CNN Encoder: Raw Audio → Latent Code Z

    Captures temporal patterns (rhythms, frequencies, phonemes) via
    1D convolutions — same principle as image CNN but on time axis.

    Use Cases:
      - Smart speaker / earbuds command recognition datasets
      - Industrial machine fault detection via vibration audio
      - Voice model training at scale
    """
    def __init__(self, latent_dim: int = 128, in_channels: int = 1,
                 input_length: int = 16000):
        super().__init__()
        self.latent_dim = latent_dim

        self.conv = nn.Sequential(
            # Block 1: 1 × 16000 → 32 × 4000
            nn.Conv1d(in_channels, 32, kernel_size=8, stride=4, padding=2),
            nn.BatchNorm1d(32), nn.ReLU(inplace=True),
            # Block 2: 32 × 4000 → 64 × 1000
            nn.Conv1d(32, 64, kernel_size=8, stride=4, padding=2),
            nn.BatchNorm1d(64), nn.ReLU(inplace=True),
            nn.Dropout(0.1),
            # Block 3: 64 × 1000 → 128 × 250
            nn.Conv1d(64, 128, kernel_size=4, stride=4, padding=0),
            nn.BatchNorm1d(128), nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool1d(32),  # → 128 × 32 (size-agnostic)
        )
        self.fc = nn.Sequential(
            nn.Flatten(),            # 128 × 32 = 4096
            nn.Linear(4096, 512), nn.ReLU(inplace=True), nn.Dropout(0.3),
            nn.Linear(512, latent_dim)   # ← BOTTLENECK
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc(self.conv(x))


class AudioDecoder(nn.Module):
    """Reconstructs audio waveform from latent Z for trust verification."""
    def __init__(self, latent_dim: int = 128, out_channels: int = 1,
                 output_length: int = 16000):
        super().__init__()
        self.output_length = output_length
        self.net = nn.Sequential(
            nn.Linear(latent_dim, 512), nn.ReLU(inplace=True),
            nn.Linear(512, 4096), nn.ReLU(inplace=True),
            nn.Linear(4096, output_length), nn.Tanh()
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        out = self.net(z)
        return out.unsqueeze(1)  # (batch, 1, output_length)


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  2. TABULAR / TEXT ENCODER  (MLP)                                    ║
# ║  Input: (batch, input_features) — CSV rows, log vectors             ║
# ╚══════════════════════════════════════════════════════════════════════╝
class TabularEncoder(nn.Module):
    """
    MLP Encoder: Tabular / Text Features → Latent Code Z

    Works on flat feature vectors. Ideal for structured data that has
    already been tokenized or numerically encoded (e.g., via TF-IDF,
    label encoding, or standard feature engineering).

    Use Cases:
      - Device telemetry failure logs (temperature, voltage, etc.)
      - Retail / personalization feature tables
      - Sensor CSV datasets from IoT devices
      - Pre-tokenized text embeddings
    """
    def __init__(self, input_dim: int, latent_dim: int = 128):
        super().__init__()
        self.latent_dim = latent_dim
        hidden = min(max(input_dim * 2, 256), 1024)  # auto-scale hidden size

        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden),
            nn.BatchNorm1d(hidden), nn.ReLU(inplace=True), nn.Dropout(0.2),
            nn.Linear(hidden, 256),
            nn.BatchNorm1d(256), nn.ReLU(inplace=True), nn.Dropout(0.2),
            nn.Linear(256, latent_dim)   # ← BOTTLENECK
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class TabularDecoder(nn.Module):
    """Reconstructs original feature vector from latent Z."""
    def __init__(self, latent_dim: int = 128, output_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(latent_dim, 256), nn.ReLU(inplace=True),
            nn.Linear(256, output_dim)
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  3. TIME-SERIES / TELEMETRY ENCODER  (LSTM)                         ║
# ║  Input: (batch, timesteps, features) — sequences                    ║
# ╚══════════════════════════════════════════════════════════════════════╝
class TimeSeriesEncoder(nn.Module):
    """
    LSTM Encoder: Sequential Data → Latent Code Z

    Captures temporal dynamics (trends, cycles, anomalies) using an LSTM,
    which remembers long-term dependencies in sequences.

    Use Cases:
      - Wearable health sensors (heart rate, SpO2 sequences)
      - Industrial IoT temperature / pressure streams
      - Device failure prediction from time-ordered sensor logs
      - Smart home energy usage patterns
    """
    def __init__(self, input_features: int, latent_dim: int = 128,
                 hidden_size: int = 256, num_layers: int = 2):
        super().__init__()
        self.latent_dim = latent_dim
        self.lstm = nn.LSTM(
            input_size=input_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.2 if num_layers > 1 else 0.0
        )
        self.fc = nn.Sequential(
            nn.Linear(hidden_size, latent_dim),   # ← BOTTLENECK
            nn.Tanh()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, timesteps, features)
        _, (h_n, _) = self.lstm(x)
        last_hidden = h_n[-1]   # Top-layer final hidden state
        return self.fc(last_hidden)


class TimeSeriesDecoder(nn.Module):
    """Reconstructs time-series from latent Z (simplified MLP decoder)."""
    def __init__(self, latent_dim: int = 128, timesteps: int = 50,
                 features: int = 8):
        super().__init__()
        self.timesteps = timesteps
        self.features = features
        self.net = nn.Sequential(
            nn.Linear(latent_dim, 256), nn.ReLU(inplace=True),
            nn.Linear(256, timesteps * features), nn.Tanh()
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        out = self.net(z)
        return out.view(-1, self.timesteps, self.features)


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  4. UNIVERSAL MULTIMODAL LOSS                                        ║
# ╚══════════════════════════════════════════════════════════════════════╝
class MultiModalLoss(nn.Module):
    """
    Same 3-component CDMLLoss logic but works for all modalities:
      L = alpha * L_task + beta * L_recon + gamma * L_bottleneck
    """
    def __init__(self, alpha: float = 1.0, beta: float = 0.5,
                 gamma: float = 0.01):
        super().__init__()
        self.alpha, self.beta, self.gamma = alpha, beta, gamma
        self.ce  = nn.CrossEntropyLoss()
        self.mse = nn.MSELoss()

    def forward(self, logits, x_recon, z, x_original, labels
                ) -> Tuple[torch.Tensor, Dict]:
        L_task       = self.ce(logits, labels)
        L_recon      = self.mse(x_recon, x_original)
        L_bottleneck = torch.mean(torch.abs(z))
        L_total      = (self.alpha * L_task + self.beta * L_recon
                        + self.gamma * L_bottleneck)
        return L_total, {'task': L_task.item(), 'recon': L_recon.item(),
                         'bottleneck': L_bottleneck.item(),
                         'total': L_total.item()}


# ╔══════════════════════════════════════════════════════════════════════╗
# ║  5. UNIVERSAL MULTIMODAL TRAINER                                     ║
# ║  Works identically for image / audio / tabular / time-series        ║
# ╚══════════════════════════════════════════════════════════════════════╝
class MultiModalTrainer:
    """
    Unified trainer: plug in ANY encoder, decoder, and classifier.
    Same 3-step loop regardless of data modality:
      1. Encode input → z
      2. Decode z → reconstruction
      3. Classify z → label

    Usage:
      enc = AudioEncoder(latent_dim=128)
      dec = AudioDecoder(latent_dim=128)
      clf = nn.Linear(128, num_classes)
      trainer = MultiModalTrainer(enc, dec, clf)
      trainer.fit(train_loader, epochs=10)
    """
    def __init__(self, encoder: nn.Module, decoder: nn.Module,
                 classifier: nn.Module, lr: float = 1e-3,
                 alpha: float = 1.0, beta: float = 0.5,
                 gamma: float = 0.01):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.encoder    = encoder.to(self.device)
        self.decoder    = decoder.to(self.device)
        self.classifier = classifier.to(self.device)
        self.criterion  = MultiModalLoss(alpha, beta, gamma)
        params = (list(encoder.parameters()) +
                  list(decoder.parameters()) +
                  list(classifier.parameters()))
        self.optimizer = torch.optim.Adam(params, lr=lr, weight_decay=1e-4)

    def fit(self, loader, epochs: int = 10, verbose: bool = True
            ) -> Dict[str, list]:
        history = {'loss': [], 'accuracy': []}
        for ep in range(1, epochs + 1):
            self.encoder.train()
            self.decoder.train()
            self.classifier.train()
            total_loss, correct, total = 0.0, 0, 0

            for x_batch, y_batch in loader:
                x_batch = x_batch.to(self.device)
                y_batch = y_batch.to(self.device)

                self.optimizer.zero_grad()
                z       = self.encoder(x_batch)
                x_recon = self.decoder(z)
                logits  = self.classifier(z)
                loss, _ = self.criterion(logits, x_recon, z, x_batch, y_batch)
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item()
                correct    += (logits.argmax(1) == y_batch).sum().item()
                total      += len(y_batch)

            acc = 100.0 * correct / total
            avg_loss = total_loss / len(loader)
            history['loss'].append(avg_loss)
            history['accuracy'].append(acc)

            if verbose:
                print(f"  Ep {ep:2d}/{epochs} | Loss: {avg_loss:.4f} | Acc: {acc:.1f}%")

        return history
