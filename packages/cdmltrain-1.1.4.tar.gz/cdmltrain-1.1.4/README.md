# cdmltrain 🚀

**Stream ML datasets directly from compressed archives into PyTorch — zero disk extraction, zero storage waste.**

[![Python 3.7+](https://img.shields.io/badge/Python-3.7%2B-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![PyPI](https://img.shields.io/badge/PyPI-cdmltrain-orange.svg)](https://pypi.org/project/cdmltrain/)

---

## 🔥 The Business Problem

Every data-driven company hits the same infrastructure wall:

| Problem | Impact |
|---------|--------|
| **100 GB dataset arrives as a ZIP** | Extracting takes **2+ hours** and needs **300 GB free disk** |
| **Edge/IoT devices** generate data 24/7 | Camera footage, sensor logs, audio feeds pile up — **storage costs explode** |
| **Factory/Warehouse AI** needs real-time inference | Traditional pipelines can't process live streams fast enough |
| **Cloud costs** scale linearly with data | Every GB stored and transferred = recurring cost |
| **Colab/Kaggle notebooks** crash | Free-tier disk + RAM limits make large datasets unusable |

### 💰 The Cost of Doing Nothing

```
A factory running 10 cameras at 1080p:
  → 50 GB/day raw data
  → Traditional: Extract + Store + Process = 150 GB/day disk usage
  → With cdmltrain: Process directly from archive = 0 GB extra disk

Annual savings: ~55 TB storage × $0.023/GB (S3) = $1,265/year per factory
                + 70% reduction in data pipeline processing time
```

### ✅ What cdmltrain Does

**cdmltrain eliminates this problem entirely.** It lets PyTorch read images, audio, text, CSV, JSON — any data — **directly from compressed archives into RAM**, skipping disk extraction completely.

---

## ✨ Key Features

| Feature | Description |
|---------|-------------|
| 🗜️ **Zero-Extraction Streaming** | Read data directly from ZIP/ZSTD/S3 — no disk writes |
| 📸🎤📊📄 **Multi-Modal Support** | Images, Audio, CSV/JSON, Text — all from one archive |
| ⚡ **Live Data Pipeline** | Camera/sensor → ZIP → AI model in real-time |
| 🔒 **Thread-Safe** | Works with PyTorch `DataLoader(num_workers=N)` |
| 💾 **Memory-Safe Cache** | Bounded LRU cache prevents OOM crashes |
| 🖥️ **GPU Direct Loading** | Stream from archive → CUDA VRAM (pinned memory) |
| ☁️ **S3 Cloud Streaming** | Read from `s3://bucket/data.zip` — zero local download |
| 🏗️ **Neural Compression (Tier 2)** | CNN autoencoder for compressed-domain classification |
| 🔀 **Multi-GPU DDP** | Distributed training across multiple GPUs |
| 🧠 **Compressed Domain Algebra** | Theoretical framework for operations in compressed space |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        DATA SOURCES                             │
├──────────────┬──────────────┬──────────────┬────────────────────┤
│  Local .zip  │  .tar.zst    │  S3 Cloud    │  Live Camera/IoT   │
└──────┬───────┴──────┬───────┴──────┬───────┴────────┬───────────┘
       │              │              │                │
       ▼              ▼              ▼                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    cdmltrain ENGINE                              │
├─────────────┬──────────────┬──────────────┬─────────────────────┤
│  Tier 1     │  Tier 2      │  Tier 3      │  Tier 4             │
│  Python     │  C++ Pybind  │  ZSTD + GPU  │  S3 Cloud           │
│  Core       │  FastCore    │  Direct      │  Streaming           │
└─────────────┴──────────────┴──────────────┴─────────────────────┘
       │              │              │                │
       ▼              ▼              ▼                ▼
┌─────────────────────────────────────────────────────────────────┐
│              PyTorch DataLoader / Model Training                 │
└─────────────────────────────────────────────────────────────────┘
```

The library **auto-detects** your hardware and data location, then picks the best engine tier. Same API always.

---

## 📦 Installation

```bash
# Core (works everywhere)
pip install cdmltrain

# With ZSTD support (25x faster decompression)
pip install cdmltrain[zstd]

# With AWS S3 Cloud Streaming
pip install cdmltrain[s3]

# Everything
pip install cdmltrain[full]

# Or from source:
git clone https://github.com/prem85642/cdmltrain.git
cd cdmltrain
pip install .
```

---

## 🚀 Quick Start

### Basic Usage (ZIP — Any Data Type)

```python
from cdmltrain import CDMLStreamDataset
from torch.utils.data import DataLoader

dataset = CDMLStreamDataset("training_data.zip")
loader  = DataLoader(dataset, batch_size=32, num_workers=4)

for batch in loader:
    raw_bytes = batch       # Process however you need
    print(f"Batch loaded: {len(batch)} items")
```

### Image Dataset (with PyTorch Transforms)

```python
from torchvision import transforms

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

dataset = CDMLStreamDataset("images.zip", is_image=True, transform=transform)
loader  = DataLoader(dataset, batch_size=64, shuffle=True, num_workers=4)

for images in loader:
    predictions = model(images)   # Direct to model — no disk extraction!
```

### ZSTD Archive (25x Faster Decompression) ⚡

```python
dataset = CDMLStreamDataset("data.tar.zst")   # Auto-detects ZSTD
# Everything else is identical — same API
```

### S3 Cloud Streaming (Zero Download) ☁️

```python
dataset = CDMLStreamDataset("s3://my-bucket/dataset.zip")
# Reads via byte-range HTTP requests — never downloads the full file
```

---

## 🛠️ Step-by-Step: How to Use

If you are new to `cdmltrain`, here is the exact step-by-step process to get your data flowing without disk extraction.

### Step 1: Zip Your Data
Instead of keeping thousands of loose files (`.jpg`, `.csv`, etc.) in a folder, simply zip them up. 
*   **Locally:** Right-click folder → Compress to ZIP.
*   **Or using Python:** `shutil.make_archive("my_data", "zip", "data_folder")`

### Step 2: Initialize the Dataset
In your PyTorch training script, replace your old dataset class with `CDMLStreamDataset`.

```python
from cdmltrain import CDMLStreamDataset

# Just point it to the ZIP file!
dataset = CDMLStreamDataset(
    path="my_data.zip", 
    is_image=True,             # Set to True if the ZIP contains images
    cache_size_mb=100          # Keeps 100MB of recently used data in RAM
)
```

### Step 3: Pass to PyTorch DataLoader
Use PyTorch's native `DataLoader` exactly as you normally would.

```python
from torch.utils.data import DataLoader

# num_workers=4 will read from the ZIP in parallel beautifully
loader = DataLoader(dataset, batch_size=32, shuffle=True, num_workers=4)
```

### Step 4: Train!
Iterate over the loader. The data is pulled directly from the ZIP file into memory, bypassing your hard drive entirely.

```python
for epoch in range(10):
    for batch_images in loader:
        # batch_images is a standard PyTorch tensor!
        loss = model(batch_images)
        loss.backward()
        optimizer.step()
```

---

## 📸 Live Data Pipeline (Edge/IoT)

cdmltrain includes a complete **live data ingestion system** for real-time AI inference at the edge:

```
Camera/Sensor → live_input/ folder → Auto-ZIP → AI Model → Result
     ↓                                    ↓
  Continuous          CDMLTrain handles    Predictions in
  data stream         everything           real-time
```

### How It Works

```python
from live_connector import watch_and_pack
from cdmltrain.live_loader import LiveBatchLoader

# 1. Your callback processes each batch
def on_new_batch(zip_path):
    loader = LiveBatchLoader(zip_path)

    images = loader.get_images()        # PIL Images ready for model
    audio  = loader.get_audio(n_mfcc=20)  # MFCC features extracted
    sensor = loader.get_tabular()       # CSV rows as dicts
    logs   = loader.get_text()          # Text files parsed

    for img in images:
        prediction = model(transform(img))
        print(f"Prediction: {prediction}")

# 2. Start monitoring — automatically packs & processes
watch_and_pack(
    input_folder="live_input",           # Camera drops files here
    output_folder="live_batches",        # Temporary ZIP storage
    on_batch_ready=on_new_batch,         # Your processing callback
    interval_seconds=10,                 # Scan every 10 seconds
    auto_delete=True                     # Clean up after processing
)
```

### Zero-Disk Mode (Ultra-Fast)

For maximum speed, skip ZIP creation entirely — process files the instant they appear:

```python
from live_connector import watch_in_memory

def process_instantly(filepath, data_type):
    if data_type == 'image':
        img = Image.open(filepath)
        result = model(transform(img))
    elif data_type == 'audio':
        # Process audio in real-time
        pass

watch_in_memory("live_input", process_instantly)
# Uses OS-level file watching (Watchdog) — sub-second latency
```

### Supported Live Data Types

| Type | Extensions | What You Get |
|------|-----------|-------------|
| 📸 Images | `.jpg`, `.png`, `.bmp`, `.tiff` | PIL Image objects |
| 🎤 Audio | `.wav`, `.mp3`, `.flac`, `.ogg` | MFCC features or raw waveform |
| 📊 Tabular | `.csv` | List of row dictionaries |
| 📋 JSON | `.json` | Parsed Python objects |
| 📄 Text | `.txt` | Lines + word count |

---

## 🧠 Neural Compression (Tier 2)

Train models that classify directly from compressed representations — never decompressing to raw pixels:

```python
from cdmltrain import CDMLTrainTier2, CDMLLoss, CDMLTrainer

# Initialize autoencoder (48:1 compression ratio)
model = CDMLTrainTier2(latent_dim=64, num_classes=10)

# Train with joint optimization
trainer = CDMLTrainer(model, lr=0.001)
trainer.train(train_loader, epochs=20)

# Inference: classify from compressed code only
z = model.compress(image_batch)          # 3072D → 64D
logits = model.classifier(z)            # 64D → 10 classes
```

### Multi-Modal Encoders

```python
from cdmltrain import AudioEncoder, TabularEncoder, TimeSeriesEncoder

# Audio: Raw waveform → latent code
audio_enc = AudioEncoder(latent_dim=64)
z_audio = audio_enc(waveform)            # [B, 1, 16000] → [B, 64]

# Tabular: Feature vector → latent code
tab_enc = TabularEncoder(input_dim=20, latent_dim=64)
z_tab = tab_enc(features)               # [B, 20] → [B, 64]

# Time Series: Sequential data → latent code
ts_enc = TimeSeriesEncoder(input_features=8, latent_dim=64)
z_ts = ts_enc(sequence)                 # [B, 50, 8] → [B, 64]
```

---

## 🏭 Real-World Use Cases

| Industry | Use Case | How cdmltrain Helps |
|----------|----------|-------------------|
| **Manufacturing** | Quality inspection via camera | Live pipeline: camera → defect detection in real-time |
| **Healthcare** | Medical image analysis | Stream DICOM archives directly — no 100 GB extraction |
| **Logistics** | Warehouse monitoring | Multi-camera + sensor fusion from compressed streams |
| **Agriculture** | Drone crop analysis | Process aerial imagery from ZSTD archives at 25x speed |
| **Retail** | Customer behavior analytics | Stream surveillance footage directly to behavior models |
| **IoT/Edge** | Predictive maintenance | Sensor CSV + audio anomaly detection from live feeds |

---

## 📊 Benchmarks

### ZSTD vs ZIP Speed (200 files × 10KB)

| Metric | ZIP (Deflate) | ZSTD | Speedup |
|--------|:---:|:---:|:---:|
| Decompression | 0.42s | 0.08s | **5.2x** |
| First-batch latency | 120ms | 22ms | **5.4x** |
| Memory overhead | Moderate | Low | **~40% less** |

### Memory-Safe Cache Performance

| RAM Limit | Dataset Size | OOM Crashes | Cache Hit Rate |
|-----------|:---:|:---:|:---:|
| 50 MB | 2 GB | **0** | 94% |
| 200 MB | 10 GB | **0** | 97% |
| No cache | 2 GB | ❌ Crash | N/A |

---

## ⚙️ Configuration

```python
CDMLStreamDataset(
    path="data.zip",           # ZIP, .tar.zst, or s3:// path
    is_image=False,            # True → auto-decode as PIL Image
    transform=None,            # torchvision transforms (for images)
    cache_size_mb=50,          # LRU cache size (memory-safe)
    target_size=(224, 224),    # Resize images on load
)
```

---

## 📁 Project Structure

```
cdmltrain/
├── cdmltrain/                    # Core library
│   ├── __init__.py               # Package entry point
│   ├── core.py                   # Tier 1: Python CoreStreamEngine
│   ├── dataset.py                # CDMLStreamDataset (auto-tier selection)
│   ├── gpu_loader.py             # GPU Direct Loader (CUDA pinned memory)
│   ├── s3_engine.py              # Tier 4: S3 Cloud Streaming
│   ├── zstd_engine.py            # Tier 3: ZSTD fast decompression
│   ├── live_loader.py            # Multi-modal live batch loader
│   ├── tier2_complete.py         # Neural compression autoencoder
│   ├── tier2_multimodal.py       # Audio / Tabular / TimeSeries encoders
│   ├── tier2_differentiable.py   # Differentiable compression primitives
│   ├── tier3_cda.py              # Compressed Domain Algebra
│   ├── utils.py                  # Smart checkpointing & metrics
│   ├── cli.py                    # CLI archive scanner
│   └── src/fast_core.cpp         # Tier 2: C++ Pybind11 engine
├── live_connector.py             # Live edge data connector
├── demo.py                       # Quick demo script
├── quickstart.ipynb              # Jupyter tutorial
├── setup.py                      # Package configuration
├── requirements.txt              # Dependencies
└── LICENSE                       # MIT License
```

---

## 🖥️ OS Compatibility

| OS | Status | Notes |
|----|--------|-------|
| ✅ Windows 10/11 | Full support | C++ extension needs Visual C++ Build Tools |
| ✅ Linux (Ubuntu, CentOS) | Full support | `pip install .` works out of the box |
| ✅ macOS | Full support | `pip install .` works out of the box |
| ✅ Google Colab | Full support | `!pip install cdmltrain` |
| ✅ Kaggle Notebooks | Full support | Tested with large datasets |

---

## 🛠️ Troubleshooting

| Error | Fix |
|-------|-----|
| `ModuleNotFoundError: No module named 'cdmltrain'` | `pip install cdmltrain` |
| `ModuleNotFoundError: No module named 'zstandard'` | `pip install zstandard` |
| `Microsoft Visual C++ 14.0 required` | Install [Visual C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) or skip — pure Python works |
| `Out of Memory` | Reduce `cache_size_mb` parameter |
| `Bad CRC-32 error` | Archive is corrupted — re-download |

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

**Made with ❤️ for the ML community — because your model matters more than your storage bill.**
