# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "FetchResponse",
    "Data",
    "DataResponse",
    "DataCaptureTelemetry",
    "DataLink",
    "DataMeta",
    "DataMetaIcon",
    "DataMetaOpenGraph",
    "DataMetaOpenGraphImage",
    "DataMetaTwitter",
    "DataRenderEngines",
    "DataScreenshot",
    "DataSnippet",
    "DataSnippetUnionMember0",
    "DataSnippetUnionMember1",
]


class DataResponse(BaseModel):
    """HTTP response information (URL, optionally origin status code)"""

    url: str
    """The final URL after any redirects"""

    headers: Optional[Dict[str, str]] = None
    """
    Response headers from the fetch operation (keys are lower-cased HTTP header
    names)
    """

    origin_status_code: Optional[float] = FieldInfo(alias="originStatusCode", default=None)
    """HTTP status code returned by the origin website.

    Absent when the fetch is still pending or the origin response could not be
    determined.
    """

    redirect_status_code: Optional[float] = FieldInfo(alias="redirectStatusCode", default=None)
    """HTTP status code of the redirect response (e.g.

    301, 302). Present only when a redirect occurred.
    """

    requested_url: Optional[str] = FieldInfo(alias="requestedUrl", default=None)
    """a string to be decoded into a URL"""


class DataCaptureTelemetry(BaseModel):
    """
    Snapshot capture telemetry describing request intent, rollout selection, and actual execution path
    """

    actual: Literal["typescript", "rust"]
    """
    Snapshot capture engine that actually produced the response after fallback
    handling
    """

    rollout_applied: bool = FieldInfo(alias="rolloutApplied")
    """
    Whether server-side rollout selected Rust capture without an explicit caller
    override
    """

    selected: Literal["typescript", "rust"]
    """
    Snapshot capture engine selected before runtime availability checks and
    execution fallback
    """

    actual_style_mode: Optional[Literal["compat_full", "native_default"]] = FieldInfo(
        alias="actualStyleMode", default=None
    )
    """Rust capture style mode actually used by the response"""

    prepared_session_hit: Optional[bool] = FieldInfo(alias="preparedSessionHit", default=None)
    """Whether Rust capture reused a prewarmed Chromium session"""

    requested: Optional[Literal["typescript", "rust"]] = None
    """Explicit snapshot capture engine requested by the caller, if any"""

    requested_style_mode: Optional[Literal["compat_full", "native_default"]] = FieldInfo(
        alias="requestedStyleMode", default=None
    )
    """Explicit Rust capture style mode requested by the caller, if any"""


class DataLink(BaseModel):
    """A link extracted from the page"""

    url: str
    """The URL of the link"""

    text: Optional[str] = None
    """The anchor text of the link"""


class DataMetaIcon(BaseModel):
    """Favicon or app icon metadata from <link> tags"""

    href: str
    """Icon URL or path"""

    rel: str
    """Link relationship type"""

    sizes: Optional[str] = None
    """Icon dimensions"""

    type: Optional[str] = None
    """MIME type of the icon"""


class DataMetaOpenGraphImage(BaseModel):
    """Open Graph image with optional dimensions and alt text"""

    url: str
    """Image URL"""

    alt: Optional[str] = None
    """Image alt text for accessibility"""

    height: Optional[float] = None
    """Image height in pixels"""

    width: Optional[float] = None
    """Image width in pixels"""


class DataMetaOpenGraph(BaseModel):
    """Open Graph protocol metadata for rich link previews"""

    description: Optional[str] = None
    """Open Graph description (og:description)"""

    images: Optional[List[DataMetaOpenGraphImage]] = None
    """Open Graph images (og:image and related properties)"""

    locale: Optional[str] = None
    """Locale in language_TERRITORY format (og:locale)"""

    site_name: Optional[str] = FieldInfo(alias="siteName", default=None)
    """Site name (og:site_name)"""

    title: Optional[str] = None
    """Open Graph title (og:title)"""

    type: Optional[str] = None
    """Open Graph type (og:type) - website, article, product, etc."""

    url: Optional[str] = None
    """Canonical URL for the content (og:url)"""


class DataMetaTwitter(BaseModel):
    """Twitter Card metadata for social sharing previews"""

    card: Optional[str] = None
    """Twitter card type (twitter:card)"""

    creator: Optional[str] = None
    """Twitter @username of content creator (twitter:creator)"""

    description: Optional[str] = None
    """Description for Twitter card (twitter:description)"""

    image: Optional[str] = None
    """Image URL for Twitter card (twitter:image)"""

    site: Optional[str] = None
    """Twitter @username of the website (twitter:site)"""

    title: Optional[str] = None
    """Title for Twitter card (twitter:title)"""


class DataMeta(BaseModel):
    """Comprehensive metadata extracted from the page HTML head section"""

    canonical_url: Optional[str] = FieldInfo(alias="canonicalUrl", default=None)
    """Canonical URL from <link rel="canonical">"""

    charset: Optional[str] = None
    """Character encoding from <meta charset="...">"""

    description: Optional[str] = None
    """Meta description from <meta name="description">"""

    favicon: Optional[str] = None
    """Primary favicon URL (first icon found)"""

    icons: Optional[List[DataMetaIcon]] = None
    """All icon links (favicons, apple-touch-icons, etc.)"""

    language: Optional[str] = None
    """Page language from <html lang="...">"""

    open_graph: Optional[DataMetaOpenGraph] = FieldInfo(alias="openGraph", default=None)
    """Open Graph protocol metadata for rich link previews"""

    title: Optional[str] = None
    """Page title from <title> tag"""

    twitter: Optional[DataMetaTwitter] = None
    """Twitter Card metadata for social sharing previews"""


class DataRenderEngines(BaseModel):
    """Rendering engines actually used to produce this response"""

    capture: Optional[Literal["typescript", "rust"]] = None
    """Actual snapshot capture engine used for this response"""

    markdown: Optional[Literal["typescript", "rust"]] = None
    """Actual markdown renderer used for this response"""

    tree: Optional[Literal["typescript", "rust"]] = None
    """Actual tree renderer used for this response"""


class DataScreenshot(BaseModel):
    """Screenshot of the fetched page"""

    full_page: bool = FieldInfo(alias="fullPage")
    """Whether the screenshot captures the full scrollable page or just the viewport"""

    url: str
    """Presigned URL for the screenshot image"""


class DataSnippetUnionMember0(BaseModel):
    api_tag: Literal["MarkdownSnippet"] = FieldInfo(alias="_tag")

    index: float
    """Original chunk index"""

    score: float
    """Relevance score from the reranker (0-1)"""

    text: str
    """The text content of the snippet"""

    type: Optional[Literal["text"]] = None
    """Type identifier for TextPart compatibility"""


class DataSnippetUnionMember1(BaseModel):
    api_tag: Literal["JsonSnippet"] = FieldInfo(alias="_tag")

    index: float
    """Original chunk index"""

    json_: object = FieldInfo(alias="json")
    """The structured JSON subtree value"""

    score: float
    """Relevance score from the reranker (0-1)"""

    text: str
    """Pretty-printed JSON chunk text"""

    type: Optional[Literal["text"]] = None
    """Type identifier for TextPart compatibility"""


DataSnippet: TypeAlias = Union[DataSnippetUnionMember0, DataSnippetUnionMember1]


class Data(BaseModel):
    response: DataResponse
    """HTTP response information (URL, optionally origin status code)"""

    appendix: Optional[str] = None
    """Extracted links and sidebar content"""

    browser_session_id: Optional[str] = FieldInfo(alias="browserSessionId", default=None)
    """Unique identifier for the browser session that performed this fetch"""

    capture_telemetry: Optional[DataCaptureTelemetry] = FieldInfo(alias="captureTelemetry", default=None)
    """
    Snapshot capture telemetry describing request intent, rollout selection, and
    actual execution path
    """

    html: Optional[str] = None
    """The HTML content of the fetched page"""

    json_: Optional[List[Dict[str, Union[str, float, bool, object]]]] = FieldInfo(alias="json", default=None)
    """Pruned JSON objects extracted from the page (from HTML and network responses).

    This is recomputed on every fetch and is not persisted.
    """

    links: Optional[List[DataLink]] = None
    """Links extracted from the page"""

    markdown: Optional[str] = None
    """The markdown-formatted content extracted from the page"""

    meta: Optional[DataMeta] = None
    """Comprehensive metadata extracted from the page HTML head section"""

    render_engines: Optional[DataRenderEngines] = FieldInfo(alias="renderEngines", default=None)
    """Rendering engines actually used to produce this response"""

    screenshot: Optional[DataScreenshot] = None
    """Screenshot of the fetched page"""

    snippets: Optional[List[DataSnippet]] = None
    """Relevant snippets extracted from the page based on the search query"""

    summary: Optional[str] = None
    """AI-generated summary of the page content"""


class FetchResponse(BaseModel):
    """Complete response from a fetch operation"""

    data: Data
