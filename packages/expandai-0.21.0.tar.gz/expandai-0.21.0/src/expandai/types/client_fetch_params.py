# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Literal, Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "ClientFetchParams",
    "BrowserConfig",
    "Experimental",
    "Select",
    "SelectLinks",
    "SelectLinksUnionMember1",
    "SelectResponse",
    "SelectScreenshot",
    "SelectScreenshotSelectScreenshotConfig",
    "SelectSnippets",
    "SelectSnippetsSources",
    "SelectSnippetsSourcesJson",
    "SelectSnippetsSourcesJsonTargetChunkSize",
    "SelectSnippetsSourcesMarkdown",
    "SelectSnippetsSourcesMarkdownTargetSize",
    "SelectSummary",
    "SelectSummaryPrompt",
]


class ClientFetchParams(TypedDict, total=False):
    url: Required[str]
    """The URL to fetch content from (http or https only)"""

    browser_config: Annotated[BrowserConfig, PropertyInfo(alias="browserConfig")]
    """Configuration options for browser behavior during the fetch"""

    experimental: Experimental
    """Experimental rendering engine overrides"""

    select: Select
    """Specifies which content formats to include in the response"""


class BrowserConfig(TypedDict, total=False):
    """Configuration options for browser behavior during the fetch"""

    scroll_full_page: Annotated[bool, PropertyInfo(alias="scrollFullPage")]
    """Whether to scroll the entire page to capture lazy-loaded content"""


class Experimental(TypedDict, total=False):
    """Experimental rendering engine overrides"""

    capture_engine: Annotated[Literal["typescript", "rust"], PropertyInfo(alias="captureEngine")]
    """Opt into an alternate snapshot capture engine for this request"""

    capture_style_mode: Annotated[Literal["compat_full", "native_default"], PropertyInfo(alias="captureStyleMode")]
    """Opt into an alternate computed-style payload for Rust snapshot capture"""

    markdown_engine: Annotated[Literal["typescript", "rust"], PropertyInfo(alias="markdownEngine")]
    """Opt into an alternate markdown renderer for this request"""

    tree_engine: Annotated[Literal["typescript", "rust"], PropertyInfo(alias="treeEngine")]
    """Opt into an alternate tree printer for this request"""


class SelectLinksUnionMember1(TypedDict, total=False):
    """Options for customizing link extraction from the page"""

    exclude_patterns: Annotated[SequenceNotStr[str], PropertyInfo(alias="excludePatterns")]
    """Regex patterns - exclude links matching any pattern"""

    include_patterns: Annotated[SequenceNotStr[str], PropertyInfo(alias="includePatterns")]
    """Regex patterns - only include links matching at least one pattern"""

    same_domain_only: Annotated[bool, PropertyInfo(alias="sameDomainOnly")]
    """Only include links from the same domain as the fetched URL"""


SelectLinks: TypeAlias = Union[bool, SelectLinksUnionMember1]


class SelectResponse(TypedDict, total=False):
    """Configure response info options (headers inclusion)"""

    include_headers: Annotated[bool, PropertyInfo(alias="includeHeaders")]
    """Whether to include HTTP response headers"""


class SelectScreenshotSelectScreenshotConfig(TypedDict, total=False):
    """Options for customizing screenshot capture behavior"""

    full_page: Annotated[bool, PropertyInfo(alias="fullPage")]
    """Whether to capture the full page including content below the fold"""


SelectScreenshot: TypeAlias = Union[bool, SelectScreenshotSelectScreenshotConfig]


class SelectSnippetsSourcesJsonTargetChunkSize(TypedDict, total=False):
    """Configuration for JSON snippet source"""

    target_chunk_size: Annotated[int, PropertyInfo(alias="targetChunkSize")]
    """Target JSON chunk size in characters when stringified (100-5000)"""


SelectSnippetsSourcesJson: TypeAlias = Union[bool, SelectSnippetsSourcesJsonTargetChunkSize]


class SelectSnippetsSourcesMarkdownTargetSize(TypedDict, total=False):
    """Configuration for markdown snippet source"""

    target_size: Annotated[int, PropertyInfo(alias="targetSize")]
    """Target snippet size in characters (100-2000)"""


SelectSnippetsSourcesMarkdown: TypeAlias = Union[bool, SelectSnippetsSourcesMarkdownTargetSize]


class SelectSnippetsSources(TypedDict, total=False):
    """Configure which content sources to search. Defaults to markdown only."""

    json: SelectSnippetsSourcesJson
    """Include JSON content in snippet search"""

    markdown: SelectSnippetsSourcesMarkdown
    """Search markdown content for snippets (default: enabled)"""


class SelectSnippets(TypedDict, total=False):
    """
    Options for extracting relevant snippets from page content using semantic search
    """

    query: Required[str]
    """Query to find relevant content snippets from the page (required, non-empty)"""

    max_snippets: Annotated[int, PropertyInfo(alias="maxSnippets")]
    """Maximum number of snippets to return (1-50)"""

    min_score: Annotated[float, PropertyInfo(alias="minScore")]
    """Minimum relevance score threshold (0-1).

    Snippets below this score are filtered out.
    """

    sources: SelectSnippetsSources
    """Configure which content sources to search. Defaults to markdown only."""


class SelectSummaryPrompt(TypedDict, total=False):
    """Options for AI-powered page summarization"""

    prompt: str
    """Custom prompt for AI summarization (max 5000 characters)"""


SelectSummary: TypeAlias = Union[bool, SelectSummaryPrompt]


class Select(TypedDict, total=False):
    """Specifies which content formats to include in the response"""

    appendix: bool
    """Set to true to include extracted links and sidebar content"""

    html: Union[bool, Iterable[object], object]
    """Set to true to include HTML"""

    json: bool
    """Include pruned JSON in the response (opt-in)"""

    links: SelectLinks
    """Set to true to extract links from the page"""

    markdown: Union[bool, Iterable[object], object]
    """Include markdown-formatted content in the response"""

    meta: bool
    """Include page metadata in the response"""

    response: SelectResponse
    """Configure response info options (headers inclusion)"""

    screenshot: SelectScreenshot
    """Set to true to include a screenshot"""

    snippets: SelectSnippets
    """
    Options for extracting relevant snippets from page content using semantic search
    """

    summary: SelectSummary
    """Set to true to generate an AI summary"""
