# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from expandai import Expand, AsyncExpand
from tests.utils import assert_matches_type
from expandai.types import FetchResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestClient:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_fetch(self, client: Expand) -> None:
        client_ = client.fetch(
            url="https://www.stripe.com/docs/api",
        )
        assert_matches_type(FetchResponse, client_, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_fetch_with_all_params(self, client: Expand) -> None:
        client_ = client.fetch(
            url="https://www.stripe.com/docs/api",
            browser_config={"scroll_full_page": True},
            experimental={
                "capture_engine": "rust",
                "capture_style_mode": "native_default",
                "markdown_engine": "rust",
                "tree_engine": "rust",
            },
            select={
                "appendix": True,
                "html": True,
                "json": True,
                "links": True,
                "markdown": True,
                "meta": True,
                "response": {"include_headers": True},
                "screenshot": True,
                "snippets": {
                    "query": "pricing plans",
                    "max_snippets": 5,
                    "min_score": 0.5,
                    "sources": {
                        "json": True,
                        "markdown": True,
                    },
                },
                "summary": True,
            },
        )
        assert_matches_type(FetchResponse, client_, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_fetch(self, client: Expand) -> None:
        response = client.with_raw_response.fetch(
            url="https://www.stripe.com/docs/api",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        client_ = response.parse()
        assert_matches_type(FetchResponse, client_, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_fetch(self, client: Expand) -> None:
        with client.with_streaming_response.fetch(
            url="https://www.stripe.com/docs/api",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            client_ = response.parse()
            assert_matches_type(FetchResponse, client_, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncClient:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_fetch(self, async_client: AsyncExpand) -> None:
        client = await async_client.fetch(
            url="https://www.stripe.com/docs/api",
        )
        assert_matches_type(FetchResponse, client, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_fetch_with_all_params(self, async_client: AsyncExpand) -> None:
        client = await async_client.fetch(
            url="https://www.stripe.com/docs/api",
            browser_config={"scroll_full_page": True},
            experimental={
                "capture_engine": "rust",
                "capture_style_mode": "native_default",
                "markdown_engine": "rust",
                "tree_engine": "rust",
            },
            select={
                "appendix": True,
                "html": True,
                "json": True,
                "links": True,
                "markdown": True,
                "meta": True,
                "response": {"include_headers": True},
                "screenshot": True,
                "snippets": {
                    "query": "pricing plans",
                    "max_snippets": 5,
                    "min_score": 0.5,
                    "sources": {
                        "json": True,
                        "markdown": True,
                    },
                },
                "summary": True,
            },
        )
        assert_matches_type(FetchResponse, client, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_fetch(self, async_client: AsyncExpand) -> None:
        response = await async_client.with_raw_response.fetch(
            url="https://www.stripe.com/docs/api",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        client = await response.parse()
        assert_matches_type(FetchResponse, client, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_fetch(self, async_client: AsyncExpand) -> None:
        async with async_client.with_streaming_response.fetch(
            url="https://www.stripe.com/docs/api",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            client = await response.parse()
            assert_matches_type(FetchResponse, client, path=["response"])

        assert cast(Any, response.is_closed) is True
