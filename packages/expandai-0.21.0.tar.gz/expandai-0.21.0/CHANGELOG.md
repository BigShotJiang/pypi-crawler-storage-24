# Changelog

## 0.21.0 (2026-03-27)

Full Changelog: [v0.20.3...v0.21.0](https://github.com/expandai/expandai-python/compare/v0.20.3...v0.21.0)

### Features

* **internal:** implement indices array format for query and form serialization ([8a75d1e](https://github.com/expandai/expandai-python/commit/8a75d1ee2388fd6a0123cc0c5b5737f7abf12a45))


### Chores

* **ci:** skip lint on metadata-only changes ([34941ab](https://github.com/expandai/expandai-python/commit/34941abce46165bd3fd3c633eaf6ce2174b9e019))
* **internal:** update gitignore ([6336371](https://github.com/expandai/expandai-python/commit/633637105876745ba1574b0d94750a6cf8c792ef))

## 0.20.3 (2026-03-20)

Full Changelog: [v0.20.2...v0.20.3](https://github.com/expandai/expandai-python/compare/v0.20.2...v0.20.3)

### Bug Fixes

* sanitize endpoint path params ([43c8ac5](https://github.com/expandai/expandai-python/commit/43c8ac57993d9802a399b82f85590ed0d5779f99))


### Chores

* **internal:** tweak CI branches ([a2b211d](https://github.com/expandai/expandai-python/commit/a2b211d7a510d19b7fec36e512e48cbee72014fa))

## 0.20.2 (2026-03-17)

Full Changelog: [v0.20.1...v0.20.2](https://github.com/expandai/expandai-python/compare/v0.20.1...v0.20.2)

### Bug Fixes

* **deps:** bump minimum typing-extensions version ([26cc2bb](https://github.com/expandai/expandai-python/commit/26cc2bb27b72ae11801cfec9470c9c95a0bc9ceb))

## 0.20.1 (2026-03-17)

Full Changelog: [v0.20.0...v0.20.1](https://github.com/expandai/expandai-python/compare/v0.20.0...v0.20.1)

### Bug Fixes

* **pydantic:** do not pass `by_alias` unless set ([70bc566](https://github.com/expandai/expandai-python/commit/70bc5662950619f322d126b6be7e081cad3c18a3))

## 0.20.0 (2026-03-17)

Full Changelog: [v0.19.0...v0.20.0](https://github.com/expandai/expandai-python/compare/v0.19.0...v0.20.0)

### Features

* **api:** api update ([ce3ca30](https://github.com/expandai/expandai-python/commit/ce3ca3029188e9190c3a11ed1693c2949d99d75c))

## 0.19.0 (2026-03-15)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/expandai/expandai-python/compare/v0.18.0...v0.19.0)

### Features

* **api:** api update ([598b19a](https://github.com/expandai/expandai-python/commit/598b19a9d64409d7f5cd345764bd575724c3c57e))

## 0.18.0 (2026-03-13)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/expandai/expandai-python/compare/v0.17.0...v0.18.0)

### Features

* **api:** api update ([fcb62c8](https://github.com/expandai/expandai-python/commit/fcb62c87d9df0a477d154419623aa0507be8829b))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([965ddf6](https://github.com/expandai/expandai-python/commit/965ddf667ab0e03f4b5bc959d45c804614052d7b))

## 0.17.0 (2026-03-04)

Full Changelog: [v0.16.0...v0.17.0](https://github.com/expandai/expandai-python/compare/v0.16.0...v0.17.0)

### Features

* **api:** api update ([731a8fe](https://github.com/expandai/expandai-python/commit/731a8fe33596817e8d3e5d7a4439b425fdf9beb1))


### Chores

* **ci:** bump uv version ([4d3add9](https://github.com/expandai/expandai-python/commit/4d3add9dec3eea07b7afcb00fc61e11bcd63ba22))
* **internal:** add request options to SSE classes ([27099fa](https://github.com/expandai/expandai-python/commit/27099fadfca1826c15c62f26ea1268a7bfcc140a))
* **internal:** make `test_proxy_environment_variables` more resilient ([7a82d8e](https://github.com/expandai/expandai-python/commit/7a82d8ea5c6499e4d62d1eed8a4e093517c9b5af))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([9580556](https://github.com/expandai/expandai-python/commit/95805564083197960cfa783fe04d36c208923c93))

## 0.16.0 (2026-02-21)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/expandai/expandai-python/compare/v0.15.0...v0.16.0)

### Features

* **api:** api update ([7d41eea](https://github.com/expandai/expandai-python/commit/7d41eeac55ca3e805a0a6bf40000bf0eb5cc40a2))


### Chores

* **internal:** remove mock server code ([22040a1](https://github.com/expandai/expandai-python/commit/22040a149c6b0600842928b7f73432650dfd1851))
* update mock server docs ([62a2010](https://github.com/expandai/expandai-python/commit/62a20104b325c376353868d13a7db7df34a769ba))

## 0.15.0 (2026-02-19)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/expandai/expandai-python/compare/v0.14.0...v0.15.0)

### Features

* **api:** api update ([ec3043c](https://github.com/expandai/expandai-python/commit/ec3043c504481f0fb50bb62fd1c88e37b0fd57ce))

## 0.14.0 (2026-02-19)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/expandai/expandai-python/compare/v0.13.0...v0.14.0)

### Features

* **api:** api update ([0654a42](https://github.com/expandai/expandai-python/commit/0654a4213f0b7cf10dcdbf2b1de88b45bfa25c24))

## 0.13.0 (2026-02-18)

Full Changelog: [v0.12.1...v0.13.0](https://github.com/expandai/expandai-python/compare/v0.12.1...v0.13.0)

### Features

* **api:** api update ([bebf0f1](https://github.com/expandai/expandai-python/commit/bebf0f10b6bd1fb42fdea925f4dd44558eed4028))

## 0.12.1 (2026-02-13)

Full Changelog: [v0.12.0...v0.12.1](https://github.com/expandai/expandai-python/compare/v0.12.0...v0.12.1)

### Chores

* format all `api.md` files ([2edde25](https://github.com/expandai/expandai-python/commit/2edde25202377922e2f41148f4c61cfa572c3ca7))
* **internal:** bump dependencies ([bc96673](https://github.com/expandai/expandai-python/commit/bc96673eae9c4c2ba2a0fe1e161fa7cc5109ad0d))
* **internal:** fix lint error on Python 3.14 ([1446672](https://github.com/expandai/expandai-python/commit/14466729b0ff2a500922cb473cbcb6c08cdf52e5))

## 0.12.0 (2026-01-30)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/expandai/expandai-python/compare/v0.11.0...v0.12.0)

### Features

* **client:** add custom JSON encoder for extended type support ([d002bb4](https://github.com/expandai/expandai-python/commit/d002bb492c940a2a98e4c4ca83791371cfc77651))


### Chores

* **ci:** upgrade `actions/github-script` ([801ca00](https://github.com/expandai/expandai-python/commit/801ca0026d14830001854a06458412072bfe4fbe))

## 0.11.0 (2026-01-23)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/expandai/expandai-python/compare/v0.10.0...v0.11.0)

### Features

* **api:** api update ([812d543](https://github.com/expandai/expandai-python/commit/812d5431955cc0d29b0ad56efa80be5db20438d3))

## 0.10.0 (2026-01-19)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/expandai/expandai-python/compare/v0.9.0...v0.10.0)

### Features

* **api:** api update ([6360779](https://github.com/expandai/expandai-python/commit/6360779782d20b22c4bb9fec194aa837a0f7ca07))

## 0.9.0 (2026-01-19)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/expandai/expandai-python/compare/v0.8.0...v0.9.0)

### Features

* **api:** api update ([9391093](https://github.com/expandai/expandai-python/commit/939109324eeea5388959b39bf982cde71f91c34d))


### Chores

* **internal:** update `actions/checkout` version ([375c4bd](https://github.com/expandai/expandai-python/commit/375c4bd16ff1da14bb9a88726763ac4a78212030))

## 0.8.0 (2026-01-14)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/expandai/expandai-python/compare/v0.7.0...v0.8.0)

### Features

* **client:** add support for binary request streaming ([a87db8f](https://github.com/expandai/expandai-python/commit/a87db8f21a2afaa40104d3a7ed9d815bc94d61df))

## 0.7.0 (2026-01-13)

Full Changelog: [v0.6.1...v0.7.0](https://github.com/expandai/expandai-python/compare/v0.6.1...v0.7.0)

### Features

* **api:** api update ([c0e2844](https://github.com/expandai/expandai-python/commit/c0e284407143d3d1e3ade38dfd31b5f4828ffdca))


### Chores

* **internal:** add `--fix` argument to lint script ([e0362c3](https://github.com/expandai/expandai-python/commit/e0362c3074cc387bc2f1976e03d2f86b4ef1e737))
* **internal:** codegen related update ([bd8619b](https://github.com/expandai/expandai-python/commit/bd8619b76b554c8edb61c7637d1397c7e2b93f9b))

## 0.6.1 (2025-12-18)

Full Changelog: [v0.6.0...v0.6.1](https://github.com/expandai/expandai-python/compare/v0.6.0...v0.6.1)

### Bug Fixes

* use async_to_httpx_files in patch method ([e5b58aa](https://github.com/expandai/expandai-python/commit/e5b58aa48897b6d966ad01c98436654b47eadd1c))

## 0.6.0 (2025-12-17)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/expandai/expandai-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** manual updates ([424dee6](https://github.com/expandai/expandai-python/commit/424dee6c8f5358ac9ef83958de55a2d750be01bf))

## 0.5.0 (2025-12-17)

Full Changelog: [v0.4.1...v0.5.0](https://github.com/expandai/expandai-python/compare/v0.4.1...v0.5.0)

### Features

* **api:** manual updates ([fa62821](https://github.com/expandai/expandai-python/commit/fa62821ec4656fb171e72dc24afed03ed24a671d))

## 0.4.1 (2025-12-17)

Full Changelog: [v0.4.0...v0.4.1](https://github.com/expandai/expandai-python/compare/v0.4.0...v0.4.1)

### Chores

* **internal:** add missing files argument to base client ([80aa980](https://github.com/expandai/expandai-python/commit/80aa9803b6dd99238ac129a98a0ee81bda70ecbf))
* speedup initial import ([50d5af4](https://github.com/expandai/expandai-python/commit/50d5af411e8c08b287c94f3b2ad7510e4db18fc5))


### Refactors

* **internal:** switch from rye to uv ([a8cc129](https://github.com/expandai/expandai-python/commit/a8cc129877055286b68920f67610c3db9cd2d897))

## 0.4.0 (2025-12-12)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/expandai/expandai-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([4a17994](https://github.com/expandai/expandai-python/commit/4a17994db4684c58c617d82cbdc72500053dd8fd))

## 0.3.0 (2025-12-11)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/expandai/expandai-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** manual updates ([7436ecd](https://github.com/expandai/expandai-python/commit/7436ecd6117dda7d9c014a16175574b6d1e1b674))

## 0.2.0 (2025-12-10)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/expandai/expandai-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([54ca7dc](https://github.com/expandai/expandai-python/commit/54ca7dcd73b3b3ef7adbd3338a1115b3c90701d2))
* **api:** manual updates ([eafd153](https://github.com/expandai/expandai-python/commit/eafd153d748899ece1ce0ce7a26bd4069c7c4a58))
* **api:** manual updates ([8b94d53](https://github.com/expandai/expandai-python/commit/8b94d533f83356d7a4df76f28183e63c728cd76b))
* **api:** manual updates ([66ab470](https://github.com/expandai/expandai-python/commit/66ab4704370ae20d44bd3e25662eff96a39ac9e4))
* **api:** manual updates ([cf780b8](https://github.com/expandai/expandai-python/commit/cf780b8770b01a20d744f0a700a663e849476a30))
* **api:** manual updates ([33f9136](https://github.com/expandai/expandai-python/commit/33f9136c489884fbd67e6aca32992a90b2cf2009))
* **api:** manual updates ([77abf09](https://github.com/expandai/expandai-python/commit/77abf091a0756efa01e7f14fc5b1262dd091320f))
* **api:** manual updates ([b2fdc87](https://github.com/expandai/expandai-python/commit/b2fdc8766f274055ee6120fc448083b2d7ccfd9b))


### Chores

* update SDK settings ([244ff20](https://github.com/expandai/expandai-python/commit/244ff209b55ca271e66136fd357032887b536be5))
* update SDK settings ([190a4f2](https://github.com/expandai/expandai-python/commit/190a4f2fb911eca265a8ec49330781d8e8b0fb64))

## 0.1.0 (2025-12-10)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/expandai/expand-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([bf0bc0a](https://github.com/expandai/expand-python/commit/bf0bc0a9712be08018360c00de3bc208807c5823))
* **api:** api update ([9e4c98b](https://github.com/expandai/expand-python/commit/9e4c98b687c091a7e52d8a9d69fe9a5c2f7e6b75))
* **api:** api update ([a157740](https://github.com/expandai/expand-python/commit/a157740d97db44a7253f974f75c68ed6b5bafd37))
* **api:** api update ([29978dd](https://github.com/expandai/expand-python/commit/29978dd86bdd385e4cb719edadbf0564d2135a40))
* **api:** manual updates ([6595d0a](https://github.com/expandai/expand-python/commit/6595d0afc221d67cdae33a2f267627621c97f9c9))
* **api:** manual updates ([fc001f8](https://github.com/expandai/expand-python/commit/fc001f8c3ed73d4b18e672a215cf50458957472c))
* **api:** manual updates ([eb63b72](https://github.com/expandai/expand-python/commit/eb63b72d4b0dabb38c4bf27f515e88b6d29f9eee))
* **api:** manual updates ([7c515fd](https://github.com/expandai/expand-python/commit/7c515fdf3b33df17360767a24a370f2133a6dce6))
* **api:** manual updates ([0949ab1](https://github.com/expandai/expand-python/commit/0949ab104210fe3e0134126e39be80ac1d27a46b))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([73884f5](https://github.com/expandai/expand-python/commit/73884f5c4c1ff9264e45831db168da92827e77b5))


### Chores

* add missing docstrings ([26721fe](https://github.com/expandai/expand-python/commit/26721feec88fdbbce9240f35ba9a71db89440b4c))
* **docs:** use environment variables for authentication in code snippets ([b4f4f02](https://github.com/expandai/expand-python/commit/b4f4f02fa65e35d7819db9803a6b366f935254d3))
* update lockfile ([17586da](https://github.com/expandai/expand-python/commit/17586daa8da3b9c4c3ad3324de3cfa8986146c07))
