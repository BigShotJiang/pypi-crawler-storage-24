#!/usr/bin/env python3
"""
Madpod nanobot hook: activity-logger
Sends tool activity events via the Madpod WebSocket channel.
Also writes a local JSONL backup to /mnt/agent/{AGENT_ID}/logs/activity.jsonl

Usage: set as nanobot hook for PreToolUse, PostToolUse, OnError events.
"""

import json
import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger("activity-logger")

AGENT_ID = os.environ.get("MADPOD_AGENT_ID", "unknown")
LOG_DIR = Path(f"/mnt/agent/{AGENT_ID}/logs")


def _ensure_log_dir() -> None:
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def _write_local_log(event: dict) -> None:
    """Write event to local JSONL backup file."""
    try:
        _ensure_log_dir()
        log_file = LOG_DIR / "activity.jsonl"
        with open(log_file, "a") as f:
            f.write(json.dumps(event) + "\n")
    except Exception as e:
        logger.debug(f"Failed to write local log: {e}")


def _send_via_channel(event: dict) -> None:
    """
    Send event via the Madpod channel socket.
    The nanobot process exposes a local unix socket for hook communication.
    """
    channel_socket = os.environ.get("MADPOD_CHANNEL_SOCKET", f"/tmp/madpod-{AGENT_ID}.sock")
    try:
        import socket as sock_module
        with sock_module.socket(sock_module.AF_UNIX, sock_module.SOCK_STREAM) as s:
            s.settimeout(2.0)
            s.connect(channel_socket)
            s.sendall(json.dumps(event).encode() + b"\n")
    except Exception as e:
        logger.debug(f"Failed to send via channel socket: {e}")
        # Not fatal — local log is the backup


def process_hook_event(raw_input: str) -> None:
    """Process a hook event from nanobot."""
    try:
        data = json.loads(raw_input)
    except json.JSONDecodeError as e:
        logger.debug(f"Failed to parse hook input: {e}")
        return

    hook_type = data.get("hook_event_name", "unknown")
    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})
    tool_result = data.get("tool_response", {})
    error = data.get("error", None)

    event: dict = {
        "type": "activity",
        "agent_id": AGENT_ID,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "hook_type": hook_type,
        "tool_name": tool_name,
    }

    if hook_type == "PreToolUse":
        event["action"] = "tool_start"
        event["tool_input"] = _sanitize_tool_input(tool_name, tool_input)

    elif hook_type == "PostToolUse":
        event["action"] = "tool_complete"
        event["tool_input"] = _sanitize_tool_input(tool_name, tool_input)
        event["success"] = not bool(error)
        if error:
            event["error"] = str(error)[:500]

    elif hook_type == "OnError":
        event["action"] = "error"
        event["error"] = str(error)[:500] if error else "unknown error"

    # Write local JSONL backup
    _write_local_log(event)

    # Send via channel to control plane
    _send_via_channel(event)

    # Output nothing (hooks don't modify behavior)
    print(json.dumps({"continue": True}))


def _sanitize_tool_input(tool_name: str, tool_input: dict) -> dict:
    """Remove sensitive fields from tool input before logging."""
    if not isinstance(tool_input, dict):
        return {}
    sanitized = dict(tool_input)
    # Redact common sensitive fields
    for key in ("password", "token", "secret", "key", "api_key", "authorization"):
        if key in sanitized:
            sanitized[key] = "[REDACTED]"
    # Truncate large values
    for key, val in sanitized.items():
        if isinstance(val, str) and len(val) > 500:
            sanitized[key] = val[:500] + "...[truncated]"
    return sanitized


if __name__ == "__main__":
    raw = sys.stdin.read()
    process_hook_event(raw)
