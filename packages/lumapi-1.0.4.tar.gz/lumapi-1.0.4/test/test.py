from LumAPI import *

fdtd = lumapi.FDTD()

fdtd.close()








