"""Example: Model selection and custom models.

This example demonstrates how to use different OCR models,
including predefined models and custom organization-specific models.
"""

import asyncio
import os

from leapocr import Format, LeapOCR, Model, ProcessOptions


async def main():
    """Process documents with different models."""
    api_key = os.getenv("LEAPOCR_API_KEY")
    if not api_key:
        raise ValueError("LEAPOCR_API_KEY environment variable not set")

    async with LeapOCR(api_key) as client:
        schema = {
            "type": "object",
            "properties": {
                "text": {"type": "string"},
            },
            "required": ["text"],
        }

        # Example 1: Standard v2 model (default, 1 credit per page)
        print("Processing with standard-v2 model...")
        job1 = await client.ocr.process_url(
            "https://example.com/document.pdf",
            options=ProcessOptions(
                format=Format.STRUCTURED,
                model=Model.STANDARD_V2,
                schema=schema,
            ),
        )
        standard_result = await client.ocr.wait_until_done(job1.job_id)

        print("✓ Standard-v2 model processing complete")
        print(f"  Credits used: {standard_result.credits_used}")
        print()

        # Example 2: Pro v2 model (highest quality, 3 credits per page)
        print("Processing with pro-v2 model...")
        job2 = await client.ocr.process_url(
            "https://example.com/multilingual-document.pdf",
            options=ProcessOptions(
                format=Format.STRUCTURED,
                model=Model.PRO_V2,
                instructions="Extract all structured data with high precision",
                schema=schema,
            ),
        )
        pro_result = await client.ocr.wait_until_done(job2.job_id)

        print("✓ Pro-v2 model processing complete")
        print(f"  Credits used: {pro_result.credits_used}")
        print()

        # Example 3: Custom model (organization-specific)
        print("Processing with custom model...")
        job3 = await client.ocr.process_url(
            "https://example.com/specialized-document.pdf",
            options=ProcessOptions(
                format=Format.STRUCTURED,
                model="my-organization-model-v2",  # Custom string model
                instructions="Use custom extraction logic",
                schema=schema,
            ),
        )
        custom_result = await client.ocr.wait_until_done(job3.job_id)

        print("✓ Custom model processing complete")
        print(f"  Model used: {custom_result.model}")
        print(f"  Credits used: {custom_result.credits_used}")
        print()

        # Example 4: Model comparison
        print("Comparing model performance...")
        test_url = "https://example.com/test-document.pdf"

        # Submit all jobs concurrently
        jobs = await asyncio.gather(
            client.ocr.process_url(
                test_url, options=ProcessOptions(format=Format.MARKDOWN, model=Model.STANDARD_V2)
            ),
            client.ocr.process_url(
                test_url, options=ProcessOptions(format=Format.MARKDOWN, model=Model.PRO_V2)
            ),
        )

        # Wait for all to complete
        results = await asyncio.gather(*[client.ocr.wait_until_done(job.job_id) for job in jobs])

        print("Model comparison results:")
        for result in results:
            print(f"  {result.model}:")
            print(f"    Credits: {result.credits_used}")
            print(f"    Pages: {result.processed_pages}")


if __name__ == "__main__":
    asyncio.run(main())
