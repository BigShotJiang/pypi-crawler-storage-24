"""Unit tests for webhook helpers."""

from leapocr import verify_webhook_signature


class TestVerifyWebhookSignature:
    """Tests for webhook signature verification."""

    def test_accepts_valid_signature(self) -> None:
        payload = (
            b'{"event_type":"webhook.test","event_id":"evt_123",'
            b'"timestamp":"2024-01-01T00:00:00Z","message":"This is a test webhook event"}'
        )
        secret = "my-secret-key"
        timestamp = "1704067200"
        signature = "51033b9251a1db2003caf73152dc990d20c3efd8c97d176603de1dc034aa1bc1"

        assert verify_webhook_signature(payload, signature, timestamp, secret) is True

    def test_accepts_string_payload(self) -> None:
        payload = (
            '{"event_type":"webhook.test","event_id":"evt_123",'
            '"timestamp":"2024-01-01T00:00:00Z","message":"This is a test webhook event"}'
        )
        secret = "my-secret-key"
        timestamp = "1704067200"
        signature = "51033b9251a1db2003caf73152dc990d20c3efd8c97d176603de1dc034aa1bc1"

        assert verify_webhook_signature(payload, signature, timestamp, secret) is True

    def test_rejects_invalid_signature(self) -> None:
        payload = (
            b'{"event_type":"webhook.test","event_id":"evt_123",'
            b'"timestamp":"2024-01-01T00:00:00Z","message":"This is a test webhook event"}'
        )

        assert (
            verify_webhook_signature(payload, "invalid-signature", "1704067200", "my-secret-key")
            is False
        )

    def test_rejects_different_payload(self) -> None:
        payload = (
            b'{"event_type":"webhook.test","event_id":"evt_123",'
            b'"timestamp":"2024-01-01T00:00:00Z","message":"different payload"}'
        )
        signature = "51033b9251a1db2003caf73152dc990d20c3efd8c97d176603de1dc034aa1bc1"

        assert verify_webhook_signature(payload, signature, "1704067200", "my-secret-key") is False

    def test_rejects_different_timestamp(self) -> None:
        payload = (
            b'{"event_type":"webhook.test","event_id":"evt_123",'
            b'"timestamp":"2024-01-01T00:00:00Z","message":"This is a test webhook event"}'
        )
        signature = "51033b9251a1db2003caf73152dc990d20c3efd8c97d176603de1dc034aa1bc1"

        assert verify_webhook_signature(payload, signature, "1704067201", "my-secret-key") is False

    def test_rejects_missing_inputs(self) -> None:
        payload = (
            b'{"event_type":"webhook.test","event_id":"evt_123",'
            b'"timestamp":"2024-01-01T00:00:00Z","message":"This is a test webhook event"}'
        )

        assert verify_webhook_signature(payload, "", "1704067200", "my-secret-key") is False
        assert verify_webhook_signature(payload, "abc", "", "my-secret-key") is False
        assert verify_webhook_signature(payload, "abc", "1704067200", "") is False
