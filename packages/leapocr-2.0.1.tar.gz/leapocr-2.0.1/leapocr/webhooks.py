"""Webhook helpers for LeapOCR."""

from __future__ import annotations

import hashlib
import hmac


def verify_webhook_signature(
    payload: str | bytes,
    signature: str,
    timestamp: str,
    secret: str,
) -> bool:
    """Verify a LeapOCR webhook signature.

    LeapOCR signs outgoing webhooks as the lowercase hex-encoded HMAC-SHA256
    digest of "<timestamp>.<raw request body>", using your webhook secret.
    """
    if not signature or not timestamp or not secret:
        return False

    body = payload.encode("utf-8") if isinstance(payload, str) else payload
    signed_payload = timestamp.encode("utf-8") + b"." + body
    expected = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(signature, expected)
