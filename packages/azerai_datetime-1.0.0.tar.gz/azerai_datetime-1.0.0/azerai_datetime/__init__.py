"""
AzerAI DateTime Plugin - Tarix və zaman sorğuları üçün plugin

Plugin əsaslı, çoxdilli AI asistenti üçün tarix və zaman modulu.
"""

__version__ = "1.0.0"
__author__ = "AzStudio Dev"
__email__ = "dev@azstudio.ai"

from .plugins.datetime.main import get_current_time, get_current_date, get_datetime_info

__all__ = [
    "get_current_time",
    "get_current_date", 
    "get_datetime_info"
]
