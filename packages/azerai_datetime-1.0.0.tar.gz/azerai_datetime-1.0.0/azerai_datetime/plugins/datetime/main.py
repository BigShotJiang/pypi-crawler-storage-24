"""
DateTime Tools - LiveKit Agent Functions
Tarix və zaman sorğuları üçün funksiyalar
"""
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, Any
from livekit.agents import function_tool, RunContext

logger = logging.getLogger("datetime-tools")


class DateTimeTools:
    """Tarix və zaman sorğuları üçün alətlər"""
    
    def __init__(self):
        self.timezone = timezone(timedelta(hours=4))  # Azerbaijan Time (UTC+4)
        logger.info("DateTimeTools initialized with Azerbaijan timezone")

    def get_current_datetime(self) -> datetime:
        """Cari tarix və zamanı Azərbaycan vaxt zonasında al"""
        return datetime.now(self.timezone)

    def format_datetime(self, dt: datetime, format_type: str = "full") -> str:
        """Tarix və zamanı formatla"""
        if format_type == "time":
            return dt.strftime("%H:%M:%S")
        elif format_type == "date":
            return dt.strftime("%d.%m.%Y")
        elif format_type == "datetime":
            return dt.strftime("%d.%m.%Y %H:%M:%S")
        elif format_type == "full":
            return dt.strftime("%d %B %Y, %H:%M:%S (%A)")
        else:
            return dt.strftime("%d.%m.%Y %H:%M:%S")

    def get_day_name_az(self, dt: datetime) -> str:
        """Günün adını Azərbaycan dilində al"""
        days = {
            0: "Bazar ertəsi",
            1: "Çərşənbə axşamı", 
            2: "Çərşənbə",
            3: "Cümə axşamı",
            4: "Cümə",
            5: "Şənbə",
            6: "Bazar"
        }
        return days[dt.weekday()]

    def get_month_name_az(self, dt: datetime) -> str:
        """Ayın adını Azərbaycan dilində al"""
        months = {
            1: "Yanvar",
            2: "Fevral",
            3: "Mart",
            4: "Aprel",
            5: "May",
            6: "İyun",
            7: "İyul",
            8: "Avqust",
            9: "Sentyabr",
            10: "Oktyabr",
            11: "Noyabr",
            12: "Dekabr"
        }
        return months[dt.month]

    def get_time_of_day(self, dt: datetime) -> str:
        """Günün vaxtını təyin et"""
        hour = dt.hour
        if 5 <= hour < 12:
            return "Səhər"
        elif 12 <= hour < 17:
            return "Gündüz"
        elif 17 <= hour < 21:
            return "Axşam"
        else:
            return "Gecə"


# Global instance
datetime_tools = DateTimeTools()


@function_tool()
async def get_current_time(ctx: RunContext) -> str:
    """
    Cari vaxtı Azərbaycan vaxt zonasında al.
    
    Returns:
        str: Cari vaxt və əlavı məlumatlar
    """
    try:
        current_dt = datetime_tools.get_current_datetime()
        time_str = datetime_tools.format_datetime(current_dt, "time")
        day_name = datetime_tools.get_day_name_az(current_dt)
        time_of_day = datetime_tools.get_time_of_day(current_dt)
        
        result = f"""🕐 CURRENT TIME RESULTS

⏰ Time: {time_str}
📅 Day: {day_name}
🌤️ Period: {time_of_day}
🗺️ Timezone: Azerbaijan Time (UTC+4)
⏰ Query time: {datetime_tools.format_datetime(current_dt, "full")}

✅ Current time retrieved successfully"""
        
        logger.info(f"Current time query: {time_str}")
        return result
        
    except Exception as e:
        logger.error(f"Error getting current time: {e}")
        return f"Error retrieving current time: {str(e)}"


@function_tool()
async def get_current_date(ctx: RunContext) -> str:
    """
    Cari tarixi Azərbaycan vaxt zonasında al.
    
    Returns:
        str: Cari tarix və əlavı məlumatlar
    """
    try:
        current_dt = datetime_tools.get_current_datetime()
        date_str = datetime_tools.format_datetime(current_dt, "date")
        day_name = datetime_tools.get_day_name_az(current_dt)
        month_name = datetime_tools.get_month_name_az(current_dt)
        year = current_dt.year
        
        result = f"""📅 CURRENT DATE RESULTS

🗓️ Date: {date_str}
📝 Day: {day_name}
🌙 Month: {month_name}
📆 Year: {year}
🗺️ Timezone: Azerbaijan Time (UTC+4)
📅 Query time: {datetime_tools.format_datetime(current_dt, "full")}

✅ Current date retrieved successfully"""
        
        logger.info(f"Current date query: {date_str}")
        return result
        
    except Exception as e:
        logger.error(f"Error getting current date: {e}")
        return f"Error retrieving current date: {str(e)}"


@function_tool()
async def get_datetime_info(ctx: RunContext) -> str:
    """
    Tam tarix və zaman məlumatlarını al.
    
    Returns:
        str: Tam tarix və zaman məlumatları
    """
    try:
        current_dt = datetime_tools.get_current_datetime()
        day_name = datetime_tools.get_day_name_az(current_dt)
        month_name = datetime_tools.get_month_name_az(current_dt)
        time_of_day = datetime_tools.get_time_of_day(current_dt)
        
        # Həftənin günü (1-7)
        day_of_week = current_dt.isoweekday()
        
        # İl günü (1-366)
        day_of_year = current_dt.timetuple().tm_yday
        
        # Ayın günü
        day_of_month = current_dt.day
        
        # İlinin həftəsi (1-52)
        week_of_year = current_dt.isocalendar()[1]
        
        result = f"""📅 DATETIME INFO RESULTS

🕐 Time: {current_dt.strftime('%H:%M:%S')}
📅 Date: {current_dt.strftime('%d.%m.%Y')}
📝 Day: {day_name}
🌙 Month: {month_name}
📆 Year: {current_dt.year}
🌤️ Period: {time_of_day}
🗺️ Timezone: Azerbaijan Time (UTC+4)

📊 Additional Info:
🔢 Day of week: {day_of_week}/7
📈 Day of year: {day_of_year}/366
📋 Week of year: {week_of_year}/52
🗓️ Day of month: {day_of_month}

⏰ Full datetime: {datetime_tools.format_datetime(current_dt, "full")}

✅ Complete datetime information retrieved"""
        
        logger.info(f"Datetime info query: {current_dt.strftime('%d.%m.%Y %H:%M:%S')}")
        return result
        
    except Exception as e:
        logger.error(f"Error getting datetime info: {e}")
        return f"Error retrieving datetime info: {str(e)}"


# Export functions for direct import
get_time = get_current_time
get_date = get_current_date
get_info = get_datetime_info
