import fileinput
import json
import subprocess  # noqa: S404
from pathlib import Path

MODULES = {
    "apus_api": "annotated-doc==0.0.4,annotated-types==0.7.0,anyio==4.12.0,argcomplete==3.6.3,asn1crypto==1.5.1,black==25.11.0,boto3==1.42.19,botocore==1.42.19,certifi==2025.11.12,cffi==2.0.0,charset-normalizer==3.4.4,click==8.1.8,colorama==0.4.6,cryptography==46.0.3,datamodel-code-generator==0.44.0,ecdsa==0.19.1,exceptiongroup==1.3.1,fastapi==0.128.0,filelock==3.19.1,genson==1.3.0,greenlet==3.2.4,h11==0.16.0,idna==3.11,inflect==5.6.2,isort==5.13.2,jinja2==3.1.6,jmespath==1.0.1,markupsafe==3.0.3,mypy-extensions==1.1.0,packaging==25.0,pathspec==0.12.1,platformdirs==4.4.0,pyasn1==0.6.2,pycparser==2.23,pydantic==2.10.6,pydantic-core==2.27.2,pyjwt==2.10.1,pyopenssl==25.3.0,python-dateutil==2.9.0.post0,python-forge==18.6.0,python-jose==3.5.0,python-multipart==0.0.20,pytokens==0.3.0,pytz==2025.2,pyxis @ https://github.com/vitalibo/pyxis/archive/refs/tags/0.2.10-pyspark.zip,pyyaml==6.0.3,requests==2.32.5,rsa==4.9.1,s3transfer==0.16.0,six==1.17.0,snowflake-connector-python==4.1.1,snowflake-sqlalchemy==1.8.2,sortedcontainers==2.4.0,sqlalchemy==2.0.45,starlette==0.49.3,tomli==2.3.0,tomlkit==0.13.3,typing-extensions==4.15.0,urllib3==1.26.20,uvicorn==0.39.0",
    "apus_shared": "annotated-types==0.7.0,asn1crypto==1.5.1,boto3==1.42.19,botocore==1.42.19,certifi==2025.11.12,cffi==2.0.0,charset-normalizer==3.4.4,cryptography==46.0.3,filelock==3.19.1,greenlet==3.2.4,idna==3.11,jmespath==1.0.1,packaging==25.0,platformdirs==4.4.0,pycparser==2.23,pydantic==2.10.6,pydantic-core==2.27.2,pyjwt==2.10.1,pyopenssl==25.3.0,python-dateutil==2.9.0.post0,pytz==2025.2,pyxis @ https://github.com/vitalibo/pyxis/archive/refs/tags/0.2.10-pyspark.zip,requests==2.32.5,s3transfer==0.16.0,six==1.17.0,snowflake-connector-python==4.1.1,snowflake-sqlalchemy==1.8.2,sortedcontainers==2.4.0,sqlalchemy==2.0.45,tomlkit==0.13.3,typing-extensions==4.15.0,urllib3==1.26.20",
    "apus_cli": "annotated-types==0.7.0,attrs==25.4.0,aws-cdk-asset-awscli-v1==2.2.242,aws-cdk-asset-node-proxy-agent-v6==2.1.0,aws-cdk-cloud-assembly-schema==48.20.0,aws-cdk-lib==2.233.0,aws-croniter==1.0.5,boto3==1.42.19,botocore==1.42.19,cattrs==25.3.0,click==8.1.8,colorama==0.4.6,constructs==10.4.4,exceptiongroup==1.3.1,importlib-resources==6.5.2,jmespath==1.0.1,jsii==1.125.0,publication==0.0.3,pydantic==2.10.6,pydantic-core==2.27.2,python-dateutil==2.9.0.post0,pyyaml==6.0.3,s3transfer==0.16.0,six==1.17.0,typeguard==2.13.3,typer-slim==0.21.1,typing-extensions==4.15.0,urllib3==1.26.20,zipp==3.23.0",
    "apus_monitoring": "annotated-types==0.7.0,asn1crypto==1.5.1,boto3==1.42.19,botocore==1.42.19,certifi==2025.11.12,cffi==2.0.0,charset-normalizer==3.4.4,cryptography==46.0.3,filelock==3.19.1,greenlet==3.2.4,idna==3.11,jinja2==3.1.6,jmespath==1.0.1,markupsafe==3.0.3,packaging==25.0,platformdirs==4.4.0,pycparser==2.23,pydantic==2.10.6,pydantic-core==2.27.2,pyjwt==2.10.1,pyopenssl==25.3.0,python-dateutil==2.9.0.post0,pytz==2025.2,pyxis @ https://github.com/vitalibo/pyxis/archive/refs/tags/0.2.10-pyspark.zip,requests==2.32.5,s3transfer==0.16.0,six==1.17.0,slack-sdk==3.40.0,snowflake-connector-python==4.1.1,snowflake-sqlalchemy==1.8.2,sortedcontainers==2.4.0,sqlalchemy==2.0.45,tomlkit==0.13.3,typing-extensions==4.15.0,urllib3==1.26.20"
}


def export_requirements(module):
    """Exports the dependencies of a given module in a format suitable for requirements.txt."""

    command = (
        f'uv export --package {module}',
        '--no-dev --no-header --no-editable --no-hashes --no-annotate --no-emit-workspace --format requirements-txt',
        "| sed 's/ ;.*//'",
        '| paste -sd "," -',
    )
    result = subprocess.run(' '.join(command), shell=True, check=True, stdout=subprocess.PIPE, text=True)  # noqa: S602
    return result.stdout.strip()


def refresh_requirements(root):
    """Refreshes the MODULES dictionary with the current dependencies of each module"""

    requirements = {}
    for module in root.iterdir():
        if module.is_dir() and module.name.startswith('apus-'):
            requirements[module.name.replace('-', '_')] = export_requirements(module.name)

    with fileinput.FileInput(__file__, inplace=True) as file:
        for line in file:
            if line == 'MODULES = {}\n':
                print(f'MODULES = {json.dumps(requirements, indent=4)}')  # noqa: T201
            else:
                print(line, end='')  # noqa: T201


def __getattr__(name):
    return MODULES[name]


if __name__ == '__main__':
    refresh_requirements(Path(__file__).parent.parent.parent.parent.parent)
