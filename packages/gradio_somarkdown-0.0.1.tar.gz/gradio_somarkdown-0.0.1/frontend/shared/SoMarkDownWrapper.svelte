<script lang="ts">
	import { onMount } from "svelte";
	import SoMarkDown from "somarkdown/dist/somarkdown.js";
	import somarkdownCssText from "somarkdown/dist/somarkdown.css?raw";
	import highlightCssText from "../assets/vendor/highlight.js-11.9.0-default.min.css?raw";
	import katexCssText from "../assets/vendor/katex-0.16.9.min.css?raw";
	import katexMainRegularUrl from "../assets/vendor/fonts/KaTeX_Main-Regular-0.16.9.woff2?url";
	import katexMainItalicUrl from "../assets/vendor/fonts/KaTeX_Main-Italic-0.16.9.woff2?url";
	import katexMathItalicUrl from "../assets/vendor/fonts/KaTeX_Math-Italic-0.16.9.woff2?url";
	import katexSize1RegularUrl from "../assets/vendor/fonts/KaTeX_Size1-Regular-0.16.9.woff2?url";
	import katexSize2RegularUrl from "../assets/vendor/fonts/KaTeX_Size2-Regular-0.16.9.woff2?url";
	import katexSize3RegularUrl from "../assets/vendor/fonts/KaTeX_Size3-Regular-0.16.9.woff2?url";
	import katexSize4RegularUrl from "../assets/vendor/fonts/KaTeX_Size4-Regular-0.16.9.woff2?url";

	interface Props {
		value?: string;
		linkify?: boolean;
		typographer?: boolean;
		katex?: object;
		smiles?: object;
		img_desc_enabled?: boolean;
		theme?: string;
		elem_classes?: string[];
		visible?: boolean;
		rtl?: boolean;
	}

	let {
		value = "",
		linkify = true,
		typographer = true,
		katex = {},
		smiles = {},
		img_desc_enabled = true,
		theme = "light",
		elem_classes = [],
		visible = true,
		rtl = false
	}: Props = $props();

	let somarkdown: any;
	let host: HTMLDivElement;
	let shadowRoot: ShadowRoot | null = null;
	let contentRoot: HTMLDivElement | null = null;
	let latestHtml = "";
	const KATEX_CORE_FONTS = [
		{ family: "KaTeX_Main", srcUrl: katexMainRegularUrl, style: "normal" },
		{ family: "KaTeX_Main", srcUrl: katexMainItalicUrl, style: "italic" },
		{ family: "KaTeX_Math", srcUrl: katexMathItalicUrl, style: "italic" },
		{ family: "KaTeX_Size1", srcUrl: katexSize1RegularUrl, style: "normal" },
		{ family: "KaTeX_Size2", srcUrl: katexSize2RegularUrl, style: "normal" },
		{ family: "KaTeX_Size3", srcUrl: katexSize3RegularUrl, style: "normal" },
		{ family: "KaTeX_Size4", srcUrl: katexSize4RegularUrl, style: "normal" }
	];
	const KATEX_FONT_FACES = `
		@font-face {
			font-family: KaTeX_Main;
			font-style: normal;
			font-weight: 400;
			src: url("${katexMainRegularUrl}") format("woff2");
		}
		@font-face {
			font-family: KaTeX_Main;
			font-style: italic;
			font-weight: 400;
			src: url("${katexMainItalicUrl}") format("woff2");
		}
		@font-face {
			font-family: KaTeX_Math;
			font-style: italic;
			font-weight: 400;
			src: url("${katexMathItalicUrl}") format("woff2");
		}
		@font-face {
			font-family: KaTeX_Size1;
			font-style: normal;
			font-weight: 400;
			src: url("${katexSize1RegularUrl}") format("woff2");
		}
		@font-face {
			font-family: KaTeX_Size2;
			font-style: normal;
			font-weight: 400;
			src: url("${katexSize2RegularUrl}") format("woff2");
		}
		@font-face {
			font-family: KaTeX_Size3;
			font-style: normal;
			font-weight: 400;
			src: url("${katexSize3RegularUrl}") format("woff2");
		}
		@font-face {
			font-family: KaTeX_Size4;
			font-style: normal;
			font-weight: 400;
			src: url("${katexSize4RegularUrl}") format("woff2");
		}
	`;
	const NORMALIZED_KATEX_CSS = katexCssText.replace(/@font-face\s*\{[\s\S]*?\}\s*/g, "");

	async function ensureKatexFontsLoaded(): Promise<void> {
		if (typeof FontFace === "undefined" || typeof document === "undefined") return;
		const tasks = KATEX_CORE_FONTS.map(async ({ family, srcUrl, style }) => {
			const face = new FontFace(
				family,
				`url("${srcUrl}") format("woff2")`,
				{ style, weight: "400" }
			);
			const loaded = await face.load();
			document.fonts.add(loaded);
		});
		await Promise.allSettled(tasks);
	}

	function resolveThemeClass(mode: string): string {
		if (typeof document !== "undefined") {
			const root = document.documentElement;
			const body = document.body;
			const domHas = (
				el: Element | null,
				token: string
			): boolean =>
				Boolean(
					el &&
						(el.classList.contains(token) ||
							el.getAttribute("data-theme") === token ||
							el.getAttribute("data-color-mode") === token ||
							(el as HTMLElement).dataset?.theme === token)
				);
			if (domHas(root, "dark") || domHas(body, "dark")) return "theme-dark";
			if (domHas(root, "light") || domHas(body, "light")) return "theme-light";
		}
		if (mode === "system" && typeof window !== "undefined") {
			return window.matchMedia("(prefers-color-scheme: dark)").matches
				? "theme-dark"
				: "theme-light";
		}
		if (mode === "dark") return "theme-dark";
		if (mode === "light") return "theme-light";
		return "theme-light";
	}

	function renderShadowContent(renderedHtml: string): void {
		latestHtml = renderedHtml;
		if (!contentRoot) return;
		const themeClass = resolveThemeClass(theme);
		const direction = rtl ? "rtl" : "ltr";
		contentRoot.className = `somarkdown-container ${themeClass}`;
		contentRoot.setAttribute("dir", direction);
		contentRoot.innerHTML = renderedHtml;
	}

	onMount(() => {
		shadowRoot = host.attachShadow({ mode: "open" });
		let observer: MutationObserver | null = null;
		const style = document.createElement("style");
		style.textContent = `
			${KATEX_FONT_FACES}
			${somarkdownCssText}
			${highlightCssText}
			${NORMALIZED_KATEX_CSS}
			:host {
				all: initial;
				display: block;
				width: 100%;
			}
			.somarkdown-container {
				font-family: var(--font, Inter, ui-sans-serif, system-ui, sans-serif);
				color: var(--body-text-color, #1f2937);
				width: 100%;
				overflow-x: auto;
				background-color: transparent !important;
			}
			.theme-light,
			.theme-dark,
			.theme-academic {
				background-color: transparent !important;
			}
			.somarkdown-container * {
				box-sizing: border-box;
			}
		`;
		contentRoot = document.createElement("div");
		shadowRoot.appendChild(style);
		shadowRoot.appendChild(contentRoot);
		renderShadowContent(latestHtml);
		(async () => {
			await ensureKatexFontsLoaded();
		})();
		if (typeof document !== "undefined") {
			observer = new MutationObserver(() => renderShadowContent(latestHtml));
			observer.observe(document.documentElement, {
				attributes: true,
				attributeFilter: ["class", "data-theme", "data-color-mode"]
			});
			if (document.body) {
				observer.observe(document.body, {
					attributes: true,
					attributeFilter: ["class", "data-theme", "data-color-mode"]
				});
			}
		}
		return () => observer?.disconnect();
	});

	$effect(() => {
		const config = {
			html: true,
			linkify,
			typographer,
			imgDescEnabled: img_desc_enabled,
			// line numbers are disabled; enable via the SoMarkDown JS API if needed
			lineNumbers: { enable: false },
			katex: {
				trust: true,
				strict: false,
				...katex
			},
			smiles
			// toc plugin is always loaded by SoMarkDown; it only renders when
			// content contains a [[toc]] marker, so no explicit config is needed
		};
		somarkdown = new SoMarkDown(config);
		const renderedHtml = somarkdown.render(value || "");
		renderShadowContent(renderedHtml);
	});
</script>

<div
	bind:this={host}
	class:hidden={!visible}
	class="somarkdown-host {elem_classes.join(' ')}"
></div>

<style>
	.hidden {
		display: none;
	}
	.somarkdown-host {
		width: 100%;
	}
</style>
