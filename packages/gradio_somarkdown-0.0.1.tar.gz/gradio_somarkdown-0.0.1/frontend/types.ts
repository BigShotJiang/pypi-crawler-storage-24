import type { LoadingStatus } from "@gradio/statustracker";

export interface MarkdownProps {
	value: string;
	sanitize_html: boolean;
	header_links: boolean;
	latex_delimiters: { left: string; right: string; display: boolean }[];
	rtl: boolean;
	line_breaks: boolean;
	padding: boolean;
	buttons: string[] | null;
	height: number | null;
	min_height: number | null;
	max_height: number | null;
	// SoMarkDown specific props
	linkify: boolean;
	typographer: boolean;
	katex: object;
	smiles: object;
	img_desc_enabled: boolean;
}

export interface MarkdownEvents {
	change: string;
	copy: any;
	clear_status: LoadingStatus;
}
