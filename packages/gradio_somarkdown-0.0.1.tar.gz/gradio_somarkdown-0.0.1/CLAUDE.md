# CLAUDE.md — gradio-somarkdown

## Project Overview

A custom Gradio component that replaces the default `gr.Markdown` with the [SoMarkDown](https://github.com/SoMarkAI/SoMarkDown) renderer. SoMarkDown extends standard Markdown with KaTeX math, SMILES chemical structures, mhchem chemical equations, syntax-highlighted code blocks, and Table of Contents generation.

---

## Repository Layout

```
gradio-somarkdown/
├── backend/
│   └── gradio_somarkdown/
│       ├── __init__.py          # Exports SoMarkDown class
│       ├── somarkdown.py        # Python component implementation
│       ├── somarkdown.pyi       # Type stubs
│       └── templates/           # Compiled frontend bundles (generated)
├── frontend/
│   ├── Index.svelte             # Gradio Block wrapper (entry point)
│   ├── Example.svelte           # Gallery/table example renderer
│   ├── types.ts                 # TypeScript interfaces (MarkdownProps, MarkdownEvents)
│   ├── shared/
│   │   └── SoMarkDownWrapper.svelte  # Core: Shadow DOM + SoMarkDown JS renderer
│   ├── assets/vendor/           # Bundled CSS and woff2 fonts
│   │   ├── highlight.js-11.9.0-default.min.css
│   │   ├── katex-0.16.9.min.css
│   │   └── fonts/               # KaTeX woff2 fonts (Main, Math, Size1-4)
│   ├── package.json
│   ├── tsconfig.json
│   └── gradio.config.js         # Vite/Svelte build config
├── demo/
│   ├── app.py                   # Interactive demo app
│   ├── space.py                 # Hugging Face Space documentation demo
│   └── requirements.txt
├── pyproject.toml
└── CLAUDE.md
```

---

## Development Environment

This project uses a `uv`-managed Python 3.12 environment with a configured alias:

```bash
py312          # activate the environment
deactivate     # exit the environment
```

Always activate the environment before running any Python or Gradio commands.

---

## Key Files

### `backend/gradio_somarkdown/somarkdown.py`
The Python `SoMarkDown` class extends Gradio's `Component`. It is a **display-only** component (no user input).

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `value` | `str \| Callable \| None` | `None` | Markdown content to render |
| `linkify` | `bool` | `True` | Auto-convert URLs to links |
| `typographer` | `bool` | `True` | Smart quotes and typography |
| `katex` | `dict \| None` | `None` | KaTeX options (e.g. `{"throwOnError": False}`). `trust` and `strict` are always forced to `True`/`False`. |
| `smiles` | `dict \| None` | `None` | SMILES (chemical structure) renderer config |
| `img_desc_enabled` | `bool` | `True` | Show image descriptions below images |
| `rtl` | `bool` | `False` | Right-to-left text direction |
| `height / min_height / max_height` | `int \| str \| None` | `None` | Container sizing |
| `container` | `bool` | `False` | Wrap in Gradio Block container |
| `padding` | `bool` | `False` | Apply `--block-padding` CSS variable |

Backward-compatibility params (`sanitize_html`, `header_links`, `line_breaks`, `buttons`, `latex_delimiters`) are accepted but not used — they exist to avoid breaking code written for `gr.Markdown`.

**Not exposed as parameters (hardcoded in the frontend):**
- `lineNumbers` — always `{ enable: false }`. The SoMarkDown JS API supports `{ enable: true, nested: true }` if needed.
- `toc` — the TOC plugin is always loaded by SoMarkDown but only renders when content contains a `[[toc]]` marker; no config is passed so SoMarkDown uses its own defaults.

**Events:** `change`, `copy`

**`postprocess`** strips leading/trailing whitespace via `inspect.cleandoc`. **`preprocess`** passes through unchanged.

### `frontend/shared/SoMarkDownWrapper.svelte`
The core rendering component. Key design decisions:

- **Shadow DOM isolation** — all CSS (somarkdown, highlight.js, KaTeX) is injected into a shadow root so it never leaks into or is polluted by the host Gradio page.
- **KaTeX fonts** — 7 `FontFace` objects are loaded dynamically into `document.fonts` for reliable math rendering inside the shadow DOM.
- **Background color** — explicitly set to `transparent !important` on `.somarkdown-container`, `.theme-light`, `.theme-dark`, `.theme-academic` so Gradio's own background shows through.
- **Theme detection** — reads `class`, `data-theme`, `data-color-mode` from `document.documentElement` and `document.body`; a `MutationObserver` re-renders when these change.
- **Reactive rendering** — Svelte 5 `$effect` re-instantiates `SoMarkDown` and re-renders whenever any prop changes.

### `frontend/Index.svelte`
Thin wrapper that:
- Wraps content in a `<Block>` with `overflow_behavior="auto"`
- Adds a `<ScrollFade>` overlay when content overflows a fixed height
- Passes `gradio.shared.theme_mode` as the `theme` prop to `SoMarkDownWrapper`

### `frontend/types.ts`
Defines `MarkdownProps` (all component props) and `MarkdownEvents` (`change`, `copy`, `clear_status`). The interface includes both SoMarkDown-specific props and legacy Markdown props for compatibility.

---

## Build & Package

### Python package
- Build system: `hatchling`
- Wheel includes: `/backend/gradio_somarkdown/` + compiled templates + `.pyi` stubs
- Requires: `gradio>=6.0,<7.0`, Python `>=3.8`

### Frontend
- Framework: Svelte 5 (`^5.48.0`)
- Bundler: Vite via `@gradio/preview`
- Core JS dependency: `somarkdown@^1.2.0`
- Build output goes to `frontend/dist/` and is copied into `backend/gradio_somarkdown/templates/`

---

## Running the Demo

```bash
py312
cd demo
python app.py
```

The demo shows a side-by-side markdown editor and live SoMarkDown renderer, demonstrating KaTeX, SMILES, mhchem, code highlighting, and TOC.

---

## Architecture Notes

### Shadow DOM CSS injection order
Inside `onMount` in `SoMarkDownWrapper.svelte`, styles are injected in this order:
1. KaTeX `@font-face` declarations (custom woff2 URLs)
2. `somarkdown.css` (variables, themes, layout)
3. `highlight.js` default CSS (syntax highlighting)
4. KaTeX CSS with original `@font-face` blocks stripped
5. Host overrides: `:host { display: block; width: 100% }`, `.somarkdown-container` layout, `background-color: transparent !important`

### Theme resolution logic (`resolveThemeClass`)
Priority order:
1. DOM check: `document.documentElement` or `document.body` has `.dark` / `.light` class, `data-theme`, or `data-color-mode`
2. If `theme === "system"`: uses `prefers-color-scheme` media query
3. Explicit `"dark"` / `"light"` prop value
4. Default: `"theme-light"`

### SoMarkDown config object
The JS library is configured per render:
```ts
new SoMarkDown({
  html: true,
  linkify,
  typographer,
  imgDescEnabled: img_desc_enabled,
  lineNumbers: { enable: false },   // hardcoded off
  katex: { trust: true, strict: false, ...katex },
  smiles
  // toc: not passed — SoMarkDown uses its own default; only renders if [[toc]] is in content
})
```
`katex.trust` and `katex.strict` are always forced to `true`/`false` respectively; user-supplied `katex` dict merges on top.
