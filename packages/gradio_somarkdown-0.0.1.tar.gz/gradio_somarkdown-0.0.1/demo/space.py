
import gradio as gr
from app import demo as app
import os

_docs = {'SoMarkDown': {'description': 'Used to render arbitrary SoMarkDown output. Can also render latex enclosed by dollar signs as well as code blocks with syntax highlighting.\nSupported languages are bash, c, cpp, go, java, javascript, json, php, python, rust, sql, and yaml.\nAs this component does not accept user input, it is rarely used as an input component.\n', 'members': {'__init__': {'value': {'type': 'str | I18nData | Callable | None', 'default': 'None', 'description': 'Value to show in SoMarkDown component. If a function is provided, the function will be called each time the app loads to set the initial value of this component.'}, 'linkify': {'type': 'bool', 'default': 'True', 'description': 'If True, automatically converts URL-like text to links.'}, 'typographer': {'type': 'bool', 'default': 'True', 'description': 'If True, enables language-neutral replacements and quotes beautification.'}, 'katex': {'type': 'dict | None', 'default': 'None', 'description': 'Configuration dict for KaTeX options (e.g. ``{"throwOnError": False}``).'}, 'smiles': {'type': 'dict | None', 'default': 'None', 'description': 'Configuration dict for SMILES (chemical structure) rendering options.'}, 'img_desc_enabled': {'type': 'bool', 'default': 'True', 'description': 'If True, displays image descriptions below images.'}, 'label': {'type': 'str | I18nData | None', 'default': 'None', 'description': 'This parameter has no effect.'}, 'every': {'type': 'Timer | float | None', 'default': 'None', 'description': 'Continously calls `value` to recalculate it if `value` is a function (has no effect otherwise). Can provide a Timer whose tick resets `value`, or a float that provides the regular interval for the reset Timer.'}, 'inputs': {'type': 'Component | Sequence[Component] | set[Component] | None', 'default': 'None', 'description': 'Components that are used as inputs to calculate `value` if `value` is a function (has no effect otherwise). `value` is recalculated any time the inputs change.'}, 'show_label': {'type': 'bool | None', 'default': 'None', 'description': 'This parameter has no effect.'}, 'rtl': {'type': 'bool', 'default': 'False', 'description': 'If True, sets the direction of the rendered text to right-to-left. Default is False, which renders text left-to-right.'}, 'visible': {'type': 'bool | Literal["hidden"]', 'default': 'True', 'description': 'If False, component will be hidden. If "hidden", component will be visually hidden and not take up space in the layout but still exist in the DOM.'}, 'elem_id': {'type': 'str | None', 'default': 'None', 'description': 'An optional string that is assigned as the id of this component in the HTML DOM. Can be used for targeting CSS styles.'}, 'elem_classes': {'type': 'list[str] | str | None', 'default': 'None', 'description': 'An optional list of strings that are assigned as the classes of this component in the HTML DOM. Can be used for targeting CSS styles.'}, 'render': {'type': 'bool', 'default': 'True', 'description': 'If False, component will not render be rendered in the Blocks context. Should be used if the intention is to assign event listeners now but render the component later.'}, 'key': {'type': 'int | str | tuple[int | str, ...] | None', 'default': 'None', 'description': "in a gr.render, Components with the same key across re-renders are treated as the same component, not a new component. Properties set in 'preserved_by_key' are not reset across a re-render."}, 'preserved_by_key': {'type': 'list[str] | str | None', 'default': '"value"', 'description': "A list of parameters from this component's constructor. Inside a gr.render() function, if a component is re-rendered with the same key, these (and only these) parameters will be preserved in the UI (if they have been changed by the user or an event listener) instead of re-rendered based on the values provided during constructor."}, 'height': {'type': 'int | str | None', 'default': 'None', 'description': 'The height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If markdown content exceeds the height, the component will scroll.'}, 'max_height': {'type': 'int | str | None', 'default': 'None', 'description': 'The maximum height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If markdown content exceeds the height, the component will scroll. If markdown content is shorter than the height, the component will shrink to fit the content. Will not have any effect if `height` is set and is smaller than `max_height`.'}, 'min_height': {'type': 'int | str | None', 'default': 'None', 'description': 'The minimum height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If markdown content exceeds the height, the component will expand to fit the content. Will not have any effect if `height` is set and is larger than `min_height`.'}, 'container': {'type': 'bool', 'default': 'False', 'description': 'If True, the SoMarkDown component will be displayed in a container. Default is False.'}, 'padding': {'type': 'bool', 'default': 'False', 'description': 'If True, the SoMarkDown component will have a certain padding (set by the `--block-padding` CSS variable) in all directions. Default is False.'}, 'sanitize_html': {'type': 'bool', 'default': 'True', 'description': None}, 'header_links': {'type': 'bool', 'default': 'False', 'description': None}, 'line_breaks': {'type': 'bool', 'default': 'False', 'description': None}, 'buttons': {'type': 'list[Literal["copy"]] | None', 'default': 'None', 'description': None}, 'latex_delimiters': {'type': 'list[dict[str, str | bool]] | None', 'default': 'None', 'description': None}}, 'postprocess': {'value': {'type': 'str | gradio.i18n.I18nData | None', 'description': 'Expects a valid `str` that can be rendered as SoMarkDown.'}}, 'preprocess': {'return': {'type': 'str | None', 'description': 'Passes the `str` of SoMarkDown corresponding to the displayed value.'}, 'value': None}}, 'events': {'change': {'type': None, 'default': None, 'description': 'Triggered when the value of the SoMarkDown changes either because of user input (e.g. a user types in a textbox) OR because of a function update (e.g. an image receives a value from the output of an event trigger). See `.input()` for a listener that is only triggered by user input.'}, 'copy': {'type': None, 'default': None, 'description': 'This listener is triggered when the user copies content from the SoMarkDown. Uses event data gradio.CopyData to carry information about the copied content. See EventData documentation on how to use this event data'}}}, '__meta__': {'additional_interfaces': {}, 'user_fn_refs': {'SoMarkDown': []}}}

abs_path = os.path.join(os.path.dirname(__file__), "css.css")

with gr.Blocks(
    css=abs_path,
    theme=gr.themes.Default(
        font_mono=[
            gr.themes.GoogleFont("Inconsolata"),
            "monospace",
        ],
    ),
) as demo:
    gr.Markdown(
"""
# `gradio_somarkdown`

<div style="display: flex; gap: 7px;">
<img alt="Static Badge" src="https://img.shields.io/badge/version%20-%200.0.1%20-%20orange">  
</div>

Python library for easily interacting with trained machine learning models
""", elem_classes=["md-custom"], header_links=True)
    app.render()
    gr.Markdown(
"""
## Installation

```bash
pip install gradio_somarkdown
```

## Usage

```python
import gradio as gr
from gradio_somarkdown import SoMarkDown

# Example content from https://github.com/SoMarkAI/SoMarkDown/blob/main/example/example_data.js
EXAMPLE_MARKDOWN = r\"\"\"
# SoMarkDown Demo

## Image with description (For AI understaning display)
: **Figure 1:** The Stormtroopocat.

![The Stormtroopocat is sitting in the pic.](https://octodex.github.com/images/stormtroopocat.jpg)

## Tables

: **Table 1:** This is a table example in HTML syntax, only HTML format support spanning cells.

<table>
  <tr>
    <td colspan="4">
      **🚀 SoMarkDown Overview**

      Compatible with CommonMark, supporting components such as mathematics, chemistry, and code highlighting.
    </td>
  </tr>
  <tr>
    <td>
      **📦 Installation**

      `npm install somarkdown`
    </td>
    <td>
      **📐 Display Formula**

      $$ \int_a^b f(x)\,dx $$
    </td>
    <td>
      **🧪 SMILES Aspirin**

      $$\smiles{CC(=O)OC1=CC=CC=C1C(=O)O}$$
    </td>
    <td>
      **✨ Features**

      Paragraph mapping, high-speed rendering, multiple themes.
    </td>
  </tr>
  <tr>
    <td rowspan="2">
      **🖼️ Image Example**

      ![A random example image](https://picsum.photos/250/250?random=1)
    </td>
    <td>
      **🔢 Inline Formula**

      Supports $ \KaTeX $ and chemical extensions.
    </td>
    <td>
      **🎨 Code Highlighting**

      ```javascript
      const smd = new SoMarkDown();
      const html = smd.render(markdown)
      ```
    </td>
    <td>
      **🏷️ Caption Support**

      Caption support for image and table components.
    </td>
  </tr>
  <tr>
    <td>
      **⚡ Build Command**

      `npm run build`
    </td>
    <td>
      **📚 Goal**

      SoMarkDown is also the output target protocol for the document intelligence parsing product [SoMark](https://somark.ai/).
    </td>
    <td>
      **🧩 Image Understanding**

      Supports the display of image understanding results.
    </td>
  </tr>
</table>

: **Table 2:** This is a table example in markdown syntax.

| Option | Description |
| ------ | ----------- |
| data   | path to data files to supply the data that will be passed into templates. |
| engine | engine to be used for processing templates. Handlebars is the default. |
| ext    | extension to be used for dest files. |

## Math
$$ E = mc^2 $$

Inline: $e^{i\pi} + 1 = 0$

## Chemical Structure
$$ \smiles{CC(=O)Oc1ccccc1C(=O)O} $$

SMILES syntax has been integrated into mathematical expressions, allowing them to be easily combined.

$$\Delta G_{total} = \underbrace{\Delta G^{\ominus}}_{\text{Standard}} + RT \ln \left( \frac{[\text{ADP}] \cdot [P_i]}{[\smiles{C1=NC(=C2C(=N1)N(C=N2)[C@H]3[C@@H]([C@@H]([C@H](O3)COP(=O)(O)OP(=O)(O)OP(=O)(O)O)O)O)N}]} \right) < 0$$

## Chemistry (mhchem)
$$ \ce{CO2 + C -> 2 CO} $$

## Code
Inline `code`

Indented code

    // Some comments
    line 1 of code
    line 2 of code
    line 3 of code

Block code "fences"

```
Sample text here...
```

Syntax highlighting

``` js
var foo = function (bar) {
  return bar++;
};

console.log(foo(5));
```

## Blockquotes

> Blockquotes can also be nested...
>> ...by using additional greater-than signs right next to each other...
> > > ...or with spaces between arrows.

## Lists

Unordered

+ Create a list by starting a line with `+`, `-`, or `*`
+ Sub-lists are made by indenting 2 spaces:
  - Marker character change forces new list start:
    * Ac tristique libero volutpat at
    + Facilisis in pretium nisl aliquet
    - Nulla volutpat aliquam velit
+ Very easy!

Ordered

1. Lorem ipsum dolor sit amet
2. Consectetur adipiscing elit
3. Integer molestie lorem at massa

1. You can use sequential numbers...
1. ...or keep all the numbers as `1.`

Start numbering with offset:

57. foo
1. bar

# h1 Heading
## h2 Heading
### h3 Heading
#### h4 Heading
##### h5 Heading
###### h6 Heading

## Horizontal Rules

___

---

***

## Typographic replacements

Enable typographer option to see result.

(c) (C) (r) (R) (tm) (TM) (p) (P) +-

test.. test... test..... test?..... test!....

!!!!!! ???? ,,  -- ---

"Smartypants, double quotes" and 'single quotes'

## Emphasis

**This is bold text**

__This is bold text__

*This is italic text*

_This is italic text_

~~Strikethrough~~
\"\"\".strip()


def render(text, linkify, typographer, img_desc_enabled,
           smiles_disable_colors, smiles_width, smiles_height,
           katex_throw_on_error):
    return SoMarkDown(
        value=text,
        linkify=linkify,
        typographer=typographer,
        img_desc_enabled=img_desc_enabled,
        smiles={
            "disableColors": smiles_disable_colors,
            "width": int(smiles_width),
            "height": int(smiles_height),
        },
        katex={"throwOnError": katex_throw_on_error},
    )


CSS = \"\"\"
/* Fancy gradient divider on the left of the output panel */
#output-col {
    position: relative;
    padding-left: 28px !important;
}
#output-col::before {
    content: '';
    position: absolute;
    left: 10px;
    top: 4%;
    bottom: 4%;
    width: 2px;
    border-radius: 2px;
    background: linear-gradient(
        to bottom,
        transparent 0%,
        #EF871B 20%,
        #EF871B 80%,
        transparent 100%
    );
    box-shadow: 0 0 8px rgba(239, 135, 27, 0.45);
}
\"\"\"

with gr.Blocks(css=CSS) as demo:
    gr.Markdown("# SoMarkDown Component Demo")

    with gr.Row():
        # ── Left column: input + controls ─────────────────────────────────
        with gr.Column(scale=1):
            input_text = gr.Textbox(
                value=EXAMPLE_MARKDOWN,
                lines=12,
                max_lines=40,
                label="Markdown",
                show_label=False,
            )

            gr.Markdown("**General**")
            with gr.Row():
                linkify = gr.Checkbox(label="linkify", value=True)
                typographer = gr.Checkbox(label="typographer", value=True)
                img_desc_enabled = gr.Checkbox(label="img_desc_enabled", value=True)

            gr.Markdown("**SMILES**")
            with gr.Row():
                smiles_disable_colors = gr.Checkbox(label="disableColors", value=False)
                smiles_width = gr.Number(label="width", value=150, minimum=50, maximum=600, step=10)
                smiles_height = gr.Number(label="height", value=150, minimum=50, maximum=600, step=10)

            gr.Markdown("**KaTeX**")
            with gr.Row():
                katex_throw_on_error = gr.Checkbox(label="throwOnError", value=False)

            render_btn = gr.Button("Render", variant="primary")

        # ── Right column: rendered output ─────────────────────────────────
        with gr.Column(scale=1, elem_id="output-col"):
            somarkdown_output = SoMarkDown(
                value=EXAMPLE_MARKDOWN,
                img_desc_enabled=True,
            )

    inputs = [
        input_text,
        linkify,
        typographer,
        img_desc_enabled,
        smiles_disable_colors,
        smiles_width,
        smiles_height,
        katex_throw_on_error,
    ]

    render_btn.click(fn=render, inputs=inputs, outputs=somarkdown_output)
    input_text.change(fn=render, inputs=inputs, outputs=somarkdown_output)


if __name__ == "__main__":
    demo.launch()

```
""", elem_classes=["md-custom"], header_links=True)


    gr.Markdown("""
## `SoMarkDown`

### Initialization
""", elem_classes=["md-custom"], header_links=True)

    gr.ParamViewer(value=_docs["SoMarkDown"]["members"]["__init__"], linkify=[])


    gr.Markdown("### Events")
    gr.ParamViewer(value=_docs["SoMarkDown"]["events"], linkify=['Event'])




    gr.Markdown("""

### User function

The impact on the users predict function varies depending on whether the component is used as an input or output for an event (or both).

- When used as an Input, the component only impacts the input signature of the user function.
- When used as an output, the component only impacts the return signature of the user function.

The code snippet below is accurate in cases where the component is used as both an input and an output.

- **As input:** Is passed, passes the `str` of SoMarkDown corresponding to the displayed value.
- **As output:** Should return, expects a valid `str` that can be rendered as SoMarkDown.

 ```python
def predict(
    value: str | None
) -> str | gradio.i18n.I18nData | None:
    return value
```
""", elem_classes=["md-custom", "SoMarkDown-user-fn"], header_links=True)




    demo.load(None, js=r"""function() {
    const refs = {};
    const user_fn_refs = {
          SoMarkDown: [], };
    requestAnimationFrame(() => {

        Object.entries(user_fn_refs).forEach(([key, refs]) => {
            if (refs.length > 0) {
                const el = document.querySelector(`.${key}-user-fn`);
                if (!el) return;
                refs.forEach(ref => {
                    el.innerHTML = el.innerHTML.replace(
                        new RegExp("\\b"+ref+"\\b", "g"),
                        `<a href="#h-${ref.toLowerCase()}">${ref}</a>`
                    );
                })
            }
        })

        Object.entries(refs).forEach(([key, refs]) => {
            if (refs.length > 0) {
                const el = document.querySelector(`.${key}`);
                if (!el) return;
                refs.forEach(ref => {
                    el.innerHTML = el.innerHTML.replace(
                        new RegExp("\\b"+ref+"\\b", "g"),
                        `<a href="#h-${ref.toLowerCase()}">${ref}</a>`
                    );
                })
            }
        })
    })
}

""")

demo.launch()
