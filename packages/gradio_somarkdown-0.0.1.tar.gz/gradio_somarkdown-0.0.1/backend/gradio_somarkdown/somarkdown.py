"""gr.Markdown() component."""

from __future__ import annotations

import inspect
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any, Literal

from gradio_client.documentation import document

from gradio.components.base import Component
from gradio.events import Events
from gradio.i18n import I18nData

if TYPE_CHECKING:
    from gradio.components import Timer


@document()
class SoMarkDown(Component):
    """
    Used to render arbitrary SoMarkDown output. Can also render latex enclosed by dollar signs as well as code blocks with syntax highlighting.
    Supported languages are bash, c, cpp, go, java, javascript, json, php, python, rust, sql, and yaml.
    As this component does not accept user input, it is rarely used as an input component.

    Demos: blocks_hello, blocks_kinematics
    Guides: key-features
    """

    EVENTS = [
        Events.change,
        Events.copy,
    ]

    def __init__(
        self,
        value: str | I18nData | Callable | None = None,
        *,
        linkify: bool = True,
        typographer: bool = True,
        katex: dict | None = None,
        smiles: dict | None = None,
        img_desc_enabled: bool = True,
        label: str | I18nData | None = None,
        every: Timer | float | None = None,
        inputs: Component | Sequence[Component] | set[Component] | None = None,
        show_label: bool | None = None,
        rtl: bool = False,
        visible: bool | Literal["hidden"] = True,
        elem_id: str | None = None,
        elem_classes: list[str] | str | None = None,
        render: bool = True,
        key: int | str | tuple[int | str, ...] | None = None,
        preserved_by_key: list[str] | str | None = "value",
        height: int | str | None = None,
        max_height: int | str | None = None,
        min_height: int | str | None = None,
        container: bool = False,
        padding: bool = False,
        sanitize_html: bool = True, # Kept for compatibility but not used by SoMarkDown
        header_links: bool = False, # Kept for compatibility
        line_breaks: bool = False, # Kept for compatibility
        buttons: list[Literal["copy"]] | None = None, # Kept for compatibility
        latex_delimiters: list[dict[str, str | bool]] | None = None, # Kept for compatibility
    ):
        """
        Parameters:
            value: Value to show in SoMarkDown component. If a function is provided, the function will be called each time the app loads to set the initial value of this component.
            linkify: If True, automatically converts URL-like text to links.
            typographer: If True, enables language-neutral replacements and quotes beautification.
            katex: Configuration dict for KaTeX options (e.g. ``{"throwOnError": False}``).
                   ``trust`` and ``strict`` are always forced to ``True``/``False`` respectively.
            smiles: Configuration dict for SMILES (chemical structure) rendering options.
            img_desc_enabled: If True, displays image descriptions below images.
            label: This parameter has no effect.
            every: Continously calls `value` to recalculate it if `value` is a function (has no effect otherwise). Can provide a Timer whose tick resets `value`, or a float that provides the regular interval for the reset Timer.
            inputs: Components that are used as inputs to calculate `value` if `value` is a function (has no effect otherwise). `value` is recalculated any time the inputs change.
            show_label: This parameter has no effect.
            rtl: If True, sets the direction of the rendered text to right-to-left. Default is False, which renders text left-to-right.
            visible: If False, component will be hidden. If "hidden", component will be visually hidden and not take up space in the layout but still exist in the DOM.
            elem_id: An optional string that is assigned as the id of this component in the HTML DOM. Can be used for targeting CSS styles.
            elem_classes: An optional list of strings that are assigned as the classes of this component in the HTML DOM. Can be used for targeting CSS styles.
            render: If False, component will not render be rendered in the Blocks context. Should be used if the intention is to assign event listeners now but render the component later.
            key: in a gr.render, Components with the same key across re-renders are treated as the same component, not a new component. Properties set in 'preserved_by_key' are not reset across a re-render.
            preserved_by_key: A list of parameters from this component's constructor. Inside a gr.render() function, if a component is re-rendered with the same key, these (and only these) parameters will be preserved in the UI (if they have been changed by the user or an event listener) instead of re-rendered based on the values provided during constructor.
            height: The height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If markdown content exceeds the height, the component will scroll.
            max_height: The maximum height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If markdown content exceeds the height, the component will scroll. If markdown content is shorter than the height, the component will shrink to fit the content. Will not have any effect if `height` is set and is smaller than `max_height`.
            min_height: The minimum height of the component, specified in pixels if a number is passed, or in CSS units if a string is passed. If markdown content exceeds the height, the component will expand to fit the content. Will not have any effect if `height` is set and is larger than `min_height`.
            container: If True, the SoMarkDown component will be displayed in a container. Default is False.
            padding: If True, the SoMarkDown component will have a certain padding (set by the `--block-padding` CSS variable) in all directions. Default is False.
        """
        self.linkify = linkify
        self.typographer = typographer
        self.katex = katex
        self.smiles = smiles
        self.img_desc_enabled = img_desc_enabled
        
        self.rtl = rtl
        self.height = height
        self.max_height = max_height
        self.min_height = min_height
        self.container = container
        self.padding = padding

        # Kept for backward compatibility with gr.Markdown; not used by SoMarkDown
        self.sanitize_html = sanitize_html
        self.header_links = header_links
        self.line_breaks = line_breaks
        self.buttons = buttons
        self.latex_delimiters = latex_delimiters or []

        super().__init__(
            label=label,
            every=every,
            inputs=inputs,
            show_label=show_label,
            visible=visible,
            elem_id=elem_id,
            elem_classes=elem_classes,
            render=render,
            key=key,
            preserved_by_key=preserved_by_key,
            value=value,
            container=container,
        )

    def preprocess(self, payload: str | None) -> str | None:
        """
        Parameters:
            payload: the `str` of SoMarkDown corresponding to the displayed value.
        Returns:
            Passes the `str` of SoMarkDown corresponding to the displayed value.
        """
        return payload

    def postprocess(self, value: str | I18nData | None) -> str | dict | None:
        """
        Parameters:
            value: Expects a valid `str` that can be rendered as SoMarkDown.
        Returns:
            The same `str` as the input, but with leading and trailing whitespace removed.
            If an I18nData object is provided, returns it serialized for the frontend to translate.
        """
        if value is None:
            return None

        if isinstance(value, I18nData):
            # preserve the I18nData object for frontend translation
            return str(value)

        unindented_y = inspect.cleandoc(value)
        return unindented_y

    def example_payload(self) -> Any:
        return "# Hello!"

    def example_value(self) -> Any:
        return "# Hello!"

    def api_info(self) -> dict[str, Any]:
        return {"type": "string"}
