import { g as i0 } from "./Example-DvozunpH.js";
var Sn = { exports: {} }, n0 = Sn.exports, Hl;
function a0() {
  return Hl || (Hl = 1, (function(e, t) {
    (function(r, i) {
      e.exports = i();
    })(n0, (function() {
      var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", s = "second", o = "minute", l = "hour", c = "day", h = "week", u = "month", d = "quarter", f = "year", g = "date", m = "Invalid Date", y = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, x = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(A) {
        var L = ["th", "st", "nd", "rd"], S = A % 100;
        return "[" + A + (L[(S - 20) % 10] || L[S] || L[0]) + "]";
      } }, _ = function(A, L, S) {
        var E = String(A);
        return !E || E.length >= L ? A : "" + Array(L + 1 - E.length).join(S) + A;
      }, v = { s: _, z: function(A) {
        var L = -A.utcOffset(), S = Math.abs(L), E = Math.floor(S / 60), M = S % 60;
        return (L <= 0 ? "+" : "-") + _(E, 2, "0") + ":" + _(M, 2, "0");
      }, m: function A(L, S) {
        if (L.date() < S.date()) return -A(S, L);
        var E = 12 * (S.year() - L.year()) + (S.month() - L.month()), M = L.clone().add(E, u), q = S - M < 0, Y = L.clone().add(E + (q ? -1 : 1), u);
        return +(-(E + (S - M) / (q ? M - Y : Y - M)) || 0);
      }, a: function(A) {
        return A < 0 ? Math.ceil(A) || 0 : Math.floor(A);
      }, p: function(A) {
        return { M: u, y: f, w: h, d: c, D: g, h: l, m: o, s, ms: a, Q: d }[A] || String(A || "").toLowerCase().replace(/s$/, "");
      }, u: function(A) {
        return A === void 0;
      } }, k = "en", T = {};
      T[k] = b;
      var B = "$isDayjsObject", D = function(A) {
        return A instanceof N || !(!A || !A[B]);
      }, I = function A(L, S, E) {
        var M;
        if (!L) return k;
        if (typeof L == "string") {
          var q = L.toLowerCase();
          T[q] && (M = q), S && (T[q] = S, M = q);
          var Y = L.split("-");
          if (!M && Y.length > 1) return A(Y[0]);
        } else {
          var Z = L.name;
          T[Z] = L, M = Z;
        }
        return !E && M && (k = M), M || !E && k;
      }, O = function(A, L) {
        if (D(A)) return A.clone();
        var S = typeof L == "object" ? L : {};
        return S.date = A, S.args = arguments, new N(S);
      }, $ = v;
      $.l = I, $.i = D, $.w = function(A, L) {
        return O(A, { locale: L.$L, utc: L.$u, x: L.$x, $offset: L.$offset });
      };
      var N = (function() {
        function A(S) {
          this.$L = I(S.locale, null, !0), this.parse(S), this.$x = this.$x || S.x || {}, this[B] = !0;
        }
        var L = A.prototype;
        return L.parse = function(S) {
          this.$d = (function(E) {
            var M = E.date, q = E.utc;
            if (M === null) return /* @__PURE__ */ new Date(NaN);
            if ($.u(M)) return /* @__PURE__ */ new Date();
            if (M instanceof Date) return new Date(M);
            if (typeof M == "string" && !/Z$/i.test(M)) {
              var Y = M.match(y);
              if (Y) {
                var Z = Y[2] - 1 || 0, et = (Y[7] || "0").substring(0, 3);
                return q ? new Date(Date.UTC(Y[1], Z, Y[3] || 1, Y[4] || 0, Y[5] || 0, Y[6] || 0, et)) : new Date(Y[1], Z, Y[3] || 1, Y[4] || 0, Y[5] || 0, Y[6] || 0, et);
              }
            }
            return new Date(M);
          })(S), this.init();
        }, L.init = function() {
          var S = this.$d;
          this.$y = S.getFullYear(), this.$M = S.getMonth(), this.$D = S.getDate(), this.$W = S.getDay(), this.$H = S.getHours(), this.$m = S.getMinutes(), this.$s = S.getSeconds(), this.$ms = S.getMilliseconds();
        }, L.$utils = function() {
          return $;
        }, L.isValid = function() {
          return this.$d.toString() !== m;
        }, L.isSame = function(S, E) {
          var M = O(S);
          return this.startOf(E) <= M && M <= this.endOf(E);
        }, L.isAfter = function(S, E) {
          return O(S) < this.startOf(E);
        }, L.isBefore = function(S, E) {
          return this.endOf(E) < O(S);
        }, L.$g = function(S, E, M) {
          return $.u(S) ? this[E] : this.set(M, S);
        }, L.unix = function() {
          return Math.floor(this.valueOf() / 1e3);
        }, L.valueOf = function() {
          return this.$d.getTime();
        }, L.startOf = function(S, E) {
          var M = this, q = !!$.u(E) || E, Y = $.p(S), Z = function(ie, yt) {
            var ne = $.w(M.$u ? Date.UTC(M.$y, yt, ie) : new Date(M.$y, yt, ie), M);
            return q ? ne : ne.endOf(c);
          }, et = function(ie, yt) {
            return $.w(M.toDate()[ie].apply(M.toDate("s"), (q ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(yt)), M);
          }, K = this.$W, ot = this.$M, at = this.$D, Ct = "set" + (this.$u ? "UTC" : "");
          switch (Y) {
            case f:
              return q ? Z(1, 0) : Z(31, 11);
            case u:
              return q ? Z(1, ot) : Z(0, ot + 1);
            case h:
              var xt = this.$locale().weekStart || 0, Bt = (K < xt ? K + 7 : K) - xt;
              return Z(q ? at - Bt : at + (6 - Bt), ot);
            case c:
            case g:
              return et(Ct + "Hours", 0);
            case l:
              return et(Ct + "Minutes", 1);
            case o:
              return et(Ct + "Seconds", 2);
            case s:
              return et(Ct + "Milliseconds", 3);
            default:
              return this.clone();
          }
        }, L.endOf = function(S) {
          return this.startOf(S, !1);
        }, L.$set = function(S, E) {
          var M, q = $.p(S), Y = "set" + (this.$u ? "UTC" : ""), Z = (M = {}, M[c] = Y + "Date", M[g] = Y + "Date", M[u] = Y + "Month", M[f] = Y + "FullYear", M[l] = Y + "Hours", M[o] = Y + "Minutes", M[s] = Y + "Seconds", M[a] = Y + "Milliseconds", M)[q], et = q === c ? this.$D + (E - this.$W) : E;
          if (q === u || q === f) {
            var K = this.clone().set(g, 1);
            K.$d[Z](et), K.init(), this.$d = K.set(g, Math.min(this.$D, K.daysInMonth())).$d;
          } else Z && this.$d[Z](et);
          return this.init(), this;
        }, L.set = function(S, E) {
          return this.clone().$set(S, E);
        }, L.get = function(S) {
          return this[$.p(S)]();
        }, L.add = function(S, E) {
          var M, q = this;
          S = Number(S);
          var Y = $.p(E), Z = function(ot) {
            var at = O(q);
            return $.w(at.date(at.date() + Math.round(ot * S)), q);
          };
          if (Y === u) return this.set(u, this.$M + S);
          if (Y === f) return this.set(f, this.$y + S);
          if (Y === c) return Z(1);
          if (Y === h) return Z(7);
          var et = (M = {}, M[o] = i, M[l] = n, M[s] = r, M)[Y] || 1, K = this.$d.getTime() + S * et;
          return $.w(K, this);
        }, L.subtract = function(S, E) {
          return this.add(-1 * S, E);
        }, L.format = function(S) {
          var E = this, M = this.$locale();
          if (!this.isValid()) return M.invalidDate || m;
          var q = S || "YYYY-MM-DDTHH:mm:ssZ", Y = $.z(this), Z = this.$H, et = this.$m, K = this.$M, ot = M.weekdays, at = M.months, Ct = M.meridiem, xt = function(yt, ne, ze, ae) {
            return yt && (yt[ne] || yt(E, q)) || ze[ne].slice(0, ae);
          }, Bt = function(yt) {
            return $.s(Z % 12 || 12, yt, "0");
          }, ie = Ct || function(yt, ne, ze) {
            var ae = yt < 12 ? "AM" : "PM";
            return ze ? ae.toLowerCase() : ae;
          };
          return q.replace(x, (function(yt, ne) {
            return ne || (function(ze) {
              switch (ze) {
                case "YY":
                  return String(E.$y).slice(-2);
                case "YYYY":
                  return $.s(E.$y, 4, "0");
                case "M":
                  return K + 1;
                case "MM":
                  return $.s(K + 1, 2, "0");
                case "MMM":
                  return xt(M.monthsShort, K, at, 3);
                case "MMMM":
                  return xt(at, K);
                case "D":
                  return E.$D;
                case "DD":
                  return $.s(E.$D, 2, "0");
                case "d":
                  return String(E.$W);
                case "dd":
                  return xt(M.weekdaysMin, E.$W, ot, 2);
                case "ddd":
                  return xt(M.weekdaysShort, E.$W, ot, 3);
                case "dddd":
                  return ot[E.$W];
                case "H":
                  return String(Z);
                case "HH":
                  return $.s(Z, 2, "0");
                case "h":
                  return Bt(1);
                case "hh":
                  return Bt(2);
                case "a":
                  return ie(Z, et, !0);
                case "A":
                  return ie(Z, et, !1);
                case "m":
                  return String(et);
                case "mm":
                  return $.s(et, 2, "0");
                case "s":
                  return String(E.$s);
                case "ss":
                  return $.s(E.$s, 2, "0");
                case "SSS":
                  return $.s(E.$ms, 3, "0");
                case "Z":
                  return Y;
              }
              return null;
            })(yt) || Y.replace(":", "");
          }));
        }, L.utcOffset = function() {
          return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
        }, L.diff = function(S, E, M) {
          var q, Y = this, Z = $.p(E), et = O(S), K = (et.utcOffset() - this.utcOffset()) * i, ot = this - et, at = function() {
            return $.m(Y, et);
          };
          switch (Z) {
            case f:
              q = at() / 12;
              break;
            case u:
              q = at();
              break;
            case d:
              q = at() / 3;
              break;
            case h:
              q = (ot - K) / 6048e5;
              break;
            case c:
              q = (ot - K) / 864e5;
              break;
            case l:
              q = ot / n;
              break;
            case o:
              q = ot / i;
              break;
            case s:
              q = ot / r;
              break;
            default:
              q = ot;
          }
          return M ? q : $.a(q);
        }, L.daysInMonth = function() {
          return this.endOf(u).$D;
        }, L.$locale = function() {
          return T[this.$L];
        }, L.locale = function(S, E) {
          if (!S) return this.$L;
          var M = this.clone(), q = I(S, E, !0);
          return q && (M.$L = q), M;
        }, L.clone = function() {
          return $.w(this.$d, this);
        }, L.toDate = function() {
          return new Date(this.valueOf());
        }, L.toJSON = function() {
          return this.isValid() ? this.toISOString() : null;
        }, L.toISOString = function() {
          return this.$d.toISOString();
        }, L.toString = function() {
          return this.$d.toUTCString();
        }, A;
      })(), R = N.prototype;
      return O.prototype = R, [["$ms", a], ["$s", s], ["$m", o], ["$H", l], ["$W", c], ["$M", u], ["$y", f], ["$D", g]].forEach((function(A) {
        R[A[1]] = function(L) {
          return this.$g(L, A[0], A[1]);
        };
      })), O.extend = function(A, L) {
        return A.$i || (A(L, N, O), A.$i = !0), O;
      }, O.locale = I, O.isDayjs = D, O.unix = function(A) {
        return O(1e3 * A);
      }, O.en = T[k], O.Ls = T, O.p = {}, O;
    }));
  })(Sn)), Sn.exports;
}
var s0 = a0();
const o0 = /* @__PURE__ */ i0(s0);
var Sh = Object.defineProperty, p = (e, t) => Sh(e, "name", { value: t, configurable: !0 }), l0 = (e, t) => {
  for (var r in t)
    Sh(e, r, { get: t[r], enumerable: !0 });
}, Le = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ p((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ p((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ p((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ p((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ p((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ p((...e) => {
  }, "fatal")
}, vo = /* @__PURE__ */ p(function(e = "fatal") {
  let t = Le.fatal;
  typeof e == "string" ? e.toLowerCase() in Le && (t = Le[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= Le.fatal && (F.fatal = console.error ? console.error.bind(console, Jt("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", Jt("FATAL"))), t <= Le.error && (F.error = console.error ? console.error.bind(console, Jt("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", Jt("ERROR"))), t <= Le.warn && (F.warn = console.warn ? console.warn.bind(console, Jt("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", Jt("WARN"))), t <= Le.info && (F.info = console.info ? console.info.bind(console, Jt("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", Jt("INFO"))), t <= Le.debug && (F.debug = console.debug ? console.debug.bind(console, Jt("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Jt("DEBUG"))), t <= Le.trace && (F.trace = console.debug ? console.debug.bind(console, Jt("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Jt("TRACE")));
}, "setLogLevel"), Jt = /* @__PURE__ */ p((e) => `%c${o0().format("ss.SSS")} : ${e} : `, "format");
const Tn = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return Tn.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return Tn.hue2rgb(a, n, e) * 255;
      case "b":
        return Tn.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), s = (n + a) / 2;
    if (i === "l")
      return s * 100;
    if (n === a)
      return 0;
    const o = n - a, l = s > 0.5 ? o / (2 - n - a) : o / (n + a);
    if (i === "s")
      return l * 100;
    switch (n) {
      case e:
        return ((t - r) / o + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / o + 2) * 60;
      case r:
        return ((e - t) / o + 4) * 60;
      default:
        return -1;
    }
  }
}, c0 = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, h0 = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, st = {
  channel: Tn,
  lang: c0,
  unit: h0
}, We = {};
for (let e = 0; e <= 255; e++)
  We[e] = st.unit.dec2hex(e);
const Et = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class u0 {
  constructor() {
    this.type = Et.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = Et.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class f0 {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new u0();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = Et.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = st.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = st.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = st.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = st.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = st.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = st.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(Et.HSL) && r !== void 0 ? r : (this._ensureHSL(), st.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(Et.HSL) && r !== void 0 ? r : (this._ensureHSL(), st.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(Et.HSL) && r !== void 0 ? r : (this._ensureHSL(), st.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(Et.RGB) && r !== void 0 ? r : (this._ensureRGB(), st.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(Et.RGB) && r !== void 0 ? r : (this._ensureRGB(), st.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(Et.RGB) && r !== void 0 ? r : (this._ensureRGB(), st.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(Et.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(Et.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(Et.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(Et.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(Et.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(Et.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const _a = new f0({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), Er = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(Er.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, s = n > 4, o = s ? 1 : 17, l = s ? 8 : 4, c = a ? 0 : -1, h = s ? 255 : 15;
    return _a.set({
      r: (i >> l * (c + 3) & h) * o,
      g: (i >> l * (c + 2) & h) * o,
      b: (i >> l * (c + 1) & h) * o,
      a: a ? (i & h) * o / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}${We[Math.round(n * 255)]}` : `#${We[Math.round(t)]}${We[Math.round(r)]}${We[Math.round(i)]}`;
  }
}, ar = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(ar.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return st.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return st.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return st.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return st.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(ar.re);
    if (!r)
      return;
    const [, i, n, a, s, o] = r;
    return _a.set({
      h: ar._hue2deg(i),
      s: st.channel.clamp.s(parseFloat(n)),
      l: st.channel.clamp.l(parseFloat(a)),
      a: s ? st.channel.clamp.a(o ? parseFloat(s) / 100 : parseFloat(s)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${st.lang.round(t)}, ${st.lang.round(r)}%, ${st.lang.round(i)}%, ${n})` : `hsl(${st.lang.round(t)}, ${st.lang.round(r)}%, ${st.lang.round(i)}%)`;
  }
}, Ti = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Ti.colors[e];
    if (t)
      return Er.parse(t);
  },
  stringify: (e) => {
    const t = Er.stringify(e);
    for (const r in Ti.colors)
      if (Ti.colors[r] === t)
        return r;
  }
}, xi = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(xi.re);
    if (!r)
      return;
    const [, i, n, a, s, o, l, c, h] = r;
    return _a.set({
      r: st.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: st.channel.clamp.g(s ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: st.channel.clamp.b(l ? parseFloat(o) * 2.55 : parseFloat(o)),
      a: c ? st.channel.clamp.a(h ? parseFloat(c) / 100 : parseFloat(c)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${st.lang.round(t)}, ${st.lang.round(r)}, ${st.lang.round(i)}, ${st.lang.round(n)})` : `rgb(${st.lang.round(t)}, ${st.lang.round(r)}, ${st.lang.round(i)})`;
  }
}, _e = {
  /* VARIABLES */
  format: {
    keyword: Ti,
    hex: Er,
    rgb: xi,
    rgba: xi,
    hsl: ar,
    hsla: ar
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = Er.parse(e) || xi.parse(e) || ar.parse(e) || Ti.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(Et.HSL) || e.data.r === void 0 ? ar.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? xi.stringify(e) : Er.stringify(e)
}, Th = (e, t) => {
  const r = _e.parse(e);
  for (const i in t)
    r[i] = st.channel.clamp[i](t[i]);
  return _e.stringify(r);
}, Bi = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return Th(e, { a: t });
  const n = _a.set({
    r: st.channel.clamp.r(e),
    g: st.channel.clamp.g(t),
    b: st.channel.clamp.b(r),
    a: st.channel.clamp.a(i)
  });
  return _e.stringify(n);
}, d0 = (e) => {
  const { r: t, g: r, b: i } = _e.parse(e), n = 0.2126 * st.channel.toLinear(t) + 0.7152 * st.channel.toLinear(r) + 0.0722 * st.channel.toLinear(i);
  return st.lang.round(n);
}, p0 = (e) => d0(e) >= 0.5, Gi = (e) => !p0(e), Bh = (e, t, r) => {
  const i = _e.parse(e), n = i[t], a = st.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), _e.stringify(i);
}, H = (e, t) => Bh(e, "l", t), tt = (e, t) => Bh(e, "l", -t), w = (e, t) => {
  const r = _e.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return Th(e, i);
}, g0 = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: s } = _e.parse(e), { r: o, g: l, b: c, a: h } = _e.parse(t), u = r / 100, d = u * 2 - 1, f = s - h, m = ((d * f === -1 ? d : (d + f) / (1 + d * f)) + 1) / 2, y = 1 - m, x = i * m + o * y, b = n * m + l * y, _ = a * m + c * y, v = s * u + h * (1 - u);
  return Bi(x, b, _, v);
}, z = (e, t = 100) => {
  const r = _e.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, g0(r, e, t);
};
const {
  entries: Lh,
  setPrototypeOf: jl,
  isFrozen: m0,
  getPrototypeOf: y0,
  getOwnPropertyDescriptor: x0
} = Object;
let {
  freeze: Ht,
  seal: ee,
  create: Bn
} = Object, {
  apply: vs,
  construct: Ss
} = typeof Reflect < "u" && Reflect;
Ht || (Ht = function(t) {
  return t;
});
ee || (ee = function(t) {
  return t;
});
vs || (vs = function(t, r) {
  for (var i = arguments.length, n = new Array(i > 2 ? i - 2 : 0), a = 2; a < i; a++)
    n[a - 2] = arguments[a];
  return t.apply(r, n);
});
Ss || (Ss = function(t) {
  for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
    i[n - 1] = arguments[n];
  return new t(...i);
});
const dn = jt(Array.prototype.forEach), b0 = jt(Array.prototype.lastIndexOf), Yl = jt(Array.prototype.pop), ai = jt(Array.prototype.push), C0 = jt(Array.prototype.splice), Ln = jt(String.prototype.toLowerCase), is = jt(String.prototype.toString), ns = jt(String.prototype.match), si = jt(String.prototype.replace), _0 = jt(String.prototype.indexOf), w0 = jt(String.prototype.trim), Kt = jt(Object.prototype.hasOwnProperty), Nt = jt(RegExp.prototype.test), oi = k0(TypeError);
function jt(e) {
  return function(t) {
    t instanceof RegExp && (t.lastIndex = 0);
    for (var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), n = 1; n < r; n++)
      i[n - 1] = arguments[n];
    return vs(e, t, i);
  };
}
function k0(e) {
  return function() {
    for (var t = arguments.length, r = new Array(t), i = 0; i < t; i++)
      r[i] = arguments[i];
    return Ss(e, r);
  };
}
function ct(e, t) {
  let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Ln;
  jl && jl(e, null);
  let i = t.length;
  for (; i--; ) {
    let n = t[i];
    if (typeof n == "string") {
      const a = r(n);
      a !== n && (m0(t) || (t[i] = a), n = a);
    }
    e[n] = !0;
  }
  return e;
}
function v0(e) {
  for (let t = 0; t < e.length; t++)
    Kt(e, t) || (e[t] = null);
  return e;
}
function me(e) {
  const t = Bn(null);
  for (const [r, i] of Lh(e))
    Kt(e, r) && (Array.isArray(i) ? t[r] = v0(i) : i && typeof i == "object" && i.constructor === Object ? t[r] = me(i) : t[r] = i);
  return t;
}
function li(e, t) {
  for (; e !== null; ) {
    const i = x0(e, t);
    if (i) {
      if (i.get)
        return jt(i.get);
      if (typeof i.value == "function")
        return jt(i.value);
    }
    e = y0(e);
  }
  function r() {
    return null;
  }
  return r;
}
const Ul = Ht(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), as = Ht(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), ss = Ht(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), S0 = Ht(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), os = Ht(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), T0 = Ht(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), Gl = Ht(["#text"]), Xl = Ht(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), ls = Ht(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Vl = Ht(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), pn = Ht(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), B0 = ee(/\{\{[\w\W]*|[\w\W]*\}\}/gm), L0 = ee(/<%[\w\W]*|[\w\W]*%>/gm), A0 = ee(/\$\{[\w\W]*/gm), M0 = ee(/^data-[\-\w.\u00B7-\uFFFF]+$/), $0 = ee(/^aria-[\-\w]+$/), Ah = ee(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), E0 = ee(/^(?:\w+script|data):/i), F0 = ee(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Mh = ee(/^html$/i), D0 = ee(/^[a-z][.\w]*(-[.\w]+)+$/i);
var Zl = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: $0,
  ATTR_WHITESPACE: F0,
  CUSTOM_ELEMENT: D0,
  DATA_ATTR: M0,
  DOCTYPE_NAME: Mh,
  ERB_EXPR: L0,
  IS_ALLOWED_URI: Ah,
  IS_SCRIPT_OR_DATA: E0,
  MUSTACHE_EXPR: B0,
  TMPLIT_EXPR: A0
});
const ci = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, O0 = function() {
  return typeof window > "u" ? null : window;
}, R0 = function(t, r) {
  if (typeof t != "object" || typeof t.createPolicy != "function")
    return null;
  let i = null;
  const n = "data-tt-policy-suffix";
  r && r.hasAttribute(n) && (i = r.getAttribute(n));
  const a = "dompurify" + (i ? "#" + i : "");
  try {
    return t.createPolicy(a, {
      createHTML(s) {
        return s;
      },
      createScriptURL(s) {
        return s;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + a + " could not be created."), null;
  }
}, Kl = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function $h() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : O0();
  const t = (J) => $h(J);
  if (t.version = "3.3.3", t.removed = [], !e || !e.document || e.document.nodeType !== ci.document || !e.Element)
    return t.isSupported = !1, t;
  let {
    document: r
  } = e;
  const i = r, n = i.currentScript, {
    DocumentFragment: a,
    HTMLTemplateElement: s,
    Node: o,
    Element: l,
    NodeFilter: c,
    NamedNodeMap: h = e.NamedNodeMap || e.MozNamedAttrMap,
    HTMLFormElement: u,
    DOMParser: d,
    trustedTypes: f
  } = e, g = l.prototype, m = li(g, "cloneNode"), y = li(g, "remove"), x = li(g, "nextSibling"), b = li(g, "childNodes"), _ = li(g, "parentNode");
  if (typeof s == "function") {
    const J = r.createElement("template");
    J.content && J.content.ownerDocument && (r = J.content.ownerDocument);
  }
  let v, k = "";
  const {
    implementation: T,
    createNodeIterator: B,
    createDocumentFragment: D,
    getElementsByTagName: I
  } = r, {
    importNode: O
  } = i;
  let $ = Kl();
  t.isSupported = typeof Lh == "function" && typeof _ == "function" && T && T.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: N,
    ERB_EXPR: R,
    TMPLIT_EXPR: A,
    DATA_ATTR: L,
    ARIA_ATTR: S,
    IS_SCRIPT_OR_DATA: E,
    ATTR_WHITESPACE: M,
    CUSTOM_ELEMENT: q
  } = Zl;
  let {
    IS_ALLOWED_URI: Y
  } = Zl, Z = null;
  const et = ct({}, [...Ul, ...as, ...ss, ...os, ...Gl]);
  let K = null;
  const ot = ct({}, [...Xl, ...ls, ...Vl, ...pn]);
  let at = Object.seal(Bn(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ct = null, xt = null;
  const Bt = Object.seal(Bn(null, {
    tagCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    }
  }));
  let ie = !0, yt = !0, ne = !1, ze = !0, ae = !1, sn = !0, Je = !1, Ga = !1, Xa = !1, wr = !1, on = !1, ln = !1, Tl = !0, Bl = !1;
  const Vm = "user-content-";
  let Va = !0, ii = !1, kr = {}, pe = null;
  const Za = ct({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Ll = null;
  const Al = ct({}, ["audio", "video", "img", "source", "image", "track"]);
  let Ka = null;
  const Ml = ct({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), cn = "http://www.w3.org/1998/Math/MathML", hn = "http://www.w3.org/2000/svg", Se = "http://www.w3.org/1999/xhtml";
  let vr = Se, Qa = !1, Ja = null;
  const Zm = ct({}, [cn, hn, Se], is);
  let un = ct({}, ["mi", "mo", "mn", "ms", "mtext"]), fn = ct({}, ["annotation-xml"]);
  const Km = ct({}, ["title", "style", "font", "a", "script"]);
  let ni = null;
  const Qm = ["application/xhtml+xml", "text/html"], Jm = "text/html";
  let kt = null, Sr = null;
  const t0 = r.createElement("form"), $l = function(C) {
    return C instanceof RegExp || C instanceof Function;
  }, ts = function() {
    let C = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Sr && Sr === C)) {
      if ((!C || typeof C != "object") && (C = {}), C = me(C), ni = // eslint-disable-next-line unicorn/prefer-includes
      Qm.indexOf(C.PARSER_MEDIA_TYPE) === -1 ? Jm : C.PARSER_MEDIA_TYPE, kt = ni === "application/xhtml+xml" ? is : Ln, Z = Kt(C, "ALLOWED_TAGS") ? ct({}, C.ALLOWED_TAGS, kt) : et, K = Kt(C, "ALLOWED_ATTR") ? ct({}, C.ALLOWED_ATTR, kt) : ot, Ja = Kt(C, "ALLOWED_NAMESPACES") ? ct({}, C.ALLOWED_NAMESPACES, is) : Zm, Ka = Kt(C, "ADD_URI_SAFE_ATTR") ? ct(me(Ml), C.ADD_URI_SAFE_ATTR, kt) : Ml, Ll = Kt(C, "ADD_DATA_URI_TAGS") ? ct(me(Al), C.ADD_DATA_URI_TAGS, kt) : Al, pe = Kt(C, "FORBID_CONTENTS") ? ct({}, C.FORBID_CONTENTS, kt) : Za, Ct = Kt(C, "FORBID_TAGS") ? ct({}, C.FORBID_TAGS, kt) : me({}), xt = Kt(C, "FORBID_ATTR") ? ct({}, C.FORBID_ATTR, kt) : me({}), kr = Kt(C, "USE_PROFILES") ? C.USE_PROFILES : !1, ie = C.ALLOW_ARIA_ATTR !== !1, yt = C.ALLOW_DATA_ATTR !== !1, ne = C.ALLOW_UNKNOWN_PROTOCOLS || !1, ze = C.ALLOW_SELF_CLOSE_IN_ATTR !== !1, ae = C.SAFE_FOR_TEMPLATES || !1, sn = C.SAFE_FOR_XML !== !1, Je = C.WHOLE_DOCUMENT || !1, wr = C.RETURN_DOM || !1, on = C.RETURN_DOM_FRAGMENT || !1, ln = C.RETURN_TRUSTED_TYPE || !1, Xa = C.FORCE_BODY || !1, Tl = C.SANITIZE_DOM !== !1, Bl = C.SANITIZE_NAMED_PROPS || !1, Va = C.KEEP_CONTENT !== !1, ii = C.IN_PLACE || !1, Y = C.ALLOWED_URI_REGEXP || Ah, vr = C.NAMESPACE || Se, un = C.MATHML_TEXT_INTEGRATION_POINTS || un, fn = C.HTML_INTEGRATION_POINTS || fn, at = C.CUSTOM_ELEMENT_HANDLING || {}, C.CUSTOM_ELEMENT_HANDLING && $l(C.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (at.tagNameCheck = C.CUSTOM_ELEMENT_HANDLING.tagNameCheck), C.CUSTOM_ELEMENT_HANDLING && $l(C.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (at.attributeNameCheck = C.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), C.CUSTOM_ELEMENT_HANDLING && typeof C.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (at.allowCustomizedBuiltInElements = C.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), ae && (yt = !1), on && (wr = !0), kr && (Z = ct({}, Gl), K = Bn(null), kr.html === !0 && (ct(Z, Ul), ct(K, Xl)), kr.svg === !0 && (ct(Z, as), ct(K, ls), ct(K, pn)), kr.svgFilters === !0 && (ct(Z, ss), ct(K, ls), ct(K, pn)), kr.mathMl === !0 && (ct(Z, os), ct(K, Vl), ct(K, pn))), Kt(C, "ADD_TAGS") || (Bt.tagCheck = null), Kt(C, "ADD_ATTR") || (Bt.attributeCheck = null), C.ADD_TAGS && (typeof C.ADD_TAGS == "function" ? Bt.tagCheck = C.ADD_TAGS : (Z === et && (Z = me(Z)), ct(Z, C.ADD_TAGS, kt))), C.ADD_ATTR && (typeof C.ADD_ATTR == "function" ? Bt.attributeCheck = C.ADD_ATTR : (K === ot && (K = me(K)), ct(K, C.ADD_ATTR, kt))), C.ADD_URI_SAFE_ATTR && ct(Ka, C.ADD_URI_SAFE_ATTR, kt), C.FORBID_CONTENTS && (pe === Za && (pe = me(pe)), ct(pe, C.FORBID_CONTENTS, kt)), C.ADD_FORBID_CONTENTS && (pe === Za && (pe = me(pe)), ct(pe, C.ADD_FORBID_CONTENTS, kt)), Va && (Z["#text"] = !0), Je && ct(Z, ["html", "head", "body"]), Z.table && (ct(Z, ["tbody"]), delete Ct.tbody), C.TRUSTED_TYPES_POLICY) {
        if (typeof C.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw oi('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof C.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw oi('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        v = C.TRUSTED_TYPES_POLICY, k = v.createHTML("");
      } else
        v === void 0 && (v = R0(f, n)), v !== null && typeof k == "string" && (k = v.createHTML(""));
      Ht && Ht(C), Sr = C;
    }
  }, El = ct({}, [...as, ...ss, ...S0]), Fl = ct({}, [...os, ...T0]), e0 = function(C) {
    let P = _(C);
    (!P || !P.tagName) && (P = {
      namespaceURI: vr,
      tagName: "template"
    });
    const X = Ln(C.tagName), gt = Ln(P.tagName);
    return Ja[C.namespaceURI] ? C.namespaceURI === hn ? P.namespaceURI === Se ? X === "svg" : P.namespaceURI === cn ? X === "svg" && (gt === "annotation-xml" || un[gt]) : !!El[X] : C.namespaceURI === cn ? P.namespaceURI === Se ? X === "math" : P.namespaceURI === hn ? X === "math" && fn[gt] : !!Fl[X] : C.namespaceURI === Se ? P.namespaceURI === hn && !fn[gt] || P.namespaceURI === cn && !un[gt] ? !1 : !Fl[X] && (Km[X] || !El[X]) : !!(ni === "application/xhtml+xml" && Ja[C.namespaceURI]) : !1;
  }, ge = function(C) {
    ai(t.removed, {
      element: C
    });
    try {
      _(C).removeChild(C);
    } catch {
      y(C);
    }
  }, tr = function(C, P) {
    try {
      ai(t.removed, {
        attribute: P.getAttributeNode(C),
        from: P
      });
    } catch {
      ai(t.removed, {
        attribute: null,
        from: P
      });
    }
    if (P.removeAttribute(C), C === "is")
      if (wr || on)
        try {
          ge(P);
        } catch {
        }
      else
        try {
          P.setAttribute(C, "");
        } catch {
        }
  }, Dl = function(C) {
    let P = null, X = null;
    if (Xa)
      C = "<remove></remove>" + C;
    else {
      const _t = ns(C, /^[\r\n\t ]+/);
      X = _t && _t[0];
    }
    ni === "application/xhtml+xml" && vr === Se && (C = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + C + "</body></html>");
    const gt = v ? v.createHTML(C) : C;
    if (vr === Se)
      try {
        P = new d().parseFromString(gt, ni);
      } catch {
      }
    if (!P || !P.documentElement) {
      P = T.createDocument(vr, "template", null);
      try {
        P.documentElement.innerHTML = Qa ? k : gt;
      } catch {
      }
    }
    const $t = P.body || P.documentElement;
    return C && X && $t.insertBefore(r.createTextNode(X), $t.childNodes[0] || null), vr === Se ? I.call(P, Je ? "html" : "body")[0] : Je ? P.documentElement : $t;
  }, Ol = function(C) {
    return B.call(
      C.ownerDocument || C,
      C,
      // eslint-disable-next-line no-bitwise
      c.SHOW_ELEMENT | c.SHOW_COMMENT | c.SHOW_TEXT | c.SHOW_PROCESSING_INSTRUCTION | c.SHOW_CDATA_SECTION,
      null
    );
  }, es = function(C) {
    return C instanceof u && (typeof C.nodeName != "string" || typeof C.textContent != "string" || typeof C.removeChild != "function" || !(C.attributes instanceof h) || typeof C.removeAttribute != "function" || typeof C.setAttribute != "function" || typeof C.namespaceURI != "string" || typeof C.insertBefore != "function" || typeof C.hasChildNodes != "function");
  }, Rl = function(C) {
    return typeof o == "function" && C instanceof o;
  };
  function Te(J, C, P) {
    dn(J, (X) => {
      X.call(t, C, P, Sr);
    });
  }
  const Il = function(C) {
    let P = null;
    if (Te($.beforeSanitizeElements, C, null), es(C))
      return ge(C), !0;
    const X = kt(C.nodeName);
    if (Te($.uponSanitizeElement, C, {
      tagName: X,
      allowedTags: Z
    }), sn && C.hasChildNodes() && !Rl(C.firstElementChild) && Nt(/<[/\w!]/g, C.innerHTML) && Nt(/<[/\w!]/g, C.textContent) || C.nodeType === ci.progressingInstruction || sn && C.nodeType === ci.comment && Nt(/<[/\w]/g, C.data))
      return ge(C), !0;
    if (!(Bt.tagCheck instanceof Function && Bt.tagCheck(X)) && (!Z[X] || Ct[X])) {
      if (!Ct[X] && Nl(X) && (at.tagNameCheck instanceof RegExp && Nt(at.tagNameCheck, X) || at.tagNameCheck instanceof Function && at.tagNameCheck(X)))
        return !1;
      if (Va && !pe[X]) {
        const gt = _(C) || C.parentNode, $t = b(C) || C.childNodes;
        if ($t && gt) {
          const _t = $t.length;
          for (let Yt = _t - 1; Yt >= 0; --Yt) {
            const Be = m($t[Yt], !0);
            Be.__removalCount = (C.__removalCount || 0) + 1, gt.insertBefore(Be, x(C));
          }
        }
      }
      return ge(C), !0;
    }
    return C instanceof l && !e0(C) || (X === "noscript" || X === "noembed" || X === "noframes") && Nt(/<\/no(script|embed|frames)/i, C.innerHTML) ? (ge(C), !0) : (ae && C.nodeType === ci.text && (P = C.textContent, dn([N, R, A], (gt) => {
      P = si(P, gt, " ");
    }), C.textContent !== P && (ai(t.removed, {
      element: C.cloneNode()
    }), C.textContent = P)), Te($.afterSanitizeElements, C, null), !1);
  }, Pl = function(C, P, X) {
    if (xt[P] || Tl && (P === "id" || P === "name") && (X in r || X in t0))
      return !1;
    if (!(yt && !xt[P] && Nt(L, P))) {
      if (!(ie && Nt(S, P))) {
        if (!(Bt.attributeCheck instanceof Function && Bt.attributeCheck(P, C))) {
          if (!K[P] || xt[P]) {
            if (
              // First condition does a very basic check if a) it's basically a valid custom element tagname AND
              // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
              !(Nl(C) && (at.tagNameCheck instanceof RegExp && Nt(at.tagNameCheck, C) || at.tagNameCheck instanceof Function && at.tagNameCheck(C)) && (at.attributeNameCheck instanceof RegExp && Nt(at.attributeNameCheck, P) || at.attributeNameCheck instanceof Function && at.attributeNameCheck(P, C)) || // Alternative, second condition checks if it's an `is`-attribute, AND
              // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
              P === "is" && at.allowCustomizedBuiltInElements && (at.tagNameCheck instanceof RegExp && Nt(at.tagNameCheck, X) || at.tagNameCheck instanceof Function && at.tagNameCheck(X)))
            ) return !1;
          } else if (!Ka[P]) {
            if (!Nt(Y, si(X, M, ""))) {
              if (!((P === "src" || P === "xlink:href" || P === "href") && C !== "script" && _0(X, "data:") === 0 && Ll[C])) {
                if (!(ne && !Nt(E, si(X, M, "")))) {
                  if (X)
                    return !1;
                }
              }
            }
          }
        }
      }
    }
    return !0;
  }, Nl = function(C) {
    return C !== "annotation-xml" && ns(C, q);
  }, zl = function(C) {
    Te($.beforeSanitizeAttributes, C, null);
    const {
      attributes: P
    } = C;
    if (!P || es(C))
      return;
    const X = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: K,
      forceKeepAttr: void 0
    };
    let gt = P.length;
    for (; gt--; ) {
      const $t = P[gt], {
        name: _t,
        namespaceURI: Yt,
        value: Be
      } = $t, Tr = kt(_t), rs = Be;
      let Lt = _t === "value" ? rs : w0(rs);
      if (X.attrName = Tr, X.attrValue = Lt, X.keepAttr = !0, X.forceKeepAttr = void 0, Te($.uponSanitizeAttribute, C, X), Lt = X.attrValue, Bl && (Tr === "id" || Tr === "name") && (tr(_t, C), Lt = Vm + Lt), sn && Nt(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, Lt)) {
        tr(_t, C);
        continue;
      }
      if (Tr === "attributename" && ns(Lt, "href")) {
        tr(_t, C);
        continue;
      }
      if (X.forceKeepAttr)
        continue;
      if (!X.keepAttr) {
        tr(_t, C);
        continue;
      }
      if (!ze && Nt(/\/>/i, Lt)) {
        tr(_t, C);
        continue;
      }
      ae && dn([N, R, A], (ql) => {
        Lt = si(Lt, ql, " ");
      });
      const Wl = kt(C.nodeName);
      if (!Pl(Wl, Tr, Lt)) {
        tr(_t, C);
        continue;
      }
      if (v && typeof f == "object" && typeof f.getAttributeType == "function" && !Yt)
        switch (f.getAttributeType(Wl, Tr)) {
          case "TrustedHTML": {
            Lt = v.createHTML(Lt);
            break;
          }
          case "TrustedScriptURL": {
            Lt = v.createScriptURL(Lt);
            break;
          }
        }
      if (Lt !== rs)
        try {
          Yt ? C.setAttributeNS(Yt, _t, Lt) : C.setAttribute(_t, Lt), es(C) ? ge(C) : Yl(t.removed);
        } catch {
          tr(_t, C);
        }
    }
    Te($.afterSanitizeAttributes, C, null);
  }, r0 = function J(C) {
    let P = null;
    const X = Ol(C);
    for (Te($.beforeSanitizeShadowDOM, C, null); P = X.nextNode(); )
      Te($.uponSanitizeShadowNode, P, null), Il(P), zl(P), P.content instanceof a && J(P.content);
    Te($.afterSanitizeShadowDOM, C, null);
  };
  return t.sanitize = function(J) {
    let C = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, P = null, X = null, gt = null, $t = null;
    if (Qa = !J, Qa && (J = "<!-->"), typeof J != "string" && !Rl(J))
      if (typeof J.toString == "function") {
        if (J = J.toString(), typeof J != "string")
          throw oi("dirty is not a string, aborting");
      } else
        throw oi("toString is not a function");
    if (!t.isSupported)
      return J;
    if (Ga || ts(C), t.removed = [], typeof J == "string" && (ii = !1), ii) {
      if (J.nodeName) {
        const Be = kt(J.nodeName);
        if (!Z[Be] || Ct[Be])
          throw oi("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (J instanceof o)
      P = Dl("<!---->"), X = P.ownerDocument.importNode(J, !0), X.nodeType === ci.element && X.nodeName === "BODY" || X.nodeName === "HTML" ? P = X : P.appendChild(X);
    else {
      if (!wr && !ae && !Je && // eslint-disable-next-line unicorn/prefer-includes
      J.indexOf("<") === -1)
        return v && ln ? v.createHTML(J) : J;
      if (P = Dl(J), !P)
        return wr ? null : ln ? k : "";
    }
    P && Xa && ge(P.firstChild);
    const _t = Ol(ii ? J : P);
    for (; gt = _t.nextNode(); )
      Il(gt), zl(gt), gt.content instanceof a && r0(gt.content);
    if (ii)
      return J;
    if (wr) {
      if (on)
        for ($t = D.call(P.ownerDocument); P.firstChild; )
          $t.appendChild(P.firstChild);
      else
        $t = P;
      return (K.shadowroot || K.shadowrootmode) && ($t = O.call(i, $t, !0)), $t;
    }
    let Yt = Je ? P.outerHTML : P.innerHTML;
    return Je && Z["!doctype"] && P.ownerDocument && P.ownerDocument.doctype && P.ownerDocument.doctype.name && Nt(Mh, P.ownerDocument.doctype.name) && (Yt = "<!DOCTYPE " + P.ownerDocument.doctype.name + `>
` + Yt), ae && dn([N, R, A], (Be) => {
      Yt = si(Yt, Be, " ");
    }), v && ln ? v.createHTML(Yt) : Yt;
  }, t.setConfig = function() {
    let J = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    ts(J), Ga = !0;
  }, t.clearConfig = function() {
    Sr = null, Ga = !1;
  }, t.isValidAttribute = function(J, C, P) {
    Sr || ts({});
    const X = kt(J), gt = kt(C);
    return Pl(X, gt, P);
  }, t.addHook = function(J, C) {
    typeof C == "function" && ai($[J], C);
  }, t.removeHook = function(J, C) {
    if (C !== void 0) {
      const P = b0($[J], C);
      return P === -1 ? void 0 : C0($[J], P, 1)[0];
    }
    return Yl($[J]);
  }, t.removeHooks = function(J) {
    $[J] = [];
  }, t.removeAllHooks = function() {
    $ = Kl();
  }, t;
}
var Hr = $h(), Eh = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, Li = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, I0 = /\s*%%.*\n/gm, Or, Fh = (Or = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, p(Or, "UnknownDiagramError"), Or), ur = {}, So = /* @__PURE__ */ p(function(e, t) {
  e = e.replace(Eh, "").replace(Li, "").replace(I0, `
`);
  for (const [r, { detector: i }] of Object.entries(ur))
    if (i(e, t))
      return r;
  throw new Fh(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), Ts = /* @__PURE__ */ p((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    Dh(t, r, i);
}, "registerLazyLoadedDiagrams"), Dh = /* @__PURE__ */ p((e, t, r) => {
  ur[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), ur[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), P0 = /* @__PURE__ */ p((e) => ur[e].loader, "getDiagramLoader"), Bs = /* @__PURE__ */ p((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => Bs(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && t[a] !== null && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = Bs(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), St = Bs, wa = "#ffffff", ka = "#f2f2f2", zt = /* @__PURE__ */ p((e, t) => t ? w(e, { s: -40, l: 10 }) : w(e, { s: -40, l: -10 }), "mkBorder"), Rr, N0 = (Rr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || w(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || w(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || zt(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || zt(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || z(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || z(this.tertiaryColor), this.lineColor = this.lineColor || z(this.background), this.arrowheadColor = this.arrowheadColor || z(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? tt(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || tt(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || z(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || H(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || tt(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || tt(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || w(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || w(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || w(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || w(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || w(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || w(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || w(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || w(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || w(this.primaryColor, { h: 330 }), this.darkMode)
      for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
        this["cScale" + r] = tt(this["cScale" + r], 75);
    else
      for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
        this["cScale" + r] = tt(this["cScale" + r], 25);
    for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
      this["cScaleInv" + r] = this["cScaleInv" + r] || z(this["cScale" + r]);
    for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
      this.darkMode ? this["cScalePeer" + r] = this["cScalePeer" + r] || H(this["cScale" + r], 10) : this["cScalePeer" + r] = this["cScalePeer" + r] || tt(this["cScale" + r], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let r = 0; r < this.THEME_COLOR_LIMIT; r++)
      this["cScaleLabel" + r] = this["cScaleLabel" + r] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let r = 0; r < 5; r++)
      this["surface" + r] = this["surface" + r] || w(this.mainBkg, { h: 180, s: -15, l: t * (5 + r * 3) }), this["surfacePeer" + r] = this["surfacePeer" + r] || w(this.mainBkg, { h: 180, s: -15, l: t * (8 + r * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || w(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || w(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || w(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || w(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || w(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || w(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || w(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || w(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || w(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || w(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || w(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || w(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || w(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || w(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || w(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.venn1 = this.venn1 ?? w(this.primaryColor, { l: -30 }), this.venn2 = this.venn2 ?? w(this.secondaryColor, { l: -30 }), this.venn3 = this.venn3 ?? w(this.tertiaryColor, { l: -30 }), this.venn4 = this.venn4 ?? w(this.primaryColor, { h: 60, l: -30 }), this.venn5 = this.venn5 ?? w(this.primaryColor, { h: -60, l: -30 }), this.venn6 = this.venn6 ?? w(this.secondaryColor, { h: 60, l: -30 }), this.venn7 = this.venn7 ?? w(this.primaryColor, { h: 120, l: -30 }), this.venn8 = this.venn8 ?? w(this.secondaryColor, { h: 120, l: -30 }), this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor, this.vennSetTextColor = this.vennSetTextColor ?? this.textColor, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || w(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || w(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || w(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || w(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || w(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || w(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : tt(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? tt(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || w(this.primaryColor, { h: -30 }), this.git4 = this.git4 || w(this.primaryColor, { h: -60 }), this.git5 = this.git5 || w(this.primaryColor, { h: -90 }), this.git6 = this.git6 || w(this.primaryColor, { h: 60 }), this.git7 = this.git7 || w(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = tt(this.git0, 25), this.git1 = tt(this.git1, 25), this.git2 = tt(this.git2, 25), this.git3 = tt(this.git3, 25), this.git4 = tt(this.git4, 25), this.git5 = tt(this.git5, 25), this.git6 = tt(this.git6, 25), this.git7 = tt(this.git7, 25)), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || wa, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || ka;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Rr, "Theme"), Rr), z0 = /* @__PURE__ */ p((e) => {
  const t = new N0();
  return t.calculate(e), t;
}, "getThemeVariables"), Ir, W0 = (Ir = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = H(this.primaryColor, 16), this.tertiaryColor = w(this.primaryColor, { h: -160 }), this.primaryBorderColor = z(this.background), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = H(z("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Bi(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = tt("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = tt(this.sectionBkgColor, 10), this.taskBorderColor = Bi(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Bi(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || H(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || tt(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    this.secondBkg = H(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = H(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = H(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = z(this.doneTaskBkgColor), this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = w(this.primaryColor, { h: 64 }), this.fillType3 = w(this.secondaryColor, { h: 64 }), this.fillType4 = w(this.primaryColor, { h: -64 }), this.fillType5 = w(this.secondaryColor, { h: -64 }), this.fillType6 = w(this.primaryColor, { h: 128 }), this.fillType7 = w(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || w(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || w(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || w(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || w(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || w(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || w(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || w(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || w(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || w(this.primaryColor, { h: 330 });
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || z(this["cScale" + t]);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScalePeer" + t] = this["cScalePeer" + t] || H(this["cScale" + t], 10);
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || w(this.mainBkg, { h: 30, s: -30, l: -(-10 + t * 4) }), this["surfacePeer" + t] = this["surfacePeer" + t] || w(this.mainBkg, { h: 30, s: -30, l: -(-7 + t * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.scaleLabelColor;
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["pie" + t] = this["cScale" + t];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.mainContrastColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.mainContrastColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7";
    for (let t = 0; t < 8; t++)
      this["venn" + (t + 1)] = this["venn" + (t + 1)] ?? H(this["cScale" + t], 30);
    this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor, this.vennSetTextColor = this.vennSetTextColor ?? this.textColor, this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || w(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || w(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || w(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || w(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || w(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || w(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : tt(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? tt(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = H(this.secondaryColor, 20), this.git1 = H(this.pie2 || this.secondaryColor, 20), this.git2 = H(this.pie3 || this.tertiaryColor, 20), this.git3 = H(this.pie4 || w(this.primaryColor, { h: -30 }), 20), this.git4 = H(this.pie5 || w(this.primaryColor, { h: -60 }), 20), this.git5 = H(this.pie6 || w(this.primaryColor, { h: -90 }), 10), this.git6 = H(this.pie7 || w(this.primaryColor, { h: 60 }), 10), this.git7 = H(this.pie8 || w(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || H(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || H(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Ir, "Theme"), Ir), q0 = /* @__PURE__ */ p((e) => {
  const t = new W0();
  return t.calculate(e), t;
}, "getThemeVariables"), Pr, H0 = (Pr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = w(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = w(this.primaryColor, { h: -160 }), this.primaryBorderColor = zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Bi(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || w(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || w(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || w(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || w(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || w(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || w(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || w(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || w(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || w(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || tt(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || tt(this.tertiaryColor, 40);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScale" + t] = tt(this["cScale" + t], 10), this["cScalePeer" + t] = this["cScalePeer" + t] || tt(this["cScale" + t], 25);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || w(this["cScale" + t], { h: 180 });
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || w(this.mainBkg, { h: 30, l: -(5 + t * 5) }), this["surfacePeer" + t] = this["surfacePeer" + t] || w(this.mainBkg, { h: 30, l: -(7 + t * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || z(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || z(this.labelTextColor);
      for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
        this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = H(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || H(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = w(this.primaryColor, { h: 64 }), this.fillType3 = w(this.secondaryColor, { h: 64 }), this.fillType4 = w(this.primaryColor, { h: -64 }), this.fillType5 = w(this.secondaryColor, { h: -64 }), this.fillType6 = w(this.primaryColor, { h: 128 }), this.fillType7 = w(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || w(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || w(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || w(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || w(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || w(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || w(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || w(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || w(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || w(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || w(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.venn1 = this.venn1 ?? w(this.primaryColor, { l: -30 }), this.venn2 = this.venn2 ?? w(this.secondaryColor, { l: -30 }), this.venn3 = this.venn3 ?? w(this.tertiaryColor, { l: -40 }), this.venn4 = this.venn4 ?? w(this.primaryColor, { h: 60, l: -30 }), this.venn5 = this.venn5 ?? w(this.primaryColor, { h: -60, l: -30 }), this.venn6 = this.venn6 ?? w(this.secondaryColor, { h: 60, l: -30 }), this.venn7 = this.venn7 ?? w(this.primaryColor, { h: 120, l: -30 }), this.venn8 = this.venn8 ?? w(this.secondaryColor, { h: 120, l: -30 }), this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor, this.vennSetTextColor = this.vennSetTextColor ?? this.textColor, this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || w(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || w(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || w(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || w(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || w(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || w(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : tt(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || w(this.primaryColor, { h: -30 }), this.git4 = this.git4 || w(this.primaryColor, { h: -60 }), this.git5 = this.git5 || w(this.primaryColor, { h: -90 }), this.git6 = this.git6 || w(this.primaryColor, { h: 60 }), this.git7 = this.git7 || w(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = tt(this.git0, 25), this.git1 = tt(this.git1, 25), this.git2 = tt(this.git2, 25), this.git3 = tt(this.git3, 25), this.git4 = tt(this.git4, 25), this.git5 = tt(this.git5, 25), this.git6 = tt(this.git6, 25), this.git7 = tt(this.git7, 25)), this.gitInv0 = this.gitInv0 || tt(z(this.git0), 25), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || wa, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || ka;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Pr, "Theme"), Pr), j0 = /* @__PURE__ */ p((e) => {
  const t = new H0();
  return t.calculate(e), t;
}, "getThemeVariables"), Nr, Y0 = (Nr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = H("#cde498", 10), this.primaryBorderColor = zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.primaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    this.actorBorder = tt(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || w(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || w(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || w(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || w(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || w(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || w(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || w(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || w(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || w(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || tt(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || tt(this.tertiaryColor, 40);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScale" + t] = tt(this["cScale" + t], 10), this["cScalePeer" + t] = this["cScalePeer" + t] || tt(this["cScale" + t], 25);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || w(this["cScale" + t], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.scaleLabelColor;
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || w(this.mainBkg, { h: 30, s: -30, l: -(5 + t * 5) }), this["surfacePeer" + t] = this["surfacePeer" + t] || w(this.mainBkg, { h: 30, s: -30, l: -(8 + t * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || H(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = w(this.primaryColor, { h: 64 }), this.fillType3 = w(this.secondaryColor, { h: 64 }), this.fillType4 = w(this.primaryColor, { h: -64 }), this.fillType5 = w(this.secondaryColor, { h: -64 }), this.fillType6 = w(this.primaryColor, { h: 128 }), this.fillType7 = w(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || w(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || w(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || w(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || w(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || w(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || w(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || w(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || w(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || w(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.venn1 = this.venn1 ?? w(this.primaryColor, { l: -30 }), this.venn2 = this.venn2 ?? w(this.secondaryColor, { l: -30 }), this.venn3 = this.venn3 ?? w(this.tertiaryColor, { l: -30 }), this.venn4 = this.venn4 ?? w(this.primaryColor, { h: 60, l: -30 }), this.venn5 = this.venn5 ?? w(this.primaryColor, { h: -60, l: -30 }), this.venn6 = this.venn6 ?? w(this.secondaryColor, { h: 60, l: -30 }), this.venn7 = this.venn7 ?? w(this.primaryColor, { h: 120, l: -30 }), this.venn8 = this.venn8 ?? w(this.secondaryColor, { h: 120, l: -30 }), this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor, this.vennSetTextColor = this.vennSetTextColor ?? this.textColor, this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || w(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || w(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || w(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || w(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || w(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || w(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : tt(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || w(this.primaryColor, { h: -30 }), this.git4 = this.git4 || w(this.primaryColor, { h: -60 }), this.git5 = this.git5 || w(this.primaryColor, { h: -90 }), this.git6 = this.git6 || w(this.primaryColor, { h: 60 }), this.git7 = this.git7 || w(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = H(this.git0, 25), this.git1 = H(this.git1, 25), this.git2 = H(this.git2, 25), this.git3 = H(this.git3, 25), this.git4 = H(this.git4, 25), this.git5 = H(this.git5, 25), this.git6 = H(this.git6, 25), this.git7 = H(this.git7, 25)) : (this.git0 = tt(this.git0, 25), this.git1 = tt(this.git1, 25), this.git2 = tt(this.git2, 25), this.git3 = tt(this.git3, 25), this.git4 = tt(this.git4, 25), this.git5 = tt(this.git5, 25), this.git6 = tt(this.git6, 25), this.git7 = tt(this.git7, 25)), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || z(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || z(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || wa, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || ka;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(Nr, "Theme"), Nr), U0 = /* @__PURE__ */ p((e) => {
  const t = new Y0();
  return t.calculate(e), t;
}, "getThemeVariables"), zr, G0 = (zr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = H(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = w(this.primaryColor, { h: -160 }), this.primaryBorderColor = zt(this.primaryColor, this.darkMode), this.secondaryBorderColor = zt(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = zt(this.tertiaryColor, this.darkMode), this.primaryTextColor = z(this.primaryColor), this.secondaryTextColor = z(this.secondaryColor), this.tertiaryTextColor = z(this.tertiaryColor), this.lineColor = z(this.background), this.textColor = z(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || H(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    this.secondBkg = H(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = H(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleInv" + t] = this["cScaleInv" + t] || z(this["cScale" + t]);
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this.darkMode ? this["cScalePeer" + t] = this["cScalePeer" + t] || H(this["cScale" + t], 10) : this["cScalePeer" + t] = this["cScalePeer" + t] || tt(this["cScale" + t], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["cScaleLabel" + t] = this["cScaleLabel" + t] || this.scaleLabelColor;
    for (let t = 0; t < 5; t++)
      this["surface" + t] = this["surface" + t] || w(this.mainBkg, { l: -(5 + t * 5) }), this["surfacePeer" + t] = this["surfacePeer" + t] || w(this.mainBkg, { l: -(8 + t * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = H(this.contrast, 30), this.sectionBkgColor2 = H(this.contrast, 30), this.taskBorderColor = tt(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = H(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = tt(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = w(this.primaryColor, { h: 64 }), this.fillType3 = w(this.secondaryColor, { h: 64 }), this.fillType4 = w(this.primaryColor, { h: -64 }), this.fillType5 = w(this.secondaryColor, { h: -64 }), this.fillType6 = w(this.primaryColor, { h: 128 }), this.fillType7 = w(this.secondaryColor, { h: 128 });
    for (let t = 0; t < this.THEME_COLOR_LIMIT; t++)
      this["pie" + t] = this["cScale" + t];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7";
    for (let t = 0; t < 8; t++)
      this["venn" + (t + 1)] = this["venn" + (t + 1)] ?? this["cScale" + t];
    this.vennTitleTextColor = this.vennTitleTextColor ?? this.titleColor, this.vennSetTextColor = this.vennSetTextColor ?? this.textColor, this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || w(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || w(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || w(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || w(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || w(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || w(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || Gi(this.quadrant1Fill) ? H(this.quadrant1Fill) : tt(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: this.xyChart?.backgroundColor || this.background,
      titleColor: this.xyChart?.titleColor || this.primaryTextColor,
      xAxisTitleColor: this.xyChart?.xAxisTitleColor || this.primaryTextColor,
      xAxisLabelColor: this.xyChart?.xAxisLabelColor || this.primaryTextColor,
      xAxisTickColor: this.xyChart?.xAxisTickColor || this.primaryTextColor,
      xAxisLineColor: this.xyChart?.xAxisLineColor || this.primaryTextColor,
      yAxisTitleColor: this.xyChart?.yAxisTitleColor || this.primaryTextColor,
      yAxisLabelColor: this.xyChart?.yAxisLabelColor || this.primaryTextColor,
      yAxisTickColor: this.xyChart?.yAxisTickColor || this.primaryTextColor,
      yAxisLineColor: this.xyChart?.yAxisLineColor || this.primaryTextColor,
      plotColorPalette: this.xyChart?.plotColorPalette || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: this.radar?.axisColor || this.lineColor,
      axisStrokeWidth: this.radar?.axisStrokeWidth || 2,
      axisLabelFontSize: this.radar?.axisLabelFontSize || 12,
      curveOpacity: this.radar?.curveOpacity || 0.5,
      curveStrokeWidth: this.radar?.curveStrokeWidth || 2,
      graticuleColor: this.radar?.graticuleColor || "#DEDEDE",
      graticuleStrokeWidth: this.radar?.graticuleStrokeWidth || 1,
      graticuleOpacity: this.radar?.graticuleOpacity || 0.3,
      legendBoxSize: this.radar?.legendBoxSize || 12,
      legendFontSize: this.radar?.legendFontSize || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = tt(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || w(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || w(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || w(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || w(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || w(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || z(this.git0), this.gitInv1 = this.gitInv1 || z(this.git1), this.gitInv2 = this.gitInv2 || z(this.git2), this.gitInv3 = this.gitInv3 || z(this.git3), this.gitInv4 = this.gitInv4 || z(this.git4), this.gitInv5 = this.gitInv5 || z(this.git5), this.gitInv6 = this.gitInv6 || z(this.git6), this.gitInv7 = this.gitInv7 || z(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || wa, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || ka;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(zr, "Theme"), zr), X0 = /* @__PURE__ */ p((e) => {
  const t = new G0();
  return t.calculate(e), t;
}, "getThemeVariables"), Ee = {
  base: {
    getThemeVariables: z0
  },
  dark: {
    getThemeVariables: q0
  },
  default: {
    getThemeVariables: j0
  },
  forest: {
    getThemeVariables: U0
  },
  neutral: {
    getThemeVariables: X0
  }
}, te = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: null,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200,
    layoutAlgorithm: "cose-bilkent"
  },
  ishikawa: {
    useMaxWidth: !0,
    diagramPadding: 20
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  venn: {
    useMaxWidth: !0,
    width: 800,
    height: 450,
    padding: 8,
    useDebugLayout: !1
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Oh = {
  ...te,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF",
    forceNodeModelOrder: !1,
    considerModelOrder: "NODES_AND_EDGES"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: Ee.default.getThemeVariables(),
  sequence: {
    ...te.sequence,
    messageFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...te.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...te.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...te.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...te.pie,
    useWidth: 984
  },
  xyChart: {
    ...te.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...te.requirement,
    useWidth: void 0
  },
  packet: {
    ...te.packet
  },
  radar: {
    ...te.radar
  },
  ishikawa: {
    ...te.ishikawa
  },
  treemap: {
    useMaxWidth: !0,
    padding: 10,
    diagramPadding: 8,
    showValues: !0,
    nodeWidth: 100,
    nodeHeight: 40,
    borderWidth: 1,
    valueFontSize: 12,
    labelFontSize: 14,
    valueFormat: ","
  },
  venn: {
    ...te.venn
  }
}, Rh = /* @__PURE__ */ p((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...Rh(e[i], "")] : [...r, t + i], []), "keyify"), V0 = new Set(Rh(Oh, "")), Ih = Oh, zn = /* @__PURE__ */ p((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => zn(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !V0.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), zn(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = Z0(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r?.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), Z0 = /* @__PURE__ */ p((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), jr = Object.freeze(Ih), Ze = /* @__PURE__ */ p((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), Gt = St({}, jr), Wn, fr = [], Ai = St({}, jr), va = /* @__PURE__ */ p((e, t) => {
  let r = St({}, e), i = {};
  for (const n of t)
    zh(n), i = St(i, n);
  if (r = St(r, i), i.theme && i.theme in Ee) {
    const n = St({}, Wn), a = St(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in Ee && (r.themeVariables = Ee[r.theme].getThemeVariables(a));
  }
  return Ai = r, qh(Ai), Ai;
}, "updateCurrentConfig"), K0 = /* @__PURE__ */ p((e) => (Gt = St({}, jr), Gt = St(Gt, e), e.theme && Ee[e.theme] && (Gt.themeVariables = Ee[e.theme].getThemeVariables(e.themeVariables)), va(Gt, fr), Gt), "setSiteConfig"), Q0 = /* @__PURE__ */ p((e) => {
  Wn = St({}, e);
}, "saveConfigFromInitialize"), J0 = /* @__PURE__ */ p((e) => (Gt = St(Gt, e), va(Gt, fr), Gt), "updateSiteConfig"), Ph = /* @__PURE__ */ p(() => St({}, Gt), "getSiteConfig"), Nh = /* @__PURE__ */ p((e) => (qh(e), St(Ai, e), Dt()), "setConfig"), Dt = /* @__PURE__ */ p(() => St({}, Ai), "getConfig"), zh = /* @__PURE__ */ p((e) => {
  e && (["secure", ...Gt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && zh(e[t]);
  }));
}, "sanitize"), ty = /* @__PURE__ */ p((e) => {
  zn(e), e.fontFamily && !e.themeVariables?.fontFamily && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), fr.push(e), va(Gt, fr);
}, "addDirective"), qn = /* @__PURE__ */ p((e = Gt) => {
  fr = [], va(e, fr);
}, "reset"), ey = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead.",
  FLOWCHART_HTML_LABELS_DEPRECATED: "flowchart.htmlLabels is deprecated. Please use global htmlLabels instead."
}, Ql = {}, Wh = /* @__PURE__ */ p((e) => {
  Ql[e] || (F.warn(ey[e]), Ql[e] = !0);
}, "issueWarning"), qh = /* @__PURE__ */ p((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && Wh("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), sA = /* @__PURE__ */ p(() => {
  let e = {};
  Wn && (e = St(e, Wn));
  for (const t of fr)
    e = St(e, t);
  return e;
}, "getUserDefinedConfig"), It = /* @__PURE__ */ p((e) => (e.flowchart?.htmlLabels != null && Wh("FLOWCHART_HTML_LABELS_DEPRECATED"), Ze(e.htmlLabels ?? e.flowchart?.htmlLabels ?? !0)), "getEffectiveHtmlLabels"), Xi = /<br\s*\/?>/gi, ry = /* @__PURE__ */ p((e) => e ? Yh(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), iy = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Hh(), e = !0);
  };
})();
function Hh() {
  const e = "data-temp-href-target";
  Hr.addHook("beforeSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), Hr.addHook("afterSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
p(Hh, "setupDompurifyHooks");
var jh = /* @__PURE__ */ p((e) => (iy(), Hr.sanitize(e)), "removeScript"), Jl = /* @__PURE__ */ p((e, t) => {
  if (It(t)) {
    const r = t.securityLevel;
    r === "antiscript" || r === "strict" || r === "sandbox" ? e = jh(e) : r !== "loose" && (e = Yh(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = oy(e));
  }
  return e;
}, "sanitizeMore"), fe = /* @__PURE__ */ p((e, t) => e && (t.dompurifyConfig ? e = Hr.sanitize(Jl(e, t), t.dompurifyConfig).toString() : e = Hr.sanitize(Jl(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), ny = /* @__PURE__ */ p((e, t) => typeof e == "string" ? fe(e, t) : e.flat().map((r) => fe(r, t)), "sanitizeTextOrArray"), ay = /* @__PURE__ */ p((e) => Xi.test(e), "hasBreaks"), sy = /* @__PURE__ */ p((e) => e.split(Xi), "splitBreaks"), oy = /* @__PURE__ */ p((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), Yh = /* @__PURE__ */ p((e) => e.replace(Xi, "#br#"), "breakToPlaceholder"), ly = /* @__PURE__ */ p((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), cy = /* @__PURE__ */ p(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), hy = /* @__PURE__ */ p(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), tc = /* @__PURE__ */ p(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], s = t[i + 1];
      uy(a, s) && (n = a + "," + s, i++, r.pop());
    }
    r.push(fy(n));
  }
  return r.join("");
}, "parseGenericTypes"), Ls = /* @__PURE__ */ p((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), uy = /* @__PURE__ */ p((e, t) => {
  const r = Ls(e, "~"), i = Ls(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), fy = /* @__PURE__ */ p((e) => {
  const t = Ls(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), ec = /* @__PURE__ */ p(() => window.MathMLElement !== void 0, "isMathMLSupported"), As = /\$\$(.*)\$\$/g, Fi = /* @__PURE__ */ p((e) => (e.match(As)?.length ?? 0) > 0, "hasKatex"), oA = /* @__PURE__ */ p(async (e, t) => {
  const r = document.createElement("div");
  r.innerHTML = await Uh(e, t), r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0", document.querySelector("body")?.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), dy = /* @__PURE__ */ p(async (e, t) => {
  if (!Fi(e))
    return e;
  if (!(ec() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(As, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./katex-DRSa1quw.js"), i = t.forceLegacyMathML || !ec() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(Xi).map(
      (n) => Fi(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      As,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatexUnsanitized"), Uh = /* @__PURE__ */ p(async (e, t) => fe(await dy(e, t), t), "renderKatexSanitized"), Vi = {
  getRows: ry,
  sanitizeText: fe,
  sanitizeTextOrArray: ny,
  hasBreaks: ay,
  splitBreaks: sy,
  lineBreakRegex: Xi,
  removeScript: jh,
  getUrl: ly,
  evaluate: Ze,
  getMax: cy,
  getMin: hy
}, py = /* @__PURE__ */ p(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), gy = /* @__PURE__ */ p(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), Gh = /* @__PURE__ */ p(function(e, t, r, i) {
  const n = gy(t, r, i);
  py(e, n);
}, "configureSvgSize"), my = /* @__PURE__ */ p(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, s = n.height;
  F.info(`SVG bounds: ${a}x${s}`, n);
  let o = 0, l = 0;
  F.info(`Graph bounds: ${o}x${l}`, e), o = a + r * 2, l = s + r * 2, F.info(`Calculated bounds: ${o}x${l}`), Gh(t, l, o, i);
  const c = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", c);
}, "setupGraphViewbox"), An = {}, yy = /* @__PURE__ */ p((e, t, r) => {
  let i = "";
  return e in An && An[e] ? i = An[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), xy = /* @__PURE__ */ p((e, t) => {
  t !== void 0 && (An[e] = t);
}, "addStylesForDiagram"), by = yy, Xh = {};
l0(Xh, {
  clear: () => Cy,
  getAccDescription: () => vy,
  getAccTitle: () => wy,
  getDiagramTitle: () => Ty,
  setAccDescription: () => ky,
  setAccTitle: () => _y,
  setDiagramTitle: () => Sy
});
var To = "", Bo = "", Lo = "", Ao = /* @__PURE__ */ p((e) => fe(e, Dt()), "sanitizeText"), Cy = /* @__PURE__ */ p(() => {
  To = "", Lo = "", Bo = "";
}, "clear"), _y = /* @__PURE__ */ p((e) => {
  To = Ao(e).replace(/^\s+/g, "");
}, "setAccTitle"), wy = /* @__PURE__ */ p(() => To, "getAccTitle"), ky = /* @__PURE__ */ p((e) => {
  Lo = Ao(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), vy = /* @__PURE__ */ p(() => Lo, "getAccDescription"), Sy = /* @__PURE__ */ p((e) => {
  Bo = Ao(e);
}, "setDiagramTitle"), Ty = /* @__PURE__ */ p(() => Bo, "getDiagramTitle"), rc = F, By = vo, ft = Dt, lA = Nh, cA = jr, Mo = /* @__PURE__ */ p((e) => fe(e, ft()), "sanitizeText"), Ly = my, Ay = /* @__PURE__ */ p(() => Xh, "getCommonDb"), Hn = {}, jn = /* @__PURE__ */ p((e, t, r) => {
  Hn[e] && rc.warn(`Diagram with id ${e} already registered. Overwriting.`), Hn[e] = t, r && Dh(e, r), xy(e, t.styles), t.injectUtils?.(
    rc,
    By,
    ft,
    Mo,
    Ly,
    Ay(),
    () => {
    }
  );
}, "registerDiagram"), Ms = /* @__PURE__ */ p((e) => {
  if (e in Hn)
    return Hn[e];
  throw new My(e);
}, "getDiagram"), Wr, My = (Wr = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, p(Wr, "DiagramNotFoundError"), Wr), $y = { value: () => {
} };
function Vh() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new Mn(r);
}
function Mn(e) {
  this._ = e;
}
function Ey(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
Mn.prototype = Vh.prototype = {
  constructor: Mn,
  on: function(e, t) {
    var r = this._, i = Ey(e + "", r), n, a = -1, s = i.length;
    if (arguments.length < 2) {
      for (; ++a < s; ) if ((n = (e = i[a]).type) && (n = Fy(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < s; )
      if (n = (e = i[a]).type) r[n] = ic(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = ic(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new Mn(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function Fy(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function ic(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = $y, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var $s = "http://www.w3.org/1999/xhtml";
const nc = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: $s,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function Sa(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), nc.hasOwnProperty(t) ? { space: nc[t], local: e } : e;
}
function Dy(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === $s && t.documentElement.namespaceURI === $s ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function Oy(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function Zh(e) {
  var t = Sa(e);
  return (t.local ? Oy : Dy)(t);
}
function Ry() {
}
function $o(e) {
  return e == null ? Ry : function() {
    return this.querySelector(e);
  };
}
function Iy(e) {
  typeof e != "function" && (e = $o(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], s = a.length, o = i[n] = new Array(s), l, c, h = 0; h < s; ++h)
      (l = a[h]) && (c = e.call(l, l.__data__, h, a)) && ("__data__" in l && (c.__data__ = l.__data__), o[h] = c);
  return new Qt(i, this._parents);
}
function Py(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function Ny() {
  return [];
}
function Kh(e) {
  return e == null ? Ny : function() {
    return this.querySelectorAll(e);
  };
}
function zy(e) {
  return function() {
    return Py(e.apply(this, arguments));
  };
}
function Wy(e) {
  typeof e == "function" ? e = zy(e) : e = Kh(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var s = t[a], o = s.length, l, c = 0; c < o; ++c)
      (l = s[c]) && (i.push(e.call(l, l.__data__, c, s)), n.push(l));
  return new Qt(i, n);
}
function Qh(e) {
  return function() {
    return this.matches(e);
  };
}
function Jh(e) {
  return function(t) {
    return t.matches(e);
  };
}
var qy = Array.prototype.find;
function Hy(e) {
  return function() {
    return qy.call(this.children, e);
  };
}
function jy() {
  return this.firstElementChild;
}
function Yy(e) {
  return this.select(e == null ? jy : Hy(typeof e == "function" ? e : Jh(e)));
}
var Uy = Array.prototype.filter;
function Gy() {
  return Array.from(this.children);
}
function Xy(e) {
  return function() {
    return Uy.call(this.children, e);
  };
}
function Vy(e) {
  return this.selectAll(e == null ? Gy : Xy(typeof e == "function" ? e : Jh(e)));
}
function Zy(e) {
  typeof e != "function" && (e = Qh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], s = a.length, o = i[n] = [], l, c = 0; c < s; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && o.push(l);
  return new Qt(i, this._parents);
}
function tu(e) {
  return new Array(e.length);
}
function Ky() {
  return new Qt(this._enter || this._groups.map(tu), this._parents);
}
function Yn(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
Yn.prototype = {
  constructor: Yn,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function Qy(e) {
  return function() {
    return e;
  };
}
function Jy(e, t, r, i, n, a) {
  for (var s = 0, o, l = t.length, c = a.length; s < c; ++s)
    (o = t[s]) ? (o.__data__ = a[s], i[s] = o) : r[s] = new Yn(e, a[s]);
  for (; s < l; ++s)
    (o = t[s]) && (n[s] = o);
}
function tx(e, t, r, i, n, a, s) {
  var o, l, c = /* @__PURE__ */ new Map(), h = t.length, u = a.length, d = new Array(h), f;
  for (o = 0; o < h; ++o)
    (l = t[o]) && (d[o] = f = s.call(l, l.__data__, o, t) + "", c.has(f) ? n[o] = l : c.set(f, l));
  for (o = 0; o < u; ++o)
    f = s.call(e, a[o], o, a) + "", (l = c.get(f)) ? (i[o] = l, l.__data__ = a[o], c.delete(f)) : r[o] = new Yn(e, a[o]);
  for (o = 0; o < h; ++o)
    (l = t[o]) && c.get(d[o]) === l && (n[o] = l);
}
function ex(e) {
  return e.__data__;
}
function rx(e, t) {
  if (!arguments.length) return Array.from(this, ex);
  var r = t ? tx : Jy, i = this._parents, n = this._groups;
  typeof e != "function" && (e = Qy(e));
  for (var a = n.length, s = new Array(a), o = new Array(a), l = new Array(a), c = 0; c < a; ++c) {
    var h = i[c], u = n[c], d = u.length, f = ix(e.call(h, h && h.__data__, c, i)), g = f.length, m = o[c] = new Array(g), y = s[c] = new Array(g), x = l[c] = new Array(d);
    r(h, u, m, y, x, f, t);
    for (var b = 0, _ = 0, v, k; b < g; ++b)
      if (v = m[b]) {
        for (b >= _ && (_ = b + 1); !(k = y[_]) && ++_ < g; ) ;
        v._next = k || null;
      }
  }
  return s = new Qt(s, i), s._enter = o, s._exit = l, s;
}
function ix(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function nx() {
  return new Qt(this._exit || this._groups.map(tu), this._parents);
}
function ax(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function sx(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, s = Math.min(n, a), o = new Array(n), l = 0; l < s; ++l)
    for (var c = r[l], h = i[l], u = c.length, d = o[l] = new Array(u), f, g = 0; g < u; ++g)
      (f = c[g] || h[g]) && (d[g] = f);
  for (; l < n; ++l)
    o[l] = r[l];
  return new Qt(o, this._parents);
}
function ox() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], s; --n >= 0; )
      (s = i[n]) && (a && s.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(s, a), a = s);
  return this;
}
function lx(e) {
  e || (e = cx);
  function t(u, d) {
    return u && d ? e(u.__data__, d.__data__) : !u - !d;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var s = r[a], o = s.length, l = n[a] = new Array(o), c, h = 0; h < o; ++h)
      (c = s[h]) && (l[h] = c);
    l.sort(t);
  }
  return new Qt(n, this._parents).order();
}
function cx(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function hx() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function ux() {
  return Array.from(this);
}
function fx() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var s = i[n];
      if (s) return s;
    }
  return null;
}
function dx() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function px() {
  return !this.node();
}
function gx(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, s = n.length, o; a < s; ++a)
      (o = n[a]) && e.call(o, o.__data__, a, n);
  return this;
}
function mx(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function yx(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function xx(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function bx(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function Cx(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function _x(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function wx(e, t) {
  var r = Sa(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? yx : mx : typeof t == "function" ? r.local ? _x : Cx : r.local ? bx : xx)(r, t));
}
function eu(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function kx(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function vx(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function Sx(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function Tx(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? kx : typeof t == "function" ? Sx : vx)(e, t, r ?? "")) : Yr(this.node(), e);
}
function Yr(e, t) {
  return e.style.getPropertyValue(t) || eu(e).getComputedStyle(e, null).getPropertyValue(t);
}
function Bx(e) {
  return function() {
    delete this[e];
  };
}
function Lx(e, t) {
  return function() {
    this[e] = t;
  };
}
function Ax(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function Mx(e, t) {
  return arguments.length > 1 ? this.each((t == null ? Bx : typeof t == "function" ? Ax : Lx)(e, t)) : this.node()[e];
}
function ru(e) {
  return e.trim().split(/^|\s+/);
}
function Eo(e) {
  return e.classList || new iu(e);
}
function iu(e) {
  this._node = e, this._names = ru(e.getAttribute("class") || "");
}
iu.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function nu(e, t) {
  for (var r = Eo(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function au(e, t) {
  for (var r = Eo(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function $x(e) {
  return function() {
    nu(this, e);
  };
}
function Ex(e) {
  return function() {
    au(this, e);
  };
}
function Fx(e, t) {
  return function() {
    (t.apply(this, arguments) ? nu : au)(this, e);
  };
}
function Dx(e, t) {
  var r = ru(e + "");
  if (arguments.length < 2) {
    for (var i = Eo(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? Fx : t ? $x : Ex)(r, t));
}
function Ox() {
  this.textContent = "";
}
function Rx(e) {
  return function() {
    this.textContent = e;
  };
}
function Ix(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function Px(e) {
  return arguments.length ? this.each(e == null ? Ox : (typeof e == "function" ? Ix : Rx)(e)) : this.node().textContent;
}
function Nx() {
  this.innerHTML = "";
}
function zx(e) {
  return function() {
    this.innerHTML = e;
  };
}
function Wx(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function qx(e) {
  return arguments.length ? this.each(e == null ? Nx : (typeof e == "function" ? Wx : zx)(e)) : this.node().innerHTML;
}
function Hx() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function jx() {
  return this.each(Hx);
}
function Yx() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function Ux() {
  return this.each(Yx);
}
function Gx(e) {
  var t = typeof e == "function" ? e : Zh(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Xx() {
  return null;
}
function Vx(e, t) {
  var r = typeof e == "function" ? e : Zh(e), i = t == null ? Xx : typeof t == "function" ? t : $o(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Zx() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Kx() {
  return this.each(Zx);
}
function Qx() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Jx() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function tb(e) {
  return this.select(e ? Jx : Qx);
}
function eb(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function rb(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function ib(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function nb(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function ab(e, t, r) {
  return function() {
    var i = this.__on, n, a = rb(t);
    if (i) {
      for (var s = 0, o = i.length; s < o; ++s)
        if ((n = i[s]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function sb(e, t, r) {
  var i = ib(e + ""), n, a = i.length, s;
  if (arguments.length < 2) {
    var o = this.node().__on;
    if (o) {
      for (var l = 0, c = o.length, h; l < c; ++l)
        for (n = 0, h = o[l]; n < a; ++n)
          if ((s = i[n]).type === h.type && s.name === h.name)
            return h.value;
    }
    return;
  }
  for (o = t ? ab : nb, n = 0; n < a; ++n) this.each(o(i[n], t, r));
  return this;
}
function su(e, t, r) {
  var i = eu(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function ob(e, t) {
  return function() {
    return su(this, e, t);
  };
}
function lb(e, t) {
  return function() {
    return su(this, e, t.apply(this, arguments));
  };
}
function cb(e, t) {
  return this.each((typeof t == "function" ? lb : ob)(e, t));
}
function* hb() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, s; n < a; ++n)
      (s = i[n]) && (yield s);
}
var ou = [null];
function Qt(e, t) {
  this._groups = e, this._parents = t;
}
function Zi() {
  return new Qt([[document.documentElement]], ou);
}
function ub() {
  return this;
}
Qt.prototype = Zi.prototype = {
  constructor: Qt,
  select: Iy,
  selectAll: Wy,
  selectChild: Yy,
  selectChildren: Vy,
  filter: Zy,
  data: rx,
  enter: Ky,
  exit: nx,
  join: ax,
  merge: sx,
  selection: ub,
  order: ox,
  sort: lx,
  call: hx,
  nodes: ux,
  node: fx,
  size: dx,
  empty: px,
  each: gx,
  attr: wx,
  style: Tx,
  property: Mx,
  classed: Dx,
  text: Px,
  html: qx,
  raise: jx,
  lower: Ux,
  append: Gx,
  insert: Vx,
  remove: Kx,
  clone: tb,
  datum: eb,
  on: sb,
  dispatch: cb,
  [Symbol.iterator]: hb
};
function lt(e) {
  return typeof e == "string" ? new Qt([[document.querySelector(e)]], [document.documentElement]) : new Qt([[e]], ou);
}
function Fo(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function lu(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function Ki() {
}
var Di = 0.7, Un = 1 / Di, Fr = "\\s*([+-]?\\d+)\\s*", Oi = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", Ce = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", fb = /^#([0-9a-f]{3,8})$/, db = new RegExp(`^rgb\\(${Fr},${Fr},${Fr}\\)$`), pb = new RegExp(`^rgb\\(${Ce},${Ce},${Ce}\\)$`), gb = new RegExp(`^rgba\\(${Fr},${Fr},${Fr},${Oi}\\)$`), mb = new RegExp(`^rgba\\(${Ce},${Ce},${Ce},${Oi}\\)$`), yb = new RegExp(`^hsl\\(${Oi},${Ce},${Ce}\\)$`), xb = new RegExp(`^hsla\\(${Oi},${Ce},${Ce},${Oi}\\)$`), ac = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
Fo(Ki, Ri, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: sc,
  // Deprecated! Use color.formatHex.
  formatHex: sc,
  formatHex8: bb,
  formatHsl: Cb,
  formatRgb: oc,
  toString: oc
});
function sc() {
  return this.rgb().formatHex();
}
function bb() {
  return this.rgb().formatHex8();
}
function Cb() {
  return cu(this).formatHsl();
}
function oc() {
  return this.rgb().formatRgb();
}
function Ri(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = fb.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? lc(t) : r === 3 ? new Vt(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? gn(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? gn(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = db.exec(e)) ? new Vt(t[1], t[2], t[3], 1) : (t = pb.exec(e)) ? new Vt(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = gb.exec(e)) ? gn(t[1], t[2], t[3], t[4]) : (t = mb.exec(e)) ? gn(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = yb.exec(e)) ? uc(t[1], t[2] / 100, t[3] / 100, 1) : (t = xb.exec(e)) ? uc(t[1], t[2] / 100, t[3] / 100, t[4]) : ac.hasOwnProperty(e) ? lc(ac[e]) : e === "transparent" ? new Vt(NaN, NaN, NaN, 0) : null;
}
function lc(e) {
  return new Vt(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function gn(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new Vt(e, t, r, i);
}
function _b(e) {
  return e instanceof Ki || (e = Ri(e)), e ? (e = e.rgb(), new Vt(e.r, e.g, e.b, e.opacity)) : new Vt();
}
function Es(e, t, r, i) {
  return arguments.length === 1 ? _b(e) : new Vt(e, t, r, i ?? 1);
}
function Vt(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
Fo(Vt, Es, lu(Ki, {
  brighter(e) {
    return e = e == null ? Un : Math.pow(Un, e), new Vt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Di : Math.pow(Di, e), new Vt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Vt(cr(this.r), cr(this.g), cr(this.b), Gn(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: cc,
  // Deprecated! Use color.formatHex.
  formatHex: cc,
  formatHex8: wb,
  formatRgb: hc,
  toString: hc
}));
function cc() {
  return `#${sr(this.r)}${sr(this.g)}${sr(this.b)}`;
}
function wb() {
  return `#${sr(this.r)}${sr(this.g)}${sr(this.b)}${sr((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function hc() {
  const e = Gn(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${cr(this.r)}, ${cr(this.g)}, ${cr(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function Gn(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function cr(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function sr(e) {
  return e = cr(e), (e < 16 ? "0" : "") + e.toString(16);
}
function uc(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new le(e, t, r, i);
}
function cu(e) {
  if (e instanceof le) return new le(e.h, e.s, e.l, e.opacity);
  if (e instanceof Ki || (e = Ri(e)), !e) return new le();
  if (e instanceof le) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), s = NaN, o = a - n, l = (a + n) / 2;
  return o ? (t === a ? s = (r - i) / o + (r < i) * 6 : r === a ? s = (i - t) / o + 2 : s = (t - r) / o + 4, o /= l < 0.5 ? a + n : 2 - a - n, s *= 60) : o = l > 0 && l < 1 ? 0 : s, new le(s, o, l, e.opacity);
}
function kb(e, t, r, i) {
  return arguments.length === 1 ? cu(e) : new le(e, t, r, i ?? 1);
}
function le(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
Fo(le, kb, lu(Ki, {
  brighter(e) {
    return e = e == null ? Un : Math.pow(Un, e), new le(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Di : Math.pow(Di, e), new le(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new Vt(
      cs(e >= 240 ? e - 240 : e + 120, n, i),
      cs(e, n, i),
      cs(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new le(fc(this.h), mn(this.s), mn(this.l), Gn(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = Gn(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${fc(this.h)}, ${mn(this.s) * 100}%, ${mn(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function fc(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function mn(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function cs(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const Do = (e) => () => e;
function hu(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function vb(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function hA(e, t) {
  var r = t - e;
  return r ? hu(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : Do(isNaN(e) ? t : e);
}
function Sb(e) {
  return (e = +e) == 1 ? uu : function(t, r) {
    return r - t ? vb(t, r, e) : Do(isNaN(t) ? r : t);
  };
}
function uu(e, t) {
  var r = t - e;
  return r ? hu(e, r) : Do(isNaN(e) ? t : e);
}
const dc = (function e(t) {
  var r = Sb(t);
  function i(n, a) {
    var s = r((n = Es(n)).r, (a = Es(a)).r), o = r(n.g, a.g), l = r(n.b, a.b), c = uu(n.opacity, a.opacity);
    return function(h) {
      return n.r = s(h), n.g = o(h), n.b = l(h), n.opacity = c(h), n + "";
    };
  }
  return i.gamma = e, i;
})(1);
function qe(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var Fs = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, hs = new RegExp(Fs.source, "g");
function Tb(e) {
  return function() {
    return e;
  };
}
function Bb(e) {
  return function(t) {
    return e(t) + "";
  };
}
function Lb(e, t) {
  var r = Fs.lastIndex = hs.lastIndex = 0, i, n, a, s = -1, o = [], l = [];
  for (e = e + "", t = t + ""; (i = Fs.exec(e)) && (n = hs.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), o[s] ? o[s] += a : o[++s] = a), (i = i[0]) === (n = n[0]) ? o[s] ? o[s] += n : o[++s] = n : (o[++s] = null, l.push({ i: s, x: qe(i, n) })), r = hs.lastIndex;
  return r < t.length && (a = t.slice(r), o[s] ? o[s] += a : o[++s] = a), o.length < 2 ? l[0] ? Bb(l[0].x) : Tb(t) : (t = l.length, function(c) {
    for (var h = 0, u; h < t; ++h) o[(u = l[h]).i] = u.x(c);
    return o.join("");
  });
}
var pc = 180 / Math.PI, Ds = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function fu(e, t, r, i, n, a) {
  var s, o, l;
  return (s = Math.sqrt(e * e + t * t)) && (e /= s, t /= s), (l = e * r + t * i) && (r -= e * l, i -= t * l), (o = Math.sqrt(r * r + i * i)) && (r /= o, i /= o, l /= o), e * i < t * r && (e = -e, t = -t, l = -l, s = -s), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * pc,
    skewX: Math.atan(l) * pc,
    scaleX: s,
    scaleY: o
  };
}
var yn;
function Ab(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Ds : fu(t.a, t.b, t.c, t.d, t.e, t.f);
}
function Mb(e) {
  return e == null || (yn || (yn = document.createElementNS("http://www.w3.org/2000/svg", "g")), yn.setAttribute("transform", e), !(e = yn.transform.baseVal.consolidate())) ? Ds : (e = e.matrix, fu(e.a, e.b, e.c, e.d, e.e, e.f));
}
function du(e, t, r, i) {
  function n(c) {
    return c.length ? c.pop() + " " : "";
  }
  function a(c, h, u, d, f, g) {
    if (c !== u || h !== d) {
      var m = f.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: qe(c, u) }, { i: m - 2, x: qe(h, d) });
    } else (u || d) && f.push("translate(" + u + t + d + r);
  }
  function s(c, h, u, d) {
    c !== h ? (c - h > 180 ? h += 360 : h - c > 180 && (c += 360), d.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: qe(c, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function o(c, h, u, d) {
    c !== h ? d.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: qe(c, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function l(c, h, u, d, f, g) {
    if (c !== u || h !== d) {
      var m = f.push(n(f) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: qe(c, u) }, { i: m - 2, x: qe(h, d) });
    } else (u !== 1 || d !== 1) && f.push(n(f) + "scale(" + u + "," + d + ")");
  }
  return function(c, h) {
    var u = [], d = [];
    return c = e(c), h = e(h), a(c.translateX, c.translateY, h.translateX, h.translateY, u, d), s(c.rotate, h.rotate, u, d), o(c.skewX, h.skewX, u, d), l(c.scaleX, c.scaleY, h.scaleX, h.scaleY, u, d), c = h = null, function(f) {
      for (var g = -1, m = d.length, y; ++g < m; ) u[(y = d[g]).i] = y.x(f);
      return u.join("");
    };
  };
}
var $b = du(Ab, "px, ", "px)", "deg)"), Eb = du(Mb, ", ", ")", ")"), Ur = 0, bi = 0, hi = 0, pu = 1e3, Xn, Ci, Vn = 0, dr = 0, Ta = 0, Ii = typeof performance == "object" && performance.now ? performance : Date, gu = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function Oo() {
  return dr || (gu(Fb), dr = Ii.now() + Ta);
}
function Fb() {
  dr = 0;
}
function Zn() {
  this._call = this._time = this._next = null;
}
Zn.prototype = mu.prototype = {
  constructor: Zn,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? Oo() : +r) + (t == null ? 0 : +t), !this._next && Ci !== this && (Ci ? Ci._next = this : Xn = this, Ci = this), this._call = e, this._time = r, Os();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, Os());
  }
};
function mu(e, t, r) {
  var i = new Zn();
  return i.restart(e, t, r), i;
}
function Db() {
  Oo(), ++Ur;
  for (var e = Xn, t; e; )
    (t = dr - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --Ur;
}
function gc() {
  dr = (Vn = Ii.now()) + Ta, Ur = bi = 0;
  try {
    Db();
  } finally {
    Ur = 0, Rb(), dr = 0;
  }
}
function Ob() {
  var e = Ii.now(), t = e - Vn;
  t > pu && (Ta -= t, Vn = e);
}
function Rb() {
  for (var e, t = Xn, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : Xn = r);
  Ci = e, Os(i);
}
function Os(e) {
  if (!Ur) {
    bi && (bi = clearTimeout(bi));
    var t = e - dr;
    t > 24 ? (e < 1 / 0 && (bi = setTimeout(gc, e - Ii.now() - Ta)), hi && (hi = clearInterval(hi))) : (hi || (Vn = Ii.now(), hi = setInterval(Ob, pu)), Ur = 1, gu(gc));
  }
}
function mc(e, t, r) {
  var i = new Zn();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var Ib = Vh("start", "end", "cancel", "interrupt"), Pb = [], yu = 0, yc = 1, Rs = 2, $n = 3, xc = 4, Is = 5, En = 6;
function Ba(e, t, r, i, n, a) {
  var s = e.__transition;
  if (!s) e.__transition = {};
  else if (r in s) return;
  Nb(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: Ib,
    tween: Pb,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: yu
  });
}
function Ro(e, t) {
  var r = de(e, t);
  if (r.state > yu) throw new Error("too late; already scheduled");
  return r;
}
function ke(e, t) {
  var r = de(e, t);
  if (r.state > $n) throw new Error("too late; already running");
  return r;
}
function de(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function Nb(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = mu(a, 0, r.time);
  function a(c) {
    r.state = yc, r.timer.restart(s, r.delay, r.time), r.delay <= c && s(c - r.delay);
  }
  function s(c) {
    var h, u, d, f;
    if (r.state !== yc) return l();
    for (h in i)
      if (f = i[h], f.name === r.name) {
        if (f.state === $n) return mc(s);
        f.state === xc ? (f.state = En, f.timer.stop(), f.on.call("interrupt", e, e.__data__, f.index, f.group), delete i[h]) : +h < t && (f.state = En, f.timer.stop(), f.on.call("cancel", e, e.__data__, f.index, f.group), delete i[h]);
      }
    if (mc(function() {
      r.state === $n && (r.state = xc, r.timer.restart(o, r.delay, r.time), o(c));
    }), r.state = Rs, r.on.call("start", e, e.__data__, r.index, r.group), r.state === Rs) {
      for (r.state = $n, n = new Array(d = r.tween.length), h = 0, u = -1; h < d; ++h)
        (f = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = f);
      n.length = u + 1;
    }
  }
  function o(c) {
    for (var h = c < r.duration ? r.ease.call(null, c / r.duration) : (r.timer.restart(l), r.state = Is, 1), u = -1, d = n.length; ++u < d; )
      n[u].call(e, h);
    r.state === Is && (r.on.call("end", e, e.__data__, r.index, r.group), l());
  }
  function l() {
    r.state = En, r.timer.stop(), delete i[t];
    for (var c in i) return;
    delete e.__transition;
  }
}
function zb(e, t) {
  var r = e.__transition, i, n, a = !0, s;
  if (r) {
    t = t == null ? null : t + "";
    for (s in r) {
      if ((i = r[s]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > Rs && i.state < Is, i.state = En, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[s];
    }
    a && delete e.__transition;
  }
}
function Wb(e) {
  return this.each(function() {
    zb(this, e);
  });
}
function qb(e, t) {
  var r, i;
  return function() {
    var n = ke(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var s = 0, o = i.length; s < o; ++s)
        if (i[s].name === t) {
          i = i.slice(), i.splice(s, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function Hb(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = ke(this, e), s = a.tween;
    if (s !== i) {
      n = (i = s).slice();
      for (var o = { name: t, value: r }, l = 0, c = n.length; l < c; ++l)
        if (n[l].name === t) {
          n[l] = o;
          break;
        }
      l === c && n.push(o);
    }
    a.tween = n;
  };
}
function jb(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = de(this.node(), r).tween, n = 0, a = i.length, s; n < a; ++n)
      if ((s = i[n]).name === e)
        return s.value;
    return null;
  }
  return this.each((t == null ? qb : Hb)(r, e, t));
}
function Io(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = ke(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return de(n, i).value[t];
  };
}
function xu(e, t) {
  var r;
  return (typeof t == "number" ? qe : t instanceof Ri ? dc : (r = Ri(t)) ? (t = r, dc) : Lb)(e, t);
}
function Yb(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function Ub(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Gb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var s = this.getAttribute(e);
    return s === n ? null : s === i ? a : a = t(i = s, r);
  };
}
function Xb(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var s = this.getAttributeNS(e.space, e.local);
    return s === n ? null : s === i ? a : a = t(i = s, r);
  };
}
function Vb(e, t, r) {
  var i, n, a;
  return function() {
    var s, o = r(this), l;
    return o == null ? void this.removeAttribute(e) : (s = this.getAttribute(e), l = o + "", s === l ? null : s === i && l === n ? a : (n = l, a = t(i = s, o)));
  };
}
function Zb(e, t, r) {
  var i, n, a;
  return function() {
    var s, o = r(this), l;
    return o == null ? void this.removeAttributeNS(e.space, e.local) : (s = this.getAttributeNS(e.space, e.local), l = o + "", s === l ? null : s === i && l === n ? a : (n = l, a = t(i = s, o)));
  };
}
function Kb(e, t) {
  var r = Sa(e), i = r === "transform" ? Eb : xu;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Zb : Vb)(r, i, Io(this, "attr." + e, t)) : t == null ? (r.local ? Ub : Yb)(r) : (r.local ? Xb : Gb)(r, i, t));
}
function Qb(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function Jb(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function t1(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Jb(e, a)), r;
  }
  return n._value = t, n;
}
function e1(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Qb(e, a)), r;
  }
  return n._value = t, n;
}
function r1(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = Sa(e);
  return this.tween(r, (i.local ? t1 : e1)(i, t));
}
function i1(e, t) {
  return function() {
    Ro(this, e).delay = +t.apply(this, arguments);
  };
}
function n1(e, t) {
  return t = +t, function() {
    Ro(this, e).delay = t;
  };
}
function a1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? i1 : n1)(t, e)) : de(this.node(), t).delay;
}
function s1(e, t) {
  return function() {
    ke(this, e).duration = +t.apply(this, arguments);
  };
}
function o1(e, t) {
  return t = +t, function() {
    ke(this, e).duration = t;
  };
}
function l1(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? s1 : o1)(t, e)) : de(this.node(), t).duration;
}
function c1(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    ke(this, e).ease = t;
  };
}
function h1(e) {
  var t = this._id;
  return arguments.length ? this.each(c1(t, e)) : de(this.node(), t).ease;
}
function u1(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    ke(this, e).ease = r;
  };
}
function f1(e) {
  if (typeof e != "function") throw new Error();
  return this.each(u1(this._id, e));
}
function d1(e) {
  typeof e != "function" && (e = Qh(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], s = a.length, o = i[n] = [], l, c = 0; c < s; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && o.push(l);
  return new De(i, this._parents, this._name, this._id);
}
function p1(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), s = new Array(i), o = 0; o < a; ++o)
    for (var l = t[o], c = r[o], h = l.length, u = s[o] = new Array(h), d, f = 0; f < h; ++f)
      (d = l[f] || c[f]) && (u[f] = d);
  for (; o < i; ++o)
    s[o] = t[o];
  return new De(s, this._parents, this._name, this._id);
}
function g1(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function m1(e, t, r) {
  var i, n, a = g1(t) ? Ro : ke;
  return function() {
    var s = a(this, e), o = s.on;
    o !== i && (n = (i = o).copy()).on(t, r), s.on = n;
  };
}
function y1(e, t) {
  var r = this._id;
  return arguments.length < 2 ? de(this.node(), r).on.on(e) : this.each(m1(r, e, t));
}
function x1(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function b1() {
  return this.on("end.remove", x1(this._id));
}
function C1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = $o(e));
  for (var i = this._groups, n = i.length, a = new Array(n), s = 0; s < n; ++s)
    for (var o = i[s], l = o.length, c = a[s] = new Array(l), h, u, d = 0; d < l; ++d)
      (h = o[d]) && (u = e.call(h, h.__data__, d, o)) && ("__data__" in h && (u.__data__ = h.__data__), c[d] = u, Ba(c[d], t, r, d, c, de(h, r)));
  return new De(a, this._parents, t, r);
}
function _1(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Kh(e));
  for (var i = this._groups, n = i.length, a = [], s = [], o = 0; o < n; ++o)
    for (var l = i[o], c = l.length, h, u = 0; u < c; ++u)
      if (h = l[u]) {
        for (var d = e.call(h, h.__data__, u, l), f, g = de(h, r), m = 0, y = d.length; m < y; ++m)
          (f = d[m]) && Ba(f, t, r, m, d, g);
        a.push(d), s.push(h);
      }
  return new De(a, s, t, r);
}
var w1 = Zi.prototype.constructor;
function k1() {
  return new w1(this._groups, this._parents);
}
function v1(e, t) {
  var r, i, n;
  return function() {
    var a = Yr(this, e), s = (this.style.removeProperty(e), Yr(this, e));
    return a === s ? null : a === r && s === i ? n : n = t(r = a, i = s);
  };
}
function bu(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function S1(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var s = Yr(this, e);
    return s === n ? null : s === i ? a : a = t(i = s, r);
  };
}
function T1(e, t, r) {
  var i, n, a;
  return function() {
    var s = Yr(this, e), o = r(this), l = o + "";
    return o == null && (l = o = (this.style.removeProperty(e), Yr(this, e))), s === l ? null : s === i && l === n ? a : (n = l, a = t(i = s, o));
  };
}
function B1(e, t) {
  var r, i, n, a = "style." + t, s = "end." + a, o;
  return function() {
    var l = ke(this, e), c = l.on, h = l.value[a] == null ? o || (o = bu(t)) : void 0;
    (c !== r || n !== h) && (i = (r = c).copy()).on(s, n = h), l.on = i;
  };
}
function L1(e, t, r) {
  var i = (e += "") == "transform" ? $b : xu;
  return t == null ? this.styleTween(e, v1(e, i)).on("end.style." + e, bu(e)) : typeof t == "function" ? this.styleTween(e, T1(e, i, Io(this, "style." + e, t))).each(B1(this._id, e)) : this.styleTween(e, S1(e, i, t), r).on("end.style." + e, null);
}
function A1(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function M1(e, t, r) {
  var i, n;
  function a() {
    var s = t.apply(this, arguments);
    return s !== n && (i = (n = s) && A1(e, s, r)), i;
  }
  return a._value = t, a;
}
function $1(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, M1(e, t, r ?? ""));
}
function E1(e) {
  return function() {
    this.textContent = e;
  };
}
function F1(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function D1(e) {
  return this.tween("text", typeof e == "function" ? F1(Io(this, "text", e)) : E1(e == null ? "" : e + ""));
}
function O1(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function R1(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && O1(n)), t;
  }
  return i._value = e, i;
}
function I1(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, R1(e));
}
function P1() {
  for (var e = this._name, t = this._id, r = Cu(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var s = i[a], o = s.length, l, c = 0; c < o; ++c)
      if (l = s[c]) {
        var h = de(l, t);
        Ba(l, e, r, c, s, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new De(i, this._parents, e, r);
}
function N1() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, s) {
    var o = { value: s }, l = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var c = ke(this, i), h = c.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(o), t._.interrupt.push(o), t._.end.push(l)), c.on = t;
    }), n === 0 && a();
  });
}
var z1 = 0;
function De(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function Cu() {
  return ++z1;
}
var Ae = Zi.prototype;
De.prototype = {
  constructor: De,
  select: C1,
  selectAll: _1,
  selectChild: Ae.selectChild,
  selectChildren: Ae.selectChildren,
  filter: d1,
  merge: p1,
  selection: k1,
  transition: P1,
  call: Ae.call,
  nodes: Ae.nodes,
  node: Ae.node,
  size: Ae.size,
  empty: Ae.empty,
  each: Ae.each,
  on: y1,
  attr: Kb,
  attrTween: r1,
  style: L1,
  styleTween: $1,
  text: D1,
  textTween: I1,
  remove: b1,
  tween: jb,
  delay: a1,
  duration: l1,
  ease: h1,
  easeVarying: f1,
  end: N1,
  [Symbol.iterator]: Ae[Symbol.iterator]
};
function W1(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var q1 = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: W1
};
function H1(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function j1(e) {
  var t, r;
  e instanceof De ? (t = e._id, e = e._name) : (t = Cu(), (r = q1).time = Oo(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var s = i[a], o = s.length, l, c = 0; c < o; ++c)
      (l = s[c]) && Ba(l, e, t, c, s, r || H1(l, t));
  return new De(i, this._parents, e, t);
}
Zi.prototype.interrupt = Wb;
Zi.prototype.transition = j1;
const Ps = Math.PI, Ns = 2 * Ps, rr = 1e-6, Y1 = Ns - rr;
function _u(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function U1(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return _u;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class G1 {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? _u : U1(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, s) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +s}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let s = this._x1, o = this._y1, l = i - t, c = n - r, h = s - t, u = o - r, d = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (d > rr) if (!(Math.abs(u * l - c * h) > rr) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let f = i - s, g = n - o, m = l * l + c * c, y = f * f + g * g, x = Math.sqrt(m), b = Math.sqrt(d), _ = a * Math.tan((Ps - Math.acos((m + d - y) / (2 * x * b))) / 2), v = _ / b, k = _ / x;
      Math.abs(v - 1) > rr && this._append`L${t + v * h},${r + v * u}`, this._append`A${a},${a},0,0,${+(u * f > h * g)},${this._x1 = t + k * l},${this._y1 = r + k * c}`;
    }
  }
  arc(t, r, i, n, a, s) {
    if (t = +t, r = +r, i = +i, s = !!s, i < 0) throw new Error(`negative radius: ${i}`);
    let o = i * Math.cos(n), l = i * Math.sin(n), c = t + o, h = r + l, u = 1 ^ s, d = s ? n - a : a - n;
    this._x1 === null ? this._append`M${c},${h}` : (Math.abs(this._x1 - c) > rr || Math.abs(this._y1 - h) > rr) && this._append`L${c},${h}`, i && (d < 0 && (d = d % Ns + Ns), d > Y1 ? this._append`A${i},${i},0,1,${u},${t - o},${r - l}A${i},${i},0,1,${u},${this._x1 = c},${this._y1 = h}` : d > rr && this._append`A${i},${i},0,${+(d >= Ps)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Br(e) {
  return function() {
    return e;
  };
}
const uA = Math.abs, fA = Math.atan2, dA = Math.cos, pA = Math.max, gA = Math.min, mA = Math.sin, yA = Math.sqrt, bc = 1e-12, Po = Math.PI, Cc = Po / 2, xA = 2 * Po;
function bA(e) {
  return e > 1 ? 0 : e < -1 ? Po : Math.acos(e);
}
function CA(e) {
  return e >= 1 ? Cc : e <= -1 ? -Cc : Math.asin(e);
}
function X1(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new G1(t);
}
function V1(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function wu(e) {
  this._context = e;
}
wu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      // falls through
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function Mi(e) {
  return new wu(e);
}
function Z1(e) {
  return e[0];
}
function K1(e) {
  return e[1];
}
function Q1(e, t) {
  var r = Br(!0), i = null, n = Mi, a = null, s = X1(o);
  e = typeof e == "function" ? e : e === void 0 ? Z1 : Br(e), t = typeof t == "function" ? t : t === void 0 ? K1 : Br(t);
  function o(l) {
    var c, h = (l = V1(l)).length, u, d = !1, f;
    for (i == null && (a = n(f = s())), c = 0; c <= h; ++c)
      !(c < h && r(u = l[c], c, l)) === d && ((d = !d) ? a.lineStart() : a.lineEnd()), d && a.point(+e(u, c, l), +t(u, c, l));
    if (f) return a = null, f + "" || null;
  }
  return o.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : Br(+l), o) : e;
  }, o.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : Br(+l), o) : t;
  }, o.defined = function(l) {
    return arguments.length ? (r = typeof l == "function" ? l : Br(!!l), o) : r;
  }, o.curve = function(l) {
    return arguments.length ? (n = l, i != null && (a = n(i)), o) : n;
  }, o.context = function(l) {
    return arguments.length ? (l == null ? i = a = null : a = n(i = l), o) : i;
  }, o;
}
class ku {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      // falls through
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function vu(e) {
  return new ku(e, !0);
}
function Su(e) {
  return new ku(e, !1);
}
function Ue() {
}
function Kn(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function La(e) {
  this._context = e;
}
La.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        Kn(this, this._x1, this._y1);
      // falls through
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      // falls through
      default:
        Kn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function zs(e) {
  return new La(e);
}
function Tu(e) {
  this._context = e;
}
Tu.prototype = {
  areaStart: Ue,
  areaEnd: Ue,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        Kn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function J1(e) {
  return new Tu(e);
}
function Bu(e) {
  this._context = e;
}
Bu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        Kn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function t2(e) {
  return new Bu(e);
}
function Lu(e, t) {
  this._basis = new La(e), this._beta = t;
}
Lu.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, s = t[r] - n, o = -1, l; ++o <= r; )
        l = o / r, this._basis.point(
          this._beta * e[o] + (1 - this._beta) * (i + l * a),
          this._beta * t[o] + (1 - this._beta) * (n + l * s)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const e2 = (function e(t) {
  function r(i) {
    return t === 1 ? new La(i) : new Lu(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
})(0.85);
function Qn(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function No(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
No.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        Qn(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      // falls through
      default:
        Qn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Au = (function e(t) {
  function r(i) {
    return new No(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
})(0);
function zo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
zo.prototype = {
  areaStart: Ue,
  areaEnd: Ue,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        Qn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const r2 = (function e(t) {
  function r(i) {
    return new zo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
})(0);
function Wo(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Wo.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        Qn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const i2 = (function e(t) {
  function r(i) {
    return new Wo(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
})(0);
function qo(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, s = e._y2;
  if (e._l01_a > bc) {
    var o = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, l = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * o - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, n = (n * o - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l;
  }
  if (e._l23_a > bc) {
    var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * c + e._x1 * e._l23_2a - t * e._l12_2a) / h, s = (s * c + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, s, e._x2, e._y2);
}
function Mu(e, t) {
  this._context = e, this._alpha = t;
}
Mu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      // falls through
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const $u = (function e(t) {
  function r(i) {
    return t ? new Mu(i, t) : new No(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
})(0.5);
function Eu(e, t) {
  this._context = e, this._alpha = t;
}
Eu.prototype = {
  areaStart: Ue,
  areaEnd: Ue,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const n2 = (function e(t) {
  function r(i) {
    return t ? new Eu(i, t) : new zo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
})(0.5);
function Fu(e, t) {
  this._context = e, this._alpha = t;
}
Fu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        qo(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const a2 = (function e(t) {
  function r(i) {
    return t ? new Fu(i, t) : new Wo(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
})(0.5);
function Du(e) {
  this._context = e;
}
Du.prototype = {
  areaStart: Ue,
  areaEnd: Ue,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function s2(e) {
  return new Du(e);
}
function _c(e) {
  return e < 0 ? -1 : 1;
}
function wc(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), s = (r - e._y1) / (n || i < 0 && -0), o = (a * n + s * i) / (i + n);
  return (_c(a) + _c(s)) * Math.min(Math.abs(a), Math.abs(s), 0.5 * Math.abs(o)) || 0;
}
function kc(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function us(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, s = e._y1, o = (a - i) / 3;
  e._context.bezierCurveTo(i + o, n + o * t, a - o, s - o * r, a, s);
}
function Jn(e) {
  this._context = e;
}
Jn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        us(this, this._t0, kc(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, us(this, kc(this, r = wc(this, e, t)), r);
          break;
        default:
          us(this, this._t0, r = wc(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Ou(e) {
  this._context = new Ru(e);
}
(Ou.prototype = Object.create(Jn.prototype)).point = function(e, t) {
  Jn.prototype.point.call(this, t, e);
};
function Ru(e) {
  this._context = e;
}
Ru.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Iu(e) {
  return new Jn(e);
}
function Pu(e) {
  return new Ou(e);
}
function Nu(e) {
  this._context = e;
}
Nu.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = vc(e), n = vc(t), a = 0, s = 1; s < r; ++a, ++s)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[s], t[s]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function vc(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), s = new Array(r);
  for (n[0] = 0, a[0] = 2, s[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, s[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, s[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, s[t] -= i * s[t - 1];
  for (n[r - 1] = s[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (s[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function zu(e) {
  return new Nu(e);
}
function Aa(e, t) {
  this._context = e, this._t = t;
}
Aa.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      // falls through
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function Wu(e) {
  return new Aa(e, 0.5);
}
function qu(e) {
  return new Aa(e, 0);
}
function Hu(e) {
  return new Aa(e, 1);
}
function _i(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
_i.prototype = {
  constructor: _i,
  scale: function(e) {
    return e === 1 ? this : new _i(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new _i(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
_i.prototype;
var o2 = /* @__PURE__ */ p((e) => {
  const { securityLevel: t } = ft();
  let r = lt("body");
  if (t === "sandbox") {
    const a = lt(`#i${e}`).node()?.contentDocument ?? document;
    r = lt(a.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement");
function Ho(e) {
  return typeof e > "u" || e === null;
}
p(Ho, "isNothing");
function ju(e) {
  return typeof e == "object" && e !== null;
}
p(ju, "isObject");
function Yu(e) {
  return Array.isArray(e) ? e : Ho(e) ? [] : [e];
}
p(Yu, "toArray");
function Uu(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
p(Uu, "extend");
function Gu(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
p(Gu, "repeat");
function Xu(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
p(Xu, "isNegativeZero");
var l2 = Ho, c2 = ju, h2 = Yu, u2 = Gu, f2 = Xu, d2 = Uu, Tt = {
  isNothing: l2,
  isObject: c2,
  toArray: h2,
  repeat: u2,
  isNegativeZero: f2,
  extend: d2
};
function jo(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
p(jo, "formatError");
function Gr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = jo(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
p(Gr, "YAMLException$1");
Gr.prototype = Object.create(Error.prototype);
Gr.prototype.constructor = Gr;
Gr.prototype.toString = /* @__PURE__ */ p(function(t) {
  return this.name + ": " + jo(this, t);
}, "toString");
var Xt = Gr;
function Fn(e, t, r, i, n) {
  var a = "", s = "", o = Math.floor(n / 2) - 1;
  return i - t > o && (a = " ... ", t = i - o + a.length), r - i > o && (s = " ...", r = i + o - s.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + s,
    pos: i - t + a.length
    // relative position
  };
}
p(Fn, "getLine");
function Dn(e, t) {
  return Tt.repeat(" ", t - e.length) + e;
}
p(Dn, "padStart");
function Vu(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, s = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && s < 0 && (s = i.length - 2);
  s < 0 && (s = i.length - 1);
  var o = "", l, c, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (l = 1; l <= t.linesBefore && !(s - l < 0); l++)
    c = Fn(
      e.buffer,
      i[s - l],
      n[s - l],
      e.position - (i[s] - i[s - l]),
      u
    ), o = Tt.repeat(" ", t.indent) + Dn((e.line - l + 1).toString(), h) + " | " + c.str + `
` + o;
  for (c = Fn(e.buffer, i[s], n[s], e.position, u), o += Tt.repeat(" ", t.indent) + Dn((e.line + 1).toString(), h) + " | " + c.str + `
`, o += Tt.repeat("-", t.indent + h + 3 + c.pos) + `^
`, l = 1; l <= t.linesAfter && !(s + l >= n.length); l++)
    c = Fn(
      e.buffer,
      i[s + l],
      n[s + l],
      e.position - (i[s] - i[s + l]),
      u
    ), o += Tt.repeat(" ", t.indent) + Dn((e.line + l + 1).toString(), h) + " | " + c.str + `
`;
  return o.replace(/\n$/, "");
}
p(Vu, "makeSnippet");
var p2 = Vu, g2 = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], m2 = [
  "scalar",
  "sequence",
  "mapping"
];
function Zu(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
p(Zu, "compileStyleAliases");
function Ku(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (g2.indexOf(r) === -1)
      throw new Xt('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = Zu(t.styleAliases || null), m2.indexOf(this.kind) === -1)
    throw new Xt('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
p(Ku, "Type$1");
var Ot = Ku;
function Ws(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, s) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = s);
    }), r[n] = i;
  }), r;
}
p(Ws, "compileList");
function Qu() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (p(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
p(Qu, "compileMap");
function ta(e) {
  return this.extend(e);
}
p(ta, "Schema$1");
ta.prototype.extend = /* @__PURE__ */ p(function(t) {
  var r = [], i = [];
  if (t instanceof Ot)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new Xt("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof Ot))
      throw new Xt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new Xt("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new Xt("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof Ot))
      throw new Xt("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(ta.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = Ws(n, "implicit"), n.compiledExplicit = Ws(n, "explicit"), n.compiledTypeMap = Qu(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var y2 = ta, x2 = new Ot("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), b2 = new Ot("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), C2 = new Ot("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), _2 = new y2({
  explicit: [
    x2,
    b2,
    C2
  ]
});
function Ju(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
p(Ju, "resolveYamlNull");
function tf() {
  return null;
}
p(tf, "constructYamlNull");
function ef(e) {
  return e === null;
}
p(ef, "isNull");
var w2 = new Ot("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: Ju,
  construct: tf,
  predicate: ef,
  represent: {
    canonical: /* @__PURE__ */ p(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ p(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ p(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ p(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ p(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function rf(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
p(rf, "resolveYamlBoolean");
function nf(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
p(nf, "constructYamlBoolean");
function af(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
p(af, "isBoolean");
var k2 = new Ot("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: rf,
  construct: nf,
  predicate: af,
  represent: {
    lowercase: /* @__PURE__ */ p(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ p(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ p(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function sf(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
p(sf, "isHexCode");
function of(e) {
  return 48 <= e && e <= 55;
}
p(of, "isOctCode");
function lf(e) {
  return 48 <= e && e <= 57;
}
p(lf, "isDecCode");
function cf(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!sf(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!of(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!lf(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
p(cf, "resolveYamlInteger");
function hf(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
p(hf, "constructYamlInteger");
function uf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !Tt.isNegativeZero(e);
}
p(uf, "isInteger");
var v2 = new Ot("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: cf,
  construct: hf,
  predicate: uf,
  represent: {
    binary: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ p(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), S2 = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function ff(e) {
  return !(e === null || !S2.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
p(ff, "resolveYamlFloat");
function df(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
p(df, "constructYamlFloat");
var T2 = /^[-+]?[0-9]+e/;
function pf(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (Tt.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), T2.test(r) ? r.replace("e", ".e") : r;
}
p(pf, "representYamlFloat");
function gf(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || Tt.isNegativeZero(e));
}
p(gf, "isFloat");
var B2 = new Ot("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: ff,
  construct: df,
  predicate: gf,
  represent: pf,
  defaultStyle: "lowercase"
}), mf = _2.extend({
  implicit: [
    w2,
    k2,
    v2,
    B2
  ]
}), L2 = mf, yf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), xf = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function bf(e) {
  return e === null ? !1 : yf.exec(e) !== null || xf.exec(e) !== null;
}
p(bf, "resolveYamlTimestamp");
function Cf(e) {
  var t, r, i, n, a, s, o, l = 0, c = null, h, u, d;
  if (t = yf.exec(e), t === null && (t = xf.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], s = +t[5], o = +t[6], t[7]) {
    for (l = t[7].slice(0, 3); l.length < 3; )
      l += "0";
    l = +l;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), c = (h * 60 + u) * 6e4, t[9] === "-" && (c = -c)), d = new Date(Date.UTC(r, i, n, a, s, o, l)), c && d.setTime(d.getTime() - c), d;
}
p(Cf, "constructYamlTimestamp");
function _f(e) {
  return e.toISOString();
}
p(_f, "representYamlTimestamp");
var A2 = new Ot("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: bf,
  construct: Cf,
  instanceOf: Date,
  represent: _f
});
function wf(e) {
  return e === "<<" || e === null;
}
p(wf, "resolveYamlMerge");
var M2 = new Ot("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: wf
}), Yo = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function kf(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = Yo;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
p(kf, "resolveYamlBinary");
function vf(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = Yo, s = 0, o = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (o.push(s >> 16 & 255), o.push(s >> 8 & 255), o.push(s & 255)), s = s << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (o.push(s >> 16 & 255), o.push(s >> 8 & 255), o.push(s & 255)) : r === 18 ? (o.push(s >> 10 & 255), o.push(s >> 2 & 255)) : r === 12 && o.push(s >> 4 & 255), new Uint8Array(o);
}
p(vf, "constructYamlBinary");
function Sf(e) {
  var t = "", r = 0, i, n, a = e.length, s = Yo;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += s[r >> 18 & 63], t += s[r >> 12 & 63], t += s[r >> 6 & 63], t += s[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += s[r >> 18 & 63], t += s[r >> 12 & 63], t += s[r >> 6 & 63], t += s[r & 63]) : n === 2 ? (t += s[r >> 10 & 63], t += s[r >> 4 & 63], t += s[r << 2 & 63], t += s[64]) : n === 1 && (t += s[r >> 2 & 63], t += s[r << 4 & 63], t += s[64], t += s[64]), t;
}
p(Sf, "representYamlBinary");
function Tf(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
p(Tf, "isBinary");
var $2 = new Ot("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: kf,
  construct: vf,
  predicate: Tf,
  represent: Sf
}), E2 = Object.prototype.hasOwnProperty, F2 = Object.prototype.toString;
function Bf(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, s, o = e;
  for (r = 0, i = o.length; r < i; r += 1) {
    if (n = o[r], s = !1, F2.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (E2.call(n, a))
        if (!s) s = !0;
        else return !1;
    if (!s) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
p(Bf, "resolveYamlOmap");
function Lf(e) {
  return e !== null ? e : [];
}
p(Lf, "constructYamlOmap");
var D2 = new Ot("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: Bf,
  construct: Lf
}), O2 = Object.prototype.toString;
function Af(e) {
  if (e === null) return !0;
  var t, r, i, n, a, s = e;
  for (a = new Array(s.length), t = 0, r = s.length; t < r; t += 1) {
    if (i = s[t], O2.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
p(Af, "resolveYamlPairs");
function Mf(e) {
  if (e === null) return [];
  var t, r, i, n, a, s = e;
  for (a = new Array(s.length), t = 0, r = s.length; t < r; t += 1)
    i = s[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
p(Mf, "constructYamlPairs");
var R2 = new Ot("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: Af,
  construct: Mf
}), I2 = Object.prototype.hasOwnProperty;
function $f(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (I2.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
p($f, "resolveYamlSet");
function Ef(e) {
  return e !== null ? e : {};
}
p(Ef, "constructYamlSet");
var P2 = new Ot("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: $f,
  construct: Ef
}), Ff = L2.extend({
  implicit: [
    A2,
    M2
  ],
  explicit: [
    $2,
    D2,
    R2,
    P2
  ]
}), Ge = Object.prototype.hasOwnProperty, ea = 1, Df = 2, Of = 3, ra = 4, fs = 1, N2 = 2, Sc = 3, z2 = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, W2 = /[\x85\u2028\u2029]/, q2 = /[,\[\]\{\}]/, Rf = /^(?:!|!!|![a-z\-]+!)$/i, If = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function qs(e) {
  return Object.prototype.toString.call(e);
}
p(qs, "_class");
function he(e) {
  return e === 10 || e === 13;
}
p(he, "is_EOL");
function Ye(e) {
  return e === 9 || e === 32;
}
p(Ye, "is_WHITE_SPACE");
function Wt(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
p(Wt, "is_WS_OR_EOL");
function or(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
p(or, "is_FLOW_INDICATOR");
function Pf(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
p(Pf, "fromHexCode");
function Nf(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
p(Nf, "escapedHexLen");
function zf(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
p(zf, "fromDecimalCode");
function Hs(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
p(Hs, "simpleEscapeSequence");
function Wf(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
p(Wf, "charFromCodepoint");
function Uo(e, t, r) {
  t === "__proto__" ? Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: r
  }) : e[t] = r;
}
p(Uo, "setProperty");
var qf = new Array(256), Hf = new Array(256);
for (er = 0; er < 256; er++)
  qf[er] = Hs(er) ? 1 : 0, Hf[er] = Hs(er);
var er;
function jf(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Ff, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
p(jf, "State$1");
function Go(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = p2(r), new Xt(t, r);
}
p(Go, "generateError");
function Q(e, t) {
  throw Go(e, t);
}
p(Q, "throwError");
function Pi(e, t) {
  e.onWarning && e.onWarning.call(null, Go(e, t));
}
p(Pi, "throwWarning");
var Tc = {
  YAML: /* @__PURE__ */ p(function(t, r, i) {
    var n, a, s;
    t.version !== null && Q(t, "duplication of %YAML directive"), i.length !== 1 && Q(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && Q(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), s = parseInt(n[2], 10), a !== 1 && Q(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = s < 2, s !== 1 && s !== 2 && Pi(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ p(function(t, r, i) {
    var n, a;
    i.length !== 2 && Q(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], Rf.test(n) || Q(t, "ill-formed tag handle (first argument) of the TAG directive"), Ge.call(t.tagMap, n) && Q(t, 'there is a previously declared suffix for "' + n + '" tag handle'), If.test(a) || Q(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      Q(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function Fe(e, t, r, i) {
  var n, a, s, o;
  if (t < r) {
    if (o = e.input.slice(t, r), i)
      for (n = 0, a = o.length; n < a; n += 1)
        s = o.charCodeAt(n), s === 9 || 32 <= s && s <= 1114111 || Q(e, "expected valid JSON character");
    else z2.test(o) && Q(e, "the stream contains non-printable characters");
    e.result += o;
  }
}
p(Fe, "captureSegment");
function js(e, t, r, i) {
  var n, a, s, o;
  for (Tt.isObject(r) || Q(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), s = 0, o = n.length; s < o; s += 1)
    a = n[s], Ge.call(t, a) || (Uo(t, a, r[a]), i[a] = !0);
}
p(js, "mergeMappings");
function lr(e, t, r, i, n, a, s, o, l) {
  var c, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), c = 0, h = n.length; c < h; c += 1)
      Array.isArray(n[c]) && Q(e, "nested arrays are not supported inside keys"), typeof n == "object" && qs(n[c]) === "[object Object]" && (n[c] = "[object Object]");
  if (typeof n == "object" && qs(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (c = 0, h = a.length; c < h; c += 1)
        js(e, t, a[c], r);
    else
      js(e, t, a, r);
  else
    !e.json && !Ge.call(r, n) && Ge.call(t, n) && (e.line = s || e.line, e.lineStart = o || e.lineStart, e.position = l || e.position, Q(e, "duplicated mapping key")), Uo(t, n, a), delete r[n];
  return t;
}
p(lr, "storeMappingPair");
function Ma(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : Q(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
p(Ma, "readLineBreak");
function bt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; Ye(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (he(n))
      for (Ma(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && Pi(e, "deficient indentation"), i;
}
p(bt, "skipSeparationSpace");
function Qi(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || Wt(r)));
}
p(Qi, "testDocumentSeparator");
function $a(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += Tt.repeat(`
`, t - 1));
}
p($a, "writeFoldedLines");
function Yf(e, t, r) {
  var i, n, a, s, o, l, c, h, u = e.kind, d = e.result, f;
  if (f = e.input.charCodeAt(e.position), Wt(f) || or(f) || f === 35 || f === 38 || f === 42 || f === 33 || f === 124 || f === 62 || f === 39 || f === 34 || f === 37 || f === 64 || f === 96 || (f === 63 || f === 45) && (n = e.input.charCodeAt(e.position + 1), Wt(n) || r && or(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = s = e.position, o = !1; f !== 0; ) {
    if (f === 58) {
      if (n = e.input.charCodeAt(e.position + 1), Wt(n) || r && or(n))
        break;
    } else if (f === 35) {
      if (i = e.input.charCodeAt(e.position - 1), Wt(i))
        break;
    } else {
      if (e.position === e.lineStart && Qi(e) || r && or(f))
        break;
      if (he(f))
        if (l = e.line, c = e.lineStart, h = e.lineIndent, bt(e, !1, -1), e.lineIndent >= t) {
          o = !0, f = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = s, e.line = l, e.lineStart = c, e.lineIndent = h;
          break;
        }
    }
    o && (Fe(e, a, s, !1), $a(e, e.line - l), a = s = e.position, o = !1), Ye(f) || (s = e.position + 1), f = e.input.charCodeAt(++e.position);
  }
  return Fe(e, a, s, !1), e.result ? !0 : (e.kind = u, e.result = d, !1);
}
p(Yf, "readPlainScalar");
function Uf(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (Fe(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else he(r) ? (Fe(e, i, n, !0), $a(e, bt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && Qi(e) ? Q(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  Q(e, "unexpected end of the stream within a single quoted scalar");
}
p(Uf, "readSingleQuotedScalar");
function Gf(e, t) {
  var r, i, n, a, s, o;
  if (o = e.input.charCodeAt(e.position), o !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (o = e.input.charCodeAt(e.position)) !== 0; ) {
    if (o === 34)
      return Fe(e, r, e.position, !0), e.position++, !0;
    if (o === 92) {
      if (Fe(e, r, e.position, !0), o = e.input.charCodeAt(++e.position), he(o))
        bt(e, !1, t);
      else if (o < 256 && qf[o])
        e.result += Hf[o], e.position++;
      else if ((s = Nf(o)) > 0) {
        for (n = s, a = 0; n > 0; n--)
          o = e.input.charCodeAt(++e.position), (s = Pf(o)) >= 0 ? a = (a << 4) + s : Q(e, "expected hexadecimal character");
        e.result += Wf(a), e.position++;
      } else
        Q(e, "unknown escape sequence");
      r = i = e.position;
    } else he(o) ? (Fe(e, r, i, !0), $a(e, bt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && Qi(e) ? Q(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  Q(e, "unexpected end of the stream within a double quoted scalar");
}
p(Gf, "readDoubleQuotedScalar");
function Xf(e, t) {
  var r = !0, i, n, a, s = e.tag, o, l = e.anchor, c, h, u, d, f, g = /* @__PURE__ */ Object.create(null), m, y, x, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, f = !1, o = [];
  else if (b === 123)
    h = 125, f = !0, o = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = o), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (bt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = s, e.anchor = l, e.kind = f ? "mapping" : "sequence", e.result = o, !0;
    r ? b === 44 && Q(e, "expected the node content, but found ','") : Q(e, "missed comma between flow collection entries"), y = m = x = null, u = d = !1, b === 63 && (c = e.input.charCodeAt(e.position + 1), Wt(c) && (u = d = !0, e.position++, bt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, pr(e, t, ea, !1, !0), y = e.tag, m = e.result, bt(e, !0, t), b = e.input.charCodeAt(e.position), (d || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), bt(e, !0, t), pr(e, t, ea, !1, !0), x = e.result), f ? lr(e, o, g, y, m, x, i, n, a) : u ? o.push(lr(e, null, g, y, m, x, i, n, a)) : o.push(m), bt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  Q(e, "unexpected end of the stream within a flow collection");
}
p(Xf, "readFlowCollection");
function Vf(e, t) {
  var r, i, n = fs, a = !1, s = !1, o = t, l = 0, c = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      fs === n ? n = u === 43 ? Sc : N2 : Q(e, "repeat of a chomping mode identifier");
    else if ((h = zf(u)) >= 0)
      h === 0 ? Q(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : s ? Q(e, "repeat of an indentation width identifier") : (o = t + h - 1, s = !0);
    else
      break;
  if (Ye(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (Ye(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!he(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (Ma(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!s || e.lineIndent < o) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!s && e.lineIndent > o && (o = e.lineIndent), he(u)) {
      l++;
      continue;
    }
    if (e.lineIndent < o) {
      n === Sc ? e.result += Tt.repeat(`
`, a ? 1 + l : l) : n === fs && a && (e.result += `
`);
      break;
    }
    for (i ? Ye(u) ? (c = !0, e.result += Tt.repeat(`
`, a ? 1 + l : l)) : c ? (c = !1, e.result += Tt.repeat(`
`, l + 1)) : l === 0 ? a && (e.result += " ") : e.result += Tt.repeat(`
`, l) : e.result += Tt.repeat(`
`, a ? 1 + l : l), a = !0, s = !0, l = 0, r = e.position; !he(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    Fe(e, r, e.position, !1);
  }
  return !0;
}
p(Vf, "readBlockScalar");
function Ys(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], s, o = !1, l;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), l = e.input.charCodeAt(e.position); l !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, Q(e, "tab characters must not be used in indentation")), !(l !== 45 || (s = e.input.charCodeAt(e.position + 1), !Wt(s)))); ) {
    if (o = !0, e.position++, bt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), l = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, pr(e, t, Of, !1, !0), a.push(e.result), bt(e, !0, -1), l = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && l !== 0)
      Q(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return o ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
p(Ys, "readBlockSequence");
function Zf(e, t, r) {
  var i, n, a, s, o, l, c = e.tag, h = e.anchor, u = {}, d = /* @__PURE__ */ Object.create(null), f = null, g = null, m = null, y = !1, x = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!y && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, Q(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && Wt(i))
      b === 63 ? (y && (lr(e, u, d, f, g, null, s, o, l), f = g = m = null), x = !0, y = !0, n = !0) : y ? (y = !1, n = !0) : Q(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (s = e.line, o = e.lineStart, l = e.position, !pr(e, r, Df, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); Ye(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), Wt(b) || Q(e, "a whitespace character is expected after the key-value separator within a block mapping"), y && (lr(e, u, d, f, g, null, s, o, l), f = g = m = null), x = !0, y = !1, n = !1, f = e.tag, g = e.result;
        else if (x)
          Q(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = c, e.anchor = h, !0;
      } else if (x)
        Q(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = c, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (y && (s = e.line, o = e.lineStart, l = e.position), pr(e, t, ra, !0, n) && (y ? g = e.result : m = e.result), y || (lr(e, u, d, f, g, m, s, o, l), f = g = m = null), bt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      Q(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return y && lr(e, u, d, f, g, null, s, o, l), x && (e.tag = c, e.anchor = h, e.kind = "mapping", e.result = u), x;
}
p(Zf, "readBlockMapping");
function Kf(e) {
  var t, r = !1, i = !1, n, a, s;
  if (s = e.input.charCodeAt(e.position), s !== 33) return !1;
  if (e.tag !== null && Q(e, "duplication of a tag property"), s = e.input.charCodeAt(++e.position), s === 60 ? (r = !0, s = e.input.charCodeAt(++e.position)) : s === 33 ? (i = !0, n = "!!", s = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      s = e.input.charCodeAt(++e.position);
    while (s !== 0 && s !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), s = e.input.charCodeAt(++e.position)) : Q(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; s !== 0 && !Wt(s); )
      s === 33 && (i ? Q(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), Rf.test(n) || Q(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), s = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), q2.test(a) && Q(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !If.test(a) && Q(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    Q(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : Ge.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : Q(e, 'undeclared tag handle "' + n + '"'), !0;
}
p(Kf, "readTagProperty");
function Qf(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && Q(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !Wt(r) && !or(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && Q(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
p(Qf, "readAnchorProperty");
function Jf(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !Wt(i) && !or(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && Q(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), Ge.call(e.anchorMap, r) || Q(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], bt(e, !0, -1), !0;
}
p(Jf, "readAlias");
function pr(e, t, r, i, n) {
  var a, s, o, l = 1, c = !1, h = !1, u, d, f, g, m, y;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = s = o = ra === r || Of === r, i && bt(e, !0, -1) && (c = !0, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)), l === 1)
    for (; Kf(e) || Qf(e); )
      bt(e, !0, -1) ? (c = !0, o = a, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)) : o = !1;
  if (o && (o = c || n), (l === 1 || ra === r) && (ea === r || Df === r ? m = t : m = t + 1, y = e.position - e.lineStart, l === 1 ? o && (Ys(e, y) || Zf(e, y, m)) || Xf(e, m) ? h = !0 : (s && Vf(e, m) || Uf(e, m) || Gf(e, m) ? h = !0 : Jf(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && Q(e, "alias node should not have any properties")) : Yf(e, m, ea === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : l === 0 && (h = o && Ys(e, y))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && Q(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, d = e.implicitTypes.length; u < d; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (Ge.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, f = e.typeMap.multi[e.kind || "fallback"], u = 0, d = f.length; u < d; u += 1)
        if (e.tag.slice(0, f[u].tag.length) === f[u].tag) {
          g = f[u];
          break;
        }
    g || Q(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && Q(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : Q(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
p(pr, "composeNode");
function td(e) {
  var t = e.position, r, i, n, a = !1, s;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (s = e.input.charCodeAt(e.position)) !== 0 && (bt(e, !0, -1), s = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || s !== 37)); ) {
    for (a = !0, s = e.input.charCodeAt(++e.position), r = e.position; s !== 0 && !Wt(s); )
      s = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && Q(e, "directive name must not be less than one character in length"); s !== 0; ) {
      for (; Ye(s); )
        s = e.input.charCodeAt(++e.position);
      if (s === 35) {
        do
          s = e.input.charCodeAt(++e.position);
        while (s !== 0 && !he(s));
        break;
      }
      if (he(s)) break;
      for (r = e.position; s !== 0 && !Wt(s); )
        s = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    s !== 0 && Ma(e), Ge.call(Tc, i) ? Tc[i](e, i, n) : Pi(e, 'unknown document directive "' + i + '"');
  }
  if (bt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, bt(e, !0, -1)) : a && Q(e, "directives end mark is expected"), pr(e, e.lineIndent - 1, ra, !1, !0), bt(e, !0, -1), e.checkLineBreaks && W2.test(e.input.slice(t, e.position)) && Pi(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && Qi(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, bt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    Q(e, "end of the stream or a document separator is expected");
  else
    return;
}
p(td, "readDocument");
function Xo(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new jf(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, Q(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    td(r);
  return r.documents;
}
p(Xo, "loadDocuments");
function H2(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = Xo(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
p(H2, "loadAll$1");
function ed(e, t) {
  var r = Xo(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new Xt("expected a single document in the stream, but found more");
  }
}
p(ed, "load$1");
var j2 = ed, Y2 = {
  load: j2
}, rd = Object.prototype.toString, id = Object.prototype.hasOwnProperty, Vo = 65279, U2 = 9, Ni = 10, G2 = 13, X2 = 32, V2 = 33, Z2 = 34, Us = 35, K2 = 37, Q2 = 38, J2 = 39, tC = 42, nd = 44, eC = 45, ia = 58, rC = 61, iC = 62, nC = 63, aC = 64, ad = 91, sd = 93, sC = 96, od = 123, oC = 124, ld = 125, Pt = {};
Pt[0] = "\\0";
Pt[7] = "\\a";
Pt[8] = "\\b";
Pt[9] = "\\t";
Pt[10] = "\\n";
Pt[11] = "\\v";
Pt[12] = "\\f";
Pt[13] = "\\r";
Pt[27] = "\\e";
Pt[34] = '\\"';
Pt[92] = "\\\\";
Pt[133] = "\\N";
Pt[160] = "\\_";
Pt[8232] = "\\L";
Pt[8233] = "\\P";
var lC = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], cC = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function cd(e, t) {
  var r, i, n, a, s, o, l;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    s = i[n], o = String(t[s]), s.slice(0, 2) === "!!" && (s = "tag:yaml.org,2002:" + s.slice(2)), l = e.compiledTypeMap.fallback[s], l && id.call(l.styleAliases, o) && (o = l.styleAliases[o]), r[s] = o;
  return r;
}
p(cd, "compileStyleMap");
function hd(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new Xt("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + Tt.repeat("0", i - t.length) + t;
}
p(hd, "encodeHex");
var hC = 1, zi = 2;
function ud(e) {
  this.schema = e.schema || Ff, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = Tt.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = cd(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? zi : hC, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
p(ud, "State");
function Gs(e, t) {
  for (var r = Tt.repeat(" ", t), i = 0, n = -1, a = "", s, o = e.length; i < o; )
    n = e.indexOf(`
`, i), n === -1 ? (s = e.slice(i), i = o) : (s = e.slice(i, n + 1), i = n + 1), s.length && s !== `
` && (a += r), a += s;
  return a;
}
p(Gs, "indentString");
function na(e, t) {
  return `
` + Tt.repeat(" ", e.indent * t);
}
p(na, "generateNextLine");
function fd(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
p(fd, "testImplicitResolving");
function Wi(e) {
  return e === X2 || e === U2;
}
p(Wi, "isWhitespace");
function Xr(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== Vo || 65536 <= e && e <= 1114111;
}
p(Xr, "isPrintable");
function Xs(e) {
  return Xr(e) && e !== Vo && e !== G2 && e !== Ni;
}
p(Xs, "isNsCharOrWhitespace");
function Vs(e, t, r) {
  var i = Xs(e), n = i && !Wi(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== nd && e !== ad && e !== sd && e !== od && e !== ld) && e !== Us && !(t === ia && !n) || Xs(t) && !Wi(t) && e === Us || t === ia && n
  );
}
p(Vs, "isPlainSafe");
function dd(e) {
  return Xr(e) && e !== Vo && !Wi(e) && e !== eC && e !== nC && e !== ia && e !== nd && e !== ad && e !== sd && e !== od && e !== ld && e !== Us && e !== Q2 && e !== tC && e !== V2 && e !== oC && e !== rC && e !== iC && e !== J2 && e !== Z2 && e !== K2 && e !== aC && e !== sC;
}
p(dd, "isPlainSafeFirst");
function pd(e) {
  return !Wi(e) && e !== ia;
}
p(pd, "isPlainSafeLast");
function $r(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
p($r, "codePointAt");
function Zo(e) {
  var t = /^\n* /;
  return t.test(e);
}
p(Zo, "needIndentIndicator");
var gd = 1, Zs = 2, md = 3, yd = 4, Ar = 5;
function xd(e, t, r, i, n, a, s, o) {
  var l, c = 0, h = null, u = !1, d = !1, f = i !== -1, g = -1, m = dd($r(e, 0)) && pd($r(e, e.length - 1));
  if (t || s)
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = $r(e, l), !Xr(c))
        return Ar;
      m = m && Vs(c, h, o), h = c;
    }
  else {
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = $r(e, l), c === Ni)
        u = !0, f && (d = d || // Foldable line = too long, and not more-indented.
        l - g - 1 > i && e[g + 1] !== " ", g = l);
      else if (!Xr(c))
        return Ar;
      m = m && Vs(c, h, o), h = c;
    }
    d = d || f && l - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !d ? m && !s && !n(e) ? gd : a === zi ? Ar : Zs : r > 9 && Zo(e) ? Ar : s ? a === zi ? Ar : Zs : d ? yd : md;
}
p(xd, "chooseScalarStyle");
function bd(e, t, r, i, n) {
  e.dump = (function() {
    if (t.length === 0)
      return e.quotingType === zi ? '""' : "''";
    if (!e.noCompatMode && (lC.indexOf(t) !== -1 || cC.test(t)))
      return e.quotingType === zi ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), s = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), o = i || e.flowLevel > -1 && r >= e.flowLevel;
    function l(c) {
      return fd(e, c);
    }
    switch (p(l, "testAmbiguity"), xd(
      t,
      o,
      e.indent,
      s,
      l,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case gd:
        return t;
      case Zs:
        return "'" + t.replace(/'/g, "''") + "'";
      case md:
        return "|" + Ks(t, e.indent) + Qs(Gs(t, a));
      case yd:
        return ">" + Ks(t, e.indent) + Qs(Gs(Cd(t, s), a));
      case Ar:
        return '"' + _d(t) + '"';
      default:
        throw new Xt("impossible error: invalid scalar style");
    }
  })();
}
p(bd, "writeScalar");
function Ks(e, t) {
  var r = Zo(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
p(Ks, "blockHeader");
function Qs(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
p(Qs, "dropEndingNewline");
function Cd(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = (function() {
    var c = e.indexOf(`
`);
    return c = c !== -1 ? c : e.length, r.lastIndex = c, Js(e.slice(0, c), t);
  })(), n = e[0] === `
` || e[0] === " ", a, s; s = r.exec(e); ) {
    var o = s[1], l = s[2];
    a = l[0] === " ", i += o + (!n && !a && l !== "" ? `
` : "") + Js(l, t), n = a;
  }
  return i;
}
p(Cd, "foldString");
function Js(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, s = 0, o = 0, l = ""; i = r.exec(e); )
    o = i.index, o - n > t && (a = s > n ? s : o, l += `
` + e.slice(n, a), n = a + 1), s = o;
  return l += `
`, e.length - n > t && s > n ? l += e.slice(n, s) + `
` + e.slice(s + 1) : l += e.slice(n), l.slice(1);
}
p(Js, "foldLine");
function _d(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = $r(e, n), i = Pt[r], !i && Xr(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || hd(r);
  return t;
}
p(_d, "escapeString");
function wd(e, t, r) {
  var i = "", n = e.tag, a, s, o;
  for (a = 0, s = r.length; a < s; a += 1)
    o = r[a], e.replacer && (o = e.replacer.call(r, String(a), o)), (we(e, t, o, !1, !1) || typeof o > "u" && we(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
p(wd, "writeFlowSequence");
function to(e, t, r, i) {
  var n = "", a = e.tag, s, o, l;
  for (s = 0, o = r.length; s < o; s += 1)
    l = r[s], e.replacer && (l = e.replacer.call(r, String(s), l)), (we(e, t + 1, l, !0, !0, !1, !0) || typeof l > "u" && we(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += na(e, t)), e.dump && Ni === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
p(to, "writeBlockSequence");
function kd(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), s, o, l, c, h;
  for (s = 0, o = a.length; s < o; s += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), l = a[s], c = r[l], e.replacer && (c = e.replacer.call(r, l, c)), we(e, t, l, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), we(e, t, c, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
p(kd, "writeFlowMapping");
function vd(e, t, r, i) {
  var n = "", a = e.tag, s = Object.keys(r), o, l, c, h, u, d;
  if (e.sortKeys === !0)
    s.sort();
  else if (typeof e.sortKeys == "function")
    s.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new Xt("sortKeys must be a boolean or a function");
  for (o = 0, l = s.length; o < l; o += 1)
    d = "", (!i || n !== "") && (d += na(e, t)), c = s[o], h = r[c], e.replacer && (h = e.replacer.call(r, c, h)), we(e, t + 1, c, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && Ni === e.dump.charCodeAt(0) ? d += "?" : d += "? "), d += e.dump, u && (d += na(e, t)), we(e, t + 1, h, !0, u) && (e.dump && Ni === e.dump.charCodeAt(0) ? d += ":" : d += ": ", d += e.dump, n += d));
  e.tag = a, e.dump = n || "{}";
}
p(vd, "writeBlockMapping");
function eo(e, t, r) {
  var i, n, a, s, o, l;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, s = n.length; a < s; a += 1)
    if (o = n[a], (o.instanceOf || o.predicate) && (!o.instanceOf || typeof t == "object" && t instanceof o.instanceOf) && (!o.predicate || o.predicate(t))) {
      if (r ? o.multi && o.representName ? e.tag = o.representName(t) : e.tag = o.tag : e.tag = "?", o.represent) {
        if (l = e.styleMap[o.tag] || o.defaultStyle, rd.call(o.represent) === "[object Function]")
          i = o.represent(t, l);
        else if (id.call(o.represent, l))
          i = o.represent[l](t, l);
        else
          throw new Xt("!<" + o.tag + '> tag resolver accepts not "' + l + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
p(eo, "detectType");
function we(e, t, r, i, n, a, s) {
  e.tag = null, e.dump = r, eo(e, r, !1) || eo(e, r, !0);
  var o = rd.call(e.dump), l = i, c;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = o === "[object Object]" || o === "[object Array]", u, d;
  if (h && (u = e.duplicates.indexOf(r), d = u !== -1), (e.tag !== null && e.tag !== "?" || d || e.indent !== 2 && t > 0) && (n = !1), d && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && d && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), o === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (vd(e, t, e.dump, n), d && (e.dump = "&ref_" + u + e.dump)) : (kd(e, t, e.dump), d && (e.dump = "&ref_" + u + " " + e.dump));
    else if (o === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !s && t > 0 ? to(e, t - 1, e.dump, n) : to(e, t, e.dump, n), d && (e.dump = "&ref_" + u + e.dump)) : (wd(e, t, e.dump), d && (e.dump = "&ref_" + u + " " + e.dump));
    else if (o === "[object String]")
      e.tag !== "?" && bd(e, e.dump, t, a, l);
    else {
      if (o === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new Xt("unacceptable kind of an object to dump " + o);
    }
    e.tag !== null && e.tag !== "?" && (c = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? c = "!" + c : c.slice(0, 18) === "tag:yaml.org,2002:" ? c = "!!" + c.slice(18) : c = "!<" + c + ">", e.dump = c + " " + e.dump);
  }
  return !0;
}
p(we, "writeNode");
function Sd(e, t) {
  var r = [], i = [], n, a;
  for (aa(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
p(Sd, "getDuplicateReferences");
function aa(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        aa(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        aa(e[i[n]], t, r);
}
p(aa, "inspectNode");
function uC(e, t) {
  t = t || {};
  var r = new ud(t);
  r.noRefs || Sd(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), we(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
p(uC, "dump$1");
function fC(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
p(fC, "renamed");
var dC = mf, pC = Y2.load;
var ui = /* @__PURE__ */ p((e, t) => {
  if (t)
    return "translate(" + -e.width / 2 + ", " + -e.height / 2 + ")";
  const r = e.x ?? 0, i = e.y ?? 0;
  return "translate(" + -(r + e.width / 2) + ", " + -(i + e.height / 2) + ")";
}, "computeLabelTransform"), Ft = {
  aggregation: 17.25,
  extension: 17.25,
  composition: 17.25,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
  //arrow_cross: 24,
}, Bc = {
  arrow_point: 9,
  arrow_cross: 12.5,
  arrow_circle: 12.5
};
function wi(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = mt(e), t = mt(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], s = n - r, o = a - i;
  return { angle: Math.atan(o / s), deltaX: s, deltaY: o };
}
p(wi, "calculateDeltaAndAngle");
var mt = /* @__PURE__ */ p((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), gC = /* @__PURE__ */ p((e) => ({
  x: /* @__PURE__ */ p(function(t, r, i) {
    let n = 0;
    const a = mt(i[0]).x < mt(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(Ft, e.arrowTypeStart)) {
      const { angle: f, deltaX: g } = wi(i[0], i[1]);
      n = Ft[e.arrowTypeStart] * Math.cos(f) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ft, e.arrowTypeEnd)) {
      const { angle: f, deltaX: g } = wi(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ft[e.arrowTypeEnd] * Math.cos(f) * (g >= 0 ? 1 : -1);
    }
    const s = Math.abs(
      mt(t).x - mt(i[i.length - 1]).x
    ), o = Math.abs(
      mt(t).y - mt(i[i.length - 1]).y
    ), l = Math.abs(mt(t).x - mt(i[0]).x), c = Math.abs(mt(t).y - mt(i[0]).y), h = Ft[e.arrowTypeStart], u = Ft[e.arrowTypeEnd], d = 1;
    if (s < u && s > 0 && o < u) {
      let f = u + d - s;
      f *= a === "right" ? -1 : 1, n -= f;
    }
    if (l < h && l > 0 && c < h) {
      let f = h + d - l;
      f *= a === "right" ? -1 : 1, n += f;
    }
    return mt(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ p(function(t, r, i) {
    let n = 0;
    const a = mt(i[0]).y < mt(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(Ft, e.arrowTypeStart)) {
      const { angle: f, deltaY: g } = wi(i[0], i[1]);
      n = Ft[e.arrowTypeStart] * Math.abs(Math.sin(f)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ft, e.arrowTypeEnd)) {
      const { angle: f, deltaY: g } = wi(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ft[e.arrowTypeEnd] * Math.abs(Math.sin(f)) * (g >= 0 ? 1 : -1);
    }
    const s = Math.abs(
      mt(t).y - mt(i[i.length - 1]).y
    ), o = Math.abs(
      mt(t).x - mt(i[i.length - 1]).x
    ), l = Math.abs(mt(t).y - mt(i[0]).y), c = Math.abs(mt(t).x - mt(i[0]).x), h = Ft[e.arrowTypeStart], u = Ft[e.arrowTypeEnd], d = 1;
    if (s < u && s > 0 && o < u) {
      let f = u + d - s;
      f *= a === "up" ? -1 : 1, n -= f;
    }
    if (l < h && l > 0 && c < h) {
      let f = h + d - l;
      f *= a === "up" ? -1 : 1, n += f;
    }
    return mt(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), xn = {}, vt = {}, Lc;
function mC() {
  return Lc || (Lc = 1, Object.defineProperty(vt, "__esModule", { value: !0 }), vt.BLANK_URL = vt.relativeFirstCharacters = vt.whitespaceEscapeCharsRegex = vt.urlSchemeRegex = vt.ctrlCharactersRegex = vt.htmlCtrlEntityRegex = vt.htmlEntitiesRegex = vt.invalidProtocolRegex = void 0, vt.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im, vt.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g, vt.htmlCtrlEntityRegex = /&(newline|tab);/gi, vt.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim, vt.urlSchemeRegex = /^.+(:|&colon;)/gim, vt.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g, vt.relativeFirstCharacters = [".", "/"], vt.BLANK_URL = "about:blank"), vt;
}
var Ac;
function yC() {
  if (Ac) return xn;
  Ac = 1, Object.defineProperty(xn, "__esModule", { value: !0 }), xn.sanitizeUrl = a;
  var e = mC();
  function t(s) {
    return e.relativeFirstCharacters.indexOf(s[0]) > -1;
  }
  function r(s) {
    var o = s.replace(e.ctrlCharactersRegex, "");
    return o.replace(e.htmlEntitiesRegex, function(l, c) {
      return String.fromCharCode(c);
    });
  }
  function i(s) {
    return URL.canParse(s);
  }
  function n(s) {
    try {
      return decodeURIComponent(s);
    } catch {
      return s;
    }
  }
  function a(s) {
    if (!s)
      return e.BLANK_URL;
    var o, l = n(s.trim());
    do
      l = r(l).replace(e.htmlCtrlEntityRegex, "").replace(e.ctrlCharactersRegex, "").replace(e.whitespaceEscapeCharsRegex, "").trim(), l = n(l), o = l.match(e.ctrlCharactersRegex) || l.match(e.htmlEntitiesRegex) || l.match(e.htmlCtrlEntityRegex) || l.match(e.whitespaceEscapeCharsRegex);
    while (o && o.length > 0);
    var c = l;
    if (!c)
      return e.BLANK_URL;
    if (t(c))
      return c;
    var h = c.trimStart(), u = h.match(e.urlSchemeRegex);
    if (!u)
      return c;
    var d = u[0].toLowerCase().trim();
    if (e.invalidProtocolRegex.test(d))
      return e.BLANK_URL;
    var f = h.replace(/\\/g, "/");
    if (d === "mailto:" || d.includes("://"))
      return f;
    if (d === "http:" || d === "https:") {
      if (!i(f))
        return e.BLANK_URL;
      var g = new URL(f);
      return g.protocol = g.protocol.toLowerCase(), g.hostname = g.hostname.toLowerCase(), g.toString();
    }
    return f;
  }
  return xn;
}
var xC = yC(), Td = typeof global == "object" && global && global.Object === Object && global, bC = typeof self == "object" && self && self.Object === Object && self, ve = Td || bC || Function("return this")(), sa = ve.Symbol, Bd = Object.prototype, CC = Bd.hasOwnProperty, _C = Bd.toString, fi = sa ? sa.toStringTag : void 0;
function wC(e) {
  var t = CC.call(e, fi), r = e[fi];
  try {
    e[fi] = void 0;
    var i = !0;
  } catch {
  }
  var n = _C.call(e);
  return i && (t ? e[fi] = r : delete e[fi]), n;
}
var kC = Object.prototype, vC = kC.toString;
function SC(e) {
  return vC.call(e);
}
var TC = "[object Null]", BC = "[object Undefined]", Mc = sa ? sa.toStringTag : void 0;
function Kr(e) {
  return e == null ? e === void 0 ? BC : TC : Mc && Mc in Object(e) ? wC(e) : SC(e);
}
function xr(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var LC = "[object AsyncFunction]", AC = "[object Function]", MC = "[object GeneratorFunction]", $C = "[object Proxy]";
function Ko(e) {
  if (!xr(e))
    return !1;
  var t = Kr(e);
  return t == AC || t == MC || t == LC || t == $C;
}
var ds = ve["__core-js_shared__"], $c = (function() {
  var e = /[^.]+$/.exec(ds && ds.keys && ds.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
})();
function EC(e) {
  return !!$c && $c in e;
}
var FC = Function.prototype, DC = FC.toString;
function br(e) {
  if (e != null) {
    try {
      return DC.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var OC = /[\\^$.*+?()[\]{}|]/g, RC = /^\[object .+?Constructor\]$/, IC = Function.prototype, PC = Object.prototype, NC = IC.toString, zC = PC.hasOwnProperty, WC = RegExp(
  "^" + NC.call(zC).replace(OC, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function qC(e) {
  if (!xr(e) || EC(e))
    return !1;
  var t = Ko(e) ? WC : RC;
  return t.test(br(e));
}
function HC(e, t) {
  return e?.[t];
}
function Cr(e, t) {
  var r = HC(e, t);
  return qC(r) ? r : void 0;
}
var qi = Cr(Object, "create");
function jC() {
  this.__data__ = qi ? qi(null) : {}, this.size = 0;
}
function YC(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var UC = "__lodash_hash_undefined__", GC = Object.prototype, XC = GC.hasOwnProperty;
function VC(e) {
  var t = this.__data__;
  if (qi) {
    var r = t[e];
    return r === UC ? void 0 : r;
  }
  return XC.call(t, e) ? t[e] : void 0;
}
var ZC = Object.prototype, KC = ZC.hasOwnProperty;
function QC(e) {
  var t = this.__data__;
  return qi ? t[e] !== void 0 : KC.call(t, e);
}
var JC = "__lodash_hash_undefined__";
function t_(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = qi && t === void 0 ? JC : t, this;
}
function gr(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
gr.prototype.clear = jC;
gr.prototype.delete = YC;
gr.prototype.get = VC;
gr.prototype.has = QC;
gr.prototype.set = t_;
function e_() {
  this.__data__ = [], this.size = 0;
}
function Ea(e, t) {
  return e === t || e !== e && t !== t;
}
function Fa(e, t) {
  for (var r = e.length; r--; )
    if (Ea(e[r][0], t))
      return r;
  return -1;
}
var r_ = Array.prototype, i_ = r_.splice;
function n_(e) {
  var t = this.__data__, r = Fa(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : i_.call(t, r, 1), --this.size, !0;
}
function a_(e) {
  var t = this.__data__, r = Fa(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function s_(e) {
  return Fa(this.__data__, e) > -1;
}
function o_(e, t) {
  var r = this.__data__, i = Fa(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function Ie(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ie.prototype.clear = e_;
Ie.prototype.delete = n_;
Ie.prototype.get = a_;
Ie.prototype.has = s_;
Ie.prototype.set = o_;
var Hi = Cr(ve, "Map");
function l_() {
  this.size = 0, this.__data__ = {
    hash: new gr(),
    map: new (Hi || Ie)(),
    string: new gr()
  };
}
function c_(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Da(e, t) {
  var r = e.__data__;
  return c_(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function h_(e) {
  var t = Da(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function u_(e) {
  return Da(this, e).get(e);
}
function f_(e) {
  return Da(this, e).has(e);
}
function d_(e, t) {
  var r = Da(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Ke(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ke.prototype.clear = l_;
Ke.prototype.delete = h_;
Ke.prototype.get = u_;
Ke.prototype.has = f_;
Ke.prototype.set = d_;
var p_ = "Expected a function";
function Ji(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(p_);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var s = e.apply(this, i);
    return r.cache = a.set(n, s) || a, s;
  };
  return r.cache = new (Ji.Cache || Ke)(), r;
}
Ji.Cache = Ke;
function g_() {
  this.__data__ = new Ie(), this.size = 0;
}
function m_(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function y_(e) {
  return this.__data__.get(e);
}
function x_(e) {
  return this.__data__.has(e);
}
var b_ = 200;
function C_(e, t) {
  var r = this.__data__;
  if (r instanceof Ie) {
    var i = r.__data__;
    if (!Hi || i.length < b_ - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Ke(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function Qr(e) {
  var t = this.__data__ = new Ie(e);
  this.size = t.size;
}
Qr.prototype.clear = g_;
Qr.prototype.delete = m_;
Qr.prototype.get = y_;
Qr.prototype.has = x_;
Qr.prototype.set = C_;
var oa = (function() {
  try {
    var e = Cr(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
})();
function Qo(e, t, r) {
  t == "__proto__" && oa ? oa(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function ro(e, t, r) {
  (r !== void 0 && !Ea(e[t], r) || r === void 0 && !(t in e)) && Qo(e, t, r);
}
function __(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), s = i(t), o = s.length; o--; ) {
      var l = s[++n];
      if (r(a[l], l, a) === !1)
        break;
    }
    return t;
  };
}
var w_ = __(), Ld = typeof exports == "object" && exports && !exports.nodeType && exports, Ec = Ld && typeof module == "object" && module && !module.nodeType && module, k_ = Ec && Ec.exports === Ld, Fc = k_ ? ve.Buffer : void 0, Dc = Fc ? Fc.allocUnsafe : void 0;
function v_(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Dc ? Dc(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Oc = ve.Uint8Array;
function S_(e) {
  var t = new e.constructor(e.byteLength);
  return new Oc(t).set(new Oc(e)), t;
}
function T_(e, t) {
  var r = t ? S_(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function B_(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var Rc = Object.create, L_ = /* @__PURE__ */ (function() {
  function e() {
  }
  return function(t) {
    if (!xr(t))
      return {};
    if (Rc)
      return Rc(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
})();
function Ad(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var Md = Ad(Object.getPrototypeOf, Object), A_ = Object.prototype;
function Oa(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || A_;
  return e === r;
}
function M_(e) {
  return typeof e.constructor == "function" && !Oa(e) ? L_(Md(e)) : {};
}
function tn(e) {
  return e != null && typeof e == "object";
}
var $_ = "[object Arguments]";
function Ic(e) {
  return tn(e) && Kr(e) == $_;
}
var $d = Object.prototype, E_ = $d.hasOwnProperty, F_ = $d.propertyIsEnumerable, la = Ic(/* @__PURE__ */ (function() {
  return arguments;
})()) ? Ic : function(e) {
  return tn(e) && E_.call(e, "callee") && !F_.call(e, "callee");
}, ca = Array.isArray, D_ = 9007199254740991;
function Ed(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= D_;
}
function Ra(e) {
  return e != null && Ed(e.length) && !Ko(e);
}
function O_(e) {
  return tn(e) && Ra(e);
}
function R_() {
  return !1;
}
var Fd = typeof exports == "object" && exports && !exports.nodeType && exports, Pc = Fd && typeof module == "object" && module && !module.nodeType && module, I_ = Pc && Pc.exports === Fd, Nc = I_ ? ve.Buffer : void 0, P_ = Nc ? Nc.isBuffer : void 0, Jo = P_ || R_, N_ = "[object Object]", z_ = Function.prototype, W_ = Object.prototype, Dd = z_.toString, q_ = W_.hasOwnProperty, H_ = Dd.call(Object);
function j_(e) {
  if (!tn(e) || Kr(e) != N_)
    return !1;
  var t = Md(e);
  if (t === null)
    return !0;
  var r = q_.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && Dd.call(r) == H_;
}
var Y_ = "[object Arguments]", U_ = "[object Array]", G_ = "[object Boolean]", X_ = "[object Date]", V_ = "[object Error]", Z_ = "[object Function]", K_ = "[object Map]", Q_ = "[object Number]", J_ = "[object Object]", tw = "[object RegExp]", ew = "[object Set]", rw = "[object String]", iw = "[object WeakMap]", nw = "[object ArrayBuffer]", aw = "[object DataView]", sw = "[object Float32Array]", ow = "[object Float64Array]", lw = "[object Int8Array]", cw = "[object Int16Array]", hw = "[object Int32Array]", uw = "[object Uint8Array]", fw = "[object Uint8ClampedArray]", dw = "[object Uint16Array]", pw = "[object Uint32Array]", pt = {};
pt[sw] = pt[ow] = pt[lw] = pt[cw] = pt[hw] = pt[uw] = pt[fw] = pt[dw] = pt[pw] = !0;
pt[Y_] = pt[U_] = pt[nw] = pt[G_] = pt[aw] = pt[X_] = pt[V_] = pt[Z_] = pt[K_] = pt[Q_] = pt[J_] = pt[tw] = pt[ew] = pt[rw] = pt[iw] = !1;
function gw(e) {
  return tn(e) && Ed(e.length) && !!pt[Kr(e)];
}
function mw(e) {
  return function(t) {
    return e(t);
  };
}
var Od = typeof exports == "object" && exports && !exports.nodeType && exports, $i = Od && typeof module == "object" && module && !module.nodeType && module, yw = $i && $i.exports === Od, ps = yw && Td.process, zc = (function() {
  try {
    var e = $i && $i.require && $i.require("util").types;
    return e || ps && ps.binding && ps.binding("util");
  } catch {
  }
})(), Wc = zc && zc.isTypedArray, tl = Wc ? mw(Wc) : gw;
function io(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var xw = Object.prototype, bw = xw.hasOwnProperty;
function Cw(e, t, r) {
  var i = e[t];
  (!(bw.call(e, t) && Ea(i, r)) || r === void 0 && !(t in e)) && Qo(e, t, r);
}
function _w(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, s = t.length; ++a < s; ) {
    var o = t[a], l = void 0;
    l === void 0 && (l = e[o]), n ? Qo(r, o, l) : Cw(r, o, l);
  }
  return r;
}
function ww(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var kw = 9007199254740991, vw = /^(?:0|[1-9]\d*)$/;
function Rd(e, t) {
  var r = typeof e;
  return t = t ?? kw, !!t && (r == "number" || r != "symbol" && vw.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var Sw = Object.prototype, Tw = Sw.hasOwnProperty;
function Bw(e, t) {
  var r = ca(e), i = !r && la(e), n = !r && !i && Jo(e), a = !r && !i && !n && tl(e), s = r || i || n || a, o = s ? ww(e.length, String) : [], l = o.length;
  for (var c in e)
    (t || Tw.call(e, c)) && !(s && // Safari 9 has enumerable `arguments.length` in strict mode.
    (c == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (c == "offset" || c == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (c == "buffer" || c == "byteLength" || c == "byteOffset") || // Skip index properties.
    Rd(c, l))) && o.push(c);
  return o;
}
function Lw(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var Aw = Object.prototype, Mw = Aw.hasOwnProperty;
function $w(e) {
  if (!xr(e))
    return Lw(e);
  var t = Oa(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !Mw.call(e, i)) || r.push(i);
  return r;
}
function Id(e) {
  return Ra(e) ? Bw(e, !0) : $w(e);
}
function Ew(e) {
  return _w(e, Id(e));
}
function Fw(e, t, r, i, n, a, s) {
  var o = io(e, r), l = io(t, r), c = s.get(l);
  if (c) {
    ro(e, r, c);
    return;
  }
  var h = a ? a(o, l, r + "", e, t, s) : void 0, u = h === void 0;
  if (u) {
    var d = ca(l), f = !d && Jo(l), g = !d && !f && tl(l);
    h = l, d || f || g ? ca(o) ? h = o : O_(o) ? h = B_(o) : f ? (u = !1, h = v_(l, !0)) : g ? (u = !1, h = T_(l, !0)) : h = [] : j_(l) || la(l) ? (h = o, la(o) ? h = Ew(o) : (!xr(o) || Ko(o)) && (h = M_(l))) : u = !1;
  }
  u && (s.set(l, h), n(h, l, i, a, s), s.delete(l)), ro(e, r, h);
}
function Pd(e, t, r, i, n) {
  e !== t && w_(t, function(a, s) {
    if (n || (n = new Qr()), xr(a))
      Fw(e, t, s, r, Pd, i, n);
    else {
      var o = i ? i(io(e, s), a, s + "", e, t, n) : void 0;
      o === void 0 && (o = a), ro(e, s, o);
    }
  }, Id);
}
function Nd(e) {
  return e;
}
function Dw(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var qc = Math.max;
function Ow(e, t, r) {
  return t = qc(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = qc(i.length - t, 0), s = Array(a); ++n < a; )
      s[n] = i[t + n];
    n = -1;
    for (var o = Array(t + 1); ++n < t; )
      o[n] = i[n];
    return o[t] = r(s), Dw(e, this, o);
  };
}
function Rw(e) {
  return function() {
    return e;
  };
}
var Iw = oa ? function(e, t) {
  return oa(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: Rw(t),
    writable: !0
  });
} : Nd, Pw = 800, Nw = 16, zw = Date.now;
function Ww(e) {
  var t = 0, r = 0;
  return function() {
    var i = zw(), n = Nw - (i - r);
    if (r = i, n > 0) {
      if (++t >= Pw)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var qw = Ww(Iw);
function Hw(e, t) {
  return qw(Ow(e, t, Nd), e + "");
}
function jw(e, t, r) {
  if (!xr(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? Ra(r) && Rd(t, r.length) : i == "string" && t in r) ? Ea(r[t], e) : !1;
}
function Yw(e) {
  return Hw(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, s = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, s && jw(r[0], r[1], s) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var o = r[i];
      o && e(t, o, i, a);
    }
    return t;
  });
}
var Uw = Yw(function(e, t, r) {
  Pd(e, t, r);
}), Gw = "​", Xw = {
  curveBasis: zs,
  curveBasisClosed: J1,
  curveBasisOpen: t2,
  curveBumpX: vu,
  curveBumpY: Su,
  curveBundle: e2,
  curveCardinalClosed: r2,
  curveCardinalOpen: i2,
  curveCardinal: Au,
  curveCatmullRomClosed: n2,
  curveCatmullRomOpen: a2,
  curveCatmullRom: $u,
  curveLinear: Mi,
  curveLinearClosed: s2,
  curveMonotoneX: Iu,
  curveMonotoneY: Pu,
  curveNatural: zu,
  curveStep: Wu,
  curveStepAfter: Hu,
  curveStepBefore: qu
}, Vw = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, Zw = /* @__PURE__ */ p(function(e, t) {
  const r = zd(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const s = r.map((o) => o.args);
    zn(s), i = St(i, [...s]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = So(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), zd = /* @__PURE__ */ p(function(e, t = null) {
  try {
    const r = new RegExp(
      `[%]{2}(?![{]${Vw.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(r, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let i;
    const n = [];
    for (; (i = Li.exec(e)) !== null; )
      if (i.index === Li.lastIndex && Li.lastIndex++, i && !t || t && i[1]?.match(t) || t && i[2]?.match(t)) {
        const a = i[1] ? i[1] : i[2], s = i[3] ? i[3].trim() : i[4] ? JSON.parse(i[4].trim()) : null;
        n.push({ type: a, args: s });
      }
    return n.length === 0 ? { type: e, args: null } : n.length === 1 ? n[0] : n;
  } catch (r) {
    return F.error(
      `ERROR: ${r.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), Kw = /* @__PURE__ */ p(function(e) {
  return e.replace(Li, "");
}, "removeDirectives"), Qw = /* @__PURE__ */ p(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function el(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return Xw[r] ?? t;
}
p(el, "interpolateToCurve");
function Wd(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? xC.sanitizeUrl(r) : r;
}
p(Wd, "formatUrl");
var Jw = /* @__PURE__ */ p((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let s = 0; s < i; s++)
    if (a = a[r[s]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function rl(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
p(rl, "distance");
function qd(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += rl(n, t), t = n;
  });
  const i = r / 2;
  return il(e, i);
}
p(qd, "traverseEdge");
function Hd(e) {
  return e.length === 1 ? e[0] : qd(e);
}
p(Hd, "calcLabelPosition");
var Hc = /* @__PURE__ */ p((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), il = /* @__PURE__ */ p((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = rl(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const s = i / a;
        if (s <= 0)
          return r;
        if (s >= 1)
          return { x: n.x, y: n.y };
        if (s > 0 && s < 1)
          return {
            x: Hc((1 - s) * r.x + s * n.x, 5),
            y: Hc((1 - s) * r.y + s * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), tk = /* @__PURE__ */ p((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = il(t, 25), a = e ? 10 : 5, s = Math.atan2(t[0].y - n.y, t[0].x - n.x), o = { x: 0, y: 0 };
  return o.x = Math.sin(s) * a + (t[0].x + n.x) / 2, o.y = -Math.cos(s) * a + (t[0].y + n.y) / 2, o;
}, "calcCardinalityPosition");
function jd(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = il(i, n), s = 10 + e * 0.5, o = Math.atan2(i[0].y - a.y, i[0].x - a.x), l = { x: 0, y: 0 };
  return t === "start_left" ? (l.x = Math.sin(o + Math.PI) * s + (i[0].x + a.x) / 2, l.y = -Math.cos(o + Math.PI) * s + (i[0].y + a.y) / 2) : t === "end_right" ? (l.x = Math.sin(o - Math.PI) * s + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(o - Math.PI) * s + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (l.x = Math.sin(o) * s + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(o) * s + (i[0].y + a.y) / 2 - 5) : (l.x = Math.sin(o) * s + (i[0].x + a.x) / 2, l.y = -Math.cos(o) * s + (i[0].y + a.y) / 2), l;
}
p(jd, "calcTerminalLabelPosition");
function Yd(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
p(Yd, "getStylesFromArray");
var jc = 0, ek = /* @__PURE__ */ p(() => (jc++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + jc), "generateId");
function Ud(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
p(Ud, "makeRandomHex");
var rk = /* @__PURE__ */ p((e) => Ud(e.length), "random"), ik = /* @__PURE__ */ p(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), nk = /* @__PURE__ */ p(function(e, t) {
  const r = t.text.replace(Vi.lineBreakRegex, " "), [, i] = Ia(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), ak = Ji(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), Vi.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((s, o) => {
      const l = Oe(`${s} `, r), c = Oe(a, r);
      if (l > t) {
        const { hyphenatedStrings: d, remainingWord: f } = sk(s, t, "-", r);
        n.push(a, ...d), a = f;
      } else c + l >= t ? (n.push(a), a = s) : a = [a, s].filter(Boolean).join(" ");
      o + 1 === i.length && n.push(a);
    }), n.filter((s) => s !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), sk = Ji(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let s = "";
    return n.forEach((o, l) => {
      const c = `${s}${o}`;
      if (Oe(c, i) >= t) {
        const u = l + 1, d = n.length === u, f = `${c}${r}`;
        a.push(d ? c : f), s = "";
      } else
        s = c;
    }), { hyphenatedStrings: a, remainingWord: s };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function Gd(e, t) {
  return nl(e, t).height;
}
p(Gd, "calculateTextHeight");
function Oe(e, t) {
  return nl(e, t).width;
}
p(Oe, "calculateTextWidth");
var nl = Ji(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Ia(r), s = ["sans-serif", i], o = e.split(Vi.lineBreakRegex), l = [], c = lt("body");
    if (!c.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = c.append("svg");
    for (const d of s) {
      let f = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of o) {
        const y = ik();
        y.text = m || Gw;
        const x = nk(h, y).style("font-size", a).style("font-weight", n).style("font-family", d), b = (x._groups || x)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), f = Math.round(b.height), g.height += f, g.lineHeight = Math.round(Math.max(g.lineHeight, f));
      }
      l.push(g);
    }
    h.remove();
    const u = isNaN(l[1].height) || isNaN(l[1].width) || isNaN(l[1].lineHeight) || l[0].height > l[1].height && l[0].width > l[1].width && l[0].lineHeight > l[1].lineHeight ? 0 : 1;
    return l[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), qr, ok = (qr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, p(qr, "InitIDGenerator"), qr), bn, lk = /* @__PURE__ */ p(function(e) {
  return bn = bn || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), bn.innerHTML = e, unescape(bn.textContent);
}, "entityDecode");
function al(e) {
  return "str" in e;
}
p(al, "isDetailedError");
var ck = /* @__PURE__ */ p((e, t, r, i) => {
  if (!i)
    return;
  const n = e.node()?.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Ia = /* @__PURE__ */ p((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function sl(e, t) {
  return Uw({}, e, t);
}
p(sl, "cleanAndMerge");
var ce = {
  assignWithDepth: St,
  wrapLabel: ak,
  calculateTextHeight: Gd,
  calculateTextWidth: Oe,
  calculateTextDimensions: nl,
  cleanAndMerge: sl,
  detectInit: Zw,
  detectDirective: zd,
  isSubstringInArray: Qw,
  interpolateToCurve: el,
  calcLabelPosition: Hd,
  calcCardinalityPosition: tk,
  calcTerminalLabelPosition: jd,
  formatUrl: Wd,
  getStylesFromArray: Yd,
  generateId: ek,
  random: rk,
  runFunc: Jw,
  entityDecode: lk,
  insertTitle: ck,
  isLabelCoordinateInPath: Xd,
  parseFontSize: Ia,
  InitIDGenerator: ok
}, hk = /* @__PURE__ */ p(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), Jr = /* @__PURE__ */ p(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), _A = /* @__PURE__ */ p((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function Rt(e) {
  return e ?? null;
}
p(Rt, "handleUndefinedAttr");
function Xd(e, t) {
  const r = Math.round(e.x), i = Math.round(e.y), n = t.replace(
    /(\d+\.\d+)/g,
    (a) => Math.round(parseFloat(a)).toString()
  );
  return n.includes(r.toString()) || n.includes(i.toString());
}
p(Xd, "isLabelCoordinateInPath");
var ol = /* @__PURE__ */ p(({
  flowchart: e
}) => {
  const t = e?.subGraphTitleMargin?.top ?? 0, r = e?.subGraphTitleMargin?.bottom ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins");
async function Vd(e, t) {
  const r = e.getElementsByTagName("img");
  if (!r || r.length === 0)
    return;
  const i = t.replace(/<img[^>]*>/g, "").trim() === "";
  await Promise.all(
    [...r].map(
      (n) => new Promise((a) => {
        function s() {
          if (n.style.display = "flex", n.style.flexDirection = "column", i) {
            const o = ft().fontSize ? ft().fontSize : window.getComputedStyle(document.body).fontSize, l = 5, [c = Ih.fontSize] = Ia(o), h = c * l + "px";
            n.style.minWidth = h, n.style.maxWidth = h;
          } else
            n.style.width = "100%";
          a(n);
        }
        p(s, "setupImage"), setTimeout(() => {
          n.complete && s();
        }), n.addEventListener("error", s), n.addEventListener("load", s);
      })
    )
  );
}
p(Vd, "configureLabelImages");
var uk = /* @__PURE__ */ p((e) => {
  const { handDrawnSeed: t } = ft();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), ti = /* @__PURE__ */ p((e) => {
  const t = fk([
    ...e.cssCompiledStyles || [],
    ...e.cssStyles || [],
    ...e.labelStyle || []
  ]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), fk = /* @__PURE__ */ p((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n?.trim());
  }), t;
}, "styles2Map"), Zd = /* @__PURE__ */ p((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), G = /* @__PURE__ */ p((e) => {
  const { stylesArray: t } = ti(e), r = [], i = [], n = [], a = [];
  return t.forEach((s) => {
    const o = s[0];
    Zd(o) ? r.push(s.join(":") + " !important") : (i.push(s.join(":") + " !important"), o.includes("stroke") && n.push(s.join(":") + " !important"), o === "fill" && a.push(s.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), U = /* @__PURE__ */ p((e, t) => {
  const { themeVariables: r, handDrawnSeed: i } = ft(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: s } = ti(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: s.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: s.get("stroke") || n,
      seed: i,
      strokeWidth: s.get("stroke-width")?.replace("px", "") || 1.3,
      fillLineDash: [0, 0],
      strokeLineDash: dk(s.get("stroke-dasharray"))
    },
    t
  );
}, "userNodeOverrides"), dk = /* @__PURE__ */ p((e) => {
  if (!e)
    return [0, 0];
  const t = e.trim().split(/\s+/).map(Number);
  if (t.length === 1) {
    const n = isNaN(t[0]) ? 0 : t[0];
    return [n, n];
  }
  const r = isNaN(t[0]) ? 0 : t[0], i = isNaN(t[1]) ? 0 : t[1];
  return [r, i];
}, "getStrokeDashArray");
const pk = Object.freeze({
  left: 0,
  top: 0,
  width: 16,
  height: 16
}), ha = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), Kd = Object.freeze({
  ...pk,
  ...ha
}), gk = Object.freeze({
  ...Kd,
  body: "",
  hidden: !1
}), mk = Object.freeze({
  width: null,
  height: null
}), yk = Object.freeze({
  ...mk,
  ...ha
}), xk = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3) return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length) return null;
  if (n.length > 1) {
    const o = n.pop(), l = n.pop(), c = {
      provider: n.length > 0 ? n[0] : i,
      prefix: l,
      name: o
    };
    return gs(c) ? c : null;
  }
  const a = n[0], s = a.split("-");
  if (s.length > 1) {
    const o = {
      provider: i,
      prefix: s.shift(),
      name: s.join("-")
    };
    return gs(o) ? o : null;
  }
  if (r && i === "") {
    const o = {
      provider: i,
      prefix: "",
      name: a
    };
    return gs(o, r) ? o : null;
  }
  return null;
}, gs = (e, t) => e ? !!((t && e.prefix === "" || e.prefix) && e.name) : !1;
function bk(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function Yc(e, t) {
  const r = bk(e, t);
  for (const i in gk) i in ha ? i in e && !(i in r) && (r[i] = ha[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function Ck(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(s) {
    if (r[s]) return n[s] = [];
    if (!(s in n)) {
      n[s] = null;
      const o = i[s] && i[s].parent, l = o && a(o);
      l && (n[s] = [o].concat(l));
    }
    return n[s];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function Uc(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function s(o) {
    a = Yc(i[o] || n[o], a);
  }
  return s(t), r.forEach(s), Yc(e, a);
}
function _k(e, t) {
  if (e.icons[t]) return Uc(e, t, []);
  const r = Ck(e, [t])[t];
  return r ? Uc(e, t, r) : null;
}
const wk = /(-?[0-9.]*[0-9]+[0-9.]*)/g, kk = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function Gc(e, t, r) {
  if (t === 1) return e;
  if (r = r || 100, typeof e == "number") return Math.ceil(e * t * r) / r;
  if (typeof e != "string") return e;
  const i = e.split(wk);
  if (i === null || !i.length) return e;
  const n = [];
  let a = i.shift(), s = kk.test(a);
  for (; ; ) {
    if (s) {
      const o = parseFloat(a);
      isNaN(o) ? n.push(a) : n.push(Math.ceil(o * t * r) / r);
    } else n.push(a);
    if (a = i.shift(), a === void 0) return n.join("");
    s = !s;
  }
}
function vk(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1) break;
    const s = e.indexOf(">", a);
    if (s === -1) break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(s + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function Sk(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function Tk(e, t, r) {
  const i = vk(e);
  return Sk(i.defs, t + i.content + r);
}
const Bk = (e) => e === "unset" || e === "undefined" || e === "none";
function Lk(e, t) {
  const r = {
    ...Kd,
    ...e
  }, i = {
    ...yk,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const y = [], x = m.hFlip, b = m.vFlip;
    let _ = m.rotate;
    x ? b ? _ += 2 : (y.push("translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"), y.push("scale(-1 1)"), n.top = n.left = 0) : b && (y.push("translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"), y.push("scale(1 -1)"), n.top = n.left = 0);
    let v;
    switch (_ < 0 && (_ -= Math.floor(_ / 4) * 4), _ = _ % 4, _) {
      case 1:
        v = n.height / 2 + n.top, y.unshift("rotate(90 " + v.toString() + " " + v.toString() + ")");
        break;
      case 2:
        y.unshift("rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")");
        break;
      case 3:
        v = n.width / 2 + n.left, y.unshift("rotate(-90 " + v.toString() + " " + v.toString() + ")");
        break;
    }
    _ % 2 === 1 && (n.left !== n.top && (v = n.left, n.left = n.top, n.top = v), n.width !== n.height && (v = n.width, n.width = n.height, n.height = v)), y.length && (a = Tk(a, '<g transform="' + y.join(" ") + '">', "</g>"));
  });
  const s = i.width, o = i.height, l = n.width, c = n.height;
  let h, u;
  s === null ? (u = o === null ? "1em" : o === "auto" ? c : o, h = Gc(u, l / c)) : (h = s === "auto" ? l : s, u = o === null ? Gc(h, c / l) : o === "auto" ? c : o);
  const d = {}, f = (m, y) => {
    Bk(y) || (d[m] = y.toString());
  };
  f("width", h), f("height", u);
  const g = [
    n.left,
    n.top,
    l,
    c
  ];
  return d.viewBox = g.join(" "), {
    attributes: d,
    viewBox: g,
    body: a
  };
}
const Ak = /\sid="(\S+)"/g, Xc = /* @__PURE__ */ new Map();
function Mk(e) {
  e = e.replace(/[0-9]+$/, "") || "a";
  const t = Xc.get(e) || 0;
  return Xc.set(e, t + 1), t ? `${e}${t}` : e;
}
function $k(e) {
  const t = [];
  let r;
  for (; r = Ak.exec(e); ) t.push(r[1]);
  if (!t.length) return e;
  const i = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return t.forEach((n) => {
    const a = Mk(n), s = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + a + i + "$3");
  }), e = e.replace(new RegExp(i, "g"), ""), e;
}
function Ek(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t) r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function ll() {
  return { async: !1, breaks: !1, extensions: null, gfm: !0, hooks: null, pedantic: !1, renderer: null, silent: !1, tokenizer: null, walkTokens: null };
}
var _r = ll();
function Qd(e) {
  _r = e;
}
var Ei = { exec: () => null };
function ut(e, t = "") {
  let r = typeof e == "string" ? e : e.source, i = { replace: (n, a) => {
    let s = typeof a == "string" ? a : a.source;
    return s = s.replace(qt.caret, "$1"), r = r.replace(n, s), i;
  }, getRegex: () => new RegExp(r, t) };
  return i;
}
var Fk = (() => {
  try {
    return !!new RegExp("(?<=1)(?<!1)");
  } catch {
    return !1;
  }
})(), qt = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceTabs: /^\t+/, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] /, listReplaceTask: /^\[[ xX]\] +/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`), htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i") }, Dk = /^(?:[ \t]*(?:\n|$))+/, Ok = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, Rk = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, en = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Ik = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, cl = /(?:[*+-]|\d{1,9}[.)])/, Jd = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, tp = ut(Jd).replace(/bull/g, cl).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Pk = ut(Jd).replace(/bull/g, cl).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), hl = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Nk = /^[^\n]+/, ul = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, zk = ut(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", ul).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Wk = ut(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, cl).getRegex(), Pa = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", fl = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, qk = ut("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", fl).replace("tag", Pa).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ep = ut(hl).replace("hr", en).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Pa).getRegex(), Hk = ut(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ep).getRegex(), dl = { blockquote: Hk, code: Ok, def: zk, fences: Rk, heading: Ik, hr: en, html: qk, lheading: tp, list: Wk, newline: Dk, paragraph: ep, table: Ei, text: Nk }, Vc = ut("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", en).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Pa).getRegex(), jk = { ...dl, lheading: Pk, table: Vc, paragraph: ut(hl).replace("hr", en).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Vc).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Pa).getRegex() }, Yk = { ...dl, html: ut(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", fl).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: Ei, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: ut(hl).replace("hr", en).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", tp).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() }, Uk = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Gk = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, rp = /^( {2,}|\\)\n(?!\s*$)/, Xk = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Na = /[\p{P}\p{S}]/u, pl = /[\s\p{P}\p{S}]/u, ip = /[^\s\p{P}\p{S}]/u, Vk = ut(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, pl).getRegex(), np = /(?!~)[\p{P}\p{S}]/u, Zk = /(?!~)[\s\p{P}\p{S}]/u, Kk = /(?:[^\s\p{P}\p{S}]|~)/u, Qk = ut(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", Fk ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex(), ap = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Jk = ut(ap, "u").replace(/punct/g, Na).getRegex(), tv = ut(ap, "u").replace(/punct/g, np).getRegex(), sp = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", ev = ut(sp, "gu").replace(/notPunctSpace/g, ip).replace(/punctSpace/g, pl).replace(/punct/g, Na).getRegex(), rv = ut(sp, "gu").replace(/notPunctSpace/g, Kk).replace(/punctSpace/g, Zk).replace(/punct/g, np).getRegex(), iv = ut("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, ip).replace(/punctSpace/g, pl).replace(/punct/g, Na).getRegex(), nv = ut(/\\(punct)/, "gu").replace(/punct/g, Na).getRegex(), av = ut(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), sv = ut(fl).replace("(?:-->|$)", "-->").getRegex(), ov = ut("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", sv).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), ua = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+[^`]*?`+(?!`)|[^\[\]\\`])*?/, lv = ut(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", ua).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), op = ut(/^!?\[(label)\]\[(ref)\]/).replace("label", ua).replace("ref", ul).getRegex(), lp = ut(/^!?\[(ref)\](?:\[\])?/).replace("ref", ul).getRegex(), cv = ut("reflink|nolink(?!\\()", "g").replace("reflink", op).replace("nolink", lp).getRegex(), Zc = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, gl = { _backpedal: Ei, anyPunctuation: nv, autolink: av, blockSkip: Qk, br: rp, code: Gk, del: Ei, emStrongLDelim: Jk, emStrongRDelimAst: ev, emStrongRDelimUnd: iv, escape: Uk, link: lv, nolink: lp, punctuation: Vk, reflink: op, reflinkSearch: cv, tag: ov, text: Xk, url: Ei }, hv = { ...gl, link: ut(/^!?\[(label)\]\((.*?)\)/).replace("label", ua).getRegex(), reflink: ut(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", ua).getRegex() }, no = { ...gl, emStrongRDelimAst: rv, emStrongLDelim: tv, url: ut(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", Zc).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: ut(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", Zc).getRegex() }, uv = { ...no, br: ut(rp).replace("{2,}", "*").getRegex(), text: ut(no.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() }, Cn = { normal: dl, gfm: jk, pedantic: Yk }, di = { normal: gl, gfm: no, breaks: uv, pedantic: hv }, fv = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }, Kc = (e) => fv[e];
function ye(e, t) {
  if (t) {
    if (qt.escapeTest.test(e)) return e.replace(qt.escapeReplace, Kc);
  } else if (qt.escapeTestNoEncode.test(e)) return e.replace(qt.escapeReplaceNoEncode, Kc);
  return e;
}
function Qc(e) {
  try {
    e = encodeURI(e).replace(qt.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function Jc(e, t) {
  let r = e.replace(qt.findPipe, (a, s, o) => {
    let l = !1, c = s;
    for (; --c >= 0 && o[c] === "\\"; ) l = !l;
    return l ? "|" : " |";
  }), i = r.split(qt.splitPipe), n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i.at(-1)?.trim() && i.pop(), t) if (i.length > t) i.splice(t);
  else for (; i.length < t; ) i.push("");
  for (; n < i.length; n++) i[n] = i[n].trim().replace(qt.slashPipe, "|");
  return i;
}
function pi(e, t, r) {
  let i = e.length;
  if (i === 0) return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function dv(e, t) {
  if (e.indexOf(t[1]) === -1) return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++) if (e[i] === "\\") i++;
  else if (e[i] === t[0]) r++;
  else if (e[i] === t[1] && (r--, r < 0)) return i;
  return r > 0 ? -2 : -1;
}
function th(e, t, r, i, n) {
  let a = t.href, s = t.title || null, o = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  let l = { type: e[0].charAt(0) === "!" ? "image" : "link", raw: r, href: a, title: s, text: o, tokens: i.inlineTokens(o) };
  return i.state.inLink = !1, l;
}
function pv(e, t, r) {
  let i = e.match(r.other.indentCodeCompensation);
  if (i === null) return t;
  let n = i[1];
  return t.split(`
`).map((a) => {
    let s = a.match(r.other.beginningSpace);
    if (s === null) return a;
    let [o] = s;
    return o.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var fa = class {
  options;
  rules;
  lexer;
  constructor(t) {
    this.options = t || _r;
  }
  space(t) {
    let r = this.rules.block.newline.exec(t);
    if (r && r[0].length > 0) return { type: "space", raw: r[0] };
  }
  code(t) {
    let r = this.rules.block.code.exec(t);
    if (r) {
      let i = r[0].replace(this.rules.other.codeRemoveIndent, "");
      return { type: "code", raw: r[0], codeBlockStyle: "indented", text: this.options.pedantic ? i : pi(i, `
`) };
    }
  }
  fences(t) {
    let r = this.rules.block.fences.exec(t);
    if (r) {
      let i = r[0], n = pv(i, r[3] || "", this.rules);
      return { type: "code", raw: i, lang: r[2] ? r[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : r[2], text: n };
    }
  }
  heading(t) {
    let r = this.rules.block.heading.exec(t);
    if (r) {
      let i = r[2].trim();
      if (this.rules.other.endingHash.test(i)) {
        let n = pi(i, "#");
        (this.options.pedantic || !n || this.rules.other.endingSpaceChar.test(n)) && (i = n.trim());
      }
      return { type: "heading", raw: r[0], depth: r[1].length, text: i, tokens: this.lexer.inline(i) };
    }
  }
  hr(t) {
    let r = this.rules.block.hr.exec(t);
    if (r) return { type: "hr", raw: pi(r[0], `
`) };
  }
  blockquote(t) {
    let r = this.rules.block.blockquote.exec(t);
    if (r) {
      let i = pi(r[0], `
`).split(`
`), n = "", a = "", s = [];
      for (; i.length > 0; ) {
        let o = !1, l = [], c;
        for (c = 0; c < i.length; c++) if (this.rules.other.blockquoteStart.test(i[c])) l.push(i[c]), o = !0;
        else if (!o) l.push(i[c]);
        else break;
        i = i.slice(c);
        let h = l.join(`
`), u = h.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        n = n ? `${n}
${h}` : h, a = a ? `${a}
${u}` : u;
        let d = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(u, s, !0), this.lexer.state.top = d, i.length === 0) break;
        let f = s.at(-1);
        if (f?.type === "code") break;
        if (f?.type === "blockquote") {
          let g = f, m = g.raw + `
` + i.join(`
`), y = this.blockquote(m);
          s[s.length - 1] = y, n = n.substring(0, n.length - g.raw.length) + y.raw, a = a.substring(0, a.length - g.text.length) + y.text;
          break;
        } else if (f?.type === "list") {
          let g = f, m = g.raw + `
` + i.join(`
`), y = this.list(m);
          s[s.length - 1] = y, n = n.substring(0, n.length - f.raw.length) + y.raw, a = a.substring(0, a.length - g.raw.length) + y.raw, i = m.substring(s.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return { type: "blockquote", raw: n, tokens: s, text: a };
    }
  }
  list(t) {
    let r = this.rules.block.list.exec(t);
    if (r) {
      let i = r[1].trim(), n = i.length > 1, a = { type: "list", raw: "", ordered: n, start: n ? +i.slice(0, -1) : "", loose: !1, items: [] };
      i = n ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = n ? i : "[*+-]");
      let s = this.rules.other.listItemRegex(i), o = !1;
      for (; t; ) {
        let c = !1, h = "", u = "";
        if (!(r = s.exec(t)) || this.rules.block.hr.test(t)) break;
        h = r[0], t = t.substring(h.length);
        let d = r[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (b) => " ".repeat(3 * b.length)), f = t.split(`
`, 1)[0], g = !d.trim(), m = 0;
        if (this.options.pedantic ? (m = 2, u = d.trimStart()) : g ? m = r[1].length + 1 : (m = r[2].search(this.rules.other.nonSpaceChar), m = m > 4 ? 1 : m, u = d.slice(m), m += r[1].length), g && this.rules.other.blankLine.test(f) && (h += f + `
`, t = t.substring(f.length + 1), c = !0), !c) {
          let b = this.rules.other.nextBulletRegex(m), _ = this.rules.other.hrRegex(m), v = this.rules.other.fencesBeginRegex(m), k = this.rules.other.headingBeginRegex(m), T = this.rules.other.htmlBeginRegex(m);
          for (; t; ) {
            let B = t.split(`
`, 1)[0], D;
            if (f = B, this.options.pedantic ? (f = f.replace(this.rules.other.listReplaceNesting, "  "), D = f) : D = f.replace(this.rules.other.tabCharGlobal, "    "), v.test(f) || k.test(f) || T.test(f) || b.test(f) || _.test(f)) break;
            if (D.search(this.rules.other.nonSpaceChar) >= m || !f.trim()) u += `
` + D.slice(m);
            else {
              if (g || d.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || v.test(d) || k.test(d) || _.test(d)) break;
              u += `
` + f;
            }
            !g && !f.trim() && (g = !0), h += B + `
`, t = t.substring(B.length + 1), d = D.slice(m);
          }
        }
        a.loose || (o ? a.loose = !0 : this.rules.other.doubleBlankLine.test(h) && (o = !0));
        let y = null, x;
        this.options.gfm && (y = this.rules.other.listIsTask.exec(u), y && (x = y[0] !== "[ ] ", u = u.replace(this.rules.other.listReplaceTask, ""))), a.items.push({ type: "list_item", raw: h, task: !!y, checked: x, loose: !1, text: u, tokens: [] }), a.raw += h;
      }
      let l = a.items.at(-1);
      if (l) l.raw = l.raw.trimEnd(), l.text = l.text.trimEnd();
      else return;
      a.raw = a.raw.trimEnd();
      for (let c = 0; c < a.items.length; c++) if (this.lexer.state.top = !1, a.items[c].tokens = this.lexer.blockTokens(a.items[c].text, []), !a.loose) {
        let h = a.items[c].tokens.filter((d) => d.type === "space"), u = h.length > 0 && h.some((d) => this.rules.other.anyLine.test(d.raw));
        a.loose = u;
      }
      if (a.loose) for (let c = 0; c < a.items.length; c++) a.items[c].loose = !0;
      return a;
    }
  }
  html(t) {
    let r = this.rules.block.html.exec(t);
    if (r) return { type: "html", block: !0, raw: r[0], pre: r[1] === "pre" || r[1] === "script" || r[1] === "style", text: r[0] };
  }
  def(t) {
    let r = this.rules.block.def.exec(t);
    if (r) {
      let i = r[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), n = r[2] ? r[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = r[3] ? r[3].substring(1, r[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : r[3];
      return { type: "def", tag: i, raw: r[0], href: n, title: a };
    }
  }
  table(t) {
    let r = this.rules.block.table.exec(t);
    if (!r || !this.rules.other.tableDelimiter.test(r[2])) return;
    let i = Jc(r[1]), n = r[2].replace(this.rules.other.tableAlignChars, "").split("|"), a = r[3]?.trim() ? r[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], s = { type: "table", raw: r[0], header: [], align: [], rows: [] };
    if (i.length === n.length) {
      for (let o of n) this.rules.other.tableAlignRight.test(o) ? s.align.push("right") : this.rules.other.tableAlignCenter.test(o) ? s.align.push("center") : this.rules.other.tableAlignLeft.test(o) ? s.align.push("left") : s.align.push(null);
      for (let o = 0; o < i.length; o++) s.header.push({ text: i[o], tokens: this.lexer.inline(i[o]), header: !0, align: s.align[o] });
      for (let o of a) s.rows.push(Jc(o, s.header.length).map((l, c) => ({ text: l, tokens: this.lexer.inline(l), header: !1, align: s.align[c] })));
      return s;
    }
  }
  lheading(t) {
    let r = this.rules.block.lheading.exec(t);
    if (r) return { type: "heading", raw: r[0], depth: r[2].charAt(0) === "=" ? 1 : 2, text: r[1], tokens: this.lexer.inline(r[1]) };
  }
  paragraph(t) {
    let r = this.rules.block.paragraph.exec(t);
    if (r) {
      let i = r[1].charAt(r[1].length - 1) === `
` ? r[1].slice(0, -1) : r[1];
      return { type: "paragraph", raw: r[0], text: i, tokens: this.lexer.inline(i) };
    }
  }
  text(t) {
    let r = this.rules.block.text.exec(t);
    if (r) return { type: "text", raw: r[0], text: r[0], tokens: this.lexer.inline(r[0]) };
  }
  escape(t) {
    let r = this.rules.inline.escape.exec(t);
    if (r) return { type: "escape", raw: r[0], text: r[1] };
  }
  tag(t) {
    let r = this.rules.inline.tag.exec(t);
    if (r) return !this.lexer.state.inLink && this.rules.other.startATag.test(r[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(r[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(r[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(r[0]) && (this.lexer.state.inRawBlock = !1), { type: "html", raw: r[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: !1, text: r[0] };
  }
  link(t) {
    let r = this.rules.inline.link.exec(t);
    if (r) {
      let i = r[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(i)) {
        if (!this.rules.other.endAngleBracket.test(i)) return;
        let s = pi(i.slice(0, -1), "\\");
        if ((i.length - s.length) % 2 === 0) return;
      } else {
        let s = dv(r[2], "()");
        if (s === -2) return;
        if (s > -1) {
          let o = (r[0].indexOf("!") === 0 ? 5 : 4) + r[1].length + s;
          r[2] = r[2].substring(0, s), r[0] = r[0].substring(0, o).trim(), r[3] = "";
        }
      }
      let n = r[2], a = "";
      if (this.options.pedantic) {
        let s = this.rules.other.pedanticHrefTitle.exec(n);
        s && (n = s[1], a = s[3]);
      } else a = r[3] ? r[3].slice(1, -1) : "";
      return n = n.trim(), this.rules.other.startAngleBracket.test(n) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(i) ? n = n.slice(1) : n = n.slice(1, -1)), th(r, { href: n && n.replace(this.rules.inline.anyPunctuation, "$1"), title: a && a.replace(this.rules.inline.anyPunctuation, "$1") }, r[0], this.lexer, this.rules);
    }
  }
  reflink(t, r) {
    let i;
    if ((i = this.rules.inline.reflink.exec(t)) || (i = this.rules.inline.nolink.exec(t))) {
      let n = (i[2] || i[1]).replace(this.rules.other.multipleSpaceGlobal, " "), a = r[n.toLowerCase()];
      if (!a) {
        let s = i[0].charAt(0);
        return { type: "text", raw: s, text: s };
      }
      return th(i, a, i[0], this.lexer, this.rules);
    }
  }
  emStrong(t, r, i = "") {
    let n = this.rules.inline.emStrongLDelim.exec(t);
    if (!(!n || n[3] && i.match(this.rules.other.unicodeAlphaNumeric)) && (!(n[1] || n[2]) || !i || this.rules.inline.punctuation.exec(i))) {
      let a = [...n[0]].length - 1, s, o, l = a, c = 0, h = n[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, r = r.slice(-1 * t.length + a); (n = h.exec(r)) != null; ) {
        if (s = n[1] || n[2] || n[3] || n[4] || n[5] || n[6], !s) continue;
        if (o = [...s].length, n[3] || n[4]) {
          l += o;
          continue;
        } else if ((n[5] || n[6]) && a % 3 && !((a + o) % 3)) {
          c += o;
          continue;
        }
        if (l -= o, l > 0) continue;
        o = Math.min(o, o + l + c);
        let u = [...n[0]][0].length, d = t.slice(0, a + n.index + u + o);
        if (Math.min(a, o) % 2) {
          let g = d.slice(1, -1);
          return { type: "em", raw: d, text: g, tokens: this.lexer.inlineTokens(g) };
        }
        let f = d.slice(2, -2);
        return { type: "strong", raw: d, text: f, tokens: this.lexer.inlineTokens(f) };
      }
    }
  }
  codespan(t) {
    let r = this.rules.inline.code.exec(t);
    if (r) {
      let i = r[2].replace(this.rules.other.newLineCharGlobal, " "), n = this.rules.other.nonSpaceChar.test(i), a = this.rules.other.startingSpaceChar.test(i) && this.rules.other.endingSpaceChar.test(i);
      return n && a && (i = i.substring(1, i.length - 1)), { type: "codespan", raw: r[0], text: i };
    }
  }
  br(t) {
    let r = this.rules.inline.br.exec(t);
    if (r) return { type: "br", raw: r[0] };
  }
  del(t) {
    let r = this.rules.inline.del.exec(t);
    if (r) return { type: "del", raw: r[0], text: r[2], tokens: this.lexer.inlineTokens(r[2]) };
  }
  autolink(t) {
    let r = this.rules.inline.autolink.exec(t);
    if (r) {
      let i, n;
      return r[2] === "@" ? (i = r[1], n = "mailto:" + i) : (i = r[1], n = i), { type: "link", raw: r[0], text: i, href: n, tokens: [{ type: "text", raw: i, text: i }] };
    }
  }
  url(t) {
    let r;
    if (r = this.rules.inline.url.exec(t)) {
      let i, n;
      if (r[2] === "@") i = r[0], n = "mailto:" + i;
      else {
        let a;
        do
          a = r[0], r[0] = this.rules.inline._backpedal.exec(r[0])?.[0] ?? "";
        while (a !== r[0]);
        i = r[0], r[1] === "www." ? n = "http://" + r[0] : n = r[0];
      }
      return { type: "link", raw: r[0], text: i, href: n, tokens: [{ type: "text", raw: i, text: i }] };
    }
  }
  inlineText(t) {
    let r = this.rules.inline.text.exec(t);
    if (r) {
      let i = this.lexer.state.inRawBlock;
      return { type: "text", raw: r[0], text: r[0], escaped: i };
    }
  }
}, se = class ao {
  tokens;
  options;
  state;
  tokenizer;
  inlineQueue;
  constructor(t) {
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || _r, this.options.tokenizer = this.options.tokenizer || new fa(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: !1, inRawBlock: !1, top: !0 };
    let r = { other: qt, block: Cn.normal, inline: di.normal };
    this.options.pedantic ? (r.block = Cn.pedantic, r.inline = di.pedantic) : this.options.gfm && (r.block = Cn.gfm, this.options.breaks ? r.inline = di.breaks : r.inline = di.gfm), this.tokenizer.rules = r;
  }
  static get rules() {
    return { block: Cn, inline: di };
  }
  static lex(t, r) {
    return new ao(r).lex(t);
  }
  static lexInline(t, r) {
    return new ao(r).inlineTokens(t);
  }
  lex(t) {
    t = t.replace(qt.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      let i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    for (this.options.pedantic && (t = t.replace(qt.tabCharGlobal, "    ").replace(qt.spaceLine, "")); t; ) {
      let n;
      if (this.options.extensions?.block?.some((s) => (n = s.call({ lexer: this }, t, r)) ? (t = t.substring(n.raw.length), r.push(n), !0) : !1)) continue;
      if (n = this.tokenizer.space(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        n.raw.length === 1 && s !== void 0 ? s.raw += `
` : r.push(n);
        continue;
      }
      if (n = this.tokenizer.code(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        s?.type === "paragraph" || s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.text, this.inlineQueue.at(-1).src = s.text) : r.push(n);
        continue;
      }
      if (n = this.tokenizer.fences(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.heading(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.hr(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.blockquote(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.list(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.html(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.def(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        s?.type === "paragraph" || s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.raw, this.inlineQueue.at(-1).src = s.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = { href: n.href, title: n.title }, r.push(n));
        continue;
      }
      if (n = this.tokenizer.table(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      if (n = this.tokenizer.lheading(t)) {
        t = t.substring(n.raw.length), r.push(n);
        continue;
      }
      let a = t;
      if (this.options.extensions?.startBlock) {
        let s = 1 / 0, o = t.slice(1), l;
        this.options.extensions.startBlock.forEach((c) => {
          l = c.call({ lexer: this }, o), typeof l == "number" && l >= 0 && (s = Math.min(s, l));
        }), s < 1 / 0 && s >= 0 && (a = t.substring(0, s + 1));
      }
      if (this.state.top && (n = this.tokenizer.paragraph(a))) {
        let s = r.at(-1);
        i && s?.type === "paragraph" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = s.text) : r.push(n), i = a.length !== t.length, t = t.substring(n.raw.length);
        continue;
      }
      if (n = this.tokenizer.text(t)) {
        t = t.substring(n.raw.length);
        let s = r.at(-1);
        s?.type === "text" ? (s.raw += (s.raw.endsWith(`
`) ? "" : `
`) + n.raw, s.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = s.text) : r.push(n);
        continue;
      }
      if (t) {
        let s = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(s);
          break;
        } else throw new Error(s);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  inlineTokens(t, r = []) {
    let i = t, n = null;
    if (this.tokens.links) {
      let l = Object.keys(this.tokens.links);
      if (l.length > 0) for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; ) l.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; ) i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    let a;
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; ) a = n[2] ? n[2].length : 0, i = i.slice(0, n.index + a) + "[" + "a".repeat(n[0].length - a - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    i = this.options.hooks?.emStrongMask?.call({ lexer: this }, i) ?? i;
    let s = !1, o = "";
    for (; t; ) {
      s || (o = ""), s = !1;
      let l;
      if (this.options.extensions?.inline?.some((h) => (l = h.call({ lexer: this }, t, r)) ? (t = t.substring(l.raw.length), r.push(l), !0) : !1)) continue;
      if (l = this.tokenizer.escape(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.tag(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.link(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(l.raw.length);
        let h = r.at(-1);
        l.type === "text" && h?.type === "text" ? (h.raw += l.raw, h.text += l.text) : r.push(l);
        continue;
      }
      if (l = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.codespan(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.br(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.del(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (l = this.tokenizer.autolink(t)) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      if (!this.state.inLink && (l = this.tokenizer.url(t))) {
        t = t.substring(l.raw.length), r.push(l);
        continue;
      }
      let c = t;
      if (this.options.extensions?.startInline) {
        let h = 1 / 0, u = t.slice(1), d;
        this.options.extensions.startInline.forEach((f) => {
          d = f.call({ lexer: this }, u), typeof d == "number" && d >= 0 && (h = Math.min(h, d));
        }), h < 1 / 0 && h >= 0 && (c = t.substring(0, h + 1));
      }
      if (l = this.tokenizer.inlineText(c)) {
        t = t.substring(l.raw.length), l.raw.slice(-1) !== "_" && (o = l.raw.slice(-1)), s = !0;
        let h = r.at(-1);
        h?.type === "text" ? (h.raw += l.raw, h.text += l.text) : r.push(l);
        continue;
      }
      if (t) {
        let h = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(h);
          break;
        } else throw new Error(h);
      }
    }
    return r;
  }
}, da = class {
  options;
  parser;
  constructor(t) {
    this.options = t || _r;
  }
  space(t) {
    return "";
  }
  code({ text: t, lang: r, escaped: i }) {
    let n = (r || "").match(qt.notSpaceStart)?.[0], a = t.replace(qt.endingNewline, "") + `
`;
    return n ? '<pre><code class="language-' + ye(n) + '">' + (i ? a : ye(a, !0)) + `</code></pre>
` : "<pre><code>" + (i ? a : ye(a, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: t }) {
    return `<blockquote>
${this.parser.parse(t)}</blockquote>
`;
  }
  html({ text: t }) {
    return t;
  }
  def(t) {
    return "";
  }
  heading({ tokens: t, depth: r }) {
    return `<h${r}>${this.parser.parseInline(t)}</h${r}>
`;
  }
  hr(t) {
    return `<hr>
`;
  }
  list(t) {
    let r = t.ordered, i = t.start, n = "";
    for (let o = 0; o < t.items.length; o++) {
      let l = t.items[o];
      n += this.listitem(l);
    }
    let a = r ? "ol" : "ul", s = r && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + a + s + `>
` + n + "</" + a + `>
`;
  }
  listitem(t) {
    let r = "";
    if (t.task) {
      let i = this.checkbox({ checked: !!t.checked });
      t.loose ? t.tokens[0]?.type === "paragraph" ? (t.tokens[0].text = i + " " + t.tokens[0].text, t.tokens[0].tokens && t.tokens[0].tokens.length > 0 && t.tokens[0].tokens[0].type === "text" && (t.tokens[0].tokens[0].text = i + " " + ye(t.tokens[0].tokens[0].text), t.tokens[0].tokens[0].escaped = !0)) : t.tokens.unshift({ type: "text", raw: i + " ", text: i + " ", escaped: !0 }) : r += i + " ";
    }
    return r += this.parser.parse(t.tokens, !!t.loose), `<li>${r}</li>
`;
  }
  checkbox({ checked: t }) {
    return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: t }) {
    return `<p>${this.parser.parseInline(t)}</p>
`;
  }
  table(t) {
    let r = "", i = "";
    for (let a = 0; a < t.header.length; a++) i += this.tablecell(t.header[a]);
    r += this.tablerow({ text: i });
    let n = "";
    for (let a = 0; a < t.rows.length; a++) {
      let s = t.rows[a];
      i = "";
      for (let o = 0; o < s.length; o++) i += this.tablecell(s[o]);
      n += this.tablerow({ text: i });
    }
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + r + `</thead>
` + n + `</table>
`;
  }
  tablerow({ text: t }) {
    return `<tr>
${t}</tr>
`;
  }
  tablecell(t) {
    let r = this.parser.parseInline(t.tokens), i = t.header ? "th" : "td";
    return (t.align ? `<${i} align="${t.align}">` : `<${i}>`) + r + `</${i}>
`;
  }
  strong({ tokens: t }) {
    return `<strong>${this.parser.parseInline(t)}</strong>`;
  }
  em({ tokens: t }) {
    return `<em>${this.parser.parseInline(t)}</em>`;
  }
  codespan({ text: t }) {
    return `<code>${ye(t, !0)}</code>`;
  }
  br(t) {
    return "<br>";
  }
  del({ tokens: t }) {
    return `<del>${this.parser.parseInline(t)}</del>`;
  }
  link({ href: t, title: r, tokens: i }) {
    let n = this.parser.parseInline(i), a = Qc(t);
    if (a === null) return n;
    t = a;
    let s = '<a href="' + t + '"';
    return r && (s += ' title="' + ye(r) + '"'), s += ">" + n + "</a>", s;
  }
  image({ href: t, title: r, text: i, tokens: n }) {
    n && (i = this.parser.parseInline(n, this.parser.textRenderer));
    let a = Qc(t);
    if (a === null) return ye(i);
    t = a;
    let s = `<img src="${t}" alt="${i}"`;
    return r && (s += ` title="${ye(r)}"`), s += ">", s;
  }
  text(t) {
    return "tokens" in t && t.tokens ? this.parser.parseInline(t.tokens) : "escaped" in t && t.escaped ? t.text : ye(t.text);
  }
}, ml = class {
  strong({ text: t }) {
    return t;
  }
  em({ text: t }) {
    return t;
  }
  codespan({ text: t }) {
    return t;
  }
  del({ text: t }) {
    return t;
  }
  html({ text: t }) {
    return t;
  }
  text({ text: t }) {
    return t;
  }
  link({ text: t }) {
    return "" + t;
  }
  image({ text: t }) {
    return "" + t;
  }
  br() {
    return "";
  }
}, oe = class so {
  options;
  renderer;
  textRenderer;
  constructor(t) {
    this.options = t || _r, this.options.renderer = this.options.renderer || new da(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new ml();
  }
  static parse(t, r) {
    return new so(r).parse(t);
  }
  static parseInline(t, r) {
    return new so(r).parseInline(t);
  }
  parse(t, r = !0) {
    let i = "";
    for (let n = 0; n < t.length; n++) {
      let a = t[n];
      if (this.options.extensions?.renderers?.[a.type]) {
        let o = a, l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(o.type)) {
          i += l || "";
          continue;
        }
      }
      let s = a;
      switch (s.type) {
        case "space": {
          i += this.renderer.space(s);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(s);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(s);
          continue;
        }
        case "code": {
          i += this.renderer.code(s);
          continue;
        }
        case "table": {
          i += this.renderer.table(s);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          i += this.renderer.list(s);
          continue;
        }
        case "html": {
          i += this.renderer.html(s);
          continue;
        }
        case "def": {
          i += this.renderer.def(s);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(s);
          continue;
        }
        case "text": {
          let o = s, l = this.renderer.text(o);
          for (; n + 1 < t.length && t[n + 1].type === "text"; ) o = t[++n], l += `
` + this.renderer.text(o);
          r ? i += this.renderer.paragraph({ type: "paragraph", raw: l, text: l, tokens: [{ type: "text", raw: l, text: l, escaped: !0 }] }) : i += l;
          continue;
        }
        default: {
          let o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent) return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return i;
  }
  parseInline(t, r = this.renderer) {
    let i = "";
    for (let n = 0; n < t.length; n++) {
      let a = t[n];
      if (this.options.extensions?.renderers?.[a.type]) {
        let o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          i += o || "";
          continue;
        }
      }
      let s = a;
      switch (s.type) {
        case "escape": {
          i += r.text(s);
          break;
        }
        case "html": {
          i += r.html(s);
          break;
        }
        case "link": {
          i += r.link(s);
          break;
        }
        case "image": {
          i += r.image(s);
          break;
        }
        case "strong": {
          i += r.strong(s);
          break;
        }
        case "em": {
          i += r.em(s);
          break;
        }
        case "codespan": {
          i += r.codespan(s);
          break;
        }
        case "br": {
          i += r.br(s);
          break;
        }
        case "del": {
          i += r.del(s);
          break;
        }
        case "text": {
          i += r.text(s);
          break;
        }
        default: {
          let o = 'Token with "' + s.type + '" type was not found.';
          if (this.options.silent) return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return i;
  }
}, ki = class {
  options;
  block;
  constructor(t) {
    this.options = t || _r;
  }
  static passThroughHooks = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"]);
  static passThroughHooksRespectAsync = /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"]);
  preprocess(t) {
    return t;
  }
  postprocess(t) {
    return t;
  }
  processAllTokens(t) {
    return t;
  }
  emStrongMask(t) {
    return t;
  }
  provideLexer() {
    return this.block ? se.lex : se.lexInline;
  }
  provideParser() {
    return this.block ? oe.parse : oe.parseInline;
  }
}, gv = class {
  defaults = ll();
  options = this.setOptions;
  parse = this.parseMarkdown(!0);
  parseInline = this.parseMarkdown(!1);
  Parser = oe;
  Renderer = da;
  TextRenderer = ml;
  Lexer = se;
  Tokenizer = fa;
  Hooks = ki;
  constructor(...t) {
    this.use(...t);
  }
  walkTokens(t, r) {
    let i = [];
    for (let n of t) switch (i = i.concat(r.call(this, n)), n.type) {
      case "table": {
        let a = n;
        for (let s of a.header) i = i.concat(this.walkTokens(s.tokens, r));
        for (let s of a.rows) for (let o of s) i = i.concat(this.walkTokens(o.tokens, r));
        break;
      }
      case "list": {
        let a = n;
        i = i.concat(this.walkTokens(a.items, r));
        break;
      }
      default: {
        let a = n;
        this.defaults.extensions?.childTokens?.[a.type] ? this.defaults.extensions.childTokens[a.type].forEach((s) => {
          let o = a[s].flat(1 / 0);
          i = i.concat(this.walkTokens(o, r));
        }) : a.tokens && (i = i.concat(this.walkTokens(a.tokens, r)));
      }
    }
    return i;
  }
  use(...t) {
    let r = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return t.forEach((i) => {
      let n = { ...i };
      if (n.async = this.defaults.async || n.async || !1, i.extensions && (i.extensions.forEach((a) => {
        if (!a.name) throw new Error("extension name required");
        if ("renderer" in a) {
          let s = r.renderers[a.name];
          s ? r.renderers[a.name] = function(...o) {
            let l = a.renderer.apply(this, o);
            return l === !1 && (l = s.apply(this, o)), l;
          } : r.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let s = r[a.level];
          s ? s.unshift(a.tokenizer) : r[a.level] = [a.tokenizer], a.start && (a.level === "block" ? r.startBlock ? r.startBlock.push(a.start) : r.startBlock = [a.start] : a.level === "inline" && (r.startInline ? r.startInline.push(a.start) : r.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (r.childTokens[a.name] = a.childTokens);
      }), n.extensions = r), i.renderer) {
        let a = this.defaults.renderer || new da(this.defaults);
        for (let s in i.renderer) {
          if (!(s in a)) throw new Error(`renderer '${s}' does not exist`);
          if (["options", "parser"].includes(s)) continue;
          let o = s, l = i.renderer[o], c = a[o];
          a[o] = (...h) => {
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u || "";
          };
        }
        n.renderer = a;
      }
      if (i.tokenizer) {
        let a = this.defaults.tokenizer || new fa(this.defaults);
        for (let s in i.tokenizer) {
          if (!(s in a)) throw new Error(`tokenizer '${s}' does not exist`);
          if (["options", "rules", "lexer"].includes(s)) continue;
          let o = s, l = i.tokenizer[o], c = a[o];
          a[o] = (...h) => {
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u;
          };
        }
        n.tokenizer = a;
      }
      if (i.hooks) {
        let a = this.defaults.hooks || new ki();
        for (let s in i.hooks) {
          if (!(s in a)) throw new Error(`hook '${s}' does not exist`);
          if (["options", "block"].includes(s)) continue;
          let o = s, l = i.hooks[o], c = a[o];
          ki.passThroughHooks.has(s) ? a[o] = (h) => {
            if (this.defaults.async && ki.passThroughHooksRespectAsync.has(s)) return (async () => {
              let d = await l.call(a, h);
              return c.call(a, d);
            })();
            let u = l.call(a, h);
            return c.call(a, u);
          } : a[o] = (...h) => {
            if (this.defaults.async) return (async () => {
              let d = await l.apply(a, h);
              return d === !1 && (d = await c.apply(a, h)), d;
            })();
            let u = l.apply(a, h);
            return u === !1 && (u = c.apply(a, h)), u;
          };
        }
        n.hooks = a;
      }
      if (i.walkTokens) {
        let a = this.defaults.walkTokens, s = i.walkTokens;
        n.walkTokens = function(o) {
          let l = [];
          return l.push(s.call(this, o)), a && (l = l.concat(a.call(this, o))), l;
        };
      }
      this.defaults = { ...this.defaults, ...n };
    }), this;
  }
  setOptions(t) {
    return this.defaults = { ...this.defaults, ...t }, this;
  }
  lexer(t, r) {
    return se.lex(t, r ?? this.defaults);
  }
  parser(t, r) {
    return oe.parse(t, r ?? this.defaults);
  }
  parseMarkdown(t) {
    return (r, i) => {
      let n = { ...i }, a = { ...this.defaults, ...n }, s = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1) return s(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null) return s(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string") return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      if (a.hooks && (a.hooks.options = a, a.hooks.block = t), a.async) return (async () => {
        let o = a.hooks ? await a.hooks.preprocess(r) : r, l = await (a.hooks ? await a.hooks.provideLexer() : t ? se.lex : se.lexInline)(o, a), c = a.hooks ? await a.hooks.processAllTokens(l) : l;
        a.walkTokens && await Promise.all(this.walkTokens(c, a.walkTokens));
        let h = await (a.hooks ? await a.hooks.provideParser() : t ? oe.parse : oe.parseInline)(c, a);
        return a.hooks ? await a.hooks.postprocess(h) : h;
      })().catch(s);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let o = (a.hooks ? a.hooks.provideLexer() : t ? se.lex : se.lexInline)(r, a);
        a.hooks && (o = a.hooks.processAllTokens(o)), a.walkTokens && this.walkTokens(o, a.walkTokens);
        let l = (a.hooks ? a.hooks.provideParser() : t ? oe.parse : oe.parseInline)(o, a);
        return a.hooks && (l = a.hooks.postprocess(l)), l;
      } catch (o) {
        return s(o);
      }
    };
  }
  onError(t, r) {
    return (i) => {
      if (i.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
        let n = "<p>An error occurred:</p><pre>" + ye(i.message + "", !0) + "</pre>";
        return r ? Promise.resolve(n) : n;
      }
      if (r) return Promise.reject(i);
      throw i;
    };
  }
}, mr = new gv();
function dt(e, t) {
  return mr.parse(e, t);
}
dt.options = dt.setOptions = function(e) {
  return mr.setOptions(e), dt.defaults = mr.defaults, Qd(dt.defaults), dt;
};
dt.getDefaults = ll;
dt.defaults = _r;
dt.use = function(...e) {
  return mr.use(...e), dt.defaults = mr.defaults, Qd(dt.defaults), dt;
};
dt.walkTokens = function(e, t) {
  return mr.walkTokens(e, t);
};
dt.parseInline = mr.parseInline;
dt.Parser = oe;
dt.parser = oe.parse;
dt.Renderer = da;
dt.TextRenderer = ml;
dt.Lexer = se;
dt.lexer = se.lex;
dt.Tokenizer = fa;
dt.Hooks = ki;
dt.parse = dt;
dt.options;
dt.setOptions;
dt.use;
dt.walkTokens;
dt.parseInline;
oe.parse;
se.lex;
function cp(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(o, l) {
    var c = l.match(/\n([\t ]+|(?!\s).)/g);
    return c ? o.concat(c.map(function(h) {
      var u, d;
      return (d = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && d !== void 0 ? d : 0;
    })) : o;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(o) {
      return o.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var s = i[0];
  return t.forEach(function(o, l) {
    var c = s.match(/(?:^|\n)( *)$/), h = c ? c[1] : "", u = o;
    typeof o == "string" && o.includes(`
`) && (u = String(o).split(`
`).map(function(d, f) {
      return f === 0 ? d : "" + h + d;
    }).join(`
`)), s += u + i[l + 1];
  }), s;
}
var mv = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, oo = /* @__PURE__ */ new Map(), hp = /* @__PURE__ */ new Map(), yv = /* @__PURE__ */ p((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      hp.set(t.name, t.loader);
    else if ("icons" in t)
      oo.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), up = /* @__PURE__ */ p(async (e, t) => {
  const r = xk(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = oo.get(i);
  if (!n) {
    const s = hp.get(i);
    if (!s)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await s(), prefix: i }, oo.set(i, n);
    } catch (o) {
      throw F.error(o), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = _k(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), xv = /* @__PURE__ */ p(async (e) => {
  try {
    return await up(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), rn = /* @__PURE__ */ p(async (e, t, r) => {
  let i;
  try {
    i = await up(e, t?.fallbackPrefix);
  } catch (s) {
    F.error(s), i = mv;
  }
  const n = Lk(i, t), a = Ek($k(n.body), {
    ...n.attributes,
    ...r
  });
  return fe(a, Dt());
}, "getIconSVG");
function fp(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`);
  return cp(i);
}
p(fp, "preprocessMarkdown");
function dp(e) {
  return e.split(/\\n|\n|<br\s*\/?>/gi).map(
    (t) => t.trim().match(/<[^>]+>|[^\s<>]+/g)?.map((r) => ({ content: r, type: "normal" })) ?? []
  );
}
p(dp, "nonMarkdownToLines");
function pp(e, t = {}) {
  const r = fp(e, t), i = dt.lexer(r), n = [[]];
  let a = 0;
  function s(o, l = "normal") {
    o.type === "text" ? o.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((d) => {
        d = d.replace(/&#39;/g, "'"), d && n[a].push({ content: d, type: l });
      });
    }) : o.type === "strong" || o.type === "em" ? o.tokens.forEach((c) => {
      s(c, o.type);
    }) : o.type === "html" && n[a].push({ content: o.text, type: "normal" });
  }
  return p(s, "processNode"), i.forEach((o) => {
    o.type === "paragraph" ? o.tokens?.forEach((l) => {
      s(l);
    }) : o.type === "html" ? n[a].push({ content: o.text, type: "normal" }) : n[a].push({ content: o.raw, type: "normal" });
  }), n;
}
p(pp, "markdownToLines");
function gp(e) {
  return e ? `<p>${/**
  * Replace new lines with <br /> tags.
  *
  * Unlike in markdown text, `\n` sequences are treated as line breaks here.
  */
  e.replace(/\\n|\n/g, "<br />")}</p>` : "";
}
p(gp, "nonMarkdownToHTML");
function mp(e, { markdownAutoWrap: t } = {}) {
  const r = dt.lexer(e);
  function i(n) {
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${n.tokens?.map(i).join("")}</strong>` : n.type === "em" ? `<em>${n.tokens?.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${n.tokens?.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : (F.warn(`Unsupported markdown: ${n.type}`), n.raw);
  }
  return p(i, "output"), r.map(i).join("");
}
p(mp, "markdownToHTML");
function yp(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
p(yp, "splitTextToChars");
function xp(e, t) {
  const r = yp(t.content);
  return yl(e, [], r, t.type);
}
p(xp, "splitWordToFitWidth");
function yl(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, s = [...t, n];
  return e([{ content: s.join(""), type: i }]) ? yl(e, s, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
p(yl, "splitWordToFitWidthRecursion");
function bp(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return pa(e, t);
}
p(bp, "splitLineToFitWidth");
function pa(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, s = [...i];
  if (n !== "" && s.push({ content: n, type: "normal" }), s.push(a), t(s))
    return pa(e, t, r, s);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [o, l] = xp(t, a);
    r.push([o]), l.content && e.unshift(l);
  }
  return pa(e, t, r);
}
p(pa, "splitLineToFitWidthRecursion");
function lo(e, t) {
  t && e.attr("style", t);
}
p(lo, "applyStyle");
var eh = 16384;
async function Cp(e, t, r, i, n = !1, a = Dt()) {
  const s = e.append("foreignObject");
  s.attr("width", `${Math.min(10 * r, eh)}px`), s.attr("height", `${Math.min(10 * r, eh)}px`);
  const o = s.append("xhtml:div"), l = Fi(t.label) ? await Uh(t.label.replace(Vi.lineBreakRegex, `
`), a) : fe(t.label, a), c = t.isNode ? "nodeLabel" : "edgeLabel", h = o.append("span");
  h.html(l), lo(h, t.labelStyle), h.attr("class", `${c} ${i}`), lo(o, t.labelStyle), o.style("display", "table-cell"), o.style("white-space", "nowrap"), o.style("line-height", "1.5"), r !== Number.POSITIVE_INFINITY && (o.style("max-width", r + "px"), o.style("text-align", "center")), o.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && o.attr("class", "labelBkg");
  let u = o.node().getBoundingClientRect();
  return u.width === r && (o.style("display", "table"), o.style("white-space", "break-spaces"), o.style("width", r + "px"), u = o.node().getBoundingClientRect()), s.node();
}
p(Cp, "addHtmlSpan");
function za(e, t, r, i = !1) {
  const n = e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
  return i && n.attr("text-anchor", "middle"), n;
}
p(za, "createTspan");
function _p(e, t, r) {
  const i = e.append("text"), n = za(i, 1, t);
  Wa(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
p(_p, "computeWidthOfText");
function bv(e, t, r) {
  const i = e.append("text"), n = za(i, 1, t);
  Wa(n, [{ content: r, type: "normal" }]);
  const a = n.node()?.getBoundingClientRect();
  return a && i.remove(), a;
}
p(bv, "computeDimensionOfText");
function wp(e, t, r, i = !1, n = !1) {
  const s = t.append("g"), o = s.insert("rect").attr("class", "background").attr("style", "stroke: none"), l = s.append("text").attr("y", "-10.1");
  n && l.attr("text-anchor", "middle");
  let c = 0;
  for (const h of r) {
    const u = /* @__PURE__ */ p((f) => _p(s, 1.1, f) <= e, "checkWidth"), d = u(h) ? [h] : bp(h, u);
    for (const f of d) {
      const g = za(l, c, 1.1, n);
      Wa(g, f), c++;
    }
  }
  if (i) {
    const h = l.node().getBBox(), u = 2;
    return o.attr("x", h.x - u).attr("y", h.y - u).attr("width", h.width + 2 * u).attr("height", h.height + 2 * u), s.node();
  } else
    return l.node();
}
p(wp, "createFormattedText");
function Wa(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
p(Wa, "updateTextContentAndStyles");
async function kp(e, t = {}) {
  const r = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (n, a, s) => (r.push(
    (async () => {
      const o = `${a}:${s}`;
      return await xv(o) ? await rn(o, void 0, { class: "label-icon" }) : `<i class='${fe(n, t).replace(":", " ")}'></i>`;
    })()
  ), n));
  const i = await Promise.all(r);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => i.shift() ?? "");
}
p(kp, "replaceIconSubstring");
var Pe = /* @__PURE__ */ p(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  markdown: s = !0,
  isNode: o = !0,
  /**
   * The width to wrap the text within. Set to `Number.POSITIVE_INFINITY` for no wrapping.
   */
  width: l = 200,
  addSvgBackground: c = !1
} = {}, h) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    o,
    "addSvgBackground: ",
    c
  ), a) {
    const u = s ? mp(t, h) : gp(t), d = await kp(Jr(u), h), f = t.replace(/\\\\/g, "\\"), g = {
      isNode: o,
      label: Fi(t) ? f : d,
      labelStyle: r.replace("fill:", "color:")
    };
    return await Cp(e, g, l, n, c, h);
  } else {
    const u = t.replace(/<br\s*\/?>/g, "<br/>"), d = s ? pp(u.replace("<br>", "<br/>"), h) : dp(u), f = wp(
      l,
      e,
      d,
      t ? c : !1,
      !o
    );
    if (o) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      lt(f).attr("style", g);
    } else {
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      lt(f).select("rect").attr("style", g.replace(/background:/g, "fill:"));
      const m = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      lt(f).select("text").attr("style", m);
    }
    return i ? lt(f).selectAll("tspan.text-outer-tspan").classed("title-row", !0) : lt(f).selectAll("tspan.text-outer-tspan").classed("row", !0), f;
  }
}, "createText");
function ms(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, s = Math.cos(a), o = Math.sin(a);
    for (const l of e) {
      const [c, h] = l;
      l[0] = (c - i) * s - (h - n) * o + i, l[1] = (c - i) * o + (h - n) * s + n;
    }
  }
}
function Cv(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function _v(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), s = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, o = [0, 0];
  if (n) for (const c of s) ms(c, o, n);
  const l = (function(c, h, u) {
    const d = [];
    for (const b of c) {
      const _ = [...b];
      Cv(_[0], _[_.length - 1]) || _.push([_[0][0], _[0][1]]), _.length > 2 && d.push(_);
    }
    const f = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of d) for (let _ = 0; _ < b.length - 1; _++) {
      const v = b[_], k = b[_ + 1];
      if (v[1] !== k[1]) {
        const T = Math.min(v[1], k[1]);
        g.push({ ymin: T, ymax: Math.max(v[1], k[1]), x: T === v[1] ? v[0] : k[0], islope: (k[0] - v[0]) / (k[1] - v[1]) });
      }
    }
    if (g.sort(((b, _) => b.ymin < _.ymin ? -1 : b.ymin > _.ymin ? 1 : b.x < _.x ? -1 : b.x > _.x ? 1 : b.ymax === _.ymax ? 0 : (b.ymax - _.ymax) / Math.abs(b.ymax - _.ymax))), !g.length) return f;
    let m = [], y = g[0].ymin, x = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let _ = 0; _ < g.length && !(g[_].ymin > y); _++) b = _;
        g.splice(0, b + 1).forEach(((_) => {
          m.push({ s: y, edge: _ });
        }));
      }
      if (m = m.filter(((b) => !(b.edge.ymax <= y))), m.sort(((b, _) => b.edge.x === _.edge.x ? 0 : (b.edge.x - _.edge.x) / Math.abs(b.edge.x - _.edge.x))), (u !== 1 || x % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const _ = b + 1;
        if (_ >= m.length) break;
        const v = m[b].edge, k = m[_].edge;
        f.push([[Math.round(v.x), y], [Math.round(k.x), y]]);
      }
      y += u, m.forEach(((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      })), x++;
    }
    return f;
  })(s, a, i);
  if (n) {
    for (const c of s) ms(c, o, -n);
    (function(c, h, u) {
      const d = [];
      c.forEach(((f) => d.push(...f))), ms(d, h, u);
    })(l, o, -n);
  }
  return l;
}
function nn(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), _v(e, n, i, a || 1);
}
class xl {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = nn(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function qa(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class wv extends xl {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = nn(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, s = [], o = 0.5 * i * Math.cos(a), l = 0.5 * i * Math.sin(a);
    for (const [c, h] of n) qa([c, h]) && s.push([[c[0] - o, c[1] + l], [...h]], [[c[0] + o, c[1] - l], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(s, r) };
  }
}
class kv extends xl {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class vv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = nn(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const s = n / 4;
    for (const o of t) {
      const l = qa(o), c = l / n, h = Math.ceil(c) - 1, u = l - h * n, d = (o[0][0] + o[1][0]) / 2 - n / 4, f = Math.min(o[0][1], o[1][1]);
      for (let g = 0; g < h; g++) {
        const m = f + u + g * n, y = d - s + 2 * Math.random() * s, x = m - s + 2 * Math.random() * s, b = this.helper.ellipse(y, x, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class Sv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = nn(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach(((s) => {
      const o = qa(s), l = Math.floor(o / (i + n)), c = (o + n - l * (i + n)) / 2;
      let h = s[0], u = s[1];
      h[0] > u[0] && (h = s[1], u = s[0]);
      const d = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let f = 0; f < l; f++) {
        const g = f * (i + n), m = g + i, y = [h[0] + g * Math.cos(d) + c * Math.cos(d), h[1] + g * Math.sin(d) + c * Math.sin(d)], x = [h[0] + m * Math.cos(d) + c * Math.cos(d), h[1] + m * Math.sin(d) + c * Math.sin(d)];
        a.push(...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], r));
      }
    })), a;
  }
}
class Tv {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = nn(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach(((a) => {
      const s = qa(a), o = Math.round(s / (2 * r));
      let l = a[0], c = a[1];
      l[0] > c[0] && (l = a[1], c = a[0]);
      const h = Math.atan((c[1] - l[1]) / (c[0] - l[0]));
      for (let u = 0; u < o; u++) {
        const d = 2 * u * r, f = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [l[0] + d * Math.cos(h), l[1] + d * Math.sin(h)], y = [l[0] + f * Math.cos(h), l[1] + f * Math.sin(h)], x = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], x[0], x[1], i), ...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], i));
      }
    })), n;
  }
}
const Ut = {};
class Bv {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const Lv = 0, ys = 1, rh = 2, _n = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function xs(e, t) {
  return e.type === t;
}
function bl(e) {
  const t = [], r = (function(s) {
    const o = new Array();
    for (; s !== ""; ) if (s.match(/^([ \t\r\n,]+)/)) s = s.substr(RegExp.$1.length);
    else if (s.match(/^([aAcChHlLmMqQsStTvVzZ])/)) o[o.length] = { type: Lv, text: RegExp.$1 }, s = s.substr(RegExp.$1.length);
    else {
      if (!s.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      o[o.length] = { type: ys, text: `${parseFloat(RegExp.$1)}` }, s = s.substr(RegExp.$1.length);
    }
    return o[o.length] = { type: rh, text: "" }, o;
  })(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !xs(a, rh); ) {
    let s = 0;
    const o = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return bl("M0,0" + e);
      n++, s = _n[a.text], i = a.text;
    } else xs(a, ys) ? s = _n[i] : (n++, s = _n[a.text], i = a.text);
    if (!(n + s < r.length)) throw new Error("Path data ended short");
    for (let l = n; l < n + s; l++) {
      const c = r[l];
      if (!xs(c, ys)) throw new Error("Param not a number: " + i + "," + c.text);
      o[o.length] = +c.text;
    }
    if (typeof _n[i] != "number") throw new Error("Bad segment: " + i);
    {
      const l = { key: i, data: o };
      t.push(l), n += s, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function vp(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: s, data: o } of e) switch (s) {
    case "M":
      a.push({ key: "M", data: [...o] }), [t, r] = o, [i, n] = o;
      break;
    case "m":
      t += o[0], r += o[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...o] }), [t, r] = o;
      break;
    case "l":
      t += o[0], r += o[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...o] }), t = o[4], r = o[5];
      break;
    case "c": {
      const l = o.map(((c, h) => h % 2 ? c + r : c + t));
      a.push({ key: "C", data: l }), t = l[4], r = l[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...o] }), t = o[2], r = o[3];
      break;
    case "q": {
      const l = o.map(((c, h) => h % 2 ? c + r : c + t));
      a.push({ key: "Q", data: l }), t = l[2], r = l[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...o] }), t = o[5], r = o[6];
      break;
    case "a":
      t += o[5], r += o[6], a.push({ key: "A", data: [o[0], o[1], o[2], o[3], o[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...o] }), t = o[0];
      break;
    case "h":
      t += o[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...o] }), r = o[0];
      break;
    case "v":
      r += o[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...o] }), t = o[2], r = o[3];
      break;
    case "s": {
      const l = o.map(((c, h) => h % 2 ? c + r : c + t));
      a.push({ key: "S", data: l }), t = l[2], r = l[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...o] }), t = o[0], r = o[1];
      break;
    case "t":
      t += o[0], r += o[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function Sp(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, s = 0, o = 0, l = 0;
  for (const { key: c, data: h } of e) {
    switch (c) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, s] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], o = h[2], l = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, d = 0;
        r === "C" || r === "S" ? (u = i + (i - o), d = n + (n - l)) : (u = i, d = n), t.push({ key: "C", data: [u, d, ...h] }), o = h[0], l = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, d] = h;
        let f = 0, g = 0;
        r === "Q" || r === "T" ? (f = i + (i - o), g = n + (n - l)) : (f = i, g = n);
        const m = i + 2 * (f - i) / 3, y = n + 2 * (g - n) / 3, x = u + 2 * (f - u) / 3, b = d + 2 * (g - d) / 3;
        t.push({ key: "C", data: [m, y, x, b, u, d] }), o = f, l = g, i = u, n = d;
        break;
      }
      case "Q": {
        const [u, d, f, g] = h, m = i + 2 * (u - i) / 3, y = n + 2 * (d - n) / 3, x = f + 2 * (u - f) / 3, b = g + 2 * (d - g) / 3;
        t.push({ key: "C", data: [m, y, x, b, f, g] }), o = u, l = d, i = f, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), d = Math.abs(h[1]), f = h[2], g = h[3], m = h[4], y = h[5], x = h[6];
        u === 0 || d === 0 ? (t.push({ key: "C", data: [i, n, y, x, y, x] }), i = y, n = x) : (i !== y || n !== x) && (Tp(i, n, y, x, u, d, f, g, m).forEach((function(b) {
          t.push({ key: "C", data: b });
        })), i = y, n = x);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = s;
    }
    r = c;
  }
  return t;
}
function gi(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function Tp(e, t, r, i, n, a, s, o, l, c) {
  const h = (u = s, Math.PI * u / 180);
  var u;
  let d = [], f = 0, g = 0, m = 0, y = 0;
  if (c) [f, g, m, y] = c;
  else {
    [e, t] = gi(e, t, -h), [r, i] = gi(r, i, -h);
    const R = (e - r) / 2, A = (t - i) / 2;
    let L = R * R / (n * n) + A * A / (a * a);
    L > 1 && (L = Math.sqrt(L), n *= L, a *= L);
    const S = n * n, E = a * a, M = S * E - S * A * A - E * R * R, q = S * A * A + E * R * R, Y = (o === l ? -1 : 1) * Math.sqrt(Math.abs(M / q));
    m = Y * n * A / a + (e + r) / 2, y = Y * -a * R / n + (t + i) / 2, f = Math.asin(parseFloat(((t - y) / a).toFixed(9))), g = Math.asin(parseFloat(((i - y) / a).toFixed(9))), e < m && (f = Math.PI - f), r < m && (g = Math.PI - g), f < 0 && (f = 2 * Math.PI + f), g < 0 && (g = 2 * Math.PI + g), l && f > g && (f -= 2 * Math.PI), !l && g > f && (g -= 2 * Math.PI);
  }
  let x = g - f;
  if (Math.abs(x) > 120 * Math.PI / 180) {
    const R = g, A = r, L = i;
    g = l && g > f ? f + 120 * Math.PI / 180 * 1 : f + 120 * Math.PI / 180 * -1, d = Tp(r = m + n * Math.cos(g), i = y + a * Math.sin(g), A, L, n, a, s, 0, l, [g, R, m, y]);
  }
  x = g - f;
  const b = Math.cos(f), _ = Math.sin(f), v = Math.cos(g), k = Math.sin(g), T = Math.tan(x / 4), B = 4 / 3 * n * T, D = 4 / 3 * a * T, I = [e, t], O = [e + B * _, t - D * b], $ = [r + B * k, i - D * v], N = [r, i];
  if (O[0] = 2 * I[0] - O[0], O[1] = 2 * I[1] - O[1], c) return [O, $, N].concat(d);
  {
    d = [O, $, N].concat(d);
    const R = [];
    for (let A = 0; A < d.length; A += 3) {
      const L = gi(d[A][0], d[A][1], h), S = gi(d[A + 1][0], d[A + 1][1], h), E = gi(d[A + 2][0], d[A + 2][1], h);
      R.push([L[0], L[1], S[0], S[1], E[0], E[1]]);
    }
    return R;
  }
}
const Av = { randOffset: function(e, t) {
  return nt(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return ga(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = Lp(r, i, n);
  return co(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return Xe(e, t, r, i, n, !0);
} };
function Bp(e, t, r, i, n) {
  return { type: "path", ops: Xe(e, t, r, i, n) };
}
function On(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...Xe(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...Xe(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? Bp(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function Mv(e, t, r, i, n) {
  return (function(a, s) {
    return On(a, !0, s);
  })([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function ih(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = wn(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : wn(r[0], 1.5 * (1 + 0.22 * t.roughness), sh(t));
    for (let a = 1; a < r.length; a++) {
      const s = r[a];
      if (s.length) {
        const o = wn(s, 1 * (1 + 0.2 * t.roughness), t), l = t.disableMultiStroke ? [] : wn(s, 1.5 * (1 + 0.22 * t.roughness), sh(t));
        for (const c of o) c.op !== "move" && i.push(c);
        for (const c of l) c.op !== "move" && n.push(c);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function Lp(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let s = Math.abs(e / 2), o = Math.abs(t / 2);
  const l = 1 - r.curveFitting;
  return s += nt(s * l, r), o += nt(o * l, r), { increment: a, rx: s, ry: o };
}
function co(e, t, r, i) {
  const [n, a] = oh(i.increment, e, t, i.rx, i.ry, 1, i.increment * ga(0.1, ga(0.4, 1, r), r), r);
  let s = ma(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [o] = oh(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), l = ma(o, null, r);
    s = s.concat(l);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: s } };
}
function nh(e, t, r, i, n, a, s, o, l) {
  const c = e, h = t;
  let u = Math.abs(r / 2), d = Math.abs(i / 2);
  u += nt(0.01 * u, l), d += nt(0.01 * d, l);
  let f = n, g = a;
  for (; f < 0; ) f += 2 * Math.PI, g += 2 * Math.PI;
  g - f > 2 * Math.PI && (f = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / l.curveStepCount, y = Math.min(m / 2, (g - f) / 2), x = lh(y, c, h, u, d, f, g, 1, l);
  if (!l.disableMultiStroke) {
    const b = lh(y, c, h, u, d, f, g, 1.5, l);
    x.push(...b);
  }
  return s && (o ? x.push(...Xe(c, h, c + u * Math.cos(f), h + d * Math.sin(f), l), ...Xe(c, h, c + u * Math.cos(g), h + d * Math.sin(g), l)) : x.push({ op: "lineTo", data: [c, h] }, { op: "lineTo", data: [c + u * Math.cos(f), h + d * Math.sin(f)] })), { type: "path", ops: x };
}
function ah(e, t) {
  const r = Sp(vp(bl(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: s, data: o } of r) switch (s) {
    case "M":
      a = [o[0], o[1]], n = [o[0], o[1]];
      break;
    case "L":
      i.push(...Xe(a[0], a[1], o[0], o[1], t)), a = [o[0], o[1]];
      break;
    case "C": {
      const [l, c, h, u, d, f] = o;
      i.push(...$v(l, c, h, u, d, f, a, t)), a = [d, f];
      break;
    }
    case "Z":
      i.push(...Xe(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function bs(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + nt(n, t), i[0][1] + nt(n, t)] });
      for (let s = 1; s < a; s++) r.push({ op: "lineTo", data: [i[s][0] + nt(n, t), i[s][1] + nt(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function Lr(e, t) {
  return (function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Ut[n]) switch (n) {
      case "zigzag":
        Ut[n] || (Ut[n] = new wv(i));
        break;
      case "cross-hatch":
        Ut[n] || (Ut[n] = new kv(i));
        break;
      case "dots":
        Ut[n] || (Ut[n] = new vv(i));
        break;
      case "dashed":
        Ut[n] || (Ut[n] = new Sv(i));
        break;
      case "zigzag-line":
        Ut[n] || (Ut[n] = new Tv(i));
        break;
      default:
        n = "hachure", Ut[n] || (Ut[n] = new xl(i));
    }
    return Ut[n];
  })(t, Av).fillPolygons(e, t);
}
function sh(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function Ap(e) {
  return e.randomizer || (e.randomizer = new Bv(e.seed || 0)), e.randomizer.next();
}
function ga(e, t, r, i = 1) {
  return r.roughness * i * (Ap(r) * (t - e) + e);
}
function nt(e, t, r = 1) {
  return ga(-e, e, t, r);
}
function Xe(e, t, r, i, n, a = !1) {
  const s = a ? n.disableMultiStrokeFill : n.disableMultiStroke, o = ho(e, t, r, i, n, !0, !1);
  if (s) return o;
  const l = ho(e, t, r, i, n, !0, !0);
  return o.concat(l);
}
function ho(e, t, r, i, n, a, s) {
  const o = Math.pow(e - r, 2) + Math.pow(t - i, 2), l = Math.sqrt(o);
  let c = 1;
  c = l < 200 ? 1 : l > 500 ? 0.4 : -16668e-7 * l + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > o && (h = l / 10);
  const u = h / 2, d = 0.2 + 0.2 * Ap(n);
  let f = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  f = nt(f, n, c), g = nt(g, n, c);
  const m = [], y = () => nt(u, n, c), x = () => nt(h, n, c), b = n.preserveVertices;
  return s ? m.push({ op: "move", data: [e + (b ? 0 : y()), t + (b ? 0 : y())] }) : m.push({ op: "move", data: [e + (b ? 0 : nt(h, n, c)), t + (b ? 0 : nt(h, n, c))] }), s ? m.push({ op: "bcurveTo", data: [f + e + (r - e) * d + y(), g + t + (i - t) * d + y(), f + e + 2 * (r - e) * d + y(), g + t + 2 * (i - t) * d + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }) : m.push({ op: "bcurveTo", data: [f + e + (r - e) * d + x(), g + t + (i - t) * d + x(), f + e + 2 * (r - e) * d + x(), g + t + 2 * (i - t) * d + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }), m;
}
function wn(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + nt(t, r), e[0][1] + nt(t, r)]), i.push([e[0][0] + nt(t, r), e[0][1] + nt(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + nt(t, r), e[n][1] + nt(t, r)]), n === e.length - 1 && i.push([e[n][0] + nt(t, r), e[n][1] + nt(t, r)]);
  return ma(i, null, r);
}
function ma(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], s = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let o = 1; o + 2 < i; o++) {
      const l = e[o];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (s * e[o + 1][0] - s * e[o - 1][0]) / 6, l[1] + (s * e[o + 1][1] - s * e[o - 1][1]) / 6], a[2] = [e[o + 1][0] + (s * e[o][0] - s * e[o + 2][0]) / 6, e[o + 1][1] + (s * e[o][1] - s * e[o + 2][1]) / 6], a[3] = [e[o + 1][0], e[o + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...ho(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function oh(e, t, r, i, n, a, s, o) {
  const l = [], c = [];
  if (o.roughness === 0) {
    e /= 4, c.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      l.push(u), c.push(u);
    }
    c.push([t + i * Math.cos(0), r + n * Math.sin(0)]), c.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = nt(0.5, o) - Math.PI / 2;
    c.push([nt(a, o) + t + 0.9 * i * Math.cos(h - e), nt(a, o) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let d = h; d < u; d += e) {
      const f = [nt(a, o) + t + i * Math.cos(d), nt(a, o) + r + n * Math.sin(d)];
      l.push(f), c.push(f);
    }
    c.push([nt(a, o) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * s), nt(a, o) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * s)]), c.push([nt(a, o) + t + 0.98 * i * Math.cos(h + s), nt(a, o) + r + 0.98 * n * Math.sin(h + s)]), c.push([nt(a, o) + t + 0.9 * i * Math.cos(h + 0.5 * s), nt(a, o) + r + 0.9 * n * Math.sin(h + 0.5 * s)]);
  }
  return [c, l];
}
function lh(e, t, r, i, n, a, s, o, l) {
  const c = a + nt(0.1, l), h = [];
  h.push([nt(o, l) + t + 0.9 * i * Math.cos(c - e), nt(o, l) + r + 0.9 * n * Math.sin(c - e)]);
  for (let u = c; u <= s; u += e) h.push([nt(o, l) + t + i * Math.cos(u), nt(o, l) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(s), r + n * Math.sin(s)]), h.push([t + i * Math.cos(s), r + n * Math.sin(s)]), ma(h, null, l);
}
function $v(e, t, r, i, n, a, s, o) {
  const l = [], c = [o.maxRandomnessOffset || 1, (o.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = o.disableMultiStroke ? 1 : 2, d = o.preserveVertices;
  for (let f = 0; f < u; f++) f === 0 ? l.push({ op: "move", data: [s[0], s[1]] }) : l.push({ op: "move", data: [s[0] + (d ? 0 : nt(c[0], o)), s[1] + (d ? 0 : nt(c[0], o))] }), h = d ? [n, a] : [n + nt(c[f], o), a + nt(c[f], o)], l.push({ op: "bcurveTo", data: [e + nt(c[f], o), t + nt(c[f], o), r + nt(c[f], o), i + nt(c[f], o), h[0], h[1]] });
  return l;
}
function mi(e) {
  return [...e];
}
function ch(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(mi(e[0]), mi(e[1]), mi(e[2]), mi(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let o = 1; o < e.length; o++) n.push(e[o]), o === e.length - 1 && n.push(e[o]);
    const a = [], s = 1 - t;
    i.push(mi(n[0]));
    for (let o = 1; o + 2 < n.length; o++) {
      const l = n[o];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (s * n[o + 1][0] - s * n[o - 1][0]) / 6, l[1] + (s * n[o + 1][1] - s * n[o - 1][1]) / 6], a[2] = [n[o + 1][0] + (s * n[o][0] - s * n[o + 2][0]) / 6, n[o + 1][1] + (s * n[o][1] - s * n[o + 2][1]) / 6], a[3] = [n[o + 1][0], n[o + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function Rn(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function Ev(e, t, r) {
  const i = Rn(t, r);
  if (i === 0) return Rn(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), Rn(e, ir(t, r, n));
}
function ir(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function uo(e, t, r, i) {
  const n = i || [];
  if ((function(o, l) {
    const c = o[l + 0], h = o[l + 1], u = o[l + 2], d = o[l + 3];
    let f = 3 * h[0] - 2 * c[0] - d[0];
    f *= f;
    let g = 3 * h[1] - 2 * c[1] - d[1];
    g *= g;
    let m = 3 * u[0] - 2 * d[0] - c[0];
    m *= m;
    let y = 3 * u[1] - 2 * d[1] - c[1];
    return y *= y, f < m && (f = m), g < y && (g = y), f + g;
  })(e, t) < r) {
    const o = e[t + 0];
    n.length ? (a = n[n.length - 1], s = o, Math.sqrt(Rn(a, s)) > 1 && n.push(o)) : n.push(o), n.push(e[t + 3]);
  } else {
    const l = e[t + 0], c = e[t + 1], h = e[t + 2], u = e[t + 3], d = ir(l, c, 0.5), f = ir(c, h, 0.5), g = ir(h, u, 0.5), m = ir(d, f, 0.5), y = ir(f, g, 0.5), x = ir(m, y, 0.5);
    uo([l, d, m, x], 0, r, n), uo([x, y, g, u], 0, r, n);
  }
  var a, s;
  return n;
}
function Fv(e, t) {
  return ya(e, 0, e.length, t);
}
function ya(e, t, r, i, n) {
  const a = n || [], s = e[t], o = e[r - 1];
  let l = 0, c = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = Ev(e[h], s, o);
    u > l && (l = u, c = h);
  }
  return Math.sqrt(l) > i ? (ya(e, t, c + 1, i, a), ya(e, c, r, i, a)) : (a.length || a.push(s), a.push(o)), a;
}
function Cs(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    uo(e, 3 * a, t, i);
  return r && r > 0 ? ya(i, 0, i.length, r) : i;
}
const Zt = "none";
class xa {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const s = this._o(a);
    return this._d("line", [Bp(t, r, i, n, s)], s);
  }
  rectangle(t, r, i, n, a) {
    const s = this._o(a), o = [], l = Mv(t, r, i, n, s);
    if (s.fill) {
      const c = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      s.fillStyle === "solid" ? o.push(bs([c], s)) : o.push(Lr([c], s));
    }
    return s.stroke !== Zt && o.push(l), this._d("rectangle", o, s);
  }
  ellipse(t, r, i, n, a) {
    const s = this._o(a), o = [], l = Lp(i, n, s), c = co(t, r, s, l);
    if (s.fill) if (s.fillStyle === "solid") {
      const h = co(t, r, s, l).opset;
      h.type = "fillPath", o.push(h);
    } else o.push(Lr([c.estimatedPoints], s));
    return s.stroke !== Zt && o.push(c.opset), this._d("ellipse", o, s);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [On(t, !1, i)], i);
  }
  arc(t, r, i, n, a, s, o = !1, l) {
    const c = this._o(l), h = [], u = nh(t, r, i, n, a, s, o, !0, c);
    if (o && c.fill) if (c.fillStyle === "solid") {
      const d = Object.assign({}, c);
      d.disableMultiStroke = !0;
      const f = nh(t, r, i, n, a, s, !0, !1, d);
      f.type = "fillPath", h.push(f);
    } else h.push((function(d, f, g, m, y, x, b) {
      const _ = d, v = f;
      let k = Math.abs(g / 2), T = Math.abs(m / 2);
      k += nt(0.01 * k, b), T += nt(0.01 * T, b);
      let B = y, D = x;
      for (; B < 0; ) B += 2 * Math.PI, D += 2 * Math.PI;
      D - B > 2 * Math.PI && (B = 0, D = 2 * Math.PI);
      const I = (D - B) / b.curveStepCount, O = [];
      for (let $ = B; $ <= D; $ += I) O.push([_ + k * Math.cos($), v + T * Math.sin($)]);
      return O.push([_ + k * Math.cos(D), v + T * Math.sin(D)]), O.push([_, v]), Lr([O], b);
    })(t, r, i, n, a, s, c));
    return c.stroke !== Zt && h.push(u), this._d("arc", h, c);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = ih(t, i);
    if (i.fill && i.fill !== Zt) if (i.fillStyle === "solid") {
      const s = ih(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(s.ops) });
    } else {
      const s = [], o = t;
      if (o.length) {
        const l = typeof o[0][0] == "number" ? [o] : o;
        for (const c of l) c.length < 3 ? s.push(...c) : c.length === 3 ? s.push(...Cs(ch([c[0], c[0], c[1], c[2]]), 10, (1 + i.roughness) / 2)) : s.push(...Cs(ch(c), 10, (1 + i.roughness) / 2));
      }
      s.length && n.push(Lr([s], i));
    }
    return i.stroke !== Zt && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = On(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(bs([t], i)) : n.push(Lr([t], i))), i.stroke !== Zt && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== Zt, s = i.stroke !== Zt, o = !!(i.simplification && i.simplification < 1), l = (function(h, u, d) {
      const f = Sp(vp(bl(h))), g = [];
      let m = [], y = [0, 0], x = [];
      const b = () => {
        x.length >= 4 && m.push(...Cs(x, u)), x = [];
      }, _ = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: k, data: T } of f) switch (k) {
        case "M":
          _(), y = [T[0], T[1]], m.push(y);
          break;
        case "L":
          b(), m.push([T[0], T[1]]);
          break;
        case "C":
          if (!x.length) {
            const B = m.length ? m[m.length - 1] : y;
            x.push([B[0], B[1]]);
          }
          x.push([T[0], T[1]]), x.push([T[2], T[3]]), x.push([T[4], T[5]]);
          break;
        case "Z":
          b(), m.push([y[0], y[1]]);
      }
      if (_(), !d) return g;
      const v = [];
      for (const k of g) {
        const T = Fv(k, d);
        T.length && v.push(T);
      }
      return v;
    })(t, 1, o ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), c = ah(t, i);
    if (a) if (i.fillStyle === "solid") if (l.length === 1) {
      const h = ah(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(bs(l, i));
    else n.push(Lr(l, i));
    return s && (o ? l.forEach(((h) => {
      n.push(On(h, !1, i));
    })) : n.push(c)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map(((s) => +s.toFixed(r))) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let s = null;
      switch (a.type) {
        case "path":
          s = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: Zt };
          break;
        case "fillPath":
          s = { d: this.opsToPath(a), stroke: Zt, strokeWidth: 0, fill: i.fill || Zt };
          break;
        case "fillSketch":
          s = this.fillSketch(a, i);
      }
      s && n.push(s);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || Zt, strokeWidth: i, fill: Zt };
  }
  _mergedShape(t) {
    return t.filter(((r, i) => i === 0 || r.op !== "move"));
  }
}
class Dv {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new xa(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const s of r) switch (s.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, s, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const o = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, s, a, o), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, s, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const s = typeof i == "number" && i >= 0 ? a.data.map(((o) => +o.toFixed(i))) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(s[0], s[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(s[0], s[1], s[2], s[3], s[4], s[5]);
          break;
        case "lineTo":
          t.lineTo(s[0], s[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const s = this.gen.line(t, r, i, n, a);
    return this.draw(s), s;
  }
  rectangle(t, r, i, n, a) {
    const s = this.gen.rectangle(t, r, i, n, a);
    return this.draw(s), s;
  }
  ellipse(t, r, i, n, a) {
    const s = this.gen.ellipse(t, r, i, n, a);
    return this.draw(s), s;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, s, o = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, s, o, l);
    return this.draw(c), c;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const kn = "http://www.w3.org/2000/svg";
class Ov {
  constructor(t, r) {
    this.svg = t, this.gen = new xa(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(kn, "g"), s = t.options.fixedDecimalPlaceDigits;
    for (const o of r) {
      let l = null;
      switch (o.type) {
        case "path":
          l = n.createElementNS(kn, "path"), l.setAttribute("d", this.opsToPath(o, s)), l.setAttribute("stroke", i.stroke), l.setAttribute("stroke-width", i.strokeWidth + ""), l.setAttribute("fill", "none"), i.strokeLineDash && l.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && l.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          l = n.createElementNS(kn, "path"), l.setAttribute("d", this.opsToPath(o, s)), l.setAttribute("stroke", "none"), l.setAttribute("stroke-width", "0"), l.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || l.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          l = this.fillSketch(n, o, i);
      }
      l && a.appendChild(l);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(kn, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const s = this.gen.line(t, r, i, n, a);
    return this.draw(s);
  }
  rectangle(t, r, i, n, a) {
    const s = this.gen.rectangle(t, r, i, n, a);
    return this.draw(s);
  }
  ellipse(t, r, i, n, a) {
    const s = this.gen.ellipse(t, r, i, n, a);
    return this.draw(s);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, s, o = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, s, o, l);
    return this.draw(c);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var j = { canvas: (e, t) => new Dv(e, t), svg: (e, t) => new Ov(e, t), generator: (e) => new xa(e), newSeed: () => xa.newSeed() }, it = /* @__PURE__ */ p(async (e, t, r) => {
  let i;
  const n = t.useHtmlLabels || Ze(ft()?.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), s = a.insert("g").attr("class", "label").attr("style", Rt(t.labelStyle));
  let o;
  t.label === void 0 ? o = "" : o = typeof t.label == "string" ? t.label : t.label[0];
  const l = !!t.icon || !!t.img, c = t.labelType === "markdown", h = await Pe(
    s,
    fe(Jr(o), ft()),
    {
      useHtmlLabels: n,
      width: t.width || ft().flowchart?.wrappingWidth,
      // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
      cssClasses: c ? "markdown-node-label" : void 0,
      style: t.labelStyle,
      addSvgBackground: l,
      markdown: c
    },
    ft()
  );
  let u = h.getBBox();
  const d = (t?.padding ?? 0) / 2;
  if (n) {
    const f = h.children[0], g = lt(h);
    await Vd(f, o), u = f.getBoundingClientRect(), g.attr("width", u.width), g.attr("height", u.height);
  }
  return n ? s.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")") : s.attr("transform", "translate(0, " + -u.height / 2 + ")"), t.centerLabel && s.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), s.insert("rect", ":first-child"), { shapeSvg: a, bbox: u, halfPadding: d, label: s };
}, "labelHelper"), _s = /* @__PURE__ */ p(async (e, t, r) => {
  const i = r.useHtmlLabels ?? It(ft()), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Pe(n, fe(Jr(t), ft()), {
    useHtmlLabels: i,
    width: r.width || ft()?.flowchart?.wrappingWidth,
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let s = a.getBBox();
  const o = r.padding / 2;
  if (It(ft())) {
    const l = a.children[0], c = lt(a);
    s = l.getBoundingClientRect(), c.attr("width", s.width), c.attr("height", s.height);
  }
  return i ? n.attr("transform", "translate(" + -s.width / 2 + ", " + -s.height / 2 + ")") : n.attr("transform", "translate(0, " + -s.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -s.width / 2 + ", " + -s.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: s, halfPadding: o, label: n };
}, "insertLabel"), V = /* @__PURE__ */ p((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), rt = /* @__PURE__ */ p((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function ht(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
p(ht, "createPathFromPoints");
function Ve(e, t, r, i, n, a) {
  const s = [], l = r - e, c = i - t, h = l / a, u = 2 * Math.PI / h, d = t + c / 2;
  for (let f = 0; f <= 50; f++) {
    const g = f / 50, m = e + g * l, y = d + n * Math.sin(u * (m - e));
    s.push({ x: m, y });
  }
  return s;
}
p(Ve, "generateFullSineWavePoints");
function ji(e, t, r, i, n, a) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const d = o + u * h, f = e + r * Math.cos(d), g = t + r * Math.sin(d);
    s.push({ x: -f, y: -g });
  }
  return s;
}
p(ji, "generateCirclePoints");
var Rv = /* @__PURE__ */ p((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, s = e.width / 2, o = e.height / 2, l, c;
  return Math.abs(a) * s > Math.abs(n) * o ? (a < 0 && (o = -o), l = a === 0 ? 0 : o * n / a, c = o) : (n < 0 && (s = -s), l = s, c = n === 0 ? 0 : s * a / n), { x: r + l, y: i + c };
}, "intersectRect"), ei = Rv, Iv = /* @__PURE__ */ p(async (e, t, r, i = !1, n = !1) => {
  let a = t || "";
  typeof a == "object" && (a = a[0]);
  const s = ft(), o = It(s);
  return await Pe(
    e,
    a,
    {
      style: r,
      isTitle: i,
      useHtmlLabels: o,
      markdown: !1,
      isNode: n,
      width: Number.POSITIVE_INFINITY
    },
    s
  );
}, "createLabel"), He = Iv, Qe = /* @__PURE__ */ p((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), Mp = /* @__PURE__ */ p(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: s } = i, { labelStyles: o, nodeStyles: l, borderStyles: c, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), d = It(r), f = u.insert("g").attr("class", "cluster-label ");
  let g;
  t.labelType === "markdown" ? g = await Pe(f, t.label, {
    style: t.labelStyle,
    useHtmlLabels: d,
    isNode: !0,
    width: t.width
  }) : g = await He(f, t.label, t.labelStyle || "", !1, !0);
  let m = g.getBBox();
  if (It(r)) {
    const B = g.children[0], D = lt(g);
    m = B.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let v;
  if (t.look === "handDrawn") {
    const B = j.svg(u), D = U(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: s,
      fillWeight: 3,
      seed: n
    }), I = B.path(Qe(b, _, y, x, 0), D);
    v = u.insert(() => (F.debug("Rough node insert CXC", I), I), ":first-child"), v.select("path:nth-child(2)").attr("style", c.join(";")), v.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    v = u.insert("rect", ":first-child"), v.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: k } = ol(r);
  if (f.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + k})`
  ), o) {
    const B = f.select("span");
    B && B.attr("style", o);
  }
  const T = v.node().getBBox();
  return t.offsetX = 0, t.width = T.width, t.height = T.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(B) {
    return ei(t, B);
  }, { cluster: u, labelBBox: m };
}, "rect"), Pv = /* @__PURE__ */ p((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const s = i.node().getBBox();
  return t.width = s.width, t.height = s.height, t.intersect = function(o) {
    return ei(t, o);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), Nv = /* @__PURE__ */ p(async (e, t) => {
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: s, compositeTitleBackground: o, nodeBorder: l } = i, c = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = c.insert("g", ":first-child"), u = c.insert("g").attr("class", "cluster-label");
  let d = c.append("rect");
  const f = await He(u, t.label, t.labelStyle, void 0, !0);
  let g = f.getBBox();
  if (It(r)) {
    const I = f.children[0], O = lt(f);
    g = I.getBoundingClientRect(), O.attr("width", g.width), O.attr("height", g.height);
  }
  const m = 0 * t.padding, y = m / 2, x = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, _ = t.height + m - g.height - 6, v = t.x - x / 2, k = t.y - b / 2;
  t.width = x;
  const T = t.y - t.height / 2 - y + g.height + 2;
  let B;
  if (t.look === "handDrawn") {
    const I = t.cssClasses.includes("statediagram-cluster-alt"), O = j.svg(c), $ = t.rx || t.ry ? O.path(Qe(v, k, x, b, 10), {
      roughness: 0.7,
      fill: o,
      fillStyle: "solid",
      stroke: l,
      seed: n
    }) : O.rectangle(v, k, x, b, { seed: n });
    B = c.insert(() => $, ":first-child");
    const N = O.rectangle(v, T, x, _, {
      fill: I ? a : s,
      fillStyle: I ? "hachure" : "solid",
      stroke: l,
      seed: n
    });
    B = c.insert(() => $, ":first-child"), d = c.insert(() => N);
  } else
    B = h.insert("rect", ":first-child"), B.attr("class", "outer").attr("x", v).attr("y", k).attr("width", x).attr("height", b).attr("data-look", t.look), d.attr("class", "inner").attr("x", v).attr("y", T).attr("width", x).attr("height", _);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${k + 1 - (It(r) ? 0 : 3)})`
  );
  const D = B.node().getBBox();
  return t.height = D.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(I) {
    return ei(t, I);
  }, { cluster: c, labelBBox: g };
}, "roundedWithTitle"), zv = /* @__PURE__ */ p(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: s } = i, { labelStyles: o, nodeStyles: l, borderStyles: c, backgroundStyles: h } = G(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), d = It(r), f = u.insert("g").attr("class", "cluster-label "), g = await Pe(f, t.label, {
    style: t.labelStyle,
    useHtmlLabels: d,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (It(r)) {
    const B = g.children[0], D = lt(g);
    m = B.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const y = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const x = t.height, b = t.x - y / 2, _ = t.y - x / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let v;
  if (t.look === "handDrawn") {
    const B = j.svg(u), D = U(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: s,
      fillWeight: 4,
      seed: n
    }), I = B.path(Qe(b, _, y, x, t.rx), D);
    v = u.insert(() => (F.debug("Rough node insert CXC", I), I), ":first-child"), v.select("path:nth-child(2)").attr("style", c.join(";")), v.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    v = u.insert("rect", ":first-child"), v.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", _).attr("width", y).attr("height", x);
  const { subGraphTitleTopMargin: k } = ol(r);
  if (f.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + k})`
  ), o) {
    const B = f.select("span");
    B && B.attr("style", o);
  }
  const T = v.node().getBBox();
  return t.offsetX = 0, t.width = T.width, t.height = T.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(B) {
    return ei(t, B);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), Wv = /* @__PURE__ */ p((e, t) => {
  const r = ft(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, s = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), o = s.insert("g", ":first-child"), l = 0 * t.padding, c = t.width + l;
  t.diff = -t.padding;
  const h = t.height + l, u = t.x - c / 2, d = t.y - h / 2;
  t.width = c;
  let f;
  if (t.look === "handDrawn") {
    const y = j.svg(s).rectangle(u, d, c, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    f = s.insert(() => y, ":first-child");
  } else
    f = o.insert("rect", ":first-child"), f.attr("class", "divider").attr("x", u).attr("y", d).attr("width", c).attr("height", h).attr("data-look", t.look);
  const g = f.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return ei(t, m);
  }, { cluster: s, labelBBox: {} };
}, "divider"), qv = Mp, Hv = {
  rect: Mp,
  squareRect: qv,
  roundedWithTitle: Nv,
  noteGroup: Pv,
  divider: Wv,
  kanbanSection: zv
}, $p = /* @__PURE__ */ new Map(), jv = /* @__PURE__ */ p(async (e, t) => {
  const r = t.shape || "rect", i = await Hv[r](e, t);
  return $p.set(t.id, i), i;
}, "insertCluster"), BA = /* @__PURE__ */ p(() => {
  $p = /* @__PURE__ */ new Map();
}, "clear");
function Ep(e, t) {
  return e.intersect(t);
}
p(Ep, "intersectNode");
var Yv = Ep;
function Fp(e, t, r, i) {
  var n = e.x, a = e.y, s = n - i.x, o = a - i.y, l = Math.sqrt(t * t * o * o + r * r * s * s), c = Math.abs(t * r * s / l);
  i.x < n && (c = -c);
  var h = Math.abs(t * r * o / l);
  return i.y < a && (h = -h), { x: n + c, y: a + h };
}
p(Fp, "intersectEllipse");
var Dp = Fp;
function Op(e, t, r) {
  return Dp(e, t, t, r);
}
p(Op, "intersectCircle");
var Uv = Op;
function Rp(e, t, r, i) {
  {
    const n = t.y - e.y, a = e.x - t.x, s = t.x * e.y - e.x * t.y, o = n * r.x + a * r.y + s, l = n * i.x + a * i.y + s, c = 1e-6;
    if (o !== 0 && l !== 0 && fo(o, l))
      return;
    const h = i.y - r.y, u = r.x - i.x, d = i.x * r.y - r.x * i.y, f = h * e.x + u * e.y + d, g = h * t.x + u * t.y + d;
    if (Math.abs(f) < c && Math.abs(g) < c && fo(f, g))
      return;
    const m = n * u - h * a;
    if (m === 0)
      return;
    const y = Math.abs(m / 2);
    let x = a * d - u * s;
    const b = x < 0 ? (x - y) / m : (x + y) / m;
    x = h * s - n * d;
    const _ = x < 0 ? (x - y) / m : (x + y) / m;
    return { x: b, y: _ };
  }
}
p(Rp, "intersectLine");
function fo(e, t) {
  return e * t > 0;
}
p(fo, "sameSign");
var Gv = Rp;
function Ip(e, t, r) {
  let i = e.x, n = e.y, a = [], s = Number.POSITIVE_INFINITY, o = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    s = Math.min(s, h.x), o = Math.min(o, h.y);
  }) : (s = Math.min(s, t.x), o = Math.min(o, t.y));
  let l = i - e.width / 2 - s, c = n - e.height / 2 - o;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], d = t[h < t.length - 1 ? h + 1 : 0], f = Gv(
      e,
      r,
      { x: l + u.x, y: c + u.y },
      { x: l + d.x, y: c + d.y }
    );
    f && a.push(f);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let d = h.x - r.x, f = h.y - r.y, g = Math.sqrt(d * d + f * f), m = u.x - r.x, y = u.y - r.y, x = Math.sqrt(m * m + y * y);
    return g < x ? -1 : g === x ? 0 : 1;
  }), a[0]) : e;
}
p(Ip, "intersectPolygon");
var Xv = Ip, W = {
  node: Yv,
  circle: Uv,
  ellipse: Dp,
  polygon: Xv,
  rect: ei
};
function Pp(e, t) {
  const { labelStyles: r } = G(t);
  t.labelStyle = r;
  const i = rt(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), s = 1, { cssStyles: o } = t, l = j.svg(a), c = U(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (c.roughness = 0);
  const h = l.circle(0, 0, s * 2, c), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", Rt(o)), V(t, u), t.intersect = function(d) {
    return F.info("Circle intersect", t, s, d), W.circle(t, s, d);
  }, a;
}
p(Pp, "anchor");
function po(e, t, r, i, n, a, s) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, d = (i - t) / 2, f = u / n, g = d / a, m = Math.sqrt(f ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const y = Math.sqrt(1 - m ** 2), x = l + y * a * Math.sin(h) * (s ? -1 : 1), b = c - y * n * Math.cos(h) * (s ? -1 : 1), _ = Math.atan2((t - b) / a, (e - x) / n);
  let k = Math.atan2((i - b) / a, (r - x) / n) - _;
  s && k < 0 && (k += 2 * Math.PI), !s && k > 0 && (k -= 2 * Math.PI);
  const T = [];
  for (let B = 0; B < 20; B++) {
    const D = B / 19, I = _ + D * k, O = x + n * Math.cos(I), $ = b + a * Math.sin(I);
    T.push({ x: O, y: $ });
  }
  return T;
}
p(po, "generateArcPoints");
async function Np(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.width + t.padding + 20, o = a.height + t.padding, l = o / 2, c = l / (2.5 + o / 50), { cssStyles: h } = t, u = [
    { x: s / 2, y: -o / 2 },
    { x: -s / 2, y: -o / 2 },
    ...po(-s / 2, -o / 2, -s / 2, o / 2, c, l, !1),
    { x: s / 2, y: o / 2 },
    ...po(s / 2, o / 2, s / 2, -o / 2, c, l, !0)
  ], d = j.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = ht(u), m = d.path(g, f), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(${c / 2}, 0)`), V(t, y), t.intersect = function(x) {
    return W.polygon(t, u, x);
  }, n;
}
p(Np, "bowTieRect");
function Ne(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
p(Ne, "insertPolygonShape");
async function zp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.height + t.padding, o = 12, l = a.width + t.padding + o, c = 0, h = l, u = -s, d = 0, f = [
    { x: c + o, y: u },
    { x: h, y: u },
    { x: h, y: d },
    { x: c, y: d },
    { x: c, y: u + o },
    { x: c + o, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const y = j.svg(n), x = U(t, {}), b = ht(f), _ = y.path(b, x);
    g = n.insert(() => _, ":first-child").attr("transform", `translate(${-l / 2}, ${s / 2})`), m && g.attr("style", m);
  } else
    g = Ne(n, l, s, f);
  return i && g.attr("style", i), V(t, g), t.intersect = function(y) {
    return W.polygon(t, f, y);
  }, n;
}
p(zp, "card");
function Wp(e, t) {
  const { nodeStyles: r } = G(t);
  t.label = "";
  const i = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), s = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], o = j.svg(i), l = U(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = ht(s), h = o.path(c, l), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(d) {
    return W.polygon(t, s, d);
  }, i;
}
p(Wp, "choice");
async function Cl(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: s, halfPadding: o } = await it(e, t, rt(t)), l = r?.padding ?? o, c = s.width / 2 + l;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const d = j.svg(a), f = U(t, {}), g = d.circle(0, 0, c * 2, f);
    h = a.insert(() => g, ":first-child"), h.attr("class", "basic label-container").attr("style", Rt(u));
  } else
    h = a.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", n).attr("r", c).attr("cx", 0).attr("cy", 0);
  return V(t, h), t.calcIntersect = function(d, f) {
    const g = d.width / 2;
    return W.circle(d, g, f);
  }, t.intersect = function(d) {
    return F.info("Circle intersect", t, c, d), W.circle(t, c, d);
  }, a;
}
p(Cl, "circle");
function qp(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, s = { x: -(i / 2) * t, y: -(i / 2) * r }, o = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${o.x},${o.y}
                   M ${n.x},${n.y} L ${s.x},${s.y}`;
}
p(qp, "createLine");
function Hp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), a = Math.max(30, t?.width ?? 0), { cssStyles: s } = t, o = j.svg(n), l = U(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = o.circle(0, 0, a * 2, l), h = qp(a), u = o.path(h, l), d = n.insert(() => c, ":first-child");
  return d.insert(() => u), s && t.look !== "handDrawn" && d.selectAll("path").attr("style", s), i && t.look !== "handDrawn" && d.selectAll("path").attr("style", i), V(t, d), t.intersect = function(f) {
    return F.info("crossedCircle intersect", t, { radius: a, point: f }), W.circle(t, a, f);
  }, n;
}
p(Hp, "crossedCircle");
function Me(e, t, r, i = 100, n = 0, a = 180) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const d = o + u * h, f = e + r * Math.cos(d), g = t + r * Math.sin(d);
    s.push({ x: -f, y: -g });
  }
  return s;
}
p(Me, "generateCirclePoints");
async function jp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...Me(o / 2, -l / 2, c, 30, -90, 0),
    { x: -o / 2 - c, y: c },
    ...Me(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...Me(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: -l / 2 },
    ...Me(o / 2, l / 2, c, 20, 0, 90)
  ], d = [
    { x: o / 2, y: -l / 2 - c },
    { x: -o / 2, y: -l / 2 - c },
    ...Me(o / 2, -l / 2, c, 20, -90, 0),
    { x: -o / 2 - c, y: -c },
    ...Me(o / 2 + o * 0.1, -c, c, 20, -180, -270),
    ...Me(o / 2 + o * 0.1, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: l / 2 },
    ...Me(o / 2, l / 2, c, 20, 0, 90),
    { x: -o / 2, y: l / 2 + c },
    { x: o / 2, y: l / 2 + c }
  ], f = j.svg(n), g = U(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = ht(u).replace("Z", ""), x = f.path(y, g), b = ht(d), _ = f.path(b, { ...g }), v = n.insert("g", ":first-child");
  return v.insert(() => _, ":first-child").attr("stroke-opacity", 0), v.insert(() => x, ":first-child"), v.attr("class", "text"), h && t.look !== "handDrawn" && v.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), v.attr("transform", `translate(${c}, 0)`), s.attr(
    "transform",
    `translate(${-o / 2 + c - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, v), t.intersect = function(k) {
    return W.polygon(t, d, k);
  }, n;
}
p(jp, "curlyBraceLeft");
function $e(e, t, r, i = 100, n = 0, a = 180) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const d = o + u * h, f = e + r * Math.cos(d), g = t + r * Math.sin(d);
    s.push({ x: f, y: g });
  }
  return s;
}
p($e, "generateCirclePoints");
async function Yp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...$e(o / 2, -l / 2, c, 20, -90, 0),
    { x: o / 2 + c, y: -c },
    ...$e(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...$e(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: o / 2 + c, y: l / 2 },
    ...$e(o / 2, l / 2, c, 20, 0, 90)
  ], d = [
    { x: -o / 2, y: -l / 2 - c },
    { x: o / 2, y: -l / 2 - c },
    ...$e(o / 2, -l / 2, c, 20, -90, 0),
    { x: o / 2 + c, y: -c },
    ...$e(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...$e(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: o / 2 + c, y: l / 2 },
    ...$e(o / 2, l / 2, c, 20, 0, 90),
    { x: o / 2, y: l / 2 + c },
    { x: -o / 2, y: l / 2 + c }
  ], f = j.svg(n), g = U(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = ht(u).replace("Z", ""), x = f.path(y, g), b = ht(d), _ = f.path(b, { ...g }), v = n.insert("g", ":first-child");
  return v.insert(() => _, ":first-child").attr("stroke-opacity", 0), v.insert(() => x, ":first-child"), v.attr("class", "text"), h && t.look !== "handDrawn" && v.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), v.attr("transform", `translate(${-c}, 0)`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, v), t.intersect = function(k) {
    return W.polygon(t, d, k);
  }, n;
}
p(Yp, "curlyBraceRight");
function At(e, t, r, i = 100, n = 0, a = 180) {
  const s = [], o = n * Math.PI / 180, h = (a * Math.PI / 180 - o) / (i - 1);
  for (let u = 0; u < i; u++) {
    const d = o + u * h, f = e + r * Math.cos(d), g = t + r * Math.sin(d);
    s.push({ x: -f, y: -g });
  }
  return s;
}
p(At, "generateCirclePoints");
async function Up(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...At(o / 2, -l / 2, c, 30, -90, 0),
    { x: -o / 2 - c, y: c },
    ...At(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...At(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: -l / 2 },
    ...At(o / 2, l / 2, c, 20, 0, 90)
  ], d = [
    ...At(-o / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: o / 2 - c / 2, y: c },
    ...At(-o / 2 - c / 2, -c, c, 20, 0, 90),
    ...At(-o / 2 - c / 2, c, c, 20, -90, 0),
    { x: o / 2 - c / 2, y: -c },
    ...At(-o / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], f = [
    { x: o / 2, y: -l / 2 - c },
    { x: -o / 2, y: -l / 2 - c },
    ...At(o / 2, -l / 2, c, 20, -90, 0),
    { x: -o / 2 - c, y: -c },
    ...At(o / 2 + c * 2, -c, c, 20, -180, -270),
    ...At(o / 2 + c * 2, c, c, 20, -90, -180),
    { x: -o / 2 - c, y: l / 2 },
    ...At(o / 2, l / 2, c, 20, 0, 90),
    { x: -o / 2, y: l / 2 + c },
    { x: o / 2 - c - c / 2, y: l / 2 + c },
    ...At(-o / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: o / 2 - c / 2, y: c },
    ...At(-o / 2 - c / 2, -c, c, 20, 0, 90),
    ...At(-o / 2 - c / 2, c, c, 20, -90, 0),
    { x: o / 2 - c / 2, y: -c },
    ...At(-o / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], g = j.svg(n), m = U(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = ht(u).replace("Z", ""), b = g.path(x, m), v = ht(d).replace("Z", ""), k = g.path(v, m), T = ht(f), B = g.path(T, { ...m }), D = n.insert("g", ":first-child");
  return D.insert(() => B, ":first-child").attr("stroke-opacity", 0), D.insert(() => b, ":first-child"), D.insert(() => k, ":first-child"), D.attr("class", "text"), h && t.look !== "handDrawn" && D.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(${c - c / 4}, 0)`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, D), t.intersect = function(I) {
    return W.polygon(t, f, I);
  }, n;
}
p(Up, "curlyBraces");
async function Gp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 80, o = 20, l = Math.max(s, (a.width + (t.padding ?? 0) * 2) * 1.25, t?.width ?? 0), c = Math.max(o, a.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = c / 2, { cssStyles: u } = t, d = j.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = l, m = c, y = g - h, x = m / 4, b = [
    { x: y, y: 0 },
    { x, y: 0 },
    { x: 0, y: m / 2 },
    { x, y: m },
    { x: y, y: m },
    ...ji(-y, -m / 2, h, 50, 270, 90)
  ], _ = ht(b), v = d.path(_, f), k = n.insert(() => v, ":first-child");
  return k.attr("class", "basic label-container"), u && t.look !== "handDrawn" && k.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && k.selectChildren("path").attr("style", i), k.attr("transform", `translate(${-l / 2}, ${-c / 2})`), V(t, k), t.intersect = function(T) {
    return W.polygon(t, b, T);
  }, n;
}
p(Gp, "curvedTrapezoid");
var Vv = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), Zv = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), Kv = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function Xp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + t.padding, t.width ?? 0), l = o / 2, c = l / (2.5 + o / 50), h = Math.max(a.height + c + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: d } = t;
  if (t.look === "handDrawn") {
    const f = j.svg(n), g = Zv(0, 0, o, h, l, c), m = Kv(0, c, o, h, l, c), y = f.path(g, U(t, {})), x = f.path(m, U(t, { fill: "none" }));
    u = n.insert(() => x, ":first-child"), u = n.insert(() => y, ":first-child"), u.attr("class", "basic label-container"), d && u.attr("style", d);
  } else {
    const f = Vv(0, 0, o, h, l, c);
    u = n.insert("path", ":first-child").attr("d", f).attr("class", "basic label-container").attr("style", Rt(d)).attr("style", i);
  }
  return u.attr("label-offset-y", c), u.attr("transform", `translate(${-o / 2}, ${-(h / 2 + c)})`), V(t, u), s.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(f) {
    const g = W.rect(t, f), m = g.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let y = c * c * (1 - m * m / (l * l));
      y > 0 && (y = Math.sqrt(y)), y = c - y, f.y - (t.y ?? 0) > 0 && (y = -y), g.y += y;
    }
    return g;
  }, n;
}
p(Xp, "cylinder");
async function Vp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + t.padding, l = a.height + t.padding, c = l * 0.2, h = -o / 2, u = -l / 2 - c / 2, { cssStyles: d } = t, f = j.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + c },
    { x: -h, y: u + c },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + c }
  ], y = f.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), d && t.look !== "handDrawn" && x.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + c + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return W.rect(t, b);
  }, n;
}
p(Vp, "dividedRectangle");
async function Zp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s } = await it(e, t, rt(t)), l = a.width / 2 + s + 5, c = a.width / 2 + s;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const d = j.svg(n), f = U(t, { roughness: 0.2, strokeWidth: 2.5 }), g = U(t, { roughness: 0.2, strokeWidth: 1.5 }), m = d.circle(0, 0, l * 2, f), y = d.circle(0, 0, c * 2, g);
    h = n.insert("g", ":first-child"), h.attr("class", Rt(t.cssClasses)).attr("style", Rt(u)), h.node()?.appendChild(m), h.node()?.appendChild(y);
  } else {
    h = n.insert("g", ":first-child");
    const d = h.insert("circle", ":first-child"), f = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), d.attr("class", "outer-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0), f.attr("class", "inner-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0);
  }
  return V(t, h), t.intersect = function(d) {
    return F.info("DoubleCircle intersect", t, l, d), W.circle(t, l, d);
  }, n;
}
p(Zp, "doublecircle");
function Kp(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), s = 7, { cssStyles: o } = t, l = j.svg(a), { nodeBorder: c } = r, h = U(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = l.circle(0, 0, s * 2, h), d = a.insert(() => u, ":first-child");
  return d.selectAll("path").attr("style", `fill: ${c} !important;`), o && o.length > 0 && t.look !== "handDrawn" && d.selectAll("path").attr("style", o), n && t.look !== "handDrawn" && d.selectAll("path").attr("style", n), V(t, d), t.intersect = function(f) {
    return F.info("filledCircle intersect", t, { radius: s, point: f }), W.circle(t, s, f);
  }, a;
}
p(Kp, "filledCircle");
async function Qp(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = a.width + (t.padding ?? 0), l = o + a.height, c = o + a.height, h = [
    { x: 0, y: -l },
    { x: c, y: -l },
    { x: c / 2, y: 0 }
  ], { cssStyles: u } = t, d = j.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = ht(h), m = d.path(g, f), y = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = o, t.height = l, V(t, y), s.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-l / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(x) {
    return F.info("Triangle intersect", t, h, x), W.polygon(t, h, x);
  }, n;
}
p(Qp, "flippedTriangle");
function Jp(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = G(t);
  t.label = "";
  const s = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), { cssStyles: o } = t;
  let l = Math.max(70, t?.width ?? 0), c = Math.max(10, t?.height ?? 0);
  r === "LR" && (l = Math.max(10, t?.width ?? 0), c = Math.max(70, t?.height ?? 0));
  const h = -1 * l / 2, u = -1 * c / 2, d = j.svg(s), f = U(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = d.rectangle(h, u, l, c, f), m = s.insert(() => g, ":first-child");
  o && t.look !== "handDrawn" && m.selectAll("path").attr("style", o), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), V(t, m);
  const y = i?.padding ?? 0;
  return t.width && t.height && (t.width += y / 2 || 0, t.height += y / 2 || 0), t.intersect = function(x) {
    return W.rect(t, x);
  }, s;
}
p(Jp, "forkJoin");
async function tg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: s, bbox: o } = await it(e, t, rt(t)), l = Math.max(n, o.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(a, o.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = c / 2, { cssStyles: u } = t, d = j.svg(s), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = [
    { x: -l / 2, y: -c / 2 },
    { x: l / 2 - h, y: -c / 2 },
    ...ji(-l / 2 + h, 0, h, 50, 90, 270),
    { x: l / 2 - h, y: c / 2 },
    { x: -l / 2, y: c / 2 }
  ], m = ht(g), y = d.path(m, f), x = s.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), V(t, x), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), W.polygon(t, g, b);
  }, s;
}
p(tg, "halfRoundedRectangle");
var Qv = /* @__PURE__ */ p((e, t, r, i, n) => [
  `M${e + n},${t}`,
  `L${e + r - n},${t}`,
  `L${e + r},${t - i / 2}`,
  `L${e + r - n},${t - i}`,
  `L${e + n},${t - i}`,
  `L${e},${t - i / 2}`,
  "Z"
].join(" "), "createHexagonPathD");
async function eg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 4, o = a.height + t.padding, l = o / s, c = a.width + 2 * l + t.padding, h = [
    { x: l, y: 0 },
    { x: c - l, y: 0 },
    { x: c, y: -o / 2 },
    { x: c - l, y: -o },
    { x: l, y: -o },
    { x: 0, y: -o / 2 }
  ];
  let u;
  const { cssStyles: d } = t;
  if (t.look === "handDrawn") {
    const f = j.svg(n), g = U(t, {}), m = Qv(0, 0, c, o, l), y = f.path(m, g);
    u = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2}, ${o / 2})`), d && u.attr("style", d);
  } else
    u = Ne(n, c, o, h);
  return i && u.attr("style", i), t.width = c, t.height = o, V(t, u), t.intersect = function(f) {
    return W.polygon(t, h, f);
  }, n;
}
p(eg, "hexagon");
async function rg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await it(e, t, rt(t)), a = Math.max(30, t?.width ?? 0), s = Math.max(30, t?.height ?? 0), { cssStyles: o } = t, l = j.svg(n), c = U(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: s },
    { x: a, y: s }
  ], u = ht(h), d = l.path(u, c), f = n.insert(() => d, ":first-child");
  return f.attr("class", "basic label-container"), o && t.look !== "handDrawn" && f.selectChildren("path").attr("style", o), i && t.look !== "handDrawn" && f.selectChildren("path").attr("style", i), f.attr("transform", `translate(${-a / 2}, ${-s / 2})`), V(t, f), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), W.polygon(t, h, g);
  }, n;
}
p(rg, "hourglass");
async function ig(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await it(e, t, "icon-shape default"), d = t.pos === "t", f = o, g = o, { nodeBorder: m } = r, { stylesMap: y } = ti(t), x = -g / 2, b = -f / 2, _ = t.label ? 8 : 0, v = j.svg(c), k = U(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid");
  const T = v.rectangle(x, b, g, f, k), B = Math.max(g, h.width), D = f + h.height + _, I = v.rectangle(-B / 2, -D / 2, B, D, {
    ...k,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => T, ":first-child"), $ = c.insert(() => I);
  if (t.icon) {
    const N = c.append("g");
    N.html(
      `<g>${await rn(t.icon, {
        height: o,
        width: o,
        fallbackPrefix: ""
      })}</g>`
    );
    const R = N.node().getBBox(), A = R.width, L = R.height, S = R.x, E = R.y;
    N.attr(
      "transform",
      `translate(${-A / 2 - S},${d ? h.height / 2 + _ / 2 - L / 2 - E : -h.height / 2 - _ / 2 - L / 2 - E})`
    ), N.attr("style", `color: ${y.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${d ? -D / 2 : D / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${d ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), V(t, $), t.intersect = function(N) {
    if (F.info("iconSquare intersect", t, N), !t.label)
      return W.rect(t, N);
    const R = t.x ?? 0, A = t.y ?? 0, L = t.height ?? 0;
    let S = [];
    return d ? S = [
      { x: R - h.width / 2, y: A - L / 2 },
      { x: R + h.width / 2, y: A - L / 2 },
      { x: R + h.width / 2, y: A - L / 2 + h.height + _ },
      { x: R + g / 2, y: A - L / 2 + h.height + _ },
      { x: R + g / 2, y: A + L / 2 },
      { x: R - g / 2, y: A + L / 2 },
      { x: R - g / 2, y: A - L / 2 + h.height + _ },
      { x: R - h.width / 2, y: A - L / 2 + h.height + _ }
    ] : S = [
      { x: R - g / 2, y: A - L / 2 },
      { x: R + g / 2, y: A - L / 2 },
      { x: R + g / 2, y: A - L / 2 + f },
      { x: R + h.width / 2, y: A - L / 2 + f },
      { x: R + h.width / 2 / 2, y: A + L / 2 },
      { x: R - h.width / 2, y: A + L / 2 },
      { x: R - h.width / 2, y: A - L / 2 + f },
      { x: R - g / 2, y: A - L / 2 + f }
    ], W.polygon(t, S, N);
  }, c;
}
p(ig, "icon");
async function ng(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await it(e, t, "icon-shape default"), d = 20, f = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: y } = r, { stylesMap: x } = ti(t), b = j.svg(c), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const v = x.get("fill");
  _.stroke = v ?? y;
  const k = c.append("g");
  t.icon && k.html(
    `<g>${await rn(t.icon, {
      height: o,
      width: o,
      fallbackPrefix: ""
    })}</g>`
  );
  const T = k.node().getBBox(), B = T.width, D = T.height, I = T.x, O = T.y, $ = Math.max(B, D) * Math.SQRT2 + d * 2, N = b.circle(0, 0, $, _), R = Math.max($, h.width), A = $ + h.height + f, L = b.rectangle(-R / 2, -A / 2, R, A, {
    ..._,
    fill: "transparent",
    stroke: "none"
  }), S = c.insert(() => N, ":first-child"), E = c.insert(() => L);
  return k.attr(
    "transform",
    `translate(${-B / 2 - I},${g ? h.height / 2 + f / 2 - D / 2 - O : -h.height / 2 - f / 2 - D / 2 - O})`
  ), k.attr("style", `color: ${x.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -A / 2 : A / 2 - h.height})`
  ), S.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + f / 2 : -h.height / 2 - f / 2})`
  ), V(t, E), t.intersect = function(M) {
    return F.info("iconSquare intersect", t, M), W.rect(t, M);
  }, c;
}
p(ng, "iconCircle");
async function ag(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: d } = await it(
    e,
    t,
    "icon-shape default"
  ), f = t.pos === "t", g = o + u * 2, m = o + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = ti(t), _ = -m / 2, v = -g / 2, k = t.label ? 8 : 0, T = j.svg(c), B = U(t, {});
  t.look !== "handDrawn" && (B.roughness = 0, B.fillStyle = "solid");
  const D = b.get("fill");
  B.stroke = D ?? x;
  const I = T.path(Qe(_, v, m, g, 5), B), O = Math.max(m, h.width), $ = g + h.height + k, N = T.rectangle(-O / 2, -$ / 2, O, $, {
    ...B,
    fill: "transparent",
    stroke: "none"
  }), R = c.insert(() => I, ":first-child").attr("class", "icon-shape2"), A = c.insert(() => N);
  if (t.icon) {
    const L = c.append("g");
    L.html(
      `<g>${await rn(t.icon, {
        height: o,
        width: o,
        fallbackPrefix: ""
      })}</g>`
    );
    const S = L.node().getBBox(), E = S.width, M = S.height, q = S.x, Y = S.y;
    L.attr(
      "transform",
      `translate(${-E / 2 - q},${f ? h.height / 2 + k / 2 - M / 2 - Y : -h.height / 2 - k / 2 - M / 2 - Y})`
    ), L.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return d.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -$ / 2 : $ / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + k / 2 : -h.height / 2 - k / 2})`
  ), V(t, A), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return W.rect(t, L);
    const S = t.x ?? 0, E = t.y ?? 0, M = t.height ?? 0;
    let q = [];
    return f ? q = [
      { x: S - h.width / 2, y: E - M / 2 },
      { x: S + h.width / 2, y: E - M / 2 },
      { x: S + h.width / 2, y: E - M / 2 + h.height + k },
      { x: S + m / 2, y: E - M / 2 + h.height + k },
      { x: S + m / 2, y: E + M / 2 },
      { x: S - m / 2, y: E + M / 2 },
      { x: S - m / 2, y: E - M / 2 + h.height + k },
      { x: S - h.width / 2, y: E - M / 2 + h.height + k }
    ] : q = [
      { x: S - m / 2, y: E - M / 2 },
      { x: S + m / 2, y: E - M / 2 },
      { x: S + m / 2, y: E - M / 2 + g },
      { x: S + h.width / 2, y: E - M / 2 + g },
      { x: S + h.width / 2 / 2, y: E + M / 2 },
      { x: S - h.width / 2, y: E + M / 2 },
      { x: S - h.width / 2, y: E - M / 2 + g },
      { x: S - m / 2, y: E - M / 2 + g }
    ], W.polygon(t, q, L);
  }, c;
}
p(ag, "iconRounded");
async function sg(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, s = t.assetWidth ?? 48, o = Math.max(a, s), l = i?.wrappingWidth;
  t.width = Math.max(o, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: d } = await it(
    e,
    t,
    "icon-shape default"
  ), f = t.pos === "t", g = o + u * 2, m = o + u * 2, { nodeBorder: y, mainBkg: x } = r, { stylesMap: b } = ti(t), _ = -m / 2, v = -g / 2, k = t.label ? 8 : 0, T = j.svg(c), B = U(t, {});
  t.look !== "handDrawn" && (B.roughness = 0, B.fillStyle = "solid");
  const D = b.get("fill");
  B.stroke = D ?? x;
  const I = T.path(Qe(_, v, m, g, 0.1), B), O = Math.max(m, h.width), $ = g + h.height + k, N = T.rectangle(-O / 2, -$ / 2, O, $, {
    ...B,
    fill: "transparent",
    stroke: "none"
  }), R = c.insert(() => I, ":first-child"), A = c.insert(() => N);
  if (t.icon) {
    const L = c.append("g");
    L.html(
      `<g>${await rn(t.icon, {
        height: o,
        width: o,
        fallbackPrefix: ""
      })}</g>`
    );
    const S = L.node().getBBox(), E = S.width, M = S.height, q = S.x, Y = S.y;
    L.attr(
      "transform",
      `translate(${-E / 2 - q},${f ? h.height / 2 + k / 2 - M / 2 - Y : -h.height / 2 - k / 2 - M / 2 - Y})`
    ), L.attr("style", `color: ${b.get("stroke") ?? y};`);
  }
  return d.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -$ / 2 : $ / 2 - h.height})`
  ), R.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + k / 2 : -h.height / 2 - k / 2})`
  ), V(t, A), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return W.rect(t, L);
    const S = t.x ?? 0, E = t.y ?? 0, M = t.height ?? 0;
    let q = [];
    return f ? q = [
      { x: S - h.width / 2, y: E - M / 2 },
      { x: S + h.width / 2, y: E - M / 2 },
      { x: S + h.width / 2, y: E - M / 2 + h.height + k },
      { x: S + m / 2, y: E - M / 2 + h.height + k },
      { x: S + m / 2, y: E + M / 2 },
      { x: S - m / 2, y: E + M / 2 },
      { x: S - m / 2, y: E - M / 2 + h.height + k },
      { x: S - h.width / 2, y: E - M / 2 + h.height + k }
    ] : q = [
      { x: S - m / 2, y: E - M / 2 },
      { x: S + m / 2, y: E - M / 2 },
      { x: S + m / 2, y: E - M / 2 + g },
      { x: S + h.width / 2, y: E - M / 2 + g },
      { x: S + h.width / 2 / 2, y: E + M / 2 },
      { x: S - h.width / 2, y: E + M / 2 },
      { x: S - h.width / 2, y: E - M / 2 + g },
      { x: S - m / 2, y: E - M / 2 + g }
    ], W.polygon(t, q, L);
  }, c;
}
p(sg, "iconSquare");
async function og(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = t?.img ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: s } = G(t);
  t.labelStyle = s;
  const o = r?.wrappingWidth;
  t.defaultWidth = r?.wrappingWidth;
  const l = Math.max(
    t.label ? o ?? 0 : 0,
    t?.assetWidth ?? n
  ), c = t.constraint === "on" && t?.assetHeight ? t.assetHeight * t.imageAspectRatio : l, h = t.constraint === "on" ? c / t.imageAspectRatio : t?.assetHeight ?? a;
  t.width = Math.max(c, o ?? 0);
  const { shapeSvg: u, bbox: d, label: f } = await it(e, t, "image-shape default"), g = t.pos === "t", m = -c / 2, y = -h / 2, x = t.label ? 8 : 0, b = j.svg(u), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const v = b.rectangle(m, y, c, h, _), k = Math.max(c, d.width), T = h + d.height + x, B = b.rectangle(-k / 2, -T / 2, k, T, {
    ..._,
    fill: "none",
    stroke: "none"
  }), D = u.insert(() => v, ":first-child"), I = u.insert(() => B);
  if (t.img) {
    const O = u.append("image");
    O.attr("href", t.img), O.attr("width", c), O.attr("height", h), O.attr("preserveAspectRatio", "none"), O.attr(
      "transform",
      `translate(${-c / 2},${g ? T / 2 - h : -T / 2})`
    );
  }
  return f.attr(
    "transform",
    `translate(${-d.width / 2 - (d.x - (d.left ?? 0))},${g ? -h / 2 - d.height / 2 - x / 2 : h / 2 - d.height / 2 + x / 2})`
  ), D.attr(
    "transform",
    `translate(0,${g ? d.height / 2 + x / 2 : -d.height / 2 - x / 2})`
  ), V(t, I), t.intersect = function(O) {
    if (F.info("iconSquare intersect", t, O), !t.label)
      return W.rect(t, O);
    const $ = t.x ?? 0, N = t.y ?? 0, R = t.height ?? 0;
    let A = [];
    return g ? A = [
      { x: $ - d.width / 2, y: N - R / 2 },
      { x: $ + d.width / 2, y: N - R / 2 },
      { x: $ + d.width / 2, y: N - R / 2 + d.height + x },
      { x: $ + c / 2, y: N - R / 2 + d.height + x },
      { x: $ + c / 2, y: N + R / 2 },
      { x: $ - c / 2, y: N + R / 2 },
      { x: $ - c / 2, y: N - R / 2 + d.height + x },
      { x: $ - d.width / 2, y: N - R / 2 + d.height + x }
    ] : A = [
      { x: $ - c / 2, y: N - R / 2 },
      { x: $ + c / 2, y: N - R / 2 },
      { x: $ + c / 2, y: N - R / 2 + h },
      { x: $ + d.width / 2, y: N - R / 2 + h },
      { x: $ + d.width / 2 / 2, y: N + R / 2 },
      { x: $ - d.width / 2, y: N + R / 2 },
      { x: $ - d.width / 2, y: N - R / 2 + h },
      { x: $ - c / 2, y: N - R / 2 + h }
    ], W.polygon(t, A, O);
  }, u;
}
p(og, "imageSquare");
async function lg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), l = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s + 3 * o / 6, y: -o },
    { x: -3 * o / 6, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), d = U(t, {}), f = ht(l), g = u.path(f, d);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ne(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, V(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(lg, "inv_trapezoid");
async function an(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: s } = await it(e, t, rt(t)), o = Math.max(s.width + r.labelPaddingX * 2, t?.width || 0), l = Math.max(s.height + r.labelPaddingY * 2, t?.height || 0), c = -o / 2, h = -l / 2;
  let u, { rx: d, ry: f } = t;
  const { cssStyles: g } = t;
  if (r?.rx && r.ry && (d = r.rx, f = r.ry), t.look === "handDrawn") {
    const m = j.svg(a), y = U(t, {}), x = d || f ? m.path(Qe(c, h, o, l, d || 0), y) : m.rectangle(c, h, o, l, y);
    u = a.insert(() => x, ":first-child"), u.attr("class", "basic label-container").attr("style", Rt(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", Rt(d)).attr("ry", Rt(f)).attr("x", c).attr("y", h).attr("width", o).attr("height", l);
  return V(t, u), t.calcIntersect = function(m, y) {
    return W.rect(m, y);
  }, t.intersect = function(m) {
    return W.rect(t, m);
  }, a;
}
p(an, "drawRect");
async function cg(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await it(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), V(t, a), t.intersect = function(l) {
    return W.rect(t, l);
  }, r;
}
p(cg, "labelRect");
async function hg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0), t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0), t?.height ?? 0), l = [
    { x: 0, y: 0 },
    { x: s + 3 * o / 6, y: 0 },
    { x: s, y: -o },
    { x: -(3 * o) / 6, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), d = U(t, {}), f = ht(l), g = u.path(f, d);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ne(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, V(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(hg, "lean_left");
async function ug(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0), t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0), t?.height ?? 0), l = [
    { x: -3 * o / 6, y: 0 },
    { x: s, y: 0 },
    { x: s + 3 * o / 6, y: -o },
    { x: 0, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), d = U(t, {}), f = ht(l), g = u.path(f, d);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ne(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, V(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(ug, "lean_right");
function fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", rt(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, s = Math.max(35, t?.width ?? 0), o = Math.max(35, t?.height ?? 0), l = 7, c = [
    { x: s, y: 0 },
    { x: 0, y: o + l / 2 },
    { x: s - 2 * l, y: o + l / 2 },
    { x: 0, y: 2 * o },
    { x: s, y: o - l / 2 },
    { x: 2 * l, y: o - l / 2 }
  ], h = j.svg(n), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const d = ht(c), f = h.path(d, u), g = n.insert(() => f, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${s / 2},${-o})`), V(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), W.polygon(t, c, m);
  }, n;
}
p(fg, "lightningBolt");
var Jv = /* @__PURE__ */ p((e, t, r, i, n, a, s) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + s}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), tS = /* @__PURE__ */ p((e, t, r, i, n, a, s) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + s}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), eS = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function dg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), l = o / 2, c = l / (2.5 + o / 50), h = Math.max(a.height + c + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let d;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const g = j.svg(n), m = tS(0, 0, o, h, l, c, u), y = eS(0, c, o, h, l, c), x = U(t, {}), b = g.path(m, x), _ = g.path(y, x);
    n.insert(() => _, ":first-child").attr("class", "line"), d = n.insert(() => b, ":first-child"), d.attr("class", "basic label-container"), f && d.attr("style", f);
  } else {
    const g = Jv(0, 0, o, h, l, c, u);
    d = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", Rt(f)).attr("style", i);
  }
  return d.attr("label-offset-y", c), d.attr("transform", `translate(${-o / 2}, ${-(h / 2 + c)})`), V(t, d), s.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = W.rect(t, g), y = m.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(y) < (t.width ?? 0) / 2 || Math.abs(y) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let x = c * c * (1 - y * y / (l * l));
      x > 0 && (x = Math.sqrt(x)), x = c - x, g.y - (t.y ?? 0) > 0 && (x = -x), m.y += x;
    }
    return m;
  }, n;
}
p(dg, "linedCylinder");
async function pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 4, h = l + c, { cssStyles: u } = t, d = j.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = [
    { x: -o / 2 - o / 2 * 0.1, y: -h / 2 },
    { x: -o / 2 - o / 2 * 0.1, y: h / 2 },
    ...Ve(
      -o / 2 - o / 2 * 0.1,
      h / 2,
      o / 2 + o / 2 * 0.1,
      h / 2,
      c,
      0.8
    ),
    { x: o / 2 + o / 2 * 0.1, y: -h / 2 },
    { x: -o / 2 - o / 2 * 0.1, y: -h / 2 },
    { x: -o / 2, y: -h / 2 },
    { x: -o / 2, y: h / 2 * 1.1 },
    { x: -o / 2, y: -h / 2 }
  ], m = d.polygon(
    g.map((x) => [x.x, x.y]),
    f
  ), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), y.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) + o / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, y), t.intersect = function(x) {
    return W.polygon(t, g, x);
  }, n;
}
p(pg, "linedWaveEdgedRect");
async function gg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = 5, h = -o / 2, u = -l / 2, { cssStyles: d } = t, f = j.svg(n), g = U(t, {}), m = [
    { x: h - c, y: u + c },
    { x: h - c, y: u + l + c },
    { x: h + o - c, y: u + l + c },
    { x: h + o - c, y: u + l },
    { x: h + o, y: u + l },
    { x: h + o, y: u + l - c },
    { x: h + o + c, y: u + l - c },
    { x: h + o + c, y: u - c },
    { x: h + c, y: u - c },
    { x: h + c, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = [
    { x: h, y: u + c },
    { x: h + o - c, y: u + c },
    { x: h + o - c, y: u + l },
    { x: h + o, y: u + l },
    { x: h + o, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = ht(m), b = f.path(x, g), _ = ht(y), v = f.path(_, { ...g, fill: "none" }), k = n.insert(() => v, ":first-child");
  return k.insert(() => b, ":first-child"), k.attr("class", "basic label-container"), d && t.look !== "handDrawn" && k.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${-(a.width / 2) - c - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), V(t, k), t.intersect = function(T) {
    return W.polygon(t, m, T);
  }, n;
}
p(gg, "multiRect");
async function mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 4, h = l + c, u = -o / 2, d = -h / 2, f = 5, { cssStyles: g } = t, m = Ve(
    u - f,
    d + h + f,
    u + o - f,
    d + h + f,
    c,
    0.8
  ), y = m?.[m.length - 1], x = [
    { x: u - f, y: d + f },
    { x: u - f, y: d + h + f },
    ...m,
    { x: u + o - f, y: y.y - f },
    { x: u + o, y: y.y - f },
    { x: u + o, y: y.y - 2 * f },
    { x: u + o + f, y: y.y - 2 * f },
    { x: u + o + f, y: d - f },
    { x: u + f, y: d - f },
    { x: u + f, y: d },
    { x: u, y: d },
    { x: u, y: d + f }
  ], b = [
    { x: u, y: d + f },
    { x: u + o - f, y: d + f },
    { x: u + o - f, y: y.y - f },
    { x: u + o, y: y.y - f },
    { x: u + o, y: d },
    { x: u, y: d }
  ], _ = j.svg(n), v = U(t, {});
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const k = ht(x), T = _.path(k, v), B = ht(b), D = _.path(B, v), I = n.insert(() => T, ":first-child");
  return I.insert(() => D), I.attr("class", "basic label-container"), g && t.look !== "handDrawn" && I.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && I.selectAll("path").attr("style", i), I.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-(a.width / 2) - f - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + f - c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, I), t.intersect = function(O) {
    return W.polygon(t, x, O);
  }, n;
}
p(mg, "multiWaveEdgedRectangle");
async function yg(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i, t.useHtmlLabels || It(Dt()) || (t.centerLabel = !0);
  const { shapeSvg: s, bbox: o, label: l } = await it(e, t, rt(t)), c = Math.max(o.width + (t.padding ?? 0) * 2, t?.width ?? 0), h = Math.max(o.height + (t.padding ?? 0) * 2, t?.height ?? 0), u = -c / 2, d = -h / 2, { cssStyles: f } = t, g = j.svg(s), m = U(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = g.rectangle(u, d, c, h, m), x = s.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), f && t.look !== "handDrawn" && x.selectAll("path").attr("style", f), n && t.look !== "handDrawn" && x.selectAll("path").attr("style", n), l.attr(
    "transform",
    `translate(${-o.width / 2 - (o.x - (o.left ?? 0))}, ${-(o.height / 2) - (o.y - (o.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return W.rect(t, b);
  }, s;
}
p(yg, "note");
var rS = /* @__PURE__ */ p((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function xg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.width + t.padding, o = a.height + t.padding, l = s + o, c = 0.5, h = [
    { x: l / 2, y: 0 },
    { x: l, y: -l / 2 },
    { x: l / 2, y: -l },
    { x: 0, y: -l / 2 }
  ];
  let u;
  const { cssStyles: d } = t;
  if (t.look === "handDrawn") {
    const f = j.svg(n), g = U(t, {}), m = rS(0, 0, l), y = f.path(m, g);
    u = n.insert(() => y, ":first-child").attr("transform", `translate(${-l / 2 + c}, ${l / 2})`), d && u.attr("style", d);
  } else
    u = Ne(n, l, l, h), u.attr("transform", `translate(${-l / 2 + c}, ${l / 2})`);
  return i && u.attr("style", i), V(t, u), t.calcIntersect = function(f, g) {
    const m = f.width, y = [
      { x: m / 2, y: 0 },
      { x: m, y: -m / 2 },
      { x: m / 2, y: -m },
      { x: 0, y: -m / 2 }
    ], x = W.polygon(f, y, g);
    return { x: x.x - 0.5, y: x.y - 0.5 };
  }, t.intersect = function(f) {
    return this.calcIntersect(t, f);
  }, n;
}
p(xg, "question");
async function bg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0), t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0), t?.height ?? 0), c = -o / 2, h = -l / 2, u = h / 2, d = [
    { x: c + u, y: h },
    { x: c, y: 0 },
    { x: c + u, y: -h },
    { x: -c, y: -h },
    { x: -c, y: h }
  ], { cssStyles: f } = t, g = j.svg(n), m = U(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = ht(d), x = g.path(y, m), b = n.insert(() => x, ":first-child");
  return b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), s.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), V(t, b), t.intersect = function(_) {
    return W.polygon(t, d, _);
  }, n;
}
p(bg, "rect_left_inv_arrow");
async function Cg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), s = a.insert("g"), o = a.insert("g").attr("class", "label").attr("style", i), l = t.description, c = t.label, h = await He(o, c, t.labelStyle, !0, !0);
  let u = { width: 0, height: 0 };
  if (It(ft())) {
    const D = h.children[0], I = lt(h);
    u = D.getBoundingClientRect(), I.attr("width", u.width), I.attr("height", u.height);
  }
  F.info("Text 2", l);
  const d = l || [], f = h.getBBox(), g = await He(
    o,
    Array.isArray(d) ? d.join("<br/>") : d,
    t.labelStyle,
    !0,
    !0
  ), m = g.children[0], y = lt(g);
  u = m.getBoundingClientRect(), y.attr("width", u.width), y.attr("height", u.height);
  const x = (t.padding || 0) / 2;
  lt(g).attr(
    "transform",
    "translate( " + (u.width > f.width ? 0 : (f.width - u.width) / 2) + ", " + (f.height + x + 5) + ")"
  ), lt(h).attr(
    "transform",
    "translate( " + (u.width < f.width ? 0 : -(f.width - u.width) / 2) + ", 0)"
  ), u = o.node().getBBox(), o.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - x + 3) + ")"
  );
  const b = u.width + (t.padding || 0), _ = u.height + (t.padding || 0), v = -u.width / 2 - x, k = -u.height / 2 - x;
  let T, B;
  if (t.look === "handDrawn") {
    const D = j.svg(a), I = U(t, {}), O = D.path(
      Qe(v, k, b, _, t.rx || 0),
      I
    ), $ = D.line(
      -u.width / 2 - x,
      -u.height / 2 - x + f.height + x,
      u.width / 2 + x,
      -u.height / 2 - x + f.height + x,
      I
    );
    B = a.insert(() => (F.debug("Rough node insert CXC", O), $), ":first-child"), T = a.insert(() => (F.debug("Rough node insert CXC", O), O), ":first-child");
  } else
    T = s.insert("rect", ":first-child"), B = s.insert("line"), T.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - x).attr("y", -u.height / 2 - x).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), B.attr("class", "divider").attr("x1", -u.width / 2 - x).attr("x2", u.width / 2 + x).attr("y1", -u.height / 2 - x + f.height + x).attr("y2", -u.height / 2 - x + f.height + x);
  return V(t, T), t.intersect = function(D) {
    return W.rect(t, D);
  }, a;
}
p(Cg, "rectWithTitle");
async function _g(e, t) {
  const r = {
    rx: 5,
    ry: 5,
    labelPaddingX: (t?.padding || 0) * 1,
    labelPaddingY: (t?.padding || 0) * 1
  };
  return an(e, t, r);
}
p(_g, "roundedRect");
async function wg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = t?.padding ?? 0, l = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = -a.width / 2 - o, u = -a.height / 2 - o, { cssStyles: d } = t, f = j.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + l + 8, y: u },
    { x: h + l + 8, y: u + c },
    { x: h - 8, y: u + c },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], y = f.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container").attr("style", Rt(d)), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), d && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${-l / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return W.rect(t, b);
  }, n;
}
p(wg, "shadedProcess");
async function kg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = -o / 2, h = -l / 2, { cssStyles: u } = t, d = j.svg(n), f = U(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const g = [
    { x: c, y: h },
    { x: c, y: h + l },
    { x: c + o, y: h + l },
    { x: c + o, y: h - l / 2 }
  ], m = ht(g), y = d.path(m, f), x = n.insert(() => y, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), x.attr("transform", `translate(0, ${l / 4})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-l / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), V(t, x), t.intersect = function(b) {
    return W.polygon(t, g, b);
  }, n;
}
p(kg, "slopedRect");
async function vg(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: t.labelPaddingX ?? (t?.padding || 0) * 2,
    labelPaddingY: (t?.padding || 0) * 1
  };
  return an(e, t, r);
}
p(vg, "squareRect");
async function Sg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.height + t.padding, o = a.width + s / 4 + t.padding, l = s / 2, { cssStyles: c } = t, h = j.svg(n), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const d = [
    { x: -o / 2 + l, y: -s / 2 },
    { x: o / 2 - l, y: -s / 2 },
    ...ji(-o / 2 + l, 0, l, 50, 90, 270),
    { x: o / 2 - l, y: s / 2 },
    ...ji(o / 2 - l, 0, l, 50, 270, 450)
  ], f = ht(d), g = h.path(f, u), m = n.insert(() => g, ":first-child");
  return m.attr("class", "basic label-container outer-path"), c && t.look !== "handDrawn" && m.selectChildren("path").attr("style", c), i && t.look !== "handDrawn" && m.selectChildren("path").attr("style", i), V(t, m), t.intersect = function(y) {
    return W.polygon(t, d, y);
  }, n;
}
p(Sg, "stadium");
async function Tg(e, t) {
  return an(e, t, {
    rx: 5,
    ry: 5
  });
}
p(Tg, "state");
function Bg(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: s, stateBorder: o, nodeBorder: l } = r, c = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = j.svg(c), u = U(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const d = h.circle(0, 0, 14, {
    ...u,
    stroke: s,
    strokeWidth: 2
  }), f = o ?? l, g = h.circle(0, 0, 5, {
    ...u,
    fill: f,
    stroke: f,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = c.insert(() => d, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), V(t, m), t.intersect = function(y) {
    return W.circle(t, 7, y);
  }, c;
}
p(Bg, "stateEnd");
function Lg(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const o = j.svg(n).circle(0, 0, 14, uk(i));
    a = n.insert(() => o), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return V(t, a), t.intersect = function(s) {
    return W.circle(t, 7, s);
  }, n;
}
p(Lg, "stateStart");
async function Ag(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = (t?.padding || 0) / 2, o = a.width + t.padding, l = a.height + t.padding, c = -a.width / 2 - s, h = -a.height / 2 - s, u = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o, y: -l },
    { x: 0, y: -l },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: o + 8, y: 0 },
    { x: o + 8, y: -l },
    { x: -8, y: -l },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const d = j.svg(n), f = U(t, {}), g = d.rectangle(c - 8, h, o + 16, l, f), m = d.line(c, h, c, h + l, f), y = d.line(c + o, h, c + o, h + l, f);
    n.insert(() => m, ":first-child"), n.insert(() => y, ":first-child");
    const x = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    x.attr("class", "basic label-container").attr("style", Rt(b)), V(t, x);
  } else {
    const d = Ne(n, o, l, u);
    i && d.attr("style", i), V(t, d);
  }
  return t.intersect = function(d) {
    return W.polygon(t, u, d);
  }, n;
}
p(Ag, "subroutine");
async function Mg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), o = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), l = -s / 2, c = -o / 2, h = 0.2 * o, u = 0.2 * o, { cssStyles: d } = t, f = j.svg(n), g = U(t, {}), m = [
    { x: l - h / 2, y: c },
    { x: l + s + h / 2, y: c },
    { x: l + s + h / 2, y: c + o },
    { x: l - h / 2, y: c + o }
  ], y = [
    { x: l + s - h / 2, y: c + o },
    { x: l + s + h / 2, y: c + o },
    { x: l + s + h / 2, y: c + o - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = ht(m), b = f.path(x, g), _ = ht(y), v = f.path(_, { ...g, fillStyle: "solid" }), k = n.insert(() => v, ":first-child");
  return k.insert(() => b, ":first-child"), k.attr("class", "basic label-container"), d && t.look !== "handDrawn" && k.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), V(t, k), t.intersect = function(T) {
    return W.polygon(t, m, T);
  }, n;
}
p(Mg, "taggedRect");
async function $g(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 4, h = 0.2 * o, u = 0.2 * l, d = l + c, { cssStyles: f } = t, g = j.svg(n), m = U(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = [
    { x: -o / 2 - o / 2 * 0.1, y: d / 2 },
    ...Ve(
      -o / 2 - o / 2 * 0.1,
      d / 2,
      o / 2 + o / 2 * 0.1,
      d / 2,
      c,
      0.8
    ),
    { x: o / 2 + o / 2 * 0.1, y: -d / 2 },
    { x: -o / 2 - o / 2 * 0.1, y: -d / 2 }
  ], x = -o / 2 + o / 2 * 0.1, b = -d / 2 - u * 0.4, _ = [
    { x: x + o - h, y: (b + l) * 1.4 },
    { x: x + o, y: b + l - u },
    { x: x + o, y: (b + l) * 0.9 },
    ...Ve(
      x + o,
      (b + l) * 1.3,
      x + o - h,
      (b + l) * 1.5,
      -l * 0.03,
      0.5
    )
  ], v = ht(y), k = g.path(v, m), T = ht(_), B = g.path(T, {
    ...m,
    fillStyle: "solid"
  }), D = n.insert(() => B, ":first-child");
  return D.insert(() => k, ":first-child"), D.attr("class", "basic label-container"), f && t.look !== "handDrawn" && D.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, D), t.intersect = function(I) {
    return W.polygon(t, y, I);
  }, n;
}
p($g, "taggedWaveEdgedRectangle");
async function Eg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = Math.max(a.width + t.padding, t?.width || 0), o = Math.max(a.height + t.padding, t?.height || 0), l = -s / 2, c = -o / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", l).attr("y", c).attr("width", s).attr("height", o), V(t, h), t.intersect = function(u) {
    return W.rect(t, u);
  }, n;
}
p(Eg, "text");
var iS = /* @__PURE__ */ p((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), nS = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), aS = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function Fg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s, halfPadding: o } = await it(
    e,
    t,
    rt(t)
  ), l = t.look === "neo" ? o * 2 : o, c = a.height + l, h = c / 2, u = h / (2.5 + c / 50), d = a.width + u + l, { cssStyles: f } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = j.svg(n), y = nS(0, 0, d, c, u, h), x = aS(0, 0, d, c, u, h), b = m.path(y, U(t, {})), _ = m.path(x, U(t, { fill: "none" }));
    g = n.insert(() => _, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), f && g.attr("style", f);
  } else {
    const m = iS(0, 0, d, c, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", Rt(f)).attr("style", i), g.attr("class", "basic label-container"), f && g.selectAll("path").attr("style", f), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-d / 2}, ${c / 2} )`), s.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), V(t, g), t.intersect = function(m) {
    const y = W.rect(t, m), x = y.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(x) < (t.height ?? 0) / 2 || Math.abs(x) == (t.height ?? 0) / 2 && Math.abs(y.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - x * x / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), y.x += b;
    }
    return y;
  }, n;
}
p(Fg, "tiltedCylinder");
async function Dg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = a.width + t.padding, o = a.height + t.padding, l = [
    { x: -3 * o / 6, y: 0 },
    { x: s + 3 * o / 6, y: 0 },
    { x: s, y: -o },
    { x: 0, y: -o }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = j.svg(n), d = U(t, {}), f = ht(l), g = u.path(f, d);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-s / 2}, ${o / 2})`), h && c.attr("style", h);
  } else
    c = Ne(n, s, o, l);
  return i && c.attr("style", i), t.width = s, t.height = o, V(t, c), t.intersect = function(u) {
    return W.polygon(t, l, u);
  }, n;
}
p(Dg, "trapezoid");
async function Og(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 60, o = 20, l = Math.max(s, a.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(o, a.height + (t.padding ?? 0) * 2, t?.height ?? 0), { cssStyles: h } = t, u = j.svg(n), d = U(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const f = [
    { x: -l / 2 * 0.8, y: -c / 2 },
    { x: l / 2 * 0.8, y: -c / 2 },
    { x: l / 2, y: -c / 2 * 0.6 },
    { x: l / 2, y: c / 2 },
    { x: -l / 2, y: c / 2 },
    { x: -l / 2, y: -c / 2 * 0.6 }
  ], g = ht(f), m = u.path(g, d), y = n.insert(() => m, ":first-child");
  return y.attr("class", "basic label-container"), h && t.look !== "handDrawn" && y.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), V(t, y), t.intersect = function(x) {
    return W.polygon(t, f, x);
  }, n;
}
p(Og, "trapezoidalPentagon");
async function Rg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = t.useHtmlLabels || It(ft()), l = a.width + (t.padding ?? 0), c = l + a.height, h = l + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -c }
  ], { cssStyles: d } = t, f = j.svg(n), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = ht(u), y = f.path(m, g), x = n.insert(() => y, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return d && t.look !== "handDrawn" && x.selectChildren("path").attr("style", d), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = l, t.height = c, V(t, x), s.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${c / 2 - (a.height + (t.padding ?? 0) / (o ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(b) {
    return F.info("Triangle intersect", t, u, b), W.polygon(t, u, b);
  }, n;
}
p(Rg, "triangle");
async function Ig(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = l / 8, h = l + c, { cssStyles: u } = t, f = 70 - o, g = f > 0 ? f / 2 : 0, m = j.svg(n), y = U(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const x = [
    { x: -o / 2 - g, y: h / 2 },
    ...Ve(
      -o / 2 - g,
      h / 2,
      o / 2 + g,
      h / 2,
      c,
      0.8
    ),
    { x: o / 2 + g, y: -h / 2 },
    { x: -o / 2 - g, y: -h / 2 }
  ], b = ht(x), _ = m.path(b, y), v = n.insert(() => _, ":first-child");
  return v.attr("class", "basic label-container"), u && t.look !== "handDrawn" && v.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && v.selectAll("path").attr("style", i), v.attr("transform", `translate(0,${-c / 2})`), s.attr(
    "transform",
    `translate(${-o / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c - (a.y - (a.top ?? 0))})`
  ), V(t, v), t.intersect = function(k) {
    return W.polygon(t, x, k);
  }, n;
}
p(Ig, "waveEdgedRectangle");
async function Pg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await it(e, t, rt(t)), s = 100, o = 50, l = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), h = l / c;
  let u = l, d = c;
  u > d * h ? d = u / h : u = d * h, u = Math.max(u, s), d = Math.max(d, o);
  const f = Math.min(d * 0.2, d / 4), g = d + f * 2, { cssStyles: m } = t, y = j.svg(n), x = U(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Ve(-u / 2, g / 2, u / 2, g / 2, f, 1),
    { x: u / 2, y: -g / 2 },
    ...Ve(u / 2, -g / 2, -u / 2, -g / 2, f, -1)
  ], _ = ht(b), v = y.path(_, x), k = n.insert(() => v, ":first-child");
  return k.attr("class", "basic label-container"), m && t.look !== "handDrawn" && k.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), V(t, k), t.intersect = function(T) {
    return W.polygon(t, b, T);
  }, n;
}
p(Pg, "waveRectangle");
async function Ng(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: s } = await it(e, t, rt(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, t?.width ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, t?.height ?? 0), c = 5, h = -o / 2, u = -l / 2, { cssStyles: d } = t, f = j.svg(n), g = U(t, {}), m = [
    { x: h - c, y: u - c },
    { x: h - c, y: u + l },
    { x: h + o, y: u + l },
    { x: h + o, y: u - c }
  ], y = `M${h - c},${u - c} L${h + o},${u - c} L${h + o},${u + l} L${h - c},${u + l} L${h - c},${u - c}
                M${h - c},${u} L${h + o},${u}
                M${h},${u - c} L${h},${u + l}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = f.path(y, g), b = n.insert(() => x, ":first-child");
  return b.attr("transform", `translate(${c / 2}, ${c / 2})`), b.attr("class", "basic label-container"), d && t.look !== "handDrawn" && b.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), s.attr(
    "transform",
    `translate(${-(a.width / 2) + c / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c / 2 - (a.y - (a.top ?? 0))})`
  ), V(t, b), t.intersect = function(_) {
    return W.polygon(t, m, _);
  }, n;
}
p(Ng, "windowPane");
async function _l(e, t) {
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: et } = Dt(), { background: K } = et, ot = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${K}`]
    };
    await _l(e, ot);
  }
  const i = Dt();
  t.useHtmlLabels = i.htmlLabels;
  let n = i.er?.diagramPadding ?? 10, a = i.er?.entityPadding ?? 6;
  const { cssStyles: s } = t, { labelStyles: o, nodeStyles: l } = G(t);
  if (r.attributes.length === 0 && t.label) {
    const et = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    Oe(t.label, i) + et.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const K = await an(e, t, et);
    if (!Ze(i.htmlLabels)) {
      const ot = K.select("text"), at = ot.node()?.getBBox();
      ot.attr("transform", `translate(${-at.width / 2}, 0)`);
    }
    return K;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let c = rt(t);
  c || (c = "node default");
  const h = e.insert("g").attr("class", c).attr("id", t.domId || t.id), u = await Mr(h, t.label ?? "", i, 0, 0, ["name"], o);
  u.height += a;
  let d = 0;
  const f = [], g = [];
  let m = 0, y = 0, x = 0, b = 0, _ = !0, v = !0;
  for (const et of r.attributes) {
    const K = await Mr(
      h,
      et.type,
      i,
      0,
      d,
      ["attribute-type"],
      o
    );
    m = Math.max(m, K.width + n);
    const ot = await Mr(
      h,
      et.name,
      i,
      0,
      d,
      ["attribute-name"],
      o
    );
    y = Math.max(y, ot.width + n);
    const at = await Mr(
      h,
      et.keys.join(),
      i,
      0,
      d,
      ["attribute-keys"],
      o
    );
    x = Math.max(x, at.width + n);
    const Ct = await Mr(
      h,
      et.comment,
      i,
      0,
      d,
      ["attribute-comment"],
      o
    );
    b = Math.max(b, Ct.width + n);
    const xt = Math.max(K.height, ot.height, at.height, Ct.height) + a;
    g.push({ yOffset: d, rowHeight: xt }), d += xt;
  }
  let k = 4;
  x <= n && (_ = !1, x = 0, k--), b <= n && (v = !1, b = 0, k--);
  const T = h.node().getBBox();
  if (u.width + n * 2 - (m + y + x + b) > 0) {
    const et = u.width + n * 2 - (m + y + x + b);
    m += et / k, y += et / k, x > 0 && (x += et / k), b > 0 && (b += et / k);
  }
  const B = m + y + x + b, D = j.svg(h), I = U(t, {});
  t.look !== "handDrawn" && (I.roughness = 0, I.fillStyle = "solid");
  let O = 0;
  g.length > 0 && (O = g.reduce((et, K) => et + (K?.rowHeight ?? 0), 0));
  const $ = Math.max(T.width + n * 2, t?.width || 0, B), N = Math.max((O ?? 0) + u.height, t?.height || 0), R = -$ / 2, A = -N / 2;
  h.selectAll("g:not(:first-child)").each((et, K, ot) => {
    const at = lt(ot[K]), Ct = at.attr("transform");
    let xt = 0, Bt = 0;
    if (Ct) {
      const yt = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(Ct);
      yt && (xt = parseFloat(yt[1]), Bt = parseFloat(yt[2]), at.attr("class").includes("attribute-name") ? xt += m : at.attr("class").includes("attribute-keys") ? xt += m + y : at.attr("class").includes("attribute-comment") && (xt += m + y + x));
    }
    at.attr(
      "transform",
      `translate(${R + n / 2 + xt}, ${Bt + A + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (A + a / 2) + ")");
  const L = D.rectangle(R, A, $, N, I), S = h.insert(() => L, ":first-child").attr("style", s.join("")), { themeVariables: E } = Dt(), { rowEven: M, rowOdd: q, nodeBorder: Y } = E;
  f.push(0);
  for (const [et, K] of g.entries()) {
    const at = (et + 1) % 2 === 0 && K.yOffset !== 0, Ct = D.rectangle(R, u.height + A + K?.yOffset, $, K?.rowHeight, {
      ...I,
      fill: at ? M : q,
      stroke: Y
    });
    h.insert(() => Ct, "g.label").attr("style", s.join("")).attr("class", `row-rect-${at ? "even" : "odd"}`);
  }
  let Z = D.line(R, u.height + A, $ + R, u.height + A, I);
  h.insert(() => Z).attr("class", "divider"), Z = D.line(m + R, u.height + A, m + R, N + A, I), h.insert(() => Z).attr("class", "divider"), _ && (Z = D.line(
    m + y + R,
    u.height + A,
    m + y + R,
    N + A,
    I
  ), h.insert(() => Z).attr("class", "divider")), v && (Z = D.line(
    m + y + x + R,
    u.height + A,
    m + y + x + R,
    N + A,
    I
  ), h.insert(() => Z).attr("class", "divider"));
  for (const et of f)
    Z = D.line(
      R,
      u.height + A + et,
      $ + R,
      u.height + A + et,
      I
    ), h.insert(() => Z).attr("class", "divider");
  if (V(t, S), l && t.look !== "handDrawn") {
    const K = l.split(";")?.filter((ot) => ot.includes("stroke"))?.map((ot) => `${ot}`).join("; ");
    h.selectAll("path").attr("style", K ?? ""), h.selectAll(".row-rect-even path").attr("style", l);
  }
  return t.intersect = function(et) {
    return W.rect(t, et);
  }, h;
}
p(_l, "erBox");
async function Mr(e, t, r, i = 0, n = 0, a = [], s = "") {
  const o = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", s);
  t !== tc(t) && (t = tc(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const l = o.node().appendChild(
    await Pe(
      o,
      t,
      {
        width: Oe(t, r) + 100,
        style: s,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = l.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let c = l.getBBox();
  if (Ze(r.htmlLabels)) {
    const h = l.children[0];
    h.style.textAlign = "start";
    const u = lt(l);
    c = h.getBoundingClientRect(), u.attr("width", c.width), u.attr("height", c.height);
  }
  return c;
}
p(Mr, "addText");
async function zg(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, s = e.insert("g").attr("class", rt(t)).attr("id", t.domId || t.id);
  let o = null, l = null, c = null, h = null, u = 0, d = 0, f = 0;
  if (o = s.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await vi(o, { text: `«${b}»` }, 0), u = o.node().getBBox().height;
  }
  l = s.insert("g").attr("class", "label-group text"), await vi(l, t, 0, ["font-weight: bolder"]);
  const g = l.node().getBBox();
  d = g.height, c = s.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const _ = await vi(c, b, m, [b.parseClassifier()]);
    m += _ + a;
  }
  f = c.node().getBBox().height, f <= 0 && (f = n / 2), h = s.insert("g").attr("class", "methods-group text");
  let y = 0;
  for (const b of t.methods) {
    const _ = await vi(h, b, y, [b.parseClassifier()]);
    y += _ + a;
  }
  let x = s.node().getBBox();
  if (o !== null) {
    const b = o.node().getBBox();
    o.attr("transform", `translate(${-b.width / 2})`);
  }
  return l.attr("transform", `translate(${-g.width / 2}, ${u})`), x = s.node().getBBox(), c.attr(
    "transform",
    `translate(0, ${u + d + n * 2})`
  ), x = s.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + d + (f ? f + n * 4 : n * 2)})`
  ), x = s.node().getBBox(), { shapeSvg: s, bbox: x };
}
p(zg, "textHelper");
async function vi(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Dt();
  let s = "useHtmlLabels" in t ? t.useHtmlLabels : Ze(a.htmlLabels) ?? !0, o = "";
  "text" in t ? o = t.text : o = t.label, !s && o.startsWith("\\") && (o = o.substring(1)), Fi(o) && (s = !0);
  const l = await Pe(
    n,
    Mo(Jr(o)),
    {
      width: Oe(o, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: s
    },
    a
  );
  let c, h = 1;
  if (s) {
    const u = l.children[0], d = lt(l);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const f = u.getElementsByTagName("img");
    if (f) {
      const g = o.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...f].map(
          (m) => new Promise((y) => {
            function x() {
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const b = a.fontSize?.toString() ?? window.getComputedStyle(document.body).fontSize, v = parseInt(b, 10) * 5 + "px";
                m.style.minWidth = v, m.style.maxWidth = v;
              } else
                m.style.width = "100%";
              y(m);
            }
            p(x, "setupImage"), setTimeout(() => {
              m.complete && x();
            }), m.addEventListener("error", x), m.addEventListener("load", x);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), d.attr("width", c.width), d.attr("height", c.height);
  } else {
    i.includes("font-weight: bolder") && lt(l).selectAll("tspan").attr("font-weight", ""), h = l.children.length;
    const u = l.children[0];
    (l.textContent === "" || l.textContent.includes("&gt")) && (u.textContent = o[0] + o.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), o[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), c = l.getBBox();
  }
  return n.attr("transform", "translate(0," + (-c.height / (2 * h) + r) + ")"), c.height;
}
p(vi, "addText");
async function Wg(e, t) {
  const r = ft(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? Ze(r.htmlLabels) ?? !0, s = t;
  s.annotations = s.annotations ?? [], s.members = s.members ?? [], s.methods = s.methods ?? [];
  const { shapeSvg: o, bbox: l } = await zg(e, t, r, a, n), { labelStyles: c, nodeStyles: h } = G(t);
  t.labelStyle = c, t.cssStyles = s.styles || "";
  const u = s.styles?.join(";") || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const d = s.members.length === 0 && s.methods.length === 0 && !r.class?.hideEmptyMembersBox, f = j.svg(o), g = U(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = l.width;
  let y = l.height;
  s.members.length === 0 && s.methods.length === 0 ? y += n : s.members.length > 0 && s.methods.length === 0 && (y += n * 2);
  const x = -m / 2, b = -y / 2, _ = f.rectangle(
    x - i,
    b - i - (d ? i : s.members.length === 0 && s.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    y + 2 * i + (d ? i * 2 : s.members.length === 0 && s.methods.length === 0 ? -i : 0),
    g
  ), v = o.insert(() => _, ":first-child");
  v.attr("class", "basic label-container");
  const k = v.node().getBBox();
  o.selectAll(".text").each((I, O, $) => {
    const N = lt($[O]), R = N.attr("transform");
    let A = 0;
    if (R) {
      const M = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(R);
      M && (A = parseFloat(M[2]));
    }
    let L = A + b + i - (d ? i : s.members.length === 0 && s.methods.length === 0 ? -i / 2 : 0);
    a || (L -= 4);
    let S = x;
    (N.attr("class").includes("label-group") || N.attr("class").includes("annotation-group")) && (S = -N.node()?.getBBox().width / 2 || 0, o.selectAll("text").each(function(E, M, q) {
      window.getComputedStyle(q[M]).textAnchor === "middle" && (S = 0);
    })), N.attr("transform", `translate(${S}, ${L})`);
  });
  const T = o.select(".annotation-group").node().getBBox().height - (d ? i / 2 : 0) || 0, B = o.select(".label-group").node().getBBox().height - (d ? i / 2 : 0) || 0, D = o.select(".members-group").node().getBBox().height - (d ? i / 2 : 0) || 0;
  if (s.members.length > 0 || s.methods.length > 0 || d) {
    const I = f.line(
      k.x,
      T + B + b + i,
      k.x + k.width,
      T + B + b + i,
      g
    );
    o.insert(() => I).attr("class", "divider").attr("style", u);
  }
  if (d || s.members.length > 0 || s.methods.length > 0) {
    const I = f.line(
      k.x,
      T + B + D + b + n * 2 + i,
      k.x + k.width,
      T + B + D + b + i + n * 2,
      g
    );
    o.insert(() => I).attr("class", "divider").attr("style", u);
  }
  if (s.look !== "handDrawn" && o.selectAll("path").attr("style", u), v.select(":nth-child(2)").attr("style", u), o.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? o.selectAll("span").attr("style", t.labelStyle) : o.selectAll("span").attr("style", u), !a) {
    const I = RegExp(/color\s*:\s*([^;]*)/), O = I.exec(u);
    if (O) {
      const $ = O[0].replace("color", "fill");
      o.selectAll("tspan").attr("style", $);
    } else if (c) {
      const $ = I.exec(c);
      if ($) {
        const N = $[0].replace("color", "fill");
        o.selectAll("tspan").attr("style", N);
      }
    }
  }
  return V(t, v), t.intersect = function(I) {
    return W.rect(t, I);
  }, o;
}
p(Wg, "classBox");
async function qg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const n = t, a = t, s = 20, o = 20, l = "verifyMethod" in t, c = rt(t), h = e.insert("g").attr("class", c).attr("id", t.domId ?? t.id);
  let u;
  l ? u = await xe(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await xe(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let d = u;
  const f = await xe(
    h,
    n.name,
    d,
    t.labelStyle + "; font-weight: bold;"
  );
  if (d += f + o, l) {
    const T = await xe(
      h,
      `${n.requirementId ? `ID: ${n.requirementId}` : ""}`,
      d,
      t.labelStyle
    );
    d += T;
    const B = await xe(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      d,
      t.labelStyle
    );
    d += B;
    const D = await xe(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      d,
      t.labelStyle
    );
    d += D, await xe(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      d,
      t.labelStyle
    );
  } else {
    const T = await xe(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      d,
      t.labelStyle
    );
    d += T, await xe(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      d,
      t.labelStyle
    );
  }
  const g = (h.node()?.getBBox().width ?? 200) + s, m = (h.node()?.getBBox().height ?? 200) + s, y = -g / 2, x = -m / 2, b = j.svg(h), _ = U(t, {});
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const v = b.rectangle(y, x, g, m, _), k = h.insert(() => v, ":first-child");
  if (k.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((T, B, D) => {
    const I = lt(D[B]), O = I.attr("transform");
    let $ = 0, N = 0;
    if (O) {
      const S = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(O);
      S && ($ = parseFloat(S[1]), N = parseFloat(S[2]));
    }
    const R = N - m / 2;
    let A = y + s / 2;
    (B === 0 || B === 1) && (A = $), I.attr("transform", `translate(${A}, ${R + s})`);
  }), d > u + f + o) {
    const T = b.line(
      y,
      x + u + f + o,
      y + g,
      x + u + f + o,
      _
    );
    h.insert(() => T).attr("style", i);
  }
  return V(t, k), t.intersect = function(T) {
    return W.rect(t, T);
  }, h;
}
p(qg, "requirementBox");
async function xe(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = ft(), s = a.htmlLabels ?? !0, o = await Pe(
    n,
    Mo(Jr(t)),
    {
      width: Oe(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: s,
      style: i
    },
    a
  );
  let l;
  if (s) {
    const c = o.children[0], h = lt(o);
    l = c.getBoundingClientRect(), h.attr("width", l.width), h.attr("height", l.height);
  } else {
    const c = o.children[0];
    for (const h of c.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    l = o.getBBox(), l.height += 6;
  }
  return n.attr("transform", `translate(${-l.width / 2},${-l.height / 2 + r})`), l.height;
}
p(xe, "addText");
var sS = /* @__PURE__ */ p((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    // no stroke
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function Hg(e, t, { config: r }) {
  const { labelStyles: i, nodeStyles: n } = G(t);
  t.labelStyle = i || "";
  const a = 10, s = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: o,
    bbox: l,
    label: c
  } = await it(e, t, rt(t)), h = t.padding || 10;
  let u = "", d;
  "ticket" in t && t.ticket && r?.kanban?.ticketBaseUrl && (u = r?.kanban?.ticketBaseUrl.replace("#TICKET#", t.ticket), d = o.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const f = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  d ? { label: g, bbox: m } = await _s(
    d,
    "ticket" in t && t.ticket || "",
    f
  ) : { label: g, bbox: m } = await _s(
    o,
    "ticket" in t && t.ticket || "",
    f
  );
  const { label: y, bbox: x } = await _s(
    o,
    "assigned" in t && t.assigned || "",
    f
  );
  t.width = s;
  const b = 10, _ = t?.width || 0, v = Math.max(m.height, x.height) / 2, k = Math.max(l.height + b * 2, t?.height || 0) + v, T = -_ / 2, B = -k / 2;
  c.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-v - l.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - _ / 2) + ", " + (-v + l.height / 2) + ")"
  ), y.attr(
    "transform",
    "translate(" + (h + _ / 2 - x.width - 2 * a) + ", " + (-v + l.height / 2) + ")"
  );
  let D;
  const { rx: I, ry: O } = t, { cssStyles: $ } = t;
  if (t.look === "handDrawn") {
    const N = j.svg(o), R = U(t, {}), A = I || O ? N.path(Qe(T, B, _, k, I || 0), R) : N.rectangle(T, B, _, k, R);
    D = o.insert(() => A, ":first-child"), D.attr("class", "basic label-container").attr("style", $ || null);
  } else {
    D = o.insert("rect", ":first-child"), D.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", I ?? 5).attr("ry", O ?? 5).attr("x", T).attr("y", B).attr("width", _).attr("height", k);
    const N = "priority" in t && t.priority;
    if (N) {
      const R = o.append("line"), A = T + 2, L = B + Math.floor((I ?? 0) / 2), S = B + k - Math.floor((I ?? 0) / 2);
      R.attr("x1", A).attr("y1", L).attr("x2", A).attr("y2", S).attr("stroke-width", "4").attr("stroke", sS(N));
    }
  }
  return V(t, D), t.height = k, t.intersect = function(N) {
    return W.rect(t, N);
  }, o;
}
p(Hg, "kanbanItem");
async function jg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s, label: o } = await it(
    e,
    t,
    rt(t)
  ), l = a.width + 10 * s, c = a.height + 8 * s, h = 0.15 * l, { cssStyles: u } = t, d = a.width + 20, f = a.height + 20, g = Math.max(l, d), m = Math.max(c, f);
  o.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`);
  let y;
  const x = `M0 0 
    a${h},${h} 1 0,0 ${g * 0.25},${-1 * m * 0.1}
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},${m * 0.1}

    a${h},${h} 1 0,0 ${g * 0.15},${m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${m * 0.34}
    a${h},${h} 1 0,0 ${-1 * g * 0.15},${m * 0.33}

    a${h},${h} 1 0,0 ${-1 * g * 0.25},${m * 0.15}
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},${-1 * m * 0.15}

    a${h},${h} 1 0,0 ${-1 * g * 0.1},${-1 * m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${-1 * m * 0.34}
    a${h},${h} 1 0,0 ${g * 0.1},${-1 * m * 0.33}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const b = j.svg(n), _ = U(t, {}), v = b.path(x, _);
    y = n.insert(() => v, ":first-child"), y.attr("class", "basic label-container").attr("style", Rt(u));
  } else
    y = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", x);
  return y.attr("transform", `translate(${-g / 2}, ${-m / 2})`), V(t, y), t.calcIntersect = function(b, _) {
    return W.rect(b, _);
  }, t.intersect = function(b) {
    return F.info("Bang intersect", t, b), W.rect(t, b);
  }, n;
}
p(jg, "bang");
async function Yg(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s, label: o } = await it(
    e,
    t,
    rt(t)
  ), l = a.width + 2 * s, c = a.height + 2 * s, h = 0.15 * l, u = 0.25 * l, d = 0.35 * l, f = 0.2 * l, { cssStyles: g } = t;
  let m;
  const y = `M0 0 
    a${h},${h} 0 0,1 ${l * 0.25},${-1 * l * 0.1}
    a${d},${d} 1 0,1 ${l * 0.4},${-1 * l * 0.1}
    a${u},${u} 1 0,1 ${l * 0.35},${l * 0.2}

    a${h},${h} 1 0,1 ${l * 0.15},${c * 0.35}
    a${f},${f} 1 0,1 ${-1 * l * 0.15},${c * 0.65}

    a${u},${h} 1 0,1 ${-1 * l * 0.25},${l * 0.15}
    a${d},${d} 1 0,1 ${-1 * l * 0.5},0
    a${h},${h} 1 0,1 ${-1 * l * 0.25},${-1 * l * 0.15}

    a${h},${h} 1 0,1 ${-1 * l * 0.1},${-1 * c * 0.35}
    a${f},${f} 1 0,1 ${l * 0.1},${-1 * c * 0.65}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const x = j.svg(n), b = U(t, {}), _ = x.path(y, b);
    m = n.insert(() => _, ":first-child"), m.attr("class", "basic label-container").attr("style", Rt(g));
  } else
    m = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", y);
  return o.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), m.attr("transform", `translate(${-l / 2}, ${-c / 2})`), V(t, m), t.calcIntersect = function(x, b) {
    return W.rect(x, b);
  }, t.intersect = function(x) {
    return F.info("Cloud intersect", t, x), W.rect(t, x);
  }, n;
}
p(Yg, "cloud");
async function Ug(e, t) {
  const { labelStyles: r, nodeStyles: i } = G(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: s, label: o } = await it(
    e,
    t,
    rt(t)
  ), l = a.width + 8 * s, c = a.height + 2 * s, h = 5, u = `
    M${-l / 2} ${c / 2 - h}
    v${-c + 2 * h}
    q0,-${h} ${h},-${h}
    h${l - 2 * h}
    q${h},0 ${h},${h}
    v${c - 2 * h}
    q0,${h} -${h},${h}
    h${-l + 2 * h}
    q-${h},0 -${h},-${h}
    Z
  `, d = n.append("path").attr("id", "node-" + t.id).attr("class", "node-bkg node-" + t.type).attr("style", i).attr("d", u);
  return n.append("line").attr("class", "node-line-").attr("x1", -l / 2).attr("y1", c / 2).attr("x2", l / 2).attr("y2", c / 2), o.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), n.append(() => o.node()), V(t, d), t.calcIntersect = function(f, g) {
    return W.rect(f, g);
  }, t.intersect = function(f) {
    return W.rect(t, f);
  }, n;
}
p(Ug, "defaultMindmapNode");
async function Gg(e, t) {
  const r = {
    padding: t.padding ?? 0
  };
  return Cl(e, t, r);
}
p(Gg, "mindmapCircle");
var oS = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: vg
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: _g
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: Sg
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: Ag
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: Xp
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: Cl
  },
  {
    semanticName: "Bang",
    name: "Bang",
    shortName: "bang",
    description: "Bang",
    aliases: ["bang"],
    handler: jg
  },
  {
    semanticName: "Cloud",
    name: "Cloud",
    shortName: "cloud",
    description: "cloud",
    aliases: ["cloud"],
    handler: Yg
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: xg
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: eg
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: ug
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: hg
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: Dg
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: lg
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: Zp
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: Eg
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: zp
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: wg
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: Lg
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: Bg
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: Jp
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: rg
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: jp
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: Yp
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: Up
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: fg
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Ig
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: tg
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: Fg
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: dg
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: Gp
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: Vp
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: Rg
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Ng
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: Kp
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: Og
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: Qp
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: kg
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: mg
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: gg
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Np
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: Hp
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: $g
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: Mg
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: Pg
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: bg
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: pg
  }
], lS = /* @__PURE__ */ p(() => {
  const t = [
    ...Object.entries({
      // States
      state: Tg,
      choice: Wp,
      note: yg,
      // Rectangles
      rectWithTitle: Cg,
      labelRect: cg,
      // Icons
      iconSquare: sg,
      iconCircle: ng,
      icon: ig,
      iconRounded: ag,
      imageSquare: og,
      anchor: Pp,
      // Kanban diagram
      kanbanItem: Hg,
      //Mindmap diagram
      mindmapCircle: Gg,
      defaultMindmapNode: Ug,
      // class diagram
      classBox: Wg,
      // er diagram
      erBox: _l,
      // Requirement diagram
      requirementBox: qg
    }),
    ...oS.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), Xg = lS();
function cS(e) {
  return e in Xg;
}
p(cS, "isValidShape");
var Ha = /* @__PURE__ */ new Map();
async function Vg(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? Xg[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let s;
    r.config.securityLevel === "sandbox" ? s = "_top" : t.linkTarget && (s = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", s ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), Ha.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
p(Vg, "insertNode");
var LA = /* @__PURE__ */ p((e, t) => {
  Ha.set(t.id, e);
}, "setNodeElem"), AA = /* @__PURE__ */ p(() => {
  Ha.clear();
}, "clear"), MA = /* @__PURE__ */ p((e) => {
  const t = Ha.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), hS = /* @__PURE__ */ p((e, t, r, i, n, a) => {
  t.arrowTypeStart && hh(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && hh(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), uS = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, hh = /* @__PURE__ */ p((e, t, r, i, n, a, s) => {
  const o = uS[r];
  if (!o) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const l = o.type, h = `${n}_${a}-${l}${t === "start" ? "Start" : "End"}`;
  if (s && s.trim() !== "") {
    const u = s.replace(/[^\dA-Za-z]/g, "_"), d = `${h}_${u}`;
    if (!document.getElementById(d)) {
      const f = document.getElementById(h);
      if (f) {
        const g = f.cloneNode(!0);
        g.id = d, g.querySelectorAll("path, circle, line").forEach((y) => {
          y.setAttribute("stroke", s), o.fill && y.setAttribute("fill", s);
        }), f.parentNode?.appendChild(g);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${d})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), fS = /* @__PURE__ */ p((e) => typeof e == "string" ? e : ft()?.flowchart?.curve, "resolveEdgeCurveType"), ba = /* @__PURE__ */ new Map(), Mt = /* @__PURE__ */ new Map(), $A = /* @__PURE__ */ p(() => {
  ba.clear(), Mt.clear();
}, "clear"), yi = /* @__PURE__ */ p((e) => e ? typeof e == "string" ? e : e.reduce((t, r) => t + ";" + r, "") : "", "getLabelStyles"), dS = /* @__PURE__ */ p(async (e, t) => {
  const r = ft();
  let i = It(r);
  const { labelStyles: n } = G(t);
  t.labelStyle = n;
  const a = e.insert("g").attr("class", "edgeLabel"), s = a.insert("g").attr("class", "label").attr("data-id", t.id), o = t.labelType === "markdown", c = await Pe(
    e,
    t.label,
    {
      style: yi(t.labelStyle),
      useHtmlLabels: i,
      addSvgBackground: !0,
      isNode: !1,
      markdown: o,
      // Plain text edge labels should auto-wrap, markdown edge labels respect markdownAutoWrap config
      width: o ? void 0 : void 0
    },
    r
  );
  s.node().appendChild(c), F.info("abc82", t, t.labelType);
  let h = c.getBBox(), u = h;
  if (i) {
    const f = c.children[0], g = lt(c);
    h = f.getBoundingClientRect(), u = h, g.attr("width", h.width), g.attr("height", h.height);
  } else {
    const f = lt(c).select("text").node();
    f && typeof f.getBBox == "function" && (u = f.getBBox());
  }
  s.attr("transform", ui(u, i)), ba.set(t.id, a), t.width = h.width, t.height = h.height;
  let d;
  if (t.startLabelLeft) {
    const f = e.insert("g").attr("class", "edgeTerminals"), g = f.insert("g").attr("class", "inner"), m = await He(
      g,
      t.startLabelLeft,
      yi(t.labelStyle) || "",
      !1,
      !1
    );
    d = m;
    let y = m.getBBox();
    if (i) {
      const x = m.children[0], b = lt(m);
      y = x.getBoundingClientRect(), b.attr("width", y.width), b.attr("height", y.height);
    }
    g.attr("transform", ui(y, i)), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).startLeft = f, Si(d, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const f = e.insert("g").attr("class", "edgeTerminals"), g = f.insert("g").attr("class", "inner"), m = await He(
      g,
      t.startLabelRight,
      yi(t.labelStyle) || "",
      !1,
      !1
    );
    d = m, g.node().appendChild(m);
    let y = m.getBBox();
    if (i) {
      const x = m.children[0], b = lt(m);
      y = x.getBoundingClientRect(), b.attr("width", y.width), b.attr("height", y.height);
    }
    g.attr("transform", ui(y, i)), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).startRight = f, Si(d, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const f = e.insert("g").attr("class", "edgeTerminals"), g = f.insert("g").attr("class", "inner"), m = await He(
      g,
      t.endLabelLeft,
      yi(t.labelStyle) || "",
      !1,
      !1
    );
    d = m;
    let y = m.getBBox();
    if (i) {
      const x = m.children[0], b = lt(m);
      y = x.getBoundingClientRect(), b.attr("width", y.width), b.attr("height", y.height);
    }
    g.attr("transform", ui(y, i)), f.node().appendChild(m), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).endLeft = f, Si(d, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const f = e.insert("g").attr("class", "edgeTerminals"), g = f.insert("g").attr("class", "inner"), m = await He(
      g,
      t.endLabelRight,
      yi(t.labelStyle) || "",
      !1,
      !1
    );
    d = m;
    let y = m.getBBox();
    if (i) {
      const x = m.children[0], b = lt(m);
      y = x.getBoundingClientRect(), b.attr("width", y.width), b.attr("height", y.height);
    }
    g.attr("transform", ui(y, i)), f.node().appendChild(m), Mt.get(t.id) || Mt.set(t.id, {}), Mt.get(t.id).endRight = f, Si(d, t.endLabelRight);
  }
  return c;
}, "insertEdgeLabel");
function Si(e, t) {
  It(ft()) && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
p(Si, "setTerminalWidth");
var pS = /* @__PURE__ */ p((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, ba.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = ft(), { subGraphTitleTotalMargin: n } = ol(i);
  if (e.label) {
    const a = ba.get(e.id);
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        s,
        ",",
        o,
        ") to (",
        l.x,
        ",",
        l.y,
        ") abc88"
      ), t.updatedPath && (s = l.x, o = l.y);
    }
    a.attr("transform", `translate(${s}, ${o + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = Mt.get(e.id).startLeft;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
  if (e.startLabelRight) {
    const a = Mt.get(e.id).startRight;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
  if (e.endLabelLeft) {
    const a = Mt.get(e.id).endLeft;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
  if (e.endLabelRight) {
    const a = Mt.get(e.id).endRight;
    let s = e.x, o = e.y;
    if (r) {
      const l = ce.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      s = l.x, o = l.y;
    }
    a.attr("transform", `translate(${s}, ${o})`);
  }
}, "positionEdgeLabel"), gS = /* @__PURE__ */ p((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), s = e.width / 2, o = e.height / 2;
  return n >= s || a >= o;
}, "outsideNode"), mS = /* @__PURE__ */ p((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), s = e.width / 2;
  let o = r.x < t.x ? s - a : s + a;
  const l = e.height / 2, c = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * s > Math.abs(i - t.x) * l) {
    let u = r.y < t.y ? t.y - l - n : n - l - t.y;
    o = h * u / c;
    const d = {
      x: r.x < t.x ? r.x + o : r.x - h + o,
      y: r.y < t.y ? r.y + c - u : r.y - c + u
    };
    return o === 0 && (d.x = t.x, d.y = t.y), h === 0 && (d.x = t.x), c === 0 && (d.y = t.y), F.debug(`abc89 top/bottom calc, Q ${c}, q ${u}, R ${h}, r ${o}`, d), d;
  } else {
    r.x < t.x ? o = t.x - s - i : o = i - s - t.x;
    let u = c * o / h, d = r.x < t.x ? r.x + h - o : r.x - h + o, f = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${c}, q ${u}, R ${h}, r ${o}`, { _x: d, _y: f }), o === 0 && (d = t.x, f = t.y), h === 0 && (d = t.x), c === 0 && (f = t.y), { x: d, y: f };
  }
}, "intersection"), uh = /* @__PURE__ */ p((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !gS(t, a) && !n) {
      const s = mS(t, i, a);
      F.debug("abc88 inside", a, i, s), F.debug("abc88 intersection", s, t);
      let o = !1;
      r.forEach((l) => {
        o = o || l.x === s.x && l.y === s.y;
      }), r.some((l) => l.x === s.x && l.y === s.y) ? F.warn("abc88 no intersect", s, r) : r.push(s), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function Zg(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], s = e[i + 1];
    (n.x === a.x && a.y === s.y && Math.abs(a.x - s.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === s.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - s.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
p(Zg, "extractCornerPoints");
var fh = /* @__PURE__ */ p(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), s = r / a;
  return { x: t.x - s * i, y: t.y - s * n };
}, "findAdjacentPoint"), yS = /* @__PURE__ */ p(function(e) {
  const { cornerPointPositions: t } = Zg(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], s = e[i], o = fh(n, s, 5), l = fh(a, s, 5), c = l.x - o.x, h = l.y - o.y;
      r.push(o);
      const u = Math.sqrt(2) * 2;
      let d = { x: s.x, y: s.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const f = 5;
        s.x === o.x ? d = {
          x: c < 0 ? o.x - f + u : o.x + f - u,
          y: h < 0 ? o.y - u : o.y + u
        } : d = {
          x: c < 0 ? o.x - u : o.x + u,
          y: h < 0 ? o.y - f + u : o.y + f - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(d, l);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), xS = /* @__PURE__ */ p((e, t, r) => {
  const i = e - t - r, n = 2, a = 2, s = n + a, o = Math.floor(i / s), l = Array(o).fill(`${n} ${a}`).join(" ");
  return `0 ${t} ${l} ${r}`;
}, "generateDashArray"), bS = /* @__PURE__ */ p(function(e, t, r, i, n, a, s, o = !1) {
  const { handDrawnSeed: l } = ft();
  let c = t.points, h = !1;
  const u = n;
  var d = a;
  const f = [];
  for (const S in t.cssCompiledStyles)
    Zd(S) || f.push(t.cssCompiledStyles[S]);
  F.debug("UIO intersect check", t.points, d.x, u.x), d.intersect && u.intersect && !o && (c = c.slice(1, t.points.length - 1), c.unshift(u.intersect(c[0])), F.debug(
    "Last point UIO",
    t.start,
    "-->",
    t.end,
    c[c.length - 1],
    d,
    d.intersect(c[c.length - 1])
  ), c.push(d.intersect(c[c.length - 1])));
  const g = btoa(JSON.stringify(c));
  t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), c = uh(t.points, r.get(t.toCluster).node), h = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(c, null, 2)
  ), c = uh(c.reverse(), r.get(t.fromCluster).node).reverse(), h = !0);
  let m = c.filter((S) => !Number.isNaN(S.y));
  const y = fS(t.curve);
  y !== "rounded" && (m = yS(m));
  let x = Mi;
  switch (y) {
    case "linear":
      x = Mi;
      break;
    case "basis":
      x = zs;
      break;
    case "cardinal":
      x = Au;
      break;
    case "bumpX":
      x = vu;
      break;
    case "bumpY":
      x = Su;
      break;
    case "catmullRom":
      x = $u;
      break;
    case "monotoneX":
      x = Iu;
      break;
    case "monotoneY":
      x = Pu;
      break;
    case "natural":
      x = zu;
      break;
    case "step":
      x = Wu;
      break;
    case "stepAfter":
      x = Hu;
      break;
    case "stepBefore":
      x = qu;
      break;
    case "rounded":
      x = Mi;
      break;
    default:
      x = zs;
  }
  const { x: b, y: _ } = gC(t), v = Q1().x(b).y(_).curve(x);
  let k;
  switch (t.thickness) {
    case "normal":
      k = "edge-thickness-normal";
      break;
    case "thick":
      k = "edge-thickness-thick";
      break;
    case "invisible":
      k = "edge-thickness-invisible";
      break;
    default:
      k = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      k += " edge-pattern-solid";
      break;
    case "dotted":
      k += " edge-pattern-dotted";
      break;
    case "dashed":
      k += " edge-pattern-dashed";
      break;
    default:
      k += " edge-pattern-solid";
  }
  let T, B = y === "rounded" ? Kg(Qg(m, t), 5) : v(m);
  const D = Array.isArray(t.style) ? t.style : [t.style];
  let I = D.find((S) => S?.startsWith("stroke:")), O = "";
  t.animate && (O = "edge-animation-fast"), t.animation && (O = "edge-animation-" + t.animation);
  let $ = !1;
  if (t.look === "handDrawn") {
    const S = j.svg(e);
    Object.assign([], m);
    const E = S.path(B, {
      roughness: 0.3,
      seed: l
    });
    k += " transition", T = lt(E).select("path").attr("id", t.id).attr(
      "class",
      " " + k + (t.classes ? " " + t.classes : "") + (O ? " " + O : "")
    ).attr("style", D ? D.reduce((q, Y) => q + ";" + Y, "") : "");
    let M = T.attr("d");
    T.attr("d", M), e.node().appendChild(T.node());
  } else {
    const S = f.join(";"), E = D ? D.reduce((K, ot) => K + ot + ";", "") : "", M = (S ? S + ";" + E + ";" : E) + ";" + (D ? D.reduce((K, ot) => K + ";" + ot, "") : "");
    T = e.append("path").attr("d", B).attr("id", t.id).attr(
      "class",
      " " + k + (t.classes ? " " + t.classes : "") + (O ? " " + O : "")
    ).attr("style", M), I = M.match(/stroke:([^;]+)/)?.[1], $ = t.animate === !0 || !!t.animation || S.includes("animation");
    const q = T.node(), Y = typeof q.getTotalLength == "function" ? q.getTotalLength() : 0, Z = Bc[t.arrowTypeStart] || 0, et = Bc[t.arrowTypeEnd] || 0;
    if (t.look === "neo" && !$) {
      const ot = `stroke-dasharray: ${t.pattern === "dotted" || t.pattern === "dashed" ? xS(Y, Z, et) : `0 ${Z} ${Y - Z - et} ${et}`}; stroke-dashoffset: 0;`;
      T.attr("style", ot + T.attr("style"));
    }
  }
  T.attr("data-edge", !0), T.attr("data-et", "edge"), T.attr("data-id", t.id), T.attr("data-points", g), t.showPoints && m.forEach((S) => {
    e.append("circle").style("stroke", "red").style("fill", "red").attr("r", 1).attr("cx", S.x).attr("cy", S.y);
  });
  let N = "";
  (ft().flowchart.arrowMarkerAbsolute || ft().state.arrowMarkerAbsolute) && (N = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, N = N.replace(/\(/g, "\\(").replace(/\)/g, "\\)")), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), hS(T, t, N, s, i, I);
  const R = Math.floor(c.length / 2), A = c[R];
  ce.isLabelCoordinateInPath(A, T.attr("d")) || (h = !0);
  let L = {};
  return h && (L.updatedPath = c), L.originalPath = t.points, L;
}, "insertEdge");
function Kg(e, t) {
  if (e.length < 2)
    return "";
  let r = "";
  const i = e.length, n = 1e-5;
  for (let a = 0; a < i; a++) {
    const s = e[a], o = e[a - 1], l = e[a + 1];
    if (a === 0)
      r += `M${s.x},${s.y}`;
    else if (a === i - 1)
      r += `L${s.x},${s.y}`;
    else {
      const c = s.x - o.x, h = s.y - o.y, u = l.x - s.x, d = l.y - s.y, f = Math.hypot(c, h), g = Math.hypot(u, d);
      if (f < n || g < n) {
        r += `L${s.x},${s.y}`;
        continue;
      }
      const m = c / f, y = h / f, x = u / g, b = d / g, _ = m * x + y * b, v = Math.max(-1, Math.min(1, _)), k = Math.acos(v);
      if (k < n || Math.abs(Math.PI - k) < n) {
        r += `L${s.x},${s.y}`;
        continue;
      }
      const T = Math.min(t / Math.sin(k / 2), f / 2, g / 2), B = s.x - m * T, D = s.y - y * T, I = s.x + x * T, O = s.y + b * T;
      r += `L${B},${D}`, r += `Q${s.x},${s.y} ${I},${O}`;
    }
  }
  return r;
}
p(Kg, "generateRoundedPath");
function go(e, t) {
  if (!e || !t)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  const r = t.x - e.x, i = t.y - e.y;
  return { angle: Math.atan2(i, r), deltaX: r, deltaY: i };
}
p(go, "calculateDeltaAndAngle");
function Qg(e, t) {
  const r = e.map((n) => ({ ...n }));
  if (e.length >= 2 && Ft[t.arrowTypeStart]) {
    const n = Ft[t.arrowTypeStart], a = e[0], s = e[1], { angle: o } = go(a, s), l = n * Math.cos(o), c = n * Math.sin(o);
    r[0].x = a.x + l, r[0].y = a.y + c;
  }
  const i = e.length;
  if (i >= 2 && Ft[t.arrowTypeEnd]) {
    const n = Ft[t.arrowTypeEnd], a = e[i - 1], s = e[i - 2], { angle: o } = go(s, a), l = n * Math.cos(o), c = n * Math.sin(o);
    r[i - 1].x = a.x - l, r[i - 1].y = a.y - c;
  }
  return r;
}
p(Qg, "applyMarkerOffsetsToPoints");
var CS = /* @__PURE__ */ p((e, t, r, i) => {
  t.forEach((n) => {
    RS[n](e, r, i);
  });
}, "insertMarkers"), _S = /* @__PURE__ */ p((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), wS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), kS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), vS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), SS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), TS = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), BS = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), LS = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), AS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), MS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), $S = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), ES = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), FS = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), DS = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), OS = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), RS = {
  extension: _S,
  composition: wS,
  aggregation: kS,
  dependency: vS,
  lollipop: SS,
  point: TS,
  circle: BS,
  cross: LS,
  barb: AS,
  only_one: MS,
  zero_or_one: $S,
  one_or_more: ES,
  zero_or_more: FS,
  requirement_arrow: DS,
  requirement_contains: OS
}, IS = CS, PS = {
  common: Vi,
  getConfig: Dt,
  insertCluster: jv,
  insertEdge: bS,
  insertEdgeLabel: dS,
  insertMarkers: IS,
  insertNode: Vg,
  interpolateToCurve: el,
  labelHelper: it,
  log: F,
  positionEdgeLabel: pS
}, Yi = {}, Jg = /* @__PURE__ */ p((e) => {
  for (const t of e)
    Yi[t.name] = t;
}, "registerLayoutLoaders"), NS = /* @__PURE__ */ p(() => {
  Jg([
    {
      name: "dagre",
      loader: /* @__PURE__ */ p(async () => await import("./dagre-KLK3FWXG-VZnBXgjW.js"), "loader")
    },
    {
      name: "cose-bilkent",
      loader: /* @__PURE__ */ p(async () => await import("./cose-bilkent-S5V4N54A-B1K0_k5R.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
NS();
var EA = /* @__PURE__ */ p(async (e, t) => {
  if (!(e.layoutAlgorithm in Yi))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = Yi[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, PS, {
    algorithm: r.algorithm
  });
}, "render"), FA = /* @__PURE__ */ p((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in Yi)
    return e;
  if (t in Yi)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), tm = "comm", em = "rule", rm = "decl", zS = "@import", WS = "@namespace", qS = "@keyframes", HS = "@layer", im = Math.abs, wl = String.fromCharCode;
function nm(e) {
  return e.trim();
}
function In(e, t, r) {
  return e.replace(t, r);
}
function jS(e, t, r) {
  return e.indexOf(t, r);
}
function Dr(e, t) {
  return e.charCodeAt(t) | 0;
}
function Vr(e, t, r) {
  return e.slice(t, r);
}
function be(e) {
  return e.length;
}
function YS(e) {
  return e.length;
}
function vn(e, t) {
  return t.push(e), e;
}
var ja = 1, Zr = 1, am = 0, re = 0, wt = 0, ri = "";
function kl(e, t, r, i, n, a, s, o) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: ja, column: Zr, length: s, return: "", siblings: o };
}
function US() {
  return wt;
}
function GS() {
  return wt = re > 0 ? Dr(ri, --re) : 0, Zr--, wt === 10 && (Zr = 1, ja--), wt;
}
function ue() {
  return wt = re < am ? Dr(ri, re++) : 0, Zr++, wt === 10 && (Zr = 1, ja++), wt;
}
function je() {
  return Dr(ri, re);
}
function Pn() {
  return re;
}
function Ya(e, t) {
  return Vr(ri, e, t);
}
function Ui(e) {
  switch (e) {
    // \0 \t \n \r \s whitespace token
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    // ! + , / > @ ~ isolate token
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    // ; { } breakpoint token
    case 59:
    case 123:
    case 125:
      return 4;
    // : accompanied token
    case 58:
      return 3;
    // " ' ( [ opening delimit token
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    // ) ] closing delimit token
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function XS(e) {
  return ja = Zr = 1, am = be(ri = e), re = 0, [];
}
function VS(e) {
  return ri = "", e;
}
function ws(e) {
  return nm(Ya(re - 1, mo(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function ZS(e) {
  for (; (wt = je()) && wt < 33; )
    ue();
  return Ui(e) > 2 || Ui(wt) > 3 ? "" : " ";
}
function KS(e, t) {
  for (; --t && ue() && !(wt < 48 || wt > 102 || wt > 57 && wt < 65 || wt > 70 && wt < 97); )
    ;
  return Ya(e, Pn() + (t < 6 && je() == 32 && ue() == 32));
}
function mo(e) {
  for (; ue(); )
    switch (wt) {
      // ] ) " '
      case e:
        return re;
      // " '
      case 34:
      case 39:
        e !== 34 && e !== 39 && mo(wt);
        break;
      // (
      case 40:
        e === 41 && mo(e);
        break;
      // \
      case 92:
        ue();
        break;
    }
  return re;
}
function QS(e, t) {
  for (; ue() && e + wt !== 57; )
    if (e + wt === 84 && je() === 47)
      break;
  return "/*" + Ya(t, re - 1) + "*" + wl(e === 47 ? e : ue());
}
function JS(e) {
  for (; !Ui(je()); )
    ue();
  return Ya(e, re);
}
function tT(e) {
  return VS(Nn("", null, null, null, [""], e = XS(e), 0, [0], e));
}
function Nn(e, t, r, i, n, a, s, o, l) {
  for (var c = 0, h = 0, u = s, d = 0, f = 0, g = 0, m = 1, y = 1, x = 1, b = 0, _ = "", v = n, k = a, T = i, B = _; y; )
    switch (g = b, b = ue()) {
      // (
      case 40:
        if (g != 108 && Dr(B, u - 1) == 58) {
          jS(B += In(ws(b), "&", "&\f"), "&\f", im(c ? o[c - 1] : 0)) != -1 && (x = -1);
          break;
        }
      // " ' [
      case 34:
      case 39:
      case 91:
        B += ws(b);
        break;
      // \t \n \r \s
      case 9:
      case 10:
      case 13:
      case 32:
        B += ZS(g);
        break;
      // \
      case 92:
        B += KS(Pn() - 1, 7);
        continue;
      // /
      case 47:
        switch (je()) {
          case 42:
          case 47:
            vn(eT(QS(ue(), Pn()), t, r, l), l), (Ui(g || 1) == 5 || Ui(je() || 1) == 5) && be(B) && Vr(B, -1, void 0) !== " " && (B += " ");
            break;
          default:
            B += "/";
        }
        break;
      // {
      case 123 * m:
        o[c++] = be(B) * x;
      // } ; \0
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          // \0 }
          case 0:
          case 125:
            y = 0;
          // ;
          case 59 + h:
            x == -1 && (B = In(B, /\f/g, "")), f > 0 && (be(B) - u || m === 0 && g === 47) && vn(f > 32 ? ph(B + ";", i, r, u - 1, l) : ph(In(B, " ", "") + ";", i, r, u - 2, l), l);
            break;
          // @ ;
          case 59:
            B += ";";
          // { rule/at-rule
          default:
            if (vn(T = dh(B, t, r, c, h, n, o, _, v = [], k = [], u, a), a), b === 123)
              if (h === 0)
                Nn(B, t, T, T, v, a, u, o, k);
              else {
                switch (d) {
                  // c(ontainer)
                  case 99:
                    if (Dr(B, 3) === 110) break;
                  // l(ayer)
                  case 108:
                    if (Dr(B, 2) === 97) break;
                  default:
                    h = 0;
                  // d(ocument) m(edia) s(upports)
                  case 100:
                  case 109:
                  case 115:
                }
                h ? Nn(e, T, T, i && vn(dh(e, T, T, 0, 0, n, o, _, n, v = [], u, k), k), n, k, u, o, i ? v : k) : Nn(B, T, T, T, [""], k, 0, o, k);
              }
        }
        c = h = f = 0, m = x = 1, _ = B = "", u = s;
        break;
      // :
      case 58:
        u = 1 + be(B), f = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && GS() == 125)
            continue;
        }
        switch (B += wl(b), b * m) {
          // &
          case 38:
            x = h > 0 ? 1 : (B += "\f", -1);
            break;
          // ,
          case 44:
            o[c++] = (be(B) - 1) * x, x = 1;
            break;
          // @
          case 64:
            je() === 45 && (B += ws(ue())), d = je(), h = u = be(_ = B += JS(Pn())), b++;
            break;
          // -
          case 45:
            g === 45 && be(B) == 2 && (m = 0);
        }
    }
  return a;
}
function dh(e, t, r, i, n, a, s, o, l, c, h, u) {
  for (var d = n - 1, f = n === 0 ? a : [""], g = YS(f), m = 0, y = 0, x = 0; m < i; ++m)
    for (var b = 0, _ = Vr(e, d + 1, d = im(y = s[m])), v = e; b < g; ++b)
      (v = nm(y > 0 ? f[b] + " " + _ : In(_, /&\f/g, f[b]))) && (l[x++] = v);
  return kl(e, t, r, n === 0 ? em : o, l, c, h, u);
}
function eT(e, t, r, i) {
  return kl(e, t, r, tm, wl(US()), Vr(e, 2, -2), 0, i);
}
function ph(e, t, r, i, n) {
  return kl(e, t, r, rm, Vr(e, 0, i), Vr(e, i + 1, -1), i, n);
}
function yo(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function rT(e, t, r, i) {
  switch (e.type) {
    case HS:
      if (e.children.length) break;
    case zS:
    case WS:
    case rm:
      return e.return = e.return || e.value;
    case tm:
      return "";
    case qS:
      return e.return = e.value + "{" + yo(e.children, i) + "}";
    case em:
      if (!be(e.value = e.props.join(","))) return "";
  }
  return be(r = yo(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var iT = Ad(Object.keys, Object), nT = Object.prototype, aT = nT.hasOwnProperty;
function sT(e) {
  if (!Oa(e))
    return iT(e);
  var t = [];
  for (var r in Object(e))
    aT.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var xo = Cr(ve, "DataView"), bo = Cr(ve, "Promise"), Co = Cr(ve, "Set"), _o = Cr(ve, "WeakMap"), gh = "[object Map]", oT = "[object Object]", mh = "[object Promise]", yh = "[object Set]", xh = "[object WeakMap]", bh = "[object DataView]", lT = br(xo), cT = br(Hi), hT = br(bo), uT = br(Co), fT = br(_o), nr = Kr;
(xo && nr(new xo(new ArrayBuffer(1))) != bh || Hi && nr(new Hi()) != gh || bo && nr(bo.resolve()) != mh || Co && nr(new Co()) != yh || _o && nr(new _o()) != xh) && (nr = function(e) {
  var t = Kr(e), r = t == oT ? e.constructor : void 0, i = r ? br(r) : "";
  if (i)
    switch (i) {
      case lT:
        return bh;
      case cT:
        return gh;
      case hT:
        return mh;
      case uT:
        return yh;
      case fT:
        return xh;
    }
  return t;
});
var dT = "[object Map]", pT = "[object Set]", gT = Object.prototype, mT = gT.hasOwnProperty;
function Ch(e) {
  if (e == null)
    return !0;
  if (Ra(e) && (ca(e) || typeof e == "string" || typeof e.splice == "function" || Jo(e) || tl(e) || la(e)))
    return !e.length;
  var t = nr(e);
  if (t == dT || t == pT)
    return !e.size;
  if (Oa(e))
    return !sT(e).length;
  for (var r in e)
    if (mT.call(e, r))
      return !1;
  return !0;
}
var sm = "c4", yT = /* @__PURE__ */ p((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), xT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./c4Diagram-IC4MRINW-CiPUfNys.js");
  return { id: sm, diagram: e };
}, "loader"), bT = {
  id: sm,
  detector: yT,
  loader: xT
}, CT = bT, om = "flowchart", _T = /* @__PURE__ */ p((e, t) => t?.flowchart?.defaultRenderer === "dagre-wrapper" || t?.flowchart?.defaultRenderer === "elk" ? !1 : /^\s*graph/.test(e), "detector"), wT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-PKNHOUZH-CmHzKyJg.js");
  return { id: om, diagram: e };
}, "loader"), kT = {
  id: om,
  detector: _T,
  loader: wT
}, vT = kT, lm = "flowchart-v2", ST = /* @__PURE__ */ p((e, t) => t?.flowchart?.defaultRenderer === "dagre-d3" ? !1 : (t?.flowchart?.defaultRenderer === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && t?.flowchart?.defaultRenderer === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e)), "detector"), TT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-PKNHOUZH-CmHzKyJg.js");
  return { id: lm, diagram: e };
}, "loader"), BT = {
  id: lm,
  detector: ST,
  loader: TT
}, LT = BT, cm = "er", AT = /* @__PURE__ */ p((e) => /^\s*erDiagram/.test(e), "detector"), MT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./erDiagram-INFDFZHY-Btr1tv7Q.js");
  return { id: cm, diagram: e };
}, "loader"), $T = {
  id: cm,
  detector: AT,
  loader: MT
}, ET = $T, hm = "gitGraph", FT = /* @__PURE__ */ p((e) => /^\s*gitGraph/.test(e), "detector"), DT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-K3NZZRJ6-D783Ds1u.js");
  return { id: hm, diagram: e };
}, "loader"), OT = {
  id: hm,
  detector: FT,
  loader: DT
}, RT = OT, um = "gantt", IT = /* @__PURE__ */ p((e) => /^\s*gantt/.test(e), "detector"), PT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./ganttDiagram-A5KZAMGK-pZNw_POm.js");
  return { id: um, diagram: e };
}, "loader"), NT = {
  id: um,
  detector: IT,
  loader: PT
}, zT = NT, fm = "info", WT = /* @__PURE__ */ p((e) => /^\s*info/.test(e), "detector"), qT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./infoDiagram-LFFYTUFH-DcUm3rHi.js");
  return { id: fm, diagram: e };
}, "loader"), HT = {
  id: fm,
  detector: WT,
  loader: qT
}, dm = "pie", jT = /* @__PURE__ */ p((e) => /^\s*pie/.test(e), "detector"), YT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./pieDiagram-SKSYHLDU-D1dWdVuX.js");
  return { id: dm, diagram: e };
}, "loader"), UT = {
  id: dm,
  detector: jT,
  loader: YT
}, pm = "quadrantChart", GT = /* @__PURE__ */ p((e) => /^\s*quadrantChart/.test(e), "detector"), XT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./quadrantDiagram-337W2JSQ-D_BYa8XU.js");
  return { id: pm, diagram: e };
}, "loader"), VT = {
  id: pm,
  detector: GT,
  loader: XT
}, ZT = VT, gm = "xychart", KT = /* @__PURE__ */ p((e) => /^\s*xychart(-beta)?/.test(e), "detector"), QT = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./xychartDiagram-JWTSCODW-BlBLie6x.js");
  return { id: gm, diagram: e };
}, "loader"), JT = {
  id: gm,
  detector: KT,
  loader: QT
}, tB = JT, mm = "requirement", eB = /* @__PURE__ */ p((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), rB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./requirementDiagram-Z7DCOOCP-DwL6Ug7b.js");
  return { id: mm, diagram: e };
}, "loader"), iB = {
  id: mm,
  detector: eB,
  loader: rB
}, nB = iB, ym = "sequence", aB = /* @__PURE__ */ p((e) => /^\s*sequenceDiagram/.test(e), "detector"), sB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./sequenceDiagram-2WXFIKYE-CVREcPPf.js");
  return { id: ym, diagram: e };
}, "loader"), oB = {
  id: ym,
  detector: aB,
  loader: sB
}, lB = oB, xm = "class", cB = /* @__PURE__ */ p((e, t) => t?.class?.defaultRenderer === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e), "detector"), hB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./classDiagram-VBA2DB6C-DK-vGlco.js");
  return { id: xm, diagram: e };
}, "loader"), uB = {
  id: xm,
  detector: cB,
  loader: hB
}, fB = uB, bm = "classDiagram", dB = /* @__PURE__ */ p((e, t) => /^\s*classDiagram/.test(e) && t?.class?.defaultRenderer === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e), "detector"), pB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./classDiagram-v2-RAHNMMFH-DK-vGlco.js");
  return { id: bm, diagram: e };
}, "loader"), gB = {
  id: bm,
  detector: dB,
  loader: pB
}, mB = gB, Cm = "state", yB = /* @__PURE__ */ p((e, t) => t?.state?.defaultRenderer === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e), "detector"), xB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./stateDiagram-RAJIS63D-COIAZrds.js");
  return { id: Cm, diagram: e };
}, "loader"), bB = {
  id: Cm,
  detector: yB,
  loader: xB
}, CB = bB, _m = "stateDiagram", _B = /* @__PURE__ */ p((e, t) => !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && t?.state?.defaultRenderer === "dagre-wrapper"), "detector"), wB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-FVOUBMTO-DHSD12xN.js");
  return { id: _m, diagram: e };
}, "loader"), kB = {
  id: _m,
  detector: _B,
  loader: wB
}, vB = kB, wm = "journey", SB = /* @__PURE__ */ p((e) => /^\s*journey/.test(e), "detector"), TB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./journeyDiagram-4ABVD52K-D4TsOm0L.js");
  return { id: wm, diagram: e };
}, "loader"), BB = {
  id: wm,
  detector: SB,
  loader: TB
}, LB = BB, AB = /* @__PURE__ */ p((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = o2(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), Gh(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), km = { draw: AB }, MB = km, $B = {
  db: {},
  renderer: km,
  parser: {
    parse: /* @__PURE__ */ p(() => {
    }, "parse")
  }
}, EB = $B, vm = "flowchart-elk", FB = /* @__PURE__ */ p((e, t = {}) => (
  // If diagram explicitly states flowchart-elk
  /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
  /^\s*(flowchart|graph)/.test(e) && t?.flowchart?.defaultRenderer === "elk" ? (t.layout = "elk", !0) : !1
), "detector"), DB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-PKNHOUZH-CmHzKyJg.js");
  return { id: vm, diagram: e };
}, "loader"), OB = {
  id: vm,
  detector: FB,
  loader: DB
}, RB = OB, Sm = "timeline", IB = /* @__PURE__ */ p((e) => /^\s*timeline/.test(e), "detector"), PB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./timeline-definition-YZTLITO2-BQNFnP36.js");
  return { id: Sm, diagram: e };
}, "loader"), NB = {
  id: Sm,
  detector: IB,
  loader: PB
}, zB = NB, Tm = "mindmap", WB = /* @__PURE__ */ p((e) => /^\s*mindmap/.test(e), "detector"), qB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./mindmap-definition-YRQLILUH-Ci0Kp5YP.js");
  return { id: Tm, diagram: e };
}, "loader"), HB = {
  id: Tm,
  detector: WB,
  loader: qB
}, jB = HB, Bm = "kanban", YB = /* @__PURE__ */ p((e) => /^\s*kanban/.test(e), "detector"), UB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./kanban-definition-K7BYSVSG-CLPflfbz.js");
  return { id: Bm, diagram: e };
}, "loader"), GB = {
  id: Bm,
  detector: YB,
  loader: UB
}, XB = GB, Lm = "sankey", VB = /* @__PURE__ */ p((e) => /^\s*sankey(-beta)?/.test(e), "detector"), ZB = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./sankeyDiagram-WA2Y5GQK-DZ_GzLFJ.js");
  return { id: Lm, diagram: e };
}, "loader"), KB = {
  id: Lm,
  detector: VB,
  loader: ZB
}, QB = KB, Am = "packet", JB = /* @__PURE__ */ p((e) => /^\s*packet(-beta)?/.test(e), "detector"), tL = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-P4PSJMXO-DNr7Ul8U.js");
  return { id: Am, diagram: e };
}, "loader"), eL = {
  id: Am,
  detector: JB,
  loader: tL
}, Mm = "radar", rL = /* @__PURE__ */ p((e) => /^\s*radar-beta/.test(e), "detector"), iL = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-IFDJBPK2-BpBaMU0C.js");
  return { id: Mm, diagram: e };
}, "loader"), nL = {
  id: Mm,
  detector: rL,
  loader: iL
}, $m = "block", aL = /* @__PURE__ */ p((e) => /^\s*block(-beta)?/.test(e), "detector"), sL = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./blockDiagram-WCTKOSBZ-LYVC8du3.js");
  return { id: $m, diagram: e };
}, "loader"), oL = {
  id: $m,
  detector: aL,
  loader: sL
}, lL = oL, Em = "architecture", cL = /* @__PURE__ */ p((e) => /^\s*architecture/.test(e), "detector"), hL = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./architectureDiagram-2XIMDMQ5-Dt7_BsvH.js");
  return { id: Em, diagram: e };
}, "loader"), uL = {
  id: Em,
  detector: cL,
  loader: hL
}, fL = uL, Fm = "ishikawa", dL = /* @__PURE__ */ p((e) => /^\s*ishikawa(-beta)?\b/i.test(e), "detector"), pL = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./ishikawaDiagram-PHBUUO56-DRCTQrPq.js");
  return { id: Fm, diagram: e };
}, "loader"), gL = {
  id: Fm,
  detector: dL,
  loader: pL
}, Dm = "venn", mL = /* @__PURE__ */ p((e) => /^\s*venn-beta/.test(e), "detector"), yL = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./vennDiagram-LZ73GAT5-BlRHMuis.js");
  return { id: Dm, diagram: e };
}, "loader"), xL = {
  id: Dm,
  detector: mL,
  loader: yL
}, bL = xL, Om = "treemap", CL = /* @__PURE__ */ p((e) => /^\s*treemap/.test(e), "detector"), _L = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-E7M64L7V-D6hQV7J2.js");
  return { id: Om, diagram: e };
}, "loader"), wL = {
  id: Om,
  detector: CL,
  loader: _L
}, _h = !1, Ua = /* @__PURE__ */ p(() => {
  _h || (_h = !0, jn("error", EB, (e) => e.toLowerCase().trim() === "error"), jn(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ p(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ p(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ p(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ p(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), Ts(RB, jB, fL), Ts(
    CT,
    XB,
    mB,
    fB,
    ET,
    zT,
    HT,
    UT,
    nB,
    lB,
    LT,
    vT,
    zB,
    RT,
    vB,
    CB,
    LB,
    ZT,
    QB,
    eL,
    tB,
    lL,
    nL,
    gL,
    wL,
    bL
  ));
}, "addDiagrams"), kL = /* @__PURE__ */ p(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(ur).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          Ms(r);
        } catch {
          try {
            const { diagram: a, id: s } = await n();
            jn(s, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete ur[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), vL = "graphics-document document";
function Rm(e, t) {
  e.attr("role", vL), t !== "" && e.attr("aria-roledescription", t);
}
p(Rm, "setA11yDiagramInfo");
function Im(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
p(Im, "addSVGa11yTitleDescription");
var hr, wo = (hr = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    const i = Dt(), n = So(t, i);
    t = hk(t) + `
`;
    try {
      Ms(n);
    } catch {
      const c = P0(n);
      if (!c)
        throw new Fh(`Diagram ${n} not found.`);
      const { id: h, diagram: u } = await c();
      jn(h, u);
    }
    const { db: a, parser: s, renderer: o, init: l } = Ms(n);
    return s.parser && (s.parser.yy = a), a.clear?.(), l?.(i), r.title && a.setDiagramTitle?.(r.title), await s.parse(t), new hr(n, t, a, s, o);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, p(hr, "Diagram"), hr), wh = [], SL = /* @__PURE__ */ p(() => {
  wh.forEach((e) => {
    e();
  }), wh = [];
}, "attachFunctions"), TL = /* @__PURE__ */ p((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function Pm(e) {
  const t = e.match(Eh);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = pC(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: dC
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
p(Pm, "extractFrontMatter");
var BL = /* @__PURE__ */ p((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), LL = /* @__PURE__ */ p((e) => {
  const { text: t, metadata: r } = Pm(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), AL = /* @__PURE__ */ p((e) => {
  const t = ce.detectInit(e) ?? {}, r = ce.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : r?.type === "wrap" && (t.wrap = !0), {
    text: Kw(e),
    directive: t
  };
}, "processDirectives");
function vl(e) {
  const t = BL(e), r = LL(t), i = AL(r.text), n = sl(r.config, i.directive);
  return e = TL(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
p(vl, "preprocessDiagram");
function Nm(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
p(Nm, "toBase64");
var ML = 5e4, $L = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", EL = "sandbox", FL = "loose", DL = "http://www.w3.org/2000/svg", OL = "http://www.w3.org/1999/xlink", RL = "http://www.w3.org/1999/xhtml", IL = "100%", PL = "100%", NL = "border:0;margin:0;", zL = "margin:0", WL = "allow-top-navigation-by-user-activation allow-popups", qL = 'The "iframe" tag is not supported by your browser.', HL = ["foreignobject"], jL = ["dominant-baseline"];
function Sl(e) {
  const t = vl(e);
  return qn(), ty(t.config ?? {}), t;
}
p(Sl, "processAndSetConfigs");
async function zm(e, t) {
  Ua();
  try {
    const { code: r, config: i } = Sl(e);
    return { diagramType: (await qm(r)).type, config: i };
  } catch (r) {
    if (t?.suppressErrors)
      return !1;
    throw r;
  }
}
p(zm, "parse");
var kh = /* @__PURE__ */ p((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), YL = /* @__PURE__ */ p((e, t = /* @__PURE__ */ new Map()) => {
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = It(e) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((o) => {
      Ch(o.styles) || s.forEach((l) => {
        r += kh(o.id, l, o.styles);
      }), Ch(o.textStyles) || (r += kh(
        o.id,
        "tspan",
        (o?.textStyles || []).map((l) => l.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), UL = /* @__PURE__ */ p((e, t, r, i) => {
  const n = YL(e, r), a = by(t, n, e.themeVariables);
  return yo(tT(`${i}{${a}}`), rT);
}, "createUserStyles"), GL = /* @__PURE__ */ p((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = Jr(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), XL = /* @__PURE__ */ p((e = "", t) => {
  const r = t?.viewBox?.baseVal?.height ? t.viewBox.baseVal.height + "px" : PL, i = Nm(`<body style="${zL}">${e}</body>`);
  return `<iframe style="width:${IL};height:${r};${NL}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${WL}">
  ${qL}
</iframe>`;
}, "putIntoIFrame"), vh = /* @__PURE__ */ p((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const s = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", DL);
  return n && s.attr("xmlns:xlink", n), s.append("g"), e;
}, "appendDivSvgG");
function ko(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
p(ko, "sandboxedIframe");
var VL = /* @__PURE__ */ p((e, t, r, i) => {
  e.getElementById(t)?.remove(), e.getElementById(r)?.remove(), e.getElementById(i)?.remove();
}, "removeExistingElements"), ZL = /* @__PURE__ */ p(async function(e, t, r) {
  Ua();
  const i = Sl(t);
  t = i.code;
  const n = Dt();
  F.debug(n), t.length > (n?.maxTextSize ?? ML) && (t = $L);
  const a = "#" + e, s = "i" + e, o = "#" + s, l = "d" + e, c = "#" + l, h = /* @__PURE__ */ p(() => {
    const R = lt(d ? o : c).node();
    R && "remove" in R && R.remove();
  }, "removeTempElements");
  let u = lt("body");
  const d = n.securityLevel === EL, f = n.securityLevel === FL, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), d) {
      const N = ko(lt(r), s);
      u = lt(N.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = lt(r);
    vh(u, e, l, `font-family: ${g}`, OL);
  } else {
    if (VL(document, e, l, s), d) {
      const N = ko(lt("body"), s);
      u = lt(N.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = lt("body");
    vh(u, e, l);
  }
  let m, y;
  try {
    m = await wo.fromText(t, { title: i.title });
  } catch (N) {
    if (n.suppressErrorRendering)
      throw h(), N;
    m = await wo.fromText("error"), y = N;
  }
  const x = u.select(c).node(), b = m.type, _ = x.firstChild, v = _.firstChild, k = m.renderer.getClasses?.(t, m), T = UL(n, b, k, a), B = document.createElement("style");
  B.innerHTML = T, _.insertBefore(B, v);
  try {
    await m.renderer.draw(t, e, "11.13.0", m);
  } catch (N) {
    throw n.suppressErrorRendering ? h() : MB.draw(t, e, "11.13.0"), N;
  }
  const D = u.select(`${c} svg`), I = m.db.getAccTitle?.(), O = m.db.getAccDescription?.();
  Hm(b, D, I, O), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", RL);
  let $ = u.select(c).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), $ = GL($, d, Ze(n.arrowMarkerAbsolute)), d) {
    const N = u.select(c + " svg").node();
    $ = XL($, N);
  } else f || ($ = Hr.sanitize($, {
    ADD_TAGS: HL,
    ADD_ATTR: jL,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (SL(), y)
    throw y;
  return h(), {
    diagramType: b,
    svg: $,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function Wm(e = {}) {
  const t = St({}, e);
  t?.fontFamily && !t.themeVariables?.fontFamily && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), Q0(t), t?.theme && t.theme in Ee ? t.themeVariables = Ee[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = Ee.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? K0(t) : Ph();
  vo(r.logLevel), Ua();
}
p(Wm, "initialize");
var qm = /* @__PURE__ */ p((e, t = {}) => {
  const { code: r } = vl(e);
  return wo.fromText(r, t);
}, "getDiagramFromText");
function Hm(e, t, r, i) {
  Rm(t, e), Im(t, r, i, t.attr("id"));
}
p(Hm, "addA11yInfo");
var yr = Object.freeze({
  render: ZL,
  parse: zm,
  getDiagramFromText: qm,
  initialize: Wm,
  getConfig: Dt,
  setConfig: Nh,
  getSiteConfig: Ph,
  updateSiteConfig: J0,
  reset: /* @__PURE__ */ p(() => {
    qn();
  }, "reset"),
  globalReset: /* @__PURE__ */ p(() => {
    qn(jr);
  }, "globalReset"),
  defaultConfig: jr
});
vo(Dt().logLevel);
qn(Dt());
var KL = /* @__PURE__ */ p((e, t, r) => {
  F.warn(e), al(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), jm = /* @__PURE__ */ p(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await QL(e);
  } catch (t) {
    if (al(t) && F.error(t.str), Re.parseError && Re.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), QL = /* @__PURE__ */ p(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = yr.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), i?.startOnLoad !== void 0 && (F.debug("Start On Load: " + i?.startOnLoad), yr.updateSiteConfig({ startOnLoad: i?.startOnLoad }));
  const a = new ce.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let s;
  const o = [];
  for (const l of Array.from(n)) {
    if (F.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
      continue;
    l.setAttribute("data-processed", "true");
    const c = `mermaid-${a.next()}`;
    s = l.innerHTML, s = cp(ce.entityDecode(s)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = ce.detectInit(s);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: d } = await Xm(c, s, l);
      l.innerHTML = u, e && await e(c), d && d(l);
    } catch (u) {
      KL(u, o, Re.parseError);
    }
  }
  if (o.length > 0)
    throw o[0];
}, "runThrowsErrors"), Ym = /* @__PURE__ */ p(function(e) {
  yr.initialize(e);
}, "initialize"), JL = /* @__PURE__ */ p(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && Ym(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await jm(i);
}, "init"), tA = /* @__PURE__ */ p(async (e, {
  lazyLoad: t = !0
} = {}) => {
  Ua(), Ts(...e), t === !1 && await kL();
}, "registerExternalDiagrams"), Um = /* @__PURE__ */ p(function() {
  if (Re.startOnLoad) {
    const { startOnLoad: e } = yr.getConfig();
    e && Re.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", Um, !1);
var eA = /* @__PURE__ */ p(function(e) {
  Re.parseError = e;
}, "setParseErrorHandler"), Ca = [], ks = !1, Gm = /* @__PURE__ */ p(async () => {
  if (!ks) {
    for (ks = !0; Ca.length > 0; ) {
      const e = Ca.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    ks = !1;
  }
}, "executeQueue"), rA = /* @__PURE__ */ p(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ p(() => new Promise((a, s) => {
    yr.parse(e, t).then(
      (o) => {
        a(o), r(o);
      },
      (o) => {
        F.error("Error parsing", o), Re.parseError?.(o), s(o), i(o);
      }
    );
  }), "performCall");
  Ca.push(n), Gm().catch(i);
}), "parse"), Xm = /* @__PURE__ */ p((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ p(() => new Promise((s, o) => {
    yr.render(e, t, r).then(
      (l) => {
        s(l), i(l);
      },
      (l) => {
        F.error("Error parsing", l), Re.parseError?.(l), o(l), n(l);
      }
    );
  }), "performCall");
  Ca.push(a), Gm().catch(n);
}), "render"), iA = /* @__PURE__ */ p(() => Object.keys(ur).map((e) => ({
  id: e
})), "getRegisteredDiagramsMetadata"), Re = {
  startOnLoad: !0,
  mermaidAPI: yr,
  parse: rA,
  render: Xm,
  init: JL,
  run: jm,
  registerExternalDiagrams: tA,
  registerLayoutLoaders: Jg,
  initialize: Ym,
  parseError: void 0,
  contentLoaded: Um,
  setParseErrorHandler: eA,
  detectType: So,
  registerIconPacks: yv,
  getRegisteredDiagramsMetadata: iA
}, nA = Re;
const DA = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: nA
}, Symbol.toStringTag, { value: "Module" }));
export {
  Xh as $,
  cA as A,
  Bi as B,
  l0 as C,
  Ly as D,
  sl as E,
  Ih as F,
  Dt as G,
  rk as H,
  o2 as I,
  dC as J,
  j0 as K,
  Fi as L,
  oA as M,
  Ia as N,
  ly as O,
  Uh as P,
  tc as Q,
  Q1 as R,
  zs as S,
  ek as T,
  Xi as U,
  my as V,
  Gi as W,
  H as X,
  tt as Y,
  Gw as Z,
  p as _,
  wy as a,
  Cw as a$,
  X1 as a0,
  Po as a1,
  dA as a2,
  mA as a3,
  Br as a4,
  Cc as a5,
  bc as a6,
  xA as a7,
  yA as a8,
  gA as a9,
  $A as aA,
  BA as aB,
  V as aC,
  LA as aD,
  bS as aE,
  pS as aF,
  dS as aG,
  bv as aH,
  Bh as aI,
  V1 as aJ,
  sA as aK,
  rn as aL,
  yv as aM,
  mv as aN,
  Do as aO,
  qe as aP,
  Ri as aQ,
  dc as aR,
  Lb as aS,
  xr as aT,
  jw as aU,
  Id as aV,
  Ea as aW,
  Ra as aX,
  ca as aY,
  Nd as aZ,
  Rd as a_,
  uA as aa,
  fA as ab,
  pA as ac,
  CA as ad,
  bA as ae,
  jv as af,
  Vg as ag,
  MA as ah,
  gC as ai,
  It as aj,
  Pe as ak,
  ui as al,
  ol as am,
  Yd as an,
  Jr as ao,
  Vd as ap,
  st as aq,
  _e as ar,
  j as as,
  Hw as at,
  O_ as au,
  Rw as av,
  Ko as aw,
  Ch as ax,
  IS as ay,
  AA as az,
  _y as b,
  G as b0,
  Zd as b1,
  Vt as b2,
  _b as b3,
  Fo as b4,
  lu as b5,
  Ki as b6,
  uu as b7,
  hA as b8,
  o0 as b9,
  tl as bA,
  Ed as bB,
  Co as bC,
  Yw as bD,
  Oa as bE,
  DA as bF,
  qw as ba,
  Ow as bb,
  w_ as bc,
  Qo as bd,
  mw as be,
  Uw as bf,
  tn as bg,
  Kr as bh,
  sa as bi,
  Bw as bj,
  sT as bk,
  Ji as bl,
  la as bm,
  _w as bn,
  Md as bo,
  S_ as bp,
  T_ as bq,
  nr as br,
  zc as bs,
  B_ as bt,
  Jo as bu,
  v_ as bv,
  M_ as bw,
  Qr as bx,
  Ke as by,
  Oc as bz,
  ft as c,
  lt as d,
  Gh as e,
  St as f,
  vy as g,
  Oe as h,
  fe as i,
  xC as j,
  Vi as k,
  F as l,
  Gd as m,
  lA as n,
  FA as o,
  Sy as p,
  Ty as q,
  EA as r,
  ky as s,
  pC as t,
  ce as u,
  cS as v,
  ak as w,
  _A as x,
  Hr as y,
  Cy as z
};
