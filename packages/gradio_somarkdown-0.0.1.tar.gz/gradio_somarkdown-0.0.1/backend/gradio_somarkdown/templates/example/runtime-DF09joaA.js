var Tt = Array.isArray, kt = Array.prototype.indexOf, te = Array.prototype.includes, En = Array.from, mn = Object.defineProperty, ue = Object.getOwnPropertyDescriptor, Rt = Object.getOwnPropertyDescriptors, Pt = Object.prototype, Ot = Array.prototype, $e = Object.getPrototypeOf, qe = Object.isExtensible;
const Nt = () => {
};
function Dt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function Ze() {
  var e, t, n = new Promise((r, s) => {
    e = r, t = s;
  });
  return { promise: n, resolve: e, reject: t };
}
const E = 2, ne = 4, be = 8, We = 1 << 24, G = 16, F = 32, $ = 64, It = 128, T = 512, g = 1024, x = 2048, I = 4096, q = 8192, D = 16384, Q = 32768, Ye = 1 << 25, Te = 65536, Ue = 1 << 17, Mt = 1 << 18, ve = 1 << 19, Ct = 1 << 20, Z = 65536, ke = 1 << 21, De = 1 << 22, Y = 1 << 23, oe = /* @__PURE__ */ Symbol("$state"), bn = /* @__PURE__ */ Symbol("legacy props"), C = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Ft() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function jt(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Lt() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function qt(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function Yt() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function Sn(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function Ut() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Bt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Gt() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function An() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
const Tn = 1, kn = 2, Rn = 4, Pn = 8, On = 16, Nn = 2, m = /* @__PURE__ */ Symbol(), Vt = "http://www.w3.org/1999/xhtml", Dn = "http://www.w3.org/2000/svg", In = "http://www.w3.org/1998/Math/MathML";
function Je(e) {
  return e === this.v;
}
function Kt(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function zt(e) {
  return !Kt(e, this.v);
}
let Ie = !1;
function Mn() {
  Ie = !0;
}
let R = null;
function ge(e) {
  R = e;
}
function Cn(e, t = !1, n) {
  R = {
    p: R,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    r: (
      /** @type {Effect} */
      h
    ),
    l: Ie && !t ? { s: null, u: null, $: [] } : null
  };
}
function Fn(e) {
  var t = (
    /** @type {ComponentContext} */
    R
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      dt(r);
  }
  return t.i = !0, R = t.p, /** @type {T} */
  {};
}
function he() {
  return !Ie || R !== null && R.l === null;
}
let K = [];
function Qe() {
  var e = K;
  K = [], Dt(e);
}
function Be(e) {
  if (K.length === 0 && !ce) {
    var t = K;
    queueMicrotask(() => {
      t === K && Qe();
    });
  }
  K.push(e);
}
function Ht() {
  for (; K.length > 0; )
    Qe();
}
function $t(e) {
  var t = h;
  if (t === null)
    return v.f |= Y, e;
  if ((t.f & Q) === 0 && (t.f & ne) === 0)
    throw e;
  Ee(e, t);
}
function Ee(e, t) {
  for (; t !== null; ) {
    if ((t.f & It) !== 0) {
      if ((t.f & Q) === 0)
        throw e;
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    }
    t = t.parent;
  }
  throw e;
}
const Zt = -7169;
function y(e, t) {
  e.f = e.f & Zt | t;
}
function Me(e) {
  (e.f & T) !== 0 || e.deps === null ? y(e, g) : y(e, I);
}
function Xe(e) {
  if (e !== null)
    for (const t of e)
      (t.f & E) === 0 || (t.f & Z) === 0 || (t.f ^= Z, Xe(
        /** @type {Derived} */
        t.deps
      ));
}
function Wt(e, t, n) {
  (e.f & x) !== 0 ? t.add(e) : (e.f & I) !== 0 && n.add(e), Xe(e.deps), y(e, g);
}
const X = /* @__PURE__ */ new Set();
let w = null, O = null, Re = null, ce = !1, Se = !1, ee = null, we = null;
var Ge = 0;
let Jt = 1;
class re {
  // for debugging. TODO remove once async is stable
  id = Jt++;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<(batch: Batch) => void>}
   */
  #s = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #l = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #f = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #i = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #u = null;
  /**
   * The root effects that need to be flushed
   * @type {Effect[]}
   */
  #e = [];
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #r = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * A map of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`.
   * The value contains child effects that were dirty/maybe_dirty before being reset,
   * so they can be rescheduled if the branch survives.
   * @type {Map<Effect, { d: Effect[], m: Effect[] }>}
   */
  #n = /* @__PURE__ */ new Map();
  is_fork = !1;
  #a = !1;
  #o() {
    return this.is_fork || this.#i > 0;
  }
  /**
   * Add an effect to the #skipped_branches map and reset its children
   * @param {Effect} effect
   */
  skip_effect(t) {
    this.#n.has(t) || this.#n.set(t, { d: [], m: [] });
  }
  /**
   * Remove an effect from the #skipped_branches map and reschedule
   * any tracked dirty/maybe_dirty child effects
   * @param {Effect} effect
   */
  unskip_effect(t) {
    var n = this.#n.get(t);
    if (n) {
      this.#n.delete(t);
      for (var r of n.d)
        y(r, x), this.schedule(r);
      for (r of n.m)
        y(r, I), this.schedule(r);
    }
  }
  #c() {
    if (Ge++ > 1e3 && (X.delete(this), Xt()), !this.#o()) {
      for (const f of this.#r)
        this.#t.delete(f), y(f, x), this.schedule(f);
      for (const f of this.#t)
        y(f, I), this.schedule(f);
    }
    const t = this.#e;
    this.#e = [], this.apply();
    var n = ee = [], r = [], s = we = [];
    for (const f of t)
      try {
        this.#_(f, n, r);
      } catch (l) {
        throw rt(f), l;
      }
    if (w = null, s.length > 0) {
      var i = re.ensure();
      for (const f of s)
        i.schedule(f);
    }
    if (ee = null, we = null, this.#o()) {
      this.#v(r), this.#v(n);
      for (const [f, l] of this.#n)
        nt(f, l);
    } else {
      this.#f === 0 && X.delete(this), this.#r.clear(), this.#t.clear();
      for (const f of this.#s) f(this);
      this.#s.clear(), Ve(r), Ve(n), this.#u?.resolve();
    }
    var u = (
      /** @type {Batch | null} */
      /** @type {unknown} */
      w
    );
    if (this.#e.length > 0) {
      const f = u ??= this;
      f.#e.push(...this.#e.filter((l) => !f.#e.includes(l)));
    }
    u !== null && (X.add(u), u.#c()), X.has(this) || this.#h();
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #_(t, n, r) {
    t.f ^= g;
    for (var s = t.first; s !== null; ) {
      var i = s.f, u = (i & (F | $)) !== 0, f = u && (i & g) !== 0, l = f || (i & q) !== 0 || this.#n.has(s);
      if (!l && s.fn !== null) {
        u ? s.f ^= g : (i & ne) !== 0 ? n.push(s) : de(s) && ((i & G) !== 0 && this.#t.add(s), le(s));
        var a = s.first;
        if (a !== null) {
          s = a;
          continue;
        }
      }
      for (; s !== null; ) {
        var o = s.next;
        if (o !== null) {
          s = o;
          break;
        }
        s = s.parent;
      }
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #v(t) {
    for (var n = 0; n < t.length; n += 1)
      Wt(t[n], this.#r, this.#t);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} old_value
   */
  capture(t, n) {
    n !== m && !this.previous.has(t) && this.previous.set(t, n), (t.f & Y) === 0 && (this.current.set(t, t.v), O?.set(t, t.v));
  }
  activate() {
    w = this;
  }
  deactivate() {
    w = null, O = null;
  }
  flush() {
    try {
      Se = !0, w = this, this.#c();
    } finally {
      Ge = 0, Re = null, ee = null, we = null, Se = !1, w = null, O = null, U.clear();
    }
  }
  discard() {
    for (const t of this.#l) t(this);
    this.#l.clear();
  }
  #h() {
    for (const l of X) {
      var t = l.id < this.id, n = [];
      for (const [a, o] of this.current) {
        if (l.current.has(a))
          if (t && o !== l.current.get(a))
            l.current.set(a, o);
          else
            continue;
        n.push(a);
      }
      if (n.length !== 0) {
        var r = [...l.current.keys()].filter((a) => !this.current.has(a));
        if (r.length > 0) {
          l.activate();
          var s = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map();
          for (var u of n)
            et(u, r, s, i);
          if (l.#e.length > 0) {
            l.apply();
            for (var f of l.#e)
              l.#_(f, [], []);
            l.#e = [];
          }
          l.deactivate();
        }
      }
    }
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#f += 1, t && (this.#i += 1);
  }
  /**
   * @param {boolean} blocking
   * @param {boolean} skip - whether to skip updates (because this is triggered by a stale reaction)
   */
  decrement(t, n) {
    this.#f -= 1, t && (this.#i -= 1), !(this.#a || n) && (this.#a = !0, Be(() => {
      this.#a = !1, this.flush();
    }));
  }
  /**
   * @param {Set<Effect>} dirty_effects
   * @param {Set<Effect>} maybe_dirty_effects
   */
  transfer_effects(t, n) {
    for (const r of t)
      this.#r.add(r);
    for (const r of n)
      this.#t.add(r);
    t.clear(), n.clear();
  }
  /** @param {(batch: Batch) => void} fn */
  oncommit(t) {
    this.#s.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#l.add(t);
  }
  settled() {
    return (this.#u ??= Ze()).promise;
  }
  static ensure() {
    if (w === null) {
      const t = w = new re();
      Se || (X.add(w), ce || Be(() => {
        w === t && t.flush();
      }));
    }
    return w;
  }
  apply() {
    {
      O = null;
      return;
    }
  }
  /**
   *
   * @param {Effect} effect
   */
  schedule(t) {
    if (Re = t, t.b?.is_pending && (t.f & (ne | be | We)) !== 0 && (t.f & Q) === 0) {
      t.b.defer_effect(t);
      return;
    }
    for (var n = t; n.parent !== null; ) {
      n = n.parent;
      var r = n.f;
      if (ee !== null && n === h && (v === null || (v.f & E) === 0))
        return;
      if ((r & ($ | F)) !== 0) {
        if ((r & g) === 0)
          return;
        n.f ^= g;
      }
    }
    this.#e.push(n);
  }
}
function Qt(e) {
  var t = ce;
  ce = !0;
  try {
    for (var n; ; ) {
      if (Ht(), w === null)
        return (
          /** @type {T} */
          n
        );
      w.flush();
    }
  } finally {
    ce = t;
  }
}
function Xt() {
  try {
    Yt();
  } catch (e) {
    Ee(e, Re);
  }
}
let M = null;
function Ve(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & (D | q)) === 0 && de(r) && (M = /* @__PURE__ */ new Set(), le(r), r.deps === null && r.first === null && r.nodes === null && r.teardown === null && r.ac === null && wt(r), M?.size > 0)) {
        U.clear();
        for (const s of M) {
          if ((s.f & (D | q)) !== 0) continue;
          const i = [s];
          let u = s.parent;
          for (; u !== null; )
            M.has(u) && (M.delete(u), i.push(u)), u = u.parent;
          for (let f = i.length - 1; f >= 0; f--) {
            const l = i[f];
            (l.f & (D | q)) === 0 && le(l);
          }
        }
        M.clear();
      }
    }
    M = null;
  }
}
function et(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const s of e.reactions) {
      const i = s.f;
      (i & E) !== 0 ? et(
        /** @type {Derived} */
        s,
        t,
        n,
        r
      ) : (i & (De | G)) !== 0 && (i & x) === 0 && tt(s, t, r) && (y(s, x), Ce(
        /** @type {Effect} */
        s
      ));
    }
}
function tt(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const s of e.deps) {
      if (te.call(t, s))
        return !0;
      if ((s.f & E) !== 0 && tt(
        /** @type {Derived} */
        s,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          s,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function Ce(e) {
  w.schedule(e);
}
function nt(e, t) {
  if (!((e.f & F) !== 0 && (e.f & g) !== 0)) {
    (e.f & x) !== 0 ? t.d.push(e) : (e.f & I) !== 0 && t.m.push(e), y(e, g);
    for (var n = e.first; n !== null; )
      nt(n, t), n = n.next;
  }
}
function rt(e) {
  y(e, g);
  for (var t = e.first; t !== null; )
    rt(t), t = t.next;
}
function en(e, t, n, r) {
  const s = he() ? Fe : rn;
  var i = e.filter((c) => !c.settled);
  if (n.length === 0 && i.length === 0) {
    r(t.map(s));
    return;
  }
  var u = (
    /** @type {Effect} */
    h
  ), f = tn(), l = i.length === 1 ? i[0].promise : i.length > 1 ? Promise.all(i.map((c) => c.promise)) : null;
  function a(c) {
    f();
    try {
      r(c);
    } catch (p) {
      (u.f & D) === 0 && Ee(p, u);
    }
    me();
  }
  if (n.length === 0) {
    l.then(() => a(t.map(s)));
    return;
  }
  var o = st();
  function _() {
    Promise.all(n.map((c) => /* @__PURE__ */ nn(c))).then((c) => a([...t.map(s), ...c])).catch((c) => Ee(c, u)).finally(() => o());
  }
  l ? l.then(() => {
    f(), _(), me();
  }) : _();
}
function tn() {
  var e = (
    /** @type {Effect} */
    h
  ), t = v, n = R, r = (
    /** @type {Batch} */
    w
  );
  return function(i = !0) {
    se(e), B(t), ge(n), i && (e.f & D) === 0 && (r?.activate(), r?.apply());
  };
}
function me(e = !0) {
  se(null), B(null), ge(null), e && w?.deactivate();
}
function st() {
  var e = (
    /** @type {Boundary} */
    /** @type {Effect} */
    h.b
  ), t = (
    /** @type {Batch} */
    w
  ), n = e.is_rendered();
  return e.update_pending_count(1, t), t.increment(n), (r = !1) => {
    e.update_pending_count(-1, t), t.decrement(n, r);
  };
}
// @__NO_SIDE_EFFECTS__
function Fe(e) {
  var t = E | x, n = v !== null && (v.f & E) !== 0 ? (
    /** @type {Derived} */
    v
  ) : null;
  return h !== null && (h.f |= ve), {
    ctx: R,
    deps: null,
    effects: null,
    equals: Je,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      m
    ),
    wv: 0,
    parent: n ?? h,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function nn(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    h
  );
  r === null && Ft();
  var s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), i = at(
    /** @type {V} */
    m
  ), u = !v, f = /* @__PURE__ */ new Map();
  return hn(() => {
    var l = (
      /** @type {Effect} */
      h
    ), a = Ze();
    s = a.promise;
    try {
      Promise.resolve(e()).then(a.resolve, a.reject).finally(me);
    } catch (p) {
      a.reject(p), me();
    }
    var o = (
      /** @type {Batch} */
      w
    );
    if (u) {
      if ((l.f & Q) !== 0)
        var _ = st();
      if (
        /** @type {Boundary} */
        r.b.is_rendered()
      )
        f.get(o)?.reject(C), f.delete(o);
      else {
        for (const p of f.values())
          p.reject(C);
        f.clear();
      }
      f.set(o, a);
    }
    const c = (p, d = void 0) => {
      if (_) {
        var P = d === C;
        _(P);
      }
      if (!(d === C || (l.f & D) !== 0)) {
        if (o.activate(), d)
          i.f |= Y, Oe(i, d);
        else {
          (i.f & Y) !== 0 && (i.f ^= Y), Oe(i, p);
          for (const [fe, pe] of f) {
            if (f.delete(fe), fe === o) break;
            pe.reject(C);
          }
        }
        o.deactivate();
      }
    };
    a.promise.then(c, (p) => c(null, p || "unknown"));
  }), vn(() => {
    for (const l of f.values())
      l.reject(C);
  }), new Promise((l) => {
    function a(o) {
      function _() {
        o === s ? l(i) : a(s);
      }
      o.then(_, _);
    }
    a(s);
  });
}
// @__NO_SIDE_EFFECTS__
function jn(e) {
  const t = /* @__PURE__ */ Fe(e);
  return gt(t), t;
}
// @__NO_SIDE_EFFECTS__
function rn(e) {
  const t = /* @__PURE__ */ Fe(e);
  return t.equals = zt, t;
}
function sn(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      W(
        /** @type {Effect} */
        t[n]
      );
  }
}
function ln(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & E) === 0)
      return (t.f & D) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function je(e) {
  var t, n = h;
  se(ln(e));
  try {
    e.f &= ~Z, sn(e), t = xt(e);
  } finally {
    se(n);
  }
  return t;
}
function lt(e) {
  var t = e.v, n = je(e);
  if (!e.equals(n) && (e.wv = mt(), (!w?.is_fork || e.deps === null) && (e.v = n, w?.capture(e, t), e.deps === null))) {
    y(e, g);
    return;
  }
  J || (O !== null ? (ht() || w?.is_fork) && O.set(e, n) : Me(e));
}
function fn(e) {
  if (e.effects !== null)
    for (const t of e.effects)
      (t.teardown || t.ac) && (t.teardown?.(), t.ac?.abort(C), t.teardown = Nt, t.ac = null, _e(t, 0), Le(t));
}
function ft(e) {
  if (e.effects !== null)
    for (const t of e.effects)
      t.teardown && le(t);
}
let Pe = /* @__PURE__ */ new Set();
const U = /* @__PURE__ */ new Map();
let it = !1;
function at(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: Je,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function L(e, t) {
  const n = at(e);
  return gt(n), n;
}
function V(e, t, n = !1) {
  v !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!N || (v.f & Ue) !== 0) && he() && (v.f & (E | G | De | Ue)) !== 0 && (k === null || !te.call(k, e)) && Gt();
  let r = n ? ie(t) : t;
  return Oe(e, r, we);
}
function Oe(e, t, n = null) {
  if (!e.equals(t)) {
    var r = e.v;
    J ? U.set(e, t) : U.set(e, r), e.v = t;
    var s = re.ensure();
    if (s.capture(e, r), (e.f & E) !== 0) {
      const i = (
        /** @type {Derived} */
        e
      );
      (e.f & x) !== 0 && je(i), O === null && Me(i);
    }
    e.wv = mt(), ut(e, x, n), he() && h !== null && (h.f & g) !== 0 && (h.f & (F | $)) === 0 && (A === null ? yn([e]) : A.push(e)), !s.is_fork && Pe.size > 0 && !it && an();
  }
  return t;
}
function an() {
  it = !1;
  for (const e of Pe)
    (e.f & g) !== 0 && y(e, I), de(e) && le(e);
  Pe.clear();
}
function Ae(e) {
  V(e, e.v + 1);
}
function ut(e, t, n) {
  var r = e.reactions;
  if (r !== null)
    for (var s = he(), i = r.length, u = 0; u < i; u++) {
      var f = r[u], l = f.f;
      if (!(!s && f === h)) {
        var a = (l & x) === 0;
        if (a && y(f, t), (l & E) !== 0) {
          var o = (
            /** @type {Derived} */
            f
          );
          O?.delete(o), (l & Z) === 0 && (l & T && (f.f |= Z), ut(o, I, n));
        } else if (a) {
          var _ = (
            /** @type {Effect} */
            f
          );
          (l & G) !== 0 && M !== null && M.add(_), n !== null ? n.push(_) : Ce(_);
        }
      }
    }
}
function ie(e) {
  if (typeof e != "object" || e === null || oe in e)
    return e;
  const t = $e(e);
  if (t !== Pt && t !== Ot)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Tt(e), s = /* @__PURE__ */ L(0), i = H, u = (f) => {
    if (H === i)
      return f();
    var l = v, a = H;
    B(null), He(i);
    var o = f();
    return B(l), He(a), o;
  };
  return r && n.set("length", /* @__PURE__ */ L(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(f, l, a) {
        (!("value" in a) || a.configurable === !1 || a.enumerable === !1 || a.writable === !1) && Ut();
        var o = n.get(l);
        return o === void 0 ? u(() => {
          var _ = /* @__PURE__ */ L(a.value);
          return n.set(l, _), _;
        }) : V(o, a.value, !0), !0;
      },
      deleteProperty(f, l) {
        var a = n.get(l);
        if (a === void 0) {
          if (l in f) {
            const o = u(() => /* @__PURE__ */ L(m));
            n.set(l, o), Ae(s);
          }
        } else
          V(a, m), Ae(s);
        return !0;
      },
      get(f, l, a) {
        if (l === oe)
          return e;
        var o = n.get(l), _ = l in f;
        if (o === void 0 && (!_ || ue(f, l)?.writable) && (o = u(() => {
          var p = ie(_ ? f[l] : m), d = /* @__PURE__ */ L(p);
          return d;
        }), n.set(l, o)), o !== void 0) {
          var c = ae(o);
          return c === m ? void 0 : c;
        }
        return Reflect.get(f, l, a);
      },
      getOwnPropertyDescriptor(f, l) {
        var a = Reflect.getOwnPropertyDescriptor(f, l);
        if (a && "value" in a) {
          var o = n.get(l);
          o && (a.value = ae(o));
        } else if (a === void 0) {
          var _ = n.get(l), c = _?.v;
          if (_ !== void 0 && c !== m)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return a;
      },
      has(f, l) {
        if (l === oe)
          return !0;
        var a = n.get(l), o = a !== void 0 && a.v !== m || Reflect.has(f, l);
        if (a !== void 0 || h !== null && (!o || ue(f, l)?.writable)) {
          a === void 0 && (a = u(() => {
            var c = o ? ie(f[l]) : m, p = /* @__PURE__ */ L(c);
            return p;
          }), n.set(l, a));
          var _ = ae(a);
          if (_ === m)
            return !1;
        }
        return o;
      },
      set(f, l, a, o) {
        var _ = n.get(l), c = l in f;
        if (r && l === "length")
          for (var p = a; p < /** @type {Source<number>} */
          _.v; p += 1) {
            var d = n.get(p + "");
            d !== void 0 ? V(d, m) : p in f && (d = u(() => /* @__PURE__ */ L(m)), n.set(p + "", d));
          }
        if (_ === void 0)
          (!c || ue(f, l)?.writable) && (_ = u(() => /* @__PURE__ */ L(void 0)), V(_, ie(a)), n.set(l, _));
        else {
          c = _.v !== m;
          var P = u(() => ie(a));
          V(_, P);
        }
        var fe = Reflect.getOwnPropertyDescriptor(f, l);
        if (fe?.set && fe.set.call(o, a), !c) {
          if (r && typeof l == "string") {
            var pe = (
              /** @type {Source<number>} */
              n.get("length")
            ), xe = Number(l);
            Number.isInteger(xe) && xe >= pe.v && V(pe, xe + 1);
          }
          Ae(s);
        }
        return !0;
      },
      ownKeys(f) {
        ae(s);
        var l = Reflect.ownKeys(f).filter((_) => {
          var c = n.get(_);
          return c === void 0 || c.v !== m;
        });
        for (var [a, o] of n)
          o.v !== m && !(a in f) && l.push(a);
        return l;
      },
      setPrototypeOf() {
        Bt();
      }
    }
  );
}
var Ke, un, ot, ct;
function Ln() {
  if (Ke === void 0) {
    Ke = window, un = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    ot = ue(t, "firstChild").get, ct = ue(t, "nextSibling").get, qe(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), qe(n) && (n.__t = void 0);
  }
}
function qn(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function on(e) {
  return (
    /** @type {TemplateNode | null} */
    ot.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function _t(e) {
  return (
    /** @type {TemplateNode | null} */
    ct.call(e)
  );
}
function Yn(e, t) {
  return /* @__PURE__ */ on(e);
}
function Un(e, t, n) {
  return (
    /** @type {T extends keyof HTMLElementTagNameMap ? HTMLElementTagNameMap[T] : Element} */
    document.createElementNS(t ?? Vt, e, void 0)
  );
}
function vt(e) {
  var t = v, n = h;
  B(null), se(null);
  try {
    return e();
  } finally {
    B(t), se(n);
  }
}
function cn(e) {
  h === null && (v === null && qt(), Lt()), J && jt();
}
function _n(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function j(e, t) {
  var n = h;
  n !== null && (n.f & q) !== 0 && (e |= q);
  var r = {
    ctx: R,
    deps: null,
    nodes: null,
    f: e | x | T,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: n,
    b: n && n.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  }, s = r;
  if ((e & ne) !== 0)
    ee !== null ? ee.push(r) : re.ensure().schedule(r);
  else if (t !== null) {
    try {
      le(r);
    } catch (u) {
      throw W(r), u;
    }
    s.deps === null && s.teardown === null && s.nodes === null && s.first === s.last && // either `null`, or a singular child
    (s.f & ve) === 0 && (s = s.first, (e & G) !== 0 && (e & Te) !== 0 && s !== null && (s.f |= Te));
  }
  if (s !== null && (s.parent = n, n !== null && _n(s, n), v !== null && (v.f & E) !== 0 && (e & $) === 0)) {
    var i = (
      /** @type {Derived} */
      v
    );
    (i.effects ??= []).push(s);
  }
  return r;
}
function ht() {
  return v !== null && !N;
}
function vn(e) {
  const t = j(be, null);
  return y(t, g), t.teardown = e, t;
}
function Bn(e) {
  cn();
  var t = (
    /** @type {Effect} */
    h.f
  ), n = !v && (t & F) !== 0 && (t & Q) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      R
    );
    (r.e ??= []).push(e);
  } else
    return dt(e);
}
function dt(e) {
  return j(ne | Ct, e);
}
function Gn(e) {
  re.ensure();
  const t = j($ | ve, e);
  return (n = {}) => new Promise((r) => {
    n.outro ? wn(t, () => {
      W(t), r(void 0);
    }) : (W(t), r(void 0));
  });
}
function Vn(e) {
  return j(ne, e);
}
function hn(e) {
  return j(De | ve, e);
}
function Kn(e, t = 0) {
  return j(be | t, e);
}
function zn(e, t = [], n = [], r = []) {
  en(r, t, n, (s) => {
    j(be, () => e(...s.map(ae)));
  });
}
function Hn(e, t = 0) {
  var n = j(G | t, e);
  return n;
}
function $n(e) {
  return j(F | ve, e);
}
function pt(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = J, r = v;
    ze(!0), B(null);
    try {
      t.call(null);
    } finally {
      ze(n), B(r);
    }
  }
}
function Le(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const s = n.ac;
    s !== null && vt(() => {
      s.abort(C);
    });
    var r = n.next;
    (n.f & $) !== 0 ? n.parent = null : W(n, t), n = r;
  }
}
function dn(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & F) === 0 && W(t), t = n;
  }
}
function W(e, t = !0) {
  var n = !1;
  (t || (e.f & Mt) !== 0) && e.nodes !== null && e.nodes.end !== null && (pn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), y(e, Ye), Le(e, t && !n), _e(e, 0);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const i of r)
      i.stop();
  pt(e), e.f ^= Ye, e.f |= D;
  var s = e.parent;
  s !== null && s.first !== null && wt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function pn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ _t(e);
    e.remove(), e = n;
  }
}
function wt(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function wn(e, t, n = !0) {
  var r = [];
  yt(e, r, !0);
  var s = () => {
    n && W(e), t && t();
  }, i = r.length;
  if (i > 0) {
    var u = () => --i || s();
    for (var f of r)
      f.out(u);
  } else
    s();
}
function yt(e, t, n) {
  if ((e.f & q) === 0) {
    e.f ^= q;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const f of r)
        (f.is_global || n) && t.push(f);
    for (var s = e.first; s !== null; ) {
      var i = s.next, u = (s.f & Te) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (s.f & F) !== 0 && (e.f & G) !== 0;
      yt(s, t, u ? n : !1), s = i;
    }
  }
}
function Zn(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var s = n === r ? null : /* @__PURE__ */ _t(n);
      t.append(n), n = s;
    }
}
let ye = !1, J = !1;
function ze(e) {
  J = e;
}
let v = null, N = !1;
function B(e) {
  v = e;
}
let h = null;
function se(e) {
  h = e;
}
let k = null;
function gt(e) {
  v !== null && (k === null ? k = [e] : k.push(e));
}
let b = null, S = 0, A = null;
function yn(e) {
  A = e;
}
let Et = 1, z = 0, H = z;
function He(e) {
  H = e;
}
function mt() {
  return ++Et;
}
function de(e) {
  var t = e.f;
  if ((t & x) !== 0)
    return !0;
  if (t & E && (e.f &= ~Z), (t & I) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, s = 0; s < r; s++) {
      var i = n[s];
      if (de(
        /** @type {Derived} */
        i
      ) && lt(
        /** @type {Derived} */
        i
      ), i.wv > e.wv)
        return !0;
    }
    (t & T) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    O === null && y(e, g);
  }
  return !1;
}
function bt(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !(k !== null && te.call(k, e)))
    for (var s = 0; s < r.length; s++) {
      var i = r[s];
      (i.f & E) !== 0 ? bt(
        /** @type {Derived} */
        i,
        t,
        !1
      ) : t === i && (n ? y(i, x) : (i.f & g) !== 0 && y(i, I), Ce(
        /** @type {Effect} */
        i
      ));
    }
}
function xt(e) {
  var t = b, n = S, r = A, s = v, i = k, u = R, f = N, l = H, a = e.f;
  b = /** @type {null | Value[]} */
  null, S = 0, A = null, v = (a & (F | $)) === 0 ? e : null, k = null, ge(e.ctx), N = !1, H = ++z, e.ac !== null && (vt(() => {
    e.ac.abort(C);
  }), e.ac = null);
  try {
    e.f |= ke;
    var o = (
      /** @type {Function} */
      e.fn
    ), _ = o();
    e.f |= Q;
    var c = e.deps, p = w?.is_fork;
    if (b !== null) {
      var d;
      if (p || _e(e, S), c !== null && S > 0)
        for (c.length = S + b.length, d = 0; d < b.length; d++)
          c[S + d] = b[d];
      else
        e.deps = c = b;
      if (ht() && (e.f & T) !== 0)
        for (d = S; d < c.length; d++)
          (c[d].reactions ??= []).push(e);
    } else !p && c !== null && S < c.length && (_e(e, S), c.length = S);
    if (he() && A !== null && !N && c !== null && (e.f & (E | I | x)) === 0)
      for (d = 0; d < /** @type {Source[]} */
      A.length; d++)
        bt(
          A[d],
          /** @type {Effect} */
          e
        );
    if (s !== null && s !== e) {
      if (z++, s.deps !== null)
        for (let P = 0; P < n; P += 1)
          s.deps[P].rv = z;
      if (t !== null)
        for (const P of t)
          P.rv = z;
      A !== null && (r === null ? r = A : r.push(.../** @type {Source[]} */
      A));
    }
    return (e.f & Y) !== 0 && (e.f ^= Y), _;
  } catch (P) {
    return $t(P);
  } finally {
    e.f ^= ke, b = t, S = n, A = r, v = s, k = i, ge(u), N = f, H = l;
  }
}
function gn(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = kt.call(n, e);
    if (r !== -1) {
      var s = n.length - 1;
      s === 0 ? n = t.reactions = null : (n[r] = n[s], n.pop());
    }
  }
  if (n === null && (t.f & E) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (b === null || !te.call(b, t))) {
    var i = (
      /** @type {Derived} */
      t
    );
    (i.f & T) !== 0 && (i.f ^= T, i.f &= ~Z), Me(i), fn(i), _e(i, 0);
  }
}
function _e(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      gn(e, n[r]);
}
function le(e) {
  var t = e.f;
  if ((t & D) === 0) {
    y(e, g);
    var n = h, r = ye;
    h = e, ye = !0;
    try {
      (t & (G | We)) !== 0 ? dn(e) : Le(e), pt(e);
      var s = xt(e);
      e.teardown = typeof s == "function" ? s : null, e.wv = Et;
      var i;
    } finally {
      ye = r, h = n;
    }
  }
}
async function Wn() {
  await Promise.resolve(), Qt();
}
function ae(e) {
  var t = e.f, n = (t & E) !== 0;
  if (v !== null && !N) {
    var r = h !== null && (h.f & D) !== 0;
    if (!r && (k === null || !te.call(k, e))) {
      var s = v.deps;
      if ((v.f & ke) !== 0)
        e.rv < z && (e.rv = z, b === null && s !== null && s[S] === e ? S++ : b === null ? b = [e] : b.push(e));
      else {
        (v.deps ??= []).push(e);
        var i = e.reactions;
        i === null ? e.reactions = [v] : te.call(i, v) || i.push(v);
      }
    }
  }
  if (J && U.has(e))
    return U.get(e);
  if (n) {
    var u = (
      /** @type {Derived} */
      e
    );
    if (J) {
      var f = u.v;
      return ((u.f & g) === 0 && u.reactions !== null || At(u)) && (f = je(u)), U.set(u, f), f;
    }
    var l = (u.f & T) === 0 && !N && v !== null && (ye || (v.f & T) !== 0), a = (u.f & Q) === 0;
    de(u) && (l && (u.f |= T), lt(u)), l && !a && (ft(u), St(u));
  }
  if (O?.has(e))
    return O.get(e);
  if ((e.f & Y) !== 0)
    throw e.v;
  return e.v;
}
function St(e) {
  if (e.f |= T, e.deps !== null)
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & E) !== 0 && (t.f & T) === 0 && (ft(
        /** @type {Derived} */
        t
      ), St(
        /** @type {Derived} */
        t
      ));
}
function At(e) {
  if (e.v === m) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (U.has(t) || (t.f & E) !== 0 && At(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Jn(e) {
  var t = N;
  try {
    return N = !0, e();
  } finally {
    N = t;
  }
}
function Qn(e) {
  if (!(typeof e != "object" || !e || e instanceof EventTarget)) {
    if (oe in e)
      Ne(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        const n = e[t];
        typeof n == "object" && n && oe in n && Ne(n);
      }
  }
}
function Ne(e, t = /* @__PURE__ */ new Set()) {
  if (typeof e == "object" && e !== null && // We don't want to traverse DOM elements
  !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let r in e)
      try {
        Ne(e[r], t);
      } catch {
      }
    const n = $e(e);
    if (n !== Object.prototype && n !== Array.prototype && n !== Map.prototype && n !== Set.prototype && n !== Date.prototype) {
      const r = Rt(n);
      for (let s in r) {
        const i = r[s].get;
        if (i)
          try {
            i.call(e);
          } catch {
          }
      }
    }
  }
}
export {
  Ie as $,
  ve as A,
  It as B,
  mn as C,
  Ln as D,
  Te as E,
  Gn as F,
  En as G,
  Cn as H,
  Fn as I,
  Un as J,
  on as K,
  un as L,
  zn as M,
  pn as N,
  Dn as O,
  In as P,
  Vn as Q,
  Ye as R,
  oe as S,
  Nn as T,
  ue as U,
  Sn as V,
  Rn as W,
  ie as X,
  V as Y,
  D as Z,
  Pn as _,
  h as a,
  kn as a0,
  Tn as a1,
  Fe as a2,
  rn as a3,
  On as a4,
  J as a5,
  bn as a6,
  Mn as a7,
  Bn as a8,
  jn as a9,
  Wn as aa,
  Qn as ab,
  Yn as ac,
  Hn as b,
  $n as c,
  qn as d,
  ht as e,
  w as f,
  ae as g,
  Wt as h,
  Ae as i,
  se as j,
  B as k,
  ge as l,
  Zn as m,
  re as n,
  $t as o,
  wn as p,
  Be as q,
  Kn as r,
  at as s,
  v as t,
  Jn as u,
  R as v,
  Oe as w,
  W as x,
  Ee as y,
  An as z
};
