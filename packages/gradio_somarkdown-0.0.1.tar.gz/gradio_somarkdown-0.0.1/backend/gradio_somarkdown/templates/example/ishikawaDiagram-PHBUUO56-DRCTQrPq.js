import { _ as o, c as ot, N as ut, I as dt, as as yt, z as ft, k as pt, p as it, a as gt, b as kt, g as mt, s as wt, q as _t, e as bt } from "./mermaid.core-CbLi0pBF.js";
var J = (function() {
  var e = /* @__PURE__ */ o(function(T, t, s, i) {
    for (s = s || {}, i = T.length; i--; s[T[i]] = t) ;
    return s;
  }, "o"), h = [1, 4], r = [1, 14], a = [1, 12], l = [1, 13], y = [6, 7, 8], f = [1, 20], d = [1, 18], m = [1, 19], u = [6, 7, 11], k = [1, 6, 13, 14], g = [1, 23], _ = [1, 24], x = [1, 6, 7, 11, 13, 14], D = {
    trace: /* @__PURE__ */ o(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, ishikawa: 4, spaceLines: 5, SPACELINE: 6, NL: 7, ISHIKAWA: 8, document: 9, stop: 10, EOF: 11, statement: 12, SPACELIST: 13, TEXT: 14, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 6: "SPACELINE", 7: "NL", 8: "ISHIKAWA", 11: "EOF", 13: "SPACELIST", 14: "TEXT" },
    productions_: [0, [3, 1], [3, 2], [5, 1], [5, 2], [5, 2], [4, 2], [4, 3], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [9, 3], [9, 2], [12, 2], [12, 1], [12, 1], [12, 1]],
    performAction: /* @__PURE__ */ o(function(t, s, i, c, p, n, v) {
      var w = n.length - 1;
      switch (p) {
        case 6:
        case 7:
          return c;
        case 15:
          c.addNode(n[w - 1].length, n[w].trim());
          break;
        case 16:
          c.addNode(0, n[w].trim());
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: 2, 5: 3, 6: [1, 5], 8: h }, { 1: [3] }, { 1: [2, 1] }, { 4: 6, 6: [1, 7], 7: [1, 8], 8: h }, { 6: r, 7: [1, 10], 9: 9, 12: 11, 13: a, 14: l }, e(y, [2, 3]), { 1: [2, 2] }, e(y, [2, 4]), e(y, [2, 5]), { 1: [2, 6], 6: r, 12: 15, 13: a, 14: l }, { 6: r, 9: 16, 12: 11, 13: a, 14: l }, { 6: f, 7: d, 10: 17, 11: m }, e(u, [2, 18], { 14: [1, 21] }), e(u, [2, 16]), e(u, [2, 17]), { 6: f, 7: d, 10: 22, 11: m }, { 1: [2, 7], 6: r, 12: 15, 13: a, 14: l }, e(k, [2, 14], { 7: g, 11: _ }), e(x, [2, 8]), e(x, [2, 9]), e(x, [2, 10]), e(u, [2, 15]), e(k, [2, 13], { 7: g, 11: _ }), e(x, [2, 11]), e(x, [2, 12])],
    defaultActions: { 2: [2, 1], 6: [2, 2] },
    parseError: /* @__PURE__ */ o(function(t, s) {
      if (s.recoverable)
        this.trace(t);
      else {
        var i = new Error(t);
        throw i.hash = s, i;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ o(function(t) {
      var s = this, i = [0], c = [], p = [null], n = [], v = this.table, w = "", I = 0, $ = 0, L = 2, A = 1, C = n.slice.call(arguments, 1), b = Object.create(this.lexer), S = { yy: {} };
      for (var N in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, N) && (S.yy[N] = this.yy[N]);
      b.setInput(t, S.yy), S.yy.lexer = b, S.yy.parser = this, typeof b.yylloc > "u" && (b.yylloc = {});
      var R = b.yylloc;
      n.push(R);
      var G = b.options && b.options.ranges;
      typeof S.yy.parseError == "function" ? this.parseError = S.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function Y(P) {
        i.length = i.length - 2 * P, p.length = p.length - P, n.length = n.length - P;
      }
      o(Y, "popStack");
      function tt() {
        var P;
        return P = c.pop() || b.lex() || A, typeof P != "number" && (P instanceof Array && (c = P, P = c.pop()), P = s.symbols_[P] || P), P;
      }
      o(tt, "lex");
      for (var M, W, B, q, z = {}, U, V, et, Z; ; ) {
        if (W = i[i.length - 1], this.defaultActions[W] ? B = this.defaultActions[W] : ((M === null || typeof M > "u") && (M = tt()), B = v[W] && v[W][M]), typeof B > "u" || !B.length || !B[0]) {
          var K = "";
          Z = [];
          for (U in v[W])
            this.terminals_[U] && U > L && Z.push("'" + this.terminals_[U] + "'");
          b.showPosition ? K = "Parse error on line " + (I + 1) + `:
` + b.showPosition() + `
Expecting ` + Z.join(", ") + ", got '" + (this.terminals_[M] || M) + "'" : K = "Parse error on line " + (I + 1) + ": Unexpected " + (M == A ? "end of input" : "'" + (this.terminals_[M] || M) + "'"), this.parseError(K, {
            text: b.match,
            token: this.terminals_[M] || M,
            line: b.yylineno,
            loc: R,
            expected: Z
          });
        }
        if (B[0] instanceof Array && B.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + W + ", token: " + M);
        switch (B[0]) {
          case 1:
            i.push(M), p.push(b.yytext), n.push(b.yylloc), i.push(B[1]), M = null, $ = b.yyleng, w = b.yytext, I = b.yylineno, R = b.yylloc;
            break;
          case 2:
            if (V = this.productions_[B[1]][1], z.$ = p[p.length - V], z._$ = {
              first_line: n[n.length - (V || 1)].first_line,
              last_line: n[n.length - 1].last_line,
              first_column: n[n.length - (V || 1)].first_column,
              last_column: n[n.length - 1].last_column
            }, G && (z._$.range = [
              n[n.length - (V || 1)].range[0],
              n[n.length - 1].range[1]
            ]), q = this.performAction.apply(z, [
              w,
              $,
              I,
              S.yy,
              B[1],
              p,
              n
            ].concat(C)), typeof q < "u")
              return q;
            V && (i = i.slice(0, -1 * V * 2), p = p.slice(0, -1 * V), n = n.slice(0, -1 * V)), i.push(this.productions_[B[1]][0]), p.push(z.$), n.push(z._$), et = v[i[i.length - 2]][i[i.length - 1]], i.push(et);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, O = /* @__PURE__ */ (function() {
    var T = {
      EOF: 1,
      parseError: /* @__PURE__ */ o(function(s, i) {
        if (this.yy.parser)
          this.yy.parser.parseError(s, i);
        else
          throw new Error(s);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ o(function(t, s) {
        return this.yy = s || this.yy || {}, this._input = t, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ o(function() {
        var t = this._input[0];
        this.yytext += t, this.yyleng++, this.offset++, this.match += t, this.matched += t;
        var s = t.match(/(?:\r\n?|\n).*/g);
        return s ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), t;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ o(function(t) {
        var s = t.length, i = t.split(/(?:\r\n?|\n)/g);
        this._input = t + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - s), this.offset -= s;
        var c = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), i.length - 1 && (this.yylineno -= i.length - 1);
        var p = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: i ? (i.length === c.length ? this.yylloc.first_column : 0) + c[c.length - i.length].length - i[0].length : this.yylloc.first_column - s
        }, this.options.ranges && (this.yylloc.range = [p[0], p[0] + this.yyleng - s]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ o(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ o(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ o(function(t) {
        this.unput(this.match.slice(t));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ o(function() {
        var t = this.matched.substr(0, this.matched.length - this.match.length);
        return (t.length > 20 ? "..." : "") + t.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ o(function() {
        var t = this.match;
        return t.length < 20 && (t += this._input.substr(0, 20 - t.length)), (t.substr(0, 20) + (t.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ o(function() {
        var t = this.pastInput(), s = new Array(t.length + 1).join("-");
        return t + this.upcomingInput() + `
` + s + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ o(function(t, s) {
        var i, c, p;
        if (this.options.backtrack_lexer && (p = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (p.yylloc.range = this.yylloc.range.slice(0))), c = t[0].match(/(?:\r\n?|\n).*/g), c && (this.yylineno += c.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: c ? c[c.length - 1].length - c[c.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + t[0].length
        }, this.yytext += t[0], this.match += t[0], this.matches = t, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(t[0].length), this.matched += t[0], i = this.performAction.call(this, this.yy, this, s, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), i)
          return i;
        if (this._backtrack) {
          for (var n in p)
            this[n] = p[n];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ o(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var t, s, i, c;
        this._more || (this.yytext = "", this.match = "");
        for (var p = this._currentRules(), n = 0; n < p.length; n++)
          if (i = this._input.match(this.rules[p[n]]), i && (!s || i[0].length > s[0].length)) {
            if (s = i, c = n, this.options.backtrack_lexer) {
              if (t = this.test_match(i, p[n]), t !== !1)
                return t;
              if (this._backtrack) {
                s = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return s ? (t = this.test_match(s, p[c]), t !== !1 ? t : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ o(function() {
        var s = this.next();
        return s || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ o(function(s) {
        this.conditionStack.push(s);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ o(function() {
        var s = this.conditionStack.length - 1;
        return s > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ o(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ o(function(s) {
        return s = this.conditionStack.length - 1 - Math.abs(s || 0), s >= 0 ? this.conditionStack[s] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ o(function(s) {
        this.begin(s);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ o(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ o(function(s, i, c, p) {
        switch (c) {
          case 0:
            return 6;
          case 1:
            return 8;
          case 2:
            return 8;
          case 3:
            return 6;
          case 4:
            return 7;
          case 5:
            return 13;
          case 6:
            return 14;
          case 7:
            return 11;
        }
      }, "anonymous"),
      rules: [/^(?:\s*%%.*)/i, /^(?:ishikawa-beta\b)/i, /^(?:ishikawa\b)/i, /^(?:[\s]+[\n])/i, /^(?:[\n]+)/i, /^(?:[\s]+)/i, /^(?:[^\n]+)/i, /^(?:$)/i],
      conditions: { INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7], inclusive: !0 } }
    };
    return T;
  })();
  D.lexer = O;
  function E() {
    this.yy = {};
  }
  return o(E, "Parser"), E.prototype = D, D.Parser = E, new E();
})();
J.parser = J;
var xt = J, H, vt = (H = class {
  constructor() {
    this.stack = [], this.clear = this.clear.bind(this), this.addNode = this.addNode.bind(this), this.getRoot = this.getRoot.bind(this);
  }
  clear() {
    this.root = void 0, this.stack = [], this.baseLevel = void 0, ft();
  }
  getRoot() {
    return this.root;
  }
  addNode(h, r) {
    const a = pt.sanitizeText(r, ot());
    if (!this.root) {
      this.baseLevel = h, this.root = { text: a, children: [] }, this.stack = [{ level: 0, node: this.root }], it(a);
      return;
    }
    let l = h - (this.baseLevel ?? 0);
    for (l <= 0 && (l = 1); this.stack.length > 1 && this.stack[this.stack.length - 1].level >= l; )
      this.stack.pop();
    const y = this.stack[this.stack.length - 1].node, f = { text: a, children: [] };
    y.children.push(f), this.stack.push({ level: l, node: f });
  }
  getAccTitle() {
    return gt();
  }
  setAccTitle(h) {
    kt(h);
  }
  getAccDescription() {
    return mt();
  }
  setAccDescription(h) {
    wt(h);
  }
  getDiagramTitle() {
    return _t();
  }
  setDiagramTitle(h) {
    it(h);
  }
}, o(H, "IshikawaDB"), H), St = 14, F = 250, $t = 30, Et = 60, At = 5, ht = 82 * Math.PI / 180, st = Math.cos(ht), nt = Math.sin(ht), at = /* @__PURE__ */ o((e, h, r) => {
  const a = e.node().getBBox(), l = a.width + h * 2, y = a.height + h * 2;
  bt(e, y, l, r), e.attr("viewBox", `${a.x - h} ${a.y - h} ${l} ${y}`);
}, "applyPaddedViewBox"), It = /* @__PURE__ */ o((e, h, r, a) => {
  const y = a.db.getRoot();
  if (!y)
    return;
  const f = ot(), { look: d, handDrawnSeed: m, themeVariables: u } = f, k = ut(f.fontSize)[0] ?? St, g = d === "handDrawn", _ = y.children ?? [], x = f.ishikawa?.diagramPadding ?? 20, D = f.ishikawa?.useMaxWidth ?? !1, O = dt(h), E = O.append("g").attr("class", "ishikawa"), T = g ? yt.svg(O.node()) : void 0, t = T ? {
    roughSvg: T,
    seed: m ?? 0,
    lineColor: u?.lineColor ?? "#333",
    fillColor: u?.mainBkg ?? "#fff"
  } : void 0, s = `ishikawa-arrow-${h}`;
  g || E.append("defs").append("marker").attr("id", s).attr("viewBox", "0 0 10 10").attr("refX", 0).attr("refY", 5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto").append("path").attr("d", "M 10 0 L 0 5 L 10 10 Z").attr("class", "ishikawa-arrow");
  let i = 0, c = F;
  const p = g ? void 0 : j(E, i, c, i, c, "ishikawa-spine");
  if (Lt(E, i, c, y.text, k, t), !_.length) {
    g && j(E, i, c, i, c, "ishikawa-spine", t), at(O, x, D);
    return;
  }
  i -= 20;
  const n = _.filter((S, N) => N % 2 === 0), v = _.filter((S, N) => N % 2 === 1), w = rt(n), I = rt(v), $ = w.total + I.total;
  let L = F, A = F;
  if ($ > 0) {
    const S = F * 2, N = F * 0.3;
    L = Math.max(N, S * (w.total / $)), A = Math.max(N, S * (I.total / $));
  }
  const C = k * 2;
  L = Math.max(L, w.max * C), A = Math.max(A, I.max * C), c = Math.max(L, F), p && p.attr("y1", c).attr("y2", c), E.select(".ishikawa-head-group").attr("transform", `translate(0,${c})`);
  const b = Math.ceil(_.length / 2);
  for (let S = 0; S < b; S++) {
    const N = E.append("g").attr("class", "ishikawa-pair");
    for (const [R, G, Y] of [
      [_[S * 2], -1, L],
      [_[S * 2 + 1], 1, A]
    ])
      R && Nt(N, R, i, c, G, Y, k, t);
    i = N.selectAll("text").nodes().reduce((R, G) => Math.min(R, G.getBBox().x), 1 / 0);
  }
  if (g)
    j(E, i, c, 0, c, "ishikawa-spine", t);
  else {
    p.attr("x1", i);
    const S = `url(#${s})`;
    E.selectAll("line.ishikawa-branch, line.ishikawa-sub-branch").attr("marker-start", S);
  }
  at(O, x, D);
}, "draw"), rt = /* @__PURE__ */ o((e) => {
  const h = /* @__PURE__ */ o((r) => r.children.reduce((a, l) => a + 1 + h(l), 0), "countDescendants");
  return e.reduce(
    (r, a) => {
      const l = h(a);
      return r.total += l, r.max = Math.max(r.max, l), r;
    },
    { total: 0, max: 0 }
  );
}, "sideStats"), Lt = /* @__PURE__ */ o((e, h, r, a, l, y) => {
  const f = Math.max(6, Math.floor(110 / (l * 0.6))), d = e.append("g").attr("class", "ishikawa-head-group").attr("transform", `translate(${h},${r})`), m = X(
    d,
    ct(a, f),
    0,
    0,
    "ishikawa-head-label",
    "start",
    l
  ), u = m.node().getBBox(), k = Math.max(60, u.width + 6), g = Math.max(40, u.height * 2 + 40), _ = `M 0 ${-g / 2} L 0 ${g / 2} Q ${k * 2.4} 0 0 ${-g / 2} Z`;
  if (y) {
    const x = y.roughSvg.path(_, {
      roughness: 1.5,
      seed: y.seed,
      fill: y.fillColor,
      fillStyle: "hachure",
      fillWeight: 2.5,
      hachureGap: 5,
      stroke: y.lineColor,
      strokeWidth: 2
    });
    d.insert(() => x, ":first-child").attr("class", "ishikawa-head");
  } else
    d.insert("path", ":first-child").attr("class", "ishikawa-head").attr("d", _);
  m.attr("transform", `translate(${(k - u.width) / 2 - u.x + 3},${-u.y - u.height / 2})`);
}, "drawHead"), Tt = /* @__PURE__ */ o((e, h) => {
  const r = [], a = [], l = /* @__PURE__ */ o((y, f, d) => {
    const m = h === -1 ? [...y].reverse() : y;
    for (const u of m) {
      const k = r.length, g = u.children ?? [];
      r.push({
        depth: d,
        text: ct(u.text, 15),
        parentIndex: f,
        childCount: g.length
      }), d % 2 === 0 ? (a.push(k), g.length && l(g, k, d + 1)) : (g.length && l(g, k, d + 1), a.push(k));
    }
  }, "walk");
  return l(e, -1, 2), { entries: r, yOrder: a };
}, "flattenTree"), Mt = /* @__PURE__ */ o((e, h, r, a, l, y, f) => {
  const d = e.append("g").attr("class", "ishikawa-label-group"), u = X(
    d,
    h,
    r,
    a + 11 * l,
    "ishikawa-label cause",
    "middle",
    y
  ).node().getBBox();
  if (f) {
    const k = f.roughSvg.rectangle(
      u.x - 20,
      u.y - 2,
      u.width + 40,
      u.height + 4,
      {
        roughness: 1.5,
        seed: f.seed,
        fill: f.fillColor,
        fillStyle: "hachure",
        fillWeight: 2.5,
        hachureGap: 5,
        stroke: f.lineColor,
        strokeWidth: 2
      }
    );
    d.insert(() => k, ":first-child").attr("class", "ishikawa-label-box");
  } else
    d.insert("rect", ":first-child").attr("class", "ishikawa-label-box").attr("x", u.x - 20).attr("y", u.y - 2).attr("width", u.width + 40).attr("height", u.height + 4);
}, "drawCauseLabel"), Q = /* @__PURE__ */ o((e, h, r, a, l, y) => {
  const f = Math.sqrt(a * a + l * l);
  if (f === 0)
    return;
  const d = a / f, m = l / f, u = 6, k = -m * u, g = d * u, _ = h, x = r, D = `M ${_} ${x} L ${_ - d * u * 2 + k} ${x - m * u * 2 + g} L ${_ - d * u * 2 - k} ${x - m * u * 2 - g} Z`, O = y.roughSvg.path(D, {
    roughness: 1,
    seed: y.seed,
    fill: y.lineColor,
    fillStyle: "solid",
    stroke: y.lineColor,
    strokeWidth: 1
  });
  e.append(() => O);
}, "drawArrowMarker"), Nt = /* @__PURE__ */ o((e, h, r, a, l, y, f, d) => {
  const m = h.children ?? [], u = y * (m.length ? 1 : 0.2), k = -st * u, g = nt * u * l, _ = r + k, x = a + g;
  if (j(e, r, a, _, x, "ishikawa-branch", d), d && Q(e, r, a, r - _, a - x, d), Mt(e, h.text, _, x, l, f, d), !m.length)
    return;
  const { entries: D, yOrder: O } = Tt(m, l), E = D.length, T = new Array(E);
  for (const [p, n] of O.entries())
    T[n] = a + g * ((p + 1) / (E + 1));
  const t = /* @__PURE__ */ new Map();
  t.set(-1, {
    x0: r,
    y0: a,
    x1: _,
    y1: x,
    childCount: m.length,
    childrenDrawn: 0
  });
  const s = -st, i = nt * l, c = l < 0 ? "ishikawa-label up" : "ishikawa-label down";
  for (const [p, n] of D.entries()) {
    const v = T[p], w = t.get(n.parentIndex), I = e.append("g").attr("class", "ishikawa-sub-group");
    let $ = 0, L = 0, A = 0;
    if (n.depth % 2 === 0) {
      const C = w.y1 - w.y0;
      $ = lt(w.x0, w.x1, C ? (v - w.y0) / C : 0.5), L = v, A = $ - (n.childCount > 0 ? Et + n.childCount * At : $t), j(I, $, v, A, v, "ishikawa-sub-branch", d), d && Q(I, $, v, 1, 0, d), X(I, n.text, A, v, "ishikawa-label align", "end", f);
    } else {
      const C = w.childrenDrawn++;
      $ = lt(w.x0, w.x1, (w.childCount - C) / (w.childCount + 1)), L = w.y0, A = $ + s * ((v - L) / i), j(I, $, L, A, v, "ishikawa-sub-branch", d), d && Q(I, $, L, $ - A, L - v, d), X(I, n.text, A, v, c, "end", f);
    }
    n.childCount > 0 && t.set(p, {
      x0: $,
      y0: L,
      x1: A,
      y1: v,
      childCount: n.childCount,
      childrenDrawn: 0
    });
  }
}, "drawBranch"), Pt = /* @__PURE__ */ o((e) => e.split(/<br\s*\/?>|\n/), "splitLines"), ct = /* @__PURE__ */ o((e, h) => {
  if (e.length <= h)
    return e;
  const r = [];
  for (const a of e.split(/\s+/)) {
    const l = r.length - 1;
    l >= 0 && r[l].length + 1 + a.length <= h ? r[l] += " " + a : r.push(a);
  }
  return r.join(`
`);
}, "wrapText"), X = /* @__PURE__ */ o((e, h, r, a, l, y, f) => {
  const d = Pt(h), m = f * 1.05, u = e.append("text").attr("class", l).attr("text-anchor", y).attr("x", r).attr("y", a - (d.length - 1) * m / 2);
  for (const [k, g] of d.entries())
    u.append("tspan").attr("x", r).attr("dy", k === 0 ? 0 : m).text(g);
  return u;
}, "drawMultilineText"), lt = /* @__PURE__ */ o((e, h, r) => e + (h - e) * r, "lerp"), j = /* @__PURE__ */ o((e, h, r, a, l, y, f) => {
  if (f) {
    const d = f.roughSvg.line(h, r, a, l, {
      roughness: 1.5,
      seed: f.seed,
      stroke: f.lineColor,
      strokeWidth: 2
    });
    e.append(() => d).attr("class", y);
    return;
  }
  return e.append("line").attr("class", y).attr("x1", h).attr("y1", r).attr("x2", a).attr("y2", l);
}, "drawLine"), Bt = { draw: It }, Dt = /* @__PURE__ */ o((e) => `
.ishikawa .ishikawa-spine,
.ishikawa .ishikawa-branch,
.ishikawa .ishikawa-sub-branch {
  stroke: ${e.lineColor};
  stroke-width: 2;
  fill: none;
}

.ishikawa .ishikawa-sub-branch {
  stroke-width: 1;
}

.ishikawa .ishikawa-arrow {
  fill: ${e.lineColor};
}

.ishikawa .ishikawa-head {
  fill: ${e.mainBkg};
  stroke: ${e.lineColor};
  stroke-width: 2;
}

.ishikawa .ishikawa-label-box {
  fill: ${e.mainBkg};
  stroke: ${e.lineColor};
  stroke-width: 2;
}

.ishikawa text {
  font-family: ${e.fontFamily};
  font-size: ${e.fontSize};
  fill: ${e.textColor};
}

.ishikawa .ishikawa-head-label {
  font-weight: 600;
  text-anchor: middle;
  dominant-baseline: middle;
  font-size: 14px;
}

.ishikawa .ishikawa-label {
  text-anchor: end;
}

.ishikawa .ishikawa-label.cause {
  text-anchor: middle;
  dominant-baseline: middle;
}

.ishikawa .ishikawa-label.align {
  text-anchor: end;
  dominant-baseline: middle;
}

.ishikawa .ishikawa-label.up {
  dominant-baseline: baseline;
}

.ishikawa .ishikawa-label.down {
  dominant-baseline: hanging;
}
`, "getStyles"), Ot = Dt, Vt = {
  parser: xt,
  get db() {
    return new vt();
  },
  renderer: Bt,
  styles: Ot
};
export {
  Vt as diagram
};
