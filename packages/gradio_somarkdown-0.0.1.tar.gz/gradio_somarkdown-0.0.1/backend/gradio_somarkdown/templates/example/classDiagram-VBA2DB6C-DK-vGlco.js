import { s as r, c as s, a as e, C as t } from "./chunk-WL4C6EOR-BbvZqDOS.js";
import { _ as l } from "./mermaid.core-CbLi0pBF.js";
var d = {
  parser: e,
  get db() {
    return new t();
  },
  renderer: s,
  styles: r,
  init: /* @__PURE__ */ l((a) => {
    a.class || (a.class = {}), a.class.arrowMarkerAbsolute = a.arrowMarkerAbsolute;
  }, "init")
};
export {
  d as diagram
};
