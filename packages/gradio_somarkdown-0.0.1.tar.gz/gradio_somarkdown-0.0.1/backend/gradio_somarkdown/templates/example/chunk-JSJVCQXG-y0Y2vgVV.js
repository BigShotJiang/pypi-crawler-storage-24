import { _ as i, d as l, U as d, j as o } from "./mermaid.core-CbLi0pBF.js";
var x = /* @__PURE__ */ i((r, t) => {
  const e = r.append("rect");
  if (e.attr("x", t.x), e.attr("y", t.y), e.attr("fill", t.fill), e.attr("stroke", t.stroke), e.attr("width", t.width), e.attr("height", t.height), t.name && e.attr("name", t.name), t.rx && e.attr("rx", t.rx), t.ry && e.attr("ry", t.ry), t.attrs !== void 0)
    for (const s in t.attrs)
      e.attr(s, t.attrs[s]);
  return t.class && e.attr("class", t.class), e;
}, "drawRect"), p = /* @__PURE__ */ i((r, t) => {
  const e = {
    x: t.startx,
    y: t.starty,
    width: t.stopx - t.startx,
    height: t.stopy - t.starty,
    fill: t.fill,
    stroke: t.stroke,
    class: "rect"
  };
  x(r, e).lower();
}, "drawBackgroundRect"), y = /* @__PURE__ */ i((r, t) => {
  const e = t.text.replace(d, " "), s = r.append("text");
  s.attr("x", t.x), s.attr("y", t.y), s.attr("class", "legend"), s.style("text-anchor", t.anchor), t.class && s.attr("class", t.class);
  const a = s.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.text(e), s;
}, "drawText"), m = /* @__PURE__ */ i((r, t, e, s) => {
  const a = r.append("image");
  a.attr("x", t), a.attr("y", e);
  const n = o.sanitizeUrl(s);
  a.attr("xlink:href", n);
}, "drawImage"), g = /* @__PURE__ */ i((r, t, e, s) => {
  const a = r.append("use");
  a.attr("x", t), a.attr("y", e);
  const n = o.sanitizeUrl(s);
  a.attr("xlink:href", `#${n}`);
}, "drawEmbeddedImage"), h = /* @__PURE__ */ i(() => ({
  x: 0,
  y: 0,
  width: 100,
  height: 100,
  fill: "#EDF2AE",
  stroke: "#666",
  anchor: "start",
  rx: 0,
  ry: 0
}), "getNoteRect"), f = /* @__PURE__ */ i(() => ({
  x: 0,
  y: 0,
  width: 100,
  height: 100,
  "text-anchor": "start",
  style: "#666",
  textMargin: 0,
  rx: 0,
  ry: 0,
  tspan: !0
}), "getTextObj"), w = /* @__PURE__ */ i(() => {
  let r = l(".mermaidTooltip");
  return r.empty() && (r = l("body").append("div").attr("class", "mermaidTooltip").style("opacity", 0).style("position", "absolute").style("text-align", "center").style("max-width", "200px").style("padding", "2px").style("font-size", "12px").style("background", "#ffffde").style("border", "1px solid #333").style("border-radius", "2px").style("pointer-events", "none").style("z-index", "100")), r;
}, "createTooltip");
export {
  p as a,
  f as b,
  w as c,
  x as d,
  g as e,
  m as f,
  h as g,
  y as h
};
