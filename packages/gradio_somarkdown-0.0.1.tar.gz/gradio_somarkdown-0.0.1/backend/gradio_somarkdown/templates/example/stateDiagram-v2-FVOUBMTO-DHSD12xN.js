import { s as a, b as t, a as r, S as s } from "./chunk-NQ4KR5QH-CP7c1bG4.js";
import { _ as i } from "./mermaid.core-CbLi0pBF.js";
var _ = {
  parser: r,
  get db() {
    return new s(2);
  },
  renderer: t,
  styles: a,
  init: /* @__PURE__ */ i((e) => {
    e.state || (e.state = {}), e.state.arrowMarkerAbsolute = e.arrowMarkerAbsolute;
  }, "init")
};
export {
  _ as diagram
};
