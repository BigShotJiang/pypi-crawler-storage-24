import { g as He } from "./chunk-FMBD7UC4-BE_kxjEu.js";
import { _ as m, n as Me, l as $, c as b1, d as P1, o as Xe, r as Qe, u as re, b as Je, s as Ze, p as $e, a as et, g as tt, q as st, k as it, t as rt, J as at, v as nt, x as ie, y as ut, z as ot, A as lt, B as ct } from "./mermaid.core-CbLi0pBF.js";
import { c as ht } from "./chunk-JSJVCQXG-y0Y2vgVV.js";
import { g as dt } from "./chunk-55IACEB6-362b7Ann.js";
import { s as pt } from "./chunk-KX2RTZJC-DDLAkZGm.js";
import { c as ft } from "./channel-pxn14BVk.js";
var gt = "flowchart-", N1, bt = (N1 = class {
  // cspell:ignore funs
  constructor() {
    this.vertexCounter = 0, this.config = b1(), this.vertices = /* @__PURE__ */ new Map(), this.edges = [], this.classes = /* @__PURE__ */ new Map(), this.subGraphs = [], this.subGraphLookup = /* @__PURE__ */ new Map(), this.tooltips = /* @__PURE__ */ new Map(), this.subCount = 0, this.firstGraphFlag = !0, this.secCount = -1, this.posCrossRef = [], this.funs = [], this.setAccTitle = Je, this.setAccDescription = Ze, this.setDiagramTitle = $e, this.getAccTitle = et, this.getAccDescription = tt, this.getDiagramTitle = st, this.funs.push(this.setupToolTips.bind(this)), this.addVertex = this.addVertex.bind(this), this.firstGraph = this.firstGraph.bind(this), this.setDirection = this.setDirection.bind(this), this.addSubGraph = this.addSubGraph.bind(this), this.addLink = this.addLink.bind(this), this.setLink = this.setLink.bind(this), this.updateLink = this.updateLink.bind(this), this.addClass = this.addClass.bind(this), this.setClass = this.setClass.bind(this), this.destructLink = this.destructLink.bind(this), this.setClickEvent = this.setClickEvent.bind(this), this.setTooltip = this.setTooltip.bind(this), this.updateLinkInterpolate = this.updateLinkInterpolate.bind(this), this.setClickFun = this.setClickFun.bind(this), this.bindFunctions = this.bindFunctions.bind(this), this.lex = {
      firstGraph: this.firstGraph.bind(this)
    }, this.clear(), this.setGen("gen-2");
  }
  sanitizeText(i) {
    return it.sanitizeText(i, this.config);
  }
  sanitizeNodeLabelType(i) {
    switch (i) {
      case "markdown":
      case "string":
      case "text":
        return i;
      default:
        return "markdown";
    }
  }
  /**
   * Function to lookup domId from id in the graph definition.
   *
   * @param id - id of the node
   */
  lookUpDomId(i) {
    for (const a of this.vertices.values())
      if (a.id === i)
        return a.domId;
    return i;
  }
  /**
   * Function called by parser when a node definition has been found
   */
  addVertex(i, a, r, n, l, g, c = {}, b) {
    if (!i || i.trim().length === 0)
      return;
    let u;
    if (b !== void 0) {
      let k;
      b.includes(`
`) ? k = b + `
` : k = `{
` + b + `
}`, u = rt(k, { schema: at });
    }
    const A = this.edges.find((k) => k.id === i);
    if (A) {
      const k = u;
      k?.animate !== void 0 && (A.animate = k.animate), k?.animation !== void 0 && (A.animation = k.animation), k?.curve !== void 0 && (A.interpolate = k.curve);
      return;
    }
    let F, f = this.vertices.get(i);
    if (f === void 0 && (f = {
      id: i,
      labelType: "text",
      domId: gt + i + "-" + this.vertexCounter,
      styles: [],
      classes: []
    }, this.vertices.set(i, f)), this.vertexCounter++, a !== void 0 ? (this.config = b1(), F = this.sanitizeText(a.text.trim()), f.labelType = a.type, F.startsWith('"') && F.endsWith('"') && (F = F.substring(1, F.length - 1)), f.text = F) : f.text === void 0 && (f.text = i), r !== void 0 && (f.type = r), n?.forEach((k) => {
      f.styles.push(k);
    }), l?.forEach((k) => {
      f.classes.push(k);
    }), g !== void 0 && (f.dir = g), f.props === void 0 ? f.props = c : c !== void 0 && Object.assign(f.props, c), u !== void 0) {
      if (u.shape) {
        if (u.shape !== u.shape.toLowerCase() || u.shape.includes("_"))
          throw new Error(`No such shape: ${u.shape}. Shape names should be lowercase.`);
        if (!nt(u.shape))
          throw new Error(`No such shape: ${u.shape}.`);
        f.type = u?.shape;
      }
      u?.label && (f.text = u?.label, f.labelType = this.sanitizeNodeLabelType(u?.labelType)), u?.icon && (f.icon = u?.icon, !u.label?.trim() && f.text === i && (f.text = "")), u?.form && (f.form = u?.form), u?.pos && (f.pos = u?.pos), u?.img && (f.img = u?.img, !u.label?.trim() && f.text === i && (f.text = "")), u?.constraint && (f.constraint = u.constraint), u.w && (f.assetWidth = Number(u.w)), u.h && (f.assetHeight = Number(u.h));
    }
  }
  /**
   * Function called by parser when a link/edge definition has been found
   *
   */
  addSingleLink(i, a, r, n) {
    const c = {
      start: i,
      end: a,
      type: void 0,
      text: "",
      labelType: "text",
      classes: [],
      isUserDefinedId: !1,
      interpolate: this.edges.defaultInterpolate
    };
    $.info("abc78 Got edge...", c);
    const b = r.text;
    if (b !== void 0 && (c.text = this.sanitizeText(b.text.trim()), c.text.startsWith('"') && c.text.endsWith('"') && (c.text = c.text.substring(1, c.text.length - 1)), c.labelType = this.sanitizeNodeLabelType(b.type)), r !== void 0 && (c.type = r.type, c.stroke = r.stroke, c.length = r.length > 10 ? 10 : r.length), n && !this.edges.some((u) => u.id === n))
      c.id = n, c.isUserDefinedId = !0;
    else {
      const u = this.edges.filter((A) => A.start === c.start && A.end === c.end);
      u.length === 0 ? c.id = ie(c.start, c.end, { counter: 0, prefix: "L" }) : c.id = ie(c.start, c.end, {
        counter: u.length + 1,
        prefix: "L"
      });
    }
    if (this.edges.length < (this.config.maxEdges ?? 500))
      $.info("Pushing edge..."), this.edges.push(c);
    else
      throw new Error(
        `Edge limit exceeded. ${this.edges.length} edges found, but the limit is ${this.config.maxEdges}.

Initialize mermaid with maxEdges set to a higher number to allow more edges.
You cannot set this config via configuration inside the diagram as it is a secure config.
You have to call mermaid.initialize.`
      );
  }
  isLinkData(i) {
    return i !== null && typeof i == "object" && "id" in i && typeof i.id == "string";
  }
  addLink(i, a, r) {
    const n = this.isLinkData(r) ? r.id.replace("@", "") : void 0;
    $.info("addLink", i, a, n);
    for (const l of i)
      for (const g of a) {
        const c = l === i[i.length - 1], b = g === a[0];
        c && b ? this.addSingleLink(l, g, r, n) : this.addSingleLink(l, g, r, void 0);
      }
  }
  /**
   * Updates a link's line interpolation algorithm
   */
  updateLinkInterpolate(i, a) {
    i.forEach((r) => {
      r === "default" ? this.edges.defaultInterpolate = a : this.edges[r].interpolate = a;
    });
  }
  /**
   * Updates a link with a style
   *
   */
  updateLink(i, a) {
    i.forEach((r) => {
      if (typeof r == "number" && r >= this.edges.length)
        throw new Error(
          `The index ${r} for linkStyle is out of bounds. Valid indices for linkStyle are between 0 and ${this.edges.length - 1}. (Help: Ensure that the index is within the range of existing edges.)`
        );
      r === "default" ? this.edges.defaultStyle = a : (this.edges[r].style = a, (this.edges[r]?.style?.length ?? 0) > 0 && !this.edges[r]?.style?.some((n) => n?.startsWith("fill")) && this.edges[r]?.style?.push("fill:none"));
    });
  }
  addClass(i, a) {
    const r = a.join().replace(/\\,/g, "§§§").replace(/,/g, ";").replace(/§§§/g, ",").split(";");
    i.split(",").forEach((n) => {
      let l = this.classes.get(n);
      l === void 0 && (l = { id: n, styles: [], textStyles: [] }, this.classes.set(n, l)), r?.forEach((g) => {
        if (/color/.exec(g)) {
          const c = g.replace("fill", "bgFill");
          l.textStyles.push(c);
        }
        l.styles.push(g);
      });
    });
  }
  /**
   * Called by parser when a graph definition is found, stores the direction of the chart.
   *
   */
  setDirection(i) {
    this.direction = i.trim(), /.*</.exec(this.direction) && (this.direction = "RL"), /.*\^/.exec(this.direction) && (this.direction = "BT"), /.*>/.exec(this.direction) && (this.direction = "LR"), /.*v/.exec(this.direction) && (this.direction = "TB"), this.direction === "TD" && (this.direction = "TB");
  }
  /**
   * Called by parser when a special node is found, e.g. a clickable element.
   *
   * @param ids - Comma separated list of ids
   * @param className - Class to add
   */
  setClass(i, a) {
    for (const r of i.split(",")) {
      const n = this.vertices.get(r);
      n && n.classes.push(a);
      const l = this.edges.find((c) => c.id === r);
      l && l.classes.push(a);
      const g = this.subGraphLookup.get(r);
      g && g.classes.push(a);
    }
  }
  setTooltip(i, a) {
    if (a !== void 0) {
      a = this.sanitizeText(a);
      for (const r of i.split(","))
        this.tooltips.set(this.version === "gen-1" ? this.lookUpDomId(r) : r, a);
    }
  }
  setClickFun(i, a, r) {
    const n = this.lookUpDomId(i);
    if (b1().securityLevel !== "loose" || a === void 0)
      return;
    let l = [];
    if (typeof r == "string") {
      l = r.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
      for (let c = 0; c < l.length; c++) {
        let b = l[c].trim();
        b.startsWith('"') && b.endsWith('"') && (b = b.substr(1, b.length - 2)), l[c] = b;
      }
    }
    l.length === 0 && l.push(i);
    const g = this.vertices.get(i);
    g && (g.haveCallback = !0, this.funs.push(() => {
      const c = document.querySelector(`[id="${n}"]`);
      c !== null && c.addEventListener(
        "click",
        () => {
          re.runFunc(a, ...l);
        },
        !1
      );
    }));
  }
  /**
   * Called by parser when a link is found. Adds the URL to the vertex data.
   *
   * @param ids - Comma separated list of ids
   * @param linkStr - URL to create a link for
   * @param target - Target attribute for the link
   */
  setLink(i, a, r) {
    i.split(",").forEach((n) => {
      const l = this.vertices.get(n);
      l !== void 0 && (l.link = re.formatUrl(a, this.config), l.linkTarget = r);
    }), this.setClass(i, "clickable");
  }
  getTooltip(i) {
    return this.tooltips.get(i);
  }
  /**
   * Called by parser when a click definition is found. Registers an event handler.
   *
   * @param ids - Comma separated list of ids
   * @param functionName - Function to be called on click
   * @param functionArgs - Arguments to be passed to the function
   */
  setClickEvent(i, a, r) {
    i.split(",").forEach((n) => {
      this.setClickFun(n, a, r);
    }), this.setClass(i, "clickable");
  }
  bindFunctions(i) {
    this.funs.forEach((a) => {
      a(i);
    });
  }
  getDirection() {
    return this.direction?.trim();
  }
  /**
   * Retrieval function for fetching the found nodes after parsing has completed.
   *
   */
  getVertices() {
    return this.vertices;
  }
  /**
   * Retrieval function for fetching the found links after parsing has completed.
   *
   */
  getEdges() {
    return this.edges;
  }
  /**
   * Retrieval function for fetching the found class definitions after parsing has completed.
   *
   */
  getClasses() {
    return this.classes;
  }
  setupToolTips(i) {
    const a = ht();
    P1(i).select("svg").selectAll("g.node").on("mouseover", (l) => {
      const g = P1(l.currentTarget), c = g.attr("title");
      if (c === null)
        return;
      const b = l.currentTarget?.getBoundingClientRect();
      a.transition().duration(200).style("opacity", ".9"), a.text(g.attr("title")).style("left", window.scrollX + b.left + (b.right - b.left) / 2 + "px").style("top", window.scrollY + b.bottom + "px"), a.html(ut.sanitize(c)), g.classed("hover", !0);
    }).on("mouseout", (l) => {
      a.transition().duration(500).style("opacity", 0), P1(l.currentTarget).classed("hover", !1);
    });
  }
  /**
   * Clears the internal graph db so that a new graph can be parsed.
   *
   */
  clear(i = "gen-2") {
    this.vertices = /* @__PURE__ */ new Map(), this.classes = /* @__PURE__ */ new Map(), this.edges = [], this.funs = [this.setupToolTips.bind(this)], this.subGraphs = [], this.subGraphLookup = /* @__PURE__ */ new Map(), this.subCount = 0, this.tooltips = /* @__PURE__ */ new Map(), this.firstGraphFlag = !0, this.version = i, this.config = b1(), ot();
  }
  setGen(i) {
    this.version = i || "gen-2";
  }
  defaultStyle() {
    return "fill:#ffa;stroke: #f66; stroke-width: 3px; stroke-dasharray: 5, 5;fill:#ffa;stroke: #666;";
  }
  addSubGraph(i, a, r) {
    let n = i.text.trim(), l = r.text;
    i === r && /\s/.exec(r.text) && (n = void 0);
    const c = (/* @__PURE__ */ m((f) => {
      const k = { boolean: {}, number: {}, string: {} }, S = [];
      let x;
      return { nodeList: f.filter(function(z) {
        const J = typeof z;
        return z.stmt && z.stmt === "dir" ? (x = z.value, !1) : z.trim() === "" ? !1 : J in k ? k[J].hasOwnProperty(z) ? !1 : k[J][z] = !0 : S.includes(z) ? !1 : S.push(z);
      }), dir: x };
    }, "uniq"))(a.flat()), b = c.nodeList;
    let u = c.dir;
    const A = b1().flowchart ?? {};
    if (u = u ?? (A.inheritDir ? this.getDirection() ?? b1().direction ?? void 0 : void 0), this.version === "gen-1")
      for (let f = 0; f < b.length; f++)
        b[f] = this.lookUpDomId(b[f]);
    n = n ?? "subGraph" + this.subCount, l = l || "", l = this.sanitizeText(l), this.subCount = this.subCount + 1;
    const F = {
      id: n,
      nodes: b,
      title: l.trim(),
      classes: [],
      dir: u,
      labelType: this.sanitizeNodeLabelType(r?.type)
    };
    return $.info("Adding", F.id, F.nodes, F.dir), F.nodes = this.makeUniq(F, this.subGraphs).nodes, this.subGraphs.push(F), this.subGraphLookup.set(n, F), n;
  }
  getPosForId(i) {
    for (const [a, r] of this.subGraphs.entries())
      if (r.id === i)
        return a;
    return -1;
  }
  indexNodes2(i, a) {
    const r = this.subGraphs[a].nodes;
    if (this.secCount = this.secCount + 1, this.secCount > 2e3)
      return {
        result: !1,
        count: 0
      };
    if (this.posCrossRef[this.secCount] = a, this.subGraphs[a].id === i)
      return {
        result: !0,
        count: 0
      };
    let n = 0, l = 1;
    for (; n < r.length; ) {
      const g = this.getPosForId(r[n]);
      if (g >= 0) {
        const c = this.indexNodes2(i, g);
        if (c.result)
          return {
            result: !0,
            count: l + c.count
          };
        l = l + c.count;
      }
      n = n + 1;
    }
    return {
      result: !1,
      count: l
    };
  }
  getDepthFirstPos(i) {
    return this.posCrossRef[i];
  }
  indexNodes() {
    this.secCount = -1, this.subGraphs.length > 0 && this.indexNodes2("none", this.subGraphs.length - 1);
  }
  getSubGraphs() {
    return this.subGraphs;
  }
  firstGraph() {
    return this.firstGraphFlag ? (this.firstGraphFlag = !1, !0) : !1;
  }
  destructStartLink(i) {
    let a = i.trim(), r = "arrow_open";
    switch (a[0]) {
      case "<":
        r = "arrow_point", a = a.slice(1);
        break;
      case "x":
        r = "arrow_cross", a = a.slice(1);
        break;
      case "o":
        r = "arrow_circle", a = a.slice(1);
        break;
    }
    let n = "normal";
    return a.includes("=") && (n = "thick"), a.includes(".") && (n = "dotted"), { type: r, stroke: n };
  }
  countChar(i, a) {
    const r = a.length;
    let n = 0;
    for (let l = 0; l < r; ++l)
      a[l] === i && ++n;
    return n;
  }
  destructEndLink(i) {
    const a = i.trim();
    let r = a.slice(0, -1), n = "arrow_open";
    switch (a.slice(-1)) {
      case "x":
        n = "arrow_cross", a.startsWith("x") && (n = "double_" + n, r = r.slice(1));
        break;
      case ">":
        n = "arrow_point", a.startsWith("<") && (n = "double_" + n, r = r.slice(1));
        break;
      case "o":
        n = "arrow_circle", a.startsWith("o") && (n = "double_" + n, r = r.slice(1));
        break;
    }
    let l = "normal", g = r.length - 1;
    r.startsWith("=") && (l = "thick"), r.startsWith("~") && (l = "invisible");
    const c = this.countChar(".", r);
    return c && (l = "dotted", g = c), { type: n, stroke: l, length: g };
  }
  destructLink(i, a) {
    const r = this.destructEndLink(i);
    let n;
    if (a) {
      if (n = this.destructStartLink(a), n.stroke !== r.stroke)
        return { type: "INVALID", stroke: "INVALID" };
      if (n.type === "arrow_open")
        n.type = r.type;
      else {
        if (n.type !== r.type)
          return { type: "INVALID", stroke: "INVALID" };
        n.type = "double_" + n.type;
      }
      return n.type === "double_arrow" && (n.type = "double_arrow_point"), n.length = r.length, n;
    }
    return r;
  }
  // Todo optimizer this by caching existing nodes
  exists(i, a) {
    for (const r of i)
      if (r.nodes.includes(a))
        return !0;
    return !1;
  }
  /**
   * Deletes an id from all subgraphs
   *
   */
  makeUniq(i, a) {
    const r = [];
    return i.nodes.forEach((n, l) => {
      this.exists(a, n) || r.push(i.nodes[l]);
    }), { nodes: r };
  }
  getTypeFromVertex(i) {
    if (i.img)
      return "imageSquare";
    if (i.icon)
      return i.form === "circle" ? "iconCircle" : i.form === "square" ? "iconSquare" : i.form === "rounded" ? "iconRounded" : "icon";
    switch (i.type) {
      case "square":
      case void 0:
        return "squareRect";
      case "round":
        return "roundedRect";
      case "ellipse":
        return "ellipse";
      default:
        return i.type;
    }
  }
  findNode(i, a) {
    return i.find((r) => r.id === a);
  }
  destructEdgeType(i) {
    let a = "none", r = "arrow_point";
    switch (i) {
      case "arrow_point":
      case "arrow_circle":
      case "arrow_cross":
        r = i;
        break;
      case "double_arrow_point":
      case "double_arrow_circle":
      case "double_arrow_cross":
        a = i.replace("double_", ""), r = a;
        break;
    }
    return { arrowTypeStart: a, arrowTypeEnd: r };
  }
  addNodeFromVertex(i, a, r, n, l, g) {
    const c = r.get(i.id), b = n.get(i.id) ?? !1, u = this.findNode(a, i.id);
    if (u)
      u.cssStyles = i.styles, u.cssCompiledStyles = this.getCompiledStyles(i.classes), u.cssClasses = i.classes.join(" ");
    else {
      const A = {
        id: i.id,
        label: i.text,
        labelType: i.labelType,
        labelStyle: "",
        parentId: c,
        padding: l.flowchart?.padding || 8,
        cssStyles: i.styles,
        cssCompiledStyles: this.getCompiledStyles(["default", "node", ...i.classes]),
        cssClasses: "default " + i.classes.join(" "),
        dir: i.dir,
        domId: i.domId,
        look: g,
        link: i.link,
        linkTarget: i.linkTarget,
        tooltip: this.getTooltip(i.id),
        icon: i.icon,
        pos: i.pos,
        img: i.img,
        assetWidth: i.assetWidth,
        assetHeight: i.assetHeight,
        constraint: i.constraint
      };
      b ? a.push({
        ...A,
        isGroup: !0,
        shape: "rect"
      }) : a.push({
        ...A,
        isGroup: !1,
        shape: this.getTypeFromVertex(i)
      });
    }
  }
  getCompiledStyles(i) {
    let a = [];
    for (const r of i) {
      const n = this.classes.get(r);
      n?.styles && (a = [...a, ...n.styles ?? []].map((l) => l.trim())), n?.textStyles && (a = [...a, ...n.textStyles ?? []].map((l) => l.trim()));
    }
    return a;
  }
  getData() {
    const i = b1(), a = [], r = [], n = this.getSubGraphs(), l = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new Map();
    for (let u = n.length - 1; u >= 0; u--) {
      const A = n[u];
      A.nodes.length > 0 && g.set(A.id, !0);
      for (const F of A.nodes)
        l.set(F, A.id);
    }
    for (let u = n.length - 1; u >= 0; u--) {
      const A = n[u];
      a.push({
        id: A.id,
        label: A.title,
        labelStyle: "",
        labelType: A.labelType,
        parentId: l.get(A.id),
        padding: 8,
        cssCompiledStyles: this.getCompiledStyles(A.classes),
        cssClasses: A.classes.join(" "),
        shape: "rect",
        dir: A.dir,
        isGroup: !0,
        look: i.look
      });
    }
    this.getVertices().forEach((u) => {
      this.addNodeFromVertex(u, a, l, g, i, i.look || "classic");
    });
    const b = this.getEdges();
    return b.forEach((u, A) => {
      const { arrowTypeStart: F, arrowTypeEnd: f } = this.destructEdgeType(u.type), k = [...b.defaultStyle ?? []];
      u.style && k.push(...u.style);
      const S = {
        id: ie(u.start, u.end, { counter: A, prefix: "L" }, u.id),
        isUserDefinedId: u.isUserDefinedId,
        start: u.start,
        end: u.end,
        type: u.type ?? "normal",
        label: u.text,
        labelType: u.labelType,
        labelpos: "c",
        thickness: u.stroke,
        minlen: u.length,
        classes: u?.stroke === "invisible" ? "" : "edge-thickness-normal edge-pattern-solid flowchart-link",
        arrowTypeStart: u?.stroke === "invisible" || u?.type === "arrow_open" ? "none" : F,
        arrowTypeEnd: u?.stroke === "invisible" || u?.type === "arrow_open" ? "none" : f,
        arrowheadStyle: "fill: #333",
        cssCompiledStyles: this.getCompiledStyles(u.classes),
        labelStyle: k,
        style: k,
        pattern: u.stroke,
        look: i.look,
        animate: u.animate,
        animation: u.animation,
        curve: u.interpolate || this.edges.defaultInterpolate || i.flowchart?.curve
      };
      r.push(S);
    }), { nodes: a, edges: r, other: {}, config: i };
  }
  defaultConfig() {
    return lt.flowchart;
  }
}, m(N1, "FlowDB"), N1), At = /* @__PURE__ */ m(function(s, i) {
  return i.db.getClasses();
}, "getClasses"), kt = /* @__PURE__ */ m(async function(s, i, a, r) {
  $.info("REF0:"), $.info("Drawing state diagram (v2)", i);
  const { securityLevel: n, flowchart: l, layout: g } = b1();
  let c;
  n === "sandbox" && (c = P1("#i" + i));
  const b = n === "sandbox" ? c.nodes()[0].contentDocument : document;
  $.debug("Before getData: ");
  const u = r.db.getData();
  $.debug("Data: ", u);
  const A = dt(i, n), F = r.db.getDirection();
  u.type = r.type, u.layoutAlgorithm = Xe(g), u.layoutAlgorithm === "dagre" && g === "elk" && $.warn(
    "flowchart-elk was moved to an external package in Mermaid v11. Please refer [release notes](https://github.com/mermaid-js/mermaid/releases/tag/v11.0.0) for more details. This diagram will be rendered using `dagre` layout as a fallback."
  ), u.direction = F, u.nodeSpacing = l?.nodeSpacing || 50, u.rankSpacing = l?.rankSpacing || 50, u.markers = ["point", "circle", "cross"], u.diagramId = i, $.debug("REF1:", u), await Qe(u, A);
  const f = u.config.flowchart?.diagramPadding ?? 8;
  re.insertTitle(
    A,
    "flowchartTitleText",
    l?.titleTopMargin || 0,
    r.db.getDiagramTitle()
  ), pt(A, f, "flowchart", l?.useMaxWidth || !1);
  for (const k of u.nodes) {
    const S = P1(`#${i} [id="${k.id}"]`);
    if (!S || !k.link)
      continue;
    const x = b.createElementNS("http://www.w3.org/2000/svg", "a");
    x.setAttributeNS("http://www.w3.org/2000/svg", "class", k.cssClasses), x.setAttributeNS("http://www.w3.org/2000/svg", "rel", "noopener"), n === "sandbox" ? x.setAttributeNS("http://www.w3.org/2000/svg", "target", "_top") : k.linkTarget && x.setAttributeNS("http://www.w3.org/2000/svg", "target", k.linkTarget);
    const d1 = S.insert(function() {
      return x;
    }, ":first-child"), z = S.select(".label-container");
    z && d1.append(function() {
      return z.node();
    });
    const J = S.select(".label");
    J && d1.append(function() {
      return J.node();
    });
  }
}, "draw"), mt = {
  getClasses: At,
  draw: kt
}, ae = (function() {
  var s = /* @__PURE__ */ m(function(g1, h, d, p) {
    for (d = d || {}, p = g1.length; p--; d[g1[p]] = h) ;
    return d;
  }, "o"), i = [1, 4], a = [1, 3], r = [1, 5], n = [1, 8, 9, 10, 11, 27, 34, 36, 38, 44, 60, 84, 85, 86, 87, 88, 89, 102, 105, 106, 109, 111, 114, 115, 116, 121, 122, 123, 124, 125], l = [2, 2], g = [1, 13], c = [1, 14], b = [1, 15], u = [1, 16], A = [1, 23], F = [1, 25], f = [1, 26], k = [1, 27], S = [1, 50], x = [1, 49], d1 = [1, 29], z = [1, 30], J = [1, 31], O1 = [1, 32], M1 = [1, 33], V = [1, 45], w = [1, 47], I = [1, 43], R = [1, 48], N = [1, 44], G = [1, 51], P = [1, 46], O = [1, 52], M = [1, 53], U1 = [1, 34], z1 = [1, 35], W1 = [1, 36], j1 = [1, 37], K1 = [1, 38], p1 = [1, 58], y = [1, 8, 9, 10, 11, 27, 32, 34, 36, 38, 44, 60, 84, 85, 86, 87, 88, 89, 102, 105, 106, 109, 111, 114, 115, 116, 121, 122, 123, 124, 125], e1 = [1, 62], t1 = [1, 61], s1 = [1, 63], C1 = [8, 9, 11, 75, 77, 78], ne = [1, 79], E1 = [1, 92], D1 = [1, 97], T1 = [1, 96], S1 = [1, 93], x1 = [1, 89], y1 = [1, 95], F1 = [1, 91], _1 = [1, 98], B1 = [1, 94], v1 = [1, 99], L1 = [1, 90], A1 = [8, 9, 10, 11, 40, 75, 77, 78], W = [8, 9, 10, 11, 40, 46, 75, 77, 78], q = [8, 9, 10, 11, 29, 40, 44, 46, 48, 50, 52, 54, 56, 58, 60, 63, 65, 67, 68, 70, 75, 77, 78, 89, 102, 105, 106, 109, 111, 114, 115, 116], ue = [8, 9, 11, 44, 60, 75, 77, 78, 89, 102, 105, 106, 109, 111, 114, 115, 116], V1 = [44, 60, 89, 102, 105, 106, 109, 111, 114, 115, 116], oe = [1, 122], le = [1, 123], Y1 = [1, 125], q1 = [1, 124], ce = [44, 60, 62, 74, 89, 102, 105, 106, 109, 111, 114, 115, 116], he = [1, 134], de = [1, 148], pe = [1, 149], fe = [1, 150], ge = [1, 151], be = [1, 136], Ae = [1, 138], ke = [1, 142], me = [1, 143], Ce = [1, 144], Ee = [1, 145], De = [1, 146], Te = [1, 147], Se = [1, 152], xe = [1, 153], ye = [1, 132], Fe = [1, 133], _e = [1, 140], Be = [1, 135], ve = [1, 139], Le = [1, 137], J1 = [8, 9, 10, 11, 27, 32, 34, 36, 38, 44, 60, 84, 85, 86, 87, 88, 89, 102, 105, 106, 109, 111, 114, 115, 116, 121, 122, 123, 124, 125], Ve = [1, 155], we = [1, 157], v = [8, 9, 11], H = [8, 9, 10, 11, 14, 44, 60, 89, 105, 106, 109, 111, 114, 115, 116], C = [1, 177], j = [1, 173], K = [1, 174], E = [1, 178], D = [1, 175], T = [1, 176], w1 = [77, 116, 119], _ = [8, 9, 10, 11, 12, 14, 27, 29, 32, 44, 60, 75, 84, 85, 86, 87, 88, 89, 90, 105, 109, 111, 114, 115, 116], Ie = [10, 106], f1 = [31, 49, 51, 53, 55, 57, 62, 64, 66, 67, 69, 71, 116, 117, 118], i1 = [1, 248], r1 = [1, 246], a1 = [1, 250], n1 = [1, 244], u1 = [1, 245], o1 = [1, 247], l1 = [1, 249], c1 = [1, 251], I1 = [1, 269], Re = [8, 9, 11, 106], Z = [8, 9, 10, 11, 60, 84, 105, 106, 109, 110, 111, 112], Z1 = {
    trace: /* @__PURE__ */ m(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, graphConfig: 4, document: 5, line: 6, statement: 7, SEMI: 8, NEWLINE: 9, SPACE: 10, EOF: 11, GRAPH: 12, NODIR: 13, DIR: 14, FirstStmtSeparator: 15, ending: 16, endToken: 17, spaceList: 18, spaceListNewline: 19, vertexStatement: 20, separator: 21, styleStatement: 22, linkStyleStatement: 23, classDefStatement: 24, classStatement: 25, clickStatement: 26, subgraph: 27, textNoTags: 28, SQS: 29, text: 30, SQE: 31, end: 32, direction: 33, acc_title: 34, acc_title_value: 35, acc_descr: 36, acc_descr_value: 37, acc_descr_multiline_value: 38, shapeData: 39, SHAPE_DATA: 40, link: 41, node: 42, styledVertex: 43, AMP: 44, vertex: 45, STYLE_SEPARATOR: 46, idString: 47, DOUBLECIRCLESTART: 48, DOUBLECIRCLEEND: 49, PS: 50, PE: 51, "(-": 52, "-)": 53, STADIUMSTART: 54, STADIUMEND: 55, SUBROUTINESTART: 56, SUBROUTINEEND: 57, VERTEX_WITH_PROPS_START: 58, "NODE_STRING[field]": 59, COLON: 60, "NODE_STRING[value]": 61, PIPE: 62, CYLINDERSTART: 63, CYLINDEREND: 64, DIAMOND_START: 65, DIAMOND_STOP: 66, TAGEND: 67, TRAPSTART: 68, TRAPEND: 69, INVTRAPSTART: 70, INVTRAPEND: 71, linkStatement: 72, arrowText: 73, TESTSTR: 74, START_LINK: 75, edgeText: 76, LINK: 77, LINK_ID: 78, edgeTextToken: 79, STR: 80, MD_STR: 81, textToken: 82, keywords: 83, STYLE: 84, LINKSTYLE: 85, CLASSDEF: 86, CLASS: 87, CLICK: 88, DOWN: 89, UP: 90, textNoTagsToken: 91, stylesOpt: 92, "idString[vertex]": 93, "idString[class]": 94, CALLBACKNAME: 95, CALLBACKARGS: 96, HREF: 97, LINK_TARGET: 98, "STR[link]": 99, "STR[tooltip]": 100, alphaNum: 101, DEFAULT: 102, numList: 103, INTERPOLATE: 104, NUM: 105, COMMA: 106, style: 107, styleComponent: 108, NODE_STRING: 109, UNIT: 110, BRKT: 111, PCT: 112, idStringToken: 113, MINUS: 114, MULT: 115, UNICODE_TEXT: 116, TEXT: 117, TAGSTART: 118, EDGE_TEXT: 119, alphaNumToken: 120, direction_tb: 121, direction_bt: 122, direction_rl: 123, direction_lr: 124, direction_td: 125, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 8: "SEMI", 9: "NEWLINE", 10: "SPACE", 11: "EOF", 12: "GRAPH", 13: "NODIR", 14: "DIR", 27: "subgraph", 29: "SQS", 31: "SQE", 32: "end", 34: "acc_title", 35: "acc_title_value", 36: "acc_descr", 37: "acc_descr_value", 38: "acc_descr_multiline_value", 40: "SHAPE_DATA", 44: "AMP", 46: "STYLE_SEPARATOR", 48: "DOUBLECIRCLESTART", 49: "DOUBLECIRCLEEND", 50: "PS", 51: "PE", 52: "(-", 53: "-)", 54: "STADIUMSTART", 55: "STADIUMEND", 56: "SUBROUTINESTART", 57: "SUBROUTINEEND", 58: "VERTEX_WITH_PROPS_START", 59: "NODE_STRING[field]", 60: "COLON", 61: "NODE_STRING[value]", 62: "PIPE", 63: "CYLINDERSTART", 64: "CYLINDEREND", 65: "DIAMOND_START", 66: "DIAMOND_STOP", 67: "TAGEND", 68: "TRAPSTART", 69: "TRAPEND", 70: "INVTRAPSTART", 71: "INVTRAPEND", 74: "TESTSTR", 75: "START_LINK", 77: "LINK", 78: "LINK_ID", 80: "STR", 81: "MD_STR", 84: "STYLE", 85: "LINKSTYLE", 86: "CLASSDEF", 87: "CLASS", 88: "CLICK", 89: "DOWN", 90: "UP", 93: "idString[vertex]", 94: "idString[class]", 95: "CALLBACKNAME", 96: "CALLBACKARGS", 97: "HREF", 98: "LINK_TARGET", 99: "STR[link]", 100: "STR[tooltip]", 102: "DEFAULT", 104: "INTERPOLATE", 105: "NUM", 106: "COMMA", 109: "NODE_STRING", 110: "UNIT", 111: "BRKT", 112: "PCT", 114: "MINUS", 115: "MULT", 116: "UNICODE_TEXT", 117: "TEXT", 118: "TAGSTART", 119: "EDGE_TEXT", 121: "direction_tb", 122: "direction_bt", 123: "direction_rl", 124: "direction_lr", 125: "direction_td" },
    productions_: [0, [3, 2], [5, 0], [5, 2], [6, 1], [6, 1], [6, 1], [6, 1], [6, 1], [4, 2], [4, 2], [4, 2], [4, 3], [16, 2], [16, 1], [17, 1], [17, 1], [17, 1], [15, 1], [15, 1], [15, 2], [19, 2], [19, 2], [19, 1], [19, 1], [18, 2], [18, 1], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 9], [7, 6], [7, 4], [7, 1], [7, 2], [7, 2], [7, 1], [21, 1], [21, 1], [21, 1], [39, 2], [39, 1], [20, 4], [20, 3], [20, 4], [20, 2], [20, 2], [20, 1], [42, 1], [42, 6], [42, 5], [43, 1], [43, 3], [45, 4], [45, 4], [45, 6], [45, 4], [45, 4], [45, 4], [45, 8], [45, 4], [45, 4], [45, 4], [45, 6], [45, 4], [45, 4], [45, 4], [45, 4], [45, 4], [45, 1], [41, 2], [41, 3], [41, 3], [41, 1], [41, 3], [41, 4], [76, 1], [76, 2], [76, 1], [76, 1], [72, 1], [72, 2], [73, 3], [30, 1], [30, 2], [30, 1], [30, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [28, 1], [28, 2], [28, 1], [28, 1], [24, 5], [25, 5], [26, 2], [26, 4], [26, 3], [26, 5], [26, 3], [26, 5], [26, 5], [26, 7], [26, 2], [26, 4], [26, 2], [26, 4], [26, 4], [26, 6], [22, 5], [23, 5], [23, 5], [23, 9], [23, 9], [23, 7], [23, 7], [103, 1], [103, 3], [92, 1], [92, 3], [107, 1], [107, 2], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [82, 1], [82, 1], [82, 1], [82, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [79, 1], [79, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [47, 1], [47, 2], [101, 1], [101, 2], [33, 1], [33, 1], [33, 1], [33, 1], [33, 1]],
    performAction: /* @__PURE__ */ m(function(h, d, p, o, B, e, G1) {
      var t = e.length - 1;
      switch (B) {
        case 2:
          this.$ = [];
          break;
        case 3:
          (!Array.isArray(e[t]) || e[t].length > 0) && e[t - 1].push(e[t]), this.$ = e[t - 1];
          break;
        case 4:
        case 183:
          this.$ = e[t];
          break;
        case 11:
          o.setDirection("TB"), this.$ = "TB";
          break;
        case 12:
          o.setDirection(e[t - 1]), this.$ = e[t - 1];
          break;
        case 27:
          this.$ = e[t - 1].nodes;
          break;
        case 28:
        case 29:
        case 30:
        case 31:
        case 32:
          this.$ = [];
          break;
        case 33:
          this.$ = o.addSubGraph(e[t - 6], e[t - 1], e[t - 4]);
          break;
        case 34:
          this.$ = o.addSubGraph(e[t - 3], e[t - 1], e[t - 3]);
          break;
        case 35:
          this.$ = o.addSubGraph(void 0, e[t - 1], void 0);
          break;
        case 37:
          this.$ = e[t].trim(), o.setAccTitle(this.$);
          break;
        case 38:
        case 39:
          this.$ = e[t].trim(), o.setAccDescription(this.$);
          break;
        case 43:
          this.$ = e[t - 1] + e[t];
          break;
        case 44:
          this.$ = e[t];
          break;
        case 45:
          o.addVertex(e[t - 1][e[t - 1].length - 1], void 0, void 0, void 0, void 0, void 0, void 0, e[t]), o.addLink(e[t - 3].stmt, e[t - 1], e[t - 2]), this.$ = { stmt: e[t - 1], nodes: e[t - 1].concat(e[t - 3].nodes) };
          break;
        case 46:
          o.addLink(e[t - 2].stmt, e[t], e[t - 1]), this.$ = { stmt: e[t], nodes: e[t].concat(e[t - 2].nodes) };
          break;
        case 47:
          o.addLink(e[t - 3].stmt, e[t - 1], e[t - 2]), this.$ = { stmt: e[t - 1], nodes: e[t - 1].concat(e[t - 3].nodes) };
          break;
        case 48:
          this.$ = { stmt: e[t - 1], nodes: e[t - 1] };
          break;
        case 49:
          o.addVertex(e[t - 1][e[t - 1].length - 1], void 0, void 0, void 0, void 0, void 0, void 0, e[t]), this.$ = { stmt: e[t - 1], nodes: e[t - 1], shapeData: e[t] };
          break;
        case 50:
          this.$ = { stmt: e[t], nodes: e[t] };
          break;
        case 51:
          this.$ = [e[t]];
          break;
        case 52:
          o.addVertex(e[t - 5][e[t - 5].length - 1], void 0, void 0, void 0, void 0, void 0, void 0, e[t - 4]), this.$ = e[t - 5].concat(e[t]);
          break;
        case 53:
          this.$ = e[t - 4].concat(e[t]);
          break;
        case 54:
          this.$ = e[t];
          break;
        case 55:
          this.$ = e[t - 2], o.setClass(e[t - 2], e[t]);
          break;
        case 56:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "square");
          break;
        case 57:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "doublecircle");
          break;
        case 58:
          this.$ = e[t - 5], o.addVertex(e[t - 5], e[t - 2], "circle");
          break;
        case 59:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "ellipse");
          break;
        case 60:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "stadium");
          break;
        case 61:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "subroutine");
          break;
        case 62:
          this.$ = e[t - 7], o.addVertex(e[t - 7], e[t - 1], "rect", void 0, void 0, void 0, Object.fromEntries([[e[t - 5], e[t - 3]]]));
          break;
        case 63:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "cylinder");
          break;
        case 64:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "round");
          break;
        case 65:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "diamond");
          break;
        case 66:
          this.$ = e[t - 5], o.addVertex(e[t - 5], e[t - 2], "hexagon");
          break;
        case 67:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "odd");
          break;
        case 68:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "trapezoid");
          break;
        case 69:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "inv_trapezoid");
          break;
        case 70:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "lean_right");
          break;
        case 71:
          this.$ = e[t - 3], o.addVertex(e[t - 3], e[t - 1], "lean_left");
          break;
        case 72:
          this.$ = e[t], o.addVertex(e[t]);
          break;
        case 73:
          e[t - 1].text = e[t], this.$ = e[t - 1];
          break;
        case 74:
        case 75:
          e[t - 2].text = e[t - 1], this.$ = e[t - 2];
          break;
        case 76:
          this.$ = e[t];
          break;
        case 77:
          var L = o.destructLink(e[t], e[t - 2]);
          this.$ = { type: L.type, stroke: L.stroke, length: L.length, text: e[t - 1] };
          break;
        case 78:
          var L = o.destructLink(e[t], e[t - 2]);
          this.$ = { type: L.type, stroke: L.stroke, length: L.length, text: e[t - 1], id: e[t - 3] };
          break;
        case 79:
          this.$ = { text: e[t], type: "text" };
          break;
        case 80:
          this.$ = { text: e[t - 1].text + "" + e[t], type: e[t - 1].type };
          break;
        case 81:
          this.$ = { text: e[t], type: "string" };
          break;
        case 82:
          this.$ = { text: e[t], type: "markdown" };
          break;
        case 83:
          var L = o.destructLink(e[t]);
          this.$ = { type: L.type, stroke: L.stroke, length: L.length };
          break;
        case 84:
          var L = o.destructLink(e[t]);
          this.$ = { type: L.type, stroke: L.stroke, length: L.length, id: e[t - 1] };
          break;
        case 85:
          this.$ = e[t - 1];
          break;
        case 86:
          this.$ = { text: e[t], type: "text" };
          break;
        case 87:
          this.$ = { text: e[t - 1].text + "" + e[t], type: e[t - 1].type };
          break;
        case 88:
          this.$ = { text: e[t], type: "string" };
          break;
        case 89:
        case 104:
          this.$ = { text: e[t], type: "markdown" };
          break;
        case 101:
          this.$ = { text: e[t], type: "text" };
          break;
        case 102:
          this.$ = { text: e[t - 1].text + "" + e[t], type: e[t - 1].type };
          break;
        case 103:
          this.$ = { text: e[t], type: "text" };
          break;
        case 105:
          this.$ = e[t - 4], o.addClass(e[t - 2], e[t]);
          break;
        case 106:
          this.$ = e[t - 4], o.setClass(e[t - 2], e[t]);
          break;
        case 107:
        case 115:
          this.$ = e[t - 1], o.setClickEvent(e[t - 1], e[t]);
          break;
        case 108:
        case 116:
          this.$ = e[t - 3], o.setClickEvent(e[t - 3], e[t - 2]), o.setTooltip(e[t - 3], e[t]);
          break;
        case 109:
          this.$ = e[t - 2], o.setClickEvent(e[t - 2], e[t - 1], e[t]);
          break;
        case 110:
          this.$ = e[t - 4], o.setClickEvent(e[t - 4], e[t - 3], e[t - 2]), o.setTooltip(e[t - 4], e[t]);
          break;
        case 111:
          this.$ = e[t - 2], o.setLink(e[t - 2], e[t]);
          break;
        case 112:
          this.$ = e[t - 4], o.setLink(e[t - 4], e[t - 2]), o.setTooltip(e[t - 4], e[t]);
          break;
        case 113:
          this.$ = e[t - 4], o.setLink(e[t - 4], e[t - 2], e[t]);
          break;
        case 114:
          this.$ = e[t - 6], o.setLink(e[t - 6], e[t - 4], e[t]), o.setTooltip(e[t - 6], e[t - 2]);
          break;
        case 117:
          this.$ = e[t - 1], o.setLink(e[t - 1], e[t]);
          break;
        case 118:
          this.$ = e[t - 3], o.setLink(e[t - 3], e[t - 2]), o.setTooltip(e[t - 3], e[t]);
          break;
        case 119:
          this.$ = e[t - 3], o.setLink(e[t - 3], e[t - 2], e[t]);
          break;
        case 120:
          this.$ = e[t - 5], o.setLink(e[t - 5], e[t - 4], e[t]), o.setTooltip(e[t - 5], e[t - 2]);
          break;
        case 121:
          this.$ = e[t - 4], o.addVertex(e[t - 2], void 0, void 0, e[t]);
          break;
        case 122:
          this.$ = e[t - 4], o.updateLink([e[t - 2]], e[t]);
          break;
        case 123:
          this.$ = e[t - 4], o.updateLink(e[t - 2], e[t]);
          break;
        case 124:
          this.$ = e[t - 8], o.updateLinkInterpolate([e[t - 6]], e[t - 2]), o.updateLink([e[t - 6]], e[t]);
          break;
        case 125:
          this.$ = e[t - 8], o.updateLinkInterpolate(e[t - 6], e[t - 2]), o.updateLink(e[t - 6], e[t]);
          break;
        case 126:
          this.$ = e[t - 6], o.updateLinkInterpolate([e[t - 4]], e[t]);
          break;
        case 127:
          this.$ = e[t - 6], o.updateLinkInterpolate(e[t - 4], e[t]);
          break;
        case 128:
        case 130:
          this.$ = [e[t]];
          break;
        case 129:
        case 131:
          e[t - 2].push(e[t]), this.$ = e[t - 2];
          break;
        case 133:
          this.$ = e[t - 1] + e[t];
          break;
        case 181:
          this.$ = e[t];
          break;
        case 182:
          this.$ = e[t - 1] + "" + e[t];
          break;
        case 184:
          this.$ = e[t - 1] + "" + e[t];
          break;
        case 185:
          this.$ = { stmt: "dir", value: "TB" };
          break;
        case 186:
          this.$ = { stmt: "dir", value: "BT" };
          break;
        case 187:
          this.$ = { stmt: "dir", value: "RL" };
          break;
        case 188:
          this.$ = { stmt: "dir", value: "LR" };
          break;
        case 189:
          this.$ = { stmt: "dir", value: "TD" };
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: 2, 9: i, 10: a, 12: r }, { 1: [3] }, s(n, l, { 5: 6 }), { 4: 7, 9: i, 10: a, 12: r }, { 4: 8, 9: i, 10: a, 12: r }, { 13: [1, 9], 14: [1, 10] }, { 1: [2, 1], 6: 11, 7: 12, 8: g, 9: c, 10: b, 11: u, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: A, 33: 24, 34: F, 36: f, 38: k, 42: 28, 43: 39, 44: S, 45: 40, 47: 41, 60: x, 84: d1, 85: z, 86: J, 87: O1, 88: M1, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M, 121: U1, 122: z1, 123: W1, 124: j1, 125: K1 }, s(n, [2, 9]), s(n, [2, 10]), s(n, [2, 11]), { 8: [1, 55], 9: [1, 56], 10: p1, 15: 54, 18: 57 }, s(y, [2, 3]), s(y, [2, 4]), s(y, [2, 5]), s(y, [2, 6]), s(y, [2, 7]), s(y, [2, 8]), { 8: e1, 9: t1, 11: s1, 21: 59, 41: 60, 72: 64, 75: [1, 65], 77: [1, 67], 78: [1, 66] }, { 8: e1, 9: t1, 11: s1, 21: 68 }, { 8: e1, 9: t1, 11: s1, 21: 69 }, { 8: e1, 9: t1, 11: s1, 21: 70 }, { 8: e1, 9: t1, 11: s1, 21: 71 }, { 8: e1, 9: t1, 11: s1, 21: 72 }, { 8: e1, 9: t1, 10: [1, 73], 11: s1, 21: 74 }, s(y, [2, 36]), { 35: [1, 75] }, { 37: [1, 76] }, s(y, [2, 39]), s(C1, [2, 50], { 18: 77, 39: 78, 10: p1, 40: ne }), { 10: [1, 80] }, { 10: [1, 81] }, { 10: [1, 82] }, { 10: [1, 83] }, { 14: E1, 44: D1, 60: T1, 80: [1, 87], 89: S1, 95: [1, 84], 97: [1, 85], 101: 86, 105: x1, 106: y1, 109: F1, 111: _1, 114: B1, 115: v1, 116: L1, 120: 88 }, s(y, [2, 185]), s(y, [2, 186]), s(y, [2, 187]), s(y, [2, 188]), s(y, [2, 189]), s(A1, [2, 51]), s(A1, [2, 54], { 46: [1, 100] }), s(W, [2, 72], { 113: 113, 29: [1, 101], 44: S, 48: [1, 102], 50: [1, 103], 52: [1, 104], 54: [1, 105], 56: [1, 106], 58: [1, 107], 60: x, 63: [1, 108], 65: [1, 109], 67: [1, 110], 68: [1, 111], 70: [1, 112], 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 114: P, 115: O, 116: M }), s(q, [2, 181]), s(q, [2, 142]), s(q, [2, 143]), s(q, [2, 144]), s(q, [2, 145]), s(q, [2, 146]), s(q, [2, 147]), s(q, [2, 148]), s(q, [2, 149]), s(q, [2, 150]), s(q, [2, 151]), s(q, [2, 152]), s(n, [2, 12]), s(n, [2, 18]), s(n, [2, 19]), { 9: [1, 114] }, s(ue, [2, 26], { 18: 115, 10: p1 }), s(y, [2, 27]), { 42: 116, 43: 39, 44: S, 45: 40, 47: 41, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, s(y, [2, 40]), s(y, [2, 41]), s(y, [2, 42]), s(V1, [2, 76], { 73: 117, 62: [1, 119], 74: [1, 118] }), { 76: 120, 79: 121, 80: oe, 81: le, 116: Y1, 119: q1 }, { 75: [1, 126], 77: [1, 127] }, s(ce, [2, 83]), s(y, [2, 28]), s(y, [2, 29]), s(y, [2, 30]), s(y, [2, 31]), s(y, [2, 32]), { 10: he, 12: de, 14: pe, 27: fe, 28: 128, 32: ge, 44: be, 60: Ae, 75: ke, 80: [1, 130], 81: [1, 131], 83: 141, 84: me, 85: Ce, 86: Ee, 87: De, 88: Te, 89: Se, 90: xe, 91: 129, 105: ye, 109: Fe, 111: _e, 114: Be, 115: ve, 116: Le }, s(J1, l, { 5: 154 }), s(y, [2, 37]), s(y, [2, 38]), s(C1, [2, 48], { 44: Ve }), s(C1, [2, 49], { 18: 156, 10: p1, 40: we }), s(A1, [2, 44]), { 44: S, 47: 158, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, { 102: [1, 159], 103: 160, 105: [1, 161] }, { 44: S, 47: 162, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, { 44: S, 47: 163, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, s(v, [2, 107], { 10: [1, 164], 96: [1, 165] }), { 80: [1, 166] }, s(v, [2, 115], { 120: 168, 10: [1, 167], 14: E1, 44: D1, 60: T1, 89: S1, 105: x1, 106: y1, 109: F1, 111: _1, 114: B1, 115: v1, 116: L1 }), s(v, [2, 117], { 10: [1, 169] }), s(H, [2, 183]), s(H, [2, 170]), s(H, [2, 171]), s(H, [2, 172]), s(H, [2, 173]), s(H, [2, 174]), s(H, [2, 175]), s(H, [2, 176]), s(H, [2, 177]), s(H, [2, 178]), s(H, [2, 179]), s(H, [2, 180]), { 44: S, 47: 170, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, { 30: 171, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 179, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 181, 50: [1, 180], 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 182, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 183, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 184, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 109: [1, 185] }, { 30: 186, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 187, 65: [1, 188], 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 189, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 190, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 30: 191, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, s(q, [2, 182]), s(n, [2, 20]), s(ue, [2, 25]), s(C1, [2, 46], { 39: 192, 18: 193, 10: p1, 40: ne }), s(V1, [2, 73], { 10: [1, 194] }), { 10: [1, 195] }, { 30: 196, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 77: [1, 197], 79: 198, 116: Y1, 119: q1 }, s(w1, [2, 79]), s(w1, [2, 81]), s(w1, [2, 82]), s(w1, [2, 168]), s(w1, [2, 169]), { 76: 199, 79: 121, 80: oe, 81: le, 116: Y1, 119: q1 }, s(ce, [2, 84]), { 8: e1, 9: t1, 10: he, 11: s1, 12: de, 14: pe, 21: 201, 27: fe, 29: [1, 200], 32: ge, 44: be, 60: Ae, 75: ke, 83: 141, 84: me, 85: Ce, 86: Ee, 87: De, 88: Te, 89: Se, 90: xe, 91: 202, 105: ye, 109: Fe, 111: _e, 114: Be, 115: ve, 116: Le }, s(_, [2, 101]), s(_, [2, 103]), s(_, [2, 104]), s(_, [2, 157]), s(_, [2, 158]), s(_, [2, 159]), s(_, [2, 160]), s(_, [2, 161]), s(_, [2, 162]), s(_, [2, 163]), s(_, [2, 164]), s(_, [2, 165]), s(_, [2, 166]), s(_, [2, 167]), s(_, [2, 90]), s(_, [2, 91]), s(_, [2, 92]), s(_, [2, 93]), s(_, [2, 94]), s(_, [2, 95]), s(_, [2, 96]), s(_, [2, 97]), s(_, [2, 98]), s(_, [2, 99]), s(_, [2, 100]), { 6: 11, 7: 12, 8: g, 9: c, 10: b, 11: u, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: A, 32: [1, 203], 33: 24, 34: F, 36: f, 38: k, 42: 28, 43: 39, 44: S, 45: 40, 47: 41, 60: x, 84: d1, 85: z, 86: J, 87: O1, 88: M1, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M, 121: U1, 122: z1, 123: W1, 124: j1, 125: K1 }, { 10: p1, 18: 204 }, { 44: [1, 205] }, s(A1, [2, 43]), { 10: [1, 206], 44: S, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 113, 114: P, 115: O, 116: M }, { 10: [1, 207] }, { 10: [1, 208], 106: [1, 209] }, s(Ie, [2, 128]), { 10: [1, 210], 44: S, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 113, 114: P, 115: O, 116: M }, { 10: [1, 211], 44: S, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 113, 114: P, 115: O, 116: M }, { 80: [1, 212] }, s(v, [2, 109], { 10: [1, 213] }), s(v, [2, 111], { 10: [1, 214] }), { 80: [1, 215] }, s(H, [2, 184]), { 80: [1, 216], 98: [1, 217] }, s(A1, [2, 55], { 113: 113, 44: S, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 114: P, 115: O, 116: M }), { 31: [1, 218], 67: C, 82: 219, 116: E, 117: D, 118: T }, s(f1, [2, 86]), s(f1, [2, 88]), s(f1, [2, 89]), s(f1, [2, 153]), s(f1, [2, 154]), s(f1, [2, 155]), s(f1, [2, 156]), { 49: [1, 220], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 30: 221, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 51: [1, 222], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 53: [1, 223], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 55: [1, 224], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 57: [1, 225], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 60: [1, 226] }, { 64: [1, 227], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 66: [1, 228], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 30: 229, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, { 31: [1, 230], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 67: C, 69: [1, 231], 71: [1, 232], 82: 219, 116: E, 117: D, 118: T }, { 67: C, 69: [1, 234], 71: [1, 233], 82: 219, 116: E, 117: D, 118: T }, s(C1, [2, 45], { 18: 156, 10: p1, 40: we }), s(C1, [2, 47], { 44: Ve }), s(V1, [2, 75]), s(V1, [2, 74]), { 62: [1, 235], 67: C, 82: 219, 116: E, 117: D, 118: T }, s(V1, [2, 77]), s(w1, [2, 80]), { 77: [1, 236], 79: 198, 116: Y1, 119: q1 }, { 30: 237, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, s(J1, l, { 5: 238 }), s(_, [2, 102]), s(y, [2, 35]), { 43: 239, 44: S, 45: 40, 47: 41, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, { 10: p1, 18: 240 }, { 10: i1, 60: r1, 84: a1, 92: 241, 105: n1, 107: 242, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, { 10: i1, 60: r1, 84: a1, 92: 252, 104: [1, 253], 105: n1, 107: 242, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, { 10: i1, 60: r1, 84: a1, 92: 254, 104: [1, 255], 105: n1, 107: 242, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, { 105: [1, 256] }, { 10: i1, 60: r1, 84: a1, 92: 257, 105: n1, 107: 242, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, { 44: S, 47: 258, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, s(v, [2, 108]), { 80: [1, 259] }, { 80: [1, 260], 98: [1, 261] }, s(v, [2, 116]), s(v, [2, 118], { 10: [1, 262] }), s(v, [2, 119]), s(W, [2, 56]), s(f1, [2, 87]), s(W, [2, 57]), { 51: [1, 263], 67: C, 82: 219, 116: E, 117: D, 118: T }, s(W, [2, 64]), s(W, [2, 59]), s(W, [2, 60]), s(W, [2, 61]), { 109: [1, 264] }, s(W, [2, 63]), s(W, [2, 65]), { 66: [1, 265], 67: C, 82: 219, 116: E, 117: D, 118: T }, s(W, [2, 67]), s(W, [2, 68]), s(W, [2, 70]), s(W, [2, 69]), s(W, [2, 71]), s([10, 44, 60, 89, 102, 105, 106, 109, 111, 114, 115, 116], [2, 85]), s(V1, [2, 78]), { 31: [1, 266], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 6: 11, 7: 12, 8: g, 9: c, 10: b, 11: u, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: A, 32: [1, 267], 33: 24, 34: F, 36: f, 38: k, 42: 28, 43: 39, 44: S, 45: 40, 47: 41, 60: x, 84: d1, 85: z, 86: J, 87: O1, 88: M1, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M, 121: U1, 122: z1, 123: W1, 124: j1, 125: K1 }, s(A1, [2, 53]), { 43: 268, 44: S, 45: 40, 47: 41, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M }, s(v, [2, 121], { 106: I1 }), s(Re, [2, 130], { 108: 270, 10: i1, 60: r1, 84: a1, 105: n1, 109: u1, 110: o1, 111: l1, 112: c1 }), s(Z, [2, 132]), s(Z, [2, 134]), s(Z, [2, 135]), s(Z, [2, 136]), s(Z, [2, 137]), s(Z, [2, 138]), s(Z, [2, 139]), s(Z, [2, 140]), s(Z, [2, 141]), s(v, [2, 122], { 106: I1 }), { 10: [1, 271] }, s(v, [2, 123], { 106: I1 }), { 10: [1, 272] }, s(Ie, [2, 129]), s(v, [2, 105], { 106: I1 }), s(v, [2, 106], { 113: 113, 44: S, 60: x, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 114: P, 115: O, 116: M }), s(v, [2, 110]), s(v, [2, 112], { 10: [1, 273] }), s(v, [2, 113]), { 98: [1, 274] }, { 51: [1, 275] }, { 62: [1, 276] }, { 66: [1, 277] }, { 8: e1, 9: t1, 11: s1, 21: 278 }, s(y, [2, 34]), s(A1, [2, 52]), { 10: i1, 60: r1, 84: a1, 105: n1, 107: 279, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, s(Z, [2, 133]), { 14: E1, 44: D1, 60: T1, 89: S1, 101: 280, 105: x1, 106: y1, 109: F1, 111: _1, 114: B1, 115: v1, 116: L1, 120: 88 }, { 14: E1, 44: D1, 60: T1, 89: S1, 101: 281, 105: x1, 106: y1, 109: F1, 111: _1, 114: B1, 115: v1, 116: L1, 120: 88 }, { 98: [1, 282] }, s(v, [2, 120]), s(W, [2, 58]), { 30: 283, 67: C, 80: j, 81: K, 82: 172, 116: E, 117: D, 118: T }, s(W, [2, 66]), s(J1, l, { 5: 284 }), s(Re, [2, 131], { 108: 270, 10: i1, 60: r1, 84: a1, 105: n1, 109: u1, 110: o1, 111: l1, 112: c1 }), s(v, [2, 126], { 120: 168, 10: [1, 285], 14: E1, 44: D1, 60: T1, 89: S1, 105: x1, 106: y1, 109: F1, 111: _1, 114: B1, 115: v1, 116: L1 }), s(v, [2, 127], { 120: 168, 10: [1, 286], 14: E1, 44: D1, 60: T1, 89: S1, 105: x1, 106: y1, 109: F1, 111: _1, 114: B1, 115: v1, 116: L1 }), s(v, [2, 114]), { 31: [1, 287], 67: C, 82: 219, 116: E, 117: D, 118: T }, { 6: 11, 7: 12, 8: g, 9: c, 10: b, 11: u, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: A, 32: [1, 288], 33: 24, 34: F, 36: f, 38: k, 42: 28, 43: 39, 44: S, 45: 40, 47: 41, 60: x, 84: d1, 85: z, 86: J, 87: O1, 88: M1, 89: V, 102: w, 105: I, 106: R, 109: N, 111: G, 113: 42, 114: P, 115: O, 116: M, 121: U1, 122: z1, 123: W1, 124: j1, 125: K1 }, { 10: i1, 60: r1, 84: a1, 92: 289, 105: n1, 107: 242, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, { 10: i1, 60: r1, 84: a1, 92: 290, 105: n1, 107: 242, 108: 243, 109: u1, 110: o1, 111: l1, 112: c1 }, s(W, [2, 62]), s(y, [2, 33]), s(v, [2, 124], { 106: I1 }), s(v, [2, 125], { 106: I1 })],
    defaultActions: {},
    parseError: /* @__PURE__ */ m(function(h, d) {
      if (d.recoverable)
        this.trace(h);
      else {
        var p = new Error(h);
        throw p.hash = d, p;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ m(function(h) {
      var d = this, p = [0], o = [], B = [null], e = [], G1 = this.table, t = "", L = 0, Ne = 0, je = 2, Ge = 1, Ke = e.slice.call(arguments, 1), U = Object.create(this.lexer), k1 = { yy: {} };
      for (var $1 in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, $1) && (k1.yy[$1] = this.yy[$1]);
      U.setInput(h, k1.yy), k1.yy.lexer = U, k1.yy.parser = this, typeof U.yylloc > "u" && (U.yylloc = {});
      var ee = U.yylloc;
      e.push(ee);
      var Ye = U.options && U.options.ranges;
      typeof k1.yy.parseError == "function" ? this.parseError = k1.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function qe(X) {
        p.length = p.length - 2 * X, B.length = B.length - X, e.length = e.length - X;
      }
      m(qe, "popStack");
      function Pe() {
        var X;
        return X = o.pop() || U.lex() || Ge, typeof X != "number" && (X instanceof Array && (o = X, X = o.pop()), X = d.symbols_[X] || X), X;
      }
      m(Pe, "lex");
      for (var Y, m1, Q, te, R1 = {}, X1, h1, Oe, Q1; ; ) {
        if (m1 = p[p.length - 1], this.defaultActions[m1] ? Q = this.defaultActions[m1] : ((Y === null || typeof Y > "u") && (Y = Pe()), Q = G1[m1] && G1[m1][Y]), typeof Q > "u" || !Q.length || !Q[0]) {
          var se = "";
          Q1 = [];
          for (X1 in G1[m1])
            this.terminals_[X1] && X1 > je && Q1.push("'" + this.terminals_[X1] + "'");
          U.showPosition ? se = "Parse error on line " + (L + 1) + `:
` + U.showPosition() + `
Expecting ` + Q1.join(", ") + ", got '" + (this.terminals_[Y] || Y) + "'" : se = "Parse error on line " + (L + 1) + ": Unexpected " + (Y == Ge ? "end of input" : "'" + (this.terminals_[Y] || Y) + "'"), this.parseError(se, {
            text: U.match,
            token: this.terminals_[Y] || Y,
            line: U.yylineno,
            loc: ee,
            expected: Q1
          });
        }
        if (Q[0] instanceof Array && Q.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + m1 + ", token: " + Y);
        switch (Q[0]) {
          case 1:
            p.push(Y), B.push(U.yytext), e.push(U.yylloc), p.push(Q[1]), Y = null, Ne = U.yyleng, t = U.yytext, L = U.yylineno, ee = U.yylloc;
            break;
          case 2:
            if (h1 = this.productions_[Q[1]][1], R1.$ = B[B.length - h1], R1._$ = {
              first_line: e[e.length - (h1 || 1)].first_line,
              last_line: e[e.length - 1].last_line,
              first_column: e[e.length - (h1 || 1)].first_column,
              last_column: e[e.length - 1].last_column
            }, Ye && (R1._$.range = [
              e[e.length - (h1 || 1)].range[0],
              e[e.length - 1].range[1]
            ]), te = this.performAction.apply(R1, [
              t,
              Ne,
              L,
              k1.yy,
              Q[1],
              B,
              e
            ].concat(Ke)), typeof te < "u")
              return te;
            h1 && (p = p.slice(0, -1 * h1 * 2), B = B.slice(0, -1 * h1), e = e.slice(0, -1 * h1)), p.push(this.productions_[Q[1]][0]), B.push(R1.$), e.push(R1._$), Oe = G1[p[p.length - 2]][p[p.length - 1]], p.push(Oe);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, We = /* @__PURE__ */ (function() {
    var g1 = {
      EOF: 1,
      parseError: /* @__PURE__ */ m(function(d, p) {
        if (this.yy.parser)
          this.yy.parser.parseError(d, p);
        else
          throw new Error(d);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ m(function(h, d) {
        return this.yy = d || this.yy || {}, this._input = h, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ m(function() {
        var h = this._input[0];
        this.yytext += h, this.yyleng++, this.offset++, this.match += h, this.matched += h;
        var d = h.match(/(?:\r\n?|\n).*/g);
        return d ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), h;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ m(function(h) {
        var d = h.length, p = h.split(/(?:\r\n?|\n)/g);
        this._input = h + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - d), this.offset -= d;
        var o = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), p.length - 1 && (this.yylineno -= p.length - 1);
        var B = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: p ? (p.length === o.length ? this.yylloc.first_column : 0) + o[o.length - p.length].length - p[0].length : this.yylloc.first_column - d
        }, this.options.ranges && (this.yylloc.range = [B[0], B[0] + this.yyleng - d]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ m(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ m(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ m(function(h) {
        this.unput(this.match.slice(h));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ m(function() {
        var h = this.matched.substr(0, this.matched.length - this.match.length);
        return (h.length > 20 ? "..." : "") + h.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ m(function() {
        var h = this.match;
        return h.length < 20 && (h += this._input.substr(0, 20 - h.length)), (h.substr(0, 20) + (h.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ m(function() {
        var h = this.pastInput(), d = new Array(h.length + 1).join("-");
        return h + this.upcomingInput() + `
` + d + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ m(function(h, d) {
        var p, o, B;
        if (this.options.backtrack_lexer && (B = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (B.yylloc.range = this.yylloc.range.slice(0))), o = h[0].match(/(?:\r\n?|\n).*/g), o && (this.yylineno += o.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: o ? o[o.length - 1].length - o[o.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + h[0].length
        }, this.yytext += h[0], this.match += h[0], this.matches = h, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(h[0].length), this.matched += h[0], p = this.performAction.call(this, this.yy, this, d, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), p)
          return p;
        if (this._backtrack) {
          for (var e in B)
            this[e] = B[e];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ m(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var h, d, p, o;
        this._more || (this.yytext = "", this.match = "");
        for (var B = this._currentRules(), e = 0; e < B.length; e++)
          if (p = this._input.match(this.rules[B[e]]), p && (!d || p[0].length > d[0].length)) {
            if (d = p, o = e, this.options.backtrack_lexer) {
              if (h = this.test_match(p, B[e]), h !== !1)
                return h;
              if (this._backtrack) {
                d = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return d ? (h = this.test_match(d, B[o]), h !== !1 ? h : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ m(function() {
        var d = this.next();
        return d || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ m(function(d) {
        this.conditionStack.push(d);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ m(function() {
        var d = this.conditionStack.length - 1;
        return d > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ m(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ m(function(d) {
        return d = this.conditionStack.length - 1 - Math.abs(d || 0), d >= 0 ? this.conditionStack[d] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ m(function(d) {
        this.begin(d);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ m(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: {},
      performAction: /* @__PURE__ */ m(function(d, p, o, B) {
        switch (o) {
          case 0:
            return this.begin("acc_title"), 34;
          case 1:
            return this.popState(), "acc_title_value";
          case 2:
            return this.begin("acc_descr"), 36;
          case 3:
            return this.popState(), "acc_descr_value";
          case 4:
            this.begin("acc_descr_multiline");
            break;
          case 5:
            this.popState();
            break;
          case 6:
            return "acc_descr_multiline_value";
          case 7:
            return this.pushState("shapeData"), p.yytext = "", 40;
          case 8:
            return this.pushState("shapeDataStr"), 40;
          case 9:
            return this.popState(), 40;
          case 10:
            const e = /\n\s*/g;
            return p.yytext = p.yytext.replace(e, "<br/>"), 40;
          case 11:
            return 40;
          case 12:
            this.popState();
            break;
          case 13:
            this.begin("callbackname");
            break;
          case 14:
            this.popState();
            break;
          case 15:
            this.popState(), this.begin("callbackargs");
            break;
          case 16:
            return 95;
          case 17:
            this.popState();
            break;
          case 18:
            return 96;
          case 19:
            return "MD_STR";
          case 20:
            this.popState();
            break;
          case 21:
            this.begin("md_string");
            break;
          case 22:
            return "STR";
          case 23:
            this.popState();
            break;
          case 24:
            this.pushState("string");
            break;
          case 25:
            return 84;
          case 26:
            return 102;
          case 27:
            return 85;
          case 28:
            return 104;
          case 29:
            return 86;
          case 30:
            return 87;
          case 31:
            return 97;
          case 32:
            this.begin("click");
            break;
          case 33:
            this.popState();
            break;
          case 34:
            return 88;
          case 35:
            return d.lex.firstGraph() && this.begin("dir"), 12;
          case 36:
            return d.lex.firstGraph() && this.begin("dir"), 12;
          case 37:
            return d.lex.firstGraph() && this.begin("dir"), 12;
          case 38:
            return 27;
          case 39:
            return 32;
          case 40:
            return 98;
          case 41:
            return 98;
          case 42:
            return 98;
          case 43:
            return 98;
          case 44:
            return this.popState(), 13;
          case 45:
            return this.popState(), 14;
          case 46:
            return this.popState(), 14;
          case 47:
            return this.popState(), 14;
          case 48:
            return this.popState(), 14;
          case 49:
            return this.popState(), 14;
          case 50:
            return this.popState(), 14;
          case 51:
            return this.popState(), 14;
          case 52:
            return this.popState(), 14;
          case 53:
            return this.popState(), 14;
          case 54:
            return this.popState(), 14;
          case 55:
            return 121;
          case 56:
            return 122;
          case 57:
            return 123;
          case 58:
            return 124;
          case 59:
            return 125;
          case 60:
            return 78;
          case 61:
            return 105;
          case 62:
            return 111;
          case 63:
            return 46;
          case 64:
            return 60;
          case 65:
            return 44;
          case 66:
            return 8;
          case 67:
            return 106;
          case 68:
            return 115;
          case 69:
            return this.popState(), 77;
          case 70:
            return this.pushState("edgeText"), 75;
          case 71:
            return 119;
          case 72:
            return this.popState(), 77;
          case 73:
            return this.pushState("thickEdgeText"), 75;
          case 74:
            return 119;
          case 75:
            return this.popState(), 77;
          case 76:
            return this.pushState("dottedEdgeText"), 75;
          case 77:
            return 119;
          case 78:
            return 77;
          case 79:
            return this.popState(), 53;
          case 80:
            return "TEXT";
          case 81:
            return this.pushState("ellipseText"), 52;
          case 82:
            return this.popState(), 55;
          case 83:
            return this.pushState("text"), 54;
          case 84:
            return this.popState(), 57;
          case 85:
            return this.pushState("text"), 56;
          case 86:
            return 58;
          case 87:
            return this.pushState("text"), 67;
          case 88:
            return this.popState(), 64;
          case 89:
            return this.pushState("text"), 63;
          case 90:
            return this.popState(), 49;
          case 91:
            return this.pushState("text"), 48;
          case 92:
            return this.popState(), 69;
          case 93:
            return this.popState(), 71;
          case 94:
            return 117;
          case 95:
            return this.pushState("trapText"), 68;
          case 96:
            return this.pushState("trapText"), 70;
          case 97:
            return 118;
          case 98:
            return 67;
          case 99:
            return 90;
          case 100:
            return "SEP";
          case 101:
            return 89;
          case 102:
            return 115;
          case 103:
            return 111;
          case 104:
            return 44;
          case 105:
            return 109;
          case 106:
            return 114;
          case 107:
            return 116;
          case 108:
            return this.popState(), 62;
          case 109:
            return this.pushState("text"), 62;
          case 110:
            return this.popState(), 51;
          case 111:
            return this.pushState("text"), 50;
          case 112:
            return this.popState(), 31;
          case 113:
            return this.pushState("text"), 29;
          case 114:
            return this.popState(), 66;
          case 115:
            return this.pushState("text"), 65;
          case 116:
            return "TEXT";
          case 117:
            return "QUOTE";
          case 118:
            return 9;
          case 119:
            return 10;
          case 120:
            return 11;
        }
      }, "anonymous"),
      rules: [/^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:@\{)/, /^(?:["])/, /^(?:["])/, /^(?:[^\"]+)/, /^(?:[^}^"]+)/, /^(?:\})/, /^(?:call[\s]+)/, /^(?:\([\s]*\))/, /^(?:\()/, /^(?:[^(]*)/, /^(?:\))/, /^(?:[^)]*)/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["][`])/, /^(?:[^"]+)/, /^(?:["])/, /^(?:["])/, /^(?:style\b)/, /^(?:default\b)/, /^(?:linkStyle\b)/, /^(?:interpolate\b)/, /^(?:classDef\b)/, /^(?:class\b)/, /^(?:href[\s])/, /^(?:click[\s]+)/, /^(?:[\s\n])/, /^(?:[^\s\n]*)/, /^(?:flowchart-elk\b)/, /^(?:graph\b)/, /^(?:flowchart\b)/, /^(?:subgraph\b)/, /^(?:end\b\s*)/, /^(?:_self\b)/, /^(?:_blank\b)/, /^(?:_parent\b)/, /^(?:_top\b)/, /^(?:(\r?\n)*\s*\n)/, /^(?:\s*LR\b)/, /^(?:\s*RL\b)/, /^(?:\s*TB\b)/, /^(?:\s*BT\b)/, /^(?:\s*TD\b)/, /^(?:\s*BR\b)/, /^(?:\s*<)/, /^(?:\s*>)/, /^(?:\s*\^)/, /^(?:\s*v\b)/, /^(?:.*direction\s+TB[^\n]*)/, /^(?:.*direction\s+BT[^\n]*)/, /^(?:.*direction\s+RL[^\n]*)/, /^(?:.*direction\s+LR[^\n]*)/, /^(?:.*direction\s+TD[^\n]*)/, /^(?:[^\s\"]+@(?=[^\{\"]))/, /^(?:[0-9]+)/, /^(?:#)/, /^(?::::)/, /^(?::)/, /^(?:&)/, /^(?:;)/, /^(?:,)/, /^(?:\*)/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?--\s*)/, /^(?:[^-]|-(?!-)+)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?==\s*)/, /^(?:[^=]|=(?!))/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?:\s*[xo<]?-\.\s*)/, /^(?:[^\.]|\.(?!))/, /^(?:\s*~~[\~]+\s*)/, /^(?:[-/\)][\)])/, /^(?:[^\(\)\[\]\{\}]|!\)+)/, /^(?:\(-)/, /^(?:\]\))/, /^(?:\(\[)/, /^(?:\]\])/, /^(?:\[\[)/, /^(?:\[\|)/, /^(?:>)/, /^(?:\)\])/, /^(?:\[\()/, /^(?:\)\)\))/, /^(?:\(\(\()/, /^(?:[\\(?=\])][\]])/, /^(?:\/(?=\])\])/, /^(?:\/(?!\])|\\(?!\])|[^\\\[\]\(\)\{\}\/]+)/, /^(?:\[\/)/, /^(?:\[\\)/, /^(?:<)/, /^(?:>)/, /^(?:\^)/, /^(?:\\\|)/, /^(?:v\b)/, /^(?:\*)/, /^(?:#)/, /^(?:&)/, /^(?:([A-Za-z0-9!"\#$%&'*+\.`?\\_\/]|-(?=[^\>\-\.])|(?!))+)/, /^(?:-)/, /^(?:[\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6]|[\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377]|[\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5]|[\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA]|[\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE]|[\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA]|[\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0]|[\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977]|[\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2]|[\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A]|[\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39]|[\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8]|[\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C]|[\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C]|[\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99]|[\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0]|[\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D]|[\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3]|[\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10]|[\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1]|[\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81]|[\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3]|[\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6]|[\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A]|[\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081]|[\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D]|[\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0]|[\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310]|[\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C]|[\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711]|[\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7]|[\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C]|[\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16]|[\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF]|[\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC]|[\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D]|[\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D]|[\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3]|[\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F]|[\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128]|[\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184]|[\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3]|[\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6]|[\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE]|[\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C]|[\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D]|[\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC]|[\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B]|[\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788]|[\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805]|[\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB]|[\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28]|[\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5]|[\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4]|[\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E]|[\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D]|[\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36]|[\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D]|[\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC]|[\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF]|[\uFFD2-\uFFD7\uFFDA-\uFFDC])/, /^(?:\|)/, /^(?:\|)/, /^(?:\))/, /^(?:\()/, /^(?:\])/, /^(?:\[)/, /^(?:(\}))/, /^(?:\{)/, /^(?:[^\[\]\(\)\{\}\|\"]+)/, /^(?:")/, /^(?:(\r?\n)+)/, /^(?:\s)/, /^(?:$)/],
      conditions: { shapeDataEndBracket: { rules: [21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, shapeDataStr: { rules: [9, 10, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, shapeData: { rules: [8, 11, 12, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, callbackargs: { rules: [17, 18, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, callbackname: { rules: [14, 15, 16, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, href: { rules: [21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, click: { rules: [21, 24, 33, 34, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, dottedEdgeText: { rules: [21, 24, 75, 77, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, thickEdgeText: { rules: [21, 24, 72, 74, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, edgeText: { rules: [21, 24, 69, 71, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, trapText: { rules: [21, 24, 78, 81, 83, 85, 89, 91, 92, 93, 94, 95, 96, 109, 111, 113, 115], inclusive: !1 }, ellipseText: { rules: [21, 24, 78, 79, 80, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, text: { rules: [21, 24, 78, 81, 82, 83, 84, 85, 88, 89, 90, 91, 95, 96, 108, 109, 110, 111, 112, 113, 114, 115, 116], inclusive: !1 }, vertex: { rules: [21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, dir: { rules: [21, 24, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, acc_descr_multiline: { rules: [5, 6, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, acc_descr: { rules: [3, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, acc_title: { rules: [1, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, md_string: { rules: [19, 20, 21, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, string: { rules: [21, 22, 23, 24, 78, 81, 83, 85, 89, 91, 95, 96, 109, 111, 113, 115], inclusive: !1 }, INITIAL: { rules: [0, 2, 4, 7, 13, 21, 24, 25, 26, 27, 28, 29, 30, 31, 32, 35, 36, 37, 38, 39, 40, 41, 42, 43, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 72, 73, 75, 76, 78, 81, 83, 85, 86, 87, 89, 91, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109, 111, 113, 115, 117, 118, 119, 120], inclusive: !0 } }
    };
    return g1;
  })();
  Z1.lexer = We;
  function H1() {
    this.yy = {};
  }
  return m(H1, "Parser"), H1.prototype = Z1, Z1.Parser = H1, new H1();
})();
ae.parser = ae;
var Ue = ae, ze = Object.assign({}, Ue);
ze.parse = (s) => {
  const i = s.replace(/}\s*\n/g, `}
`);
  return Ue.parse(i);
};
var Ct = ze, Et = /* @__PURE__ */ m((s, i) => {
  const a = ft, r = a(s, "r"), n = a(s, "g"), l = a(s, "b");
  return ct(r, n, l, i);
}, "fade"), Dt = /* @__PURE__ */ m((s) => `.label {
    font-family: ${s.fontFamily};
    color: ${s.nodeTextColor || s.textColor};
  }
  .cluster-label text {
    fill: ${s.titleColor};
  }
  .cluster-label span {
    color: ${s.titleColor};
  }
  .cluster-label span p {
    background-color: transparent;
  }

  .label text,span {
    fill: ${s.nodeTextColor || s.textColor};
    color: ${s.nodeTextColor || s.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${s.mainBkg};
    stroke: ${s.nodeBorder};
    stroke-width: 1px;
  }
  .rough-node .label text , .node .label text, .image-shape .label, .icon-shape .label {
    text-anchor: middle;
  }
  // .flowchart-label .text-outer-tspan {
  //   text-anchor: middle;
  // }
  // .flowchart-label .text-inner-tspan {
  //   text-anchor: start;
  // }

  .node .katex path {
    fill: #000;
    stroke: #000;
    stroke-width: 1px;
  }

  .rough-node .label,.node .label, .image-shape .label, .icon-shape .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }


  .root .anchor path {
    fill: ${s.lineColor} !important;
    stroke-width: 0;
    stroke: ${s.lineColor};
  }

  .arrowheadPath {
    fill: ${s.arrowheadColor};
  }

  .edgePath .path {
    stroke: ${s.lineColor};
    stroke-width: 2.0px;
  }

  .flowchart-link {
    stroke: ${s.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${s.edgeLabelBackground};
    p {
      background-color: ${s.edgeLabelBackground};
    }
    rect {
      opacity: 0.5;
      background-color: ${s.edgeLabelBackground};
      fill: ${s.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${Et(s.edgeLabelBackground, 0.5)};
    // background-color:
  }

  .cluster rect {
    fill: ${s.clusterBkg};
    stroke: ${s.clusterBorder};
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${s.titleColor};
  }

  .cluster span {
    color: ${s.titleColor};
  }
  /* .cluster div {
    color: ${s.titleColor};
  } */

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${s.fontFamily};
    font-size: 12px;
    background: ${s.tertiaryColor};
    border: 1px solid ${s.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${s.textColor};
  }

  rect.text {
    fill: none;
    stroke-width: 0;
  }

  .icon-shape, .image-shape {
    background-color: ${s.edgeLabelBackground};
    p {
      background-color: ${s.edgeLabelBackground};
      padding: 2px;
    }
    .label rect {
      opacity: 0.5;
      background-color: ${s.edgeLabelBackground};
      fill: ${s.edgeLabelBackground};
    }
    text-align: center;
  }
  ${He()}
`, "getStyles"), Tt = Dt, vt = {
  parser: Ct,
  get db() {
    return new bt();
  },
  renderer: mt,
  styles: Tt,
  init: /* @__PURE__ */ m((s) => {
    s.flowchart || (s.flowchart = {}), s.layout && Me({ layout: s.layout }), s.flowchart.arrowMarkerAbsolute = s.arrowMarkerAbsolute, Me({ flowchart: { arrowMarkerAbsolute: s.arrowMarkerAbsolute } });
  }, "init")
};
export {
  vt as diagram
};
