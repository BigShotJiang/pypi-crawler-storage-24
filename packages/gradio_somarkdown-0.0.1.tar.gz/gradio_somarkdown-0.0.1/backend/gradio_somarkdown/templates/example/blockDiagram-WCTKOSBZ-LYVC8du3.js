import { g as ce } from "./chunk-FMBD7UC4-BE_kxjEu.js";
import { _ as g, G as at, d as T, e as oe, l as S, z as he, B as ge, ai as de, R as ue, S as pe, c as R, O as fe, aj as F, ak as St, al as $, am as xe, u as tt, k as ye, an as be, i as Nt, ao as It, ap as we } from "./mermaid.core-CbLi0pBF.js";
import { c as me } from "./clone-Cz_0t0gq.js";
import { G as Le } from "./graph-Bp5WMA2a.js";
import { c as Se } from "./channel-pxn14BVk.js";
var yt = (function() {
  var e = /* @__PURE__ */ g(function(D, w, d, y) {
    for (d = d || {}, y = D.length; y--; d[D[y]] = w) ;
    return d;
  }, "o"), t = [1, 15], a = [1, 7], i = [1, 13], l = [1, 14], s = [1, 19], r = [1, 16], n = [1, 17], c = [1, 18], x = [8, 30], o = [8, 10, 21, 28, 29, 30, 31, 39, 43, 46], u = [1, 23], b = [1, 24], f = [8, 10, 15, 16, 21, 28, 29, 30, 31, 39, 43, 46], m = [8, 10, 15, 16, 21, 27, 28, 29, 30, 31, 39, 43, 46], v = [1, 49], L = {
    trace: /* @__PURE__ */ g(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, spaceLines: 3, SPACELINE: 4, NL: 5, separator: 6, SPACE: 7, EOF: 8, start: 9, BLOCK_DIAGRAM_KEY: 10, document: 11, stop: 12, statement: 13, link: 14, LINK: 15, START_LINK: 16, LINK_LABEL: 17, STR: 18, nodeStatement: 19, columnsStatement: 20, SPACE_BLOCK: 21, blockStatement: 22, classDefStatement: 23, cssClassStatement: 24, styleStatement: 25, node: 26, SIZE: 27, COLUMNS: 28, "id-block": 29, end: 30, NODE_ID: 31, nodeShapeNLabel: 32, dirList: 33, DIR: 34, NODE_DSTART: 35, NODE_DEND: 36, BLOCK_ARROW_START: 37, BLOCK_ARROW_END: 38, classDef: 39, CLASSDEF_ID: 40, CLASSDEF_STYLEOPTS: 41, DEFAULT: 42, class: 43, CLASSENTITY_IDS: 44, STYLECLASS: 45, style: 46, STYLE_ENTITY_IDS: 47, STYLE_DEFINITION_DATA: 48, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "SPACELINE", 5: "NL", 7: "SPACE", 8: "EOF", 10: "BLOCK_DIAGRAM_KEY", 15: "LINK", 16: "START_LINK", 17: "LINK_LABEL", 18: "STR", 21: "SPACE_BLOCK", 27: "SIZE", 28: "COLUMNS", 29: "id-block", 30: "end", 31: "NODE_ID", 34: "DIR", 35: "NODE_DSTART", 36: "NODE_DEND", 37: "BLOCK_ARROW_START", 38: "BLOCK_ARROW_END", 39: "classDef", 40: "CLASSDEF_ID", 41: "CLASSDEF_STYLEOPTS", 42: "DEFAULT", 43: "class", 44: "CLASSENTITY_IDS", 45: "STYLECLASS", 46: "style", 47: "STYLE_ENTITY_IDS", 48: "STYLE_DEFINITION_DATA" },
    productions_: [0, [3, 1], [3, 2], [3, 2], [6, 1], [6, 1], [6, 1], [9, 3], [12, 1], [12, 1], [12, 2], [12, 2], [11, 1], [11, 2], [14, 1], [14, 4], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [19, 3], [19, 2], [19, 1], [20, 1], [22, 4], [22, 3], [26, 1], [26, 2], [33, 1], [33, 2], [32, 3], [32, 4], [23, 3], [23, 3], [24, 3], [25, 3]],
    performAction: /* @__PURE__ */ g(function(w, d, y, k, E, h, W) {
      var p = h.length - 1;
      switch (E) {
        case 4:
          k.getLogger().debug("Rule: separator (NL) ");
          break;
        case 5:
          k.getLogger().debug("Rule: separator (Space) ");
          break;
        case 6:
          k.getLogger().debug("Rule: separator (EOF) ");
          break;
        case 7:
          k.getLogger().debug("Rule: hierarchy: ", h[p - 1]), k.setHierarchy(h[p - 1]);
          break;
        case 8:
          k.getLogger().debug("Stop NL ");
          break;
        case 9:
          k.getLogger().debug("Stop EOF ");
          break;
        case 10:
          k.getLogger().debug("Stop NL2 ");
          break;
        case 11:
          k.getLogger().debug("Stop EOF2 ");
          break;
        case 12:
          k.getLogger().debug("Rule: statement: ", h[p]), typeof h[p].length == "number" ? this.$ = h[p] : this.$ = [h[p]];
          break;
        case 13:
          k.getLogger().debug("Rule: statement #2: ", h[p - 1]), this.$ = [h[p - 1]].concat(h[p]);
          break;
        case 14:
          k.getLogger().debug("Rule: link: ", h[p], w), this.$ = { edgeTypeStr: h[p], label: "" };
          break;
        case 15:
          k.getLogger().debug("Rule: LABEL link: ", h[p - 3], h[p - 1], h[p]), this.$ = { edgeTypeStr: h[p], label: h[p - 1] };
          break;
        case 18:
          const O = parseInt(h[p]), Z = k.generateId();
          this.$ = { id: Z, type: "space", label: "", width: O, children: [] };
          break;
        case 23:
          k.getLogger().debug("Rule: (nodeStatement link node) ", h[p - 2], h[p - 1], h[p], " typestr: ", h[p - 1].edgeTypeStr);
          const V = k.edgeStrToEdgeData(h[p - 1].edgeTypeStr);
          this.$ = [
            { id: h[p - 2].id, label: h[p - 2].label, type: h[p - 2].type, directions: h[p - 2].directions },
            { id: h[p - 2].id + "-" + h[p].id, start: h[p - 2].id, end: h[p].id, label: h[p - 1].label, type: "edge", directions: h[p].directions, arrowTypeEnd: V, arrowTypeStart: "arrow_open" },
            { id: h[p].id, label: h[p].label, type: k.typeStr2Type(h[p].typeStr), directions: h[p].directions }
          ];
          break;
        case 24:
          k.getLogger().debug("Rule: nodeStatement (abc88 node size) ", h[p - 1], h[p]), this.$ = { id: h[p - 1].id, label: h[p - 1].label, type: k.typeStr2Type(h[p - 1].typeStr), directions: h[p - 1].directions, widthInColumns: parseInt(h[p], 10) };
          break;
        case 25:
          k.getLogger().debug("Rule: nodeStatement (node) ", h[p]), this.$ = { id: h[p].id, label: h[p].label, type: k.typeStr2Type(h[p].typeStr), directions: h[p].directions, widthInColumns: 1 };
          break;
        case 26:
          k.getLogger().debug("APA123", this ? this : "na"), k.getLogger().debug("COLUMNS: ", h[p]), this.$ = { type: "column-setting", columns: h[p] === "auto" ? -1 : parseInt(h[p]) };
          break;
        case 27:
          k.getLogger().debug("Rule: id-block statement : ", h[p - 2], h[p - 1]), k.generateId(), this.$ = { ...h[p - 2], type: "composite", children: h[p - 1] };
          break;
        case 28:
          k.getLogger().debug("Rule: blockStatement : ", h[p - 2], h[p - 1], h[p]);
          const st = k.generateId();
          this.$ = { id: st, type: "composite", label: "", children: h[p - 1] };
          break;
        case 29:
          k.getLogger().debug("Rule: node (NODE_ID separator): ", h[p]), this.$ = { id: h[p] };
          break;
        case 30:
          k.getLogger().debug("Rule: node (NODE_ID nodeShapeNLabel separator): ", h[p - 1], h[p]), this.$ = { id: h[p - 1], label: h[p].label, typeStr: h[p].typeStr, directions: h[p].directions };
          break;
        case 31:
          k.getLogger().debug("Rule: dirList: ", h[p]), this.$ = [h[p]];
          break;
        case 32:
          k.getLogger().debug("Rule: dirList: ", h[p - 1], h[p]), this.$ = [h[p - 1]].concat(h[p]);
          break;
        case 33:
          k.getLogger().debug("Rule: nodeShapeNLabel: ", h[p - 2], h[p - 1], h[p]), this.$ = { typeStr: h[p - 2] + h[p], label: h[p - 1] };
          break;
        case 34:
          k.getLogger().debug("Rule: BLOCK_ARROW nodeShapeNLabel: ", h[p - 3], h[p - 2], " #3:", h[p - 1], h[p]), this.$ = { typeStr: h[p - 3] + h[p], label: h[p - 2], directions: h[p - 1] };
          break;
        case 35:
        case 36:
          this.$ = { type: "classDef", id: h[p - 1].trim(), css: h[p].trim() };
          break;
        case 37:
          this.$ = { type: "applyClass", id: h[p - 1].trim(), styleClass: h[p].trim() };
          break;
        case 38:
          this.$ = { type: "applyStyles", id: h[p - 1].trim(), stylesStr: h[p].trim() };
          break;
      }
    }, "anonymous"),
    table: [{ 9: 1, 10: [1, 2] }, { 1: [3] }, { 10: t, 11: 3, 13: 4, 19: 5, 20: 6, 21: a, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: i, 29: l, 31: s, 39: r, 43: n, 46: c }, { 8: [1, 20] }, e(x, [2, 12], { 13: 4, 19: 5, 20: 6, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 11: 21, 10: t, 21: a, 28: i, 29: l, 31: s, 39: r, 43: n, 46: c }), e(o, [2, 16], { 14: 22, 15: u, 16: b }), e(o, [2, 17]), e(o, [2, 18]), e(o, [2, 19]), e(o, [2, 20]), e(o, [2, 21]), e(o, [2, 22]), e(f, [2, 25], { 27: [1, 25] }), e(o, [2, 26]), { 19: 26, 26: 12, 31: s }, { 10: t, 11: 27, 13: 4, 19: 5, 20: 6, 21: a, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: i, 29: l, 31: s, 39: r, 43: n, 46: c }, { 40: [1, 28], 42: [1, 29] }, { 44: [1, 30] }, { 47: [1, 31] }, e(m, [2, 29], { 32: 32, 35: [1, 33], 37: [1, 34] }), { 1: [2, 7] }, e(x, [2, 13]), { 26: 35, 31: s }, { 31: [2, 14] }, { 17: [1, 36] }, e(f, [2, 24]), { 10: t, 11: 37, 13: 4, 14: 22, 15: u, 16: b, 19: 5, 20: 6, 21: a, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: i, 29: l, 31: s, 39: r, 43: n, 46: c }, { 30: [1, 38] }, { 41: [1, 39] }, { 41: [1, 40] }, { 45: [1, 41] }, { 48: [1, 42] }, e(m, [2, 30]), { 18: [1, 43] }, { 18: [1, 44] }, e(f, [2, 23]), { 18: [1, 45] }, { 30: [1, 46] }, e(o, [2, 28]), e(o, [2, 35]), e(o, [2, 36]), e(o, [2, 37]), e(o, [2, 38]), { 36: [1, 47] }, { 33: 48, 34: v }, { 15: [1, 50] }, e(o, [2, 27]), e(m, [2, 33]), { 38: [1, 51] }, { 33: 52, 34: v, 38: [2, 31] }, { 31: [2, 15] }, e(m, [2, 34]), { 38: [2, 32] }],
    defaultActions: { 20: [2, 7], 23: [2, 14], 50: [2, 15], 52: [2, 32] },
    parseError: /* @__PURE__ */ g(function(w, d) {
      if (d.recoverable)
        this.trace(w);
      else {
        var y = new Error(w);
        throw y.hash = d, y;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ g(function(w) {
      var d = this, y = [0], k = [], E = [null], h = [], W = this.table, p = "", O = 0, Z = 0, V = 2, st = 1, ie = h.slice.call(arguments, 1), z = Object.create(this.lexer), q = { yy: {} };
      for (var dt in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, dt) && (q.yy[dt] = this.yy[dt]);
      z.setInput(w, q.yy), q.yy.lexer = z, q.yy.parser = this, typeof z.yylloc > "u" && (z.yylloc = {});
      var ut = z.yylloc;
      h.push(ut);
      var ne = z.options && z.options.ranges;
      typeof q.yy.parseError == "function" ? this.parseError = q.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function le(Y) {
        y.length = y.length - 2 * Y, E.length = E.length - Y, h.length = h.length - Y;
      }
      g(le, "popStack");
      function Tt() {
        var Y;
        return Y = k.pop() || z.lex() || st, typeof Y != "number" && (Y instanceof Array && (k = Y, Y = k.pop()), Y = d.symbols_[Y] || Y), Y;
      }
      g(Tt, "lex");
      for (var P, J, K, pt, Q = {}, it, G, Bt, nt; ; ) {
        if (J = y[y.length - 1], this.defaultActions[J] ? K = this.defaultActions[J] : ((P === null || typeof P > "u") && (P = Tt()), K = W[J] && W[J][P]), typeof K > "u" || !K.length || !K[0]) {
          var ft = "";
          nt = [];
          for (it in W[J])
            this.terminals_[it] && it > V && nt.push("'" + this.terminals_[it] + "'");
          z.showPosition ? ft = "Parse error on line " + (O + 1) + `:
` + z.showPosition() + `
Expecting ` + nt.join(", ") + ", got '" + (this.terminals_[P] || P) + "'" : ft = "Parse error on line " + (O + 1) + ": Unexpected " + (P == st ? "end of input" : "'" + (this.terminals_[P] || P) + "'"), this.parseError(ft, {
            text: z.match,
            token: this.terminals_[P] || P,
            line: z.yylineno,
            loc: ut,
            expected: nt
          });
        }
        if (K[0] instanceof Array && K.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + J + ", token: " + P);
        switch (K[0]) {
          case 1:
            y.push(P), E.push(z.yytext), h.push(z.yylloc), y.push(K[1]), P = null, Z = z.yyleng, p = z.yytext, O = z.yylineno, ut = z.yylloc;
            break;
          case 2:
            if (G = this.productions_[K[1]][1], Q.$ = E[E.length - G], Q._$ = {
              first_line: h[h.length - (G || 1)].first_line,
              last_line: h[h.length - 1].last_line,
              first_column: h[h.length - (G || 1)].first_column,
              last_column: h[h.length - 1].last_column
            }, ne && (Q._$.range = [
              h[h.length - (G || 1)].range[0],
              h[h.length - 1].range[1]
            ]), pt = this.performAction.apply(Q, [
              p,
              Z,
              O,
              q.yy,
              K[1],
              E,
              h
            ].concat(ie)), typeof pt < "u")
              return pt;
            G && (y = y.slice(0, -1 * G * 2), E = E.slice(0, -1 * G), h = h.slice(0, -1 * G)), y.push(this.productions_[K[1]][0]), E.push(Q.$), h.push(Q._$), Bt = W[y[y.length - 2]][y[y.length - 1]], y.push(Bt);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, _ = /* @__PURE__ */ (function() {
    var D = {
      EOF: 1,
      parseError: /* @__PURE__ */ g(function(d, y) {
        if (this.yy.parser)
          this.yy.parser.parseError(d, y);
        else
          throw new Error(d);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ g(function(w, d) {
        return this.yy = d || this.yy || {}, this._input = w, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ g(function() {
        var w = this._input[0];
        this.yytext += w, this.yyleng++, this.offset++, this.match += w, this.matched += w;
        var d = w.match(/(?:\r\n?|\n).*/g);
        return d ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), w;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ g(function(w) {
        var d = w.length, y = w.split(/(?:\r\n?|\n)/g);
        this._input = w + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - d), this.offset -= d;
        var k = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), y.length - 1 && (this.yylineno -= y.length - 1);
        var E = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: y ? (y.length === k.length ? this.yylloc.first_column : 0) + k[k.length - y.length].length - y[0].length : this.yylloc.first_column - d
        }, this.options.ranges && (this.yylloc.range = [E[0], E[0] + this.yyleng - d]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ g(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ g(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ g(function(w) {
        this.unput(this.match.slice(w));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ g(function() {
        var w = this.matched.substr(0, this.matched.length - this.match.length);
        return (w.length > 20 ? "..." : "") + w.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ g(function() {
        var w = this.match;
        return w.length < 20 && (w += this._input.substr(0, 20 - w.length)), (w.substr(0, 20) + (w.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ g(function() {
        var w = this.pastInput(), d = new Array(w.length + 1).join("-");
        return w + this.upcomingInput() + `
` + d + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ g(function(w, d) {
        var y, k, E;
        if (this.options.backtrack_lexer && (E = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (E.yylloc.range = this.yylloc.range.slice(0))), k = w[0].match(/(?:\r\n?|\n).*/g), k && (this.yylineno += k.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: k ? k[k.length - 1].length - k[k.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + w[0].length
        }, this.yytext += w[0], this.match += w[0], this.matches = w, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(w[0].length), this.matched += w[0], y = this.performAction.call(this, this.yy, this, d, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), y)
          return y;
        if (this._backtrack) {
          for (var h in E)
            this[h] = E[h];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ g(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var w, d, y, k;
        this._more || (this.yytext = "", this.match = "");
        for (var E = this._currentRules(), h = 0; h < E.length; h++)
          if (y = this._input.match(this.rules[E[h]]), y && (!d || y[0].length > d[0].length)) {
            if (d = y, k = h, this.options.backtrack_lexer) {
              if (w = this.test_match(y, E[h]), w !== !1)
                return w;
              if (this._backtrack) {
                d = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return d ? (w = this.test_match(d, E[k]), w !== !1 ? w : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ g(function() {
        var d = this.next();
        return d || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ g(function(d) {
        this.conditionStack.push(d);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ g(function() {
        var d = this.conditionStack.length - 1;
        return d > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ g(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ g(function(d) {
        return d = this.conditionStack.length - 1 - Math.abs(d || 0), d >= 0 ? this.conditionStack[d] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ g(function(d) {
        this.begin(d);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ g(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: {},
      performAction: /* @__PURE__ */ g(function(d, y, k, E) {
        switch (k) {
          case 0:
            return d.getLogger().debug("Found block-beta"), 10;
          case 1:
            return d.getLogger().debug("Found id-block"), 29;
          case 2:
            return d.getLogger().debug("Found block"), 10;
          case 3:
            d.getLogger().debug(".", y.yytext);
            break;
          case 4:
            d.getLogger().debug("_", y.yytext);
            break;
          case 5:
            return 5;
          case 6:
            return y.yytext = -1, 28;
          case 7:
            return y.yytext = y.yytext.replace(/columns\s+/, ""), d.getLogger().debug("COLUMNS (LEX)", y.yytext), 28;
          case 8:
            this.pushState("md_string");
            break;
          case 9:
            return "MD_STR";
          case 10:
            this.popState();
            break;
          case 11:
            this.pushState("string");
            break;
          case 12:
            d.getLogger().debug("LEX: POPPING STR:", y.yytext), this.popState();
            break;
          case 13:
            return d.getLogger().debug("LEX: STR end:", y.yytext), "STR";
          case 14:
            return y.yytext = y.yytext.replace(/space\:/, ""), d.getLogger().debug("SPACE NUM (LEX)", y.yytext), 21;
          case 15:
            return y.yytext = "1", d.getLogger().debug("COLUMNS (LEX)", y.yytext), 21;
          case 16:
            return 42;
          case 17:
            return "LINKSTYLE";
          case 18:
            return "INTERPOLATE";
          case 19:
            return this.pushState("CLASSDEF"), 39;
          case 20:
            return this.popState(), this.pushState("CLASSDEFID"), "DEFAULT_CLASSDEF_ID";
          case 21:
            return this.popState(), this.pushState("CLASSDEFID"), 40;
          case 22:
            return this.popState(), 41;
          case 23:
            return this.pushState("CLASS"), 43;
          case 24:
            return this.popState(), this.pushState("CLASS_STYLE"), 44;
          case 25:
            return this.popState(), 45;
          case 26:
            return this.pushState("STYLE_STMNT"), 46;
          case 27:
            return this.popState(), this.pushState("STYLE_DEFINITION"), 47;
          case 28:
            return this.popState(), 48;
          case 29:
            return this.pushState("acc_title"), "acc_title";
          case 30:
            return this.popState(), "acc_title_value";
          case 31:
            return this.pushState("acc_descr"), "acc_descr";
          case 32:
            return this.popState(), "acc_descr_value";
          case 33:
            this.pushState("acc_descr_multiline");
            break;
          case 34:
            this.popState();
            break;
          case 35:
            return "acc_descr_multiline_value";
          case 36:
            return 30;
          case 37:
            return this.popState(), d.getLogger().debug("Lex: (("), "NODE_DEND";
          case 38:
            return this.popState(), d.getLogger().debug("Lex: (("), "NODE_DEND";
          case 39:
            return this.popState(), d.getLogger().debug("Lex: ))"), "NODE_DEND";
          case 40:
            return this.popState(), d.getLogger().debug("Lex: (("), "NODE_DEND";
          case 41:
            return this.popState(), d.getLogger().debug("Lex: (("), "NODE_DEND";
          case 42:
            return this.popState(), d.getLogger().debug("Lex: (-"), "NODE_DEND";
          case 43:
            return this.popState(), d.getLogger().debug("Lex: -)"), "NODE_DEND";
          case 44:
            return this.popState(), d.getLogger().debug("Lex: (("), "NODE_DEND";
          case 45:
            return this.popState(), d.getLogger().debug("Lex: ]]"), "NODE_DEND";
          case 46:
            return this.popState(), d.getLogger().debug("Lex: ("), "NODE_DEND";
          case 47:
            return this.popState(), d.getLogger().debug("Lex: ])"), "NODE_DEND";
          case 48:
            return this.popState(), d.getLogger().debug("Lex: /]"), "NODE_DEND";
          case 49:
            return this.popState(), d.getLogger().debug("Lex: /]"), "NODE_DEND";
          case 50:
            return this.popState(), d.getLogger().debug("Lex: )]"), "NODE_DEND";
          case 51:
            return this.popState(), d.getLogger().debug("Lex: )"), "NODE_DEND";
          case 52:
            return this.popState(), d.getLogger().debug("Lex: ]>"), "NODE_DEND";
          case 53:
            return this.popState(), d.getLogger().debug("Lex: ]"), "NODE_DEND";
          case 54:
            return d.getLogger().debug("Lexa: -)"), this.pushState("NODE"), 35;
          case 55:
            return d.getLogger().debug("Lexa: (-"), this.pushState("NODE"), 35;
          case 56:
            return d.getLogger().debug("Lexa: ))"), this.pushState("NODE"), 35;
          case 57:
            return d.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 58:
            return d.getLogger().debug("Lex: ((("), this.pushState("NODE"), 35;
          case 59:
            return d.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 60:
            return d.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 61:
            return d.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 62:
            return d.getLogger().debug("Lexc: >"), this.pushState("NODE"), 35;
          case 63:
            return d.getLogger().debug("Lexa: (["), this.pushState("NODE"), 35;
          case 64:
            return d.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
          case 65:
            return this.pushState("NODE"), 35;
          case 66:
            return this.pushState("NODE"), 35;
          case 67:
            return this.pushState("NODE"), 35;
          case 68:
            return this.pushState("NODE"), 35;
          case 69:
            return this.pushState("NODE"), 35;
          case 70:
            return this.pushState("NODE"), 35;
          case 71:
            return this.pushState("NODE"), 35;
          case 72:
            return d.getLogger().debug("Lexa: ["), this.pushState("NODE"), 35;
          case 73:
            return this.pushState("BLOCK_ARROW"), d.getLogger().debug("LEX ARR START"), 37;
          case 74:
            return d.getLogger().debug("Lex: NODE_ID", y.yytext), 31;
          case 75:
            return d.getLogger().debug("Lex: EOF", y.yytext), 8;
          case 76:
            this.pushState("md_string");
            break;
          case 77:
            this.pushState("md_string");
            break;
          case 78:
            return "NODE_DESCR";
          case 79:
            this.popState();
            break;
          case 80:
            d.getLogger().debug("Lex: Starting string"), this.pushState("string");
            break;
          case 81:
            d.getLogger().debug("LEX ARR: Starting string"), this.pushState("string");
            break;
          case 82:
            return d.getLogger().debug("LEX: NODE_DESCR:", y.yytext), "NODE_DESCR";
          case 83:
            d.getLogger().debug("LEX POPPING"), this.popState();
            break;
          case 84:
            d.getLogger().debug("Lex: =>BAE"), this.pushState("ARROW_DIR");
            break;
          case 85:
            return y.yytext = y.yytext.replace(/^,\s*/, ""), d.getLogger().debug("Lex (right): dir:", y.yytext), "DIR";
          case 86:
            return y.yytext = y.yytext.replace(/^,\s*/, ""), d.getLogger().debug("Lex (left):", y.yytext), "DIR";
          case 87:
            return y.yytext = y.yytext.replace(/^,\s*/, ""), d.getLogger().debug("Lex (x):", y.yytext), "DIR";
          case 88:
            return y.yytext = y.yytext.replace(/^,\s*/, ""), d.getLogger().debug("Lex (y):", y.yytext), "DIR";
          case 89:
            return y.yytext = y.yytext.replace(/^,\s*/, ""), d.getLogger().debug("Lex (up):", y.yytext), "DIR";
          case 90:
            return y.yytext = y.yytext.replace(/^,\s*/, ""), d.getLogger().debug("Lex (down):", y.yytext), "DIR";
          case 91:
            return y.yytext = "]>", d.getLogger().debug("Lex (ARROW_DIR end):", y.yytext), this.popState(), this.popState(), "BLOCK_ARROW_END";
          case 92:
            return d.getLogger().debug("Lex: LINK", "#" + y.yytext + "#"), 15;
          case 93:
            return d.getLogger().debug("Lex: LINK", y.yytext), 15;
          case 94:
            return d.getLogger().debug("Lex: LINK", y.yytext), 15;
          case 95:
            return d.getLogger().debug("Lex: LINK", y.yytext), 15;
          case 96:
            return d.getLogger().debug("Lex: START_LINK", y.yytext), this.pushState("LLABEL"), 16;
          case 97:
            return d.getLogger().debug("Lex: START_LINK", y.yytext), this.pushState("LLABEL"), 16;
          case 98:
            return d.getLogger().debug("Lex: START_LINK", y.yytext), this.pushState("LLABEL"), 16;
          case 99:
            this.pushState("md_string");
            break;
          case 100:
            return d.getLogger().debug("Lex: Starting string"), this.pushState("string"), "LINK_LABEL";
          case 101:
            return this.popState(), d.getLogger().debug("Lex: LINK", "#" + y.yytext + "#"), 15;
          case 102:
            return this.popState(), d.getLogger().debug("Lex: LINK", y.yytext), 15;
          case 103:
            return this.popState(), d.getLogger().debug("Lex: LINK", y.yytext), 15;
          case 104:
            return d.getLogger().debug("Lex: COLON", y.yytext), y.yytext = y.yytext.slice(1), 27;
        }
      }, "anonymous"),
      rules: [/^(?:block-beta\b)/, /^(?:block:)/, /^(?:block\b)/, /^(?:[\s]+)/, /^(?:[\n]+)/, /^(?:((\u000D\u000A)|(\u000A)))/, /^(?:columns\s+auto\b)/, /^(?:columns\s+[\d]+)/, /^(?:["][`])/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["])/, /^(?:["])/, /^(?:[^"]*)/, /^(?:space[:]\d+)/, /^(?:space\b)/, /^(?:default\b)/, /^(?:linkStyle\b)/, /^(?:interpolate\b)/, /^(?:classDef\s+)/, /^(?:DEFAULT\s+)/, /^(?:\w+\s+)/, /^(?:[^\n]*)/, /^(?:class\s+)/, /^(?:(\w+)+((,\s*\w+)*))/, /^(?:[^\n]*)/, /^(?:style\s+)/, /^(?:(\w+)+((,\s*\w+)*))/, /^(?:[^\n]*)/, /^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:end\b\s*)/, /^(?:\(\(\()/, /^(?:\)\)\))/, /^(?:[\)]\))/, /^(?:\}\})/, /^(?:\})/, /^(?:\(-)/, /^(?:-\))/, /^(?:\(\()/, /^(?:\]\])/, /^(?:\()/, /^(?:\]\))/, /^(?:\\\])/, /^(?:\/\])/, /^(?:\)\])/, /^(?:[\)])/, /^(?:\]>)/, /^(?:[\]])/, /^(?:-\))/, /^(?:\(-)/, /^(?:\)\))/, /^(?:\))/, /^(?:\(\(\()/, /^(?:\(\()/, /^(?:\{\{)/, /^(?:\{)/, /^(?:>)/, /^(?:\(\[)/, /^(?:\()/, /^(?:\[\[)/, /^(?:\[\|)/, /^(?:\[\()/, /^(?:\)\)\))/, /^(?:\[\\)/, /^(?:\[\/)/, /^(?:\[\\)/, /^(?:\[)/, /^(?:<\[)/, /^(?:[^\(\[\n\-\)\{\}\s\<\>:]+)/, /^(?:$)/, /^(?:["][`])/, /^(?:["][`])/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["])/, /^(?:["])/, /^(?:[^"]+)/, /^(?:["])/, /^(?:\]>\s*\()/, /^(?:,?\s*right\s*)/, /^(?:,?\s*left\s*)/, /^(?:,?\s*x\s*)/, /^(?:,?\s*y\s*)/, /^(?:,?\s*up\s*)/, /^(?:,?\s*down\s*)/, /^(?:\)\s*)/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?:\s*~~[\~]+\s*)/, /^(?:\s*[xo<]?--\s*)/, /^(?:\s*[xo<]?==\s*)/, /^(?:\s*[xo<]?-\.\s*)/, /^(?:["][`])/, /^(?:["])/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?::\d+)/],
      conditions: { STYLE_DEFINITION: { rules: [28], inclusive: !1 }, STYLE_STMNT: { rules: [27], inclusive: !1 }, CLASSDEFID: { rules: [22], inclusive: !1 }, CLASSDEF: { rules: [20, 21], inclusive: !1 }, CLASS_STYLE: { rules: [25], inclusive: !1 }, CLASS: { rules: [24], inclusive: !1 }, LLABEL: { rules: [99, 100, 101, 102, 103], inclusive: !1 }, ARROW_DIR: { rules: [85, 86, 87, 88, 89, 90, 91], inclusive: !1 }, BLOCK_ARROW: { rules: [76, 81, 84], inclusive: !1 }, NODE: { rules: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 77, 80], inclusive: !1 }, md_string: { rules: [9, 10, 78, 79], inclusive: !1 }, space: { rules: [], inclusive: !1 }, string: { rules: [12, 13, 82, 83], inclusive: !1 }, acc_descr_multiline: { rules: [34, 35], inclusive: !1 }, acc_descr: { rules: [32], inclusive: !1 }, acc_title: { rules: [30], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 14, 15, 16, 17, 18, 19, 23, 26, 29, 31, 33, 36, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 92, 93, 94, 95, 96, 97, 98, 104], inclusive: !0 } }
    };
    return D;
  })();
  L.lexer = _;
  function I() {
    this.yy = {};
  }
  return g(I, "Parser"), I.prototype = L, L.Parser = I, new I();
})();
yt.parser = yt;
var ke = yt, X = /* @__PURE__ */ new Map(), kt = [], bt = /* @__PURE__ */ new Map(), Ct = "color", Ot = "fill", ve = "bgFill", Yt = ",", Ee = R(), ct = /* @__PURE__ */ new Map(), _e = /* @__PURE__ */ g((e) => ye.sanitizeText(e, Ee), "sanitizeText"), De = /* @__PURE__ */ g(function(e, t = "") {
  let a = ct.get(e);
  a || (a = { id: e, styles: [], textStyles: [] }, ct.set(e, a)), t?.split(Yt).forEach((i) => {
    const l = i.replace(/([^;]*);/, "$1").trim();
    if (RegExp(Ct).exec(i)) {
      const r = l.replace(Ot, ve).replace(Ct, Ot);
      a.textStyles.push(r);
    }
    a.styles.push(l);
  });
}, "addStyleClass"), Te = /* @__PURE__ */ g(function(e, t = "") {
  const a = X.get(e);
  t != null && (a.styles = t.split(Yt));
}, "addStyle2Node"), Be = /* @__PURE__ */ g(function(e, t) {
  e.split(",").forEach(function(a) {
    let i = X.get(a);
    if (i === void 0) {
      const l = a.trim();
      i = { id: l, type: "na", children: [] }, X.set(l, i);
    }
    i.classes || (i.classes = []), i.classes.push(t);
  });
}, "setCssClass"), Ht = /* @__PURE__ */ g((e, t) => {
  const a = e.flat(), i = [], s = a.find((r) => r?.type === "column-setting")?.columns ?? -1;
  for (const r of a) {
    if (typeof s == "number" && s > 0 && r.type !== "column-setting" && typeof r.widthInColumns == "number" && r.widthInColumns > s && S.warn(
      `Block ${r.id} width ${r.widthInColumns} exceeds configured column width ${s}`
    ), r.label && (r.label = _e(r.label)), r.type === "classDef") {
      De(r.id, r.css);
      continue;
    }
    if (r.type === "applyClass") {
      Be(r.id, r?.styleClass ?? "");
      continue;
    }
    if (r.type === "applyStyles") {
      r?.stylesStr && Te(r.id, r?.stylesStr);
      continue;
    }
    if (r.type === "column-setting")
      t.columns = r.columns ?? -1;
    else if (r.type === "edge") {
      const n = (bt.get(r.id) ?? 0) + 1;
      bt.set(r.id, n), r.id = n + "-" + r.id, kt.push(r);
    } else {
      r.label || (r.type === "composite" ? r.label = "" : r.label = r.id);
      const n = X.get(r.id);
      if (n === void 0 ? X.set(r.id, r) : (r.type !== "na" && (n.type = r.type), r.label !== r.id && (n.label = r.label)), r.children && Ht(r.children, r), r.type === "space") {
        const c = r.width ?? 1;
        for (let x = 0; x < c; x++) {
          const o = me(r);
          o.id = o.id + "-" + x, X.set(o.id, o), i.push(o);
        }
      } else n === void 0 && i.push(r);
    }
  }
  t.children = i;
}, "populateBlockDatabase"), vt = [], rt = { id: "root", type: "composite", children: [], columns: -1 }, Ne = /* @__PURE__ */ g(() => {
  S.debug("Clear called"), he(), rt = { id: "root", type: "composite", children: [], columns: -1 }, X = /* @__PURE__ */ new Map([["root", rt]]), vt = [], ct = /* @__PURE__ */ new Map(), kt = [], bt = /* @__PURE__ */ new Map();
}, "clear");
function Kt(e) {
  switch (S.debug("typeStr2Type", e), e) {
    case "[]":
      return "square";
    case "()":
      return S.debug("we have a round"), "round";
    case "(())":
      return "circle";
    case ">]":
      return "rect_left_inv_arrow";
    case "{}":
      return "diamond";
    case "{{}}":
      return "hexagon";
    case "([])":
      return "stadium";
    case "[[]]":
      return "subroutine";
    case "[()]":
      return "cylinder";
    case "((()))":
      return "doublecircle";
    case "[//]":
      return "lean_right";
    case "[\\\\]":
      return "lean_left";
    case "[/\\]":
      return "trapezoid";
    case "[\\/]":
      return "inv_trapezoid";
    case "<[]>":
      return "block_arrow";
    default:
      return "na";
  }
}
g(Kt, "typeStr2Type");
function Ut(e) {
  return S.debug("typeStr2Type", e), e === "==" ? "thick" : "normal";
}
g(Ut, "edgeTypeStr2Type");
function Xt(e) {
  switch (e.replace(/^[\s-]+|[\s-]+$/g, "")) {
    case "x":
      return "arrow_cross";
    case "o":
      return "arrow_circle";
    case ">":
      return "arrow_point";
    default:
      return "";
  }
}
g(Xt, "edgeStrToEdgeData");
var Rt = 0, Ie = /* @__PURE__ */ g(() => (Rt++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + Rt), "generateId"), Ce = /* @__PURE__ */ g((e) => {
  rt.children = e, Ht(e, rt), vt = rt.children;
}, "setHierarchy"), Oe = /* @__PURE__ */ g((e) => {
  const t = X.get(e);
  return t ? t.columns ? t.columns : t.children ? t.children.length : -1 : -1;
}, "getColumns"), Re = /* @__PURE__ */ g(() => [...X.values()], "getBlocksFlat"), ze = /* @__PURE__ */ g(() => vt || [], "getBlocks"), Ae = /* @__PURE__ */ g(() => kt, "getEdges"), Me = /* @__PURE__ */ g((e) => X.get(e), "getBlock"), Fe = /* @__PURE__ */ g((e) => {
  X.set(e.id, e);
}, "setBlock"), Pe = /* @__PURE__ */ g(() => S, "getLogger"), We = /* @__PURE__ */ g(function() {
  return ct;
}, "getClasses"), Ye = {
  getConfig: /* @__PURE__ */ g(() => at().block, "getConfig"),
  typeStr2Type: Kt,
  edgeTypeStr2Type: Ut,
  edgeStrToEdgeData: Xt,
  getLogger: Pe,
  getBlocksFlat: Re,
  getBlocks: ze,
  getEdges: Ae,
  setHierarchy: Ce,
  getBlock: Me,
  setBlock: Fe,
  getColumns: Oe,
  getClasses: We,
  clear: Ne,
  generateId: Ie
}, He = Ye, xt = /* @__PURE__ */ g((e, t) => {
  const a = Se, i = a(e, "r"), l = a(e, "g"), s = a(e, "b");
  return ge(i, l, s, t);
}, "fade"), Ke = /* @__PURE__ */ g((e) => `.label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }
  .cluster-label text {
    fill: ${e.titleColor};
  }
  .cluster-label span,p {
    color: ${e.titleColor};
  }



  .label text,span,p {
    fill: ${e.nodeTextColor || e.textColor};
    color: ${e.nodeTextColor || e.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
    stroke-width: 1px;
  }
  .flowchart-label text {
    text-anchor: middle;
  }
  // .flowchart-label .text-outer-tspan {
  //   text-anchor: middle;
  // }
  // .flowchart-label .text-inner-tspan {
  //   text-anchor: start;
  // }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${e.arrowheadColor};
  }

  .edgePath .path {
    stroke: ${e.lineColor};
    stroke-width: 2.0px;
  }

  .flowchart-link {
    stroke: ${e.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${e.edgeLabelBackground};
    /*
     * This is for backward compatibility with existing code that didn't
     * add a \`<p>\` around edge labels.
     *
     * TODO: We should probably remove this in a future release.
     */
    p {
      margin: 0;
      padding: 0;
      display: inline;
    }
    rect {
      opacity: 0.5;
      background-color: ${e.edgeLabelBackground};
      fill: ${e.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${e.edgeLabelBackground};
  }

  .node .cluster {
    // fill: ${xt(e.mainBkg, 0.5)};
    fill: ${xt(e.clusterBkg, 0.5)};
    stroke: ${xt(e.clusterBorder, 0.2)};
    box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${e.titleColor};
  }

  .cluster span,p {
    color: ${e.titleColor};
  }
  /* .cluster div {
    color: ${e.titleColor};
  } */

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${e.fontFamily};
    font-size: 12px;
    background: ${e.tertiaryColor};
    border: 1px solid ${e.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${e.textColor};
  }
  ${ce()}
`, "getStyles"), Ue = Ke, Xe = /* @__PURE__ */ g((e, t, a, i) => {
  t.forEach((l) => {
    er[l](e, a, i);
  });
}, "insertMarkers"), je = /* @__PURE__ */ g((e, t, a) => {
  S.trace("Making markers for ", a), e.append("defs").append("marker").attr("id", a + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), Ve = /* @__PURE__ */ g((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), Ge = /* @__PURE__ */ g((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), Ze = /* @__PURE__ */ g((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), qe = /* @__PURE__ */ g((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), Je = /* @__PURE__ */ g((e, t, a) => {
  e.append("marker").attr("id", a + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 6).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", a + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), Qe = /* @__PURE__ */ g((e, t, a) => {
  e.append("marker").attr("id", a + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", a + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), $e = /* @__PURE__ */ g((e, t, a) => {
  e.append("marker").attr("id", a + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", a + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), tr = /* @__PURE__ */ g((e, t, a) => {
  e.append("defs").append("marker").attr("id", a + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "strokeWidth").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), er = {
  extension: je,
  composition: Ve,
  aggregation: Ge,
  dependency: Ze,
  lollipop: qe,
  point: Je,
  circle: Qe,
  cross: $e,
  barb: tr
}, rr = Xe, C = R()?.block?.padding ?? 8;
function wt(e, t) {
  if (e === 0 || !Number.isInteger(e))
    throw new Error("Columns must be an integer !== 0.");
  if (t < 0 || !Number.isInteger(t))
    throw new Error("Position must be a non-negative integer." + t);
  if (e < 0)
    return { px: t, py: 0 };
  if (e === 1)
    return { px: 0, py: t };
  const a = t % e, i = Math.floor(t / e);
  return { px: a, py: i };
}
g(wt, "calculateBlockPosition");
var ar = /* @__PURE__ */ g((e) => {
  let t = 0, a = 0;
  for (const i of e.children) {
    const { width: l, height: s, x: r, y: n } = i.size ?? { width: 0, height: 0, x: 0, y: 0 };
    S.debug(
      "getMaxChildSize abc95 child:",
      i.id,
      "width:",
      l,
      "height:",
      s,
      "x:",
      r,
      "y:",
      n,
      i.type
    ), i.type !== "space" && (l > t && (t = l / (i.widthInColumns ?? 1)), s > a && (a = s));
  }
  return { width: t, height: a };
}, "getMaxChildSize");
function ot(e, t, a = 0, i = 0) {
  S.debug(
    "setBlockSizes abc95 (start)",
    e.id,
    e?.size?.x,
    "block width =",
    e?.size,
    "siblingWidth",
    a
  ), e?.size?.width || (e.size = {
    width: a,
    height: i,
    x: 0,
    y: 0
  });
  let l = 0, s = 0;
  if (e.children?.length > 0) {
    for (const f of e.children)
      ot(f, t);
    const r = ar(e);
    l = r.width, s = r.height, S.debug("setBlockSizes abc95 maxWidth of", e.id, ":s children is ", l, s);
    for (const f of e.children)
      f.size && (S.debug(
        `abc95 Setting size of children of ${e.id} id=${f.id} ${l} ${s} ${JSON.stringify(f.size)}`
      ), f.size.width = l * (f.widthInColumns ?? 1) + C * ((f.widthInColumns ?? 1) - 1), f.size.height = s, f.size.x = 0, f.size.y = 0, S.debug(
        `abc95 updating size of ${e.id} children child:${f.id} maxWidth:${l} maxHeight:${s}`
      ));
    for (const f of e.children)
      ot(f, t, l, s);
    const n = e.columns ?? -1;
    let c = 0;
    for (const f of e.children)
      c += f.widthInColumns ?? 1;
    let x = e.children.length;
    n > 0 && n < c && (x = n);
    const o = Math.ceil(c / x);
    let u = x * (l + C) + C, b = o * (s + C) + C;
    if (u < a) {
      S.debug(
        `Detected to small sibling: abc95 ${e.id} siblingWidth ${a} siblingHeight ${i} width ${u}`
      ), u = a, b = i;
      const f = (a - x * C - C) / x, m = (i - o * C - C) / o;
      S.debug("Size indata abc88", e.id, "childWidth", f, "maxWidth", l), S.debug("Size indata abc88", e.id, "childHeight", m, "maxHeight", s), S.debug("Size indata abc88 xSize", x, "padding", C);
      for (const v of e.children)
        v.size && (v.size.width = f, v.size.height = m, v.size.x = 0, v.size.y = 0);
    }
    if (S.debug(
      `abc95 (finale calc) ${e.id} xSize ${x} ySize ${o} columns ${n}${e.children.length} width=${Math.max(u, e.size?.width || 0)}`
    ), u < (e?.size?.width || 0)) {
      u = e?.size?.width || 0;
      const f = n > 0 ? Math.min(e.children.length, n) : e.children.length;
      if (f > 0) {
        const m = (u - f * C - C) / f;
        S.debug("abc95 (growing to fit) width", e.id, u, e.size?.width, m);
        for (const v of e.children)
          v.size && (v.size.width = m);
      }
    }
    e.size = {
      width: u,
      height: b,
      x: 0,
      y: 0
    };
  }
  S.debug(
    "setBlockSizes abc94 (done)",
    e.id,
    e?.size?.x,
    e?.size?.width,
    e?.size?.y,
    e?.size?.height
  );
}
g(ot, "setBlockSizes");
function Et(e, t) {
  S.debug(
    `abc85 layout blocks (=>layoutBlocks) ${e.id} x: ${e?.size?.x} y: ${e?.size?.y} width: ${e?.size?.width}`
  );
  const a = e.columns ?? -1;
  if (S.debug("layoutBlocks columns abc95", e.id, "=>", a, e), e.children && // find max width of children
  e.children.length > 0) {
    const i = e?.children[0]?.size?.width ?? 0, l = e.children.length * i + (e.children.length - 1) * C;
    S.debug("widthOfChildren 88", l, "posX");
    const s = /* @__PURE__ */ new Map();
    {
      let o = 0;
      for (const u of e.children) {
        if (!u.size)
          continue;
        const { py: b } = wt(a, o), f = s.get(b) ?? 0;
        u.size.height > f && s.set(b, u.size.height);
        let m = u?.widthInColumns ?? 1;
        a > 0 && (m = Math.min(m, a - o % a)), o += m;
      }
    }
    const r = /* @__PURE__ */ new Map();
    {
      let o = 0;
      const u = [...s.keys()].sort((b, f) => b - f);
      for (const b of u)
        r.set(b, o), o += (s.get(b) ?? 0) + C;
    }
    let n = 0;
    S.debug("abc91 block?.size?.x", e.id, e?.size?.x);
    let c = e?.size?.x ? e?.size?.x + (-e?.size?.width / 2 || 0) : -C, x = 0;
    for (const o of e.children) {
      const u = e;
      if (!o.size)
        continue;
      const { width: b, height: f } = o.size, { px: m, py: v } = wt(a, n);
      if (v != x && (x = v, c = e?.size?.x ? e?.size?.x + (-e?.size?.width / 2 || 0) : -C, S.debug("New row in layout for block", e.id, " and child ", o.id, x)), S.debug(
        `abc89 layout blocks (child) id: ${o.id} Pos: ${n} (px, py) ${m},${v} (${u?.size?.x},${u?.size?.y}) parent: ${u.id} width: ${b}${C}`
      ), u.size) {
        const _ = b / 2;
        o.size.x = c + C + _, S.debug(
          `abc91 layout blocks (calc) px, pyid:${o.id} startingPos=X${c} new startingPosX${o.size.x} ${_} padding=${C} width=${b} halfWidth=${_} => x:${o.size.x} y:${o.size.y} ${o.widthInColumns} (width * (child?.w || 1)) / 2 ${b * (o?.widthInColumns ?? 1) / 2}`
        ), c = o.size.x + _;
        const I = r.get(v) ?? 0, D = s.get(v) ?? f;
        o.size.y = u.size.y - u.size.height / 2 + I + D / 2 + C, S.debug(
          `abc88 layout blocks (calc) px, pyid:${o.id}startingPosX${c}${C}${_}=>x:${o.size.x}y:${o.size.y}${o.widthInColumns}(width * (child?.w || 1)) / 2${b * (o?.widthInColumns ?? 1) / 2}`
        );
      }
      o.children && Et(o);
      let L = o?.widthInColumns ?? 1;
      a > 0 && (L = Math.min(L, a - n % a)), n += L, S.debug("abc88 columnsPos", o, n);
    }
  }
  S.debug(
    `layout blocks (<==layoutBlocks) ${e.id} x: ${e?.size?.x} y: ${e?.size?.y} width: ${e?.size?.width}`
  );
}
g(Et, "layoutBlocks");
function _t(e, { minX: t, minY: a, maxX: i, maxY: l } = { minX: 0, minY: 0, maxX: 0, maxY: 0 }) {
  if (e.size && e.id !== "root") {
    const { x: s, y: r, width: n, height: c } = e.size;
    s - n / 2 < t && (t = s - n / 2), r - c / 2 < a && (a = r - c / 2), s + n / 2 > i && (i = s + n / 2), r + c / 2 > l && (l = r + c / 2);
  }
  if (e.children)
    for (const s of e.children)
      ({ minX: t, minY: a, maxX: i, maxY: l } = _t(s, { minX: t, minY: a, maxX: i, maxY: l }));
  return { minX: t, minY: a, maxX: i, maxY: l };
}
g(_t, "findBounds");
function jt(e) {
  const t = e.getBlock("root");
  if (!t)
    return;
  ot(t, e, 0, 0), Et(t), S.debug("getBlocks", JSON.stringify(t, null, 2));
  const { minX: a, minY: i, maxX: l, maxY: s } = _t(t), r = s - i, n = l - a;
  return { x: a, y: i, width: n, height: r };
}
g(jt, "layout");
var sr = /* @__PURE__ */ g(async (e, t, a, i = !1, l = !1) => {
  let s = t || "";
  typeof s == "object" && (s = s[0]);
  const r = R(), n = F(r);
  return await St(
    e,
    s,
    {
      style: a,
      isTitle: i,
      useHtmlLabels: n,
      markdown: !1,
      isNode: l,
      width: Number.POSITIVE_INFINITY
    },
    r
  );
}, "createLabel"), U = sr, ir = /* @__PURE__ */ g((e, t, a, i, l) => {
  t.arrowTypeStart && zt(e, "start", t.arrowTypeStart, a, i, l), t.arrowTypeEnd && zt(e, "end", t.arrowTypeEnd, a, i, l);
}, "addEdgeMarkers"), nr = {
  arrow_cross: "cross",
  arrow_point: "point",
  arrow_barb: "barb",
  arrow_circle: "circle",
  aggregation: "aggregation",
  extension: "extension",
  composition: "composition",
  dependency: "dependency",
  lollipop: "lollipop"
}, zt = /* @__PURE__ */ g((e, t, a, i, l, s) => {
  const r = nr[a];
  if (!r) {
    S.warn(`Unknown arrow type: ${a}`);
    return;
  }
  const n = t === "start" ? "Start" : "End";
  e.attr(`marker-${t}`, `url(${i}#${l}_${s}-${r}${n})`);
}, "addEdgeMarker"), mt = {}, M = {}, lr = /* @__PURE__ */ g(async (e, t) => {
  const a = R(), i = F(a), l = e.insert("g").attr("class", "edgeLabel"), s = l.insert("g").attr("class", "label"), r = t.labelType === "markdown", n = await St(
    e,
    t.label,
    {
      style: t.labelStyle,
      useHtmlLabels: i,
      // TODO: The old code only set addSvgBackground when using markdown, but
      // this function is only used by block diagrams which never use markdown.
      addSvgBackground: r,
      isNode: !1,
      markdown: r,
      // If using markdown, wrap using default width
      width: r ? void 0 : Number.POSITIVE_INFINITY
    },
    a
  );
  s.node().appendChild(n);
  let c = n.getBBox(), x = c;
  if (i) {
    const u = n.children[0], b = T(n);
    c = u.getBoundingClientRect(), x = c, b.attr("width", c.width), b.attr("height", c.height);
  } else {
    const u = T(n).select("text").node();
    u && typeof u.getBBox == "function" && (x = u.getBBox());
  }
  s.attr("transform", $(x, i)), mt[t.id] = l, t.width = c.width, t.height = c.height;
  let o;
  if (t.startLabelLeft) {
    const u = e.insert("g").attr("class", "edgeTerminals"), b = u.insert("g").attr("class", "inner"), f = await U(b, t.startLabelLeft, t.labelStyle);
    o = f;
    let m = f.getBBox();
    if (i) {
      const v = f.children[0], L = T(f);
      m = v.getBoundingClientRect(), L.attr("width", m.width), L.attr("height", m.height);
    }
    b.attr("transform", $(m, i)), M[t.id] || (M[t.id] = {}), M[t.id].startLeft = u, et(o, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const u = e.insert("g").attr("class", "edgeTerminals"), b = u.insert("g").attr("class", "inner"), f = await U(
      u,
      t.startLabelRight,
      t.labelStyle
    );
    o = f, b.node().appendChild(f);
    let m = f.getBBox();
    if (i) {
      const v = f.children[0], L = T(f);
      m = v.getBoundingClientRect(), L.attr("width", m.width), L.attr("height", m.height);
    }
    b.attr("transform", $(m, i)), M[t.id] || (M[t.id] = {}), M[t.id].startRight = u, et(o, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const u = e.insert("g").attr("class", "edgeTerminals"), b = u.insert("g").attr("class", "inner"), f = await U(b, t.endLabelLeft, t.labelStyle);
    o = f;
    let m = f.getBBox();
    if (i) {
      const v = f.children[0], L = T(f);
      m = v.getBoundingClientRect(), L.attr("width", m.width), L.attr("height", m.height);
    }
    b.attr("transform", $(m, i)), u.node().appendChild(f), M[t.id] || (M[t.id] = {}), M[t.id].endLeft = u, et(o, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const u = e.insert("g").attr("class", "edgeTerminals"), b = u.insert("g").attr("class", "inner"), f = await U(b, t.endLabelRight, t.labelStyle);
    o = f;
    let m = f.getBBox();
    if (i) {
      const v = f.children[0], L = T(f);
      m = v.getBoundingClientRect(), L.attr("width", m.width), L.attr("height", m.height);
    }
    b.attr("transform", $(m, i)), u.node().appendChild(f), M[t.id] || (M[t.id] = {}), M[t.id].endRight = u, et(o, t.endLabelRight);
  }
  return n;
}, "insertEdgeLabel");
function et(e, t) {
  F(R()) && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
g(et, "setTerminalWidth");
var cr = /* @__PURE__ */ g((e, t) => {
  S.debug("Moving label abc88 ", e.id, e.label, mt[e.id], t);
  let a = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = R(), { subGraphTitleTotalMargin: l } = xe(i);
  if (e.label) {
    const s = mt[e.id];
    let r = e.x, n = e.y;
    if (a) {
      const c = tt.calcLabelPosition(a);
      S.debug(
        "Moving label " + e.label + " from (",
        r,
        ",",
        n,
        ") to (",
        c.x,
        ",",
        c.y,
        ") abc88"
      ), t.updatedPath && (r = c.x, n = c.y);
    }
    s.attr("transform", `translate(${r}, ${n + l / 2})`);
  }
  if (e.startLabelLeft) {
    const s = M[e.id].startLeft;
    let r = e.x, n = e.y;
    if (a) {
      const c = tt.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", a);
      r = c.x, n = c.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
  if (e.startLabelRight) {
    const s = M[e.id].startRight;
    let r = e.x, n = e.y;
    if (a) {
      const c = tt.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        a
      );
      r = c.x, n = c.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
  if (e.endLabelLeft) {
    const s = M[e.id].endLeft;
    let r = e.x, n = e.y;
    if (a) {
      const c = tt.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", a);
      r = c.x, n = c.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
  if (e.endLabelRight) {
    const s = M[e.id].endRight;
    let r = e.x, n = e.y;
    if (a) {
      const c = tt.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", a);
      r = c.x, n = c.y;
    }
    s.attr("transform", `translate(${r}, ${n})`);
  }
}, "positionEdgeLabel"), or = /* @__PURE__ */ g((e, t) => {
  const a = e.x, i = e.y, l = Math.abs(t.x - a), s = Math.abs(t.y - i), r = e.width / 2, n = e.height / 2;
  return l >= r || s >= n;
}, "outsideNode"), hr = /* @__PURE__ */ g((e, t, a) => {
  S.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(a)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, l = e.y, s = Math.abs(i - a.x), r = e.width / 2;
  let n = a.x < t.x ? r - s : r + s;
  const c = e.height / 2, x = Math.abs(t.y - a.y), o = Math.abs(t.x - a.x);
  if (Math.abs(l - t.y) * r > Math.abs(i - t.x) * c) {
    let u = a.y < t.y ? t.y - c - l : l - c - t.y;
    n = o * u / x;
    const b = {
      x: a.x < t.x ? a.x + n : a.x - o + n,
      y: a.y < t.y ? a.y + x - u : a.y - x + u
    };
    return n === 0 && (b.x = t.x, b.y = t.y), o === 0 && (b.x = t.x), x === 0 && (b.y = t.y), S.debug(`abc89 topp/bott calc, Q ${x}, q ${u}, R ${o}, r ${n}`, b), b;
  } else {
    a.x < t.x ? n = t.x - r - i : n = i - r - t.x;
    let u = x * n / o, b = a.x < t.x ? a.x + o - n : a.x - o + n, f = a.y < t.y ? a.y + u : a.y - u;
    return S.debug(`sides calc abc89, Q ${x}, q ${u}, R ${o}, r ${n}`, { _x: b, _y: f }), n === 0 && (b = t.x, f = t.y), o === 0 && (b = t.x), x === 0 && (f = t.y), { x: b, y: f };
  }
}, "intersection"), At = /* @__PURE__ */ g((e, t) => {
  S.debug("abc88 cutPathAtIntersect", e, t);
  let a = [], i = e[0], l = !1;
  return e.forEach((s) => {
    if (!or(t, s) && !l) {
      const r = hr(t, i, s);
      let n = !1;
      a.forEach((c) => {
        n = n || c.x === r.x && c.y === r.y;
      }), a.some((c) => c.x === r.x && c.y === r.y) || a.push(r), l = !0;
    } else
      i = s, l || a.push(s);
  }), a;
}, "cutPathAtIntersect"), gr = /* @__PURE__ */ g(function(e, t, a, i, l, s, r) {
  let n = a.points;
  S.debug("abc88 InsertEdge: edge=", a, "e=", t);
  let c = !1;
  const x = s.node(t.v);
  var o = s.node(t.w);
  o?.intersect && x?.intersect && (n = n.slice(1, a.points.length - 1), n.unshift(x.intersect(n[0])), n.push(o.intersect(n[n.length - 1]))), a.toCluster && (S.debug("to cluster abc88", i[a.toCluster]), n = At(a.points, i[a.toCluster].node), c = !0), a.fromCluster && (S.debug("from cluster abc88", i[a.fromCluster]), n = At(n.reverse(), i[a.fromCluster].node).reverse(), c = !0);
  const u = n.filter((w) => !Number.isNaN(w.y));
  let b = pe;
  a.curve && (l === "graph" || l === "flowchart") && (b = a.curve);
  const { x: f, y: m } = de(a), v = ue().x(f).y(m).curve(b);
  let L;
  switch (a.thickness) {
    case "normal":
      L = "edge-thickness-normal";
      break;
    case "thick":
      L = "edge-thickness-thick";
      break;
    case "invisible":
      L = "edge-thickness-thick";
      break;
    default:
      L = "";
  }
  switch (a.pattern) {
    case "solid":
      L += " edge-pattern-solid";
      break;
    case "dotted":
      L += " edge-pattern-dotted";
      break;
    case "dashed":
      L += " edge-pattern-dashed";
      break;
  }
  const _ = e.append("path").attr("d", v(u)).attr("id", a.id).attr("class", " " + L + (a.classes ? " " + a.classes : "")).attr("style", a.style);
  let I = "";
  (R().flowchart.arrowMarkerAbsolute || R().state.arrowMarkerAbsolute) && (I = fe(!0)), ir(_, a, I, r, l);
  let D = {};
  return c && (D.updatedPath = n), D.originalPath = a.points, D;
}, "insertEdge"), dr = /* @__PURE__ */ g((e) => {
  const t = /* @__PURE__ */ new Set();
  for (const a of e)
    switch (a) {
      case "x":
        t.add("right"), t.add("left");
        break;
      case "y":
        t.add("up"), t.add("down");
        break;
      default:
        t.add(a);
        break;
    }
  return t;
}, "expandAndDeduplicateDirections"), ur = /* @__PURE__ */ g((e, t, a) => {
  const i = dr(e), l = 2, s = t.height + 2 * a.padding, r = s / l, n = t.width + 2 * r + a.padding, c = a.padding / 2;
  return i.has("right") && i.has("left") && i.has("up") && i.has("down") ? [
    // Bottom
    { x: 0, y: 0 },
    { x: r, y: 0 },
    { x: n / 2, y: 2 * c },
    { x: n - r, y: 0 },
    { x: n, y: 0 },
    // Right
    { x: n, y: -s / 3 },
    { x: n + 2 * c, y: -s / 2 },
    { x: n, y: -2 * s / 3 },
    { x: n, y: -s },
    // Top
    { x: n - r, y: -s },
    { x: n / 2, y: -s - 2 * c },
    { x: r, y: -s },
    // Left
    { x: 0, y: -s },
    { x: 0, y: -2 * s / 3 },
    { x: -2 * c, y: -s / 2 },
    { x: 0, y: -s / 3 }
  ] : i.has("right") && i.has("left") && i.has("up") ? [
    { x: r, y: 0 },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ] : i.has("right") && i.has("left") && i.has("down") ? [
    { x: 0, y: 0 },
    { x: r, y: -s },
    { x: n - r, y: -s },
    { x: n, y: 0 }
  ] : i.has("right") && i.has("up") && i.has("down") ? [
    { x: 0, y: 0 },
    { x: n, y: -r },
    { x: n, y: -s + r },
    { x: 0, y: -s }
  ] : i.has("left") && i.has("up") && i.has("down") ? [
    { x: n, y: 0 },
    { x: 0, y: -r },
    { x: 0, y: -s + r },
    { x: n, y: -s }
  ] : i.has("right") && i.has("left") ? [
    { x: r, y: 0 },
    { x: r, y: -c },
    { x: n - r, y: -c },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: n - r, y: -s + c },
    { x: r, y: -s + c },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ] : i.has("up") && i.has("down") ? [
    // Bottom center
    { x: n / 2, y: 0 },
    // Left pont of bottom arrow
    { x: 0, y: -c },
    { x: r, y: -c },
    // Left top over vertical section
    { x: r, y: -s + c },
    { x: 0, y: -s + c },
    // Top of arrow
    { x: n / 2, y: -s },
    { x: n, y: -s + c },
    // Top of right vertical bar
    { x: n - r, y: -s + c },
    { x: n - r, y: -c },
    { x: n, y: -c }
  ] : i.has("right") && i.has("up") ? [
    { x: 0, y: 0 },
    { x: n, y: -r },
    { x: 0, y: -s }
  ] : i.has("right") && i.has("down") ? [
    { x: 0, y: 0 },
    { x: n, y: 0 },
    { x: 0, y: -s }
  ] : i.has("left") && i.has("up") ? [
    { x: n, y: 0 },
    { x: 0, y: -r },
    { x: n, y: -s }
  ] : i.has("left") && i.has("down") ? [
    { x: n, y: 0 },
    { x: 0, y: 0 },
    { x: n, y: -s }
  ] : i.has("right") ? [
    { x: r, y: -c },
    { x: r, y: -c },
    { x: n - r, y: -c },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: n - r, y: -s + c },
    // top left corner of arrow
    { x: r, y: -s + c },
    { x: r, y: -s + c }
  ] : i.has("left") ? [
    { x: r, y: 0 },
    { x: r, y: -c },
    // Two points, the right corners
    { x: n - r, y: -c },
    { x: n - r, y: -s + c },
    { x: r, y: -s + c },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ] : i.has("up") ? [
    // Bottom center
    { x: r, y: -c },
    // Left top over vertical section
    { x: r, y: -s + c },
    { x: 0, y: -s + c },
    // Top of arrow
    { x: n / 2, y: -s },
    { x: n, y: -s + c },
    // Top of right vertical bar
    { x: n - r, y: -s + c },
    { x: n - r, y: -c }
  ] : i.has("down") ? [
    // Bottom center
    { x: n / 2, y: 0 },
    // Left pont of bottom arrow
    { x: 0, y: -c },
    { x: r, y: -c },
    // Left top over vertical section
    { x: r, y: -s + c },
    { x: n - r, y: -s + c },
    { x: n - r, y: -c },
    { x: n, y: -c }
  ] : [{ x: 0, y: 0 }];
}, "getArrowPoints");
function Vt(e, t) {
  return e.intersect(t);
}
g(Vt, "intersectNode");
var pr = Vt;
function Gt(e, t, a, i) {
  var l = e.x, s = e.y, r = l - i.x, n = s - i.y, c = Math.sqrt(t * t * n * n + a * a * r * r), x = Math.abs(t * a * r / c);
  i.x < l && (x = -x);
  var o = Math.abs(t * a * n / c);
  return i.y < s && (o = -o), { x: l + x, y: s + o };
}
g(Gt, "intersectEllipse");
var Zt = Gt;
function qt(e, t, a) {
  return Zt(e, t, t, a);
}
g(qt, "intersectCircle");
var fr = qt;
function Jt(e, t, a, i) {
  var l, s, r, n, c, x, o, u, b, f, m, v, L, _, I;
  if (l = t.y - e.y, r = e.x - t.x, c = t.x * e.y - e.x * t.y, b = l * a.x + r * a.y + c, f = l * i.x + r * i.y + c, !(b !== 0 && f !== 0 && Lt(b, f)) && (s = i.y - a.y, n = a.x - i.x, x = i.x * a.y - a.x * i.y, o = s * e.x + n * e.y + x, u = s * t.x + n * t.y + x, !(o !== 0 && u !== 0 && Lt(o, u)) && (m = l * n - s * r, m !== 0)))
    return v = Math.abs(m / 2), L = r * x - n * c, _ = L < 0 ? (L - v) / m : (L + v) / m, L = s * c - l * x, I = L < 0 ? (L - v) / m : (L + v) / m, { x: _, y: I };
}
g(Jt, "intersectLine");
function Lt(e, t) {
  return e * t > 0;
}
g(Lt, "sameSign");
var xr = Jt, yr = Qt;
function Qt(e, t, a) {
  var i = e.x, l = e.y, s = [], r = Number.POSITIVE_INFINITY, n = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(m) {
    r = Math.min(r, m.x), n = Math.min(n, m.y);
  }) : (r = Math.min(r, t.x), n = Math.min(n, t.y));
  for (var c = i - e.width / 2 - r, x = l - e.height / 2 - n, o = 0; o < t.length; o++) {
    var u = t[o], b = t[o < t.length - 1 ? o + 1 : 0], f = xr(
      e,
      a,
      { x: c + u.x, y: x + u.y },
      { x: c + b.x, y: x + b.y }
    );
    f && s.push(f);
  }
  return s.length ? (s.length > 1 && s.sort(function(m, v) {
    var L = m.x - a.x, _ = m.y - a.y, I = Math.sqrt(L * L + _ * _), D = v.x - a.x, w = v.y - a.y, d = Math.sqrt(D * D + w * w);
    return I < d ? -1 : I === d ? 0 : 1;
  }), s[0]) : e;
}
g(Qt, "intersectPolygon");
var br = /* @__PURE__ */ g((e, t) => {
  var a = e.x, i = e.y, l = t.x - a, s = t.y - i, r = e.width / 2, n = e.height / 2, c, x;
  return Math.abs(s) * r > Math.abs(l) * n ? (s < 0 && (n = -n), c = s === 0 ? 0 : n * l / s, x = n) : (l < 0 && (r = -r), c = r, x = l === 0 ? 0 : r * s / l), { x: a + c, y: i + x };
}, "intersectRect"), wr = br, B = {
  node: pr,
  circle: fr,
  ellipse: Zt,
  polygon: yr,
  rect: wr
}, A = /* @__PURE__ */ g(async (e, t, a, i) => {
  const l = R();
  let s;
  const r = t.useHtmlLabels || F(l);
  a ? s = a : s = "node default";
  const n = e.insert("g").attr("class", s).attr("id", t.domId || t.id), c = n.insert("g").attr("class", "label").attr("style", t.labelStyle);
  let x;
  t.labelText === void 0 ? x = "" : x = typeof t.labelText == "string" ? t.labelText : t.labelText[0];
  let o;
  t.labelType === "markdown" ? o = St(
    c,
    Nt(It(x), l),
    {
      useHtmlLabels: r,
      width: t.width || l.flowchart.wrappingWidth,
      classes: "markdown-node-label"
    },
    l
  ) : o = await U(
    c,
    Nt(It(x), l),
    t.labelStyle,
    !1,
    i
  );
  let u = o.getBBox();
  const b = t.padding / 2;
  if (F(l)) {
    const f = o.children[0], m = T(o);
    await we(f, x), u = f.getBoundingClientRect(), m.attr("width", u.width), m.attr("height", u.height);
  }
  return r ? c.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")") : c.attr("transform", "translate(0, " + -u.height / 2 + ")"), t.centerLabel && c.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.insert("rect", ":first-child"), { shapeSvg: n, bbox: u, halfPadding: b, label: c };
}, "labelHelper"), N = /* @__PURE__ */ g((e, t) => {
  const a = t.node().getBBox();
  e.width = a.width, e.height = a.height;
}, "updateNodeBounds");
function j(e, t, a, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(l) {
      return l.x + "," + l.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + a / 2 + ")");
}
g(j, "insertPolygonShape");
var mr = /* @__PURE__ */ g(async (e, t) => {
  t.useHtmlLabels || F(R()) || (t.centerLabel = !0);
  const { shapeSvg: i, bbox: l, halfPadding: s } = await A(
    e,
    t,
    "node " + t.classes,
    !0
  );
  S.info("Classes = ", t.classes);
  const r = i.insert("rect", ":first-child");
  return r.attr("rx", t.rx).attr("ry", t.ry).attr("x", -l.width / 2 - s).attr("y", -l.height / 2 - s).attr("width", l.width + t.padding).attr("height", l.height + t.padding), N(t, r), t.intersect = function(n) {
    return B.rect(t, n);
  }, i;
}, "note"), Lr = mr, Mt = /* @__PURE__ */ g((e) => e ? " " + e : "", "formatClass"), H = /* @__PURE__ */ g((e, t) => `${t || "node default"}${Mt(e.classes)} ${Mt(
  e.class
)}`, "getClassesFromNode"), Ft = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = l + s, n = [
    { x: r / 2, y: 0 },
    { x: r, y: -r / 2 },
    { x: r / 2, y: -r },
    { x: 0, y: -r / 2 }
  ];
  S.info("Question main (Circle)");
  const c = j(a, r, r, n);
  return c.attr("style", t.style), N(t, c), t.intersect = function(x) {
    return S.warn("Intersect called"), B.polygon(t, n, x);
  }, a;
}, "question"), Sr = /* @__PURE__ */ g((e, t) => {
  const a = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), i = 28, l = [
    { x: 0, y: i / 2 },
    { x: i / 2, y: 0 },
    { x: 0, y: -i / 2 },
    { x: -i / 2, y: 0 }
  ];
  return a.insert("polygon", ":first-child").attr(
    "points",
    l.map(function(r) {
      return r.x + "," + r.y;
    }).join(" ")
  ).attr("class", "state-start").attr("r", 7).attr("width", 28).attr("height", 28), t.width = 28, t.height = 28, t.intersect = function(r) {
    return B.circle(t, 14, r);
  }, a;
}, "choice"), kr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = 4, s = i.height + t.padding, r = s / l, n = i.width + 2 * r + t.padding, c = [
    { x: r, y: 0 },
    { x: n - r, y: 0 },
    { x: n, y: -s / 2 },
    { x: n - r, y: -s },
    { x: r, y: -s },
    { x: 0, y: -s / 2 }
  ], x = j(a, n, s, c);
  return x.attr("style", t.style), N(t, x), t.intersect = function(o) {
    return B.polygon(t, c, o);
  }, a;
}, "hexagon"), vr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(e, t, void 0, !0), l = 2, s = i.height + 2 * t.padding, r = s / l, n = i.width + 2 * r + t.padding, c = ur(t.directions, i, t), x = j(a, n, s, c);
  return x.attr("style", t.style), N(t, x), t.intersect = function(o) {
    return B.polygon(t, c, o);
  }, a;
}, "block_arrow"), Er = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: -s / 2, y: 0 },
    { x: l, y: 0 },
    { x: l, y: -s },
    { x: -s / 2, y: -s },
    { x: 0, y: -s / 2 }
  ];
  return j(a, l, s, r).attr("style", t.style), t.width = l + s, t.height = s, t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "rect_left_inv_arrow"), _r = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(e, t, H(t), !0), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: -2 * s / 6, y: 0 },
    { x: l - s / 6, y: 0 },
    { x: l + 2 * s / 6, y: -s },
    { x: s / 6, y: -s }
  ], n = j(a, l, s, r);
  return n.attr("style", t.style), N(t, n), t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "lean_right"), Dr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: 2 * s / 6, y: 0 },
    { x: l + s / 6, y: 0 },
    { x: l - 2 * s / 6, y: -s },
    { x: -s / 6, y: -s }
  ], n = j(a, l, s, r);
  return n.attr("style", t.style), N(t, n), t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "lean_left"), Tr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: -2 * s / 6, y: 0 },
    { x: l + 2 * s / 6, y: 0 },
    { x: l - s / 6, y: -s },
    { x: s / 6, y: -s }
  ], n = j(a, l, s, r);
  return n.attr("style", t.style), N(t, n), t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "trapezoid"), Br = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: s / 6, y: 0 },
    { x: l - s / 6, y: 0 },
    { x: l + 2 * s / 6, y: -s },
    { x: -2 * s / 6, y: -s }
  ], n = j(a, l, s, r);
  return n.attr("style", t.style), N(t, n), t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "inv_trapezoid"), Nr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: 0, y: 0 },
    { x: l + s / 2, y: 0 },
    { x: l, y: -s / 2 },
    { x: l + s / 2, y: -s },
    { x: 0, y: -s }
  ], n = j(a, l, s, r);
  return n.attr("style", t.style), N(t, n), t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "rect_right_inv_arrow"), Ir = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = l / 2, r = s / (2.5 + l / 50), n = i.height + r + t.padding, c = "M 0," + r + " a " + s + "," + r + " 0,0,0 " + l + " 0 a " + s + "," + r + " 0,0,0 " + -l + " 0 l 0," + n + " a " + s + "," + r + " 0,0,0 " + l + " 0 l 0," + -n, x = a.attr("label-offset-y", r).insert("path", ":first-child").attr("style", t.style).attr("d", c).attr("transform", "translate(" + -l / 2 + "," + -(n / 2 + r) + ")");
  return N(t, x), t.intersect = function(o) {
    const u = B.rect(t, o), b = u.x - t.x;
    if (s != 0 && (Math.abs(b) < t.width / 2 || Math.abs(b) == t.width / 2 && Math.abs(u.y - t.y) > t.height / 2 - r)) {
      let f = r * r * (1 - b * b / (s * s));
      f != 0 && (f = Math.sqrt(f)), f = r - f, o.y - t.y > 0 && (f = -f), u.y += f;
    }
    return u;
  }, a;
}, "cylinder"), Cr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await A(
    e,
    t,
    "node " + t.classes + " " + t.class,
    !0
  ), s = a.insert("rect", ":first-child"), r = t.positioned ? t.width : i.width + t.padding, n = t.positioned ? t.height : i.height + t.padding, c = t.positioned ? -r / 2 : -i.width / 2 - l, x = t.positioned ? -n / 2 : -i.height / 2 - l;
  if (s.attr("class", "basic label-container").attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("x", c).attr("y", x).attr("width", r).attr("height", n), t.props) {
    const o = new Set(Object.keys(t.props));
    t.props.borders && (ht(s, t.props.borders, r, n), o.delete("borders")), o.forEach((u) => {
      S.warn(`Unknown node property ${u}`);
    });
  }
  return N(t, s), t.intersect = function(o) {
    return B.rect(t, o);
  }, a;
}, "rect"), Or = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await A(
    e,
    t,
    "node " + t.classes,
    !0
  ), s = a.insert("rect", ":first-child"), r = t.positioned ? t.width : i.width + t.padding, n = t.positioned ? t.height : i.height + t.padding, c = t.positioned ? -r / 2 : -i.width / 2 - l, x = t.positioned ? -n / 2 : -i.height / 2 - l;
  if (s.attr("class", "basic cluster composite label-container").attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("x", c).attr("y", x).attr("width", r).attr("height", n), t.props) {
    const o = new Set(Object.keys(t.props));
    t.props.borders && (ht(s, t.props.borders, r, n), o.delete("borders")), o.forEach((u) => {
      S.warn(`Unknown node property ${u}`);
    });
  }
  return N(t, s), t.intersect = function(o) {
    return B.rect(t, o);
  }, a;
}, "composite"), Rr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a } = await A(e, t, "label", !0);
  S.trace("Classes = ", t.class);
  const i = a.insert("rect", ":first-child"), l = 0, s = 0;
  if (i.attr("width", l).attr("height", s), a.attr("class", "label edgeLabel"), t.props) {
    const r = new Set(Object.keys(t.props));
    t.props.borders && (ht(i, t.props.borders, l, s), r.delete("borders")), r.forEach((n) => {
      S.warn(`Unknown node property ${n}`);
    });
  }
  return N(t, i), t.intersect = function(r) {
    return B.rect(t, r);
  }, a;
}, "labelRect");
function ht(e, t, a, i) {
  const l = [], s = /* @__PURE__ */ g((n) => {
    l.push(n, 0);
  }, "addBorder"), r = /* @__PURE__ */ g((n) => {
    l.push(0, n);
  }, "skipBorder");
  t.includes("t") ? (S.debug("add top border"), s(a)) : r(a), t.includes("r") ? (S.debug("add right border"), s(i)) : r(i), t.includes("b") ? (S.debug("add bottom border"), s(a)) : r(a), t.includes("l") ? (S.debug("add left border"), s(i)) : r(i), e.attr("stroke-dasharray", l.join(" "));
}
g(ht, "applyNodePropertyBorders");
var zr = /* @__PURE__ */ g(async (e, t) => {
  let a;
  t.classes ? a = "node " + t.classes : a = "node default";
  const i = e.insert("g").attr("class", a).attr("id", t.domId || t.id), l = i.insert("rect", ":first-child"), s = i.insert("line"), r = i.insert("g").attr("class", "label"), n = t.labelText.flat ? t.labelText.flat() : t.labelText;
  let c = "";
  typeof n == "object" ? c = n[0] : c = n, S.info("Label text abc79", c, n, typeof n == "object");
  const x = await U(r, c, t.labelStyle, !0, !0);
  let o = { width: 0, height: 0 };
  if (F(R())) {
    const v = x.children[0], L = T(x);
    o = v.getBoundingClientRect(), L.attr("width", o.width), L.attr("height", o.height);
  }
  S.info("Text 2", n);
  const u = n.slice(1, n.length);
  let b = x.getBBox();
  const f = await U(
    r,
    u.join ? u.join("<br/>") : u,
    t.labelStyle,
    !0,
    !0
  );
  if (F(R())) {
    const v = f.children[0], L = T(f);
    o = v.getBoundingClientRect(), L.attr("width", o.width), L.attr("height", o.height);
  }
  const m = t.padding / 2;
  return T(f).attr(
    "transform",
    "translate( " + // (titleBox.width - bbox.width) / 2 +
    (o.width > b.width ? 0 : (b.width - o.width) / 2) + ", " + (b.height + m + 5) + ")"
  ), T(x).attr(
    "transform",
    "translate( " + // (titleBox.width - bbox.width) / 2 +
    (o.width < b.width ? 0 : -(b.width - o.width) / 2) + ", 0)"
  ), o = r.node().getBBox(), r.attr(
    "transform",
    "translate(" + -o.width / 2 + ", " + (-o.height / 2 - m + 3) + ")"
  ), l.attr("class", "outer title-state").attr("x", -o.width / 2 - m).attr("y", -o.height / 2 - m).attr("width", o.width + t.padding).attr("height", o.height + t.padding), s.attr("class", "divider").attr("x1", -o.width / 2 - m).attr("x2", o.width / 2 + m).attr("y1", -o.height / 2 - m + b.height + m).attr("y2", -o.height / 2 - m + b.height + m), N(t, l), t.intersect = function(v) {
    return B.rect(t, v);
  }, i;
}, "rectWithTitle"), Ar = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.height + t.padding, s = i.width + l / 4 + t.padding, r = a.insert("rect", ":first-child").attr("style", t.style).attr("rx", l / 2).attr("ry", l / 2).attr("x", -s / 2).attr("y", -l / 2).attr("width", s).attr("height", l);
  return N(t, r), t.intersect = function(n) {
    return B.rect(t, n);
  }, a;
}, "stadium"), Mr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), s = a.insert("circle", ":first-child");
  return s.attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("r", i.width / 2 + l).attr("width", i.width + t.padding).attr("height", i.height + t.padding), S.info("Circle main"), N(t, s), t.intersect = function(r) {
    return S.info("Circle intersect", t, i.width / 2 + l, r), B.circle(t, i.width / 2 + l, r);
  }, a;
}, "circle"), Fr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i, halfPadding: l } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), s = 5, r = a.insert("g", ":first-child"), n = r.insert("circle"), c = r.insert("circle");
  return r.attr("class", t.class), n.attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("r", i.width / 2 + l + s).attr("width", i.width + t.padding + s * 2).attr("height", i.height + t.padding + s * 2), c.attr("style", t.style).attr("rx", t.rx).attr("ry", t.ry).attr("r", i.width / 2 + l).attr("width", i.width + t.padding).attr("height", i.height + t.padding), S.info("DoubleCircle main"), N(t, n), t.intersect = function(x) {
    return S.info("DoubleCircle intersect", t, i.width / 2 + l + s, x), B.circle(t, i.width / 2 + l + s, x);
  }, a;
}, "doublecircle"), Pr = /* @__PURE__ */ g(async (e, t) => {
  const { shapeSvg: a, bbox: i } = await A(
    e,
    t,
    H(t, void 0),
    !0
  ), l = i.width + t.padding, s = i.height + t.padding, r = [
    { x: 0, y: 0 },
    { x: l, y: 0 },
    { x: l, y: -s },
    { x: 0, y: -s },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: l + 8, y: 0 },
    { x: l + 8, y: -s },
    { x: -8, y: -s },
    { x: -8, y: 0 }
  ], n = j(a, l, s, r);
  return n.attr("style", t.style), N(t, n), t.intersect = function(c) {
    return B.polygon(t, r, c);
  }, a;
}, "subroutine"), Wr = /* @__PURE__ */ g((e, t) => {
  const a = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), i = a.insert("circle", ":first-child");
  return i.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14), N(t, i), t.intersect = function(l) {
    return B.circle(t, 7, l);
  }, a;
}, "start"), Pt = /* @__PURE__ */ g((e, t, a) => {
  const i = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let l = 70, s = 10;
  a === "LR" && (l = 10, s = 70);
  const r = i.append("rect").attr("x", -1 * l / 2).attr("y", -1 * s / 2).attr("width", l).attr("height", s).attr("class", "fork-join");
  return N(t, r), t.height = t.height + t.padding / 2, t.width = t.width + t.padding / 2, t.intersect = function(n) {
    return B.rect(t, n);
  }, i;
}, "forkJoin"), Yr = /* @__PURE__ */ g((e, t) => {
  const a = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), i = a.insert("circle", ":first-child"), l = a.insert("circle", ":first-child");
  return l.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14), i.attr("class", "state-end").attr("r", 5).attr("width", 10).attr("height", 10), N(t, l), t.intersect = function(s) {
    return B.circle(t, 7, s);
  }, a;
}, "end"), Hr = /* @__PURE__ */ g(async (e, t) => {
  const a = t.padding / 2, i = 4, l = 8;
  let s;
  t.classes ? s = "node " + t.classes : s = "node default";
  const r = e.insert("g").attr("class", s).attr("id", t.domId || t.id), n = r.insert("rect", ":first-child"), c = r.insert("line"), x = r.insert("line");
  let o = 0, u = i;
  const b = r.insert("g").attr("class", "label");
  let f = 0;
  const m = t.classData.annotations?.[0], v = t.classData.annotations[0] ? "«" + t.classData.annotations[0] + "»" : "", L = await U(
    b,
    v,
    t.labelStyle,
    !0,
    !0
  );
  let _ = L.getBBox();
  if (F(R())) {
    const E = L.children[0], h = T(L);
    _ = E.getBoundingClientRect(), h.attr("width", _.width), h.attr("height", _.height);
  }
  t.classData.annotations[0] && (u += _.height + i, o += _.width);
  let I = t.classData.label;
  t.classData.type !== void 0 && t.classData.type !== "" && (F(R()) ? I += "&lt;" + t.classData.type + "&gt;" : I += "<" + t.classData.type + ">");
  const D = await U(
    b,
    I,
    t.labelStyle,
    !0,
    !0
  );
  T(D).attr("class", "classTitle");
  let w = D.getBBox();
  if (F(R())) {
    const E = D.children[0], h = T(D);
    w = E.getBoundingClientRect(), h.attr("width", w.width), h.attr("height", w.height);
  }
  u += w.height + i, w.width > o && (o = w.width);
  const d = [];
  t.classData.members.forEach(async (E) => {
    const h = E.getDisplayDetails();
    let W = h.displayText;
    F(R()) && (W = W.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    const p = await U(
      b,
      W,
      h.cssStyle ? h.cssStyle : t.labelStyle,
      !0,
      !0
    );
    let O = p.getBBox();
    if (F(R())) {
      const Z = p.children[0], V = T(p);
      O = Z.getBoundingClientRect(), V.attr("width", O.width), V.attr("height", O.height);
    }
    O.width > o && (o = O.width), u += O.height + i, d.push(p);
  }), u += l;
  const y = [];
  if (t.classData.methods.forEach(async (E) => {
    const h = E.getDisplayDetails();
    let W = h.displayText;
    F(R()) && (W = W.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    const p = await U(
      b,
      W,
      h.cssStyle ? h.cssStyle : t.labelStyle,
      !0,
      !0
    );
    let O = p.getBBox();
    if (F(R())) {
      const Z = p.children[0], V = T(p);
      O = Z.getBoundingClientRect(), V.attr("width", O.width), V.attr("height", O.height);
    }
    O.width > o && (o = O.width), u += O.height + i, y.push(p);
  }), u += l, m) {
    let E = (o - _.width) / 2;
    T(L).attr(
      "transform",
      "translate( " + (-1 * o / 2 + E) + ", " + -1 * u / 2 + ")"
    ), f = _.height + i;
  }
  let k = (o - w.width) / 2;
  return T(D).attr(
    "transform",
    "translate( " + (-1 * o / 2 + k) + ", " + (-1 * u / 2 + f) + ")"
  ), f += w.height + i, c.attr("class", "divider").attr("x1", -o / 2 - a).attr("x2", o / 2 + a).attr("y1", -u / 2 - a + l + f).attr("y2", -u / 2 - a + l + f), f += l, d.forEach((E) => {
    T(E).attr(
      "transform",
      "translate( " + -o / 2 + ", " + (-1 * u / 2 + f + l / 2) + ")"
    );
    const h = E?.getBBox();
    f += (h?.height ?? 0) + i;
  }), f += l, x.attr("class", "divider").attr("x1", -o / 2 - a).attr("x2", o / 2 + a).attr("y1", -u / 2 - a + l + f).attr("y2", -u / 2 - a + l + f), f += l, y.forEach((E) => {
    T(E).attr(
      "transform",
      "translate( " + -o / 2 + ", " + (-1 * u / 2 + f) + ")"
    );
    const h = E?.getBBox();
    f += (h?.height ?? 0) + i;
  }), n.attr("style", t.style).attr("class", "outer title-state").attr("x", -o / 2 - a).attr("y", -(u / 2) - a).attr("width", o + t.padding).attr("height", u + t.padding), N(t, n), t.intersect = function(E) {
    return B.rect(t, E);
  }, r;
}, "class_box"), Wt = {
  rhombus: Ft,
  composite: Or,
  question: Ft,
  rect: Cr,
  labelRect: Rr,
  rectWithTitle: zr,
  choice: Sr,
  circle: Mr,
  doublecircle: Fr,
  stadium: Ar,
  hexagon: kr,
  block_arrow: vr,
  rect_left_inv_arrow: Er,
  lean_right: _r,
  lean_left: Dr,
  trapezoid: Tr,
  inv_trapezoid: Br,
  rect_right_inv_arrow: Nr,
  cylinder: Ir,
  start: Wr,
  end: Yr,
  note: Lr,
  subroutine: Pr,
  fork: Pt,
  join: Pt,
  class_box: Hr
}, lt = {}, $t = /* @__PURE__ */ g(async (e, t, a) => {
  let i, l;
  if (t.link) {
    let s;
    R().securityLevel === "sandbox" ? s = "_top" : t.linkTarget && (s = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", s), l = await Wt[t.shape](i, t, a);
  } else
    l = await Wt[t.shape](e, t, a), i = l;
  return t.tooltip && l.attr("title", t.tooltip), t.class && l.attr("class", "node default " + t.class), lt[t.id] = i, t.haveCallback && lt[t.id].attr("class", lt[t.id].attr("class") + " clickable"), i;
}, "insertNode"), Kr = /* @__PURE__ */ g((e) => {
  const t = lt[e.id];
  S.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const a = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - a) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode");
function Dt(e, t, a = !1) {
  const i = e;
  let l = "default";
  (i?.classes?.length || 0) > 0 && (l = (i?.classes ?? []).join(" ")), l = l + " flowchart-label";
  let s = 0, r = "", n;
  switch (i.type) {
    case "round":
      s = 5, r = "rect";
      break;
    case "composite":
      s = 0, r = "composite", n = 0;
      break;
    case "square":
      r = "rect";
      break;
    case "diamond":
      r = "question";
      break;
    case "hexagon":
      r = "hexagon";
      break;
    case "block_arrow":
      r = "block_arrow";
      break;
    case "odd":
      r = "rect_left_inv_arrow";
      break;
    case "lean_right":
      r = "lean_right";
      break;
    case "lean_left":
      r = "lean_left";
      break;
    case "trapezoid":
      r = "trapezoid";
      break;
    case "inv_trapezoid":
      r = "inv_trapezoid";
      break;
    case "rect_left_inv_arrow":
      r = "rect_left_inv_arrow";
      break;
    case "circle":
      r = "circle";
      break;
    case "ellipse":
      r = "ellipse";
      break;
    case "stadium":
      r = "stadium";
      break;
    case "subroutine":
      r = "subroutine";
      break;
    case "cylinder":
      r = "cylinder";
      break;
    case "group":
      r = "rect";
      break;
    case "doublecircle":
      r = "doublecircle";
      break;
    default:
      r = "rect";
  }
  const c = be(i?.styles ?? []), x = i.label, o = i.size ?? { width: 0, height: 0, x: 0, y: 0 };
  return {
    labelStyle: c.labelStyle,
    shape: r,
    labelText: x,
    rx: s,
    ry: s,
    class: l,
    style: c.style,
    id: i.id,
    directions: i.directions,
    width: o.width,
    height: o.height,
    x: o.x,
    y: o.y,
    positioned: a,
    intersect: void 0,
    type: i.type,
    padding: n ?? at()?.block?.padding ?? 0
  };
}
g(Dt, "getNodeFromBlock");
async function te(e, t, a) {
  const i = Dt(t, a, !1);
  if (i.type === "group")
    return;
  const l = at(), s = await $t(e, i, { config: l }), r = s.node().getBBox(), n = a.getBlock(i.id);
  n.size = { width: r.width, height: r.height, x: 0, y: 0, node: s }, a.setBlock(n), s.remove();
}
g(te, "calculateBlockSize");
async function ee(e, t, a) {
  const i = Dt(t, a, !0);
  if (a.getBlock(i.id).type !== "space") {
    const s = at();
    await $t(e, i, { config: s }), t.intersect = i?.intersect, Kr(i);
  }
}
g(ee, "insertBlockPositioned");
async function gt(e, t, a, i) {
  for (const l of t)
    await i(e, l, a), l.children && await gt(e, l.children, a, i);
}
g(gt, "performOperations");
async function re(e, t, a) {
  await gt(e, t, a, te);
}
g(re, "calculateBlockSizes");
async function ae(e, t, a) {
  await gt(e, t, a, ee);
}
g(ae, "insertBlocks");
async function se(e, t, a, i, l) {
  const s = new Le({
    multigraph: !0,
    compound: !0
  });
  s.setGraph({
    rankdir: "TB",
    nodesep: 10,
    ranksep: 10,
    marginx: 8,
    marginy: 8
  });
  for (const r of a)
    r.size && s.setNode(r.id, {
      width: r.size.width,
      height: r.size.height,
      intersect: r.intersect
    });
  for (const r of t)
    if (r.start && r.end) {
      const n = i.getBlock(r.start), c = i.getBlock(r.end);
      if (n?.size && c?.size) {
        const x = n.size, o = c.size, u = [
          { x: x.x, y: x.y },
          { x: x.x + (o.x - x.x) / 2, y: x.y + (o.y - x.y) / 2 },
          { x: o.x, y: o.y }
        ];
        gr(
          e,
          { v: r.start, w: r.end, name: r.id },
          {
            ...r,
            arrowTypeEnd: r.arrowTypeEnd,
            arrowTypeStart: r.arrowTypeStart,
            points: u,
            classes: "edge-thickness-normal edge-pattern-solid flowchart-link LS-a1 LE-b1"
          },
          void 0,
          "block",
          s,
          l
        ), r.label && (await lr(e, {
          ...r,
          label: r.label,
          labelStyle: "stroke: #333; stroke-width: 1.5px;fill:none;",
          arrowTypeEnd: r.arrowTypeEnd,
          arrowTypeStart: r.arrowTypeStart,
          points: u,
          classes: "edge-thickness-normal edge-pattern-solid flowchart-link LS-a1 LE-b1"
        }), cr(
          { ...r, x: u[1].x, y: u[1].y },
          {
            originalPath: u
          }
        ));
      }
    }
}
g(se, "insertEdges");
var Ur = /* @__PURE__ */ g(function(e, t) {
  return t.db.getClasses();
}, "getClasses"), Xr = /* @__PURE__ */ g(async function(e, t, a, i) {
  const { securityLevel: l, block: s } = at(), r = i.db;
  let n;
  l === "sandbox" && (n = T("#i" + t));
  const c = l === "sandbox" ? T(n.nodes()[0].contentDocument.body) : T("body"), x = l === "sandbox" ? c.select(`[id="${t}"]`) : T(`[id="${t}"]`);
  rr(x, ["point", "circle", "cross"], i.type, t);
  const u = r.getBlocks(), b = r.getBlocksFlat(), f = r.getEdges(), m = x.insert("g").attr("class", "block");
  await re(m, u, r);
  const v = jt(r);
  if (await ae(m, u, r), await se(m, f, b, r, t), v) {
    const L = v, _ = Math.max(1, Math.round(0.125 * (L.width / L.height))), I = L.height + _ + 10, D = L.width + 10, { useMaxWidth: w } = s;
    oe(x, I, D, !!w), S.debug("Here Bounds", v, L), x.attr(
      "viewBox",
      `${L.x - 5} ${L.y - 5} ${L.width + 10} ${L.height + 10}`
    );
  }
}, "draw"), jr = {
  draw: Xr,
  getClasses: Ur
}, Qr = {
  parser: ke,
  db: He,
  renderer: jr,
  styles: Ue
};
export {
  Qr as diagram
};
