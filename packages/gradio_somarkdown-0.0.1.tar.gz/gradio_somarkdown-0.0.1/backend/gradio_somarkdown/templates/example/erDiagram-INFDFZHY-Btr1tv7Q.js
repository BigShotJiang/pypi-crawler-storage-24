import { g as Vt } from "./chunk-55IACEB6-362b7Ann.js";
import { s as Mt } from "./chunk-KX2RTZJC-DDLAkZGm.js";
import { _ as u, b as Bt, a as Ft, s as Yt, g as Pt, p as zt, q as Gt, c as it, l as L, z as Kt, x as Ut, B as Zt, C as jt, o as Wt, r as Qt, d as Xt, u as qt } from "./mermaid.core-CbLi0pBF.js";
import { c as Ht } from "./channel-pxn14BVk.js";
var _t = (function() {
  var s = /* @__PURE__ */ u(function(R, n, a, c) {
    for (a = a || {}, c = R.length; c--; a[R[c]] = n) ;
    return a;
  }, "o"), i = [6, 8, 10, 22, 24, 26, 28, 33, 34, 35, 36, 37, 40, 43, 44, 48, 50, 51, 52], l = [1, 10], d = [1, 11], o = [1, 12], h = [1, 13], y = [1, 23], _ = [1, 24], E = [1, 25], V = [1, 26], W = [1, 27], S = [1, 19], rt = [1, 28], Q = [1, 29], T = [1, 20], I = [1, 18], M = [1, 21], B = [1, 22], nt = [1, 36], at = [1, 37], ct = [1, 38], lt = [1, 39], ot = [1, 40], F = [6, 8, 10, 13, 15, 17, 20, 21, 22, 24, 26, 28, 33, 34, 35, 36, 37, 40, 43, 44, 48, 50, 51, 52, 65, 66, 67, 68, 69], O = [1, 45], N = [1, 46], Y = [1, 55], P = [40, 48, 50, 51, 52, 70, 71], z = [1, 66], G = [1, 64], A = [1, 61], K = [1, 65], U = [1, 67], X = [6, 8, 10, 13, 17, 22, 24, 26, 28, 33, 34, 35, 36, 37, 40, 41, 42, 43, 44, 48, 49, 50, 51, 52, 65, 66, 67, 68, 69], gt = [65, 66, 67, 68, 69], bt = [1, 84], mt = [1, 83], Et = [1, 81], kt = [1, 82], St = [6, 10, 42, 47], v = [6, 10, 13, 41, 42, 47, 48, 49], q = [1, 92], H = [1, 91], J = [1, 90], Z = [19, 58], Tt = [1, 101], Ot = [1, 100], ht = [19, 58, 60, 62], ut = {
    trace: /* @__PURE__ */ u(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, ER_DIAGRAM: 4, document: 5, EOF: 6, line: 7, SPACE: 8, statement: 9, NEWLINE: 10, entityName: 11, relSpec: 12, COLON: 13, role: 14, STYLE_SEPARATOR: 15, idList: 16, BLOCK_START: 17, attributes: 18, BLOCK_STOP: 19, SQS: 20, SQE: 21, title: 22, title_value: 23, acc_title: 24, acc_title_value: 25, acc_descr: 26, acc_descr_value: 27, acc_descr_multiline_value: 28, direction: 29, classDefStatement: 30, classStatement: 31, styleStatement: 32, direction_tb: 33, direction_bt: 34, direction_rl: 35, direction_lr: 36, CLASSDEF: 37, stylesOpt: 38, separator: 39, UNICODE_TEXT: 40, STYLE_TEXT: 41, COMMA: 42, CLASS: 43, STYLE: 44, style: 45, styleComponent: 46, SEMI: 47, NUM: 48, BRKT: 49, ENTITY_NAME: 50, DECIMAL_NUM: 51, ENTITY_ONE: 52, attribute: 53, attributeType: 54, attributeName: 55, attributeKeyTypeList: 56, attributeComment: 57, ATTRIBUTE_WORD: 58, attributeKeyType: 59, ",": 60, ATTRIBUTE_KEY: 61, COMMENT: 62, cardinality: 63, relType: 64, ZERO_OR_ONE: 65, ZERO_OR_MORE: 66, ONE_OR_MORE: 67, ONLY_ONE: 68, MD_PARENT: 69, NON_IDENTIFYING: 70, IDENTIFYING: 71, WORD: 72, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "ER_DIAGRAM", 6: "EOF", 8: "SPACE", 10: "NEWLINE", 13: "COLON", 15: "STYLE_SEPARATOR", 17: "BLOCK_START", 19: "BLOCK_STOP", 20: "SQS", 21: "SQE", 22: "title", 23: "title_value", 24: "acc_title", 25: "acc_title_value", 26: "acc_descr", 27: "acc_descr_value", 28: "acc_descr_multiline_value", 33: "direction_tb", 34: "direction_bt", 35: "direction_rl", 36: "direction_lr", 37: "CLASSDEF", 40: "UNICODE_TEXT", 41: "STYLE_TEXT", 42: "COMMA", 43: "CLASS", 44: "STYLE", 47: "SEMI", 48: "NUM", 49: "BRKT", 50: "ENTITY_NAME", 51: "DECIMAL_NUM", 52: "ENTITY_ONE", 58: "ATTRIBUTE_WORD", 60: ",", 61: "ATTRIBUTE_KEY", 62: "COMMENT", 65: "ZERO_OR_ONE", 66: "ZERO_OR_MORE", 67: "ONE_OR_MORE", 68: "ONLY_ONE", 69: "MD_PARENT", 70: "NON_IDENTIFYING", 71: "IDENTIFYING", 72: "WORD" },
    productions_: [0, [3, 3], [5, 0], [5, 2], [7, 2], [7, 1], [7, 1], [7, 1], [9, 5], [9, 9], [9, 7], [9, 7], [9, 4], [9, 6], [9, 3], [9, 5], [9, 1], [9, 3], [9, 7], [9, 9], [9, 6], [9, 8], [9, 4], [9, 6], [9, 2], [9, 2], [9, 2], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [29, 1], [29, 1], [29, 1], [29, 1], [30, 4], [16, 1], [16, 1], [16, 3], [16, 3], [31, 3], [32, 4], [38, 1], [38, 3], [45, 1], [45, 2], [39, 1], [39, 1], [39, 1], [46, 1], [46, 1], [46, 1], [46, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [18, 1], [18, 2], [53, 2], [53, 3], [53, 3], [53, 4], [54, 1], [55, 1], [56, 1], [56, 3], [59, 1], [57, 1], [12, 3], [63, 1], [63, 1], [63, 1], [63, 1], [63, 1], [64, 1], [64, 1], [14, 1], [14, 1], [14, 1]],
    performAction: /* @__PURE__ */ u(function(n, a, c, r, p, t, j) {
      var e = t.length - 1;
      switch (p) {
        case 1:
          break;
        case 2:
          this.$ = [];
          break;
        case 3:
          t[e - 1].push(t[e]), this.$ = t[e - 1];
          break;
        case 4:
        case 5:
          this.$ = t[e];
          break;
        case 6:
        case 7:
          this.$ = [];
          break;
        case 8:
          r.addEntity(t[e - 4]), r.addEntity(t[e - 2]), r.addRelationship(t[e - 4], t[e], t[e - 2], t[e - 3]);
          break;
        case 9:
          r.addEntity(t[e - 8]), r.addEntity(t[e - 4]), r.addRelationship(t[e - 8], t[e], t[e - 4], t[e - 5]), r.setClass([t[e - 8]], t[e - 6]), r.setClass([t[e - 4]], t[e - 2]);
          break;
        case 10:
          r.addEntity(t[e - 6]), r.addEntity(t[e - 2]), r.addRelationship(t[e - 6], t[e], t[e - 2], t[e - 3]), r.setClass([t[e - 6]], t[e - 4]);
          break;
        case 11:
          r.addEntity(t[e - 6]), r.addEntity(t[e - 4]), r.addRelationship(t[e - 6], t[e], t[e - 4], t[e - 5]), r.setClass([t[e - 4]], t[e - 2]);
          break;
        case 12:
          r.addEntity(t[e - 3]), r.addAttributes(t[e - 3], t[e - 1]);
          break;
        case 13:
          r.addEntity(t[e - 5]), r.addAttributes(t[e - 5], t[e - 1]), r.setClass([t[e - 5]], t[e - 3]);
          break;
        case 14:
          r.addEntity(t[e - 2]);
          break;
        case 15:
          r.addEntity(t[e - 4]), r.setClass([t[e - 4]], t[e - 2]);
          break;
        case 16:
          r.addEntity(t[e]);
          break;
        case 17:
          r.addEntity(t[e - 2]), r.setClass([t[e - 2]], t[e]);
          break;
        case 18:
          r.addEntity(t[e - 6], t[e - 4]), r.addAttributes(t[e - 6], t[e - 1]);
          break;
        case 19:
          r.addEntity(t[e - 8], t[e - 6]), r.addAttributes(t[e - 8], t[e - 1]), r.setClass([t[e - 8]], t[e - 3]);
          break;
        case 20:
          r.addEntity(t[e - 5], t[e - 3]);
          break;
        case 21:
          r.addEntity(t[e - 7], t[e - 5]), r.setClass([t[e - 7]], t[e - 2]);
          break;
        case 22:
          r.addEntity(t[e - 3], t[e - 1]);
          break;
        case 23:
          r.addEntity(t[e - 5], t[e - 3]), r.setClass([t[e - 5]], t[e]);
          break;
        case 24:
        case 25:
          this.$ = t[e].trim(), r.setAccTitle(this.$);
          break;
        case 26:
        case 27:
          this.$ = t[e].trim(), r.setAccDescription(this.$);
          break;
        case 32:
          r.setDirection("TB");
          break;
        case 33:
          r.setDirection("BT");
          break;
        case 34:
          r.setDirection("RL");
          break;
        case 35:
          r.setDirection("LR");
          break;
        case 36:
          this.$ = t[e - 3], r.addClass(t[e - 2], t[e - 1]);
          break;
        case 37:
        case 38:
        case 59:
        case 67:
          this.$ = [t[e]];
          break;
        case 39:
        case 40:
          this.$ = t[e - 2].concat([t[e]]);
          break;
        case 41:
          this.$ = t[e - 2], r.setClass(t[e - 1], t[e]);
          break;
        case 42:
          this.$ = t[e - 3], r.addCssStyles(t[e - 2], t[e - 1]);
          break;
        case 43:
          this.$ = [t[e]];
          break;
        case 44:
          t[e - 2].push(t[e]), this.$ = t[e - 2];
          break;
        case 46:
          this.$ = t[e - 1] + t[e];
          break;
        case 54:
        case 79:
        case 80:
          this.$ = t[e].replace(/"/g, "");
          break;
        case 55:
        case 56:
        case 57:
        case 58:
        case 81:
          this.$ = t[e];
          break;
        case 60:
          t[e].push(t[e - 1]), this.$ = t[e];
          break;
        case 61:
          this.$ = { type: t[e - 1], name: t[e] };
          break;
        case 62:
          this.$ = { type: t[e - 2], name: t[e - 1], keys: t[e] };
          break;
        case 63:
          this.$ = { type: t[e - 2], name: t[e - 1], comment: t[e] };
          break;
        case 64:
          this.$ = { type: t[e - 3], name: t[e - 2], keys: t[e - 1], comment: t[e] };
          break;
        case 65:
        case 66:
        case 69:
          this.$ = t[e];
          break;
        case 68:
          t[e - 2].push(t[e]), this.$ = t[e - 2];
          break;
        case 70:
          this.$ = t[e].replace(/"/g, "");
          break;
        case 71:
          this.$ = { cardA: t[e], relType: t[e - 1], cardB: t[e - 2] };
          break;
        case 72:
          this.$ = r.Cardinality.ZERO_OR_ONE;
          break;
        case 73:
          this.$ = r.Cardinality.ZERO_OR_MORE;
          break;
        case 74:
          this.$ = r.Cardinality.ONE_OR_MORE;
          break;
        case 75:
          this.$ = r.Cardinality.ONLY_ONE;
          break;
        case 76:
          this.$ = r.Cardinality.MD_PARENT;
          break;
        case 77:
          this.$ = r.Identification.NON_IDENTIFYING;
          break;
        case 78:
          this.$ = r.Identification.IDENTIFYING;
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: [1, 2] }, { 1: [3] }, s(i, [2, 2], { 5: 3 }), { 6: [1, 4], 7: 5, 8: [1, 6], 9: 7, 10: [1, 8], 11: 9, 22: l, 24: d, 26: o, 28: h, 29: 14, 30: 15, 31: 16, 32: 17, 33: y, 34: _, 35: E, 36: V, 37: W, 40: S, 43: rt, 44: Q, 48: T, 50: I, 51: M, 52: B }, s(i, [2, 7], { 1: [2, 1] }), s(i, [2, 3]), { 9: 30, 11: 9, 22: l, 24: d, 26: o, 28: h, 29: 14, 30: 15, 31: 16, 32: 17, 33: y, 34: _, 35: E, 36: V, 37: W, 40: S, 43: rt, 44: Q, 48: T, 50: I, 51: M, 52: B }, s(i, [2, 5]), s(i, [2, 6]), s(i, [2, 16], { 12: 31, 63: 35, 15: [1, 32], 17: [1, 33], 20: [1, 34], 65: nt, 66: at, 67: ct, 68: lt, 69: ot }), { 23: [1, 41] }, { 25: [1, 42] }, { 27: [1, 43] }, s(i, [2, 27]), s(i, [2, 28]), s(i, [2, 29]), s(i, [2, 30]), s(i, [2, 31]), s(F, [2, 54]), s(F, [2, 55]), s(F, [2, 56]), s(F, [2, 57]), s(F, [2, 58]), s(i, [2, 32]), s(i, [2, 33]), s(i, [2, 34]), s(i, [2, 35]), { 16: 44, 40: O, 41: N }, { 16: 47, 40: O, 41: N }, { 16: 48, 40: O, 41: N }, s(i, [2, 4]), { 11: 49, 40: S, 48: T, 50: I, 51: M, 52: B }, { 16: 50, 40: O, 41: N }, { 18: 51, 19: [1, 52], 53: 53, 54: 54, 58: Y }, { 11: 56, 40: S, 48: T, 50: I, 51: M, 52: B }, { 64: 57, 70: [1, 58], 71: [1, 59] }, s(P, [2, 72]), s(P, [2, 73]), s(P, [2, 74]), s(P, [2, 75]), s(P, [2, 76]), s(i, [2, 24]), s(i, [2, 25]), s(i, [2, 26]), { 13: z, 38: 60, 41: G, 42: A, 45: 62, 46: 63, 48: K, 49: U }, s(X, [2, 37]), s(X, [2, 38]), { 16: 68, 40: O, 41: N, 42: A }, { 13: z, 38: 69, 41: G, 42: A, 45: 62, 46: 63, 48: K, 49: U }, { 13: [1, 70], 15: [1, 71] }, s(i, [2, 17], { 63: 35, 12: 72, 17: [1, 73], 42: A, 65: nt, 66: at, 67: ct, 68: lt, 69: ot }), { 19: [1, 74] }, s(i, [2, 14]), { 18: 75, 19: [2, 59], 53: 53, 54: 54, 58: Y }, { 55: 76, 58: [1, 77] }, { 58: [2, 65] }, { 21: [1, 78] }, { 63: 79, 65: nt, 66: at, 67: ct, 68: lt, 69: ot }, s(gt, [2, 77]), s(gt, [2, 78]), { 6: bt, 10: mt, 39: 80, 42: Et, 47: kt }, { 40: [1, 85], 41: [1, 86] }, s(St, [2, 43], { 46: 87, 13: z, 41: G, 48: K, 49: U }), s(v, [2, 45]), s(v, [2, 50]), s(v, [2, 51]), s(v, [2, 52]), s(v, [2, 53]), s(i, [2, 41], { 42: A }), { 6: bt, 10: mt, 39: 88, 42: Et, 47: kt }, { 14: 89, 40: q, 50: H, 72: J }, { 16: 93, 40: O, 41: N }, { 11: 94, 40: S, 48: T, 50: I, 51: M, 52: B }, { 18: 95, 19: [1, 96], 53: 53, 54: 54, 58: Y }, s(i, [2, 12]), { 19: [2, 60] }, s(Z, [2, 61], { 56: 97, 57: 98, 59: 99, 61: Tt, 62: Ot }), s([19, 58, 61, 62], [2, 66]), s(i, [2, 22], { 15: [1, 103], 17: [1, 102] }), s([40, 48, 50, 51, 52], [2, 71]), s(i, [2, 36]), { 13: z, 41: G, 45: 104, 46: 63, 48: K, 49: U }, s(i, [2, 47]), s(i, [2, 48]), s(i, [2, 49]), s(X, [2, 39]), s(X, [2, 40]), s(v, [2, 46]), s(i, [2, 42]), s(i, [2, 8]), s(i, [2, 79]), s(i, [2, 80]), s(i, [2, 81]), { 13: [1, 105], 42: A }, { 13: [1, 107], 15: [1, 106] }, { 19: [1, 108] }, s(i, [2, 15]), s(Z, [2, 62], { 57: 109, 60: [1, 110], 62: Ot }), s(Z, [2, 63]), s(ht, [2, 67]), s(Z, [2, 70]), s(ht, [2, 69]), { 18: 111, 19: [1, 112], 53: 53, 54: 54, 58: Y }, { 16: 113, 40: O, 41: N }, s(St, [2, 44], { 46: 87, 13: z, 41: G, 48: K, 49: U }), { 14: 114, 40: q, 50: H, 72: J }, { 16: 115, 40: O, 41: N }, { 14: 116, 40: q, 50: H, 72: J }, s(i, [2, 13]), s(Z, [2, 64]), { 59: 117, 61: Tt }, { 19: [1, 118] }, s(i, [2, 20]), s(i, [2, 23], { 17: [1, 119], 42: A }), s(i, [2, 11]), { 13: [1, 120], 42: A }, s(i, [2, 10]), s(ht, [2, 68]), s(i, [2, 18]), { 18: 121, 19: [1, 122], 53: 53, 54: 54, 58: Y }, { 14: 123, 40: q, 50: H, 72: J }, { 19: [1, 124] }, s(i, [2, 21]), s(i, [2, 9]), s(i, [2, 19])],
    defaultActions: { 55: [2, 65], 75: [2, 60] },
    parseError: /* @__PURE__ */ u(function(n, a) {
      if (a.recoverable)
        this.trace(n);
      else {
        var c = new Error(n);
        throw c.hash = a, c;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ u(function(n) {
      var a = this, c = [0], r = [], p = [null], t = [], j = this.table, e = "", tt = 0, Nt = 0, vt = 2, At = 1, Dt = t.slice.call(arguments, 1), f = Object.create(this.lexer), x = { yy: {} };
      for (var dt in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, dt) && (x.yy[dt] = this.yy[dt]);
      f.setInput(n, x.yy), x.yy.lexer = f, x.yy.parser = this, typeof f.yylloc > "u" && (f.yylloc = {});
      var pt = f.yylloc;
      t.push(pt);
      var Lt = f.options && f.options.ranges;
      typeof x.yy.parseError == "function" ? this.parseError = x.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function wt(b) {
        c.length = c.length - 2 * b, p.length = p.length - b, t.length = t.length - b;
      }
      u(wt, "popStack");
      function Rt() {
        var b;
        return b = r.pop() || f.lex() || At, typeof b != "number" && (b instanceof Array && (r = b, b = r.pop()), b = a.symbols_[b] || b), b;
      }
      u(Rt, "lex");
      for (var g, C, m, ft, D = {}, et, k, It, st; ; ) {
        if (C = c[c.length - 1], this.defaultActions[C] ? m = this.defaultActions[C] : ((g === null || typeof g > "u") && (g = Rt()), m = j[C] && j[C][g]), typeof m > "u" || !m.length || !m[0]) {
          var yt = "";
          st = [];
          for (et in j[C])
            this.terminals_[et] && et > vt && st.push("'" + this.terminals_[et] + "'");
          f.showPosition ? yt = "Parse error on line " + (tt + 1) + `:
` + f.showPosition() + `
Expecting ` + st.join(", ") + ", got '" + (this.terminals_[g] || g) + "'" : yt = "Parse error on line " + (tt + 1) + ": Unexpected " + (g == At ? "end of input" : "'" + (this.terminals_[g] || g) + "'"), this.parseError(yt, {
            text: f.match,
            token: this.terminals_[g] || g,
            line: f.yylineno,
            loc: pt,
            expected: st
          });
        }
        if (m[0] instanceof Array && m.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + C + ", token: " + g);
        switch (m[0]) {
          case 1:
            c.push(g), p.push(f.yytext), t.push(f.yylloc), c.push(m[1]), g = null, Nt = f.yyleng, e = f.yytext, tt = f.yylineno, pt = f.yylloc;
            break;
          case 2:
            if (k = this.productions_[m[1]][1], D.$ = p[p.length - k], D._$ = {
              first_line: t[t.length - (k || 1)].first_line,
              last_line: t[t.length - 1].last_line,
              first_column: t[t.length - (k || 1)].first_column,
              last_column: t[t.length - 1].last_column
            }, Lt && (D._$.range = [
              t[t.length - (k || 1)].range[0],
              t[t.length - 1].range[1]
            ]), ft = this.performAction.apply(D, [
              e,
              Nt,
              tt,
              x.yy,
              m[1],
              p,
              t
            ].concat(Dt)), typeof ft < "u")
              return ft;
            k && (c = c.slice(0, -1 * k * 2), p = p.slice(0, -1 * k), t = t.slice(0, -1 * k)), c.push(this.productions_[m[1]][0]), p.push(D.$), t.push(D._$), It = j[c[c.length - 2]][c[c.length - 1]], c.push(It);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, Ct = /* @__PURE__ */ (function() {
    var R = {
      EOF: 1,
      parseError: /* @__PURE__ */ u(function(a, c) {
        if (this.yy.parser)
          this.yy.parser.parseError(a, c);
        else
          throw new Error(a);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ u(function(n, a) {
        return this.yy = a || this.yy || {}, this._input = n, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ u(function() {
        var n = this._input[0];
        this.yytext += n, this.yyleng++, this.offset++, this.match += n, this.matched += n;
        var a = n.match(/(?:\r\n?|\n).*/g);
        return a ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), n;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ u(function(n) {
        var a = n.length, c = n.split(/(?:\r\n?|\n)/g);
        this._input = n + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - a), this.offset -= a;
        var r = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), c.length - 1 && (this.yylineno -= c.length - 1);
        var p = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: c ? (c.length === r.length ? this.yylloc.first_column : 0) + r[r.length - c.length].length - c[0].length : this.yylloc.first_column - a
        }, this.options.ranges && (this.yylloc.range = [p[0], p[0] + this.yyleng - a]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ u(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ u(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ u(function(n) {
        this.unput(this.match.slice(n));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ u(function() {
        var n = this.matched.substr(0, this.matched.length - this.match.length);
        return (n.length > 20 ? "..." : "") + n.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ u(function() {
        var n = this.match;
        return n.length < 20 && (n += this._input.substr(0, 20 - n.length)), (n.substr(0, 20) + (n.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ u(function() {
        var n = this.pastInput(), a = new Array(n.length + 1).join("-");
        return n + this.upcomingInput() + `
` + a + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ u(function(n, a) {
        var c, r, p;
        if (this.options.backtrack_lexer && (p = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (p.yylloc.range = this.yylloc.range.slice(0))), r = n[0].match(/(?:\r\n?|\n).*/g), r && (this.yylineno += r.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: r ? r[r.length - 1].length - r[r.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + n[0].length
        }, this.yytext += n[0], this.match += n[0], this.matches = n, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(n[0].length), this.matched += n[0], c = this.performAction.call(this, this.yy, this, a, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), c)
          return c;
        if (this._backtrack) {
          for (var t in p)
            this[t] = p[t];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ u(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var n, a, c, r;
        this._more || (this.yytext = "", this.match = "");
        for (var p = this._currentRules(), t = 0; t < p.length; t++)
          if (c = this._input.match(this.rules[p[t]]), c && (!a || c[0].length > a[0].length)) {
            if (a = c, r = t, this.options.backtrack_lexer) {
              if (n = this.test_match(c, p[t]), n !== !1)
                return n;
              if (this._backtrack) {
                a = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return a ? (n = this.test_match(a, p[r]), n !== !1 ? n : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ u(function() {
        var a = this.next();
        return a || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ u(function(a) {
        this.conditionStack.push(a);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ u(function() {
        var a = this.conditionStack.length - 1;
        return a > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ u(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ u(function(a) {
        return a = this.conditionStack.length - 1 - Math.abs(a || 0), a >= 0 ? this.conditionStack[a] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ u(function(a) {
        this.begin(a);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ u(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ u(function(a, c, r, p) {
        switch (r) {
          case 0:
            return this.begin("acc_title"), 24;
          case 1:
            return this.popState(), "acc_title_value";
          case 2:
            return this.begin("acc_descr"), 26;
          case 3:
            return this.popState(), "acc_descr_value";
          case 4:
            this.begin("acc_descr_multiline");
            break;
          case 5:
            this.popState();
            break;
          case 6:
            return "acc_descr_multiline_value";
          case 7:
            return 33;
          case 8:
            return 34;
          case 9:
            return 35;
          case 10:
            return 36;
          case 11:
            return 10;
          case 12:
            break;
          case 13:
            return 8;
          case 14:
            return 50;
          case 15:
            return 72;
          case 16:
            return 4;
          case 17:
            return this.begin("block"), 17;
          case 18:
            return 49;
          case 19:
            return 49;
          case 20:
            return 42;
          case 21:
            return 15;
          case 22:
            return 13;
          case 23:
            break;
          case 24:
            return 61;
          case 25:
            return 58;
          case 26:
            return 58;
          case 27:
            return 62;
          case 28:
            break;
          case 29:
            return this.popState(), 19;
          case 30:
            return c.yytext[0];
          case 31:
            return 20;
          case 32:
            return 21;
          case 33:
            return this.begin("style"), 44;
          case 34:
            return this.popState(), 10;
          case 35:
            break;
          case 36:
            return 13;
          case 37:
            return 42;
          case 38:
            return 49;
          case 39:
            return this.begin("style"), 37;
          case 40:
            return 43;
          case 41:
            return 65;
          case 42:
            return 67;
          case 43:
            return 67;
          case 44:
            return 67;
          case 45:
            return 65;
          case 46:
            return 65;
          case 47:
            return 66;
          case 48:
            return 66;
          case 49:
            return 66;
          case 50:
            return 66;
          case 51:
            return 66;
          case 52:
            return 67;
          case 53:
            return 66;
          case 54:
            return 67;
          case 55:
            return 68;
          case 56:
            return 68;
          case 57:
            return 51;
          case 58:
            return 68;
          case 59:
            return 68;
          case 60:
            return 52;
          case 61:
            return 48;
          case 62:
            return 68;
          case 63:
            return 65;
          case 64:
            return 66;
          case 65:
            return 67;
          case 66:
            return 69;
          case 67:
            return 70;
          case 68:
            return 71;
          case 69:
            return 71;
          case 70:
            return 70;
          case 71:
            return 70;
          case 72:
            return 70;
          case 73:
            return 41;
          case 74:
            return 47;
          case 75:
            return 40;
          case 76:
            return c.yytext[0];
          case 77:
            return 6;
        }
      }, "anonymous"),
      rules: [/^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:.*direction\s+TB[^\n]*)/i, /^(?:.*direction\s+BT[^\n]*)/i, /^(?:.*direction\s+RL[^\n]*)/i, /^(?:.*direction\s+LR[^\n]*)/i, /^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:[\s]+)/i, /^(?:"[^"%\r\n\v\b\\]+")/i, /^(?:"[^"]*")/i, /^(?:erDiagram\b)/i, /^(?:\{)/i, /^(?:#)/i, /^(?:#)/i, /^(?:,)/i, /^(?::::)/i, /^(?::)/i, /^(?:\s+)/i, /^(?:\b((?:PK)|(?:FK)|(?:UK))\b)/i, /^(?:([^\s]*)[~].*[~]([^\s]*))/i, /^(?:([\*A-Za-z_\u00C0-\uFFFF][A-Za-z0-9\-\_\[\]\(\)\u00C0-\uFFFF\*]*))/i, /^(?:"[^"]*")/i, /^(?:[\n]+)/i, /^(?:\})/i, /^(?:.)/i, /^(?:\[)/i, /^(?:\])/i, /^(?:style\b)/i, /^(?:[\n]+)/i, /^(?:\s+)/i, /^(?::)/i, /^(?:,)/i, /^(?:#)/i, /^(?:classDef\b)/i, /^(?:class\b)/i, /^(?:one or zero\b)/i, /^(?:one or more\b)/i, /^(?:one or many\b)/i, /^(?:1\+)/i, /^(?:\|o\b)/i, /^(?:zero or one\b)/i, /^(?:zero or more\b)/i, /^(?:zero or many\b)/i, /^(?:0\+)/i, /^(?:\}o\b)/i, /^(?:many\(0\))/i, /^(?:many\(1\))/i, /^(?:many\b)/i, /^(?:\}\|)/i, /^(?:one\b)/i, /^(?:only one\b)/i, /^(?:[0-9]+\.[0-9]+)/i, /^(?:1(?=\s+[A-Za-z_"']))/i, /^(?:1(?=(--|\.\.|\.-|-\.)))/i, /^(?:1\b)/i, /^(?:[0-9]+)/i, /^(?:\|\|)/i, /^(?:o\|)/i, /^(?:o\{)/i, /^(?:\|\{)/i, /^(?:u(?=[\.\-\|]))/i, /^(?:\.\.)/i, /^(?:--)/i, /^(?:to\b)/i, /^(?:optionally to\b)/i, /^(?:\.-)/i, /^(?:-\.)/i, /^(?:([^\x00-\x7F]|\w|-|\*)+)/i, /^(?:;)/i, /^(?:([^\x00-\x7F]|\w|-|\*|\.)+)/i, /^(?:.)/i, /^(?:$)/i],
      conditions: { style: { rules: [34, 35, 36, 37, 38, 73, 74], inclusive: !1 }, acc_descr_multiline: { rules: [5, 6], inclusive: !1 }, acc_descr: { rules: [3], inclusive: !1 }, acc_title: { rules: [1], inclusive: !1 }, block: { rules: [23, 24, 25, 26, 27, 28, 29, 30], inclusive: !1 }, INITIAL: { rules: [0, 2, 4, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 31, 32, 33, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 75, 76, 77], inclusive: !0 } }
    };
    return R;
  })();
  ut.lexer = Ct;
  function $() {
    this.yy = {};
  }
  return u($, "Parser"), $.prototype = ut, ut.Parser = $, new $();
})();
_t.parser = _t;
var Jt = _t, w, $t = (w = class {
  constructor() {
    this.entities = /* @__PURE__ */ new Map(), this.relationships = [], this.classes = /* @__PURE__ */ new Map(), this.direction = "TB", this.Cardinality = {
      ZERO_OR_ONE: "ZERO_OR_ONE",
      ZERO_OR_MORE: "ZERO_OR_MORE",
      ONE_OR_MORE: "ONE_OR_MORE",
      ONLY_ONE: "ONLY_ONE",
      MD_PARENT: "MD_PARENT"
    }, this.Identification = {
      NON_IDENTIFYING: "NON_IDENTIFYING",
      IDENTIFYING: "IDENTIFYING"
    }, this.setAccTitle = Bt, this.getAccTitle = Ft, this.setAccDescription = Yt, this.getAccDescription = Pt, this.setDiagramTitle = zt, this.getDiagramTitle = Gt, this.getConfig = /* @__PURE__ */ u(() => it().er, "getConfig"), this.clear(), this.addEntity = this.addEntity.bind(this), this.addAttributes = this.addAttributes.bind(this), this.addRelationship = this.addRelationship.bind(this), this.setDirection = this.setDirection.bind(this), this.addCssStyles = this.addCssStyles.bind(this), this.addClass = this.addClass.bind(this), this.setClass = this.setClass.bind(this), this.setAccTitle = this.setAccTitle.bind(this), this.setAccDescription = this.setAccDescription.bind(this);
  }
  /**
   * Add entity
   * @param name - The name of the entity
   * @param alias - The alias of the entity
   */
  addEntity(i, l = "") {
    return this.entities.has(i) ? !this.entities.get(i)?.alias && l && (this.entities.get(i).alias = l, L.info(`Add alias '${l}' to entity '${i}'`)) : (this.entities.set(i, {
      id: `entity-${i}-${this.entities.size}`,
      label: i,
      attributes: [],
      alias: l,
      shape: "erBox",
      look: it().look ?? "default",
      cssClasses: "default",
      cssStyles: [],
      labelType: "markdown"
    }), L.info("Added new entity :", i)), this.entities.get(i);
  }
  getEntity(i) {
    return this.entities.get(i);
  }
  getEntities() {
    return this.entities;
  }
  getClasses() {
    return this.classes;
  }
  addAttributes(i, l) {
    const d = this.addEntity(i);
    let o;
    for (o = l.length - 1; o >= 0; o--)
      l[o].keys || (l[o].keys = []), l[o].comment || (l[o].comment = ""), d.attributes.push(l[o]), L.debug("Added attribute ", l[o].name);
  }
  /**
   * Add a relationship
   *
   * @param entA - The first entity in the relationship
   * @param rolA - The role played by the first entity in relation to the second
   * @param entB - The second entity in the relationship
   * @param rSpec - The details of the relationship between the two entities
   */
  addRelationship(i, l, d, o) {
    const h = this.entities.get(i), y = this.entities.get(d);
    if (!h || !y)
      return;
    const _ = {
      entityA: h.id,
      roleA: l,
      entityB: y.id,
      relSpec: o
    };
    this.relationships.push(_), L.debug("Added new relationship :", _);
  }
  getRelationships() {
    return this.relationships;
  }
  getDirection() {
    return this.direction;
  }
  setDirection(i) {
    this.direction = i;
  }
  getCompiledStyles(i) {
    let l = [];
    for (const d of i) {
      const o = this.classes.get(d);
      o?.styles && (l = [...l, ...o.styles ?? []].map((h) => h.trim())), o?.textStyles && (l = [...l, ...o.textStyles ?? []].map((h) => h.trim()));
    }
    return l;
  }
  addCssStyles(i, l) {
    for (const d of i) {
      const o = this.entities.get(d);
      if (!l || !o)
        return;
      for (const h of l)
        o.cssStyles.push(h);
    }
  }
  addClass(i, l) {
    i.forEach((d) => {
      let o = this.classes.get(d);
      o === void 0 && (o = { id: d, styles: [], textStyles: [] }, this.classes.set(d, o)), l && l.forEach(function(h) {
        if (/color/.exec(h)) {
          const y = h.replace("fill", "bgFill");
          o.textStyles.push(y);
        }
        o.styles.push(h);
      });
    });
  }
  setClass(i, l) {
    for (const d of i) {
      const o = this.entities.get(d);
      if (o)
        for (const h of l)
          o.cssClasses += " " + h;
    }
  }
  clear() {
    this.entities = /* @__PURE__ */ new Map(), this.classes = /* @__PURE__ */ new Map(), this.relationships = [], Kt();
  }
  getData() {
    const i = [], l = [], d = it();
    for (const h of this.entities.keys()) {
      const y = this.entities.get(h);
      y && (y.cssCompiledStyles = this.getCompiledStyles(y.cssClasses.split(" ")), i.push(y));
    }
    let o = 0;
    for (const h of this.relationships) {
      const y = {
        id: Ut(h.entityA, h.entityB, {
          prefix: "id",
          counter: o++
        }),
        type: "normal",
        curve: "basis",
        start: h.entityA,
        end: h.entityB,
        label: h.roleA,
        labelpos: "c",
        thickness: "normal",
        classes: "relationshipLine",
        arrowTypeStart: h.relSpec.cardB.toLowerCase(),
        arrowTypeEnd: h.relSpec.cardA.toLowerCase(),
        pattern: h.relSpec.relType == "IDENTIFYING" ? "solid" : "dashed",
        look: d.look,
        labelType: "markdown"
      };
      l.push(y);
    }
    return { nodes: i, edges: l, other: {}, config: d, direction: "TB" };
  }
}, u(w, "ErDB"), w), xt = {};
jt(xt, {
  draw: () => te
});
var te = /* @__PURE__ */ u(async function(s, i, l, d) {
  L.info("REF0:"), L.info("Drawing er diagram (unified)", i);
  const { securityLevel: o, er: h, layout: y } = it(), _ = d.db.getData(), E = Vt(i, o);
  _.type = d.type, _.layoutAlgorithm = Wt(y), _.config.flowchart.nodeSpacing = h?.nodeSpacing || 140, _.config.flowchart.rankSpacing = h?.rankSpacing || 80, _.direction = d.db.getDirection(), _.markers = ["only_one", "zero_or_one", "one_or_more", "zero_or_more"], _.diagramId = i, await Qt(_, E), _.layoutAlgorithm === "elk" && E.select(".edges").lower();
  const V = E.selectAll('[id*="-background"]');
  Array.from(V).length > 0 && V.each(function() {
    const S = Xt(this), Q = S.attr("id").replace("-background", ""), T = E.select(`#${CSS.escape(Q)}`);
    if (!T.empty()) {
      const I = T.attr("transform");
      S.attr("transform", I);
    }
  });
  const W = 8;
  qt.insertTitle(
    E,
    "erDiagramTitleText",
    h?.titleTopMargin ?? 25,
    d.db.getDiagramTitle()
  ), Mt(E, W, "erDiagram", h?.useMaxWidth ?? !0);
}, "draw"), ee = /* @__PURE__ */ u((s, i) => {
  const l = Ht, d = l(s, "r"), o = l(s, "g"), h = l(s, "b");
  return Zt(d, o, h, i);
}, "fade"), se = /* @__PURE__ */ u((s) => `
  .entityBox {
    fill: ${s.mainBkg};
    stroke: ${s.nodeBorder};
  }

  .relationshipLabelBox {
    fill: ${s.tertiaryColor};
    opacity: 0.7;
    background-color: ${s.tertiaryColor};
      rect {
        opacity: 0.5;
      }
  }

  .labelBkg {
    background-color: ${ee(s.tertiaryColor, 0.5)};
  }

  .edgeLabel .label {
    fill: ${s.nodeBorder};
    font-size: 14px;
  }

  .label {
    font-family: ${s.fontFamily};
    color: ${s.nodeTextColor || s.textColor};
  }

  .edge-pattern-dashed {
    stroke-dasharray: 8,8;
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon
  {
    fill: ${s.mainBkg};
    stroke: ${s.nodeBorder};
    stroke-width: 1px;
  }

  .relationshipLine {
    stroke: ${s.lineColor};
    stroke-width: 1;
    fill: none;
  }

  .marker {
    fill: none !important;
    stroke: ${s.lineColor} !important;
    stroke-width: 1;
  }
    
  .edgeLabel {
    background-color: ${s.edgeLabelBackground};
  }
  .edgeLabel .label rect {
    fill: ${s.edgeLabelBackground};
  }
  .edgeLabel .label text {
    fill: ${s.textColor};
  }
`, "getStyles"), ie = se, le = {
  parser: Jt,
  get db() {
    return new $t();
  },
  renderer: xt,
  styles: ie
};
export {
  le as diagram
};
