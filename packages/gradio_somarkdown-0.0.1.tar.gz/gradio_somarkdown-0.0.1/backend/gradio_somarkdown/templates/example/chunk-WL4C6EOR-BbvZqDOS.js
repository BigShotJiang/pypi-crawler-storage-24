import { g as et } from "./chunk-FMBD7UC4-BE_kxjEu.js";
import { c as tt } from "./chunk-JSJVCQXG-y0Y2vgVV.js";
import { g as st } from "./chunk-55IACEB6-362b7Ann.js";
import { s as it } from "./chunk-KX2RTZJC-DDLAkZGm.js";
import { _ as A, l as Oe, c as F, o as at, r as rt, u as we, d as de, y as nt, b as ut, a as lt, s as ot, g as ct, p as ht, q as dt, k as v, z as pt, x as At, i as ft, Q as G } from "./mermaid.core-CbLi0pBF.js";
var Ve = (function() {
  var s = /* @__PURE__ */ A(function(O, o, c, d) {
    for (c = c || {}, d = O.length; d--; c[O[d]] = o) ;
    return c;
  }, "o"), i = [1, 18], r = [1, 19], u = [1, 20], l = [1, 41], a = [1, 42], p = [1, 26], f = [1, 24], C = [1, 25], D = [1, 32], B = [1, 33], Ae = [1, 34], m = [1, 45], fe = [1, 35], ge = [1, 36], Ce = [1, 37], me = [1, 38], be = [1, 27], Ee = [1, 28], ye = [1, 29], ke = [1, 30], Te = [1, 31], b = [1, 44], E = [1, 46], y = [1, 43], k = [1, 47], De = [1, 9], h = [1, 8, 9], ee = [1, 58], te = [1, 59], se = [1, 60], ie = [1, 61], ae = [1, 62], Fe = [1, 63], Be = [1, 64], I = [1, 8, 9, 41], Me = [1, 76], P = [1, 8, 9, 12, 13, 22, 39, 41, 44, 68, 69, 70, 71, 72, 73, 74, 79, 81], re = [1, 8, 9, 12, 13, 18, 20, 22, 39, 41, 44, 50, 60, 68, 69, 70, 71, 72, 73, 74, 79, 81, 86, 100, 102, 103], ne = [13, 60, 86, 100, 102, 103], Y = [13, 60, 73, 74, 86, 100, 102, 103], Pe = [13, 60, 68, 69, 70, 71, 72, 86, 100, 102, 103], _e = [1, 101], K = [1, 118], Q = [1, 114], W = [1, 110], j = [1, 116], X = [1, 111], q = [1, 112], H = [1, 113], J = [1, 115], Z = [1, 117], Re = [22, 48, 60, 61, 82, 86, 87, 88, 89, 90], Se = [1, 8, 9, 39, 41, 44], ue = [1, 8, 9, 22], Ge = [1, 147], Ue = [1, 8, 9, 61], x = [1, 8, 9, 22, 48, 60, 61, 82, 86, 87, 88, 89, 90], Ne = {
    trace: /* @__PURE__ */ A(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, mermaidDoc: 4, statements: 5, graphConfig: 6, CLASS_DIAGRAM: 7, NEWLINE: 8, EOF: 9, statement: 10, classLabel: 11, SQS: 12, STR: 13, SQE: 14, namespaceName: 15, alphaNumToken: 16, classLiteralName: 17, DOT: 18, className: 19, GENERICTYPE: 20, relationStatement: 21, LABEL: 22, namespaceStatement: 23, classStatement: 24, memberStatement: 25, annotationStatement: 26, clickStatement: 27, styleStatement: 28, cssClassStatement: 29, noteStatement: 30, classDefStatement: 31, direction: 32, acc_title: 33, acc_title_value: 34, acc_descr: 35, acc_descr_value: 36, acc_descr_multiline_value: 37, namespaceIdentifier: 38, STRUCT_START: 39, classStatements: 40, STRUCT_STOP: 41, NAMESPACE: 42, classIdentifier: 43, STYLE_SEPARATOR: 44, members: 45, CLASS: 46, emptyBody: 47, SPACE: 48, ANNOTATION_START: 49, ANNOTATION_END: 50, MEMBER: 51, SEPARATOR: 52, relation: 53, NOTE_FOR: 54, noteText: 55, NOTE: 56, CLASSDEF: 57, classList: 58, stylesOpt: 59, ALPHA: 60, COMMA: 61, direction_tb: 62, direction_bt: 63, direction_rl: 64, direction_lr: 65, relationType: 66, lineType: 67, AGGREGATION: 68, EXTENSION: 69, COMPOSITION: 70, DEPENDENCY: 71, LOLLIPOP: 72, LINE: 73, DOTTED_LINE: 74, CALLBACK: 75, LINK: 76, LINK_TARGET: 77, CLICK: 78, CALLBACK_NAME: 79, CALLBACK_ARGS: 80, HREF: 81, STYLE: 82, CSSCLASS: 83, style: 84, styleComponent: 85, NUM: 86, COLON: 87, UNIT: 88, BRKT: 89, PCT: 90, commentToken: 91, textToken: 92, graphCodeTokens: 93, textNoTagsToken: 94, TAGSTART: 95, TAGEND: 96, "==": 97, "--": 98, DEFAULT: 99, MINUS: 100, keywords: 101, UNICODE_TEXT: 102, BQUOTE_STR: 103, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 7: "CLASS_DIAGRAM", 8: "NEWLINE", 9: "EOF", 12: "SQS", 13: "STR", 14: "SQE", 18: "DOT", 20: "GENERICTYPE", 22: "LABEL", 33: "acc_title", 34: "acc_title_value", 35: "acc_descr", 36: "acc_descr_value", 37: "acc_descr_multiline_value", 39: "STRUCT_START", 41: "STRUCT_STOP", 42: "NAMESPACE", 44: "STYLE_SEPARATOR", 46: "CLASS", 48: "SPACE", 49: "ANNOTATION_START", 50: "ANNOTATION_END", 51: "MEMBER", 52: "SEPARATOR", 54: "NOTE_FOR", 56: "NOTE", 57: "CLASSDEF", 60: "ALPHA", 61: "COMMA", 62: "direction_tb", 63: "direction_bt", 64: "direction_rl", 65: "direction_lr", 68: "AGGREGATION", 69: "EXTENSION", 70: "COMPOSITION", 71: "DEPENDENCY", 72: "LOLLIPOP", 73: "LINE", 74: "DOTTED_LINE", 75: "CALLBACK", 76: "LINK", 77: "LINK_TARGET", 78: "CLICK", 79: "CALLBACK_NAME", 80: "CALLBACK_ARGS", 81: "HREF", 82: "STYLE", 83: "CSSCLASS", 86: "NUM", 87: "COLON", 88: "UNIT", 89: "BRKT", 90: "PCT", 93: "graphCodeTokens", 95: "TAGSTART", 96: "TAGEND", 97: "==", 98: "--", 99: "DEFAULT", 100: "MINUS", 101: "keywords", 102: "UNICODE_TEXT", 103: "BQUOTE_STR" },
    productions_: [0, [3, 1], [3, 1], [4, 1], [6, 4], [5, 1], [5, 2], [5, 3], [11, 3], [15, 1], [15, 1], [15, 3], [15, 2], [19, 1], [19, 3], [19, 1], [19, 2], [19, 2], [19, 2], [10, 1], [10, 2], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [10, 1], [23, 4], [23, 5], [38, 2], [40, 1], [40, 2], [40, 3], [40, 1], [40, 2], [40, 3], [24, 1], [24, 3], [24, 4], [24, 3], [24, 6], [43, 2], [43, 3], [47, 0], [47, 2], [47, 2], [26, 4], [45, 1], [45, 2], [25, 1], [25, 2], [25, 1], [25, 1], [21, 3], [21, 4], [21, 4], [21, 5], [30, 3], [30, 2], [31, 3], [58, 1], [58, 3], [32, 1], [32, 1], [32, 1], [32, 1], [53, 3], [53, 2], [53, 2], [53, 1], [66, 1], [66, 1], [66, 1], [66, 1], [66, 1], [67, 1], [67, 1], [27, 3], [27, 4], [27, 3], [27, 4], [27, 4], [27, 5], [27, 3], [27, 4], [27, 4], [27, 5], [27, 4], [27, 5], [27, 5], [27, 6], [28, 3], [29, 3], [59, 1], [59, 3], [84, 1], [84, 2], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [91, 1], [91, 1], [92, 1], [92, 1], [92, 1], [92, 1], [92, 1], [92, 1], [92, 1], [94, 1], [94, 1], [94, 1], [94, 1], [16, 1], [16, 1], [16, 1], [16, 1], [17, 1], [55, 1]],
    performAction: /* @__PURE__ */ A(function(o, c, d, n, g, e, $) {
      var t = e.length - 1;
      switch (g) {
        case 8:
          this.$ = e[t - 1];
          break;
        case 9:
        case 10:
        case 13:
        case 15:
          this.$ = e[t];
          break;
        case 11:
        case 14:
          this.$ = e[t - 2] + "." + e[t];
          break;
        case 12:
        case 16:
          this.$ = e[t - 1] + e[t];
          break;
        case 17:
        case 18:
          this.$ = e[t - 1] + "~" + e[t] + "~";
          break;
        case 19:
          n.addRelation(e[t]);
          break;
        case 20:
          e[t - 1].title = n.cleanupLabel(e[t]), n.addRelation(e[t - 1]);
          break;
        case 31:
          this.$ = e[t].trim(), n.setAccTitle(this.$);
          break;
        case 32:
        case 33:
          this.$ = e[t].trim(), n.setAccDescription(this.$);
          break;
        case 34:
          n.addClassesToNamespace(e[t - 3], e[t - 1][0], e[t - 1][1]);
          break;
        case 35:
          n.addClassesToNamespace(e[t - 4], e[t - 1][0], e[t - 1][1]);
          break;
        case 36:
          this.$ = e[t], n.addNamespace(e[t]);
          break;
        case 37:
          this.$ = [[e[t]], []];
          break;
        case 38:
          this.$ = [[e[t - 1]], []];
          break;
        case 39:
          e[t][0].unshift(e[t - 2]), this.$ = e[t];
          break;
        case 40:
          this.$ = [[], [e[t]]];
          break;
        case 41:
          this.$ = [[], [e[t - 1]]];
          break;
        case 42:
          e[t][1].unshift(e[t - 2]), this.$ = e[t];
          break;
        case 44:
          n.setCssClass(e[t - 2], e[t]);
          break;
        case 45:
          n.addMembers(e[t - 3], e[t - 1]);
          break;
        case 47:
          n.setCssClass(e[t - 5], e[t - 3]), n.addMembers(e[t - 5], e[t - 1]);
          break;
        case 48:
          this.$ = e[t], n.addClass(e[t]);
          break;
        case 49:
          this.$ = e[t - 1], n.addClass(e[t - 1]), n.setClassLabel(e[t - 1], e[t]);
          break;
        case 53:
          n.addAnnotation(e[t], e[t - 2]);
          break;
        case 54:
        case 67:
          this.$ = [e[t]];
          break;
        case 55:
          e[t].push(e[t - 1]), this.$ = e[t];
          break;
        case 56:
          break;
        case 57:
          n.addMember(e[t - 1], n.cleanupLabel(e[t]));
          break;
        case 58:
          break;
        case 59:
          break;
        case 60:
          this.$ = { id1: e[t - 2], id2: e[t], relation: e[t - 1], relationTitle1: "none", relationTitle2: "none" };
          break;
        case 61:
          this.$ = { id1: e[t - 3], id2: e[t], relation: e[t - 1], relationTitle1: e[t - 2], relationTitle2: "none" };
          break;
        case 62:
          this.$ = { id1: e[t - 3], id2: e[t], relation: e[t - 2], relationTitle1: "none", relationTitle2: e[t - 1] };
          break;
        case 63:
          this.$ = { id1: e[t - 4], id2: e[t], relation: e[t - 2], relationTitle1: e[t - 3], relationTitle2: e[t - 1] };
          break;
        case 64:
          this.$ = n.addNote(e[t], e[t - 1]);
          break;
        case 65:
          this.$ = n.addNote(e[t]);
          break;
        case 66:
          this.$ = e[t - 2], n.defineClass(e[t - 1], e[t]);
          break;
        case 68:
          this.$ = e[t - 2].concat([e[t]]);
          break;
        case 69:
          n.setDirection("TB");
          break;
        case 70:
          n.setDirection("BT");
          break;
        case 71:
          n.setDirection("RL");
          break;
        case 72:
          n.setDirection("LR");
          break;
        case 73:
          this.$ = { type1: e[t - 2], type2: e[t], lineType: e[t - 1] };
          break;
        case 74:
          this.$ = { type1: "none", type2: e[t], lineType: e[t - 1] };
          break;
        case 75:
          this.$ = { type1: e[t - 1], type2: "none", lineType: e[t] };
          break;
        case 76:
          this.$ = { type1: "none", type2: "none", lineType: e[t] };
          break;
        case 77:
          this.$ = n.relationType.AGGREGATION;
          break;
        case 78:
          this.$ = n.relationType.EXTENSION;
          break;
        case 79:
          this.$ = n.relationType.COMPOSITION;
          break;
        case 80:
          this.$ = n.relationType.DEPENDENCY;
          break;
        case 81:
          this.$ = n.relationType.LOLLIPOP;
          break;
        case 82:
          this.$ = n.lineType.LINE;
          break;
        case 83:
          this.$ = n.lineType.DOTTED_LINE;
          break;
        case 84:
        case 90:
          this.$ = e[t - 2], n.setClickEvent(e[t - 1], e[t]);
          break;
        case 85:
        case 91:
          this.$ = e[t - 3], n.setClickEvent(e[t - 2], e[t - 1]), n.setTooltip(e[t - 2], e[t]);
          break;
        case 86:
          this.$ = e[t - 2], n.setLink(e[t - 1], e[t]);
          break;
        case 87:
          this.$ = e[t - 3], n.setLink(e[t - 2], e[t - 1], e[t]);
          break;
        case 88:
          this.$ = e[t - 3], n.setLink(e[t - 2], e[t - 1]), n.setTooltip(e[t - 2], e[t]);
          break;
        case 89:
          this.$ = e[t - 4], n.setLink(e[t - 3], e[t - 2], e[t]), n.setTooltip(e[t - 3], e[t - 1]);
          break;
        case 92:
          this.$ = e[t - 3], n.setClickEvent(e[t - 2], e[t - 1], e[t]);
          break;
        case 93:
          this.$ = e[t - 4], n.setClickEvent(e[t - 3], e[t - 2], e[t - 1]), n.setTooltip(e[t - 3], e[t]);
          break;
        case 94:
          this.$ = e[t - 3], n.setLink(e[t - 2], e[t]);
          break;
        case 95:
          this.$ = e[t - 4], n.setLink(e[t - 3], e[t - 1], e[t]);
          break;
        case 96:
          this.$ = e[t - 4], n.setLink(e[t - 3], e[t - 1]), n.setTooltip(e[t - 3], e[t]);
          break;
        case 97:
          this.$ = e[t - 5], n.setLink(e[t - 4], e[t - 2], e[t]), n.setTooltip(e[t - 4], e[t - 1]);
          break;
        case 98:
          this.$ = e[t - 2], n.setCssStyle(e[t - 1], e[t]);
          break;
        case 99:
          n.setCssClass(e[t - 1], e[t]);
          break;
        case 100:
          this.$ = [e[t]];
          break;
        case 101:
          e[t - 2].push(e[t]), this.$ = e[t - 2];
          break;
        case 103:
          this.$ = e[t - 1] + e[t];
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: 2, 5: 3, 6: 4, 7: [1, 6], 10: 5, 16: 39, 17: 40, 19: 21, 21: 7, 23: 8, 24: 9, 25: 10, 26: 11, 27: 12, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 33: i, 35: r, 37: u, 38: 22, 42: l, 43: 23, 46: a, 49: p, 51: f, 52: C, 54: D, 56: B, 57: Ae, 60: m, 62: fe, 63: ge, 64: Ce, 65: me, 75: be, 76: Ee, 78: ye, 82: ke, 83: Te, 86: b, 100: E, 102: y, 103: k }, { 1: [3] }, { 1: [2, 1] }, { 1: [2, 2] }, { 1: [2, 3] }, s(De, [2, 5], { 8: [1, 48] }), { 8: [1, 49] }, s(h, [2, 19], { 22: [1, 50] }), s(h, [2, 21]), s(h, [2, 22]), s(h, [2, 23]), s(h, [2, 24]), s(h, [2, 25]), s(h, [2, 26]), s(h, [2, 27]), s(h, [2, 28]), s(h, [2, 29]), s(h, [2, 30]), { 34: [1, 51] }, { 36: [1, 52] }, s(h, [2, 33]), s(h, [2, 56], { 53: 53, 66: 56, 67: 57, 13: [1, 54], 22: [1, 55], 68: ee, 69: te, 70: se, 71: ie, 72: ae, 73: Fe, 74: Be }), { 39: [1, 65] }, s(I, [2, 43], { 39: [1, 67], 44: [1, 66] }), s(h, [2, 58]), s(h, [2, 59]), { 16: 68, 60: m, 86: b, 100: E, 102: y }, { 16: 39, 17: 40, 19: 69, 60: m, 86: b, 100: E, 102: y, 103: k }, { 16: 39, 17: 40, 19: 70, 60: m, 86: b, 100: E, 102: y, 103: k }, { 16: 39, 17: 40, 19: 71, 60: m, 86: b, 100: E, 102: y, 103: k }, { 60: [1, 72] }, { 13: [1, 73] }, { 16: 39, 17: 40, 19: 74, 60: m, 86: b, 100: E, 102: y, 103: k }, { 13: Me, 55: 75 }, { 58: 77, 60: [1, 78] }, s(h, [2, 69]), s(h, [2, 70]), s(h, [2, 71]), s(h, [2, 72]), s(P, [2, 13], { 16: 39, 17: 40, 19: 80, 18: [1, 79], 20: [1, 81], 60: m, 86: b, 100: E, 102: y, 103: k }), s(P, [2, 15], { 20: [1, 82] }), { 15: 83, 16: 84, 17: 85, 60: m, 86: b, 100: E, 102: y, 103: k }, { 16: 39, 17: 40, 19: 86, 60: m, 86: b, 100: E, 102: y, 103: k }, s(re, [2, 126]), s(re, [2, 127]), s(re, [2, 128]), s(re, [2, 129]), s([1, 8, 9, 12, 13, 20, 22, 39, 41, 44, 68, 69, 70, 71, 72, 73, 74, 79, 81], [2, 130]), s(De, [2, 6], { 10: 5, 21: 7, 23: 8, 24: 9, 25: 10, 26: 11, 27: 12, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 19: 21, 38: 22, 43: 23, 16: 39, 17: 40, 5: 87, 33: i, 35: r, 37: u, 42: l, 46: a, 49: p, 51: f, 52: C, 54: D, 56: B, 57: Ae, 60: m, 62: fe, 63: ge, 64: Ce, 65: me, 75: be, 76: Ee, 78: ye, 82: ke, 83: Te, 86: b, 100: E, 102: y, 103: k }), { 5: 88, 10: 5, 16: 39, 17: 40, 19: 21, 21: 7, 23: 8, 24: 9, 25: 10, 26: 11, 27: 12, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 33: i, 35: r, 37: u, 38: 22, 42: l, 43: 23, 46: a, 49: p, 51: f, 52: C, 54: D, 56: B, 57: Ae, 60: m, 62: fe, 63: ge, 64: Ce, 65: me, 75: be, 76: Ee, 78: ye, 82: ke, 83: Te, 86: b, 100: E, 102: y, 103: k }, s(h, [2, 20]), s(h, [2, 31]), s(h, [2, 32]), { 13: [1, 90], 16: 39, 17: 40, 19: 89, 60: m, 86: b, 100: E, 102: y, 103: k }, { 53: 91, 66: 56, 67: 57, 68: ee, 69: te, 70: se, 71: ie, 72: ae, 73: Fe, 74: Be }, s(h, [2, 57]), { 67: 92, 73: Fe, 74: Be }, s(ne, [2, 76], { 66: 93, 68: ee, 69: te, 70: se, 71: ie, 72: ae }), s(Y, [2, 77]), s(Y, [2, 78]), s(Y, [2, 79]), s(Y, [2, 80]), s(Y, [2, 81]), s(Pe, [2, 82]), s(Pe, [2, 83]), { 8: [1, 95], 24: 96, 30: 97, 40: 94, 43: 23, 46: a, 54: D, 56: B }, { 16: 98, 60: m, 86: b, 100: E, 102: y }, { 41: [1, 100], 45: 99, 51: _e }, { 50: [1, 102] }, { 13: [1, 103] }, { 13: [1, 104] }, { 79: [1, 105], 81: [1, 106] }, { 22: K, 48: Q, 59: 107, 60: W, 82: j, 84: 108, 85: 109, 86: X, 87: q, 88: H, 89: J, 90: Z }, { 60: [1, 119] }, { 13: Me, 55: 120 }, s(I, [2, 65]), s(I, [2, 131]), { 22: K, 48: Q, 59: 121, 60: W, 61: [1, 122], 82: j, 84: 108, 85: 109, 86: X, 87: q, 88: H, 89: J, 90: Z }, s(Re, [2, 67]), { 16: 39, 17: 40, 19: 123, 60: m, 86: b, 100: E, 102: y, 103: k }, s(P, [2, 16]), s(P, [2, 17]), s(P, [2, 18]), { 39: [2, 36] }, { 15: 125, 16: 84, 17: 85, 18: [1, 124], 39: [2, 9], 60: m, 86: b, 100: E, 102: y, 103: k }, { 39: [2, 10] }, s(Se, [2, 48], { 11: 126, 12: [1, 127] }), s(De, [2, 7]), { 9: [1, 128] }, s(ue, [2, 60]), { 16: 39, 17: 40, 19: 129, 60: m, 86: b, 100: E, 102: y, 103: k }, { 13: [1, 131], 16: 39, 17: 40, 19: 130, 60: m, 86: b, 100: E, 102: y, 103: k }, s(ne, [2, 75], { 66: 132, 68: ee, 69: te, 70: se, 71: ie, 72: ae }), s(ne, [2, 74]), { 41: [1, 133] }, { 24: 96, 30: 97, 40: 134, 43: 23, 46: a, 54: D, 56: B }, { 8: [1, 135], 41: [2, 37] }, { 8: [1, 136], 41: [2, 40] }, s(I, [2, 44], { 39: [1, 137] }), { 41: [1, 138] }, s(I, [2, 46]), { 41: [2, 54], 45: 139, 51: _e }, { 16: 39, 17: 40, 19: 140, 60: m, 86: b, 100: E, 102: y, 103: k }, s(h, [2, 84], { 13: [1, 141] }), s(h, [2, 86], { 13: [1, 143], 77: [1, 142] }), s(h, [2, 90], { 13: [1, 144], 80: [1, 145] }), { 13: [1, 146] }, s(h, [2, 98], { 61: Ge }), s(Ue, [2, 100], { 85: 148, 22: K, 48: Q, 60: W, 82: j, 86: X, 87: q, 88: H, 89: J, 90: Z }), s(x, [2, 102]), s(x, [2, 104]), s(x, [2, 105]), s(x, [2, 106]), s(x, [2, 107]), s(x, [2, 108]), s(x, [2, 109]), s(x, [2, 110]), s(x, [2, 111]), s(x, [2, 112]), s(h, [2, 99]), s(I, [2, 64]), s(h, [2, 66], { 61: Ge }), { 60: [1, 149] }, s(P, [2, 14]), { 15: 150, 16: 84, 17: 85, 60: m, 86: b, 100: E, 102: y, 103: k }, { 39: [2, 12] }, s(Se, [2, 49]), { 13: [1, 151] }, { 1: [2, 4] }, s(ue, [2, 62]), s(ue, [2, 61]), { 16: 39, 17: 40, 19: 152, 60: m, 86: b, 100: E, 102: y, 103: k }, s(ne, [2, 73]), s(h, [2, 34]), { 41: [1, 153] }, { 24: 96, 30: 97, 40: 154, 41: [2, 38], 43: 23, 46: a, 54: D, 56: B }, { 24: 96, 30: 97, 40: 155, 41: [2, 41], 43: 23, 46: a, 54: D, 56: B }, { 45: 156, 51: _e }, s(I, [2, 45]), { 41: [2, 55] }, s(h, [2, 53]), s(h, [2, 85]), s(h, [2, 87]), s(h, [2, 88], { 77: [1, 157] }), s(h, [2, 91]), s(h, [2, 92], { 13: [1, 158] }), s(h, [2, 94], { 13: [1, 160], 77: [1, 159] }), { 22: K, 48: Q, 60: W, 82: j, 84: 161, 85: 109, 86: X, 87: q, 88: H, 89: J, 90: Z }, s(x, [2, 103]), s(Re, [2, 68]), { 39: [2, 11] }, { 14: [1, 162] }, s(ue, [2, 63]), s(h, [2, 35]), { 41: [2, 39] }, { 41: [2, 42] }, { 41: [1, 163] }, s(h, [2, 89]), s(h, [2, 93]), s(h, [2, 95]), s(h, [2, 96], { 77: [1, 164] }), s(Ue, [2, 101], { 85: 148, 22: K, 48: Q, 60: W, 82: j, 86: X, 87: q, 88: H, 89: J, 90: Z }), s(Se, [2, 8]), s(I, [2, 47]), s(h, [2, 97])],
    defaultActions: { 2: [2, 1], 3: [2, 2], 4: [2, 3], 83: [2, 36], 85: [2, 10], 125: [2, 12], 128: [2, 4], 139: [2, 55], 150: [2, 11], 154: [2, 39], 155: [2, 42] },
    parseError: /* @__PURE__ */ A(function(o, c) {
      if (c.recoverable)
        this.trace(o);
      else {
        var d = new Error(o);
        throw d.hash = c, d;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ A(function(o) {
      var c = this, d = [0], n = [], g = [null], e = [], $ = this.table, t = "", oe = 0, ze = 0, He = 2, Ye = 1, Je = e.slice.call(arguments, 1), T = Object.create(this.lexer), w = { yy: {} };
      for (var xe in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, xe) && (w.yy[xe] = this.yy[xe]);
      T.setInput(o, w.yy), w.yy.lexer = T, w.yy.parser = this, typeof T.yylloc > "u" && (T.yylloc = {});
      var Le = T.yylloc;
      e.push(Le);
      var Ze = T.options && T.options.ranges;
      typeof w.yy.parseError == "function" ? this.parseError = w.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function $e(S) {
        d.length = d.length - 2 * S, g.length = g.length - S, e.length = e.length - S;
      }
      A($e, "popStack");
      function Ke() {
        var S;
        return S = n.pop() || T.lex() || Ye, typeof S != "number" && (S instanceof Array && (n = S, S = n.pop()), S = c.symbols_[S] || S), S;
      }
      A(Ke, "lex");
      for (var _, V, N, ve, R = {}, ce, L, Qe, he; ; ) {
        if (V = d[d.length - 1], this.defaultActions[V] ? N = this.defaultActions[V] : ((_ === null || typeof _ > "u") && (_ = Ke()), N = $[V] && $[V][_]), typeof N > "u" || !N.length || !N[0]) {
          var Ie = "";
          he = [];
          for (ce in $[V])
            this.terminals_[ce] && ce > He && he.push("'" + this.terminals_[ce] + "'");
          T.showPosition ? Ie = "Parse error on line " + (oe + 1) + `:
` + T.showPosition() + `
Expecting ` + he.join(", ") + ", got '" + (this.terminals_[_] || _) + "'" : Ie = "Parse error on line " + (oe + 1) + ": Unexpected " + (_ == Ye ? "end of input" : "'" + (this.terminals_[_] || _) + "'"), this.parseError(Ie, {
            text: T.match,
            token: this.terminals_[_] || _,
            line: T.yylineno,
            loc: Le,
            expected: he
          });
        }
        if (N[0] instanceof Array && N.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + V + ", token: " + _);
        switch (N[0]) {
          case 1:
            d.push(_), g.push(T.yytext), e.push(T.yylloc), d.push(N[1]), _ = null, ze = T.yyleng, t = T.yytext, oe = T.yylineno, Le = T.yylloc;
            break;
          case 2:
            if (L = this.productions_[N[1]][1], R.$ = g[g.length - L], R._$ = {
              first_line: e[e.length - (L || 1)].first_line,
              last_line: e[e.length - 1].last_line,
              first_column: e[e.length - (L || 1)].first_column,
              last_column: e[e.length - 1].last_column
            }, Ze && (R._$.range = [
              e[e.length - (L || 1)].range[0],
              e[e.length - 1].range[1]
            ]), ve = this.performAction.apply(R, [
              t,
              ze,
              oe,
              w.yy,
              N[1],
              g,
              e
            ].concat(Je)), typeof ve < "u")
              return ve;
            L && (d = d.slice(0, -1 * L * 2), g = g.slice(0, -1 * L), e = e.slice(0, -1 * L)), d.push(this.productions_[N[1]][0]), g.push(R.$), e.push(R._$), Qe = $[d[d.length - 2]][d[d.length - 1]], d.push(Qe);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, qe = /* @__PURE__ */ (function() {
    var O = {
      EOF: 1,
      parseError: /* @__PURE__ */ A(function(c, d) {
        if (this.yy.parser)
          this.yy.parser.parseError(c, d);
        else
          throw new Error(c);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ A(function(o, c) {
        return this.yy = c || this.yy || {}, this._input = o, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ A(function() {
        var o = this._input[0];
        this.yytext += o, this.yyleng++, this.offset++, this.match += o, this.matched += o;
        var c = o.match(/(?:\r\n?|\n).*/g);
        return c ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), o;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ A(function(o) {
        var c = o.length, d = o.split(/(?:\r\n?|\n)/g);
        this._input = o + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - c), this.offset -= c;
        var n = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), d.length - 1 && (this.yylineno -= d.length - 1);
        var g = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: d ? (d.length === n.length ? this.yylloc.first_column : 0) + n[n.length - d.length].length - d[0].length : this.yylloc.first_column - c
        }, this.options.ranges && (this.yylloc.range = [g[0], g[0] + this.yyleng - c]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ A(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ A(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ A(function(o) {
        this.unput(this.match.slice(o));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ A(function() {
        var o = this.matched.substr(0, this.matched.length - this.match.length);
        return (o.length > 20 ? "..." : "") + o.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ A(function() {
        var o = this.match;
        return o.length < 20 && (o += this._input.substr(0, 20 - o.length)), (o.substr(0, 20) + (o.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ A(function() {
        var o = this.pastInput(), c = new Array(o.length + 1).join("-");
        return o + this.upcomingInput() + `
` + c + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ A(function(o, c) {
        var d, n, g;
        if (this.options.backtrack_lexer && (g = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (g.yylloc.range = this.yylloc.range.slice(0))), n = o[0].match(/(?:\r\n?|\n).*/g), n && (this.yylineno += n.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: n ? n[n.length - 1].length - n[n.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + o[0].length
        }, this.yytext += o[0], this.match += o[0], this.matches = o, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(o[0].length), this.matched += o[0], d = this.performAction.call(this, this.yy, this, c, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), d)
          return d;
        if (this._backtrack) {
          for (var e in g)
            this[e] = g[e];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ A(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var o, c, d, n;
        this._more || (this.yytext = "", this.match = "");
        for (var g = this._currentRules(), e = 0; e < g.length; e++)
          if (d = this._input.match(this.rules[g[e]]), d && (!c || d[0].length > c[0].length)) {
            if (c = d, n = e, this.options.backtrack_lexer) {
              if (o = this.test_match(d, g[e]), o !== !1)
                return o;
              if (this._backtrack) {
                c = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return c ? (o = this.test_match(c, g[n]), o !== !1 ? o : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ A(function() {
        var c = this.next();
        return c || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ A(function(c) {
        this.conditionStack.push(c);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ A(function() {
        var c = this.conditionStack.length - 1;
        return c > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ A(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ A(function(c) {
        return c = this.conditionStack.length - 1 - Math.abs(c || 0), c >= 0 ? this.conditionStack[c] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ A(function(c) {
        this.begin(c);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ A(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: {},
      performAction: /* @__PURE__ */ A(function(c, d, n, g) {
        switch (n) {
          case 0:
            return 62;
          case 1:
            return 63;
          case 2:
            return 64;
          case 3:
            return 65;
          case 4:
            break;
          case 5:
            break;
          case 6:
            return this.begin("acc_title"), 33;
          case 7:
            return this.popState(), "acc_title_value";
          case 8:
            return this.begin("acc_descr"), 35;
          case 9:
            return this.popState(), "acc_descr_value";
          case 10:
            this.begin("acc_descr_multiline");
            break;
          case 11:
            this.popState();
            break;
          case 12:
            return "acc_descr_multiline_value";
          case 13:
            return 8;
          case 14:
            break;
          case 15:
            return 7;
          case 16:
            return 7;
          case 17:
            return "EDGE_STATE";
          case 18:
            this.begin("callback_name");
            break;
          case 19:
            this.popState();
            break;
          case 20:
            this.popState(), this.begin("callback_args");
            break;
          case 21:
            return 79;
          case 22:
            this.popState();
            break;
          case 23:
            return 80;
          case 24:
            this.popState();
            break;
          case 25:
            return "STR";
          case 26:
            this.begin("string");
            break;
          case 27:
            return 82;
          case 28:
            return 57;
          case 29:
            return this.begin("namespace"), 42;
          case 30:
            return this.popState(), 8;
          case 31:
            break;
          case 32:
            return this.begin("namespace-body"), 39;
          case 33:
            return this.popState(), 41;
          case 34:
            return "EOF_IN_STRUCT";
          case 35:
            return 8;
          case 36:
            break;
          case 37:
            return "EDGE_STATE";
          case 38:
            return this.begin("class"), 46;
          case 39:
            return this.popState(), 8;
          case 40:
            break;
          case 41:
            return this.popState(), this.popState(), 41;
          case 42:
            return this.begin("class-body"), 39;
          case 43:
            return this.popState(), 41;
          case 44:
            return "EOF_IN_STRUCT";
          case 45:
            return "EDGE_STATE";
          case 46:
            return "OPEN_IN_STRUCT";
          case 47:
            break;
          case 48:
            return "MEMBER";
          case 49:
            return 83;
          case 50:
            return 75;
          case 51:
            return 76;
          case 52:
            return 78;
          case 53:
            return 54;
          case 54:
            return 56;
          case 55:
            return 49;
          case 56:
            return 50;
          case 57:
            return 81;
          case 58:
            this.popState();
            break;
          case 59:
            return "GENERICTYPE";
          case 60:
            this.begin("generic");
            break;
          case 61:
            this.popState();
            break;
          case 62:
            return "BQUOTE_STR";
          case 63:
            this.begin("bqstring");
            break;
          case 64:
            return 77;
          case 65:
            return 77;
          case 66:
            return 77;
          case 67:
            return 77;
          case 68:
            return 69;
          case 69:
            return 69;
          case 70:
            return 71;
          case 71:
            return 71;
          case 72:
            return 70;
          case 73:
            return 68;
          case 74:
            return 72;
          case 75:
            return 73;
          case 76:
            return 74;
          case 77:
            return 22;
          case 78:
            return 44;
          case 79:
            return 100;
          case 80:
            return 18;
          case 81:
            return "PLUS";
          case 82:
            return 87;
          case 83:
            return 61;
          case 84:
            return 89;
          case 85:
            return 89;
          case 86:
            return 90;
          case 87:
            return "EQUALS";
          case 88:
            return "EQUALS";
          case 89:
            return 60;
          case 90:
            return 12;
          case 91:
            return 14;
          case 92:
            return "PUNCTUATION";
          case 93:
            return 86;
          case 94:
            return 102;
          case 95:
            return 48;
          case 96:
            return 48;
          case 97:
            return 9;
        }
      }, "anonymous"),
      rules: [/^(?:.*direction\s+TB[^\n]*)/, /^(?:.*direction\s+BT[^\n]*)/, /^(?:.*direction\s+RL[^\n]*)/, /^(?:.*direction\s+LR[^\n]*)/, /^(?:%%(?!\{)*[^\n]*(\r?\n?)+)/, /^(?:%%[^\n]*(\r?\n)*)/, /^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:classDiagram-v2\b)/, /^(?:classDiagram\b)/, /^(?:\[\*\])/, /^(?:call[\s]+)/, /^(?:\([\s]*\))/, /^(?:\()/, /^(?:[^(]*)/, /^(?:\))/, /^(?:[^)]*)/, /^(?:["])/, /^(?:[^"]*)/, /^(?:["])/, /^(?:style\b)/, /^(?:classDef\b)/, /^(?:namespace\b)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:[{])/, /^(?:[}])/, /^(?:$)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:\[\*\])/, /^(?:class\b)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:[}])/, /^(?:[{])/, /^(?:[}])/, /^(?:$)/, /^(?:\[\*\])/, /^(?:[{])/, /^(?:[\n])/, /^(?:[^{}\n]*)/, /^(?:cssClass\b)/, /^(?:callback\b)/, /^(?:link\b)/, /^(?:click\b)/, /^(?:note for\b)/, /^(?:note\b)/, /^(?:<<)/, /^(?:>>)/, /^(?:href\b)/, /^(?:[~])/, /^(?:[^~]*)/, /^(?:~)/, /^(?:[`])/, /^(?:[^`]+)/, /^(?:[`])/, /^(?:_self\b)/, /^(?:_blank\b)/, /^(?:_parent\b)/, /^(?:_top\b)/, /^(?:\s*<\|)/, /^(?:\s*\|>)/, /^(?:\s*>)/, /^(?:\s*<)/, /^(?:\s*\*)/, /^(?:\s*o\b)/, /^(?:\s*\(\))/, /^(?:--)/, /^(?:\.\.)/, /^(?::{1}[^:\n;]+)/, /^(?::{3})/, /^(?:-)/, /^(?:\.)/, /^(?:\+)/, /^(?::)/, /^(?:,)/, /^(?:#)/, /^(?:#)/, /^(?:%)/, /^(?:=)/, /^(?:=)/, /^(?:\w+)/, /^(?:\[)/, /^(?:\])/, /^(?:[!"#$%&'*+,-.`?\\/])/, /^(?:[0-9]+)/, /^(?:[\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6]|[\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377]|[\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5]|[\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA]|[\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE]|[\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA]|[\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0]|[\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977]|[\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2]|[\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A]|[\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39]|[\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8]|[\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C]|[\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C]|[\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99]|[\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0]|[\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D]|[\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3]|[\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10]|[\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1]|[\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81]|[\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3]|[\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6]|[\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A]|[\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081]|[\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D]|[\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0]|[\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310]|[\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C]|[\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711]|[\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7]|[\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C]|[\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16]|[\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF]|[\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC]|[\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D]|[\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D]|[\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3]|[\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F]|[\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128]|[\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184]|[\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3]|[\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6]|[\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE]|[\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C]|[\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D]|[\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC]|[\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B]|[\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788]|[\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805]|[\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB]|[\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28]|[\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5]|[\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4]|[\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E]|[\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D]|[\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36]|[\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D]|[\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC]|[\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF]|[\uFFD2-\uFFD7\uFFDA-\uFFDC])/, /^(?:\s)/, /^(?:\s)/, /^(?:$)/],
      conditions: { "namespace-body": { rules: [26, 33, 34, 35, 36, 37, 38, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, namespace: { rules: [26, 29, 30, 31, 32, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, "class-body": { rules: [26, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, class: { rules: [26, 39, 40, 41, 42, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, acc_descr_multiline: { rules: [11, 12, 26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, acc_descr: { rules: [9, 26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, acc_title: { rules: [7, 26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, callback_args: { rules: [22, 23, 26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, callback_name: { rules: [19, 20, 21, 26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, href: { rules: [26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, struct: { rules: [26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, generic: { rules: [26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, bqstring: { rules: [26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, string: { rules: [24, 25, 26, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 97], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 8, 10, 13, 14, 15, 16, 17, 18, 26, 27, 28, 29, 38, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97], inclusive: !0 } }
    };
    return O;
  })();
  Ne.lexer = qe;
  function le() {
    this.yy = {};
  }
  return A(le, "Parser"), le.prototype = Ne, Ne.Parser = le, new le();
})();
Ve.parser = Ve;
var Ft = Ve, We = ["#", "+", "~", "-", ""], U, je = (U = class {
  constructor(i, r) {
    this.memberType = r, this.visibility = "", this.classifier = "", this.text = "";
    const u = ft(i, F());
    this.parseMember(u);
  }
  getDisplayDetails() {
    let i = this.visibility + G(this.id);
    this.memberType === "method" && (i += `(${G(this.parameters.trim())})`, this.returnType && (i += " : " + G(this.returnType))), i = i.trim();
    const r = this.parseClassifier();
    return {
      displayText: i,
      cssStyle: r
    };
  }
  parseMember(i) {
    let r = "";
    if (this.memberType === "method") {
      const a = /([#+~-])?(.+)\((.*)\)([\s$*])?(.*)([$*])?/.exec(i);
      if (a) {
        const p = a[1] ? a[1].trim() : "";
        if (We.includes(p) && (this.visibility = p), this.id = a[2], this.parameters = a[3] ? a[3].trim() : "", r = a[4] ? a[4].trim() : "", this.returnType = a[5] ? a[5].trim() : "", r === "") {
          const f = this.returnType.substring(this.returnType.length - 1);
          /[$*]/.exec(f) && (r = f, this.returnType = this.returnType.substring(0, this.returnType.length - 1));
        }
      }
    } else {
      const l = i.length, a = i.substring(0, 1), p = i.substring(l - 1);
      We.includes(a) && (this.visibility = a), /[$*]/.exec(p) && (r = p), this.id = i.substring(
        this.visibility === "" ? 0 : 1,
        r === "" ? l : l - 1
      );
    }
    this.classifier = r, this.id = this.id.startsWith(" ") ? " " + this.id.trim() : this.id.trim();
    const u = `${this.visibility ? "\\" + this.visibility : ""}${G(this.id)}${this.memberType === "method" ? `(${G(this.parameters)})${this.returnType ? " : " + G(this.returnType) : ""}` : ""}`;
    this.text = u.replaceAll("<", "&lt;").replaceAll(">", "&gt;"), this.text.startsWith("\\&lt;") && (this.text = this.text.replace("\\&lt;", "~"));
  }
  parseClassifier() {
    switch (this.classifier) {
      case "*":
        return "font-style:italic;";
      case "$":
        return "text-decoration:underline;";
      default:
        return "";
    }
  }
}, A(U, "ClassMember"), U), pe = "classId-", Xe = 0, M = /* @__PURE__ */ A((s) => v.sanitizeText(s, F()), "sanitizeText"), z, Bt = (z = class {
  constructor() {
    this.relations = [], this.classes = /* @__PURE__ */ new Map(), this.styleClasses = /* @__PURE__ */ new Map(), this.notes = /* @__PURE__ */ new Map(), this.interfaces = [], this.namespaces = /* @__PURE__ */ new Map(), this.namespaceCounter = 0, this.functions = [], this.lineType = {
      LINE: 0,
      DOTTED_LINE: 1
    }, this.relationType = {
      AGGREGATION: 0,
      EXTENSION: 1,
      COMPOSITION: 2,
      DEPENDENCY: 3,
      LOLLIPOP: 4
    }, this.setupToolTips = /* @__PURE__ */ A((i) => {
      const r = tt();
      de(i).select("svg").selectAll("g").filter(function() {
        return de(this).attr("title") !== null;
      }).on("mouseover", (a) => {
        const p = de(a.currentTarget), f = p.attr("title");
        if (!f)
          return;
        const C = a.currentTarget.getBoundingClientRect();
        r.transition().duration(200).style("opacity", ".9"), r.html(nt.sanitize(f)).style("left", `${window.scrollX + C.left + C.width / 2}px`).style("top", `${window.scrollY + C.bottom + 4}px`), p.classed("hover", !0);
      }).on("mouseout", (a) => {
        r.transition().duration(500).style("opacity", 0), de(a.currentTarget).classed("hover", !1);
      });
    }, "setupToolTips"), this.direction = "TB", this.setAccTitle = ut, this.getAccTitle = lt, this.setAccDescription = ot, this.getAccDescription = ct, this.setDiagramTitle = ht, this.getDiagramTitle = dt, this.getConfig = /* @__PURE__ */ A(() => F().class, "getConfig"), this.functions.push(this.setupToolTips.bind(this)), this.clear(), this.addRelation = this.addRelation.bind(this), this.addClassesToNamespace = this.addClassesToNamespace.bind(this), this.addNamespace = this.addNamespace.bind(this), this.setCssClass = this.setCssClass.bind(this), this.addMembers = this.addMembers.bind(this), this.addClass = this.addClass.bind(this), this.setClassLabel = this.setClassLabel.bind(this), this.addAnnotation = this.addAnnotation.bind(this), this.addMember = this.addMember.bind(this), this.cleanupLabel = this.cleanupLabel.bind(this), this.addNote = this.addNote.bind(this), this.defineClass = this.defineClass.bind(this), this.setDirection = this.setDirection.bind(this), this.setLink = this.setLink.bind(this), this.bindFunctions = this.bindFunctions.bind(this), this.clear = this.clear.bind(this), this.setTooltip = this.setTooltip.bind(this), this.setClickEvent = this.setClickEvent.bind(this), this.setCssStyle = this.setCssStyle.bind(this);
  }
  splitClassNameAndType(i) {
    const r = v.sanitizeText(i, F());
    let u = "", l = r;
    if (r.indexOf("~") > 0) {
      const a = r.split("~");
      l = M(a[0]), u = M(a[1]);
    }
    return { className: l, type: u };
  }
  setClassLabel(i, r) {
    const u = v.sanitizeText(i, F());
    r && (r = M(r));
    const { className: l } = this.splitClassNameAndType(u);
    this.classes.get(l).label = r, this.classes.get(l).text = `${r}${this.classes.get(l).type ? `<${this.classes.get(l).type}>` : ""}`;
  }
  /**
   * Function called by parser when a node definition has been found.
   *
   * @param id - ID of the class to add
   * @public
   */
  addClass(i) {
    const r = v.sanitizeText(i, F()), { className: u, type: l } = this.splitClassNameAndType(r);
    if (this.classes.has(u))
      return;
    const a = v.sanitizeText(u, F());
    this.classes.set(a, {
      id: a,
      type: l,
      label: a,
      text: `${a}${l ? `&lt;${l}&gt;` : ""}`,
      shape: "classBox",
      cssClasses: "default",
      methods: [],
      members: [],
      annotations: [],
      styles: [],
      domId: pe + a + "-" + Xe
    }), Xe++;
  }
  addInterface(i, r) {
    const u = {
      id: `interface${this.interfaces.length}`,
      label: i,
      classId: r
    };
    this.interfaces.push(u);
  }
  /**
   * Function to lookup domId from id in the graph definition.
   *
   * @param id - class ID to lookup
   * @public
   */
  lookUpDomId(i) {
    const r = v.sanitizeText(i, F());
    if (this.classes.has(r))
      return this.classes.get(r).domId;
    throw new Error("Class not found: " + r);
  }
  clear() {
    this.relations = [], this.classes = /* @__PURE__ */ new Map(), this.notes = /* @__PURE__ */ new Map(), this.interfaces = [], this.functions = [], this.functions.push(this.setupToolTips.bind(this)), this.namespaces = /* @__PURE__ */ new Map(), this.namespaceCounter = 0, this.direction = "TB", pt();
  }
  getClass(i) {
    return this.classes.get(i);
  }
  getClasses() {
    return this.classes;
  }
  getRelations() {
    return this.relations;
  }
  getNote(i) {
    const r = typeof i == "number" ? `note${i}` : i;
    return this.notes.get(r);
  }
  getNotes() {
    return this.notes;
  }
  addRelation(i) {
    Oe.debug("Adding relation: " + JSON.stringify(i));
    const r = [
      this.relationType.LOLLIPOP,
      this.relationType.AGGREGATION,
      this.relationType.COMPOSITION,
      this.relationType.DEPENDENCY,
      this.relationType.EXTENSION
    ];
    i.relation.type1 === this.relationType.LOLLIPOP && !r.includes(i.relation.type2) ? (this.addClass(i.id2), this.addInterface(i.id1, i.id2), i.id1 = `interface${this.interfaces.length - 1}`) : i.relation.type2 === this.relationType.LOLLIPOP && !r.includes(i.relation.type1) ? (this.addClass(i.id1), this.addInterface(i.id2, i.id1), i.id2 = `interface${this.interfaces.length - 1}`) : (this.addClass(i.id1), this.addClass(i.id2)), i.id1 = this.splitClassNameAndType(i.id1).className, i.id2 = this.splitClassNameAndType(i.id2).className, i.relationTitle1 = v.sanitizeText(
      i.relationTitle1.trim(),
      F()
    ), i.relationTitle2 = v.sanitizeText(
      i.relationTitle2.trim(),
      F()
    ), this.relations.push(i);
  }
  /**
   * Adds an annotation to the specified class Annotations mark special properties of the given type
   * (like 'interface' or 'service')
   *
   * @param className - The class name
   * @param annotation - The name of the annotation without any brackets
   * @public
   */
  addAnnotation(i, r) {
    const u = this.splitClassNameAndType(i).className;
    this.classes.get(u).annotations.push(r);
  }
  /**
   * Adds a member to the specified class
   *
   * @param className - The class name
   * @param member - The full name of the member. If the member is enclosed in `<<brackets>>` it is
   *   treated as an annotation If the member is ending with a closing bracket ) it is treated as a
   *   method Otherwise the member will be treated as a normal property
   * @public
   */
  addMember(i, r) {
    this.addClass(i);
    const u = this.splitClassNameAndType(i).className, l = this.classes.get(u);
    if (typeof r == "string") {
      const a = r.trim();
      a.startsWith("<<") && a.endsWith(">>") ? l.annotations.push(M(a.substring(2, a.length - 2))) : a.indexOf(")") > 0 ? l.methods.push(new je(a, "method")) : a && l.members.push(new je(a, "attribute"));
    }
  }
  addMembers(i, r) {
    Array.isArray(r) && (r.reverse(), r.forEach((u) => this.addMember(i, u)));
  }
  addNote(i, r) {
    const u = this.notes.size, l = {
      id: `note${u}`,
      class: r,
      text: i,
      index: u
    };
    return this.notes.set(l.id, l), l.id;
  }
  cleanupLabel(i) {
    return i.startsWith(":") && (i = i.substring(1)), M(i.trim());
  }
  /**
   * Called by parser when assigning cssClass to a class
   *
   * @param ids - Comma separated list of ids
   * @param className - Class to add
   */
  setCssClass(i, r) {
    i.split(",").forEach((u) => {
      let l = u;
      /\d/.exec(u[0]) && (l = pe + l);
      const a = this.classes.get(l);
      a && (a.cssClasses += " " + r);
    });
  }
  defineClass(i, r) {
    for (const u of i) {
      let l = this.styleClasses.get(u);
      l === void 0 && (l = { id: u, styles: [], textStyles: [] }, this.styleClasses.set(u, l)), r && r.forEach((a) => {
        if (/color/.exec(a)) {
          const p = a.replace("fill", "bgFill");
          l.textStyles.push(p);
        }
        l.styles.push(a);
      }), this.classes.forEach((a) => {
        a.cssClasses.includes(u) && a.styles.push(...r.flatMap((p) => p.split(",")));
      });
    }
  }
  /**
   * Called by parser when a tooltip is found, e.g. a clickable element.
   *
   * @param ids - Comma separated list of ids
   * @param tooltip - Tooltip to add
   */
  setTooltip(i, r) {
    i.split(",").forEach((u) => {
      r !== void 0 && (this.classes.get(u).tooltip = M(r));
    });
  }
  getTooltip(i, r) {
    return r && this.namespaces.has(r) ? this.namespaces.get(r).classes.get(i).tooltip : this.classes.get(i).tooltip;
  }
  /**
   * Called by parser when a link is found. Adds the URL to the vertex data.
   *
   * @param ids - Comma separated list of ids
   * @param linkStr - URL to create a link for
   * @param target - Target of the link, _blank by default as originally defined in the svgDraw.js file
   */
  setLink(i, r, u) {
    const l = F();
    i.split(",").forEach((a) => {
      let p = a;
      /\d/.exec(a[0]) && (p = pe + p);
      const f = this.classes.get(p);
      f && (f.link = we.formatUrl(r, l), l.securityLevel === "sandbox" ? f.linkTarget = "_top" : typeof u == "string" ? f.linkTarget = M(u) : f.linkTarget = "_blank");
    }), this.setCssClass(i, "clickable");
  }
  /**
   * Called by parser when a click definition is found. Registers an event handler.
   *
   * @param ids - Comma separated list of ids
   * @param functionName - Function to be called on click
   * @param functionArgs - Function args the function should be called with
   */
  setClickEvent(i, r, u) {
    i.split(",").forEach((l) => {
      this.setClickFunc(l, r, u), this.classes.get(l).haveCallback = !0;
    }), this.setCssClass(i, "clickable");
  }
  setClickFunc(i, r, u) {
    const l = v.sanitizeText(i, F());
    if (F().securityLevel !== "loose" || r === void 0)
      return;
    const p = l;
    if (this.classes.has(p)) {
      const f = this.lookUpDomId(p);
      let C = [];
      if (typeof u == "string") {
        C = u.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        for (let D = 0; D < C.length; D++) {
          let B = C[D].trim();
          B.startsWith('"') && B.endsWith('"') && (B = B.substr(1, B.length - 2)), C[D] = B;
        }
      }
      C.length === 0 && C.push(f), this.functions.push(() => {
        const D = document.querySelector(`[id="${f}"]`);
        D !== null && D.addEventListener(
          "click",
          () => {
            we.runFunc(r, ...C);
          },
          !1
        );
      });
    }
  }
  bindFunctions(i) {
    this.functions.forEach((r) => {
      r(i);
    });
  }
  // Utility function to escape HTML meta-characters
  escapeHtml(i) {
    return i.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  getDirection() {
    return this.direction;
  }
  setDirection(i) {
    this.direction = i;
  }
  /**
   * Function called by parser when a namespace definition has been found.
   *
   * @param id - ID of the namespace to add
   * @public
   */
  addNamespace(i) {
    this.namespaces.has(i) || (this.namespaces.set(i, {
      id: i,
      classes: /* @__PURE__ */ new Map(),
      notes: /* @__PURE__ */ new Map(),
      children: /* @__PURE__ */ new Map(),
      domId: pe + i + "-" + this.namespaceCounter
    }), this.namespaceCounter++);
  }
  getNamespace(i) {
    return this.namespaces.get(i);
  }
  getNamespaces() {
    return this.namespaces;
  }
  /**
   * Function called by parser when a namespace definition has been found.
   *
   * @param id - ID of the namespace to add
   * @param classNames - IDs of the class to add
   * @param noteNames - IDs of the notes to add
   * @public
   */
  addClassesToNamespace(i, r, u) {
    if (this.namespaces.has(i)) {
      for (const l of r) {
        const { className: a } = this.splitClassNameAndType(l), p = this.getClass(a);
        p.parent = i, this.namespaces.get(i).classes.set(a, p);
      }
      for (const l of u) {
        const a = this.getNote(l);
        a.parent = i, this.namespaces.get(i).notes.set(l, a);
      }
    }
  }
  setCssStyle(i, r) {
    const u = this.classes.get(i);
    if (!(!r || !u))
      for (const l of r)
        l.includes(",") ? u.styles.push(...l.split(",")) : u.styles.push(l);
  }
  /**
   * Gets the arrow marker for a type index
   *
   * @param type - The type to look for
   * @returns The arrow marker
   */
  getArrowMarker(i) {
    let r;
    switch (i) {
      case 0:
        r = "aggregation";
        break;
      case 1:
        r = "extension";
        break;
      case 2:
        r = "composition";
        break;
      case 3:
        r = "dependency";
        break;
      case 4:
        r = "lollipop";
        break;
      default:
        r = "none";
    }
    return r;
  }
  getData() {
    const i = [], r = [], u = F();
    for (const a of this.namespaces.values()) {
      const p = {
        id: a.id,
        label: a.id,
        isGroup: !0,
        padding: u.class.padding ?? 16,
        // parent node must be one of [rect, roundedWithTitle, noteGroup, divider]
        shape: "rect",
        cssStyles: [],
        look: u.look
      };
      i.push(p);
    }
    for (const a of this.classes.values()) {
      const p = {
        ...a,
        type: void 0,
        isGroup: !1,
        parentId: a.parent,
        look: u.look
      };
      i.push(p);
    }
    for (const a of this.notes.values()) {
      const p = {
        id: a.id,
        label: a.text,
        isGroup: !1,
        shape: "note",
        padding: u.class.padding ?? 6,
        cssStyles: [
          "text-align: left",
          "white-space: nowrap",
          `fill: ${u.themeVariables.noteBkgColor}`,
          `stroke: ${u.themeVariables.noteBorderColor}`
        ],
        look: u.look,
        parentId: a.parent,
        labelType: "markdown"
      };
      i.push(p);
      const f = this.classes.get(a.class)?.id;
      if (f) {
        const C = {
          id: `edgeNote${a.index}`,
          start: a.id,
          end: f,
          type: "normal",
          thickness: "normal",
          classes: "relation",
          arrowTypeStart: "none",
          arrowTypeEnd: "none",
          arrowheadStyle: "",
          labelStyle: [""],
          style: ["fill: none"],
          pattern: "dotted",
          look: u.look
        };
        r.push(C);
      }
    }
    for (const a of this.interfaces) {
      const p = {
        id: a.id,
        label: a.label,
        isGroup: !1,
        shape: "rect",
        cssStyles: ["opacity: 0;"],
        look: u.look
      };
      i.push(p);
    }
    let l = 0;
    for (const a of this.relations) {
      l++;
      const p = {
        id: At(a.id1, a.id2, {
          prefix: "id",
          counter: l
        }),
        start: a.id1,
        end: a.id2,
        type: "normal",
        label: a.title,
        labelpos: "c",
        thickness: "normal",
        classes: "relation",
        arrowTypeStart: this.getArrowMarker(a.relation.type1),
        arrowTypeEnd: this.getArrowMarker(a.relation.type2),
        startLabelRight: a.relationTitle1 === "none" ? "" : a.relationTitle1,
        endLabelLeft: a.relationTitle2 === "none" ? "" : a.relationTitle2,
        arrowheadStyle: "",
        labelStyle: ["display: inline-block"],
        style: a.style || "",
        pattern: a.relation.lineType == 1 ? "dashed" : "solid",
        look: u.look,
        labelType: "markdown"
      };
      r.push(p);
    }
    return { nodes: i, edges: r, other: {}, config: u, direction: this.getDirection() };
  }
}, A(z, "ClassDB"), z), gt = /* @__PURE__ */ A((s) => `g.classGroup text {
  fill: ${s.nodeBorder || s.classText};
  stroke: none;
  font-family: ${s.fontFamily};
  font-size: 10px;

  .title {
    font-weight: bolder;
  }

}

  .cluster-label text {
    fill: ${s.titleColor};
  }
  .cluster-label span {
    color: ${s.titleColor};
  }
  .cluster-label span p {
    background-color: transparent;
  }

  .cluster rect {
    fill: ${s.clusterBkg};
    stroke: ${s.clusterBorder};
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${s.titleColor};
  }

  .cluster span {
    color: ${s.titleColor};
  }

.nodeLabel, .edgeLabel {
  color: ${s.classText};
}
.edgeLabel .label rect {
  fill: ${s.mainBkg};
}
.label text {
  fill: ${s.classText};
}

.labelBkg {
  background: ${s.mainBkg};
}
.edgeLabel .label span {
  background: ${s.mainBkg};
}

.classTitle {
  font-weight: bolder;
}
.node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${s.mainBkg};
    stroke: ${s.nodeBorder};
    stroke-width: 1px;
  }


.divider {
  stroke: ${s.nodeBorder};
  stroke-width: 1;
}

g.clickable {
  cursor: pointer;
}

g.classGroup rect {
  fill: ${s.mainBkg};
  stroke: ${s.nodeBorder};
}

g.classGroup line {
  stroke: ${s.nodeBorder};
  stroke-width: 1;
}

.classLabel .box {
  stroke: none;
  stroke-width: 0;
  fill: ${s.mainBkg};
  opacity: 0.5;
}

.classLabel .label {
  fill: ${s.nodeBorder};
  font-size: 10px;
}

.relation {
  stroke: ${s.lineColor};
  stroke-width: 1;
  fill: none;
}

.dashed-line{
  stroke-dasharray: 3;
}

.dotted-line{
  stroke-dasharray: 1 2;
}

#compositionStart, .composition {
  fill: ${s.lineColor} !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#compositionEnd, .composition {
  fill: ${s.lineColor} !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#dependencyStart, .dependency {
  fill: ${s.lineColor} !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#dependencyStart, .dependency {
  fill: ${s.lineColor} !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#extensionStart, .extension {
  fill: transparent !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#extensionEnd, .extension {
  fill: transparent !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#aggregationStart, .aggregation {
  fill: transparent !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#aggregationEnd, .aggregation {
  fill: transparent !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#lollipopStart, .lollipop {
  fill: ${s.mainBkg} !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

#lollipopEnd, .lollipop {
  fill: ${s.mainBkg} !important;
  stroke: ${s.lineColor} !important;
  stroke-width: 1;
}

.edgeTerminals {
  font-size: 11px;
  line-height: initial;
}

.classTitleText {
  text-anchor: middle;
  font-size: 18px;
  fill: ${s.textColor};
}
  ${et()}
`, "getStyles"), _t = gt, Ct = /* @__PURE__ */ A((s, i = "TB") => {
  if (!s.doc)
    return i;
  let r = i;
  for (const u of s.doc)
    u.stmt === "dir" && (r = u.value);
  return r;
}, "getDir"), mt = /* @__PURE__ */ A(function(s, i) {
  return i.db.getClasses();
}, "getClasses"), bt = /* @__PURE__ */ A(async function(s, i, r, u) {
  Oe.info("REF0:"), Oe.info("Drawing class diagram (v3)", i);
  const { securityLevel: l, state: a, layout: p } = F(), f = u.db.getData(), C = st(i, l);
  f.type = u.type, f.layoutAlgorithm = at(p), f.nodeSpacing = a?.nodeSpacing || 50, f.rankSpacing = a?.rankSpacing || 50, f.markers = ["aggregation", "extension", "composition", "dependency", "lollipop"], f.diagramId = i, await rt(f, C);
  const D = 8;
  we.insertTitle(
    C,
    "classDiagramTitleText",
    a?.titleTopMargin ?? 25,
    u.db.getDiagramTitle()
  ), it(C, D, "classDiagram", a?.useMaxWidth ?? !0);
}, "draw"), St = {
  getClasses: mt,
  draw: bt,
  getDir: Ct
};
export {
  Bt as C,
  Ft as a,
  St as c,
  _t as s
};
