import { aI as Gt, s as Wt, g as Kt, q as Ht, p as Yt, a as Xt, b as Zt, _ as w, G as wt, I as Jt, d as ot, as as Qt, W as $t, X as te, Y as ee, e as ne, z as se, E as ie, F as oe } from "./mermaid.core-CbLi0pBF.js";
const kt = (t, n) => Gt(t, "a", -n), _t = 1e-10;
function st(t, n) {
  const s = ae(t), e = s.filter((c) => re(c, t));
  let i = 0, o = 0;
  const a = [];
  if (e.length > 1) {
    const c = Tt(e);
    for (let u = 0; u < e.length; ++u) {
      const r = e[u];
      r.angle = Math.atan2(r.x - c.x, r.y - c.y);
    }
    e.sort((u, r) => r.angle - u.angle);
    let h = e[e.length - 1];
    for (let u = 0; u < e.length; ++u) {
      const r = e[u];
      o += (h.x + r.x) * (r.y - h.y);
      const y = { x: (r.x + h.x) / 2, y: (r.y + h.y) / 2 };
      let d = null;
      for (let b = 0; b < r.parentIndex.length; ++b)
        if (h.parentIndex.includes(r.parentIndex[b])) {
          const x = t[r.parentIndex[b]], M = Math.atan2(r.x - x.x, r.y - x.y), A = Math.atan2(h.x - x.x, h.y - x.y);
          let E = A - M;
          E < 0 && (E += 2 * Math.PI);
          const S = A - E / 2;
          let g = q(y, {
            x: x.x + x.radius * Math.sin(S),
            y: x.y + x.radius * Math.cos(S)
          });
          g > x.radius * 2 && (g = x.radius * 2), (d == null || d.width > g) && (d = { circle: x, width: g, p1: r, p2: h, large: g > x.radius, sweep: !0 });
        }
      d != null && (a.push(d), i += lt(d.circle.radius, d.width), h = r);
    }
  } else {
    let c = t[0];
    for (let u = 1; u < t.length; ++u)
      t[u].radius < c.radius && (c = t[u]);
    let h = !1;
    for (let u = 0; u < t.length; ++u)
      if (q(t[u], c) > Math.abs(c.radius - t[u].radius)) {
        h = !0;
        break;
      }
    h ? i = o = 0 : (i = c.radius * c.radius * Math.PI, a.push({
      circle: c,
      p1: { x: c.x, y: c.y + c.radius },
      p2: { x: c.x - _t, y: c.y + c.radius },
      width: c.radius * 2,
      large: !0,
      sweep: !0
    }));
  }
  return o /= 2, n && (n.area = i + o, n.arcArea = i, n.polygonArea = o, n.arcs = a, n.innerPoints = e, n.intersectionPoints = s), i + o;
}
function re(t, n) {
  return n.every((s) => q(t, s) < s.radius + _t);
}
function ae(t) {
  const n = [];
  for (let s = 0; s < t.length; ++s)
    for (let e = s + 1; e < t.length; ++e) {
      const i = Et(t[s], t[e]);
      for (const o of i)
        o.parentIndex = [s, e], n.push(o);
    }
  return n;
}
function lt(t, n) {
  return t * t * Math.acos(1 - n / t) - (t - n) * Math.sqrt(n * (2 * t - n));
}
function q(t, n) {
  return Math.sqrt((t.x - n.x) * (t.x - n.x) + (t.y - n.y) * (t.y - n.y));
}
function xt(t, n, s) {
  if (s >= t + n)
    return 0;
  if (s <= Math.abs(t - n))
    return Math.PI * Math.min(t, n) * Math.min(t, n);
  const e = t - (s * s - n * n + t * t) / (2 * s), i = n - (s * s - t * t + n * n) / (2 * s);
  return lt(t, e) + lt(n, i);
}
function Et(t, n) {
  const s = q(t, n), e = t.radius, i = n.radius;
  if (s >= e + i || s <= Math.abs(e - i))
    return [];
  const o = (e * e - i * i + s * s) / (2 * s), a = Math.sqrt(e * e - o * o), c = t.x + o * (n.x - t.x) / s, h = t.y + o * (n.y - t.y) / s, u = -(n.y - t.y) * (a / s), r = -(n.x - t.x) * (a / s);
  return [
    { x: c + u, y: h - r },
    { x: c - u, y: h + r }
  ];
}
function Tt(t) {
  const n = { x: 0, y: 0 };
  for (const s of t)
    n.x += s.x, n.y += s.y;
  return n.x /= t.length, n.y /= t.length, n;
}
function le(t, n, s, e) {
  e = e || {};
  const i = e.maxIterations || 100, o = e.tolerance || 1e-10, a = t(n), c = t(s);
  let h = s - n;
  if (a * c > 0)
    throw "Initial bisect points must have opposite signs";
  if (a === 0) return n;
  if (c === 0) return s;
  for (let u = 0; u < i; ++u) {
    h /= 2;
    const r = n + h, y = t(r);
    if (y * a >= 0 && (n = r), Math.abs(h) < o || y === 0)
      return r;
  }
  return n + h;
}
function ct(t) {
  const n = new Array(t);
  for (let s = 0; s < t; ++s)
    n[s] = 0;
  return n;
}
function Mt(t, n) {
  return ct(t).map(() => ct(n));
}
function $(t, n) {
  let s = 0;
  for (let e = 0; e < t.length; ++e)
    s += t[e] * n[e];
  return s;
}
function ut(t) {
  return Math.sqrt($(t, t));
}
function ft(t, n, s) {
  for (let e = 0; e < n.length; ++e)
    t[e] = n[e] * s;
}
function J(t, n, s, e, i) {
  for (let o = 0; o < t.length; ++o)
    t[o] = n * s[o] + e * i[o];
}
function zt(t, n, s) {
  s = s || {};
  const e = s.maxIterations || n.length * 200, i = s.nonZeroDelta || 1.05, o = s.zeroDelta || 1e-3, a = s.minErrorDelta || 1e-6, c = s.minErrorDelta || 1e-5, h = s.rho !== void 0 ? s.rho : 1, u = s.chi !== void 0 ? s.chi : 2, r = s.psi !== void 0 ? s.psi : -0.5, y = s.sigma !== void 0 ? s.sigma : 0.5;
  let d;
  const b = n.length, x = new Array(b + 1);
  x[0] = n, x[0].fx = t(n), x[0].id = 0;
  for (let v = 0; v < b; ++v) {
    const l = n.slice();
    l[v] = l[v] ? l[v] * i : o, x[v + 1] = l, x[v + 1].fx = t(l), x[v + 1].id = v + 1;
  }
  function M(v) {
    for (let l = 0; l < v.length; l++)
      x[b][l] = v[l];
    x[b].fx = v.fx;
  }
  const A = (v, l) => v.fx - l.fx, E = n.slice(), S = n.slice(), g = n.slice(), m = n.slice();
  for (let v = 0; v < e; ++v) {
    if (x.sort(A), s.history) {
      const p = x.map((f) => {
        const N = f.slice();
        return N.fx = f.fx, N.id = f.id, N;
      });
      p.sort((f, N) => f.id - N.id), s.history.push({
        x: x[0].slice(),
        fx: x[0].fx,
        simplex: p
      });
    }
    d = 0;
    for (let p = 0; p < b; ++p)
      d = Math.max(d, Math.abs(x[0][p] - x[1][p]));
    if (Math.abs(x[0].fx - x[b].fx) < a && d < c)
      break;
    for (let p = 0; p < b; ++p) {
      E[p] = 0;
      for (let f = 0; f < b; ++f)
        E[p] += x[f][p];
      E[p] /= b;
    }
    const l = x[b];
    if (J(S, 1 + h, E, -h, l), S.fx = t(S), S.fx < x[0].fx)
      J(m, 1 + u, E, -u, l), m.fx = t(m), m.fx < S.fx ? M(m) : M(S);
    else if (S.fx >= x[b - 1].fx) {
      let p = !1;
      if (S.fx > l.fx ? (J(g, 1 + r, E, -r, l), g.fx = t(g), g.fx < l.fx ? M(g) : p = !0) : (J(g, 1 - r * h, E, r * h, l), g.fx = t(g), g.fx < S.fx ? M(g) : p = !0), p) {
        if (y >= 1) break;
        for (let f = 1; f < x.length; ++f)
          J(x[f], 1 - y, x[0], y, x[f]), x[f].fx = t(x[f]);
      }
    } else
      M(S);
  }
  return x.sort(A), { fx: x[0].fx, x: x[0] };
}
function ce(t, n, s, e, i, o, a) {
  const c = s.fx, h = $(s.fxprime, n);
  let u = c, r = c, y = h, d = 0;
  i = i || 1, o = o || 1e-6, a = a || 0.1;
  function b(x, M, A) {
    for (let E = 0; E < 16; ++E)
      if (i = (x + M) / 2, J(e.x, 1, s.x, i, n), u = e.fx = t(e.x, e.fxprime), y = $(e.fxprime, n), u > c + o * i * h || u >= A)
        M = i;
      else {
        if (Math.abs(y) <= -a * h)
          return i;
        y * (M - x) >= 0 && (M = x), x = i, A = u;
      }
    return 0;
  }
  for (let x = 0; x < 10; ++x) {
    if (J(e.x, 1, s.x, i, n), u = e.fx = t(e.x, e.fxprime), y = $(e.fxprime, n), u > c + o * i * h || x && u >= r)
      return b(d, i, r);
    if (Math.abs(y) <= -a * h)
      return i;
    if (y >= 0)
      return b(i, d, u);
    r = u, d = i, i *= 2;
  }
  return i;
}
function ue(t, n, s) {
  let e = { x: n.slice(), fx: 0, fxprime: n.slice() }, i = { x: n.slice(), fx: 0, fxprime: n.slice() };
  const o = n.slice();
  let a, c, h = 1, u;
  s = s || {}, u = s.maxIterations || n.length * 20, e.fx = t(e.x, e.fxprime), a = e.fxprime.slice(), ft(a, e.fxprime, -1);
  for (let r = 0; r < u; ++r) {
    if (h = ce(t, a, e, i, h), s.history && s.history.push({
      x: e.x.slice(),
      fx: e.fx,
      fxprime: e.fxprime.slice(),
      alpha: h
    }), !h)
      ft(a, e.fxprime, -1);
    else {
      J(o, 1, i.fxprime, -1, e.fxprime);
      const y = $(e.fxprime, e.fxprime), d = Math.max(0, $(o, i.fxprime) / y);
      J(a, d, a, -1, i.fxprime), c = e, e = i, i = c;
    }
    if (ut(e.fxprime) <= 1e-5)
      break;
  }
  return s.history && s.history.push({
    x: e.x.slice(),
    fx: e.fx,
    fxprime: e.fxprime.slice(),
    alpha: h
  }), e;
}
function At(t, n = {}) {
  n.maxIterations = n.maxIterations || 500;
  const s = n.initialLayout || ge, e = n.lossFunction || tt, i = fe(t, n), o = s(i, n), a = Object.keys(o), c = [];
  for (const r of a)
    c.push(o[r].x), c.push(o[r].y);
  const u = zt(
    (r) => {
      const y = {};
      for (let d = 0; d < a.length; ++d) {
        const b = a[d];
        y[b] = {
          x: r[2 * d],
          y: r[2 * d + 1],
          radius: o[b].radius
          // size : circles[setid].size
        };
      }
      return e(y, i);
    },
    c,
    n
  ).x;
  for (let r = 0; r < a.length; ++r) {
    const y = a[r];
    o[y].x = u[2 * r], o[y].y = u[2 * r + 1];
  }
  return o;
}
const Rt = 1e-10;
function ht(t, n, s) {
  return Math.min(t, n) * Math.min(t, n) * Math.PI <= s + Rt ? Math.abs(t - n) : le((e) => xt(t, n, e) - s, 0, t + n);
}
function fe(t, n = {}) {
  const s = n.distinct, e = t.map((c) => Object.assign({}, c));
  function i(c) {
    return c.join(";");
  }
  if (s) {
    const c = /* @__PURE__ */ new Map();
    for (const h of e)
      for (let u = 0; u < h.sets.length; u++) {
        const r = String(h.sets[u]);
        c.set(r, h.size + (c.get(r) || 0));
        for (let y = u + 1; y < h.sets.length; y++) {
          const d = String(h.sets[y]), b = `${r};${d}`, x = `${d};${r}`;
          c.set(b, h.size + (c.get(b) || 0)), c.set(x, h.size + (c.get(x) || 0));
        }
      }
    for (const h of e)
      h.sets.length < 3 && (h.size = c.get(i(h.sets)));
  }
  const o = [], a = /* @__PURE__ */ new Set();
  for (const c of e)
    if (c.sets.length === 1)
      o.push(c.sets[0]);
    else if (c.sets.length === 2) {
      const h = c.sets[0], u = c.sets[1];
      a.add(i(c.sets)), a.add(i([u, h]));
    }
  o.sort((c, h) => c === h ? 0 : c < h ? -1 : 1);
  for (let c = 0; c < o.length; ++c) {
    const h = o[c];
    for (let u = c + 1; u < o.length; ++u) {
      const r = o[u];
      a.has(i([h, r])) || e.push({ sets: [h, r], size: 0 });
    }
  }
  return e;
}
function he(t, n, s) {
  const e = Mt(n.length, n.length), i = Mt(n.length, n.length);
  return t.filter((o) => o.sets.length === 2).forEach((o) => {
    const a = s[o.sets[0]], c = s[o.sets[1]], h = Math.sqrt(n[a].size / Math.PI), u = Math.sqrt(n[c].size / Math.PI), r = ht(h, u, o.size);
    e[a][c] = e[c][a] = r;
    let y = 0;
    o.size + 1e-10 >= Math.min(n[a].size, n[c].size) ? y = 1 : o.size <= 1e-10 && (y = -1), i[a][c] = i[c][a] = y;
  }), { distances: e, constraints: i };
}
function de(t, n, s, e) {
  for (let o = 0; o < n.length; ++o)
    n[o] = 0;
  let i = 0;
  for (let o = 0; o < s.length; ++o) {
    const a = t[2 * o], c = t[2 * o + 1];
    for (let h = o + 1; h < s.length; ++h) {
      const u = t[2 * h], r = t[2 * h + 1], y = s[o][h], d = e[o][h], b = (u - a) * (u - a) + (r - c) * (r - c), x = Math.sqrt(b), M = b - y * y;
      d > 0 && x <= y || d < 0 && x >= y || (i += 2 * M * M, n[2 * o] += 4 * M * (a - u), n[2 * o + 1] += 4 * M * (c - r), n[2 * h] += 4 * M * (u - a), n[2 * h + 1] += 4 * M * (r - c));
    }
  }
  return i;
}
function ge(t, n = {}) {
  let s = ye(t, n);
  const e = n.lossFunction || tt;
  if (t.length >= 8) {
    const i = xe(t, n), o = e(i, t), a = e(s, t);
    o + 1e-8 < a && (s = i);
  }
  return s;
}
function xe(t, n = {}) {
  const s = n.restarts || 10, e = [], i = {};
  for (const d of t)
    d.sets.length === 1 && (i[d.sets[0]] = e.length, e.push(d));
  let { distances: o, constraints: a } = he(t, e, i);
  const c = ut(o.map(ut)) / o.length;
  o = o.map((d) => d.map((b) => b / c));
  const h = (d, b) => de(d, b, o, a);
  let u = null;
  for (let d = 0; d < s; ++d) {
    const b = ct(o.length * 2).map(Math.random), x = ue(h, b, n);
    (!u || x.fx < u.fx) && (u = x);
  }
  const r = u.x, y = {};
  for (let d = 0; d < e.length; ++d) {
    const b = e[d];
    y[b.sets[0]] = {
      x: r[2 * d] * c,
      y: r[2 * d + 1] * c,
      radius: Math.sqrt(b.size / Math.PI)
    };
  }
  if (n.history)
    for (const d of n.history)
      ft(d.x, c);
  return y;
}
function ye(t, n) {
  const s = n && n.lossFunction ? n.lossFunction : tt, e = {}, i = {};
  for (const y of t)
    if (y.sets.length === 1) {
      const d = y.sets[0];
      e[d] = {
        x: 1e10,
        y: 1e10,
        rowid: e.length,
        size: y.size,
        radius: Math.sqrt(y.size / Math.PI)
      }, i[d] = [];
    }
  t = t.filter((y) => y.sets.length === 2);
  for (const y of t) {
    let d = y.weight != null ? y.weight : 1;
    const b = y.sets[0], x = y.sets[1];
    y.size + Rt >= Math.min(e[b].size, e[x].size) && (d = 0), i[b].push({ set: x, size: y.size, weight: d }), i[x].push({ set: b, size: y.size, weight: d });
  }
  const o = [];
  Object.keys(i).forEach((y) => {
    let d = 0;
    for (let b = 0; b < i[y].length; ++b)
      d += i[y][b].size * i[y][b].weight;
    o.push({ set: y, size: d });
  });
  function a(y, d) {
    return d.size - y.size;
  }
  o.sort(a);
  const c = {};
  function h(y) {
    return y.set in c;
  }
  function u(y, d) {
    e[d].x = y.x, e[d].y = y.y, c[d] = !0;
  }
  u({ x: 0, y: 0 }, o[0].set);
  for (let y = 1; y < o.length; ++y) {
    const d = o[y].set, b = i[d].filter(h), x = e[d];
    if (b.sort(a), b.length === 0)
      throw "ERROR: missing pairwise overlap information";
    const M = [];
    for (var r = 0; r < b.length; ++r) {
      const S = e[b[r].set], g = ht(x.radius, S.radius, b[r].size);
      M.push({ x: S.x + g, y: S.y }), M.push({ x: S.x - g, y: S.y }), M.push({ y: S.y + g, x: S.x }), M.push({ y: S.y - g, x: S.x });
      for (let m = r + 1; m < b.length; ++m) {
        const v = e[b[m].set], l = ht(x.radius, v.radius, b[m].size), p = Et(
          { x: S.x, y: S.y, radius: g },
          { x: v.x, y: v.y, radius: l }
        );
        M.push(...p);
      }
    }
    let A = 1e50, E = M[0];
    for (const S of M) {
      e[d].x = S.x, e[d].y = S.y;
      const g = s(e, t);
      g < A && (A = g, E = S);
    }
    u(E, d);
  }
  return e;
}
function tt(t, n) {
  let s = 0;
  for (const e of n) {
    if (e.sets.length === 1)
      continue;
    let i;
    if (e.sets.length === 2) {
      const a = t[e.sets[0]], c = t[e.sets[1]];
      i = xt(a.radius, c.radius, q(a, c));
    } else
      i = st(e.sets.map((a) => t[a]));
    const o = e.weight != null ? e.weight : 1;
    s += o * (i - e.size) * (i - e.size);
  }
  return s;
}
function Ct(t, n) {
  let s = 0;
  for (const e of n) {
    if (e.sets.length === 1)
      continue;
    let i;
    if (e.sets.length === 2) {
      const c = t[e.sets[0]], h = t[e.sets[1]];
      i = xt(c.radius, h.radius, q(c, h));
    } else
      i = st(e.sets.map((c) => t[c]));
    const o = e.weight != null ? e.weight : 1, a = Math.log((i + 1) / (e.size + 1));
    s += o * a * a;
  }
  return s;
}
function pe(t, n, s) {
  if (s == null ? t.sort((i, o) => o.radius - i.radius) : t.sort(s), t.length > 0) {
    const i = t[0].x, o = t[0].y;
    for (const a of t)
      a.x -= i, a.y -= o;
  }
  if (t.length === 2 && q(t[0], t[1]) < Math.abs(t[1].radius - t[0].radius) && (t[1].x = t[0].x + t[0].radius - t[1].radius - 1e-10, t[1].y = t[0].y), t.length > 1) {
    const i = Math.atan2(t[1].x, t[1].y) - n, o = Math.cos(i), a = Math.sin(i);
    for (const c of t) {
      const h = c.x, u = c.y;
      c.x = o * h - a * u, c.y = a * h + o * u;
    }
  }
  if (t.length > 2) {
    let i = Math.atan2(t[2].x, t[2].y) - n;
    for (; i < 0; )
      i += 2 * Math.PI;
    for (; i > 2 * Math.PI; )
      i -= 2 * Math.PI;
    if (i > Math.PI) {
      const o = t[1].y / (1e-10 + t[1].x);
      for (const a of t) {
        var e = (a.x + o * a.y) / (1 + o * o);
        a.x = 2 * e - a.x, a.y = 2 * e * o - a.y;
      }
    }
  }
}
function me(t) {
  t.forEach((i) => {
    i.parent = i;
  });
  function n(i) {
    return i.parent !== i && (i.parent = n(i.parent)), i.parent;
  }
  function s(i, o) {
    const a = n(i), c = n(o);
    a.parent = c;
  }
  for (let i = 0; i < t.length; ++i)
    for (let o = i + 1; o < t.length; ++o) {
      const a = t[i].radius + t[o].radius;
      q(t[i], t[o]) + 1e-10 < a && s(t[o], t[i]);
    }
  const e = /* @__PURE__ */ new Map();
  for (let i = 0; i < t.length; ++i) {
    const o = n(t[i]).parent.setid;
    e.has(o) || e.set(o, []), e.get(o).push(t[i]);
  }
  return t.forEach((i) => {
    delete i.parent;
  }), Array.from(e.values());
}
function dt(t) {
  const n = (s) => {
    const e = t.reduce((o, a) => Math.max(o, a[s] + a.radius), Number.NEGATIVE_INFINITY), i = t.reduce((o, a) => Math.min(o, a[s] - a.radius), Number.POSITIVE_INFINITY);
    return { max: e, min: i };
  };
  return { xRange: n("x"), yRange: n("y") };
}
function Dt(t, n, s) {
  n == null && (n = Math.PI / 2);
  let e = Ft(t).map((u) => Object.assign({}, u));
  const i = me(e);
  for (const u of i) {
    pe(u, n, s);
    const r = dt(u);
    u.size = (r.xRange.max - r.xRange.min) * (r.yRange.max - r.yRange.min), u.bounds = r;
  }
  i.sort((u, r) => r.size - u.size), e = i[0];
  let o = e.bounds;
  const a = (o.xRange.max - o.xRange.min) / 50;
  function c(u, r, y) {
    if (!u)
      return;
    const d = u.bounds;
    let b, x;
    if (r)
      b = o.xRange.max - d.xRange.min + a;
    else {
      b = o.xRange.max - d.xRange.max;
      const M = (d.xRange.max - d.xRange.min) / 2 - (o.xRange.max - o.xRange.min) / 2;
      M < 0 && (b += M);
    }
    if (y)
      x = o.yRange.max - d.yRange.min + a;
    else {
      x = o.yRange.max - d.yRange.max;
      const M = (d.yRange.max - d.yRange.min) / 2 - (o.yRange.max - o.yRange.min) / 2;
      M < 0 && (x += M);
    }
    for (const M of u)
      M.x += b, M.y += x, e.push(M);
  }
  let h = 1;
  for (; h < i.length; )
    c(i[h], !0, !1), c(i[h + 1], !1, !0), c(i[h + 2], !0, !0), h += 3, o = dt(e);
  return Ot(e);
}
function Nt(t, n, s, e, i) {
  const o = Ft(t);
  n -= 2 * e, s -= 2 * e;
  const { xRange: a, yRange: c } = dt(o);
  if (a.max === a.min || c.max === c.min)
    return console.log("not scaling solution: zero size detected"), t;
  let h, u;
  if (i) {
    const b = Math.sqrt(i / Math.PI) * 2;
    h = n / b, u = s / b;
  } else
    h = n / (a.max - a.min), u = s / (c.max - c.min);
  const r = Math.min(u, h), y = (n - (a.max - a.min) * r) / 2, d = (s - (c.max - c.min) * r) / 2;
  return Ot(
    o.map((b) => ({
      radius: r * b.radius,
      x: e + y + (b.x - a.min) * r,
      y: e + d + (b.y - c.min) * r,
      setid: b.setid
    }))
  );
}
function Ot(t) {
  const n = {};
  for (const s of t)
    n[s.setid] = s;
  return n;
}
function Ft(t) {
  return Object.keys(t).map((s) => Object.assign(t[s], { setid: s }));
}
function be(t = {}) {
  let n = !1, s = 600, e = 350, i = 15, o = 1e3, a = Math.PI / 2, c = !0, h = null, u = !0, r = !0, y = null, d = null, b = !1, x = null, M = t && t.symmetricalTextCentre ? t.symmetricalTextCentre : !1, A = {}, E = t && t.colourScheme ? t.colourScheme : t && t.colorScheme ? t.colorScheme : [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#17becf"
  ], S = 0, g = function(p) {
    if (p in A)
      return A[p];
    var f = A[p] = E[S];
    return S += 1, S >= E.length && (S = 0), f;
  }, m = At, v = tt;
  function l(p) {
    let f = p.datum();
    const N = /* @__PURE__ */ new Set();
    f.forEach((k) => {
      k.size == 0 && k.sets.length == 1 && N.add(k.sets[0]);
    }), f = f.filter((k) => !k.sets.some((F) => N.has(F)));
    let I = {}, C = {};
    if (f.length > 0) {
      let k = m(f, { lossFunction: v, distinct: b });
      c && (k = Dt(k, a, d)), I = Nt(k, s, e, i, h), C = jt(I, f, M);
    }
    const U = {};
    f.forEach((k) => {
      k.label && (U[k.sets] = k.label);
    });
    function j(k) {
      if (k.sets in U)
        return U[k.sets];
      if (k.sets.length == 1)
        return "" + k.sets[0];
    }
    p.selectAll("svg").data([I]).enter().append("svg");
    const T = p.select("svg");
    n ? T.attr("viewBox", `0 0 ${s} ${e}`) : T.attr("width", s).attr("height", e);
    const R = {};
    let _ = !1;
    T.selectAll(".venn-area path").each(function(k) {
      const F = this.getAttribute("d");
      k.sets.length == 1 && F && !b && (_ = !0, R[k.sets[0]] = ke(F));
    });
    function P(k) {
      return (F) => {
        const H = k.sets.map((et) => {
          let Y = R[et], Z = I[et];
          return Y || (Y = { x: s / 2, y: e / 2, radius: 1 }), Z || (Z = { x: s / 2, y: e / 2, radius: 1 }), {
            x: Y.x * (1 - F) + Z.x * F,
            y: Y.y * (1 - F) + Z.y * F,
            radius: Y.radius * (1 - F) + Z.radius * F
          };
        });
        return St(H, x);
      };
    }
    const V = T.selectAll(".venn-area").data(f, (k) => k.sets), O = V.enter().append("g").attr(
      "class",
      (k) => `venn-area venn-${k.sets.length == 1 ? "circle" : "intersection"}${k.colour || k.color ? " venn-coloured" : ""}`
    ).attr("data-venn-sets", (k) => k.sets.join("_")), B = O.append("path"), W = O.append("text").attr("class", "label").text((k) => j(k)).attr("text-anchor", "middle").attr("dy", ".35em").attr("x", s / 2).attr("y", e / 2);
    r && (B.style("fill-opacity", "0").filter((k) => k.sets.length == 1).style("fill", (k) => k.colour ? k.colour : k.color ? k.color : g(k.sets)).style("fill-opacity", ".25"), W.style("fill", (k) => k.colour || k.color ? "#FFF" : t.textFill ? t.textFill : k.sets.length == 1 ? g(k.sets) : "#444"));
    function K(k) {
      return typeof k.transition == "function" ? k.transition("venn").duration(o) : k;
    }
    let z = p;
    _ && typeof z.transition == "function" ? (z = K(p), z.selectAll("path").attrTween("d", P)) : z.selectAll("path").attr("d", (k) => St(k.sets.map((F) => I[F])), x);
    const L = z.selectAll("text").filter((k) => k.sets in C).text((k) => j(k)).attr("x", (k) => Math.floor(C[k.sets].x)).attr("y", (k) => Math.floor(C[k.sets].y));
    u && (_ ? "on" in L ? L.on("end", rt(I, j)) : L.each("end", rt(I, j)) : L.each(rt(I, j)));
    const D = K(V.exit()).remove();
    typeof V.transition == "function" && D.selectAll("path").attrTween("d", P);
    const X = D.selectAll("text").attr("x", s / 2).attr("y", e / 2);
    return y !== null && (W.style("font-size", "0px"), L.style("font-size", y), X.style("font-size", "0px")), { circles: I, textCentres: C, nodes: V, enter: O, update: z, exit: D };
  }
  return l.wrap = function(p) {
    return arguments.length ? (u = p, l) : u;
  }, l.useViewBox = function() {
    return n = !0, l;
  }, l.width = function(p) {
    return arguments.length ? (s = p, l) : s;
  }, l.height = function(p) {
    return arguments.length ? (e = p, l) : e;
  }, l.padding = function(p) {
    return arguments.length ? (i = p, l) : i;
  }, l.distinct = function(p) {
    return arguments.length ? (b = p, l) : b;
  }, l.colours = function(p) {
    return arguments.length ? (g = p, l) : g;
  }, l.colors = function(p) {
    return arguments.length ? (g = p, l) : g;
  }, l.fontSize = function(p) {
    return arguments.length ? (y = p, l) : y;
  }, l.round = function(p) {
    return arguments.length ? (x = p, l) : x;
  }, l.duration = function(p) {
    return arguments.length ? (o = p, l) : o;
  }, l.layoutFunction = function(p) {
    return arguments.length ? (m = p, l) : m;
  }, l.normalize = function(p) {
    return arguments.length ? (c = p, l) : c;
  }, l.scaleToFit = function(p) {
    return arguments.length ? (h = p, l) : h;
  }, l.styled = function(p) {
    return arguments.length ? (r = p, l) : r;
  }, l.orientation = function(p) {
    return arguments.length ? (a = p, l) : a;
  }, l.orientationOrder = function(p) {
    return arguments.length ? (d = p, l) : d;
  }, l.lossFunction = function(p) {
    return arguments.length ? (v = p === "default" ? tt : p === "logRatio" ? Ct : p, l) : v;
  }, l;
}
function rt(t, n) {
  return function(s) {
    const e = this, i = t[s.sets[0]].radius || 50, o = n(s) || "", a = o.split(/\s+/).reverse(), h = (o.length + a.length) / 3;
    let u = a.pop(), r = [u], y = 0;
    const d = 1.1;
    e.textContent = null;
    const b = [];
    function x(g) {
      const m = e.ownerDocument.createElementNS(e.namespaceURI, "tspan");
      return m.textContent = g, b.push(m), e.append(m), m;
    }
    let M = x(u);
    for (; u = a.pop(), !!u; ) {
      r.push(u);
      const g = r.join(" ");
      M.textContent = g, g.length > h && M.getComputedTextLength() > i && (r.pop(), M.textContent = r.join(" "), r = [u], M = x(u), y++);
    }
    const A = 0.35 - y * d / 2, E = e.getAttribute("x"), S = e.getAttribute("y");
    b.forEach((g, m) => {
      g.setAttribute("x", E), g.setAttribute("y", S), g.setAttribute("dy", `${A + m * d}em`);
    });
  };
}
function at(t, n, s) {
  let e = n[0].radius - q(n[0], t);
  for (let i = 1; i < n.length; ++i) {
    const o = n[i].radius - q(n[i], t);
    o <= e && (e = o);
  }
  for (let i = 0; i < s.length; ++i) {
    const o = q(s[i], t) - s[i].radius;
    o <= e && (e = o);
  }
  return e;
}
function Lt(t, n, s) {
  const e = [];
  for (const r of t)
    e.push({ x: r.x, y: r.y }), e.push({ x: r.x + r.radius / 2, y: r.y }), e.push({ x: r.x - r.radius / 2, y: r.y }), e.push({ x: r.x, y: r.y + r.radius / 2 }), e.push({ x: r.x, y: r.y - r.radius / 2 });
  let i = e[0], o = at(e[0], t, n);
  for (let r = 1; r < e.length; ++r) {
    const y = at(e[r], t, n);
    y >= o && (i = e[r], o = y);
  }
  const a = zt(
    (r) => -1 * at({ x: r[0], y: r[1] }, t, n),
    [i.x, i.y],
    { maxIterations: 500, minErrorDelta: 1e-10 }
  ).x, c = { x: s ? 0 : a[0], y: a[1] };
  let h = !0;
  for (const r of t)
    if (q(c, r) > r.radius) {
      h = !1;
      break;
    }
  for (const r of n)
    if (q(c, r) < r.radius) {
      h = !1;
      break;
    }
  if (h)
    return c;
  if (t.length == 1)
    return { x: t[0].x, y: t[0].y };
  const u = {};
  return st(t, u), u.arcs.length === 0 ? { x: 0, y: -1e3, disjoint: !0 } : u.arcs.length == 1 ? { x: u.arcs[0].circle.x, y: u.arcs[0].circle.y } : n.length ? Lt(t, []) : Tt(u.arcs.map((r) => r.p1));
}
function ve(t) {
  const n = {}, s = Object.keys(t);
  for (const e of s)
    n[e] = [];
  for (let e = 0; e < s.length; e++) {
    const i = s[e], o = t[i];
    for (let a = e + 1; a < s.length; ++a) {
      const c = s[a], h = t[c], u = q(o, h);
      u + h.radius <= o.radius + 1e-10 ? n[c].push(i) : u + o.radius <= h.radius + 1e-10 && n[i].push(c);
    }
  }
  return n;
}
function jt(t, n, s) {
  const e = {}, i = ve(t);
  for (let o = 0; o < n.length; ++o) {
    const a = n[o].sets, c = {}, h = {};
    for (let d = 0; d < a.length; ++d) {
      c[a[d]] = !0;
      const b = i[a[d]];
      for (let x = 0; x < b.length; ++x)
        h[b[x]] = !0;
    }
    const u = [], r = [];
    for (let d in t)
      d in c ? u.push(t[d]) : d in h || r.push(t[d]);
    const y = Lt(u, r, s);
    e[a] = y, y.disjoint && n[o].size > 0 && console.log("WARNING: area " + a + " not represented on screen");
  }
  return e;
}
function Ie(t, n, s) {
  const e = [];
  return e.push(`
M`, t, n), e.push(`
m`, -s, 0), e.push(`
a`, s, s, 0, 1, 0, s * 2, 0), e.push(`
a`, s, s, 0, 1, 0, -s * 2, 0), e.join(" ");
}
function ke(t) {
  const n = t.split(" ");
  return { x: Number.parseFloat(n[1]), y: Number.parseFloat(n[2]), radius: -Number.parseFloat(n[4]) };
}
function Pt(t) {
  if (t.length === 0)
    return [];
  const n = {};
  return st(t, n), n.arcs;
}
function Vt(t, n) {
  if (t.length === 0)
    return "M 0 0";
  const s = Math.pow(10, n || 0), e = n != null ? (o) => Math.round(o * s) / s : (o) => o;
  if (t.length == 1) {
    const o = t[0].circle;
    return Ie(e(o.x), e(o.y), e(o.radius));
  }
  const i = [`
M`, e(t[0].p2.x), e(t[0].p2.y)];
  for (const o of t) {
    const a = e(o.circle.radius);
    i.push(`
A`, a, a, 0, o.large ? 1 : 0, o.sweep ? 1 : 0, e(o.p1.x), e(o.p1.y));
  }
  return i.join(" ");
}
function St(t, n) {
  return Vt(Pt(t), n);
}
function Me(t, n = {}) {
  const {
    lossFunction: s,
    layoutFunction: e = At,
    normalize: i = !0,
    orientation: o = Math.PI / 2,
    orientationOrder: a,
    width: c = 600,
    height: h = 350,
    padding: u = 15,
    scaleToFit: r = !1,
    symmetricalTextCentre: y = !1,
    distinct: d,
    round: b = 2
  } = n;
  let x = e(t, {
    lossFunction: s === "default" || !s ? tt : s === "logRatio" ? Ct : s,
    distinct: d
  });
  i && (x = Dt(x, o, a));
  const M = Nt(x, c, h, u, r), A = jt(M, t, y), E = new Map(
    Object.keys(M).map((m) => [
      m,
      {
        set: m,
        x: M[m].x,
        y: M[m].y,
        radius: M[m].radius
      }
    ])
  ), S = t.map((m) => {
    const v = m.sets.map((f) => E.get(f)), l = Pt(v), p = Vt(l, b);
    return { circles: v, arcs: l, path: p, area: m, has: new Set(m.sets) };
  });
  function g(m) {
    let v = "";
    for (const l of S)
      l.has.size > m.length && m.every((p) => l.has.has(p)) && (v += " " + l.path);
    return v;
  }
  return S.map(({ circles: m, arcs: v, path: l, area: p }) => ({
    data: p,
    text: A[p.sets],
    circles: m,
    arcs: v,
    path: l,
    distinctPath: l + g(p.sets)
  }));
}
var gt = (function() {
  var t = /* @__PURE__ */ w(function(S, g, m, v) {
    for (m = m || {}, v = S.length; v--; m[S[v]] = g) ;
    return m;
  }, "o"), n = [5, 8], s = [7, 8, 11, 12, 17, 19, 22, 24], e = [1, 17], i = [1, 18], o = [7, 8, 11, 12, 14, 15, 16, 17, 19, 20, 21, 22, 24, 27], a = [1, 31], c = [1, 39], h = [7, 8, 11, 12, 17, 19, 22, 24, 27], u = [1, 57], r = [1, 56], y = [1, 58], d = [1, 59], b = [1, 60], x = [7, 8, 11, 12, 16, 17, 19, 20, 22, 24, 27, 31, 32, 33], M = {
    trace: /* @__PURE__ */ w(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, optNewlines: 4, VENN: 5, document: 6, EOF: 7, NEWLINE: 8, line: 9, statement: 10, TITLE: 11, SET: 12, identifier: 13, BRACKET_LABEL: 14, COLON: 15, NUMERIC: 16, UNION: 17, identifierList: 18, TEXT: 19, IDENTIFIER: 20, STRING: 21, INDENT_TEXT: 22, indentedTextTail: 23, STYLE: 24, stylesOpt: 25, styleField: 26, COMMA: 27, styleValue: 28, valueTokens: 29, valueToken: 30, HEXCOLOR: 31, RGBCOLOR: 32, RGBACOLOR: 33, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 5: "VENN", 7: "EOF", 8: "NEWLINE", 11: "TITLE", 12: "SET", 14: "BRACKET_LABEL", 15: "COLON", 16: "NUMERIC", 17: "UNION", 19: "TEXT", 20: "IDENTIFIER", 21: "STRING", 22: "INDENT_TEXT", 24: "STYLE", 27: "COMMA", 31: "HEXCOLOR", 32: "RGBCOLOR", 33: "RGBACOLOR" },
    productions_: [0, [3, 4], [4, 0], [4, 2], [6, 0], [6, 2], [9, 1], [9, 1], [10, 1], [10, 2], [10, 3], [10, 4], [10, 5], [10, 2], [10, 3], [10, 4], [10, 5], [10, 3], [10, 3], [10, 3], [10, 4], [10, 4], [10, 2], [10, 3], [23, 1], [23, 1], [23, 1], [23, 2], [23, 2], [25, 1], [25, 3], [26, 3], [28, 1], [28, 1], [29, 1], [29, 2], [30, 1], [30, 1], [30, 1], [30, 1], [30, 1], [18, 1], [18, 3], [13, 1], [13, 1]],
    performAction: /* @__PURE__ */ w(function(g, m, v, l, p, f, N) {
      var I = f.length - 1;
      switch (p) {
        case 1:
          return f[I - 1];
        case 2:
        case 3:
        case 4:
          this.$ = [];
          break;
        case 5:
          f[I - 1].push(f[I]), this.$ = f[I - 1];
          break;
        case 6:
          this.$ = [];
          break;
        case 7:
        case 22:
        case 32:
        case 36:
        case 37:
        case 38:
        case 39:
        case 40:
          this.$ = f[I];
          break;
        case 8:
          l.setDiagramTitle(f[I].substr(6)), this.$ = f[I].substr(6);
          break;
        case 9:
          l.addSubsetData([f[I]], void 0, void 0), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 10:
          l.addSubsetData([f[I - 1]], f[I], void 0), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 11:
          l.addSubsetData([f[I - 2]], void 0, parseFloat(f[I])), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 12:
          l.addSubsetData([f[I - 3]], f[I - 2], parseFloat(f[I])), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 13:
          if (f[I].length < 2)
            throw new Error("union requires multiple identifiers");
          l.validateUnionIdentifiers && l.validateUnionIdentifiers(f[I]), l.addSubsetData(f[I], void 0, void 0), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 14:
          if (f[I - 1].length < 2)
            throw new Error("union requires multiple identifiers");
          l.validateUnionIdentifiers && l.validateUnionIdentifiers(f[I - 1]), l.addSubsetData(f[I - 1], f[I], void 0), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 15:
          if (f[I - 2].length < 2)
            throw new Error("union requires multiple identifiers");
          l.validateUnionIdentifiers && l.validateUnionIdentifiers(f[I - 2]), l.addSubsetData(f[I - 2], void 0, parseFloat(f[I])), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 16:
          if (f[I - 3].length < 2)
            throw new Error("union requires multiple identifiers");
          l.validateUnionIdentifiers && l.validateUnionIdentifiers(f[I - 3]), l.addSubsetData(f[I - 3], f[I - 2], parseFloat(f[I])), l.setIndentMode && l.setIndentMode(!0);
          break;
        case 17:
        case 18:
        case 19:
          l.addTextData(f[I - 1], f[I], void 0);
          break;
        case 20:
        case 21:
          l.addTextData(f[I - 2], f[I - 1], f[I]);
          break;
        case 23:
          l.addStyleData(f[I - 1], f[I]);
          break;
        case 24:
        case 25:
        case 26:
          var C = l.getCurrentSets();
          if (!C) throw new Error("text requires set");
          l.addTextData(C, f[I], void 0);
          break;
        case 27:
        case 28:
          var C = l.getCurrentSets();
          if (!C) throw new Error("text requires set");
          l.addTextData(C, f[I - 1], f[I]);
          break;
        case 29:
        case 41:
          this.$ = [f[I]];
          break;
        case 30:
        case 42:
          this.$ = [...f[I - 2], f[I]];
          break;
        case 31:
          this.$ = [f[I - 2], f[I]];
          break;
        case 33:
          this.$ = f[I].join(" ");
          break;
        case 34:
          this.$ = [f[I]];
          break;
        case 35:
          f[I - 1].push(f[I]), this.$ = f[I - 1];
          break;
        case 43:
        case 44:
          this.$ = f[I];
          break;
      }
    }, "anonymous"),
    table: [t(n, [2, 2], { 3: 1, 4: 2 }), { 1: [3] }, { 5: [1, 3], 8: [1, 4] }, t(s, [2, 4], { 6: 5 }), t(n, [2, 3]), { 7: [1, 6], 8: [1, 8], 9: 7, 10: 9, 11: [1, 10], 12: [1, 11], 17: [1, 12], 19: [1, 13], 22: [1, 14], 24: [1, 15] }, { 1: [2, 1] }, t(s, [2, 5]), t(s, [2, 6]), t(s, [2, 7]), t(s, [2, 8]), { 13: 16, 20: e, 21: i }, { 13: 20, 18: 19, 20: e, 21: i }, { 13: 20, 18: 21, 20: e, 21: i }, { 16: [1, 25], 20: [1, 23], 21: [1, 24], 23: 22 }, { 13: 20, 18: 26, 20: e, 21: i }, t(s, [2, 9], { 14: [1, 27], 15: [1, 28] }), t(o, [2, 43]), t(o, [2, 44]), t(s, [2, 13], { 14: [1, 29], 15: [1, 30], 27: a }), t(o, [2, 41]), { 16: [1, 34], 20: [1, 32], 21: [1, 33], 27: a }, t(s, [2, 22]), t(s, [2, 24], { 14: [1, 35] }), t(s, [2, 25], { 14: [1, 36] }), t(s, [2, 26]), { 20: c, 25: 37, 26: 38, 27: a }, t(s, [2, 10], { 15: [1, 40] }), { 16: [1, 41] }, t(s, [2, 14], { 15: [1, 42] }), { 16: [1, 43] }, { 13: 44, 20: e, 21: i }, t(s, [2, 17], { 14: [1, 45] }), t(s, [2, 18], { 14: [1, 46] }), t(s, [2, 19]), t(s, [2, 27]), t(s, [2, 28]), t(s, [2, 23], { 27: [1, 47] }), t(h, [2, 29]), { 15: [1, 48] }, { 16: [1, 49] }, t(s, [2, 11]), { 16: [1, 50] }, t(s, [2, 15]), t(o, [2, 42]), t(s, [2, 20]), t(s, [2, 21]), { 20: c, 26: 51 }, { 16: u, 20: r, 21: [1, 53], 28: 52, 29: 54, 30: 55, 31: y, 32: d, 33: b }, t(s, [2, 12]), t(s, [2, 16]), t(h, [2, 30]), t(h, [2, 31]), t(h, [2, 32]), t(h, [2, 33], { 30: 61, 16: u, 20: r, 31: y, 32: d, 33: b }), t(x, [2, 34]), t(x, [2, 36]), t(x, [2, 37]), t(x, [2, 38]), t(x, [2, 39]), t(x, [2, 40]), t(x, [2, 35])],
    defaultActions: { 6: [2, 1] },
    parseError: /* @__PURE__ */ w(function(g, m) {
      if (m.recoverable)
        this.trace(g);
      else {
        var v = new Error(g);
        throw v.hash = m, v;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ w(function(g) {
      var m = this, v = [0], l = [], p = [null], f = [], N = this.table, I = "", C = 0, U = 0, j = 2, T = 1, R = f.slice.call(arguments, 1), _ = Object.create(this.lexer), P = { yy: {} };
      for (var V in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, V) && (P.yy[V] = this.yy[V]);
      _.setInput(g, P.yy), P.yy.lexer = _, P.yy.parser = this, typeof _.yylloc > "u" && (_.yylloc = {});
      var O = _.yylloc;
      f.push(O);
      var B = _.options && _.options.ranges;
      typeof P.yy.parseError == "function" ? this.parseError = P.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function W(G) {
        v.length = v.length - 2 * G, p.length = p.length - G, f.length = f.length - G;
      }
      w(W, "popStack");
      function K() {
        var G;
        return G = l.pop() || _.lex() || T, typeof G != "number" && (G instanceof Array && (l = G, G = l.pop()), G = m.symbols_[G] || G), G;
      }
      w(K, "lex");
      for (var z, L, D, X, k = {}, F, H, et, Y; ; ) {
        if (L = v[v.length - 1], this.defaultActions[L] ? D = this.defaultActions[L] : ((z === null || typeof z > "u") && (z = K()), D = N[L] && N[L][z]), typeof D > "u" || !D.length || !D[0]) {
          var Z = "";
          Y = [];
          for (F in N[L])
            this.terminals_[F] && F > j && Y.push("'" + this.terminals_[F] + "'");
          _.showPosition ? Z = "Parse error on line " + (C + 1) + `:
` + _.showPosition() + `
Expecting ` + Y.join(", ") + ", got '" + (this.terminals_[z] || z) + "'" : Z = "Parse error on line " + (C + 1) + ": Unexpected " + (z == T ? "end of input" : "'" + (this.terminals_[z] || z) + "'"), this.parseError(Z, {
            text: _.match,
            token: this.terminals_[z] || z,
            line: _.yylineno,
            loc: O,
            expected: Y
          });
        }
        if (D[0] instanceof Array && D.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + L + ", token: " + z);
        switch (D[0]) {
          case 1:
            v.push(z), p.push(_.yytext), f.push(_.yylloc), v.push(D[1]), z = null, U = _.yyleng, I = _.yytext, C = _.yylineno, O = _.yylloc;
            break;
          case 2:
            if (H = this.productions_[D[1]][1], k.$ = p[p.length - H], k._$ = {
              first_line: f[f.length - (H || 1)].first_line,
              last_line: f[f.length - 1].last_line,
              first_column: f[f.length - (H || 1)].first_column,
              last_column: f[f.length - 1].last_column
            }, B && (k._$.range = [
              f[f.length - (H || 1)].range[0],
              f[f.length - 1].range[1]
            ]), X = this.performAction.apply(k, [
              I,
              U,
              C,
              P.yy,
              D[1],
              p,
              f
            ].concat(R)), typeof X < "u")
              return X;
            H && (v = v.slice(0, -1 * H * 2), p = p.slice(0, -1 * H), f = f.slice(0, -1 * H)), v.push(this.productions_[D[1]][0]), p.push(k.$), f.push(k._$), et = N[v[v.length - 2]][v[v.length - 1]], v.push(et);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, A = /* @__PURE__ */ (function() {
    var S = {
      EOF: 1,
      parseError: /* @__PURE__ */ w(function(m, v) {
        if (this.yy.parser)
          this.yy.parser.parseError(m, v);
        else
          throw new Error(m);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ w(function(g, m) {
        return this.yy = m || this.yy || {}, this._input = g, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ w(function() {
        var g = this._input[0];
        this.yytext += g, this.yyleng++, this.offset++, this.match += g, this.matched += g;
        var m = g.match(/(?:\r\n?|\n).*/g);
        return m ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), g;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ w(function(g) {
        var m = g.length, v = g.split(/(?:\r\n?|\n)/g);
        this._input = g + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - m), this.offset -= m;
        var l = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), v.length - 1 && (this.yylineno -= v.length - 1);
        var p = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: v ? (v.length === l.length ? this.yylloc.first_column : 0) + l[l.length - v.length].length - v[0].length : this.yylloc.first_column - m
        }, this.options.ranges && (this.yylloc.range = [p[0], p[0] + this.yyleng - m]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ w(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ w(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ w(function(g) {
        this.unput(this.match.slice(g));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ w(function() {
        var g = this.matched.substr(0, this.matched.length - this.match.length);
        return (g.length > 20 ? "..." : "") + g.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ w(function() {
        var g = this.match;
        return g.length < 20 && (g += this._input.substr(0, 20 - g.length)), (g.substr(0, 20) + (g.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ w(function() {
        var g = this.pastInput(), m = new Array(g.length + 1).join("-");
        return g + this.upcomingInput() + `
` + m + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ w(function(g, m) {
        var v, l, p;
        if (this.options.backtrack_lexer && (p = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (p.yylloc.range = this.yylloc.range.slice(0))), l = g[0].match(/(?:\r\n?|\n).*/g), l && (this.yylineno += l.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: l ? l[l.length - 1].length - l[l.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + g[0].length
        }, this.yytext += g[0], this.match += g[0], this.matches = g, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(g[0].length), this.matched += g[0], v = this.performAction.call(this, this.yy, this, m, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), v)
          return v;
        if (this._backtrack) {
          for (var f in p)
            this[f] = p[f];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ w(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var g, m, v, l;
        this._more || (this.yytext = "", this.match = "");
        for (var p = this._currentRules(), f = 0; f < p.length; f++)
          if (v = this._input.match(this.rules[p[f]]), v && (!m || v[0].length > m[0].length)) {
            if (m = v, l = f, this.options.backtrack_lexer) {
              if (g = this.test_match(v, p[f]), g !== !1)
                return g;
              if (this._backtrack) {
                m = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return m ? (g = this.test_match(m, p[l]), g !== !1 ? g : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ w(function() {
        var m = this.next();
        return m || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ w(function(m) {
        this.conditionStack.push(m);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ w(function() {
        var m = this.conditionStack.length - 1;
        return m > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ w(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ w(function(m) {
        return m = this.conditionStack.length - 1 - Math.abs(m || 0), m >= 0 ? this.conditionStack[m] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ w(function(m) {
        this.begin(m);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ w(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ w(function(m, v, l, p) {
        switch (l) {
          case 0:
            break;
          case 1:
            break;
          case 2:
            break;
          case 3:
            if (m.getIndentMode && m.getIndentMode())
              return m.consumeIndentText = !0, this.begin("INITIAL"), 22;
            break;
          case 4:
            break;
          case 5:
            m.setIndentMode && m.setIndentMode(!1), this.begin("INITIAL"), this.unput(v.yytext);
            break;
          case 6:
            return this.begin("bol"), 8;
          case 7:
            break;
          case 8:
            break;
          case 9:
            return 7;
          case 10:
            return 11;
          case 11:
            return 5;
          case 12:
            return 12;
          case 13:
            return 17;
          case 14:
            if (m.consumeIndentText)
              m.consumeIndentText = !1;
            else
              return 19;
            break;
          case 15:
            return 24;
          case 16:
            return v.yytext = v.yytext.slice(2, -2), 14;
          case 17:
            return v.yytext = v.yytext.slice(1, -1).trim(), 14;
          case 18:
            return 16;
          case 19:
            return 31;
          case 20:
            return 33;
          case 21:
            return 32;
          case 22:
            return 20;
          case 23:
            return 21;
          case 24:
            return 27;
          case 25:
            return 15;
        }
      }, "anonymous"),
      rules: [/^(?:%%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[ \t]+(?=[\n\r]))/i, /^(?:[ \t]+(?=text\b))/i, /^(?:[ \t]+)/i, /^(?:[^ \t\n\r])/i, /^(?:[\n\r]+)/i, /^(?:%%[^\n]*)/i, /^(?:[ \t]+)/i, /^(?:$)/i, /^(?:title\s[^#\n;]+)/i, /^(?:venn-beta\b)/i, /^(?:set\b)/i, /^(?:union\b)/i, /^(?:text\b)/i, /^(?:style\b)/i, /^(?:\["[^\"]*"\])/i, /^(?:\[[^\]\"]+\])/i, /^(?:[+-]?(\d+(\.\d+)?|\.\d+))/i, /^(?:#[0-9a-fA-F]{3,8})/i, /^(?:rgba\(\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*\))/i, /^(?:rgb\(\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*\))/i, /^(?:[A-Za-z_][A-Za-z0-9\-_]*)/i, /^(?:"[^\"]*")/i, /^(?:,)/i, /^(?::)/i],
      conditions: { bol: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25], inclusive: !0 }, INITIAL: { rules: [0, 1, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25], inclusive: !0 } }
    };
    return S;
  })();
  M.lexer = A;
  function E() {
    this.yy = {};
  }
  return w(E, "Parser"), E.prototype = M, M.Parser = E, new E();
})();
gt.parser = gt;
var Se = gt, yt = [], pt = [], mt = [], bt = /* @__PURE__ */ new Set(), vt, It = !1, we = /* @__PURE__ */ w((t, n, s) => {
  const e = it(t).sort(), i = s ?? 10 / Math.pow(t.length, 2);
  vt = e, e.length === 1 && bt.add(e[0]), yt.push({
    sets: e,
    size: i,
    label: n ? nt(n) : void 0
  });
}, "addSubsetData"), _e = /* @__PURE__ */ w(() => yt, "getSubsetData"), nt = /* @__PURE__ */ w((t) => {
  const n = t.trim();
  return n.length >= 2 && n.startsWith('"') && n.endsWith('"') ? n.slice(1, -1) : n;
}, "normalizeText"), Ee = /* @__PURE__ */ w((t) => t && nt(t), "normalizeStyleValue"), Te = /* @__PURE__ */ w((t, n, s) => {
  const e = nt(n);
  pt.push({
    sets: it(t).sort(),
    id: e,
    label: s ? nt(s) : void 0
  });
}, "addTextData"), ze = /* @__PURE__ */ w((t, n) => {
  const s = it(t).sort(), e = {};
  for (const [i, o] of n)
    e[i] = Ee(o) ?? o;
  mt.push({ targets: s, styles: e });
}, "addStyleData"), Ae = /* @__PURE__ */ w(() => mt, "getStyleData"), it = /* @__PURE__ */ w((t) => t.map((n) => nt(n)), "normalizeIdentifierList"), Re = /* @__PURE__ */ w((t) => {
  const s = it(t).filter((e) => !bt.has(e));
  if (s.length > 0)
    throw new Error(`unknown set identifier: ${s.join(", ")}`);
}, "validateUnionIdentifiers"), Ce = /* @__PURE__ */ w(() => pt, "getTextData"), De = /* @__PURE__ */ w(() => vt, "getCurrentSets"), Ne = /* @__PURE__ */ w(() => It, "getIndentMode"), Oe = /* @__PURE__ */ w((t) => {
  It = t;
}, "setIndentMode"), Fe = oe.venn;
function Bt() {
  return ie(Fe, wt().venn);
}
w(Bt, "getConfig");
var Le = /* @__PURE__ */ w(() => {
  se(), yt.length = 0, pt.length = 0, mt.length = 0, bt.clear(), vt = void 0, It = !1;
}, "customClear"), je = {
  getConfig: Bt,
  clear: Le,
  setAccTitle: Zt,
  getAccTitle: Xt,
  setDiagramTitle: Yt,
  getDiagramTitle: Ht,
  getAccDescription: Kt,
  setAccDescription: Wt,
  addSubsetData: we,
  getSubsetData: _e,
  addTextData: Te,
  addStyleData: ze,
  validateUnionIdentifiers: Re,
  getTextData: Ce,
  getStyleData: Ae,
  getCurrentSets: De,
  getIndentMode: Ne,
  setIndentMode: Oe
}, Pe = /* @__PURE__ */ w((t) => `
  .venn-title {
    font-size: 32px;
    fill: ${t.vennTitleTextColor};
    font-family: ${t.fontFamily};
  }

  .venn-circle text {
    font-size: 48px;
    font-family: ${t.fontFamily};
  }

  .venn-intersection text {
    font-size: 48px;
    fill: ${t.vennSetTextColor};
    font-family: ${t.fontFamily};
  }

  .venn-text-node {
    font-family: ${t.fontFamily};
    color: ${t.vennSetTextColor};
  }
`, "getStyles"), Ve = Pe;
function qt(t) {
  const n = /* @__PURE__ */ new Map();
  for (const s of t) {
    const e = s.targets.join("|"), i = n.get(e);
    i ? Object.assign(i, s.styles) : n.set(e, { ...s.styles });
  }
  return n;
}
w(qt, "buildStyleByKey");
var Be = /* @__PURE__ */ w((t, n, s, e) => {
  const i = e.db, o = i.getConfig?.(), { themeVariables: a, look: c, handDrawnSeed: h } = wt(), u = c === "handDrawn", r = [
    a.venn1,
    a.venn2,
    a.venn3,
    a.venn4,
    a.venn5,
    a.venn6,
    a.venn7,
    a.venn8
  ].filter(Boolean), y = i.getDiagramTitle?.(), d = i.getSubsetData(), b = i.getTextData(), x = qt(i.getStyleData()), M = o?.width ?? 800, A = o?.height ?? 450, S = M / 1600, g = y ? 48 * S : 0, m = a.primaryTextColor ?? a.textColor, v = Jt(n);
  v.attr("viewBox", `0 0 ${M} ${A}`), y && v.append("text").text(y).attr("class", "venn-title").attr("font-size", `${32 * S}px`).attr("text-anchor", "middle").attr("dominant-baseline", "middle").attr("x", "50%").attr("y", 32 * S).style("fill", a.vennTitleTextColor || a.titleColor);
  const l = ot(document.createElement("div")), p = be().width(M).height(A - g);
  l.datum(d).call(p);
  const f = u ? Qt.svg(l.select("svg").node()) : void 0, N = Me(d, {
    width: M,
    height: A - g,
    padding: o?.padding ?? 15
  }), I = /* @__PURE__ */ new Map();
  for (const T of N) {
    const R = Q([...T.data.sets].sort());
    I.set(R, T);
  }
  b.length > 0 && Ut(o, I, l, b, S, x);
  const C = $t(a.background || "#f4f4f4");
  l.selectAll(".venn-circle").each(function(T, R) {
    const _ = ot(this), V = Q([...T.sets].sort()), O = x.get(V), B = O?.fill || r[R % r.length] || a.primaryColor;
    _.classed(`venn-set-${R % 8}`, !0);
    const W = O?.["fill-opacity"] ?? 0.1, K = O?.stroke || B, z = O?.["stroke-width"] || `${5 * S}`;
    if (u && f) {
      const D = I.get(V);
      if (D && D.circles.length > 0) {
        const X = D.circles[0], k = f.circle(X.x, X.y, X.radius * 2, {
          roughness: 0.7,
          seed: h,
          fill: kt(B, 0.7),
          fillStyle: "hachure",
          fillWeight: 2,
          hachureGap: 8,
          hachureAngle: -41 + R * 60,
          stroke: K,
          strokeWidth: parseFloat(String(z))
        });
        _.select("path").remove(), _.node()?.insertBefore(k, _.select("text").node());
      }
    } else
      _.select("path").style("fill", B).style("fill-opacity", W).style("stroke", K).style("stroke-width", z).style("stroke-opacity", 0.95);
    const L = O?.color || (C ? te(B, 30) : ee(B, 30));
    _.select("text").style("font-size", `${48 * S}px`).style("fill", L);
  }), u && f ? l.selectAll(".venn-intersection").each(function(T) {
    const R = ot(this), P = Q([...T.sets].sort()), V = x.get(P), O = V?.fill;
    if (O) {
      const B = R.select("path"), W = B.attr("d");
      if (W) {
        const K = f.path(W, {
          roughness: 0.7,
          seed: h,
          fill: kt(O, 0.3),
          fillStyle: "cross-hatch",
          fillWeight: 2,
          hachureGap: 6,
          hachureAngle: 60,
          stroke: "none"
        }), z = B.node();
        z?.parentNode?.insertBefore(K, z), B.remove();
      }
    } else
      R.select("path").style("fill-opacity", 0);
    R.select("text").style("font-size", `${48 * S}px`).style("fill", V?.color ?? a.vennSetTextColor ?? m);
  }) : (l.selectAll(".venn-intersection text").style("font-size", `${48 * S}px`).style("fill", (T) => {
    const _ = Q([...T.sets].sort());
    return x.get(_)?.color ?? a.vennSetTextColor ?? m;
  }), l.selectAll(".venn-intersection path").style("fill-opacity", (T) => {
    const _ = Q([...T.sets].sort());
    return x.get(_)?.fill ? 1 : 0;
  }).style("fill", (T) => {
    const _ = Q([...T.sets].sort());
    return x.get(_)?.fill ?? "transparent";
  }));
  const U = v.append("g").attr("transform", `translate(0, ${g})`), j = l.select("svg").node();
  if (j && "childNodes" in j)
    for (const T of [...j.childNodes])
      U.node()?.appendChild(T);
  ne(v, A, M, o?.useMaxWidth ?? !0);
}, "draw");
function Q(t) {
  return t.join("|");
}
w(Q, "stableSetsKey");
function Ut(t, n, s, e, i, o) {
  const a = t?.useDebugLayout ?? !1, h = s.select("svg").append("g").attr("class", "venn-text-nodes"), u = /* @__PURE__ */ new Map();
  for (const r of e) {
    const y = Q(r.sets), d = u.get(y);
    d ? d.push(r) : u.set(y, [r]);
  }
  for (const [r, y] of u.entries()) {
    const d = n.get(r);
    if (!d?.text)
      continue;
    const b = d.text.x, x = d.text.y, M = Math.min(...d.circles.map((T) => T.radius)), A = Math.min(
      ...d.circles.map((T) => T.radius - Math.hypot(b - T.x, x - T.y))
    );
    let E = Number.isFinite(A) ? Math.max(0, A) : 0;
    E === 0 && Number.isFinite(M) && (E = M * 0.6);
    const S = h.append("g").attr("class", "venn-text-area").attr("font-size", `${40 * i}px`);
    a && S.append("circle").attr("class", "venn-text-debug-circle").attr("cx", b).attr("cy", x).attr("r", E).attr("fill", "none").attr("stroke", "purple").attr("stroke-width", 1.5 * i).attr("stroke-dasharray", `${6 * i} ${4 * i}`);
    const g = Math.max(80 * i, E * 2 * 0.95), m = Math.max(60 * i, E * 2 * 0.95), p = (d.data.label && d.data.label.length > 0 ? Math.min(32 * i, E * 0.25) : 0) + (y.length <= 2 ? 30 * i : 0), f = b - g / 2, N = x - m / 2 + p, I = Math.max(1, Math.ceil(Math.sqrt(y.length))), C = Math.max(1, Math.ceil(y.length / I)), U = g / I, j = m / C;
    for (const [T, R] of y.entries()) {
      const _ = T % I, P = Math.floor(T / I), V = f + U * (_ + 0.5), O = N + j * (P + 0.5);
      a && S.append("rect").attr("class", "venn-text-debug-cell").attr("x", f + U * _).attr("y", N + j * P).attr("width", U).attr("height", j).attr("fill", "none").attr("stroke", "teal").attr("stroke-width", 1 * i).attr("stroke-dasharray", `${4 * i} ${3 * i}`);
      const B = U * 0.9, W = j * 0.9, K = S.append("foreignObject").attr("class", "venn-text-node-fo").attr("width", B).attr("height", W).attr("x", V - B / 2).attr("y", O - W / 2).attr("overflow", "visible"), z = o.get(R.id)?.color, L = K.append("xhtml:span").attr("class", "venn-text-node").style("display", "flex").style("width", "100%").style("height", "100%").style("white-space", "normal").style("align-items", "center").style("justify-content", "center").style("text-align", "center").style("overflow-wrap", "normal").style("word-break", "normal").text(R.label ?? R.id);
      z && L.style("color", z);
    }
  }
}
w(Ut, "renderTextNodes");
var qe = { draw: Be }, Ge = {
  parser: Se,
  db: je,
  renderer: qe,
  styles: Ve
};
export {
  Ge as diagram
};
