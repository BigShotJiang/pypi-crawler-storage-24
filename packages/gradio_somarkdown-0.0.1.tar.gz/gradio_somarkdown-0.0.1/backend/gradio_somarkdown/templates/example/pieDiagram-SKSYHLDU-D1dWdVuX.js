import { a4 as S, a7 as z, aJ as j, g as q, s as J, a as Z, b as H, q as K, p as Q, _ as p, l as F, c as X, E as Y, I as ee, N as te, e as ae, z as re, F as ne } from "./mermaid.core-CbLi0pBF.js";
import { p as ie } from "./chunk-4BX2VUAB-CjvniHW0.js";
import { p as se } from "./treemap-KZPCXAKY-DhtVEf_b.js";
import { d as R } from "./arc-BxioCF2F.js";
import { o as le } from "./ordinal-B6-f3MAq.js";
function oe(e, a) {
  return a < e ? -1 : a > e ? 1 : a >= e ? 0 : NaN;
}
function ce(e) {
  return e;
}
function ue() {
  var e = ce, a = oe, f = null, x = S(0), s = S(z), o = S(0);
  function l(t) {
    var n, c = (t = j(t)).length, d, y, m = 0, u = new Array(c), i = new Array(c), v = +x.apply(this, arguments), w = Math.min(z, Math.max(-z, s.apply(this, arguments) - v)), h, C = Math.min(Math.abs(w) / c, o.apply(this, arguments)), $ = C * (w < 0 ? -1 : 1), g;
    for (n = 0; n < c; ++n)
      (g = i[u[n] = n] = +e(t[n], n, t)) > 0 && (m += g);
    for (a != null ? u.sort(function(A, D) {
      return a(i[A], i[D]);
    }) : f != null && u.sort(function(A, D) {
      return f(t[A], t[D]);
    }), n = 0, y = m ? (w - c * $) / m : 0; n < c; ++n, v = h)
      d = u[n], g = i[d], h = v + (g > 0 ? g * y : 0) + $, i[d] = {
        data: t[d],
        index: n,
        value: g,
        startAngle: v,
        endAngle: h,
        padAngle: C
      };
    return i;
  }
  return l.value = function(t) {
    return arguments.length ? (e = typeof t == "function" ? t : S(+t), l) : e;
  }, l.sortValues = function(t) {
    return arguments.length ? (a = t, f = null, l) : a;
  }, l.sort = function(t) {
    return arguments.length ? (f = t, a = null, l) : f;
  }, l.startAngle = function(t) {
    return arguments.length ? (x = typeof t == "function" ? t : S(+t), l) : x;
  }, l.endAngle = function(t) {
    return arguments.length ? (s = typeof t == "function" ? t : S(+t), l) : s;
  }, l.padAngle = function(t) {
    return arguments.length ? (o = typeof t == "function" ? t : S(+t), l) : o;
  }, l;
}
var pe = ne.pie, N = {
  sections: /* @__PURE__ */ new Map(),
  showData: !1
}, T = N.sections, G = N.showData, de = structuredClone(pe), ge = /* @__PURE__ */ p(() => structuredClone(de), "getConfig"), fe = /* @__PURE__ */ p(() => {
  T = /* @__PURE__ */ new Map(), G = N.showData, re();
}, "clear"), he = /* @__PURE__ */ p(({ label: e, value: a }) => {
  if (a < 0)
    throw new Error(
      `"${e}" has invalid value: ${a}. Negative values are not allowed in pie charts. All slice values must be >= 0.`
    );
  T.has(e) || (T.set(e, a), F.debug(`added new section: ${e}, with value: ${a}`));
}, "addSection"), me = /* @__PURE__ */ p(() => T, "getSections"), ve = /* @__PURE__ */ p((e) => {
  G = e;
}, "setShowData"), Se = /* @__PURE__ */ p(() => G, "getShowData"), L = {
  getConfig: ge,
  clear: fe,
  setDiagramTitle: Q,
  getDiagramTitle: K,
  setAccTitle: H,
  getAccTitle: Z,
  setAccDescription: J,
  getAccDescription: q,
  addSection: he,
  getSections: me,
  setShowData: ve,
  getShowData: Se
}, xe = /* @__PURE__ */ p((e, a) => {
  ie(e, a), a.setShowData(e.showData), e.sections.map(a.addSection);
}, "populateDb"), ye = {
  parse: /* @__PURE__ */ p(async (e) => {
    const a = await se("pie", e);
    F.debug(a), xe(a, L);
  }, "parse")
}, we = /* @__PURE__ */ p((e) => `
  .pieCircle{
    stroke: ${e.pieStrokeColor};
    stroke-width : ${e.pieStrokeWidth};
    opacity : ${e.pieOpacity};
  }
  .pieOuterCircle{
    stroke: ${e.pieOuterStrokeColor};
    stroke-width: ${e.pieOuterStrokeWidth};
    fill: none;
  }
  .pieTitleText {
    text-anchor: middle;
    font-size: ${e.pieTitleTextSize};
    fill: ${e.pieTitleTextColor};
    font-family: ${e.fontFamily};
  }
  .slice {
    font-family: ${e.fontFamily};
    fill: ${e.pieSectionTextColor};
    font-size:${e.pieSectionTextSize};
    // fill: white;
  }
  .legend text {
    fill: ${e.pieLegendTextColor};
    font-family: ${e.fontFamily};
    font-size: ${e.pieLegendTextSize};
  }
`, "getStyles"), Ae = we, De = /* @__PURE__ */ p((e) => {
  const a = [...e.values()].reduce((s, o) => s + o, 0), f = [...e.entries()].map(([s, o]) => ({ label: s, value: o })).filter((s) => s.value / a * 100 >= 1).sort((s, o) => o.value - s.value);
  return ue().value((s) => s.value)(f);
}, "createPieArcs"), Ce = /* @__PURE__ */ p((e, a, f, x) => {
  F.debug(`rendering pie chart
` + e);
  const s = x.db, o = X(), l = Y(s.getConfig(), o.pie), t = 40, n = 18, c = 4, d = 450, y = d, m = ee(a), u = m.append("g");
  u.attr("transform", "translate(" + y / 2 + "," + d / 2 + ")");
  const { themeVariables: i } = o;
  let [v] = te(i.pieOuterStrokeWidth);
  v ??= 2;
  const w = l.textPosition, h = Math.min(y, d) / 2 - t, C = R().innerRadius(0).outerRadius(h), $ = R().innerRadius(h * w).outerRadius(h * w);
  u.append("circle").attr("cx", 0).attr("cy", 0).attr("r", h + v / 2).attr("class", "pieOuterCircle");
  const g = s.getSections(), A = De(g), D = [
    i.pie1,
    i.pie2,
    i.pie3,
    i.pie4,
    i.pie5,
    i.pie6,
    i.pie7,
    i.pie8,
    i.pie9,
    i.pie10,
    i.pie11,
    i.pie12
  ];
  let E = 0;
  g.forEach((r) => {
    E += r;
  });
  const W = A.filter((r) => (r.data.value / E * 100).toFixed(0) !== "0"), b = le(D);
  u.selectAll("mySlices").data(W).enter().append("path").attr("d", C).attr("fill", (r) => b(r.data.label)).attr("class", "pieCircle"), u.selectAll("mySlices").data(W).enter().append("text").text((r) => (r.data.value / E * 100).toFixed(0) + "%").attr("transform", (r) => "translate(" + $.centroid(r) + ")").style("text-anchor", "middle").attr("class", "slice"), u.append("text").text(s.getDiagramTitle()).attr("x", 0).attr("y", -400 / 2).attr("class", "pieTitleText");
  const I = [...g.entries()].map(([r, M]) => ({
    label: r,
    value: M
  })), k = u.selectAll(".legend").data(I).enter().append("g").attr("class", "legend").attr("transform", (r, M) => {
    const P = n + c, B = P * I.length / 2, V = 12 * n, U = M * P - B;
    return "translate(" + V + "," + U + ")";
  });
  k.append("rect").attr("width", n).attr("height", n).style("fill", (r) => b(r.label)).style("stroke", (r) => b(r.label)), k.append("text").attr("x", n + c).attr("y", n - c).text((r) => s.getShowData() ? `${r.label} [${r.value}]` : r.label);
  const _ = Math.max(
    ...k.selectAll("text").nodes().map((r) => r?.getBoundingClientRect().width ?? 0)
  ), O = y + t + n + c + _;
  m.attr("viewBox", `0 0 ${O} ${d}`), ae(m, d, O, l.useMaxWidth);
}, "draw"), $e = { draw: Ce }, ze = {
  parser: ye,
  db: L,
  renderer: $e,
  styles: Ae
};
export {
  ze as diagram
};
