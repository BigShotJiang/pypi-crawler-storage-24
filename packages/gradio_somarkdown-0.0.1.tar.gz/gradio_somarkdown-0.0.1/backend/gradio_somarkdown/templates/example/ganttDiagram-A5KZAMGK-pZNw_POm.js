import { b2 as an, b3 as Wn, b4 as on, b5 as cn, b6 as un, b7 as ce, b8 as $n, g as On, s as Hn, q as Nn, p as Pn, a as Rn, b as Vn, _ as d, c as _t, d as Zt, e as zn, b9 as rt, l as Tt, k as qn, j as Zn, z as Bn, u as Xn } from "./mermaid.core-CbLi0pBF.js";
import { g as ae } from "./Example-DvozunpH.js";
import { b as Gn, t as He, c as jn, a as Qn, l as Jn } from "./linear-BgqqqmCb.js";
import { i as Kn } from "./init-DjUOC4st.js";
function tr(t, e) {
  let n;
  if (e === void 0)
    for (const r of t)
      r != null && (n < r || n === void 0 && r >= r) && (n = r);
  else {
    let r = -1;
    for (let i of t)
      (i = e(i, ++r, t)) != null && (n < i || n === void 0 && i >= i) && (n = i);
  }
  return n;
}
function er(t, e) {
  let n;
  if (e === void 0)
    for (const r of t)
      r != null && (n > r || n === void 0 && r >= r) && (n = r);
  else {
    let r = -1;
    for (let i of t)
      (i = e(i, ++r, t)) != null && (n > i || n === void 0 && i >= i) && (n = i);
  }
  return n;
}
function nr(t) {
  return t;
}
var Xt = 1, ue = 2, Te = 3, Bt = 4, Ne = 1e-6;
function rr(t) {
  return "translate(" + t + ",0)";
}
function ir(t) {
  return "translate(0," + t + ")";
}
function sr(t) {
  return (e) => +t(e);
}
function ar(t, e) {
  return e = Math.max(0, t.bandwidth() - e * 2) / 2, t.round() && (e = Math.round(e)), (n) => +t(n) + e;
}
function or() {
  return !this.__axis;
}
function ln(t, e) {
  var n = [], r = null, i = null, a = 6, c = 6, m = 3, Y = typeof window < "u" && window.devicePixelRatio > 1 ? 0 : 0.5, C = t === Xt || t === Bt ? -1 : 1, k = t === Bt || t === ue ? "x" : "y", I = t === Xt || t === Te ? rr : ir;
  function _(S) {
    var Z = r ?? (e.ticks ? e.ticks.apply(e, n) : e.domain()), A = i ?? (e.tickFormat ? e.tickFormat.apply(e, n) : nr), U = Math.max(a, 0) + m, L = e.range(), N = +L[0] + Y, W = +L[L.length - 1] + Y, q = (e.bandwidth ? ar : sr)(e.copy(), Y), j = S.selection ? S.selection() : S, p = j.selectAll(".domain").data([null]), g = j.selectAll(".tick").data(Z, e).order(), y = g.exit(), h = g.enter().append("g").attr("class", "tick"), D = g.select("line"), w = g.select("text");
    p = p.merge(p.enter().insert("path", ".tick").attr("class", "domain").attr("stroke", "currentColor")), g = g.merge(h), D = D.merge(h.append("line").attr("stroke", "currentColor").attr(k + "2", C * a)), w = w.merge(h.append("text").attr("fill", "currentColor").attr(k, C * U).attr("dy", t === Xt ? "0em" : t === Te ? "0.71em" : "0.32em")), S !== j && (p = p.transition(S), g = g.transition(S), D = D.transition(S), w = w.transition(S), y = y.transition(S).attr("opacity", Ne).attr("transform", function(T) {
      return isFinite(T = q(T)) ? I(T + Y) : this.getAttribute("transform");
    }), h.attr("opacity", Ne).attr("transform", function(T) {
      var v = this.parentNode.__axis;
      return I((v && isFinite(v = v(T)) ? v : q(T)) + Y);
    })), y.remove(), p.attr("d", t === Bt || t === ue ? c ? "M" + C * c + "," + N + "H" + Y + "V" + W + "H" + C * c : "M" + Y + "," + N + "V" + W : c ? "M" + N + "," + C * c + "V" + Y + "H" + W + "V" + C * c : "M" + N + "," + Y + "H" + W), g.attr("opacity", 1).attr("transform", function(T) {
      return I(q(T) + Y);
    }), D.attr(k + "2", C * a), w.attr(k, C * U).text(A), j.filter(or).attr("fill", "none").attr("font-size", 10).attr("font-family", "sans-serif").attr("text-anchor", t === ue ? "start" : t === Bt ? "end" : "middle"), j.each(function() {
      this.__axis = q;
    });
  }
  return _.scale = function(S) {
    return arguments.length ? (e = S, _) : e;
  }, _.ticks = function() {
    return n = Array.from(arguments), _;
  }, _.tickArguments = function(S) {
    return arguments.length ? (n = S == null ? [] : Array.from(S), _) : n.slice();
  }, _.tickValues = function(S) {
    return arguments.length ? (r = S == null ? null : Array.from(S), _) : r && r.slice();
  }, _.tickFormat = function(S) {
    return arguments.length ? (i = S, _) : i;
  }, _.tickSize = function(S) {
    return arguments.length ? (a = c = +S, _) : a;
  }, _.tickSizeInner = function(S) {
    return arguments.length ? (a = +S, _) : a;
  }, _.tickSizeOuter = function(S) {
    return arguments.length ? (c = +S, _) : c;
  }, _.tickPadding = function(S) {
    return arguments.length ? (m = +S, _) : m;
  }, _.offset = function(S) {
    return arguments.length ? (Y = +S, _) : Y;
  }, _;
}
function cr(t) {
  return ln(Xt, t);
}
function ur(t) {
  return ln(Te, t);
}
const lr = Math.PI / 180, fr = 180 / Math.PI, ee = 18, fn = 0.96422, dn = 1, hn = 0.82521, mn = 4 / 29, Ft = 6 / 29, gn = 3 * Ft * Ft, dr = Ft * Ft * Ft;
function yn(t) {
  if (t instanceof ft) return new ft(t.l, t.a, t.b, t.opacity);
  if (t instanceof ht) return kn(t);
  t instanceof an || (t = Wn(t));
  var e = he(t.r), n = he(t.g), r = he(t.b), i = le((0.2225045 * e + 0.7168786 * n + 0.0606169 * r) / dn), a, c;
  return e === n && n === r ? a = c = i : (a = le((0.4360747 * e + 0.3850649 * n + 0.1430804 * r) / fn), c = le((0.0139322 * e + 0.0971045 * n + 0.7141733 * r) / hn)), new ft(116 * i - 16, 500 * (a - i), 200 * (i - c), t.opacity);
}
function hr(t, e, n, r) {
  return arguments.length === 1 ? yn(t) : new ft(t, e, n, r ?? 1);
}
function ft(t, e, n, r) {
  this.l = +t, this.a = +e, this.b = +n, this.opacity = +r;
}
on(ft, hr, cn(un, {
  brighter(t) {
    return new ft(this.l + ee * (t ?? 1), this.a, this.b, this.opacity);
  },
  darker(t) {
    return new ft(this.l - ee * (t ?? 1), this.a, this.b, this.opacity);
  },
  rgb() {
    var t = (this.l + 16) / 116, e = isNaN(this.a) ? t : t + this.a / 500, n = isNaN(this.b) ? t : t - this.b / 200;
    return e = fn * fe(e), t = dn * fe(t), n = hn * fe(n), new an(
      de(3.1338561 * e - 1.6168667 * t - 0.4906146 * n),
      de(-0.9787684 * e + 1.9161415 * t + 0.033454 * n),
      de(0.0719453 * e - 0.2289914 * t + 1.4052427 * n),
      this.opacity
    );
  }
}));
function le(t) {
  return t > dr ? Math.pow(t, 1 / 3) : t / gn + mn;
}
function fe(t) {
  return t > Ft ? t * t * t : gn * (t - mn);
}
function de(t) {
  return 255 * (t <= 31308e-7 ? 12.92 * t : 1.055 * Math.pow(t, 1 / 2.4) - 0.055);
}
function he(t) {
  return (t /= 255) <= 0.04045 ? t / 12.92 : Math.pow((t + 0.055) / 1.055, 2.4);
}
function mr(t) {
  if (t instanceof ht) return new ht(t.h, t.c, t.l, t.opacity);
  if (t instanceof ft || (t = yn(t)), t.a === 0 && t.b === 0) return new ht(NaN, 0 < t.l && t.l < 100 ? 0 : NaN, t.l, t.opacity);
  var e = Math.atan2(t.b, t.a) * fr;
  return new ht(e < 0 ? e + 360 : e, Math.sqrt(t.a * t.a + t.b * t.b), t.l, t.opacity);
}
function xe(t, e, n, r) {
  return arguments.length === 1 ? mr(t) : new ht(t, e, n, r ?? 1);
}
function ht(t, e, n, r) {
  this.h = +t, this.c = +e, this.l = +n, this.opacity = +r;
}
function kn(t) {
  if (isNaN(t.h)) return new ft(t.l, 0, 0, t.opacity);
  var e = t.h * lr;
  return new ft(t.l, Math.cos(e) * t.c, Math.sin(e) * t.c, t.opacity);
}
on(ht, xe, cn(un, {
  brighter(t) {
    return new ht(this.h, this.c, this.l + ee * (t ?? 1), this.opacity);
  },
  darker(t) {
    return new ht(this.h, this.c, this.l - ee * (t ?? 1), this.opacity);
  },
  rgb() {
    return kn(this).rgb();
  }
}));
function gr(t) {
  return function(e, n) {
    var r = t((e = xe(e)).h, (n = xe(n)).h), i = ce(e.c, n.c), a = ce(e.l, n.l), c = ce(e.opacity, n.opacity);
    return function(m) {
      return e.h = r(m), e.c = i(m), e.l = a(m), e.opacity = c(m), e + "";
    };
  };
}
const yr = gr($n);
function kr(t, e) {
  t = t.slice();
  var n = 0, r = t.length - 1, i = t[n], a = t[r], c;
  return a < i && (c = n, n = r, r = c, c = i, i = a, a = c), t[n] = e.floor(i), t[r] = e.ceil(a), t;
}
const me = /* @__PURE__ */ new Date(), ge = /* @__PURE__ */ new Date();
function et(t, e, n, r) {
  function i(a) {
    return t(a = arguments.length === 0 ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(+a)), a;
  }
  return i.floor = (a) => (t(a = /* @__PURE__ */ new Date(+a)), a), i.ceil = (a) => (t(a = new Date(a - 1)), e(a, 1), t(a), a), i.round = (a) => {
    const c = i(a), m = i.ceil(a);
    return a - c < m - a ? c : m;
  }, i.offset = (a, c) => (e(a = /* @__PURE__ */ new Date(+a), c == null ? 1 : Math.floor(c)), a), i.range = (a, c, m) => {
    const Y = [];
    if (a = i.ceil(a), m = m == null ? 1 : Math.floor(m), !(a < c) || !(m > 0)) return Y;
    let C;
    do
      Y.push(C = /* @__PURE__ */ new Date(+a)), e(a, m), t(a);
    while (C < a && a < c);
    return Y;
  }, i.filter = (a) => et((c) => {
    if (c >= c) for (; t(c), !a(c); ) c.setTime(c - 1);
  }, (c, m) => {
    if (c >= c)
      if (m < 0) for (; ++m <= 0; )
        for (; e(c, -1), !a(c); )
          ;
      else for (; --m >= 0; )
        for (; e(c, 1), !a(c); )
          ;
  }), n && (i.count = (a, c) => (me.setTime(+a), ge.setTime(+c), t(me), t(ge), Math.floor(n(me, ge))), i.every = (a) => (a = Math.floor(a), !isFinite(a) || !(a > 0) ? null : a > 1 ? i.filter(r ? (c) => r(c) % a === 0 : (c) => i.count(0, c) % a === 0) : i)), i;
}
const Ut = et(() => {
}, (t, e) => {
  t.setTime(+t + e);
}, (t, e) => e - t);
Ut.every = (t) => (t = Math.floor(t), !isFinite(t) || !(t > 0) ? null : t > 1 ? et((e) => {
  e.setTime(Math.floor(e / t) * t);
}, (e, n) => {
  e.setTime(+e + n * t);
}, (e, n) => (n - e) / t) : Ut);
Ut.range;
const mt = 1e3, ct = mt * 60, gt = ct * 60, yt = gt * 24, Ce = yt * 7, Pe = yt * 30, ye = yt * 365, vt = et((t) => {
  t.setTime(t - t.getMilliseconds());
}, (t, e) => {
  t.setTime(+t + e * mt);
}, (t, e) => (e - t) / mt, (t) => t.getUTCSeconds());
vt.range;
const $t = et((t) => {
  t.setTime(t - t.getMilliseconds() - t.getSeconds() * mt);
}, (t, e) => {
  t.setTime(+t + e * ct);
}, (t, e) => (e - t) / ct, (t) => t.getMinutes());
$t.range;
const pr = et((t) => {
  t.setUTCSeconds(0, 0);
}, (t, e) => {
  t.setTime(+t + e * ct);
}, (t, e) => (e - t) / ct, (t) => t.getUTCMinutes());
pr.range;
const Ot = et((t) => {
  t.setTime(t - t.getMilliseconds() - t.getSeconds() * mt - t.getMinutes() * ct);
}, (t, e) => {
  t.setTime(+t + e * gt);
}, (t, e) => (e - t) / gt, (t) => t.getHours());
Ot.range;
const vr = et((t) => {
  t.setUTCMinutes(0, 0, 0);
}, (t, e) => {
  t.setTime(+t + e * gt);
}, (t, e) => (e - t) / gt, (t) => t.getUTCHours());
vr.range;
const xt = et(
  (t) => t.setHours(0, 0, 0, 0),
  (t, e) => t.setDate(t.getDate() + e),
  (t, e) => (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * ct) / yt,
  (t) => t.getDate() - 1
);
xt.range;
const Se = et((t) => {
  t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCDate(t.getUTCDate() + e);
}, (t, e) => (e - t) / yt, (t) => t.getUTCDate() - 1);
Se.range;
const Tr = et((t) => {
  t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCDate(t.getUTCDate() + e);
}, (t, e) => (e - t) / yt, (t) => Math.floor(t / yt));
Tr.range;
function Dt(t) {
  return et((e) => {
    e.setDate(e.getDate() - (e.getDay() + 7 - t) % 7), e.setHours(0, 0, 0, 0);
  }, (e, n) => {
    e.setDate(e.getDate() + n * 7);
  }, (e, n) => (n - e - (n.getTimezoneOffset() - e.getTimezoneOffset()) * ct) / Ce);
}
const Pt = Dt(0), Ht = Dt(1), pn = Dt(2), vn = Dt(3), bt = Dt(4), Tn = Dt(5), xn = Dt(6);
Pt.range;
Ht.range;
pn.range;
vn.range;
bt.range;
Tn.range;
xn.range;
function Mt(t) {
  return et((e) => {
    e.setUTCDate(e.getUTCDate() - (e.getUTCDay() + 7 - t) % 7), e.setUTCHours(0, 0, 0, 0);
  }, (e, n) => {
    e.setUTCDate(e.getUTCDate() + n * 7);
  }, (e, n) => (n - e) / Ce);
}
const bn = Mt(0), ne = Mt(1), xr = Mt(2), br = Mt(3), Et = Mt(4), wr = Mt(5), Dr = Mt(6);
bn.range;
ne.range;
xr.range;
br.range;
Et.range;
wr.range;
Dr.range;
const Nt = et((t) => {
  t.setDate(1), t.setHours(0, 0, 0, 0);
}, (t, e) => {
  t.setMonth(t.getMonth() + e);
}, (t, e) => e.getMonth() - t.getMonth() + (e.getFullYear() - t.getFullYear()) * 12, (t) => t.getMonth());
Nt.range;
const Mr = et((t) => {
  t.setUTCDate(1), t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCMonth(t.getUTCMonth() + e);
}, (t, e) => e.getUTCMonth() - t.getUTCMonth() + (e.getUTCFullYear() - t.getUTCFullYear()) * 12, (t) => t.getUTCMonth());
Mr.range;
const kt = et((t) => {
  t.setMonth(0, 1), t.setHours(0, 0, 0, 0);
}, (t, e) => {
  t.setFullYear(t.getFullYear() + e);
}, (t, e) => e.getFullYear() - t.getFullYear(), (t) => t.getFullYear());
kt.every = (t) => !isFinite(t = Math.floor(t)) || !(t > 0) ? null : et((e) => {
  e.setFullYear(Math.floor(e.getFullYear() / t) * t), e.setMonth(0, 1), e.setHours(0, 0, 0, 0);
}, (e, n) => {
  e.setFullYear(e.getFullYear() + n * t);
});
kt.range;
const wt = et((t) => {
  t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
}, (t, e) => {
  t.setUTCFullYear(t.getUTCFullYear() + e);
}, (t, e) => e.getUTCFullYear() - t.getUTCFullYear(), (t) => t.getUTCFullYear());
wt.every = (t) => !isFinite(t = Math.floor(t)) || !(t > 0) ? null : et((e) => {
  e.setUTCFullYear(Math.floor(e.getUTCFullYear() / t) * t), e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0);
}, (e, n) => {
  e.setUTCFullYear(e.getUTCFullYear() + n * t);
});
wt.range;
function Cr(t, e, n, r, i, a) {
  const c = [
    [vt, 1, mt],
    [vt, 5, 5 * mt],
    [vt, 15, 15 * mt],
    [vt, 30, 30 * mt],
    [a, 1, ct],
    [a, 5, 5 * ct],
    [a, 15, 15 * ct],
    [a, 30, 30 * ct],
    [i, 1, gt],
    [i, 3, 3 * gt],
    [i, 6, 6 * gt],
    [i, 12, 12 * gt],
    [r, 1, yt],
    [r, 2, 2 * yt],
    [n, 1, Ce],
    [e, 1, Pe],
    [e, 3, 3 * Pe],
    [t, 1, ye]
  ];
  function m(C, k, I) {
    const _ = k < C;
    _ && ([C, k] = [k, C]);
    const S = I && typeof I.range == "function" ? I : Y(C, k, I), Z = S ? S.range(C, +k + 1) : [];
    return _ ? Z.reverse() : Z;
  }
  function Y(C, k, I) {
    const _ = Math.abs(k - C) / I, S = Gn(([, , U]) => U).right(c, _);
    if (S === c.length) return t.every(He(C / ye, k / ye, I));
    if (S === 0) return Ut.every(Math.max(He(C, k, I), 1));
    const [Z, A] = c[_ / c[S - 1][2] < c[S][2] / _ ? S - 1 : S];
    return Z.every(A);
  }
  return [m, Y];
}
const [Sr, _r] = Cr(kt, Nt, Pt, xt, Ot, $t);
function ke(t) {
  if (0 <= t.y && t.y < 100) {
    var e = new Date(-1, t.m, t.d, t.H, t.M, t.S, t.L);
    return e.setFullYear(t.y), e;
  }
  return new Date(t.y, t.m, t.d, t.H, t.M, t.S, t.L);
}
function pe(t) {
  if (0 <= t.y && t.y < 100) {
    var e = new Date(Date.UTC(-1, t.m, t.d, t.H, t.M, t.S, t.L));
    return e.setUTCFullYear(t.y), e;
  }
  return new Date(Date.UTC(t.y, t.m, t.d, t.H, t.M, t.S, t.L));
}
function It(t, e, n) {
  return { y: t, m: e, d: n, H: 0, M: 0, S: 0, L: 0 };
}
function Fr(t) {
  var e = t.dateTime, n = t.date, r = t.time, i = t.periods, a = t.days, c = t.shortDays, m = t.months, Y = t.shortMonths, C = At(i), k = Wt(i), I = At(a), _ = Wt(a), S = At(c), Z = Wt(c), A = At(m), U = Wt(m), L = At(Y), N = Wt(Y), W = {
    a: b,
    A: F,
    b: o,
    B: X,
    c: null,
    d: Be,
    e: Be,
    f: Jr,
    g: ci,
    G: li,
    H: Gr,
    I: jr,
    j: Qr,
    L: wn,
    m: Kr,
    M: ti,
    p: s,
    q: E,
    Q: je,
    s: Qe,
    S: ei,
    u: ni,
    U: ri,
    V: ii,
    w: si,
    W: ai,
    x: null,
    X: null,
    y: oi,
    Y: ui,
    Z: fi,
    "%": Ge
  }, q = {
    a: z,
    A: V,
    b: P,
    B: K,
    c: null,
    d: Xe,
    e: Xe,
    f: gi,
    g: Mi,
    G: Si,
    H: di,
    I: hi,
    j: mi,
    L: Mn,
    m: yi,
    M: ki,
    p: O,
    q: st,
    Q: je,
    s: Qe,
    S: pi,
    u: vi,
    U: Ti,
    V: xi,
    w: bi,
    W: wi,
    x: null,
    X: null,
    y: Di,
    Y: Ci,
    Z: _i,
    "%": Ge
  }, j = {
    a: D,
    A: w,
    b: T,
    B: v,
    c: u,
    d: qe,
    e: qe,
    f: qr,
    g: ze,
    G: Ve,
    H: Ze,
    I: Ze,
    j: Pr,
    L: zr,
    m: Nr,
    M: Rr,
    p: h,
    q: Hr,
    Q: Br,
    s: Xr,
    S: Vr,
    u: Ir,
    U: Ar,
    V: Wr,
    w: Lr,
    W: $r,
    x: f,
    X: x,
    y: ze,
    Y: Ve,
    Z: Or,
    "%": Zr
  };
  W.x = p(n, W), W.X = p(r, W), W.c = p(e, W), q.x = p(n, q), q.X = p(r, q), q.c = p(e, q);
  function p(M, H) {
    return function(R) {
      var l = [], J = -1, $ = 0, Q = M.length, G, it, at;
      for (R instanceof Date || (R = /* @__PURE__ */ new Date(+R)); ++J < Q; )
        M.charCodeAt(J) === 37 && (l.push(M.slice($, J)), (it = Re[G = M.charAt(++J)]) != null ? G = M.charAt(++J) : it = G === "e" ? " " : "0", (at = H[G]) && (G = at(R, it)), l.push(G), $ = J + 1);
      return l.push(M.slice($, J)), l.join("");
    };
  }
  function g(M, H) {
    return function(R) {
      var l = It(1900, void 0, 1), J = y(l, M, R += "", 0), $, Q;
      if (J != R.length) return null;
      if ("Q" in l) return new Date(l.Q);
      if ("s" in l) return new Date(l.s * 1e3 + ("L" in l ? l.L : 0));
      if (H && !("Z" in l) && (l.Z = 0), "p" in l && (l.H = l.H % 12 + l.p * 12), l.m === void 0 && (l.m = "q" in l ? l.q : 0), "V" in l) {
        if (l.V < 1 || l.V > 53) return null;
        "w" in l || (l.w = 1), "Z" in l ? ($ = pe(It(l.y, 0, 1)), Q = $.getUTCDay(), $ = Q > 4 || Q === 0 ? ne.ceil($) : ne($), $ = Se.offset($, (l.V - 1) * 7), l.y = $.getUTCFullYear(), l.m = $.getUTCMonth(), l.d = $.getUTCDate() + (l.w + 6) % 7) : ($ = ke(It(l.y, 0, 1)), Q = $.getDay(), $ = Q > 4 || Q === 0 ? Ht.ceil($) : Ht($), $ = xt.offset($, (l.V - 1) * 7), l.y = $.getFullYear(), l.m = $.getMonth(), l.d = $.getDate() + (l.w + 6) % 7);
      } else ("W" in l || "U" in l) && ("w" in l || (l.w = "u" in l ? l.u % 7 : "W" in l ? 1 : 0), Q = "Z" in l ? pe(It(l.y, 0, 1)).getUTCDay() : ke(It(l.y, 0, 1)).getDay(), l.m = 0, l.d = "W" in l ? (l.w + 6) % 7 + l.W * 7 - (Q + 5) % 7 : l.w + l.U * 7 - (Q + 6) % 7);
      return "Z" in l ? (l.H += l.Z / 100 | 0, l.M += l.Z % 100, pe(l)) : ke(l);
    };
  }
  function y(M, H, R, l) {
    for (var J = 0, $ = H.length, Q = R.length, G, it; J < $; ) {
      if (l >= Q) return -1;
      if (G = H.charCodeAt(J++), G === 37) {
        if (G = H.charAt(J++), it = j[G in Re ? H.charAt(J++) : G], !it || (l = it(M, R, l)) < 0) return -1;
      } else if (G != R.charCodeAt(l++))
        return -1;
    }
    return l;
  }
  function h(M, H, R) {
    var l = C.exec(H.slice(R));
    return l ? (M.p = k.get(l[0].toLowerCase()), R + l[0].length) : -1;
  }
  function D(M, H, R) {
    var l = S.exec(H.slice(R));
    return l ? (M.w = Z.get(l[0].toLowerCase()), R + l[0].length) : -1;
  }
  function w(M, H, R) {
    var l = I.exec(H.slice(R));
    return l ? (M.w = _.get(l[0].toLowerCase()), R + l[0].length) : -1;
  }
  function T(M, H, R) {
    var l = L.exec(H.slice(R));
    return l ? (M.m = N.get(l[0].toLowerCase()), R + l[0].length) : -1;
  }
  function v(M, H, R) {
    var l = A.exec(H.slice(R));
    return l ? (M.m = U.get(l[0].toLowerCase()), R + l[0].length) : -1;
  }
  function u(M, H, R) {
    return y(M, e, H, R);
  }
  function f(M, H, R) {
    return y(M, n, H, R);
  }
  function x(M, H, R) {
    return y(M, r, H, R);
  }
  function b(M) {
    return c[M.getDay()];
  }
  function F(M) {
    return a[M.getDay()];
  }
  function o(M) {
    return Y[M.getMonth()];
  }
  function X(M) {
    return m[M.getMonth()];
  }
  function s(M) {
    return i[+(M.getHours() >= 12)];
  }
  function E(M) {
    return 1 + ~~(M.getMonth() / 3);
  }
  function z(M) {
    return c[M.getUTCDay()];
  }
  function V(M) {
    return a[M.getUTCDay()];
  }
  function P(M) {
    return Y[M.getUTCMonth()];
  }
  function K(M) {
    return m[M.getUTCMonth()];
  }
  function O(M) {
    return i[+(M.getUTCHours() >= 12)];
  }
  function st(M) {
    return 1 + ~~(M.getUTCMonth() / 3);
  }
  return {
    format: function(M) {
      var H = p(M += "", W);
      return H.toString = function() {
        return M;
      }, H;
    },
    parse: function(M) {
      var H = g(M += "", !1);
      return H.toString = function() {
        return M;
      }, H;
    },
    utcFormat: function(M) {
      var H = p(M += "", q);
      return H.toString = function() {
        return M;
      }, H;
    },
    utcParse: function(M) {
      var H = g(M += "", !0);
      return H.toString = function() {
        return M;
      }, H;
    }
  };
}
var Re = { "-": "", _: " ", 0: "0" }, nt = /^\s*\d+/, Yr = /^%/, Ur = /[\\^$*+?|[\]().{}]/g;
function B(t, e, n) {
  var r = t < 0 ? "-" : "", i = (r ? -t : t) + "", a = i.length;
  return r + (a < n ? new Array(n - a + 1).join(e) + i : i);
}
function Er(t) {
  return t.replace(Ur, "\\$&");
}
function At(t) {
  return new RegExp("^(?:" + t.map(Er).join("|") + ")", "i");
}
function Wt(t) {
  return new Map(t.map((e, n) => [e.toLowerCase(), n]));
}
function Lr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 1));
  return r ? (t.w = +r[0], n + r[0].length) : -1;
}
function Ir(t, e, n) {
  var r = nt.exec(e.slice(n, n + 1));
  return r ? (t.u = +r[0], n + r[0].length) : -1;
}
function Ar(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.U = +r[0], n + r[0].length) : -1;
}
function Wr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.V = +r[0], n + r[0].length) : -1;
}
function $r(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.W = +r[0], n + r[0].length) : -1;
}
function Ve(t, e, n) {
  var r = nt.exec(e.slice(n, n + 4));
  return r ? (t.y = +r[0], n + r[0].length) : -1;
}
function ze(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1;
}
function Or(t, e, n) {
  var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n, n + 6));
  return r ? (t.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1;
}
function Hr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 1));
  return r ? (t.q = r[0] * 3 - 3, n + r[0].length) : -1;
}
function Nr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.m = r[0] - 1, n + r[0].length) : -1;
}
function qe(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.d = +r[0], n + r[0].length) : -1;
}
function Pr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 3));
  return r ? (t.m = 0, t.d = +r[0], n + r[0].length) : -1;
}
function Ze(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.H = +r[0], n + r[0].length) : -1;
}
function Rr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.M = +r[0], n + r[0].length) : -1;
}
function Vr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 2));
  return r ? (t.S = +r[0], n + r[0].length) : -1;
}
function zr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 3));
  return r ? (t.L = +r[0], n + r[0].length) : -1;
}
function qr(t, e, n) {
  var r = nt.exec(e.slice(n, n + 6));
  return r ? (t.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1;
}
function Zr(t, e, n) {
  var r = Yr.exec(e.slice(n, n + 1));
  return r ? n + r[0].length : -1;
}
function Br(t, e, n) {
  var r = nt.exec(e.slice(n));
  return r ? (t.Q = +r[0], n + r[0].length) : -1;
}
function Xr(t, e, n) {
  var r = nt.exec(e.slice(n));
  return r ? (t.s = +r[0], n + r[0].length) : -1;
}
function Be(t, e) {
  return B(t.getDate(), e, 2);
}
function Gr(t, e) {
  return B(t.getHours(), e, 2);
}
function jr(t, e) {
  return B(t.getHours() % 12 || 12, e, 2);
}
function Qr(t, e) {
  return B(1 + xt.count(kt(t), t), e, 3);
}
function wn(t, e) {
  return B(t.getMilliseconds(), e, 3);
}
function Jr(t, e) {
  return wn(t, e) + "000";
}
function Kr(t, e) {
  return B(t.getMonth() + 1, e, 2);
}
function ti(t, e) {
  return B(t.getMinutes(), e, 2);
}
function ei(t, e) {
  return B(t.getSeconds(), e, 2);
}
function ni(t) {
  var e = t.getDay();
  return e === 0 ? 7 : e;
}
function ri(t, e) {
  return B(Pt.count(kt(t) - 1, t), e, 2);
}
function Dn(t) {
  var e = t.getDay();
  return e >= 4 || e === 0 ? bt(t) : bt.ceil(t);
}
function ii(t, e) {
  return t = Dn(t), B(bt.count(kt(t), t) + (kt(t).getDay() === 4), e, 2);
}
function si(t) {
  return t.getDay();
}
function ai(t, e) {
  return B(Ht.count(kt(t) - 1, t), e, 2);
}
function oi(t, e) {
  return B(t.getFullYear() % 100, e, 2);
}
function ci(t, e) {
  return t = Dn(t), B(t.getFullYear() % 100, e, 2);
}
function ui(t, e) {
  return B(t.getFullYear() % 1e4, e, 4);
}
function li(t, e) {
  var n = t.getDay();
  return t = n >= 4 || n === 0 ? bt(t) : bt.ceil(t), B(t.getFullYear() % 1e4, e, 4);
}
function fi(t) {
  var e = t.getTimezoneOffset();
  return (e > 0 ? "-" : (e *= -1, "+")) + B(e / 60 | 0, "0", 2) + B(e % 60, "0", 2);
}
function Xe(t, e) {
  return B(t.getUTCDate(), e, 2);
}
function di(t, e) {
  return B(t.getUTCHours(), e, 2);
}
function hi(t, e) {
  return B(t.getUTCHours() % 12 || 12, e, 2);
}
function mi(t, e) {
  return B(1 + Se.count(wt(t), t), e, 3);
}
function Mn(t, e) {
  return B(t.getUTCMilliseconds(), e, 3);
}
function gi(t, e) {
  return Mn(t, e) + "000";
}
function yi(t, e) {
  return B(t.getUTCMonth() + 1, e, 2);
}
function ki(t, e) {
  return B(t.getUTCMinutes(), e, 2);
}
function pi(t, e) {
  return B(t.getUTCSeconds(), e, 2);
}
function vi(t) {
  var e = t.getUTCDay();
  return e === 0 ? 7 : e;
}
function Ti(t, e) {
  return B(bn.count(wt(t) - 1, t), e, 2);
}
function Cn(t) {
  var e = t.getUTCDay();
  return e >= 4 || e === 0 ? Et(t) : Et.ceil(t);
}
function xi(t, e) {
  return t = Cn(t), B(Et.count(wt(t), t) + (wt(t).getUTCDay() === 4), e, 2);
}
function bi(t) {
  return t.getUTCDay();
}
function wi(t, e) {
  return B(ne.count(wt(t) - 1, t), e, 2);
}
function Di(t, e) {
  return B(t.getUTCFullYear() % 100, e, 2);
}
function Mi(t, e) {
  return t = Cn(t), B(t.getUTCFullYear() % 100, e, 2);
}
function Ci(t, e) {
  return B(t.getUTCFullYear() % 1e4, e, 4);
}
function Si(t, e) {
  var n = t.getUTCDay();
  return t = n >= 4 || n === 0 ? Et(t) : Et.ceil(t), B(t.getUTCFullYear() % 1e4, e, 4);
}
function _i() {
  return "+0000";
}
function Ge() {
  return "%";
}
function je(t) {
  return +t;
}
function Qe(t) {
  return Math.floor(+t / 1e3);
}
var St, re;
Fi({
  dateTime: "%x, %X",
  date: "%-m/%-d/%Y",
  time: "%-I:%M:%S %p",
  periods: ["AM", "PM"],
  days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
  shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});
function Fi(t) {
  return St = Fr(t), re = St.format, St.parse, St.utcFormat, St.utcParse, St;
}
function Yi(t) {
  return new Date(t);
}
function Ui(t) {
  return t instanceof Date ? +t : +/* @__PURE__ */ new Date(+t);
}
function Sn(t, e, n, r, i, a, c, m, Y, C) {
  var k = jn(), I = k.invert, _ = k.domain, S = C(".%L"), Z = C(":%S"), A = C("%I:%M"), U = C("%I %p"), L = C("%a %d"), N = C("%b %d"), W = C("%B"), q = C("%Y");
  function j(p) {
    return (Y(p) < p ? S : m(p) < p ? Z : c(p) < p ? A : a(p) < p ? U : r(p) < p ? i(p) < p ? L : N : n(p) < p ? W : q)(p);
  }
  return k.invert = function(p) {
    return new Date(I(p));
  }, k.domain = function(p) {
    return arguments.length ? _(Array.from(p, Ui)) : _().map(Yi);
  }, k.ticks = function(p) {
    var g = _();
    return t(g[0], g[g.length - 1], p ?? 10);
  }, k.tickFormat = function(p, g) {
    return g == null ? j : C(g);
  }, k.nice = function(p) {
    var g = _();
    return (!p || typeof p.range != "function") && (p = e(g[0], g[g.length - 1], p ?? 10)), p ? _(kr(g, p)) : k;
  }, k.copy = function() {
    return Qn(k, Sn(t, e, n, r, i, a, c, m, Y, C));
  }, k;
}
function Ei() {
  return Kn.apply(Sn(Sr, _r, kt, Nt, Pt, xt, Ot, $t, vt, re).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments);
}
var Gt = { exports: {} }, Li = Gt.exports, Je;
function Ii() {
  return Je || (Je = 1, (function(t, e) {
    (function(n, r) {
      t.exports = r();
    })(Li, (function() {
      var n = "day";
      return function(r, i, a) {
        var c = function(C) {
          return C.add(4 - C.isoWeekday(), n);
        }, m = i.prototype;
        m.isoWeekYear = function() {
          return c(this).year();
        }, m.isoWeek = function(C) {
          if (!this.$utils().u(C)) return this.add(7 * (C - this.isoWeek()), n);
          var k, I, _, S, Z = c(this), A = (k = this.isoWeekYear(), I = this.$u, _ = (I ? a.utc : a)().year(k).startOf("year"), S = 4 - _.isoWeekday(), _.isoWeekday() > 4 && (S += 7), _.add(S, n));
          return Z.diff(A, "week") + 1;
        }, m.isoWeekday = function(C) {
          return this.$utils().u(C) ? this.day() || 7 : this.day(this.day() % 7 ? C : C - 7);
        };
        var Y = m.startOf;
        m.startOf = function(C, k) {
          var I = this.$utils(), _ = !!I.u(k) || k;
          return I.p(C) === "isoweek" ? _ ? this.date(this.date() - (this.isoWeekday() - 1)).startOf("day") : this.date(this.date() - 1 - (this.isoWeekday() - 1) + 7).endOf("day") : Y.bind(this)(C, k);
        };
      };
    }));
  })(Gt)), Gt.exports;
}
var Ai = Ii();
const Wi = /* @__PURE__ */ ae(Ai);
var jt = { exports: {} }, $i = jt.exports, Ke;
function Oi() {
  return Ke || (Ke = 1, (function(t, e) {
    (function(n, r) {
      t.exports = r();
    })($i, (function() {
      var n = { LTS: "h:mm:ss A", LT: "h:mm A", L: "MM/DD/YYYY", LL: "MMMM D, YYYY", LLL: "MMMM D, YYYY h:mm A", LLLL: "dddd, MMMM D, YYYY h:mm A" }, r = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g, i = /\d/, a = /\d\d/, c = /\d\d?/, m = /\d*[^-_:/,()\s\d]+/, Y = {}, C = function(U) {
        return (U = +U) + (U > 68 ? 1900 : 2e3);
      }, k = function(U) {
        return function(L) {
          this[U] = +L;
        };
      }, I = [/[+-]\d\d:?(\d\d)?|Z/, function(U) {
        (this.zone || (this.zone = {})).offset = (function(L) {
          if (!L || L === "Z") return 0;
          var N = L.match(/([+-]|\d\d)/g), W = 60 * N[1] + (+N[2] || 0);
          return W === 0 ? 0 : N[0] === "+" ? -W : W;
        })(U);
      }], _ = function(U) {
        var L = Y[U];
        return L && (L.indexOf ? L : L.s.concat(L.f));
      }, S = function(U, L) {
        var N, W = Y.meridiem;
        if (W) {
          for (var q = 1; q <= 24; q += 1) if (U.indexOf(W(q, 0, L)) > -1) {
            N = q > 12;
            break;
          }
        } else N = U === (L ? "pm" : "PM");
        return N;
      }, Z = { A: [m, function(U) {
        this.afternoon = S(U, !1);
      }], a: [m, function(U) {
        this.afternoon = S(U, !0);
      }], Q: [i, function(U) {
        this.month = 3 * (U - 1) + 1;
      }], S: [i, function(U) {
        this.milliseconds = 100 * +U;
      }], SS: [a, function(U) {
        this.milliseconds = 10 * +U;
      }], SSS: [/\d{3}/, function(U) {
        this.milliseconds = +U;
      }], s: [c, k("seconds")], ss: [c, k("seconds")], m: [c, k("minutes")], mm: [c, k("minutes")], H: [c, k("hours")], h: [c, k("hours")], HH: [c, k("hours")], hh: [c, k("hours")], D: [c, k("day")], DD: [a, k("day")], Do: [m, function(U) {
        var L = Y.ordinal, N = U.match(/\d+/);
        if (this.day = N[0], L) for (var W = 1; W <= 31; W += 1) L(W).replace(/\[|\]/g, "") === U && (this.day = W);
      }], w: [c, k("week")], ww: [a, k("week")], M: [c, k("month")], MM: [a, k("month")], MMM: [m, function(U) {
        var L = _("months"), N = (_("monthsShort") || L.map((function(W) {
          return W.slice(0, 3);
        }))).indexOf(U) + 1;
        if (N < 1) throw new Error();
        this.month = N % 12 || N;
      }], MMMM: [m, function(U) {
        var L = _("months").indexOf(U) + 1;
        if (L < 1) throw new Error();
        this.month = L % 12 || L;
      }], Y: [/[+-]?\d+/, k("year")], YY: [a, function(U) {
        this.year = C(U);
      }], YYYY: [/\d{4}/, k("year")], Z: I, ZZ: I };
      function A(U) {
        var L, N;
        L = U, N = Y && Y.formats;
        for (var W = (U = L.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(D, w, T) {
          var v = T && T.toUpperCase();
          return w || N[T] || n[T] || N[v].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(u, f, x) {
            return f || x.slice(1);
          }));
        }))).match(r), q = W.length, j = 0; j < q; j += 1) {
          var p = W[j], g = Z[p], y = g && g[0], h = g && g[1];
          W[j] = h ? { regex: y, parser: h } : p.replace(/^\[|\]$/g, "");
        }
        return function(D) {
          for (var w = {}, T = 0, v = 0; T < q; T += 1) {
            var u = W[T];
            if (typeof u == "string") v += u.length;
            else {
              var f = u.regex, x = u.parser, b = D.slice(v), F = f.exec(b)[0];
              x.call(w, F), D = D.replace(F, "");
            }
          }
          return (function(o) {
            var X = o.afternoon;
            if (X !== void 0) {
              var s = o.hours;
              X ? s < 12 && (o.hours += 12) : s === 12 && (o.hours = 0), delete o.afternoon;
            }
          })(w), w;
        };
      }
      return function(U, L, N) {
        N.p.customParseFormat = !0, U && U.parseTwoDigitYear && (C = U.parseTwoDigitYear);
        var W = L.prototype, q = W.parse;
        W.parse = function(j) {
          var p = j.date, g = j.utc, y = j.args;
          this.$u = g;
          var h = y[1];
          if (typeof h == "string") {
            var D = y[2] === !0, w = y[3] === !0, T = D || w, v = y[2];
            w && (v = y[2]), Y = this.$locale(), !D && v && (Y = N.Ls[v]), this.$d = (function(b, F, o, X) {
              try {
                if (["x", "X"].indexOf(F) > -1) return new Date((F === "X" ? 1e3 : 1) * b);
                var s = A(F)(b), E = s.year, z = s.month, V = s.day, P = s.hours, K = s.minutes, O = s.seconds, st = s.milliseconds, M = s.zone, H = s.week, R = /* @__PURE__ */ new Date(), l = V || (E || z ? 1 : R.getDate()), J = E || R.getFullYear(), $ = 0;
                E && !z || ($ = z > 0 ? z - 1 : R.getMonth());
                var Q, G = P || 0, it = K || 0, at = O || 0, pt = st || 0;
                return M ? new Date(Date.UTC(J, $, l, G, it, at, pt + 60 * M.offset * 1e3)) : o ? new Date(Date.UTC(J, $, l, G, it, at, pt)) : (Q = new Date(J, $, l, G, it, at, pt), H && (Q = X(Q).week(H).toDate()), Q);
              } catch {
                return /* @__PURE__ */ new Date("");
              }
            })(p, h, g, N), this.init(), v && v !== !0 && (this.$L = this.locale(v).$L), T && p != this.format(h) && (this.$d = /* @__PURE__ */ new Date("")), Y = {};
          } else if (h instanceof Array) for (var u = h.length, f = 1; f <= u; f += 1) {
            y[1] = h[f - 1];
            var x = N.apply(this, y);
            if (x.isValid()) {
              this.$d = x.$d, this.$L = x.$L, this.init();
              break;
            }
            f === u && (this.$d = /* @__PURE__ */ new Date(""));
          }
          else q.call(this, j);
        };
      };
    }));
  })(jt)), jt.exports;
}
var Hi = Oi();
const Ni = /* @__PURE__ */ ae(Hi);
var Qt = { exports: {} }, Pi = Qt.exports, tn;
function Ri() {
  return tn || (tn = 1, (function(t, e) {
    (function(n, r) {
      t.exports = r();
    })(Pi, (function() {
      return function(n, r) {
        var i = r.prototype, a = i.format;
        i.format = function(c) {
          var m = this, Y = this.$locale();
          if (!this.isValid()) return a.bind(this)(c);
          var C = this.$utils(), k = (c || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, (function(I) {
            switch (I) {
              case "Q":
                return Math.ceil((m.$M + 1) / 3);
              case "Do":
                return Y.ordinal(m.$D);
              case "gggg":
                return m.weekYear();
              case "GGGG":
                return m.isoWeekYear();
              case "wo":
                return Y.ordinal(m.week(), "W");
              case "w":
              case "ww":
                return C.s(m.week(), I === "w" ? 1 : 2, "0");
              case "W":
              case "WW":
                return C.s(m.isoWeek(), I === "W" ? 1 : 2, "0");
              case "k":
              case "kk":
                return C.s(String(m.$H === 0 ? 24 : m.$H), I === "k" ? 1 : 2, "0");
              case "X":
                return Math.floor(m.$d.getTime() / 1e3);
              case "x":
                return m.$d.getTime();
              case "z":
                return "[" + m.offsetName() + "]";
              case "zzz":
                return "[" + m.offsetName("long") + "]";
              default:
                return I;
            }
          }));
          return a.bind(this)(k);
        };
      };
    }));
  })(Qt)), Qt.exports;
}
var Vi = Ri();
const zi = /* @__PURE__ */ ae(Vi);
var Jt = { exports: {} }, qi = Jt.exports, en;
function Zi() {
  return en || (en = 1, (function(t, e) {
    (function(n, r) {
      t.exports = r();
    })(qi, (function() {
      var n, r, i = 1e3, a = 6e4, c = 36e5, m = 864e5, Y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, C = 31536e6, k = 2628e6, I = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/, _ = { years: C, months: k, days: m, hours: c, minutes: a, seconds: i, milliseconds: 1, weeks: 6048e5 }, S = function(p) {
        return p instanceof q;
      }, Z = function(p, g, y) {
        return new q(p, y, g.$l);
      }, A = function(p) {
        return r.p(p) + "s";
      }, U = function(p) {
        return p < 0;
      }, L = function(p) {
        return U(p) ? Math.ceil(p) : Math.floor(p);
      }, N = function(p) {
        return Math.abs(p);
      }, W = function(p, g) {
        return p ? U(p) ? { negative: !0, format: "" + N(p) + g } : { negative: !1, format: "" + p + g } : { negative: !1, format: "" };
      }, q = (function() {
        function p(y, h, D) {
          var w = this;
          if (this.$d = {}, this.$l = D, y === void 0 && (this.$ms = 0, this.parseFromMilliseconds()), h) return Z(y * _[A(h)], this);
          if (typeof y == "number") return this.$ms = y, this.parseFromMilliseconds(), this;
          if (typeof y == "object") return Object.keys(y).forEach((function(u) {
            w.$d[A(u)] = y[u];
          })), this.calMilliseconds(), this;
          if (typeof y == "string") {
            var T = y.match(I);
            if (T) {
              var v = T.slice(2).map((function(u) {
                return u != null ? Number(u) : 0;
              }));
              return this.$d.years = v[0], this.$d.months = v[1], this.$d.weeks = v[2], this.$d.days = v[3], this.$d.hours = v[4], this.$d.minutes = v[5], this.$d.seconds = v[6], this.calMilliseconds(), this;
            }
          }
          return this;
        }
        var g = p.prototype;
        return g.calMilliseconds = function() {
          var y = this;
          this.$ms = Object.keys(this.$d).reduce((function(h, D) {
            return h + (y.$d[D] || 0) * _[D];
          }), 0);
        }, g.parseFromMilliseconds = function() {
          var y = this.$ms;
          this.$d.years = L(y / C), y %= C, this.$d.months = L(y / k), y %= k, this.$d.days = L(y / m), y %= m, this.$d.hours = L(y / c), y %= c, this.$d.minutes = L(y / a), y %= a, this.$d.seconds = L(y / i), y %= i, this.$d.milliseconds = y;
        }, g.toISOString = function() {
          var y = W(this.$d.years, "Y"), h = W(this.$d.months, "M"), D = +this.$d.days || 0;
          this.$d.weeks && (D += 7 * this.$d.weeks);
          var w = W(D, "D"), T = W(this.$d.hours, "H"), v = W(this.$d.minutes, "M"), u = this.$d.seconds || 0;
          this.$d.milliseconds && (u += this.$d.milliseconds / 1e3, u = Math.round(1e3 * u) / 1e3);
          var f = W(u, "S"), x = y.negative || h.negative || w.negative || T.negative || v.negative || f.negative, b = T.format || v.format || f.format ? "T" : "", F = (x ? "-" : "") + "P" + y.format + h.format + w.format + b + T.format + v.format + f.format;
          return F === "P" || F === "-P" ? "P0D" : F;
        }, g.toJSON = function() {
          return this.toISOString();
        }, g.format = function(y) {
          var h = y || "YYYY-MM-DDTHH:mm:ss", D = { Y: this.$d.years, YY: r.s(this.$d.years, 2, "0"), YYYY: r.s(this.$d.years, 4, "0"), M: this.$d.months, MM: r.s(this.$d.months, 2, "0"), D: this.$d.days, DD: r.s(this.$d.days, 2, "0"), H: this.$d.hours, HH: r.s(this.$d.hours, 2, "0"), m: this.$d.minutes, mm: r.s(this.$d.minutes, 2, "0"), s: this.$d.seconds, ss: r.s(this.$d.seconds, 2, "0"), SSS: r.s(this.$d.milliseconds, 3, "0") };
          return h.replace(Y, (function(w, T) {
            return T || String(D[w]);
          }));
        }, g.as = function(y) {
          return this.$ms / _[A(y)];
        }, g.get = function(y) {
          var h = this.$ms, D = A(y);
          return D === "milliseconds" ? h %= 1e3 : h = D === "weeks" ? L(h / _[D]) : this.$d[D], h || 0;
        }, g.add = function(y, h, D) {
          var w;
          return w = h ? y * _[A(h)] : S(y) ? y.$ms : Z(y, this).$ms, Z(this.$ms + w * (D ? -1 : 1), this);
        }, g.subtract = function(y, h) {
          return this.add(y, h, !0);
        }, g.locale = function(y) {
          var h = this.clone();
          return h.$l = y, h;
        }, g.clone = function() {
          return Z(this.$ms, this);
        }, g.humanize = function(y) {
          return n().add(this.$ms, "ms").locale(this.$l).fromNow(!y);
        }, g.valueOf = function() {
          return this.asMilliseconds();
        }, g.milliseconds = function() {
          return this.get("milliseconds");
        }, g.asMilliseconds = function() {
          return this.as("milliseconds");
        }, g.seconds = function() {
          return this.get("seconds");
        }, g.asSeconds = function() {
          return this.as("seconds");
        }, g.minutes = function() {
          return this.get("minutes");
        }, g.asMinutes = function() {
          return this.as("minutes");
        }, g.hours = function() {
          return this.get("hours");
        }, g.asHours = function() {
          return this.as("hours");
        }, g.days = function() {
          return this.get("days");
        }, g.asDays = function() {
          return this.as("days");
        }, g.weeks = function() {
          return this.get("weeks");
        }, g.asWeeks = function() {
          return this.as("weeks");
        }, g.months = function() {
          return this.get("months");
        }, g.asMonths = function() {
          return this.as("months");
        }, g.years = function() {
          return this.get("years");
        }, g.asYears = function() {
          return this.as("years");
        }, p;
      })(), j = function(p, g, y) {
        return p.add(g.years() * y, "y").add(g.months() * y, "M").add(g.days() * y, "d").add(g.hours() * y, "h").add(g.minutes() * y, "m").add(g.seconds() * y, "s").add(g.milliseconds() * y, "ms");
      };
      return function(p, g, y) {
        n = y, r = y().$utils(), y.duration = function(w, T) {
          var v = y.locale();
          return Z(w, { $l: v }, T);
        }, y.isDuration = S;
        var h = g.prototype.add, D = g.prototype.subtract;
        g.prototype.add = function(w, T) {
          return S(w) ? j(this, w, 1) : h.bind(this)(w, T);
        }, g.prototype.subtract = function(w, T) {
          return S(w) ? j(this, w, -1) : D.bind(this)(w, T);
        };
      };
    }));
  })(Jt)), Jt.exports;
}
var Bi = Zi();
const Xi = /* @__PURE__ */ ae(Bi);
var be = (function() {
  var t = /* @__PURE__ */ d(function(v, u, f, x) {
    for (f = f || {}, x = v.length; x--; f[v[x]] = u) ;
    return f;
  }, "o"), e = [6, 8, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33, 35, 36, 38, 40], n = [1, 26], r = [1, 27], i = [1, 28], a = [1, 29], c = [1, 30], m = [1, 31], Y = [1, 32], C = [1, 33], k = [1, 34], I = [1, 9], _ = [1, 10], S = [1, 11], Z = [1, 12], A = [1, 13], U = [1, 14], L = [1, 15], N = [1, 16], W = [1, 19], q = [1, 20], j = [1, 21], p = [1, 22], g = [1, 23], y = [1, 25], h = [1, 35], D = {
    trace: /* @__PURE__ */ d(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, gantt: 4, document: 5, EOF: 6, line: 7, SPACE: 8, statement: 9, NL: 10, weekday: 11, weekday_monday: 12, weekday_tuesday: 13, weekday_wednesday: 14, weekday_thursday: 15, weekday_friday: 16, weekday_saturday: 17, weekday_sunday: 18, weekend: 19, weekend_friday: 20, weekend_saturday: 21, dateFormat: 22, inclusiveEndDates: 23, topAxis: 24, axisFormat: 25, tickInterval: 26, excludes: 27, includes: 28, todayMarker: 29, title: 30, acc_title: 31, acc_title_value: 32, acc_descr: 33, acc_descr_value: 34, acc_descr_multiline_value: 35, section: 36, clickStatement: 37, taskTxt: 38, taskData: 39, click: 40, callbackname: 41, callbackargs: 42, href: 43, clickStatementDebug: 44, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "gantt", 6: "EOF", 8: "SPACE", 10: "NL", 12: "weekday_monday", 13: "weekday_tuesday", 14: "weekday_wednesday", 15: "weekday_thursday", 16: "weekday_friday", 17: "weekday_saturday", 18: "weekday_sunday", 20: "weekend_friday", 21: "weekend_saturday", 22: "dateFormat", 23: "inclusiveEndDates", 24: "topAxis", 25: "axisFormat", 26: "tickInterval", 27: "excludes", 28: "includes", 29: "todayMarker", 30: "title", 31: "acc_title", 32: "acc_title_value", 33: "acc_descr", 34: "acc_descr_value", 35: "acc_descr_multiline_value", 36: "section", 38: "taskTxt", 39: "taskData", 40: "click", 41: "callbackname", 42: "callbackargs", 43: "href" },
    productions_: [0, [3, 3], [5, 0], [5, 2], [7, 2], [7, 1], [7, 1], [7, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [11, 1], [19, 1], [19, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 1], [9, 2], [9, 2], [9, 1], [9, 1], [9, 1], [9, 2], [37, 2], [37, 3], [37, 3], [37, 4], [37, 3], [37, 4], [37, 2], [44, 2], [44, 3], [44, 3], [44, 4], [44, 3], [44, 4], [44, 2]],
    performAction: /* @__PURE__ */ d(function(u, f, x, b, F, o, X) {
      var s = o.length - 1;
      switch (F) {
        case 1:
          return o[s - 1];
        case 2:
          this.$ = [];
          break;
        case 3:
          o[s - 1].push(o[s]), this.$ = o[s - 1];
          break;
        case 4:
        case 5:
          this.$ = o[s];
          break;
        case 6:
        case 7:
          this.$ = [];
          break;
        case 8:
          b.setWeekday("monday");
          break;
        case 9:
          b.setWeekday("tuesday");
          break;
        case 10:
          b.setWeekday("wednesday");
          break;
        case 11:
          b.setWeekday("thursday");
          break;
        case 12:
          b.setWeekday("friday");
          break;
        case 13:
          b.setWeekday("saturday");
          break;
        case 14:
          b.setWeekday("sunday");
          break;
        case 15:
          b.setWeekend("friday");
          break;
        case 16:
          b.setWeekend("saturday");
          break;
        case 17:
          b.setDateFormat(o[s].substr(11)), this.$ = o[s].substr(11);
          break;
        case 18:
          b.enableInclusiveEndDates(), this.$ = o[s].substr(18);
          break;
        case 19:
          b.TopAxis(), this.$ = o[s].substr(8);
          break;
        case 20:
          b.setAxisFormat(o[s].substr(11)), this.$ = o[s].substr(11);
          break;
        case 21:
          b.setTickInterval(o[s].substr(13)), this.$ = o[s].substr(13);
          break;
        case 22:
          b.setExcludes(o[s].substr(9)), this.$ = o[s].substr(9);
          break;
        case 23:
          b.setIncludes(o[s].substr(9)), this.$ = o[s].substr(9);
          break;
        case 24:
          b.setTodayMarker(o[s].substr(12)), this.$ = o[s].substr(12);
          break;
        case 27:
          b.setDiagramTitle(o[s].substr(6)), this.$ = o[s].substr(6);
          break;
        case 28:
          this.$ = o[s].trim(), b.setAccTitle(this.$);
          break;
        case 29:
        case 30:
          this.$ = o[s].trim(), b.setAccDescription(this.$);
          break;
        case 31:
          b.addSection(o[s].substr(8)), this.$ = o[s].substr(8);
          break;
        case 33:
          b.addTask(o[s - 1], o[s]), this.$ = "task";
          break;
        case 34:
          this.$ = o[s - 1], b.setClickEvent(o[s - 1], o[s], null);
          break;
        case 35:
          this.$ = o[s - 2], b.setClickEvent(o[s - 2], o[s - 1], o[s]);
          break;
        case 36:
          this.$ = o[s - 2], b.setClickEvent(o[s - 2], o[s - 1], null), b.setLink(o[s - 2], o[s]);
          break;
        case 37:
          this.$ = o[s - 3], b.setClickEvent(o[s - 3], o[s - 2], o[s - 1]), b.setLink(o[s - 3], o[s]);
          break;
        case 38:
          this.$ = o[s - 2], b.setClickEvent(o[s - 2], o[s], null), b.setLink(o[s - 2], o[s - 1]);
          break;
        case 39:
          this.$ = o[s - 3], b.setClickEvent(o[s - 3], o[s - 1], o[s]), b.setLink(o[s - 3], o[s - 2]);
          break;
        case 40:
          this.$ = o[s - 1], b.setLink(o[s - 1], o[s]);
          break;
        case 41:
        case 47:
          this.$ = o[s - 1] + " " + o[s];
          break;
        case 42:
        case 43:
        case 45:
          this.$ = o[s - 2] + " " + o[s - 1] + " " + o[s];
          break;
        case 44:
        case 46:
          this.$ = o[s - 3] + " " + o[s - 2] + " " + o[s - 1] + " " + o[s];
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: [1, 2] }, { 1: [3] }, t(e, [2, 2], { 5: 3 }), { 6: [1, 4], 7: 5, 8: [1, 6], 9: 7, 10: [1, 8], 11: 17, 12: n, 13: r, 14: i, 15: a, 16: c, 17: m, 18: Y, 19: 18, 20: C, 21: k, 22: I, 23: _, 24: S, 25: Z, 26: A, 27: U, 28: L, 29: N, 30: W, 31: q, 33: j, 35: p, 36: g, 37: 24, 38: y, 40: h }, t(e, [2, 7], { 1: [2, 1] }), t(e, [2, 3]), { 9: 36, 11: 17, 12: n, 13: r, 14: i, 15: a, 16: c, 17: m, 18: Y, 19: 18, 20: C, 21: k, 22: I, 23: _, 24: S, 25: Z, 26: A, 27: U, 28: L, 29: N, 30: W, 31: q, 33: j, 35: p, 36: g, 37: 24, 38: y, 40: h }, t(e, [2, 5]), t(e, [2, 6]), t(e, [2, 17]), t(e, [2, 18]), t(e, [2, 19]), t(e, [2, 20]), t(e, [2, 21]), t(e, [2, 22]), t(e, [2, 23]), t(e, [2, 24]), t(e, [2, 25]), t(e, [2, 26]), t(e, [2, 27]), { 32: [1, 37] }, { 34: [1, 38] }, t(e, [2, 30]), t(e, [2, 31]), t(e, [2, 32]), { 39: [1, 39] }, t(e, [2, 8]), t(e, [2, 9]), t(e, [2, 10]), t(e, [2, 11]), t(e, [2, 12]), t(e, [2, 13]), t(e, [2, 14]), t(e, [2, 15]), t(e, [2, 16]), { 41: [1, 40], 43: [1, 41] }, t(e, [2, 4]), t(e, [2, 28]), t(e, [2, 29]), t(e, [2, 33]), t(e, [2, 34], { 42: [1, 42], 43: [1, 43] }), t(e, [2, 40], { 41: [1, 44] }), t(e, [2, 35], { 43: [1, 45] }), t(e, [2, 36]), t(e, [2, 38], { 42: [1, 46] }), t(e, [2, 37]), t(e, [2, 39])],
    defaultActions: {},
    parseError: /* @__PURE__ */ d(function(u, f) {
      if (f.recoverable)
        this.trace(u);
      else {
        var x = new Error(u);
        throw x.hash = f, x;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ d(function(u) {
      var f = this, x = [0], b = [], F = [null], o = [], X = this.table, s = "", E = 0, z = 0, V = 2, P = 1, K = o.slice.call(arguments, 1), O = Object.create(this.lexer), st = { yy: {} };
      for (var M in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, M) && (st.yy[M] = this.yy[M]);
      O.setInput(u, st.yy), st.yy.lexer = O, st.yy.parser = this, typeof O.yylloc > "u" && (O.yylloc = {});
      var H = O.yylloc;
      o.push(H);
      var R = O.options && O.options.ranges;
      typeof st.yy.parseError == "function" ? this.parseError = st.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function l(ot) {
        x.length = x.length - 2 * ot, F.length = F.length - ot, o.length = o.length - ot;
      }
      d(l, "popStack");
      function J() {
        var ot;
        return ot = b.pop() || O.lex() || P, typeof ot != "number" && (ot instanceof Array && (b = ot, ot = b.pop()), ot = f.symbols_[ot] || ot), ot;
      }
      d(J, "lex");
      for (var $, Q, G, it, at = {}, pt, ut, Oe, qt; ; ) {
        if (Q = x[x.length - 1], this.defaultActions[Q] ? G = this.defaultActions[Q] : (($ === null || typeof $ > "u") && ($ = J()), G = X[Q] && X[Q][$]), typeof G > "u" || !G.length || !G[0]) {
          var oe = "";
          qt = [];
          for (pt in X[Q])
            this.terminals_[pt] && pt > V && qt.push("'" + this.terminals_[pt] + "'");
          O.showPosition ? oe = "Parse error on line " + (E + 1) + `:
` + O.showPosition() + `
Expecting ` + qt.join(", ") + ", got '" + (this.terminals_[$] || $) + "'" : oe = "Parse error on line " + (E + 1) + ": Unexpected " + ($ == P ? "end of input" : "'" + (this.terminals_[$] || $) + "'"), this.parseError(oe, {
            text: O.match,
            token: this.terminals_[$] || $,
            line: O.yylineno,
            loc: H,
            expected: qt
          });
        }
        if (G[0] instanceof Array && G.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + Q + ", token: " + $);
        switch (G[0]) {
          case 1:
            x.push($), F.push(O.yytext), o.push(O.yylloc), x.push(G[1]), $ = null, z = O.yyleng, s = O.yytext, E = O.yylineno, H = O.yylloc;
            break;
          case 2:
            if (ut = this.productions_[G[1]][1], at.$ = F[F.length - ut], at._$ = {
              first_line: o[o.length - (ut || 1)].first_line,
              last_line: o[o.length - 1].last_line,
              first_column: o[o.length - (ut || 1)].first_column,
              last_column: o[o.length - 1].last_column
            }, R && (at._$.range = [
              o[o.length - (ut || 1)].range[0],
              o[o.length - 1].range[1]
            ]), it = this.performAction.apply(at, [
              s,
              z,
              E,
              st.yy,
              G[1],
              F,
              o
            ].concat(K)), typeof it < "u")
              return it;
            ut && (x = x.slice(0, -1 * ut * 2), F = F.slice(0, -1 * ut), o = o.slice(0, -1 * ut)), x.push(this.productions_[G[1]][0]), F.push(at.$), o.push(at._$), Oe = X[x[x.length - 2]][x[x.length - 1]], x.push(Oe);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, w = /* @__PURE__ */ (function() {
    var v = {
      EOF: 1,
      parseError: /* @__PURE__ */ d(function(f, x) {
        if (this.yy.parser)
          this.yy.parser.parseError(f, x);
        else
          throw new Error(f);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ d(function(u, f) {
        return this.yy = f || this.yy || {}, this._input = u, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ d(function() {
        var u = this._input[0];
        this.yytext += u, this.yyleng++, this.offset++, this.match += u, this.matched += u;
        var f = u.match(/(?:\r\n?|\n).*/g);
        return f ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), u;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ d(function(u) {
        var f = u.length, x = u.split(/(?:\r\n?|\n)/g);
        this._input = u + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - f), this.offset -= f;
        var b = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), x.length - 1 && (this.yylineno -= x.length - 1);
        var F = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: x ? (x.length === b.length ? this.yylloc.first_column : 0) + b[b.length - x.length].length - x[0].length : this.yylloc.first_column - f
        }, this.options.ranges && (this.yylloc.range = [F[0], F[0] + this.yyleng - f]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ d(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ d(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ d(function(u) {
        this.unput(this.match.slice(u));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ d(function() {
        var u = this.matched.substr(0, this.matched.length - this.match.length);
        return (u.length > 20 ? "..." : "") + u.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ d(function() {
        var u = this.match;
        return u.length < 20 && (u += this._input.substr(0, 20 - u.length)), (u.substr(0, 20) + (u.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ d(function() {
        var u = this.pastInput(), f = new Array(u.length + 1).join("-");
        return u + this.upcomingInput() + `
` + f + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ d(function(u, f) {
        var x, b, F;
        if (this.options.backtrack_lexer && (F = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (F.yylloc.range = this.yylloc.range.slice(0))), b = u[0].match(/(?:\r\n?|\n).*/g), b && (this.yylineno += b.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: b ? b[b.length - 1].length - b[b.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + u[0].length
        }, this.yytext += u[0], this.match += u[0], this.matches = u, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(u[0].length), this.matched += u[0], x = this.performAction.call(this, this.yy, this, f, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), x)
          return x;
        if (this._backtrack) {
          for (var o in F)
            this[o] = F[o];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ d(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var u, f, x, b;
        this._more || (this.yytext = "", this.match = "");
        for (var F = this._currentRules(), o = 0; o < F.length; o++)
          if (x = this._input.match(this.rules[F[o]]), x && (!f || x[0].length > f[0].length)) {
            if (f = x, b = o, this.options.backtrack_lexer) {
              if (u = this.test_match(x, F[o]), u !== !1)
                return u;
              if (this._backtrack) {
                f = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return f ? (u = this.test_match(f, F[b]), u !== !1 ? u : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ d(function() {
        var f = this.next();
        return f || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ d(function(f) {
        this.conditionStack.push(f);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ d(function() {
        var f = this.conditionStack.length - 1;
        return f > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ d(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ d(function(f) {
        return f = this.conditionStack.length - 1 - Math.abs(f || 0), f >= 0 ? this.conditionStack[f] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ d(function(f) {
        this.begin(f);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ d(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ d(function(f, x, b, F) {
        switch (b) {
          case 0:
            return this.begin("open_directive"), "open_directive";
          case 1:
            return this.begin("acc_title"), 31;
          case 2:
            return this.popState(), "acc_title_value";
          case 3:
            return this.begin("acc_descr"), 33;
          case 4:
            return this.popState(), "acc_descr_value";
          case 5:
            this.begin("acc_descr_multiline");
            break;
          case 6:
            this.popState();
            break;
          case 7:
            return "acc_descr_multiline_value";
          case 8:
            break;
          case 9:
            break;
          case 10:
            break;
          case 11:
            return 10;
          case 12:
            break;
          case 13:
            break;
          case 14:
            this.begin("href");
            break;
          case 15:
            this.popState();
            break;
          case 16:
            return 43;
          case 17:
            this.begin("callbackname");
            break;
          case 18:
            this.popState();
            break;
          case 19:
            this.popState(), this.begin("callbackargs");
            break;
          case 20:
            return 41;
          case 21:
            this.popState();
            break;
          case 22:
            return 42;
          case 23:
            this.begin("click");
            break;
          case 24:
            this.popState();
            break;
          case 25:
            return 40;
          case 26:
            return 4;
          case 27:
            return 22;
          case 28:
            return 23;
          case 29:
            return 24;
          case 30:
            return 25;
          case 31:
            return 26;
          case 32:
            return 28;
          case 33:
            return 27;
          case 34:
            return 29;
          case 35:
            return 12;
          case 36:
            return 13;
          case 37:
            return 14;
          case 38:
            return 15;
          case 39:
            return 16;
          case 40:
            return 17;
          case 41:
            return 18;
          case 42:
            return 20;
          case 43:
            return 21;
          case 44:
            return "date";
          case 45:
            return 30;
          case 46:
            return "accDescription";
          case 47:
            return 36;
          case 48:
            return 38;
          case 49:
            return 39;
          case 50:
            return ":";
          case 51:
            return 6;
          case 52:
            return "INVALID";
        }
      }, "anonymous"),
      rules: [/^(?:%%\{)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:%%(?!\{)*[^\n]*)/i, /^(?:[^\}]%%*[^\n]*)/i, /^(?:%%*[^\n]*[\n]*)/i, /^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:%[^\n]*)/i, /^(?:href[\s]+["])/i, /^(?:["])/i, /^(?:[^"]*)/i, /^(?:call[\s]+)/i, /^(?:\([\s]*\))/i, /^(?:\()/i, /^(?:[^(]*)/i, /^(?:\))/i, /^(?:[^)]*)/i, /^(?:click[\s]+)/i, /^(?:[\s\n])/i, /^(?:[^\s\n]*)/i, /^(?:gantt\b)/i, /^(?:dateFormat\s[^#\n;]+)/i, /^(?:inclusiveEndDates\b)/i, /^(?:topAxis\b)/i, /^(?:axisFormat\s[^#\n;]+)/i, /^(?:tickInterval\s[^#\n;]+)/i, /^(?:includes\s[^#\n;]+)/i, /^(?:excludes\s[^#\n;]+)/i, /^(?:todayMarker\s[^\n;]+)/i, /^(?:weekday\s+monday\b)/i, /^(?:weekday\s+tuesday\b)/i, /^(?:weekday\s+wednesday\b)/i, /^(?:weekday\s+thursday\b)/i, /^(?:weekday\s+friday\b)/i, /^(?:weekday\s+saturday\b)/i, /^(?:weekday\s+sunday\b)/i, /^(?:weekend\s+friday\b)/i, /^(?:weekend\s+saturday\b)/i, /^(?:\d\d\d\d-\d\d-\d\d\b)/i, /^(?:title\s[^\n]+)/i, /^(?:accDescription\s[^#\n;]+)/i, /^(?:section\s[^\n]+)/i, /^(?:[^:\n]+)/i, /^(?::[^#\n;]+)/i, /^(?::)/i, /^(?:$)/i, /^(?:.)/i],
      conditions: { acc_descr_multiline: { rules: [6, 7], inclusive: !1 }, acc_descr: { rules: [4], inclusive: !1 }, acc_title: { rules: [2], inclusive: !1 }, callbackargs: { rules: [21, 22], inclusive: !1 }, callbackname: { rules: [18, 19, 20], inclusive: !1 }, href: { rules: [15, 16], inclusive: !1 }, click: { rules: [24, 25], inclusive: !1 }, INITIAL: { rules: [0, 1, 3, 5, 8, 9, 10, 11, 12, 13, 14, 17, 23, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52], inclusive: !0 } }
    };
    return v;
  })();
  D.lexer = w;
  function T() {
    this.yy = {};
  }
  return d(T, "Parser"), T.prototype = D, D.Parser = T, new T();
})();
be.parser = be;
var Gi = be;
rt.extend(Wi);
rt.extend(Ni);
rt.extend(zi);
var nn = { friday: 5, saturday: 6 }, lt = "", _e = "", Fe = void 0, Ye = "", Rt = [], Vt = [], Ue = /* @__PURE__ */ new Map(), Ee = [], ie = [], Lt = "", Le = "", _n = ["active", "done", "crit", "milestone", "vert"], Ie = [], zt = !1, Ae = !1, We = "sunday", se = "saturday", we = 0, ji = /* @__PURE__ */ d(function() {
  Ee = [], ie = [], Lt = "", Ie = [], Kt = 0, Me = void 0, te = void 0, tt = [], lt = "", _e = "", Le = "", Fe = void 0, Ye = "", Rt = [], Vt = [], zt = !1, Ae = !1, we = 0, Ue = /* @__PURE__ */ new Map(), Bn(), We = "sunday", se = "saturday";
}, "clear"), Qi = /* @__PURE__ */ d(function(t) {
  _e = t;
}, "setAxisFormat"), Ji = /* @__PURE__ */ d(function() {
  return _e;
}, "getAxisFormat"), Ki = /* @__PURE__ */ d(function(t) {
  Fe = t;
}, "setTickInterval"), ts = /* @__PURE__ */ d(function() {
  return Fe;
}, "getTickInterval"), es = /* @__PURE__ */ d(function(t) {
  Ye = t;
}, "setTodayMarker"), ns = /* @__PURE__ */ d(function() {
  return Ye;
}, "getTodayMarker"), rs = /* @__PURE__ */ d(function(t) {
  lt = t;
}, "setDateFormat"), is = /* @__PURE__ */ d(function() {
  zt = !0;
}, "enableInclusiveEndDates"), ss = /* @__PURE__ */ d(function() {
  return zt;
}, "endDatesAreInclusive"), as = /* @__PURE__ */ d(function() {
  Ae = !0;
}, "enableTopAxis"), os = /* @__PURE__ */ d(function() {
  return Ae;
}, "topAxisEnabled"), cs = /* @__PURE__ */ d(function(t) {
  Le = t;
}, "setDisplayMode"), us = /* @__PURE__ */ d(function() {
  return Le;
}, "getDisplayMode"), ls = /* @__PURE__ */ d(function() {
  return lt;
}, "getDateFormat"), fs = /* @__PURE__ */ d(function(t) {
  Rt = t.toLowerCase().split(/[\s,]+/);
}, "setIncludes"), ds = /* @__PURE__ */ d(function() {
  return Rt;
}, "getIncludes"), hs = /* @__PURE__ */ d(function(t) {
  Vt = t.toLowerCase().split(/[\s,]+/);
}, "setExcludes"), ms = /* @__PURE__ */ d(function() {
  return Vt;
}, "getExcludes"), gs = /* @__PURE__ */ d(function() {
  return Ue;
}, "getLinks"), ys = /* @__PURE__ */ d(function(t) {
  Lt = t, Ee.push(t);
}, "addSection"), ks = /* @__PURE__ */ d(function() {
  return Ee;
}, "getSections"), ps = /* @__PURE__ */ d(function() {
  let t = rn();
  const e = 10;
  let n = 0;
  for (; !t && n < e; )
    t = rn(), n++;
  return ie = tt, ie;
}, "getTasks"), Fn = /* @__PURE__ */ d(function(t, e, n, r) {
  const i = t.format(e.trim()), a = t.format("YYYY-MM-DD");
  return r.includes(i) || r.includes(a) ? !1 : n.includes("weekends") && (t.isoWeekday() === nn[se] || t.isoWeekday() === nn[se] + 1) || n.includes(t.format("dddd").toLowerCase()) ? !0 : n.includes(i) || n.includes(a);
}, "isInvalidDate"), vs = /* @__PURE__ */ d(function(t) {
  We = t;
}, "setWeekday"), Ts = /* @__PURE__ */ d(function() {
  return We;
}, "getWeekday"), xs = /* @__PURE__ */ d(function(t) {
  se = t;
}, "setWeekend"), Yn = /* @__PURE__ */ d(function(t, e, n, r) {
  if (!n.length || t.manualEndTime)
    return;
  let i;
  t.startTime instanceof Date ? i = rt(t.startTime) : i = rt(t.startTime, e, !0), i = i.add(1, "d");
  let a;
  t.endTime instanceof Date ? a = rt(t.endTime) : a = rt(t.endTime, e, !0);
  const [c, m] = bs(
    i,
    a,
    e,
    n,
    r
  );
  t.endTime = c.toDate(), t.renderEndTime = m;
}, "checkTaskDates"), bs = /* @__PURE__ */ d(function(t, e, n, r, i) {
  let a = !1, c = null;
  for (; t <= e; )
    a || (c = e.toDate()), a = Fn(t, n, r, i), a && (e = e.add(1, "d")), t = t.add(1, "d");
  return [e, c];
}, "fixTaskDates"), De = /* @__PURE__ */ d(function(t, e, n) {
  if (n = n.trim(), (/* @__PURE__ */ d((m) => {
    const Y = m.trim();
    return Y === "x" || Y === "X";
  }, "isTimestampFormat"))(e) && /^\d+$/.test(n))
    return new Date(Number(n));
  const a = /^after\s+(?<ids>[\d\w- ]+)/.exec(n);
  if (a !== null) {
    let m = null;
    for (const C of a.groups.ids.split(" ")) {
      let k = Ct(C);
      k !== void 0 && (!m || k.endTime > m.endTime) && (m = k);
    }
    if (m)
      return m.endTime;
    const Y = /* @__PURE__ */ new Date();
    return Y.setHours(0, 0, 0, 0), Y;
  }
  let c = rt(n, e.trim(), !0);
  if (c.isValid())
    return c.toDate();
  {
    Tt.debug("Invalid date:" + n), Tt.debug("With date format:" + e.trim());
    const m = new Date(n);
    if (m === void 0 || isNaN(m.getTime()) || // WebKit browsers can mis-parse invalid dates to be ridiculously
    // huge numbers, e.g. new Date('202304') gets parsed as January 1, 202304.
    // This can cause virtually infinite loops while rendering, so for the
    // purposes of Gantt charts we'll just treat any date beyond 10,000 AD/BC as
    // invalid.
    m.getFullYear() < -1e4 || m.getFullYear() > 1e4)
      throw new Error("Invalid date:" + n);
    return m;
  }
}, "getStartDate"), Un = /* @__PURE__ */ d(function(t) {
  const e = /^(\d+(?:\.\d+)?)([Mdhmswy]|ms)$/.exec(t.trim());
  return e !== null ? [Number.parseFloat(e[1]), e[2]] : [NaN, "ms"];
}, "parseDuration"), En = /* @__PURE__ */ d(function(t, e, n, r = !1) {
  n = n.trim();
  const a = /^until\s+(?<ids>[\d\w- ]+)/.exec(n);
  if (a !== null) {
    let k = null;
    for (const _ of a.groups.ids.split(" ")) {
      let S = Ct(_);
      S !== void 0 && (!k || S.startTime < k.startTime) && (k = S);
    }
    if (k)
      return k.startTime;
    const I = /* @__PURE__ */ new Date();
    return I.setHours(0, 0, 0, 0), I;
  }
  let c = rt(n, e.trim(), !0);
  if (c.isValid())
    return r && (c = c.add(1, "d")), c.toDate();
  let m = rt(t);
  const [Y, C] = Un(n);
  if (!Number.isNaN(Y)) {
    const k = m.add(Y, C);
    k.isValid() && (m = k);
  }
  return m.toDate();
}, "getEndDate"), Kt = 0, Yt = /* @__PURE__ */ d(function(t) {
  return t === void 0 ? (Kt = Kt + 1, "task" + Kt) : t;
}, "parseId"), ws = /* @__PURE__ */ d(function(t, e) {
  let n;
  e.substr(0, 1) === ":" ? n = e.substr(1, e.length) : n = e;
  const r = n.split(","), i = {};
  $e(r, i, _n);
  for (let c = 0; c < r.length; c++)
    r[c] = r[c].trim();
  let a = "";
  switch (r.length) {
    case 1:
      i.id = Yt(), i.startTime = t.endTime, a = r[0];
      break;
    case 2:
      i.id = Yt(), i.startTime = De(void 0, lt, r[0]), a = r[1];
      break;
    case 3:
      i.id = Yt(r[0]), i.startTime = De(void 0, lt, r[1]), a = r[2];
      break;
  }
  return a && (i.endTime = En(i.startTime, lt, a, zt), i.manualEndTime = rt(a, "YYYY-MM-DD", !0).isValid(), Yn(i, lt, Vt, Rt)), i;
}, "compileData"), Ds = /* @__PURE__ */ d(function(t, e) {
  let n;
  e.substr(0, 1) === ":" ? n = e.substr(1, e.length) : n = e;
  const r = n.split(","), i = {};
  $e(r, i, _n);
  for (let a = 0; a < r.length; a++)
    r[a] = r[a].trim();
  switch (r.length) {
    case 1:
      i.id = Yt(), i.startTime = {
        type: "prevTaskEnd",
        id: t
      }, i.endTime = {
        data: r[0]
      };
      break;
    case 2:
      i.id = Yt(), i.startTime = {
        type: "getStartDate",
        startData: r[0]
      }, i.endTime = {
        data: r[1]
      };
      break;
    case 3:
      i.id = Yt(r[0]), i.startTime = {
        type: "getStartDate",
        startData: r[1]
      }, i.endTime = {
        data: r[2]
      };
      break;
  }
  return i;
}, "parseData"), Me, te, tt = [], Ln = {}, Ms = /* @__PURE__ */ d(function(t, e) {
  const n = {
    section: Lt,
    type: Lt,
    processed: !1,
    manualEndTime: !1,
    renderEndTime: null,
    raw: { data: e },
    task: t,
    classes: []
  }, r = Ds(te, e);
  n.raw.startTime = r.startTime, n.raw.endTime = r.endTime, n.id = r.id, n.prevTaskId = te, n.active = r.active, n.done = r.done, n.crit = r.crit, n.milestone = r.milestone, n.vert = r.vert, n.order = we, we++;
  const i = tt.push(n);
  te = n.id, Ln[n.id] = i - 1;
}, "addTask"), Ct = /* @__PURE__ */ d(function(t) {
  const e = Ln[t];
  return tt[e];
}, "findTaskById"), Cs = /* @__PURE__ */ d(function(t, e) {
  const n = {
    section: Lt,
    type: Lt,
    description: t,
    task: t,
    classes: []
  }, r = ws(Me, e);
  n.startTime = r.startTime, n.endTime = r.endTime, n.id = r.id, n.active = r.active, n.done = r.done, n.crit = r.crit, n.milestone = r.milestone, n.vert = r.vert, Me = n, ie.push(n);
}, "addTaskOrg"), rn = /* @__PURE__ */ d(function() {
  const t = /* @__PURE__ */ d(function(n) {
    const r = tt[n];
    let i = "";
    switch (tt[n].raw.startTime.type) {
      case "prevTaskEnd": {
        const a = Ct(r.prevTaskId);
        r.startTime = a.endTime;
        break;
      }
      case "getStartDate":
        i = De(void 0, lt, tt[n].raw.startTime.startData), i && (tt[n].startTime = i);
        break;
    }
    return tt[n].startTime && (tt[n].endTime = En(
      tt[n].startTime,
      lt,
      tt[n].raw.endTime.data,
      zt
    ), tt[n].endTime && (tt[n].processed = !0, tt[n].manualEndTime = rt(
      tt[n].raw.endTime.data,
      "YYYY-MM-DD",
      !0
    ).isValid(), Yn(tt[n], lt, Vt, Rt))), tt[n].processed;
  }, "compileTask");
  let e = !0;
  for (const [n, r] of tt.entries())
    t(n), e = e && r.processed;
  return e;
}, "compileTasks"), Ss = /* @__PURE__ */ d(function(t, e) {
  let n = e;
  _t().securityLevel !== "loose" && (n = Zn.sanitizeUrl(e)), t.split(",").forEach(function(r) {
    Ct(r) !== void 0 && (An(r, () => {
      window.open(n, "_self");
    }), Ue.set(r, n));
  }), In(t, "clickable");
}, "setLink"), In = /* @__PURE__ */ d(function(t, e) {
  t.split(",").forEach(function(n) {
    let r = Ct(n);
    r !== void 0 && r.classes.push(e);
  });
}, "setClass"), _s = /* @__PURE__ */ d(function(t, e, n) {
  if (_t().securityLevel !== "loose" || e === void 0)
    return;
  let r = [];
  if (typeof n == "string") {
    r = n.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    for (let a = 0; a < r.length; a++) {
      let c = r[a].trim();
      c.startsWith('"') && c.endsWith('"') && (c = c.substr(1, c.length - 2)), r[a] = c;
    }
  }
  r.length === 0 && r.push(t), Ct(t) !== void 0 && An(t, () => {
    Xn.runFunc(e, ...r);
  });
}, "setClickFun"), An = /* @__PURE__ */ d(function(t, e) {
  Ie.push(
    function() {
      const n = document.querySelector(`[id="${t}"]`);
      n !== null && n.addEventListener("click", function() {
        e();
      });
    },
    function() {
      const n = document.querySelector(`[id="${t}-text"]`);
      n !== null && n.addEventListener("click", function() {
        e();
      });
    }
  );
}, "pushFun"), Fs = /* @__PURE__ */ d(function(t, e, n) {
  t.split(",").forEach(function(r) {
    _s(r, e, n);
  }), In(t, "clickable");
}, "setClickEvent"), Ys = /* @__PURE__ */ d(function(t) {
  Ie.forEach(function(e) {
    e(t);
  });
}, "bindFunctions"), Us = {
  getConfig: /* @__PURE__ */ d(() => _t().gantt, "getConfig"),
  clear: ji,
  setDateFormat: rs,
  getDateFormat: ls,
  enableInclusiveEndDates: is,
  endDatesAreInclusive: ss,
  enableTopAxis: as,
  topAxisEnabled: os,
  setAxisFormat: Qi,
  getAxisFormat: Ji,
  setTickInterval: Ki,
  getTickInterval: ts,
  setTodayMarker: es,
  getTodayMarker: ns,
  setAccTitle: Vn,
  getAccTitle: Rn,
  setDiagramTitle: Pn,
  getDiagramTitle: Nn,
  setDisplayMode: cs,
  getDisplayMode: us,
  setAccDescription: Hn,
  getAccDescription: On,
  addSection: ys,
  getSections: ks,
  getTasks: ps,
  addTask: Ms,
  findTaskById: Ct,
  addTaskOrg: Cs,
  setIncludes: fs,
  getIncludes: ds,
  setExcludes: hs,
  getExcludes: ms,
  setClickEvent: Fs,
  setLink: Ss,
  getLinks: gs,
  bindFunctions: Ys,
  parseDuration: Un,
  isInvalidDate: Fn,
  setWeekday: vs,
  getWeekday: Ts,
  setWeekend: xs
};
function $e(t, e, n) {
  let r = !0;
  for (; r; )
    r = !1, n.forEach(function(i) {
      const a = "^\\s*" + i + "\\s*$", c = new RegExp(a);
      t[0].match(c) && (e[i] = !0, t.shift(1), r = !0);
    });
}
d($e, "getTaskTags");
rt.extend(Xi);
var Es = /* @__PURE__ */ d(function() {
  Tt.debug("Something is calling, setConf, remove the call");
}, "setConf"), sn = {
  monday: Ht,
  tuesday: pn,
  wednesday: vn,
  thursday: bt,
  friday: Tn,
  saturday: xn,
  sunday: Pt
}, Ls = /* @__PURE__ */ d((t, e) => {
  let n = [...t].map(() => -1 / 0), r = [...t].sort((a, c) => a.startTime - c.startTime || a.order - c.order), i = 0;
  for (const a of r)
    for (let c = 0; c < n.length; c++)
      if (a.startTime >= n[c]) {
        n[c] = a.endTime, a.order = c + e, c > i && (i = c);
        break;
      }
  return i;
}, "getMaxIntersections"), dt, ve = 1e4, Is = /* @__PURE__ */ d(function(t, e, n, r) {
  const i = _t().gantt, a = _t().securityLevel;
  let c;
  a === "sandbox" && (c = Zt("#i" + e));
  const m = a === "sandbox" ? Zt(c.nodes()[0].contentDocument.body) : Zt("body"), Y = a === "sandbox" ? c.nodes()[0].contentDocument : document, C = Y.getElementById(e);
  dt = C.parentElement.offsetWidth, dt === void 0 && (dt = 1200), i.useWidth !== void 0 && (dt = i.useWidth);
  const k = r.db.getTasks();
  let I = [];
  for (const h of k)
    I.push(h.type);
  I = y(I);
  const _ = {};
  let S = 2 * i.topPadding;
  if (r.db.getDisplayMode() === "compact" || i.displayMode === "compact") {
    const h = {};
    for (const w of k)
      h[w.section] === void 0 ? h[w.section] = [w] : h[w.section].push(w);
    let D = 0;
    for (const w of Object.keys(h)) {
      const T = Ls(h[w], D) + 1;
      D += T, S += T * (i.barHeight + i.barGap), _[w] = T;
    }
  } else {
    S += k.length * (i.barHeight + i.barGap);
    for (const h of I)
      _[h] = k.filter((D) => D.type === h).length;
  }
  C.setAttribute("viewBox", "0 0 " + dt + " " + S);
  const Z = m.select(`[id="${e}"]`), A = Ei().domain([
    er(k, function(h) {
      return h.startTime;
    }),
    tr(k, function(h) {
      return h.endTime;
    })
  ]).rangeRound([0, dt - i.leftPadding - i.rightPadding]);
  function U(h, D) {
    const w = h.startTime, T = D.startTime;
    let v = 0;
    return w > T ? v = 1 : w < T && (v = -1), v;
  }
  d(U, "taskCompare"), k.sort(U), L(k, dt, S), zn(Z, S, dt, i.useMaxWidth), Z.append("text").text(r.db.getDiagramTitle()).attr("x", dt / 2).attr("y", i.titleTopMargin).attr("class", "titleText");
  function L(h, D, w) {
    const T = i.barHeight, v = T + i.barGap, u = i.topPadding, f = i.leftPadding, x = Jn().domain([0, I.length]).range(["#00B9FA", "#F95002"]).interpolate(yr);
    W(
      v,
      u,
      f,
      D,
      w,
      h,
      r.db.getExcludes(),
      r.db.getIncludes()
    ), j(f, u, D, w), N(h, v, u, f, T, x, D), p(v, u), g(f, u, D, w);
  }
  d(L, "makeGantt");
  function N(h, D, w, T, v, u, f) {
    h.sort((s, E) => s.vert === E.vert ? 0 : s.vert ? 1 : -1);
    const b = [...new Set(h.map((s) => s.order))].map((s) => h.find((E) => E.order === s));
    Z.append("g").selectAll("rect").data(b).enter().append("rect").attr("x", 0).attr("y", function(s, E) {
      return E = s.order, E * D + w - 2;
    }).attr("width", function() {
      return f - i.rightPadding / 2;
    }).attr("height", D).attr("class", function(s) {
      for (const [E, z] of I.entries())
        if (s.type === z)
          return "section section" + E % i.numberSectionStyles;
      return "section section0";
    }).enter();
    const F = Z.append("g").selectAll("rect").data(h).enter(), o = r.db.getLinks();
    if (F.append("rect").attr("id", function(s) {
      return s.id;
    }).attr("rx", 3).attr("ry", 3).attr("x", function(s) {
      return s.milestone ? A(s.startTime) + T + 0.5 * (A(s.endTime) - A(s.startTime)) - 0.5 * v : A(s.startTime) + T;
    }).attr("y", function(s, E) {
      return E = s.order, s.vert ? i.gridLineStartPadding : E * D + w;
    }).attr("width", function(s) {
      return s.milestone ? v : s.vert ? 0.08 * v : A(s.renderEndTime || s.endTime) - A(s.startTime);
    }).attr("height", function(s) {
      return s.vert ? k.length * (i.barHeight + i.barGap) + i.barHeight * 2 : v;
    }).attr("transform-origin", function(s, E) {
      return E = s.order, (A(s.startTime) + T + 0.5 * (A(s.endTime) - A(s.startTime))).toString() + "px " + (E * D + w + 0.5 * v).toString() + "px";
    }).attr("class", function(s) {
      const E = "task";
      let z = "";
      s.classes.length > 0 && (z = s.classes.join(" "));
      let V = 0;
      for (const [K, O] of I.entries())
        s.type === O && (V = K % i.numberSectionStyles);
      let P = "";
      return s.active ? s.crit ? P += " activeCrit" : P = " active" : s.done ? s.crit ? P = " doneCrit" : P = " done" : s.crit && (P += " crit"), P.length === 0 && (P = " task"), s.milestone && (P = " milestone " + P), s.vert && (P = " vert " + P), P += V, P += " " + z, E + P;
    }), F.append("text").attr("id", function(s) {
      return s.id + "-text";
    }).text(function(s) {
      return s.task;
    }).attr("font-size", i.fontSize).attr("x", function(s) {
      let E = A(s.startTime), z = A(s.renderEndTime || s.endTime);
      if (s.milestone && (E += 0.5 * (A(s.endTime) - A(s.startTime)) - 0.5 * v, z = E + v), s.vert)
        return A(s.startTime) + T;
      const V = this.getBBox().width;
      return V > z - E ? z + V + 1.5 * i.leftPadding > f ? E + T - 5 : z + T + 5 : (z - E) / 2 + E + T;
    }).attr("y", function(s, E) {
      return s.vert ? i.gridLineStartPadding + k.length * (i.barHeight + i.barGap) + 60 : (E = s.order, E * D + i.barHeight / 2 + (i.fontSize / 2 - 2) + w);
    }).attr("text-height", v).attr("class", function(s) {
      const E = A(s.startTime);
      let z = A(s.endTime);
      s.milestone && (z = E + v);
      const V = this.getBBox().width;
      let P = "";
      s.classes.length > 0 && (P = s.classes.join(" "));
      let K = 0;
      for (const [st, M] of I.entries())
        s.type === M && (K = st % i.numberSectionStyles);
      let O = "";
      return s.active && (s.crit ? O = "activeCritText" + K : O = "activeText" + K), s.done ? s.crit ? O = O + " doneCritText" + K : O = O + " doneText" + K : s.crit && (O = O + " critText" + K), s.milestone && (O += " milestoneText"), s.vert && (O += " vertText"), V > z - E ? z + V + 1.5 * i.leftPadding > f ? P + " taskTextOutsideLeft taskTextOutside" + K + " " + O : P + " taskTextOutsideRight taskTextOutside" + K + " " + O + " width-" + V : P + " taskText taskText" + K + " " + O + " width-" + V;
    }), _t().securityLevel === "sandbox") {
      let s;
      s = Zt("#i" + e);
      const E = s.nodes()[0].contentDocument;
      F.filter(function(z) {
        return o.has(z.id);
      }).each(function(z) {
        var V = E.querySelector("#" + z.id), P = E.querySelector("#" + z.id + "-text");
        const K = V.parentNode;
        var O = E.createElement("a");
        O.setAttribute("xlink:href", o.get(z.id)), O.setAttribute("target", "_top"), K.appendChild(O), O.appendChild(V), O.appendChild(P);
      });
    }
  }
  d(N, "drawRects");
  function W(h, D, w, T, v, u, f, x) {
    if (f.length === 0 && x.length === 0)
      return;
    let b, F;
    for (const { startTime: V, endTime: P } of u)
      (b === void 0 || V < b) && (b = V), (F === void 0 || P > F) && (F = P);
    if (!b || !F)
      return;
    if (rt(F).diff(rt(b), "year") > 5) {
      Tt.warn(
        "The difference between the min and max time is more than 5 years. This will cause performance issues. Skipping drawing exclude days."
      );
      return;
    }
    const o = r.db.getDateFormat(), X = [];
    let s = null, E = rt(b);
    for (; E.valueOf() <= F; )
      r.db.isInvalidDate(E, o, f, x) ? s ? s.end = E : s = {
        start: E,
        end: E
      } : s && (X.push(s), s = null), E = E.add(1, "d");
    Z.append("g").selectAll("rect").data(X).enter().append("rect").attr("id", (V) => "exclude-" + V.start.format("YYYY-MM-DD")).attr("x", (V) => A(V.start.startOf("day")) + w).attr("y", i.gridLineStartPadding).attr("width", (V) => A(V.end.endOf("day")) - A(V.start.startOf("day"))).attr("height", v - D - i.gridLineStartPadding).attr("transform-origin", function(V, P) {
      return (A(V.start) + w + 0.5 * (A(V.end) - A(V.start))).toString() + "px " + (P * h + 0.5 * v).toString() + "px";
    }).attr("class", "exclude-range");
  }
  d(W, "drawExcludeDays");
  function q(h, D, w, T) {
    if (w <= 0 || h > D)
      return 1 / 0;
    const v = D - h, u = rt.duration({ [T ?? "day"]: w }).asMilliseconds();
    return u <= 0 ? 1 / 0 : Math.ceil(v / u);
  }
  d(q, "getEstimatedTickCount");
  function j(h, D, w, T) {
    const v = r.db.getDateFormat(), u = r.db.getAxisFormat();
    let f;
    u ? f = u : v === "D" ? f = "%d" : f = i.axisFormat ?? "%Y-%m-%d";
    let x = ur(A).tickSize(-T + D + i.gridLineStartPadding).tickFormat(re(f));
    const F = /^([1-9]\d*)(millisecond|second|minute|hour|day|week|month)$/.exec(
      r.db.getTickInterval() || i.tickInterval
    );
    if (F !== null) {
      const o = parseInt(F[1], 10);
      if (isNaN(o) || o <= 0)
        Tt.warn(
          `Invalid tick interval value: "${F[1]}". Skipping custom tick interval.`
        );
      else {
        const X = F[2], s = r.db.getWeekday() || i.weekday, E = A.domain(), z = E[0], V = E[1], P = q(z, V, o, X);
        if (P > ve)
          Tt.warn(
            `The tick interval "${o}${X}" would generate ${P} ticks, which exceeds the maximum allowed (${ve}). This may indicate an invalid date or time range. Skipping custom tick interval.`
          );
        else
          switch (X) {
            case "millisecond":
              x.ticks(Ut.every(o));
              break;
            case "second":
              x.ticks(vt.every(o));
              break;
            case "minute":
              x.ticks($t.every(o));
              break;
            case "hour":
              x.ticks(Ot.every(o));
              break;
            case "day":
              x.ticks(xt.every(o));
              break;
            case "week":
              x.ticks(sn[s].every(o));
              break;
            case "month":
              x.ticks(Nt.every(o));
              break;
          }
      }
    }
    if (Z.append("g").attr("class", "grid").attr("transform", "translate(" + h + ", " + (T - 50) + ")").call(x).selectAll("text").style("text-anchor", "middle").attr("fill", "#000").attr("stroke", "none").attr("font-size", 10).attr("dy", "1em"), r.db.topAxisEnabled() || i.topAxis) {
      let o = cr(A).tickSize(-T + D + i.gridLineStartPadding).tickFormat(re(f));
      if (F !== null) {
        const X = parseInt(F[1], 10);
        if (isNaN(X) || X <= 0)
          Tt.warn(
            `Invalid tick interval value: "${F[1]}". Skipping custom tick interval.`
          );
        else {
          const s = F[2], E = r.db.getWeekday() || i.weekday, z = A.domain(), V = z[0], P = z[1];
          if (q(V, P, X, s) <= ve)
            switch (s) {
              case "millisecond":
                o.ticks(Ut.every(X));
                break;
              case "second":
                o.ticks(vt.every(X));
                break;
              case "minute":
                o.ticks($t.every(X));
                break;
              case "hour":
                o.ticks(Ot.every(X));
                break;
              case "day":
                o.ticks(xt.every(X));
                break;
              case "week":
                o.ticks(sn[E].every(X));
                break;
              case "month":
                o.ticks(Nt.every(X));
                break;
            }
        }
      }
      Z.append("g").attr("class", "grid").attr("transform", "translate(" + h + ", " + D + ")").call(o).selectAll("text").style("text-anchor", "middle").attr("fill", "#000").attr("stroke", "none").attr("font-size", 10);
    }
  }
  d(j, "makeGrid");
  function p(h, D) {
    let w = 0;
    const T = Object.keys(_).map((v) => [v, _[v]]);
    Z.append("g").selectAll("text").data(T).enter().append(function(v) {
      const u = v[0].split(qn.lineBreakRegex), f = -(u.length - 1) / 2, x = Y.createElementNS("http://www.w3.org/2000/svg", "text");
      x.setAttribute("dy", f + "em");
      for (const [b, F] of u.entries()) {
        const o = Y.createElementNS("http://www.w3.org/2000/svg", "tspan");
        o.setAttribute("alignment-baseline", "central"), o.setAttribute("x", "10"), b > 0 && o.setAttribute("dy", "1em"), o.textContent = F, x.appendChild(o);
      }
      return x;
    }).attr("x", 10).attr("y", function(v, u) {
      if (u > 0)
        for (let f = 0; f < u; f++)
          return w += T[u - 1][1], v[1] * h / 2 + w * h + D;
      else
        return v[1] * h / 2 + D;
    }).attr("font-size", i.sectionFontSize).attr("class", function(v) {
      for (const [u, f] of I.entries())
        if (v[0] === f)
          return "sectionTitle sectionTitle" + u % i.numberSectionStyles;
      return "sectionTitle";
    });
  }
  d(p, "vertLabels");
  function g(h, D, w, T) {
    const v = r.db.getTodayMarker();
    if (v === "off")
      return;
    const u = Z.append("g").attr("class", "today"), f = /* @__PURE__ */ new Date(), x = u.append("line");
    x.attr("x1", A(f) + h).attr("x2", A(f) + h).attr("y1", i.titleTopMargin).attr("y2", T - i.titleTopMargin).attr("class", "today"), v !== "" && x.attr("style", v.replace(/,/g, ";"));
  }
  d(g, "drawToday");
  function y(h) {
    const D = {}, w = [];
    for (let T = 0, v = h.length; T < v; ++T)
      Object.prototype.hasOwnProperty.call(D, h[T]) || (D[h[T]] = !0, w.push(h[T]));
    return w;
  }
  d(y, "checkUnique");
}, "draw"), As = {
  setConf: Es,
  draw: Is
}, Ws = /* @__PURE__ */ d((t) => `
  .mermaid-main-font {
        font-family: ${t.fontFamily};
  }

  .exclude-range {
    fill: ${t.excludeBkgColor};
  }

  .section {
    stroke: none;
    opacity: 0.2;
  }

  .section0 {
    fill: ${t.sectionBkgColor};
  }

  .section2 {
    fill: ${t.sectionBkgColor2};
  }

  .section1,
  .section3 {
    fill: ${t.altSectionBkgColor};
    opacity: 0.2;
  }

  .sectionTitle0 {
    fill: ${t.titleColor};
  }

  .sectionTitle1 {
    fill: ${t.titleColor};
  }

  .sectionTitle2 {
    fill: ${t.titleColor};
  }

  .sectionTitle3 {
    fill: ${t.titleColor};
  }

  .sectionTitle {
    text-anchor: start;
    font-family: ${t.fontFamily};
  }


  /* Grid and axis */

  .grid .tick {
    stroke: ${t.gridColor};
    opacity: 0.8;
    shape-rendering: crispEdges;
  }

  .grid .tick text {
    font-family: ${t.fontFamily};
    fill: ${t.textColor};
  }

  .grid path {
    stroke-width: 0;
  }


  /* Today line */

  .today {
    fill: none;
    stroke: ${t.todayLineColor};
    stroke-width: 2px;
  }


  /* Task styling */

  /* Default task */

  .task {
    stroke-width: 2;
  }

  .taskText {
    text-anchor: middle;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideRight {
    fill: ${t.taskTextDarkColor};
    text-anchor: start;
    font-family: ${t.fontFamily};
  }

  .taskTextOutsideLeft {
    fill: ${t.taskTextDarkColor};
    text-anchor: end;
  }


  /* Special case clickable */

  .task.clickable {
    cursor: pointer;
  }

  .taskText.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideLeft.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideRight.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }


  /* Specific task settings for the sections*/

  .taskText0,
  .taskText1,
  .taskText2,
  .taskText3 {
    fill: ${t.taskTextColor};
  }

  .task0,
  .task1,
  .task2,
  .task3 {
    fill: ${t.taskBkgColor};
    stroke: ${t.taskBorderColor};
  }

  .taskTextOutside0,
  .taskTextOutside2
  {
    fill: ${t.taskTextOutsideColor};
  }

  .taskTextOutside1,
  .taskTextOutside3 {
    fill: ${t.taskTextOutsideColor};
  }


  /* Active task */

  .active0,
  .active1,
  .active2,
  .active3 {
    fill: ${t.activeTaskBkgColor};
    stroke: ${t.activeTaskBorderColor};
  }

  .activeText0,
  .activeText1,
  .activeText2,
  .activeText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Completed task */

  .done0,
  .done1,
  .done2,
  .done3 {
    stroke: ${t.doneTaskBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
  }

  .doneText0,
  .doneText1,
  .doneText2,
  .doneText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  /* Done task text displayed outside the bar sits against the diagram background,
     not against the done-task bar, so it must use the outside/contrast color. */
  .doneText0.taskTextOutsideLeft,
  .doneText0.taskTextOutsideRight,
  .doneText1.taskTextOutsideLeft,
  .doneText1.taskTextOutsideRight,
  .doneText2.taskTextOutsideLeft,
  .doneText2.taskTextOutsideRight,
  .doneText3.taskTextOutsideLeft,
  .doneText3.taskTextOutsideRight {
    fill: ${t.taskTextOutsideColor} !important;
  }


  /* Tasks on the critical line */

  .crit0,
  .crit1,
  .crit2,
  .crit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.critBkgColor};
    stroke-width: 2;
  }

  .activeCrit0,
  .activeCrit1,
  .activeCrit2,
  .activeCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.activeTaskBkgColor};
    stroke-width: 2;
  }

  .doneCrit0,
  .doneCrit1,
  .doneCrit2,
  .doneCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
    cursor: pointer;
    shape-rendering: crispEdges;
  }

  .milestone {
    transform: rotate(45deg) scale(0.8,0.8);
  }

  .milestoneText {
    font-style: italic;
  }
  .doneCritText0,
  .doneCritText1,
  .doneCritText2,
  .doneCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  /* Done-crit task text outside the bar — same reasoning as doneText above. */
  .doneCritText0.taskTextOutsideLeft,
  .doneCritText0.taskTextOutsideRight,
  .doneCritText1.taskTextOutsideLeft,
  .doneCritText1.taskTextOutsideRight,
  .doneCritText2.taskTextOutsideLeft,
  .doneCritText2.taskTextOutsideRight,
  .doneCritText3.taskTextOutsideLeft,
  .doneCritText3.taskTextOutsideRight {
    fill: ${t.taskTextOutsideColor} !important;
  }

  .vert {
    stroke: ${t.vertLineColor};
  }

  .vertText {
    font-size: 15px;
    text-anchor: middle;
    fill: ${t.vertLineColor} !important;
  }

  .activeCritText0,
  .activeCritText1,
  .activeCritText2,
  .activeCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .titleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${t.titleColor || t.textColor};
    font-family: ${t.fontFamily};
  }
`, "getStyles"), $s = Ws, Rs = {
  parser: Gi,
  db: Us,
  renderer: As,
  styles: $s
};
export {
  Rs as diagram
};
