import { e as U, g as M, r as $, s as j, u as G, i as P, q as S, a as m, B as R, b as H, c as p, d as q, p as N, f as V, m as W, h as Y, j as T, k, l as B, n as J, o as K, t as L, v as z, w as Q, x, y as b, z as X, E as Z, A as ee, C as te, D as re, F as ie, G as ne, H as se, I as ae } from "./runtime-DF09joaA.js";
function oe() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function fe(r) {
  let e = 0, t = j(0), n;
  return () => {
    U() && (M(t), $(() => (e === 0 && (n = G(() => r(() => P(t)))), e += 1, () => {
      S(() => {
        e -= 1, e === 0 && (n?.(), n = void 0, P(t));
      });
    })));
  };
}
var he = Z | ee;
function le(r, e, t, n) {
  new ue(r, e, t, n);
}
class ue {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /**
   * API-level transformError transform function. Transforms errors before they reach the `failed` snippet.
   * Inherited from parent boundary, or defaults to identity.
   * @type {(error: unknown) => unknown}
   */
  transform_error;
  /** @type {TemplateNode} */
  #r;
  /** @type {TemplateNode | null} */
  #m = null;
  /** @type {BoundaryProps} */
  #n;
  /** @type {((anchor: Node) => void)} */
  #h;
  /** @type {Effect} */
  #e;
  /** @type {Effect | null} */
  #s = null;
  /** @type {Effect | null} */
  #t = null;
  /** @type {Effect | null} */
  #i = null;
  /** @type {DocumentFragment | null} */
  #a = null;
  #l = 0;
  #f = 0;
  #u = !1;
  /** @type {Set<Effect>} */
  #_ = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #p = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #o = null;
  #y = fe(() => (this.#o = j(this.#l), () => {
    this.#o = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   * @param {((error: unknown) => unknown) | undefined} [transform_error]
   */
  constructor(e, t, n, o) {
    this.#r = e, this.#n = t, this.#h = (i) => {
      var c = (
        /** @type {Effect} */
        m
      );
      c.b = this, c.f |= R, n(i);
    }, this.parent = /** @type {Effect} */
    m.b, this.transform_error = o ?? this.parent?.transform_error ?? ((i) => i), this.#e = H(() => {
      this.#v();
    }, he);
  }
  #b() {
    try {
      this.#s = p(() => this.#h(this.#r));
    } catch (e) {
      this.error(e);
    }
  }
  /**
   * @param {unknown} error The deserialized error from the server's hydration comment
   */
  #w(e) {
    const t = this.#n.failed;
    t && (this.#i = p(() => {
      t(
        this.#r,
        () => e,
        () => () => {
        }
      );
    }));
  }
  #E() {
    const e = this.#n.pending;
    e && (this.is_pending = !0, this.#t = p(() => e(this.#r)), S(() => {
      var t = this.#a = document.createDocumentFragment(), n = q();
      t.append(n), this.#s = this.#d(() => p(() => this.#h(n))), this.#f === 0 && (this.#r.before(t), this.#a = null, N(
        /** @type {Effect} */
        this.#t,
        () => {
          this.#t = null;
        }
      ), this.#c(
        /** @type {Batch} */
        V
      ));
    }));
  }
  #v() {
    try {
      if (this.is_pending = this.has_pending_snippet(), this.#f = 0, this.#l = 0, this.#s = p(() => {
        this.#h(this.#r);
      }), this.#f > 0) {
        var e = this.#a = document.createDocumentFragment();
        W(this.#s, e);
        const t = (
          /** @type {(anchor: Node) => void} */
          this.#n.pending
        );
        this.#t = p(() => t(this.#r));
      } else
        this.#c(
          /** @type {Batch} */
          V
        );
    } catch (t) {
      this.error(t);
    }
  }
  /**
   * @param {Batch} batch
   */
  #c(e) {
    this.is_pending = !1, e.transfer_effects(this.#_, this.#p);
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(e) {
    Y(e, this.#_, this.#p);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#n.pending;
  }
  /**
   * @template T
   * @param {() => T} fn
   */
  #d(e) {
    var t = m, n = L, o = z;
    T(this.#e), k(this.#e), B(this.#e.ctx);
    try {
      return J.ensure(), e();
    } catch (i) {
      return K(i), null;
    } finally {
      T(t), k(n), B(o);
    }
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  #g(e, t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#g(e, t);
      return;
    }
    this.#f += e, this.#f === 0 && (this.#c(t), this.#t && N(this.#t, () => {
      this.#t = null;
    }), this.#a && (this.#r.before(this.#a), this.#a = null));
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  update_pending_count(e, t) {
    this.#g(e, t), this.#l += e, !(!this.#o || this.#u) && (this.#u = !0, S(() => {
      this.#u = !1, this.#o && Q(this.#o, this.#l);
    }));
  }
  get_effect_pending() {
    return this.#y(), M(
      /** @type {Source<number>} */
      this.#o
    );
  }
  /** @param {unknown} error */
  error(e) {
    var t = this.#n.onerror;
    let n = this.#n.failed;
    if (!t && !n)
      throw e;
    this.#s && (x(this.#s), this.#s = null), this.#t && (x(this.#t), this.#t = null), this.#i && (x(this.#i), this.#i = null);
    var o = !1, i = !1;
    const c = () => {
      if (o) {
        oe();
        return;
      }
      o = !0, i && X(), this.#i !== null && N(this.#i, () => {
        this.#i = null;
      }), this.#d(() => {
        this.#v();
      });
    }, _ = (s) => {
      try {
        i = !0, t?.(s, c), i = !1;
      } catch (a) {
        b(a, this.#e && this.#e.parent);
      }
      n && (this.#i = this.#d(() => {
        try {
          return p(() => {
            var a = (
              /** @type {Effect} */
              m
            );
            a.b = this, a.f |= R, n(
              this.#r,
              () => s,
              () => c
            );
          });
        } catch (a) {
          return b(
            a,
            /** @type {Effect} */
            this.#e.parent
          ), null;
        }
      }));
    };
    S(() => {
      var s;
      try {
        s = this.transform_error(e);
      } catch (a) {
        b(a, this.#e && this.#e.parent);
        return;
      }
      s !== null && typeof s == "object" && typeof /** @type {any} */
      s.then == "function" ? s.then(
        _,
        /** @param {unknown} e */
        (a) => b(a, this.#e && this.#e.parent)
      ) : _(s);
    });
  }
}
const ce = ["touchstart", "touchmove"];
function de(r) {
  return ce.includes(r);
}
const w = /* @__PURE__ */ Symbol("events"), _e = /* @__PURE__ */ new Set(), D = /* @__PURE__ */ new Set();
let A = null;
function I(r) {
  var e = this, t = (
    /** @type {Node} */
    e.ownerDocument
  ), n = r.type, o = r.composedPath?.() || [], i = (
    /** @type {null | Element} */
    o[0] || r.target
  );
  A = r;
  var c = 0, _ = A === r && r[w];
  if (_) {
    var s = o.indexOf(_);
    if (s !== -1 && (e === document || e === /** @type {any} */
    window)) {
      r[w] = e;
      return;
    }
    var a = o.indexOf(e);
    if (a === -1)
      return;
    s <= a && (c = s);
  }
  if (i = /** @type {Element} */
  o[c] || r.target, i !== e) {
    te(r, "currentTarget", {
      configurable: !0,
      get() {
        return i || t;
      }
    });
    var v = L, y = m;
    k(null), T(null);
    try {
      for (var d, l = []; i !== null; ) {
        var f = i.assignedSlot || i.parentNode || /** @type {any} */
        i.host || null;
        try {
          var h = i[w]?.[n];
          h != null && (!/** @type {any} */
          i.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          r.target === i) && h.call(i, r);
        } catch (u) {
          d ? l.push(u) : d = u;
        }
        if (r.cancelBubble || f === e || f === null)
          break;
        i = f;
      }
      if (d) {
        for (let u of l)
          queueMicrotask(() => {
            throw u;
          });
        throw d;
      }
    } finally {
      r[w] = e, delete r.currentTarget, k(v), T(y);
    }
  }
}
function ye(r, e) {
  return pe(r, e);
}
const E = /* @__PURE__ */ new Map();
function pe(r, { target: e, anchor: t, props: n = {}, events: o, context: i, intro: c = !0, transformError: _ }) {
  re();
  var s = void 0, a = ie(() => {
    var v = t ?? e.appendChild(q());
    le(
      /** @type {TemplateNode} */
      v,
      {
        pending: () => {
        }
      },
      (l) => {
        se({});
        var f = (
          /** @type {ComponentContext} */
          z
        );
        i && (f.c = i), o && (n.$$events = o), s = r(l, n) || {}, ae();
      },
      _
    );
    var y = /* @__PURE__ */ new Set(), d = (l) => {
      for (var f = 0; f < l.length; f++) {
        var h = l[f];
        if (!y.has(h)) {
          y.add(h);
          var u = de(h);
          for (const F of [e, document]) {
            var g = E.get(F);
            g === void 0 && (g = /* @__PURE__ */ new Map(), E.set(F, g));
            var O = g.get(h);
            O === void 0 ? (F.addEventListener(h, I, { passive: u }), g.set(h, 1)) : g.set(h, O + 1);
          }
        }
      }
    };
    return d(ne(_e)), D.add(d), () => {
      for (var l of y)
        for (const u of [e, document]) {
          var f = (
            /** @type {Map<string, number>} */
            E.get(u)
          ), h = (
            /** @type {number} */
            f.get(l)
          );
          --h == 0 ? (u.removeEventListener(l, I), f.delete(l), f.size === 0 && E.delete(u)) : f.set(l, h);
        }
      D.delete(d), v !== t && v.parentNode?.removeChild(v);
    };
  });
  return C.set(s, a), s;
}
let C = /* @__PURE__ */ new WeakMap();
function me(r, e) {
  const t = C.get(r);
  return t ? (C.delete(r), t(e)) : Promise.resolve();
}
const ve = "5";
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add(ve);
const be = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
export {
  be as SVELTE_VERSION,
  ye as mount,
  me as unmount
};
