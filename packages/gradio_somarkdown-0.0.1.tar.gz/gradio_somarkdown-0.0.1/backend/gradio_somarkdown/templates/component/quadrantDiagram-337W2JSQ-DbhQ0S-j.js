import { s as _e, g as Ae, q as ie, p as ke, a as Fe, b as Pe, _ as o, c as zt, l as bt, d as Lt, e as ve, z as Ce, F as D, i as Le, K as Ee } from "./mermaid.core-DfOz2mRZ.js";
import { l as ee } from "./linear-C6o3ECe4.js";
var Et = (function() {
  var t = /* @__PURE__ */ o(function(M, r, l, x) {
    for (l = l || {}, x = M.length; x--; l[M[x]] = r) ;
    return l;
  }, "o"), n = [1, 3], f = [1, 4], d = [1, 5], h = [1, 6], p = [1, 7], y = [1, 4, 5, 10, 12, 13, 14, 18, 25, 35, 37, 39, 41, 42, 48, 50, 51, 52, 53, 54, 55, 56, 57, 60, 61, 63, 64, 65, 66, 67], _ = [1, 4, 5, 10, 12, 13, 14, 18, 25, 28, 35, 37, 39, 41, 42, 48, 50, 51, 52, 53, 54, 55, 56, 57, 60, 61, 63, 64, 65, 66, 67], a = [55, 56, 57], A = [2, 36], u = [1, 37], T = [1, 36], q = [1, 38], m = [1, 35], b = [1, 43], g = [1, 41], G = [1, 14], ht = [1, 23], xt = [1, 18], ft = [1, 19], gt = [1, 20], ct = [1, 21], _t = [1, 22], dt = [1, 24], i = [1, 25], Vt = [1, 26], It = [1, 27], wt = [1, 28], Bt = [1, 29], W = [1, 32], U = [1, 33], k = [1, 34], F = [1, 39], P = [1, 40], v = [1, 42], C = [1, 44], O = [1, 62], H = [1, 61], L = [4, 5, 8, 10, 12, 13, 14, 18, 44, 47, 49, 55, 56, 57, 63, 64, 65, 66, 67], Rt = [1, 65], Nt = [1, 66], Wt = [1, 67], Ut = [1, 68], Qt = [1, 69], Ot = [1, 70], Ht = [1, 71], Xt = [1, 72], Mt = [1, 73], Yt = [1, 74], jt = [1, 75], Gt = [1, 76], I = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 18], K = [1, 90], Z = [1, 91], J = [1, 92], $ = [1, 99], tt = [1, 93], et = [1, 96], it = [1, 94], at = [1, 95], nt = [1, 97], st = [1, 98], At = [1, 102], Kt = [10, 55, 56, 57], R = [4, 5, 6, 8, 10, 11, 13, 17, 18, 19, 20, 55, 56, 57], kt = {
    trace: /* @__PURE__ */ o(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, idStringToken: 3, ALPHA: 4, NUM: 5, NODE_STRING: 6, DOWN: 7, MINUS: 8, DEFAULT: 9, COMMA: 10, COLON: 11, AMP: 12, BRKT: 13, MULT: 14, UNICODE_TEXT: 15, styleComponent: 16, UNIT: 17, SPACE: 18, STYLE: 19, PCT: 20, idString: 21, style: 22, stylesOpt: 23, classDefStatement: 24, CLASSDEF: 25, start: 26, eol: 27, QUADRANT: 28, document: 29, line: 30, statement: 31, axisDetails: 32, quadrantDetails: 33, points: 34, title: 35, title_value: 36, acc_title: 37, acc_title_value: 38, acc_descr: 39, acc_descr_value: 40, acc_descr_multiline_value: 41, section: 42, text: 43, point_start: 44, point_x: 45, point_y: 46, class_name: 47, "X-AXIS": 48, "AXIS-TEXT-DELIMITER": 49, "Y-AXIS": 50, QUADRANT_1: 51, QUADRANT_2: 52, QUADRANT_3: 53, QUADRANT_4: 54, NEWLINE: 55, SEMI: 56, EOF: 57, alphaNumToken: 58, textNoTagsToken: 59, STR: 60, MD_STR: 61, alphaNum: 62, PUNCTUATION: 63, PLUS: 64, EQUALS: 65, DOT: 66, UNDERSCORE: 67, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "ALPHA", 5: "NUM", 6: "NODE_STRING", 7: "DOWN", 8: "MINUS", 9: "DEFAULT", 10: "COMMA", 11: "COLON", 12: "AMP", 13: "BRKT", 14: "MULT", 15: "UNICODE_TEXT", 17: "UNIT", 18: "SPACE", 19: "STYLE", 20: "PCT", 25: "CLASSDEF", 28: "QUADRANT", 35: "title", 36: "title_value", 37: "acc_title", 38: "acc_title_value", 39: "acc_descr", 40: "acc_descr_value", 41: "acc_descr_multiline_value", 42: "section", 44: "point_start", 45: "point_x", 46: "point_y", 47: "class_name", 48: "X-AXIS", 49: "AXIS-TEXT-DELIMITER", 50: "Y-AXIS", 51: "QUADRANT_1", 52: "QUADRANT_2", 53: "QUADRANT_3", 54: "QUADRANT_4", 55: "NEWLINE", 56: "SEMI", 57: "EOF", 60: "STR", 61: "MD_STR", 63: "PUNCTUATION", 64: "PLUS", 65: "EQUALS", 66: "DOT", 67: "UNDERSCORE" },
    productions_: [0, [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [21, 1], [21, 2], [22, 1], [22, 2], [23, 1], [23, 3], [24, 5], [26, 2], [26, 2], [26, 2], [29, 0], [29, 2], [30, 2], [31, 0], [31, 1], [31, 2], [31, 1], [31, 1], [31, 1], [31, 2], [31, 2], [31, 2], [31, 1], [31, 1], [34, 4], [34, 5], [34, 5], [34, 6], [32, 4], [32, 3], [32, 2], [32, 4], [32, 3], [32, 2], [33, 2], [33, 2], [33, 2], [33, 2], [27, 1], [27, 1], [27, 1], [43, 1], [43, 2], [43, 1], [43, 1], [62, 1], [62, 2], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [59, 1], [59, 1], [59, 1]],
    performAction: /* @__PURE__ */ o(function(r, l, x, c, S, e, ut) {
      var s = e.length - 1;
      switch (S) {
        case 23:
          this.$ = e[s];
          break;
        case 24:
          this.$ = e[s - 1] + "" + e[s];
          break;
        case 26:
          this.$ = e[s - 1] + e[s];
          break;
        case 27:
          this.$ = [e[s].trim()];
          break;
        case 28:
          e[s - 2].push(e[s].trim()), this.$ = e[s - 2];
          break;
        case 29:
          this.$ = e[s - 4], c.addClass(e[s - 2], e[s]);
          break;
        case 37:
          this.$ = [];
          break;
        case 42:
          this.$ = e[s].trim(), c.setDiagramTitle(this.$);
          break;
        case 43:
          this.$ = e[s].trim(), c.setAccTitle(this.$);
          break;
        case 44:
        case 45:
          this.$ = e[s].trim(), c.setAccDescription(this.$);
          break;
        case 46:
          c.addSection(e[s].substr(8)), this.$ = e[s].substr(8);
          break;
        case 47:
          c.addPoint(e[s - 3], "", e[s - 1], e[s], []);
          break;
        case 48:
          c.addPoint(e[s - 4], e[s - 3], e[s - 1], e[s], []);
          break;
        case 49:
          c.addPoint(e[s - 4], "", e[s - 2], e[s - 1], e[s]);
          break;
        case 50:
          c.addPoint(e[s - 5], e[s - 4], e[s - 2], e[s - 1], e[s]);
          break;
        case 51:
          c.setXAxisLeftText(e[s - 2]), c.setXAxisRightText(e[s]);
          break;
        case 52:
          e[s - 1].text += " ⟶ ", c.setXAxisLeftText(e[s - 1]);
          break;
        case 53:
          c.setXAxisLeftText(e[s]);
          break;
        case 54:
          c.setYAxisBottomText(e[s - 2]), c.setYAxisTopText(e[s]);
          break;
        case 55:
          e[s - 1].text += " ⟶ ", c.setYAxisBottomText(e[s - 1]);
          break;
        case 56:
          c.setYAxisBottomText(e[s]);
          break;
        case 57:
          c.setQuadrant1Text(e[s]);
          break;
        case 58:
          c.setQuadrant2Text(e[s]);
          break;
        case 59:
          c.setQuadrant3Text(e[s]);
          break;
        case 60:
          c.setQuadrant4Text(e[s]);
          break;
        case 64:
          this.$ = { text: e[s], type: "text" };
          break;
        case 65:
          this.$ = { text: e[s - 1].text + "" + e[s], type: e[s - 1].type };
          break;
        case 66:
          this.$ = { text: e[s], type: "text" };
          break;
        case 67:
          this.$ = { text: e[s], type: "markdown" };
          break;
        case 68:
          this.$ = e[s];
          break;
        case 69:
          this.$ = e[s - 1] + "" + e[s];
          break;
      }
    }, "anonymous"),
    table: [{ 18: n, 26: 1, 27: 2, 28: f, 55: d, 56: h, 57: p }, { 1: [3] }, { 18: n, 26: 8, 27: 2, 28: f, 55: d, 56: h, 57: p }, { 18: n, 26: 9, 27: 2, 28: f, 55: d, 56: h, 57: p }, t(y, [2, 33], { 29: 10 }), t(_, [2, 61]), t(_, [2, 62]), t(_, [2, 63]), { 1: [2, 30] }, { 1: [2, 31] }, t(a, A, { 30: 11, 31: 12, 24: 13, 32: 15, 33: 16, 34: 17, 43: 30, 58: 31, 1: [2, 32], 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 18: G, 25: ht, 35: xt, 37: ft, 39: gt, 41: ct, 42: _t, 48: dt, 50: i, 51: Vt, 52: It, 53: wt, 54: Bt, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }), t(y, [2, 34]), { 27: 45, 55: d, 56: h, 57: p }, t(a, [2, 37]), t(a, A, { 24: 13, 32: 15, 33: 16, 34: 17, 43: 30, 58: 31, 31: 46, 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 18: G, 25: ht, 35: xt, 37: ft, 39: gt, 41: ct, 42: _t, 48: dt, 50: i, 51: Vt, 52: It, 53: wt, 54: Bt, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 39]), t(a, [2, 40]), t(a, [2, 41]), { 36: [1, 47] }, { 38: [1, 48] }, { 40: [1, 49] }, t(a, [2, 45]), t(a, [2, 46]), { 18: [1, 50] }, { 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 43: 51, 58: 31, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }, { 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 43: 52, 58: 31, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }, { 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 43: 53, 58: 31, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }, { 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 43: 54, 58: 31, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }, { 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 43: 55, 58: 31, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }, { 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 43: 56, 58: 31, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }, { 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 44: [1, 57], 47: [1, 58], 58: 60, 59: 59, 63: k, 64: F, 65: P, 66: v, 67: C }, t(L, [2, 64]), t(L, [2, 66]), t(L, [2, 67]), t(L, [2, 70]), t(L, [2, 71]), t(L, [2, 72]), t(L, [2, 73]), t(L, [2, 74]), t(L, [2, 75]), t(L, [2, 76]), t(L, [2, 77]), t(L, [2, 78]), t(L, [2, 79]), t(L, [2, 80]), t(y, [2, 35]), t(a, [2, 38]), t(a, [2, 42]), t(a, [2, 43]), t(a, [2, 44]), { 3: 64, 4: Rt, 5: Nt, 6: Wt, 7: Ut, 8: Qt, 9: Ot, 10: Ht, 11: Xt, 12: Mt, 13: Yt, 14: jt, 15: Gt, 21: 63 }, t(a, [2, 53], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 49: [1, 77], 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 56], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 49: [1, 78], 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 57], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 58], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 59], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 60], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 63: k, 64: F, 65: P, 66: v, 67: C }), { 45: [1, 79] }, { 44: [1, 80] }, t(L, [2, 65]), t(L, [2, 81]), t(L, [2, 82]), t(L, [2, 83]), { 3: 82, 4: Rt, 5: Nt, 6: Wt, 7: Ut, 8: Qt, 9: Ot, 10: Ht, 11: Xt, 12: Mt, 13: Yt, 14: jt, 15: Gt, 18: [1, 81] }, t(I, [2, 23]), t(I, [2, 1]), t(I, [2, 2]), t(I, [2, 3]), t(I, [2, 4]), t(I, [2, 5]), t(I, [2, 6]), t(I, [2, 7]), t(I, [2, 8]), t(I, [2, 9]), t(I, [2, 10]), t(I, [2, 11]), t(I, [2, 12]), t(a, [2, 52], { 58: 31, 43: 83, 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 55], { 58: 31, 43: 84, 4: u, 5: T, 10: q, 12: m, 13: b, 14: g, 60: W, 61: U, 63: k, 64: F, 65: P, 66: v, 67: C }), { 46: [1, 85] }, { 45: [1, 86] }, { 4: K, 5: Z, 6: J, 8: $, 11: tt, 13: et, 16: 89, 17: it, 18: at, 19: nt, 20: st, 22: 88, 23: 87 }, t(I, [2, 24]), t(a, [2, 51], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 54], { 59: 59, 58: 60, 4: u, 5: T, 8: O, 10: q, 12: m, 13: b, 14: g, 18: H, 63: k, 64: F, 65: P, 66: v, 67: C }), t(a, [2, 47], { 22: 88, 16: 89, 23: 100, 4: K, 5: Z, 6: J, 8: $, 11: tt, 13: et, 17: it, 18: at, 19: nt, 20: st }), { 46: [1, 101] }, t(a, [2, 29], { 10: At }), t(Kt, [2, 27], { 16: 103, 4: K, 5: Z, 6: J, 8: $, 11: tt, 13: et, 17: it, 18: at, 19: nt, 20: st }), t(R, [2, 25]), t(R, [2, 13]), t(R, [2, 14]), t(R, [2, 15]), t(R, [2, 16]), t(R, [2, 17]), t(R, [2, 18]), t(R, [2, 19]), t(R, [2, 20]), t(R, [2, 21]), t(R, [2, 22]), t(a, [2, 49], { 10: At }), t(a, [2, 48], { 22: 88, 16: 89, 23: 104, 4: K, 5: Z, 6: J, 8: $, 11: tt, 13: et, 17: it, 18: at, 19: nt, 20: st }), { 4: K, 5: Z, 6: J, 8: $, 11: tt, 13: et, 16: 89, 17: it, 18: at, 19: nt, 20: st, 22: 105 }, t(R, [2, 26]), t(a, [2, 50], { 10: At }), t(Kt, [2, 28], { 16: 103, 4: K, 5: Z, 6: J, 8: $, 11: tt, 13: et, 17: it, 18: at, 19: nt, 20: st })],
    defaultActions: { 8: [2, 30], 9: [2, 31] },
    parseError: /* @__PURE__ */ o(function(r, l) {
      if (l.recoverable)
        this.trace(r);
      else {
        var x = new Error(r);
        throw x.hash = l, x;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ o(function(r) {
      var l = this, x = [0], c = [], S = [null], e = [], ut = this.table, s = "", yt = 0, Zt = 0, qe = 2, Jt = 1, me = e.slice.call(arguments, 1), E = Object.create(this.lexer), Y = { yy: {} };
      for (var Ft in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, Ft) && (Y.yy[Ft] = this.yy[Ft]);
      E.setInput(r, Y.yy), Y.yy.lexer = E, Y.yy.parser = this, typeof E.yylloc > "u" && (E.yylloc = {});
      var Pt = E.yylloc;
      e.push(Pt);
      var be = E.options && E.options.ranges;
      typeof Y.yy.parseError == "function" ? this.parseError = Y.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function Se(B) {
        x.length = x.length - 2 * B, S.length = S.length - B, e.length = e.length - B;
      }
      o(Se, "popStack");
      function $t() {
        var B;
        return B = c.pop() || E.lex() || Jt, typeof B != "number" && (B instanceof Array && (c = B, B = c.pop()), B = l.symbols_[B] || B), B;
      }
      o($t, "lex");
      for (var w, j, N, vt, rt = {}, Tt, X, te, qt; ; ) {
        if (j = x[x.length - 1], this.defaultActions[j] ? N = this.defaultActions[j] : ((w === null || typeof w > "u") && (w = $t()), N = ut[j] && ut[j][w]), typeof N > "u" || !N.length || !N[0]) {
          var Ct = "";
          qt = [];
          for (Tt in ut[j])
            this.terminals_[Tt] && Tt > qe && qt.push("'" + this.terminals_[Tt] + "'");
          E.showPosition ? Ct = "Parse error on line " + (yt + 1) + `:
` + E.showPosition() + `
Expecting ` + qt.join(", ") + ", got '" + (this.terminals_[w] || w) + "'" : Ct = "Parse error on line " + (yt + 1) + ": Unexpected " + (w == Jt ? "end of input" : "'" + (this.terminals_[w] || w) + "'"), this.parseError(Ct, {
            text: E.match,
            token: this.terminals_[w] || w,
            line: E.yylineno,
            loc: Pt,
            expected: qt
          });
        }
        if (N[0] instanceof Array && N.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + j + ", token: " + w);
        switch (N[0]) {
          case 1:
            x.push(w), S.push(E.yytext), e.push(E.yylloc), x.push(N[1]), w = null, Zt = E.yyleng, s = E.yytext, yt = E.yylineno, Pt = E.yylloc;
            break;
          case 2:
            if (X = this.productions_[N[1]][1], rt.$ = S[S.length - X], rt._$ = {
              first_line: e[e.length - (X || 1)].first_line,
              last_line: e[e.length - 1].last_line,
              first_column: e[e.length - (X || 1)].first_column,
              last_column: e[e.length - 1].last_column
            }, be && (rt._$.range = [
              e[e.length - (X || 1)].range[0],
              e[e.length - 1].range[1]
            ]), vt = this.performAction.apply(rt, [
              s,
              Zt,
              yt,
              Y.yy,
              N[1],
              S,
              e
            ].concat(me)), typeof vt < "u")
              return vt;
            X && (x = x.slice(0, -1 * X * 2), S = S.slice(0, -1 * X), e = e.slice(0, -1 * X)), x.push(this.productions_[N[1]][0]), S.push(rt.$), e.push(rt._$), te = ut[x[x.length - 2]][x[x.length - 1]], x.push(te);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, Te = /* @__PURE__ */ (function() {
    var M = {
      EOF: 1,
      parseError: /* @__PURE__ */ o(function(l, x) {
        if (this.yy.parser)
          this.yy.parser.parseError(l, x);
        else
          throw new Error(l);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ o(function(r, l) {
        return this.yy = l || this.yy || {}, this._input = r, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ o(function() {
        var r = this._input[0];
        this.yytext += r, this.yyleng++, this.offset++, this.match += r, this.matched += r;
        var l = r.match(/(?:\r\n?|\n).*/g);
        return l ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), r;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ o(function(r) {
        var l = r.length, x = r.split(/(?:\r\n?|\n)/g);
        this._input = r + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - l), this.offset -= l;
        var c = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), x.length - 1 && (this.yylineno -= x.length - 1);
        var S = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: x ? (x.length === c.length ? this.yylloc.first_column : 0) + c[c.length - x.length].length - x[0].length : this.yylloc.first_column - l
        }, this.options.ranges && (this.yylloc.range = [S[0], S[0] + this.yyleng - l]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ o(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ o(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ o(function(r) {
        this.unput(this.match.slice(r));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ o(function() {
        var r = this.matched.substr(0, this.matched.length - this.match.length);
        return (r.length > 20 ? "..." : "") + r.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ o(function() {
        var r = this.match;
        return r.length < 20 && (r += this._input.substr(0, 20 - r.length)), (r.substr(0, 20) + (r.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ o(function() {
        var r = this.pastInput(), l = new Array(r.length + 1).join("-");
        return r + this.upcomingInput() + `
` + l + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ o(function(r, l) {
        var x, c, S;
        if (this.options.backtrack_lexer && (S = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (S.yylloc.range = this.yylloc.range.slice(0))), c = r[0].match(/(?:\r\n?|\n).*/g), c && (this.yylineno += c.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: c ? c[c.length - 1].length - c[c.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + r[0].length
        }, this.yytext += r[0], this.match += r[0], this.matches = r, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(r[0].length), this.matched += r[0], x = this.performAction.call(this, this.yy, this, l, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), x)
          return x;
        if (this._backtrack) {
          for (var e in S)
            this[e] = S[e];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ o(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var r, l, x, c;
        this._more || (this.yytext = "", this.match = "");
        for (var S = this._currentRules(), e = 0; e < S.length; e++)
          if (x = this._input.match(this.rules[S[e]]), x && (!l || x[0].length > l[0].length)) {
            if (l = x, c = e, this.options.backtrack_lexer) {
              if (r = this.test_match(x, S[e]), r !== !1)
                return r;
              if (this._backtrack) {
                l = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return l ? (r = this.test_match(l, S[c]), r !== !1 ? r : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ o(function() {
        var l = this.next();
        return l || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ o(function(l) {
        this.conditionStack.push(l);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ o(function() {
        var l = this.conditionStack.length - 1;
        return l > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ o(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ o(function(l) {
        return l = this.conditionStack.length - 1 - Math.abs(l || 0), l >= 0 ? this.conditionStack[l] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ o(function(l) {
        this.begin(l);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ o(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ o(function(l, x, c, S) {
        switch (c) {
          case 0:
            break;
          case 1:
            break;
          case 2:
            return 55;
          case 3:
            break;
          case 4:
            return this.begin("title"), 35;
          case 5:
            return this.popState(), "title_value";
          case 6:
            return this.begin("acc_title"), 37;
          case 7:
            return this.popState(), "acc_title_value";
          case 8:
            return this.begin("acc_descr"), 39;
          case 9:
            return this.popState(), "acc_descr_value";
          case 10:
            this.begin("acc_descr_multiline");
            break;
          case 11:
            this.popState();
            break;
          case 12:
            return "acc_descr_multiline_value";
          case 13:
            return 48;
          case 14:
            return 50;
          case 15:
            return 49;
          case 16:
            return 51;
          case 17:
            return 52;
          case 18:
            return 53;
          case 19:
            return 54;
          case 20:
            return 25;
          case 21:
            this.begin("md_string");
            break;
          case 22:
            return "MD_STR";
          case 23:
            this.popState();
            break;
          case 24:
            this.begin("string");
            break;
          case 25:
            this.popState();
            break;
          case 26:
            return "STR";
          case 27:
            this.begin("class_name");
            break;
          case 28:
            return this.popState(), 47;
          case 29:
            return this.begin("point_start"), 44;
          case 30:
            return this.begin("point_x"), 45;
          case 31:
            this.popState();
            break;
          case 32:
            this.popState(), this.begin("point_y");
            break;
          case 33:
            return this.popState(), 46;
          case 34:
            return 28;
          case 35:
            return 4;
          case 36:
            return 11;
          case 37:
            return 64;
          case 38:
            return 10;
          case 39:
            return 65;
          case 40:
            return 65;
          case 41:
            return 14;
          case 42:
            return 13;
          case 43:
            return 67;
          case 44:
            return 66;
          case 45:
            return 12;
          case 46:
            return 8;
          case 47:
            return 5;
          case 48:
            return 18;
          case 49:
            return 56;
          case 50:
            return 63;
          case 51:
            return 57;
        }
      }, "anonymous"),
      rules: [/^(?:%%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[\n\r]+)/i, /^(?:%%[^\n]*)/i, /^(?:title\b)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?: *x-axis *)/i, /^(?: *y-axis *)/i, /^(?: *--+> *)/i, /^(?: *quadrant-1 *)/i, /^(?: *quadrant-2 *)/i, /^(?: *quadrant-3 *)/i, /^(?: *quadrant-4 *)/i, /^(?:classDef\b)/i, /^(?:["][`])/i, /^(?:[^`"]+)/i, /^(?:[`]["])/i, /^(?:["])/i, /^(?:["])/i, /^(?:[^"]*)/i, /^(?::::)/i, /^(?:^\w+)/i, /^(?:\s*:\s*\[\s*)/i, /^(?:(1)|(0(.\d+)?))/i, /^(?:\s*\] *)/i, /^(?:\s*,\s*)/i, /^(?:(1)|(0(.\d+)?))/i, /^(?: *quadrantChart *)/i, /^(?:[A-Za-z]+)/i, /^(?::)/i, /^(?:\+)/i, /^(?:,)/i, /^(?:=)/i, /^(?:=)/i, /^(?:\*)/i, /^(?:#)/i, /^(?:[\_])/i, /^(?:\.)/i, /^(?:&)/i, /^(?:-)/i, /^(?:[0-9]+)/i, /^(?:\s)/i, /^(?:;)/i, /^(?:[!"#$%&'*+,-.`?\\_/])/i, /^(?:$)/i],
      conditions: { class_name: { rules: [28], inclusive: !1 }, point_y: { rules: [33], inclusive: !1 }, point_x: { rules: [32], inclusive: !1 }, point_start: { rules: [30, 31], inclusive: !1 }, acc_descr_multiline: { rules: [11, 12], inclusive: !1 }, acc_descr: { rules: [9], inclusive: !1 }, acc_title: { rules: [7], inclusive: !1 }, title: { rules: [5], inclusive: !1 }, md_string: { rules: [22, 23], inclusive: !1 }, string: { rules: [25, 26], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 6, 8, 10, 13, 14, 15, 16, 17, 18, 19, 20, 21, 24, 27, 29, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51], inclusive: !0 } }
    };
    return M;
  })();
  kt.lexer = Te;
  function pt() {
    this.yy = {};
  }
  return o(pt, "Parser"), pt.prototype = kt, kt.Parser = pt, new pt();
})();
Et.parser = Et;
var De = Et, V = Ee(), ot, ze = (ot = class {
  constructor() {
    this.classes = /* @__PURE__ */ new Map(), this.config = this.getDefaultConfig(), this.themeConfig = this.getDefaultThemeConfig(), this.data = this.getDefaultData();
  }
  getDefaultData() {
    return {
      titleText: "",
      quadrant1Text: "",
      quadrant2Text: "",
      quadrant3Text: "",
      quadrant4Text: "",
      xAxisLeftText: "",
      xAxisRightText: "",
      yAxisBottomText: "",
      yAxisTopText: "",
      points: []
    };
  }
  getDefaultConfig() {
    return {
      showXAxis: !0,
      showYAxis: !0,
      showTitle: !0,
      chartHeight: D.quadrantChart?.chartWidth || 500,
      chartWidth: D.quadrantChart?.chartHeight || 500,
      titlePadding: D.quadrantChart?.titlePadding || 10,
      titleFontSize: D.quadrantChart?.titleFontSize || 20,
      quadrantPadding: D.quadrantChart?.quadrantPadding || 5,
      xAxisLabelPadding: D.quadrantChart?.xAxisLabelPadding || 5,
      yAxisLabelPadding: D.quadrantChart?.yAxisLabelPadding || 5,
      xAxisLabelFontSize: D.quadrantChart?.xAxisLabelFontSize || 16,
      yAxisLabelFontSize: D.quadrantChart?.yAxisLabelFontSize || 16,
      quadrantLabelFontSize: D.quadrantChart?.quadrantLabelFontSize || 16,
      quadrantTextTopPadding: D.quadrantChart?.quadrantTextTopPadding || 5,
      pointTextPadding: D.quadrantChart?.pointTextPadding || 5,
      pointLabelFontSize: D.quadrantChart?.pointLabelFontSize || 12,
      pointRadius: D.quadrantChart?.pointRadius || 5,
      xAxisPosition: D.quadrantChart?.xAxisPosition || "top",
      yAxisPosition: D.quadrantChart?.yAxisPosition || "left",
      quadrantInternalBorderStrokeWidth: D.quadrantChart?.quadrantInternalBorderStrokeWidth || 1,
      quadrantExternalBorderStrokeWidth: D.quadrantChart?.quadrantExternalBorderStrokeWidth || 2
    };
  }
  getDefaultThemeConfig() {
    return {
      quadrant1Fill: V.quadrant1Fill,
      quadrant2Fill: V.quadrant2Fill,
      quadrant3Fill: V.quadrant3Fill,
      quadrant4Fill: V.quadrant4Fill,
      quadrant1TextFill: V.quadrant1TextFill,
      quadrant2TextFill: V.quadrant2TextFill,
      quadrant3TextFill: V.quadrant3TextFill,
      quadrant4TextFill: V.quadrant4TextFill,
      quadrantPointFill: V.quadrantPointFill,
      quadrantPointTextFill: V.quadrantPointTextFill,
      quadrantXAxisTextFill: V.quadrantXAxisTextFill,
      quadrantYAxisTextFill: V.quadrantYAxisTextFill,
      quadrantTitleFill: V.quadrantTitleFill,
      quadrantInternalBorderStrokeFill: V.quadrantInternalBorderStrokeFill,
      quadrantExternalBorderStrokeFill: V.quadrantExternalBorderStrokeFill
    };
  }
  clear() {
    this.config = this.getDefaultConfig(), this.themeConfig = this.getDefaultThemeConfig(), this.data = this.getDefaultData(), this.classes = /* @__PURE__ */ new Map(), bt.info("clear called");
  }
  setData(n) {
    this.data = { ...this.data, ...n };
  }
  addPoints(n) {
    this.data.points = [...n, ...this.data.points];
  }
  addClass(n, f) {
    this.classes.set(n, f);
  }
  setConfig(n) {
    bt.trace("setConfig called with: ", n), this.config = { ...this.config, ...n };
  }
  setThemeConfig(n) {
    bt.trace("setThemeConfig called with: ", n), this.themeConfig = { ...this.themeConfig, ...n };
  }
  calculateSpace(n, f, d, h) {
    const p = this.config.xAxisLabelPadding * 2 + this.config.xAxisLabelFontSize, y = {
      top: n === "top" && f ? p : 0,
      bottom: n === "bottom" && f ? p : 0
    }, _ = this.config.yAxisLabelPadding * 2 + this.config.yAxisLabelFontSize, a = {
      left: this.config.yAxisPosition === "left" && d ? _ : 0,
      right: this.config.yAxisPosition === "right" && d ? _ : 0
    }, A = this.config.titleFontSize + this.config.titlePadding * 2, u = {
      top: h ? A : 0
    }, T = this.config.quadrantPadding + a.left, q = this.config.quadrantPadding + y.top + u.top, m = this.config.chartWidth - this.config.quadrantPadding * 2 - a.left - a.right, b = this.config.chartHeight - this.config.quadrantPadding * 2 - y.top - y.bottom - u.top, g = m / 2, G = b / 2;
    return {
      xAxisSpace: y,
      yAxisSpace: a,
      titleSpace: u,
      quadrantSpace: {
        quadrantLeft: T,
        quadrantTop: q,
        quadrantWidth: m,
        quadrantHalfWidth: g,
        quadrantHeight: b,
        quadrantHalfHeight: G
      }
    };
  }
  getAxisLabels(n, f, d, h) {
    const { quadrantSpace: p, titleSpace: y } = h, {
      quadrantHalfHeight: _,
      quadrantHeight: a,
      quadrantLeft: A,
      quadrantHalfWidth: u,
      quadrantTop: T,
      quadrantWidth: q
    } = p, m = !!this.data.xAxisRightText, b = !!this.data.yAxisTopText, g = [];
    return this.data.xAxisLeftText && f && g.push({
      text: this.data.xAxisLeftText,
      fill: this.themeConfig.quadrantXAxisTextFill,
      x: A + (m ? u / 2 : 0),
      y: n === "top" ? this.config.xAxisLabelPadding + y.top : this.config.xAxisLabelPadding + T + a + this.config.quadrantPadding,
      fontSize: this.config.xAxisLabelFontSize,
      verticalPos: m ? "center" : "left",
      horizontalPos: "top",
      rotation: 0
    }), this.data.xAxisRightText && f && g.push({
      text: this.data.xAxisRightText,
      fill: this.themeConfig.quadrantXAxisTextFill,
      x: A + u + (m ? u / 2 : 0),
      y: n === "top" ? this.config.xAxisLabelPadding + y.top : this.config.xAxisLabelPadding + T + a + this.config.quadrantPadding,
      fontSize: this.config.xAxisLabelFontSize,
      verticalPos: m ? "center" : "left",
      horizontalPos: "top",
      rotation: 0
    }), this.data.yAxisBottomText && d && g.push({
      text: this.data.yAxisBottomText,
      fill: this.themeConfig.quadrantYAxisTextFill,
      x: this.config.yAxisPosition === "left" ? this.config.yAxisLabelPadding : this.config.yAxisLabelPadding + A + q + this.config.quadrantPadding,
      y: T + a - (b ? _ / 2 : 0),
      fontSize: this.config.yAxisLabelFontSize,
      verticalPos: b ? "center" : "left",
      horizontalPos: "top",
      rotation: -90
    }), this.data.yAxisTopText && d && g.push({
      text: this.data.yAxisTopText,
      fill: this.themeConfig.quadrantYAxisTextFill,
      x: this.config.yAxisPosition === "left" ? this.config.yAxisLabelPadding : this.config.yAxisLabelPadding + A + q + this.config.quadrantPadding,
      y: T + _ - (b ? _ / 2 : 0),
      fontSize: this.config.yAxisLabelFontSize,
      verticalPos: b ? "center" : "left",
      horizontalPos: "top",
      rotation: -90
    }), g;
  }
  getQuadrants(n) {
    const { quadrantSpace: f } = n, { quadrantHalfHeight: d, quadrantLeft: h, quadrantHalfWidth: p, quadrantTop: y } = f, _ = [
      {
        text: {
          text: this.data.quadrant1Text,
          fill: this.themeConfig.quadrant1TextFill,
          x: 0,
          y: 0,
          fontSize: this.config.quadrantLabelFontSize,
          verticalPos: "center",
          horizontalPos: "middle",
          rotation: 0
        },
        x: h + p,
        y,
        width: p,
        height: d,
        fill: this.themeConfig.quadrant1Fill
      },
      {
        text: {
          text: this.data.quadrant2Text,
          fill: this.themeConfig.quadrant2TextFill,
          x: 0,
          y: 0,
          fontSize: this.config.quadrantLabelFontSize,
          verticalPos: "center",
          horizontalPos: "middle",
          rotation: 0
        },
        x: h,
        y,
        width: p,
        height: d,
        fill: this.themeConfig.quadrant2Fill
      },
      {
        text: {
          text: this.data.quadrant3Text,
          fill: this.themeConfig.quadrant3TextFill,
          x: 0,
          y: 0,
          fontSize: this.config.quadrantLabelFontSize,
          verticalPos: "center",
          horizontalPos: "middle",
          rotation: 0
        },
        x: h,
        y: y + d,
        width: p,
        height: d,
        fill: this.themeConfig.quadrant3Fill
      },
      {
        text: {
          text: this.data.quadrant4Text,
          fill: this.themeConfig.quadrant4TextFill,
          x: 0,
          y: 0,
          fontSize: this.config.quadrantLabelFontSize,
          verticalPos: "center",
          horizontalPos: "middle",
          rotation: 0
        },
        x: h + p,
        y: y + d,
        width: p,
        height: d,
        fill: this.themeConfig.quadrant4Fill
      }
    ];
    for (const a of _)
      a.text.x = a.x + a.width / 2, this.data.points.length === 0 ? (a.text.y = a.y + a.height / 2, a.text.horizontalPos = "middle") : (a.text.y = a.y + this.config.quadrantTextTopPadding, a.text.horizontalPos = "top");
    return _;
  }
  getQuadrantPoints(n) {
    const { quadrantSpace: f } = n, { quadrantHeight: d, quadrantLeft: h, quadrantTop: p, quadrantWidth: y } = f, _ = ee().domain([0, 1]).range([h, y + h]), a = ee().domain([0, 1]).range([d + p, p]);
    return this.data.points.map((u) => {
      const T = this.classes.get(u.className);
      return T && (u = { ...T, ...u }), {
        x: _(u.x),
        y: a(u.y),
        fill: u.color ?? this.themeConfig.quadrantPointFill,
        radius: u.radius ?? this.config.pointRadius,
        text: {
          text: u.text,
          fill: this.themeConfig.quadrantPointTextFill,
          x: _(u.x),
          y: a(u.y) + this.config.pointTextPadding,
          verticalPos: "center",
          horizontalPos: "top",
          fontSize: this.config.pointLabelFontSize,
          rotation: 0
        },
        strokeColor: u.strokeColor ?? this.themeConfig.quadrantPointFill,
        strokeWidth: u.strokeWidth ?? "0px"
      };
    });
  }
  getBorders(n) {
    const f = this.config.quadrantExternalBorderStrokeWidth / 2, { quadrantSpace: d } = n, {
      quadrantHalfHeight: h,
      quadrantHeight: p,
      quadrantLeft: y,
      quadrantHalfWidth: _,
      quadrantTop: a,
      quadrantWidth: A
    } = d;
    return [
      // top border
      {
        strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
        strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
        x1: y - f,
        y1: a,
        x2: y + A + f,
        y2: a
      },
      // right border
      {
        strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
        strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
        x1: y + A,
        y1: a + f,
        x2: y + A,
        y2: a + p - f
      },
      // bottom border
      {
        strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
        strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
        x1: y - f,
        y1: a + p,
        x2: y + A + f,
        y2: a + p
      },
      // left border
      {
        strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill,
        strokeWidth: this.config.quadrantExternalBorderStrokeWidth,
        x1: y,
        y1: a + f,
        x2: y,
        y2: a + p - f
      },
      // vertical inner border
      {
        strokeFill: this.themeConfig.quadrantInternalBorderStrokeFill,
        strokeWidth: this.config.quadrantInternalBorderStrokeWidth,
        x1: y + _,
        y1: a + f,
        x2: y + _,
        y2: a + p - f
      },
      // horizontal inner border
      {
        strokeFill: this.themeConfig.quadrantInternalBorderStrokeFill,
        strokeWidth: this.config.quadrantInternalBorderStrokeWidth,
        x1: y + f,
        y1: a + h,
        x2: y + A - f,
        y2: a + h
      }
    ];
  }
  getTitle(n) {
    if (n)
      return {
        text: this.data.titleText,
        fill: this.themeConfig.quadrantTitleFill,
        fontSize: this.config.titleFontSize,
        horizontalPos: "top",
        verticalPos: "center",
        rotation: 0,
        y: this.config.titlePadding,
        x: this.config.chartWidth / 2
      };
  }
  build() {
    const n = this.config.showXAxis && !!(this.data.xAxisLeftText || this.data.xAxisRightText), f = this.config.showYAxis && !!(this.data.yAxisTopText || this.data.yAxisBottomText), d = this.config.showTitle && !!this.data.titleText, h = this.data.points.length > 0 ? "bottom" : this.config.xAxisPosition, p = this.calculateSpace(h, n, f, d);
    return {
      points: this.getQuadrantPoints(p),
      quadrants: this.getQuadrants(p),
      axisLabels: this.getAxisLabels(h, n, f, p),
      borderLines: this.getBorders(p),
      title: this.getTitle(d)
    };
  }
}, o(ot, "QuadrantBuilder"), ot), lt, mt = (lt = class extends Error {
  constructor(n, f, d) {
    super(`value for ${n} ${f} is invalid, please use a valid ${d}`), this.name = "InvalidStyleError";
  }
}, o(lt, "InvalidStyleError"), lt);
function Dt(t) {
  return !/^#?([\dA-Fa-f]{6}|[\dA-Fa-f]{3})$/.test(t);
}
o(Dt, "validateHexCode");
function ae(t) {
  return !/^\d+$/.test(t);
}
o(ae, "validateNumber");
function ne(t) {
  return !/^\d+px$/.test(t);
}
o(ne, "validateSizeInPixels");
var Ve = zt();
function Q(t) {
  return Le(t.trim(), Ve);
}
o(Q, "textSanitizer");
var z = new ze();
function se(t) {
  z.setData({ quadrant1Text: Q(t.text) });
}
o(se, "setQuadrant1Text");
function re(t) {
  z.setData({ quadrant2Text: Q(t.text) });
}
o(re, "setQuadrant2Text");
function oe(t) {
  z.setData({ quadrant3Text: Q(t.text) });
}
o(oe, "setQuadrant3Text");
function le(t) {
  z.setData({ quadrant4Text: Q(t.text) });
}
o(le, "setQuadrant4Text");
function he(t) {
  z.setData({ xAxisLeftText: Q(t.text) });
}
o(he, "setXAxisLeftText");
function ce(t) {
  z.setData({ xAxisRightText: Q(t.text) });
}
o(ce, "setXAxisRightText");
function de(t) {
  z.setData({ yAxisTopText: Q(t.text) });
}
o(de, "setYAxisTopText");
function ue(t) {
  z.setData({ yAxisBottomText: Q(t.text) });
}
o(ue, "setYAxisBottomText");
function St(t) {
  const n = {};
  for (const f of t) {
    const [d, h] = f.trim().split(/\s*:\s*/);
    if (d === "radius") {
      if (ae(h))
        throw new mt(d, h, "number");
      n.radius = parseInt(h);
    } else if (d === "color") {
      if (Dt(h))
        throw new mt(d, h, "hex code");
      n.color = h;
    } else if (d === "stroke-color") {
      if (Dt(h))
        throw new mt(d, h, "hex code");
      n.strokeColor = h;
    } else if (d === "stroke-width") {
      if (ne(h))
        throw new mt(d, h, "number of pixels (eg. 10px)");
      n.strokeWidth = h;
    } else
      throw new Error(`style named ${d} is not supported.`);
  }
  return n;
}
o(St, "parseStyles");
function xe(t, n, f, d, h) {
  const p = St(h);
  z.addPoints([
    {
      x: f,
      y: d,
      text: Q(t.text),
      className: n,
      ...p
    }
  ]);
}
o(xe, "addPoint");
function fe(t, n) {
  z.addClass(t, St(n));
}
o(fe, "addClass");
function ge(t) {
  z.setConfig({ chartWidth: t });
}
o(ge, "setWidth");
function pe(t) {
  z.setConfig({ chartHeight: t });
}
o(pe, "setHeight");
function ye() {
  const t = zt(), { themeVariables: n, quadrantChart: f } = t;
  return f && z.setConfig(f), z.setThemeConfig({
    quadrant1Fill: n.quadrant1Fill,
    quadrant2Fill: n.quadrant2Fill,
    quadrant3Fill: n.quadrant3Fill,
    quadrant4Fill: n.quadrant4Fill,
    quadrant1TextFill: n.quadrant1TextFill,
    quadrant2TextFill: n.quadrant2TextFill,
    quadrant3TextFill: n.quadrant3TextFill,
    quadrant4TextFill: n.quadrant4TextFill,
    quadrantPointFill: n.quadrantPointFill,
    quadrantPointTextFill: n.quadrantPointTextFill,
    quadrantXAxisTextFill: n.quadrantXAxisTextFill,
    quadrantYAxisTextFill: n.quadrantYAxisTextFill,
    quadrantExternalBorderStrokeFill: n.quadrantExternalBorderStrokeFill,
    quadrantInternalBorderStrokeFill: n.quadrantInternalBorderStrokeFill,
    quadrantTitleFill: n.quadrantTitleFill
  }), z.setData({ titleText: ie() }), z.build();
}
o(ye, "getQuadrantData");
var Ie = /* @__PURE__ */ o(function() {
  z.clear(), Ce();
}, "clear"), we = {
  setWidth: ge,
  setHeight: pe,
  setQuadrant1Text: se,
  setQuadrant2Text: re,
  setQuadrant3Text: oe,
  setQuadrant4Text: le,
  setXAxisLeftText: he,
  setXAxisRightText: ce,
  setYAxisTopText: de,
  setYAxisBottomText: ue,
  parseStyles: St,
  addPoint: xe,
  addClass: fe,
  getQuadrantData: ye,
  clear: Ie,
  setAccTitle: Pe,
  getAccTitle: Fe,
  setDiagramTitle: ke,
  getDiagramTitle: ie,
  getAccDescription: Ae,
  setAccDescription: _e
}, Be = /* @__PURE__ */ o((t, n, f, d) => {
  function h(i) {
    return i === "top" ? "hanging" : "middle";
  }
  o(h, "getDominantBaseLine");
  function p(i) {
    return i === "left" ? "start" : "middle";
  }
  o(p, "getTextAnchor");
  function y(i) {
    return `translate(${i.x}, ${i.y}) rotate(${i.rotation || 0})`;
  }
  o(y, "getTransformation");
  const _ = zt();
  bt.debug(`Rendering quadrant chart
` + t);
  const a = _.securityLevel;
  let A;
  a === "sandbox" && (A = Lt("#i" + n));
  const T = (a === "sandbox" ? Lt(A.nodes()[0].contentDocument.body) : Lt("body")).select(`[id="${n}"]`), q = T.append("g").attr("class", "main"), m = _.quadrantChart?.chartWidth ?? 500, b = _.quadrantChart?.chartHeight ?? 500;
  ve(T, b, m, _.quadrantChart?.useMaxWidth ?? !0), T.attr("viewBox", "0 0 " + m + " " + b), d.db.setHeight(b), d.db.setWidth(m);
  const g = d.db.getQuadrantData(), G = q.append("g").attr("class", "quadrants"), ht = q.append("g").attr("class", "border"), xt = q.append("g").attr("class", "data-points"), ft = q.append("g").attr("class", "labels"), gt = q.append("g").attr("class", "title");
  g.title && gt.append("text").attr("x", 0).attr("y", 0).attr("fill", g.title.fill).attr("font-size", g.title.fontSize).attr("dominant-baseline", h(g.title.horizontalPos)).attr("text-anchor", p(g.title.verticalPos)).attr("transform", y(g.title)).text(g.title.text), g.borderLines && ht.selectAll("line").data(g.borderLines).enter().append("line").attr("x1", (i) => i.x1).attr("y1", (i) => i.y1).attr("x2", (i) => i.x2).attr("y2", (i) => i.y2).style("stroke", (i) => i.strokeFill).style("stroke-width", (i) => i.strokeWidth);
  const ct = G.selectAll("g.quadrant").data(g.quadrants).enter().append("g").attr("class", "quadrant");
  ct.append("rect").attr("x", (i) => i.x).attr("y", (i) => i.y).attr("width", (i) => i.width).attr("height", (i) => i.height).attr("fill", (i) => i.fill), ct.append("text").attr("x", 0).attr("y", 0).attr("fill", (i) => i.text.fill).attr("font-size", (i) => i.text.fontSize).attr(
    "dominant-baseline",
    (i) => h(i.text.horizontalPos)
  ).attr("text-anchor", (i) => p(i.text.verticalPos)).attr("transform", (i) => y(i.text)).text((i) => i.text.text), ft.selectAll("g.label").data(g.axisLabels).enter().append("g").attr("class", "label").append("text").attr("x", 0).attr("y", 0).text((i) => i.text).attr("fill", (i) => i.fill).attr("font-size", (i) => i.fontSize).attr("dominant-baseline", (i) => h(i.horizontalPos)).attr("text-anchor", (i) => p(i.verticalPos)).attr("transform", (i) => y(i));
  const dt = xt.selectAll("g.data-point").data(g.points).enter().append("g").attr("class", "data-point");
  dt.append("circle").attr("cx", (i) => i.x).attr("cy", (i) => i.y).attr("r", (i) => i.radius).attr("fill", (i) => i.fill).attr("stroke", (i) => i.strokeColor).attr("stroke-width", (i) => i.strokeWidth), dt.append("text").attr("x", 0).attr("y", 0).text((i) => i.text.text).attr("fill", (i) => i.text.fill).attr("font-size", (i) => i.text.fontSize).attr(
    "dominant-baseline",
    (i) => h(i.text.horizontalPos)
  ).attr("text-anchor", (i) => p(i.text.verticalPos)).attr("transform", (i) => y(i.text));
}, "draw"), Re = {
  draw: Be
}, Ue = {
  parser: De,
  db: we,
  renderer: Re,
  styles: /* @__PURE__ */ o(() => "", "styles")
};
export {
  Ue as diagram
};
