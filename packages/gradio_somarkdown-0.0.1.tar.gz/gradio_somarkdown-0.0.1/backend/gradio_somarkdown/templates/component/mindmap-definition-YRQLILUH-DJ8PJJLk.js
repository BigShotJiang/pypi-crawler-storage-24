import { g as le } from "./chunk-55IACEB6-C0AU7_zG.js";
import { s as he } from "./chunk-KX2RTZJC-CqTMtmV1.js";
import { _ as l, l as I, o as de, r as ge, F, c as W, i as V, aK as ue, W as pe, X as fe, Y as ye } from "./mermaid.core-DfOz2mRZ.js";
const E = [];
for (let t = 0; t < 256; ++t)
  E.push((t + 256).toString(16).slice(1));
function me(t, e = 0) {
  return (E[t[e + 0]] + E[t[e + 1]] + E[t[e + 2]] + E[t[e + 3]] + "-" + E[t[e + 4]] + E[t[e + 5]] + "-" + E[t[e + 6]] + E[t[e + 7]] + "-" + E[t[e + 8]] + E[t[e + 9]] + "-" + E[t[e + 10]] + E[t[e + 11]] + E[t[e + 12]] + E[t[e + 13]] + E[t[e + 14]] + E[t[e + 15]]).toLowerCase();
}
let X;
const Ee = new Uint8Array(16);
function _e() {
  if (!X) {
    if (typeof crypto > "u" || !crypto.getRandomValues)
      throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    X = crypto.getRandomValues.bind(crypto);
  }
  return X(Ee);
}
const be = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto), ne = { randomUUID: be };
function Se(t, e, n) {
  if (ne.randomUUID && !t)
    return ne.randomUUID();
  t = t || {};
  const c = t.random ?? t.rng?.() ?? _e();
  if (c.length < 16)
    throw new Error("Random bytes length must be >= 16");
  return c[6] = c[6] & 15 | 64, c[8] = c[8] & 63 | 128, me(c);
}
var z = (function() {
  var t = /* @__PURE__ */ l(function(x, s, i, o) {
    for (i = i || {}, o = x.length; o--; i[x[o]] = s) ;
    return i;
  }, "o"), e = [1, 4], n = [1, 13], c = [1, 12], f = [1, 15], h = [1, 16], p = [1, 20], m = [1, 19], u = [6, 7, 8], D = [1, 26], Y = [1, 24], K = [1, 25], b = [6, 7, 11], q = [1, 6, 13, 15, 16, 19, 22], J = [1, 33], Q = [1, 34], R = [1, 6, 7, 11, 13, 15, 16, 19, 22], B = {
    trace: /* @__PURE__ */ l(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, mindMap: 4, spaceLines: 5, SPACELINE: 6, NL: 7, MINDMAP: 8, document: 9, stop: 10, EOF: 11, statement: 12, SPACELIST: 13, node: 14, ICON: 15, CLASS: 16, nodeWithId: 17, nodeWithoutId: 18, NODE_DSTART: 19, NODE_DESCR: 20, NODE_DEND: 21, NODE_ID: 22, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 6: "SPACELINE", 7: "NL", 8: "MINDMAP", 11: "EOF", 13: "SPACELIST", 15: "ICON", 16: "CLASS", 19: "NODE_DSTART", 20: "NODE_DESCR", 21: "NODE_DEND", 22: "NODE_ID" },
    productions_: [0, [3, 1], [3, 2], [5, 1], [5, 2], [5, 2], [4, 2], [4, 3], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [9, 3], [9, 2], [12, 2], [12, 2], [12, 2], [12, 1], [12, 1], [12, 1], [12, 1], [12, 1], [14, 1], [14, 1], [18, 3], [17, 1], [17, 4]],
    performAction: /* @__PURE__ */ l(function(s, i, o, a, g, r, w) {
      var d = r.length - 1;
      switch (g) {
        case 6:
        case 7:
          return a;
        case 8:
          a.getLogger().trace("Stop NL ");
          break;
        case 9:
          a.getLogger().trace("Stop EOF ");
          break;
        case 11:
          a.getLogger().trace("Stop NL2 ");
          break;
        case 12:
          a.getLogger().trace("Stop EOF2 ");
          break;
        case 15:
          a.getLogger().info("Node: ", r[d].id), a.addNode(r[d - 1].length, r[d].id, r[d].descr, r[d].type);
          break;
        case 16:
          a.getLogger().trace("Icon: ", r[d]), a.decorateNode({ icon: r[d] });
          break;
        case 17:
        case 21:
          a.decorateNode({ class: r[d] });
          break;
        case 18:
          a.getLogger().trace("SPACELIST");
          break;
        case 19:
          a.getLogger().trace("Node: ", r[d].id), a.addNode(0, r[d].id, r[d].descr, r[d].type);
          break;
        case 20:
          a.decorateNode({ icon: r[d] });
          break;
        case 25:
          a.getLogger().trace("node found ..", r[d - 2]), this.$ = { id: r[d - 1], descr: r[d - 1], type: a.getType(r[d - 2], r[d]) };
          break;
        case 26:
          this.$ = { id: r[d], descr: r[d], type: a.nodeType.DEFAULT };
          break;
        case 27:
          a.getLogger().trace("node found ..", r[d - 3]), this.$ = { id: r[d - 3], descr: r[d - 1], type: a.getType(r[d - 2], r[d]) };
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: 2, 5: 3, 6: [1, 5], 8: e }, { 1: [3] }, { 1: [2, 1] }, { 4: 6, 6: [1, 7], 7: [1, 8], 8: e }, { 6: n, 7: [1, 10], 9: 9, 12: 11, 13: c, 14: 14, 15: f, 16: h, 17: 17, 18: 18, 19: p, 22: m }, t(u, [2, 3]), { 1: [2, 2] }, t(u, [2, 4]), t(u, [2, 5]), { 1: [2, 6], 6: n, 12: 21, 13: c, 14: 14, 15: f, 16: h, 17: 17, 18: 18, 19: p, 22: m }, { 6: n, 9: 22, 12: 11, 13: c, 14: 14, 15: f, 16: h, 17: 17, 18: 18, 19: p, 22: m }, { 6: D, 7: Y, 10: 23, 11: K }, t(b, [2, 22], { 17: 17, 18: 18, 14: 27, 15: [1, 28], 16: [1, 29], 19: p, 22: m }), t(b, [2, 18]), t(b, [2, 19]), t(b, [2, 20]), t(b, [2, 21]), t(b, [2, 23]), t(b, [2, 24]), t(b, [2, 26], { 19: [1, 30] }), { 20: [1, 31] }, { 6: D, 7: Y, 10: 32, 11: K }, { 1: [2, 7], 6: n, 12: 21, 13: c, 14: 14, 15: f, 16: h, 17: 17, 18: 18, 19: p, 22: m }, t(q, [2, 14], { 7: J, 11: Q }), t(R, [2, 8]), t(R, [2, 9]), t(R, [2, 10]), t(b, [2, 15]), t(b, [2, 16]), t(b, [2, 17]), { 20: [1, 35] }, { 21: [1, 36] }, t(q, [2, 13], { 7: J, 11: Q }), t(R, [2, 11]), t(R, [2, 12]), { 21: [1, 37] }, t(b, [2, 25]), t(b, [2, 27])],
    defaultActions: { 2: [2, 1], 6: [2, 2] },
    parseError: /* @__PURE__ */ l(function(s, i) {
      if (i.recoverable)
        this.trace(s);
      else {
        var o = new Error(s);
        throw o.hash = i, o;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ l(function(s) {
      var i = this, o = [0], a = [], g = [null], r = [], w = this.table, d = "", U = 0, Z = 0, re = 2, ee = 1, oe = r.slice.call(arguments, 1), y = Object.create(this.lexer), v = { yy: {} };
      for (var j in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, j) && (v.yy[j] = this.yy[j]);
      y.setInput(s, v.yy), v.yy.lexer = y, v.yy.parser = this, typeof y.yylloc > "u" && (y.yylloc = {});
      var G = y.yylloc;
      r.push(G);
      var ae = y.options && y.options.ranges;
      typeof v.yy.parseError == "function" ? this.parseError = v.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function ce(S) {
        o.length = o.length - 2 * S, g.length = g.length - S, r.length = r.length - S;
      }
      l(ce, "popStack");
      function te() {
        var S;
        return S = a.pop() || y.lex() || ee, typeof S != "number" && (S instanceof Array && (a = S, S = a.pop()), S = i.symbols_[S] || S), S;
      }
      l(te, "lex");
      for (var _, T, N, H, O = {}, P, k, ie, M; ; ) {
        if (T = o[o.length - 1], this.defaultActions[T] ? N = this.defaultActions[T] : ((_ === null || typeof _ > "u") && (_ = te()), N = w[T] && w[T][_]), typeof N > "u" || !N.length || !N[0]) {
          var $ = "";
          M = [];
          for (P in w[T])
            this.terminals_[P] && P > re && M.push("'" + this.terminals_[P] + "'");
          y.showPosition ? $ = "Parse error on line " + (U + 1) + `:
` + y.showPosition() + `
Expecting ` + M.join(", ") + ", got '" + (this.terminals_[_] || _) + "'" : $ = "Parse error on line " + (U + 1) + ": Unexpected " + (_ == ee ? "end of input" : "'" + (this.terminals_[_] || _) + "'"), this.parseError($, {
            text: y.match,
            token: this.terminals_[_] || _,
            line: y.yylineno,
            loc: G,
            expected: M
          });
        }
        if (N[0] instanceof Array && N.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + T + ", token: " + _);
        switch (N[0]) {
          case 1:
            o.push(_), g.push(y.yytext), r.push(y.yylloc), o.push(N[1]), _ = null, Z = y.yyleng, d = y.yytext, U = y.yylineno, G = y.yylloc;
            break;
          case 2:
            if (k = this.productions_[N[1]][1], O.$ = g[g.length - k], O._$ = {
              first_line: r[r.length - (k || 1)].first_line,
              last_line: r[r.length - 1].last_line,
              first_column: r[r.length - (k || 1)].first_column,
              last_column: r[r.length - 1].last_column
            }, ae && (O._$.range = [
              r[r.length - (k || 1)].range[0],
              r[r.length - 1].range[1]
            ]), H = this.performAction.apply(O, [
              d,
              Z,
              U,
              v.yy,
              N[1],
              g,
              r
            ].concat(oe)), typeof H < "u")
              return H;
            k && (o = o.slice(0, -1 * k * 2), g = g.slice(0, -1 * k), r = r.slice(0, -1 * k)), o.push(this.productions_[N[1]][0]), g.push(O.$), r.push(O._$), ie = w[o[o.length - 2]][o[o.length - 1]], o.push(ie);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, se = /* @__PURE__ */ (function() {
    var x = {
      EOF: 1,
      parseError: /* @__PURE__ */ l(function(i, o) {
        if (this.yy.parser)
          this.yy.parser.parseError(i, o);
        else
          throw new Error(i);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ l(function(s, i) {
        return this.yy = i || this.yy || {}, this._input = s, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ l(function() {
        var s = this._input[0];
        this.yytext += s, this.yyleng++, this.offset++, this.match += s, this.matched += s;
        var i = s.match(/(?:\r\n?|\n).*/g);
        return i ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), s;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ l(function(s) {
        var i = s.length, o = s.split(/(?:\r\n?|\n)/g);
        this._input = s + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - i), this.offset -= i;
        var a = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), o.length - 1 && (this.yylineno -= o.length - 1);
        var g = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: o ? (o.length === a.length ? this.yylloc.first_column : 0) + a[a.length - o.length].length - o[0].length : this.yylloc.first_column - i
        }, this.options.ranges && (this.yylloc.range = [g[0], g[0] + this.yyleng - i]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ l(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ l(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ l(function(s) {
        this.unput(this.match.slice(s));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ l(function() {
        var s = this.matched.substr(0, this.matched.length - this.match.length);
        return (s.length > 20 ? "..." : "") + s.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ l(function() {
        var s = this.match;
        return s.length < 20 && (s += this._input.substr(0, 20 - s.length)), (s.substr(0, 20) + (s.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ l(function() {
        var s = this.pastInput(), i = new Array(s.length + 1).join("-");
        return s + this.upcomingInput() + `
` + i + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ l(function(s, i) {
        var o, a, g;
        if (this.options.backtrack_lexer && (g = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (g.yylloc.range = this.yylloc.range.slice(0))), a = s[0].match(/(?:\r\n?|\n).*/g), a && (this.yylineno += a.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: a ? a[a.length - 1].length - a[a.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + s[0].length
        }, this.yytext += s[0], this.match += s[0], this.matches = s, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(s[0].length), this.matched += s[0], o = this.performAction.call(this, this.yy, this, i, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), o)
          return o;
        if (this._backtrack) {
          for (var r in g)
            this[r] = g[r];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ l(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var s, i, o, a;
        this._more || (this.yytext = "", this.match = "");
        for (var g = this._currentRules(), r = 0; r < g.length; r++)
          if (o = this._input.match(this.rules[g[r]]), o && (!i || o[0].length > i[0].length)) {
            if (i = o, a = r, this.options.backtrack_lexer) {
              if (s = this.test_match(o, g[r]), s !== !1)
                return s;
              if (this._backtrack) {
                i = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return i ? (s = this.test_match(i, g[a]), s !== !1 ? s : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ l(function() {
        var i = this.next();
        return i || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ l(function(i) {
        this.conditionStack.push(i);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ l(function() {
        var i = this.conditionStack.length - 1;
        return i > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ l(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ l(function(i) {
        return i = this.conditionStack.length - 1 - Math.abs(i || 0), i >= 0 ? this.conditionStack[i] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ l(function(i) {
        this.begin(i);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ l(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ l(function(i, o, a, g) {
        switch (a) {
          case 0:
            return i.getLogger().trace("Found comment", o.yytext), 6;
          case 1:
            return 8;
          case 2:
            this.begin("CLASS");
            break;
          case 3:
            return this.popState(), 16;
          case 4:
            this.popState();
            break;
          case 5:
            i.getLogger().trace("Begin icon"), this.begin("ICON");
            break;
          case 6:
            return i.getLogger().trace("SPACELINE"), 6;
          case 7:
            return 7;
          case 8:
            return 15;
          case 9:
            i.getLogger().trace("end icon"), this.popState();
            break;
          case 10:
            return i.getLogger().trace("Exploding node"), this.begin("NODE"), 19;
          case 11:
            return i.getLogger().trace("Cloud"), this.begin("NODE"), 19;
          case 12:
            return i.getLogger().trace("Explosion Bang"), this.begin("NODE"), 19;
          case 13:
            return i.getLogger().trace("Cloud Bang"), this.begin("NODE"), 19;
          case 14:
            return this.begin("NODE"), 19;
          case 15:
            return this.begin("NODE"), 19;
          case 16:
            return this.begin("NODE"), 19;
          case 17:
            return this.begin("NODE"), 19;
          case 18:
            return 13;
          case 19:
            return 22;
          case 20:
            return 11;
          case 21:
            this.begin("NSTR2");
            break;
          case 22:
            return "NODE_DESCR";
          case 23:
            this.popState();
            break;
          case 24:
            i.getLogger().trace("Starting NSTR"), this.begin("NSTR");
            break;
          case 25:
            return i.getLogger().trace("description:", o.yytext), "NODE_DESCR";
          case 26:
            this.popState();
            break;
          case 27:
            return this.popState(), i.getLogger().trace("node end ))"), "NODE_DEND";
          case 28:
            return this.popState(), i.getLogger().trace("node end )"), "NODE_DEND";
          case 29:
            return this.popState(), i.getLogger().trace("node end ...", o.yytext), "NODE_DEND";
          case 30:
            return this.popState(), i.getLogger().trace("node end (("), "NODE_DEND";
          case 31:
            return this.popState(), i.getLogger().trace("node end (-"), "NODE_DEND";
          case 32:
            return this.popState(), i.getLogger().trace("node end (-"), "NODE_DEND";
          case 33:
            return this.popState(), i.getLogger().trace("node end (("), "NODE_DEND";
          case 34:
            return this.popState(), i.getLogger().trace("node end (("), "NODE_DEND";
          case 35:
            return i.getLogger().trace("Long description:", o.yytext), 20;
          case 36:
            return i.getLogger().trace("Long description:", o.yytext), 20;
        }
      }, "anonymous"),
      rules: [/^(?:\s*%%.*)/i, /^(?:mindmap\b)/i, /^(?::::)/i, /^(?:.+)/i, /^(?:\n)/i, /^(?:::icon\()/i, /^(?:[\s]+[\n])/i, /^(?:[\n]+)/i, /^(?:[^\)]+)/i, /^(?:\))/i, /^(?:-\))/i, /^(?:\(-)/i, /^(?:\)\))/i, /^(?:\))/i, /^(?:\(\()/i, /^(?:\{\{)/i, /^(?:\()/i, /^(?:\[)/i, /^(?:[\s]+)/i, /^(?:[^\(\[\n\)\{\}]+)/i, /^(?:$)/i, /^(?:["][`])/i, /^(?:[^`"]+)/i, /^(?:[`]["])/i, /^(?:["])/i, /^(?:[^"]+)/i, /^(?:["])/i, /^(?:[\)]\))/i, /^(?:[\)])/i, /^(?:[\]])/i, /^(?:\}\})/i, /^(?:\(-)/i, /^(?:-\))/i, /^(?:\(\()/i, /^(?:\()/i, /^(?:[^\)\]\(\}]+)/i, /^(?:.+(?!\(\())/i],
      conditions: { CLASS: { rules: [3, 4], inclusive: !1 }, ICON: { rules: [8, 9], inclusive: !1 }, NSTR2: { rules: [22, 23], inclusive: !1 }, NSTR: { rules: [25, 26], inclusive: !1 }, NODE: { rules: [21, 24, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], inclusive: !0 } }
    };
    return x;
  })();
  B.lexer = se;
  function A() {
    this.yy = {};
  }
  return l(A, "Parser"), A.prototype = B, B.Parser = A, new A();
})();
z.parser = z;
var Ne = z, De = 12, L = {
  DEFAULT: 0,
  NO_BORDER: 0,
  ROUNDED_RECT: 1,
  RECT: 2,
  CIRCLE: 3,
  CLOUD: 4,
  BANG: 5,
  HEXAGON: 6
}, C, ke = (C = class {
  constructor() {
    this.nodes = [], this.count = 0, this.elements = {}, this.getLogger = this.getLogger.bind(this), this.nodeType = L, this.clear(), this.getType = this.getType.bind(this), this.getElementById = this.getElementById.bind(this), this.getParent = this.getParent.bind(this), this.getMindmap = this.getMindmap.bind(this), this.addNode = this.addNode.bind(this), this.decorateNode = this.decorateNode.bind(this);
  }
  clear() {
    this.nodes = [], this.count = 0, this.elements = {}, this.baseLevel = void 0;
  }
  getParent(e) {
    for (let n = this.nodes.length - 1; n >= 0; n--)
      if (this.nodes[n].level < e)
        return this.nodes[n];
    return null;
  }
  getMindmap() {
    return this.nodes.length > 0 ? this.nodes[0] : null;
  }
  addNode(e, n, c, f) {
    I.info("addNode", e, n, c, f);
    let h = !1;
    this.nodes.length === 0 ? (this.baseLevel = e, e = 0, h = !0) : this.baseLevel !== void 0 && (e = e - this.baseLevel, h = !1);
    const p = W();
    let m = p.mindmap?.padding ?? F.mindmap.padding;
    switch (f) {
      case this.nodeType.ROUNDED_RECT:
      case this.nodeType.RECT:
      case this.nodeType.HEXAGON:
        m *= 2;
        break;
    }
    const u = {
      id: this.count++,
      nodeId: V(n, p),
      level: e,
      descr: V(c, p),
      type: f,
      children: [],
      width: p.mindmap?.maxNodeWidth ?? F.mindmap.maxNodeWidth,
      padding: m,
      isRoot: h
    }, D = this.getParent(e);
    if (D)
      D.children.push(u), this.nodes.push(u);
    else if (h)
      this.nodes.push(u);
    else
      throw new Error(
        `There can be only one root. No parent could be found for ("${u.descr}")`
      );
  }
  getType(e, n) {
    switch (I.debug("In get type", e, n), e) {
      case "[":
        return this.nodeType.RECT;
      case "(":
        return n === ")" ? this.nodeType.ROUNDED_RECT : this.nodeType.CLOUD;
      case "((":
        return this.nodeType.CIRCLE;
      case ")":
        return this.nodeType.CLOUD;
      case "))":
        return this.nodeType.BANG;
      case "{{":
        return this.nodeType.HEXAGON;
      default:
        return this.nodeType.DEFAULT;
    }
  }
  setElementForId(e, n) {
    this.elements[e] = n;
  }
  getElementById(e) {
    return this.elements[e];
  }
  decorateNode(e) {
    if (!e)
      return;
    const n = W(), c = this.nodes[this.nodes.length - 1];
    e.icon && (c.icon = V(e.icon, n)), e.class && (c.class = V(e.class, n));
  }
  type2Str(e) {
    switch (e) {
      case this.nodeType.DEFAULT:
        return "no-border";
      case this.nodeType.RECT:
        return "rect";
      case this.nodeType.ROUNDED_RECT:
        return "rounded-rect";
      case this.nodeType.CIRCLE:
        return "circle";
      case this.nodeType.CLOUD:
        return "cloud";
      case this.nodeType.BANG:
        return "bang";
      case this.nodeType.HEXAGON:
        return "hexgon";
      // cspell: disable-line
      default:
        return "no-border";
    }
  }
  /**
   * Assign section numbers to nodes based on their position relative to root
   * @param node - The mindmap node to process
   * @param sectionNumber - The section number to assign (undefined for root)
   */
  assignSections(e, n) {
    if (e.level === 0 ? e.section = void 0 : e.section = n, e.children)
      for (const [c, f] of e.children.entries()) {
        const h = e.level === 0 ? c % (De - 1) : n;
        this.assignSections(f, h);
      }
  }
  /**
   * Convert mindmap tree structure to flat array of nodes
   * @param node - The mindmap node to process
   * @param processedNodes - Array to collect processed nodes
   */
  flattenNodes(e, n) {
    const c = ["mindmap-node"];
    e.isRoot === !0 ? c.push("section-root", "section--1") : e.section !== void 0 && c.push(`section-${e.section}`), e.class && c.push(e.class);
    const f = c.join(" "), h = /* @__PURE__ */ l((m) => {
      switch (m) {
        case L.CIRCLE:
          return "mindmapCircle";
        case L.RECT:
          return "rect";
        case L.ROUNDED_RECT:
          return "rounded";
        case L.CLOUD:
          return "cloud";
        case L.BANG:
          return "bang";
        case L.HEXAGON:
          return "hexagon";
        case L.DEFAULT:
          return "defaultMindmapNode";
        case L.NO_BORDER:
        default:
          return "rect";
      }
    }, "getShapeFromType"), p = {
      id: e.id.toString(),
      domId: "node_" + e.id.toString(),
      label: e.descr,
      labelType: "markdown",
      isGroup: !1,
      shape: h(e.type),
      width: e.width,
      height: e.height ?? 0,
      padding: e.padding,
      cssClasses: f,
      cssStyles: [],
      look: "default",
      icon: e.icon,
      x: e.x,
      y: e.y,
      // Mindmap-specific properties
      level: e.level,
      nodeId: e.nodeId,
      type: e.type,
      section: e.section
    };
    if (n.push(p), e.children)
      for (const m of e.children)
        this.flattenNodes(m, n);
  }
  /**
   * Generate edges from parent-child relationships in mindmap tree
   * @param node - The mindmap node to process
   * @param edges - Array to collect edges
   */
  generateEdges(e, n) {
    if (e.children)
      for (const c of e.children) {
        let f = "edge";
        c.section !== void 0 && (f += ` section-edge-${c.section}`);
        const h = e.level + 1;
        f += ` edge-depth-${h}`;
        const p = {
          id: `edge_${e.id}_${c.id}`,
          start: e.id.toString(),
          end: c.id.toString(),
          type: "normal",
          curve: "basis",
          thickness: "normal",
          look: "default",
          classes: f,
          // Store mindmap-specific data
          depth: e.level,
          section: c.section
        };
        n.push(p), this.generateEdges(c, n);
      }
  }
  /**
   * Get structured data for layout algorithms
   * Following the pattern established by ER diagrams
   * @returns Structured data containing nodes, edges, and config
   */
  getData() {
    const e = this.getMindmap(), n = W(), f = ue().layout !== void 0, h = n;
    if (f || (h.layout = "cose-bilkent"), !e)
      return {
        nodes: [],
        edges: [],
        config: h
      };
    I.debug("getData: mindmapRoot", e, n), this.assignSections(e);
    const p = [], m = [];
    this.flattenNodes(e, p), this.generateEdges(e, m), I.debug(
      `getData: processed ${p.length} nodes and ${m.length} edges`
    );
    const u = /* @__PURE__ */ new Map();
    for (const D of p)
      u.set(D.id, {
        shape: D.shape,
        width: D.width,
        height: D.height,
        padding: D.padding
      });
    return {
      nodes: p,
      edges: m,
      config: h,
      // Store the root node for mindmap-specific layout algorithms
      rootNode: e,
      // Properties required by dagre layout algorithm
      markers: ["point"],
      // Mindmaps don't use markers
      direction: "TB",
      // Top-to-bottom direction for mindmaps
      nodeSpacing: 50,
      // Default spacing between nodes
      rankSpacing: 50,
      // Default spacing between ranks
      // Add shapes for ELK compatibility
      shapes: Object.fromEntries(u),
      // Additional properties that layout algorithms might expect
      type: "mindmap",
      diagramId: "mindmap-" + Se()
    };
  }
  // Expose logger to grammar
  getLogger() {
    return I;
  }
}, l(C, "MindmapDB"), C), Le = /* @__PURE__ */ l(async (t, e, n, c) => {
  I.debug(`Rendering mindmap diagram
` + t);
  const f = c.db, h = f.getData(), p = le(e, h.config.securityLevel);
  h.type = c.type, h.layoutAlgorithm = de(h.config.layout, {
    fallback: "cose-bilkent"
  }), h.diagramId = e, f.getMindmap() && (h.nodes.forEach((u) => {
    u.shape === "rounded" ? (u.radius = 15, u.taper = 15, u.stroke = "none", u.width = 0, u.padding = 15) : u.shape === "circle" ? u.padding = 10 : u.shape === "rect" && (u.width = 0, u.padding = 10);
  }), await ge(h, p), he(
    p,
    h.config.mindmap?.padding ?? F.mindmap.padding,
    "mindmapDiagram",
    h.config.mindmap?.useMaxWidth ?? F.mindmap.useMaxWidth
  ));
}, "draw"), xe = {
  draw: Le
}, ve = /* @__PURE__ */ l((t) => {
  let e = "";
  for (let n = 0; n < t.THEME_COLOR_LIMIT; n++)
    t["lineColor" + n] = t["lineColor" + n] || t["cScaleInv" + n], pe(t["lineColor" + n]) ? t["lineColor" + n] = fe(t["lineColor" + n], 20) : t["lineColor" + n] = ye(t["lineColor" + n], 20);
  for (let n = 0; n < t.THEME_COLOR_LIMIT; n++) {
    const c = "" + (17 - 3 * n);
    e += `
    .section-${n - 1} rect, .section-${n - 1} path, .section-${n - 1} circle, .section-${n - 1} polygon, .section-${n - 1} path  {
      fill: ${t["cScale" + n]};
    }
    .section-${n - 1} text {
     fill: ${t["cScaleLabel" + n]};
    }
    .node-icon-${n - 1} {
      font-size: 40px;
      color: ${t["cScaleLabel" + n]};
    }
    .section-edge-${n - 1}{
      stroke: ${t["cScale" + n]};
    }
    .edge-depth-${n - 1}{
      stroke-width: ${c};
    }
    .section-${n - 1} line {
      stroke: ${t["cScaleInv" + n]} ;
      stroke-width: 3;
    }

    .disabled, .disabled circle, .disabled text {
      fill: lightgray;
    }
    .disabled text {
      fill: #efefef;
    }
    `;
  }
  return e;
}, "genSections"), Te = /* @__PURE__ */ l((t) => `
  .edge {
    stroke-width: 3;
  }
  ${ve(t)}
  .section-root rect, .section-root path, .section-root circle, .section-root polygon  {
    fill: ${t.git0};
  }
  .section-root text {
    fill: ${t.gitBranchLabel0};
  }
  .section-root span {
    color: ${t.gitBranchLabel0};
  }
  .section-2 span {
    color: ${t.gitBranchLabel0};
  }
  .icon-container {
    height:100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .edge {
    fill: none;
  }
  .mindmap-node-label {
    dy: 1em;
    alignment-baseline: middle;
    text-anchor: middle;
    dominant-baseline: middle;
    text-align: center;
  }
`, "getStyles"), Oe = Te, we = {
  get db() {
    return new ke();
  },
  renderer: xe,
  parser: Ne,
  styles: Oe
};
export {
  we as diagram
};
