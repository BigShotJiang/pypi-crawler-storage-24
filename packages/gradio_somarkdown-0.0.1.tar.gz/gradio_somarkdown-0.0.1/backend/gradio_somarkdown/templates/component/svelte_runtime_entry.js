import { m as d, u as r } from "./render-C-LyLVx7.js";
const e = "5";
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add(e);
const o = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
export {
  o as SVELTE_VERSION,
  d as mount,
  r as unmount
};
