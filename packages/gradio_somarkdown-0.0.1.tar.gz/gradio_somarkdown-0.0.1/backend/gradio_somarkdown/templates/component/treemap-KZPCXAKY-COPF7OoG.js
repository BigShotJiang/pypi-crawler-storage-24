import { bD as Lh, bE as Oh, aX as wd, bn as xh, a$ as Dh, aY as je, at as Mh, au as wl, bd as Fh, bg as bd, bh as _d, be as Gh, bs as bl, aw as Hn, ax as ae, aZ as Uh, aT as qh } from "./mermaid.core-DfOz2mRZ.js";
import { k as Ur, j as el, g as Kr, S as jh, w as zh, x as Bh, c as Id, v as $e, y as Pd, l as Wh, z as Vh, A as Kh, B as Hh, C as Yh, a as $d, d as q, i as tn, r as Je, f as ht, D as Fe } from "./_baseUniq-CHMJb_u8.js";
import { j as tl, m as M, d as Xh, f as yt, g as qr, h as z, i as nl, l as qn, e as Jh } from "./_basePickBy-Dav4Bp6I.js";
import { c as Be } from "./clone-uXzw6j0L.js";
import { a as Qh } from "./Index-CcLf415l.js";
var Zh = Object.prototype, ep = Zh.hasOwnProperty, ft = Lh(function(t, e) {
  if (Oh(e) || wd(e)) {
    xh(e, Ur(e), t);
    return;
  }
  for (var n in e)
    ep.call(e, n) && Dh(t, n, e[n]);
});
function Ld(t, e, n) {
  var r = -1, i = t.length;
  e < 0 && (e = -e > i ? 0 : i + e), n = n > i ? i : n, n < 0 && (n += i), i = e > n ? 0 : n - e >>> 0, e >>>= 0;
  for (var s = Array(i); ++r < i; )
    s[r] = t[r + e];
  return s;
}
function ts(t) {
  for (var e = -1, n = t == null ? 0 : t.length, r = 0, i = []; ++e < n; ) {
    var s = t[e];
    s && (i[r++] = s);
  }
  return i;
}
function tp(t, e, n, r) {
  for (var i = -1, s = t == null ? 0 : t.length; ++i < s; ) {
    var a = t[i];
    e(r, a, n(a), t);
  }
  return r;
}
function np(t, e, n, r) {
  return el(t, function(i, s, a) {
    e(r, i, n(i), a);
  }), r;
}
function rp(t, e) {
  return function(n, r) {
    var i = je(n) ? tp : np, s = e ? e() : {};
    return i(n, t, Kr(r), s);
  };
}
var ip = 200;
function sp(t, e, n, r) {
  var i = -1, s = zh, a = !0, o = t.length, c = [], l = e.length;
  if (!o)
    return c;
  e.length >= ip && (s = Bh, a = !1, e = new jh(e));
  e:
    for (; ++i < o; ) {
      var u = t[i], f = u;
      if (u = u !== 0 ? u : 0, a && f === f) {
        for (var m = l; m--; )
          if (e[m] === f)
            continue e;
        c.push(u);
      } else s(e, f, r) || c.push(u);
    }
  return c;
}
var ba = Mh(function(t, e) {
  return wl(t) ? sp(t, Id(e, 1, wl, !0)) : [];
});
function Ge(t, e, n) {
  var r = t == null ? 0 : t.length;
  return r ? (e = e === void 0 ? 1 : tl(e), Ld(t, e < 0 ? 0 : e, r)) : [];
}
function ji(t, e, n) {
  var r = t == null ? 0 : t.length;
  return r ? (e = e === void 0 ? 1 : tl(e), e = r - e, Ld(t, 0, e < 0 ? 0 : e)) : [];
}
function ap(t, e) {
  for (var n = -1, r = t == null ? 0 : t.length; ++n < r; )
    if (!e(t[n], n, t))
      return !1;
  return !0;
}
function op(t, e) {
  var n = !0;
  return el(t, function(r, i, s) {
    return n = !!e(r, i, s), n;
  }), n;
}
function kt(t, e, n) {
  var r = je(t) ? ap : op;
  return r(t, Kr(e));
}
function Nt(t) {
  return t && t.length ? t[0] : void 0;
}
function dt(t, e) {
  return Id(M(t, e));
}
var cp = Object.prototype, lp = cp.hasOwnProperty, up = rp(function(t, e, n) {
  lp.call(t, n) ? t[n].push(e) : Fh(t, n, [e]);
}), dp = "[object String]";
function nt(t) {
  return typeof t == "string" || !je(t) && bd(t) && _d(t) == dp;
}
var fp = Math.max;
function et(t, e, n, r) {
  t = wd(t) ? t : $e(t), n = n ? tl(n) : 0;
  var i = t.length;
  return n < 0 && (n = fp(i + n, 0)), nt(t) ? n <= i && t.indexOf(e, n) > -1 : !!i && Pd(t, e, n) > -1;
}
function _l(t, e, n) {
  var r = t == null ? 0 : t.length;
  if (!r)
    return -1;
  var i = 0;
  return Pd(t, e, i);
}
var hp = "[object RegExp]";
function pp(t) {
  return bd(t) && _d(t) == hp;
}
var Il = bl && bl.isRegExp, nn = Il ? Gh(Il) : pp, mp = "Expected a function";
function gp(t) {
  if (typeof t != "function")
    throw new TypeError(mp);
  return function() {
    var e = arguments;
    switch (e.length) {
      case 0:
        return !t.call(this);
      case 1:
        return !t.call(this, e[0]);
      case 2:
        return !t.call(this, e[0], e[1]);
      case 3:
        return !t.call(this, e[0], e[1], e[2]);
    }
    return !t.apply(this, e);
  };
}
function wt(t, e) {
  if (t == null)
    return {};
  var n = Wh(Vh(t), function(r) {
    return [r];
  });
  return e = Kr(e), Xh(t, n, function(r, i) {
    return e(r, i[0]);
  });
}
function _a(t, e) {
  var n = je(t) ? Kh : Hh;
  return n(t, gp(Kr(e)));
}
function yp(t, e) {
  var n;
  return el(t, function(r, i, s) {
    return n = e(r, i, s), !n;
  }), !!n;
}
function Od(t, e, n) {
  var r = je(t) ? Yh : yp;
  return r(t, Kr(e));
}
function rl(t) {
  return t && t.length ? $d(t) : [];
}
function Tp(t, e) {
  return t && t.length ? $d(t, Kr(e)) : [];
}
function We(t) {
  return typeof t == "object" && t !== null && typeof t.$type == "string";
}
function St(t) {
  return typeof t == "object" && t !== null && typeof t.$refText == "string" && "ref" in t;
}
function un(t) {
  return typeof t == "object" && t !== null && typeof t.$refText == "string" && "items" in t;
}
function Rp(t) {
  return typeof t == "object" && t !== null && typeof t.name == "string" && typeof t.type == "string" && typeof t.path == "string";
}
function di(t) {
  return typeof t == "object" && t !== null && typeof t.info == "object" && typeof t.message == "string";
}
class xd {
  constructor() {
    this.subtypes = {}, this.allSubtypes = {};
  }
  getAllTypes() {
    return Object.keys(this.types);
  }
  getReferenceType(e) {
    const n = this.types[e.container.$type];
    if (!n)
      throw new Error(`Type ${e.container.$type || "undefined"} not found.`);
    const r = n.properties[e.property]?.referenceType;
    if (!r)
      throw new Error(`Property ${e.property || "undefined"} of type ${e.container.$type} is not a reference.`);
    return r;
  }
  getTypeMetaData(e) {
    const n = this.types[e];
    return n || {
      name: e,
      properties: {},
      superTypes: []
    };
  }
  isInstance(e, n) {
    return We(e) && this.isSubtype(e.$type, n);
  }
  isSubtype(e, n) {
    if (e === n)
      return !0;
    let r = this.subtypes[e];
    r || (r = this.subtypes[e] = {});
    const i = r[n];
    if (i !== void 0)
      return i;
    {
      const s = this.types[e], a = s ? s.superTypes.some((o) => this.isSubtype(o, n)) : !1;
      return r[n] = a, a;
    }
  }
  getAllSubTypes(e) {
    const n = this.allSubtypes[e];
    if (n)
      return n;
    {
      const r = this.getAllTypes(), i = [];
      for (const s of r)
        this.isSubtype(s, e) && i.push(s);
      return this.allSubtypes[e] = i, i;
    }
  }
}
function zi(t) {
  return typeof t == "object" && t !== null && Array.isArray(t.content);
}
function Dd(t) {
  return typeof t == "object" && t !== null && typeof t.tokenType == "object";
}
function Md(t) {
  return zi(t) && typeof t.fullText == "string";
}
class Ue {
  constructor(e, n) {
    this.startFn = e, this.nextFn = n;
  }
  iterator() {
    const e = {
      state: this.startFn(),
      next: () => this.nextFn(e.state),
      [Symbol.iterator]: () => e
    };
    return e;
  }
  [Symbol.iterator]() {
    return this.iterator();
  }
  isEmpty() {
    return !!this.iterator().next().done;
  }
  count() {
    const e = this.iterator();
    let n = 0, r = e.next();
    for (; !r.done; )
      n++, r = e.next();
    return n;
  }
  toArray() {
    const e = [], n = this.iterator();
    let r;
    do
      r = n.next(), r.value !== void 0 && e.push(r.value);
    while (!r.done);
    return e;
  }
  toSet() {
    return new Set(this);
  }
  toMap(e, n) {
    const r = this.map((i) => [
      e ? e(i) : i,
      n ? n(i) : i
    ]);
    return new Map(r);
  }
  toString() {
    return this.join();
  }
  concat(e) {
    return new Ue(() => ({ first: this.startFn(), firstDone: !1, iterator: e[Symbol.iterator]() }), (n) => {
      let r;
      if (!n.firstDone) {
        do
          if (r = this.nextFn(n.first), !r.done)
            return r;
        while (!r.done);
        n.firstDone = !0;
      }
      do
        if (r = n.iterator.next(), !r.done)
          return r;
      while (!r.done);
      return lt;
    });
  }
  join(e = ",") {
    const n = this.iterator();
    let r = "", i, s = !1;
    do
      i = n.next(), i.done || (s && (r += e), r += vp(i.value)), s = !0;
    while (!i.done);
    return r;
  }
  indexOf(e, n = 0) {
    const r = this.iterator();
    let i = 0, s = r.next();
    for (; !s.done; ) {
      if (i >= n && s.value === e)
        return i;
      s = r.next(), i++;
    }
    return -1;
  }
  every(e) {
    const n = this.iterator();
    let r = n.next();
    for (; !r.done; ) {
      if (!e(r.value))
        return !1;
      r = n.next();
    }
    return !0;
  }
  some(e) {
    const n = this.iterator();
    let r = n.next();
    for (; !r.done; ) {
      if (e(r.value))
        return !0;
      r = n.next();
    }
    return !1;
  }
  forEach(e) {
    const n = this.iterator();
    let r = 0, i = n.next();
    for (; !i.done; )
      e(i.value, r), i = n.next(), r++;
  }
  map(e) {
    return new Ue(this.startFn, (n) => {
      const { done: r, value: i } = this.nextFn(n);
      return r ? lt : { done: !1, value: e(i) };
    });
  }
  filter(e) {
    return new Ue(this.startFn, (n) => {
      let r;
      do
        if (r = this.nextFn(n), !r.done && e(r.value))
          return r;
      while (!r.done);
      return lt;
    });
  }
  nonNullable() {
    return this.filter((e) => e != null);
  }
  reduce(e, n) {
    const r = this.iterator();
    let i = n, s = r.next();
    for (; !s.done; )
      i === void 0 ? i = s.value : i = e(i, s.value), s = r.next();
    return i;
  }
  reduceRight(e, n) {
    return this.recursiveReduce(this.iterator(), e, n);
  }
  recursiveReduce(e, n, r) {
    const i = e.next();
    if (i.done)
      return r;
    const s = this.recursiveReduce(e, n, r);
    return s === void 0 ? i.value : n(s, i.value);
  }
  find(e) {
    const n = this.iterator();
    let r = n.next();
    for (; !r.done; ) {
      if (e(r.value))
        return r.value;
      r = n.next();
    }
  }
  findIndex(e) {
    const n = this.iterator();
    let r = 0, i = n.next();
    for (; !i.done; ) {
      if (e(i.value))
        return r;
      i = n.next(), r++;
    }
    return -1;
  }
  includes(e) {
    const n = this.iterator();
    let r = n.next();
    for (; !r.done; ) {
      if (r.value === e)
        return !0;
      r = n.next();
    }
    return !1;
  }
  flatMap(e) {
    return new Ue(() => ({ this: this.startFn() }), (n) => {
      do {
        if (n.iterator) {
          const s = n.iterator.next();
          if (s.done)
            n.iterator = void 0;
          else
            return s;
        }
        const { done: r, value: i } = this.nextFn(n.this);
        if (!r) {
          const s = e(i);
          if (sa(s))
            n.iterator = s[Symbol.iterator]();
          else
            return { done: !1, value: s };
        }
      } while (n.iterator);
      return lt;
    });
  }
  flat(e) {
    if (e === void 0 && (e = 1), e <= 0)
      return this;
    const n = e > 1 ? this.flat(e - 1) : this;
    return new Ue(() => ({ this: n.startFn() }), (r) => {
      do {
        if (r.iterator) {
          const a = r.iterator.next();
          if (a.done)
            r.iterator = void 0;
          else
            return a;
        }
        const { done: i, value: s } = n.nextFn(r.this);
        if (!i)
          if (sa(s))
            r.iterator = s[Symbol.iterator]();
          else
            return { done: !1, value: s };
      } while (r.iterator);
      return lt;
    });
  }
  head() {
    const n = this.iterator().next();
    if (!n.done)
      return n.value;
  }
  tail(e = 1) {
    return new Ue(() => {
      const n = this.startFn();
      for (let r = 0; r < e; r++)
        if (this.nextFn(n).done)
          return n;
      return n;
    }, this.nextFn);
  }
  limit(e) {
    return new Ue(() => ({ size: 0, state: this.startFn() }), (n) => (n.size++, n.size > e ? lt : this.nextFn(n.state)));
  }
  distinct(e) {
    return new Ue(() => ({ set: /* @__PURE__ */ new Set(), internalState: this.startFn() }), (n) => {
      let r;
      do
        if (r = this.nextFn(n.internalState), !r.done) {
          const i = e ? e(r.value) : r.value;
          if (!n.set.has(i))
            return n.set.add(i), r;
        }
      while (!r.done);
      return lt;
    });
  }
  exclude(e, n) {
    const r = /* @__PURE__ */ new Set();
    for (const i of e) {
      const s = n ? n(i) : i;
      r.add(s);
    }
    return this.filter((i) => {
      const s = n ? n(i) : i;
      return !r.has(s);
    });
  }
}
function vp(t) {
  return typeof t == "string" ? t : typeof t > "u" ? "undefined" : typeof t.toString == "function" ? t.toString() : Object.prototype.toString.call(t);
}
function sa(t) {
  return !!t && typeof t[Symbol.iterator] == "function";
}
const Fd = new Ue(() => {
}, () => lt), lt = Object.freeze({ done: !0, value: void 0 });
function me(...t) {
  if (t.length === 1) {
    const e = t[0];
    if (e instanceof Ue)
      return e;
    if (sa(e))
      return new Ue(() => e[Symbol.iterator](), (n) => n.next());
    if (typeof e.length == "number")
      return new Ue(() => ({ index: 0 }), (n) => n.index < e.length ? { done: !1, value: e[n.index++] } : lt);
  }
  return t.length > 1 ? new Ue(() => ({ collIndex: 0, arrIndex: 0 }), (e) => {
    do {
      if (e.iterator) {
        const n = e.iterator.next();
        if (!n.done)
          return n;
        e.iterator = void 0;
      }
      if (e.array) {
        if (e.arrIndex < e.array.length)
          return { done: !1, value: e.array[e.arrIndex++] };
        e.array = void 0, e.arrIndex = 0;
      }
      if (e.collIndex < t.length) {
        const n = t[e.collIndex++];
        sa(n) ? e.iterator = n[Symbol.iterator]() : n && typeof n.length == "number" && (e.array = n);
      }
    } while (e.iterator || e.array || e.collIndex < t.length);
    return lt;
  }) : Fd;
}
class il extends Ue {
  constructor(e, n, r) {
    super(() => ({
      iterators: r?.includeRoot ? [[e][Symbol.iterator]()] : [n(e)[Symbol.iterator]()],
      pruned: !1
    }), (i) => {
      for (i.pruned && (i.iterators.pop(), i.pruned = !1); i.iterators.length > 0; ) {
        const a = i.iterators[i.iterators.length - 1].next();
        if (a.done)
          i.iterators.pop();
        else
          return i.iterators.push(n(a.value)[Symbol.iterator]()), a;
      }
      return lt;
    });
  }
  iterator() {
    const e = {
      state: this.startFn(),
      next: () => this.nextFn(e.state),
      prune: () => {
        e.state.pruned = !0;
      },
      [Symbol.iterator]: () => e
    };
    return e;
  }
}
var yo;
(function(t) {
  function e(s) {
    return s.reduce((a, o) => a + o, 0);
  }
  t.sum = e;
  function n(s) {
    return s.reduce((a, o) => a * o, 0);
  }
  t.product = n;
  function r(s) {
    return s.reduce((a, o) => Math.min(a, o));
  }
  t.min = r;
  function i(s) {
    return s.reduce((a, o) => Math.max(a, o));
  }
  t.max = i;
})(yo || (yo = {}));
function To(t, e = {}) {
  for (const [n, r] of Object.entries(t))
    n.startsWith("$") || (Array.isArray(r) ? r.forEach((i, s) => {
      We(i) && (i.$container = t, i.$containerProperty = n, i.$containerIndex = s, e.deep && To(i, e));
    }) : We(r) && (r.$container = t, r.$containerProperty = n, e.deep && To(r, e)));
}
function Ia(t, e) {
  let n = t;
  for (; n; ) {
    if (e(n))
      return n;
    n = n.$container;
  }
}
function Qt(t) {
  const n = Bs(t).$document;
  if (!n)
    throw new Error("AST node has no document.");
  return n;
}
function Bs(t) {
  for (; t.$container; )
    t = t.$container;
  return t;
}
function Pl(t) {
  return St(t) ? t.ref ? [t.ref] : [] : un(t) ? t.items.map((e) => e.ref) : [];
}
function sl(t, e) {
  if (!t)
    throw new Error("Node must be an AstNode.");
  const n = e?.range;
  return new Ue(() => ({
    keys: Object.keys(t),
    keyIndex: 0,
    arrayIndex: 0
  }), (r) => {
    for (; r.keyIndex < r.keys.length; ) {
      const i = r.keys[r.keyIndex];
      if (!i.startsWith("$")) {
        const s = t[i];
        if (We(s)) {
          if (r.keyIndex++, $l(s, n))
            return { done: !1, value: s };
        } else if (Array.isArray(s)) {
          for (; r.arrayIndex < s.length; ) {
            const a = r.arrayIndex++, o = s[a];
            if (We(o) && $l(o, n))
              return { done: !1, value: o };
          }
          r.arrayIndex = 0;
        }
      }
      r.keyIndex++;
    }
    return lt;
  });
}
function ns(t, e) {
  if (!t)
    throw new Error("Root node must be an AstNode.");
  return new il(t, (n) => sl(n, e));
}
function Zt(t, e) {
  if (!t)
    throw new Error("Root node must be an AstNode.");
  return new il(t, (n) => sl(n, e), { includeRoot: !0 });
}
function $l(t, e) {
  if (!e)
    return !0;
  const n = t.$cstNode?.range;
  return n ? zp(n, e) : !1;
}
function aa(t) {
  return new Ue(() => ({
    keys: Object.keys(t),
    keyIndex: 0,
    arrayIndex: 0
  }), (e) => {
    for (; e.keyIndex < e.keys.length; ) {
      const n = e.keys[e.keyIndex];
      if (!n.startsWith("$")) {
        const r = t[n];
        if (St(r) || un(r))
          return e.keyIndex++, { done: !1, value: { reference: r, container: t, property: n } };
        if (Array.isArray(r)) {
          for (; e.arrayIndex < r.length; ) {
            const i = e.arrayIndex++, s = r[i];
            if (St(s) || un(r))
              return { done: !1, value: { reference: s, container: t, property: n, index: i } };
          }
          e.arrayIndex = 0;
        }
      }
      e.keyIndex++;
    }
    return lt;
  });
}
function Ep(t, e) {
  const n = t.getTypeMetaData(e.$type), r = e;
  for (const i of Object.values(n.properties))
    i.defaultValue !== void 0 && r[i.name] === void 0 && (r[i.name] = Gd(i.defaultValue));
}
function Gd(t) {
  return Array.isArray(t) ? [...t.map(Gd)] : t;
}
const ct = {
  $type: "AbstractElement",
  cardinality: "cardinality"
};
function Ap(t) {
  return ee.isInstance(t, ct.$type);
}
const Ws = {
  $type: "AbstractParserRule"
};
function rs(t) {
  return ee.isInstance(t, Ws.$type);
}
const _s = {
  $type: "AbstractRule"
}, Et = {
  $type: "AbstractType"
}, Ln = {
  $type: "Action",
  cardinality: "cardinality",
  feature: "feature",
  inferredType: "inferredType",
  operator: "operator",
  type: "type"
};
function Pa(t) {
  return ee.isInstance(t, Ln.$type);
}
const Vs = {
  $type: "Alternatives",
  cardinality: "cardinality",
  elements: "elements"
};
function Ud(t) {
  return ee.isInstance(t, Vs.$type);
}
const Ll = {
  $type: "ArrayLiteral",
  elements: "elements"
}, Ol = {
  $type: "ArrayType",
  elementType: "elementType"
}, On = {
  $type: "Assignment",
  cardinality: "cardinality",
  feature: "feature",
  operator: "operator",
  predicate: "predicate",
  terminal: "terminal"
};
function jn(t) {
  return ee.isInstance(t, On.$type);
}
const Ro = {
  $type: "BooleanLiteral",
  true: "true"
};
function Sp(t) {
  return ee.isInstance(t, Ro.$type);
}
const xn = {
  $type: "CharacterRange",
  cardinality: "cardinality",
  left: "left",
  lookahead: "lookahead",
  parenthesized: "parenthesized",
  right: "right"
};
function kp(t) {
  return ee.isInstance(t, xn.$type);
}
const tr = {
  $type: "Condition"
}, Ks = {
  $type: "Conjunction",
  left: "left",
  right: "right"
};
function Cp(t) {
  return ee.isInstance(t, Ks.$type);
}
const Dn = {
  $type: "CrossReference",
  cardinality: "cardinality",
  deprecatedSyntax: "deprecatedSyntax",
  isMulti: "isMulti",
  terminal: "terminal",
  type: "type"
};
function $a(t) {
  return ee.isInstance(t, Dn.$type);
}
const Hs = {
  $type: "Disjunction",
  left: "left",
  right: "right"
};
function Np(t) {
  return ee.isInstance(t, Hs.$type);
}
const vo = {
  $type: "EndOfFile",
  cardinality: "cardinality"
};
function wp(t) {
  return ee.isInstance(t, vo.$type);
}
const En = {
  $type: "Grammar",
  imports: "imports",
  interfaces: "interfaces",
  isDeclared: "isDeclared",
  name: "name",
  rules: "rules",
  types: "types"
}, xl = {
  $type: "GrammarImport",
  path: "path"
}, or = {
  $type: "Group",
  cardinality: "cardinality",
  elements: "elements",
  guardCondition: "guardCondition",
  predicate: "predicate"
};
function al(t) {
  return ee.isInstance(t, or.$type);
}
const Eo = {
  $type: "InferredType",
  name: "name"
};
function qd(t) {
  return ee.isInstance(t, Eo.$type);
}
const Vt = {
  $type: "InfixRule",
  call: "call",
  dataType: "dataType",
  inferredType: "inferredType",
  name: "name",
  operators: "operators",
  parameters: "parameters",
  returnType: "returnType"
};
function oa(t) {
  return ee.isInstance(t, Vt.$type);
}
const Va = {
  $type: "InfixRuleOperatorList",
  associativity: "associativity",
  operators: "operators"
}, Dl = {
  $type: "InfixRuleOperators",
  precedences: "precedences"
}, $i = {
  $type: "Interface",
  attributes: "attributes",
  name: "name",
  superTypes: "superTypes"
};
function bp(t) {
  return ee.isInstance(t, $i.$type);
}
const Li = {
  $type: "Keyword",
  cardinality: "cardinality",
  predicate: "predicate",
  value: "value"
};
function zn(t) {
  return ee.isInstance(t, Li.$type);
}
const Is = {
  $type: "NamedArgument",
  calledByName: "calledByName",
  parameter: "parameter",
  value: "value"
}, cr = {
  $type: "NegatedToken",
  cardinality: "cardinality",
  lookahead: "lookahead",
  parenthesized: "parenthesized",
  terminal: "terminal"
};
function _p(t) {
  return ee.isInstance(t, cr.$type);
}
const Ao = {
  $type: "Negation",
  value: "value"
};
function Ip(t) {
  return ee.isInstance(t, Ao.$type);
}
const Ml = {
  $type: "NumberLiteral",
  value: "value"
}, Ps = {
  $type: "Parameter",
  name: "name"
}, So = {
  $type: "ParameterReference",
  parameter: "parameter"
};
function Pp(t) {
  return ee.isInstance(t, So.$type);
}
const Pt = {
  $type: "ParserRule",
  dataType: "dataType",
  definition: "definition",
  entry: "entry",
  fragment: "fragment",
  inferredType: "inferredType",
  name: "name",
  parameters: "parameters",
  returnType: "returnType"
};
function sn(t) {
  return ee.isInstance(t, Pt.$type);
}
const Ka = {
  $type: "ReferenceType",
  isMulti: "isMulti",
  referenceType: "referenceType"
}, lr = {
  $type: "RegexToken",
  cardinality: "cardinality",
  lookahead: "lookahead",
  parenthesized: "parenthesized",
  regex: "regex"
};
function $p(t) {
  return ee.isInstance(t, lr.$type);
}
const ko = {
  $type: "ReturnType",
  name: "name"
};
function Lp(t) {
  return ee.isInstance(t, ko.$type);
}
const ur = {
  $type: "RuleCall",
  arguments: "arguments",
  cardinality: "cardinality",
  predicate: "predicate",
  rule: "rule"
};
function Bn(t) {
  return ee.isInstance(t, ur.$type);
}
const Oi = {
  $type: "SimpleType",
  primitiveType: "primitiveType",
  stringType: "stringType",
  typeRef: "typeRef"
};
function Op(t) {
  return ee.isInstance(t, Oi.$type);
}
const Fl = {
  $type: "StringLiteral",
  value: "value"
}, dr = {
  $type: "TerminalAlternatives",
  cardinality: "cardinality",
  elements: "elements",
  lookahead: "lookahead",
  parenthesized: "parenthesized"
};
function xp(t) {
  return ee.isInstance(t, dr.$type);
}
const gt = {
  $type: "TerminalElement",
  cardinality: "cardinality",
  lookahead: "lookahead",
  parenthesized: "parenthesized"
}, fr = {
  $type: "TerminalGroup",
  cardinality: "cardinality",
  elements: "elements",
  lookahead: "lookahead",
  parenthesized: "parenthesized"
};
function Dp(t) {
  return ee.isInstance(t, fr.$type);
}
const ln = {
  $type: "TerminalRule",
  definition: "definition",
  fragment: "fragment",
  hidden: "hidden",
  name: "name",
  type: "type"
};
function an(t) {
  return ee.isInstance(t, ln.$type);
}
const hr = {
  $type: "TerminalRuleCall",
  cardinality: "cardinality",
  lookahead: "lookahead",
  parenthesized: "parenthesized",
  rule: "rule"
};
function Mp(t) {
  return ee.isInstance(t, hr.$type);
}
const Ys = {
  $type: "Type",
  name: "name",
  type: "type"
};
function Fp(t) {
  return ee.isInstance(t, Ys.$type);
}
const fi = {
  $type: "TypeAttribute",
  defaultValue: "defaultValue",
  isOptional: "isOptional",
  name: "name",
  type: "type"
}, hi = {
  $type: "TypeDefinition"
}, Gl = {
  $type: "UnionType",
  types: "types"
}, Xs = {
  $type: "UnorderedGroup",
  cardinality: "cardinality",
  elements: "elements"
};
function jd(t) {
  return ee.isInstance(t, Xs.$type);
}
const pr = {
  $type: "UntilToken",
  cardinality: "cardinality",
  lookahead: "lookahead",
  parenthesized: "parenthesized",
  terminal: "terminal"
};
function Gp(t) {
  return ee.isInstance(t, pr.$type);
}
const pi = {
  $type: "ValueLiteral"
}, xi = {
  $type: "Wildcard",
  cardinality: "cardinality",
  lookahead: "lookahead",
  parenthesized: "parenthesized"
};
function Up(t) {
  return ee.isInstance(t, xi.$type);
}
class zd extends xd {
  constructor() {
    super(...arguments), this.types = {
      AbstractElement: {
        name: ct.$type,
        properties: {
          cardinality: {
            name: ct.cardinality
          }
        },
        superTypes: []
      },
      AbstractParserRule: {
        name: Ws.$type,
        properties: {},
        superTypes: [_s.$type, Et.$type]
      },
      AbstractRule: {
        name: _s.$type,
        properties: {},
        superTypes: []
      },
      AbstractType: {
        name: Et.$type,
        properties: {},
        superTypes: []
      },
      Action: {
        name: Ln.$type,
        properties: {
          cardinality: {
            name: Ln.cardinality
          },
          feature: {
            name: Ln.feature
          },
          inferredType: {
            name: Ln.inferredType
          },
          operator: {
            name: Ln.operator
          },
          type: {
            name: Ln.type,
            referenceType: Et.$type
          }
        },
        superTypes: [ct.$type]
      },
      Alternatives: {
        name: Vs.$type,
        properties: {
          cardinality: {
            name: Vs.cardinality
          },
          elements: {
            name: Vs.elements,
            defaultValue: []
          }
        },
        superTypes: [ct.$type]
      },
      ArrayLiteral: {
        name: Ll.$type,
        properties: {
          elements: {
            name: Ll.elements,
            defaultValue: []
          }
        },
        superTypes: [pi.$type]
      },
      ArrayType: {
        name: Ol.$type,
        properties: {
          elementType: {
            name: Ol.elementType
          }
        },
        superTypes: [hi.$type]
      },
      Assignment: {
        name: On.$type,
        properties: {
          cardinality: {
            name: On.cardinality
          },
          feature: {
            name: On.feature
          },
          operator: {
            name: On.operator
          },
          predicate: {
            name: On.predicate
          },
          terminal: {
            name: On.terminal
          }
        },
        superTypes: [ct.$type]
      },
      BooleanLiteral: {
        name: Ro.$type,
        properties: {
          true: {
            name: Ro.true,
            defaultValue: !1
          }
        },
        superTypes: [tr.$type, pi.$type]
      },
      CharacterRange: {
        name: xn.$type,
        properties: {
          cardinality: {
            name: xn.cardinality
          },
          left: {
            name: xn.left
          },
          lookahead: {
            name: xn.lookahead
          },
          parenthesized: {
            name: xn.parenthesized,
            defaultValue: !1
          },
          right: {
            name: xn.right
          }
        },
        superTypes: [gt.$type]
      },
      Condition: {
        name: tr.$type,
        properties: {},
        superTypes: []
      },
      Conjunction: {
        name: Ks.$type,
        properties: {
          left: {
            name: Ks.left
          },
          right: {
            name: Ks.right
          }
        },
        superTypes: [tr.$type]
      },
      CrossReference: {
        name: Dn.$type,
        properties: {
          cardinality: {
            name: Dn.cardinality
          },
          deprecatedSyntax: {
            name: Dn.deprecatedSyntax,
            defaultValue: !1
          },
          isMulti: {
            name: Dn.isMulti,
            defaultValue: !1
          },
          terminal: {
            name: Dn.terminal
          },
          type: {
            name: Dn.type,
            referenceType: Et.$type
          }
        },
        superTypes: [ct.$type]
      },
      Disjunction: {
        name: Hs.$type,
        properties: {
          left: {
            name: Hs.left
          },
          right: {
            name: Hs.right
          }
        },
        superTypes: [tr.$type]
      },
      EndOfFile: {
        name: vo.$type,
        properties: {
          cardinality: {
            name: vo.cardinality
          }
        },
        superTypes: [ct.$type]
      },
      Grammar: {
        name: En.$type,
        properties: {
          imports: {
            name: En.imports,
            defaultValue: []
          },
          interfaces: {
            name: En.interfaces,
            defaultValue: []
          },
          isDeclared: {
            name: En.isDeclared,
            defaultValue: !1
          },
          name: {
            name: En.name
          },
          rules: {
            name: En.rules,
            defaultValue: []
          },
          types: {
            name: En.types,
            defaultValue: []
          }
        },
        superTypes: []
      },
      GrammarImport: {
        name: xl.$type,
        properties: {
          path: {
            name: xl.path
          }
        },
        superTypes: []
      },
      Group: {
        name: or.$type,
        properties: {
          cardinality: {
            name: or.cardinality
          },
          elements: {
            name: or.elements,
            defaultValue: []
          },
          guardCondition: {
            name: or.guardCondition
          },
          predicate: {
            name: or.predicate
          }
        },
        superTypes: [ct.$type]
      },
      InferredType: {
        name: Eo.$type,
        properties: {
          name: {
            name: Eo.name
          }
        },
        superTypes: [Et.$type]
      },
      InfixRule: {
        name: Vt.$type,
        properties: {
          call: {
            name: Vt.call
          },
          dataType: {
            name: Vt.dataType
          },
          inferredType: {
            name: Vt.inferredType
          },
          name: {
            name: Vt.name
          },
          operators: {
            name: Vt.operators
          },
          parameters: {
            name: Vt.parameters,
            defaultValue: []
          },
          returnType: {
            name: Vt.returnType,
            referenceType: Et.$type
          }
        },
        superTypes: [Ws.$type]
      },
      InfixRuleOperatorList: {
        name: Va.$type,
        properties: {
          associativity: {
            name: Va.associativity
          },
          operators: {
            name: Va.operators,
            defaultValue: []
          }
        },
        superTypes: []
      },
      InfixRuleOperators: {
        name: Dl.$type,
        properties: {
          precedences: {
            name: Dl.precedences,
            defaultValue: []
          }
        },
        superTypes: []
      },
      Interface: {
        name: $i.$type,
        properties: {
          attributes: {
            name: $i.attributes,
            defaultValue: []
          },
          name: {
            name: $i.name
          },
          superTypes: {
            name: $i.superTypes,
            defaultValue: [],
            referenceType: Et.$type
          }
        },
        superTypes: [Et.$type]
      },
      Keyword: {
        name: Li.$type,
        properties: {
          cardinality: {
            name: Li.cardinality
          },
          predicate: {
            name: Li.predicate
          },
          value: {
            name: Li.value
          }
        },
        superTypes: [ct.$type]
      },
      NamedArgument: {
        name: Is.$type,
        properties: {
          calledByName: {
            name: Is.calledByName,
            defaultValue: !1
          },
          parameter: {
            name: Is.parameter,
            referenceType: Ps.$type
          },
          value: {
            name: Is.value
          }
        },
        superTypes: []
      },
      NegatedToken: {
        name: cr.$type,
        properties: {
          cardinality: {
            name: cr.cardinality
          },
          lookahead: {
            name: cr.lookahead
          },
          parenthesized: {
            name: cr.parenthesized,
            defaultValue: !1
          },
          terminal: {
            name: cr.terminal
          }
        },
        superTypes: [gt.$type]
      },
      Negation: {
        name: Ao.$type,
        properties: {
          value: {
            name: Ao.value
          }
        },
        superTypes: [tr.$type]
      },
      NumberLiteral: {
        name: Ml.$type,
        properties: {
          value: {
            name: Ml.value
          }
        },
        superTypes: [pi.$type]
      },
      Parameter: {
        name: Ps.$type,
        properties: {
          name: {
            name: Ps.name
          }
        },
        superTypes: []
      },
      ParameterReference: {
        name: So.$type,
        properties: {
          parameter: {
            name: So.parameter,
            referenceType: Ps.$type
          }
        },
        superTypes: [tr.$type]
      },
      ParserRule: {
        name: Pt.$type,
        properties: {
          dataType: {
            name: Pt.dataType
          },
          definition: {
            name: Pt.definition
          },
          entry: {
            name: Pt.entry,
            defaultValue: !1
          },
          fragment: {
            name: Pt.fragment,
            defaultValue: !1
          },
          inferredType: {
            name: Pt.inferredType
          },
          name: {
            name: Pt.name
          },
          parameters: {
            name: Pt.parameters,
            defaultValue: []
          },
          returnType: {
            name: Pt.returnType,
            referenceType: Et.$type
          }
        },
        superTypes: [Ws.$type]
      },
      ReferenceType: {
        name: Ka.$type,
        properties: {
          isMulti: {
            name: Ka.isMulti,
            defaultValue: !1
          },
          referenceType: {
            name: Ka.referenceType
          }
        },
        superTypes: [hi.$type]
      },
      RegexToken: {
        name: lr.$type,
        properties: {
          cardinality: {
            name: lr.cardinality
          },
          lookahead: {
            name: lr.lookahead
          },
          parenthesized: {
            name: lr.parenthesized,
            defaultValue: !1
          },
          regex: {
            name: lr.regex
          }
        },
        superTypes: [gt.$type]
      },
      ReturnType: {
        name: ko.$type,
        properties: {
          name: {
            name: ko.name
          }
        },
        superTypes: []
      },
      RuleCall: {
        name: ur.$type,
        properties: {
          arguments: {
            name: ur.arguments,
            defaultValue: []
          },
          cardinality: {
            name: ur.cardinality
          },
          predicate: {
            name: ur.predicate
          },
          rule: {
            name: ur.rule,
            referenceType: _s.$type
          }
        },
        superTypes: [ct.$type]
      },
      SimpleType: {
        name: Oi.$type,
        properties: {
          primitiveType: {
            name: Oi.primitiveType
          },
          stringType: {
            name: Oi.stringType
          },
          typeRef: {
            name: Oi.typeRef,
            referenceType: Et.$type
          }
        },
        superTypes: [hi.$type]
      },
      StringLiteral: {
        name: Fl.$type,
        properties: {
          value: {
            name: Fl.value
          }
        },
        superTypes: [pi.$type]
      },
      TerminalAlternatives: {
        name: dr.$type,
        properties: {
          cardinality: {
            name: dr.cardinality
          },
          elements: {
            name: dr.elements,
            defaultValue: []
          },
          lookahead: {
            name: dr.lookahead
          },
          parenthesized: {
            name: dr.parenthesized,
            defaultValue: !1
          }
        },
        superTypes: [gt.$type]
      },
      TerminalElement: {
        name: gt.$type,
        properties: {
          cardinality: {
            name: gt.cardinality
          },
          lookahead: {
            name: gt.lookahead
          },
          parenthesized: {
            name: gt.parenthesized,
            defaultValue: !1
          }
        },
        superTypes: [ct.$type]
      },
      TerminalGroup: {
        name: fr.$type,
        properties: {
          cardinality: {
            name: fr.cardinality
          },
          elements: {
            name: fr.elements,
            defaultValue: []
          },
          lookahead: {
            name: fr.lookahead
          },
          parenthesized: {
            name: fr.parenthesized,
            defaultValue: !1
          }
        },
        superTypes: [gt.$type]
      },
      TerminalRule: {
        name: ln.$type,
        properties: {
          definition: {
            name: ln.definition
          },
          fragment: {
            name: ln.fragment,
            defaultValue: !1
          },
          hidden: {
            name: ln.hidden,
            defaultValue: !1
          },
          name: {
            name: ln.name
          },
          type: {
            name: ln.type
          }
        },
        superTypes: [_s.$type]
      },
      TerminalRuleCall: {
        name: hr.$type,
        properties: {
          cardinality: {
            name: hr.cardinality
          },
          lookahead: {
            name: hr.lookahead
          },
          parenthesized: {
            name: hr.parenthesized,
            defaultValue: !1
          },
          rule: {
            name: hr.rule,
            referenceType: ln.$type
          }
        },
        superTypes: [gt.$type]
      },
      Type: {
        name: Ys.$type,
        properties: {
          name: {
            name: Ys.name
          },
          type: {
            name: Ys.type
          }
        },
        superTypes: [Et.$type]
      },
      TypeAttribute: {
        name: fi.$type,
        properties: {
          defaultValue: {
            name: fi.defaultValue
          },
          isOptional: {
            name: fi.isOptional,
            defaultValue: !1
          },
          name: {
            name: fi.name
          },
          type: {
            name: fi.type
          }
        },
        superTypes: []
      },
      TypeDefinition: {
        name: hi.$type,
        properties: {},
        superTypes: []
      },
      UnionType: {
        name: Gl.$type,
        properties: {
          types: {
            name: Gl.types,
            defaultValue: []
          }
        },
        superTypes: [hi.$type]
      },
      UnorderedGroup: {
        name: Xs.$type,
        properties: {
          cardinality: {
            name: Xs.cardinality
          },
          elements: {
            name: Xs.elements,
            defaultValue: []
          }
        },
        superTypes: [ct.$type]
      },
      UntilToken: {
        name: pr.$type,
        properties: {
          cardinality: {
            name: pr.cardinality
          },
          lookahead: {
            name: pr.lookahead
          },
          parenthesized: {
            name: pr.parenthesized,
            defaultValue: !1
          },
          terminal: {
            name: pr.terminal
          }
        },
        superTypes: [gt.$type]
      },
      ValueLiteral: {
        name: pi.$type,
        properties: {},
        superTypes: []
      },
      Wildcard: {
        name: xi.$type,
        properties: {
          cardinality: {
            name: xi.cardinality
          },
          lookahead: {
            name: xi.lookahead
          },
          parenthesized: {
            name: xi.parenthesized,
            defaultValue: !1
          }
        },
        superTypes: [gt.$type]
      }
    };
  }
}
const ee = new zd();
function Co(t) {
  return new il(t, (e) => zi(e) ? e.content : [], { includeRoot: !0 });
}
function qp(t, e) {
  for (; t.container; )
    if (t = t.container, t === e)
      return !0;
  return !1;
}
function No(t) {
  return {
    start: {
      character: t.startColumn - 1,
      line: t.startLine - 1
    },
    end: {
      character: t.endColumn,
      // endColumn uses the correct index
      line: t.endLine - 1
    }
  };
}
function ca(t) {
  if (!t)
    return;
  const { offset: e, end: n, range: r } = t;
  return {
    range: r,
    offset: e,
    end: n,
    length: n - e
  };
}
var Xt;
(function(t) {
  t[t.Before = 0] = "Before", t[t.After = 1] = "After", t[t.OverlapFront = 2] = "OverlapFront", t[t.OverlapBack = 3] = "OverlapBack", t[t.Inside = 4] = "Inside", t[t.Outside = 5] = "Outside";
})(Xt || (Xt = {}));
function jp(t, e) {
  if (t.end.line < e.start.line || t.end.line === e.start.line && t.end.character <= e.start.character)
    return Xt.Before;
  if (t.start.line > e.end.line || t.start.line === e.end.line && t.start.character >= e.end.character)
    return Xt.After;
  const n = t.start.line > e.start.line || t.start.line === e.start.line && t.start.character >= e.start.character, r = t.end.line < e.end.line || t.end.line === e.end.line && t.end.character <= e.end.character;
  return n && r ? Xt.Inside : n ? Xt.OverlapBack : r ? Xt.OverlapFront : Xt.Outside;
}
function zp(t, e) {
  return jp(t, e) > Xt.After;
}
const Bp = /^[\w\p{L}]$/u;
function Wp(t, e) {
  if (t) {
    const n = Vp(t, !0);
    if (n && Ul(n, e))
      return n;
    if (Md(t)) {
      const r = t.content.findIndex((i) => !i.hidden);
      for (let i = r - 1; i >= 0; i--) {
        const s = t.content[i];
        if (Ul(s, e))
          return s;
      }
    }
  }
}
function Ul(t, e) {
  return Dd(t) && e.includes(t.tokenType.name);
}
function Vp(t, e = !0) {
  for (; t.container; ) {
    const n = t.container;
    let r = n.content.indexOf(t);
    for (; r > 0; ) {
      r--;
      const i = n.content[r];
      if (e || !i.hidden)
        return i;
    }
    t = n;
  }
}
class Bd extends Error {
  constructor(e, n) {
    super(e ? `${n} at ${e.range.start.line}:${e.range.start.character}` : n);
  }
}
function is(t, e = "Error: Got unexpected value.") {
  throw new Error(e);
}
function W(t) {
  return t.charCodeAt(0);
}
function Ha(t, e) {
  Array.isArray(t) ? t.forEach(function(n) {
    e.push(n);
  }) : e.push(t);
}
function mi(t, e) {
  if (t[e] === !0)
    throw "duplicate flag " + e;
  t[e], t[e] = !0;
}
function nr(t) {
  if (t === void 0)
    throw Error("Internal Error - Should never get here!");
  return !0;
}
function Kp() {
  throw Error("Internal Error - Should never get here!");
}
function ql(t) {
  return t.type === "Character";
}
const la = [];
for (let t = W("0"); t <= W("9"); t++)
  la.push(t);
const ua = [W("_")].concat(la);
for (let t = W("a"); t <= W("z"); t++)
  ua.push(t);
for (let t = W("A"); t <= W("Z"); t++)
  ua.push(t);
const jl = [
  W(" "),
  W("\f"),
  W(`
`),
  W("\r"),
  W("	"),
  W("\v"),
  W("	"),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W(" "),
  W("\u2028"),
  W("\u2029"),
  W(" "),
  W(" "),
  W("　"),
  W("\uFEFF")
], Hp = /[0-9a-fA-F]/, $s = /[0-9]/, Yp = /[1-9]/;
class Wd {
  constructor() {
    this.idx = 0, this.input = "", this.groupIdx = 0;
  }
  saveState() {
    return {
      idx: this.idx,
      input: this.input,
      groupIdx: this.groupIdx
    };
  }
  restoreState(e) {
    this.idx = e.idx, this.input = e.input, this.groupIdx = e.groupIdx;
  }
  pattern(e) {
    this.idx = 0, this.input = e, this.groupIdx = 0, this.consumeChar("/");
    const n = this.disjunction();
    this.consumeChar("/");
    const r = {
      type: "Flags",
      loc: { begin: this.idx, end: e.length },
      global: !1,
      ignoreCase: !1,
      multiLine: !1,
      unicode: !1,
      sticky: !1
    };
    for (; this.isRegExpFlag(); )
      switch (this.popChar()) {
        case "g":
          mi(r, "global");
          break;
        case "i":
          mi(r, "ignoreCase");
          break;
        case "m":
          mi(r, "multiLine");
          break;
        case "u":
          mi(r, "unicode");
          break;
        case "y":
          mi(r, "sticky");
          break;
      }
    if (this.idx !== this.input.length)
      throw Error("Redundant input: " + this.input.substring(this.idx));
    return {
      type: "Pattern",
      flags: r,
      value: n,
      loc: this.loc(0)
    };
  }
  disjunction() {
    const e = [], n = this.idx;
    for (e.push(this.alternative()); this.peekChar() === "|"; )
      this.consumeChar("|"), e.push(this.alternative());
    return { type: "Disjunction", value: e, loc: this.loc(n) };
  }
  alternative() {
    const e = [], n = this.idx;
    for (; this.isTerm(); )
      e.push(this.term());
    return { type: "Alternative", value: e, loc: this.loc(n) };
  }
  term() {
    return this.isAssertion() ? this.assertion() : this.atom();
  }
  assertion() {
    const e = this.idx;
    switch (this.popChar()) {
      case "^":
        return {
          type: "StartAnchor",
          loc: this.loc(e)
        };
      case "$":
        return { type: "EndAnchor", loc: this.loc(e) };
      // '\b' or '\B'
      case "\\":
        switch (this.popChar()) {
          case "b":
            return {
              type: "WordBoundary",
              loc: this.loc(e)
            };
          case "B":
            return {
              type: "NonWordBoundary",
              loc: this.loc(e)
            };
        }
        throw Error("Invalid Assertion Escape");
      // '(?=' or '(?!'
      case "(":
        this.consumeChar("?");
        let n;
        switch (this.popChar()) {
          case "=":
            n = "Lookahead";
            break;
          case "!":
            n = "NegativeLookahead";
            break;
          case "<": {
            switch (this.popChar()) {
              case "=":
                n = "Lookbehind";
                break;
              case "!":
                n = "NegativeLookbehind";
            }
            break;
          }
        }
        nr(n);
        const r = this.disjunction();
        return this.consumeChar(")"), {
          type: n,
          value: r,
          loc: this.loc(e)
        };
    }
    return Kp();
  }
  quantifier(e = !1) {
    let n;
    const r = this.idx;
    switch (this.popChar()) {
      case "*":
        n = {
          atLeast: 0,
          atMost: 1 / 0
        };
        break;
      case "+":
        n = {
          atLeast: 1,
          atMost: 1 / 0
        };
        break;
      case "?":
        n = {
          atLeast: 0,
          atMost: 1
        };
        break;
      case "{":
        const i = this.integerIncludingZero();
        switch (this.popChar()) {
          case "}":
            n = {
              atLeast: i,
              atMost: i
            };
            break;
          case ",":
            let s;
            this.isDigit() ? (s = this.integerIncludingZero(), n = {
              atLeast: i,
              atMost: s
            }) : n = {
              atLeast: i,
              atMost: 1 / 0
            }, this.consumeChar("}");
            break;
        }
        if (e === !0 && n === void 0)
          return;
        nr(n);
        break;
    }
    if (!(e === !0 && n === void 0) && nr(n))
      return this.peekChar(0) === "?" ? (this.consumeChar("?"), n.greedy = !1) : n.greedy = !0, n.type = "Quantifier", n.loc = this.loc(r), n;
  }
  atom() {
    let e;
    const n = this.idx;
    switch (this.peekChar()) {
      case ".":
        e = this.dotAll();
        break;
      case "\\":
        e = this.atomEscape();
        break;
      case "[":
        e = this.characterClass();
        break;
      case "(":
        e = this.group();
        break;
    }
    if (e === void 0 && this.isPatternCharacter() && (e = this.patternCharacter()), nr(e))
      return e.loc = this.loc(n), this.isQuantifier() && (e.quantifier = this.quantifier()), e;
  }
  dotAll() {
    return this.consumeChar("."), {
      type: "Set",
      complement: !0,
      value: [W(`
`), W("\r"), W("\u2028"), W("\u2029")]
    };
  }
  atomEscape() {
    switch (this.consumeChar("\\"), this.peekChar()) {
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9":
        return this.decimalEscapeAtom();
      case "d":
      case "D":
      case "s":
      case "S":
      case "w":
      case "W":
        return this.characterClassEscape();
      case "f":
      case "n":
      case "r":
      case "t":
      case "v":
        return this.controlEscapeAtom();
      case "c":
        return this.controlLetterEscapeAtom();
      case "0":
        return this.nulCharacterAtom();
      case "x":
        return this.hexEscapeSequenceAtom();
      case "u":
        return this.regExpUnicodeEscapeSequenceAtom();
      default:
        return this.identityEscapeAtom();
    }
  }
  decimalEscapeAtom() {
    return { type: "GroupBackReference", value: this.positiveInteger() };
  }
  characterClassEscape() {
    let e, n = !1;
    switch (this.popChar()) {
      case "d":
        e = la;
        break;
      case "D":
        e = la, n = !0;
        break;
      case "s":
        e = jl;
        break;
      case "S":
        e = jl, n = !0;
        break;
      case "w":
        e = ua;
        break;
      case "W":
        e = ua, n = !0;
        break;
    }
    if (nr(e))
      return { type: "Set", value: e, complement: n };
  }
  controlEscapeAtom() {
    let e;
    switch (this.popChar()) {
      case "f":
        e = W("\f");
        break;
      case "n":
        e = W(`
`);
        break;
      case "r":
        e = W("\r");
        break;
      case "t":
        e = W("	");
        break;
      case "v":
        e = W("\v");
        break;
    }
    if (nr(e))
      return { type: "Character", value: e };
  }
  controlLetterEscapeAtom() {
    this.consumeChar("c");
    const e = this.popChar();
    if (/[a-zA-Z]/.test(e) === !1)
      throw Error("Invalid ");
    return { type: "Character", value: e.toUpperCase().charCodeAt(0) - 64 };
  }
  nulCharacterAtom() {
    return this.consumeChar("0"), { type: "Character", value: W("\0") };
  }
  hexEscapeSequenceAtom() {
    return this.consumeChar("x"), this.parseHexDigits(2);
  }
  regExpUnicodeEscapeSequenceAtom() {
    return this.consumeChar("u"), this.parseHexDigits(4);
  }
  identityEscapeAtom() {
    const e = this.popChar();
    return { type: "Character", value: W(e) };
  }
  classPatternCharacterAtom() {
    switch (this.peekChar()) {
      // istanbul ignore next
      case `
`:
      // istanbul ignore next
      case "\r":
      // istanbul ignore next
      case "\u2028":
      // istanbul ignore next
      case "\u2029":
      // istanbul ignore next
      case "\\":
      // istanbul ignore next
      case "]":
        throw Error("TBD");
      default:
        const e = this.popChar();
        return { type: "Character", value: W(e) };
    }
  }
  characterClass() {
    const e = [];
    let n = !1;
    for (this.consumeChar("["), this.peekChar(0) === "^" && (this.consumeChar("^"), n = !0); this.isClassAtom(); ) {
      const r = this.classAtom();
      if (r.type, ql(r) && this.isRangeDash()) {
        this.consumeChar("-");
        const i = this.classAtom();
        if (i.type, ql(i)) {
          if (i.value < r.value)
            throw Error("Range out of order in character class");
          e.push({ from: r.value, to: i.value });
        } else
          Ha(r.value, e), e.push(W("-")), Ha(i.value, e);
      } else
        Ha(r.value, e);
    }
    return this.consumeChar("]"), { type: "Set", complement: n, value: e };
  }
  classAtom() {
    switch (this.peekChar()) {
      // istanbul ignore next
      case "]":
      // istanbul ignore next
      case `
`:
      // istanbul ignore next
      case "\r":
      // istanbul ignore next
      case "\u2028":
      // istanbul ignore next
      case "\u2029":
        throw Error("TBD");
      case "\\":
        return this.classEscape();
      default:
        return this.classPatternCharacterAtom();
    }
  }
  classEscape() {
    switch (this.consumeChar("\\"), this.peekChar()) {
      // Matches a backspace.
      // (Not to be confused with \b word boundary outside characterClass)
      case "b":
        return this.consumeChar("b"), { type: "Character", value: W("\b") };
      case "d":
      case "D":
      case "s":
      case "S":
      case "w":
      case "W":
        return this.characterClassEscape();
      case "f":
      case "n":
      case "r":
      case "t":
      case "v":
        return this.controlEscapeAtom();
      case "c":
        return this.controlLetterEscapeAtom();
      case "0":
        return this.nulCharacterAtom();
      case "x":
        return this.hexEscapeSequenceAtom();
      case "u":
        return this.regExpUnicodeEscapeSequenceAtom();
      default:
        return this.identityEscapeAtom();
    }
  }
  group() {
    let e = !0;
    this.consumeChar("("), this.peekChar(0) === "?" ? (this.consumeChar("?"), this.consumeChar(":"), e = !1) : this.groupIdx++;
    const n = this.disjunction();
    this.consumeChar(")");
    const r = {
      type: "Group",
      capturing: e,
      value: n
    };
    return e && (r.idx = this.groupIdx), r;
  }
  positiveInteger() {
    let e = this.popChar();
    if (Yp.test(e) === !1)
      throw Error("Expecting a positive integer");
    for (; $s.test(this.peekChar(0)); )
      e += this.popChar();
    return parseInt(e, 10);
  }
  integerIncludingZero() {
    let e = this.popChar();
    if ($s.test(e) === !1)
      throw Error("Expecting an integer");
    for (; $s.test(this.peekChar(0)); )
      e += this.popChar();
    return parseInt(e, 10);
  }
  patternCharacter() {
    const e = this.popChar();
    switch (e) {
      // istanbul ignore next
      case `
`:
      // istanbul ignore next
      case "\r":
      // istanbul ignore next
      case "\u2028":
      // istanbul ignore next
      case "\u2029":
      // istanbul ignore next
      case "^":
      // istanbul ignore next
      case "$":
      // istanbul ignore next
      case "\\":
      // istanbul ignore next
      case ".":
      // istanbul ignore next
      case "*":
      // istanbul ignore next
      case "+":
      // istanbul ignore next
      case "?":
      // istanbul ignore next
      case "(":
      // istanbul ignore next
      case ")":
      // istanbul ignore next
      case "[":
      // istanbul ignore next
      case "|":
        throw Error("TBD");
      default:
        return { type: "Character", value: W(e) };
    }
  }
  isRegExpFlag() {
    switch (this.peekChar(0)) {
      case "g":
      case "i":
      case "m":
      case "u":
      case "y":
        return !0;
      default:
        return !1;
    }
  }
  isRangeDash() {
    return this.peekChar() === "-" && this.isClassAtom(1);
  }
  isDigit() {
    return $s.test(this.peekChar(0));
  }
  isClassAtom(e = 0) {
    switch (this.peekChar(e)) {
      case "]":
      case `
`:
      case "\r":
      case "\u2028":
      case "\u2029":
        return !1;
      default:
        return !0;
    }
  }
  isTerm() {
    return this.isAtom() || this.isAssertion();
  }
  isAtom() {
    if (this.isPatternCharacter())
      return !0;
    switch (this.peekChar(0)) {
      case ".":
      case "\\":
      // atomEscape
      case "[":
      // characterClass
      // TODO: isAtom must be called before isAssertion - disambiguate
      case "(":
        return !0;
      default:
        return !1;
    }
  }
  isAssertion() {
    switch (this.peekChar(0)) {
      case "^":
      case "$":
        return !0;
      // '\b' or '\B'
      case "\\":
        switch (this.peekChar(1)) {
          case "b":
          case "B":
            return !0;
          default:
            return !1;
        }
      // '(?=' or '(?!' or `(?<=` or `(?<!`
      case "(":
        return this.peekChar(1) === "?" && (this.peekChar(2) === "=" || this.peekChar(2) === "!" || this.peekChar(2) === "<" && (this.peekChar(3) === "=" || this.peekChar(3) === "!"));
      default:
        return !1;
    }
  }
  isQuantifier() {
    const e = this.saveState();
    try {
      return this.quantifier(!0) !== void 0;
    } catch {
      return !1;
    } finally {
      this.restoreState(e);
    }
  }
  isPatternCharacter() {
    switch (this.peekChar()) {
      case "^":
      case "$":
      case "\\":
      case ".":
      case "*":
      case "+":
      case "?":
      case "(":
      case ")":
      case "[":
      case "|":
      case "/":
      case `
`:
      case "\r":
      case "\u2028":
      case "\u2029":
        return !1;
      default:
        return !0;
    }
  }
  parseHexDigits(e) {
    let n = "";
    for (let i = 0; i < e; i++) {
      const s = this.popChar();
      if (Hp.test(s) === !1)
        throw Error("Expecting a HexDecimal digits");
      n += s;
    }
    return { type: "Character", value: parseInt(n, 16) };
  }
  peekChar(e = 0) {
    return this.input[this.idx + e];
  }
  popChar() {
    const e = this.peekChar(0);
    return this.consumeChar(void 0), e;
  }
  consumeChar(e) {
    if (e !== void 0 && this.input[this.idx] !== e)
      throw Error("Expected: '" + e + "' but found: '" + this.input[this.idx] + "' at offset: " + this.idx);
    if (this.idx >= this.input.length)
      throw Error("Unexpected end of input");
    this.idx++;
  }
  loc(e) {
    return { begin: e, end: this.idx };
  }
}
class La {
  visitChildren(e) {
    for (const n in e) {
      const r = e[n];
      e.hasOwnProperty(n) && (r.type !== void 0 ? this.visit(r) : Array.isArray(r) && r.forEach((i) => {
        this.visit(i);
      }, this));
    }
  }
  visit(e) {
    switch (e.type) {
      case "Pattern":
        this.visitPattern(e);
        break;
      case "Flags":
        this.visitFlags(e);
        break;
      case "Disjunction":
        this.visitDisjunction(e);
        break;
      case "Alternative":
        this.visitAlternative(e);
        break;
      case "StartAnchor":
        this.visitStartAnchor(e);
        break;
      case "EndAnchor":
        this.visitEndAnchor(e);
        break;
      case "WordBoundary":
        this.visitWordBoundary(e);
        break;
      case "NonWordBoundary":
        this.visitNonWordBoundary(e);
        break;
      case "Lookahead":
        this.visitLookahead(e);
        break;
      case "NegativeLookahead":
        this.visitNegativeLookahead(e);
        break;
      case "Lookbehind":
        this.visitLookbehind(e);
        break;
      case "NegativeLookbehind":
        this.visitNegativeLookbehind(e);
        break;
      case "Character":
        this.visitCharacter(e);
        break;
      case "Set":
        this.visitSet(e);
        break;
      case "Group":
        this.visitGroup(e);
        break;
      case "GroupBackReference":
        this.visitGroupBackReference(e);
        break;
      case "Quantifier":
        this.visitQuantifier(e);
        break;
    }
    this.visitChildren(e);
  }
  visitPattern(e) {
  }
  visitFlags(e) {
  }
  visitDisjunction(e) {
  }
  visitAlternative(e) {
  }
  // Assertion
  visitStartAnchor(e) {
  }
  visitEndAnchor(e) {
  }
  visitWordBoundary(e) {
  }
  visitNonWordBoundary(e) {
  }
  visitLookahead(e) {
  }
  visitNegativeLookahead(e) {
  }
  visitLookbehind(e) {
  }
  visitNegativeLookbehind(e) {
  }
  // atoms
  visitCharacter(e) {
  }
  visitSet(e) {
  }
  visitGroup(e) {
  }
  visitGroupBackReference(e) {
  }
  visitQuantifier(e) {
  }
}
const Xp = /\r?\n/gm, Jp = new Wd();
class Qp extends La {
  constructor() {
    super(...arguments), this.isStarting = !0, this.endRegexpStack = [], this.multiline = !1;
  }
  get endRegex() {
    return this.endRegexpStack.join("");
  }
  reset(e) {
    this.multiline = !1, this.regex = e, this.startRegexp = "", this.isStarting = !0, this.endRegexpStack = [];
  }
  visitGroup(e) {
    e.quantifier && (this.isStarting = !1, this.endRegexpStack = []);
  }
  visitCharacter(e) {
    const n = String.fromCharCode(e.value);
    if (!this.multiline && n === `
` && (this.multiline = !0), e.quantifier)
      this.isStarting = !1, this.endRegexpStack = [];
    else {
      const r = Oa(n);
      this.endRegexpStack.push(r), this.isStarting && (this.startRegexp += r);
    }
  }
  visitSet(e) {
    if (!this.multiline) {
      const n = this.regex.substring(e.loc.begin, e.loc.end), r = new RegExp(n);
      this.multiline = !!`
`.match(r);
    }
    if (e.quantifier)
      this.isStarting = !1, this.endRegexpStack = [];
    else {
      const n = this.regex.substring(e.loc.begin, e.loc.end);
      this.endRegexpStack.push(n), this.isStarting && (this.startRegexp += n);
    }
  }
  visitChildren(e) {
    e.type === "Group" && e.quantifier || super.visitChildren(e);
  }
}
const Ya = new Qp();
function Zp(t) {
  try {
    return typeof t == "string" && (t = new RegExp(t)), t = t.toString(), Ya.reset(t), Ya.visit(Jp.pattern(t)), Ya.multiline;
  } catch {
    return !1;
  }
}
const em = `\f
\r	\v              \u2028\u2029  　\uFEFF`.split("");
function Vd(t) {
  const e = typeof t == "string" ? new RegExp(t) : t;
  return em.some((n) => e.test(n));
}
function Oa(t) {
  return t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function tm(t, e) {
  const n = nm(t), r = e.match(n);
  return !!r && r[0].length > 0;
}
function nm(t) {
  typeof t == "string" && (t = new RegExp(t));
  const e = t, n = t.source;
  let r = 0;
  function i() {
    let s = "", a;
    function o(l) {
      s += n.substr(r, l), r += l;
    }
    function c(l) {
      s += "(?:" + n.substr(r, l) + "|$)", r += l;
    }
    for (; r < n.length; )
      switch (n[r]) {
        case "\\":
          switch (n[r + 1]) {
            case "c":
              c(3);
              break;
            case "x":
              c(4);
              break;
            case "u":
              e.unicode ? n[r + 2] === "{" ? c(n.indexOf("}", r) - r + 1) : c(6) : c(2);
              break;
            case "p":
            case "P":
              e.unicode ? c(n.indexOf("}", r) - r + 1) : c(2);
              break;
            case "k":
              c(n.indexOf(">", r) - r + 1);
              break;
            default:
              c(2);
              break;
          }
          break;
        case "[":
          a = /\[(?:\\.|.)*?\]/g, a.lastIndex = r, a = a.exec(n) || [], c(a[0].length);
          break;
        case "|":
        case "^":
        case "$":
        case "*":
        case "+":
        case "?":
          o(1);
          break;
        case "{":
          a = /\{\d+,?\d*\}/g, a.lastIndex = r, a = a.exec(n), a ? o(a[0].length) : c(1);
          break;
        case "(":
          if (n[r + 1] === "?")
            switch (n[r + 2]) {
              case ":":
                s += "(?:", r += 3, s += i() + "|$)";
                break;
              case "=":
                s += "(?=", r += 3, s += i() + ")";
                break;
              case "!":
                a = r, r += 3, i(), s += n.substr(a, r - a);
                break;
              case "<":
                switch (n[r + 3]) {
                  case "=":
                  case "!":
                    a = r, r += 4, i(), s += n.substr(a, r - a);
                    break;
                  default:
                    o(n.indexOf(">", r) - r + 1), s += i() + "|$)";
                    break;
                }
                break;
            }
          else
            o(1), s += i() + "|$)";
          break;
        case ")":
          return ++r, s;
        default:
          c(1);
          break;
      }
    return s;
  }
  return new RegExp(i(), t.flags);
}
function rm(t) {
  return t.rules.find((e) => sn(e) && e.entry);
}
function im(t) {
  return t.rules.filter((e) => an(e) && e.hidden);
}
function Kd(t, e) {
  const n = /* @__PURE__ */ new Set(), r = rm(t);
  if (!r)
    return new Set(t.rules);
  const i = [r].concat(im(t));
  for (const a of i)
    Hd(a, n, e);
  const s = /* @__PURE__ */ new Set();
  for (const a of t.rules)
    (n.has(a.name) || an(a) && a.hidden) && s.add(a);
  return s;
}
function Hd(t, e, n) {
  e.add(t.name), ns(t).forEach((r) => {
    if (Bn(r) || n) {
      const i = r.rule.ref;
      i && !e.has(i.name) && Hd(i, e, n);
    }
  });
}
function sm(t) {
  if (t.terminal)
    return t.terminal;
  if (t.type.ref)
    return Xd(t.type.ref)?.terminal;
}
function am(t) {
  return t.hidden && !Vd(cl(t));
}
function om(t, e) {
  return !t || !e ? [] : ol(t, e, t.astNode, !0);
}
function Yd(t, e, n) {
  if (!t || !e)
    return;
  const r = ol(t, e, t.astNode, !0);
  if (r.length !== 0)
    return n !== void 0 ? n = Math.max(0, Math.min(n, r.length - 1)) : n = 0, r[n];
}
function ol(t, e, n, r) {
  if (!r) {
    const i = Ia(t.grammarSource, jn);
    if (i && i.feature === e)
      return [t];
  }
  return zi(t) && t.astNode === n ? t.content.flatMap((i) => ol(i, e, n, !1)) : [];
}
function cm(t, e, n) {
  if (!t)
    return;
  const r = lm(t, e, t?.astNode);
  if (r.length !== 0)
    return n !== void 0 ? n = Math.max(0, Math.min(n, r.length - 1)) : n = 0, r[n];
}
function lm(t, e, n) {
  if (t.astNode !== n)
    return [];
  if (zn(t.grammarSource) && t.grammarSource.value === e)
    return [t];
  const r = Co(t).iterator();
  let i;
  const s = [];
  do
    if (i = r.next(), !i.done) {
      const a = i.value;
      a.astNode === n ? zn(a.grammarSource) && a.grammarSource.value === e && s.push(a) : r.prune();
    }
  while (!i.done);
  return s;
}
function um(t) {
  const e = t.astNode;
  for (; e === t.container?.astNode; ) {
    const n = Ia(t.grammarSource, jn);
    if (n)
      return n;
    t = t.container;
  }
}
function Xd(t) {
  let e = t;
  return qd(e) && (Pa(e.$container) ? e = e.$container.$container : rs(e.$container) ? e = e.$container : is(e.$container)), Jd(t, e, /* @__PURE__ */ new Map());
}
function Jd(t, e, n) {
  function r(i, s) {
    let a;
    return Ia(i, jn) || (a = Jd(s, s, n)), n.set(t, a), a;
  }
  if (n.has(t))
    return n.get(t);
  n.set(t, void 0);
  for (const i of ns(e)) {
    if (jn(i) && i.feature.toLowerCase() === "name")
      return n.set(t, i), i;
    if (Bn(i) && sn(i.rule.ref))
      return r(i, i.rule.ref);
    if (Op(i) && i.typeRef?.ref)
      return r(i, i.typeRef.ref);
  }
}
function Qd(t) {
  return Zd(t, /* @__PURE__ */ new Set());
}
function Zd(t, e) {
  if (e.has(t))
    return !0;
  e.add(t);
  for (const n of ns(t))
    if (Bn(n)) {
      if (!n.rule.ref || sn(n.rule.ref) && !Zd(n.rule.ref, e) || oa(n.rule.ref))
        return !1;
    } else {
      if (jn(n))
        return !1;
      if (Pa(n))
        return !1;
    }
  return !!t.definition;
}
function ef(t) {
  if (!an(t)) {
    if (t.inferredType)
      return t.inferredType.name;
    if (t.dataType)
      return t.dataType;
    if (t.returnType) {
      const e = t.returnType.ref;
      if (e)
        return e.name;
    }
  }
}
function Bi(t) {
  if (rs(t))
    return sn(t) && Qd(t) ? t.name : ef(t) ?? t.name;
  if (bp(t) || Fp(t) || Lp(t))
    return t.name;
  if (Pa(t)) {
    const e = dm(t);
    if (e)
      return e;
  } else if (qd(t))
    return t.name;
  throw new Error("Cannot get name of Unknown Type");
}
function dm(t) {
  if (t.inferredType)
    return t.inferredType.name;
  if (t.type?.ref)
    return Bi(t.type.ref);
}
function fm(t) {
  return an(t) ? t.type?.name ?? "string" : ef(t) ?? t.name;
}
function cl(t) {
  const e = {
    s: !1,
    i: !1,
    u: !1
  }, n = Hr(t.definition, e), r = Object.entries(e).filter(([, i]) => i).map(([i]) => i).join("");
  return new RegExp(n, r);
}
const ll = /[\s\S]/.source;
function Hr(t, e) {
  if (xp(t))
    return hm(t);
  if (Dp(t))
    return pm(t);
  if (kp(t))
    return ym(t);
  if (Mp(t)) {
    const n = t.rule.ref;
    if (!n)
      throw new Error("Missing rule reference.");
    return en(Hr(n.definition), {
      cardinality: t.cardinality,
      lookahead: t.lookahead,
      parenthesized: t.parenthesized
    });
  } else {
    if (_p(t))
      return gm(t);
    if (Gp(t))
      return mm(t);
    if ($p(t)) {
      const n = t.regex.lastIndexOf("/"), r = t.regex.substring(1, n), i = t.regex.substring(n + 1);
      return e && (e.i = i.includes("i"), e.s = i.includes("s"), e.u = i.includes("u")), en(r, {
        cardinality: t.cardinality,
        lookahead: t.lookahead,
        parenthesized: t.parenthesized,
        wrap: !1
      });
    } else {
      if (Up(t))
        return en(ll, {
          cardinality: t.cardinality,
          lookahead: t.lookahead,
          parenthesized: t.parenthesized
        });
      throw new Error(`Invalid terminal element: ${t?.$type}, ${t?.$cstNode?.text}`);
    }
  }
}
function hm(t) {
  return en(t.elements.map((e) => Hr(e)).join("|"), {
    cardinality: t.cardinality,
    lookahead: t.lookahead,
    parenthesized: t.parenthesized,
    wrap: !1
    // wrapping is not required for top level alternatives, and nested alternatives are already parenthesized according to the grammar
  });
}
function pm(t) {
  return en(t.elements.map((e) => Hr(e)).join(""), {
    cardinality: t.cardinality,
    lookahead: t.lookahead,
    parenthesized: t.parenthesized,
    wrap: !1
    // wrapping is not required for top level group, and nested group are already parenthesized according to the grammar
  });
}
function mm(t) {
  return en(`${ll}*?${Hr(t.terminal)}`, {
    cardinality: t.cardinality,
    lookahead: t.lookahead,
    parenthesized: t.parenthesized
  });
}
function gm(t) {
  return en(`(?!${Hr(t.terminal)})${ll}*?`, {
    cardinality: t.cardinality,
    lookahead: t.lookahead,
    parenthesized: t.parenthesized
  });
}
function ym(t) {
  return t.right ? en(`[${Xa(t.left)}-${Xa(t.right)}]`, {
    cardinality: t.cardinality,
    lookahead: t.lookahead,
    parenthesized: t.parenthesized,
    wrap: !1
  }) : en(Xa(t.left), {
    cardinality: t.cardinality,
    lookahead: t.lookahead,
    parenthesized: t.parenthesized,
    wrap: !1
  });
}
function Xa(t) {
  return Oa(t.value);
}
function en(t, e) {
  return (e.parenthesized || e.lookahead || e.wrap !== !1) && (t = `(${e.lookahead ?? (e.parenthesized ? "" : "?:")}${t})`), e.cardinality ? `${t}${e.cardinality}` : t;
}
function Tm(t) {
  const e = [], n = t.Grammar;
  for (const r of n.rules)
    an(r) && am(r) && Zp(cl(r)) && e.push(r.name);
  return {
    multilineCommentRules: e,
    nameRegexp: Bp
  };
}
function wo(t) {
  console && console.error && console.error(`Error: ${t}`);
}
function tf(t) {
  console && console.warn && console.warn(`Warning: ${t}`);
}
function nf(t) {
  const e = (/* @__PURE__ */ new Date()).getTime(), n = t();
  return { time: (/* @__PURE__ */ new Date()).getTime() - e, value: n };
}
function rf(t) {
  function e() {
  }
  e.prototype = t;
  const n = new e();
  function r() {
    return typeof n.bar;
  }
  return r(), r(), t;
}
function Rm(t) {
  return vm(t) ? t.LABEL : t.name;
}
function vm(t) {
  return nt(t.LABEL) && t.LABEL !== "";
}
class xt {
  get definition() {
    return this._definition;
  }
  set definition(e) {
    this._definition = e;
  }
  constructor(e) {
    this._definition = e;
  }
  accept(e) {
    e.visit(this), q(this.definition, (n) => {
      n.accept(e);
    });
  }
}
class Qe extends xt {
  constructor(e) {
    super([]), this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
  set definition(e) {
  }
  get definition() {
    return this.referencedRule !== void 0 ? this.referencedRule.definition : [];
  }
  accept(e) {
    e.visit(this);
  }
}
class Yr extends xt {
  constructor(e) {
    super(e.definition), this.orgText = "", ft(this, wt(e, (n) => n !== void 0));
  }
}
class rt extends xt {
  constructor(e) {
    super(e.definition), this.ignoreAmbiguities = !1, ft(this, wt(e, (n) => n !== void 0));
  }
}
let ze = class extends xt {
  constructor(e) {
    super(e.definition), this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
};
class pt extends xt {
  constructor(e) {
    super(e.definition), this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
}
class mt extends xt {
  constructor(e) {
    super(e.definition), this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
}
class Ae extends xt {
  constructor(e) {
    super(e.definition), this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
}
class it extends xt {
  constructor(e) {
    super(e.definition), this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
}
class st extends xt {
  get definition() {
    return this._definition;
  }
  set definition(e) {
    this._definition = e;
  }
  constructor(e) {
    super(e.definition), this.idx = 1, this.ignoreAmbiguities = !1, this.hasPredicates = !1, ft(this, wt(e, (n) => n !== void 0));
  }
}
class le {
  constructor(e) {
    this.idx = 1, ft(this, wt(e, (n) => n !== void 0));
  }
  accept(e) {
    e.visit(this);
  }
}
function Em(t) {
  return M(t, Js);
}
function Js(t) {
  function e(n) {
    return M(n, Js);
  }
  if (t instanceof Qe) {
    const n = {
      type: "NonTerminal",
      name: t.nonTerminalName,
      idx: t.idx
    };
    return nt(t.label) && (n.label = t.label), n;
  } else {
    if (t instanceof rt)
      return {
        type: "Alternative",
        definition: e(t.definition)
      };
    if (t instanceof ze)
      return {
        type: "Option",
        idx: t.idx,
        definition: e(t.definition)
      };
    if (t instanceof pt)
      return {
        type: "RepetitionMandatory",
        idx: t.idx,
        definition: e(t.definition)
      };
    if (t instanceof mt)
      return {
        type: "RepetitionMandatoryWithSeparator",
        idx: t.idx,
        separator: Js(new le({ terminalType: t.separator })),
        definition: e(t.definition)
      };
    if (t instanceof it)
      return {
        type: "RepetitionWithSeparator",
        idx: t.idx,
        separator: Js(new le({ terminalType: t.separator })),
        definition: e(t.definition)
      };
    if (t instanceof Ae)
      return {
        type: "Repetition",
        idx: t.idx,
        definition: e(t.definition)
      };
    if (t instanceof st)
      return {
        type: "Alternation",
        idx: t.idx,
        definition: e(t.definition)
      };
    if (t instanceof le) {
      const n = {
        type: "Terminal",
        name: t.terminalType.name,
        label: Rm(t.terminalType),
        idx: t.idx
      };
      nt(t.label) && (n.terminalLabel = t.label);
      const r = t.terminalType.PATTERN;
      return t.terminalType.PATTERN && (n.pattern = nn(r) ? r.source : r), n;
    } else {
      if (t instanceof Yr)
        return {
          type: "Rule",
          name: t.name,
          orgText: t.orgText,
          definition: e(t.definition)
        };
      throw Error("non exhaustive match");
    }
  }
}
class Xr {
  visit(e) {
    const n = e;
    switch (n.constructor) {
      case Qe:
        return this.visitNonTerminal(n);
      case rt:
        return this.visitAlternative(n);
      case ze:
        return this.visitOption(n);
      case pt:
        return this.visitRepetitionMandatory(n);
      case mt:
        return this.visitRepetitionMandatoryWithSeparator(n);
      case it:
        return this.visitRepetitionWithSeparator(n);
      case Ae:
        return this.visitRepetition(n);
      case st:
        return this.visitAlternation(n);
      case le:
        return this.visitTerminal(n);
      case Yr:
        return this.visitRule(n);
      /* c8 ignore next 2 */
      default:
        throw Error("non exhaustive match");
    }
  }
  /* c8 ignore next */
  visitNonTerminal(e) {
  }
  /* c8 ignore next */
  visitAlternative(e) {
  }
  /* c8 ignore next */
  visitOption(e) {
  }
  /* c8 ignore next */
  visitRepetition(e) {
  }
  /* c8 ignore next */
  visitRepetitionMandatory(e) {
  }
  /* c8 ignore next 3 */
  visitRepetitionMandatoryWithSeparator(e) {
  }
  /* c8 ignore next */
  visitRepetitionWithSeparator(e) {
  }
  /* c8 ignore next */
  visitAlternation(e) {
  }
  /* c8 ignore next */
  visitTerminal(e) {
  }
  /* c8 ignore next */
  visitRule(e) {
  }
}
function Am(t) {
  return t instanceof rt || t instanceof ze || t instanceof Ae || t instanceof pt || t instanceof mt || t instanceof it || t instanceof le || t instanceof Yr;
}
function da(t, e = []) {
  return t instanceof ze || t instanceof Ae || t instanceof it ? !0 : t instanceof st ? Od(t.definition, (r) => da(r, e)) : t instanceof Qe && et(e, t) ? !1 : t instanceof xt ? (t instanceof Qe && e.push(t), kt(t.definition, (r) => da(r, e))) : !1;
}
function Sm(t) {
  return t instanceof st;
}
function $t(t) {
  if (t instanceof Qe)
    return "SUBRULE";
  if (t instanceof ze)
    return "OPTION";
  if (t instanceof st)
    return "OR";
  if (t instanceof pt)
    return "AT_LEAST_ONE";
  if (t instanceof mt)
    return "AT_LEAST_ONE_SEP";
  if (t instanceof it)
    return "MANY_SEP";
  if (t instanceof Ae)
    return "MANY";
  if (t instanceof le)
    return "CONSUME";
  throw Error("non exhaustive match");
}
class xa {
  walk(e, n = []) {
    q(e.definition, (r, i) => {
      const s = Ge(e.definition, i + 1);
      if (r instanceof Qe)
        this.walkProdRef(r, s, n);
      else if (r instanceof le)
        this.walkTerminal(r, s, n);
      else if (r instanceof rt)
        this.walkFlat(r, s, n);
      else if (r instanceof ze)
        this.walkOption(r, s, n);
      else if (r instanceof pt)
        this.walkAtLeastOne(r, s, n);
      else if (r instanceof mt)
        this.walkAtLeastOneSep(r, s, n);
      else if (r instanceof it)
        this.walkManySep(r, s, n);
      else if (r instanceof Ae)
        this.walkMany(r, s, n);
      else if (r instanceof st)
        this.walkOr(r, s, n);
      else
        throw Error("non exhaustive match");
    });
  }
  walkTerminal(e, n, r) {
  }
  walkProdRef(e, n, r) {
  }
  walkFlat(e, n, r) {
    const i = n.concat(r);
    this.walk(e, i);
  }
  walkOption(e, n, r) {
    const i = n.concat(r);
    this.walk(e, i);
  }
  walkAtLeastOne(e, n, r) {
    const i = [
      new ze({ definition: e.definition })
    ].concat(n, r);
    this.walk(e, i);
  }
  walkAtLeastOneSep(e, n, r) {
    const i = zl(e, n, r);
    this.walk(e, i);
  }
  walkMany(e, n, r) {
    const i = [
      new ze({ definition: e.definition })
    ].concat(n, r);
    this.walk(e, i);
  }
  walkManySep(e, n, r) {
    const i = zl(e, n, r);
    this.walk(e, i);
  }
  walkOr(e, n, r) {
    const i = n.concat(r);
    q(e.definition, (s) => {
      const a = new rt({ definition: [s] });
      this.walk(a, i);
    });
  }
}
function zl(t, e, n) {
  return [
    new ze({
      definition: [
        new le({ terminalType: t.separator })
      ].concat(t.definition)
    })
  ].concat(e, n);
}
function ss(t) {
  if (t instanceof Qe)
    return ss(t.referencedRule);
  if (t instanceof le)
    return Nm(t);
  if (Am(t))
    return km(t);
  if (Sm(t))
    return Cm(t);
  throw Error("non exhaustive match");
}
function km(t) {
  let e = [];
  const n = t.definition;
  let r = 0, i = n.length > r, s, a = !0;
  for (; i && a; )
    s = n[r], a = da(s), e = e.concat(ss(s)), r = r + 1, i = n.length > r;
  return rl(e);
}
function Cm(t) {
  const e = M(t.definition, (n) => ss(n));
  return rl(yt(e));
}
function Nm(t) {
  return [t.terminalType];
}
const sf = "_~IN~_";
class wm extends xa {
  constructor(e) {
    super(), this.topProd = e, this.follows = {};
  }
  startWalking() {
    return this.walk(this.topProd), this.follows;
  }
  walkTerminal(e, n, r) {
  }
  walkProdRef(e, n, r) {
    const i = _m(e.referencedRule, e.idx) + this.topProd.name, s = n.concat(r), a = new rt({ definition: s }), o = ss(a);
    this.follows[i] = o;
  }
}
function bm(t) {
  const e = {};
  return q(t, (n) => {
    const r = new wm(n).startWalking();
    ft(e, r);
  }), e;
}
function _m(t, e) {
  return t.name + e + sf;
}
let Qs = {};
const Im = new Wd();
function Da(t) {
  const e = t.toString();
  if (Qs.hasOwnProperty(e))
    return Qs[e];
  {
    const n = Im.pattern(e);
    return Qs[e] = n, n;
  }
}
function Pm() {
  Qs = {};
}
const af = "Complement Sets are not supported for first char optimization", fa = `Unable to use "first char" lexer optimizations:
`;
function $m(t, e = !1) {
  try {
    const n = Da(t);
    return bo(n.value, {}, n.flags.ignoreCase);
  } catch (n) {
    if (n.message === af)
      e && tf(`${fa}	Unable to optimize: < ${t.toString()} >
	Complement Sets cannot be automatically optimized.
	This will disable the lexer's first char optimizations.
	See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#COMPLEMENT for details.`);
    else {
      let r = "";
      e && (r = `
	This will disable the lexer's first char optimizations.
	See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#REGEXP_PARSING for details.`), wo(`${fa}
	Failed parsing: < ${t.toString()} >
	Using the @chevrotain/regexp-to-ast library
	Please open an issue at: https://github.com/chevrotain/chevrotain/issues` + r);
    }
  }
  return [];
}
function bo(t, e, n) {
  switch (t.type) {
    case "Disjunction":
      for (let i = 0; i < t.value.length; i++)
        bo(t.value[i], e, n);
      break;
    case "Alternative":
      const r = t.value;
      for (let i = 0; i < r.length; i++) {
        const s = r[i];
        switch (s.type) {
          case "EndAnchor":
          // A group back reference cannot affect potential starting char.
          // because if a back reference is the first production than automatically
          // the group being referenced has had to come BEFORE so its codes have already been added
          case "GroupBackReference":
          // assertions do not affect potential starting codes
          case "Lookahead":
          case "NegativeLookahead":
          case "Lookbehind":
          case "NegativeLookbehind":
          case "StartAnchor":
          case "WordBoundary":
          case "NonWordBoundary":
            continue;
        }
        const a = s;
        switch (a.type) {
          case "Character":
            Ls(a.value, e, n);
            break;
          case "Set":
            if (a.complement === !0)
              throw Error(af);
            q(a.value, (c) => {
              if (typeof c == "number")
                Ls(c, e, n);
              else {
                const l = c;
                if (n === !0)
                  for (let u = l.from; u <= l.to; u++)
                    Ls(u, e, n);
                else {
                  for (let u = l.from; u <= l.to && u < Mi; u++)
                    Ls(u, e, n);
                  if (l.to >= Mi) {
                    const u = l.from >= Mi ? l.from : Mi, f = l.to, m = dn(u), p = dn(f);
                    for (let A = m; A <= p; A++)
                      e[A] = A;
                  }
                }
              }
            });
            break;
          case "Group":
            bo(a.value, e, n);
            break;
          /* istanbul ignore next */
          default:
            throw Error("Non Exhaustive Match");
        }
        const o = a.quantifier !== void 0 && a.quantifier.atLeast === 0;
        if (
          // A group may be optional due to empty contents /(?:)/
          // or if everything inside it is optional /((a)?)/
          a.type === "Group" && _o(a) === !1 || // If this term is not a group it may only be optional if it has an optional quantifier
          a.type !== "Group" && o === !1
        )
          break;
      }
      break;
    /* istanbul ignore next */
    default:
      throw Error("non exhaustive match!");
  }
  return $e(e);
}
function Ls(t, e, n) {
  const r = dn(t);
  e[r] = r, n === !0 && Lm(t, e);
}
function Lm(t, e) {
  const n = String.fromCharCode(t), r = n.toUpperCase();
  if (r !== n) {
    const i = dn(r.charCodeAt(0));
    e[i] = i;
  } else {
    const i = n.toLowerCase();
    if (i !== n) {
      const s = dn(i.charCodeAt(0));
      e[s] = s;
    }
  }
}
function Bl(t, e) {
  return qr(t.value, (n) => {
    if (typeof n == "number")
      return et(e, n);
    {
      const r = n;
      return qr(e, (i) => r.from <= i && i <= r.to) !== void 0;
    }
  });
}
function _o(t) {
  const e = t.quantifier;
  return e && e.atLeast === 0 ? !0 : t.value ? je(t.value) ? kt(t.value, _o) : _o(t.value) : !1;
}
class Om extends La {
  constructor(e) {
    super(), this.targetCharCodes = e, this.found = !1;
  }
  visitChildren(e) {
    if (this.found !== !0) {
      switch (e.type) {
        case "Lookahead":
          this.visitLookahead(e);
          return;
        case "NegativeLookahead":
          this.visitNegativeLookahead(e);
          return;
        case "Lookbehind":
          this.visitLookbehind(e);
          return;
        case "NegativeLookbehind":
          this.visitNegativeLookbehind(e);
          return;
      }
      super.visitChildren(e);
    }
  }
  visitCharacter(e) {
    et(this.targetCharCodes, e.value) && (this.found = !0);
  }
  visitSet(e) {
    e.complement ? Bl(e, this.targetCharCodes) === void 0 && (this.found = !0) : Bl(e, this.targetCharCodes) !== void 0 && (this.found = !0);
  }
}
function ul(t, e) {
  if (e instanceof RegExp) {
    const n = Da(e), r = new Om(t);
    return r.visit(n), r.found;
  } else
    return qr(e, (n) => et(t, n.charCodeAt(0))) !== void 0;
}
const Wn = "PATTERN", Di = "defaultMode", Os = "modes";
function xm(t, e) {
  e = nl(e, {
    debug: !1,
    safeMode: !1,
    positionTracking: "full",
    lineTerminatorCharacters: ["\r", `
`],
    tracer: (N, k) => k()
  });
  const n = e.tracer;
  n("initCharCodeToOptimizedIndexMap", () => {
    sg();
  });
  let r;
  n("Reject Lexer.NA", () => {
    r = _a(t, (N) => N[Wn] === tt.NA);
  });
  let i = !1, s;
  n("Transform Patterns", () => {
    i = !1, s = M(r, (N) => {
      const k = N[Wn];
      if (nn(k)) {
        const P = k.source;
        return P.length === 1 && // only these regExp meta characters which can appear in a length one regExp
        P !== "^" && P !== "$" && P !== "." && !k.ignoreCase ? P : P.length === 2 && P[0] === "\\" && // not a meta character
        !et([
          "d",
          "D",
          "s",
          "S",
          "t",
          "r",
          "n",
          "t",
          "0",
          "c",
          "b",
          "B",
          "f",
          "v",
          "w",
          "W"
        ], P[1]) ? P[1] : Wl(k);
      } else {
        if (Hn(k))
          return i = !0, { exec: k };
        if (typeof k == "object")
          return i = !0, k;
        if (typeof k == "string") {
          if (k.length === 1)
            return k;
          {
            const P = k.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"), H = new RegExp(P);
            return Wl(H);
          }
        } else
          throw Error("non exhaustive match");
      }
    });
  });
  let a, o, c, l, u;
  n("misc mapping", () => {
    a = M(r, (N) => N.tokenTypeIdx), o = M(r, (N) => {
      const k = N.GROUP;
      if (k !== tt.SKIPPED) {
        if (nt(k))
          return k;
        if (tn(k))
          return !1;
        throw Error("non exhaustive match");
      }
    }), c = M(r, (N) => {
      const k = N.LONGER_ALT;
      if (k)
        return je(k) ? M(k, (H) => _l(r, H)) : [_l(r, k)];
    }), l = M(r, (N) => N.PUSH_MODE), u = M(r, (N) => z(N, "POP_MODE"));
  });
  let f;
  n("Line Terminator Handling", () => {
    const N = lf(e.lineTerminatorCharacters);
    f = M(r, (k) => !1), e.positionTracking !== "onlyOffset" && (f = M(r, (k) => z(k, "LINE_BREAKS") ? !!k.LINE_BREAKS : cf(k, N) === !1 && ul(N, k.PATTERN)));
  });
  let m, p, A, b;
  n("Misc Mapping #2", () => {
    m = M(r, of), p = M(s, ng), A = Je(r, (N, k) => {
      const P = k.GROUP;
      return nt(P) && P !== tt.SKIPPED && (N[P] = []), N;
    }, {}), b = M(s, (N, k) => ({
      pattern: s[k],
      longerAlt: c[k],
      canLineTerminator: f[k],
      isCustom: m[k],
      short: p[k],
      group: o[k],
      push: l[k],
      pop: u[k],
      tokenTypeIdx: a[k],
      tokenType: r[k]
    }));
  });
  let I = !0, C = [];
  return e.safeMode || n("First Char Optimization", () => {
    C = Je(r, (N, k, P) => {
      if (typeof k.PATTERN == "string") {
        const H = k.PATTERN.charCodeAt(0), K = dn(H);
        Ja(N, K, b[P]);
      } else if (je(k.START_CHARS_HINT)) {
        let H;
        q(k.START_CHARS_HINT, (K) => {
          const J = typeof K == "string" ? K.charCodeAt(0) : K, oe = dn(J);
          H !== oe && (H = oe, Ja(N, oe, b[P]));
        });
      } else if (nn(k.PATTERN))
        if (k.PATTERN.unicode)
          I = !1, e.ensureOptimizations && wo(`${fa}	Unable to analyze < ${k.PATTERN.toString()} > pattern.
	The regexp unicode flag is not currently supported by the regexp-to-ast library.
	This will disable the lexer's first char optimizations.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#UNICODE_OPTIMIZE`);
        else {
          const H = $m(k.PATTERN, e.ensureOptimizations);
          ae(H) && (I = !1), q(H, (K) => {
            Ja(N, K, b[P]);
          });
        }
      else
        e.ensureOptimizations && wo(`${fa}	TokenType: <${k.name}> is using a custom token pattern without providing <start_chars_hint> parameter.
	This will disable the lexer's first char optimizations.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#CUSTOM_OPTIMIZE`), I = !1;
      return N;
    }, []);
  }), {
    emptyGroups: A,
    patternIdxToConfig: b,
    charCodeToPatternIdxToConfig: C,
    hasCustom: i,
    canBeOptimized: I
  };
}
function Dm(t, e) {
  let n = [];
  const r = Fm(t);
  n = n.concat(r.errors);
  const i = Gm(r.valid), s = i.valid;
  return n = n.concat(i.errors), n = n.concat(Mm(s)), n = n.concat(Km(s)), n = n.concat(Hm(s, e)), n = n.concat(Ym(s)), n;
}
function Mm(t) {
  let e = [];
  const n = ht(t, (r) => nn(r[Wn]));
  return e = e.concat(qm(n)), e = e.concat(Bm(n)), e = e.concat(Wm(n)), e = e.concat(Vm(n)), e = e.concat(jm(n)), e;
}
function Fm(t) {
  const e = ht(t, (i) => !z(i, Wn)), n = M(e, (i) => ({
    message: "Token Type: ->" + i.name + "<- missing static 'PATTERN' property",
    type: Se.MISSING_PATTERN,
    tokenTypes: [i]
  })), r = ba(t, e);
  return { errors: n, valid: r };
}
function Gm(t) {
  const e = ht(t, (i) => {
    const s = i[Wn];
    return !nn(s) && !Hn(s) && !z(s, "exec") && !nt(s);
  }), n = M(e, (i) => ({
    message: "Token Type: ->" + i.name + "<- static 'PATTERN' can only be a RegExp, a Function matching the {CustomPatternMatcherFunc} type or an Object matching the {ICustomPattern} interface.",
    type: Se.INVALID_PATTERN,
    tokenTypes: [i]
  })), r = ba(t, e);
  return { errors: n, valid: r };
}
const Um = /[^\\][$]/;
function qm(t) {
  class e extends La {
    constructor() {
      super(...arguments), this.found = !1;
    }
    visitEndAnchor(s) {
      this.found = !0;
    }
  }
  const n = ht(t, (i) => {
    const s = i.PATTERN;
    try {
      const a = Da(s), o = new e();
      return o.visit(a), o.found;
    } catch {
      return Um.test(s.source);
    }
  });
  return M(n, (i) => ({
    message: `Unexpected RegExp Anchor Error:
	Token Type: ->` + i.name + `<- static 'PATTERN' cannot contain end of input anchor '$'
	See chevrotain.io/docs/guide/resolving_lexer_errors.html#ANCHORS	for details.`,
    type: Se.EOI_ANCHOR_FOUND,
    tokenTypes: [i]
  }));
}
function jm(t) {
  const e = ht(t, (r) => r.PATTERN.test(""));
  return M(e, (r) => ({
    message: "Token Type: ->" + r.name + "<- static 'PATTERN' must not match an empty string",
    type: Se.EMPTY_MATCH_PATTERN,
    tokenTypes: [r]
  }));
}
const zm = /[^\\[][\^]|^\^/;
function Bm(t) {
  class e extends La {
    constructor() {
      super(...arguments), this.found = !1;
    }
    visitStartAnchor(s) {
      this.found = !0;
    }
  }
  const n = ht(t, (i) => {
    const s = i.PATTERN;
    try {
      const a = Da(s), o = new e();
      return o.visit(a), o.found;
    } catch {
      return zm.test(s.source);
    }
  });
  return M(n, (i) => ({
    message: `Unexpected RegExp Anchor Error:
	Token Type: ->` + i.name + `<- static 'PATTERN' cannot contain start of input anchor '^'
	See https://chevrotain.io/docs/guide/resolving_lexer_errors.html#ANCHORS	for details.`,
    type: Se.SOI_ANCHOR_FOUND,
    tokenTypes: [i]
  }));
}
function Wm(t) {
  const e = ht(t, (r) => {
    const i = r[Wn];
    return i instanceof RegExp && (i.multiline || i.global);
  });
  return M(e, (r) => ({
    message: "Token Type: ->" + r.name + "<- static 'PATTERN' may NOT contain global('g') or multiline('m')",
    type: Se.UNSUPPORTED_FLAGS_FOUND,
    tokenTypes: [r]
  }));
}
function Vm(t) {
  const e = [];
  let n = M(t, (s) => Je(t, (a, o) => (s.PATTERN.source === o.PATTERN.source && !et(e, o) && o.PATTERN !== tt.NA && (e.push(o), a.push(o)), a), []));
  n = ts(n);
  const r = ht(n, (s) => s.length > 1);
  return M(r, (s) => {
    const a = M(s, (c) => c.name);
    return {
      message: `The same RegExp pattern ->${Nt(s).PATTERN}<-has been used in all of the following Token Types: ${a.join(", ")} <-`,
      type: Se.DUPLICATE_PATTERNS_FOUND,
      tokenTypes: s
    };
  });
}
function Km(t) {
  const e = ht(t, (r) => {
    if (!z(r, "GROUP"))
      return !1;
    const i = r.GROUP;
    return i !== tt.SKIPPED && i !== tt.NA && !nt(i);
  });
  return M(e, (r) => ({
    message: "Token Type: ->" + r.name + "<- static 'GROUP' can only be Lexer.SKIPPED/Lexer.NA/A String",
    type: Se.INVALID_GROUP_TYPE_FOUND,
    tokenTypes: [r]
  }));
}
function Hm(t, e) {
  const n = ht(t, (i) => i.PUSH_MODE !== void 0 && !et(e, i.PUSH_MODE));
  return M(n, (i) => ({
    message: `Token Type: ->${i.name}<- static 'PUSH_MODE' value cannot refer to a Lexer Mode ->${i.PUSH_MODE}<-which does not exist`,
    type: Se.PUSH_MODE_DOES_NOT_EXIST,
    tokenTypes: [i]
  }));
}
function Ym(t) {
  const e = [], n = Je(t, (r, i, s) => {
    const a = i.PATTERN;
    return a === tt.NA || (nt(a) ? r.push({ str: a, idx: s, tokenType: i }) : nn(a) && Jm(a) && r.push({ str: a.source, idx: s, tokenType: i })), r;
  }, []);
  return q(t, (r, i) => {
    q(n, ({ str: s, idx: a, tokenType: o }) => {
      if (i < a && Xm(s, r.PATTERN)) {
        const c = `Token: ->${o.name}<- can never be matched.
Because it appears AFTER the Token Type ->${r.name}<-in the lexer's definition.
See https://chevrotain.io/docs/guide/resolving_lexer_errors.html#UNREACHABLE`;
        e.push({
          message: c,
          type: Se.UNREACHABLE_PATTERN,
          tokenTypes: [r, o]
        });
      }
    });
  }), e;
}
function Xm(t, e) {
  if (nn(e)) {
    if (Qm(e))
      return !1;
    const n = e.exec(t);
    return n !== null && n.index === 0;
  } else {
    if (Hn(e))
      return e(t, 0, [], {});
    if (z(e, "exec"))
      return e.exec(t, 0, [], {});
    if (typeof e == "string")
      return e === t;
    throw Error("non exhaustive match");
  }
}
function Jm(t) {
  return qr([
    ".",
    "\\",
    "[",
    "]",
    "|",
    "^",
    "$",
    "(",
    ")",
    "?",
    "*",
    "+",
    "{"
  ], (n) => t.source.indexOf(n) !== -1) === void 0;
}
function Qm(t) {
  return /(\(\?=)|(\(\?!)|(\(\?<=)|(\(\?<!)/.test(t.source);
}
function Wl(t) {
  const e = t.ignoreCase ? "iy" : "y";
  return new RegExp(`${t.source}`, e);
}
function Zm(t, e, n) {
  const r = [];
  return z(t, Di) || r.push({
    message: "A MultiMode Lexer cannot be initialized without a <" + Di + `> property in its definition
`,
    type: Se.MULTI_MODE_LEXER_WITHOUT_DEFAULT_MODE
  }), z(t, Os) || r.push({
    message: "A MultiMode Lexer cannot be initialized without a <" + Os + `> property in its definition
`,
    type: Se.MULTI_MODE_LEXER_WITHOUT_MODES_PROPERTY
  }), z(t, Os) && z(t, Di) && !z(t.modes, t.defaultMode) && r.push({
    message: `A MultiMode Lexer cannot be initialized with a ${Di}: <${t.defaultMode}>which does not exist
`,
    type: Se.MULTI_MODE_LEXER_DEFAULT_MODE_VALUE_DOES_NOT_EXIST
  }), z(t, Os) && q(t.modes, (i, s) => {
    q(i, (a, o) => {
      if (tn(a))
        r.push({
          message: `A Lexer cannot be initialized using an undefined Token Type. Mode:<${s}> at index: <${o}>
`,
          type: Se.LEXER_DEFINITION_CANNOT_CONTAIN_UNDEFINED
        });
      else if (z(a, "LONGER_ALT")) {
        const c = je(a.LONGER_ALT) ? a.LONGER_ALT : [a.LONGER_ALT];
        q(c, (l) => {
          !tn(l) && !et(i, l) && r.push({
            message: `A MultiMode Lexer cannot be initialized with a longer_alt <${l.name}> on token <${a.name}> outside of mode <${s}>
`,
            type: Se.MULTI_MODE_LEXER_LONGER_ALT_NOT_IN_CURRENT_MODE
          });
        });
      }
    });
  }), r;
}
function eg(t, e, n) {
  const r = [];
  let i = !1;
  const s = ts(yt($e(t.modes))), a = _a(s, (c) => c[Wn] === tt.NA), o = lf(n);
  return e && q(a, (c) => {
    const l = cf(c, o);
    if (l !== !1) {
      const f = {
        message: ig(c, l),
        type: l.issue,
        tokenType: c
      };
      r.push(f);
    } else
      z(c, "LINE_BREAKS") ? c.LINE_BREAKS === !0 && (i = !0) : ul(o, c.PATTERN) && (i = !0);
  }), e && !i && r.push({
    message: `Warning: No LINE_BREAKS Found.
	This Lexer has been defined to track line and column information,
	But none of the Token Types can be identified as matching a line terminator.
	See https://chevrotain.io/docs/guide/resolving_lexer_errors.html#LINE_BREAKS 
	for details.`,
    type: Se.NO_LINE_BREAKS_FLAGS
  }), r;
}
function tg(t) {
  const e = {}, n = Ur(t);
  return q(n, (r) => {
    const i = t[r];
    if (je(i))
      e[r] = [];
    else
      throw Error("non exhaustive match");
  }), e;
}
function of(t) {
  const e = t.PATTERN;
  if (nn(e))
    return !1;
  if (Hn(e))
    return !0;
  if (z(e, "exec"))
    return !0;
  if (nt(e))
    return !1;
  throw Error("non exhaustive match");
}
function ng(t) {
  return nt(t) && t.length === 1 ? t.charCodeAt(0) : !1;
}
const rg = {
  // implements /\n|\r\n?/g.test
  test: function(t) {
    const e = t.length;
    for (let n = this.lastIndex; n < e; n++) {
      const r = t.charCodeAt(n);
      if (r === 10)
        return this.lastIndex = n + 1, !0;
      if (r === 13)
        return t.charCodeAt(n + 1) === 10 ? this.lastIndex = n + 2 : this.lastIndex = n + 1, !0;
    }
    return !1;
  },
  lastIndex: 0
};
function cf(t, e) {
  if (z(t, "LINE_BREAKS"))
    return !1;
  if (nn(t.PATTERN)) {
    try {
      ul(e, t.PATTERN);
    } catch (n) {
      return {
        issue: Se.IDENTIFY_TERMINATOR,
        errMsg: n.message
      };
    }
    return !1;
  } else {
    if (nt(t.PATTERN))
      return !1;
    if (of(t))
      return { issue: Se.CUSTOM_LINE_BREAK };
    throw Error("non exhaustive match");
  }
}
function ig(t, e) {
  if (e.issue === Se.IDENTIFY_TERMINATOR)
    return `Warning: unable to identify line terminator usage in pattern.
	The problem is in the <${t.name}> Token Type
	 Root cause: ${e.errMsg}.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#IDENTIFY_TERMINATOR`;
  if (e.issue === Se.CUSTOM_LINE_BREAK)
    return `Warning: A Custom Token Pattern should specify the <line_breaks> option.
	The problem is in the <${t.name}> Token Type
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#CUSTOM_LINE_BREAK`;
  throw Error("non exhaustive match");
}
function lf(t) {
  return M(t, (n) => nt(n) ? n.charCodeAt(0) : n);
}
function Ja(t, e, n) {
  t[e] === void 0 ? t[e] = [n] : t[e].push(n);
}
const Mi = 256;
let Zs = [];
function dn(t) {
  return t < Mi ? t : Zs[t];
}
function sg() {
  if (ae(Zs)) {
    Zs = new Array(65536);
    for (let t = 0; t < 65536; t++)
      Zs[t] = t > 255 ? 255 + ~~(t / 255) : t;
  }
}
function as(t, e) {
  const n = t.tokenTypeIdx;
  return n === e.tokenTypeIdx ? !0 : e.isParent === !0 && e.categoryMatchesMap[n] === !0;
}
function ha(t, e) {
  return t.tokenTypeIdx === e.tokenTypeIdx;
}
let Vl = 1;
const uf = {};
function os(t) {
  const e = ag(t);
  og(e), lg(e), cg(e), q(e, (n) => {
    n.isParent = n.categoryMatches.length > 0;
  });
}
function ag(t) {
  let e = Be(t), n = t, r = !0;
  for (; r; ) {
    n = ts(yt(M(n, (s) => s.CATEGORIES)));
    const i = ba(n, e);
    e = e.concat(i), ae(i) ? r = !1 : n = i;
  }
  return e;
}
function og(t) {
  q(t, (e) => {
    ff(e) || (uf[Vl] = e, e.tokenTypeIdx = Vl++), Kl(e) && !je(e.CATEGORIES) && (e.CATEGORIES = [e.CATEGORIES]), Kl(e) || (e.CATEGORIES = []), ug(e) || (e.categoryMatches = []), dg(e) || (e.categoryMatchesMap = {});
  });
}
function cg(t) {
  q(t, (e) => {
    e.categoryMatches = [], q(e.categoryMatchesMap, (n, r) => {
      e.categoryMatches.push(uf[r].tokenTypeIdx);
    });
  });
}
function lg(t) {
  q(t, (e) => {
    df([], e);
  });
}
function df(t, e) {
  q(t, (n) => {
    e.categoryMatchesMap[n.tokenTypeIdx] = !0;
  }), q(e.CATEGORIES, (n) => {
    const r = t.concat(e);
    et(r, n) || df(r, n);
  });
}
function ff(t) {
  return z(t, "tokenTypeIdx");
}
function Kl(t) {
  return z(t, "CATEGORIES");
}
function ug(t) {
  return z(t, "categoryMatches");
}
function dg(t) {
  return z(t, "categoryMatchesMap");
}
function fg(t) {
  return z(t, "tokenTypeIdx");
}
const Io = {
  buildUnableToPopLexerModeMessage(t) {
    return `Unable to pop Lexer Mode after encountering Token ->${t.image}<- The Mode Stack is empty`;
  },
  buildUnexpectedCharactersMessage(t, e, n, r, i, s) {
    return `unexpected character: ->${t.charAt(e)}<- at offset: ${e}, skipped ${n} characters.`;
  }
};
var Se;
(function(t) {
  t[t.MISSING_PATTERN = 0] = "MISSING_PATTERN", t[t.INVALID_PATTERN = 1] = "INVALID_PATTERN", t[t.EOI_ANCHOR_FOUND = 2] = "EOI_ANCHOR_FOUND", t[t.UNSUPPORTED_FLAGS_FOUND = 3] = "UNSUPPORTED_FLAGS_FOUND", t[t.DUPLICATE_PATTERNS_FOUND = 4] = "DUPLICATE_PATTERNS_FOUND", t[t.INVALID_GROUP_TYPE_FOUND = 5] = "INVALID_GROUP_TYPE_FOUND", t[t.PUSH_MODE_DOES_NOT_EXIST = 6] = "PUSH_MODE_DOES_NOT_EXIST", t[t.MULTI_MODE_LEXER_WITHOUT_DEFAULT_MODE = 7] = "MULTI_MODE_LEXER_WITHOUT_DEFAULT_MODE", t[t.MULTI_MODE_LEXER_WITHOUT_MODES_PROPERTY = 8] = "MULTI_MODE_LEXER_WITHOUT_MODES_PROPERTY", t[t.MULTI_MODE_LEXER_DEFAULT_MODE_VALUE_DOES_NOT_EXIST = 9] = "MULTI_MODE_LEXER_DEFAULT_MODE_VALUE_DOES_NOT_EXIST", t[t.LEXER_DEFINITION_CANNOT_CONTAIN_UNDEFINED = 10] = "LEXER_DEFINITION_CANNOT_CONTAIN_UNDEFINED", t[t.SOI_ANCHOR_FOUND = 11] = "SOI_ANCHOR_FOUND", t[t.EMPTY_MATCH_PATTERN = 12] = "EMPTY_MATCH_PATTERN", t[t.NO_LINE_BREAKS_FLAGS = 13] = "NO_LINE_BREAKS_FLAGS", t[t.UNREACHABLE_PATTERN = 14] = "UNREACHABLE_PATTERN", t[t.IDENTIFY_TERMINATOR = 15] = "IDENTIFY_TERMINATOR", t[t.CUSTOM_LINE_BREAK = 16] = "CUSTOM_LINE_BREAK", t[t.MULTI_MODE_LEXER_LONGER_ALT_NOT_IN_CURRENT_MODE = 17] = "MULTI_MODE_LEXER_LONGER_ALT_NOT_IN_CURRENT_MODE";
})(Se || (Se = {}));
const Fi = {
  deferDefinitionErrorsHandling: !1,
  positionTracking: "full",
  lineTerminatorsPattern: /\n|\r\n?/g,
  lineTerminatorCharacters: [`
`, "\r"],
  ensureOptimizations: !1,
  safeMode: !1,
  errorMessageProvider: Io,
  traceInitPerf: !1,
  skipValidations: !1,
  recoveryEnabled: !0
};
Object.freeze(Fi);
class tt {
  constructor(e, n = Fi) {
    if (this.lexerDefinition = e, this.lexerDefinitionErrors = [], this.lexerDefinitionWarning = [], this.patternIdxToConfig = {}, this.charCodeToPatternIdxToConfig = {}, this.modes = [], this.emptyGroups = {}, this.trackStartLines = !0, this.trackEndLines = !0, this.hasCustom = !1, this.canModeBeOptimized = {}, this.TRACE_INIT = (i, s) => {
      if (this.traceInitPerf === !0) {
        this.traceInitIndent++;
        const a = new Array(this.traceInitIndent + 1).join("	");
        this.traceInitIndent < this.traceInitMaxIdent && console.log(`${a}--> <${i}>`);
        const { time: o, value: c } = nf(s), l = o > 10 ? console.warn : console.log;
        return this.traceInitIndent < this.traceInitMaxIdent && l(`${a}<-- <${i}> time: ${o}ms`), this.traceInitIndent--, c;
      } else
        return s();
    }, typeof n == "boolean")
      throw Error(`The second argument to the Lexer constructor is now an ILexerConfig Object.
a boolean 2nd argument is no longer supported`);
    this.config = ft({}, Fi, n);
    const r = this.config.traceInitPerf;
    r === !0 ? (this.traceInitMaxIdent = 1 / 0, this.traceInitPerf = !0) : typeof r == "number" && (this.traceInitMaxIdent = r, this.traceInitPerf = !0), this.traceInitIndent = -1, this.TRACE_INIT("Lexer Constructor", () => {
      let i, s = !0;
      this.TRACE_INIT("Lexer Config handling", () => {
        if (this.config.lineTerminatorsPattern === Fi.lineTerminatorsPattern)
          this.config.lineTerminatorsPattern = rg;
        else if (this.config.lineTerminatorCharacters === Fi.lineTerminatorCharacters)
          throw Error(`Error: Missing <lineTerminatorCharacters> property on the Lexer config.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#MISSING_LINE_TERM_CHARS`);
        if (n.safeMode && n.ensureOptimizations)
          throw Error('"safeMode" and "ensureOptimizations" flags are mutually exclusive.');
        this.trackStartLines = /full|onlyStart/i.test(this.config.positionTracking), this.trackEndLines = /full/i.test(this.config.positionTracking), je(e) ? i = {
          modes: { defaultMode: Be(e) },
          defaultMode: Di
        } : (s = !1, i = Be(e));
      }), this.config.skipValidations === !1 && (this.TRACE_INIT("performRuntimeChecks", () => {
        this.lexerDefinitionErrors = this.lexerDefinitionErrors.concat(Zm(i, this.trackStartLines, this.config.lineTerminatorCharacters));
      }), this.TRACE_INIT("performWarningRuntimeChecks", () => {
        this.lexerDefinitionWarning = this.lexerDefinitionWarning.concat(eg(i, this.trackStartLines, this.config.lineTerminatorCharacters));
      })), i.modes = i.modes ? i.modes : {}, q(i.modes, (o, c) => {
        i.modes[c] = _a(o, (l) => tn(l));
      });
      const a = Ur(i.modes);
      if (q(i.modes, (o, c) => {
        this.TRACE_INIT(`Mode: <${c}> processing`, () => {
          if (this.modes.push(c), this.config.skipValidations === !1 && this.TRACE_INIT("validatePatterns", () => {
            this.lexerDefinitionErrors = this.lexerDefinitionErrors.concat(Dm(o, a));
          }), ae(this.lexerDefinitionErrors)) {
            os(o);
            let l;
            this.TRACE_INIT("analyzeTokenTypes", () => {
              l = xm(o, {
                lineTerminatorCharacters: this.config.lineTerminatorCharacters,
                positionTracking: n.positionTracking,
                ensureOptimizations: n.ensureOptimizations,
                safeMode: n.safeMode,
                tracer: this.TRACE_INIT
              });
            }), this.patternIdxToConfig[c] = l.patternIdxToConfig, this.charCodeToPatternIdxToConfig[c] = l.charCodeToPatternIdxToConfig, this.emptyGroups = ft({}, this.emptyGroups, l.emptyGroups), this.hasCustom = l.hasCustom || this.hasCustom, this.canModeBeOptimized[c] = l.canBeOptimized;
          }
        });
      }), this.defaultMode = i.defaultMode, !ae(this.lexerDefinitionErrors) && !this.config.deferDefinitionErrorsHandling) {
        const c = M(this.lexerDefinitionErrors, (l) => l.message).join(`-----------------------
`);
        throw new Error(`Errors detected in definition of Lexer:
` + c);
      }
      q(this.lexerDefinitionWarning, (o) => {
        tf(o.message);
      }), this.TRACE_INIT("Choosing sub-methods implementations", () => {
        if (s && (this.handleModes = Fe), this.trackStartLines === !1 && (this.computeNewColumn = Uh), this.trackEndLines === !1 && (this.updateTokenEndLineColumnLocation = Fe), /full/i.test(this.config.positionTracking))
          this.createTokenInstance = this.createFullToken;
        else if (/onlyStart/i.test(this.config.positionTracking))
          this.createTokenInstance = this.createStartOnlyToken;
        else if (/onlyOffset/i.test(this.config.positionTracking))
          this.createTokenInstance = this.createOffsetOnlyToken;
        else
          throw Error(`Invalid <positionTracking> config option: "${this.config.positionTracking}"`);
        this.hasCustom ? (this.addToken = this.addTokenUsingPush, this.handlePayload = this.handlePayloadWithCustom) : (this.addToken = this.addTokenUsingMemberAccess, this.handlePayload = this.handlePayloadNoCustom);
      }), this.TRACE_INIT("Failed Optimization Warnings", () => {
        const o = Je(this.canModeBeOptimized, (c, l, u) => (l === !1 && c.push(u), c), []);
        if (n.ensureOptimizations && !ae(o))
          throw Error(`Lexer Modes: < ${o.join(", ")} > cannot be optimized.
	 Disable the "ensureOptimizations" lexer config flag to silently ignore this and run the lexer in an un-optimized mode.
	 Or inspect the console log for details on how to resolve these issues.`);
      }), this.TRACE_INIT("clearRegExpParserCache", () => {
        Pm();
      }), this.TRACE_INIT("toFastProperties", () => {
        rf(this);
      });
    });
  }
  tokenize(e, n = this.defaultMode) {
    if (!ae(this.lexerDefinitionErrors)) {
      const i = M(this.lexerDefinitionErrors, (s) => s.message).join(`-----------------------
`);
      throw new Error(`Unable to Tokenize because Errors detected in definition of Lexer:
` + i);
    }
    return this.tokenizeInternal(e, n);
  }
  // There is quite a bit of duplication between this and "tokenizeInternalLazy"
  // This is intentional due to performance considerations.
  // this method also used quite a bit of `!` none null assertions because it is too optimized
  // for `tsc` to always understand it is "safe"
  tokenizeInternal(e, n) {
    let r, i, s, a, o, c, l, u, f, m, p, A, b, I, C;
    const N = e, k = N.length;
    let P = 0, H = 0;
    const K = this.hasCustom ? 0 : Math.floor(e.length / 10), J = new Array(K), oe = [];
    let ue = this.trackStartLines ? 1 : void 0, de = this.trackStartLines ? 1 : void 0;
    const _ = tg(this.emptyGroups), T = this.trackStartLines, g = this.config.lineTerminatorsPattern;
    let S = 0, y = [], R = [];
    const E = [], O = [];
    Object.freeze(O);
    let D = !1;
    const x = (B) => {
      if (E.length === 1 && // if we have both a POP_MODE and a PUSH_MODE this is in-fact a "transition"
      // So no error should occur.
      B.tokenType.PUSH_MODE === void 0) {
        const ne = this.config.errorMessageProvider.buildUnableToPopLexerModeMessage(B);
        oe.push({
          offset: B.startOffset,
          line: B.startLine,
          column: B.startColumn,
          length: B.image.length,
          message: ne
        });
      } else {
        E.pop();
        const ne = qn(E);
        y = this.patternIdxToConfig[ne], R = this.charCodeToPatternIdxToConfig[ne], S = y.length;
        const Oe = this.canModeBeOptimized[ne] && this.config.safeMode === !1;
        R && Oe ? D = !0 : D = !1;
      }
    };
    function j(B) {
      E.push(B), R = this.charCodeToPatternIdxToConfig[B], y = this.patternIdxToConfig[B], S = y.length, S = y.length;
      const ne = this.canModeBeOptimized[B] && this.config.safeMode === !1;
      R && ne ? D = !0 : D = !1;
    }
    j.call(this, n);
    let G;
    const ie = this.config.recoveryEnabled;
    for (; P < k; ) {
      c = null, f = -1;
      const B = N.charCodeAt(P);
      let ne;
      if (D) {
        const Re = dn(B), fe = R[Re];
        ne = fe !== void 0 ? fe : O;
      } else
        ne = y;
      const Oe = ne.length;
      for (r = 0; r < Oe; r++) {
        G = ne[r];
        const Re = G.pattern;
        l = null;
        const fe = G.short;
        if (fe !== !1 ? B === fe && (f = 1, c = Re) : G.isCustom === !0 ? (C = Re.exec(N, P, J, _), C !== null ? (c = C[0], f = c.length, C.payload !== void 0 && (l = C.payload)) : c = null) : (Re.lastIndex = P, f = this.matchLength(Re, e, P)), f !== -1) {
          if (o = G.longerAlt, o !== void 0) {
            c = e.substring(P, P + f);
            const Ie = o.length;
            for (s = 0; s < Ie; s++) {
              const xe = y[o[s]], be = xe.pattern;
              if (u = null, xe.isCustom === !0 ? (C = be.exec(N, P, J, _), C !== null ? (a = C[0], C.payload !== void 0 && (u = C.payload)) : a = null) : (be.lastIndex = P, a = this.match(be, e, P)), a && a.length > c.length) {
                c = a, f = a.length, l = u, G = xe;
                break;
              }
            }
          }
          break;
        }
      }
      if (f !== -1) {
        if (m = G.group, m !== void 0 && (c = c !== null ? c : e.substring(P, P + f), p = G.tokenTypeIdx, A = this.createTokenInstance(c, P, p, G.tokenType, ue, de, f), this.handlePayload(A, l), m === !1 ? H = this.addToken(J, H, A) : _[m].push(A)), T === !0 && G.canLineTerminator === !0) {
          let Re = 0, fe, Ie;
          g.lastIndex = 0;
          do
            c = c !== null ? c : e.substring(P, P + f), fe = g.test(c), fe === !0 && (Ie = g.lastIndex - 1, Re++);
          while (fe === !0);
          Re !== 0 ? (ue = ue + Re, de = f - Ie, this.updateTokenEndLineColumnLocation(A, m, Ie, Re, ue, de, f)) : de = this.computeNewColumn(de, f);
        } else
          de = this.computeNewColumn(de, f);
        P = P + f, this.handleModes(G, x, j, A);
      } else {
        const Re = P, fe = ue, Ie = de;
        let xe = ie === !1;
        for (; xe === !1 && P < k; )
          for (P++, i = 0; i < S; i++) {
            const be = y[i], Z = be.pattern, at = be.short;
            if (at !== !1 ? N.charCodeAt(P) === at && (xe = !0) : be.isCustom === !0 ? xe = Z.exec(N, P, J, _) !== null : (Z.lastIndex = P, xe = Z.exec(e) !== null), xe === !0)
              break;
          }
        if (b = P - Re, de = this.computeNewColumn(de, b), I = this.config.errorMessageProvider.buildUnexpectedCharactersMessage(N, Re, b, fe, Ie, qn(E)), oe.push({
          offset: Re,
          line: fe,
          column: Ie,
          length: b,
          message: I
        }), ie === !1)
          break;
      }
    }
    return this.hasCustom || (J.length = H), {
      tokens: J,
      groups: _,
      errors: oe
    };
  }
  handleModes(e, n, r, i) {
    if (e.pop === !0) {
      const s = e.push;
      n(i), s !== void 0 && r.call(this, s);
    } else e.push !== void 0 && r.call(this, e.push);
  }
  // TODO: decrease this under 600 characters? inspect stripping comments option in TSC compiler
  updateTokenEndLineColumnLocation(e, n, r, i, s, a, o) {
    let c, l;
    n !== void 0 && (c = r === o - 1, l = c ? -1 : 0, i === 1 && c === !0 || (e.endLine = s + l, e.endColumn = a - 1 + -l));
  }
  computeNewColumn(e, n) {
    return e + n;
  }
  createOffsetOnlyToken(e, n, r, i) {
    return {
      image: e,
      startOffset: n,
      tokenTypeIdx: r,
      tokenType: i
    };
  }
  createStartOnlyToken(e, n, r, i, s, a) {
    return {
      image: e,
      startOffset: n,
      startLine: s,
      startColumn: a,
      tokenTypeIdx: r,
      tokenType: i
    };
  }
  createFullToken(e, n, r, i, s, a, o) {
    return {
      image: e,
      startOffset: n,
      endOffset: n + o - 1,
      startLine: s,
      endLine: s,
      startColumn: a,
      endColumn: a + o - 1,
      tokenTypeIdx: r,
      tokenType: i
    };
  }
  addTokenUsingPush(e, n, r) {
    return e.push(r), n;
  }
  addTokenUsingMemberAccess(e, n, r) {
    return e[n] = r, n++, n;
  }
  handlePayloadNoCustom(e, n) {
  }
  handlePayloadWithCustom(e, n) {
    n !== null && (e.payload = n);
  }
  match(e, n, r) {
    return e.test(n) === !0 ? n.substring(r, e.lastIndex) : null;
  }
  matchLength(e, n, r) {
    return e.test(n) === !0 ? e.lastIndex - r : -1;
  }
}
tt.SKIPPED = "This marks a skipped Token pattern, this means each token identified by it will be consumed and then thrown into oblivion, this can be used to for example to completely ignore whitespace.";
tt.NA = /NOT_APPLICABLE/;
function Ar(t) {
  return hf(t) ? t.LABEL : t.name;
}
function hf(t) {
  return nt(t.LABEL) && t.LABEL !== "";
}
const hg = "parent", Hl = "categories", Yl = "label", Xl = "group", Jl = "push_mode", Ql = "pop_mode", Zl = "longer_alt", eu = "line_breaks", tu = "start_chars_hint";
function pf(t) {
  return pg(t);
}
function pg(t) {
  const e = t.pattern, n = {};
  if (n.name = t.name, tn(e) || (n.PATTERN = e), z(t, hg))
    throw `The parent property is no longer supported.
See: https://github.com/chevrotain/chevrotain/issues/564#issuecomment-349062346 for details.`;
  return z(t, Hl) && (n.CATEGORIES = t[Hl]), os([n]), z(t, Yl) && (n.LABEL = t[Yl]), z(t, Xl) && (n.GROUP = t[Xl]), z(t, Ql) && (n.POP_MODE = t[Ql]), z(t, Jl) && (n.PUSH_MODE = t[Jl]), z(t, Zl) && (n.LONGER_ALT = t[Zl]), z(t, eu) && (n.LINE_BREAKS = t[eu]), z(t, tu) && (n.START_CHARS_HINT = t[tu]), n;
}
const fn = pf({ name: "EOF", pattern: tt.NA });
os([fn]);
function dl(t, e, n, r, i, s, a, o) {
  return {
    image: e,
    startOffset: n,
    endOffset: r,
    startLine: i,
    endLine: s,
    startColumn: a,
    endColumn: o,
    tokenTypeIdx: t.tokenTypeIdx,
    tokenType: t
  };
}
function mf(t, e) {
  return as(t, e);
}
const vr = {
  buildMismatchTokenMessage({ expected: t, actual: e, previous: n, ruleName: r }) {
    return `Expecting ${hf(t) ? `--> ${Ar(t)} <--` : `token of type --> ${t.name} <--`} but found --> '${e.image}' <--`;
  },
  buildNotAllInputParsedMessage({ firstRedundant: t, ruleName: e }) {
    return "Redundant input, expecting EOF but found: " + t.image;
  },
  buildNoViableAltMessage({ expectedPathsPerAlt: t, actual: e, previous: n, customUserDescription: r, ruleName: i }) {
    const s = "Expecting: ", o = `
but found: '` + Nt(e).image + "'";
    if (r)
      return s + r + o;
    {
      const c = Je(t, (m, p) => m.concat(p), []), l = M(c, (m) => `[${M(m, (p) => Ar(p)).join(", ")}]`), f = `one of these possible Token sequences:
${M(l, (m, p) => `  ${p + 1}. ${m}`).join(`
`)}`;
      return s + f + o;
    }
  },
  buildEarlyExitMessage({ expectedIterationPaths: t, actual: e, customUserDescription: n, ruleName: r }) {
    const i = "Expecting: ", a = `
but found: '` + Nt(e).image + "'";
    if (n)
      return i + n + a;
    {
      const c = `expecting at least one iteration which starts with one of these possible Token sequences::
  <${M(t, (l) => `[${M(l, (u) => Ar(u)).join(",")}]`).join(" ,")}>`;
      return i + c + a;
    }
  }
};
Object.freeze(vr);
const mg = {
  buildRuleNotFoundError(t, e) {
    return "Invalid grammar, reference to a rule which is not defined: ->" + e.nonTerminalName + `<-
inside top level rule: ->` + t.name + "<-";
  }
}, Gn = {
  buildDuplicateFoundError(t, e) {
    function n(u) {
      return u instanceof le ? u.terminalType.name : u instanceof Qe ? u.nonTerminalName : "";
    }
    const r = t.name, i = Nt(e), s = i.idx, a = $t(i), o = n(i), c = s > 0;
    let l = `->${a}${c ? s : ""}<- ${o ? `with argument: ->${o}<-` : ""}
                  appears more than once (${e.length} times) in the top level rule: ->${r}<-.                  
                  For further details see: https://chevrotain.io/docs/FAQ.html#NUMERICAL_SUFFIXES 
                  `;
    return l = l.replace(/[ \t]+/g, " "), l = l.replace(/\s\s+/g, `
`), l;
  },
  buildNamespaceConflictError(t) {
    return `Namespace conflict found in grammar.
The grammar has both a Terminal(Token) and a Non-Terminal(Rule) named: <${t.name}>.
To resolve this make sure each Terminal and Non-Terminal names are unique
This is easy to accomplish by using the convention that Terminal names start with an uppercase letter
and Non-Terminal names start with a lower case letter.`;
  },
  buildAlternationPrefixAmbiguityError(t) {
    const e = M(t.prefixPath, (i) => Ar(i)).join(", "), n = t.alternation.idx === 0 ? "" : t.alternation.idx;
    return `Ambiguous alternatives: <${t.ambiguityIndices.join(" ,")}> due to common lookahead prefix
in <OR${n}> inside <${t.topLevelRule.name}> Rule,
<${e}> may appears as a prefix path in all these alternatives.
See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#COMMON_PREFIX
For Further details.`;
  },
  buildAlternationAmbiguityError(t) {
    const e = t.alternation.idx === 0 ? "" : t.alternation.idx, n = t.prefixPath.length === 0;
    let r = `Ambiguous Alternatives Detected: <${t.ambiguityIndices.join(" ,")}> in <OR${e}> inside <${t.topLevelRule.name}> Rule,
`;
    if (n)
      r += `These alternatives are all empty (match no tokens), making them indistinguishable.
Only the last alternative may be empty.
`;
    else {
      const i = M(t.prefixPath, (s) => Ar(s)).join(", ");
      r += `<${i}> may appears as a prefix path in all these alternatives.
`;
    }
    return r += `See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#AMBIGUOUS_ALTERNATIVES
For Further details.`, r;
  },
  buildEmptyRepetitionError(t) {
    let e = $t(t.repetition);
    return t.repetition.idx !== 0 && (e += t.repetition.idx), `The repetition <${e}> within Rule <${t.topLevelRule.name}> can never consume any tokens.
This could lead to an infinite loop.`;
  },
  // TODO: remove - `errors_public` from nyc.config.js exclude
  //       once this method is fully removed from this file
  buildTokenNameError(t) {
    return "deprecated";
  },
  buildEmptyAlternationError(t) {
    return `Ambiguous empty alternative: <${t.emptyChoiceIdx + 1}> in <OR${t.alternation.idx}> inside <${t.topLevelRule.name}> Rule.
Only the last alternative may be an empty alternative.`;
  },
  buildTooManyAlternativesError(t) {
    return `An Alternation cannot have more than 256 alternatives:
<OR${t.alternation.idx}> inside <${t.topLevelRule.name}> Rule.
 has ${t.alternation.definition.length + 1} alternatives.`;
  },
  buildLeftRecursionError(t) {
    const e = t.topLevelRule.name, n = M(t.leftRecursionPath, (s) => s.name), r = `${e} --> ${n.concat([e]).join(" --> ")}`;
    return `Left Recursion found in grammar.
rule: <${e}> can be invoked from itself (directly or indirectly)
without consuming any Tokens. The grammar path that causes this is: 
 ${r}
 To fix this refactor your grammar to remove the left recursion.
see: https://en.wikipedia.org/wiki/LL_parser#Left_factoring.`;
  },
  // TODO: remove - `errors_public` from nyc.config.js exclude
  //       once this method is fully removed from this file
  buildInvalidRuleNameError(t) {
    return "deprecated";
  },
  buildDuplicateRuleNameError(t) {
    let e;
    return t.topLevelRule instanceof Yr ? e = t.topLevelRule.name : e = t.topLevelRule, `Duplicate definition, rule: ->${e}<- is already defined in the grammar: ->${t.grammarName}<-`;
  }
};
function gg(t, e) {
  const n = new yg(t, e);
  return n.resolveRefs(), n.errors;
}
class yg extends Xr {
  constructor(e, n) {
    super(), this.nameToTopRule = e, this.errMsgProvider = n, this.errors = [];
  }
  resolveRefs() {
    q($e(this.nameToTopRule), (e) => {
      this.currTopLevel = e, e.accept(this);
    });
  }
  visitNonTerminal(e) {
    const n = this.nameToTopRule[e.nonTerminalName];
    if (n)
      e.referencedRule = n;
    else {
      const r = this.errMsgProvider.buildRuleNotFoundError(this.currTopLevel, e);
      this.errors.push({
        message: r,
        type: Ze.UNRESOLVED_SUBRULE_REF,
        ruleName: this.currTopLevel.name,
        unresolvedRefName: e.nonTerminalName
      });
    }
  }
}
class Tg extends xa {
  constructor(e, n) {
    super(), this.topProd = e, this.path = n, this.possibleTokTypes = [], this.nextProductionName = "", this.nextProductionOccurrence = 0, this.found = !1, this.isAtEndOfPath = !1;
  }
  startWalking() {
    if (this.found = !1, this.path.ruleStack[0] !== this.topProd.name)
      throw Error("The path does not start with the walker's top Rule!");
    return this.ruleStack = Be(this.path.ruleStack).reverse(), this.occurrenceStack = Be(this.path.occurrenceStack).reverse(), this.ruleStack.pop(), this.occurrenceStack.pop(), this.updateExpectedNext(), this.walk(this.topProd), this.possibleTokTypes;
  }
  walk(e, n = []) {
    this.found || super.walk(e, n);
  }
  walkProdRef(e, n, r) {
    if (e.referencedRule.name === this.nextProductionName && e.idx === this.nextProductionOccurrence) {
      const i = n.concat(r);
      this.updateExpectedNext(), this.walk(e.referencedRule, i);
    }
  }
  updateExpectedNext() {
    ae(this.ruleStack) ? (this.nextProductionName = "", this.nextProductionOccurrence = 0, this.isAtEndOfPath = !0) : (this.nextProductionName = this.ruleStack.pop(), this.nextProductionOccurrence = this.occurrenceStack.pop());
  }
}
class Rg extends Tg {
  constructor(e, n) {
    super(e, n), this.path = n, this.nextTerminalName = "", this.nextTerminalOccurrence = 0, this.nextTerminalName = this.path.lastTok.name, this.nextTerminalOccurrence = this.path.lastTokOccurrence;
  }
  walkTerminal(e, n, r) {
    if (this.isAtEndOfPath && e.terminalType.name === this.nextTerminalName && e.idx === this.nextTerminalOccurrence && !this.found) {
      const i = n.concat(r), s = new rt({ definition: i });
      this.possibleTokTypes = ss(s), this.found = !0;
    }
  }
}
class Ma extends xa {
  constructor(e, n) {
    super(), this.topRule = e, this.occurrence = n, this.result = {
      token: void 0,
      occurrence: void 0,
      isEndOfRule: void 0
    };
  }
  startWalking() {
    return this.walk(this.topRule), this.result;
  }
}
class vg extends Ma {
  walkMany(e, n, r) {
    if (e.idx === this.occurrence) {
      const i = Nt(n.concat(r));
      this.result.isEndOfRule = i === void 0, i instanceof le && (this.result.token = i.terminalType, this.result.occurrence = i.idx);
    } else
      super.walkMany(e, n, r);
  }
}
class nu extends Ma {
  walkManySep(e, n, r) {
    if (e.idx === this.occurrence) {
      const i = Nt(n.concat(r));
      this.result.isEndOfRule = i === void 0, i instanceof le && (this.result.token = i.terminalType, this.result.occurrence = i.idx);
    } else
      super.walkManySep(e, n, r);
  }
}
class Eg extends Ma {
  walkAtLeastOne(e, n, r) {
    if (e.idx === this.occurrence) {
      const i = Nt(n.concat(r));
      this.result.isEndOfRule = i === void 0, i instanceof le && (this.result.token = i.terminalType, this.result.occurrence = i.idx);
    } else
      super.walkAtLeastOne(e, n, r);
  }
}
class ru extends Ma {
  walkAtLeastOneSep(e, n, r) {
    if (e.idx === this.occurrence) {
      const i = Nt(n.concat(r));
      this.result.isEndOfRule = i === void 0, i instanceof le && (this.result.token = i.terminalType, this.result.occurrence = i.idx);
    } else
      super.walkAtLeastOneSep(e, n, r);
  }
}
function Po(t, e, n = []) {
  n = Be(n);
  let r = [], i = 0;
  function s(o) {
    return o.concat(Ge(t, i + 1));
  }
  function a(o) {
    const c = Po(s(o), e, n);
    return r.concat(c);
  }
  for (; n.length < e && i < t.length; ) {
    const o = t[i];
    if (o instanceof rt)
      return a(o.definition);
    if (o instanceof Qe)
      return a(o.definition);
    if (o instanceof ze)
      r = a(o.definition);
    else if (o instanceof pt) {
      const c = o.definition.concat([
        new Ae({
          definition: o.definition
        })
      ]);
      return a(c);
    } else if (o instanceof mt) {
      const c = [
        new rt({ definition: o.definition }),
        new Ae({
          definition: [new le({ terminalType: o.separator })].concat(o.definition)
        })
      ];
      return a(c);
    } else if (o instanceof it) {
      const c = o.definition.concat([
        new Ae({
          definition: [new le({ terminalType: o.separator })].concat(o.definition)
        })
      ]);
      r = a(c);
    } else if (o instanceof Ae) {
      const c = o.definition.concat([
        new Ae({
          definition: o.definition
        })
      ]);
      r = a(c);
    } else {
      if (o instanceof st)
        return q(o.definition, (c) => {
          ae(c.definition) === !1 && (r = a(c.definition));
        }), r;
      if (o instanceof le)
        n.push(o.terminalType);
      else
        throw Error("non exhaustive match");
    }
    i++;
  }
  return r.push({
    partialPath: n,
    suffixDef: Ge(t, i)
  }), r;
}
function gf(t, e, n, r) {
  const i = "EXIT_NONE_TERMINAL", s = [i], a = "EXIT_ALTERNATIVE";
  let o = !1;
  const c = e.length, l = c - r - 1, u = [], f = [];
  for (f.push({
    idx: -1,
    def: t,
    ruleStack: [],
    occurrenceStack: []
  }); !ae(f); ) {
    const m = f.pop();
    if (m === a) {
      o && qn(f).idx <= l && f.pop();
      continue;
    }
    const p = m.def, A = m.idx, b = m.ruleStack, I = m.occurrenceStack;
    if (ae(p))
      continue;
    const C = p[0];
    if (C === i) {
      const N = {
        idx: A,
        def: Ge(p),
        ruleStack: ji(b),
        occurrenceStack: ji(I)
      };
      f.push(N);
    } else if (C instanceof le)
      if (A < c - 1) {
        const N = A + 1, k = e[N];
        if (n(k, C.terminalType)) {
          const P = {
            idx: N,
            def: Ge(p),
            ruleStack: b,
            occurrenceStack: I
          };
          f.push(P);
        }
      } else if (A === c - 1)
        u.push({
          nextTokenType: C.terminalType,
          nextTokenOccurrence: C.idx,
          ruleStack: b,
          occurrenceStack: I
        }), o = !0;
      else
        throw Error("non exhaustive match");
    else if (C instanceof Qe) {
      const N = Be(b);
      N.push(C.nonTerminalName);
      const k = Be(I);
      k.push(C.idx);
      const P = {
        idx: A,
        def: C.definition.concat(s, Ge(p)),
        ruleStack: N,
        occurrenceStack: k
      };
      f.push(P);
    } else if (C instanceof ze) {
      const N = {
        idx: A,
        def: Ge(p),
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(N), f.push(a);
      const k = {
        idx: A,
        def: C.definition.concat(Ge(p)),
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(k);
    } else if (C instanceof pt) {
      const N = new Ae({
        definition: C.definition,
        idx: C.idx
      }), k = C.definition.concat([N], Ge(p)), P = {
        idx: A,
        def: k,
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(P);
    } else if (C instanceof mt) {
      const N = new le({
        terminalType: C.separator
      }), k = new Ae({
        definition: [N].concat(C.definition),
        idx: C.idx
      }), P = C.definition.concat([k], Ge(p)), H = {
        idx: A,
        def: P,
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(H);
    } else if (C instanceof it) {
      const N = {
        idx: A,
        def: Ge(p),
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(N), f.push(a);
      const k = new le({
        terminalType: C.separator
      }), P = new Ae({
        definition: [k].concat(C.definition),
        idx: C.idx
      }), H = C.definition.concat([P], Ge(p)), K = {
        idx: A,
        def: H,
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(K);
    } else if (C instanceof Ae) {
      const N = {
        idx: A,
        def: Ge(p),
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(N), f.push(a);
      const k = new Ae({
        definition: C.definition,
        idx: C.idx
      }), P = C.definition.concat([k], Ge(p)), H = {
        idx: A,
        def: P,
        ruleStack: b,
        occurrenceStack: I
      };
      f.push(H);
    } else if (C instanceof st)
      for (let N = C.definition.length - 1; N >= 0; N--) {
        const k = C.definition[N], P = {
          idx: A,
          def: k.definition.concat(Ge(p)),
          ruleStack: b,
          occurrenceStack: I
        };
        f.push(P), f.push(a);
      }
    else if (C instanceof rt)
      f.push({
        idx: A,
        def: C.definition.concat(Ge(p)),
        ruleStack: b,
        occurrenceStack: I
      });
    else if (C instanceof Yr)
      f.push(Ag(C, A, b, I));
    else
      throw Error("non exhaustive match");
  }
  return u;
}
function Ag(t, e, n, r) {
  const i = Be(n);
  i.push(t.name);
  const s = Be(r);
  return s.push(1), {
    idx: e,
    def: t.definition,
    ruleStack: i,
    occurrenceStack: s
  };
}
var ge;
(function(t) {
  t[t.OPTION = 0] = "OPTION", t[t.REPETITION = 1] = "REPETITION", t[t.REPETITION_MANDATORY = 2] = "REPETITION_MANDATORY", t[t.REPETITION_MANDATORY_WITH_SEPARATOR = 3] = "REPETITION_MANDATORY_WITH_SEPARATOR", t[t.REPETITION_WITH_SEPARATOR = 4] = "REPETITION_WITH_SEPARATOR", t[t.ALTERNATION = 5] = "ALTERNATION";
})(ge || (ge = {}));
function fl(t) {
  if (t instanceof ze || t === "Option")
    return ge.OPTION;
  if (t instanceof Ae || t === "Repetition")
    return ge.REPETITION;
  if (t instanceof pt || t === "RepetitionMandatory")
    return ge.REPETITION_MANDATORY;
  if (t instanceof mt || t === "RepetitionMandatoryWithSeparator")
    return ge.REPETITION_MANDATORY_WITH_SEPARATOR;
  if (t instanceof it || t === "RepetitionWithSeparator")
    return ge.REPETITION_WITH_SEPARATOR;
  if (t instanceof st || t === "Alternation")
    return ge.ALTERNATION;
  throw Error("non exhaustive match");
}
function iu(t) {
  const { occurrence: e, rule: n, prodType: r, maxLookahead: i } = t, s = fl(r);
  return s === ge.ALTERNATION ? Fa(e, n, i) : Ga(e, n, s, i);
}
function Sg(t, e, n, r, i, s) {
  const a = Fa(t, e, n), o = Rf(a) ? ha : as;
  return s(a, r, o, i);
}
function kg(t, e, n, r, i, s) {
  const a = Ga(t, e, i, n), o = Rf(a) ? ha : as;
  return s(a[0], o, r);
}
function Cg(t, e, n, r) {
  const i = t.length, s = kt(t, (a) => kt(a, (o) => o.length === 1));
  if (e)
    return function(a) {
      const o = M(a, (c) => c.GATE);
      for (let c = 0; c < i; c++) {
        const l = t[c], u = l.length, f = o[c];
        if (!(f !== void 0 && f.call(this) === !1))
          e: for (let m = 0; m < u; m++) {
            const p = l[m], A = p.length;
            for (let b = 0; b < A; b++) {
              const I = this.LA(b + 1);
              if (n(I, p[b]) === !1)
                continue e;
            }
            return c;
          }
      }
    };
  if (s && !r) {
    const a = M(t, (c) => yt(c)), o = Je(a, (c, l, u) => (q(l, (f) => {
      z(c, f.tokenTypeIdx) || (c[f.tokenTypeIdx] = u), q(f.categoryMatches, (m) => {
        z(c, m) || (c[m] = u);
      });
    }), c), {});
    return function() {
      const c = this.LA(1);
      return o[c.tokenTypeIdx];
    };
  } else
    return function() {
      for (let a = 0; a < i; a++) {
        const o = t[a], c = o.length;
        e: for (let l = 0; l < c; l++) {
          const u = o[l], f = u.length;
          for (let m = 0; m < f; m++) {
            const p = this.LA(m + 1);
            if (n(p, u[m]) === !1)
              continue e;
          }
          return a;
        }
      }
    };
}
function Ng(t, e, n) {
  const r = kt(t, (s) => s.length === 1), i = t.length;
  if (r && !n) {
    const s = yt(t);
    if (s.length === 1 && ae(s[0].categoryMatches)) {
      const o = s[0].tokenTypeIdx;
      return function() {
        return this.LA(1).tokenTypeIdx === o;
      };
    } else {
      const a = Je(s, (o, c, l) => (o[c.tokenTypeIdx] = !0, q(c.categoryMatches, (u) => {
        o[u] = !0;
      }), o), []);
      return function() {
        const o = this.LA(1);
        return a[o.tokenTypeIdx] === !0;
      };
    }
  } else
    return function() {
      e: for (let s = 0; s < i; s++) {
        const a = t[s], o = a.length;
        for (let c = 0; c < o; c++) {
          const l = this.LA(c + 1);
          if (e(l, a[c]) === !1)
            continue e;
        }
        return !0;
      }
      return !1;
    };
}
class wg extends xa {
  constructor(e, n, r) {
    super(), this.topProd = e, this.targetOccurrence = n, this.targetProdType = r;
  }
  startWalking() {
    return this.walk(this.topProd), this.restDef;
  }
  checkIsTarget(e, n, r, i) {
    return e.idx === this.targetOccurrence && this.targetProdType === n ? (this.restDef = r.concat(i), !0) : !1;
  }
  walkOption(e, n, r) {
    this.checkIsTarget(e, ge.OPTION, n, r) || super.walkOption(e, n, r);
  }
  walkAtLeastOne(e, n, r) {
    this.checkIsTarget(e, ge.REPETITION_MANDATORY, n, r) || super.walkOption(e, n, r);
  }
  walkAtLeastOneSep(e, n, r) {
    this.checkIsTarget(e, ge.REPETITION_MANDATORY_WITH_SEPARATOR, n, r) || super.walkOption(e, n, r);
  }
  walkMany(e, n, r) {
    this.checkIsTarget(e, ge.REPETITION, n, r) || super.walkOption(e, n, r);
  }
  walkManySep(e, n, r) {
    this.checkIsTarget(e, ge.REPETITION_WITH_SEPARATOR, n, r) || super.walkOption(e, n, r);
  }
}
class yf extends Xr {
  constructor(e, n, r) {
    super(), this.targetOccurrence = e, this.targetProdType = n, this.targetRef = r, this.result = [];
  }
  checkIsTarget(e, n) {
    e.idx === this.targetOccurrence && this.targetProdType === n && (this.targetRef === void 0 || e === this.targetRef) && (this.result = e.definition);
  }
  visitOption(e) {
    this.checkIsTarget(e, ge.OPTION);
  }
  visitRepetition(e) {
    this.checkIsTarget(e, ge.REPETITION);
  }
  visitRepetitionMandatory(e) {
    this.checkIsTarget(e, ge.REPETITION_MANDATORY);
  }
  visitRepetitionMandatoryWithSeparator(e) {
    this.checkIsTarget(e, ge.REPETITION_MANDATORY_WITH_SEPARATOR);
  }
  visitRepetitionWithSeparator(e) {
    this.checkIsTarget(e, ge.REPETITION_WITH_SEPARATOR);
  }
  visitAlternation(e) {
    this.checkIsTarget(e, ge.ALTERNATION);
  }
}
function su(t) {
  const e = new Array(t);
  for (let n = 0; n < t; n++)
    e[n] = [];
  return e;
}
function Qa(t) {
  let e = [""];
  for (let n = 0; n < t.length; n++) {
    const r = t[n], i = [];
    for (let s = 0; s < e.length; s++) {
      const a = e[s];
      i.push(a + "_" + r.tokenTypeIdx);
      for (let o = 0; o < r.categoryMatches.length; o++) {
        const c = "_" + r.categoryMatches[o];
        i.push(a + c);
      }
    }
    e = i;
  }
  return e;
}
function bg(t, e, n) {
  for (let r = 0; r < t.length; r++) {
    if (r === n)
      continue;
    const i = t[r];
    for (let s = 0; s < e.length; s++) {
      const a = e[s];
      if (i[a] === !0)
        return !1;
    }
  }
  return !0;
}
function Tf(t, e) {
  const n = M(t, (a) => Po([a], 1)), r = su(n.length), i = M(n, (a) => {
    const o = {};
    return q(a, (c) => {
      const l = Qa(c.partialPath);
      q(l, (u) => {
        o[u] = !0;
      });
    }), o;
  });
  let s = n;
  for (let a = 1; a <= e; a++) {
    const o = s;
    s = su(o.length);
    for (let c = 0; c < o.length; c++) {
      const l = o[c];
      for (let u = 0; u < l.length; u++) {
        const f = l[u].partialPath, m = l[u].suffixDef, p = Qa(f);
        if (bg(i, p, c) || ae(m) || f.length === e) {
          const b = r[c];
          if ($o(b, f) === !1) {
            b.push(f);
            for (let I = 0; I < p.length; I++) {
              const C = p[I];
              i[c][C] = !0;
            }
          }
        } else {
          const b = Po(m, a + 1, f);
          s[c] = s[c].concat(b), q(b, (I) => {
            const C = Qa(I.partialPath);
            q(C, (N) => {
              i[c][N] = !0;
            });
          });
        }
      }
    }
  }
  return r;
}
function Fa(t, e, n, r) {
  const i = new yf(t, ge.ALTERNATION, r);
  return e.accept(i), Tf(i.result, n);
}
function Ga(t, e, n, r) {
  const i = new yf(t, n);
  e.accept(i);
  const s = i.result, o = new wg(e, t, n).startWalking(), c = new rt({ definition: s }), l = new rt({ definition: o });
  return Tf([c, l], r);
}
function $o(t, e) {
  e: for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (r.length === e.length) {
      for (let i = 0; i < r.length; i++) {
        const s = e[i], a = r[i];
        if ((s === a || a.categoryMatchesMap[s.tokenTypeIdx] !== void 0) === !1)
          continue e;
      }
      return !0;
    }
  }
  return !1;
}
function _g(t, e) {
  return t.length < e.length && kt(t, (n, r) => {
    const i = e[r];
    return n === i || i.categoryMatchesMap[n.tokenTypeIdx];
  });
}
function Rf(t) {
  return kt(t, (e) => kt(e, (n) => kt(n, (r) => ae(r.categoryMatches))));
}
function Ig(t) {
  const e = t.lookaheadStrategy.validate({
    rules: t.rules,
    tokenTypes: t.tokenTypes,
    grammarName: t.grammarName
  });
  return M(e, (n) => Object.assign({ type: Ze.CUSTOM_LOOKAHEAD_VALIDATION }, n));
}
function Pg(t, e, n, r) {
  const i = dt(t, (c) => $g(c, n)), s = Bg(t, e, n), a = dt(t, (c) => Ug(c, n)), o = dt(t, (c) => xg(c, t, r, n));
  return i.concat(s, a, o);
}
function $g(t, e) {
  const n = new Og();
  t.accept(n);
  const r = n.allProductions, i = up(r, Lg), s = wt(i, (o) => o.length > 1);
  return M($e(s), (o) => {
    const c = Nt(o), l = e.buildDuplicateFoundError(t, o), u = $t(c), f = {
      message: l,
      type: Ze.DUPLICATE_PRODUCTIONS,
      ruleName: t.name,
      dslName: u,
      occurrence: c.idx
    }, m = vf(c);
    return m && (f.parameter = m), f;
  });
}
function Lg(t) {
  return `${$t(t)}_#_${t.idx}_#_${vf(t)}`;
}
function vf(t) {
  return t instanceof le ? t.terminalType.name : t instanceof Qe ? t.nonTerminalName : "";
}
class Og extends Xr {
  constructor() {
    super(...arguments), this.allProductions = [];
  }
  visitNonTerminal(e) {
    this.allProductions.push(e);
  }
  visitOption(e) {
    this.allProductions.push(e);
  }
  visitRepetitionWithSeparator(e) {
    this.allProductions.push(e);
  }
  visitRepetitionMandatory(e) {
    this.allProductions.push(e);
  }
  visitRepetitionMandatoryWithSeparator(e) {
    this.allProductions.push(e);
  }
  visitRepetition(e) {
    this.allProductions.push(e);
  }
  visitAlternation(e) {
    this.allProductions.push(e);
  }
  visitTerminal(e) {
    this.allProductions.push(e);
  }
}
function xg(t, e, n, r) {
  const i = [];
  if (Je(e, (a, o) => o.name === t.name ? a + 1 : a, 0) > 1) {
    const a = r.buildDuplicateRuleNameError({
      topLevelRule: t,
      grammarName: n
    });
    i.push({
      message: a,
      type: Ze.DUPLICATE_RULE_NAME,
      ruleName: t.name
    });
  }
  return i;
}
function Dg(t, e, n) {
  const r = [];
  let i;
  return et(e, t) || (i = `Invalid rule override, rule: ->${t}<- cannot be overridden in the grammar: ->${n}<-as it is not defined in any of the super grammars `, r.push({
    message: i,
    type: Ze.INVALID_RULE_OVERRIDE,
    ruleName: t
  })), r;
}
function Ef(t, e, n, r = []) {
  const i = [], s = ea(e.definition);
  if (ae(s))
    return [];
  {
    const a = t.name;
    et(s, t) && i.push({
      message: n.buildLeftRecursionError({
        topLevelRule: t,
        leftRecursionPath: r
      }),
      type: Ze.LEFT_RECURSION,
      ruleName: a
    });
    const c = ba(s, r.concat([t])), l = dt(c, (u) => {
      const f = Be(r);
      return f.push(u), Ef(t, u, n, f);
    });
    return i.concat(l);
  }
}
function ea(t) {
  let e = [];
  if (ae(t))
    return e;
  const n = Nt(t);
  if (n instanceof Qe)
    e.push(n.referencedRule);
  else if (n instanceof rt || n instanceof ze || n instanceof pt || n instanceof mt || n instanceof it || n instanceof Ae)
    e = e.concat(ea(n.definition));
  else if (n instanceof st)
    e = yt(M(n.definition, (s) => ea(s.definition)));
  else if (!(n instanceof le)) throw Error("non exhaustive match");
  const r = da(n), i = t.length > 1;
  if (r && i) {
    const s = Ge(t);
    return e.concat(ea(s));
  } else
    return e;
}
class hl extends Xr {
  constructor() {
    super(...arguments), this.alternations = [];
  }
  visitAlternation(e) {
    this.alternations.push(e);
  }
}
function Mg(t, e) {
  const n = new hl();
  t.accept(n);
  const r = n.alternations;
  return dt(r, (s) => {
    const a = ji(s.definition);
    return dt(a, (o, c) => {
      const l = gf([o], [], as, 1);
      return ae(l) ? [
        {
          message: e.buildEmptyAlternationError({
            topLevelRule: t,
            alternation: s,
            emptyChoiceIdx: c
          }),
          type: Ze.NONE_LAST_EMPTY_ALT,
          ruleName: t.name,
          occurrence: s.idx,
          alternative: c + 1
        }
      ] : [];
    });
  });
}
function Fg(t, e, n) {
  const r = new hl();
  t.accept(r);
  let i = r.alternations;
  return i = _a(i, (a) => a.ignoreAmbiguities === !0), dt(i, (a) => {
    const o = a.idx, c = a.maxLookahead || e, l = Fa(o, t, c, a), u = jg(l, a, t, n), f = zg(l, a, t, n);
    return u.concat(f);
  });
}
class Gg extends Xr {
  constructor() {
    super(...arguments), this.allProductions = [];
  }
  visitRepetitionWithSeparator(e) {
    this.allProductions.push(e);
  }
  visitRepetitionMandatory(e) {
    this.allProductions.push(e);
  }
  visitRepetitionMandatoryWithSeparator(e) {
    this.allProductions.push(e);
  }
  visitRepetition(e) {
    this.allProductions.push(e);
  }
}
function Ug(t, e) {
  const n = new hl();
  t.accept(n);
  const r = n.alternations;
  return dt(r, (s) => s.definition.length > 255 ? [
    {
      message: e.buildTooManyAlternativesError({
        topLevelRule: t,
        alternation: s
      }),
      type: Ze.TOO_MANY_ALTS,
      ruleName: t.name,
      occurrence: s.idx
    }
  ] : []);
}
function qg(t, e, n) {
  const r = [];
  return q(t, (i) => {
    const s = new Gg();
    i.accept(s);
    const a = s.allProductions;
    q(a, (o) => {
      const c = fl(o), l = o.maxLookahead || e, u = o.idx, m = Ga(u, i, c, l)[0];
      if (ae(yt(m))) {
        const p = n.buildEmptyRepetitionError({
          topLevelRule: i,
          repetition: o
        });
        r.push({
          message: p,
          type: Ze.NO_NON_EMPTY_LOOKAHEAD,
          ruleName: i.name
        });
      }
    });
  }), r;
}
function jg(t, e, n, r) {
  const i = [], s = Je(t, (o, c, l) => (e.definition[l].ignoreAmbiguities === !0 || q(c, (u) => {
    const f = [l];
    q(t, (m, p) => {
      l !== p && $o(m, u) && // ignore (skip) ambiguities with this "other" alternative
      e.definition[p].ignoreAmbiguities !== !0 && f.push(p);
    }), f.length > 1 && !$o(i, u) && (i.push(u), o.push({
      alts: f,
      path: u
    }));
  }), o), []);
  return M(s, (o) => {
    const c = M(o.alts, (u) => u + 1);
    return {
      message: r.buildAlternationAmbiguityError({
        topLevelRule: n,
        alternation: e,
        ambiguityIndices: c,
        prefixPath: o.path
      }),
      type: Ze.AMBIGUOUS_ALTS,
      ruleName: n.name,
      occurrence: e.idx,
      alternatives: o.alts
    };
  });
}
function zg(t, e, n, r) {
  const i = Je(t, (a, o, c) => {
    const l = M(o, (u) => ({ idx: c, path: u }));
    return a.concat(l);
  }, []);
  return ts(dt(i, (a) => {
    if (e.definition[a.idx].ignoreAmbiguities === !0)
      return [];
    const c = a.idx, l = a.path, u = ht(i, (m) => (
      // ignore (skip) ambiguities with this "other" alternative
      e.definition[m.idx].ignoreAmbiguities !== !0 && m.idx < c && // checking for strict prefix because identical lookaheads
      // will be be detected using a different validation.
      _g(m.path, l)
    ));
    return M(u, (m) => {
      const p = [m.idx + 1, c + 1], A = e.idx === 0 ? "" : e.idx;
      return {
        message: r.buildAlternationPrefixAmbiguityError({
          topLevelRule: n,
          alternation: e,
          ambiguityIndices: p,
          prefixPath: m.path
        }),
        type: Ze.AMBIGUOUS_PREFIX_ALTS,
        ruleName: n.name,
        occurrence: A,
        alternatives: p
      };
    });
  }));
}
function Bg(t, e, n) {
  const r = [], i = M(e, (s) => s.name);
  return q(t, (s) => {
    const a = s.name;
    if (et(i, a)) {
      const o = n.buildNamespaceConflictError(s);
      r.push({
        message: o,
        type: Ze.CONFLICT_TOKENS_RULES_NAMESPACE,
        ruleName: a
      });
    }
  }), r;
}
function Wg(t) {
  const e = nl(t, {
    errMsgProvider: mg
  }), n = {};
  return q(t.rules, (r) => {
    n[r.name] = r;
  }), gg(n, e.errMsgProvider);
}
function Vg(t) {
  return t = nl(t, {
    errMsgProvider: Gn
  }), Pg(t.rules, t.tokenTypes, t.errMsgProvider, t.grammarName);
}
const Af = "MismatchedTokenException", Sf = "NoViableAltException", kf = "EarlyExitException", Cf = "NotAllInputParsedException", Nf = [
  Af,
  Sf,
  kf,
  Cf
];
Object.freeze(Nf);
function pa(t) {
  return et(Nf, t.name);
}
class Ua extends Error {
  constructor(e, n) {
    super(e), this.token = n, this.resyncedTokens = [], Object.setPrototypeOf(this, new.target.prototype), Error.captureStackTrace && Error.captureStackTrace(this, this.constructor);
  }
}
class wf extends Ua {
  constructor(e, n, r) {
    super(e, n), this.previousToken = r, this.name = Af;
  }
}
class Kg extends Ua {
  constructor(e, n, r) {
    super(e, n), this.previousToken = r, this.name = Sf;
  }
}
class Hg extends Ua {
  constructor(e, n) {
    super(e, n), this.name = Cf;
  }
}
class Yg extends Ua {
  constructor(e, n, r) {
    super(e, n), this.previousToken = r, this.name = kf;
  }
}
const Za = {}, bf = "InRuleRecoveryException";
class Xg extends Error {
  constructor(e) {
    super(e), this.name = bf;
  }
}
class Jg {
  initRecoverable(e) {
    this.firstAfterRepMap = {}, this.resyncFollows = {}, this.recoveryEnabled = z(e, "recoveryEnabled") ? e.recoveryEnabled : rn.recoveryEnabled, this.recoveryEnabled && (this.attemptInRepetitionRecovery = Qg);
  }
  getTokenToInsert(e) {
    const n = dl(e, "", NaN, NaN, NaN, NaN, NaN, NaN);
    return n.isInsertedInRecovery = !0, n;
  }
  canTokenTypeBeInsertedInRecovery(e) {
    return !0;
  }
  canTokenTypeBeDeletedInRecovery(e) {
    return !0;
  }
  tryInRepetitionRecovery(e, n, r, i) {
    const s = this.findReSyncTokenType(), a = this.exportLexerState(), o = [];
    let c = !1;
    const l = this.LA(1);
    let u = this.LA(1);
    const f = () => {
      const m = this.LA(0), p = this.errorMessageProvider.buildMismatchTokenMessage({
        expected: i,
        actual: l,
        previous: m,
        ruleName: this.getCurrRuleFullName()
      }), A = new wf(p, l, this.LA(0));
      A.resyncedTokens = ji(o), this.SAVE_ERROR(A);
    };
    for (; !c; )
      if (this.tokenMatcher(u, i)) {
        f();
        return;
      } else if (r.call(this)) {
        f(), e.apply(this, n);
        return;
      } else this.tokenMatcher(u, s) ? c = !0 : (u = this.SKIP_TOKEN(), this.addToResyncTokens(u, o));
    this.importLexerState(a);
  }
  shouldInRepetitionRecoveryBeTried(e, n, r) {
    return !(r === !1 || this.tokenMatcher(this.LA(1), e) || this.isBackTracking() || this.canPerformInRuleRecovery(e, this.getFollowsForInRuleRecovery(e, n)));
  }
  // Error Recovery functionality
  getFollowsForInRuleRecovery(e, n) {
    const r = this.getCurrentGrammarPath(e, n);
    return this.getNextPossibleTokenTypes(r);
  }
  tryInRuleRecovery(e, n) {
    if (this.canRecoverWithSingleTokenInsertion(e, n))
      return this.getTokenToInsert(e);
    if (this.canRecoverWithSingleTokenDeletion(e)) {
      const r = this.SKIP_TOKEN();
      return this.consumeToken(), r;
    }
    throw new Xg("sad sad panda");
  }
  canPerformInRuleRecovery(e, n) {
    return this.canRecoverWithSingleTokenInsertion(e, n) || this.canRecoverWithSingleTokenDeletion(e);
  }
  canRecoverWithSingleTokenInsertion(e, n) {
    if (!this.canTokenTypeBeInsertedInRecovery(e) || ae(n))
      return !1;
    const r = this.LA(1);
    return qr(n, (s) => this.tokenMatcher(r, s)) !== void 0;
  }
  canRecoverWithSingleTokenDeletion(e) {
    return this.canTokenTypeBeDeletedInRecovery(e) ? this.tokenMatcher(this.LA(2), e) : !1;
  }
  isInCurrentRuleReSyncSet(e) {
    const n = this.getCurrFollowKey(), r = this.getFollowSetFromFollowKey(n);
    return et(r, e);
  }
  findReSyncTokenType() {
    const e = this.flattenFollowSet();
    let n = this.LA(1), r = 2;
    for (; ; ) {
      const i = qr(e, (s) => mf(n, s));
      if (i !== void 0)
        return i;
      n = this.LA(r), r++;
    }
  }
  getCurrFollowKey() {
    if (this.RULE_STACK.length === 1)
      return Za;
    const e = this.getLastExplicitRuleShortName(), n = this.getLastExplicitRuleOccurrenceIndex(), r = this.getPreviousExplicitRuleShortName();
    return {
      ruleName: this.shortRuleNameToFullName(e),
      idxInCallingRule: n,
      inRule: this.shortRuleNameToFullName(r)
    };
  }
  buildFullFollowKeyStack() {
    const e = this.RULE_STACK, n = this.RULE_OCCURRENCE_STACK;
    return M(e, (r, i) => i === 0 ? Za : {
      ruleName: this.shortRuleNameToFullName(r),
      idxInCallingRule: n[i],
      inRule: this.shortRuleNameToFullName(e[i - 1])
    });
  }
  flattenFollowSet() {
    const e = M(this.buildFullFollowKeyStack(), (n) => this.getFollowSetFromFollowKey(n));
    return yt(e);
  }
  getFollowSetFromFollowKey(e) {
    if (e === Za)
      return [fn];
    const n = e.ruleName + e.idxInCallingRule + sf + e.inRule;
    return this.resyncFollows[n];
  }
  // It does not make any sense to include a virtual EOF token in the list of resynced tokens
  // as EOF does not really exist and thus does not contain any useful information (line/column numbers)
  addToResyncTokens(e, n) {
    return this.tokenMatcher(e, fn) || n.push(e), n;
  }
  reSyncTo(e) {
    const n = [];
    let r = this.LA(1);
    for (; this.tokenMatcher(r, e) === !1; )
      r = this.SKIP_TOKEN(), this.addToResyncTokens(r, n);
    return ji(n);
  }
  attemptInRepetitionRecovery(e, n, r, i, s, a, o) {
  }
  getCurrentGrammarPath(e, n) {
    const r = this.getHumanReadableRuleStack(), i = Be(this.RULE_OCCURRENCE_STACK);
    return {
      ruleStack: r,
      occurrenceStack: i,
      lastTok: e,
      lastTokOccurrence: n
    };
  }
  getHumanReadableRuleStack() {
    return M(this.RULE_STACK, (e) => this.shortRuleNameToFullName(e));
  }
}
function Qg(t, e, n, r, i, s, a) {
  const o = this.getKeyForAutomaticLookahead(r, i);
  let c = this.firstAfterRepMap[o];
  if (c === void 0) {
    const m = this.getCurrRuleFullName(), p = this.getGAstProductions()[m];
    c = new s(p, i).startWalking(), this.firstAfterRepMap[o] = c;
  }
  let l = c.token, u = c.occurrence;
  const f = c.isEndOfRule;
  this.RULE_STACK.length === 1 && f && l === void 0 && (l = fn, u = 1), !(l === void 0 || u === void 0) && this.shouldInRepetitionRecoveryBeTried(l, u, a) && this.tryInRepetitionRecovery(t, e, n, l);
}
const Zg = 4, pn = 8, _f = 1 << pn, If = 2 << pn, Lo = 3 << pn, Oo = 4 << pn, xo = 5 << pn, ta = 6 << pn;
function eo(t, e, n) {
  return n | e | t;
}
class pl {
  constructor(e) {
    var n;
    this.maxLookahead = (n = e?.maxLookahead) !== null && n !== void 0 ? n : rn.maxLookahead;
  }
  validate(e) {
    const n = this.validateNoLeftRecursion(e.rules);
    if (ae(n)) {
      const r = this.validateEmptyOrAlternatives(e.rules), i = this.validateAmbiguousAlternationAlternatives(e.rules, this.maxLookahead), s = this.validateSomeNonEmptyLookaheadPath(e.rules, this.maxLookahead);
      return [
        ...n,
        ...r,
        ...i,
        ...s
      ];
    }
    return n;
  }
  validateNoLeftRecursion(e) {
    return dt(e, (n) => Ef(n, n, Gn));
  }
  validateEmptyOrAlternatives(e) {
    return dt(e, (n) => Mg(n, Gn));
  }
  validateAmbiguousAlternationAlternatives(e, n) {
    return dt(e, (r) => Fg(r, n, Gn));
  }
  validateSomeNonEmptyLookaheadPath(e, n) {
    return qg(e, n, Gn);
  }
  buildLookaheadForAlternation(e) {
    return Sg(e.prodOccurrence, e.rule, e.maxLookahead, e.hasPredicates, e.dynamicTokensEnabled, Cg);
  }
  buildLookaheadForOptional(e) {
    return kg(e.prodOccurrence, e.rule, e.maxLookahead, e.dynamicTokensEnabled, fl(e.prodType), Ng);
  }
}
class ey {
  initLooksAhead(e) {
    this.dynamicTokensEnabled = z(e, "dynamicTokensEnabled") ? e.dynamicTokensEnabled : rn.dynamicTokensEnabled, this.maxLookahead = z(e, "maxLookahead") ? e.maxLookahead : rn.maxLookahead, this.lookaheadStrategy = z(e, "lookaheadStrategy") ? e.lookaheadStrategy : new pl({ maxLookahead: this.maxLookahead }), this.lookAheadFuncsCache = /* @__PURE__ */ new Map();
  }
  preComputeLookaheadFunctions(e) {
    q(e, (n) => {
      this.TRACE_INIT(`${n.name} Rule Lookahead`, () => {
        const { alternation: r, repetition: i, option: s, repetitionMandatory: a, repetitionMandatoryWithSeparator: o, repetitionWithSeparator: c } = ny(n);
        q(r, (l) => {
          const u = l.idx === 0 ? "" : l.idx;
          this.TRACE_INIT(`${$t(l)}${u}`, () => {
            const f = this.lookaheadStrategy.buildLookaheadForAlternation({
              prodOccurrence: l.idx,
              rule: n,
              maxLookahead: l.maxLookahead || this.maxLookahead,
              hasPredicates: l.hasPredicates,
              dynamicTokensEnabled: this.dynamicTokensEnabled
            }), m = eo(this.fullRuleNameToShort[n.name], _f, l.idx);
            this.setLaFuncCache(m, f);
          });
        }), q(i, (l) => {
          this.computeLookaheadFunc(n, l.idx, Lo, "Repetition", l.maxLookahead, $t(l));
        }), q(s, (l) => {
          this.computeLookaheadFunc(n, l.idx, If, "Option", l.maxLookahead, $t(l));
        }), q(a, (l) => {
          this.computeLookaheadFunc(n, l.idx, Oo, "RepetitionMandatory", l.maxLookahead, $t(l));
        }), q(o, (l) => {
          this.computeLookaheadFunc(n, l.idx, ta, "RepetitionMandatoryWithSeparator", l.maxLookahead, $t(l));
        }), q(c, (l) => {
          this.computeLookaheadFunc(n, l.idx, xo, "RepetitionWithSeparator", l.maxLookahead, $t(l));
        });
      });
    });
  }
  computeLookaheadFunc(e, n, r, i, s, a) {
    this.TRACE_INIT(`${a}${n === 0 ? "" : n}`, () => {
      const o = this.lookaheadStrategy.buildLookaheadForOptional({
        prodOccurrence: n,
        rule: e,
        maxLookahead: s || this.maxLookahead,
        dynamicTokensEnabled: this.dynamicTokensEnabled,
        prodType: i
      }), c = eo(this.fullRuleNameToShort[e.name], r, n);
      this.setLaFuncCache(c, o);
    });
  }
  // this actually returns a number, but it is always used as a string (object prop key)
  getKeyForAutomaticLookahead(e, n) {
    const r = this.getLastExplicitRuleShortName();
    return eo(r, e, n);
  }
  getLaFuncFromCache(e) {
    return this.lookAheadFuncsCache.get(e);
  }
  /* istanbul ignore next */
  setLaFuncCache(e, n) {
    this.lookAheadFuncsCache.set(e, n);
  }
}
class ty extends Xr {
  constructor() {
    super(...arguments), this.dslMethods = {
      option: [],
      alternation: [],
      repetition: [],
      repetitionWithSeparator: [],
      repetitionMandatory: [],
      repetitionMandatoryWithSeparator: []
    };
  }
  reset() {
    this.dslMethods = {
      option: [],
      alternation: [],
      repetition: [],
      repetitionWithSeparator: [],
      repetitionMandatory: [],
      repetitionMandatoryWithSeparator: []
    };
  }
  visitOption(e) {
    this.dslMethods.option.push(e);
  }
  visitRepetitionWithSeparator(e) {
    this.dslMethods.repetitionWithSeparator.push(e);
  }
  visitRepetitionMandatory(e) {
    this.dslMethods.repetitionMandatory.push(e);
  }
  visitRepetitionMandatoryWithSeparator(e) {
    this.dslMethods.repetitionMandatoryWithSeparator.push(e);
  }
  visitRepetition(e) {
    this.dslMethods.repetition.push(e);
  }
  visitAlternation(e) {
    this.dslMethods.alternation.push(e);
  }
}
const xs = new ty();
function ny(t) {
  xs.reset(), t.accept(xs);
  const e = xs.dslMethods;
  return xs.reset(), e;
}
function au(t, e) {
  isNaN(t.startOffset) === !0 ? (t.startOffset = e.startOffset, t.endOffset = e.endOffset) : t.endOffset < e.endOffset && (t.endOffset = e.endOffset);
}
function ou(t, e) {
  isNaN(t.startOffset) === !0 ? (t.startOffset = e.startOffset, t.startColumn = e.startColumn, t.startLine = e.startLine, t.endOffset = e.endOffset, t.endColumn = e.endColumn, t.endLine = e.endLine) : t.endOffset < e.endOffset && (t.endOffset = e.endOffset, t.endColumn = e.endColumn, t.endLine = e.endLine);
}
function ry(t, e, n) {
  t.children[n] === void 0 ? t.children[n] = [e] : t.children[n].push(e);
}
function iy(t, e, n) {
  t.children[e] === void 0 ? t.children[e] = [n] : t.children[e].push(n);
}
const sy = "name";
function Pf(t, e) {
  Object.defineProperty(t, sy, {
    enumerable: !1,
    configurable: !0,
    writable: !1,
    value: e
  });
}
function ay(t, e) {
  const n = Ur(t), r = n.length;
  for (let i = 0; i < r; i++) {
    const s = n[i], a = t[s], o = a.length;
    for (let c = 0; c < o; c++) {
      const l = a[c];
      l.tokenTypeIdx === void 0 && this[l.name](l.children, e);
    }
  }
}
function oy(t, e) {
  const n = function() {
  };
  Pf(n, t + "BaseSemantics");
  const r = {
    visit: function(i, s) {
      if (je(i) && (i = i[0]), !tn(i))
        return this[i.name](i.children, s);
    },
    validateVisitor: function() {
      const i = ly(this, e);
      if (!ae(i)) {
        const s = M(i, (a) => a.msg);
        throw Error(`Errors Detected in CST Visitor <${this.constructor.name}>:
	${s.join(`

`).replace(/\n/g, `
	`)}`);
      }
    }
  };
  return n.prototype = r, n.prototype.constructor = n, n._RULE_NAMES = e, n;
}
function cy(t, e, n) {
  const r = function() {
  };
  Pf(r, t + "BaseSemanticsWithDefaults");
  const i = Object.create(n.prototype);
  return q(e, (s) => {
    i[s] = ay;
  }), r.prototype = i, r.prototype.constructor = r, r;
}
var Do;
(function(t) {
  t[t.REDUNDANT_METHOD = 0] = "REDUNDANT_METHOD", t[t.MISSING_METHOD = 1] = "MISSING_METHOD";
})(Do || (Do = {}));
function ly(t, e) {
  return uy(t, e);
}
function uy(t, e) {
  const n = ht(e, (i) => Hn(t[i]) === !1), r = M(n, (i) => ({
    msg: `Missing visitor method: <${i}> on ${t.constructor.name} CST Visitor.`,
    type: Do.MISSING_METHOD,
    methodName: i
  }));
  return ts(r);
}
class dy {
  initTreeBuilder(e) {
    if (this.CST_STACK = [], this.outputCst = e.outputCst, this.nodeLocationTracking = z(e, "nodeLocationTracking") ? e.nodeLocationTracking : rn.nodeLocationTracking, !this.outputCst)
      this.cstInvocationStateUpdate = Fe, this.cstFinallyStateUpdate = Fe, this.cstPostTerminal = Fe, this.cstPostNonTerminal = Fe, this.cstPostRule = Fe;
    else if (/full/i.test(this.nodeLocationTracking))
      this.recoveryEnabled ? (this.setNodeLocationFromToken = ou, this.setNodeLocationFromNode = ou, this.cstPostRule = Fe, this.setInitialNodeLocation = this.setInitialNodeLocationFullRecovery) : (this.setNodeLocationFromToken = Fe, this.setNodeLocationFromNode = Fe, this.cstPostRule = this.cstPostRuleFull, this.setInitialNodeLocation = this.setInitialNodeLocationFullRegular);
    else if (/onlyOffset/i.test(this.nodeLocationTracking))
      this.recoveryEnabled ? (this.setNodeLocationFromToken = au, this.setNodeLocationFromNode = au, this.cstPostRule = Fe, this.setInitialNodeLocation = this.setInitialNodeLocationOnlyOffsetRecovery) : (this.setNodeLocationFromToken = Fe, this.setNodeLocationFromNode = Fe, this.cstPostRule = this.cstPostRuleOnlyOffset, this.setInitialNodeLocation = this.setInitialNodeLocationOnlyOffsetRegular);
    else if (/none/i.test(this.nodeLocationTracking))
      this.setNodeLocationFromToken = Fe, this.setNodeLocationFromNode = Fe, this.cstPostRule = Fe, this.setInitialNodeLocation = Fe;
    else
      throw Error(`Invalid <nodeLocationTracking> config option: "${e.nodeLocationTracking}"`);
  }
  setInitialNodeLocationOnlyOffsetRecovery(e) {
    e.location = {
      startOffset: NaN,
      endOffset: NaN
    };
  }
  setInitialNodeLocationOnlyOffsetRegular(e) {
    e.location = {
      // without error recovery the starting Location of a new CstNode is guaranteed
      // To be the next Token's startOffset (for valid inputs).
      // For invalid inputs there won't be any CSTOutput so this potential
      // inaccuracy does not matter
      startOffset: this.LA(1).startOffset,
      endOffset: NaN
    };
  }
  setInitialNodeLocationFullRecovery(e) {
    e.location = {
      startOffset: NaN,
      startLine: NaN,
      startColumn: NaN,
      endOffset: NaN,
      endLine: NaN,
      endColumn: NaN
    };
  }
  /**
       *  @see setInitialNodeLocationOnlyOffsetRegular for explanation why this work
  
       * @param cstNode
       */
  setInitialNodeLocationFullRegular(e) {
    const n = this.LA(1);
    e.location = {
      startOffset: n.startOffset,
      startLine: n.startLine,
      startColumn: n.startColumn,
      endOffset: NaN,
      endLine: NaN,
      endColumn: NaN
    };
  }
  cstInvocationStateUpdate(e) {
    const n = {
      name: e,
      children: /* @__PURE__ */ Object.create(null)
    };
    this.setInitialNodeLocation(n), this.CST_STACK.push(n);
  }
  cstFinallyStateUpdate() {
    this.CST_STACK.pop();
  }
  cstPostRuleFull(e) {
    const n = this.LA(0), r = e.location;
    r.startOffset <= n.startOffset ? (r.endOffset = n.endOffset, r.endLine = n.endLine, r.endColumn = n.endColumn) : (r.startOffset = NaN, r.startLine = NaN, r.startColumn = NaN);
  }
  cstPostRuleOnlyOffset(e) {
    const n = this.LA(0), r = e.location;
    r.startOffset <= n.startOffset ? r.endOffset = n.endOffset : r.startOffset = NaN;
  }
  cstPostTerminal(e, n) {
    const r = this.CST_STACK[this.CST_STACK.length - 1];
    ry(r, n, e), this.setNodeLocationFromToken(r.location, n);
  }
  cstPostNonTerminal(e, n) {
    const r = this.CST_STACK[this.CST_STACK.length - 1];
    iy(r, n, e), this.setNodeLocationFromNode(r.location, e.location);
  }
  getBaseCstVisitorConstructor() {
    if (tn(this.baseCstVisitorConstructor)) {
      const e = oy(this.className, Ur(this.gastProductionsCache));
      return this.baseCstVisitorConstructor = e, e;
    }
    return this.baseCstVisitorConstructor;
  }
  getBaseCstVisitorConstructorWithDefaults() {
    if (tn(this.baseCstVisitorWithDefaultsConstructor)) {
      const e = cy(this.className, Ur(this.gastProductionsCache), this.getBaseCstVisitorConstructor());
      return this.baseCstVisitorWithDefaultsConstructor = e, e;
    }
    return this.baseCstVisitorWithDefaultsConstructor;
  }
  getLastExplicitRuleShortName() {
    const e = this.RULE_STACK;
    return e[e.length - 1];
  }
  getPreviousExplicitRuleShortName() {
    const e = this.RULE_STACK;
    return e[e.length - 2];
  }
  getLastExplicitRuleOccurrenceIndex() {
    const e = this.RULE_OCCURRENCE_STACK;
    return e[e.length - 1];
  }
}
class fy {
  initLexerAdapter() {
    this.tokVector = [], this.tokVectorLength = 0, this.currIdx = -1;
  }
  set input(e) {
    if (this.selfAnalysisDone !== !0)
      throw Error("Missing <performSelfAnalysis> invocation at the end of the Parser's constructor.");
    this.reset(), this.tokVector = e, this.tokVectorLength = e.length;
  }
  get input() {
    return this.tokVector;
  }
  // skips a token and returns the next token
  SKIP_TOKEN() {
    return this.currIdx <= this.tokVector.length - 2 ? (this.consumeToken(), this.LA(1)) : ga;
  }
  // Lexer (accessing Token vector) related methods which can be overridden to implement lazy lexers
  // or lexers dependent on parser context.
  LA(e) {
    const n = this.currIdx + e;
    return n < 0 || this.tokVectorLength <= n ? ga : this.tokVector[n];
  }
  consumeToken() {
    this.currIdx++;
  }
  exportLexerState() {
    return this.currIdx;
  }
  importLexerState(e) {
    this.currIdx = e;
  }
  resetLexerState() {
    this.currIdx = -1;
  }
  moveToTerminatedState() {
    this.currIdx = this.tokVector.length - 1;
  }
  getLexerPosition() {
    return this.exportLexerState();
  }
}
class hy {
  ACTION(e) {
    return e.call(this);
  }
  consume(e, n, r) {
    return this.consumeInternal(n, e, r);
  }
  subrule(e, n, r) {
    return this.subruleInternal(n, e, r);
  }
  option(e, n) {
    return this.optionInternal(n, e);
  }
  or(e, n) {
    return this.orInternal(n, e);
  }
  many(e, n) {
    return this.manyInternal(e, n);
  }
  atLeastOne(e, n) {
    return this.atLeastOneInternal(e, n);
  }
  CONSUME(e, n) {
    return this.consumeInternal(e, 0, n);
  }
  CONSUME1(e, n) {
    return this.consumeInternal(e, 1, n);
  }
  CONSUME2(e, n) {
    return this.consumeInternal(e, 2, n);
  }
  CONSUME3(e, n) {
    return this.consumeInternal(e, 3, n);
  }
  CONSUME4(e, n) {
    return this.consumeInternal(e, 4, n);
  }
  CONSUME5(e, n) {
    return this.consumeInternal(e, 5, n);
  }
  CONSUME6(e, n) {
    return this.consumeInternal(e, 6, n);
  }
  CONSUME7(e, n) {
    return this.consumeInternal(e, 7, n);
  }
  CONSUME8(e, n) {
    return this.consumeInternal(e, 8, n);
  }
  CONSUME9(e, n) {
    return this.consumeInternal(e, 9, n);
  }
  SUBRULE(e, n) {
    return this.subruleInternal(e, 0, n);
  }
  SUBRULE1(e, n) {
    return this.subruleInternal(e, 1, n);
  }
  SUBRULE2(e, n) {
    return this.subruleInternal(e, 2, n);
  }
  SUBRULE3(e, n) {
    return this.subruleInternal(e, 3, n);
  }
  SUBRULE4(e, n) {
    return this.subruleInternal(e, 4, n);
  }
  SUBRULE5(e, n) {
    return this.subruleInternal(e, 5, n);
  }
  SUBRULE6(e, n) {
    return this.subruleInternal(e, 6, n);
  }
  SUBRULE7(e, n) {
    return this.subruleInternal(e, 7, n);
  }
  SUBRULE8(e, n) {
    return this.subruleInternal(e, 8, n);
  }
  SUBRULE9(e, n) {
    return this.subruleInternal(e, 9, n);
  }
  OPTION(e) {
    return this.optionInternal(e, 0);
  }
  OPTION1(e) {
    return this.optionInternal(e, 1);
  }
  OPTION2(e) {
    return this.optionInternal(e, 2);
  }
  OPTION3(e) {
    return this.optionInternal(e, 3);
  }
  OPTION4(e) {
    return this.optionInternal(e, 4);
  }
  OPTION5(e) {
    return this.optionInternal(e, 5);
  }
  OPTION6(e) {
    return this.optionInternal(e, 6);
  }
  OPTION7(e) {
    return this.optionInternal(e, 7);
  }
  OPTION8(e) {
    return this.optionInternal(e, 8);
  }
  OPTION9(e) {
    return this.optionInternal(e, 9);
  }
  OR(e) {
    return this.orInternal(e, 0);
  }
  OR1(e) {
    return this.orInternal(e, 1);
  }
  OR2(e) {
    return this.orInternal(e, 2);
  }
  OR3(e) {
    return this.orInternal(e, 3);
  }
  OR4(e) {
    return this.orInternal(e, 4);
  }
  OR5(e) {
    return this.orInternal(e, 5);
  }
  OR6(e) {
    return this.orInternal(e, 6);
  }
  OR7(e) {
    return this.orInternal(e, 7);
  }
  OR8(e) {
    return this.orInternal(e, 8);
  }
  OR9(e) {
    return this.orInternal(e, 9);
  }
  MANY(e) {
    this.manyInternal(0, e);
  }
  MANY1(e) {
    this.manyInternal(1, e);
  }
  MANY2(e) {
    this.manyInternal(2, e);
  }
  MANY3(e) {
    this.manyInternal(3, e);
  }
  MANY4(e) {
    this.manyInternal(4, e);
  }
  MANY5(e) {
    this.manyInternal(5, e);
  }
  MANY6(e) {
    this.manyInternal(6, e);
  }
  MANY7(e) {
    this.manyInternal(7, e);
  }
  MANY8(e) {
    this.manyInternal(8, e);
  }
  MANY9(e) {
    this.manyInternal(9, e);
  }
  MANY_SEP(e) {
    this.manySepFirstInternal(0, e);
  }
  MANY_SEP1(e) {
    this.manySepFirstInternal(1, e);
  }
  MANY_SEP2(e) {
    this.manySepFirstInternal(2, e);
  }
  MANY_SEP3(e) {
    this.manySepFirstInternal(3, e);
  }
  MANY_SEP4(e) {
    this.manySepFirstInternal(4, e);
  }
  MANY_SEP5(e) {
    this.manySepFirstInternal(5, e);
  }
  MANY_SEP6(e) {
    this.manySepFirstInternal(6, e);
  }
  MANY_SEP7(e) {
    this.manySepFirstInternal(7, e);
  }
  MANY_SEP8(e) {
    this.manySepFirstInternal(8, e);
  }
  MANY_SEP9(e) {
    this.manySepFirstInternal(9, e);
  }
  AT_LEAST_ONE(e) {
    this.atLeastOneInternal(0, e);
  }
  AT_LEAST_ONE1(e) {
    return this.atLeastOneInternal(1, e);
  }
  AT_LEAST_ONE2(e) {
    this.atLeastOneInternal(2, e);
  }
  AT_LEAST_ONE3(e) {
    this.atLeastOneInternal(3, e);
  }
  AT_LEAST_ONE4(e) {
    this.atLeastOneInternal(4, e);
  }
  AT_LEAST_ONE5(e) {
    this.atLeastOneInternal(5, e);
  }
  AT_LEAST_ONE6(e) {
    this.atLeastOneInternal(6, e);
  }
  AT_LEAST_ONE7(e) {
    this.atLeastOneInternal(7, e);
  }
  AT_LEAST_ONE8(e) {
    this.atLeastOneInternal(8, e);
  }
  AT_LEAST_ONE9(e) {
    this.atLeastOneInternal(9, e);
  }
  AT_LEAST_ONE_SEP(e) {
    this.atLeastOneSepFirstInternal(0, e);
  }
  AT_LEAST_ONE_SEP1(e) {
    this.atLeastOneSepFirstInternal(1, e);
  }
  AT_LEAST_ONE_SEP2(e) {
    this.atLeastOneSepFirstInternal(2, e);
  }
  AT_LEAST_ONE_SEP3(e) {
    this.atLeastOneSepFirstInternal(3, e);
  }
  AT_LEAST_ONE_SEP4(e) {
    this.atLeastOneSepFirstInternal(4, e);
  }
  AT_LEAST_ONE_SEP5(e) {
    this.atLeastOneSepFirstInternal(5, e);
  }
  AT_LEAST_ONE_SEP6(e) {
    this.atLeastOneSepFirstInternal(6, e);
  }
  AT_LEAST_ONE_SEP7(e) {
    this.atLeastOneSepFirstInternal(7, e);
  }
  AT_LEAST_ONE_SEP8(e) {
    this.atLeastOneSepFirstInternal(8, e);
  }
  AT_LEAST_ONE_SEP9(e) {
    this.atLeastOneSepFirstInternal(9, e);
  }
  RULE(e, n, r = ya) {
    if (et(this.definedRulesNames, e)) {
      const a = {
        message: Gn.buildDuplicateRuleNameError({
          topLevelRule: e,
          grammarName: this.className
        }),
        type: Ze.DUPLICATE_RULE_NAME,
        ruleName: e
      };
      this.definitionErrors.push(a);
    }
    this.definedRulesNames.push(e);
    const i = this.defineRule(e, n, r);
    return this[e] = i, i;
  }
  OVERRIDE_RULE(e, n, r = ya) {
    const i = Dg(e, this.definedRulesNames, this.className);
    this.definitionErrors = this.definitionErrors.concat(i);
    const s = this.defineRule(e, n, r);
    return this[e] = s, s;
  }
  BACKTRACK(e, n) {
    return function() {
      this.isBackTrackingStack.push(1);
      const r = this.saveRecogState();
      try {
        return e.apply(this, n), !0;
      } catch (i) {
        if (pa(i))
          return !1;
        throw i;
      } finally {
        this.reloadRecogState(r), this.isBackTrackingStack.pop();
      }
    };
  }
  // GAST export APIs
  getGAstProductions() {
    return this.gastProductionsCache;
  }
  getSerializedGastProductions() {
    return Em($e(this.gastProductionsCache));
  }
}
class py {
  initRecognizerEngine(e, n) {
    if (this.className = this.constructor.name, this.shortRuleNameToFull = {}, this.fullRuleNameToShort = {}, this.ruleShortNameIdx = 256, this.tokenMatcher = ha, this.subruleIdx = 0, this.definedRulesNames = [], this.tokensMap = {}, this.isBackTrackingStack = [], this.RULE_STACK = [], this.RULE_OCCURRENCE_STACK = [], this.gastProductionsCache = {}, z(n, "serializedGrammar"))
      throw Error(`The Parser's configuration can no longer contain a <serializedGrammar> property.
	See: https://chevrotain.io/docs/changes/BREAKING_CHANGES.html#_6-0-0
	For Further details.`);
    if (je(e)) {
      if (ae(e))
        throw Error(`A Token Vocabulary cannot be empty.
	Note that the first argument for the parser constructor
	is no longer a Token vector (since v4.0).`);
      if (typeof e[0].startOffset == "number")
        throw Error(`The Parser constructor no longer accepts a token vector as the first argument.
	See: https://chevrotain.io/docs/changes/BREAKING_CHANGES.html#_4-0-0
	For Further details.`);
    }
    if (je(e))
      this.tokensMap = Je(e, (s, a) => (s[a.name] = a, s), {});
    else if (z(e, "modes") && kt(yt($e(e.modes)), fg)) {
      const s = yt($e(e.modes)), a = rl(s);
      this.tokensMap = Je(a, (o, c) => (o[c.name] = c, o), {});
    } else if (qh(e))
      this.tokensMap = Be(e);
    else
      throw new Error("<tokensDictionary> argument must be An Array of Token constructors, A dictionary of Token constructors or an IMultiModeLexerDefinition");
    this.tokensMap.EOF = fn;
    const r = z(e, "modes") ? yt($e(e.modes)) : $e(e), i = kt(r, (s) => ae(s.categoryMatches));
    this.tokenMatcher = i ? ha : as, os($e(this.tokensMap));
  }
  defineRule(e, n, r) {
    if (this.selfAnalysisDone)
      throw Error(`Grammar rule <${e}> may not be defined after the 'performSelfAnalysis' method has been called'
Make sure that all grammar rule definitions are done before 'performSelfAnalysis' is called.`);
    const i = z(r, "resyncEnabled") ? r.resyncEnabled : ya.resyncEnabled, s = z(r, "recoveryValueFunc") ? r.recoveryValueFunc : ya.recoveryValueFunc, a = this.ruleShortNameIdx << Zg + pn;
    this.ruleShortNameIdx++, this.shortRuleNameToFull[a] = e, this.fullRuleNameToShort[e] = a;
    let o;
    return this.outputCst === !0 ? o = function(...u) {
      try {
        this.ruleInvocationStateUpdate(a, e, this.subruleIdx), n.apply(this, u);
        const f = this.CST_STACK[this.CST_STACK.length - 1];
        return this.cstPostRule(f), f;
      } catch (f) {
        return this.invokeRuleCatch(f, i, s);
      } finally {
        this.ruleFinallyStateUpdate();
      }
    } : o = function(...u) {
      try {
        return this.ruleInvocationStateUpdate(a, e, this.subruleIdx), n.apply(this, u);
      } catch (f) {
        return this.invokeRuleCatch(f, i, s);
      } finally {
        this.ruleFinallyStateUpdate();
      }
    }, Object.assign(o, { ruleName: e, originalGrammarAction: n });
  }
  invokeRuleCatch(e, n, r) {
    const i = this.RULE_STACK.length === 1, s = n && !this.isBackTracking() && this.recoveryEnabled;
    if (pa(e)) {
      const a = e;
      if (s) {
        const o = this.findReSyncTokenType();
        if (this.isInCurrentRuleReSyncSet(o))
          if (a.resyncedTokens = this.reSyncTo(o), this.outputCst) {
            const c = this.CST_STACK[this.CST_STACK.length - 1];
            return c.recoveredNode = !0, c;
          } else
            return r(e);
        else {
          if (this.outputCst) {
            const c = this.CST_STACK[this.CST_STACK.length - 1];
            c.recoveredNode = !0, a.partialCstResult = c;
          }
          throw a;
        }
      } else {
        if (i)
          return this.moveToTerminatedState(), r(e);
        throw a;
      }
    } else
      throw e;
  }
  // Implementation of parsing DSL
  optionInternal(e, n) {
    const r = this.getKeyForAutomaticLookahead(If, n);
    return this.optionInternalLogic(e, n, r);
  }
  optionInternalLogic(e, n, r) {
    let i = this.getLaFuncFromCache(r), s;
    if (typeof e != "function") {
      s = e.DEF;
      const a = e.GATE;
      if (a !== void 0) {
        const o = i;
        i = () => a.call(this) && o.call(this);
      }
    } else
      s = e;
    if (i.call(this) === !0)
      return s.call(this);
  }
  atLeastOneInternal(e, n) {
    const r = this.getKeyForAutomaticLookahead(Oo, e);
    return this.atLeastOneInternalLogic(e, n, r);
  }
  atLeastOneInternalLogic(e, n, r) {
    let i = this.getLaFuncFromCache(r), s;
    if (typeof n != "function") {
      s = n.DEF;
      const a = n.GATE;
      if (a !== void 0) {
        const o = i;
        i = () => a.call(this) && o.call(this);
      }
    } else
      s = n;
    if (i.call(this) === !0) {
      let a = this.doSingleRepetition(s);
      for (; i.call(this) === !0 && a === !0; )
        a = this.doSingleRepetition(s);
    } else
      throw this.raiseEarlyExitException(e, ge.REPETITION_MANDATORY, n.ERR_MSG);
    this.attemptInRepetitionRecovery(this.atLeastOneInternal, [e, n], i, Oo, e, Eg);
  }
  atLeastOneSepFirstInternal(e, n) {
    const r = this.getKeyForAutomaticLookahead(ta, e);
    this.atLeastOneSepFirstInternalLogic(e, n, r);
  }
  atLeastOneSepFirstInternalLogic(e, n, r) {
    const i = n.DEF, s = n.SEP;
    if (this.getLaFuncFromCache(r).call(this) === !0) {
      i.call(this);
      const o = () => this.tokenMatcher(this.LA(1), s);
      for (; this.tokenMatcher(this.LA(1), s) === !0; )
        this.CONSUME(s), i.call(this);
      this.attemptInRepetitionRecovery(this.repetitionSepSecondInternal, [
        e,
        s,
        o,
        i,
        ru
      ], o, ta, e, ru);
    } else
      throw this.raiseEarlyExitException(e, ge.REPETITION_MANDATORY_WITH_SEPARATOR, n.ERR_MSG);
  }
  manyInternal(e, n) {
    const r = this.getKeyForAutomaticLookahead(Lo, e);
    return this.manyInternalLogic(e, n, r);
  }
  manyInternalLogic(e, n, r) {
    let i = this.getLaFuncFromCache(r), s;
    if (typeof n != "function") {
      s = n.DEF;
      const o = n.GATE;
      if (o !== void 0) {
        const c = i;
        i = () => o.call(this) && c.call(this);
      }
    } else
      s = n;
    let a = !0;
    for (; i.call(this) === !0 && a === !0; )
      a = this.doSingleRepetition(s);
    this.attemptInRepetitionRecovery(
      this.manyInternal,
      [e, n],
      i,
      Lo,
      e,
      vg,
      // The notStuck parameter is only relevant when "attemptInRepetitionRecovery"
      // is invoked from manyInternal, in the MANY_SEP case and AT_LEAST_ONE[_SEP]
      // An infinite loop cannot occur as:
      // - Either the lookahead is guaranteed to consume something (Single Token Separator)
      // - AT_LEAST_ONE by definition is guaranteed to consume something (or error out).
      a
    );
  }
  manySepFirstInternal(e, n) {
    const r = this.getKeyForAutomaticLookahead(xo, e);
    this.manySepFirstInternalLogic(e, n, r);
  }
  manySepFirstInternalLogic(e, n, r) {
    const i = n.DEF, s = n.SEP;
    if (this.getLaFuncFromCache(r).call(this) === !0) {
      i.call(this);
      const o = () => this.tokenMatcher(this.LA(1), s);
      for (; this.tokenMatcher(this.LA(1), s) === !0; )
        this.CONSUME(s), i.call(this);
      this.attemptInRepetitionRecovery(this.repetitionSepSecondInternal, [
        e,
        s,
        o,
        i,
        nu
      ], o, xo, e, nu);
    }
  }
  repetitionSepSecondInternal(e, n, r, i, s) {
    for (; r(); )
      this.CONSUME(n), i.call(this);
    this.attemptInRepetitionRecovery(this.repetitionSepSecondInternal, [
      e,
      n,
      r,
      i,
      s
    ], r, ta, e, s);
  }
  doSingleRepetition(e) {
    const n = this.getLexerPosition();
    return e.call(this), this.getLexerPosition() > n;
  }
  orInternal(e, n) {
    const r = this.getKeyForAutomaticLookahead(_f, n), i = je(e) ? e : e.DEF, a = this.getLaFuncFromCache(r).call(this, i);
    if (a !== void 0)
      return i[a].ALT.call(this);
    this.raiseNoAltException(n, e.ERR_MSG);
  }
  ruleFinallyStateUpdate() {
    if (this.RULE_STACK.pop(), this.RULE_OCCURRENCE_STACK.pop(), this.cstFinallyStateUpdate(), this.RULE_STACK.length === 0 && this.isAtEndOfInput() === !1) {
      const e = this.LA(1), n = this.errorMessageProvider.buildNotAllInputParsedMessage({
        firstRedundant: e,
        ruleName: this.getCurrRuleFullName()
      });
      this.SAVE_ERROR(new Hg(n, e));
    }
  }
  subruleInternal(e, n, r) {
    let i;
    try {
      const s = r !== void 0 ? r.ARGS : void 0;
      return this.subruleIdx = n, i = e.apply(this, s), this.cstPostNonTerminal(i, r !== void 0 && r.LABEL !== void 0 ? r.LABEL : e.ruleName), i;
    } catch (s) {
      throw this.subruleInternalError(s, r, e.ruleName);
    }
  }
  subruleInternalError(e, n, r) {
    throw pa(e) && e.partialCstResult !== void 0 && (this.cstPostNonTerminal(e.partialCstResult, n !== void 0 && n.LABEL !== void 0 ? n.LABEL : r), delete e.partialCstResult), e;
  }
  consumeInternal(e, n, r) {
    let i;
    try {
      const s = this.LA(1);
      this.tokenMatcher(s, e) === !0 ? (this.consumeToken(), i = s) : this.consumeInternalError(e, s, r);
    } catch (s) {
      i = this.consumeInternalRecovery(e, n, s);
    }
    return this.cstPostTerminal(r !== void 0 && r.LABEL !== void 0 ? r.LABEL : e.name, i), i;
  }
  consumeInternalError(e, n, r) {
    let i;
    const s = this.LA(0);
    throw r !== void 0 && r.ERR_MSG ? i = r.ERR_MSG : i = this.errorMessageProvider.buildMismatchTokenMessage({
      expected: e,
      actual: n,
      previous: s,
      ruleName: this.getCurrRuleFullName()
    }), this.SAVE_ERROR(new wf(i, n, s));
  }
  consumeInternalRecovery(e, n, r) {
    if (this.recoveryEnabled && // TODO: more robust checking of the exception type. Perhaps Typescript extending expressions?
    r.name === "MismatchedTokenException" && !this.isBackTracking()) {
      const i = this.getFollowsForInRuleRecovery(e, n);
      try {
        return this.tryInRuleRecovery(e, i);
      } catch (s) {
        throw s.name === bf ? r : s;
      }
    } else
      throw r;
  }
  saveRecogState() {
    const e = this.errors, n = Be(this.RULE_STACK);
    return {
      errors: e,
      lexerState: this.exportLexerState(),
      RULE_STACK: n,
      CST_STACK: this.CST_STACK
    };
  }
  reloadRecogState(e) {
    this.errors = e.errors, this.importLexerState(e.lexerState), this.RULE_STACK = e.RULE_STACK;
  }
  ruleInvocationStateUpdate(e, n, r) {
    this.RULE_OCCURRENCE_STACK.push(r), this.RULE_STACK.push(e), this.cstInvocationStateUpdate(n);
  }
  isBackTracking() {
    return this.isBackTrackingStack.length !== 0;
  }
  getCurrRuleFullName() {
    const e = this.getLastExplicitRuleShortName();
    return this.shortRuleNameToFull[e];
  }
  shortRuleNameToFullName(e) {
    return this.shortRuleNameToFull[e];
  }
  isAtEndOfInput() {
    return this.tokenMatcher(this.LA(1), fn);
  }
  reset() {
    this.resetLexerState(), this.subruleIdx = 0, this.isBackTrackingStack = [], this.errors = [], this.RULE_STACK = [], this.CST_STACK = [], this.RULE_OCCURRENCE_STACK = [];
  }
}
class my {
  initErrorHandler(e) {
    this._errors = [], this.errorMessageProvider = z(e, "errorMessageProvider") ? e.errorMessageProvider : rn.errorMessageProvider;
  }
  SAVE_ERROR(e) {
    if (pa(e))
      return e.context = {
        ruleStack: this.getHumanReadableRuleStack(),
        ruleOccurrenceStack: Be(this.RULE_OCCURRENCE_STACK)
      }, this._errors.push(e), e;
    throw Error("Trying to save an Error which is not a RecognitionException");
  }
  get errors() {
    return Be(this._errors);
  }
  set errors(e) {
    this._errors = e;
  }
  // TODO: consider caching the error message computed information
  raiseEarlyExitException(e, n, r) {
    const i = this.getCurrRuleFullName(), s = this.getGAstProductions()[i], o = Ga(e, s, n, this.maxLookahead)[0], c = [];
    for (let u = 1; u <= this.maxLookahead; u++)
      c.push(this.LA(u));
    const l = this.errorMessageProvider.buildEarlyExitMessage({
      expectedIterationPaths: o,
      actual: c,
      previous: this.LA(0),
      customUserDescription: r,
      ruleName: i
    });
    throw this.SAVE_ERROR(new Yg(l, this.LA(1), this.LA(0)));
  }
  // TODO: consider caching the error message computed information
  raiseNoAltException(e, n) {
    const r = this.getCurrRuleFullName(), i = this.getGAstProductions()[r], s = Fa(e, i, this.maxLookahead), a = [];
    for (let l = 1; l <= this.maxLookahead; l++)
      a.push(this.LA(l));
    const o = this.LA(0), c = this.errorMessageProvider.buildNoViableAltMessage({
      expectedPathsPerAlt: s,
      actual: a,
      previous: o,
      customUserDescription: n,
      ruleName: this.getCurrRuleFullName()
    });
    throw this.SAVE_ERROR(new Kg(c, this.LA(1), o));
  }
}
class gy {
  initContentAssist() {
  }
  computeContentAssist(e, n) {
    const r = this.gastProductionsCache[e];
    if (tn(r))
      throw Error(`Rule ->${e}<- does not exist in this grammar.`);
    return gf([r], n, this.tokenMatcher, this.maxLookahead);
  }
  // TODO: should this be a member method or a utility? it does not have any state or usage of 'this'...
  // TODO: should this be more explicitly part of the public API?
  getNextPossibleTokenTypes(e) {
    const n = Nt(e.ruleStack), i = this.getGAstProductions()[n];
    return new Rg(i, e).startWalking();
  }
}
const qa = {
  description: "This Object indicates the Parser is during Recording Phase"
};
Object.freeze(qa);
const cu = !0, lu = Math.pow(2, pn) - 1, $f = pf({ name: "RECORDING_PHASE_TOKEN", pattern: tt.NA });
os([$f]);
const Lf = dl(
  $f,
  `This IToken indicates the Parser is in Recording Phase
	See: https://chevrotain.io/docs/guide/internals.html#grammar-recording for details`,
  // Using "-1" instead of NaN (as in EOF) because an actual number is less likely to
  // cause errors if the output of LA or CONSUME would be (incorrectly) used during the recording phase.
  -1,
  -1,
  -1,
  -1,
  -1,
  -1
);
Object.freeze(Lf);
const yy = {
  name: `This CSTNode indicates the Parser is in Recording Phase
	See: https://chevrotain.io/docs/guide/internals.html#grammar-recording for details`,
  children: {}
};
class Ty {
  initGastRecorder(e) {
    this.recordingProdStack = [], this.RECORDING_PHASE = !1;
  }
  enableRecording() {
    this.RECORDING_PHASE = !0, this.TRACE_INIT("Enable Recording", () => {
      for (let e = 0; e < 10; e++) {
        const n = e > 0 ? e : "";
        this[`CONSUME${n}`] = function(r, i) {
          return this.consumeInternalRecord(r, e, i);
        }, this[`SUBRULE${n}`] = function(r, i) {
          return this.subruleInternalRecord(r, e, i);
        }, this[`OPTION${n}`] = function(r) {
          return this.optionInternalRecord(r, e);
        }, this[`OR${n}`] = function(r) {
          return this.orInternalRecord(r, e);
        }, this[`MANY${n}`] = function(r) {
          this.manyInternalRecord(e, r);
        }, this[`MANY_SEP${n}`] = function(r) {
          this.manySepFirstInternalRecord(e, r);
        }, this[`AT_LEAST_ONE${n}`] = function(r) {
          this.atLeastOneInternalRecord(e, r);
        }, this[`AT_LEAST_ONE_SEP${n}`] = function(r) {
          this.atLeastOneSepFirstInternalRecord(e, r);
        };
      }
      this.consume = function(e, n, r) {
        return this.consumeInternalRecord(n, e, r);
      }, this.subrule = function(e, n, r) {
        return this.subruleInternalRecord(n, e, r);
      }, this.option = function(e, n) {
        return this.optionInternalRecord(n, e);
      }, this.or = function(e, n) {
        return this.orInternalRecord(n, e);
      }, this.many = function(e, n) {
        this.manyInternalRecord(e, n);
      }, this.atLeastOne = function(e, n) {
        this.atLeastOneInternalRecord(e, n);
      }, this.ACTION = this.ACTION_RECORD, this.BACKTRACK = this.BACKTRACK_RECORD, this.LA = this.LA_RECORD;
    });
  }
  disableRecording() {
    this.RECORDING_PHASE = !1, this.TRACE_INIT("Deleting Recording methods", () => {
      const e = this;
      for (let n = 0; n < 10; n++) {
        const r = n > 0 ? n : "";
        delete e[`CONSUME${r}`], delete e[`SUBRULE${r}`], delete e[`OPTION${r}`], delete e[`OR${r}`], delete e[`MANY${r}`], delete e[`MANY_SEP${r}`], delete e[`AT_LEAST_ONE${r}`], delete e[`AT_LEAST_ONE_SEP${r}`];
      }
      delete e.consume, delete e.subrule, delete e.option, delete e.or, delete e.many, delete e.atLeastOne, delete e.ACTION, delete e.BACKTRACK, delete e.LA;
    });
  }
  //   Parser methods are called inside an ACTION?
  //   Maybe try/catch/finally on ACTIONS while disabling the recorders state changes?
  // @ts-expect-error -- noop place holder
  ACTION_RECORD(e) {
  }
  // Executing backtracking logic will break our recording logic assumptions
  BACKTRACK_RECORD(e, n) {
    return () => !0;
  }
  // LA is part of the official API and may be used for custom lookahead logic
  // by end users who may forget to wrap it in ACTION or inside a GATE
  LA_RECORD(e) {
    return ga;
  }
  topLevelRuleRecord(e, n) {
    try {
      const r = new Yr({ definition: [], name: e });
      return r.name = e, this.recordingProdStack.push(r), n.call(this), this.recordingProdStack.pop(), r;
    } catch (r) {
      if (r.KNOWN_RECORDER_ERROR !== !0)
        try {
          r.message = r.message + `
	 This error was thrown during the "grammar recording phase" For more info see:
	https://chevrotain.io/docs/guide/internals.html#grammar-recording`;
        } catch {
          throw r;
        }
      throw r;
    }
  }
  // Implementation of parsing DSL
  optionInternalRecord(e, n) {
    return gi.call(this, ze, e, n);
  }
  atLeastOneInternalRecord(e, n) {
    gi.call(this, pt, n, e);
  }
  atLeastOneSepFirstInternalRecord(e, n) {
    gi.call(this, mt, n, e, cu);
  }
  manyInternalRecord(e, n) {
    gi.call(this, Ae, n, e);
  }
  manySepFirstInternalRecord(e, n) {
    gi.call(this, it, n, e, cu);
  }
  orInternalRecord(e, n) {
    return Ry.call(this, e, n);
  }
  subruleInternalRecord(e, n, r) {
    if (ma(n), !e || z(e, "ruleName") === !1) {
      const o = new Error(`<SUBRULE${uu(n)}> argument is invalid expecting a Parser method reference but got: <${JSON.stringify(e)}>
 inside top level rule: <${this.recordingProdStack[0].name}>`);
      throw o.KNOWN_RECORDER_ERROR = !0, o;
    }
    const i = qn(this.recordingProdStack), s = e.ruleName, a = new Qe({
      idx: n,
      nonTerminalName: s,
      label: r?.LABEL,
      // The resolving of the `referencedRule` property will be done once all the Rule's GASTs have been created
      referencedRule: void 0
    });
    return i.definition.push(a), this.outputCst ? yy : qa;
  }
  consumeInternalRecord(e, n, r) {
    if (ma(n), !ff(e)) {
      const a = new Error(`<CONSUME${uu(n)}> argument is invalid expecting a TokenType reference but got: <${JSON.stringify(e)}>
 inside top level rule: <${this.recordingProdStack[0].name}>`);
      throw a.KNOWN_RECORDER_ERROR = !0, a;
    }
    const i = qn(this.recordingProdStack), s = new le({
      idx: n,
      terminalType: e,
      label: r?.LABEL
    });
    return i.definition.push(s), Lf;
  }
}
function gi(t, e, n, r = !1) {
  ma(n);
  const i = qn(this.recordingProdStack), s = Hn(e) ? e : e.DEF, a = new t({ definition: [], idx: n });
  return r && (a.separator = e.SEP), z(e, "MAX_LOOKAHEAD") && (a.maxLookahead = e.MAX_LOOKAHEAD), this.recordingProdStack.push(a), s.call(this), i.definition.push(a), this.recordingProdStack.pop(), qa;
}
function Ry(t, e) {
  ma(e);
  const n = qn(this.recordingProdStack), r = je(t) === !1, i = r === !1 ? t : t.DEF, s = new st({
    definition: [],
    idx: e,
    ignoreAmbiguities: r && t.IGNORE_AMBIGUITIES === !0
  });
  z(t, "MAX_LOOKAHEAD") && (s.maxLookahead = t.MAX_LOOKAHEAD);
  const a = Od(i, (o) => Hn(o.GATE));
  return s.hasPredicates = a, n.definition.push(s), q(i, (o) => {
    const c = new rt({ definition: [] });
    s.definition.push(c), z(o, "IGNORE_AMBIGUITIES") ? c.ignoreAmbiguities = o.IGNORE_AMBIGUITIES : z(o, "GATE") && (c.ignoreAmbiguities = !0), this.recordingProdStack.push(c), o.ALT.call(this), this.recordingProdStack.pop();
  }), qa;
}
function uu(t) {
  return t === 0 ? "" : `${t}`;
}
function ma(t) {
  if (t < 0 || t > lu) {
    const e = new Error(
      // The stack trace will contain all the needed details
      `Invalid DSL Method idx value: <${t}>
	Idx value must be a none negative value smaller than ${lu + 1}`
    );
    throw e.KNOWN_RECORDER_ERROR = !0, e;
  }
}
class vy {
  initPerformanceTracer(e) {
    if (z(e, "traceInitPerf")) {
      const n = e.traceInitPerf, r = typeof n == "number";
      this.traceInitMaxIdent = r ? n : 1 / 0, this.traceInitPerf = r ? n > 0 : n;
    } else
      this.traceInitMaxIdent = 0, this.traceInitPerf = rn.traceInitPerf;
    this.traceInitIndent = -1;
  }
  TRACE_INIT(e, n) {
    if (this.traceInitPerf === !0) {
      this.traceInitIndent++;
      const r = new Array(this.traceInitIndent + 1).join("	");
      this.traceInitIndent < this.traceInitMaxIdent && console.log(`${r}--> <${e}>`);
      const { time: i, value: s } = nf(n), a = i > 10 ? console.warn : console.log;
      return this.traceInitIndent < this.traceInitMaxIdent && a(`${r}<-- <${e}> time: ${i}ms`), this.traceInitIndent--, s;
    } else
      return n();
  }
}
function Ey(t, e) {
  e.forEach((n) => {
    const r = n.prototype;
    Object.getOwnPropertyNames(r).forEach((i) => {
      if (i === "constructor")
        return;
      const s = Object.getOwnPropertyDescriptor(r, i);
      s && (s.get || s.set) ? Object.defineProperty(t.prototype, i, s) : t.prototype[i] = n.prototype[i];
    });
  });
}
const ga = dl(fn, "", NaN, NaN, NaN, NaN, NaN, NaN);
Object.freeze(ga);
const rn = Object.freeze({
  recoveryEnabled: !1,
  maxLookahead: 3,
  dynamicTokensEnabled: !1,
  outputCst: !0,
  errorMessageProvider: vr,
  nodeLocationTracking: "none",
  traceInitPerf: !1,
  skipValidations: !1
}), ya = Object.freeze({
  recoveryValueFunc: () => {
  },
  resyncEnabled: !0
});
var Ze;
(function(t) {
  t[t.INVALID_RULE_NAME = 0] = "INVALID_RULE_NAME", t[t.DUPLICATE_RULE_NAME = 1] = "DUPLICATE_RULE_NAME", t[t.INVALID_RULE_OVERRIDE = 2] = "INVALID_RULE_OVERRIDE", t[t.DUPLICATE_PRODUCTIONS = 3] = "DUPLICATE_PRODUCTIONS", t[t.UNRESOLVED_SUBRULE_REF = 4] = "UNRESOLVED_SUBRULE_REF", t[t.LEFT_RECURSION = 5] = "LEFT_RECURSION", t[t.NONE_LAST_EMPTY_ALT = 6] = "NONE_LAST_EMPTY_ALT", t[t.AMBIGUOUS_ALTS = 7] = "AMBIGUOUS_ALTS", t[t.CONFLICT_TOKENS_RULES_NAMESPACE = 8] = "CONFLICT_TOKENS_RULES_NAMESPACE", t[t.INVALID_TOKEN_NAME = 9] = "INVALID_TOKEN_NAME", t[t.NO_NON_EMPTY_LOOKAHEAD = 10] = "NO_NON_EMPTY_LOOKAHEAD", t[t.AMBIGUOUS_PREFIX_ALTS = 11] = "AMBIGUOUS_PREFIX_ALTS", t[t.TOO_MANY_ALTS = 12] = "TOO_MANY_ALTS", t[t.CUSTOM_LOOKAHEAD_VALIDATION = 13] = "CUSTOM_LOOKAHEAD_VALIDATION";
})(Ze || (Ze = {}));
function du(t = void 0) {
  return function() {
    return t;
  };
}
class cs {
  /**
   *  @deprecated use the **instance** method with the same name instead
   */
  static performSelfAnalysis(e) {
    throw Error("The **static** `performSelfAnalysis` method has been deprecated.	\nUse the **instance** method with the same name instead.");
  }
  performSelfAnalysis() {
    this.TRACE_INIT("performSelfAnalysis", () => {
      let e;
      this.selfAnalysisDone = !0;
      const n = this.className;
      this.TRACE_INIT("toFastProps", () => {
        rf(this);
      }), this.TRACE_INIT("Grammar Recording", () => {
        try {
          this.enableRecording(), q(this.definedRulesNames, (i) => {
            const a = this[i].originalGrammarAction;
            let o;
            this.TRACE_INIT(`${i} Rule`, () => {
              o = this.topLevelRuleRecord(i, a);
            }), this.gastProductionsCache[i] = o;
          });
        } finally {
          this.disableRecording();
        }
      });
      let r = [];
      if (this.TRACE_INIT("Grammar Resolving", () => {
        r = Wg({
          rules: $e(this.gastProductionsCache)
        }), this.definitionErrors = this.definitionErrors.concat(r);
      }), this.TRACE_INIT("Grammar Validations", () => {
        if (ae(r) && this.skipValidations === !1) {
          const i = Vg({
            rules: $e(this.gastProductionsCache),
            tokenTypes: $e(this.tokensMap),
            errMsgProvider: Gn,
            grammarName: n
          }), s = Ig({
            lookaheadStrategy: this.lookaheadStrategy,
            rules: $e(this.gastProductionsCache),
            tokenTypes: $e(this.tokensMap),
            grammarName: n
          });
          this.definitionErrors = this.definitionErrors.concat(i, s);
        }
      }), ae(this.definitionErrors) && (this.recoveryEnabled && this.TRACE_INIT("computeAllProdsFollows", () => {
        const i = bm($e(this.gastProductionsCache));
        this.resyncFollows = i;
      }), this.TRACE_INIT("ComputeLookaheadFunctions", () => {
        var i, s;
        (s = (i = this.lookaheadStrategy).initialize) === null || s === void 0 || s.call(i, {
          rules: $e(this.gastProductionsCache)
        }), this.preComputeLookaheadFunctions($e(this.gastProductionsCache));
      })), !cs.DEFER_DEFINITION_ERRORS_HANDLING && !ae(this.definitionErrors))
        throw e = M(this.definitionErrors, (i) => i.message), new Error(`Parser Definition Errors detected:
 ${e.join(`
-------------------------------
`)}`);
    });
  }
  constructor(e, n) {
    this.definitionErrors = [], this.selfAnalysisDone = !1;
    const r = this;
    if (r.initErrorHandler(n), r.initLexerAdapter(), r.initLooksAhead(n), r.initRecognizerEngine(e, n), r.initRecoverable(n), r.initTreeBuilder(n), r.initContentAssist(), r.initGastRecorder(n), r.initPerformanceTracer(n), z(n, "ignoredIssues"))
      throw new Error(`The <ignoredIssues> IParserConfig property has been deprecated.
	Please use the <IGNORE_AMBIGUITIES> flag on the relevant DSL method instead.
	See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#IGNORING_AMBIGUITIES
	For further details.`);
    this.skipValidations = z(n, "skipValidations") ? n.skipValidations : rn.skipValidations;
  }
}
cs.DEFER_DEFINITION_ERRORS_HANDLING = !1;
Ey(cs, [
  Jg,
  ey,
  dy,
  fy,
  py,
  hy,
  my,
  gy,
  Ty,
  vy
]);
class Ay extends cs {
  constructor(e, n = rn) {
    const r = Be(n);
    r.outputCst = !1, super(e, r);
  }
}
function jr(t, e, n) {
  return `${t.name}_${e}_${n}`;
}
const hn = 1, Sy = 2, Of = 4, xf = 5, ls = 7, ky = 8, Cy = 9, Ny = 10, wy = 11, Df = 12;
class ml {
  constructor(e) {
    this.target = e;
  }
  isEpsilon() {
    return !1;
  }
}
class gl extends ml {
  constructor(e, n) {
    super(e), this.tokenType = n;
  }
}
class Mf extends ml {
  constructor(e) {
    super(e);
  }
  isEpsilon() {
    return !0;
  }
}
class yl extends ml {
  constructor(e, n, r) {
    super(e), this.rule = n, this.followState = r;
  }
  isEpsilon() {
    return !0;
  }
}
function by(t) {
  const e = {
    decisionMap: {},
    decisionStates: [],
    ruleToStartState: /* @__PURE__ */ new Map(),
    ruleToStopState: /* @__PURE__ */ new Map(),
    states: []
  };
  _y(e, t);
  const n = t.length;
  for (let r = 0; r < n; r++) {
    const i = t[r], s = Yn(e, i, i);
    s !== void 0 && Uy(e, i, s);
  }
  return e;
}
function _y(t, e) {
  const n = e.length;
  for (let r = 0; r < n; r++) {
    const i = e[r], s = Le(t, i, void 0, {
      type: Sy
    }), a = Le(t, i, void 0, {
      type: ls
    });
    s.stop = a, t.ruleToStartState.set(i, s), t.ruleToStopState.set(i, a);
  }
}
function Ff(t, e, n) {
  return n instanceof le ? Tl(t, e, n.terminalType, n) : n instanceof Qe ? Gy(t, e, n) : n instanceof st ? Oy(t, e, n) : n instanceof ze ? xy(t, e, n) : n instanceof Ae ? Iy(t, e, n) : n instanceof it ? Py(t, e, n) : n instanceof pt ? $y(t, e, n) : n instanceof mt ? Ly(t, e, n) : Yn(t, e, n);
}
function Iy(t, e, n) {
  const r = Le(t, e, n, {
    type: xf
  });
  mn(t, r);
  const i = Jr(t, e, r, n, Yn(t, e, n));
  return Uf(t, e, n, i);
}
function Py(t, e, n) {
  const r = Le(t, e, n, {
    type: xf
  });
  mn(t, r);
  const i = Jr(t, e, r, n, Yn(t, e, n)), s = Tl(t, e, n.separator, n);
  return Uf(t, e, n, i, s);
}
function $y(t, e, n) {
  const r = Le(t, e, n, {
    type: Of
  });
  mn(t, r);
  const i = Jr(t, e, r, n, Yn(t, e, n));
  return Gf(t, e, n, i);
}
function Ly(t, e, n) {
  const r = Le(t, e, n, {
    type: Of
  });
  mn(t, r);
  const i = Jr(t, e, r, n, Yn(t, e, n)), s = Tl(t, e, n.separator, n);
  return Gf(t, e, n, i, s);
}
function Oy(t, e, n) {
  const r = Le(t, e, n, {
    type: hn
  });
  mn(t, r);
  const i = M(n.definition, (a) => Ff(t, e, a));
  return Jr(t, e, r, n, ...i);
}
function xy(t, e, n) {
  const r = Le(t, e, n, {
    type: hn
  });
  mn(t, r);
  const i = Jr(t, e, r, n, Yn(t, e, n));
  return Dy(t, e, n, i);
}
function Yn(t, e, n) {
  const r = ht(M(n.definition, (i) => Ff(t, e, i)), (i) => i !== void 0);
  return r.length === 1 ? r[0] : r.length === 0 ? void 0 : Fy(t, r);
}
function Gf(t, e, n, r, i) {
  const s = r.left, a = r.right, o = Le(t, e, n, {
    type: wy
  });
  mn(t, o);
  const c = Le(t, e, n, {
    type: Df
  });
  return s.loopback = o, c.loopback = o, t.decisionMap[jr(e, i ? "RepetitionMandatoryWithSeparator" : "RepetitionMandatory", n.idx)] = o, _e(a, o), i === void 0 ? (_e(o, s), _e(o, c)) : (_e(o, c), _e(o, i.left), _e(i.right, s)), {
    left: s,
    right: c
  };
}
function Uf(t, e, n, r, i) {
  const s = r.left, a = r.right, o = Le(t, e, n, {
    type: Ny
  });
  mn(t, o);
  const c = Le(t, e, n, {
    type: Df
  }), l = Le(t, e, n, {
    type: Cy
  });
  return o.loopback = l, c.loopback = l, _e(o, s), _e(o, c), _e(a, l), i !== void 0 ? (_e(l, c), _e(l, i.left), _e(i.right, s)) : _e(l, o), t.decisionMap[jr(e, i ? "RepetitionWithSeparator" : "Repetition", n.idx)] = o, {
    left: o,
    right: c
  };
}
function Dy(t, e, n, r) {
  const i = r.left, s = r.right;
  return _e(i, s), t.decisionMap[jr(e, "Option", n.idx)] = i, r;
}
function mn(t, e) {
  return t.decisionStates.push(e), e.decision = t.decisionStates.length - 1, e.decision;
}
function Jr(t, e, n, r, ...i) {
  const s = Le(t, e, r, {
    type: ky,
    start: n
  });
  n.end = s;
  for (const o of i)
    o !== void 0 ? (_e(n, o.left), _e(o.right, s)) : _e(n, s);
  const a = {
    left: n,
    right: s
  };
  return t.decisionMap[jr(e, My(r), r.idx)] = n, a;
}
function My(t) {
  if (t instanceof st)
    return "Alternation";
  if (t instanceof ze)
    return "Option";
  if (t instanceof Ae)
    return "Repetition";
  if (t instanceof it)
    return "RepetitionWithSeparator";
  if (t instanceof pt)
    return "RepetitionMandatory";
  if (t instanceof mt)
    return "RepetitionMandatoryWithSeparator";
  throw new Error("Invalid production type encountered");
}
function Fy(t, e) {
  const n = e.length;
  for (let s = 0; s < n - 1; s++) {
    const a = e[s];
    let o;
    a.left.transitions.length === 1 && (o = a.left.transitions[0]);
    const c = o instanceof yl, l = o, u = e[s + 1].left;
    a.left.type === hn && a.right.type === hn && o !== void 0 && (c && l.followState === a.right || o.target === a.right) ? (c ? l.followState = u : o.target = u, qy(t, a.right)) : _e(a.right, u);
  }
  const r = e[0], i = e[n - 1];
  return {
    left: r.left,
    right: i.right
  };
}
function Tl(t, e, n, r) {
  const i = Le(t, e, r, {
    type: hn
  }), s = Le(t, e, r, {
    type: hn
  });
  return Rl(i, new gl(s, n)), {
    left: i,
    right: s
  };
}
function Gy(t, e, n) {
  const r = n.referencedRule, i = t.ruleToStartState.get(r), s = Le(t, e, n, {
    type: hn
  }), a = Le(t, e, n, {
    type: hn
  }), o = new yl(i, r, a);
  return Rl(s, o), {
    left: s,
    right: a
  };
}
function Uy(t, e, n) {
  const r = t.ruleToStartState.get(e);
  _e(r, n.left);
  const i = t.ruleToStopState.get(e);
  return _e(n.right, i), {
    left: r,
    right: i
  };
}
function _e(t, e) {
  const n = new Mf(e);
  Rl(t, n);
}
function Le(t, e, n, r) {
  const i = Object.assign({
    atn: t,
    production: n,
    epsilonOnlyTransitions: !1,
    rule: e,
    transitions: [],
    nextTokenWithinRule: [],
    stateNumber: t.states.length
  }, r);
  return t.states.push(i), i;
}
function Rl(t, e) {
  t.transitions.length === 0 && (t.epsilonOnlyTransitions = e.isEpsilon()), t.transitions.push(e);
}
function qy(t, e) {
  t.states.splice(t.states.indexOf(e), 1);
}
const Ta = {};
class Mo {
  constructor() {
    this.map = {}, this.configs = [];
  }
  get size() {
    return this.configs.length;
  }
  finalize() {
    this.map = {};
  }
  add(e) {
    const n = qf(e);
    n in this.map || (this.map[n] = this.configs.length, this.configs.push(e));
  }
  get elements() {
    return this.configs;
  }
  get alts() {
    return M(this.configs, (e) => e.alt);
  }
  get key() {
    let e = "";
    for (const n in this.map)
      e += n + ":";
    return e;
  }
}
function qf(t, e = !0) {
  return `${e ? `a${t.alt}` : ""}s${t.state.stateNumber}:${t.stack.map((n) => n.stateNumber.toString()).join("_")}`;
}
function jy(t, e) {
  const n = {};
  return (r) => {
    const i = r.toString();
    let s = n[i];
    return s !== void 0 || (s = {
      atnStartState: t,
      decision: e,
      states: {}
    }, n[i] = s), s;
  };
}
class jf {
  constructor() {
    this.predicates = [];
  }
  is(e) {
    return e >= this.predicates.length || this.predicates[e];
  }
  set(e, n) {
    this.predicates[e] = n;
  }
  toString() {
    let e = "";
    const n = this.predicates.length;
    for (let r = 0; r < n; r++)
      e += this.predicates[r] === !0 ? "1" : "0";
    return e;
  }
}
const fu = new jf();
class zy extends pl {
  constructor(e) {
    var n;
    super(), this.logging = (n = e?.logging) !== null && n !== void 0 ? n : ((r) => console.log(r));
  }
  initialize(e) {
    this.atn = by(e.rules), this.dfas = By(this.atn);
  }
  validateAmbiguousAlternationAlternatives() {
    return [];
  }
  validateEmptyOrAlternatives() {
    return [];
  }
  buildLookaheadForAlternation(e) {
    const { prodOccurrence: n, rule: r, hasPredicates: i, dynamicTokensEnabled: s } = e, a = this.dfas, o = this.logging, c = jr(r, "Alternation", n), u = this.atn.decisionMap[c].decision, f = M(iu({
      maxLookahead: 1,
      occurrence: n,
      prodType: "Alternation",
      rule: r
    }), (m) => M(m, (p) => p[0]));
    if (hu(f, !1) && !s) {
      const m = Je(f, (p, A, b) => (q(A, (I) => {
        I && (p[I.tokenTypeIdx] = b, q(I.categoryMatches, (C) => {
          p[C] = b;
        }));
      }), p), {});
      return i ? function(p) {
        var A;
        const b = this.LA(1), I = m[b.tokenTypeIdx];
        if (p !== void 0 && I !== void 0) {
          const C = (A = p[I]) === null || A === void 0 ? void 0 : A.GATE;
          if (C !== void 0 && C.call(this) === !1)
            return;
        }
        return I;
      } : function() {
        const p = this.LA(1);
        return m[p.tokenTypeIdx];
      };
    } else return i ? function(m) {
      const p = new jf(), A = m === void 0 ? 0 : m.length;
      for (let I = 0; I < A; I++) {
        const C = m?.[I].GATE;
        p.set(I, C === void 0 || C.call(this));
      }
      const b = to.call(this, a, u, p, o);
      return typeof b == "number" ? b : void 0;
    } : function() {
      const m = to.call(this, a, u, fu, o);
      return typeof m == "number" ? m : void 0;
    };
  }
  buildLookaheadForOptional(e) {
    const { prodOccurrence: n, rule: r, prodType: i, dynamicTokensEnabled: s } = e, a = this.dfas, o = this.logging, c = jr(r, i, n), u = this.atn.decisionMap[c].decision, f = M(iu({
      maxLookahead: 1,
      occurrence: n,
      prodType: i,
      rule: r
    }), (m) => M(m, (p) => p[0]));
    if (hu(f) && f[0][0] && !s) {
      const m = f[0], p = yt(m);
      if (p.length === 1 && ae(p[0].categoryMatches)) {
        const b = p[0].tokenTypeIdx;
        return function() {
          return this.LA(1).tokenTypeIdx === b;
        };
      } else {
        const A = Je(p, (b, I) => (I !== void 0 && (b[I.tokenTypeIdx] = !0, q(I.categoryMatches, (C) => {
          b[C] = !0;
        })), b), {});
        return function() {
          const b = this.LA(1);
          return A[b.tokenTypeIdx] === !0;
        };
      }
    }
    return function() {
      const m = to.call(this, a, u, fu, o);
      return typeof m == "object" ? !1 : m === 0;
    };
  }
}
function hu(t, e = !0) {
  const n = /* @__PURE__ */ new Set();
  for (const r of t) {
    const i = /* @__PURE__ */ new Set();
    for (const s of r) {
      if (s === void 0) {
        if (e)
          break;
        return !1;
      }
      const a = [s.tokenTypeIdx].concat(s.categoryMatches);
      for (const o of a)
        if (n.has(o)) {
          if (!i.has(o))
            return !1;
        } else
          n.add(o), i.add(o);
    }
  }
  return !0;
}
function By(t) {
  const e = t.decisionStates.length, n = Array(e);
  for (let r = 0; r < e; r++)
    n[r] = jy(t.decisionStates[r], r);
  return n;
}
function to(t, e, n, r) {
  const i = t[e](n);
  let s = i.start;
  if (s === void 0) {
    const o = tT(i.atnStartState);
    s = Bf(i, zf(o)), i.start = s;
  }
  return Wy.apply(this, [i, s, n, r]);
}
function Wy(t, e, n, r) {
  let i = e, s = 1;
  const a = [];
  let o = this.LA(s++);
  for (; ; ) {
    let c = Jy(i, o);
    if (c === void 0 && (c = Vy.apply(this, [t, i, o, s, n, r])), c === Ta)
      return Xy(a, i, o);
    if (c.isAcceptState === !0)
      return c.prediction;
    i = c, a.push(o), o = this.LA(s++);
  }
}
function Vy(t, e, n, r, i, s) {
  const a = Qy(e.configs, n, i);
  if (a.size === 0)
    return pu(t, e, n, Ta), Ta;
  let o = zf(a);
  const c = eT(a, i);
  if (c !== void 0)
    o.isAcceptState = !0, o.prediction = c, o.configs.uniqueAlt = c;
  else if (sT(a)) {
    const l = Jh(a.alts);
    o.isAcceptState = !0, o.prediction = l, o.configs.uniqueAlt = l, Ky.apply(this, [t, r, a.alts, s]);
  }
  return o = pu(t, e, n, o), o;
}
function Ky(t, e, n, r) {
  const i = [];
  for (let l = 1; l <= e; l++)
    i.push(this.LA(l).tokenType);
  const s = t.atnStartState, a = s.rule, o = s.production, c = Hy({
    topLevelRule: a,
    ambiguityIndices: n,
    production: o,
    prefixPath: i
  });
  r(c);
}
function Hy(t) {
  const e = M(t.prefixPath, (i) => Ar(i)).join(", "), n = t.production.idx === 0 ? "" : t.production.idx;
  let r = `Ambiguous Alternatives Detected: <${t.ambiguityIndices.join(", ")}> in <${Yy(t.production)}${n}> inside <${t.topLevelRule.name}> Rule,
<${e}> may appears as a prefix path in all these alternatives.
`;
  return r = r + `See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#AMBIGUOUS_ALTERNATIVES
For Further details.`, r;
}
function Yy(t) {
  if (t instanceof Qe)
    return "SUBRULE";
  if (t instanceof ze)
    return "OPTION";
  if (t instanceof st)
    return "OR";
  if (t instanceof pt)
    return "AT_LEAST_ONE";
  if (t instanceof mt)
    return "AT_LEAST_ONE_SEP";
  if (t instanceof it)
    return "MANY_SEP";
  if (t instanceof Ae)
    return "MANY";
  if (t instanceof le)
    return "CONSUME";
  throw Error("non exhaustive match");
}
function Xy(t, e, n) {
  const r = dt(e.configs.elements, (s) => s.state.transitions), i = Tp(r.filter((s) => s instanceof gl).map((s) => s.tokenType), (s) => s.tokenTypeIdx);
  return {
    actualToken: n,
    possibleTokenTypes: i,
    tokenPath: t
  };
}
function Jy(t, e) {
  return t.edges[e.tokenTypeIdx];
}
function Qy(t, e, n) {
  const r = new Mo(), i = [];
  for (const a of t.elements) {
    if (n.is(a.alt) === !1)
      continue;
    if (a.state.type === ls) {
      i.push(a);
      continue;
    }
    const o = a.state.transitions.length;
    for (let c = 0; c < o; c++) {
      const l = a.state.transitions[c], u = Zy(l, e);
      u !== void 0 && r.add({
        state: u,
        alt: a.alt,
        stack: a.stack
      });
    }
  }
  let s;
  if (i.length === 0 && r.size === 1 && (s = r), s === void 0) {
    s = new Mo();
    for (const a of r.elements)
      Ra(a, s);
  }
  if (i.length > 0 && !rT(s))
    for (const a of i)
      s.add(a);
  return s;
}
function Zy(t, e) {
  if (t instanceof gl && mf(e, t.tokenType))
    return t.target;
}
function eT(t, e) {
  let n;
  for (const r of t.elements)
    if (e.is(r.alt) === !0) {
      if (n === void 0)
        n = r.alt;
      else if (n !== r.alt)
        return;
    }
  return n;
}
function zf(t) {
  return {
    configs: t,
    edges: {},
    isAcceptState: !1,
    prediction: -1
  };
}
function pu(t, e, n, r) {
  return r = Bf(t, r), e.edges[n.tokenTypeIdx] = r, r;
}
function Bf(t, e) {
  if (e === Ta)
    return e;
  const n = e.configs.key, r = t.states[n];
  return r !== void 0 ? r : (e.configs.finalize(), t.states[n] = e, e);
}
function tT(t) {
  const e = new Mo(), n = t.transitions.length;
  for (let r = 0; r < n; r++) {
    const s = {
      state: t.transitions[r].target,
      alt: r,
      stack: []
    };
    Ra(s, e);
  }
  return e;
}
function Ra(t, e) {
  const n = t.state;
  if (n.type === ls) {
    if (t.stack.length > 0) {
      const i = [...t.stack], a = {
        state: i.pop(),
        alt: t.alt,
        stack: i
      };
      Ra(a, e);
    } else
      e.add(t);
    return;
  }
  n.epsilonOnlyTransitions || e.add(t);
  const r = n.transitions.length;
  for (let i = 0; i < r; i++) {
    const s = n.transitions[i], a = nT(t, s);
    a !== void 0 && Ra(a, e);
  }
}
function nT(t, e) {
  if (e instanceof Mf)
    return {
      state: e.target,
      alt: t.alt,
      stack: t.stack
    };
  if (e instanceof yl) {
    const n = [...t.stack, e.followState];
    return {
      state: e.target,
      alt: t.alt,
      stack: n
    };
  }
}
function rT(t) {
  for (const e of t.elements)
    if (e.state.type === ls)
      return !0;
  return !1;
}
function iT(t) {
  for (const e of t.elements)
    if (e.state.type !== ls)
      return !1;
  return !0;
}
function sT(t) {
  if (iT(t))
    return !0;
  const e = aT(t.elements);
  return oT(e) && !cT(e);
}
function aT(t) {
  const e = /* @__PURE__ */ new Map();
  for (const n of t) {
    const r = qf(n, !1);
    let i = e.get(r);
    i === void 0 && (i = {}, e.set(r, i)), i[n.alt] = !0;
  }
  return e;
}
function oT(t) {
  for (const e of Array.from(t.values()))
    if (Object.keys(e).length > 1)
      return !0;
  return !1;
}
function cT(t) {
  for (const e of Array.from(t.values()))
    if (Object.keys(e).length === 1)
      return !0;
  return !1;
}
var Fo;
(function(t) {
  function e(n) {
    return typeof n == "string";
  }
  t.is = e;
})(Fo || (Fo = {}));
var va;
(function(t) {
  function e(n) {
    return typeof n == "string";
  }
  t.is = e;
})(va || (va = {}));
var Go;
(function(t) {
  t.MIN_VALUE = -2147483648, t.MAX_VALUE = 2147483647;
  function e(n) {
    return typeof n == "number" && t.MIN_VALUE <= n && n <= t.MAX_VALUE;
  }
  t.is = e;
})(Go || (Go = {}));
var Wi;
(function(t) {
  t.MIN_VALUE = 0, t.MAX_VALUE = 2147483647;
  function e(n) {
    return typeof n == "number" && t.MIN_VALUE <= n && n <= t.MAX_VALUE;
  }
  t.is = e;
})(Wi || (Wi = {}));
var te;
(function(t) {
  function e(r, i) {
    return r === Number.MAX_VALUE && (r = Wi.MAX_VALUE), i === Number.MAX_VALUE && (i = Wi.MAX_VALUE), { line: r, character: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.objectLiteral(i) && v.uinteger(i.line) && v.uinteger(i.character);
  }
  t.is = n;
})(te || (te = {}));
var X;
(function(t) {
  function e(r, i, s, a) {
    if (v.uinteger(r) && v.uinteger(i) && v.uinteger(s) && v.uinteger(a))
      return { start: te.create(r, i), end: te.create(s, a) };
    if (te.is(r) && te.is(i))
      return { start: r, end: i };
    throw new Error(`Range#create called with invalid arguments[${r}, ${i}, ${s}, ${a}]`);
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.objectLiteral(i) && te.is(i.start) && te.is(i.end);
  }
  t.is = n;
})(X || (X = {}));
var Vi;
(function(t) {
  function e(r, i) {
    return { uri: r, range: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.objectLiteral(i) && X.is(i.range) && (v.string(i.uri) || v.undefined(i.uri));
  }
  t.is = n;
})(Vi || (Vi = {}));
var Uo;
(function(t) {
  function e(r, i, s, a) {
    return { targetUri: r, targetRange: i, targetSelectionRange: s, originSelectionRange: a };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.objectLiteral(i) && X.is(i.targetRange) && v.string(i.targetUri) && X.is(i.targetSelectionRange) && (X.is(i.originSelectionRange) || v.undefined(i.originSelectionRange));
  }
  t.is = n;
})(Uo || (Uo = {}));
var Ea;
(function(t) {
  function e(r, i, s, a) {
    return {
      red: r,
      green: i,
      blue: s,
      alpha: a
    };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && v.numberRange(i.red, 0, 1) && v.numberRange(i.green, 0, 1) && v.numberRange(i.blue, 0, 1) && v.numberRange(i.alpha, 0, 1);
  }
  t.is = n;
})(Ea || (Ea = {}));
var qo;
(function(t) {
  function e(r, i) {
    return {
      range: r,
      color: i
    };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && X.is(i.range) && Ea.is(i.color);
  }
  t.is = n;
})(qo || (qo = {}));
var jo;
(function(t) {
  function e(r, i, s) {
    return {
      label: r,
      textEdit: i,
      additionalTextEdits: s
    };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && v.string(i.label) && (v.undefined(i.textEdit) || Ot.is(i)) && (v.undefined(i.additionalTextEdits) || v.typedArray(i.additionalTextEdits, Ot.is));
  }
  t.is = n;
})(jo || (jo = {}));
var zo;
(function(t) {
  t.Comment = "comment", t.Imports = "imports", t.Region = "region";
})(zo || (zo = {}));
var Bo;
(function(t) {
  function e(r, i, s, a, o, c) {
    const l = {
      startLine: r,
      endLine: i
    };
    return v.defined(s) && (l.startCharacter = s), v.defined(a) && (l.endCharacter = a), v.defined(o) && (l.kind = o), v.defined(c) && (l.collapsedText = c), l;
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && v.uinteger(i.startLine) && v.uinteger(i.startLine) && (v.undefined(i.startCharacter) || v.uinteger(i.startCharacter)) && (v.undefined(i.endCharacter) || v.uinteger(i.endCharacter)) && (v.undefined(i.kind) || v.string(i.kind));
  }
  t.is = n;
})(Bo || (Bo = {}));
var Aa;
(function(t) {
  function e(r, i) {
    return {
      location: r,
      message: i
    };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && Vi.is(i.location) && v.string(i.message);
  }
  t.is = n;
})(Aa || (Aa = {}));
var Wo;
(function(t) {
  t.Error = 1, t.Warning = 2, t.Information = 3, t.Hint = 4;
})(Wo || (Wo = {}));
var Vo;
(function(t) {
  t.Unnecessary = 1, t.Deprecated = 2;
})(Vo || (Vo = {}));
var Ko;
(function(t) {
  function e(n) {
    const r = n;
    return v.objectLiteral(r) && v.string(r.href);
  }
  t.is = e;
})(Ko || (Ko = {}));
var Ki;
(function(t) {
  function e(r, i, s, a, o, c) {
    let l = { range: r, message: i };
    return v.defined(s) && (l.severity = s), v.defined(a) && (l.code = a), v.defined(o) && (l.source = o), v.defined(c) && (l.relatedInformation = c), l;
  }
  t.create = e;
  function n(r) {
    var i;
    let s = r;
    return v.defined(s) && X.is(s.range) && v.string(s.message) && (v.number(s.severity) || v.undefined(s.severity)) && (v.integer(s.code) || v.string(s.code) || v.undefined(s.code)) && (v.undefined(s.codeDescription) || v.string((i = s.codeDescription) === null || i === void 0 ? void 0 : i.href)) && (v.string(s.source) || v.undefined(s.source)) && (v.undefined(s.relatedInformation) || v.typedArray(s.relatedInformation, Aa.is));
  }
  t.is = n;
})(Ki || (Ki = {}));
var Vn;
(function(t) {
  function e(r, i, ...s) {
    let a = { title: r, command: i };
    return v.defined(s) && s.length > 0 && (a.arguments = s), a;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.string(i.title) && v.string(i.command);
  }
  t.is = n;
})(Vn || (Vn = {}));
var Ot;
(function(t) {
  function e(s, a) {
    return { range: s, newText: a };
  }
  t.replace = e;
  function n(s, a) {
    return { range: { start: s, end: s }, newText: a };
  }
  t.insert = n;
  function r(s) {
    return { range: s, newText: "" };
  }
  t.del = r;
  function i(s) {
    const a = s;
    return v.objectLiteral(a) && v.string(a.newText) && X.is(a.range);
  }
  t.is = i;
})(Ot || (Ot = {}));
var Un;
(function(t) {
  function e(r, i, s) {
    const a = { label: r };
    return i !== void 0 && (a.needsConfirmation = i), s !== void 0 && (a.description = s), a;
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && v.string(i.label) && (v.boolean(i.needsConfirmation) || i.needsConfirmation === void 0) && (v.string(i.description) || i.description === void 0);
  }
  t.is = n;
})(Un || (Un = {}));
var qe;
(function(t) {
  function e(n) {
    const r = n;
    return v.string(r);
  }
  t.is = e;
})(qe || (qe = {}));
var Jt;
(function(t) {
  function e(s, a, o) {
    return { range: s, newText: a, annotationId: o };
  }
  t.replace = e;
  function n(s, a, o) {
    return { range: { start: s, end: s }, newText: a, annotationId: o };
  }
  t.insert = n;
  function r(s, a) {
    return { range: s, newText: "", annotationId: a };
  }
  t.del = r;
  function i(s) {
    const a = s;
    return Ot.is(a) && (Un.is(a.annotationId) || qe.is(a.annotationId));
  }
  t.is = i;
})(Jt || (Jt = {}));
var Hi;
(function(t) {
  function e(r, i) {
    return { textDocument: r, edits: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && Yi.is(i.textDocument) && Array.isArray(i.edits);
  }
  t.is = n;
})(Hi || (Hi = {}));
var zr;
(function(t) {
  function e(r, i, s) {
    let a = {
      kind: "create",
      uri: r
    };
    return i !== void 0 && (i.overwrite !== void 0 || i.ignoreIfExists !== void 0) && (a.options = i), s !== void 0 && (a.annotationId = s), a;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return i && i.kind === "create" && v.string(i.uri) && (i.options === void 0 || (i.options.overwrite === void 0 || v.boolean(i.options.overwrite)) && (i.options.ignoreIfExists === void 0 || v.boolean(i.options.ignoreIfExists))) && (i.annotationId === void 0 || qe.is(i.annotationId));
  }
  t.is = n;
})(zr || (zr = {}));
var Br;
(function(t) {
  function e(r, i, s, a) {
    let o = {
      kind: "rename",
      oldUri: r,
      newUri: i
    };
    return s !== void 0 && (s.overwrite !== void 0 || s.ignoreIfExists !== void 0) && (o.options = s), a !== void 0 && (o.annotationId = a), o;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return i && i.kind === "rename" && v.string(i.oldUri) && v.string(i.newUri) && (i.options === void 0 || (i.options.overwrite === void 0 || v.boolean(i.options.overwrite)) && (i.options.ignoreIfExists === void 0 || v.boolean(i.options.ignoreIfExists))) && (i.annotationId === void 0 || qe.is(i.annotationId));
  }
  t.is = n;
})(Br || (Br = {}));
var Wr;
(function(t) {
  function e(r, i, s) {
    let a = {
      kind: "delete",
      uri: r
    };
    return i !== void 0 && (i.recursive !== void 0 || i.ignoreIfNotExists !== void 0) && (a.options = i), s !== void 0 && (a.annotationId = s), a;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return i && i.kind === "delete" && v.string(i.uri) && (i.options === void 0 || (i.options.recursive === void 0 || v.boolean(i.options.recursive)) && (i.options.ignoreIfNotExists === void 0 || v.boolean(i.options.ignoreIfNotExists))) && (i.annotationId === void 0 || qe.is(i.annotationId));
  }
  t.is = n;
})(Wr || (Wr = {}));
var Sa;
(function(t) {
  function e(n) {
    let r = n;
    return r && (r.changes !== void 0 || r.documentChanges !== void 0) && (r.documentChanges === void 0 || r.documentChanges.every((i) => v.string(i.kind) ? zr.is(i) || Br.is(i) || Wr.is(i) : Hi.is(i)));
  }
  t.is = e;
})(Sa || (Sa = {}));
class Ds {
  constructor(e, n) {
    this.edits = e, this.changeAnnotations = n;
  }
  insert(e, n, r) {
    let i, s;
    if (r === void 0 ? i = Ot.insert(e, n) : qe.is(r) ? (s = r, i = Jt.insert(e, n, r)) : (this.assertChangeAnnotations(this.changeAnnotations), s = this.changeAnnotations.manage(r), i = Jt.insert(e, n, s)), this.edits.push(i), s !== void 0)
      return s;
  }
  replace(e, n, r) {
    let i, s;
    if (r === void 0 ? i = Ot.replace(e, n) : qe.is(r) ? (s = r, i = Jt.replace(e, n, r)) : (this.assertChangeAnnotations(this.changeAnnotations), s = this.changeAnnotations.manage(r), i = Jt.replace(e, n, s)), this.edits.push(i), s !== void 0)
      return s;
  }
  delete(e, n) {
    let r, i;
    if (n === void 0 ? r = Ot.del(e) : qe.is(n) ? (i = n, r = Jt.del(e, n)) : (this.assertChangeAnnotations(this.changeAnnotations), i = this.changeAnnotations.manage(n), r = Jt.del(e, i)), this.edits.push(r), i !== void 0)
      return i;
  }
  add(e) {
    this.edits.push(e);
  }
  all() {
    return this.edits;
  }
  clear() {
    this.edits.splice(0, this.edits.length);
  }
  assertChangeAnnotations(e) {
    if (e === void 0)
      throw new Error("Text edit change is not configured to manage change annotations.");
  }
}
class mu {
  constructor(e) {
    this._annotations = e === void 0 ? /* @__PURE__ */ Object.create(null) : e, this._counter = 0, this._size = 0;
  }
  all() {
    return this._annotations;
  }
  get size() {
    return this._size;
  }
  manage(e, n) {
    let r;
    if (qe.is(e) ? r = e : (r = this.nextId(), n = e), this._annotations[r] !== void 0)
      throw new Error(`Id ${r} is already in use.`);
    if (n === void 0)
      throw new Error(`No annotation provided for id ${r}`);
    return this._annotations[r] = n, this._size++, r;
  }
  nextId() {
    return this._counter++, this._counter.toString();
  }
}
class lT {
  constructor(e) {
    this._textEditChanges = /* @__PURE__ */ Object.create(null), e !== void 0 ? (this._workspaceEdit = e, e.documentChanges ? (this._changeAnnotations = new mu(e.changeAnnotations), e.changeAnnotations = this._changeAnnotations.all(), e.documentChanges.forEach((n) => {
      if (Hi.is(n)) {
        const r = new Ds(n.edits, this._changeAnnotations);
        this._textEditChanges[n.textDocument.uri] = r;
      }
    })) : e.changes && Object.keys(e.changes).forEach((n) => {
      const r = new Ds(e.changes[n]);
      this._textEditChanges[n] = r;
    })) : this._workspaceEdit = {};
  }
  /**
   * Returns the underlying {@link WorkspaceEdit} literal
   * use to be returned from a workspace edit operation like rename.
   */
  get edit() {
    return this.initDocumentChanges(), this._changeAnnotations !== void 0 && (this._changeAnnotations.size === 0 ? this._workspaceEdit.changeAnnotations = void 0 : this._workspaceEdit.changeAnnotations = this._changeAnnotations.all()), this._workspaceEdit;
  }
  getTextEditChange(e) {
    if (Yi.is(e)) {
      if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
        throw new Error("Workspace edit is not configured for document changes.");
      const n = { uri: e.uri, version: e.version };
      let r = this._textEditChanges[n.uri];
      if (!r) {
        const i = [], s = {
          textDocument: n,
          edits: i
        };
        this._workspaceEdit.documentChanges.push(s), r = new Ds(i, this._changeAnnotations), this._textEditChanges[n.uri] = r;
      }
      return r;
    } else {
      if (this.initChanges(), this._workspaceEdit.changes === void 0)
        throw new Error("Workspace edit is not configured for normal text edit changes.");
      let n = this._textEditChanges[e];
      if (!n) {
        let r = [];
        this._workspaceEdit.changes[e] = r, n = new Ds(r), this._textEditChanges[e] = n;
      }
      return n;
    }
  }
  initDocumentChanges() {
    this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0 && (this._changeAnnotations = new mu(), this._workspaceEdit.documentChanges = [], this._workspaceEdit.changeAnnotations = this._changeAnnotations.all());
  }
  initChanges() {
    this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0 && (this._workspaceEdit.changes = /* @__PURE__ */ Object.create(null));
  }
  createFile(e, n, r) {
    if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
      throw new Error("Workspace edit is not configured for document changes.");
    let i;
    Un.is(n) || qe.is(n) ? i = n : r = n;
    let s, a;
    if (i === void 0 ? s = zr.create(e, r) : (a = qe.is(i) ? i : this._changeAnnotations.manage(i), s = zr.create(e, r, a)), this._workspaceEdit.documentChanges.push(s), a !== void 0)
      return a;
  }
  renameFile(e, n, r, i) {
    if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
      throw new Error("Workspace edit is not configured for document changes.");
    let s;
    Un.is(r) || qe.is(r) ? s = r : i = r;
    let a, o;
    if (s === void 0 ? a = Br.create(e, n, i) : (o = qe.is(s) ? s : this._changeAnnotations.manage(s), a = Br.create(e, n, i, o)), this._workspaceEdit.documentChanges.push(a), o !== void 0)
      return o;
  }
  deleteFile(e, n, r) {
    if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
      throw new Error("Workspace edit is not configured for document changes.");
    let i;
    Un.is(n) || qe.is(n) ? i = n : r = n;
    let s, a;
    if (i === void 0 ? s = Wr.create(e, r) : (a = qe.is(i) ? i : this._changeAnnotations.manage(i), s = Wr.create(e, r, a)), this._workspaceEdit.documentChanges.push(s), a !== void 0)
      return a;
  }
}
var Ho;
(function(t) {
  function e(r) {
    return { uri: r };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.string(i.uri);
  }
  t.is = n;
})(Ho || (Ho = {}));
var Yo;
(function(t) {
  function e(r, i) {
    return { uri: r, version: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.string(i.uri) && v.integer(i.version);
  }
  t.is = n;
})(Yo || (Yo = {}));
var Yi;
(function(t) {
  function e(r, i) {
    return { uri: r, version: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.string(i.uri) && (i.version === null || v.integer(i.version));
  }
  t.is = n;
})(Yi || (Yi = {}));
var Xo;
(function(t) {
  function e(r, i, s, a) {
    return { uri: r, languageId: i, version: s, text: a };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.string(i.uri) && v.string(i.languageId) && v.integer(i.version) && v.string(i.text);
  }
  t.is = n;
})(Xo || (Xo = {}));
var ka;
(function(t) {
  t.PlainText = "plaintext", t.Markdown = "markdown";
  function e(n) {
    const r = n;
    return r === t.PlainText || r === t.Markdown;
  }
  t.is = e;
})(ka || (ka = {}));
var Vr;
(function(t) {
  function e(n) {
    const r = n;
    return v.objectLiteral(n) && ka.is(r.kind) && v.string(r.value);
  }
  t.is = e;
})(Vr || (Vr = {}));
var Jo;
(function(t) {
  t.Text = 1, t.Method = 2, t.Function = 3, t.Constructor = 4, t.Field = 5, t.Variable = 6, t.Class = 7, t.Interface = 8, t.Module = 9, t.Property = 10, t.Unit = 11, t.Value = 12, t.Enum = 13, t.Keyword = 14, t.Snippet = 15, t.Color = 16, t.File = 17, t.Reference = 18, t.Folder = 19, t.EnumMember = 20, t.Constant = 21, t.Struct = 22, t.Event = 23, t.Operator = 24, t.TypeParameter = 25;
})(Jo || (Jo = {}));
var Qo;
(function(t) {
  t.PlainText = 1, t.Snippet = 2;
})(Qo || (Qo = {}));
var Zo;
(function(t) {
  t.Deprecated = 1;
})(Zo || (Zo = {}));
var ec;
(function(t) {
  function e(r, i, s) {
    return { newText: r, insert: i, replace: s };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return i && v.string(i.newText) && X.is(i.insert) && X.is(i.replace);
  }
  t.is = n;
})(ec || (ec = {}));
var tc;
(function(t) {
  t.asIs = 1, t.adjustIndentation = 2;
})(tc || (tc = {}));
var nc;
(function(t) {
  function e(n) {
    const r = n;
    return r && (v.string(r.detail) || r.detail === void 0) && (v.string(r.description) || r.description === void 0);
  }
  t.is = e;
})(nc || (nc = {}));
var rc;
(function(t) {
  function e(n) {
    return { label: n };
  }
  t.create = e;
})(rc || (rc = {}));
var ic;
(function(t) {
  function e(n, r) {
    return { items: n || [], isIncomplete: !!r };
  }
  t.create = e;
})(ic || (ic = {}));
var Xi;
(function(t) {
  function e(r) {
    return r.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&");
  }
  t.fromPlainText = e;
  function n(r) {
    const i = r;
    return v.string(i) || v.objectLiteral(i) && v.string(i.language) && v.string(i.value);
  }
  t.is = n;
})(Xi || (Xi = {}));
var sc;
(function(t) {
  function e(n) {
    let r = n;
    return !!r && v.objectLiteral(r) && (Vr.is(r.contents) || Xi.is(r.contents) || v.typedArray(r.contents, Xi.is)) && (n.range === void 0 || X.is(n.range));
  }
  t.is = e;
})(sc || (sc = {}));
var ac;
(function(t) {
  function e(n, r) {
    return r ? { label: n, documentation: r } : { label: n };
  }
  t.create = e;
})(ac || (ac = {}));
var oc;
(function(t) {
  function e(n, r, ...i) {
    let s = { label: n };
    return v.defined(r) && (s.documentation = r), v.defined(i) ? s.parameters = i : s.parameters = [], s;
  }
  t.create = e;
})(oc || (oc = {}));
var cc;
(function(t) {
  t.Text = 1, t.Read = 2, t.Write = 3;
})(cc || (cc = {}));
var lc;
(function(t) {
  function e(n, r) {
    let i = { range: n };
    return v.number(r) && (i.kind = r), i;
  }
  t.create = e;
})(lc || (lc = {}));
var uc;
(function(t) {
  t.File = 1, t.Module = 2, t.Namespace = 3, t.Package = 4, t.Class = 5, t.Method = 6, t.Property = 7, t.Field = 8, t.Constructor = 9, t.Enum = 10, t.Interface = 11, t.Function = 12, t.Variable = 13, t.Constant = 14, t.String = 15, t.Number = 16, t.Boolean = 17, t.Array = 18, t.Object = 19, t.Key = 20, t.Null = 21, t.EnumMember = 22, t.Struct = 23, t.Event = 24, t.Operator = 25, t.TypeParameter = 26;
})(uc || (uc = {}));
var dc;
(function(t) {
  t.Deprecated = 1;
})(dc || (dc = {}));
var fc;
(function(t) {
  function e(n, r, i, s, a) {
    let o = {
      name: n,
      kind: r,
      location: { uri: s, range: i }
    };
    return a && (o.containerName = a), o;
  }
  t.create = e;
})(fc || (fc = {}));
var hc;
(function(t) {
  function e(n, r, i, s) {
    return s !== void 0 ? { name: n, kind: r, location: { uri: i, range: s } } : { name: n, kind: r, location: { uri: i } };
  }
  t.create = e;
})(hc || (hc = {}));
var pc;
(function(t) {
  function e(r, i, s, a, o, c) {
    let l = {
      name: r,
      detail: i,
      kind: s,
      range: a,
      selectionRange: o
    };
    return c !== void 0 && (l.children = c), l;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return i && v.string(i.name) && v.number(i.kind) && X.is(i.range) && X.is(i.selectionRange) && (i.detail === void 0 || v.string(i.detail)) && (i.deprecated === void 0 || v.boolean(i.deprecated)) && (i.children === void 0 || Array.isArray(i.children)) && (i.tags === void 0 || Array.isArray(i.tags));
  }
  t.is = n;
})(pc || (pc = {}));
var mc;
(function(t) {
  t.Empty = "", t.QuickFix = "quickfix", t.Refactor = "refactor", t.RefactorExtract = "refactor.extract", t.RefactorInline = "refactor.inline", t.RefactorRewrite = "refactor.rewrite", t.Source = "source", t.SourceOrganizeImports = "source.organizeImports", t.SourceFixAll = "source.fixAll";
})(mc || (mc = {}));
var Ji;
(function(t) {
  t.Invoked = 1, t.Automatic = 2;
})(Ji || (Ji = {}));
var gc;
(function(t) {
  function e(r, i, s) {
    let a = { diagnostics: r };
    return i != null && (a.only = i), s != null && (a.triggerKind = s), a;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.typedArray(i.diagnostics, Ki.is) && (i.only === void 0 || v.typedArray(i.only, v.string)) && (i.triggerKind === void 0 || i.triggerKind === Ji.Invoked || i.triggerKind === Ji.Automatic);
  }
  t.is = n;
})(gc || (gc = {}));
var yc;
(function(t) {
  function e(r, i, s) {
    let a = { title: r }, o = !0;
    return typeof i == "string" ? (o = !1, a.kind = i) : Vn.is(i) ? a.command = i : a.edit = i, o && s !== void 0 && (a.kind = s), a;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return i && v.string(i.title) && (i.diagnostics === void 0 || v.typedArray(i.diagnostics, Ki.is)) && (i.kind === void 0 || v.string(i.kind)) && (i.edit !== void 0 || i.command !== void 0) && (i.command === void 0 || Vn.is(i.command)) && (i.isPreferred === void 0 || v.boolean(i.isPreferred)) && (i.edit === void 0 || Sa.is(i.edit));
  }
  t.is = n;
})(yc || (yc = {}));
var Tc;
(function(t) {
  function e(r, i) {
    let s = { range: r };
    return v.defined(i) && (s.data = i), s;
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && X.is(i.range) && (v.undefined(i.command) || Vn.is(i.command));
  }
  t.is = n;
})(Tc || (Tc = {}));
var Rc;
(function(t) {
  function e(r, i) {
    return { tabSize: r, insertSpaces: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && v.uinteger(i.tabSize) && v.boolean(i.insertSpaces);
  }
  t.is = n;
})(Rc || (Rc = {}));
var vc;
(function(t) {
  function e(r, i, s) {
    return { range: r, target: i, data: s };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.defined(i) && X.is(i.range) && (v.undefined(i.target) || v.string(i.target));
  }
  t.is = n;
})(vc || (vc = {}));
var Ec;
(function(t) {
  function e(r, i) {
    return { range: r, parent: i };
  }
  t.create = e;
  function n(r) {
    let i = r;
    return v.objectLiteral(i) && X.is(i.range) && (i.parent === void 0 || t.is(i.parent));
  }
  t.is = n;
})(Ec || (Ec = {}));
var Ac;
(function(t) {
  t.namespace = "namespace", t.type = "type", t.class = "class", t.enum = "enum", t.interface = "interface", t.struct = "struct", t.typeParameter = "typeParameter", t.parameter = "parameter", t.variable = "variable", t.property = "property", t.enumMember = "enumMember", t.event = "event", t.function = "function", t.method = "method", t.macro = "macro", t.keyword = "keyword", t.modifier = "modifier", t.comment = "comment", t.string = "string", t.number = "number", t.regexp = "regexp", t.operator = "operator", t.decorator = "decorator";
})(Ac || (Ac = {}));
var Sc;
(function(t) {
  t.declaration = "declaration", t.definition = "definition", t.readonly = "readonly", t.static = "static", t.deprecated = "deprecated", t.abstract = "abstract", t.async = "async", t.modification = "modification", t.documentation = "documentation", t.defaultLibrary = "defaultLibrary";
})(Sc || (Sc = {}));
var kc;
(function(t) {
  function e(n) {
    const r = n;
    return v.objectLiteral(r) && (r.resultId === void 0 || typeof r.resultId == "string") && Array.isArray(r.data) && (r.data.length === 0 || typeof r.data[0] == "number");
  }
  t.is = e;
})(kc || (kc = {}));
var Cc;
(function(t) {
  function e(r, i) {
    return { range: r, text: i };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return i != null && X.is(i.range) && v.string(i.text);
  }
  t.is = n;
})(Cc || (Cc = {}));
var Nc;
(function(t) {
  function e(r, i, s) {
    return { range: r, variableName: i, caseSensitiveLookup: s };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return i != null && X.is(i.range) && v.boolean(i.caseSensitiveLookup) && (v.string(i.variableName) || i.variableName === void 0);
  }
  t.is = n;
})(Nc || (Nc = {}));
var wc;
(function(t) {
  function e(r, i) {
    return { range: r, expression: i };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return i != null && X.is(i.range) && (v.string(i.expression) || i.expression === void 0);
  }
  t.is = n;
})(wc || (wc = {}));
var bc;
(function(t) {
  function e(r, i) {
    return { frameId: r, stoppedLocation: i };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.defined(i) && X.is(r.stoppedLocation);
  }
  t.is = n;
})(bc || (bc = {}));
var Ca;
(function(t) {
  t.Type = 1, t.Parameter = 2;
  function e(n) {
    return n === 1 || n === 2;
  }
  t.is = e;
})(Ca || (Ca = {}));
var Na;
(function(t) {
  function e(r) {
    return { value: r };
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && (i.tooltip === void 0 || v.string(i.tooltip) || Vr.is(i.tooltip)) && (i.location === void 0 || Vi.is(i.location)) && (i.command === void 0 || Vn.is(i.command));
  }
  t.is = n;
})(Na || (Na = {}));
var _c;
(function(t) {
  function e(r, i, s) {
    const a = { position: r, label: i };
    return s !== void 0 && (a.kind = s), a;
  }
  t.create = e;
  function n(r) {
    const i = r;
    return v.objectLiteral(i) && te.is(i.position) && (v.string(i.label) || v.typedArray(i.label, Na.is)) && (i.kind === void 0 || Ca.is(i.kind)) && i.textEdits === void 0 || v.typedArray(i.textEdits, Ot.is) && (i.tooltip === void 0 || v.string(i.tooltip) || Vr.is(i.tooltip)) && (i.paddingLeft === void 0 || v.boolean(i.paddingLeft)) && (i.paddingRight === void 0 || v.boolean(i.paddingRight));
  }
  t.is = n;
})(_c || (_c = {}));
var Ic;
(function(t) {
  function e(n) {
    return { kind: "snippet", value: n };
  }
  t.createSnippet = e;
})(Ic || (Ic = {}));
var Pc;
(function(t) {
  function e(n, r, i, s) {
    return { insertText: n, filterText: r, range: i, command: s };
  }
  t.create = e;
})(Pc || (Pc = {}));
var $c;
(function(t) {
  function e(n) {
    return { items: n };
  }
  t.create = e;
})($c || ($c = {}));
var Lc;
(function(t) {
  t.Invoked = 0, t.Automatic = 1;
})(Lc || (Lc = {}));
var Oc;
(function(t) {
  function e(n, r) {
    return { range: n, text: r };
  }
  t.create = e;
})(Oc || (Oc = {}));
var xc;
(function(t) {
  function e(n, r) {
    return { triggerKind: n, selectedCompletionInfo: r };
  }
  t.create = e;
})(xc || (xc = {}));
var Dc;
(function(t) {
  function e(n) {
    const r = n;
    return v.objectLiteral(r) && va.is(r.uri) && v.string(r.name);
  }
  t.is = e;
})(Dc || (Dc = {}));
const uT = [`
`, `\r
`, "\r"];
var Mc;
(function(t) {
  function e(s, a, o, c) {
    return new dT(s, a, o, c);
  }
  t.create = e;
  function n(s) {
    let a = s;
    return !!(v.defined(a) && v.string(a.uri) && (v.undefined(a.languageId) || v.string(a.languageId)) && v.uinteger(a.lineCount) && v.func(a.getText) && v.func(a.positionAt) && v.func(a.offsetAt));
  }
  t.is = n;
  function r(s, a) {
    let o = s.getText(), c = i(a, (u, f) => {
      let m = u.range.start.line - f.range.start.line;
      return m === 0 ? u.range.start.character - f.range.start.character : m;
    }), l = o.length;
    for (let u = c.length - 1; u >= 0; u--) {
      let f = c[u], m = s.offsetAt(f.range.start), p = s.offsetAt(f.range.end);
      if (p <= l)
        o = o.substring(0, m) + f.newText + o.substring(p, o.length);
      else
        throw new Error("Overlapping edit");
      l = m;
    }
    return o;
  }
  t.applyEdits = r;
  function i(s, a) {
    if (s.length <= 1)
      return s;
    const o = s.length / 2 | 0, c = s.slice(0, o), l = s.slice(o);
    i(c, a), i(l, a);
    let u = 0, f = 0, m = 0;
    for (; u < c.length && f < l.length; )
      a(c[u], l[f]) <= 0 ? s[m++] = c[u++] : s[m++] = l[f++];
    for (; u < c.length; )
      s[m++] = c[u++];
    for (; f < l.length; )
      s[m++] = l[f++];
    return s;
  }
})(Mc || (Mc = {}));
let dT = class {
  constructor(e, n, r, i) {
    this._uri = e, this._languageId = n, this._version = r, this._content = i, this._lineOffsets = void 0;
  }
  get uri() {
    return this._uri;
  }
  get languageId() {
    return this._languageId;
  }
  get version() {
    return this._version;
  }
  getText(e) {
    if (e) {
      let n = this.offsetAt(e.start), r = this.offsetAt(e.end);
      return this._content.substring(n, r);
    }
    return this._content;
  }
  update(e, n) {
    this._content = e.text, this._version = n, this._lineOffsets = void 0;
  }
  getLineOffsets() {
    if (this._lineOffsets === void 0) {
      let e = [], n = this._content, r = !0;
      for (let i = 0; i < n.length; i++) {
        r && (e.push(i), r = !1);
        let s = n.charAt(i);
        r = s === "\r" || s === `
`, s === "\r" && i + 1 < n.length && n.charAt(i + 1) === `
` && i++;
      }
      r && n.length > 0 && e.push(n.length), this._lineOffsets = e;
    }
    return this._lineOffsets;
  }
  positionAt(e) {
    e = Math.max(Math.min(e, this._content.length), 0);
    let n = this.getLineOffsets(), r = 0, i = n.length;
    if (i === 0)
      return te.create(0, e);
    for (; r < i; ) {
      let a = Math.floor((r + i) / 2);
      n[a] > e ? i = a : r = a + 1;
    }
    let s = r - 1;
    return te.create(s, e - n[s]);
  }
  offsetAt(e) {
    let n = this.getLineOffsets();
    if (e.line >= n.length)
      return this._content.length;
    if (e.line < 0)
      return 0;
    let r = n[e.line], i = e.line + 1 < n.length ? n[e.line + 1] : this._content.length;
    return Math.max(Math.min(r + e.character, i), r);
  }
  get lineCount() {
    return this.getLineOffsets().length;
  }
};
var v;
(function(t) {
  const e = Object.prototype.toString;
  function n(p) {
    return typeof p < "u";
  }
  t.defined = n;
  function r(p) {
    return typeof p > "u";
  }
  t.undefined = r;
  function i(p) {
    return p === !0 || p === !1;
  }
  t.boolean = i;
  function s(p) {
    return e.call(p) === "[object String]";
  }
  t.string = s;
  function a(p) {
    return e.call(p) === "[object Number]";
  }
  t.number = a;
  function o(p, A, b) {
    return e.call(p) === "[object Number]" && A <= p && p <= b;
  }
  t.numberRange = o;
  function c(p) {
    return e.call(p) === "[object Number]" && -2147483648 <= p && p <= 2147483647;
  }
  t.integer = c;
  function l(p) {
    return e.call(p) === "[object Number]" && 0 <= p && p <= 2147483647;
  }
  t.uinteger = l;
  function u(p) {
    return e.call(p) === "[object Function]";
  }
  t.func = u;
  function f(p) {
    return p !== null && typeof p == "object";
  }
  t.objectLiteral = f;
  function m(p, A) {
    return Array.isArray(p) && p.every(A);
  }
  t.typedArray = m;
})(v || (v = {}));
const fT = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  get AnnotatedTextEdit() {
    return Jt;
  },
  get ChangeAnnotation() {
    return Un;
  },
  get ChangeAnnotationIdentifier() {
    return qe;
  },
  get CodeAction() {
    return yc;
  },
  get CodeActionContext() {
    return gc;
  },
  get CodeActionKind() {
    return mc;
  },
  get CodeActionTriggerKind() {
    return Ji;
  },
  get CodeDescription() {
    return Ko;
  },
  get CodeLens() {
    return Tc;
  },
  get Color() {
    return Ea;
  },
  get ColorInformation() {
    return qo;
  },
  get ColorPresentation() {
    return jo;
  },
  get Command() {
    return Vn;
  },
  get CompletionItem() {
    return rc;
  },
  get CompletionItemKind() {
    return Jo;
  },
  get CompletionItemLabelDetails() {
    return nc;
  },
  get CompletionItemTag() {
    return Zo;
  },
  get CompletionList() {
    return ic;
  },
  get CreateFile() {
    return zr;
  },
  get DeleteFile() {
    return Wr;
  },
  get Diagnostic() {
    return Ki;
  },
  get DiagnosticRelatedInformation() {
    return Aa;
  },
  get DiagnosticSeverity() {
    return Wo;
  },
  get DiagnosticTag() {
    return Vo;
  },
  get DocumentHighlight() {
    return lc;
  },
  get DocumentHighlightKind() {
    return cc;
  },
  get DocumentLink() {
    return vc;
  },
  get DocumentSymbol() {
    return pc;
  },
  get DocumentUri() {
    return Fo;
  },
  EOL: uT,
  get FoldingRange() {
    return Bo;
  },
  get FoldingRangeKind() {
    return zo;
  },
  get FormattingOptions() {
    return Rc;
  },
  get Hover() {
    return sc;
  },
  get InlayHint() {
    return _c;
  },
  get InlayHintKind() {
    return Ca;
  },
  get InlayHintLabelPart() {
    return Na;
  },
  get InlineCompletionContext() {
    return xc;
  },
  get InlineCompletionItem() {
    return Pc;
  },
  get InlineCompletionList() {
    return $c;
  },
  get InlineCompletionTriggerKind() {
    return Lc;
  },
  get InlineValueContext() {
    return bc;
  },
  get InlineValueEvaluatableExpression() {
    return wc;
  },
  get InlineValueText() {
    return Cc;
  },
  get InlineValueVariableLookup() {
    return Nc;
  },
  get InsertReplaceEdit() {
    return ec;
  },
  get InsertTextFormat() {
    return Qo;
  },
  get InsertTextMode() {
    return tc;
  },
  get Location() {
    return Vi;
  },
  get LocationLink() {
    return Uo;
  },
  get MarkedString() {
    return Xi;
  },
  get MarkupContent() {
    return Vr;
  },
  get MarkupKind() {
    return ka;
  },
  get OptionalVersionedTextDocumentIdentifier() {
    return Yi;
  },
  get ParameterInformation() {
    return ac;
  },
  get Position() {
    return te;
  },
  get Range() {
    return X;
  },
  get RenameFile() {
    return Br;
  },
  get SelectedCompletionInfo() {
    return Oc;
  },
  get SelectionRange() {
    return Ec;
  },
  get SemanticTokenModifiers() {
    return Sc;
  },
  get SemanticTokenTypes() {
    return Ac;
  },
  get SemanticTokens() {
    return kc;
  },
  get SignatureInformation() {
    return oc;
  },
  get StringValue() {
    return Ic;
  },
  get SymbolInformation() {
    return fc;
  },
  get SymbolKind() {
    return uc;
  },
  get SymbolTag() {
    return dc;
  },
  get TextDocument() {
    return Mc;
  },
  get TextDocumentEdit() {
    return Hi;
  },
  get TextDocumentIdentifier() {
    return Ho;
  },
  get TextDocumentItem() {
    return Xo;
  },
  get TextEdit() {
    return Ot;
  },
  get URI() {
    return va;
  },
  get VersionedTextDocumentIdentifier() {
    return Yo;
  },
  WorkspaceChange: lT,
  get WorkspaceEdit() {
    return Sa;
  },
  get WorkspaceFolder() {
    return Dc;
  },
  get WorkspaceSymbol() {
    return hc;
  },
  get integer() {
    return Go;
  },
  get uinteger() {
    return Wi;
  }
}, Symbol.toStringTag, { value: "Module" }));
class hT {
  constructor() {
    this.nodeStack = [];
  }
  get current() {
    return this.nodeStack[this.nodeStack.length - 1] ?? this.rootNode;
  }
  buildRootNode(e) {
    return this.rootNode = new Vf(e), this.rootNode.root = this.rootNode, this.nodeStack = [this.rootNode], this.rootNode;
  }
  buildCompositeNode(e) {
    const n = new vl();
    return n.grammarSource = e, n.root = this.rootNode, this.current.content.push(n), this.nodeStack.push(n), n;
  }
  buildLeafNode(e, n) {
    const r = new Fc(e.startOffset, e.image.length, No(e), e.tokenType, !n);
    return r.grammarSource = n, r.root = this.rootNode, this.current.content.push(r), r;
  }
  removeNode(e) {
    const n = e.container;
    if (n) {
      const r = n.content.indexOf(e);
      r >= 0 && n.content.splice(r, 1);
    }
  }
  addHiddenNodes(e) {
    const n = [];
    for (const s of e) {
      const a = new Fc(s.startOffset, s.image.length, No(s), s.tokenType, !0);
      a.root = this.rootNode, n.push(a);
    }
    let r = this.current, i = !1;
    if (r.content.length > 0) {
      r.content.push(...n);
      return;
    }
    for (; r.container; ) {
      const s = r.container.content.indexOf(r);
      if (s > 0) {
        r.container.content.splice(s, 0, ...n), i = !0;
        break;
      }
      r = r.container;
    }
    i || this.rootNode.content.unshift(...n);
  }
  construct(e) {
    const n = this.current;
    typeof e.$type == "string" && !e.$infixName && (this.current.astNode = e), e.$cstNode = n;
    const r = this.nodeStack.pop();
    r?.content.length === 0 && this.removeNode(r);
  }
}
class Wf {
  get hidden() {
    return !1;
  }
  get astNode() {
    const e = typeof this._astNode?.$type == "string" ? this._astNode : this.container?.astNode;
    if (!e)
      throw new Error("This node has no associated AST element");
    return e;
  }
  set astNode(e) {
    this._astNode = e;
  }
  get text() {
    return this.root.fullText.substring(this.offset, this.end);
  }
}
class Fc extends Wf {
  get offset() {
    return this._offset;
  }
  get length() {
    return this._length;
  }
  get end() {
    return this._offset + this._length;
  }
  get hidden() {
    return this._hidden;
  }
  get tokenType() {
    return this._tokenType;
  }
  get range() {
    return this._range;
  }
  constructor(e, n, r, i, s = !1) {
    super(), this._hidden = s, this._offset = e, this._tokenType = i, this._length = n, this._range = r;
  }
}
class vl extends Wf {
  constructor() {
    super(...arguments), this.content = new El(this);
  }
  get offset() {
    return this.firstNonHiddenNode?.offset ?? 0;
  }
  get length() {
    return this.end - this.offset;
  }
  get end() {
    return this.lastNonHiddenNode?.end ?? 0;
  }
  get range() {
    const e = this.firstNonHiddenNode, n = this.lastNonHiddenNode;
    if (e && n) {
      if (this._rangeCache === void 0) {
        const { range: r } = e, { range: i } = n;
        this._rangeCache = { start: r.start, end: i.end.line < r.start.line ? r.start : i.end };
      }
      return this._rangeCache;
    } else
      return { start: te.create(0, 0), end: te.create(0, 0) };
  }
  get firstNonHiddenNode() {
    for (const e of this.content)
      if (!e.hidden)
        return e;
    return this.content[0];
  }
  get lastNonHiddenNode() {
    for (let e = this.content.length - 1; e >= 0; e--) {
      const n = this.content[e];
      if (!n.hidden)
        return n;
    }
    return this.content[this.content.length - 1];
  }
}
class El extends Array {
  constructor(e) {
    super(), this.parent = e, Object.setPrototypeOf(this, El.prototype);
  }
  push(...e) {
    return this.addParents(e), super.push(...e);
  }
  unshift(...e) {
    return this.addParents(e), super.unshift(...e);
  }
  splice(e, n, ...r) {
    return this.addParents(r), super.splice(e, n, ...r);
  }
  addParents(e) {
    for (const n of e)
      n.container = this.parent;
  }
}
class Vf extends vl {
  get text() {
    return this._text.substring(this.offset, this.end);
  }
  get fullText() {
    return this._text;
  }
  constructor(e) {
    super(), this._text = "", this._text = e ?? "";
  }
}
const Gc = /* @__PURE__ */ Symbol("Datatype");
function no(t) {
  return t.$type === Gc;
}
const gu = "​", Kf = (t) => t.endsWith(gu) ? t : t + gu;
class Hf {
  constructor(e) {
    this._unorderedGroups = /* @__PURE__ */ new Map(), this.allRules = /* @__PURE__ */ new Map(), this.lexer = e.parser.Lexer;
    const n = this.lexer.definition, r = e.LanguageMetaData.mode === "production";
    e.shared.profilers.LangiumProfiler?.isActive("parsing") ? this.wrapper = new TT(n, {
      ...e.parser.ParserConfig,
      skipValidations: r,
      errorMessageProvider: e.parser.ParserErrorMessageProvider
    }, e.shared.profilers.LangiumProfiler.createTask("parsing", e.LanguageMetaData.languageId)) : this.wrapper = new Xf(n, {
      ...e.parser.ParserConfig,
      skipValidations: r,
      errorMessageProvider: e.parser.ParserErrorMessageProvider
    });
  }
  alternatives(e, n) {
    this.wrapper.wrapOr(e, n);
  }
  optional(e, n) {
    this.wrapper.wrapOption(e, n);
  }
  many(e, n) {
    this.wrapper.wrapMany(e, n);
  }
  atLeastOne(e, n) {
    this.wrapper.wrapAtLeastOne(e, n);
  }
  getRule(e) {
    return this.allRules.get(e);
  }
  isRecording() {
    return this.wrapper.IS_RECORDING;
  }
  get unorderedGroups() {
    return this._unorderedGroups;
  }
  getRuleStack() {
    return this.wrapper.RULE_STACK;
  }
  finalize() {
    this.wrapper.wrapSelfAnalysis();
  }
}
class pT extends Hf {
  get current() {
    return this.stack[this.stack.length - 1];
  }
  constructor(e) {
    super(e), this.nodeBuilder = new hT(), this.stack = [], this.assignmentMap = /* @__PURE__ */ new Map(), this.operatorPrecedence = /* @__PURE__ */ new Map(), this.linker = e.references.Linker, this.converter = e.parser.ValueConverter, this.astReflection = e.shared.AstReflection;
  }
  rule(e, n) {
    const r = this.computeRuleType(e);
    let i;
    oa(e) && (i = e.name, this.registerPrecedenceMap(e));
    const s = this.wrapper.DEFINE_RULE(Kf(e.name), this.startImplementation(r, i, n).bind(this));
    return this.allRules.set(e.name, s), sn(e) && e.entry && (this.mainRule = s), s;
  }
  registerPrecedenceMap(e) {
    const n = e.name, r = /* @__PURE__ */ new Map();
    for (let i = 0; i < e.operators.precedences.length; i++) {
      const s = e.operators.precedences[i];
      for (const a of s.operators)
        r.set(a.value, {
          precedence: i,
          rightAssoc: s.associativity === "right"
        });
    }
    this.operatorPrecedence.set(n, r);
  }
  computeRuleType(e) {
    return oa(e) ? Bi(e) : e.fragment ? void 0 : Qd(e) ? Gc : Bi(e);
  }
  parse(e, n = {}) {
    this.nodeBuilder.buildRootNode(e);
    const r = this.lexerResult = this.lexer.tokenize(e);
    this.wrapper.input = r.tokens;
    const i = n.rule ? this.allRules.get(n.rule) : this.mainRule;
    if (!i)
      throw new Error(n.rule ? `No rule found with name '${n.rule}'` : "No main rule available.");
    const s = this.doParse(i);
    return this.nodeBuilder.addHiddenNodes(r.hidden), this.unorderedGroups.clear(), this.lexerResult = void 0, To(s, { deep: !0 }), {
      value: s,
      lexerErrors: r.errors,
      lexerReport: r.report,
      parserErrors: this.wrapper.errors
    };
  }
  doParse(e) {
    let n = this.wrapper.rule(e);
    if (this.stack.length > 0 && (n = this.construct()), n === void 0)
      throw new Error("No result from parser");
    if (this.stack.length > 0)
      throw new Error("Parser stack is not empty after parsing");
    return n;
  }
  startImplementation(e, n, r) {
    return (i) => {
      const s = !this.isRecording() && e !== void 0;
      if (s) {
        const a = { $type: e };
        this.stack.push(a), e === Gc ? a.value = "" : n !== void 0 && (a.$infixName = n);
      }
      return r(i), s ? this.construct() : void 0;
    };
  }
  extractHiddenTokens(e) {
    const n = this.lexerResult.hidden;
    if (!n.length)
      return [];
    const r = e.startOffset;
    for (let i = 0; i < n.length; i++)
      if (n[i].startOffset > r)
        return n.splice(0, i);
    return n.splice(0, n.length);
  }
  consume(e, n, r) {
    const i = this.wrapper.wrapConsume(e, n);
    if (!this.isRecording() && this.isValidToken(i)) {
      const s = this.extractHiddenTokens(i);
      this.nodeBuilder.addHiddenNodes(s);
      const a = this.nodeBuilder.buildLeafNode(i, r), { assignment: o, crossRef: c } = this.getAssignment(r), l = this.current;
      if (o) {
        const u = zn(r) ? i.image : this.converter.convert(i.image, a);
        this.assign(o.operator, o.feature, u, a, c);
      } else if (no(l)) {
        let u = i.image;
        zn(r) || (u = this.converter.convert(u, a).toString()), l.value += u;
      }
    }
  }
  /**
   * Most consumed parser tokens are valid. However there are two cases in which they are not valid:
   *
   * 1. They were inserted during error recovery by the parser. These tokens don't really exist and should not be further processed
   * 2. They contain invalid token ranges. This might include the special EOF token, or other tokens produced by invalid token builders.
   */
  isValidToken(e) {
    return !e.isInsertedInRecovery && !isNaN(e.startOffset) && typeof e.endOffset == "number" && !isNaN(e.endOffset);
  }
  subrule(e, n, r, i, s) {
    let a;
    !this.isRecording() && !r && (a = this.nodeBuilder.buildCompositeNode(i));
    let o;
    try {
      o = this.wrapper.wrapSubrule(e, n, s);
    } finally {
      this.isRecording() || (o === void 0 && !r && (o = this.construct()), o !== void 0 && a && a.length > 0 && this.performSubruleAssignment(o, i, a));
    }
  }
  performSubruleAssignment(e, n, r) {
    const { assignment: i, crossRef: s } = this.getAssignment(n);
    if (i)
      this.assign(i.operator, i.feature, e, r, s);
    else if (!i) {
      const a = this.current;
      if (no(a))
        a.value += e.toString();
      else if (typeof e == "object" && e) {
        const c = this.assignWithoutOverride(e, a);
        this.stack.pop(), this.stack.push(c);
      }
    }
  }
  action(e, n) {
    if (!this.isRecording()) {
      let r = this.current;
      if (n.feature && n.operator) {
        r = this.construct(), this.nodeBuilder.removeNode(r.$cstNode), this.nodeBuilder.buildCompositeNode(n).content.push(r.$cstNode);
        const s = { $type: e };
        this.stack.push(s), this.assign(n.operator, n.feature, r, r.$cstNode);
      } else
        r.$type = e;
    }
  }
  construct() {
    if (this.isRecording())
      return;
    const e = this.stack.pop();
    return this.nodeBuilder.construct(e), "$infixName" in e ? this.constructInfix(e, this.operatorPrecedence.get(e.$infixName)) : no(e) ? this.converter.convert(e.value, e.$cstNode) : (Ep(this.astReflection, e), e);
  }
  constructInfix(e, n) {
    const r = e.parts;
    if (!Array.isArray(r) || r.length === 0)
      return;
    const i = e.operators;
    if (!Array.isArray(i) || r.length < 2)
      return r[0];
    let s = 0, a = -1;
    for (let b = 0; b < i.length; b++) {
      const I = i[b], C = n.get(I) ?? {
        precedence: 1 / 0,
        rightAssoc: !1
      };
      C.precedence > a ? (a = C.precedence, s = b) : C.precedence === a && (C.rightAssoc || (s = b));
    }
    const o = i.slice(0, s), c = i.slice(s + 1), l = r.slice(0, s + 1), u = r.slice(s + 1), f = {
      $infixName: e.$infixName,
      $type: e.$type,
      $cstNode: e.$cstNode,
      parts: l,
      operators: o
    }, m = {
      $infixName: e.$infixName,
      $type: e.$type,
      $cstNode: e.$cstNode,
      parts: u,
      operators: c
    }, p = this.constructInfix(f, n), A = this.constructInfix(m, n);
    return {
      $type: e.$type,
      $cstNode: e.$cstNode,
      left: p,
      operator: i[s],
      right: A
    };
  }
  getAssignment(e) {
    if (!this.assignmentMap.has(e)) {
      const n = Ia(e, jn);
      this.assignmentMap.set(e, {
        assignment: n,
        crossRef: n && $a(n.terminal) ? n.terminal.isMulti ? "multi" : "single" : void 0
      });
    }
    return this.assignmentMap.get(e);
  }
  assign(e, n, r, i, s) {
    const a = this.current;
    let o;
    switch (s === "single" && typeof r == "string" ? o = this.linker.buildReference(a, n, i, r) : s === "multi" && typeof r == "string" ? o = this.linker.buildMultiReference(a, n, i, r) : o = r, e) {
      case "=": {
        a[n] = o;
        break;
      }
      case "?=": {
        a[n] = !0;
        break;
      }
      case "+=":
        Array.isArray(a[n]) || (a[n] = []), a[n].push(o);
    }
  }
  assignWithoutOverride(e, n) {
    for (const [i, s] of Object.entries(n)) {
      const a = e[i];
      a === void 0 ? e[i] = s : Array.isArray(a) && Array.isArray(s) && (s.push(...a), e[i] = s);
    }
    const r = e.$cstNode;
    return r && (r.astNode = void 0, e.$cstNode = void 0), e;
  }
  get definitionErrors() {
    return this.wrapper.definitionErrors;
  }
}
class mT {
  buildMismatchTokenMessage(e) {
    return vr.buildMismatchTokenMessage(e);
  }
  buildNotAllInputParsedMessage(e) {
    return vr.buildNotAllInputParsedMessage(e);
  }
  buildNoViableAltMessage(e) {
    return vr.buildNoViableAltMessage(e);
  }
  buildEarlyExitMessage(e) {
    return vr.buildEarlyExitMessage(e);
  }
}
class Yf extends mT {
  buildMismatchTokenMessage({ expected: e, actual: n }) {
    return `Expecting ${e.LABEL ? "`" + e.LABEL + "`" : e.name.endsWith(":KW") ? `keyword '${e.name.substring(0, e.name.length - 3)}'` : `token of type '${e.name}'`} but found \`${n.image}\`.`;
  }
  buildNotAllInputParsedMessage({ firstRedundant: e }) {
    return `Expecting end of file but found \`${e.image}\`.`;
  }
}
class gT extends Hf {
  constructor() {
    super(...arguments), this.tokens = [], this.elementStack = [], this.lastElementStack = [], this.nextTokenIndex = 0, this.stackSize = 0;
  }
  action() {
  }
  construct() {
  }
  parse(e) {
    this.resetState();
    const n = this.lexer.tokenize(e, { mode: "partial" });
    return this.tokens = n.tokens, this.wrapper.input = [...this.tokens], this.mainRule.call(this.wrapper, {}), this.unorderedGroups.clear(), {
      tokens: this.tokens,
      elementStack: [...this.lastElementStack],
      tokenIndex: this.nextTokenIndex
    };
  }
  rule(e, n) {
    const r = this.wrapper.DEFINE_RULE(Kf(e.name), this.startImplementation(n).bind(this));
    return this.allRules.set(e.name, r), e.entry && (this.mainRule = r), r;
  }
  resetState() {
    this.elementStack = [], this.lastElementStack = [], this.nextTokenIndex = 0, this.stackSize = 0;
  }
  startImplementation(e) {
    return (n) => {
      const r = this.keepStackSize();
      try {
        e(n);
      } finally {
        this.resetStackSize(r);
      }
    };
  }
  removeUnexpectedElements() {
    this.elementStack.splice(this.stackSize);
  }
  keepStackSize() {
    const e = this.elementStack.length;
    return this.stackSize = e, e;
  }
  resetStackSize(e) {
    this.removeUnexpectedElements(), this.stackSize = e;
  }
  consume(e, n, r) {
    this.wrapper.wrapConsume(e, n), this.isRecording() || (this.lastElementStack = [...this.elementStack, r], this.nextTokenIndex = this.currIdx + 1);
  }
  subrule(e, n, r, i, s) {
    this.before(i), this.wrapper.wrapSubrule(e, n, s), this.after(i);
  }
  before(e) {
    this.isRecording() || this.elementStack.push(e);
  }
  after(e) {
    if (!this.isRecording()) {
      const n = this.elementStack.lastIndexOf(e);
      n >= 0 && this.elementStack.splice(n);
    }
  }
  get currIdx() {
    return this.wrapper.currIdx;
  }
}
const yT = {
  recoveryEnabled: !0,
  nodeLocationTracking: "full",
  skipValidations: !0,
  errorMessageProvider: new Yf()
};
class Xf extends Ay {
  constructor(e, n) {
    const r = n && "maxLookahead" in n;
    super(e, {
      ...yT,
      lookaheadStrategy: r ? new pl({ maxLookahead: n.maxLookahead }) : new zy({
        // If validations are skipped, don't log the lookahead warnings
        logging: n.skipValidations ? () => {
        } : void 0
      }),
      ...n
    });
  }
  get IS_RECORDING() {
    return this.RECORDING_PHASE;
  }
  DEFINE_RULE(e, n, r) {
    return this.RULE(e, n, r);
  }
  wrapSelfAnalysis() {
    this.performSelfAnalysis();
  }
  wrapConsume(e, n) {
    return this.consume(e, n, void 0);
  }
  wrapSubrule(e, n, r) {
    return this.subrule(e, n, {
      ARGS: [r]
    });
  }
  wrapOr(e, n) {
    this.or(e, n);
  }
  wrapOption(e, n) {
    this.option(e, n);
  }
  wrapMany(e, n) {
    this.many(e, n);
  }
  wrapAtLeastOne(e, n) {
    this.atLeastOne(e, n);
  }
  rule(e) {
    return e.call(this, {});
  }
}
class TT extends Xf {
  constructor(e, n, r) {
    super(e, n), this.task = r;
  }
  rule(e) {
    this.task.start(), this.task.startSubTask(this.ruleName(e));
    try {
      return super.rule(e);
    } finally {
      this.task.stopSubTask(this.ruleName(e)), this.task.stop();
    }
  }
  ruleName(e) {
    return e.ruleName;
  }
  subrule(e, n, r) {
    this.task.startSubTask(this.ruleName(n));
    try {
      return super.subrule(e, n, r);
    } finally {
      this.task.stopSubTask(this.ruleName(n));
    }
  }
}
function Jf(t, e, n) {
  return RT({
    parser: e,
    tokens: n,
    ruleNames: /* @__PURE__ */ new Map()
  }, t), e;
}
function RT(t, e) {
  const n = Kd(e, !1), r = me(e.rules).filter(sn).filter((s) => n.has(s));
  for (const s of r) {
    const a = {
      ...t,
      consume: 1,
      optional: 1,
      subrule: 1,
      many: 1,
      or: 1
    };
    t.parser.rule(s, Kn(a, s.definition));
  }
  const i = me(e.rules).filter(oa).filter((s) => n.has(s));
  for (const s of i)
    t.parser.rule(s, vT(t, s));
}
function vT(t, e) {
  const n = e.call.rule.ref;
  if (!n)
    throw new Error("Could not resolve reference to infix operator rule: " + e.call.rule.$refText);
  if (an(n))
    throw new Error("Cannot use terminal rule in infix expression");
  const r = e.operators.precedences.flatMap((p) => p.operators), i = {
    $type: "Group",
    elements: []
  }, s = {
    $container: i,
    $type: "Assignment",
    feature: "parts",
    operator: "+=",
    terminal: e.call
  }, a = {
    $container: i,
    $type: "Group",
    elements: [],
    cardinality: "*"
  };
  i.elements.push(s, a);
  const c = {
    $container: a,
    $type: "Assignment",
    feature: "operators",
    operator: "+=",
    terminal: {
      $type: "Alternatives",
      elements: r
    }
  }, l = {
    ...s,
    $container: a
  };
  a.elements.push(c, l);
  const f = r.map((p) => t.tokens[p.value]).map((p, A) => ({
    ALT: () => t.parser.consume(A, p, c)
  }));
  let m;
  return (p) => {
    m ?? (m = Al(t, n)), t.parser.subrule(0, m, !1, s, p), t.parser.many(0, {
      DEF: () => {
        t.parser.alternatives(0, f), t.parser.subrule(1, m, !1, l, p);
      }
    });
  };
}
function Kn(t, e, n = !1) {
  let r;
  if (zn(e))
    r = wT(t, e);
  else if (Pa(e))
    r = ET(t, e);
  else if (jn(e))
    r = Kn(t, e.terminal);
  else if ($a(e))
    r = Qf(t, e);
  else if (Bn(e))
    r = AT(t, e);
  else if (Ud(e))
    r = kT(t, e);
  else if (jd(e))
    r = CT(t, e);
  else if (al(e))
    r = NT(t, e);
  else if (wp(e)) {
    const i = t.consume++;
    r = () => t.parser.consume(i, fn, e);
  } else
    throw new Bd(e.$cstNode, `Unexpected element type: ${e.$type}`);
  return Zf(t, n ? void 0 : wa(e), r, e.cardinality);
}
function ET(t, e) {
  const n = Bi(e);
  return () => t.parser.action(n, e);
}
function AT(t, e) {
  const n = e.rule.ref;
  if (rs(n)) {
    const r = t.subrule++, i = sn(n) && n.fragment, s = e.arguments.length > 0 ? ST(n, e.arguments) : () => ({});
    let a;
    return (o) => {
      a ?? (a = Al(t, n)), t.parser.subrule(r, a, i, e, s(o));
    };
  } else if (an(n)) {
    const r = t.consume++, i = Uc(t, n.name);
    return () => t.parser.consume(r, i, e);
  } else if (n)
    is();
  else
    throw new Bd(e.$cstNode, `Undefined rule: ${e.rule.$refText}`);
}
function ST(t, e) {
  if (e.some((r) => r.calledByName)) {
    const r = e.map((i) => ({
      parameterName: i.parameter?.ref?.name,
      predicate: Lt(i.value)
    }));
    return (i) => {
      const s = {};
      for (const { parameterName: a, predicate: o } of r)
        a && (s[a] = o(i));
      return s;
    };
  } else {
    const r = e.map((i) => Lt(i.value));
    return (i) => {
      const s = {};
      for (let a = 0; a < r.length; a++)
        if (a < t.parameters.length) {
          const o = t.parameters[a].name, c = r[a];
          s[o] = c(i);
        }
      return s;
    };
  }
}
function Lt(t) {
  if (Np(t)) {
    const e = Lt(t.left), n = Lt(t.right);
    return (r) => e(r) || n(r);
  } else if (Cp(t)) {
    const e = Lt(t.left), n = Lt(t.right);
    return (r) => e(r) && n(r);
  } else if (Ip(t)) {
    const e = Lt(t.value);
    return (n) => !e(n);
  } else if (Pp(t)) {
    const e = t.parameter.ref.name;
    return (n) => n !== void 0 && n[e] === !0;
  } else if (Sp(t)) {
    const e = !!t.true;
    return () => e;
  }
  is();
}
function kT(t, e) {
  if (e.elements.length === 1)
    return Kn(t, e.elements[0]);
  {
    const n = [];
    for (const i of e.elements) {
      const s = {
        // Since we handle the guard condition in the alternative already
        // We can ignore the group guard condition inside
        ALT: Kn(t, i, !0)
      }, a = wa(i);
      a && (s.GATE = Lt(a)), n.push(s);
    }
    const r = t.or++;
    return (i) => t.parser.alternatives(r, n.map((s) => {
      const a = {
        ALT: () => s.ALT(i)
      }, o = s.GATE;
      return o && (a.GATE = () => o(i)), a;
    }));
  }
}
function CT(t, e) {
  if (e.elements.length === 1)
    return Kn(t, e.elements[0]);
  const n = [];
  for (const o of e.elements) {
    const c = {
      // Since we handle the guard condition in the alternative already
      // We can ignore the group guard condition inside
      ALT: Kn(t, o, !0)
    }, l = wa(o);
    l && (c.GATE = Lt(l)), n.push(c);
  }
  const r = t.or++, i = (o, c) => {
    const l = c.getRuleStack().join("-");
    return `uGroup_${o}_${l}`;
  }, s = (o) => t.parser.alternatives(r, n.map((c, l) => {
    const u = { ALT: () => !0 }, f = t.parser;
    u.ALT = () => {
      if (c.ALT(o), !f.isRecording()) {
        const p = i(r, f);
        f.unorderedGroups.get(p) || f.unorderedGroups.set(p, []);
        const A = f.unorderedGroups.get(p);
        typeof A?.[l] > "u" && (A[l] = !0);
      }
    };
    const m = c.GATE;
    return m ? u.GATE = () => m(o) : u.GATE = () => !f.unorderedGroups.get(i(r, f))?.[l], u;
  })), a = Zf(t, wa(e), s, "*");
  return (o) => {
    a(o), t.parser.isRecording() || t.parser.unorderedGroups.delete(i(r, t.parser));
  };
}
function NT(t, e) {
  const n = e.elements.map((r) => Kn(t, r));
  return (r) => n.forEach((i) => i(r));
}
function wa(t) {
  if (al(t))
    return t.guardCondition;
}
function Qf(t, e, n = e.terminal) {
  if (n)
    if (Bn(n) && sn(n.rule.ref)) {
      const r = n.rule.ref, i = t.subrule++;
      let s;
      return (a) => {
        s ?? (s = Al(t, r)), t.parser.subrule(i, s, !1, e, a);
      };
    } else if (Bn(n) && an(n.rule.ref)) {
      const r = t.consume++, i = Uc(t, n.rule.ref.name);
      return () => t.parser.consume(r, i, e);
    } else if (zn(n)) {
      const r = t.consume++, i = Uc(t, n.value);
      return () => t.parser.consume(r, i, e);
    } else
      throw new Error("Could not build cross reference parser");
  else {
    if (!e.type.ref)
      throw new Error("Could not resolve reference to type: " + e.type.$refText);
    const i = Xd(e.type.ref)?.terminal;
    if (!i)
      throw new Error("Could not find name assignment for type: " + Bi(e.type.ref));
    return Qf(t, e, i);
  }
}
function wT(t, e) {
  const n = t.consume++, r = t.tokens[e.value];
  if (!r)
    throw new Error("Could not find token for keyword: " + e.value);
  return () => t.parser.consume(n, r, e);
}
function Zf(t, e, n, r) {
  const i = e && Lt(e);
  if (!r)
    if (i) {
      const s = t.or++;
      return (a) => t.parser.alternatives(s, [
        {
          ALT: () => n(a),
          GATE: () => i(a)
        },
        {
          ALT: du(),
          GATE: () => !i(a)
        }
      ]);
    } else
      return n;
  if (r === "*") {
    const s = t.many++;
    return (a) => t.parser.many(s, {
      DEF: () => n(a),
      GATE: i ? () => i(a) : void 0
    });
  } else if (r === "+") {
    const s = t.many++;
    if (i) {
      const a = t.or++;
      return (o) => t.parser.alternatives(a, [
        {
          ALT: () => t.parser.atLeastOne(s, {
            DEF: () => n(o)
          }),
          GATE: () => i(o)
        },
        {
          ALT: du(),
          GATE: () => !i(o)
        }
      ]);
    } else
      return (a) => t.parser.atLeastOne(s, {
        DEF: () => n(a)
      });
  } else if (r === "?") {
    const s = t.optional++;
    return (a) => t.parser.optional(s, {
      DEF: () => n(a),
      GATE: i ? () => i(a) : void 0
    });
  } else
    is();
}
function Al(t, e) {
  const n = bT(t, e), r = t.parser.getRule(n);
  if (!r)
    throw new Error(`Rule "${n}" not found."`);
  return r;
}
function bT(t, e) {
  if (rs(e))
    return e.name;
  if (t.ruleNames.has(e))
    return t.ruleNames.get(e);
  {
    let n = e, r = n.$container, i = e.$type;
    for (; !sn(r); )
      (al(r) || Ud(r) || jd(r)) && (i = r.elements.indexOf(n).toString() + ":" + i), n = r, r = r.$container;
    return i = r.name + ":" + i, t.ruleNames.set(e, i), i;
  }
}
function Uc(t, e) {
  const n = t.tokens[e];
  if (!n)
    throw new Error(`Token "${e}" not found."`);
  return n;
}
function _T(t) {
  const e = t.Grammar, n = t.parser.Lexer, r = new gT(t);
  return Jf(e, r, n.definition), r.finalize(), r;
}
function IT(t) {
  const e = PT(t);
  return e.finalize(), e;
}
function PT(t) {
  const e = t.Grammar, n = t.parser.Lexer, r = new pT(t);
  return Jf(e, r, n.definition);
}
class eh {
  constructor() {
    this.diagnostics = [];
  }
  buildTokens(e, n) {
    const r = me(Kd(e, !1)), i = this.buildTerminalTokens(r), s = this.buildKeywordTokens(r, i, n);
    return s.push(...i), s;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  flushLexingReport(e) {
    return { diagnostics: this.popDiagnostics() };
  }
  popDiagnostics() {
    const e = [...this.diagnostics];
    return this.diagnostics = [], e;
  }
  buildTerminalTokens(e) {
    return e.filter(an).filter((n) => !n.fragment).map((n) => this.buildTerminalToken(n)).toArray();
  }
  buildTerminalToken(e) {
    const n = cl(e), r = this.requiresCustomPattern(n) ? this.regexPatternFunction(n) : n, i = {
      name: e.name,
      PATTERN: r
    };
    return typeof r == "function" && (i.LINE_BREAKS = !0), e.hidden && (i.GROUP = Vd(n) ? tt.SKIPPED : "hidden"), i;
  }
  requiresCustomPattern(e) {
    return !!(e.flags.includes("u") || e.flags.includes("s"));
  }
  regexPatternFunction(e) {
    const n = new RegExp(e, e.flags + "y");
    return (r, i) => (n.lastIndex = i, n.exec(r));
  }
  buildKeywordTokens(e, n, r) {
    return e.filter(rs).flatMap((i) => ns(i).filter(zn)).distinct((i) => i.value).toArray().sort((i, s) => s.value.length - i.value.length).map((i) => this.buildKeywordToken(i, n, !!r?.caseInsensitive));
  }
  buildKeywordToken(e, n, r) {
    const i = this.buildKeywordPattern(e, r), s = {
      name: e.value,
      PATTERN: i,
      LONGER_ALT: this.findLongerAlt(e, n)
    };
    return typeof i == "function" && (s.LINE_BREAKS = !0), s;
  }
  buildKeywordPattern(e, n) {
    return n ? new RegExp(Oa(e.value), "i") : e.value;
  }
  findLongerAlt(e, n) {
    return n.reduce((r, i) => {
      const s = i?.PATTERN;
      return s?.source && tm("^" + s.source + "$", e.value) && r.push(i), r;
    }, []);
  }
}
class th {
  convert(e, n) {
    let r = n.grammarSource;
    if ($a(r) && (r = sm(r)), Bn(r)) {
      const i = r.rule.ref;
      if (!i)
        throw new Error("This cst node was not parsed by a rule.");
      return this.runConverter(i, e, n);
    }
    return e;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  runConverter(e, n, r) {
    switch (e.name.toUpperCase()) {
      case "INT":
        return Ht.convertInt(n);
      case "STRING":
        return Ht.convertString(n);
      case "ID":
        return Ht.convertID(n);
    }
    switch (fm(e)?.toLowerCase()) {
      case "number":
        return Ht.convertNumber(n);
      case "boolean":
        return Ht.convertBoolean(n);
      case "bigint":
        return Ht.convertBigint(n);
      case "date":
        return Ht.convertDate(n);
      default:
        return n;
    }
  }
}
var Ht;
(function(t) {
  function e(l) {
    let u = "";
    for (let f = 1; f < l.length - 1; f++) {
      const m = l.charAt(f);
      if (m === "\\") {
        const p = l.charAt(++f);
        u += n(p);
      } else
        u += m;
    }
    return u;
  }
  t.convertString = e;
  function n(l) {
    switch (l) {
      case "b":
        return "\b";
      case "f":
        return "\f";
      case "n":
        return `
`;
      case "r":
        return "\r";
      case "t":
        return "	";
      case "v":
        return "\v";
      case "0":
        return "\0";
      default:
        return l;
    }
  }
  function r(l) {
    return l.charAt(0) === "^" ? l.substring(1) : l;
  }
  t.convertID = r;
  function i(l) {
    return parseInt(l);
  }
  t.convertInt = i;
  function s(l) {
    return BigInt(l);
  }
  t.convertBigint = s;
  function a(l) {
    return new Date(l);
  }
  t.convertDate = a;
  function o(l) {
    return Number(l);
  }
  t.convertNumber = o;
  function c(l) {
    return l.toLowerCase() === "true";
  }
  t.convertBoolean = c;
})(Ht || (Ht = {}));
var An = {}, Ms = {}, yu;
function Xn() {
  if (yu) return Ms;
  yu = 1, Object.defineProperty(Ms, "__esModule", { value: !0 });
  let t;
  function e() {
    if (t === void 0)
      throw new Error("No runtime abstraction layer installed");
    return t;
  }
  return (function(n) {
    function r(i) {
      if (i === void 0)
        throw new Error("No runtime abstraction layer provided");
      t = i;
    }
    n.install = r;
  })(e || (e = {})), Ms.default = e, Ms;
}
var De = {}, Tu;
function us() {
  if (Tu) return De;
  Tu = 1, Object.defineProperty(De, "__esModule", { value: !0 }), De.stringArray = De.array = De.func = De.error = De.number = De.string = De.boolean = void 0;
  function t(o) {
    return o === !0 || o === !1;
  }
  De.boolean = t;
  function e(o) {
    return typeof o == "string" || o instanceof String;
  }
  De.string = e;
  function n(o) {
    return typeof o == "number" || o instanceof Number;
  }
  De.number = n;
  function r(o) {
    return o instanceof Error;
  }
  De.error = r;
  function i(o) {
    return typeof o == "function";
  }
  De.func = i;
  function s(o) {
    return Array.isArray(o);
  }
  De.array = s;
  function a(o) {
    return s(o) && o.every((c) => e(c));
  }
  return De.stringArray = a, De;
}
var Sn = {}, Ru;
function Qr() {
  if (Ru) return Sn;
  Ru = 1, Object.defineProperty(Sn, "__esModule", { value: !0 }), Sn.Emitter = Sn.Event = void 0;
  const t = Xn();
  var e;
  (function(i) {
    const s = { dispose() {
    } };
    i.None = function() {
      return s;
    };
  })(e || (Sn.Event = e = {}));
  class n {
    add(s, a = null, o) {
      this._callbacks || (this._callbacks = [], this._contexts = []), this._callbacks.push(s), this._contexts.push(a), Array.isArray(o) && o.push({ dispose: () => this.remove(s, a) });
    }
    remove(s, a = null) {
      if (!this._callbacks)
        return;
      let o = !1;
      for (let c = 0, l = this._callbacks.length; c < l; c++)
        if (this._callbacks[c] === s)
          if (this._contexts[c] === a) {
            this._callbacks.splice(c, 1), this._contexts.splice(c, 1);
            return;
          } else
            o = !0;
      if (o)
        throw new Error("When adding a listener with a context, you should remove it with the same context");
    }
    invoke(...s) {
      if (!this._callbacks)
        return [];
      const a = [], o = this._callbacks.slice(0), c = this._contexts.slice(0);
      for (let l = 0, u = o.length; l < u; l++)
        try {
          a.push(o[l].apply(c[l], s));
        } catch (f) {
          (0, t.default)().console.error(f);
        }
      return a;
    }
    isEmpty() {
      return !this._callbacks || this._callbacks.length === 0;
    }
    dispose() {
      this._callbacks = void 0, this._contexts = void 0;
    }
  }
  class r {
    constructor(s) {
      this._options = s;
    }
    /**
     * For the public to allow to subscribe
     * to events from this Emitter
     */
    get event() {
      return this._event || (this._event = (s, a, o) => {
        this._callbacks || (this._callbacks = new n()), this._options && this._options.onFirstListenerAdd && this._callbacks.isEmpty() && this._options.onFirstListenerAdd(this), this._callbacks.add(s, a);
        const c = {
          dispose: () => {
            this._callbacks && (this._callbacks.remove(s, a), c.dispose = r._noop, this._options && this._options.onLastListenerRemove && this._callbacks.isEmpty() && this._options.onLastListenerRemove(this));
          }
        };
        return Array.isArray(o) && o.push(c), c;
      }), this._event;
    }
    /**
     * To be kept private to fire an event to
     * subscribers
     */
    fire(s) {
      this._callbacks && this._callbacks.invoke.call(this._callbacks, s);
    }
    dispose() {
      this._callbacks && (this._callbacks.dispose(), this._callbacks = void 0);
    }
  }
  return Sn.Emitter = r, r._noop = function() {
  }, Sn;
}
var vu;
function ja() {
  if (vu) return An;
  vu = 1, Object.defineProperty(An, "__esModule", { value: !0 }), An.CancellationTokenSource = An.CancellationToken = void 0;
  const t = Xn(), e = us(), n = Qr();
  var r;
  (function(o) {
    o.None = Object.freeze({
      isCancellationRequested: !1,
      onCancellationRequested: n.Event.None
    }), o.Cancelled = Object.freeze({
      isCancellationRequested: !0,
      onCancellationRequested: n.Event.None
    });
    function c(l) {
      const u = l;
      return u && (u === o.None || u === o.Cancelled || e.boolean(u.isCancellationRequested) && !!u.onCancellationRequested);
    }
    o.is = c;
  })(r || (An.CancellationToken = r = {}));
  const i = Object.freeze(function(o, c) {
    const l = (0, t.default)().timer.setTimeout(o.bind(c), 0);
    return { dispose() {
      l.dispose();
    } };
  });
  class s {
    constructor() {
      this._isCancelled = !1;
    }
    cancel() {
      this._isCancelled || (this._isCancelled = !0, this._emitter && (this._emitter.fire(void 0), this.dispose()));
    }
    get isCancellationRequested() {
      return this._isCancelled;
    }
    get onCancellationRequested() {
      return this._isCancelled ? i : (this._emitter || (this._emitter = new n.Emitter()), this._emitter.event);
    }
    dispose() {
      this._emitter && (this._emitter.dispose(), this._emitter = void 0);
    }
  }
  class a {
    get token() {
      return this._token || (this._token = new s()), this._token;
    }
    cancel() {
      this._token ? this._token.cancel() : this._token = r.Cancelled;
    }
    dispose() {
      this._token ? this._token instanceof s && this._token.dispose() : this._token = r.None;
    }
  }
  return An.CancellationTokenSource = a, An;
}
var ye = ja();
function $T() {
  return new Promise((t) => {
    typeof setImmediate > "u" ? setTimeout(t, 0) : setImmediate(t);
  });
}
let na = 0, LT = 10;
function OT() {
  return na = performance.now(), new ye.CancellationTokenSource();
}
const Er = /* @__PURE__ */ Symbol("OperationCancelled");
function za(t) {
  return t === Er;
}
async function Xe(t) {
  if (t === ye.CancellationToken.None)
    return;
  const e = performance.now();
  if (e - na >= LT && (na = e, await $T(), na = performance.now()), t.isCancellationRequested)
    throw Er;
}
class Sl {
  constructor() {
    this.promise = new Promise((e, n) => {
      this.resolve = (r) => (e(r), this), this.reject = (r) => (n(r), this);
    });
  }
}
class Qi {
  constructor(e, n, r, i) {
    this._uri = e, this._languageId = n, this._version = r, this._content = i, this._lineOffsets = void 0;
  }
  get uri() {
    return this._uri;
  }
  get languageId() {
    return this._languageId;
  }
  get version() {
    return this._version;
  }
  getText(e) {
    if (e) {
      const n = this.offsetAt(e.start), r = this.offsetAt(e.end);
      return this._content.substring(n, r);
    }
    return this._content;
  }
  update(e, n) {
    for (const r of e)
      if (Qi.isIncremental(r)) {
        const i = rh(r.range), s = this.offsetAt(i.start), a = this.offsetAt(i.end);
        this._content = this._content.substring(0, s) + r.text + this._content.substring(a, this._content.length);
        const o = Math.max(i.start.line, 0), c = Math.max(i.end.line, 0);
        let l = this._lineOffsets;
        const u = Eu(r.text, !1, s);
        if (c - o === u.length)
          for (let m = 0, p = u.length; m < p; m++)
            l[m + o + 1] = u[m];
        else
          u.length < 1e4 ? l.splice(o + 1, c - o, ...u) : this._lineOffsets = l = l.slice(0, o + 1).concat(u, l.slice(c + 1));
        const f = r.text.length - (a - s);
        if (f !== 0)
          for (let m = o + 1 + u.length, p = l.length; m < p; m++)
            l[m] = l[m] + f;
      } else if (Qi.isFull(r))
        this._content = r.text, this._lineOffsets = void 0;
      else
        throw new Error("Unknown change event received");
    this._version = n;
  }
  getLineOffsets() {
    return this._lineOffsets === void 0 && (this._lineOffsets = Eu(this._content, !0)), this._lineOffsets;
  }
  positionAt(e) {
    e = Math.max(Math.min(e, this._content.length), 0);
    const n = this.getLineOffsets();
    let r = 0, i = n.length;
    if (i === 0)
      return { line: 0, character: e };
    for (; r < i; ) {
      const a = Math.floor((r + i) / 2);
      n[a] > e ? i = a : r = a + 1;
    }
    const s = r - 1;
    return e = this.ensureBeforeEOL(e, n[s]), { line: s, character: e - n[s] };
  }
  offsetAt(e) {
    const n = this.getLineOffsets();
    if (e.line >= n.length)
      return this._content.length;
    if (e.line < 0)
      return 0;
    const r = n[e.line];
    if (e.character <= 0)
      return r;
    const i = e.line + 1 < n.length ? n[e.line + 1] : this._content.length, s = Math.min(r + e.character, i);
    return this.ensureBeforeEOL(s, r);
  }
  ensureBeforeEOL(e, n) {
    for (; e > n && nh(this._content.charCodeAt(e - 1)); )
      e--;
    return e;
  }
  get lineCount() {
    return this.getLineOffsets().length;
  }
  static isIncremental(e) {
    const n = e;
    return n != null && typeof n.text == "string" && n.range !== void 0 && (n.rangeLength === void 0 || typeof n.rangeLength == "number");
  }
  static isFull(e) {
    const n = e;
    return n != null && typeof n.text == "string" && n.range === void 0 && n.rangeLength === void 0;
  }
}
var qc;
(function(t) {
  function e(i, s, a, o) {
    return new Qi(i, s, a, o);
  }
  t.create = e;
  function n(i, s, a) {
    if (i instanceof Qi)
      return i.update(s, a), i;
    throw new Error("TextDocument.update: document must be created by TextDocument.create");
  }
  t.update = n;
  function r(i, s) {
    const a = i.getText(), o = jc(s.map(xT), (u, f) => {
      const m = u.range.start.line - f.range.start.line;
      return m === 0 ? u.range.start.character - f.range.start.character : m;
    });
    let c = 0;
    const l = [];
    for (const u of o) {
      const f = i.offsetAt(u.range.start);
      if (f < c)
        throw new Error("Overlapping edit");
      f > c && l.push(a.substring(c, f)), u.newText.length && l.push(u.newText), c = i.offsetAt(u.range.end);
    }
    return l.push(a.substr(c)), l.join("");
  }
  t.applyEdits = r;
})(qc || (qc = {}));
function jc(t, e) {
  if (t.length <= 1)
    return t;
  const n = t.length / 2 | 0, r = t.slice(0, n), i = t.slice(n);
  jc(r, e), jc(i, e);
  let s = 0, a = 0, o = 0;
  for (; s < r.length && a < i.length; )
    e(r[s], i[a]) <= 0 ? t[o++] = r[s++] : t[o++] = i[a++];
  for (; s < r.length; )
    t[o++] = r[s++];
  for (; a < i.length; )
    t[o++] = i[a++];
  return t;
}
function Eu(t, e, n = 0) {
  const r = e ? [n] : [];
  for (let i = 0; i < t.length; i++) {
    const s = t.charCodeAt(i);
    nh(s) && (s === 13 && i + 1 < t.length && t.charCodeAt(i + 1) === 10 && i++, r.push(n + i + 1));
  }
  return r;
}
function nh(t) {
  return t === 13 || t === 10;
}
function rh(t) {
  const e = t.start, n = t.end;
  return e.line > n.line || e.line === n.line && e.character > n.character ? { start: n, end: e } : t;
}
function xT(t) {
  const e = rh(t.range);
  return e !== t.range ? { newText: t.newText, range: e } : t;
}
var ih;
(() => {
  var t = { 975: (_) => {
    function T(y) {
      if (typeof y != "string") throw new TypeError("Path must be a string. Received " + JSON.stringify(y));
    }
    function g(y, R) {
      for (var E, O = "", D = 0, x = -1, j = 0, G = 0; G <= y.length; ++G) {
        if (G < y.length) E = y.charCodeAt(G);
        else {
          if (E === 47) break;
          E = 47;
        }
        if (E === 47) {
          if (!(x === G - 1 || j === 1)) if (x !== G - 1 && j === 2) {
            if (O.length < 2 || D !== 2 || O.charCodeAt(O.length - 1) !== 46 || O.charCodeAt(O.length - 2) !== 46) {
              if (O.length > 2) {
                var ie = O.lastIndexOf("/");
                if (ie !== O.length - 1) {
                  ie === -1 ? (O = "", D = 0) : D = (O = O.slice(0, ie)).length - 1 - O.lastIndexOf("/"), x = G, j = 0;
                  continue;
                }
              } else if (O.length === 2 || O.length === 1) {
                O = "", D = 0, x = G, j = 0;
                continue;
              }
            }
            R && (O.length > 0 ? O += "/.." : O = "..", D = 2);
          } else O.length > 0 ? O += "/" + y.slice(x + 1, G) : O = y.slice(x + 1, G), D = G - x - 1;
          x = G, j = 0;
        } else E === 46 && j !== -1 ? ++j : j = -1;
      }
      return O;
    }
    var S = { resolve: function() {
      for (var y, R = "", E = !1, O = arguments.length - 1; O >= -1 && !E; O--) {
        var D;
        O >= 0 ? D = arguments[O] : (y === void 0 && (y = process.cwd()), D = y), T(D), D.length !== 0 && (R = D + "/" + R, E = D.charCodeAt(0) === 47);
      }
      return R = g(R, !E), E ? R.length > 0 ? "/" + R : "/" : R.length > 0 ? R : ".";
    }, normalize: function(y) {
      if (T(y), y.length === 0) return ".";
      var R = y.charCodeAt(0) === 47, E = y.charCodeAt(y.length - 1) === 47;
      return (y = g(y, !R)).length !== 0 || R || (y = "."), y.length > 0 && E && (y += "/"), R ? "/" + y : y;
    }, isAbsolute: function(y) {
      return T(y), y.length > 0 && y.charCodeAt(0) === 47;
    }, join: function() {
      if (arguments.length === 0) return ".";
      for (var y, R = 0; R < arguments.length; ++R) {
        var E = arguments[R];
        T(E), E.length > 0 && (y === void 0 ? y = E : y += "/" + E);
      }
      return y === void 0 ? "." : S.normalize(y);
    }, relative: function(y, R) {
      if (T(y), T(R), y === R || (y = S.resolve(y)) === (R = S.resolve(R))) return "";
      for (var E = 1; E < y.length && y.charCodeAt(E) === 47; ++E) ;
      for (var O = y.length, D = O - E, x = 1; x < R.length && R.charCodeAt(x) === 47; ++x) ;
      for (var j = R.length - x, G = D < j ? D : j, ie = -1, B = 0; B <= G; ++B) {
        if (B === G) {
          if (j > G) {
            if (R.charCodeAt(x + B) === 47) return R.slice(x + B + 1);
            if (B === 0) return R.slice(x + B);
          } else D > G && (y.charCodeAt(E + B) === 47 ? ie = B : B === 0 && (ie = 0));
          break;
        }
        var ne = y.charCodeAt(E + B);
        if (ne !== R.charCodeAt(x + B)) break;
        ne === 47 && (ie = B);
      }
      var Oe = "";
      for (B = E + ie + 1; B <= O; ++B) B !== O && y.charCodeAt(B) !== 47 || (Oe.length === 0 ? Oe += ".." : Oe += "/..");
      return Oe.length > 0 ? Oe + R.slice(x + ie) : (x += ie, R.charCodeAt(x) === 47 && ++x, R.slice(x));
    }, _makeLong: function(y) {
      return y;
    }, dirname: function(y) {
      if (T(y), y.length === 0) return ".";
      for (var R = y.charCodeAt(0), E = R === 47, O = -1, D = !0, x = y.length - 1; x >= 1; --x) if ((R = y.charCodeAt(x)) === 47) {
        if (!D) {
          O = x;
          break;
        }
      } else D = !1;
      return O === -1 ? E ? "/" : "." : E && O === 1 ? "//" : y.slice(0, O);
    }, basename: function(y, R) {
      if (R !== void 0 && typeof R != "string") throw new TypeError('"ext" argument must be a string');
      T(y);
      var E, O = 0, D = -1, x = !0;
      if (R !== void 0 && R.length > 0 && R.length <= y.length) {
        if (R.length === y.length && R === y) return "";
        var j = R.length - 1, G = -1;
        for (E = y.length - 1; E >= 0; --E) {
          var ie = y.charCodeAt(E);
          if (ie === 47) {
            if (!x) {
              O = E + 1;
              break;
            }
          } else G === -1 && (x = !1, G = E + 1), j >= 0 && (ie === R.charCodeAt(j) ? --j == -1 && (D = E) : (j = -1, D = G));
        }
        return O === D ? D = G : D === -1 && (D = y.length), y.slice(O, D);
      }
      for (E = y.length - 1; E >= 0; --E) if (y.charCodeAt(E) === 47) {
        if (!x) {
          O = E + 1;
          break;
        }
      } else D === -1 && (x = !1, D = E + 1);
      return D === -1 ? "" : y.slice(O, D);
    }, extname: function(y) {
      T(y);
      for (var R = -1, E = 0, O = -1, D = !0, x = 0, j = y.length - 1; j >= 0; --j) {
        var G = y.charCodeAt(j);
        if (G !== 47) O === -1 && (D = !1, O = j + 1), G === 46 ? R === -1 ? R = j : x !== 1 && (x = 1) : R !== -1 && (x = -1);
        else if (!D) {
          E = j + 1;
          break;
        }
      }
      return R === -1 || O === -1 || x === 0 || x === 1 && R === O - 1 && R === E + 1 ? "" : y.slice(R, O);
    }, format: function(y) {
      if (y === null || typeof y != "object") throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof y);
      return (function(R, E) {
        var O = E.dir || E.root, D = E.base || (E.name || "") + (E.ext || "");
        return O ? O === E.root ? O + D : O + "/" + D : D;
      })(0, y);
    }, parse: function(y) {
      T(y);
      var R = { root: "", dir: "", base: "", ext: "", name: "" };
      if (y.length === 0) return R;
      var E, O = y.charCodeAt(0), D = O === 47;
      D ? (R.root = "/", E = 1) : E = 0;
      for (var x = -1, j = 0, G = -1, ie = !0, B = y.length - 1, ne = 0; B >= E; --B) if ((O = y.charCodeAt(B)) !== 47) G === -1 && (ie = !1, G = B + 1), O === 46 ? x === -1 ? x = B : ne !== 1 && (ne = 1) : x !== -1 && (ne = -1);
      else if (!ie) {
        j = B + 1;
        break;
      }
      return x === -1 || G === -1 || ne === 0 || ne === 1 && x === G - 1 && x === j + 1 ? G !== -1 && (R.base = R.name = j === 0 && D ? y.slice(1, G) : y.slice(j, G)) : (j === 0 && D ? (R.name = y.slice(1, x), R.base = y.slice(1, G)) : (R.name = y.slice(j, x), R.base = y.slice(j, G)), R.ext = y.slice(x, G)), j > 0 ? R.dir = y.slice(0, j - 1) : D && (R.dir = "/"), R;
    }, sep: "/", delimiter: ":", win32: null, posix: null };
    S.posix = S, _.exports = S;
  } }, e = {};
  function n(_) {
    var T = e[_];
    if (T !== void 0) return T.exports;
    var g = e[_] = { exports: {} };
    return t[_](g, g.exports, n), g.exports;
  }
  n.d = (_, T) => {
    for (var g in T) n.o(T, g) && !n.o(_, g) && Object.defineProperty(_, g, { enumerable: !0, get: T[g] });
  }, n.o = (_, T) => Object.prototype.hasOwnProperty.call(_, T), n.r = (_) => {
    typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(_, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(_, "__esModule", { value: !0 });
  };
  var r = {};
  let i;
  n.r(r), n.d(r, { URI: () => m, Utils: () => de }), typeof process == "object" ? i = process.platform === "win32" : typeof navigator == "object" && (i = navigator.userAgent.indexOf("Windows") >= 0);
  const s = /^\w[\w\d+.-]*$/, a = /^\//, o = /^\/\//;
  function c(_, T) {
    if (!_.scheme && T) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${_.authority}", path: "${_.path}", query: "${_.query}", fragment: "${_.fragment}"}`);
    if (_.scheme && !s.test(_.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
    if (_.path) {
      if (_.authority) {
        if (!a.test(_.path)) throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character');
      } else if (o.test(_.path)) throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")');
    }
  }
  const l = "", u = "/", f = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
  class m {
    static isUri(T) {
      return T instanceof m || !!T && typeof T.authority == "string" && typeof T.fragment == "string" && typeof T.path == "string" && typeof T.query == "string" && typeof T.scheme == "string" && typeof T.fsPath == "string" && typeof T.with == "function" && typeof T.toString == "function";
    }
    scheme;
    authority;
    path;
    query;
    fragment;
    constructor(T, g, S, y, R, E = !1) {
      typeof T == "object" ? (this.scheme = T.scheme || l, this.authority = T.authority || l, this.path = T.path || l, this.query = T.query || l, this.fragment = T.fragment || l) : (this.scheme = /* @__PURE__ */ (function(O, D) {
        return O || D ? O : "file";
      })(T, E), this.authority = g || l, this.path = (function(O, D) {
        switch (O) {
          case "https":
          case "http":
          case "file":
            D ? D[0] !== u && (D = u + D) : D = u;
        }
        return D;
      })(this.scheme, S || l), this.query = y || l, this.fragment = R || l, c(this, E));
    }
    get fsPath() {
      return N(this);
    }
    with(T) {
      if (!T) return this;
      let { scheme: g, authority: S, path: y, query: R, fragment: E } = T;
      return g === void 0 ? g = this.scheme : g === null && (g = l), S === void 0 ? S = this.authority : S === null && (S = l), y === void 0 ? y = this.path : y === null && (y = l), R === void 0 ? R = this.query : R === null && (R = l), E === void 0 ? E = this.fragment : E === null && (E = l), g === this.scheme && S === this.authority && y === this.path && R === this.query && E === this.fragment ? this : new A(g, S, y, R, E);
    }
    static parse(T, g = !1) {
      const S = f.exec(T);
      return S ? new A(S[2] || l, K(S[4] || l), K(S[5] || l), K(S[7] || l), K(S[9] || l), g) : new A(l, l, l, l, l);
    }
    static file(T) {
      let g = l;
      if (i && (T = T.replace(/\\/g, u)), T[0] === u && T[1] === u) {
        const S = T.indexOf(u, 2);
        S === -1 ? (g = T.substring(2), T = u) : (g = T.substring(2, S), T = T.substring(S) || u);
      }
      return new A("file", g, T, l, l);
    }
    static from(T) {
      const g = new A(T.scheme, T.authority, T.path, T.query, T.fragment);
      return c(g, !0), g;
    }
    toString(T = !1) {
      return k(this, T);
    }
    toJSON() {
      return this;
    }
    static revive(T) {
      if (T) {
        if (T instanceof m) return T;
        {
          const g = new A(T);
          return g._formatted = T.external, g._fsPath = T._sep === p ? T.fsPath : null, g;
        }
      }
      return T;
    }
  }
  const p = i ? 1 : void 0;
  class A extends m {
    _formatted = null;
    _fsPath = null;
    get fsPath() {
      return this._fsPath || (this._fsPath = N(this)), this._fsPath;
    }
    toString(T = !1) {
      return T ? k(this, !0) : (this._formatted || (this._formatted = k(this, !1)), this._formatted);
    }
    toJSON() {
      const T = { $mid: 1 };
      return this._fsPath && (T.fsPath = this._fsPath, T._sep = p), this._formatted && (T.external = this._formatted), this.path && (T.path = this.path), this.scheme && (T.scheme = this.scheme), this.authority && (T.authority = this.authority), this.query && (T.query = this.query), this.fragment && (T.fragment = this.fragment), T;
    }
  }
  const b = { 58: "%3A", 47: "%2F", 63: "%3F", 35: "%23", 91: "%5B", 93: "%5D", 64: "%40", 33: "%21", 36: "%24", 38: "%26", 39: "%27", 40: "%28", 41: "%29", 42: "%2A", 43: "%2B", 44: "%2C", 59: "%3B", 61: "%3D", 32: "%20" };
  function I(_, T, g) {
    let S, y = -1;
    for (let R = 0; R < _.length; R++) {
      const E = _.charCodeAt(R);
      if (E >= 97 && E <= 122 || E >= 65 && E <= 90 || E >= 48 && E <= 57 || E === 45 || E === 46 || E === 95 || E === 126 || T && E === 47 || g && E === 91 || g && E === 93 || g && E === 58) y !== -1 && (S += encodeURIComponent(_.substring(y, R)), y = -1), S !== void 0 && (S += _.charAt(R));
      else {
        S === void 0 && (S = _.substr(0, R));
        const O = b[E];
        O !== void 0 ? (y !== -1 && (S += encodeURIComponent(_.substring(y, R)), y = -1), S += O) : y === -1 && (y = R);
      }
    }
    return y !== -1 && (S += encodeURIComponent(_.substring(y))), S !== void 0 ? S : _;
  }
  function C(_) {
    let T;
    for (let g = 0; g < _.length; g++) {
      const S = _.charCodeAt(g);
      S === 35 || S === 63 ? (T === void 0 && (T = _.substr(0, g)), T += b[S]) : T !== void 0 && (T += _[g]);
    }
    return T !== void 0 ? T : _;
  }
  function N(_, T) {
    let g;
    return g = _.authority && _.path.length > 1 && _.scheme === "file" ? `//${_.authority}${_.path}` : _.path.charCodeAt(0) === 47 && (_.path.charCodeAt(1) >= 65 && _.path.charCodeAt(1) <= 90 || _.path.charCodeAt(1) >= 97 && _.path.charCodeAt(1) <= 122) && _.path.charCodeAt(2) === 58 ? _.path[1].toLowerCase() + _.path.substr(2) : _.path, i && (g = g.replace(/\//g, "\\")), g;
  }
  function k(_, T) {
    const g = T ? C : I;
    let S = "", { scheme: y, authority: R, path: E, query: O, fragment: D } = _;
    if (y && (S += y, S += ":"), (R || y === "file") && (S += u, S += u), R) {
      let x = R.indexOf("@");
      if (x !== -1) {
        const j = R.substr(0, x);
        R = R.substr(x + 1), x = j.lastIndexOf(":"), x === -1 ? S += g(j, !1, !1) : (S += g(j.substr(0, x), !1, !1), S += ":", S += g(j.substr(x + 1), !1, !0)), S += "@";
      }
      R = R.toLowerCase(), x = R.lastIndexOf(":"), x === -1 ? S += g(R, !1, !0) : (S += g(R.substr(0, x), !1, !0), S += R.substr(x));
    }
    if (E) {
      if (E.length >= 3 && E.charCodeAt(0) === 47 && E.charCodeAt(2) === 58) {
        const x = E.charCodeAt(1);
        x >= 65 && x <= 90 && (E = `/${String.fromCharCode(x + 32)}:${E.substr(3)}`);
      } else if (E.length >= 2 && E.charCodeAt(1) === 58) {
        const x = E.charCodeAt(0);
        x >= 65 && x <= 90 && (E = `${String.fromCharCode(x + 32)}:${E.substr(2)}`);
      }
      S += g(E, !0, !1);
    }
    return O && (S += "?", S += g(O, !1, !1)), D && (S += "#", S += T ? D : I(D, !1, !1)), S;
  }
  function P(_) {
    try {
      return decodeURIComponent(_);
    } catch {
      return _.length > 3 ? _.substr(0, 3) + P(_.substr(3)) : _;
    }
  }
  const H = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
  function K(_) {
    return _.match(H) ? _.replace(H, ((T) => P(T))) : _;
  }
  var J = n(975);
  const oe = J.posix || J, ue = "/";
  var de;
  (function(_) {
    _.joinPath = function(T, ...g) {
      return T.with({ path: oe.join(T.path, ...g) });
    }, _.resolvePath = function(T, ...g) {
      let S = T.path, y = !1;
      S[0] !== ue && (S = ue + S, y = !0);
      let R = oe.resolve(S, ...g);
      return y && R[0] === ue && !T.authority && (R = R.substring(1)), T.with({ path: R });
    }, _.dirname = function(T) {
      if (T.path.length === 0 || T.path === ue) return T;
      let g = oe.dirname(T.path);
      return g.length === 1 && g.charCodeAt(0) === 46 && (g = ""), T.with({ path: g });
    }, _.basename = function(T) {
      return oe.basename(T.path);
    }, _.extname = function(T) {
      return oe.extname(T.path);
    };
  })(de || (de = {})), ih = r;
})();
const { URI: Ct, Utils: yi } = ih;
var ut;
(function(t) {
  t.basename = yi.basename, t.dirname = yi.dirname, t.extname = yi.extname, t.joinPath = yi.joinPath, t.resolvePath = yi.resolvePath;
  const e = typeof process == "object" && process?.platform === "win32";
  function n(a, o) {
    return a?.toString() === o?.toString();
  }
  t.equals = n;
  function r(a, o) {
    const c = typeof a == "string" ? Ct.parse(a).path : a.path, l = typeof o == "string" ? Ct.parse(o).path : o.path, u = c.split("/").filter((b) => b.length > 0), f = l.split("/").filter((b) => b.length > 0);
    if (e) {
      const b = /^[A-Z]:$/;
      if (u[0] && b.test(u[0]) && (u[0] = u[0].toLowerCase()), f[0] && b.test(f[0]) && (f[0] = f[0].toLowerCase()), u[0] !== f[0])
        return l.substring(1);
    }
    let m = 0;
    for (; m < u.length && u[m] === f[m]; m++)
      ;
    const p = "../".repeat(u.length - m), A = f.slice(m).join("/");
    return p + A;
  }
  t.relative = r;
  function i(a) {
    return Ct.parse(a.toString()).toString();
  }
  t.normalize = i;
  function s(a, o) {
    let c = typeof a == "string" ? a : a.path, l = typeof o == "string" ? o : o.path;
    return l.charAt(l.length - 1) === "/" && (l = l.slice(0, -1)), c.charAt(c.length - 1) === "/" && (c = c.slice(0, -1)), l === c ? !0 : l.length < c.length || l.charAt(c.length) !== "/" ? !1 : l.startsWith(c);
  }
  t.contains = s;
})(ut || (ut = {}));
class DT {
  constructor() {
    this.root = { name: "", children: /* @__PURE__ */ new Map() };
  }
  normalizeUri(e) {
    return ut.normalize(e);
  }
  clear() {
    this.root.children.clear();
  }
  insert(e, n) {
    const r = this.getNode(this.normalizeUri(e), !0);
    r.element = n;
  }
  delete(e) {
    const n = this.getNode(this.normalizeUri(e), !1);
    n?.parent && n.parent.children.delete(n.name);
  }
  has(e) {
    return this.getNode(this.normalizeUri(e), !1)?.element !== void 0;
  }
  hasNode(e) {
    return this.getNode(this.normalizeUri(e), !1) !== void 0;
  }
  find(e) {
    return this.getNode(this.normalizeUri(e), !1)?.element;
  }
  findNode(e) {
    const n = this.normalizeUri(e), r = this.getNode(n, !1);
    if (r)
      return {
        name: r.name,
        uri: ut.joinPath(Ct.parse(n), r.name).toString(),
        element: r.element
      };
  }
  findChildren(e) {
    const n = this.normalizeUri(e), r = this.getNode(n, !1);
    return r ? Array.from(r.children.values()).map((i) => ({
      name: i.name,
      uri: ut.joinPath(Ct.parse(n), i.name).toString(),
      element: i.element
    })) : [];
  }
  all() {
    return this.collectValues(this.root);
  }
  findAll(e) {
    const n = this.getNode(ut.normalize(e), !1);
    return n ? this.collectValues(n) : [];
  }
  getNode(e, n) {
    const r = e.split("/");
    e.charAt(e.length - 1) === "/" && r.pop();
    let i = this.root;
    for (const s of r) {
      let a = i.children.get(s);
      if (!a)
        if (n)
          a = {
            name: s,
            children: /* @__PURE__ */ new Map(),
            parent: i
          }, i.children.set(s, a);
        else
          return;
      i = a;
    }
    return i;
  }
  collectValues(e) {
    const n = [];
    e.element && n.push(e.element);
    for (const r of e.children.values())
      n.push(...this.collectValues(r));
    return n;
  }
}
var Y;
(function(t) {
  t[t.Changed = 0] = "Changed", t[t.Parsed = 1] = "Parsed", t[t.IndexedContent = 2] = "IndexedContent", t[t.ComputedScopes = 3] = "ComputedScopes", t[t.Linked = 4] = "Linked", t[t.IndexedReferences = 5] = "IndexedReferences", t[t.Validated = 6] = "Validated";
})(Y || (Y = {}));
class MT {
  constructor(e) {
    this.serviceRegistry = e.ServiceRegistry, this.textDocuments = e.workspace.TextDocuments, this.fileSystemProvider = e.workspace.FileSystemProvider;
  }
  async fromUri(e, n = ye.CancellationToken.None) {
    const r = await this.fileSystemProvider.readFile(e);
    return this.createAsync(e, r, n);
  }
  fromTextDocument(e, n, r) {
    return n = n ?? Ct.parse(e.uri), ye.CancellationToken.is(r) ? this.createAsync(n, e, r) : this.create(n, e, r);
  }
  fromString(e, n, r) {
    return ye.CancellationToken.is(r) ? this.createAsync(n, e, r) : this.create(n, e, r);
  }
  fromModel(e, n) {
    return this.create(n, { $model: e });
  }
  create(e, n, r) {
    if (typeof n == "string") {
      const i = this.parse(e, n, r);
      return this.createLangiumDocument(i, e, void 0, n);
    } else if ("$model" in n) {
      const i = { value: n.$model, parserErrors: [], lexerErrors: [] };
      return this.createLangiumDocument(i, e);
    } else {
      const i = this.parse(e, n.getText(), r);
      return this.createLangiumDocument(i, e, n);
    }
  }
  async createAsync(e, n, r) {
    if (typeof n == "string") {
      const i = await this.parseAsync(e, n, r);
      return this.createLangiumDocument(i, e, void 0, n);
    } else {
      const i = await this.parseAsync(e, n.getText(), r);
      return this.createLangiumDocument(i, e, n);
    }
  }
  /**
   * Create a LangiumDocument from a given parse result.
   *
   * A TextDocument is created on demand if it is not provided as argument here. Usually this
   * should not be necessary because the main purpose of the TextDocument is to convert between
   * text ranges and offsets, which is done solely in LSP request handling.
   *
   * With the introduction of {@link update} below this method is supposed to be mainly called
   * during workspace initialization and on addition/recognition of new files, while changes in
   * existing documents are processed via {@link update}.
   */
  createLangiumDocument(e, n, r, i) {
    let s;
    if (r)
      s = {
        parseResult: e,
        uri: n,
        state: Y.Parsed,
        references: [],
        textDocument: r
      };
    else {
      const a = this.createTextDocumentGetter(n, i);
      s = {
        parseResult: e,
        uri: n,
        state: Y.Parsed,
        references: [],
        get textDocument() {
          return a();
        }
      };
    }
    return e.value.$document = s, s;
  }
  async update(e, n) {
    const r = e.parseResult.value.$cstNode?.root.fullText, i = this.textDocuments?.get(e.uri.toString()), s = i ? i.getText() : await this.fileSystemProvider.readFile(e.uri);
    if (i)
      Object.defineProperty(e, "textDocument", {
        value: i
      });
    else {
      const a = this.createTextDocumentGetter(e.uri, s);
      Object.defineProperty(e, "textDocument", {
        get: a
      });
    }
    return r !== s && (e.parseResult = await this.parseAsync(e.uri, s, n), e.parseResult.value.$document = e), e.state = Y.Parsed, e;
  }
  parse(e, n, r) {
    return this.serviceRegistry.getServices(e).parser.LangiumParser.parse(n, r);
  }
  parseAsync(e, n, r) {
    return this.serviceRegistry.getServices(e).parser.AsyncParser.parse(n, r);
  }
  createTextDocumentGetter(e, n) {
    const r = this.serviceRegistry;
    let i;
    return () => i ?? (i = qc.create(e.toString(), r.getServices(e).LanguageMetaData.languageId, 0, n ?? ""));
  }
}
class FT {
  constructor(e) {
    this.documentTrie = new DT(), this.services = e, this.langiumDocumentFactory = e.workspace.LangiumDocumentFactory, this.documentBuilder = () => e.workspace.DocumentBuilder;
  }
  get all() {
    return me(this.documentTrie.all());
  }
  addDocument(e) {
    const n = e.uri.toString();
    if (this.documentTrie.has(n))
      throw new Error(`A document with the URI '${n}' is already present.`);
    this.documentTrie.insert(n, e);
  }
  getDocument(e) {
    const n = e.toString();
    return this.documentTrie.find(n);
  }
  getDocuments(e) {
    const n = e.toString();
    return this.documentTrie.findAll(n);
  }
  async getOrCreateDocument(e, n) {
    let r = this.getDocument(e);
    return r || (r = await this.langiumDocumentFactory.fromUri(e, n), this.addDocument(r), r);
  }
  createDocument(e, n, r) {
    if (r)
      return this.langiumDocumentFactory.fromString(n, e, r).then((i) => (this.addDocument(i), i));
    {
      const i = this.langiumDocumentFactory.fromString(n, e);
      return this.addDocument(i), i;
    }
  }
  hasDocument(e) {
    return this.documentTrie.has(e.toString());
  }
  /**
   * @deprecated Since 4.2 use `DocumentBuilder.resetToState(DocumentState.Changed)` instead
   * TODO remove this for the next major release
   */
  invalidateDocument(e) {
    const n = e.toString(), r = this.documentTrie.find(n);
    return r && this.documentBuilder().resetToState(r, Y.Changed), r;
  }
  deleteDocument(e) {
    const n = e.toString(), r = this.documentTrie.find(n);
    return r && (r.state = Y.Changed, this.documentTrie.delete(n)), r;
  }
  deleteDocuments(e) {
    const n = e.toString(), r = this.documentTrie.findAll(n);
    for (const i of r)
      i.state = Y.Changed;
    return this.documentTrie.delete(n), r;
  }
}
const rr = /* @__PURE__ */ Symbol("RefResolving");
class GT {
  constructor(e) {
    this.reflection = e.shared.AstReflection, this.langiumDocuments = () => e.shared.workspace.LangiumDocuments, this.scopeProvider = e.references.ScopeProvider, this.astNodeLocator = e.workspace.AstNodeLocator, this.profiler = e.shared.profilers.LangiumProfiler, this.languageId = e.LanguageMetaData.languageId;
  }
  async link(e, n = ye.CancellationToken.None) {
    if (this.profiler?.isActive("linking")) {
      const r = this.profiler.createTask("linking", this.languageId);
      r.start();
      try {
        for (const i of Zt(e.parseResult.value))
          await Xe(n), aa(i).forEach((s) => {
            const a = `${i.$type}:${s.property}`;
            r.startSubTask(a);
            try {
              this.doLink(s, e);
            } finally {
              r.stopSubTask(a);
            }
          });
      } finally {
        r.stop();
      }
    } else
      for (const r of Zt(e.parseResult.value))
        await Xe(n), aa(r).forEach((i) => this.doLink(i, e));
  }
  doLink(e, n) {
    const r = e.reference;
    if ("_ref" in r && r._ref === void 0) {
      r._ref = rr;
      try {
        const i = this.getCandidate(e);
        if (di(i))
          r._ref = i;
        else {
          r._nodeDescription = i;
          const s = this.loadAstNode(i);
          r._ref = s ?? this.createLinkingError(e, i);
        }
      } catch (i) {
        console.error(`An error occurred while resolving reference to '${r.$refText}':`, i);
        const s = i.message ?? String(i);
        r._ref = {
          info: e,
          message: `An error occurred while resolving reference to '${r.$refText}': ${s}`
        };
      }
      n.references.push(r);
    } else if ("_items" in r && r._items === void 0) {
      r._items = rr;
      try {
        const i = this.getCandidates(e), s = [];
        if (di(i))
          r._linkingError = i;
        else
          for (const a of i) {
            const o = this.loadAstNode(a);
            o && s.push({ ref: o, $nodeDescription: a });
          }
        r._items = s;
      } catch (i) {
        r._linkingError = {
          info: e,
          message: `An error occurred while resolving reference to '${r.$refText}': ${i}`
        }, r._items = [];
      }
      n.references.push(r);
    }
  }
  unlink(e) {
    for (const n of e.references)
      "_ref" in n ? (n._ref = void 0, delete n._nodeDescription) : "_items" in n && (n._items = void 0, delete n._linkingError);
    e.references = [];
  }
  getCandidate(e) {
    return this.scopeProvider.getScope(e).getElement(e.reference.$refText) ?? this.createLinkingError(e);
  }
  getCandidates(e) {
    const r = this.scopeProvider.getScope(e).getElements(e.reference.$refText).distinct((i) => `${i.documentUri}#${i.path}`).toArray();
    return r.length > 0 ? r : this.createLinkingError(e);
  }
  buildReference(e, n, r, i) {
    const s = this, a = {
      $refNode: r,
      $refText: i,
      _ref: void 0,
      get ref() {
        if (We(this._ref))
          return this._ref;
        if (Rp(this._nodeDescription)) {
          const o = s.loadAstNode(this._nodeDescription);
          this._ref = o ?? s.createLinkingError({ reference: a, container: e, property: n }, this._nodeDescription);
        } else if (this._ref === void 0) {
          this._ref = rr;
          const o = Bs(e).$document, c = s.getLinkedNode({ reference: a, container: e, property: n });
          if (c.error && o && o.state < Y.ComputedScopes)
            return this._ref = void 0;
          this._ref = c.node ?? c.error, this._nodeDescription = c.descr, o?.references.push(this);
        } else this._ref === rr && s.throwCyclicReferenceError(e, n, i);
        return We(this._ref) ? this._ref : void 0;
      },
      get $nodeDescription() {
        return this._nodeDescription;
      },
      get error() {
        return di(this._ref) ? this._ref : void 0;
      }
    };
    return a;
  }
  buildMultiReference(e, n, r, i) {
    const s = this, a = {
      $refNode: r,
      $refText: i,
      _items: void 0,
      get items() {
        if (Array.isArray(this._items))
          return this._items;
        if (this._items === void 0) {
          this._items = rr;
          const o = Bs(e).$document, c = s.getCandidates({
            reference: a,
            container: e,
            property: n
          }), l = [];
          if (di(c))
            this._linkingError = c;
          else
            for (const u of c) {
              const f = s.loadAstNode(u);
              f && l.push({ ref: f, $nodeDescription: u });
            }
          this._items = l, o?.references.push(this);
        } else this._items === rr && s.throwCyclicReferenceError(e, n, i);
        return Array.isArray(this._items) ? this._items : [];
      },
      get error() {
        if (this._linkingError)
          return this._linkingError;
        if (!(this.items.length > 0))
          return this._linkingError = s.createLinkingError({ reference: a, container: e, property: n });
      }
    };
    return a;
  }
  throwCyclicReferenceError(e, n, r) {
    throw new Error(`Cyclic reference resolution detected: ${this.astNodeLocator.getAstNodePath(e)}/${n} (symbol '${r}')`);
  }
  getLinkedNode(e) {
    try {
      const n = this.getCandidate(e);
      if (di(n))
        return { error: n };
      const r = this.loadAstNode(n);
      return r ? { node: r, descr: n } : {
        descr: n,
        error: this.createLinkingError(e, n)
      };
    } catch (n) {
      console.error(`An error occurred while resolving reference to '${e.reference.$refText}':`, n);
      const r = n.message ?? String(n);
      return {
        error: {
          info: e,
          message: `An error occurred while resolving reference to '${e.reference.$refText}': ${r}`
        }
      };
    }
  }
  loadAstNode(e) {
    if (e.node)
      return e.node;
    const n = this.langiumDocuments().getDocument(e.documentUri);
    if (n)
      return this.astNodeLocator.getAstNode(n.parseResult.value, e.path);
  }
  createLinkingError(e, n) {
    const r = Bs(e.container).$document;
    r && r.state < Y.ComputedScopes && console.warn(`Attempted reference resolution before document reached ComputedScopes state (${r.uri}).`);
    const i = this.reflection.getReferenceType(e);
    return {
      info: e,
      message: `Could not resolve reference to ${i} named '${e.reference.$refText}'.`,
      targetDescription: n
    };
  }
}
function UT(t) {
  return typeof t.name == "string";
}
class qT {
  getName(e) {
    if (UT(e))
      return e.name;
  }
  getNameNode(e) {
    return Yd(e.$cstNode, "name");
  }
}
class jT {
  constructor(e) {
    this.nameProvider = e.references.NameProvider, this.index = e.shared.workspace.IndexManager, this.nodeLocator = e.workspace.AstNodeLocator, this.documents = e.shared.workspace.LangiumDocuments, this.hasMultiReference = Zt(e.Grammar).some((n) => $a(n) && n.isMulti);
  }
  findDeclarations(e) {
    if (e) {
      const n = um(e), r = e.astNode;
      if (n && r) {
        const i = r[n.feature];
        if (St(i) || un(i))
          return Pl(i);
        if (Array.isArray(i)) {
          for (const s of i)
            if ((St(s) || un(s)) && s.$refNode && s.$refNode.offset <= e.offset && s.$refNode.end >= e.end)
              return Pl(s);
        }
      }
      if (r) {
        const i = this.nameProvider.getNameNode(r);
        if (i && (i === e || qp(e, i)))
          return this.getSelfNodes(r);
      }
    }
    return [];
  }
  /**
   * Returns all self-references for the specified node.
   * Since the node can be part of a multi-reference, this method returns all nodes that are part of the same multi-reference.
   */
  getSelfNodes(e) {
    if (this.hasMultiReference) {
      const n = this.index.findAllReferences(e, this.nodeLocator.getAstNodePath(e)), r = this.getNodeFromReferenceDescription(n.head());
      if (r) {
        for (const i of aa(r))
          if (un(i.reference) && i.reference.items.some((s) => s.ref === e))
            return i.reference.items.map((s) => s.ref);
      }
      return [e];
    } else
      return [e];
  }
  getNodeFromReferenceDescription(e) {
    if (!e)
      return;
    const n = this.documents.getDocument(e.sourceUri);
    if (n)
      return this.nodeLocator.getAstNode(n.parseResult.value, e.sourcePath);
  }
  findDeclarationNodes(e) {
    const n = this.findDeclarations(e), r = [];
    for (const i of n) {
      const s = this.nameProvider.getNameNode(i) ?? i.$cstNode;
      s && r.push(s);
    }
    return r;
  }
  findReferences(e, n) {
    const r = [];
    n.includeDeclaration && r.push(...this.getSelfReferences(e));
    let i = this.index.findAllReferences(e, this.nodeLocator.getAstNodePath(e));
    return n.documentUri && (i = i.filter((s) => ut.equals(s.sourceUri, n.documentUri))), r.push(...i), me(r);
  }
  getSelfReferences(e) {
    const n = this.getSelfNodes(e), r = [];
    for (const i of n) {
      const s = this.nameProvider.getNameNode(i);
      if (s) {
        const a = Qt(i), o = this.nodeLocator.getAstNodePath(i);
        r.push({
          sourceUri: a.uri,
          sourcePath: o,
          targetUri: a.uri,
          targetPath: o,
          segment: ca(s),
          local: !0
        });
      }
    }
    return r;
  }
}
class Zi {
  constructor(e) {
    if (this.map = /* @__PURE__ */ new Map(), e)
      for (const [n, r] of e)
        this.add(n, r);
  }
  /**
   * The total number of values in the multimap.
   */
  get size() {
    return yo.sum(me(this.map.values()).map((e) => e.length));
  }
  /**
   * Clear all entries in the multimap.
   */
  clear() {
    this.map.clear();
  }
  /**
   * Operates differently depending on whether a `value` is given:
   *  * With a value, this method deletes the specific key / value pair from the multimap.
   *  * Without a value, all values associated with the given key are deleted.
   *
   * @returns `true` if a value existed and has been removed, or `false` if the specified
   *     key / value does not exist.
   */
  delete(e, n) {
    if (n === void 0)
      return this.map.delete(e);
    {
      const r = this.map.get(e);
      if (r) {
        const i = r.indexOf(n);
        if (i >= 0)
          return r.length === 1 ? this.map.delete(e) : r.splice(i, 1), !0;
      }
      return !1;
    }
  }
  /**
   * Returns an array of all values associated with the given key. If no value exists,
   * an empty array is returned.
   *
   * _Note:_ The returned array is assumed not to be modified. Use the `set` method to add a
   * value and `delete` to remove a value from the multimap.
   */
  get(e) {
    return this.map.get(e) ?? [];
  }
  /**
   * Returns a stream of all values associated with the given key. If no value exists,
   * {@link EMPTY_STREAM} is returned.
   */
  getStream(e) {
    const n = this.map.get(e);
    return n ? me(n) : Fd;
  }
  /**
   * Operates differently depending on whether a `value` is given:
   *  * With a value, this method returns `true` if the specific key / value pair is present in the multimap.
   *  * Without a value, this method returns `true` if the given key is present in the multimap.
   */
  has(e, n) {
    if (n === void 0)
      return this.map.has(e);
    {
      const r = this.map.get(e);
      return r ? r.indexOf(n) >= 0 : !1;
    }
  }
  /**
   * Add the given key / value pair to the multimap.
   */
  add(e, n) {
    return this.map.has(e) ? this.map.get(e).push(n) : this.map.set(e, [n]), this;
  }
  /**
   * Add the given set of key / value pairs to the multimap.
   */
  addAll(e, n) {
    return this.map.has(e) ? this.map.get(e).push(...n) : this.map.set(e, Array.from(n)), this;
  }
  /**
   * Invokes the given callback function for every key / value pair in the multimap.
   */
  forEach(e) {
    this.map.forEach((n, r) => n.forEach((i) => e(i, r, this)));
  }
  /**
   * Returns an iterator of key, value pairs for every entry in the map.
   */
  [Symbol.iterator]() {
    return this.entries().iterator();
  }
  /**
   * Returns a stream of key, value pairs for every entry in the map.
   */
  entries() {
    return me(this.map.entries()).flatMap(([e, n]) => n.map((r) => [e, r]));
  }
  /**
   * Returns a stream of keys in the map.
   */
  keys() {
    return me(this.map.keys());
  }
  /**
   * Returns a stream of values in the map.
   */
  values() {
    return me(this.map.values()).flat();
  }
  /**
   * Returns a stream of key, value set pairs for every key in the map.
   */
  entriesGroupedByKey() {
    return me(this.map.entries());
  }
}
class Au {
  get size() {
    return this.map.size;
  }
  constructor(e) {
    if (this.map = /* @__PURE__ */ new Map(), this.inverse = /* @__PURE__ */ new Map(), e)
      for (const [n, r] of e)
        this.set(n, r);
  }
  clear() {
    this.map.clear(), this.inverse.clear();
  }
  set(e, n) {
    return this.map.set(e, n), this.inverse.set(n, e), this;
  }
  get(e) {
    return this.map.get(e);
  }
  getKey(e) {
    return this.inverse.get(e);
  }
  delete(e) {
    const n = this.map.get(e);
    return n !== void 0 ? (this.map.delete(e), this.inverse.delete(n), !0) : !1;
  }
}
class zT {
  constructor(e) {
    this.nameProvider = e.references.NameProvider, this.descriptions = e.workspace.AstNodeDescriptionProvider;
  }
  async collectExportedSymbols(e, n = ye.CancellationToken.None) {
    return this.collectExportedSymbolsForNode(e.parseResult.value, e, void 0, n);
  }
  /**
   * Creates {@link AstNodeDescription AstNodeDescriptions} for the given {@link AstNode parentNode} and its children.
   * The list of children to be considered is determined by the function parameter {@link children}.
   * By default only the direct children of {@link parentNode} are visited, nested nodes are not exported.
   *
   * @param parentNode AST node to be exported, i.e., of which an {@link AstNodeDescription} shall be added to the returned list.
   * @param document The document containing the AST node to be exported.
   * @param children A function called with {@link parentNode} as single argument and returning an {@link Iterable} supplying the children to be visited, which must be directly or transitively contained in {@link parentNode}.
   * @param cancelToken Indicates when to cancel the current operation.
   * @throws `OperationCancelled` if a user action occurs during execution.
   * @returns A list of {@link AstNodeDescription AstNodeDescriptions} to be published to index.
   */
  async collectExportedSymbolsForNode(e, n, r = sl, i = ye.CancellationToken.None) {
    const s = [];
    this.addExportedSymbol(e, s, n);
    for (const a of r(e))
      await Xe(i), this.addExportedSymbol(a, s, n);
    return s;
  }
  /**
   * Adds a single node to the list of exports if it has a name. Override this method to change how
   * symbols are exported, e.g. by modifying their exported name.
   */
  addExportedSymbol(e, n, r) {
    const i = this.nameProvider.getName(e);
    i && n.push(this.descriptions.createDescription(e, i, r));
  }
  // --- local symbols gathering ---
  async collectLocalSymbols(e, n = ye.CancellationToken.None) {
    const r = e.parseResult.value, i = new Zi();
    for (const s of ns(r))
      await Xe(n), this.addLocalSymbol(s, e, i);
    return i;
  }
  /**
   * Adds a single node to the local symbols of its containing document if it has a name.
   * The default implementation makes the node visible in the subtree of its container if it does have a container.
   * Override this method to change this, e.g. by increasing the visibility to a higher level in the AST.
   */
  addLocalSymbol(e, n, r) {
    const i = e.$container;
    if (i) {
      const s = this.nameProvider.getName(e);
      s && r.add(i, this.descriptions.createDescription(e, s, n));
    }
  }
}
class Su {
  constructor(e, n, r) {
    this.elements = e, this.outerScope = n, this.caseInsensitive = r?.caseInsensitive ?? !1, this.concatOuterScope = r?.concatOuterScope ?? !0;
  }
  getAllElements() {
    return this.outerScope ? this.elements.concat(this.outerScope.getAllElements()) : this.elements;
  }
  getElement(e) {
    const n = this.caseInsensitive ? e.toLowerCase() : e, r = this.caseInsensitive ? this.elements.find((i) => i.name.toLowerCase() === n) : this.elements.find((i) => i.name === e);
    if (r)
      return r;
    if (this.outerScope)
      return this.outerScope.getElement(e);
  }
  getElements(e) {
    const n = this.caseInsensitive ? e.toLowerCase() : e, r = this.caseInsensitive ? this.elements.filter((i) => i.name.toLowerCase() === n) : this.elements.filter((i) => i.name === e);
    return (this.concatOuterScope || r.isEmpty()) && this.outerScope ? r.concat(this.outerScope.getElements(e)) : r;
  }
}
class BT {
  constructor(e, n, r) {
    this.elements = new Zi(), this.caseInsensitive = r?.caseInsensitive ?? !1, this.concatOuterScope = r?.concatOuterScope ?? !0;
    for (const i of e) {
      const s = this.caseInsensitive ? i.name.toLowerCase() : i.name;
      this.elements.add(s, i);
    }
    this.outerScope = n;
  }
  getElement(e) {
    const n = this.caseInsensitive ? e.toLowerCase() : e, r = this.elements.get(n)[0];
    if (r)
      return r;
    if (this.outerScope)
      return this.outerScope.getElement(e);
  }
  getElements(e) {
    const n = this.caseInsensitive ? e.toLowerCase() : e, r = this.elements.get(n);
    return (this.concatOuterScope || r.length === 0) && this.outerScope ? me(r).concat(this.outerScope.getElements(e)) : me(r);
  }
  getAllElements() {
    let e = me(this.elements.values());
    return this.outerScope && (e = e.concat(this.outerScope.getAllElements())), e;
  }
}
class sh {
  constructor() {
    this.toDispose = [], this.isDisposed = !1;
  }
  onDispose(e) {
    this.toDispose.push(e);
  }
  dispose() {
    this.throwIfDisposed(), this.clear(), this.isDisposed = !0, this.toDispose.forEach((e) => e.dispose());
  }
  throwIfDisposed() {
    if (this.isDisposed)
      throw new Error("This cache has already been disposed");
  }
}
class WT extends sh {
  constructor() {
    super(...arguments), this.cache = /* @__PURE__ */ new Map();
  }
  has(e) {
    return this.throwIfDisposed(), this.cache.has(e);
  }
  set(e, n) {
    this.throwIfDisposed(), this.cache.set(e, n);
  }
  get(e, n) {
    if (this.throwIfDisposed(), this.cache.has(e))
      return this.cache.get(e);
    if (n) {
      const r = n();
      return this.cache.set(e, r), r;
    } else
      return;
  }
  delete(e) {
    return this.throwIfDisposed(), this.cache.delete(e);
  }
  clear() {
    this.throwIfDisposed(), this.cache.clear();
  }
}
class VT extends sh {
  constructor(e) {
    super(), this.cache = /* @__PURE__ */ new Map(), this.converter = e ?? ((n) => n);
  }
  has(e, n) {
    return this.throwIfDisposed(), this.cacheForContext(e).has(n);
  }
  set(e, n, r) {
    this.throwIfDisposed(), this.cacheForContext(e).set(n, r);
  }
  get(e, n, r) {
    this.throwIfDisposed();
    const i = this.cacheForContext(e);
    if (i.has(n))
      return i.get(n);
    if (r) {
      const s = r();
      return i.set(n, s), s;
    } else
      return;
  }
  delete(e, n) {
    return this.throwIfDisposed(), this.cacheForContext(e).delete(n);
  }
  clear(e) {
    if (this.throwIfDisposed(), e) {
      const n = this.converter(e);
      this.cache.delete(n);
    } else
      this.cache.clear();
  }
  cacheForContext(e) {
    const n = this.converter(e);
    let r = this.cache.get(n);
    return r || (r = /* @__PURE__ */ new Map(), this.cache.set(n, r)), r;
  }
}
class KT extends WT {
  /**
   * Creates a new workspace cache.
   *
   * @param sharedServices Service container instance to hook into document lifecycle events.
   * @param state Optional document state on which the cache should evict.
   * If not provided, the cache will evict on `DocumentBuilder#onUpdate`.
   * *Deleted* documents are considered in both cases.
   */
  constructor(e, n) {
    super(), n ? (this.toDispose.push(e.workspace.DocumentBuilder.onBuildPhase(n, () => {
      this.clear();
    })), this.toDispose.push(e.workspace.DocumentBuilder.onUpdate((r, i) => {
      i.length > 0 && this.clear();
    }))) : this.toDispose.push(e.workspace.DocumentBuilder.onUpdate(() => {
      this.clear();
    }));
  }
}
class HT {
  constructor(e) {
    this.reflection = e.shared.AstReflection, this.nameProvider = e.references.NameProvider, this.descriptions = e.workspace.AstNodeDescriptionProvider, this.indexManager = e.shared.workspace.IndexManager, this.globalScopeCache = new KT(e.shared);
  }
  getScope(e) {
    const n = [], r = this.reflection.getReferenceType(e), i = Qt(e.container).localSymbols;
    if (i) {
      let a = e.container;
      do
        i.has(a) && n.push(i.getStream(a).filter((o) => this.reflection.isSubtype(o.type, r))), a = a.$container;
      while (a);
    }
    let s = this.getGlobalScope(r, e);
    for (let a = n.length - 1; a >= 0; a--)
      s = this.createScope(n[a], s);
    return s;
  }
  /**
   * Create a scope for the given collection of AST node descriptions.
   */
  createScope(e, n, r) {
    return new Su(me(e), n, r);
  }
  /**
   * Create a scope for the given collection of AST nodes, which need to be transformed into respective
   * descriptions first. This is done using the `NameProvider` and `AstNodeDescriptionProvider` services.
   */
  createScopeForNodes(e, n, r) {
    const i = me(e).map((s) => {
      const a = this.nameProvider.getName(s);
      if (a)
        return this.descriptions.createDescription(s, a);
    }).nonNullable();
    return new Su(i, n, r);
  }
  /**
   * Create a global scope filtered for the given reference type.
   */
  getGlobalScope(e, n) {
    return this.globalScopeCache.get(e, () => new BT(this.indexManager.allElements(e)));
  }
}
function YT(t) {
  return typeof t.$comment == "string";
}
function ku(t) {
  return typeof t == "object" && !!t && ("$ref" in t || "$error" in t);
}
class XT {
  constructor(e) {
    this.ignoreProperties = /* @__PURE__ */ new Set(["$container", "$containerProperty", "$containerIndex", "$document", "$cstNode"]), this.langiumDocuments = e.shared.workspace.LangiumDocuments, this.astNodeLocator = e.workspace.AstNodeLocator, this.nameProvider = e.references.NameProvider, this.commentProvider = e.documentation.CommentProvider;
  }
  serialize(e, n) {
    const r = n ?? {}, i = n?.replacer, s = (o, c) => this.replacer(o, c, r), a = i ? (o, c) => i(o, c, s) : s;
    try {
      return this.currentDocument = Qt(e), JSON.stringify(e, a, n?.space);
    } finally {
      this.currentDocument = void 0;
    }
  }
  deserialize(e, n) {
    const r = n ?? {}, i = JSON.parse(e);
    return this.linkNode(i, i, r), i;
  }
  replacer(e, n, { refText: r, sourceText: i, textRegions: s, comments: a, uriConverter: o }) {
    if (!this.ignoreProperties.has(e))
      if (St(n)) {
        const c = n.ref, l = r ? n.$refText : void 0;
        if (c) {
          const u = Qt(c);
          let f = "";
          this.currentDocument && this.currentDocument !== u && (o ? f = o(u.uri, c) : f = u.uri.toString());
          const m = this.astNodeLocator.getAstNodePath(c);
          return {
            $ref: `${f}#${m}`,
            $refText: l
          };
        } else
          return {
            $error: n.error?.message ?? "Could not resolve reference",
            $refText: l
          };
      } else if (un(n)) {
        const c = r ? n.$refText : void 0, l = [];
        for (const u of n.items) {
          const f = u.ref, m = Qt(u.ref);
          let p = "";
          this.currentDocument && this.currentDocument !== m && (o ? p = o(m.uri, f) : p = m.uri.toString());
          const A = this.astNodeLocator.getAstNodePath(f);
          l.push(`${p}#${A}`);
        }
        return {
          $refs: l,
          $refText: c
        };
      } else if (We(n)) {
        let c;
        if (s && (c = this.addAstNodeRegionWithAssignmentsTo({ ...n }), (!e || n.$document) && c?.$textRegion && (c.$textRegion.documentURI = this.currentDocument?.uri.toString())), i && !e && (c ?? (c = { ...n }), c.$sourceText = n.$cstNode?.text), a) {
          c ?? (c = { ...n });
          const l = this.commentProvider.getComment(n);
          l && (c.$comment = l.replace(/\r/g, ""));
        }
        return c ?? n;
      } else
        return n;
  }
  addAstNodeRegionWithAssignmentsTo(e) {
    const n = (r) => ({
      offset: r.offset,
      end: r.end,
      length: r.length,
      range: r.range
    });
    if (e.$cstNode) {
      const r = e.$textRegion = n(e.$cstNode), i = r.assignments = {};
      return Object.keys(e).filter((s) => !s.startsWith("$")).forEach((s) => {
        const a = om(e.$cstNode, s).map(n);
        a.length !== 0 && (i[s] = a);
      }), e;
    }
  }
  linkNode(e, n, r, i, s, a) {
    for (const [c, l] of Object.entries(e))
      if (Array.isArray(l))
        for (let u = 0; u < l.length; u++) {
          const f = l[u];
          ku(f) ? l[u] = this.reviveReference(e, c, n, f, r) : We(f) && this.linkNode(f, n, r, e, c, u);
        }
      else ku(l) ? e[c] = this.reviveReference(e, c, n, l, r) : We(l) && this.linkNode(l, n, r, e, c);
    const o = e;
    o.$container = i, o.$containerProperty = s, o.$containerIndex = a;
  }
  reviveReference(e, n, r, i, s) {
    let a = i.$refText, o = i.$error, c;
    if (i.$ref) {
      const l = this.getRefNode(r, i.$ref, s.uriConverter);
      if (We(l))
        return a || (a = this.nameProvider.getName(l)), {
          $refText: a ?? "",
          ref: l
        };
      o = l;
    } else if (i.$refs) {
      const l = [];
      for (const u of i.$refs) {
        const f = this.getRefNode(r, u, s.uriConverter);
        We(f) && l.push({ ref: f });
      }
      if (l.length === 0)
        c = {
          $refText: a ?? "",
          items: l
        }, o ?? (o = "Could not resolve multi-reference");
      else
        return {
          $refText: a ?? "",
          items: l
        };
    }
    if (o)
      return c ?? (c = {
        $refText: a ?? "",
        ref: void 0
      }), c.error = {
        info: {
          container: e,
          property: n,
          reference: c
        },
        message: o
      }, c;
  }
  getRefNode(e, n, r) {
    try {
      const i = n.indexOf("#");
      if (i === 0) {
        const c = this.astNodeLocator.getAstNode(e, n.substring(1));
        return c || "Could not resolve path: " + n;
      }
      if (i < 0) {
        const c = r ? r(n) : Ct.parse(n), l = this.langiumDocuments.getDocument(c);
        return l ? l.parseResult.value : "Could not find document for URI: " + n;
      }
      const s = r ? r(n.substring(0, i)) : Ct.parse(n.substring(0, i)), a = this.langiumDocuments.getDocument(s);
      if (!a)
        return "Could not find document for URI: " + n;
      if (i === n.length - 1)
        return a.parseResult.value;
      const o = this.astNodeLocator.getAstNode(a.parseResult.value, n.substring(i + 1));
      return o || "Could not resolve URI: " + n;
    } catch (i) {
      return String(i);
    }
  }
}
class JT {
  /**
   * @deprecated Since 3.1.0. Use the new `fileExtensionMap` (or `languageIdMap`) property instead.
   */
  get map() {
    return this.fileExtensionMap;
  }
  constructor(e) {
    this.languageIdMap = /* @__PURE__ */ new Map(), this.fileExtensionMap = /* @__PURE__ */ new Map(), this.fileNameMap = /* @__PURE__ */ new Map(), this.textDocuments = e?.workspace.TextDocuments;
  }
  register(e) {
    const n = e.LanguageMetaData;
    for (const r of n.fileExtensions)
      this.fileExtensionMap.has(r) && console.warn(`The file extension ${r} is used by multiple languages. It is now assigned to '${n.languageId}'.`), this.fileExtensionMap.set(r, e);
    if (n.fileNames)
      for (const r of n.fileNames)
        this.fileNameMap.has(r) && console.warn(`The file name ${r} is used by multiple languages. It is now assigned to '${n.languageId}'.`), this.fileNameMap.set(r, e);
    this.languageIdMap.set(n.languageId, e);
  }
  getServices(e) {
    if (this.languageIdMap.size === 0)
      throw new Error("The service registry is empty. Use `register` to register the services of a language.");
    const n = this.textDocuments?.get(e)?.languageId;
    if (n !== void 0) {
      const a = this.languageIdMap.get(n);
      if (a)
        return a;
    }
    const r = ut.extname(e), i = ut.basename(e), s = this.fileNameMap.get(i) ?? this.fileExtensionMap.get(r);
    if (!s)
      throw n ? new Error(`The service registry contains no services for the extension '${r}' for language '${n}'.`) : new Error(`The service registry contains no services for the extension '${r}'.`);
    return s;
  }
  hasServices(e) {
    try {
      return this.getServices(e), !0;
    } catch {
      return !1;
    }
  }
  get all() {
    return Array.from(this.languageIdMap.values());
  }
}
function Gi(t) {
  return { code: t };
}
var zc;
(function(t) {
  t.defaults = ["fast", "slow", "built-in"], t.all = t.defaults;
})(zc || (zc = {}));
class QT {
  constructor(e) {
    this.entries = new Zi(), this.knownCategories = new Set(zc.defaults), this.entriesBefore = [], this.entriesAfter = [], this.reflection = e.shared.AstReflection;
  }
  /**
   * Register a set of validation checks. Each value in the record can be either a single validation check (i.e. a function)
   * or an array of validation checks.
   *
   * @param checksRecord Set of validation checks to register.
   * @param thisObj Optional object to be used as `this` when calling the validation check functions.
   * @param category Optional category for the validation checks (defaults to `'fast'`).
   */
  register(e, n = this, r = "fast") {
    if (r === "built-in")
      throw new Error("The 'built-in' category is reserved for lexer, parser, and linker errors.");
    this.knownCategories.add(r);
    for (const [i, s] of Object.entries(e)) {
      const a = s;
      if (Array.isArray(a))
        for (const o of a) {
          const c = {
            check: this.wrapValidationException(o, n),
            category: r
          };
          this.addEntry(i, c);
        }
      else if (typeof a == "function") {
        const o = {
          check: this.wrapValidationException(a, n),
          category: r
        };
        this.addEntry(i, o);
      } else
        is();
    }
  }
  wrapValidationException(e, n) {
    return async (r, i, s) => {
      await this.handleException(() => e.call(n, r, i, s), "An error occurred during validation", i, r);
    };
  }
  async handleException(e, n, r, i) {
    try {
      await e();
    } catch (s) {
      if (za(s))
        throw s;
      console.error(`${n}:`, s), s instanceof Error && s.stack && console.error(s.stack);
      const a = s instanceof Error ? s.message : String(s);
      r("error", `${n}: ${a}`, { node: i });
    }
  }
  addEntry(e, n) {
    if (e === "AstNode") {
      this.entries.add("AstNode", n);
      return;
    }
    for (const r of this.reflection.getAllSubTypes(e))
      this.entries.add(r, n);
  }
  getChecks(e, n) {
    let r = me(this.entries.get(e)).concat(this.entries.get("AstNode"));
    return n && (r = r.filter((i) => n.includes(i.category))), r.map((i) => i.check);
  }
  /**
   * Register logic which will be executed once before validating all the nodes of an AST/Langium document.
   * This helps to prepare or initialize some information which are required or reusable for the following checks on the AstNodes.
   *
   * As an example, for validating unique fully-qualified names of nodes in the AST,
   * here the map for mapping names to nodes could be established.
   * During the usual checks on the nodes, they are put into this map with their name.
   *
   * Note that this approach makes validations stateful, which is relevant e.g. when cancelling the validation.
   * Therefore it is recommended to clear stored information
   * _before_ validating an AST to validate each AST unaffected from other ASTs
   * AND _after_ validating the AST to free memory by information which are no longer used.
   *
   * @param checkBefore a set-up function which will be called once before actually validating an AST
   * @param thisObj Optional object to be used as `this` when calling the validation check functions.
   */
  registerBeforeDocument(e, n = this) {
    this.entriesBefore.push(this.wrapPreparationException(e, "An error occurred during set-up of the validation", n));
  }
  /**
   * Register logic which will be executed once after validating all the nodes of an AST/Langium document.
   * This helps to finally evaluate information which are collected during the checks on the AstNodes.
   *
   * As an example, for validating unique fully-qualified names of nodes in the AST,
   * here the map with all the collected nodes and their names is checked
   * and validation hints are created for all nodes with the same name.
   *
   * Note that this approach makes validations stateful, which is relevant e.g. when cancelling the validation.
   * Therefore it is recommended to clear stored information
   * _before_ validating an AST to validate each AST unaffected from other ASTs
   * AND _after_ validating the AST to free memory by information which are no longer used.
   *
   * @param checkBefore a set-up function which will be called once before actually validating an AST
   * @param thisObj Optional object to be used as `this` when calling the validation check functions.
   */
  registerAfterDocument(e, n = this) {
    this.entriesAfter.push(this.wrapPreparationException(e, "An error occurred during tear-down of the validation", n));
  }
  wrapPreparationException(e, n, r) {
    return async (i, s, a, o) => {
      await this.handleException(() => e.call(r, i, s, a, o), n, s, i);
    };
  }
  get checksBefore() {
    return this.entriesBefore;
  }
  get checksAfter() {
    return this.entriesAfter;
  }
  getAllValidationCategories(e) {
    return this.knownCategories;
  }
}
const ZT = Object.freeze({
  validateNode: !0,
  validateChildren: !0
});
class eR {
  constructor(e) {
    this.validationRegistry = e.validation.ValidationRegistry, this.metadata = e.LanguageMetaData, this.profiler = e.shared.profilers.LangiumProfiler, this.languageId = e.LanguageMetaData.languageId;
  }
  async validateDocument(e, n = {}, r = ye.CancellationToken.None) {
    const i = e.parseResult, s = [];
    if (await Xe(r), (!n.categories || n.categories.includes("built-in")) && (this.processLexingErrors(i, s, n), n.stopAfterLexingErrors && s.some((a) => a.data?.code === At.LexingError) || (this.processParsingErrors(i, s, n), n.stopAfterParsingErrors && s.some((a) => a.data?.code === At.ParsingError)) || (this.processLinkingErrors(e, s, n), n.stopAfterLinkingErrors && s.some((a) => a.data?.code === At.LinkingError))))
      return s;
    try {
      s.push(...await this.validateAst(i.value, n, r));
    } catch (a) {
      if (za(a))
        throw a;
      console.error("An error occurred during validation:", a);
    }
    return await Xe(r), s;
  }
  processLexingErrors(e, n, r) {
    const i = [...e.lexerErrors, ...e.lexerReport?.diagnostics ?? []];
    for (const s of i) {
      const a = s.severity ?? "error", o = {
        severity: ro(a),
        range: {
          start: {
            line: s.line - 1,
            character: s.column - 1
          },
          end: {
            line: s.line - 1,
            character: s.column + s.length - 1
          }
        },
        message: s.message,
        data: nR(a),
        source: this.getSource()
      };
      n.push(o);
    }
  }
  processParsingErrors(e, n, r) {
    for (const i of e.parserErrors) {
      let s;
      if (isNaN(i.token.startOffset)) {
        if ("previousToken" in i) {
          const a = i.previousToken;
          if (isNaN(a.startOffset)) {
            const o = { line: 0, character: 0 };
            s = { start: o, end: o };
          } else {
            const o = { line: a.endLine - 1, character: a.endColumn };
            s = { start: o, end: o };
          }
        }
      } else
        s = No(i.token);
      if (s) {
        const a = {
          severity: ro("error"),
          range: s,
          message: i.message,
          data: Gi(At.ParsingError),
          source: this.getSource()
        };
        n.push(a);
      }
    }
  }
  processLinkingErrors(e, n, r) {
    for (const i of e.references) {
      const s = i.error;
      if (s) {
        const a = {
          node: s.info.container,
          range: i.$refNode?.range,
          property: s.info.property,
          index: s.info.index,
          data: {
            code: At.LinkingError,
            containerType: s.info.container.$type,
            property: s.info.property,
            refText: s.info.reference.$refText
          }
        };
        n.push(this.toDiagnostic("error", s.message, a));
      }
    }
  }
  async validateAst(e, n, r = ye.CancellationToken.None) {
    const i = [], s = (a, o, c) => {
      i.push(this.toDiagnostic(a, o, c));
    };
    return await this.validateAstBefore(e, n, s, r), await this.validateAstNodes(e, n, s, r), await this.validateAstAfter(e, n, s, r), i;
  }
  async validateAstBefore(e, n, r, i = ye.CancellationToken.None) {
    const s = this.validationRegistry.checksBefore;
    for (const a of s)
      await Xe(i), await a(e, r, n.categories ?? [], i);
  }
  async validateAstNodes(e, n, r, i = ye.CancellationToken.None) {
    if (this.profiler?.isActive("validating")) {
      const s = this.profiler.createTask("validating", this.languageId);
      s.start();
      try {
        const a = Zt(e).iterator();
        for (const o of a) {
          s.startSubTask(o.$type);
          const c = this.validateSingleNodeOptions(o, n);
          if (c.validateNode)
            try {
              const l = this.validationRegistry.getChecks(o.$type, n.categories);
              for (const u of l)
                await u(o, r, i);
            } finally {
              s.stopSubTask(o.$type);
            }
          c.validateChildren || a.prune();
        }
      } finally {
        s.stop();
      }
    } else {
      const s = Zt(e).iterator();
      for (const a of s) {
        await Xe(i);
        const o = this.validateSingleNodeOptions(a, n);
        if (o.validateNode) {
          const c = this.validationRegistry.getChecks(a.$type, n.categories);
          for (const l of c)
            await l(a, r, i);
        }
        o.validateChildren || s.prune();
      }
    }
  }
  validateSingleNodeOptions(e, n) {
    return ZT;
  }
  async validateAstAfter(e, n, r, i = ye.CancellationToken.None) {
    const s = this.validationRegistry.checksAfter;
    for (const a of s)
      await Xe(i), await a(e, r, n.categories ?? [], i);
  }
  toDiagnostic(e, n, r) {
    return {
      message: n,
      range: tR(r),
      severity: ro(e),
      code: r.code,
      codeDescription: r.codeDescription,
      tags: r.tags,
      relatedInformation: r.relatedInformation,
      data: r.data,
      source: this.getSource()
    };
  }
  getSource() {
    return this.metadata.languageId;
  }
}
function tR(t) {
  if (t.range)
    return t.range;
  let e;
  return typeof t.property == "string" ? e = Yd(t.node.$cstNode, t.property, t.index) : typeof t.keyword == "string" && (e = cm(t.node.$cstNode, t.keyword, t.index)), e ?? (e = t.node.$cstNode), e ? e.range : {
    start: { line: 0, character: 0 },
    end: { line: 0, character: 0 }
  };
}
function ro(t) {
  switch (t) {
    case "error":
      return 1;
    case "warning":
      return 2;
    case "info":
      return 3;
    case "hint":
      return 4;
    default:
      throw new Error("Invalid diagnostic severity: " + t);
  }
}
function nR(t) {
  switch (t) {
    case "error":
      return Gi(At.LexingError);
    case "warning":
      return Gi(At.LexingWarning);
    case "info":
      return Gi(At.LexingInfo);
    case "hint":
      return Gi(At.LexingHint);
    default:
      throw new Error("Invalid diagnostic severity: " + t);
  }
}
var At;
(function(t) {
  t.LexingError = "lexing-error", t.LexingWarning = "lexing-warning", t.LexingInfo = "lexing-info", t.LexingHint = "lexing-hint", t.ParsingError = "parsing-error", t.LinkingError = "linking-error";
})(At || (At = {}));
class rR {
  constructor(e) {
    this.astNodeLocator = e.workspace.AstNodeLocator, this.nameProvider = e.references.NameProvider;
  }
  createDescription(e, n, r) {
    const i = r ?? Qt(e);
    n ?? (n = this.nameProvider.getName(e));
    const s = this.astNodeLocator.getAstNodePath(e);
    if (!n)
      throw new Error(`Node at path ${s} has no name.`);
    let a;
    const o = () => a ?? (a = ca(this.nameProvider.getNameNode(e) ?? e.$cstNode));
    return {
      node: e,
      name: n,
      get nameSegment() {
        return o();
      },
      selectionSegment: ca(e.$cstNode),
      type: e.$type,
      documentUri: i.uri,
      path: s
    };
  }
}
class iR {
  constructor(e) {
    this.nodeLocator = e.workspace.AstNodeLocator;
  }
  async createDescriptions(e, n = ye.CancellationToken.None) {
    const r = [], i = e.parseResult.value;
    for (const s of Zt(i))
      await Xe(n), aa(s).forEach((a) => {
        a.reference.error || r.push(...this.createInfoDescriptions(a));
      });
    return r;
  }
  createInfoDescriptions(e) {
    const n = e.reference;
    if (n.error || !n.$refNode)
      return [];
    let r = [];
    St(n) && n.$nodeDescription ? r = [n.$nodeDescription] : un(n) && (r = n.items.map((c) => c.$nodeDescription).filter((c) => c !== void 0));
    const i = Qt(e.container).uri, s = this.nodeLocator.getAstNodePath(e.container), a = [], o = ca(n.$refNode);
    for (const c of r)
      a.push({
        sourceUri: i,
        sourcePath: s,
        targetUri: c.documentUri,
        targetPath: c.path,
        segment: o,
        local: ut.equals(c.documentUri, i)
      });
    return a;
  }
}
class sR {
  constructor() {
    this.segmentSeparator = "/", this.indexSeparator = "@";
  }
  getAstNodePath(e) {
    if (e.$container) {
      const n = this.getAstNodePath(e.$container), r = this.getPathSegment(e);
      return n + this.segmentSeparator + r;
    }
    return "";
  }
  getPathSegment({ $containerProperty: e, $containerIndex: n }) {
    if (!e)
      throw new Error("Missing '$containerProperty' in AST node.");
    return n !== void 0 ? e + this.indexSeparator + n : e;
  }
  getAstNode(e, n) {
    return n.split(this.segmentSeparator).reduce((i, s) => {
      if (!i || s.length === 0)
        return i;
      const a = s.indexOf(this.indexSeparator);
      if (a > 0) {
        const o = s.substring(0, a), c = parseInt(s.substring(a + 1));
        return i[o]?.[c];
      }
      return i[s];
    }, e);
  }
}
var aR = Qr();
class oR {
  constructor(e) {
    this._ready = new Sl(), this.onConfigurationSectionUpdateEmitter = new aR.Emitter(), this.settings = {}, this.workspaceConfig = !1, this.serviceRegistry = e.ServiceRegistry;
  }
  get ready() {
    return this._ready.promise;
  }
  initialize(e) {
    this.workspaceConfig = e.capabilities.workspace?.configuration ?? !1;
  }
  async initialized(e) {
    if (this.workspaceConfig) {
      if (e.register) {
        const n = this.serviceRegistry.all;
        e.register({
          // Listen to configuration changes for all languages
          section: n.map((r) => this.toSectionName(r.LanguageMetaData.languageId))
        });
      }
      if (e.fetchConfiguration) {
        const n = this.serviceRegistry.all.map((i) => ({
          // Fetch the configuration changes for all languages
          section: this.toSectionName(i.LanguageMetaData.languageId)
        })), r = await e.fetchConfiguration(n);
        n.forEach((i, s) => {
          this.updateSectionConfiguration(i.section, r[s]);
        });
      }
    }
    this._ready.resolve();
  }
  /**
   *  Updates the cached configurations using the `change` notification parameters.
   *
   * @param change The parameters of a change configuration notification.
   * `settings` property of the change object could be expressed as `Record<string, Record<string, any>>`
   */
  updateConfiguration(e) {
    typeof e.settings != "object" || e.settings === null || Object.entries(e.settings).forEach(([n, r]) => {
      this.updateSectionConfiguration(n, r), this.onConfigurationSectionUpdateEmitter.fire({ section: n, configuration: r });
    });
  }
  updateSectionConfiguration(e, n) {
    this.settings[e] = n;
  }
  /**
  * Returns a configuration value stored for the given language.
  *
  * @param language The language id
  * @param configuration Configuration name
  */
  async getConfiguration(e, n) {
    await this.ready;
    const r = this.toSectionName(e);
    if (this.settings[r])
      return this.settings[r][n];
  }
  toSectionName(e) {
    return `${e}`;
  }
  get onConfigurationSectionUpdate() {
    return this.onConfigurationSectionUpdateEmitter.event;
  }
}
var kn = {}, Cn = {}, Fs = {}, io = {}, U = {}, Cu;
function ah() {
  if (Cu) return U;
  Cu = 1, Object.defineProperty(U, "__esModule", { value: !0 }), U.Message = U.NotificationType9 = U.NotificationType8 = U.NotificationType7 = U.NotificationType6 = U.NotificationType5 = U.NotificationType4 = U.NotificationType3 = U.NotificationType2 = U.NotificationType1 = U.NotificationType0 = U.NotificationType = U.RequestType9 = U.RequestType8 = U.RequestType7 = U.RequestType6 = U.RequestType5 = U.RequestType4 = U.RequestType3 = U.RequestType2 = U.RequestType1 = U.RequestType = U.RequestType0 = U.AbstractMessageSignature = U.ParameterStructures = U.ResponseError = U.ErrorCodes = void 0;
  const t = us();
  var e;
  (function(T) {
    T.ParseError = -32700, T.InvalidRequest = -32600, T.MethodNotFound = -32601, T.InvalidParams = -32602, T.InternalError = -32603, T.jsonrpcReservedErrorRangeStart = -32099, T.serverErrorStart = -32099, T.MessageWriteError = -32099, T.MessageReadError = -32098, T.PendingResponseRejected = -32097, T.ConnectionInactive = -32096, T.ServerNotInitialized = -32002, T.UnknownErrorCode = -32001, T.jsonrpcReservedErrorRangeEnd = -32e3, T.serverErrorEnd = -32e3;
  })(e || (U.ErrorCodes = e = {}));
  class n extends Error {
    constructor(g, S, y) {
      super(S), this.code = t.number(g) ? g : e.UnknownErrorCode, this.data = y, Object.setPrototypeOf(this, n.prototype);
    }
    toJson() {
      const g = {
        code: this.code,
        message: this.message
      };
      return this.data !== void 0 && (g.data = this.data), g;
    }
  }
  U.ResponseError = n;
  class r {
    constructor(g) {
      this.kind = g;
    }
    static is(g) {
      return g === r.auto || g === r.byName || g === r.byPosition;
    }
    toString() {
      return this.kind;
    }
  }
  U.ParameterStructures = r, r.auto = new r("auto"), r.byPosition = new r("byPosition"), r.byName = new r("byName");
  class i {
    constructor(g, S) {
      this.method = g, this.numberOfParams = S;
    }
    get parameterStructures() {
      return r.auto;
    }
  }
  U.AbstractMessageSignature = i;
  class s extends i {
    constructor(g) {
      super(g, 0);
    }
  }
  U.RequestType0 = s;
  class a extends i {
    constructor(g, S = r.auto) {
      super(g, 1), this._parameterStructures = S;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  U.RequestType = a;
  class o extends i {
    constructor(g, S = r.auto) {
      super(g, 1), this._parameterStructures = S;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  U.RequestType1 = o;
  class c extends i {
    constructor(g) {
      super(g, 2);
    }
  }
  U.RequestType2 = c;
  class l extends i {
    constructor(g) {
      super(g, 3);
    }
  }
  U.RequestType3 = l;
  class u extends i {
    constructor(g) {
      super(g, 4);
    }
  }
  U.RequestType4 = u;
  class f extends i {
    constructor(g) {
      super(g, 5);
    }
  }
  U.RequestType5 = f;
  class m extends i {
    constructor(g) {
      super(g, 6);
    }
  }
  U.RequestType6 = m;
  class p extends i {
    constructor(g) {
      super(g, 7);
    }
  }
  U.RequestType7 = p;
  class A extends i {
    constructor(g) {
      super(g, 8);
    }
  }
  U.RequestType8 = A;
  class b extends i {
    constructor(g) {
      super(g, 9);
    }
  }
  U.RequestType9 = b;
  class I extends i {
    constructor(g, S = r.auto) {
      super(g, 1), this._parameterStructures = S;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  U.NotificationType = I;
  class C extends i {
    constructor(g) {
      super(g, 0);
    }
  }
  U.NotificationType0 = C;
  class N extends i {
    constructor(g, S = r.auto) {
      super(g, 1), this._parameterStructures = S;
    }
    get parameterStructures() {
      return this._parameterStructures;
    }
  }
  U.NotificationType1 = N;
  class k extends i {
    constructor(g) {
      super(g, 2);
    }
  }
  U.NotificationType2 = k;
  class P extends i {
    constructor(g) {
      super(g, 3);
    }
  }
  U.NotificationType3 = P;
  class H extends i {
    constructor(g) {
      super(g, 4);
    }
  }
  U.NotificationType4 = H;
  class K extends i {
    constructor(g) {
      super(g, 5);
    }
  }
  U.NotificationType5 = K;
  class J extends i {
    constructor(g) {
      super(g, 6);
    }
  }
  U.NotificationType6 = J;
  class oe extends i {
    constructor(g) {
      super(g, 7);
    }
  }
  U.NotificationType7 = oe;
  class ue extends i {
    constructor(g) {
      super(g, 8);
    }
  }
  U.NotificationType8 = ue;
  class de extends i {
    constructor(g) {
      super(g, 9);
    }
  }
  U.NotificationType9 = de;
  var _;
  return (function(T) {
    function g(R) {
      const E = R;
      return E && t.string(E.method) && (t.string(E.id) || t.number(E.id));
    }
    T.isRequest = g;
    function S(R) {
      const E = R;
      return E && t.string(E.method) && R.id === void 0;
    }
    T.isNotification = S;
    function y(R) {
      const E = R;
      return E && (E.result !== void 0 || !!E.error) && (t.string(E.id) || t.number(E.id) || E.id === null);
    }
    T.isResponse = y;
  })(_ || (U.Message = _ = {})), U;
}
var Ft = {}, Nu;
function oh() {
  if (Nu) return Ft;
  Nu = 1;
  var t;
  Object.defineProperty(Ft, "__esModule", { value: !0 }), Ft.LRUCache = Ft.LinkedMap = Ft.Touch = void 0;
  var e;
  (function(i) {
    i.None = 0, i.First = 1, i.AsOld = i.First, i.Last = 2, i.AsNew = i.Last;
  })(e || (Ft.Touch = e = {}));
  class n {
    constructor() {
      this[t] = "LinkedMap", this._map = /* @__PURE__ */ new Map(), this._head = void 0, this._tail = void 0, this._size = 0, this._state = 0;
    }
    clear() {
      this._map.clear(), this._head = void 0, this._tail = void 0, this._size = 0, this._state++;
    }
    isEmpty() {
      return !this._head && !this._tail;
    }
    get size() {
      return this._size;
    }
    get first() {
      return this._head?.value;
    }
    get last() {
      return this._tail?.value;
    }
    has(s) {
      return this._map.has(s);
    }
    get(s, a = e.None) {
      const o = this._map.get(s);
      if (o)
        return a !== e.None && this.touch(o, a), o.value;
    }
    set(s, a, o = e.None) {
      let c = this._map.get(s);
      if (c)
        c.value = a, o !== e.None && this.touch(c, o);
      else {
        switch (c = { key: s, value: a, next: void 0, previous: void 0 }, o) {
          case e.None:
            this.addItemLast(c);
            break;
          case e.First:
            this.addItemFirst(c);
            break;
          case e.Last:
            this.addItemLast(c);
            break;
          default:
            this.addItemLast(c);
            break;
        }
        this._map.set(s, c), this._size++;
      }
      return this;
    }
    delete(s) {
      return !!this.remove(s);
    }
    remove(s) {
      const a = this._map.get(s);
      if (a)
        return this._map.delete(s), this.removeItem(a), this._size--, a.value;
    }
    shift() {
      if (!this._head && !this._tail)
        return;
      if (!this._head || !this._tail)
        throw new Error("Invalid list");
      const s = this._head;
      return this._map.delete(s.key), this.removeItem(s), this._size--, s.value;
    }
    forEach(s, a) {
      const o = this._state;
      let c = this._head;
      for (; c; ) {
        if (a ? s.bind(a)(c.value, c.key, this) : s(c.value, c.key, this), this._state !== o)
          throw new Error("LinkedMap got modified during iteration.");
        c = c.next;
      }
    }
    keys() {
      const s = this._state;
      let a = this._head;
      const o = {
        [Symbol.iterator]: () => o,
        next: () => {
          if (this._state !== s)
            throw new Error("LinkedMap got modified during iteration.");
          if (a) {
            const c = { value: a.key, done: !1 };
            return a = a.next, c;
          } else
            return { value: void 0, done: !0 };
        }
      };
      return o;
    }
    values() {
      const s = this._state;
      let a = this._head;
      const o = {
        [Symbol.iterator]: () => o,
        next: () => {
          if (this._state !== s)
            throw new Error("LinkedMap got modified during iteration.");
          if (a) {
            const c = { value: a.value, done: !1 };
            return a = a.next, c;
          } else
            return { value: void 0, done: !0 };
        }
      };
      return o;
    }
    entries() {
      const s = this._state;
      let a = this._head;
      const o = {
        [Symbol.iterator]: () => o,
        next: () => {
          if (this._state !== s)
            throw new Error("LinkedMap got modified during iteration.");
          if (a) {
            const c = { value: [a.key, a.value], done: !1 };
            return a = a.next, c;
          } else
            return { value: void 0, done: !0 };
        }
      };
      return o;
    }
    [(t = Symbol.toStringTag, Symbol.iterator)]() {
      return this.entries();
    }
    trimOld(s) {
      if (s >= this.size)
        return;
      if (s === 0) {
        this.clear();
        return;
      }
      let a = this._head, o = this.size;
      for (; a && o > s; )
        this._map.delete(a.key), a = a.next, o--;
      this._head = a, this._size = o, a && (a.previous = void 0), this._state++;
    }
    addItemFirst(s) {
      if (!this._head && !this._tail)
        this._tail = s;
      else if (this._head)
        s.next = this._head, this._head.previous = s;
      else
        throw new Error("Invalid list");
      this._head = s, this._state++;
    }
    addItemLast(s) {
      if (!this._head && !this._tail)
        this._head = s;
      else if (this._tail)
        s.previous = this._tail, this._tail.next = s;
      else
        throw new Error("Invalid list");
      this._tail = s, this._state++;
    }
    removeItem(s) {
      if (s === this._head && s === this._tail)
        this._head = void 0, this._tail = void 0;
      else if (s === this._head) {
        if (!s.next)
          throw new Error("Invalid list");
        s.next.previous = void 0, this._head = s.next;
      } else if (s === this._tail) {
        if (!s.previous)
          throw new Error("Invalid list");
        s.previous.next = void 0, this._tail = s.previous;
      } else {
        const a = s.next, o = s.previous;
        if (!a || !o)
          throw new Error("Invalid list");
        a.previous = o, o.next = a;
      }
      s.next = void 0, s.previous = void 0, this._state++;
    }
    touch(s, a) {
      if (!this._head || !this._tail)
        throw new Error("Invalid list");
      if (!(a !== e.First && a !== e.Last)) {
        if (a === e.First) {
          if (s === this._head)
            return;
          const o = s.next, c = s.previous;
          s === this._tail ? (c.next = void 0, this._tail = c) : (o.previous = c, c.next = o), s.previous = void 0, s.next = this._head, this._head.previous = s, this._head = s, this._state++;
        } else if (a === e.Last) {
          if (s === this._tail)
            return;
          const o = s.next, c = s.previous;
          s === this._head ? (o.previous = void 0, this._head = o) : (o.previous = c, c.next = o), s.next = void 0, s.previous = this._tail, this._tail.next = s, this._tail = s, this._state++;
        }
      }
    }
    toJSON() {
      const s = [];
      return this.forEach((a, o) => {
        s.push([o, a]);
      }), s;
    }
    fromJSON(s) {
      this.clear();
      for (const [a, o] of s)
        this.set(a, o);
    }
  }
  Ft.LinkedMap = n;
  class r extends n {
    constructor(s, a = 1) {
      super(), this._limit = s, this._ratio = Math.min(Math.max(0, a), 1);
    }
    get limit() {
      return this._limit;
    }
    set limit(s) {
      this._limit = s, this.checkTrim();
    }
    get ratio() {
      return this._ratio;
    }
    set ratio(s) {
      this._ratio = Math.min(Math.max(0, s), 1), this.checkTrim();
    }
    get(s, a = e.AsNew) {
      return super.get(s, a);
    }
    peek(s) {
      return super.get(s, e.None);
    }
    set(s, a) {
      return super.set(s, a, e.Last), this.checkTrim(), this;
    }
    checkTrim() {
      this.size > this._limit && this.trimOld(Math.round(this._limit * this._ratio));
    }
  }
  return Ft.LRUCache = r, Ft;
}
var Ti = {}, wu;
function cR() {
  if (wu) return Ti;
  wu = 1, Object.defineProperty(Ti, "__esModule", { value: !0 }), Ti.Disposable = void 0;
  var t;
  return (function(e) {
    function n(r) {
      return {
        dispose: r
      };
    }
    e.create = n;
  })(t || (Ti.Disposable = t = {})), Ti;
}
var Nn = {}, bu;
function lR() {
  if (bu) return Nn;
  bu = 1, Object.defineProperty(Nn, "__esModule", { value: !0 }), Nn.SharedArrayReceiverStrategy = Nn.SharedArraySenderStrategy = void 0;
  const t = ja();
  var e;
  (function(a) {
    a.Continue = 0, a.Cancelled = 1;
  })(e || (e = {}));
  class n {
    constructor() {
      this.buffers = /* @__PURE__ */ new Map();
    }
    enableCancellation(o) {
      if (o.id === null)
        return;
      const c = new SharedArrayBuffer(4), l = new Int32Array(c, 0, 1);
      l[0] = e.Continue, this.buffers.set(o.id, c), o.$cancellationData = c;
    }
    async sendCancellation(o, c) {
      const l = this.buffers.get(c);
      if (l === void 0)
        return;
      const u = new Int32Array(l, 0, 1);
      Atomics.store(u, 0, e.Cancelled);
    }
    cleanup(o) {
      this.buffers.delete(o);
    }
    dispose() {
      this.buffers.clear();
    }
  }
  Nn.SharedArraySenderStrategy = n;
  class r {
    constructor(o) {
      this.data = new Int32Array(o, 0, 1);
    }
    get isCancellationRequested() {
      return Atomics.load(this.data, 0) === e.Cancelled;
    }
    get onCancellationRequested() {
      throw new Error("Cancellation over SharedArrayBuffer doesn't support cancellation events");
    }
  }
  class i {
    constructor(o) {
      this.token = new r(o);
    }
    cancel() {
    }
    dispose() {
    }
  }
  class s {
    constructor() {
      this.kind = "request";
    }
    createCancellationTokenSource(o) {
      const c = o.$cancellationData;
      return c === void 0 ? new t.CancellationTokenSource() : new i(c);
    }
  }
  return Nn.SharedArrayReceiverStrategy = s, Nn;
}
var Gt = {}, Ri = {}, _u;
function ch() {
  if (_u) return Ri;
  _u = 1, Object.defineProperty(Ri, "__esModule", { value: !0 }), Ri.Semaphore = void 0;
  const t = Xn();
  class e {
    constructor(r = 1) {
      if (r <= 0)
        throw new Error("Capacity must be greater than 0");
      this._capacity = r, this._active = 0, this._waiting = [];
    }
    lock(r) {
      return new Promise((i, s) => {
        this._waiting.push({ thunk: r, resolve: i, reject: s }), this.runNext();
      });
    }
    get active() {
      return this._active;
    }
    runNext() {
      this._waiting.length === 0 || this._active === this._capacity || (0, t.default)().timer.setImmediate(() => this.doRunNext());
    }
    doRunNext() {
      if (this._waiting.length === 0 || this._active === this._capacity)
        return;
      const r = this._waiting.shift();
      if (this._active++, this._active > this._capacity)
        throw new Error("To many thunks active");
      try {
        const i = r.thunk();
        i instanceof Promise ? i.then((s) => {
          this._active--, r.resolve(s), this.runNext();
        }, (s) => {
          this._active--, r.reject(s), this.runNext();
        }) : (this._active--, r.resolve(i), this.runNext());
      } catch (i) {
        this._active--, r.reject(i), this.runNext();
      }
    }
  }
  return Ri.Semaphore = e, Ri;
}
var Iu;
function uR() {
  if (Iu) return Gt;
  Iu = 1, Object.defineProperty(Gt, "__esModule", { value: !0 }), Gt.ReadableStreamMessageReader = Gt.AbstractMessageReader = Gt.MessageReader = void 0;
  const t = Xn(), e = us(), n = Qr(), r = ch();
  var i;
  (function(c) {
    function l(u) {
      let f = u;
      return f && e.func(f.listen) && e.func(f.dispose) && e.func(f.onError) && e.func(f.onClose) && e.func(f.onPartialMessage);
    }
    c.is = l;
  })(i || (Gt.MessageReader = i = {}));
  class s {
    constructor() {
      this.errorEmitter = new n.Emitter(), this.closeEmitter = new n.Emitter(), this.partialMessageEmitter = new n.Emitter();
    }
    dispose() {
      this.errorEmitter.dispose(), this.closeEmitter.dispose();
    }
    get onError() {
      return this.errorEmitter.event;
    }
    fireError(l) {
      this.errorEmitter.fire(this.asError(l));
    }
    get onClose() {
      return this.closeEmitter.event;
    }
    fireClose() {
      this.closeEmitter.fire(void 0);
    }
    get onPartialMessage() {
      return this.partialMessageEmitter.event;
    }
    firePartialMessage(l) {
      this.partialMessageEmitter.fire(l);
    }
    asError(l) {
      return l instanceof Error ? l : new Error(`Reader received error. Reason: ${e.string(l.message) ? l.message : "unknown"}`);
    }
  }
  Gt.AbstractMessageReader = s;
  var a;
  (function(c) {
    function l(u) {
      let f, m;
      const p = /* @__PURE__ */ new Map();
      let A;
      const b = /* @__PURE__ */ new Map();
      if (u === void 0 || typeof u == "string")
        f = u ?? "utf-8";
      else {
        if (f = u.charset ?? "utf-8", u.contentDecoder !== void 0 && (m = u.contentDecoder, p.set(m.name, m)), u.contentDecoders !== void 0)
          for (const I of u.contentDecoders)
            p.set(I.name, I);
        if (u.contentTypeDecoder !== void 0 && (A = u.contentTypeDecoder, b.set(A.name, A)), u.contentTypeDecoders !== void 0)
          for (const I of u.contentTypeDecoders)
            b.set(I.name, I);
      }
      return A === void 0 && (A = (0, t.default)().applicationJson.decoder, b.set(A.name, A)), { charset: f, contentDecoder: m, contentDecoders: p, contentTypeDecoder: A, contentTypeDecoders: b };
    }
    c.fromOptions = l;
  })(a || (a = {}));
  class o extends s {
    constructor(l, u) {
      super(), this.readable = l, this.options = a.fromOptions(u), this.buffer = (0, t.default)().messageBuffer.create(this.options.charset), this._partialMessageTimeout = 1e4, this.nextMessageLength = -1, this.messageToken = 0, this.readSemaphore = new r.Semaphore(1);
    }
    set partialMessageTimeout(l) {
      this._partialMessageTimeout = l;
    }
    get partialMessageTimeout() {
      return this._partialMessageTimeout;
    }
    listen(l) {
      this.nextMessageLength = -1, this.messageToken = 0, this.partialMessageTimer = void 0, this.callback = l;
      const u = this.readable.onData((f) => {
        this.onData(f);
      });
      return this.readable.onError((f) => this.fireError(f)), this.readable.onClose(() => this.fireClose()), u;
    }
    onData(l) {
      try {
        for (this.buffer.append(l); ; ) {
          if (this.nextMessageLength === -1) {
            const f = this.buffer.tryReadHeaders(!0);
            if (!f)
              return;
            const m = f.get("content-length");
            if (!m) {
              this.fireError(new Error(`Header must provide a Content-Length property.
${JSON.stringify(Object.fromEntries(f))}`));
              return;
            }
            const p = parseInt(m);
            if (isNaN(p)) {
              this.fireError(new Error(`Content-Length value must be a number. Got ${m}`));
              return;
            }
            this.nextMessageLength = p;
          }
          const u = this.buffer.tryReadBody(this.nextMessageLength);
          if (u === void 0) {
            this.setPartialMessageTimer();
            return;
          }
          this.clearPartialMessageTimer(), this.nextMessageLength = -1, this.readSemaphore.lock(async () => {
            const f = this.options.contentDecoder !== void 0 ? await this.options.contentDecoder.decode(u) : u, m = await this.options.contentTypeDecoder.decode(f, this.options);
            this.callback(m);
          }).catch((f) => {
            this.fireError(f);
          });
        }
      } catch (u) {
        this.fireError(u);
      }
    }
    clearPartialMessageTimer() {
      this.partialMessageTimer && (this.partialMessageTimer.dispose(), this.partialMessageTimer = void 0);
    }
    setPartialMessageTimer() {
      this.clearPartialMessageTimer(), !(this._partialMessageTimeout <= 0) && (this.partialMessageTimer = (0, t.default)().timer.setTimeout((l, u) => {
        this.partialMessageTimer = void 0, l === this.messageToken && (this.firePartialMessage({ messageToken: l, waitingTime: u }), this.setPartialMessageTimer());
      }, this._partialMessageTimeout, this.messageToken, this._partialMessageTimeout));
    }
  }
  return Gt.ReadableStreamMessageReader = o, Gt;
}
var Ut = {}, Pu;
function dR() {
  if (Pu) return Ut;
  Pu = 1, Object.defineProperty(Ut, "__esModule", { value: !0 }), Ut.WriteableStreamMessageWriter = Ut.AbstractMessageWriter = Ut.MessageWriter = void 0;
  const t = Xn(), e = us(), n = ch(), r = Qr(), i = "Content-Length: ", s = `\r
`;
  var a;
  (function(u) {
    function f(m) {
      let p = m;
      return p && e.func(p.dispose) && e.func(p.onClose) && e.func(p.onError) && e.func(p.write);
    }
    u.is = f;
  })(a || (Ut.MessageWriter = a = {}));
  class o {
    constructor() {
      this.errorEmitter = new r.Emitter(), this.closeEmitter = new r.Emitter();
    }
    dispose() {
      this.errorEmitter.dispose(), this.closeEmitter.dispose();
    }
    get onError() {
      return this.errorEmitter.event;
    }
    fireError(f, m, p) {
      this.errorEmitter.fire([this.asError(f), m, p]);
    }
    get onClose() {
      return this.closeEmitter.event;
    }
    fireClose() {
      this.closeEmitter.fire(void 0);
    }
    asError(f) {
      return f instanceof Error ? f : new Error(`Writer received error. Reason: ${e.string(f.message) ? f.message : "unknown"}`);
    }
  }
  Ut.AbstractMessageWriter = o;
  var c;
  (function(u) {
    function f(m) {
      return m === void 0 || typeof m == "string" ? { charset: m ?? "utf-8", contentTypeEncoder: (0, t.default)().applicationJson.encoder } : { charset: m.charset ?? "utf-8", contentEncoder: m.contentEncoder, contentTypeEncoder: m.contentTypeEncoder ?? (0, t.default)().applicationJson.encoder };
    }
    u.fromOptions = f;
  })(c || (c = {}));
  class l extends o {
    constructor(f, m) {
      super(), this.writable = f, this.options = c.fromOptions(m), this.errorCount = 0, this.writeSemaphore = new n.Semaphore(1), this.writable.onError((p) => this.fireError(p)), this.writable.onClose(() => this.fireClose());
    }
    async write(f) {
      return this.writeSemaphore.lock(async () => this.options.contentTypeEncoder.encode(f, this.options).then((p) => this.options.contentEncoder !== void 0 ? this.options.contentEncoder.encode(p) : p).then((p) => {
        const A = [];
        return A.push(i, p.byteLength.toString(), s), A.push(s), this.doWrite(f, A, p);
      }, (p) => {
        throw this.fireError(p), p;
      }));
    }
    async doWrite(f, m, p) {
      try {
        return await this.writable.write(m.join(""), "ascii"), this.writable.write(p);
      } catch (A) {
        return this.handleError(A, f), Promise.reject(A);
      }
    }
    handleError(f, m) {
      this.errorCount++, this.fireError(f, m, this.errorCount);
    }
    end() {
      this.writable.end();
    }
  }
  return Ut.WriteableStreamMessageWriter = l, Ut;
}
var vi = {}, $u;
function fR() {
  if ($u) return vi;
  $u = 1, Object.defineProperty(vi, "__esModule", { value: !0 }), vi.AbstractMessageBuffer = void 0;
  const t = 13, e = 10, n = `\r
`;
  class r {
    constructor(s = "utf-8") {
      this._encoding = s, this._chunks = [], this._totalLength = 0;
    }
    get encoding() {
      return this._encoding;
    }
    append(s) {
      const a = typeof s == "string" ? this.fromString(s, this._encoding) : s;
      this._chunks.push(a), this._totalLength += a.byteLength;
    }
    tryReadHeaders(s = !1) {
      if (this._chunks.length === 0)
        return;
      let a = 0, o = 0, c = 0, l = 0;
      e: for (; o < this._chunks.length; ) {
        const p = this._chunks[o];
        for (c = 0; c < p.length; ) {
          switch (p[c]) {
            case t:
              switch (a) {
                case 0:
                  a = 1;
                  break;
                case 2:
                  a = 3;
                  break;
                default:
                  a = 0;
              }
              break;
            case e:
              switch (a) {
                case 1:
                  a = 2;
                  break;
                case 3:
                  a = 4, c++;
                  break e;
                default:
                  a = 0;
              }
              break;
            default:
              a = 0;
          }
          c++;
        }
        l += p.byteLength, o++;
      }
      if (a !== 4)
        return;
      const u = this._read(l + c), f = /* @__PURE__ */ new Map(), m = this.toString(u, "ascii").split(n);
      if (m.length < 2)
        return f;
      for (let p = 0; p < m.length - 2; p++) {
        const A = m[p], b = A.indexOf(":");
        if (b === -1)
          throw new Error(`Message header must separate key and value using ':'
${A}`);
        const I = A.substr(0, b), C = A.substr(b + 1).trim();
        f.set(s ? I.toLowerCase() : I, C);
      }
      return f;
    }
    tryReadBody(s) {
      if (!(this._totalLength < s))
        return this._read(s);
    }
    get numberOfBytes() {
      return this._totalLength;
    }
    _read(s) {
      if (s === 0)
        return this.emptyBuffer();
      if (s > this._totalLength)
        throw new Error("Cannot read so many bytes!");
      if (this._chunks[0].byteLength === s) {
        const l = this._chunks[0];
        return this._chunks.shift(), this._totalLength -= s, this.asNative(l);
      }
      if (this._chunks[0].byteLength > s) {
        const l = this._chunks[0], u = this.asNative(l, s);
        return this._chunks[0] = l.slice(s), this._totalLength -= s, u;
      }
      const a = this.allocNative(s);
      let o = 0, c = 0;
      for (; s > 0; ) {
        const l = this._chunks[c];
        if (l.byteLength > s) {
          const u = l.slice(0, s);
          a.set(u, o), o += s, this._chunks[c] = l.slice(s), this._totalLength -= s, s -= s;
        } else
          a.set(l, o), o += l.byteLength, this._chunks.shift(), this._totalLength -= l.byteLength, s -= l.byteLength;
      }
      return a;
    }
  }
  return vi.AbstractMessageBuffer = r, vi;
}
var so = {}, Lu;
function hR() {
  return Lu || (Lu = 1, (function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.createMessageConnection = t.ConnectionOptions = t.MessageStrategy = t.CancellationStrategy = t.CancellationSenderStrategy = t.CancellationReceiverStrategy = t.RequestCancellationReceiverStrategy = t.IdCancellationReceiverStrategy = t.ConnectionStrategy = t.ConnectionError = t.ConnectionErrors = t.LogTraceNotification = t.SetTraceNotification = t.TraceFormat = t.TraceValues = t.Trace = t.NullLogger = t.ProgressType = t.ProgressToken = void 0;
    const e = Xn(), n = us(), r = ah(), i = oh(), s = Qr(), a = ja();
    var o;
    (function(g) {
      g.type = new r.NotificationType("$/cancelRequest");
    })(o || (o = {}));
    var c;
    (function(g) {
      function S(y) {
        return typeof y == "string" || typeof y == "number";
      }
      g.is = S;
    })(c || (t.ProgressToken = c = {}));
    var l;
    (function(g) {
      g.type = new r.NotificationType("$/progress");
    })(l || (l = {}));
    class u {
      constructor() {
      }
    }
    t.ProgressType = u;
    var f;
    (function(g) {
      function S(y) {
        return n.func(y);
      }
      g.is = S;
    })(f || (f = {})), t.NullLogger = Object.freeze({
      error: () => {
      },
      warn: () => {
      },
      info: () => {
      },
      log: () => {
      }
    });
    var m;
    (function(g) {
      g[g.Off = 0] = "Off", g[g.Messages = 1] = "Messages", g[g.Compact = 2] = "Compact", g[g.Verbose = 3] = "Verbose";
    })(m || (t.Trace = m = {}));
    var p;
    (function(g) {
      g.Off = "off", g.Messages = "messages", g.Compact = "compact", g.Verbose = "verbose";
    })(p || (t.TraceValues = p = {})), (function(g) {
      function S(R) {
        if (!n.string(R))
          return g.Off;
        switch (R = R.toLowerCase(), R) {
          case "off":
            return g.Off;
          case "messages":
            return g.Messages;
          case "compact":
            return g.Compact;
          case "verbose":
            return g.Verbose;
          default:
            return g.Off;
        }
      }
      g.fromString = S;
      function y(R) {
        switch (R) {
          case g.Off:
            return "off";
          case g.Messages:
            return "messages";
          case g.Compact:
            return "compact";
          case g.Verbose:
            return "verbose";
          default:
            return "off";
        }
      }
      g.toString = y;
    })(m || (t.Trace = m = {}));
    var A;
    (function(g) {
      g.Text = "text", g.JSON = "json";
    })(A || (t.TraceFormat = A = {})), (function(g) {
      function S(y) {
        return n.string(y) ? (y = y.toLowerCase(), y === "json" ? g.JSON : g.Text) : g.Text;
      }
      g.fromString = S;
    })(A || (t.TraceFormat = A = {}));
    var b;
    (function(g) {
      g.type = new r.NotificationType("$/setTrace");
    })(b || (t.SetTraceNotification = b = {}));
    var I;
    (function(g) {
      g.type = new r.NotificationType("$/logTrace");
    })(I || (t.LogTraceNotification = I = {}));
    var C;
    (function(g) {
      g[g.Closed = 1] = "Closed", g[g.Disposed = 2] = "Disposed", g[g.AlreadyListening = 3] = "AlreadyListening";
    })(C || (t.ConnectionErrors = C = {}));
    class N extends Error {
      constructor(S, y) {
        super(y), this.code = S, Object.setPrototypeOf(this, N.prototype);
      }
    }
    t.ConnectionError = N;
    var k;
    (function(g) {
      function S(y) {
        const R = y;
        return R && n.func(R.cancelUndispatched);
      }
      g.is = S;
    })(k || (t.ConnectionStrategy = k = {}));
    var P;
    (function(g) {
      function S(y) {
        const R = y;
        return R && (R.kind === void 0 || R.kind === "id") && n.func(R.createCancellationTokenSource) && (R.dispose === void 0 || n.func(R.dispose));
      }
      g.is = S;
    })(P || (t.IdCancellationReceiverStrategy = P = {}));
    var H;
    (function(g) {
      function S(y) {
        const R = y;
        return R && R.kind === "request" && n.func(R.createCancellationTokenSource) && (R.dispose === void 0 || n.func(R.dispose));
      }
      g.is = S;
    })(H || (t.RequestCancellationReceiverStrategy = H = {}));
    var K;
    (function(g) {
      g.Message = Object.freeze({
        createCancellationTokenSource(y) {
          return new a.CancellationTokenSource();
        }
      });
      function S(y) {
        return P.is(y) || H.is(y);
      }
      g.is = S;
    })(K || (t.CancellationReceiverStrategy = K = {}));
    var J;
    (function(g) {
      g.Message = Object.freeze({
        sendCancellation(y, R) {
          return y.sendNotification(o.type, { id: R });
        },
        cleanup(y) {
        }
      });
      function S(y) {
        const R = y;
        return R && n.func(R.sendCancellation) && n.func(R.cleanup);
      }
      g.is = S;
    })(J || (t.CancellationSenderStrategy = J = {}));
    var oe;
    (function(g) {
      g.Message = Object.freeze({
        receiver: K.Message,
        sender: J.Message
      });
      function S(y) {
        const R = y;
        return R && K.is(R.receiver) && J.is(R.sender);
      }
      g.is = S;
    })(oe || (t.CancellationStrategy = oe = {}));
    var ue;
    (function(g) {
      function S(y) {
        const R = y;
        return R && n.func(R.handleMessage);
      }
      g.is = S;
    })(ue || (t.MessageStrategy = ue = {}));
    var de;
    (function(g) {
      function S(y) {
        const R = y;
        return R && (oe.is(R.cancellationStrategy) || k.is(R.connectionStrategy) || ue.is(R.messageStrategy));
      }
      g.is = S;
    })(de || (t.ConnectionOptions = de = {}));
    var _;
    (function(g) {
      g[g.New = 1] = "New", g[g.Listening = 2] = "Listening", g[g.Closed = 3] = "Closed", g[g.Disposed = 4] = "Disposed";
    })(_ || (_ = {}));
    function T(g, S, y, R) {
      const E = y !== void 0 ? y : t.NullLogger;
      let O = 0, D = 0, x = 0;
      const j = "2.0";
      let G;
      const ie = /* @__PURE__ */ new Map();
      let B;
      const ne = /* @__PURE__ */ new Map(), Oe = /* @__PURE__ */ new Map();
      let Re, fe = new i.LinkedMap(), Ie = /* @__PURE__ */ new Map(), xe = /* @__PURE__ */ new Set(), be = /* @__PURE__ */ new Map(), Z = m.Off, at = A.Text, ve, Tt = _.New;
      const Zn = new s.Emitter(), ei = new s.Emitter(), ti = new s.Emitter(), ni = new s.Emitter(), ri = new s.Emitter(), Rt = R && R.cancellationStrategy ? R.cancellationStrategy : oe.Message;
      function ii(h) {
        if (h === null)
          throw new Error("Can't send requests with id null since the response can't be correlated.");
        return "req-" + h.toString();
      }
      function ds(h) {
        return h === null ? "res-unknown-" + (++x).toString() : "res-" + h.toString();
      }
      function fs() {
        return "not-" + (++D).toString();
      }
      function hs(h, w) {
        r.Message.isRequest(w) ? h.set(ii(w.id), w) : r.Message.isResponse(w) ? h.set(ds(w.id), w) : h.set(fs(), w);
      }
      function ps(h) {
      }
      function si() {
        return Tt === _.Listening;
      }
      function ai() {
        return Tt === _.Closed;
      }
      function Dt() {
        return Tt === _.Disposed;
      }
      function oi() {
        (Tt === _.New || Tt === _.Listening) && (Tt = _.Closed, ei.fire(void 0));
      }
      function ms(h) {
        Zn.fire([h, void 0, void 0]);
      }
      function gs(h) {
        Zn.fire(h);
      }
      g.onClose(oi), g.onError(ms), S.onClose(oi), S.onError(gs);
      function ci() {
        Re || fe.size === 0 || (Re = (0, e.default)().timer.setImmediate(() => {
          Re = void 0, ys();
        }));
      }
      function li(h) {
        r.Message.isRequest(h) ? Rs(h) : r.Message.isNotification(h) ? Es(h) : r.Message.isResponse(h) ? vs(h) : As(h);
      }
      function ys() {
        if (fe.size === 0)
          return;
        const h = fe.shift();
        try {
          const w = R?.messageStrategy;
          ue.is(w) ? w.handleMessage(h, li) : li(h);
        } finally {
          ci();
        }
      }
      const Ts = (h) => {
        try {
          if (r.Message.isNotification(h) && h.method === o.type.method) {
            const w = h.params.id, L = ii(w), F = fe.get(L);
            if (r.Message.isRequest(F)) {
              const se = R?.connectionStrategy, Ee = se && se.cancelUndispatched ? se.cancelUndispatched(F, ps) : void 0;
              if (Ee && (Ee.error !== void 0 || Ee.result !== void 0)) {
                fe.delete(L), be.delete(w), Ee.id = F.id, vn(Ee, h.method, Date.now()), S.write(Ee).catch(() => E.error("Sending response for canceled message failed."));
                return;
              }
            }
            const ce = be.get(w);
            if (ce !== void 0) {
              ce.cancel(), er(h);
              return;
            } else
              xe.add(w);
          }
          hs(fe, h);
        } finally {
          ci();
        }
      };
      function Rs(h) {
        if (Dt())
          return;
        function w(Q, he, re) {
          const Pe = {
            jsonrpc: j,
            id: h.id
          };
          Q instanceof r.ResponseError ? Pe.error = Q.toJson() : Pe.result = Q === void 0 ? null : Q, vn(Pe, he, re), S.write(Pe).catch(() => E.error("Sending response failed."));
        }
        function L(Q, he, re) {
          const Pe = {
            jsonrpc: j,
            id: h.id,
            error: Q.toJson()
          };
          vn(Pe, he, re), S.write(Pe).catch(() => E.error("Sending response failed."));
        }
        function F(Q, he, re) {
          Q === void 0 && (Q = null);
          const Pe = {
            jsonrpc: j,
            id: h.id,
            result: Q
          };
          vn(Pe, he, re), S.write(Pe).catch(() => E.error("Sending response failed."));
        }
        Cs(h);
        const ce = ie.get(h.method);
        let se, Ee;
        ce && (se = ce.type, Ee = ce.handler);
        const Ne = Date.now();
        if (Ee || G) {
          const Q = h.id ?? String(Date.now()), he = P.is(Rt.receiver) ? Rt.receiver.createCancellationTokenSource(Q) : Rt.receiver.createCancellationTokenSource(h);
          h.id !== null && xe.has(h.id) && he.cancel(), h.id !== null && be.set(Q, he);
          try {
            let re;
            if (Ee)
              if (h.params === void 0) {
                if (se !== void 0 && se.numberOfParams !== 0) {
                  L(new r.ResponseError(r.ErrorCodes.InvalidParams, `Request ${h.method} defines ${se.numberOfParams} params but received none.`), h.method, Ne);
                  return;
                }
                re = Ee(he.token);
              } else if (Array.isArray(h.params)) {
                if (se !== void 0 && se.parameterStructures === r.ParameterStructures.byName) {
                  L(new r.ResponseError(r.ErrorCodes.InvalidParams, `Request ${h.method} defines parameters by name but received parameters by position`), h.method, Ne);
                  return;
                }
                re = Ee(...h.params, he.token);
              } else {
                if (se !== void 0 && se.parameterStructures === r.ParameterStructures.byPosition) {
                  L(new r.ResponseError(r.ErrorCodes.InvalidParams, `Request ${h.method} defines parameters by position but received parameters by name`), h.method, Ne);
                  return;
                }
                re = Ee(h.params, he.token);
              }
            else G && (re = G(h.method, h.params, he.token));
            const Pe = re;
            re ? Pe.then ? Pe.then((Ke) => {
              be.delete(Q), w(Ke, h.method, Ne);
            }, (Ke) => {
              be.delete(Q), Ke instanceof r.ResponseError ? L(Ke, h.method, Ne) : Ke && n.string(Ke.message) ? L(new r.ResponseError(r.ErrorCodes.InternalError, `Request ${h.method} failed with message: ${Ke.message}`), h.method, Ne) : L(new r.ResponseError(r.ErrorCodes.InternalError, `Request ${h.method} failed unexpectedly without providing any details.`), h.method, Ne);
            }) : (be.delete(Q), w(re, h.method, Ne)) : (be.delete(Q), F(re, h.method, Ne));
          } catch (re) {
            be.delete(Q), re instanceof r.ResponseError ? w(re, h.method, Ne) : re && n.string(re.message) ? L(new r.ResponseError(r.ErrorCodes.InternalError, `Request ${h.method} failed with message: ${re.message}`), h.method, Ne) : L(new r.ResponseError(r.ErrorCodes.InternalError, `Request ${h.method} failed unexpectedly without providing any details.`), h.method, Ne);
          }
        } else
          L(new r.ResponseError(r.ErrorCodes.MethodNotFound, `Unhandled method ${h.method}`), h.method, Ne);
      }
      function vs(h) {
        if (!Dt())
          if (h.id === null)
            h.error ? E.error(`Received response message without id: Error is: 
${JSON.stringify(h.error, void 0, 4)}`) : E.error("Received response message without id. No further error information provided.");
          else {
            const w = h.id, L = Ie.get(w);
            if (Ns(h, L), L !== void 0) {
              Ie.delete(w);
              try {
                if (h.error) {
                  const F = h.error;
                  L.reject(new r.ResponseError(F.code, F.message, F.data));
                } else if (h.result !== void 0)
                  L.resolve(h.result);
                else
                  throw new Error("Should never happen.");
              } catch (F) {
                F.message ? E.error(`Response handler '${L.method}' failed with message: ${F.message}`) : E.error(`Response handler '${L.method}' failed unexpectedly.`);
              }
            }
          }
      }
      function Es(h) {
        if (Dt())
          return;
        let w, L;
        if (h.method === o.type.method) {
          const F = h.params.id;
          xe.delete(F), er(h);
          return;
        } else {
          const F = ne.get(h.method);
          F && (L = F.handler, w = F.type);
        }
        if (L || B)
          try {
            if (er(h), L)
              if (h.params === void 0)
                w !== void 0 && w.numberOfParams !== 0 && w.parameterStructures !== r.ParameterStructures.byName && E.error(`Notification ${h.method} defines ${w.numberOfParams} params but received none.`), L();
              else if (Array.isArray(h.params)) {
                const F = h.params;
                h.method === l.type.method && F.length === 2 && c.is(F[0]) ? L({ token: F[0], value: F[1] }) : (w !== void 0 && (w.parameterStructures === r.ParameterStructures.byName && E.error(`Notification ${h.method} defines parameters by name but received parameters by position`), w.numberOfParams !== h.params.length && E.error(`Notification ${h.method} defines ${w.numberOfParams} params but received ${F.length} arguments`)), L(...F));
              } else
                w !== void 0 && w.parameterStructures === r.ParameterStructures.byPosition && E.error(`Notification ${h.method} defines parameters by position but received parameters by name`), L(h.params);
            else B && B(h.method, h.params);
          } catch (F) {
            F.message ? E.error(`Notification handler '${h.method}' failed with message: ${F.message}`) : E.error(`Notification handler '${h.method}' failed unexpectedly.`);
          }
        else
          ti.fire(h);
      }
      function As(h) {
        if (!h) {
          E.error("Received empty message.");
          return;
        }
        E.error(`Received message which is neither a response nor a notification message:
${JSON.stringify(h, null, 4)}`);
        const w = h;
        if (n.string(w.id) || n.number(w.id)) {
          const L = w.id, F = Ie.get(L);
          F && F.reject(new Error("The received response has neither a result nor an error property."));
        }
      }
      function vt(h) {
        if (h != null)
          switch (Z) {
            case m.Verbose:
              return JSON.stringify(h, null, 4);
            case m.Compact:
              return JSON.stringify(h);
            default:
              return;
          }
      }
      function Ss(h) {
        if (!(Z === m.Off || !ve))
          if (at === A.Text) {
            let w;
            (Z === m.Verbose || Z === m.Compact) && h.params && (w = `Params: ${vt(h.params)}

`), ve.log(`Sending request '${h.method} - (${h.id})'.`, w);
          } else
            Mt("send-request", h);
      }
      function ks(h) {
        if (!(Z === m.Off || !ve))
          if (at === A.Text) {
            let w;
            (Z === m.Verbose || Z === m.Compact) && (h.params ? w = `Params: ${vt(h.params)}

` : w = `No parameters provided.

`), ve.log(`Sending notification '${h.method}'.`, w);
          } else
            Mt("send-notification", h);
      }
      function vn(h, w, L) {
        if (!(Z === m.Off || !ve))
          if (at === A.Text) {
            let F;
            (Z === m.Verbose || Z === m.Compact) && (h.error && h.error.data ? F = `Error data: ${vt(h.error.data)}

` : h.result ? F = `Result: ${vt(h.result)}

` : h.error === void 0 && (F = `No result returned.

`)), ve.log(`Sending response '${w} - (${h.id})'. Processing request took ${Date.now() - L}ms`, F);
          } else
            Mt("send-response", h);
      }
      function Cs(h) {
        if (!(Z === m.Off || !ve))
          if (at === A.Text) {
            let w;
            (Z === m.Verbose || Z === m.Compact) && h.params && (w = `Params: ${vt(h.params)}

`), ve.log(`Received request '${h.method} - (${h.id})'.`, w);
          } else
            Mt("receive-request", h);
      }
      function er(h) {
        if (!(Z === m.Off || !ve || h.method === I.type.method))
          if (at === A.Text) {
            let w;
            (Z === m.Verbose || Z === m.Compact) && (h.params ? w = `Params: ${vt(h.params)}

` : w = `No parameters provided.

`), ve.log(`Received notification '${h.method}'.`, w);
          } else
            Mt("receive-notification", h);
      }
      function Ns(h, w) {
        if (!(Z === m.Off || !ve))
          if (at === A.Text) {
            let L;
            if ((Z === m.Verbose || Z === m.Compact) && (h.error && h.error.data ? L = `Error data: ${vt(h.error.data)}

` : h.result ? L = `Result: ${vt(h.result)}

` : h.error === void 0 && (L = `No result returned.

`)), w) {
              const F = h.error ? ` Request failed: ${h.error.message} (${h.error.code}).` : "";
              ve.log(`Received response '${w.method} - (${h.id})' in ${Date.now() - w.timerStart}ms.${F}`, L);
            } else
              ve.log(`Received response ${h.id} without active response promise.`, L);
          } else
            Mt("receive-response", h);
      }
      function Mt(h, w) {
        if (!ve || Z === m.Off)
          return;
        const L = {
          isLSPMessage: !0,
          type: h,
          message: w,
          timestamp: Date.now()
        };
        ve.log(L);
      }
      function on() {
        if (ai())
          throw new N(C.Closed, "Connection is closed.");
        if (Dt())
          throw new N(C.Disposed, "Connection is disposed.");
      }
      function ws() {
        if (si())
          throw new N(C.AlreadyListening, "Connection is already listening");
      }
      function bs() {
        if (!si())
          throw new Error("Call listen() first.");
      }
      function cn(h) {
        return h === void 0 ? null : h;
      }
      function ui(h) {
        if (h !== null)
          return h;
      }
      function d(h) {
        return h != null && !Array.isArray(h) && typeof h == "object";
      }
      function ke(h, w) {
        switch (h) {
          case r.ParameterStructures.auto:
            return d(w) ? ui(w) : [cn(w)];
          case r.ParameterStructures.byName:
            if (!d(w))
              throw new Error("Received parameters by name but param is not an object literal.");
            return ui(w);
          case r.ParameterStructures.byPosition:
            return [cn(w)];
          default:
            throw new Error(`Unknown parameter structure ${h.toString()}`);
        }
      }
      function Ce(h, w) {
        let L;
        const F = h.numberOfParams;
        switch (F) {
          case 0:
            L = void 0;
            break;
          case 1:
            L = ke(h.parameterStructures, w[0]);
            break;
          default:
            L = [];
            for (let ce = 0; ce < w.length && ce < F; ce++)
              L.push(cn(w[ce]));
            if (w.length < F)
              for (let ce = w.length; ce < F; ce++)
                L.push(null);
            break;
        }
        return L;
      }
      const V = {
        sendNotification: (h, ...w) => {
          on();
          let L, F;
          if (n.string(h)) {
            L = h;
            const se = w[0];
            let Ee = 0, Ne = r.ParameterStructures.auto;
            r.ParameterStructures.is(se) && (Ee = 1, Ne = se);
            let Q = w.length;
            const he = Q - Ee;
            switch (he) {
              case 0:
                F = void 0;
                break;
              case 1:
                F = ke(Ne, w[Ee]);
                break;
              default:
                if (Ne === r.ParameterStructures.byName)
                  throw new Error(`Received ${he} parameters for 'by Name' notification parameter structure.`);
                F = w.slice(Ee, Q).map((re) => cn(re));
                break;
            }
          } else {
            const se = w;
            L = h.method, F = Ce(h, se);
          }
          const ce = {
            jsonrpc: j,
            method: L,
            params: F
          };
          return ks(ce), S.write(ce).catch((se) => {
            throw E.error("Sending notification failed."), se;
          });
        },
        onNotification: (h, w) => {
          on();
          let L;
          return n.func(h) ? B = h : w && (n.string(h) ? (L = h, ne.set(h, { type: void 0, handler: w })) : (L = h.method, ne.set(h.method, { type: h, handler: w }))), {
            dispose: () => {
              L !== void 0 ? ne.delete(L) : B = void 0;
            }
          };
        },
        onProgress: (h, w, L) => {
          if (Oe.has(w))
            throw new Error(`Progress handler for token ${w} already registered`);
          return Oe.set(w, L), {
            dispose: () => {
              Oe.delete(w);
            }
          };
        },
        sendProgress: (h, w, L) => V.sendNotification(l.type, { token: w, value: L }),
        onUnhandledProgress: ni.event,
        sendRequest: (h, ...w) => {
          on(), bs();
          let L, F, ce;
          if (n.string(h)) {
            L = h;
            const Q = w[0], he = w[w.length - 1];
            let re = 0, Pe = r.ParameterStructures.auto;
            r.ParameterStructures.is(Q) && (re = 1, Pe = Q);
            let Ke = w.length;
            a.CancellationToken.is(he) && (Ke = Ke - 1, ce = he);
            const _t = Ke - re;
            switch (_t) {
              case 0:
                F = void 0;
                break;
              case 1:
                F = ke(Pe, w[re]);
                break;
              default:
                if (Pe === r.ParameterStructures.byName)
                  throw new Error(`Received ${_t} parameters for 'by Name' request parameter structure.`);
                F = w.slice(re, Ke).map(($h) => cn($h));
                break;
            }
          } else {
            const Q = w;
            L = h.method, F = Ce(h, Q);
            const he = h.numberOfParams;
            ce = a.CancellationToken.is(Q[he]) ? Q[he] : void 0;
          }
          const se = O++;
          let Ee;
          ce && (Ee = ce.onCancellationRequested(() => {
            const Q = Rt.sender.sendCancellation(V, se);
            return Q === void 0 ? (E.log(`Received no promise from cancellation strategy when cancelling id ${se}`), Promise.resolve()) : Q.catch(() => {
              E.log(`Sending cancellation messages for id ${se} failed`);
            });
          }));
          const Ne = {
            jsonrpc: j,
            id: se,
            method: L,
            params: F
          };
          return Ss(Ne), typeof Rt.sender.enableCancellation == "function" && Rt.sender.enableCancellation(Ne), new Promise(async (Q, he) => {
            const re = (_t) => {
              Q(_t), Rt.sender.cleanup(se), Ee?.dispose();
            }, Pe = (_t) => {
              he(_t), Rt.sender.cleanup(se), Ee?.dispose();
            }, Ke = { method: L, timerStart: Date.now(), resolve: re, reject: Pe };
            try {
              await S.write(Ne), Ie.set(se, Ke);
            } catch (_t) {
              throw E.error("Sending request failed."), Ke.reject(new r.ResponseError(r.ErrorCodes.MessageWriteError, _t.message ? _t.message : "Unknown reason")), _t;
            }
          });
        },
        onRequest: (h, w) => {
          on();
          let L = null;
          return f.is(h) ? (L = void 0, G = h) : n.string(h) ? (L = null, w !== void 0 && (L = h, ie.set(h, { handler: w, type: void 0 }))) : w !== void 0 && (L = h.method, ie.set(h.method, { type: h, handler: w })), {
            dispose: () => {
              L !== null && (L !== void 0 ? ie.delete(L) : G = void 0);
            }
          };
        },
        hasPendingResponse: () => Ie.size > 0,
        trace: async (h, w, L) => {
          let F = !1, ce = A.Text;
          L !== void 0 && (n.boolean(L) ? F = L : (F = L.sendNotification || !1, ce = L.traceFormat || A.Text)), Z = h, at = ce, Z === m.Off ? ve = void 0 : ve = w, F && !ai() && !Dt() && await V.sendNotification(b.type, { value: m.toString(h) });
        },
        onError: Zn.event,
        onClose: ei.event,
        onUnhandledNotification: ti.event,
        onDispose: ri.event,
        end: () => {
          S.end();
        },
        dispose: () => {
          if (Dt())
            return;
          Tt = _.Disposed, ri.fire(void 0);
          const h = new r.ResponseError(r.ErrorCodes.PendingResponseRejected, "Pending response rejected since connection got disposed");
          for (const w of Ie.values())
            w.reject(h);
          Ie = /* @__PURE__ */ new Map(), be = /* @__PURE__ */ new Map(), xe = /* @__PURE__ */ new Set(), fe = new i.LinkedMap(), n.func(S.dispose) && S.dispose(), n.func(g.dispose) && g.dispose();
        },
        listen: () => {
          on(), ws(), Tt = _.Listening, g.listen(Ts);
        },
        inspect: () => {
          (0, e.default)().console.log("inspect");
        }
      };
      return V.onNotification(I.type, (h) => {
        if (Z === m.Off || !ve)
          return;
        const w = Z === m.Verbose || Z === m.Compact;
        ve.log(h.message, w ? h.verbose : void 0);
      }), V.onNotification(l.type, (h) => {
        const w = Oe.get(h.token);
        w ? w(h.value) : ni.fire(h);
      }), V;
    }
    t.createMessageConnection = T;
  })(so)), so;
}
var Ou;
function Bc() {
  return Ou || (Ou = 1, (function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.ProgressType = t.ProgressToken = t.createMessageConnection = t.NullLogger = t.ConnectionOptions = t.ConnectionStrategy = t.AbstractMessageBuffer = t.WriteableStreamMessageWriter = t.AbstractMessageWriter = t.MessageWriter = t.ReadableStreamMessageReader = t.AbstractMessageReader = t.MessageReader = t.SharedArrayReceiverStrategy = t.SharedArraySenderStrategy = t.CancellationToken = t.CancellationTokenSource = t.Emitter = t.Event = t.Disposable = t.LRUCache = t.Touch = t.LinkedMap = t.ParameterStructures = t.NotificationType9 = t.NotificationType8 = t.NotificationType7 = t.NotificationType6 = t.NotificationType5 = t.NotificationType4 = t.NotificationType3 = t.NotificationType2 = t.NotificationType1 = t.NotificationType0 = t.NotificationType = t.ErrorCodes = t.ResponseError = t.RequestType9 = t.RequestType8 = t.RequestType7 = t.RequestType6 = t.RequestType5 = t.RequestType4 = t.RequestType3 = t.RequestType2 = t.RequestType1 = t.RequestType0 = t.RequestType = t.Message = t.RAL = void 0, t.MessageStrategy = t.CancellationStrategy = t.CancellationSenderStrategy = t.CancellationReceiverStrategy = t.ConnectionError = t.ConnectionErrors = t.LogTraceNotification = t.SetTraceNotification = t.TraceFormat = t.TraceValues = t.Trace = void 0;
    const e = ah();
    Object.defineProperty(t, "Message", { enumerable: !0, get: function() {
      return e.Message;
    } }), Object.defineProperty(t, "RequestType", { enumerable: !0, get: function() {
      return e.RequestType;
    } }), Object.defineProperty(t, "RequestType0", { enumerable: !0, get: function() {
      return e.RequestType0;
    } }), Object.defineProperty(t, "RequestType1", { enumerable: !0, get: function() {
      return e.RequestType1;
    } }), Object.defineProperty(t, "RequestType2", { enumerable: !0, get: function() {
      return e.RequestType2;
    } }), Object.defineProperty(t, "RequestType3", { enumerable: !0, get: function() {
      return e.RequestType3;
    } }), Object.defineProperty(t, "RequestType4", { enumerable: !0, get: function() {
      return e.RequestType4;
    } }), Object.defineProperty(t, "RequestType5", { enumerable: !0, get: function() {
      return e.RequestType5;
    } }), Object.defineProperty(t, "RequestType6", { enumerable: !0, get: function() {
      return e.RequestType6;
    } }), Object.defineProperty(t, "RequestType7", { enumerable: !0, get: function() {
      return e.RequestType7;
    } }), Object.defineProperty(t, "RequestType8", { enumerable: !0, get: function() {
      return e.RequestType8;
    } }), Object.defineProperty(t, "RequestType9", { enumerable: !0, get: function() {
      return e.RequestType9;
    } }), Object.defineProperty(t, "ResponseError", { enumerable: !0, get: function() {
      return e.ResponseError;
    } }), Object.defineProperty(t, "ErrorCodes", { enumerable: !0, get: function() {
      return e.ErrorCodes;
    } }), Object.defineProperty(t, "NotificationType", { enumerable: !0, get: function() {
      return e.NotificationType;
    } }), Object.defineProperty(t, "NotificationType0", { enumerable: !0, get: function() {
      return e.NotificationType0;
    } }), Object.defineProperty(t, "NotificationType1", { enumerable: !0, get: function() {
      return e.NotificationType1;
    } }), Object.defineProperty(t, "NotificationType2", { enumerable: !0, get: function() {
      return e.NotificationType2;
    } }), Object.defineProperty(t, "NotificationType3", { enumerable: !0, get: function() {
      return e.NotificationType3;
    } }), Object.defineProperty(t, "NotificationType4", { enumerable: !0, get: function() {
      return e.NotificationType4;
    } }), Object.defineProperty(t, "NotificationType5", { enumerable: !0, get: function() {
      return e.NotificationType5;
    } }), Object.defineProperty(t, "NotificationType6", { enumerable: !0, get: function() {
      return e.NotificationType6;
    } }), Object.defineProperty(t, "NotificationType7", { enumerable: !0, get: function() {
      return e.NotificationType7;
    } }), Object.defineProperty(t, "NotificationType8", { enumerable: !0, get: function() {
      return e.NotificationType8;
    } }), Object.defineProperty(t, "NotificationType9", { enumerable: !0, get: function() {
      return e.NotificationType9;
    } }), Object.defineProperty(t, "ParameterStructures", { enumerable: !0, get: function() {
      return e.ParameterStructures;
    } });
    const n = oh();
    Object.defineProperty(t, "LinkedMap", { enumerable: !0, get: function() {
      return n.LinkedMap;
    } }), Object.defineProperty(t, "LRUCache", { enumerable: !0, get: function() {
      return n.LRUCache;
    } }), Object.defineProperty(t, "Touch", { enumerable: !0, get: function() {
      return n.Touch;
    } });
    const r = cR();
    Object.defineProperty(t, "Disposable", { enumerable: !0, get: function() {
      return r.Disposable;
    } });
    const i = Qr();
    Object.defineProperty(t, "Event", { enumerable: !0, get: function() {
      return i.Event;
    } }), Object.defineProperty(t, "Emitter", { enumerable: !0, get: function() {
      return i.Emitter;
    } });
    const s = ja();
    Object.defineProperty(t, "CancellationTokenSource", { enumerable: !0, get: function() {
      return s.CancellationTokenSource;
    } }), Object.defineProperty(t, "CancellationToken", { enumerable: !0, get: function() {
      return s.CancellationToken;
    } });
    const a = lR();
    Object.defineProperty(t, "SharedArraySenderStrategy", { enumerable: !0, get: function() {
      return a.SharedArraySenderStrategy;
    } }), Object.defineProperty(t, "SharedArrayReceiverStrategy", { enumerable: !0, get: function() {
      return a.SharedArrayReceiverStrategy;
    } });
    const o = uR();
    Object.defineProperty(t, "MessageReader", { enumerable: !0, get: function() {
      return o.MessageReader;
    } }), Object.defineProperty(t, "AbstractMessageReader", { enumerable: !0, get: function() {
      return o.AbstractMessageReader;
    } }), Object.defineProperty(t, "ReadableStreamMessageReader", { enumerable: !0, get: function() {
      return o.ReadableStreamMessageReader;
    } });
    const c = dR();
    Object.defineProperty(t, "MessageWriter", { enumerable: !0, get: function() {
      return c.MessageWriter;
    } }), Object.defineProperty(t, "AbstractMessageWriter", { enumerable: !0, get: function() {
      return c.AbstractMessageWriter;
    } }), Object.defineProperty(t, "WriteableStreamMessageWriter", { enumerable: !0, get: function() {
      return c.WriteableStreamMessageWriter;
    } });
    const l = fR();
    Object.defineProperty(t, "AbstractMessageBuffer", { enumerable: !0, get: function() {
      return l.AbstractMessageBuffer;
    } });
    const u = hR();
    Object.defineProperty(t, "ConnectionStrategy", { enumerable: !0, get: function() {
      return u.ConnectionStrategy;
    } }), Object.defineProperty(t, "ConnectionOptions", { enumerable: !0, get: function() {
      return u.ConnectionOptions;
    } }), Object.defineProperty(t, "NullLogger", { enumerable: !0, get: function() {
      return u.NullLogger;
    } }), Object.defineProperty(t, "createMessageConnection", { enumerable: !0, get: function() {
      return u.createMessageConnection;
    } }), Object.defineProperty(t, "ProgressToken", { enumerable: !0, get: function() {
      return u.ProgressToken;
    } }), Object.defineProperty(t, "ProgressType", { enumerable: !0, get: function() {
      return u.ProgressType;
    } }), Object.defineProperty(t, "Trace", { enumerable: !0, get: function() {
      return u.Trace;
    } }), Object.defineProperty(t, "TraceValues", { enumerable: !0, get: function() {
      return u.TraceValues;
    } }), Object.defineProperty(t, "TraceFormat", { enumerable: !0, get: function() {
      return u.TraceFormat;
    } }), Object.defineProperty(t, "SetTraceNotification", { enumerable: !0, get: function() {
      return u.SetTraceNotification;
    } }), Object.defineProperty(t, "LogTraceNotification", { enumerable: !0, get: function() {
      return u.LogTraceNotification;
    } }), Object.defineProperty(t, "ConnectionErrors", { enumerable: !0, get: function() {
      return u.ConnectionErrors;
    } }), Object.defineProperty(t, "ConnectionError", { enumerable: !0, get: function() {
      return u.ConnectionError;
    } }), Object.defineProperty(t, "CancellationReceiverStrategy", { enumerable: !0, get: function() {
      return u.CancellationReceiverStrategy;
    } }), Object.defineProperty(t, "CancellationSenderStrategy", { enumerable: !0, get: function() {
      return u.CancellationSenderStrategy;
    } }), Object.defineProperty(t, "CancellationStrategy", { enumerable: !0, get: function() {
      return u.CancellationStrategy;
    } }), Object.defineProperty(t, "MessageStrategy", { enumerable: !0, get: function() {
      return u.MessageStrategy;
    } });
    const f = Xn();
    t.RAL = f.default;
  })(io)), io;
}
var xu;
function pR() {
  if (xu) return Fs;
  xu = 1, Object.defineProperty(Fs, "__esModule", { value: !0 });
  const t = Bc();
  class e extends t.AbstractMessageBuffer {
    constructor(c = "utf-8") {
      super(c), this.asciiDecoder = new TextDecoder("ascii");
    }
    emptyBuffer() {
      return e.emptyBuffer;
    }
    fromString(c, l) {
      return new TextEncoder().encode(c);
    }
    toString(c, l) {
      return l === "ascii" ? this.asciiDecoder.decode(c) : new TextDecoder(l).decode(c);
    }
    asNative(c, l) {
      return l === void 0 ? c : c.slice(0, l);
    }
    allocNative(c) {
      return new Uint8Array(c);
    }
  }
  e.emptyBuffer = new Uint8Array(0);
  class n {
    constructor(c) {
      this.socket = c, this._onData = new t.Emitter(), this._messageListener = (l) => {
        l.data.arrayBuffer().then((f) => {
          this._onData.fire(new Uint8Array(f));
        }, () => {
          (0, t.RAL)().console.error("Converting blob to array buffer failed.");
        });
      }, this.socket.addEventListener("message", this._messageListener);
    }
    onClose(c) {
      return this.socket.addEventListener("close", c), t.Disposable.create(() => this.socket.removeEventListener("close", c));
    }
    onError(c) {
      return this.socket.addEventListener("error", c), t.Disposable.create(() => this.socket.removeEventListener("error", c));
    }
    onEnd(c) {
      return this.socket.addEventListener("end", c), t.Disposable.create(() => this.socket.removeEventListener("end", c));
    }
    onData(c) {
      return this._onData.event(c);
    }
  }
  class r {
    constructor(c) {
      this.socket = c;
    }
    onClose(c) {
      return this.socket.addEventListener("close", c), t.Disposable.create(() => this.socket.removeEventListener("close", c));
    }
    onError(c) {
      return this.socket.addEventListener("error", c), t.Disposable.create(() => this.socket.removeEventListener("error", c));
    }
    onEnd(c) {
      return this.socket.addEventListener("end", c), t.Disposable.create(() => this.socket.removeEventListener("end", c));
    }
    write(c, l) {
      if (typeof c == "string") {
        if (l !== void 0 && l !== "utf-8")
          throw new Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${l}`);
        this.socket.send(c);
      } else
        this.socket.send(c);
      return Promise.resolve();
    }
    end() {
      this.socket.close();
    }
  }
  const i = new TextEncoder(), s = Object.freeze({
    messageBuffer: Object.freeze({
      create: (o) => new e(o)
    }),
    applicationJson: Object.freeze({
      encoder: Object.freeze({
        name: "application/json",
        encode: (o, c) => {
          if (c.charset !== "utf-8")
            throw new Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${c.charset}`);
          return Promise.resolve(i.encode(JSON.stringify(o, void 0, 0)));
        }
      }),
      decoder: Object.freeze({
        name: "application/json",
        decode: (o, c) => {
          if (!(o instanceof Uint8Array))
            throw new Error("In a Browser environments only Uint8Arrays are supported.");
          return Promise.resolve(JSON.parse(new TextDecoder(c.charset).decode(o)));
        }
      })
    }),
    stream: Object.freeze({
      asReadableStream: (o) => new n(o),
      asWritableStream: (o) => new r(o)
    }),
    console,
    timer: Object.freeze({
      setTimeout(o, c, ...l) {
        const u = setTimeout(o, c, ...l);
        return { dispose: () => clearTimeout(u) };
      },
      setImmediate(o, ...c) {
        const l = setTimeout(o, 0, ...c);
        return { dispose: () => clearTimeout(l) };
      },
      setInterval(o, c, ...l) {
        const u = setInterval(o, c, ...l);
        return { dispose: () => clearInterval(u) };
      }
    })
  });
  function a() {
    return s;
  }
  return (function(o) {
    function c() {
      t.RAL.install(s);
    }
    o.install = c;
  })(a || (a = {})), Fs.default = a, Fs;
}
var Du;
function Zr() {
  return Du || (Du = 1, (function(t) {
    var e = Cn && Cn.__createBinding || (Object.create ? (function(c, l, u, f) {
      f === void 0 && (f = u);
      var m = Object.getOwnPropertyDescriptor(l, u);
      (!m || ("get" in m ? !l.__esModule : m.writable || m.configurable)) && (m = { enumerable: !0, get: function() {
        return l[u];
      } }), Object.defineProperty(c, f, m);
    }) : (function(c, l, u, f) {
      f === void 0 && (f = u), c[f] = l[u];
    })), n = Cn && Cn.__exportStar || function(c, l) {
      for (var u in c) u !== "default" && !Object.prototype.hasOwnProperty.call(l, u) && e(l, c, u);
    };
    Object.defineProperty(t, "__esModule", { value: !0 }), t.createMessageConnection = t.BrowserMessageWriter = t.BrowserMessageReader = void 0, pR().default.install();
    const i = Bc();
    n(Bc(), t);
    class s extends i.AbstractMessageReader {
      constructor(l) {
        super(), this._onData = new i.Emitter(), this._messageListener = (u) => {
          this._onData.fire(u.data);
        }, l.addEventListener("error", (u) => this.fireError(u)), l.onmessage = this._messageListener;
      }
      listen(l) {
        return this._onData.event(l);
      }
    }
    t.BrowserMessageReader = s;
    class a extends i.AbstractMessageWriter {
      constructor(l) {
        super(), this.port = l, this.errorCount = 0, l.addEventListener("error", (u) => this.fireError(u));
      }
      write(l) {
        try {
          return this.port.postMessage(l), Promise.resolve();
        } catch (u) {
          return this.handleError(u, l), Promise.reject(u);
        }
      }
      handleError(l, u) {
        this.errorCount++, this.fireError(l, u, this.errorCount);
      }
      end() {
      }
    }
    t.BrowserMessageWriter = a;
    function o(c, l, u, f) {
      return u === void 0 && (u = i.NullLogger), i.ConnectionStrategy.is(f) && (f = { connectionStrategy: f }), (0, i.createMessageConnection)(c, l, u, f);
    }
    t.createMessageConnection = o;
  })(Cn)), Cn;
}
var ao, Mu;
function Fu() {
  return Mu || (Mu = 1, ao = Zr()), ao;
}
var wn = {};
const kl = /* @__PURE__ */ Qh(fT);
var He = {}, Gu;
function Te() {
  if (Gu) return He;
  Gu = 1, Object.defineProperty(He, "__esModule", { value: !0 }), He.ProtocolNotificationType = He.ProtocolNotificationType0 = He.ProtocolRequestType = He.ProtocolRequestType0 = He.RegistrationType = He.MessageDirection = void 0;
  const t = Zr();
  var e;
  (function(o) {
    o.clientToServer = "clientToServer", o.serverToClient = "serverToClient", o.both = "both";
  })(e || (He.MessageDirection = e = {}));
  class n {
    constructor(c) {
      this.method = c;
    }
  }
  He.RegistrationType = n;
  class r extends t.RequestType0 {
    constructor(c) {
      super(c);
    }
  }
  He.ProtocolRequestType0 = r;
  class i extends t.RequestType {
    constructor(c) {
      super(c, t.ParameterStructures.byName);
    }
  }
  He.ProtocolRequestType = i;
  class s extends t.NotificationType0 {
    constructor(c) {
      super(c);
    }
  }
  He.ProtocolNotificationType0 = s;
  class a extends t.NotificationType {
    constructor(c) {
      super(c, t.ParameterStructures.byName);
    }
  }
  return He.ProtocolNotificationType = a, He;
}
var oo = {}, we = {}, Uu;
function Cl() {
  if (Uu) return we;
  Uu = 1, Object.defineProperty(we, "__esModule", { value: !0 }), we.objectLiteral = we.typedArray = we.stringArray = we.array = we.func = we.error = we.number = we.string = we.boolean = void 0;
  function t(l) {
    return l === !0 || l === !1;
  }
  we.boolean = t;
  function e(l) {
    return typeof l == "string" || l instanceof String;
  }
  we.string = e;
  function n(l) {
    return typeof l == "number" || l instanceof Number;
  }
  we.number = n;
  function r(l) {
    return l instanceof Error;
  }
  we.error = r;
  function i(l) {
    return typeof l == "function";
  }
  we.func = i;
  function s(l) {
    return Array.isArray(l);
  }
  we.array = s;
  function a(l) {
    return s(l) && l.every((u) => e(u));
  }
  we.stringArray = a;
  function o(l, u) {
    return Array.isArray(l) && l.every(u);
  }
  we.typedArray = o;
  function c(l) {
    return l !== null && typeof l == "object";
  }
  return we.objectLiteral = c, we;
}
var Ei = {}, qu;
function mR() {
  if (qu) return Ei;
  qu = 1, Object.defineProperty(Ei, "__esModule", { value: !0 }), Ei.ImplementationRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "textDocument/implementation", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method);
  })(e || (Ei.ImplementationRequest = e = {})), Ei;
}
var Ai = {}, ju;
function gR() {
  if (ju) return Ai;
  ju = 1, Object.defineProperty(Ai, "__esModule", { value: !0 }), Ai.TypeDefinitionRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "textDocument/typeDefinition", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method);
  })(e || (Ai.TypeDefinitionRequest = e = {})), Ai;
}
var bn = {}, zu;
function yR() {
  if (zu) return bn;
  zu = 1, Object.defineProperty(bn, "__esModule", { value: !0 }), bn.DidChangeWorkspaceFoldersNotification = bn.WorkspaceFoldersRequest = void 0;
  const t = Te();
  var e;
  (function(r) {
    r.method = "workspace/workspaceFolders", r.messageDirection = t.MessageDirection.serverToClient, r.type = new t.ProtocolRequestType0(r.method);
  })(e || (bn.WorkspaceFoldersRequest = e = {}));
  var n;
  return (function(r) {
    r.method = "workspace/didChangeWorkspaceFolders", r.messageDirection = t.MessageDirection.clientToServer, r.type = new t.ProtocolNotificationType(r.method);
  })(n || (bn.DidChangeWorkspaceFoldersNotification = n = {})), bn;
}
var Si = {}, Bu;
function TR() {
  if (Bu) return Si;
  Bu = 1, Object.defineProperty(Si, "__esModule", { value: !0 }), Si.ConfigurationRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "workspace/configuration", n.messageDirection = t.MessageDirection.serverToClient, n.type = new t.ProtocolRequestType(n.method);
  })(e || (Si.ConfigurationRequest = e = {})), Si;
}
var _n = {}, Wu;
function RR() {
  if (Wu) return _n;
  Wu = 1, Object.defineProperty(_n, "__esModule", { value: !0 }), _n.ColorPresentationRequest = _n.DocumentColorRequest = void 0;
  const t = Te();
  var e;
  (function(r) {
    r.method = "textDocument/documentColor", r.messageDirection = t.MessageDirection.clientToServer, r.type = new t.ProtocolRequestType(r.method);
  })(e || (_n.DocumentColorRequest = e = {}));
  var n;
  return (function(r) {
    r.method = "textDocument/colorPresentation", r.messageDirection = t.MessageDirection.clientToServer, r.type = new t.ProtocolRequestType(r.method);
  })(n || (_n.ColorPresentationRequest = n = {})), _n;
}
var In = {}, Vu;
function vR() {
  if (Vu) return In;
  Vu = 1, Object.defineProperty(In, "__esModule", { value: !0 }), In.FoldingRangeRefreshRequest = In.FoldingRangeRequest = void 0;
  const t = Te();
  var e;
  (function(r) {
    r.method = "textDocument/foldingRange", r.messageDirection = t.MessageDirection.clientToServer, r.type = new t.ProtocolRequestType(r.method);
  })(e || (In.FoldingRangeRequest = e = {}));
  var n;
  return (function(r) {
    r.method = "workspace/foldingRange/refresh", r.messageDirection = t.MessageDirection.serverToClient, r.type = new t.ProtocolRequestType0(r.method);
  })(n || (In.FoldingRangeRefreshRequest = n = {})), In;
}
var ki = {}, Ku;
function ER() {
  if (Ku) return ki;
  Ku = 1, Object.defineProperty(ki, "__esModule", { value: !0 }), ki.DeclarationRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "textDocument/declaration", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method);
  })(e || (ki.DeclarationRequest = e = {})), ki;
}
var Ci = {}, Hu;
function AR() {
  if (Hu) return Ci;
  Hu = 1, Object.defineProperty(Ci, "__esModule", { value: !0 }), Ci.SelectionRangeRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "textDocument/selectionRange", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method);
  })(e || (Ci.SelectionRangeRequest = e = {})), Ci;
}
var qt = {}, Yu;
function SR() {
  if (Yu) return qt;
  Yu = 1, Object.defineProperty(qt, "__esModule", { value: !0 }), qt.WorkDoneProgressCancelNotification = qt.WorkDoneProgressCreateRequest = qt.WorkDoneProgress = void 0;
  const t = Zr(), e = Te();
  var n;
  (function(s) {
    s.type = new t.ProgressType();
    function a(o) {
      return o === s.type;
    }
    s.is = a;
  })(n || (qt.WorkDoneProgress = n = {}));
  var r;
  (function(s) {
    s.method = "window/workDoneProgress/create", s.messageDirection = e.MessageDirection.serverToClient, s.type = new e.ProtocolRequestType(s.method);
  })(r || (qt.WorkDoneProgressCreateRequest = r = {}));
  var i;
  return (function(s) {
    s.method = "window/workDoneProgress/cancel", s.messageDirection = e.MessageDirection.clientToServer, s.type = new e.ProtocolNotificationType(s.method);
  })(i || (qt.WorkDoneProgressCancelNotification = i = {})), qt;
}
var jt = {}, Xu;
function kR() {
  if (Xu) return jt;
  Xu = 1, Object.defineProperty(jt, "__esModule", { value: !0 }), jt.CallHierarchyOutgoingCallsRequest = jt.CallHierarchyIncomingCallsRequest = jt.CallHierarchyPrepareRequest = void 0;
  const t = Te();
  var e;
  (function(i) {
    i.method = "textDocument/prepareCallHierarchy", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(e || (jt.CallHierarchyPrepareRequest = e = {}));
  var n;
  (function(i) {
    i.method = "callHierarchy/incomingCalls", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(n || (jt.CallHierarchyIncomingCallsRequest = n = {}));
  var r;
  return (function(i) {
    i.method = "callHierarchy/outgoingCalls", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(r || (jt.CallHierarchyOutgoingCallsRequest = r = {})), jt;
}
var Ye = {}, Ju;
function CR() {
  if (Ju) return Ye;
  Ju = 1, Object.defineProperty(Ye, "__esModule", { value: !0 }), Ye.SemanticTokensRefreshRequest = Ye.SemanticTokensRangeRequest = Ye.SemanticTokensDeltaRequest = Ye.SemanticTokensRequest = Ye.SemanticTokensRegistrationType = Ye.TokenFormat = void 0;
  const t = Te();
  var e;
  (function(o) {
    o.Relative = "relative";
  })(e || (Ye.TokenFormat = e = {}));
  var n;
  (function(o) {
    o.method = "textDocument/semanticTokens", o.type = new t.RegistrationType(o.method);
  })(n || (Ye.SemanticTokensRegistrationType = n = {}));
  var r;
  (function(o) {
    o.method = "textDocument/semanticTokens/full", o.messageDirection = t.MessageDirection.clientToServer, o.type = new t.ProtocolRequestType(o.method), o.registrationMethod = n.method;
  })(r || (Ye.SemanticTokensRequest = r = {}));
  var i;
  (function(o) {
    o.method = "textDocument/semanticTokens/full/delta", o.messageDirection = t.MessageDirection.clientToServer, o.type = new t.ProtocolRequestType(o.method), o.registrationMethod = n.method;
  })(i || (Ye.SemanticTokensDeltaRequest = i = {}));
  var s;
  (function(o) {
    o.method = "textDocument/semanticTokens/range", o.messageDirection = t.MessageDirection.clientToServer, o.type = new t.ProtocolRequestType(o.method), o.registrationMethod = n.method;
  })(s || (Ye.SemanticTokensRangeRequest = s = {}));
  var a;
  return (function(o) {
    o.method = "workspace/semanticTokens/refresh", o.messageDirection = t.MessageDirection.serverToClient, o.type = new t.ProtocolRequestType0(o.method);
  })(a || (Ye.SemanticTokensRefreshRequest = a = {})), Ye;
}
var Ni = {}, Qu;
function NR() {
  if (Qu) return Ni;
  Qu = 1, Object.defineProperty(Ni, "__esModule", { value: !0 }), Ni.ShowDocumentRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "window/showDocument", n.messageDirection = t.MessageDirection.serverToClient, n.type = new t.ProtocolRequestType(n.method);
  })(e || (Ni.ShowDocumentRequest = e = {})), Ni;
}
var wi = {}, Zu;
function wR() {
  if (Zu) return wi;
  Zu = 1, Object.defineProperty(wi, "__esModule", { value: !0 }), wi.LinkedEditingRangeRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "textDocument/linkedEditingRange", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method);
  })(e || (wi.LinkedEditingRangeRequest = e = {})), wi;
}
var Me = {}, ed;
function bR() {
  if (ed) return Me;
  ed = 1, Object.defineProperty(Me, "__esModule", { value: !0 }), Me.WillDeleteFilesRequest = Me.DidDeleteFilesNotification = Me.DidRenameFilesNotification = Me.WillRenameFilesRequest = Me.DidCreateFilesNotification = Me.WillCreateFilesRequest = Me.FileOperationPatternKind = void 0;
  const t = Te();
  var e;
  (function(c) {
    c.file = "file", c.folder = "folder";
  })(e || (Me.FileOperationPatternKind = e = {}));
  var n;
  (function(c) {
    c.method = "workspace/willCreateFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolRequestType(c.method);
  })(n || (Me.WillCreateFilesRequest = n = {}));
  var r;
  (function(c) {
    c.method = "workspace/didCreateFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolNotificationType(c.method);
  })(r || (Me.DidCreateFilesNotification = r = {}));
  var i;
  (function(c) {
    c.method = "workspace/willRenameFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolRequestType(c.method);
  })(i || (Me.WillRenameFilesRequest = i = {}));
  var s;
  (function(c) {
    c.method = "workspace/didRenameFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolNotificationType(c.method);
  })(s || (Me.DidRenameFilesNotification = s = {}));
  var a;
  (function(c) {
    c.method = "workspace/didDeleteFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolNotificationType(c.method);
  })(a || (Me.DidDeleteFilesNotification = a = {}));
  var o;
  return (function(c) {
    c.method = "workspace/willDeleteFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolRequestType(c.method);
  })(o || (Me.WillDeleteFilesRequest = o = {})), Me;
}
var zt = {}, td;
function _R() {
  if (td) return zt;
  td = 1, Object.defineProperty(zt, "__esModule", { value: !0 }), zt.MonikerRequest = zt.MonikerKind = zt.UniquenessLevel = void 0;
  const t = Te();
  var e;
  (function(i) {
    i.document = "document", i.project = "project", i.group = "group", i.scheme = "scheme", i.global = "global";
  })(e || (zt.UniquenessLevel = e = {}));
  var n;
  (function(i) {
    i.$import = "import", i.$export = "export", i.local = "local";
  })(n || (zt.MonikerKind = n = {}));
  var r;
  return (function(i) {
    i.method = "textDocument/moniker", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(r || (zt.MonikerRequest = r = {})), zt;
}
var Bt = {}, nd;
function IR() {
  if (nd) return Bt;
  nd = 1, Object.defineProperty(Bt, "__esModule", { value: !0 }), Bt.TypeHierarchySubtypesRequest = Bt.TypeHierarchySupertypesRequest = Bt.TypeHierarchyPrepareRequest = void 0;
  const t = Te();
  var e;
  (function(i) {
    i.method = "textDocument/prepareTypeHierarchy", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(e || (Bt.TypeHierarchyPrepareRequest = e = {}));
  var n;
  (function(i) {
    i.method = "typeHierarchy/supertypes", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(n || (Bt.TypeHierarchySupertypesRequest = n = {}));
  var r;
  return (function(i) {
    i.method = "typeHierarchy/subtypes", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(r || (Bt.TypeHierarchySubtypesRequest = r = {})), Bt;
}
var Pn = {}, rd;
function PR() {
  if (rd) return Pn;
  rd = 1, Object.defineProperty(Pn, "__esModule", { value: !0 }), Pn.InlineValueRefreshRequest = Pn.InlineValueRequest = void 0;
  const t = Te();
  var e;
  (function(r) {
    r.method = "textDocument/inlineValue", r.messageDirection = t.MessageDirection.clientToServer, r.type = new t.ProtocolRequestType(r.method);
  })(e || (Pn.InlineValueRequest = e = {}));
  var n;
  return (function(r) {
    r.method = "workspace/inlineValue/refresh", r.messageDirection = t.MessageDirection.serverToClient, r.type = new t.ProtocolRequestType0(r.method);
  })(n || (Pn.InlineValueRefreshRequest = n = {})), Pn;
}
var Wt = {}, id;
function $R() {
  if (id) return Wt;
  id = 1, Object.defineProperty(Wt, "__esModule", { value: !0 }), Wt.InlayHintRefreshRequest = Wt.InlayHintResolveRequest = Wt.InlayHintRequest = void 0;
  const t = Te();
  var e;
  (function(i) {
    i.method = "textDocument/inlayHint", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(e || (Wt.InlayHintRequest = e = {}));
  var n;
  (function(i) {
    i.method = "inlayHint/resolve", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method);
  })(n || (Wt.InlayHintResolveRequest = n = {}));
  var r;
  return (function(i) {
    i.method = "workspace/inlayHint/refresh", i.messageDirection = t.MessageDirection.serverToClient, i.type = new t.ProtocolRequestType0(i.method);
  })(r || (Wt.InlayHintRefreshRequest = r = {})), Wt;
}
var ot = {}, sd;
function LR() {
  if (sd) return ot;
  sd = 1, Object.defineProperty(ot, "__esModule", { value: !0 }), ot.DiagnosticRefreshRequest = ot.WorkspaceDiagnosticRequest = ot.DocumentDiagnosticRequest = ot.DocumentDiagnosticReportKind = ot.DiagnosticServerCancellationData = void 0;
  const t = Zr(), e = Cl(), n = Te();
  var r;
  (function(c) {
    function l(u) {
      const f = u;
      return f && e.boolean(f.retriggerRequest);
    }
    c.is = l;
  })(r || (ot.DiagnosticServerCancellationData = r = {}));
  var i;
  (function(c) {
    c.Full = "full", c.Unchanged = "unchanged";
  })(i || (ot.DocumentDiagnosticReportKind = i = {}));
  var s;
  (function(c) {
    c.method = "textDocument/diagnostic", c.messageDirection = n.MessageDirection.clientToServer, c.type = new n.ProtocolRequestType(c.method), c.partialResult = new t.ProgressType();
  })(s || (ot.DocumentDiagnosticRequest = s = {}));
  var a;
  (function(c) {
    c.method = "workspace/diagnostic", c.messageDirection = n.MessageDirection.clientToServer, c.type = new n.ProtocolRequestType(c.method), c.partialResult = new t.ProgressType();
  })(a || (ot.WorkspaceDiagnosticRequest = a = {}));
  var o;
  return (function(c) {
    c.method = "workspace/diagnostic/refresh", c.messageDirection = n.MessageDirection.serverToClient, c.type = new n.ProtocolRequestType0(c.method);
  })(o || (ot.DiagnosticRefreshRequest = o = {})), ot;
}
var pe = {}, ad;
function OR() {
  if (ad) return pe;
  ad = 1, Object.defineProperty(pe, "__esModule", { value: !0 }), pe.DidCloseNotebookDocumentNotification = pe.DidSaveNotebookDocumentNotification = pe.DidChangeNotebookDocumentNotification = pe.NotebookCellArrayChange = pe.DidOpenNotebookDocumentNotification = pe.NotebookDocumentSyncRegistrationType = pe.NotebookDocument = pe.NotebookCell = pe.ExecutionSummary = pe.NotebookCellKind = void 0;
  const t = kl, e = Cl(), n = Te();
  var r;
  (function(p) {
    p.Markup = 1, p.Code = 2;
    function A(b) {
      return b === 1 || b === 2;
    }
    p.is = A;
  })(r || (pe.NotebookCellKind = r = {}));
  var i;
  (function(p) {
    function A(C, N) {
      const k = { executionOrder: C };
      return (N === !0 || N === !1) && (k.success = N), k;
    }
    p.create = A;
    function b(C) {
      const N = C;
      return e.objectLiteral(N) && t.uinteger.is(N.executionOrder) && (N.success === void 0 || e.boolean(N.success));
    }
    p.is = b;
    function I(C, N) {
      return C === N ? !0 : C == null || N === null || N === void 0 ? !1 : C.executionOrder === N.executionOrder && C.success === N.success;
    }
    p.equals = I;
  })(i || (pe.ExecutionSummary = i = {}));
  var s;
  (function(p) {
    function A(N, k) {
      return { kind: N, document: k };
    }
    p.create = A;
    function b(N) {
      const k = N;
      return e.objectLiteral(k) && r.is(k.kind) && t.DocumentUri.is(k.document) && (k.metadata === void 0 || e.objectLiteral(k.metadata));
    }
    p.is = b;
    function I(N, k) {
      const P = /* @__PURE__ */ new Set();
      return N.document !== k.document && P.add("document"), N.kind !== k.kind && P.add("kind"), N.executionSummary !== k.executionSummary && P.add("executionSummary"), (N.metadata !== void 0 || k.metadata !== void 0) && !C(N.metadata, k.metadata) && P.add("metadata"), (N.executionSummary !== void 0 || k.executionSummary !== void 0) && !i.equals(N.executionSummary, k.executionSummary) && P.add("executionSummary"), P;
    }
    p.diff = I;
    function C(N, k) {
      if (N === k)
        return !0;
      if (N == null || k === null || k === void 0 || typeof N != typeof k || typeof N != "object")
        return !1;
      const P = Array.isArray(N), H = Array.isArray(k);
      if (P !== H)
        return !1;
      if (P && H) {
        if (N.length !== k.length)
          return !1;
        for (let K = 0; K < N.length; K++)
          if (!C(N[K], k[K]))
            return !1;
      }
      if (e.objectLiteral(N) && e.objectLiteral(k)) {
        const K = Object.keys(N), J = Object.keys(k);
        if (K.length !== J.length || (K.sort(), J.sort(), !C(K, J)))
          return !1;
        for (let oe = 0; oe < K.length; oe++) {
          const ue = K[oe];
          if (!C(N[ue], k[ue]))
            return !1;
        }
      }
      return !0;
    }
  })(s || (pe.NotebookCell = s = {}));
  var a;
  (function(p) {
    function A(I, C, N, k) {
      return { uri: I, notebookType: C, version: N, cells: k };
    }
    p.create = A;
    function b(I) {
      const C = I;
      return e.objectLiteral(C) && e.string(C.uri) && t.integer.is(C.version) && e.typedArray(C.cells, s.is);
    }
    p.is = b;
  })(a || (pe.NotebookDocument = a = {}));
  var o;
  (function(p) {
    p.method = "notebookDocument/sync", p.messageDirection = n.MessageDirection.clientToServer, p.type = new n.RegistrationType(p.method);
  })(o || (pe.NotebookDocumentSyncRegistrationType = o = {}));
  var c;
  (function(p) {
    p.method = "notebookDocument/didOpen", p.messageDirection = n.MessageDirection.clientToServer, p.type = new n.ProtocolNotificationType(p.method), p.registrationMethod = o.method;
  })(c || (pe.DidOpenNotebookDocumentNotification = c = {}));
  var l;
  (function(p) {
    function A(I) {
      const C = I;
      return e.objectLiteral(C) && t.uinteger.is(C.start) && t.uinteger.is(C.deleteCount) && (C.cells === void 0 || e.typedArray(C.cells, s.is));
    }
    p.is = A;
    function b(I, C, N) {
      const k = { start: I, deleteCount: C };
      return N !== void 0 && (k.cells = N), k;
    }
    p.create = b;
  })(l || (pe.NotebookCellArrayChange = l = {}));
  var u;
  (function(p) {
    p.method = "notebookDocument/didChange", p.messageDirection = n.MessageDirection.clientToServer, p.type = new n.ProtocolNotificationType(p.method), p.registrationMethod = o.method;
  })(u || (pe.DidChangeNotebookDocumentNotification = u = {}));
  var f;
  (function(p) {
    p.method = "notebookDocument/didSave", p.messageDirection = n.MessageDirection.clientToServer, p.type = new n.ProtocolNotificationType(p.method), p.registrationMethod = o.method;
  })(f || (pe.DidSaveNotebookDocumentNotification = f = {}));
  var m;
  return (function(p) {
    p.method = "notebookDocument/didClose", p.messageDirection = n.MessageDirection.clientToServer, p.type = new n.ProtocolNotificationType(p.method), p.registrationMethod = o.method;
  })(m || (pe.DidCloseNotebookDocumentNotification = m = {})), pe;
}
var bi = {}, od;
function xR() {
  if (od) return bi;
  od = 1, Object.defineProperty(bi, "__esModule", { value: !0 }), bi.InlineCompletionRequest = void 0;
  const t = Te();
  var e;
  return (function(n) {
    n.method = "textDocument/inlineCompletion", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method);
  })(e || (bi.InlineCompletionRequest = e = {})), bi;
}
var cd;
function DR() {
  return cd || (cd = 1, (function(t) {
    Object.defineProperty(t, "__esModule", { value: !0 }), t.WorkspaceSymbolRequest = t.CodeActionResolveRequest = t.CodeActionRequest = t.DocumentSymbolRequest = t.DocumentHighlightRequest = t.ReferencesRequest = t.DefinitionRequest = t.SignatureHelpRequest = t.SignatureHelpTriggerKind = t.HoverRequest = t.CompletionResolveRequest = t.CompletionRequest = t.CompletionTriggerKind = t.PublishDiagnosticsNotification = t.WatchKind = t.RelativePattern = t.FileChangeType = t.DidChangeWatchedFilesNotification = t.WillSaveTextDocumentWaitUntilRequest = t.WillSaveTextDocumentNotification = t.TextDocumentSaveReason = t.DidSaveTextDocumentNotification = t.DidCloseTextDocumentNotification = t.DidChangeTextDocumentNotification = t.TextDocumentContentChangeEvent = t.DidOpenTextDocumentNotification = t.TextDocumentSyncKind = t.TelemetryEventNotification = t.LogMessageNotification = t.ShowMessageRequest = t.ShowMessageNotification = t.MessageType = t.DidChangeConfigurationNotification = t.ExitNotification = t.ShutdownRequest = t.InitializedNotification = t.InitializeErrorCodes = t.InitializeRequest = t.WorkDoneProgressOptions = t.TextDocumentRegistrationOptions = t.StaticRegistrationOptions = t.PositionEncodingKind = t.FailureHandlingKind = t.ResourceOperationKind = t.UnregistrationRequest = t.RegistrationRequest = t.DocumentSelector = t.NotebookCellTextDocumentFilter = t.NotebookDocumentFilter = t.TextDocumentFilter = void 0, t.MonikerRequest = t.MonikerKind = t.UniquenessLevel = t.WillDeleteFilesRequest = t.DidDeleteFilesNotification = t.WillRenameFilesRequest = t.DidRenameFilesNotification = t.WillCreateFilesRequest = t.DidCreateFilesNotification = t.FileOperationPatternKind = t.LinkedEditingRangeRequest = t.ShowDocumentRequest = t.SemanticTokensRegistrationType = t.SemanticTokensRefreshRequest = t.SemanticTokensRangeRequest = t.SemanticTokensDeltaRequest = t.SemanticTokensRequest = t.TokenFormat = t.CallHierarchyPrepareRequest = t.CallHierarchyOutgoingCallsRequest = t.CallHierarchyIncomingCallsRequest = t.WorkDoneProgressCancelNotification = t.WorkDoneProgressCreateRequest = t.WorkDoneProgress = t.SelectionRangeRequest = t.DeclarationRequest = t.FoldingRangeRefreshRequest = t.FoldingRangeRequest = t.ColorPresentationRequest = t.DocumentColorRequest = t.ConfigurationRequest = t.DidChangeWorkspaceFoldersNotification = t.WorkspaceFoldersRequest = t.TypeDefinitionRequest = t.ImplementationRequest = t.ApplyWorkspaceEditRequest = t.ExecuteCommandRequest = t.PrepareRenameRequest = t.RenameRequest = t.PrepareSupportDefaultBehavior = t.DocumentOnTypeFormattingRequest = t.DocumentRangesFormattingRequest = t.DocumentRangeFormattingRequest = t.DocumentFormattingRequest = t.DocumentLinkResolveRequest = t.DocumentLinkRequest = t.CodeLensRefreshRequest = t.CodeLensResolveRequest = t.CodeLensRequest = t.WorkspaceSymbolResolveRequest = void 0, t.InlineCompletionRequest = t.DidCloseNotebookDocumentNotification = t.DidSaveNotebookDocumentNotification = t.DidChangeNotebookDocumentNotification = t.NotebookCellArrayChange = t.DidOpenNotebookDocumentNotification = t.NotebookDocumentSyncRegistrationType = t.NotebookDocument = t.NotebookCell = t.ExecutionSummary = t.NotebookCellKind = t.DiagnosticRefreshRequest = t.WorkspaceDiagnosticRequest = t.DocumentDiagnosticRequest = t.DocumentDiagnosticReportKind = t.DiagnosticServerCancellationData = t.InlayHintRefreshRequest = t.InlayHintResolveRequest = t.InlayHintRequest = t.InlineValueRefreshRequest = t.InlineValueRequest = t.TypeHierarchySupertypesRequest = t.TypeHierarchySubtypesRequest = t.TypeHierarchyPrepareRequest = void 0;
    const e = Te(), n = kl, r = Cl(), i = mR();
    Object.defineProperty(t, "ImplementationRequest", { enumerable: !0, get: function() {
      return i.ImplementationRequest;
    } });
    const s = gR();
    Object.defineProperty(t, "TypeDefinitionRequest", { enumerable: !0, get: function() {
      return s.TypeDefinitionRequest;
    } });
    const a = yR();
    Object.defineProperty(t, "WorkspaceFoldersRequest", { enumerable: !0, get: function() {
      return a.WorkspaceFoldersRequest;
    } }), Object.defineProperty(t, "DidChangeWorkspaceFoldersNotification", { enumerable: !0, get: function() {
      return a.DidChangeWorkspaceFoldersNotification;
    } });
    const o = TR();
    Object.defineProperty(t, "ConfigurationRequest", { enumerable: !0, get: function() {
      return o.ConfigurationRequest;
    } });
    const c = RR();
    Object.defineProperty(t, "DocumentColorRequest", { enumerable: !0, get: function() {
      return c.DocumentColorRequest;
    } }), Object.defineProperty(t, "ColorPresentationRequest", { enumerable: !0, get: function() {
      return c.ColorPresentationRequest;
    } });
    const l = vR();
    Object.defineProperty(t, "FoldingRangeRequest", { enumerable: !0, get: function() {
      return l.FoldingRangeRequest;
    } }), Object.defineProperty(t, "FoldingRangeRefreshRequest", { enumerable: !0, get: function() {
      return l.FoldingRangeRefreshRequest;
    } });
    const u = ER();
    Object.defineProperty(t, "DeclarationRequest", { enumerable: !0, get: function() {
      return u.DeclarationRequest;
    } });
    const f = AR();
    Object.defineProperty(t, "SelectionRangeRequest", { enumerable: !0, get: function() {
      return f.SelectionRangeRequest;
    } });
    const m = SR();
    Object.defineProperty(t, "WorkDoneProgress", { enumerable: !0, get: function() {
      return m.WorkDoneProgress;
    } }), Object.defineProperty(t, "WorkDoneProgressCreateRequest", { enumerable: !0, get: function() {
      return m.WorkDoneProgressCreateRequest;
    } }), Object.defineProperty(t, "WorkDoneProgressCancelNotification", { enumerable: !0, get: function() {
      return m.WorkDoneProgressCancelNotification;
    } });
    const p = kR();
    Object.defineProperty(t, "CallHierarchyIncomingCallsRequest", { enumerable: !0, get: function() {
      return p.CallHierarchyIncomingCallsRequest;
    } }), Object.defineProperty(t, "CallHierarchyOutgoingCallsRequest", { enumerable: !0, get: function() {
      return p.CallHierarchyOutgoingCallsRequest;
    } }), Object.defineProperty(t, "CallHierarchyPrepareRequest", { enumerable: !0, get: function() {
      return p.CallHierarchyPrepareRequest;
    } });
    const A = CR();
    Object.defineProperty(t, "TokenFormat", { enumerable: !0, get: function() {
      return A.TokenFormat;
    } }), Object.defineProperty(t, "SemanticTokensRequest", { enumerable: !0, get: function() {
      return A.SemanticTokensRequest;
    } }), Object.defineProperty(t, "SemanticTokensDeltaRequest", { enumerable: !0, get: function() {
      return A.SemanticTokensDeltaRequest;
    } }), Object.defineProperty(t, "SemanticTokensRangeRequest", { enumerable: !0, get: function() {
      return A.SemanticTokensRangeRequest;
    } }), Object.defineProperty(t, "SemanticTokensRefreshRequest", { enumerable: !0, get: function() {
      return A.SemanticTokensRefreshRequest;
    } }), Object.defineProperty(t, "SemanticTokensRegistrationType", { enumerable: !0, get: function() {
      return A.SemanticTokensRegistrationType;
    } });
    const b = NR();
    Object.defineProperty(t, "ShowDocumentRequest", { enumerable: !0, get: function() {
      return b.ShowDocumentRequest;
    } });
    const I = wR();
    Object.defineProperty(t, "LinkedEditingRangeRequest", { enumerable: !0, get: function() {
      return I.LinkedEditingRangeRequest;
    } });
    const C = bR();
    Object.defineProperty(t, "FileOperationPatternKind", { enumerable: !0, get: function() {
      return C.FileOperationPatternKind;
    } }), Object.defineProperty(t, "DidCreateFilesNotification", { enumerable: !0, get: function() {
      return C.DidCreateFilesNotification;
    } }), Object.defineProperty(t, "WillCreateFilesRequest", { enumerable: !0, get: function() {
      return C.WillCreateFilesRequest;
    } }), Object.defineProperty(t, "DidRenameFilesNotification", { enumerable: !0, get: function() {
      return C.DidRenameFilesNotification;
    } }), Object.defineProperty(t, "WillRenameFilesRequest", { enumerable: !0, get: function() {
      return C.WillRenameFilesRequest;
    } }), Object.defineProperty(t, "DidDeleteFilesNotification", { enumerable: !0, get: function() {
      return C.DidDeleteFilesNotification;
    } }), Object.defineProperty(t, "WillDeleteFilesRequest", { enumerable: !0, get: function() {
      return C.WillDeleteFilesRequest;
    } });
    const N = _R();
    Object.defineProperty(t, "UniquenessLevel", { enumerable: !0, get: function() {
      return N.UniquenessLevel;
    } }), Object.defineProperty(t, "MonikerKind", { enumerable: !0, get: function() {
      return N.MonikerKind;
    } }), Object.defineProperty(t, "MonikerRequest", { enumerable: !0, get: function() {
      return N.MonikerRequest;
    } });
    const k = IR();
    Object.defineProperty(t, "TypeHierarchyPrepareRequest", { enumerable: !0, get: function() {
      return k.TypeHierarchyPrepareRequest;
    } }), Object.defineProperty(t, "TypeHierarchySubtypesRequest", { enumerable: !0, get: function() {
      return k.TypeHierarchySubtypesRequest;
    } }), Object.defineProperty(t, "TypeHierarchySupertypesRequest", { enumerable: !0, get: function() {
      return k.TypeHierarchySupertypesRequest;
    } });
    const P = PR();
    Object.defineProperty(t, "InlineValueRequest", { enumerable: !0, get: function() {
      return P.InlineValueRequest;
    } }), Object.defineProperty(t, "InlineValueRefreshRequest", { enumerable: !0, get: function() {
      return P.InlineValueRefreshRequest;
    } });
    const H = $R();
    Object.defineProperty(t, "InlayHintRequest", { enumerable: !0, get: function() {
      return H.InlayHintRequest;
    } }), Object.defineProperty(t, "InlayHintResolveRequest", { enumerable: !0, get: function() {
      return H.InlayHintResolveRequest;
    } }), Object.defineProperty(t, "InlayHintRefreshRequest", { enumerable: !0, get: function() {
      return H.InlayHintRefreshRequest;
    } });
    const K = LR();
    Object.defineProperty(t, "DiagnosticServerCancellationData", { enumerable: !0, get: function() {
      return K.DiagnosticServerCancellationData;
    } }), Object.defineProperty(t, "DocumentDiagnosticReportKind", { enumerable: !0, get: function() {
      return K.DocumentDiagnosticReportKind;
    } }), Object.defineProperty(t, "DocumentDiagnosticRequest", { enumerable: !0, get: function() {
      return K.DocumentDiagnosticRequest;
    } }), Object.defineProperty(t, "WorkspaceDiagnosticRequest", { enumerable: !0, get: function() {
      return K.WorkspaceDiagnosticRequest;
    } }), Object.defineProperty(t, "DiagnosticRefreshRequest", { enumerable: !0, get: function() {
      return K.DiagnosticRefreshRequest;
    } });
    const J = OR();
    Object.defineProperty(t, "NotebookCellKind", { enumerable: !0, get: function() {
      return J.NotebookCellKind;
    } }), Object.defineProperty(t, "ExecutionSummary", { enumerable: !0, get: function() {
      return J.ExecutionSummary;
    } }), Object.defineProperty(t, "NotebookCell", { enumerable: !0, get: function() {
      return J.NotebookCell;
    } }), Object.defineProperty(t, "NotebookDocument", { enumerable: !0, get: function() {
      return J.NotebookDocument;
    } }), Object.defineProperty(t, "NotebookDocumentSyncRegistrationType", { enumerable: !0, get: function() {
      return J.NotebookDocumentSyncRegistrationType;
    } }), Object.defineProperty(t, "DidOpenNotebookDocumentNotification", { enumerable: !0, get: function() {
      return J.DidOpenNotebookDocumentNotification;
    } }), Object.defineProperty(t, "NotebookCellArrayChange", { enumerable: !0, get: function() {
      return J.NotebookCellArrayChange;
    } }), Object.defineProperty(t, "DidChangeNotebookDocumentNotification", { enumerable: !0, get: function() {
      return J.DidChangeNotebookDocumentNotification;
    } }), Object.defineProperty(t, "DidSaveNotebookDocumentNotification", { enumerable: !0, get: function() {
      return J.DidSaveNotebookDocumentNotification;
    } }), Object.defineProperty(t, "DidCloseNotebookDocumentNotification", { enumerable: !0, get: function() {
      return J.DidCloseNotebookDocumentNotification;
    } });
    const oe = xR();
    Object.defineProperty(t, "InlineCompletionRequest", { enumerable: !0, get: function() {
      return oe.InlineCompletionRequest;
    } });
    var ue;
    (function(d) {
      function ke(Ce) {
        const V = Ce;
        return r.string(V) || r.string(V.language) || r.string(V.scheme) || r.string(V.pattern);
      }
      d.is = ke;
    })(ue || (t.TextDocumentFilter = ue = {}));
    var de;
    (function(d) {
      function ke(Ce) {
        const V = Ce;
        return r.objectLiteral(V) && (r.string(V.notebookType) || r.string(V.scheme) || r.string(V.pattern));
      }
      d.is = ke;
    })(de || (t.NotebookDocumentFilter = de = {}));
    var _;
    (function(d) {
      function ke(Ce) {
        const V = Ce;
        return r.objectLiteral(V) && (r.string(V.notebook) || de.is(V.notebook)) && (V.language === void 0 || r.string(V.language));
      }
      d.is = ke;
    })(_ || (t.NotebookCellTextDocumentFilter = _ = {}));
    var T;
    (function(d) {
      function ke(Ce) {
        if (!Array.isArray(Ce))
          return !1;
        for (let V of Ce)
          if (!r.string(V) && !ue.is(V) && !_.is(V))
            return !1;
        return !0;
      }
      d.is = ke;
    })(T || (t.DocumentSelector = T = {}));
    var g;
    (function(d) {
      d.method = "client/registerCapability", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolRequestType(d.method);
    })(g || (t.RegistrationRequest = g = {}));
    var S;
    (function(d) {
      d.method = "client/unregisterCapability", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolRequestType(d.method);
    })(S || (t.UnregistrationRequest = S = {}));
    var y;
    (function(d) {
      d.Create = "create", d.Rename = "rename", d.Delete = "delete";
    })(y || (t.ResourceOperationKind = y = {}));
    var R;
    (function(d) {
      d.Abort = "abort", d.Transactional = "transactional", d.TextOnlyTransactional = "textOnlyTransactional", d.Undo = "undo";
    })(R || (t.FailureHandlingKind = R = {}));
    var E;
    (function(d) {
      d.UTF8 = "utf-8", d.UTF16 = "utf-16", d.UTF32 = "utf-32";
    })(E || (t.PositionEncodingKind = E = {}));
    var O;
    (function(d) {
      function ke(Ce) {
        const V = Ce;
        return V && r.string(V.id) && V.id.length > 0;
      }
      d.hasId = ke;
    })(O || (t.StaticRegistrationOptions = O = {}));
    var D;
    (function(d) {
      function ke(Ce) {
        const V = Ce;
        return V && (V.documentSelector === null || T.is(V.documentSelector));
      }
      d.is = ke;
    })(D || (t.TextDocumentRegistrationOptions = D = {}));
    var x;
    (function(d) {
      function ke(V) {
        const h = V;
        return r.objectLiteral(h) && (h.workDoneProgress === void 0 || r.boolean(h.workDoneProgress));
      }
      d.is = ke;
      function Ce(V) {
        const h = V;
        return h && r.boolean(h.workDoneProgress);
      }
      d.hasWorkDoneProgress = Ce;
    })(x || (t.WorkDoneProgressOptions = x = {}));
    var j;
    (function(d) {
      d.method = "initialize", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(j || (t.InitializeRequest = j = {}));
    var G;
    (function(d) {
      d.unknownProtocolVersion = 1;
    })(G || (t.InitializeErrorCodes = G = {}));
    var ie;
    (function(d) {
      d.method = "initialized", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(ie || (t.InitializedNotification = ie = {}));
    var B;
    (function(d) {
      d.method = "shutdown", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType0(d.method);
    })(B || (t.ShutdownRequest = B = {}));
    var ne;
    (function(d) {
      d.method = "exit", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType0(d.method);
    })(ne || (t.ExitNotification = ne = {}));
    var Oe;
    (function(d) {
      d.method = "workspace/didChangeConfiguration", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(Oe || (t.DidChangeConfigurationNotification = Oe = {}));
    var Re;
    (function(d) {
      d.Error = 1, d.Warning = 2, d.Info = 3, d.Log = 4, d.Debug = 5;
    })(Re || (t.MessageType = Re = {}));
    var fe;
    (function(d) {
      d.method = "window/showMessage", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolNotificationType(d.method);
    })(fe || (t.ShowMessageNotification = fe = {}));
    var Ie;
    (function(d) {
      d.method = "window/showMessageRequest", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolRequestType(d.method);
    })(Ie || (t.ShowMessageRequest = Ie = {}));
    var xe;
    (function(d) {
      d.method = "window/logMessage", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolNotificationType(d.method);
    })(xe || (t.LogMessageNotification = xe = {}));
    var be;
    (function(d) {
      d.method = "telemetry/event", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolNotificationType(d.method);
    })(be || (t.TelemetryEventNotification = be = {}));
    var Z;
    (function(d) {
      d.None = 0, d.Full = 1, d.Incremental = 2;
    })(Z || (t.TextDocumentSyncKind = Z = {}));
    var at;
    (function(d) {
      d.method = "textDocument/didOpen", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(at || (t.DidOpenTextDocumentNotification = at = {}));
    var ve;
    (function(d) {
      function ke(V) {
        let h = V;
        return h != null && typeof h.text == "string" && h.range !== void 0 && (h.rangeLength === void 0 || typeof h.rangeLength == "number");
      }
      d.isIncremental = ke;
      function Ce(V) {
        let h = V;
        return h != null && typeof h.text == "string" && h.range === void 0 && h.rangeLength === void 0;
      }
      d.isFull = Ce;
    })(ve || (t.TextDocumentContentChangeEvent = ve = {}));
    var Tt;
    (function(d) {
      d.method = "textDocument/didChange", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(Tt || (t.DidChangeTextDocumentNotification = Tt = {}));
    var Zn;
    (function(d) {
      d.method = "textDocument/didClose", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(Zn || (t.DidCloseTextDocumentNotification = Zn = {}));
    var ei;
    (function(d) {
      d.method = "textDocument/didSave", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(ei || (t.DidSaveTextDocumentNotification = ei = {}));
    var ti;
    (function(d) {
      d.Manual = 1, d.AfterDelay = 2, d.FocusOut = 3;
    })(ti || (t.TextDocumentSaveReason = ti = {}));
    var ni;
    (function(d) {
      d.method = "textDocument/willSave", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(ni || (t.WillSaveTextDocumentNotification = ni = {}));
    var ri;
    (function(d) {
      d.method = "textDocument/willSaveWaitUntil", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ri || (t.WillSaveTextDocumentWaitUntilRequest = ri = {}));
    var Rt;
    (function(d) {
      d.method = "workspace/didChangeWatchedFiles", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolNotificationType(d.method);
    })(Rt || (t.DidChangeWatchedFilesNotification = Rt = {}));
    var ii;
    (function(d) {
      d.Created = 1, d.Changed = 2, d.Deleted = 3;
    })(ii || (t.FileChangeType = ii = {}));
    var ds;
    (function(d) {
      function ke(Ce) {
        const V = Ce;
        return r.objectLiteral(V) && (n.URI.is(V.baseUri) || n.WorkspaceFolder.is(V.baseUri)) && r.string(V.pattern);
      }
      d.is = ke;
    })(ds || (t.RelativePattern = ds = {}));
    var fs;
    (function(d) {
      d.Create = 1, d.Change = 2, d.Delete = 4;
    })(fs || (t.WatchKind = fs = {}));
    var hs;
    (function(d) {
      d.method = "textDocument/publishDiagnostics", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolNotificationType(d.method);
    })(hs || (t.PublishDiagnosticsNotification = hs = {}));
    var ps;
    (function(d) {
      d.Invoked = 1, d.TriggerCharacter = 2, d.TriggerForIncompleteCompletions = 3;
    })(ps || (t.CompletionTriggerKind = ps = {}));
    var si;
    (function(d) {
      d.method = "textDocument/completion", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(si || (t.CompletionRequest = si = {}));
    var ai;
    (function(d) {
      d.method = "completionItem/resolve", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ai || (t.CompletionResolveRequest = ai = {}));
    var Dt;
    (function(d) {
      d.method = "textDocument/hover", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Dt || (t.HoverRequest = Dt = {}));
    var oi;
    (function(d) {
      d.Invoked = 1, d.TriggerCharacter = 2, d.ContentChange = 3;
    })(oi || (t.SignatureHelpTriggerKind = oi = {}));
    var ms;
    (function(d) {
      d.method = "textDocument/signatureHelp", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ms || (t.SignatureHelpRequest = ms = {}));
    var gs;
    (function(d) {
      d.method = "textDocument/definition", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(gs || (t.DefinitionRequest = gs = {}));
    var ci;
    (function(d) {
      d.method = "textDocument/references", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ci || (t.ReferencesRequest = ci = {}));
    var li;
    (function(d) {
      d.method = "textDocument/documentHighlight", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(li || (t.DocumentHighlightRequest = li = {}));
    var ys;
    (function(d) {
      d.method = "textDocument/documentSymbol", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ys || (t.DocumentSymbolRequest = ys = {}));
    var Ts;
    (function(d) {
      d.method = "textDocument/codeAction", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Ts || (t.CodeActionRequest = Ts = {}));
    var Rs;
    (function(d) {
      d.method = "codeAction/resolve", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Rs || (t.CodeActionResolveRequest = Rs = {}));
    var vs;
    (function(d) {
      d.method = "workspace/symbol", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(vs || (t.WorkspaceSymbolRequest = vs = {}));
    var Es;
    (function(d) {
      d.method = "workspaceSymbol/resolve", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Es || (t.WorkspaceSymbolResolveRequest = Es = {}));
    var As;
    (function(d) {
      d.method = "textDocument/codeLens", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(As || (t.CodeLensRequest = As = {}));
    var vt;
    (function(d) {
      d.method = "codeLens/resolve", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(vt || (t.CodeLensResolveRequest = vt = {}));
    var Ss;
    (function(d) {
      d.method = "workspace/codeLens/refresh", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolRequestType0(d.method);
    })(Ss || (t.CodeLensRefreshRequest = Ss = {}));
    var ks;
    (function(d) {
      d.method = "textDocument/documentLink", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ks || (t.DocumentLinkRequest = ks = {}));
    var vn;
    (function(d) {
      d.method = "documentLink/resolve", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(vn || (t.DocumentLinkResolveRequest = vn = {}));
    var Cs;
    (function(d) {
      d.method = "textDocument/formatting", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Cs || (t.DocumentFormattingRequest = Cs = {}));
    var er;
    (function(d) {
      d.method = "textDocument/rangeFormatting", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(er || (t.DocumentRangeFormattingRequest = er = {}));
    var Ns;
    (function(d) {
      d.method = "textDocument/rangesFormatting", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Ns || (t.DocumentRangesFormattingRequest = Ns = {}));
    var Mt;
    (function(d) {
      d.method = "textDocument/onTypeFormatting", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(Mt || (t.DocumentOnTypeFormattingRequest = Mt = {}));
    var on;
    (function(d) {
      d.Identifier = 1;
    })(on || (t.PrepareSupportDefaultBehavior = on = {}));
    var ws;
    (function(d) {
      d.method = "textDocument/rename", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(ws || (t.RenameRequest = ws = {}));
    var bs;
    (function(d) {
      d.method = "textDocument/prepareRename", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(bs || (t.PrepareRenameRequest = bs = {}));
    var cn;
    (function(d) {
      d.method = "workspace/executeCommand", d.messageDirection = e.MessageDirection.clientToServer, d.type = new e.ProtocolRequestType(d.method);
    })(cn || (t.ExecuteCommandRequest = cn = {}));
    var ui;
    (function(d) {
      d.method = "workspace/applyEdit", d.messageDirection = e.MessageDirection.serverToClient, d.type = new e.ProtocolRequestType("workspace/applyEdit");
    })(ui || (t.ApplyWorkspaceEditRequest = ui = {}));
  })(oo)), oo;
}
var _i = {}, ld;
function MR() {
  if (ld) return _i;
  ld = 1, Object.defineProperty(_i, "__esModule", { value: !0 }), _i.createProtocolConnection = void 0;
  const t = Zr();
  function e(n, r, i, s) {
    return t.ConnectionStrategy.is(s) && (s = { connectionStrategy: s }), (0, t.createMessageConnection)(n, r, i, s);
  }
  return _i.createProtocolConnection = e, _i;
}
var ud;
function FR() {
  return ud || (ud = 1, (function(t) {
    var e = wn && wn.__createBinding || (Object.create ? (function(s, a, o, c) {
      c === void 0 && (c = o);
      var l = Object.getOwnPropertyDescriptor(a, o);
      (!l || ("get" in l ? !a.__esModule : l.writable || l.configurable)) && (l = { enumerable: !0, get: function() {
        return a[o];
      } }), Object.defineProperty(s, c, l);
    }) : (function(s, a, o, c) {
      c === void 0 && (c = o), s[c] = a[o];
    })), n = wn && wn.__exportStar || function(s, a) {
      for (var o in s) o !== "default" && !Object.prototype.hasOwnProperty.call(a, o) && e(a, s, o);
    };
    Object.defineProperty(t, "__esModule", { value: !0 }), t.LSPErrorCodes = t.createProtocolConnection = void 0, n(Zr(), t), n(kl, t), n(Te(), t), n(DR(), t);
    var r = MR();
    Object.defineProperty(t, "createProtocolConnection", { enumerable: !0, get: function() {
      return r.createProtocolConnection;
    } });
    var i;
    (function(s) {
      s.lspReservedErrorRangeStart = -32899, s.RequestFailed = -32803, s.ServerCancelled = -32802, s.ContentModified = -32801, s.RequestCancelled = -32800, s.lspReservedErrorRangeEnd = -32800;
    })(i || (t.LSPErrorCodes = i = {}));
  })(wn)), wn;
}
var dd;
function GR() {
  return dd || (dd = 1, (function(t) {
    var e = kn && kn.__createBinding || (Object.create ? (function(s, a, o, c) {
      c === void 0 && (c = o);
      var l = Object.getOwnPropertyDescriptor(a, o);
      (!l || ("get" in l ? !a.__esModule : l.writable || l.configurable)) && (l = { enumerable: !0, get: function() {
        return a[o];
      } }), Object.defineProperty(s, c, l);
    }) : (function(s, a, o, c) {
      c === void 0 && (c = o), s[c] = a[o];
    })), n = kn && kn.__exportStar || function(s, a) {
      for (var o in s) o !== "default" && !Object.prototype.hasOwnProperty.call(a, o) && e(a, s, o);
    };
    Object.defineProperty(t, "__esModule", { value: !0 }), t.createProtocolConnection = void 0;
    const r = Fu();
    n(Fu(), t), n(FR(), t);
    function i(s, a, o, c) {
      return (0, r.createMessageConnection)(s, a, o, c);
    }
    t.createProtocolConnection = i;
  })(kn)), kn;
}
var Gs = GR(), qi;
(function(t) {
  function e(n) {
    return {
      dispose: async () => await n()
    };
  }
  t.create = e;
})(qi || (qi = {}));
class UR {
  constructor(e) {
    this.updateBuildOptions = {
      // Default: run only the built-in validation checks and those in the _fast_ category (includes those without category)
      validation: {
        categories: ["built-in", "fast"]
      }
    }, this.updateListeners = [], this.buildPhaseListeners = new Zi(), this.documentPhaseListeners = new Zi(), this.buildState = /* @__PURE__ */ new Map(), this.documentBuildWaiters = /* @__PURE__ */ new Map(), this.currentState = Y.Changed, this.langiumDocuments = e.workspace.LangiumDocuments, this.langiumDocumentFactory = e.workspace.LangiumDocumentFactory, this.textDocuments = e.workspace.TextDocuments, this.indexManager = e.workspace.IndexManager, this.fileSystemProvider = e.workspace.FileSystemProvider, this.workspaceManager = () => e.workspace.WorkspaceManager, this.serviceRegistry = e.ServiceRegistry;
  }
  async build(e, n = {}, r = ye.CancellationToken.None) {
    for (const i of e) {
      const s = i.uri.toString();
      if (i.state === Y.Validated) {
        if (typeof n.validation == "boolean" && n.validation)
          this.resetToState(i, Y.IndexedReferences);
        else if (typeof n.validation == "object") {
          const a = this.findMissingValidationCategories(i, n);
          a.length > 0 && (this.buildState.set(s, {
            completed: !1,
            options: {
              validation: {
                categories: a
              }
            },
            result: this.buildState.get(s)?.result
          }), i.state = Y.IndexedReferences);
        }
      } else
        this.buildState.delete(s);
    }
    this.currentState = Y.Changed, await this.emitUpdate(e.map((i) => i.uri), []), await this.buildDocuments(e, n, r);
  }
  async update(e, n, r = ye.CancellationToken.None) {
    this.currentState = Y.Changed;
    const i = [];
    for (const c of n) {
      const l = this.langiumDocuments.deleteDocuments(c);
      for (const u of l)
        i.push(u.uri), this.cleanUpDeleted(u);
    }
    const s = (await Promise.all(e.map((c) => this.findChangedUris(c)))).flat();
    for (const c of s) {
      let l = this.langiumDocuments.getDocument(c);
      l === void 0 && (l = this.langiumDocumentFactory.fromModel({ $type: "INVALID" }, c), l.state = Y.Changed, this.langiumDocuments.addDocument(l)), this.resetToState(l, Y.Changed);
    }
    const a = me(s).concat(i).map((c) => c.toString()).toSet();
    this.langiumDocuments.all.filter((c) => !a.has(c.uri.toString()) && this.shouldRelink(c, a)).forEach((c) => this.resetToState(c, Y.ComputedScopes)), await this.emitUpdate(s, i), await Xe(r);
    const o = this.sortDocuments(this.langiumDocuments.all.filter((c) => (
      // This includes those that were reported as changed and those that we selected for relinking
      c.state < Y.Validated || !this.buildState.get(c.uri.toString())?.completed || this.resultsAreIncomplete(c, this.updateBuildOptions)
    )).toArray());
    await this.buildDocuments(o, this.updateBuildOptions, r);
  }
  resultsAreIncomplete(e, n) {
    return this.findMissingValidationCategories(e, n).length >= 1;
  }
  findMissingValidationCategories(e, n) {
    const r = this.buildState.get(e.uri.toString()), i = this.serviceRegistry.getServices(e.uri).validation.ValidationRegistry.getAllValidationCategories(e), s = r?.result?.validationChecks ? new Set(r?.result?.validationChecks) : r?.completed ? i : /* @__PURE__ */ new Set(), a = n === void 0 || n.validation === !0 ? i : typeof n.validation == "object" ? n.validation.categories ?? i : [];
    return me(a).filter((o) => !s.has(o)).toArray();
  }
  async findChangedUris(e) {
    if (this.langiumDocuments.getDocument(e) ?? this.textDocuments?.get(e))
      return [e];
    try {
      const r = await this.fileSystemProvider.stat(e);
      if (r.isDirectory)
        return await this.workspaceManager().searchFolder(e);
      if (this.workspaceManager().shouldIncludeEntry(r))
        return [e];
    } catch {
    }
    return [];
  }
  async emitUpdate(e, n) {
    await Promise.all(this.updateListeners.map((r) => r(e, n)));
  }
  /**
   * Sort the given documents by priority. By default, documents with an open text document are prioritized.
   * This is useful to ensure that visible documents show their diagnostics before all other documents.
   *
   * This improves the responsiveness in large workspaces as users usually don't care about diagnostics
   * in files that are currently not opened in the editor.
   */
  sortDocuments(e) {
    let n = 0, r = e.length - 1;
    for (; n < r; ) {
      for (; n < e.length && this.hasTextDocument(e[n]); )
        n++;
      for (; r >= 0 && !this.hasTextDocument(e[r]); )
        r--;
      n < r && ([e[n], e[r]] = [e[r], e[n]]);
    }
    return e;
  }
  hasTextDocument(e) {
    return !!this.textDocuments?.get(e.uri);
  }
  /**
   * Check whether the given document should be relinked after changes were found in the given URIs.
   */
  shouldRelink(e, n) {
    return e.references.some((r) => r.error !== void 0) ? !0 : this.indexManager.isAffected(e, n);
  }
  onUpdate(e) {
    return this.updateListeners.push(e), qi.create(() => {
      const n = this.updateListeners.indexOf(e);
      n >= 0 && this.updateListeners.splice(n, 1);
    });
  }
  resetToState(e, n) {
    switch (n) {
      case Y.Changed:
      case Y.Parsed:
        this.indexManager.removeContent(e.uri);
      // Fall through
      case Y.IndexedContent:
        e.localSymbols = void 0;
      // Fall through
      case Y.ComputedScopes:
        this.serviceRegistry.getServices(e.uri).references.Linker.unlink(e);
      case Y.Linked:
        this.indexManager.removeReferences(e.uri);
      // Fall through
      case Y.IndexedReferences:
        e.diagnostics = void 0, this.buildState.delete(e.uri.toString());
      // Fall through
      case Y.Validated:
    }
    e.state > n && (e.state = n);
  }
  cleanUpDeleted(e) {
    this.buildState.delete(e.uri.toString()), this.indexManager.remove(e.uri), e.state = Y.Changed;
  }
  /**
   * Build the given documents by stepping through all build phases. If a document's state indicates
   * that a certain build phase is already done, the phase is skipped for that document.
   *
   * @param documents The documents to build.
   * @param options the {@link BuildOptions} to use.
   * @param cancelToken A cancellation token that can be used to cancel the build.
   * @returns A promise that resolves when the build is done.
   */
  async buildDocuments(e, n, r) {
    this.prepareBuild(e, n), await this.runCancelable(e, Y.Parsed, r, (a) => this.langiumDocumentFactory.update(a, r)), await this.runCancelable(e, Y.IndexedContent, r, (a) => this.indexManager.updateContent(a, r)), await this.runCancelable(e, Y.ComputedScopes, r, async (a) => {
      const o = this.serviceRegistry.getServices(a.uri).references.ScopeComputation;
      a.localSymbols = await o.collectLocalSymbols(a, r);
    });
    const i = e.filter((a) => this.shouldLink(a));
    await this.runCancelable(i, Y.Linked, r, (a) => this.serviceRegistry.getServices(a.uri).references.Linker.link(a, r)), await this.runCancelable(i, Y.IndexedReferences, r, (a) => this.indexManager.updateReferences(a, r));
    const s = e.filter((a) => this.shouldValidate(a) ? !0 : (this.markAsCompleted(a), !1));
    await this.runCancelable(s, Y.Validated, r, async (a) => {
      await this.validate(a, r), this.markAsCompleted(a);
    });
  }
  markAsCompleted(e) {
    const n = this.buildState.get(e.uri.toString());
    n && (n.completed = !0);
  }
  /**
   * Runs prior to beginning the build process to update the {@link DocumentBuildState} for each document
   *
   * @param documents collection of documents to be built
   * @param options the {@link BuildOptions} to use
   */
  prepareBuild(e, n) {
    for (const r of e) {
      const i = r.uri.toString(), s = this.buildState.get(i);
      (!s || s.completed) && this.buildState.set(i, {
        completed: !1,
        options: n,
        result: s?.result
      });
    }
  }
  /**
   * Runs a cancelable operation on a set of documents to bring them to a specified {@link DocumentState}.
   *
   * @param documents The array of documents to process.
   * @param targetState The target {@link DocumentState} to bring the documents to.
   * @param cancelToken A token that can be used to cancel the operation.
   * @param callback A function to be called for each document.
   * @returns A promise that resolves when all documents have been processed or the operation is canceled.
   * @throws Will throw `OperationCancelled` if the operation is canceled via a `CancellationToken`.
   */
  async runCancelable(e, n, r, i) {
    for (const a of e)
      a.state < n && (await Xe(r), await i(a), a.state = n, await this.notifyDocumentPhase(a, n, r));
    const s = e.filter((a) => a.state === n);
    await this.notifyBuildPhase(s, n, r), this.currentState = n;
  }
  onBuildPhase(e, n) {
    return this.buildPhaseListeners.add(e, n), qi.create(() => {
      this.buildPhaseListeners.delete(e, n);
    });
  }
  onDocumentPhase(e, n) {
    return this.documentPhaseListeners.add(e, n), qi.create(() => {
      this.documentPhaseListeners.delete(e, n);
    });
  }
  waitUntil(e, n, r) {
    let i;
    return n && "path" in n ? i = n : r = n, r ?? (r = ye.CancellationToken.None), i ? this.awaitDocumentState(e, i, r) : this.awaitBuilderState(e, r);
  }
  awaitDocumentState(e, n, r) {
    const i = this.langiumDocuments.getDocument(n);
    if (i) {
      if (i.state >= e)
        return Promise.resolve(n);
      if (r.isCancellationRequested)
        return Promise.reject(Er);
      if (this.currentState >= e && e > i.state)
        return Promise.reject(new Gs.ResponseError(Gs.LSPErrorCodes.RequestFailed, `Document state of ${n.toString()} is ${Y[i.state]}, requiring ${Y[e]}, but workspace state is already ${Y[this.currentState]}. Returning undefined.`));
    } else return Promise.reject(new Gs.ResponseError(Gs.LSPErrorCodes.ServerCancelled, `No document found for URI: ${n.toString()}`));
    return new Promise((s, a) => {
      const o = this.onDocumentPhase(e, (l) => {
        ut.equals(l.uri, n) && (o.dispose(), c.dispose(), s(l.uri));
      }), c = r.onCancellationRequested(() => {
        o.dispose(), c.dispose(), a(Er);
      });
    });
  }
  awaitBuilderState(e, n) {
    return this.currentState >= e ? Promise.resolve() : n.isCancellationRequested ? Promise.reject(Er) : new Promise((r, i) => {
      const s = this.onBuildPhase(e, () => {
        s.dispose(), a.dispose(), r();
      }), a = n.onCancellationRequested(() => {
        s.dispose(), a.dispose(), i(Er);
      });
    });
  }
  async notifyDocumentPhase(e, n, r) {
    const s = this.documentPhaseListeners.get(n).slice();
    for (const a of s)
      try {
        await Xe(r), await a(e, r);
      } catch (o) {
        if (!za(o))
          throw o;
      }
  }
  async notifyBuildPhase(e, n, r) {
    if (e.length === 0)
      return;
    const s = this.buildPhaseListeners.get(n).slice();
    for (const a of s)
      await Xe(r), await a(e, r);
  }
  /**
   * Determine whether the given document should be linked during a build. The default
   * implementation checks the `eagerLinking` property of the build options. If it's set to `true`
   * or `undefined`, the document is included in the linking phase. This also affects the
   * references indexing phase, which depends on eager linking.
   */
  shouldLink(e) {
    return this.getBuildOptions(e).eagerLinking ?? !0;
  }
  /**
   * Determine whether the given document should be validated during a build. The default
   * implementation checks the `validation` property of the build options. If it's set to `true`
   * or a `ValidationOptions` object, the document is included in the validation phase.
   */
  shouldValidate(e) {
    return !!this.getBuildOptions(e).validation;
  }
  /**
   * Run validation checks on the given document and store the resulting diagnostics in the document.
   * If the document already contains diagnostics, the new ones are added to the list.
   */
  async validate(e, n) {
    const r = this.serviceRegistry.getServices(e.uri).validation.DocumentValidator, i = this.getBuildOptions(e), s = typeof i.validation == "object" ? { ...i.validation } : {};
    s.categories = this.findMissingValidationCategories(e, i);
    const a = await r.validateDocument(e, s, n);
    e.diagnostics ? e.diagnostics.push(...a) : e.diagnostics = a;
    const o = this.buildState.get(e.uri.toString());
    o && (o.result ?? (o.result = {}), o.result.validationChecks ? o.result.validationChecks = me(o.result.validationChecks).concat(s.categories).distinct().toArray() : o.result.validationChecks = [...s.categories]);
  }
  getBuildOptions(e) {
    return this.buildState.get(e.uri.toString())?.options ?? {};
  }
}
class qR {
  constructor(e) {
    this.symbolIndex = /* @__PURE__ */ new Map(), this.symbolByTypeIndex = new VT(), this.referenceIndex = /* @__PURE__ */ new Map(), this.documents = e.workspace.LangiumDocuments, this.serviceRegistry = e.ServiceRegistry, this.astReflection = e.AstReflection;
  }
  findAllReferences(e, n) {
    const r = Qt(e).uri, i = [];
    return this.referenceIndex.forEach((s) => {
      s.forEach((a) => {
        ut.equals(a.targetUri, r) && a.targetPath === n && i.push(a);
      });
    }), me(i);
  }
  allElements(e, n) {
    let r = me(this.symbolIndex.keys());
    return n && (r = r.filter((i) => !n || n.has(i))), r.map((i) => this.getFileDescriptions(i, e)).flat();
  }
  getFileDescriptions(e, n) {
    return n ? this.symbolByTypeIndex.get(e, n, () => (this.symbolIndex.get(e) ?? []).filter((s) => this.astReflection.isSubtype(s.type, n))) : this.symbolIndex.get(e) ?? [];
  }
  remove(e) {
    this.removeContent(e), this.removeReferences(e);
  }
  removeContent(e) {
    const n = e.toString();
    this.symbolIndex.delete(n), this.symbolByTypeIndex.clear(n);
  }
  removeReferences(e) {
    const n = e.toString();
    this.referenceIndex.delete(n);
  }
  async updateContent(e, n = ye.CancellationToken.None) {
    const i = await this.serviceRegistry.getServices(e.uri).references.ScopeComputation.collectExportedSymbols(e, n), s = e.uri.toString();
    this.symbolIndex.set(s, i), this.symbolByTypeIndex.clear(s);
  }
  async updateReferences(e, n = ye.CancellationToken.None) {
    const i = await this.serviceRegistry.getServices(e.uri).workspace.ReferenceDescriptionProvider.createDescriptions(e, n);
    this.referenceIndex.set(e.uri.toString(), i);
  }
  isAffected(e, n) {
    const r = this.referenceIndex.get(e.uri.toString());
    return r ? r.some((i) => !i.local && n.has(i.targetUri.toString())) : !1;
  }
}
class jR {
  constructor(e) {
    this.initialBuildOptions = {}, this._ready = new Sl(), this.serviceRegistry = e.ServiceRegistry, this.langiumDocuments = e.workspace.LangiumDocuments, this.documentBuilder = e.workspace.DocumentBuilder, this.fileSystemProvider = e.workspace.FileSystemProvider, this.mutex = e.workspace.WorkspaceLock;
  }
  get ready() {
    return this._ready.promise;
  }
  get workspaceFolders() {
    return this.folders;
  }
  initialize(e) {
    this.folders = e.workspaceFolders ?? void 0;
  }
  initialized(e) {
    return this.mutex.write((n) => this.initializeWorkspace(this.folders ?? [], n));
  }
  async initializeWorkspace(e, n = ye.CancellationToken.None) {
    const r = await this.performStartup(e);
    await Xe(n), await this.documentBuilder.build(r, this.initialBuildOptions, n);
  }
  /**
   * Performs the uninterruptable startup sequence of the workspace manager.
   * This methods loads all documents in the workspace and other documents and returns them.
   */
  async performStartup(e) {
    const n = [], r = (a) => {
      n.push(a), this.langiumDocuments.hasDocument(a.uri) || this.langiumDocuments.addDocument(a);
    };
    await this.loadAdditionalDocuments(e, r);
    const i = [];
    await Promise.all(e.map((a) => this.getRootFolder(a)).map(async (a) => this.traverseFolder(a, i)));
    const s = me(i).distinct((a) => a.toString()).filter((a) => !this.langiumDocuments.hasDocument(a));
    return await this.loadWorkspaceDocuments(s, r), this._ready.resolve(), n;
  }
  async loadWorkspaceDocuments(e, n) {
    await Promise.all(e.map(async (r) => {
      const i = await this.langiumDocuments.getOrCreateDocument(r);
      n(i);
    }));
  }
  /**
   * Load all additional documents that shall be visible in the context of the given workspace
   * folders and add them to the collector. This can be used to include built-in libraries of
   * your language, which can be either loaded from provided files or constructed in memory.
   */
  loadAdditionalDocuments(e, n) {
    return Promise.resolve();
  }
  /**
   * Determine the root folder of the source documents in the given workspace folder.
   * The default implementation returns the URI of the workspace folder, but you can override
   * this to return a subfolder like `src` instead.
   */
  getRootFolder(e) {
    return Ct.parse(e.uri);
  }
  /**
   * Traverse the file system folder identified by the given URI and its subfolders. All
   * contained files that match the file extensions are added to the `uris` array.
   */
  async traverseFolder(e, n) {
    try {
      const r = await this.fileSystemProvider.readDirectory(e);
      await Promise.all(r.map(async (i) => {
        this.shouldIncludeEntry(i) && (i.isDirectory ? await this.traverseFolder(i.uri, n) : i.isFile && n.push(i.uri));
      }));
    } catch (r) {
      console.error("Failure to read directory content of " + e.toString(!0), r);
    }
  }
  async searchFolder(e) {
    const n = [];
    return await this.traverseFolder(e, n), n;
  }
  /**
   * Determine whether the given folder entry shall be included while indexing the workspace.
   */
  shouldIncludeEntry(e) {
    const n = ut.basename(e.uri);
    return n.startsWith(".") ? !1 : e.isDirectory ? n !== "node_modules" && n !== "out" : e.isFile ? this.serviceRegistry.hasServices(e.uri) : !1;
  }
}
class zR {
  buildUnexpectedCharactersMessage(e, n, r, i, s) {
    return Io.buildUnexpectedCharactersMessage(e, n, r, i, s);
  }
  buildUnableToPopLexerModeMessage(e) {
    return Io.buildUnableToPopLexerModeMessage(e);
  }
}
const BR = { mode: "full" };
class WR {
  constructor(e) {
    this.errorMessageProvider = e.parser.LexerErrorMessageProvider, this.tokenBuilder = e.parser.TokenBuilder;
    const n = this.tokenBuilder.buildTokens(e.Grammar, {
      caseInsensitive: e.LanguageMetaData.caseInsensitive
    });
    this.tokenTypes = this.toTokenTypeDictionary(n);
    const r = fd(n) ? Object.values(n) : n, i = e.LanguageMetaData.mode === "production";
    this.chevrotainLexer = new tt(r, {
      positionTracking: "full",
      skipValidations: i,
      errorMessageProvider: this.errorMessageProvider
    });
  }
  get definition() {
    return this.tokenTypes;
  }
  tokenize(e, n = BR) {
    const r = this.chevrotainLexer.tokenize(e);
    return {
      tokens: r.tokens,
      errors: r.errors,
      hidden: r.groups.hidden ?? [],
      report: this.tokenBuilder.flushLexingReport?.(e)
    };
  }
  toTokenTypeDictionary(e) {
    if (fd(e))
      return e;
    const n = lh(e) ? Object.values(e.modes).flat() : e, r = {};
    return n.forEach((i) => r[i.name] = i), r;
  }
}
function VR(t) {
  return Array.isArray(t) && (t.length === 0 || "name" in t[0]);
}
function lh(t) {
  return t && "modes" in t && "defaultMode" in t;
}
function fd(t) {
  return !VR(t) && !lh(t);
}
function KR(t, e, n) {
  let r, i;
  typeof t == "string" ? (i = e, r = n) : (i = t.range.start, r = e), i || (i = te.create(0, 0));
  const s = uh(t), a = Nl(r), o = XR({
    lines: s,
    position: i,
    options: a
  });
  return tv({
    index: 0,
    tokens: o,
    position: i
  });
}
function HR(t, e) {
  const n = Nl(e), r = uh(t);
  if (r.length === 0)
    return !1;
  const i = r[0], s = r[r.length - 1], a = n.start, o = n.end;
  return !!a?.exec(i) && !!o?.exec(s);
}
function uh(t) {
  let e = "";
  return typeof t == "string" ? e = t : e = t.text, e.split(Xp);
}
const hd = /\s*(@([\p{L}][\p{L}\p{N}]*)?)/uy, YR = /\{(@[\p{L}][\p{L}\p{N}]*)(\s*)([^\r\n}]+)?\}/gu;
function XR(t) {
  const e = [];
  let n = t.position.line, r = t.position.character;
  for (let i = 0; i < t.lines.length; i++) {
    const s = i === 0, a = i === t.lines.length - 1;
    let o = t.lines[i], c = 0;
    if (s && t.options.start) {
      const u = t.options.start?.exec(o);
      u && (c = u.index + u[0].length);
    } else {
      const u = t.options.line?.exec(o);
      u && (c = u.index + u[0].length);
    }
    if (a) {
      const u = t.options.end?.exec(o);
      u && (o = o.substring(0, u.index));
    }
    if (o = o.substring(0, ev(o)), Wc(o, c) >= o.length) {
      if (e.length > 0) {
        const u = te.create(n, r);
        e.push({
          type: "break",
          content: "",
          range: X.create(u, u)
        });
      }
    } else {
      hd.lastIndex = c;
      const u = hd.exec(o);
      if (u) {
        const f = u[0], m = u[1], p = te.create(n, r + c), A = te.create(n, r + c + f.length);
        e.push({
          type: "tag",
          content: m,
          range: X.create(p, A)
        }), c += f.length, c = Wc(o, c);
      }
      if (c < o.length) {
        const f = o.substring(c), m = Array.from(f.matchAll(YR));
        e.push(...JR(m, f, n, r + c));
      }
    }
    n++, r = 0;
  }
  return e.length > 0 && e[e.length - 1].type === "break" ? e.slice(0, -1) : e;
}
function JR(t, e, n, r) {
  const i = [];
  if (t.length === 0) {
    const s = te.create(n, r), a = te.create(n, r + e.length);
    i.push({
      type: "text",
      content: e,
      range: X.create(s, a)
    });
  } else {
    let s = 0;
    for (const o of t) {
      const c = o.index, l = e.substring(s, c);
      l.length > 0 && i.push({
        type: "text",
        content: e.substring(s, c),
        range: X.create(te.create(n, s + r), te.create(n, c + r))
      });
      let u = l.length + 1;
      const f = o[1];
      if (i.push({
        type: "inline-tag",
        content: f,
        range: X.create(te.create(n, s + u + r), te.create(n, s + u + f.length + r))
      }), u += f.length, o.length === 4) {
        u += o[2].length;
        const m = o[3];
        i.push({
          type: "text",
          content: m,
          range: X.create(te.create(n, s + u + r), te.create(n, s + u + m.length + r))
        });
      } else
        i.push({
          type: "text",
          content: "",
          range: X.create(te.create(n, s + u + r), te.create(n, s + u + r))
        });
      s = c + o[0].length;
    }
    const a = e.substring(s);
    a.length > 0 && i.push({
      type: "text",
      content: a,
      range: X.create(te.create(n, s + r), te.create(n, s + r + a.length))
    });
  }
  return i;
}
const QR = /\S/, ZR = /\s*$/;
function Wc(t, e) {
  const n = t.substring(e).match(QR);
  return n ? e + n.index : t.length;
}
function ev(t) {
  const e = t.match(ZR);
  if (e && typeof e.index == "number")
    return e.index;
}
function tv(t) {
  const e = te.create(t.position.line, t.position.character);
  if (t.tokens.length === 0)
    return new pd([], X.create(e, e));
  const n = [];
  for (; t.index < t.tokens.length; ) {
    const s = nv(t, n[n.length - 1]);
    s && n.push(s);
  }
  const r = n[0]?.range.start ?? e, i = n[n.length - 1]?.range.end ?? e;
  return new pd(n, X.create(r, i));
}
function nv(t, e) {
  const n = t.tokens[t.index];
  if (n.type === "tag")
    return fh(t, !1);
  if (n.type === "text" || n.type === "inline-tag")
    return dh(t);
  rv(n, e), t.index++;
}
function rv(t, e) {
  if (e) {
    const n = new ph("", t.range);
    "inlines" in e ? e.inlines.push(n) : e.content.inlines.push(n);
  }
}
function dh(t) {
  let e = t.tokens[t.index];
  const n = e;
  let r = e;
  const i = [];
  for (; e && e.type !== "break" && e.type !== "tag"; )
    i.push(iv(t)), r = e, e = t.tokens[t.index];
  return new Vc(i, X.create(n.range.start, r.range.end));
}
function iv(t) {
  return t.tokens[t.index].type === "inline-tag" ? fh(t, !0) : hh(t);
}
function fh(t, e) {
  const n = t.tokens[t.index++], r = n.content.substring(1);
  if (t.tokens[t.index]?.type === "text")
    if (e) {
      const s = hh(t);
      return new lo(r, new Vc([s], s.range), e, X.create(n.range.start, s.range.end));
    } else {
      const s = dh(t);
      return new lo(r, s, e, X.create(n.range.start, s.range.end));
    }
  else {
    const s = n.range;
    return new lo(r, new Vc([], s), e, s);
  }
}
function hh(t) {
  const e = t.tokens[t.index++];
  return new ph(e.content, e.range);
}
function Nl(t) {
  if (!t)
    return Nl({
      start: "/**",
      end: "*/",
      line: "*"
    });
  const { start: e, end: n, line: r } = t;
  return {
    start: co(e, !0),
    end: co(n, !1),
    line: co(r, !0)
  };
}
function co(t, e) {
  if (typeof t == "string" || typeof t == "object") {
    const n = typeof t == "string" ? Oa(t) : t.source;
    return e ? new RegExp(`^\\s*${n}`) : new RegExp(`\\s*${n}\\s*$`);
  } else
    return t;
}
class pd {
  constructor(e, n) {
    this.elements = e, this.range = n;
  }
  getTag(e) {
    return this.getAllTags().find((n) => n.name === e);
  }
  getTags(e) {
    return this.getAllTags().filter((n) => n.name === e);
  }
  getAllTags() {
    return this.elements.filter((e) => "name" in e);
  }
  toString() {
    let e = "";
    for (const n of this.elements)
      if (e.length === 0)
        e = n.toString();
      else {
        const r = n.toString();
        e += md(e) + r;
      }
    return e.trim();
  }
  toMarkdown(e) {
    let n = "";
    for (const r of this.elements)
      if (n.length === 0)
        n = r.toMarkdown(e);
      else {
        const i = r.toMarkdown(e);
        n += md(n) + i;
      }
    return n.trim();
  }
}
class lo {
  constructor(e, n, r, i) {
    this.name = e, this.content = n, this.inline = r, this.range = i;
  }
  toString() {
    let e = `@${this.name}`;
    const n = this.content.toString();
    return this.content.inlines.length === 1 ? e = `${e} ${n}` : this.content.inlines.length > 1 && (e = `${e}
${n}`), this.inline ? `{${e}}` : e;
  }
  toMarkdown(e) {
    return e?.renderTag?.(this) ?? this.toMarkdownDefault(e);
  }
  toMarkdownDefault(e) {
    const n = this.content.toMarkdown(e);
    if (this.inline) {
      const s = sv(this.name, n, e ?? {});
      if (typeof s == "string")
        return s;
    }
    let r = "";
    e?.tag === "italic" || e?.tag === void 0 ? r = "*" : e?.tag === "bold" ? r = "**" : e?.tag === "bold-italic" && (r = "***");
    let i = `${r}@${this.name}${r}`;
    return this.content.inlines.length === 1 ? i = `${i} — ${n}` : this.content.inlines.length > 1 && (i = `${i}
${n}`), this.inline ? `{${i}}` : i;
  }
}
function sv(t, e, n) {
  if (t === "linkplain" || t === "linkcode" || t === "link") {
    const r = e.indexOf(" ");
    let i = e;
    if (r > 0) {
      const a = Wc(e, r);
      i = e.substring(a), e = e.substring(0, r);
    }
    return (t === "linkcode" || t === "link" && n.link === "code") && (i = `\`${i}\``), n.renderLink?.(e, i) ?? av(e, i);
  }
}
function av(t, e) {
  try {
    return Ct.parse(t, !0), `[${e}](${t})`;
  } catch {
    return t;
  }
}
class Vc {
  constructor(e, n) {
    this.inlines = e, this.range = n;
  }
  toString() {
    let e = "";
    for (let n = 0; n < this.inlines.length; n++) {
      const r = this.inlines[n], i = this.inlines[n + 1];
      e += r.toString(), i && i.range.start.line > r.range.start.line && (e += `
`);
    }
    return e;
  }
  toMarkdown(e) {
    let n = "";
    for (let r = 0; r < this.inlines.length; r++) {
      const i = this.inlines[r], s = this.inlines[r + 1];
      n += i.toMarkdown(e), s && s.range.start.line > i.range.start.line && (n += `
`);
    }
    return n;
  }
}
class ph {
  constructor(e, n) {
    this.text = e, this.range = n;
  }
  toString() {
    return this.text;
  }
  toMarkdown() {
    return this.text;
  }
}
function md(t) {
  return t.endsWith(`
`) ? `
` : `

`;
}
class ov {
  constructor(e) {
    this.indexManager = e.shared.workspace.IndexManager, this.commentProvider = e.documentation.CommentProvider;
  }
  getDocumentation(e) {
    const n = this.commentProvider.getComment(e);
    if (n && HR(n))
      return KR(n).toMarkdown({
        renderLink: (i, s) => this.documentationLinkRenderer(e, i, s),
        renderTag: (i) => this.documentationTagRenderer(e, i)
      });
  }
  documentationLinkRenderer(e, n, r) {
    const i = this.findNameInLocalSymbols(e, n) ?? this.findNameInGlobalScope(e, n);
    if (i && i.nameSegment) {
      const s = i.nameSegment.range.start.line + 1, a = i.nameSegment.range.start.character + 1, o = i.documentUri.with({ fragment: `L${s},${a}` });
      return `[${r}](${o.toString()})`;
    } else
      return;
  }
  documentationTagRenderer(e, n) {
  }
  findNameInLocalSymbols(e, n) {
    const i = Qt(e).localSymbols;
    if (!i)
      return;
    let s = e;
    do {
      const o = i.getStream(s).find((c) => c.name === n);
      if (o)
        return o;
      s = s.$container;
    } while (s);
  }
  findNameInGlobalScope(e, n) {
    return this.indexManager.allElements().find((i) => i.name === n);
  }
}
class cv {
  constructor(e) {
    this.grammarConfig = () => e.parser.GrammarConfig;
  }
  getComment(e) {
    return YT(e) ? e.$comment : Wp(e.$cstNode, this.grammarConfig().multilineCommentRules)?.text;
  }
}
class lv {
  constructor(e) {
    this.syncParser = e.parser.LangiumParser;
  }
  parse(e, n) {
    return Promise.resolve(this.syncParser.parse(e));
  }
}
class uv {
  constructor() {
    this.previousTokenSource = new ye.CancellationTokenSource(), this.writeQueue = [], this.readQueue = [], this.done = !0;
  }
  write(e) {
    this.cancelWrite();
    const n = OT();
    return this.previousTokenSource = n, this.enqueue(this.writeQueue, e, n.token);
  }
  read(e) {
    return this.enqueue(this.readQueue, e);
  }
  enqueue(e, n, r = ye.CancellationToken.None) {
    const i = new Sl(), s = {
      action: n,
      deferred: i,
      cancellationToken: r
    };
    return e.push(s), this.performNextOperation(), i.promise;
  }
  async performNextOperation() {
    if (!this.done)
      return;
    const e = [];
    if (this.writeQueue.length > 0)
      e.push(this.writeQueue.shift());
    else if (this.readQueue.length > 0)
      e.push(...this.readQueue.splice(0, this.readQueue.length));
    else
      return;
    this.done = !1, await Promise.all(e.map(async ({ action: n, deferred: r, cancellationToken: i }) => {
      try {
        const s = await Promise.resolve().then(() => n(i));
        r.resolve(s);
      } catch (s) {
        za(s) ? r.resolve(void 0) : r.reject(s);
      }
    })), this.done = !0, this.performNextOperation();
  }
  cancelWrite() {
    this.previousTokenSource.cancel();
  }
}
class dv {
  constructor(e) {
    this.grammarElementIdMap = new Au(), this.tokenTypeIdMap = new Au(), this.grammar = e.Grammar, this.lexer = e.parser.Lexer, this.linker = e.references.Linker;
  }
  dehydrate(e) {
    return {
      lexerErrors: e.lexerErrors,
      lexerReport: e.lexerReport ? this.dehydrateLexerReport(e.lexerReport) : void 0,
      // We need to create shallow copies of the errors
      // The original errors inherit from the `Error` class, which is not transferable across worker threads
      parserErrors: e.parserErrors.map((n) => ({ ...n, message: n.message })),
      value: this.dehydrateAstNode(e.value, this.createDehyrationContext(e.value))
    };
  }
  dehydrateLexerReport(e) {
    return e;
  }
  createDehyrationContext(e) {
    const n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
    for (const i of Zt(e))
      n.set(i, {});
    if (e.$cstNode)
      for (const i of Co(e.$cstNode))
        r.set(i, {});
    return {
      astNodes: n,
      cstNodes: r
    };
  }
  dehydrateAstNode(e, n) {
    const r = n.astNodes.get(e);
    r.$type = e.$type, r.$containerIndex = e.$containerIndex, r.$containerProperty = e.$containerProperty, e.$cstNode !== void 0 && (r.$cstNode = this.dehydrateCstNode(e.$cstNode, n));
    for (const [i, s] of Object.entries(e))
      if (!i.startsWith("$"))
        if (Array.isArray(s)) {
          const a = [];
          r[i] = a;
          for (const o of s)
            We(o) ? a.push(this.dehydrateAstNode(o, n)) : St(o) ? a.push(this.dehydrateReference(o, n)) : a.push(o);
        } else We(s) ? r[i] = this.dehydrateAstNode(s, n) : St(s) ? r[i] = this.dehydrateReference(s, n) : s !== void 0 && (r[i] = s);
    return r;
  }
  dehydrateReference(e, n) {
    const r = {};
    return r.$refText = e.$refText, e.$refNode && (r.$refNode = n.cstNodes.get(e.$refNode)), r;
  }
  dehydrateCstNode(e, n) {
    const r = n.cstNodes.get(e);
    return Md(e) ? r.fullText = e.fullText : r.grammarSource = this.getGrammarElementId(e.grammarSource), r.hidden = e.hidden, r.astNode = n.astNodes.get(e.astNode), zi(e) ? r.content = e.content.map((i) => this.dehydrateCstNode(i, n)) : Dd(e) && (r.tokenType = e.tokenType.name, r.offset = e.offset, r.length = e.length, r.startLine = e.range.start.line, r.startColumn = e.range.start.character, r.endLine = e.range.end.line, r.endColumn = e.range.end.character), r;
  }
  hydrate(e) {
    const n = e.value, r = this.createHydrationContext(n);
    return "$cstNode" in n && this.hydrateCstNode(n.$cstNode, r), {
      lexerErrors: e.lexerErrors,
      lexerReport: e.lexerReport,
      parserErrors: e.parserErrors,
      value: this.hydrateAstNode(n, r)
    };
  }
  createHydrationContext(e) {
    const n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
    for (const s of Zt(e))
      n.set(s, {});
    let i;
    if (e.$cstNode)
      for (const s of Co(e.$cstNode)) {
        let a;
        "fullText" in s ? (a = new Vf(s.fullText), i = a) : "content" in s ? a = new vl() : "tokenType" in s && (a = this.hydrateCstLeafNode(s)), a && (r.set(s, a), a.root = i);
      }
    return {
      astNodes: n,
      cstNodes: r
    };
  }
  hydrateAstNode(e, n) {
    const r = n.astNodes.get(e);
    r.$type = e.$type, r.$containerIndex = e.$containerIndex, r.$containerProperty = e.$containerProperty, e.$cstNode && (r.$cstNode = n.cstNodes.get(e.$cstNode));
    for (const [i, s] of Object.entries(e))
      if (!i.startsWith("$"))
        if (Array.isArray(s)) {
          const a = [];
          r[i] = a;
          for (const o of s)
            We(o) ? a.push(this.setParent(this.hydrateAstNode(o, n), r)) : St(o) ? a.push(this.hydrateReference(o, r, i, n)) : a.push(o);
        } else We(s) ? r[i] = this.setParent(this.hydrateAstNode(s, n), r) : St(s) ? r[i] = this.hydrateReference(s, r, i, n) : s !== void 0 && (r[i] = s);
    return r;
  }
  setParent(e, n) {
    return e.$container = n, e;
  }
  hydrateReference(e, n, r, i) {
    return this.linker.buildReference(n, r, i.cstNodes.get(e.$refNode), e.$refText);
  }
  hydrateCstNode(e, n, r = 0) {
    const i = n.cstNodes.get(e);
    if (typeof e.grammarSource == "number" && (i.grammarSource = this.getGrammarElement(e.grammarSource)), i.astNode = n.astNodes.get(e.astNode), zi(i))
      for (const s of e.content) {
        const a = this.hydrateCstNode(s, n, r++);
        i.content.push(a);
      }
    return i;
  }
  hydrateCstLeafNode(e) {
    const n = this.getTokenType(e.tokenType), r = e.offset, i = e.length, s = e.startLine, a = e.startColumn, o = e.endLine, c = e.endColumn, l = e.hidden;
    return new Fc(r, i, {
      start: {
        line: s,
        character: a
      },
      end: {
        line: o,
        character: c
      }
    }, n, l);
  }
  getTokenType(e) {
    return this.lexer.definition[e];
  }
  getGrammarElementId(e) {
    if (e)
      return this.grammarElementIdMap.size === 0 && this.createGrammarElementIdMap(), this.grammarElementIdMap.get(e);
  }
  getGrammarElement(e) {
    return this.grammarElementIdMap.size === 0 && this.createGrammarElementIdMap(), this.grammarElementIdMap.getKey(e);
  }
  createGrammarElementIdMap() {
    let e = 0;
    for (const n of Zt(this.grammar))
      Ap(n) && this.grammarElementIdMap.set(n, e++);
  }
}
function gn(t) {
  return {
    documentation: {
      CommentProvider: (e) => new cv(e),
      DocumentationProvider: (e) => new ov(e)
    },
    parser: {
      AsyncParser: (e) => new lv(e),
      GrammarConfig: (e) => Tm(e),
      LangiumParser: (e) => IT(e),
      CompletionParser: (e) => _T(e),
      ValueConverter: () => new th(),
      TokenBuilder: () => new eh(),
      Lexer: (e) => new WR(e),
      ParserErrorMessageProvider: () => new Yf(),
      LexerErrorMessageProvider: () => new zR()
    },
    workspace: {
      AstNodeLocator: () => new sR(),
      AstNodeDescriptionProvider: (e) => new rR(e),
      ReferenceDescriptionProvider: (e) => new iR(e)
    },
    references: {
      Linker: (e) => new GT(e),
      NameProvider: () => new qT(),
      ScopeProvider: (e) => new HT(e),
      ScopeComputation: (e) => new zT(e),
      References: (e) => new jT(e)
    },
    serializer: {
      Hydrator: (e) => new dv(e),
      JsonSerializer: (e) => new XT(e)
    },
    validation: {
      DocumentValidator: (e) => new eR(e),
      ValidationRegistry: (e) => new QT(e)
    },
    shared: () => t.shared
  };
}
function yn(t) {
  return {
    ServiceRegistry: (e) => new JT(e),
    workspace: {
      LangiumDocuments: (e) => new FT(e),
      LangiumDocumentFactory: (e) => new MT(e),
      DocumentBuilder: (e) => new UR(e),
      IndexManager: (e) => new qR(e),
      WorkspaceManager: (e) => new jR(e),
      FileSystemProvider: (e) => t.fileSystemProvider(e),
      WorkspaceLock: () => new uv(),
      ConfigurationProvider: (e) => new oR(e)
    },
    profilers: {}
  };
}
var gd;
(function(t) {
  t.merge = (e, n) => es(es({}, e), n);
})(gd || (gd = {}));
function Ve(t, e, n, r, i, s, a, o, c) {
  const l = [t, e, n, r, i, s, a, o, c].reduce(es, {});
  return mh(l);
}
const fv = /* @__PURE__ */ Symbol("isProxy");
function mh(t, e) {
  const n = new Proxy({}, {
    deleteProperty: () => !1,
    set: () => {
      throw new Error("Cannot set property on injected service container");
    },
    get: (r, i) => i === fv ? !0 : Td(r, i, t, e || n),
    getOwnPropertyDescriptor: (r, i) => (Td(r, i, t, e || n), Object.getOwnPropertyDescriptor(r, i)),
    // used by for..in
    has: (r, i) => i in t,
    // used by ..in..
    ownKeys: () => [...Object.getOwnPropertyNames(t)]
    // used by for..in
  });
  return n;
}
const yd = /* @__PURE__ */ Symbol();
function Td(t, e, n, r) {
  if (e in t) {
    if (t[e] instanceof Error)
      throw new Error("Construction failure. Please make sure that your dependencies are constructable. Cause: " + t[e]);
    if (t[e] === yd)
      throw new Error('Cycle detected. Please make "' + String(e) + '" lazy. Visit https://langium.org/docs/reference/configuration-services/#resolving-cyclic-dependencies');
    return t[e];
  } else if (e in n) {
    const i = n[e];
    t[e] = yd;
    try {
      t[e] = typeof i == "function" ? i(r) : mh(i, r);
    } catch (s) {
      throw t[e] = s instanceof Error ? s : void 0, s;
    }
    return t[e];
  } else
    return;
}
function es(t, e) {
  if (e) {
    for (const [n, r] of Object.entries(e))
      if (r != null)
        if (typeof r == "object") {
          const i = t[n];
          typeof i == "object" && i !== null ? t[n] = es(i, r) : t[n] = es({}, r);
        } else
          t[n] = r;
  }
  return t;
}
class hv {
  stat(e) {
    throw new Error("No file system is available.");
  }
  statSync(e) {
    throw new Error("No file system is available.");
  }
  async exists() {
    return !1;
  }
  existsSync() {
    return !1;
  }
  readBinary() {
    throw new Error("No file system is available.");
  }
  readBinarySync() {
    throw new Error("No file system is available.");
  }
  readFile() {
    throw new Error("No file system is available.");
  }
  readFileSync() {
    throw new Error("No file system is available.");
  }
  async readDirectory() {
    return [];
  }
  readDirectorySync() {
    return [];
  }
}
const Tn = {
  fileSystemProvider: () => new hv()
}, pv = {
  Grammar: () => {
  },
  LanguageMetaData: () => ({
    caseInsensitive: !1,
    fileExtensions: [".langium"],
    languageId: "langium"
  })
}, mv = {
  AstReflection: () => new zd()
};
function gv() {
  const t = Ve(yn(Tn), mv), e = Ve(gn({ shared: t }), pv);
  return t.ServiceRegistry.register(e), e;
}
function Jn(t) {
  const e = gv(), n = e.serializer.JsonSerializer.deserialize(t);
  return e.shared.workspace.LangiumDocumentFactory.fromModel(n, Ct.parse(`memory:/${n.name ?? "grammar"}.langium`)), n;
}
var yv = Object.defineProperty, $ = (t, e) => yv(t, "name", { value: e, configurable: !0 }), Kc;
((t) => {
  t.Terminals = {
    ARROW_DIRECTION: /L|R|T|B/,
    ARROW_GROUP: /\{group\}/,
    ARROW_INTO: /<|>/,
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/,
    ID: /[\w]([-\w]*\w)?/,
    NEWLINE: /\r?\n/,
    WHITESPACE: /[\t ]+/,
    YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/,
    DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/,
    SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/,
    ARCH_ICON: /\([\w-:]+\)/,
    ARCH_TITLE: /\[(?:"([^"\\]|\\.)*"|'([^'\\]|\\.)*'|[\w ]+)\]/
  };
})(Kc || (Kc = {}));
var Hc;
((t) => {
  t.Terminals = {
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    INT: /0|[1-9][0-9]*(?!\.)/,
    STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/,
    NEWLINE: /\r?\n/,
    WHITESPACE: /[\t ]+/,
    YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/,
    DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/,
    SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/,
    REFERENCE: /\w([-\./\w]*[-\w])?/
  };
})(Hc || (Hc = {}));
var Yc;
((t) => {
  t.Terminals = {
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    NEWLINE: /\r?\n/,
    WHITESPACE: /[\t ]+/,
    YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/,
    DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/,
    SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/
  };
})(Yc || (Yc = {}));
var Xc;
((t) => {
  t.Terminals = {
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    INT: /0|[1-9][0-9]*(?!\.)/,
    STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/,
    NEWLINE: /\r?\n/,
    WHITESPACE: /[\t ]+/,
    YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/,
    DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/,
    SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/
  };
})(Xc || (Xc = {}));
var Jc;
((t) => {
  t.Terminals = {
    NUMBER_PIE: /(?:-?[0-9]+\.[0-9]+(?!\.))|(?:-?(0|[1-9][0-9]*)(?!\.))/,
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/,
    NEWLINE: /\r?\n/,
    WHITESPACE: /[\t ]+/,
    YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/,
    DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/,
    SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/
  };
})(Jc || (Jc = {}));
var Qc;
((t) => {
  t.Terminals = {
    GRATICULE: /circle|polygon/,
    BOOLEAN: /true|false/,
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    NUMBER: /(?:[0-9]+\.[0-9]+(?!\.))|(?:0|[1-9][0-9]*(?!\.))/,
    STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/,
    ID: /[\w]([-\w]*\w)?/,
    NEWLINE: /\r?\n/,
    WHITESPACE: /[\t ]+/,
    YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/,
    DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/,
    SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/
  };
})(Qc || (Qc = {}));
var Zc;
((t) => {
  t.Terminals = {
    ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/,
    ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/,
    TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/,
    TREEMAP_KEYWORD: /treemap-beta|treemap/,
    CLASS_DEF: /classDef\s+([a-zA-Z_][a-zA-Z0-9_]+)(?:\s+([^;\r\n]*))?(?:;)?/,
    STYLE_SEPARATOR: /:::/,
    SEPARATOR: /:/,
    COMMA: /,/,
    INDENTATION: /[ \t]{1,}/,
    WS: /[ \t]+/,
    ML_COMMENT: /\%\%[^\n]*/,
    NL: /\r?\n/,
    ID2: /[a-zA-Z_][a-zA-Z0-9_]*/,
    NUMBER2: /[0-9_\.\,]+/,
    STRING2: /"[^"]*"|'[^']*'/
  };
})(Zc || (Zc = {}));
({
  ...Kc.Terminals,
  ...Hc.Terminals,
  ...Yc.Terminals,
  ...Xc.Terminals,
  ...Jc.Terminals,
  ...Qc.Terminals,
  ...Zc.Terminals
});
var Kt = {
  $type: "Architecture",
  accDescr: "accDescr",
  accTitle: "accTitle",
  edges: "edges",
  groups: "groups",
  junctions: "junctions",
  services: "services",
  title: "title"
};
function Tv(t) {
  return bt.isInstance(t, Kt.$type);
}
$(Tv, "isArchitecture");
var Us = {
  $type: "Axis",
  label: "label",
  name: "name"
}, ra = {
  $type: "Branch",
  name: "name",
  order: "order"
};
function Rv(t) {
  return bt.isInstance(t, ra.$type);
}
$(Rv, "isBranch");
var Rd = {
  $type: "Checkout",
  branch: "branch"
}, qs = {
  $type: "CherryPicking",
  id: "id",
  parent: "parent",
  tags: "tags"
}, uo = {
  $type: "ClassDefStatement",
  className: "className",
  styleText: "styleText"
}, mr = {
  $type: "Commit",
  id: "id",
  message: "message",
  tags: "tags",
  type: "type"
};
function vv(t) {
  return bt.isInstance(t, mr.$type);
}
$(vv, "isCommit");
var js = {
  $type: "Curve",
  entries: "entries",
  label: "label",
  name: "name"
}, ir = {
  $type: "Direction",
  accDescr: "accDescr",
  accTitle: "accTitle",
  dir: "dir",
  statements: "statements",
  title: "title"
}, It = {
  $type: "Edge",
  lhsDir: "lhsDir",
  lhsGroup: "lhsGroup",
  lhsId: "lhsId",
  lhsInto: "lhsInto",
  rhsDir: "rhsDir",
  rhsGroup: "rhsGroup",
  rhsId: "rhsId",
  rhsInto: "rhsInto",
  title: "title"
}, fo = {
  $type: "Entry",
  axis: "axis",
  value: "value"
}, Mn = {
  $type: "GitGraph",
  accDescr: "accDescr",
  accTitle: "accTitle",
  statements: "statements",
  title: "title"
};
function Ev(t) {
  return bt.isInstance(t, Mn.$type);
}
$(Ev, "isGitGraph");
var Ii = {
  $type: "Group",
  icon: "icon",
  id: "id",
  in: "in",
  title: "title"
}, Ui = {
  $type: "Info",
  accDescr: "accDescr",
  accTitle: "accTitle",
  title: "title"
};
function Av(t) {
  return bt.isInstance(t, Ui.$type);
}
$(Av, "isInfo");
var Pi = {
  $type: "Item",
  classSelector: "classSelector",
  name: "name"
}, ho = {
  $type: "Junction",
  id: "id",
  in: "in"
}, zs = {
  $type: "Leaf",
  classSelector: "classSelector",
  name: "name",
  value: "value"
}, gr = {
  $type: "Merge",
  branch: "branch",
  id: "id",
  tags: "tags",
  type: "type"
};
function Sv(t) {
  return bt.isInstance(t, gr.$type);
}
$(Sv, "isMerge");
var po = {
  $type: "Option",
  name: "name",
  value: "value"
}, yr = {
  $type: "Packet",
  accDescr: "accDescr",
  accTitle: "accTitle",
  blocks: "blocks",
  title: "title"
};
function kv(t) {
  return bt.isInstance(t, yr.$type);
}
$(kv, "isPacket");
var Tr = {
  $type: "PacketBlock",
  bits: "bits",
  end: "end",
  label: "label",
  start: "start"
};
function Cv(t) {
  return bt.isInstance(t, Tr.$type);
}
$(Cv, "isPacketBlock");
var Fn = {
  $type: "Pie",
  accDescr: "accDescr",
  accTitle: "accTitle",
  sections: "sections",
  showData: "showData",
  title: "title"
};
function Nv(t) {
  return bt.isInstance(t, Fn.$type);
}
$(Nv, "isPie");
var ia = {
  $type: "PieSection",
  label: "label",
  value: "value"
};
function wv(t) {
  return bt.isInstance(t, ia.$type);
}
$(wv, "isPieSection");
var $n = {
  $type: "Radar",
  accDescr: "accDescr",
  accTitle: "accTitle",
  axes: "axes",
  curves: "curves",
  options: "options",
  title: "title"
}, mo = {
  $type: "Section",
  classSelector: "classSelector",
  name: "name"
}, sr = {
  $type: "Service",
  icon: "icon",
  iconText: "iconText",
  id: "id",
  in: "in",
  title: "title"
}, ar = {
  $type: "Statement"
}, Rr = {
  $type: "Treemap",
  accDescr: "accDescr",
  accTitle: "accTitle",
  title: "title",
  TreemapRows: "TreemapRows"
};
function bv(t) {
  return bt.isInstance(t, Rr.$type);
}
$(bv, "isTreemap");
var go = {
  $type: "TreemapRow",
  indent: "indent",
  item: "item"
}, Sr, gh = (Sr = class extends xd {
  constructor() {
    super(...arguments), this.types = {
      Architecture: {
        name: Kt.$type,
        properties: {
          accDescr: {
            name: Kt.accDescr
          },
          accTitle: {
            name: Kt.accTitle
          },
          edges: {
            name: Kt.edges,
            defaultValue: []
          },
          groups: {
            name: Kt.groups,
            defaultValue: []
          },
          junctions: {
            name: Kt.junctions,
            defaultValue: []
          },
          services: {
            name: Kt.services,
            defaultValue: []
          },
          title: {
            name: Kt.title
          }
        },
        superTypes: []
      },
      Axis: {
        name: Us.$type,
        properties: {
          label: {
            name: Us.label
          },
          name: {
            name: Us.name
          }
        },
        superTypes: []
      },
      Branch: {
        name: ra.$type,
        properties: {
          name: {
            name: ra.name
          },
          order: {
            name: ra.order
          }
        },
        superTypes: [ar.$type]
      },
      Checkout: {
        name: Rd.$type,
        properties: {
          branch: {
            name: Rd.branch
          }
        },
        superTypes: [ar.$type]
      },
      CherryPicking: {
        name: qs.$type,
        properties: {
          id: {
            name: qs.id
          },
          parent: {
            name: qs.parent
          },
          tags: {
            name: qs.tags,
            defaultValue: []
          }
        },
        superTypes: [ar.$type]
      },
      ClassDefStatement: {
        name: uo.$type,
        properties: {
          className: {
            name: uo.className
          },
          styleText: {
            name: uo.styleText
          }
        },
        superTypes: []
      },
      Commit: {
        name: mr.$type,
        properties: {
          id: {
            name: mr.id
          },
          message: {
            name: mr.message
          },
          tags: {
            name: mr.tags,
            defaultValue: []
          },
          type: {
            name: mr.type
          }
        },
        superTypes: [ar.$type]
      },
      Curve: {
        name: js.$type,
        properties: {
          entries: {
            name: js.entries,
            defaultValue: []
          },
          label: {
            name: js.label
          },
          name: {
            name: js.name
          }
        },
        superTypes: []
      },
      Direction: {
        name: ir.$type,
        properties: {
          accDescr: {
            name: ir.accDescr
          },
          accTitle: {
            name: ir.accTitle
          },
          dir: {
            name: ir.dir
          },
          statements: {
            name: ir.statements,
            defaultValue: []
          },
          title: {
            name: ir.title
          }
        },
        superTypes: [Mn.$type]
      },
      Edge: {
        name: It.$type,
        properties: {
          lhsDir: {
            name: It.lhsDir
          },
          lhsGroup: {
            name: It.lhsGroup,
            defaultValue: !1
          },
          lhsId: {
            name: It.lhsId
          },
          lhsInto: {
            name: It.lhsInto,
            defaultValue: !1
          },
          rhsDir: {
            name: It.rhsDir
          },
          rhsGroup: {
            name: It.rhsGroup,
            defaultValue: !1
          },
          rhsId: {
            name: It.rhsId
          },
          rhsInto: {
            name: It.rhsInto,
            defaultValue: !1
          },
          title: {
            name: It.title
          }
        },
        superTypes: []
      },
      Entry: {
        name: fo.$type,
        properties: {
          axis: {
            name: fo.axis,
            referenceType: Us.$type
          },
          value: {
            name: fo.value
          }
        },
        superTypes: []
      },
      GitGraph: {
        name: Mn.$type,
        properties: {
          accDescr: {
            name: Mn.accDescr
          },
          accTitle: {
            name: Mn.accTitle
          },
          statements: {
            name: Mn.statements,
            defaultValue: []
          },
          title: {
            name: Mn.title
          }
        },
        superTypes: []
      },
      Group: {
        name: Ii.$type,
        properties: {
          icon: {
            name: Ii.icon
          },
          id: {
            name: Ii.id
          },
          in: {
            name: Ii.in
          },
          title: {
            name: Ii.title
          }
        },
        superTypes: []
      },
      Info: {
        name: Ui.$type,
        properties: {
          accDescr: {
            name: Ui.accDescr
          },
          accTitle: {
            name: Ui.accTitle
          },
          title: {
            name: Ui.title
          }
        },
        superTypes: []
      },
      Item: {
        name: Pi.$type,
        properties: {
          classSelector: {
            name: Pi.classSelector
          },
          name: {
            name: Pi.name
          }
        },
        superTypes: []
      },
      Junction: {
        name: ho.$type,
        properties: {
          id: {
            name: ho.id
          },
          in: {
            name: ho.in
          }
        },
        superTypes: []
      },
      Leaf: {
        name: zs.$type,
        properties: {
          classSelector: {
            name: zs.classSelector
          },
          name: {
            name: zs.name
          },
          value: {
            name: zs.value
          }
        },
        superTypes: [Pi.$type]
      },
      Merge: {
        name: gr.$type,
        properties: {
          branch: {
            name: gr.branch
          },
          id: {
            name: gr.id
          },
          tags: {
            name: gr.tags,
            defaultValue: []
          },
          type: {
            name: gr.type
          }
        },
        superTypes: [ar.$type]
      },
      Option: {
        name: po.$type,
        properties: {
          name: {
            name: po.name
          },
          value: {
            name: po.value,
            defaultValue: !1
          }
        },
        superTypes: []
      },
      Packet: {
        name: yr.$type,
        properties: {
          accDescr: {
            name: yr.accDescr
          },
          accTitle: {
            name: yr.accTitle
          },
          blocks: {
            name: yr.blocks,
            defaultValue: []
          },
          title: {
            name: yr.title
          }
        },
        superTypes: []
      },
      PacketBlock: {
        name: Tr.$type,
        properties: {
          bits: {
            name: Tr.bits
          },
          end: {
            name: Tr.end
          },
          label: {
            name: Tr.label
          },
          start: {
            name: Tr.start
          }
        },
        superTypes: []
      },
      Pie: {
        name: Fn.$type,
        properties: {
          accDescr: {
            name: Fn.accDescr
          },
          accTitle: {
            name: Fn.accTitle
          },
          sections: {
            name: Fn.sections,
            defaultValue: []
          },
          showData: {
            name: Fn.showData,
            defaultValue: !1
          },
          title: {
            name: Fn.title
          }
        },
        superTypes: []
      },
      PieSection: {
        name: ia.$type,
        properties: {
          label: {
            name: ia.label
          },
          value: {
            name: ia.value
          }
        },
        superTypes: []
      },
      Radar: {
        name: $n.$type,
        properties: {
          accDescr: {
            name: $n.accDescr
          },
          accTitle: {
            name: $n.accTitle
          },
          axes: {
            name: $n.axes,
            defaultValue: []
          },
          curves: {
            name: $n.curves,
            defaultValue: []
          },
          options: {
            name: $n.options,
            defaultValue: []
          },
          title: {
            name: $n.title
          }
        },
        superTypes: []
      },
      Section: {
        name: mo.$type,
        properties: {
          classSelector: {
            name: mo.classSelector
          },
          name: {
            name: mo.name
          }
        },
        superTypes: [Pi.$type]
      },
      Service: {
        name: sr.$type,
        properties: {
          icon: {
            name: sr.icon
          },
          iconText: {
            name: sr.iconText
          },
          id: {
            name: sr.id
          },
          in: {
            name: sr.in
          },
          title: {
            name: sr.title
          }
        },
        superTypes: []
      },
      Statement: {
        name: ar.$type,
        properties: {},
        superTypes: []
      },
      Treemap: {
        name: Rr.$type,
        properties: {
          accDescr: {
            name: Rr.accDescr
          },
          accTitle: {
            name: Rr.accTitle
          },
          title: {
            name: Rr.title
          },
          TreemapRows: {
            name: Rr.TreemapRows,
            defaultValue: []
          }
        },
        superTypes: []
      },
      TreemapRow: {
        name: go.$type,
        properties: {
          indent: {
            name: go.indent
          },
          item: {
            name: go.item
          }
        },
        superTypes: []
      }
    };
  }
}, $(Sr, "MermaidAstReflection"), Sr), bt = new gh(), vd, _v = /* @__PURE__ */ $(() => vd ?? (vd = Jn(`{"$type":"Grammar","isDeclared":true,"name":"ArchitectureGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Architecture","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[],"cardinality":"*"},{"$type":"Keyword","value":"architecture-beta"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Statement","definition":{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"groups","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"services","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"junctions","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}},{"$type":"Assignment","feature":"edges","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"LeftPort","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"lhsDir","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"RightPort","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"rhsDir","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Keyword","value":":"}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Arrow","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]},{"$type":"Assignment","feature":"lhsInto","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"--"},{"$type":"Group","elements":[{"$type":"Keyword","value":"-"},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]}},{"$type":"Keyword","value":"-"}]}]},{"$type":"Assignment","feature":"rhsInto","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"Group","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"group"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Assignment","feature":"icon","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@28"},"arguments":[]},"cardinality":"?"},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]},"cardinality":"?"},{"$type":"Group","elements":[{"$type":"Keyword","value":"in"},{"$type":"Assignment","feature":"in","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Service","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"service"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"iconText","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]}},{"$type":"Assignment","feature":"icon","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@28"},"arguments":[]}}],"cardinality":"?"},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]},"cardinality":"?"},{"$type":"Group","elements":[{"$type":"Keyword","value":"in"},{"$type":"Assignment","feature":"in","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Junction","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"junction"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"in"},{"$type":"Assignment","feature":"in","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Edge","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"lhsId","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Assignment","feature":"lhsGroup","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]},{"$type":"Assignment","feature":"rhsId","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Assignment","feature":"rhsGroup","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"ARROW_DIRECTION","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"L"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"R"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"T"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"B"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARROW_GROUP","definition":{"$type":"RegexToken","regex":"/\\\\{group\\\\}/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARROW_INTO","definition":{"$type":"RegexToken","regex":"/<|>/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@18"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@19"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","name":"ARCH_ICON","definition":{"$type":"RegexToken","regex":"/\\\\([\\\\w-:]+\\\\)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARCH_TITLE","definition":{"$type":"RegexToken","regex":"/\\\\[(?:\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'|[\\\\w ]+)\\\\]/","parenthesized":false},"fragment":false,"hidden":false}],"interfaces":[],"types":[]}`)), "ArchitectureGrammarGrammar"), Ed, Iv = /* @__PURE__ */ $(() => Ed ?? (Ed = Jn(`{"$type":"Grammar","isDeclared":true,"name":"GitGraphGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"GitGraph","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"gitGraph"},{"$type":"Group","elements":[{"$type":"Keyword","value":"gitGraph"},{"$type":"Keyword","value":":"}]},{"$type":"Keyword","value":"gitGraph:"},{"$type":"Group","elements":[{"$type":"Keyword","value":"gitGraph"},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]},{"$type":"Keyword","value":":"}]}]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]},{"$type":"Assignment","feature":"statements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Statement","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Direction","definition":{"$type":"Assignment","feature":"dir","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"LR"},{"$type":"Keyword","value":"TB"},{"$type":"Keyword","value":"BT"}]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Commit","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"commit"},{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"id:"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"msg:","cardinality":"?"},{"$type":"Assignment","feature":"message","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"tag:"},{"$type":"Assignment","feature":"tags","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"type:"},{"$type":"Assignment","feature":"type","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"NORMAL"},{"$type":"Keyword","value":"REVERSE"},{"$type":"Keyword","value":"HIGHLIGHT"}]}}]}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Branch","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"branch"},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"order:"},{"$type":"Assignment","feature":"order","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Merge","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"merge"},{"$type":"Assignment","feature":"branch","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}]}},{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"id:"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"tag:"},{"$type":"Assignment","feature":"tags","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"type:"},{"$type":"Assignment","feature":"type","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"NORMAL"},{"$type":"Keyword","value":"REVERSE"},{"$type":"Keyword","value":"HIGHLIGHT"}]}}]}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Checkout","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"checkout"},{"$type":"Keyword","value":"switch"}]},{"$type":"Assignment","feature":"branch","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"CherryPicking","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"cherry-pick"},{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"id:"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"tag:"},{"$type":"Assignment","feature":"tags","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"parent:"},{"$type":"Assignment","feature":"parent","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@14"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@15"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","name":"REFERENCE","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\\\w([-\\\\./\\\\w]*[-\\\\w])?/","parenthesized":false},"fragment":false,"hidden":false}],"interfaces":[],"types":[]}`)), "GitGraphGrammarGrammar"), Ad, Pv = /* @__PURE__ */ $(() => Ad ?? (Ad = Jn(`{"$type":"Grammar","isDeclared":true,"name":"InfoGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Info","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"*"},{"$type":"Keyword","value":"info"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"*"},{"$type":"Group","elements":[{"$type":"Keyword","value":"showInfo"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"*"}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[],"cardinality":"?"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@7"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@8"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "InfoGrammarGrammar"), Sd, $v = /* @__PURE__ */ $(() => Sd ?? (Sd = Jn(`{"$type":"Grammar","isDeclared":true,"name":"PacketGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Packet","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"packet"},{"$type":"Keyword","value":"packet-beta"}]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]},{"$type":"Assignment","feature":"blocks","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PacketBlock","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Assignment","feature":"start","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"-"},{"$type":"Assignment","feature":"end","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}}],"cardinality":"?"}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"+"},{"$type":"Assignment","feature":"bits","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}}]}]},{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@8"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@9"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "PacketGrammarGrammar"), kd, Lv = /* @__PURE__ */ $(() => kd ?? (kd = Jn(`{"$type":"Grammar","isDeclared":true,"name":"PieGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Pie","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"*"},{"$type":"Keyword","value":"pie"},{"$type":"Assignment","feature":"showData","operator":"?=","terminal":{"$type":"Keyword","value":"showData"},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"Assignment","feature":"sections","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PieSection","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"FLOAT_PIE","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/-?[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT_PIE","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/-?(0|[1-9][0-9]*)(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER_PIE","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@2"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@3"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@11"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@12"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "PieGrammarGrammar"), Cd, Ov = /* @__PURE__ */ $(() => Cd ?? (Cd = Jn(`{"$type":"Grammar","isDeclared":true,"name":"RadarGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Radar","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"radar-beta"},{"$type":"Keyword","value":"radar-beta:"},{"$type":"Group","elements":[{"$type":"Keyword","value":"radar-beta"},{"$type":"Keyword","value":":"}]}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]},{"$type":"Group","elements":[{"$type":"Keyword","value":"axis"},{"$type":"Assignment","feature":"axes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"axes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"*"}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"curve"},{"$type":"Assignment","feature":"curves","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"curves","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}}],"cardinality":"*"}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"options","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"options","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}}],"cardinality":"*"}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Label","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}},{"$type":"Keyword","value":"]"}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"Axis","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Curve","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[],"cardinality":"?"},{"$type":"Keyword","value":"{"},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]},{"$type":"Keyword","value":"}"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Entries","definition":{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"}]},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"}]}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"DetailedEntry","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"axis","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@2"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}},{"$type":"Keyword","value":":","cardinality":"?"},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"NumberEntry","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Option","definition":{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"showLegend"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"ticks"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"max"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"min"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"graticule"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}}]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"GRATICULE","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"circle"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"polygon"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@15"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@16"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[{"$type":"Interface","name":"Entry","attributes":[{"$type":"TypeAttribute","name":"axis","isOptional":true,"type":{"$type":"ReferenceType","referenceType":{"$type":"SimpleType","typeRef":{"$ref":"#/rules@2"}},"isMulti":false}},{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"number"},"isOptional":false}],"superTypes":[]}],"types":[]}`)), "RadarGrammarGrammar"), Nd, xv = /* @__PURE__ */ $(() => Nd ?? (Nd = Jn(`{"$type":"Grammar","isDeclared":true,"name":"TreemapGrammar","rules":[{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","entry":true,"name":"Treemap","returnType":{"$ref":"#/interfaces@4"},"definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]},{"$type":"Assignment","feature":"TreemapRows","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"TREEMAP_KEYWORD","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"treemap-beta"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"treemap"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"CLASS_DEF","definition":{"$type":"RegexToken","regex":"/classDef\\\\s+([a-zA-Z_][a-zA-Z0-9_]+)(?:\\\\s+([^;\\\\r\\\\n]*))?(?:;)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STYLE_SEPARATOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":":::"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"SEPARATOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":":"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"COMMA","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":","},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INDENTATION","definition":{"$type":"RegexToken","regex":"/[ \\\\t]{1,}/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WS","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ML_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\%\\\\%[^\\\\n]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"NL","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false},{"$type":"ParserRule","name":"TreemapRow","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"indent","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"item","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"ClassDef","dataType":"string","definition":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Item","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Section","returnType":{"$ref":"#/interfaces@1"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]},{"$type":"Assignment","feature":"classSelector","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}}],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Leaf","returnType":{"$ref":"#/interfaces@2"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[],"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[],"cardinality":"?"},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]},{"$type":"Assignment","feature":"classSelector","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}}],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"ID2","definition":{"$type":"RegexToken","regex":"/[a-zA-Z_][a-zA-Z0-9_]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER2","definition":{"$type":"RegexToken","regex":"/[0-9_\\\\.\\\\,]+/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"MyNumber","dataType":"number","definition":{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"STRING2","definition":{"$type":"RegexToken","regex":"/\\"[^\\"]*\\"|'[^']*'/","parenthesized":false},"fragment":false,"hidden":false}],"interfaces":[{"$type":"Interface","name":"Item","attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"classSelector","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]},{"$type":"Interface","name":"Section","superTypes":[{"$ref":"#/interfaces@0"}],"attributes":[]},{"$type":"Interface","name":"Leaf","superTypes":[{"$ref":"#/interfaces@0"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"number"},"isOptional":false}]},{"$type":"Interface","name":"ClassDefStatement","attributes":[{"$type":"TypeAttribute","name":"className","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"styleText","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"Treemap","attributes":[{"$type":"TypeAttribute","name":"TreemapRows","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/rules@15"}}},"isOptional":false},{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]}],"imports":[],"types":[],"$comment":"/**\\n * Treemap grammar for Langium\\n * Converted from mindmap grammar\\n *\\n * The ML_COMMENT and NL hidden terminals handle whitespace, comments, and newlines\\n * before the treemap keyword, allowing for empty lines and comments before the\\n * treemap declaration.\\n */"}`)), "TreemapGrammarGrammar"), Dv = {
  languageId: "architecture",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, Mv = {
  languageId: "gitGraph",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, Fv = {
  languageId: "info",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, Gv = {
  languageId: "packet",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, Uv = {
  languageId: "pie",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, qv = {
  languageId: "radar",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, jv = {
  languageId: "treemap",
  fileExtensions: [".mmd", ".mermaid"],
  caseInsensitive: !1,
  mode: "production"
}, Qn = {
  AstReflection: /* @__PURE__ */ $(() => new gh(), "AstReflection")
}, zv = {
  Grammar: /* @__PURE__ */ $(() => _v(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => Dv, "LanguageMetaData"),
  parser: {}
}, Bv = {
  Grammar: /* @__PURE__ */ $(() => Iv(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => Mv, "LanguageMetaData"),
  parser: {}
}, Wv = {
  Grammar: /* @__PURE__ */ $(() => Pv(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => Fv, "LanguageMetaData"),
  parser: {}
}, Vv = {
  Grammar: /* @__PURE__ */ $(() => $v(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => Gv, "LanguageMetaData"),
  parser: {}
}, Kv = {
  Grammar: /* @__PURE__ */ $(() => Lv(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => Uv, "LanguageMetaData"),
  parser: {}
}, Hv = {
  Grammar: /* @__PURE__ */ $(() => Ov(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => qv, "LanguageMetaData"),
  parser: {}
}, Yv = {
  Grammar: /* @__PURE__ */ $(() => xv(), "Grammar"),
  LanguageMetaData: /* @__PURE__ */ $(() => jv, "LanguageMetaData"),
  parser: {}
}, Xv = /accDescr(?:[\t ]*:([^\n\r]*)|\s*{([^}]*)})/, Jv = /accTitle[\t ]*:([^\n\r]*)/, Qv = /title([\t ][^\n\r]*|)/, Zv = {
  ACC_DESCR: Xv,
  ACC_TITLE: Jv,
  TITLE: Qv
}, kr, Ba = (kr = class extends th {
  runConverter(e, n, r) {
    let i = this.runCommonConverter(e, n, r);
    return i === void 0 && (i = this.runCustomConverter(e, n, r)), i === void 0 ? super.runConverter(e, n, r) : i;
  }
  runCommonConverter(e, n, r) {
    const i = Zv[e.name];
    if (i === void 0)
      return;
    const s = i.exec(n);
    if (s !== null) {
      if (s[1] !== void 0)
        return s[1].trim().replace(/[\t ]{2,}/gm, " ");
      if (s[2] !== void 0)
        return s[2].replace(/^\s*/gm, "").replace(/\s+$/gm, "").replace(/[\t ]{2,}/gm, " ").replace(/[\n\r]{2,}/gm, `
`);
    }
  }
}, $(kr, "AbstractMermaidValueConverter"), kr), Cr, Wa = (Cr = class extends Ba {
  runCustomConverter(e, n, r) {
  }
}, $(Cr, "CommonValueConverter"), Cr), Nr, Rn = (Nr = class extends eh {
  constructor(e) {
    super(), this.keywords = new Set(e);
  }
  buildKeywordTokens(e, n, r) {
    const i = super.buildKeywordTokens(e, n, r);
    return i.forEach((s) => {
      this.keywords.has(s.name) && s.PATTERN !== void 0 && (s.PATTERN = new RegExp(s.PATTERN.toString() + "(?:(?=%%)|(?!\\S))"));
    }), i;
  }
}, $(Nr, "AbstractMermaidTokenBuilder"), Nr), wr;
wr = class extends Rn {
}, $(wr, "CommonTokenBuilder");
var br, eE = (br = class extends Rn {
  constructor() {
    super(["gitGraph"]);
  }
}, $(br, "GitGraphTokenBuilder"), br), yh = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new eE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new Wa(), "ValueConverter")
  }
};
function Th(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    Bv,
    yh
  );
  return e.ServiceRegistry.register(n), { shared: e, GitGraph: n };
}
$(Th, "createGitGraphServices");
var _r, tE = (_r = class extends Rn {
  constructor() {
    super(["info", "showInfo"]);
  }
}, $(_r, "InfoTokenBuilder"), _r), Rh = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new tE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new Wa(), "ValueConverter")
  }
};
function vh(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    Wv,
    Rh
  );
  return e.ServiceRegistry.register(n), { shared: e, Info: n };
}
$(vh, "createInfoServices");
var Ir, nE = (Ir = class extends Rn {
  constructor() {
    super(["packet"]);
  }
}, $(Ir, "PacketTokenBuilder"), Ir), Eh = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new nE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new Wa(), "ValueConverter")
  }
};
function Ah(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    Vv,
    Eh
  );
  return e.ServiceRegistry.register(n), { shared: e, Packet: n };
}
$(Ah, "createPacketServices");
var Pr, rE = (Pr = class extends Rn {
  constructor() {
    super(["pie", "showData"]);
  }
}, $(Pr, "PieTokenBuilder"), Pr), $r, iE = ($r = class extends Ba {
  runCustomConverter(e, n, r) {
    if (e.name === "PIE_SECTION_LABEL")
      return n.replace(/"/g, "").trim();
  }
}, $($r, "PieValueConverter"), $r), Sh = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new rE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new iE(), "ValueConverter")
  }
};
function kh(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    Kv,
    Sh
  );
  return e.ServiceRegistry.register(n), { shared: e, Pie: n };
}
$(kh, "createPieServices");
var Lr, sE = (Lr = class extends Rn {
  constructor() {
    super(["architecture"]);
  }
}, $(Lr, "ArchitectureTokenBuilder"), Lr), Or, aE = (Or = class extends Ba {
  runCustomConverter(e, n, r) {
    if (e.name === "ARCH_ICON")
      return n.replace(/[()]/g, "").trim();
    if (e.name === "ARCH_TEXT_ICON")
      return n.replace(/["()]/g, "");
    if (e.name === "ARCH_TITLE") {
      let i = n.replace(/^\[|]$/g, "").trim();
      return (i.startsWith('"') && i.endsWith('"') || i.startsWith("'") && i.endsWith("'")) && (i = i.slice(1, -1), i = i.replace(/\\"/g, '"').replace(/\\'/g, "'")), i.trim();
    }
  }
}, $(Or, "ArchitectureValueConverter"), Or), Ch = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new sE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new aE(), "ValueConverter")
  }
};
function Nh(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    zv,
    Ch
  );
  return e.ServiceRegistry.register(n), { shared: e, Architecture: n };
}
$(Nh, "createArchitectureServices");
var xr, oE = (xr = class extends Rn {
  constructor() {
    super(["radar-beta"]);
  }
}, $(xr, "RadarTokenBuilder"), xr), wh = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new oE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new Wa(), "ValueConverter")
  }
};
function bh(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    Hv,
    wh
  );
  return e.ServiceRegistry.register(n), { shared: e, Radar: n };
}
$(bh, "createRadarServices");
var Dr, cE = (Dr = class extends Rn {
  constructor() {
    super(["treemap"]);
  }
}, $(Dr, "TreemapTokenBuilder"), Dr), lE = /classDef\s+([A-Z_a-z]\w+)(?:\s+([^\n\r;]*))?;?/, Mr, uE = (Mr = class extends Ba {
  runCustomConverter(e, n, r) {
    if (e.name === "NUMBER2")
      return parseFloat(n.replace(/,/g, ""));
    if (e.name === "SEPARATOR")
      return n.substring(1, n.length - 1);
    if (e.name === "STRING2")
      return n.substring(1, n.length - 1);
    if (e.name === "INDENTATION")
      return n.length;
    if (e.name === "ClassDef") {
      if (typeof n != "string")
        return n;
      const i = lE.exec(n);
      if (i)
        return {
          $type: "ClassDefStatement",
          className: i[1],
          styleText: i[2] || void 0
        };
    }
  }
}, $(Mr, "TreemapValueConverter"), Mr);
function _h(t) {
  const e = t.validation.TreemapValidator, n = t.validation.ValidationRegistry;
  if (n) {
    const r = {
      Treemap: e.checkSingleRoot.bind(e)
      // Remove unused validation for TreemapRow
    };
    n.register(r, e);
  }
}
$(_h, "registerValidationChecks");
var Fr, dE = (Fr = class {
  /**
   * Validates that a treemap has only one root node.
   * A root node is defined as a node that has no indentation.
   */
  checkSingleRoot(e, n) {
    let r;
    for (const i of e.TreemapRows)
      i.item && (r === void 0 && // Check if this is a root node (no indentation)
      i.indent === void 0 ? r = 0 : i.indent === void 0 ? n("error", "Multiple root nodes are not allowed in a treemap.", {
        node: i,
        property: "item"
      }) : r !== void 0 && r >= parseInt(i.indent, 10) && n("error", "Multiple root nodes are not allowed in a treemap.", {
        node: i,
        property: "item"
      }));
  }
}, $(Fr, "TreemapValidator"), Fr), Ih = {
  parser: {
    TokenBuilder: /* @__PURE__ */ $(() => new cE(), "TokenBuilder"),
    ValueConverter: /* @__PURE__ */ $(() => new uE(), "ValueConverter")
  },
  validation: {
    TreemapValidator: /* @__PURE__ */ $(() => new dE(), "TreemapValidator")
  }
};
function Ph(t = Tn) {
  const e = Ve(
    yn(t),
    Qn
  ), n = Ve(
    gn({ shared: e }),
    Yv,
    Ih
  );
  return e.ServiceRegistry.register(n), _h(n), { shared: e, Treemap: n };
}
$(Ph, "createTreemapServices");
var Yt = {}, fE = {
  info: /* @__PURE__ */ $(async () => {
    const { createInfoServices: t } = await Promise.resolve().then(() => mE), e = t().Info.parser.LangiumParser;
    Yt.info = e;
  }, "info"),
  packet: /* @__PURE__ */ $(async () => {
    const { createPacketServices: t } = await Promise.resolve().then(() => gE), e = t().Packet.parser.LangiumParser;
    Yt.packet = e;
  }, "packet"),
  pie: /* @__PURE__ */ $(async () => {
    const { createPieServices: t } = await Promise.resolve().then(() => yE), e = t().Pie.parser.LangiumParser;
    Yt.pie = e;
  }, "pie"),
  architecture: /* @__PURE__ */ $(async () => {
    const { createArchitectureServices: t } = await Promise.resolve().then(() => TE), e = t().Architecture.parser.LangiumParser;
    Yt.architecture = e;
  }, "architecture"),
  gitGraph: /* @__PURE__ */ $(async () => {
    const { createGitGraphServices: t } = await Promise.resolve().then(() => RE), e = t().GitGraph.parser.LangiumParser;
    Yt.gitGraph = e;
  }, "gitGraph"),
  radar: /* @__PURE__ */ $(async () => {
    const { createRadarServices: t } = await Promise.resolve().then(() => vE), e = t().Radar.parser.LangiumParser;
    Yt.radar = e;
  }, "radar"),
  treemap: /* @__PURE__ */ $(async () => {
    const { createTreemapServices: t } = await Promise.resolve().then(() => EE), e = t().Treemap.parser.LangiumParser;
    Yt.treemap = e;
  }, "treemap")
};
async function hE(t, e) {
  const n = fE[t];
  if (!n)
    throw new Error(`Unknown diagram type: ${t}`);
  Yt[t] || await n();
  const i = Yt[t].parse(e);
  if (i.lexerErrors.length > 0 || i.parserErrors.length > 0)
    throw new pE(i);
  return i.value;
}
$(hE, "parse");
var Gr, pE = (Gr = class extends Error {
  constructor(e) {
    const n = e.lexerErrors.map((i) => {
      const s = i.line !== void 0 && !isNaN(i.line) ? i.line : "?", a = i.column !== void 0 && !isNaN(i.column) ? i.column : "?";
      return `Lexer error on line ${s}, column ${a}: ${i.message}`;
    }).join(`
`), r = e.parserErrors.map((i) => {
      const s = i.token.startLine !== void 0 && !isNaN(i.token.startLine) ? i.token.startLine : "?", a = i.token.startColumn !== void 0 && !isNaN(i.token.startColumn) ? i.token.startColumn : "?";
      return `Parse error on line ${s}, column ${a}: ${i.message}`;
    }).join(`
`);
    super(`Parsing failed: ${n} ${r}`), this.result = e;
  }
}, $(Gr, "MermaidParseError"), Gr);
const mE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  InfoModule: Rh,
  createInfoServices: vh
}, Symbol.toStringTag, { value: "Module" })), gE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  PacketModule: Eh,
  createPacketServices: Ah
}, Symbol.toStringTag, { value: "Module" })), yE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  PieModule: Sh,
  createPieServices: kh
}, Symbol.toStringTag, { value: "Module" })), TE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ArchitectureModule: Ch,
  createArchitectureServices: Nh
}, Symbol.toStringTag, { value: "Module" })), RE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GitGraphModule: yh,
  createGitGraphServices: Th
}, Symbol.toStringTag, { value: "Module" })), vE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  RadarModule: wh,
  createRadarServices: bh
}, Symbol.toStringTag, { value: "Module" })), EE = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  TreemapModule: Ih,
  createTreemapServices: Ph
}, Symbol.toStringTag, { value: "Module" }));
export {
  hE as p
};
