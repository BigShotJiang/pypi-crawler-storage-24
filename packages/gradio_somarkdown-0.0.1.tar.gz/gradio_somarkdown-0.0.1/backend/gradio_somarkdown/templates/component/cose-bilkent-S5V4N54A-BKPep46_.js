import { _ as V, l as $, d as lt } from "./mermaid.core-DfOz2mRZ.js";
import { c as tt } from "./cytoscape.esm-Cvf3sx9F.js";
import { g as gt } from "./Index-CcLf415l.js";
var k = { exports: {} }, Z = { exports: {} }, Q = { exports: {} }, ut = Q.exports, j;
function ft() {
  return j || (j = 1, (function(G, b) {
    (function(I, L) {
      G.exports = L();
    })(ut, function() {
      return (
        /******/
        (function(N) {
          var I = {};
          function L(o) {
            if (I[o])
              return I[o].exports;
            var e = I[o] = {
              /******/
              i: o,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return N[o].call(e.exports, e, e.exports, L), e.l = !0, e.exports;
          }
          return L.m = N, L.c = I, L.i = function(o) {
            return o;
          }, L.d = function(o, e, t) {
            L.o(o, e) || Object.defineProperty(o, e, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: t
              /******/
            });
          }, L.n = function(o) {
            var e = o && o.__esModule ? (
              /******/
              function() {
                return o.default;
              }
            ) : (
              /******/
              function() {
                return o;
              }
            );
            return L.d(e, "a", e), e;
          }, L.o = function(o, e) {
            return Object.prototype.hasOwnProperty.call(o, e);
          }, L.p = "", L(L.s = 26);
        })([
          /* 0 */
          /***/
          (function(N, I, L) {
            function o() {
            }
            o.QUALITY = 1, o.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, o.DEFAULT_INCREMENTAL = !1, o.DEFAULT_ANIMATION_ON_LAYOUT = !0, o.DEFAULT_ANIMATION_DURING_LAYOUT = !1, o.DEFAULT_ANIMATION_PERIOD = 50, o.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, o.DEFAULT_GRAPH_MARGIN = 15, o.NODE_DIMENSIONS_INCLUDE_LABELS = !1, o.SIMPLE_NODE_SIZE = 40, o.SIMPLE_NODE_HALF_SIZE = o.SIMPLE_NODE_SIZE / 2, o.EMPTY_COMPOUND_NODE_SIZE = 40, o.MIN_EDGE_LENGTH = 1, o.WORLD_BOUNDARY = 1e6, o.INITIAL_WORLD_BOUNDARY = o.WORLD_BOUNDARY / 1e3, o.WORLD_CENTER_X = 1200, o.WORLD_CENTER_Y = 900, N.exports = o;
          }),
          /* 1 */
          /***/
          (function(N, I, L) {
            var o = L(2), e = L(8), t = L(9);
            function i(g, n, d) {
              o.call(this, d), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = d, this.bendpoints = [], this.source = g, this.target = n;
            }
            i.prototype = Object.create(o.prototype);
            for (var l in o)
              i[l] = o[l];
            i.prototype.getSource = function() {
              return this.source;
            }, i.prototype.getTarget = function() {
              return this.target;
            }, i.prototype.isInterGraph = function() {
              return this.isInterGraph;
            }, i.prototype.getLength = function() {
              return this.length;
            }, i.prototype.isOverlapingSourceAndTarget = function() {
              return this.isOverlapingSourceAndTarget;
            }, i.prototype.getBendpoints = function() {
              return this.bendpoints;
            }, i.prototype.getLca = function() {
              return this.lca;
            }, i.prototype.getSourceInLca = function() {
              return this.sourceInLca;
            }, i.prototype.getTargetInLca = function() {
              return this.targetInLca;
            }, i.prototype.getOtherEnd = function(g) {
              if (this.source === g)
                return this.target;
              if (this.target === g)
                return this.source;
              throw "Node is not incident with this edge";
            }, i.prototype.getOtherEndInGraph = function(g, n) {
              for (var d = this.getOtherEnd(g), r = n.getGraphManager().getRoot(); ; ) {
                if (d.getOwner() == n)
                  return d;
                if (d.getOwner() == r)
                  break;
                d = d.getOwner().getParent();
              }
              return null;
            }, i.prototype.updateLength = function() {
              var g = new Array(4);
              this.isOverlapingSourceAndTarget = e.getIntersection(this.target.getRect(), this.source.getRect(), g), this.isOverlapingSourceAndTarget || (this.lengthX = g[0] - g[2], this.lengthY = g[1] - g[3], Math.abs(this.lengthX) < 1 && (this.lengthX = t.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = t.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY));
            }, i.prototype.updateLengthSimple = function() {
              this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = t.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = t.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY);
            }, N.exports = i;
          }),
          /* 2 */
          /***/
          (function(N, I, L) {
            function o(e) {
              this.vGraphObject = e;
            }
            N.exports = o;
          }),
          /* 3 */
          /***/
          (function(N, I, L) {
            var o = L(2), e = L(10), t = L(13), i = L(0), l = L(16), g = L(4);
            function n(r, h, a, p) {
              a == null && p == null && (p = h), o.call(this, p), r.graphManager != null && (r = r.graphManager), this.estimatedSize = e.MIN_VALUE, this.inclusionTreeDepth = e.MAX_VALUE, this.vGraphObject = p, this.edges = [], this.graphManager = r, a != null && h != null ? this.rect = new t(h.x, h.y, a.width, a.height) : this.rect = new t();
            }
            n.prototype = Object.create(o.prototype);
            for (var d in o)
              n[d] = o[d];
            n.prototype.getEdges = function() {
              return this.edges;
            }, n.prototype.getChild = function() {
              return this.child;
            }, n.prototype.getOwner = function() {
              return this.owner;
            }, n.prototype.getWidth = function() {
              return this.rect.width;
            }, n.prototype.setWidth = function(r) {
              this.rect.width = r;
            }, n.prototype.getHeight = function() {
              return this.rect.height;
            }, n.prototype.setHeight = function(r) {
              this.rect.height = r;
            }, n.prototype.getCenterX = function() {
              return this.rect.x + this.rect.width / 2;
            }, n.prototype.getCenterY = function() {
              return this.rect.y + this.rect.height / 2;
            }, n.prototype.getCenter = function() {
              return new g(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2);
            }, n.prototype.getLocation = function() {
              return new g(this.rect.x, this.rect.y);
            }, n.prototype.getRect = function() {
              return this.rect;
            }, n.prototype.getDiagonal = function() {
              return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height);
            }, n.prototype.getHalfTheDiagonal = function() {
              return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2;
            }, n.prototype.setRect = function(r, h) {
              this.rect.x = r.x, this.rect.y = r.y, this.rect.width = h.width, this.rect.height = h.height;
            }, n.prototype.setCenter = function(r, h) {
              this.rect.x = r - this.rect.width / 2, this.rect.y = h - this.rect.height / 2;
            }, n.prototype.setLocation = function(r, h) {
              this.rect.x = r, this.rect.y = h;
            }, n.prototype.moveBy = function(r, h) {
              this.rect.x += r, this.rect.y += h;
            }, n.prototype.getEdgeListToNode = function(r) {
              var h = [], a = this;
              return a.edges.forEach(function(p) {
                if (p.target == r) {
                  if (p.source != a) throw "Incorrect edge source!";
                  h.push(p);
                }
              }), h;
            }, n.prototype.getEdgesBetween = function(r) {
              var h = [], a = this;
              return a.edges.forEach(function(p) {
                if (!(p.source == a || p.target == a)) throw "Incorrect edge source and/or target";
                (p.target == r || p.source == r) && h.push(p);
              }), h;
            }, n.prototype.getNeighborsList = function() {
              var r = /* @__PURE__ */ new Set(), h = this;
              return h.edges.forEach(function(a) {
                if (a.source == h)
                  r.add(a.target);
                else {
                  if (a.target != h)
                    throw "Incorrect incidency!";
                  r.add(a.source);
                }
              }), r;
            }, n.prototype.withChildren = function() {
              var r = /* @__PURE__ */ new Set(), h, a;
              if (r.add(this), this.child != null)
                for (var p = this.child.getNodes(), v = 0; v < p.length; v++)
                  h = p[v], a = h.withChildren(), a.forEach(function(D) {
                    r.add(D);
                  });
              return r;
            }, n.prototype.getNoOfChildren = function() {
              var r = 0, h;
              if (this.child == null)
                r = 1;
              else
                for (var a = this.child.getNodes(), p = 0; p < a.length; p++)
                  h = a[p], r += h.getNoOfChildren();
              return r == 0 && (r = 1), r;
            }, n.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == e.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, n.prototype.calcEstimatedSize = function() {
              return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize);
            }, n.prototype.scatter = function() {
              var r, h, a = -i.INITIAL_WORLD_BOUNDARY, p = i.INITIAL_WORLD_BOUNDARY;
              r = i.WORLD_CENTER_X + l.nextDouble() * (p - a) + a;
              var v = -i.INITIAL_WORLD_BOUNDARY, D = i.INITIAL_WORLD_BOUNDARY;
              h = i.WORLD_CENTER_Y + l.nextDouble() * (D - v) + v, this.rect.x = r, this.rect.y = h;
            }, n.prototype.updateBounds = function() {
              if (this.getChild() == null)
                throw "assert failed";
              if (this.getChild().getNodes().length != 0) {
                var r = this.getChild();
                if (r.updateBounds(!0), this.rect.x = r.getLeft(), this.rect.y = r.getTop(), this.setWidth(r.getRight() - r.getLeft()), this.setHeight(r.getBottom() - r.getTop()), i.NODE_DIMENSIONS_INCLUDE_LABELS) {
                  var h = r.getRight() - r.getLeft(), a = r.getBottom() - r.getTop();
                  this.labelWidth > h && (this.rect.x -= (this.labelWidth - h) / 2, this.setWidth(this.labelWidth)), this.labelHeight > a && (this.labelPos == "center" ? this.rect.y -= (this.labelHeight - a) / 2 : this.labelPos == "top" && (this.rect.y -= this.labelHeight - a), this.setHeight(this.labelHeight));
                }
              }
            }, n.prototype.getInclusionTreeDepth = function() {
              if (this.inclusionTreeDepth == e.MAX_VALUE)
                throw "assert failed";
              return this.inclusionTreeDepth;
            }, n.prototype.transform = function(r) {
              var h = this.rect.x;
              h > i.WORLD_BOUNDARY ? h = i.WORLD_BOUNDARY : h < -i.WORLD_BOUNDARY && (h = -i.WORLD_BOUNDARY);
              var a = this.rect.y;
              a > i.WORLD_BOUNDARY ? a = i.WORLD_BOUNDARY : a < -i.WORLD_BOUNDARY && (a = -i.WORLD_BOUNDARY);
              var p = new g(h, a), v = r.inverseTransformPoint(p);
              this.setLocation(v.x, v.y);
            }, n.prototype.getLeft = function() {
              return this.rect.x;
            }, n.prototype.getRight = function() {
              return this.rect.x + this.rect.width;
            }, n.prototype.getTop = function() {
              return this.rect.y;
            }, n.prototype.getBottom = function() {
              return this.rect.y + this.rect.height;
            }, n.prototype.getParent = function() {
              return this.owner == null ? null : this.owner.getParent();
            }, N.exports = n;
          }),
          /* 4 */
          /***/
          (function(N, I, L) {
            function o(e, t) {
              e == null && t == null ? (this.x = 0, this.y = 0) : (this.x = e, this.y = t);
            }
            o.prototype.getX = function() {
              return this.x;
            }, o.prototype.getY = function() {
              return this.y;
            }, o.prototype.setX = function(e) {
              this.x = e;
            }, o.prototype.setY = function(e) {
              this.y = e;
            }, o.prototype.getDifference = function(e) {
              return new DimensionD(this.x - e.x, this.y - e.y);
            }, o.prototype.getCopy = function() {
              return new o(this.x, this.y);
            }, o.prototype.translate = function(e) {
              return this.x += e.width, this.y += e.height, this;
            }, N.exports = o;
          }),
          /* 5 */
          /***/
          (function(N, I, L) {
            var o = L(2), e = L(10), t = L(0), i = L(6), l = L(3), g = L(1), n = L(13), d = L(12), r = L(11);
            function h(p, v, D) {
              o.call(this, D), this.estimatedSize = e.MIN_VALUE, this.margin = t.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = p, v != null && v instanceof i ? this.graphManager = v : v != null && v instanceof Layout && (this.graphManager = v.graphManager);
            }
            h.prototype = Object.create(o.prototype);
            for (var a in o)
              h[a] = o[a];
            h.prototype.getNodes = function() {
              return this.nodes;
            }, h.prototype.getEdges = function() {
              return this.edges;
            }, h.prototype.getGraphManager = function() {
              return this.graphManager;
            }, h.prototype.getParent = function() {
              return this.parent;
            }, h.prototype.getLeft = function() {
              return this.left;
            }, h.prototype.getRight = function() {
              return this.right;
            }, h.prototype.getTop = function() {
              return this.top;
            }, h.prototype.getBottom = function() {
              return this.bottom;
            }, h.prototype.isConnected = function() {
              return this.isConnected;
            }, h.prototype.add = function(p, v, D) {
              if (v == null && D == null) {
                var u = p;
                if (this.graphManager == null)
                  throw "Graph has no graph mgr!";
                if (this.getNodes().indexOf(u) > -1)
                  throw "Node already in graph!";
                return u.owner = this, this.getNodes().push(u), u;
              } else {
                var T = p;
                if (!(this.getNodes().indexOf(v) > -1 && this.getNodes().indexOf(D) > -1))
                  throw "Source or target not in graph!";
                if (!(v.owner == D.owner && v.owner == this))
                  throw "Both owners must be this graph!";
                return v.owner != D.owner ? null : (T.source = v, T.target = D, T.isInterGraph = !1, this.getEdges().push(T), v.edges.push(T), D != v && D.edges.push(T), T);
              }
            }, h.prototype.remove = function(p) {
              var v = p;
              if (p instanceof l) {
                if (v == null)
                  throw "Node is null!";
                if (!(v.owner != null && v.owner == this))
                  throw "Owner graph is invalid!";
                if (this.graphManager == null)
                  throw "Owner graph manager is invalid!";
                for (var D = v.edges.slice(), u, T = D.length, y = 0; y < T; y++)
                  u = D[y], u.isInterGraph ? this.graphManager.remove(u) : u.source.owner.remove(u);
                var O = this.nodes.indexOf(v);
                if (O == -1)
                  throw "Node not in owner node list!";
                this.nodes.splice(O, 1);
              } else if (p instanceof g) {
                var u = p;
                if (u == null)
                  throw "Edge is null!";
                if (!(u.source != null && u.target != null))
                  throw "Source and/or target is null!";
                if (!(u.source.owner != null && u.target.owner != null && u.source.owner == this && u.target.owner == this))
                  throw "Source and/or target owner is invalid!";
                var s = u.source.edges.indexOf(u), f = u.target.edges.indexOf(u);
                if (!(s > -1 && f > -1))
                  throw "Source and/or target doesn't know this edge!";
                u.source.edges.splice(s, 1), u.target != u.source && u.target.edges.splice(f, 1);
                var O = u.source.owner.getEdges().indexOf(u);
                if (O == -1)
                  throw "Not in owner's edge list!";
                u.source.owner.getEdges().splice(O, 1);
              }
            }, h.prototype.updateLeftTop = function() {
              for (var p = e.MAX_VALUE, v = e.MAX_VALUE, D, u, T, y = this.getNodes(), O = y.length, s = 0; s < O; s++) {
                var f = y[s];
                D = f.getTop(), u = f.getLeft(), p > D && (p = D), v > u && (v = u);
              }
              return p == e.MAX_VALUE ? null : (y[0].getParent().paddingLeft != null ? T = y[0].getParent().paddingLeft : T = this.margin, this.left = v - T, this.top = p - T, new d(this.left, this.top));
            }, h.prototype.updateBounds = function(p) {
              for (var v = e.MAX_VALUE, D = -e.MAX_VALUE, u = e.MAX_VALUE, T = -e.MAX_VALUE, y, O, s, f, c, E = this.nodes, A = E.length, m = 0; m < A; m++) {
                var C = E[m];
                p && C.child != null && C.updateBounds(), y = C.getLeft(), O = C.getRight(), s = C.getTop(), f = C.getBottom(), v > y && (v = y), D < O && (D = O), u > s && (u = s), T < f && (T = f);
              }
              var R = new n(v, u, D - v, T - u);
              v == e.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), E[0].getParent().paddingLeft != null ? c = E[0].getParent().paddingLeft : c = this.margin, this.left = R.x - c, this.right = R.x + R.width + c, this.top = R.y - c, this.bottom = R.y + R.height + c;
            }, h.calculateBounds = function(p) {
              for (var v = e.MAX_VALUE, D = -e.MAX_VALUE, u = e.MAX_VALUE, T = -e.MAX_VALUE, y, O, s, f, c = p.length, E = 0; E < c; E++) {
                var A = p[E];
                y = A.getLeft(), O = A.getRight(), s = A.getTop(), f = A.getBottom(), v > y && (v = y), D < O && (D = O), u > s && (u = s), T < f && (T = f);
              }
              var m = new n(v, u, D - v, T - u);
              return m;
            }, h.prototype.getInclusionTreeDepth = function() {
              return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth();
            }, h.prototype.getEstimatedSize = function() {
              if (this.estimatedSize == e.MIN_VALUE)
                throw "assert failed";
              return this.estimatedSize;
            }, h.prototype.calcEstimatedSize = function() {
              for (var p = 0, v = this.nodes, D = v.length, u = 0; u < D; u++) {
                var T = v[u];
                p += T.calcEstimatedSize();
              }
              return p == 0 ? this.estimatedSize = t.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = p / Math.sqrt(this.nodes.length), this.estimatedSize;
            }, h.prototype.updateConnected = function() {
              var p = this;
              if (this.nodes.length == 0) {
                this.isConnected = !0;
                return;
              }
              var v = new r(), D = /* @__PURE__ */ new Set(), u = this.nodes[0], T, y, O = u.withChildren();
              for (O.forEach(function(m) {
                v.push(m), D.add(m);
              }); v.length !== 0; ) {
                u = v.shift(), T = u.getEdges();
                for (var s = T.length, f = 0; f < s; f++) {
                  var c = T[f];
                  if (y = c.getOtherEndInGraph(u, this), y != null && !D.has(y)) {
                    var E = y.withChildren();
                    E.forEach(function(m) {
                      v.push(m), D.add(m);
                    });
                  }
                }
              }
              if (this.isConnected = !1, D.size >= this.nodes.length) {
                var A = 0;
                D.forEach(function(m) {
                  m.owner == p && A++;
                }), A == this.nodes.length && (this.isConnected = !0);
              }
            }, N.exports = h;
          }),
          /* 6 */
          /***/
          (function(N, I, L) {
            var o, e = L(1);
            function t(i) {
              o = L(5), this.layout = i, this.graphs = [], this.edges = [];
            }
            t.prototype.addRoot = function() {
              var i = this.layout.newGraph(), l = this.layout.newNode(null), g = this.add(i, l);
              return this.setRootGraph(g), this.rootGraph;
            }, t.prototype.add = function(i, l, g, n, d) {
              if (g == null && n == null && d == null) {
                if (i == null)
                  throw "Graph is null!";
                if (l == null)
                  throw "Parent node is null!";
                if (this.graphs.indexOf(i) > -1)
                  throw "Graph already in this graph mgr!";
                if (this.graphs.push(i), i.parent != null)
                  throw "Already has a parent!";
                if (l.child != null)
                  throw "Already has a child!";
                return i.parent = l, l.child = i, i;
              } else {
                d = g, n = l, g = i;
                var r = n.getOwner(), h = d.getOwner();
                if (!(r != null && r.getGraphManager() == this))
                  throw "Source not in this graph mgr!";
                if (!(h != null && h.getGraphManager() == this))
                  throw "Target not in this graph mgr!";
                if (r == h)
                  return g.isInterGraph = !1, r.add(g, n, d);
                if (g.isInterGraph = !0, g.source = n, g.target = d, this.edges.indexOf(g) > -1)
                  throw "Edge already in inter-graph edge list!";
                if (this.edges.push(g), !(g.source != null && g.target != null))
                  throw "Edge source and/or target is null!";
                if (!(g.source.edges.indexOf(g) == -1 && g.target.edges.indexOf(g) == -1))
                  throw "Edge already in source and/or target incidency list!";
                return g.source.edges.push(g), g.target.edges.push(g), g;
              }
            }, t.prototype.remove = function(i) {
              if (i instanceof o) {
                var l = i;
                if (l.getGraphManager() != this)
                  throw "Graph not in this graph mgr";
                if (!(l == this.rootGraph || l.parent != null && l.parent.graphManager == this))
                  throw "Invalid parent node!";
                var g = [];
                g = g.concat(l.getEdges());
                for (var n, d = g.length, r = 0; r < d; r++)
                  n = g[r], l.remove(n);
                var h = [];
                h = h.concat(l.getNodes());
                var a;
                d = h.length;
                for (var r = 0; r < d; r++)
                  a = h[r], l.remove(a);
                l == this.rootGraph && this.setRootGraph(null);
                var p = this.graphs.indexOf(l);
                this.graphs.splice(p, 1), l.parent = null;
              } else if (i instanceof e) {
                if (n = i, n == null)
                  throw "Edge is null!";
                if (!n.isInterGraph)
                  throw "Not an inter-graph edge!";
                if (!(n.source != null && n.target != null))
                  throw "Source and/or target is null!";
                if (!(n.source.edges.indexOf(n) != -1 && n.target.edges.indexOf(n) != -1))
                  throw "Source and/or target doesn't know this edge!";
                var p = n.source.edges.indexOf(n);
                if (n.source.edges.splice(p, 1), p = n.target.edges.indexOf(n), n.target.edges.splice(p, 1), !(n.source.owner != null && n.source.owner.getGraphManager() != null))
                  throw "Edge owner graph or owner graph manager is null!";
                if (n.source.owner.getGraphManager().edges.indexOf(n) == -1)
                  throw "Not in owner graph manager's edge list!";
                var p = n.source.owner.getGraphManager().edges.indexOf(n);
                n.source.owner.getGraphManager().edges.splice(p, 1);
              }
            }, t.prototype.updateBounds = function() {
              this.rootGraph.updateBounds(!0);
            }, t.prototype.getGraphs = function() {
              return this.graphs;
            }, t.prototype.getAllNodes = function() {
              if (this.allNodes == null) {
                for (var i = [], l = this.getGraphs(), g = l.length, n = 0; n < g; n++)
                  i = i.concat(l[n].getNodes());
                this.allNodes = i;
              }
              return this.allNodes;
            }, t.prototype.resetAllNodes = function() {
              this.allNodes = null;
            }, t.prototype.resetAllEdges = function() {
              this.allEdges = null;
            }, t.prototype.resetAllNodesToApplyGravitation = function() {
              this.allNodesToApplyGravitation = null;
            }, t.prototype.getAllEdges = function() {
              if (this.allEdges == null) {
                var i = [], l = this.getGraphs();
                l.length;
                for (var g = 0; g < l.length; g++)
                  i = i.concat(l[g].getEdges());
                i = i.concat(this.edges), this.allEdges = i;
              }
              return this.allEdges;
            }, t.prototype.getAllNodesToApplyGravitation = function() {
              return this.allNodesToApplyGravitation;
            }, t.prototype.setAllNodesToApplyGravitation = function(i) {
              if (this.allNodesToApplyGravitation != null)
                throw "assert failed";
              this.allNodesToApplyGravitation = i;
            }, t.prototype.getRoot = function() {
              return this.rootGraph;
            }, t.prototype.setRootGraph = function(i) {
              if (i.getGraphManager() != this)
                throw "Root not in this graph mgr!";
              this.rootGraph = i, i.parent == null && (i.parent = this.layout.newNode("Root node"));
            }, t.prototype.getLayout = function() {
              return this.layout;
            }, t.prototype.isOneAncestorOfOther = function(i, l) {
              if (!(i != null && l != null))
                throw "assert failed";
              if (i == l)
                return !0;
              var g = i.getOwner(), n;
              do {
                if (n = g.getParent(), n == null)
                  break;
                if (n == l)
                  return !0;
                if (g = n.getOwner(), g == null)
                  break;
              } while (!0);
              g = l.getOwner();
              do {
                if (n = g.getParent(), n == null)
                  break;
                if (n == i)
                  return !0;
                if (g = n.getOwner(), g == null)
                  break;
              } while (!0);
              return !1;
            }, t.prototype.calcLowestCommonAncestors = function() {
              for (var i, l, g, n, d, r = this.getAllEdges(), h = r.length, a = 0; a < h; a++) {
                if (i = r[a], l = i.source, g = i.target, i.lca = null, i.sourceInLca = l, i.targetInLca = g, l == g) {
                  i.lca = l.getOwner();
                  continue;
                }
                for (n = l.getOwner(); i.lca == null; ) {
                  for (i.targetInLca = g, d = g.getOwner(); i.lca == null; ) {
                    if (d == n) {
                      i.lca = d;
                      break;
                    }
                    if (d == this.rootGraph)
                      break;
                    if (i.lca != null)
                      throw "assert failed";
                    i.targetInLca = d.getParent(), d = i.targetInLca.getOwner();
                  }
                  if (n == this.rootGraph)
                    break;
                  i.lca == null && (i.sourceInLca = n.getParent(), n = i.sourceInLca.getOwner());
                }
                if (i.lca == null)
                  throw "assert failed";
              }
            }, t.prototype.calcLowestCommonAncestor = function(i, l) {
              if (i == l)
                return i.getOwner();
              var g = i.getOwner();
              do {
                if (g == null)
                  break;
                var n = l.getOwner();
                do {
                  if (n == null)
                    break;
                  if (n == g)
                    return n;
                  n = n.getParent().getOwner();
                } while (!0);
                g = g.getParent().getOwner();
              } while (!0);
              return g;
            }, t.prototype.calcInclusionTreeDepths = function(i, l) {
              i == null && l == null && (i = this.rootGraph, l = 1);
              for (var g, n = i.getNodes(), d = n.length, r = 0; r < d; r++)
                g = n[r], g.inclusionTreeDepth = l, g.child != null && this.calcInclusionTreeDepths(g.child, l + 1);
            }, t.prototype.includesInvalidEdge = function() {
              for (var i, l = this.edges.length, g = 0; g < l; g++)
                if (i = this.edges[g], this.isOneAncestorOfOther(i.source, i.target))
                  return !0;
              return !1;
            }, N.exports = t;
          }),
          /* 7 */
          /***/
          (function(N, I, L) {
            var o = L(0);
            function e() {
            }
            for (var t in o)
              e[t] = o[t];
            e.MAX_ITERATIONS = 2500, e.DEFAULT_EDGE_LENGTH = 50, e.DEFAULT_SPRING_STRENGTH = 0.45, e.DEFAULT_REPULSION_STRENGTH = 4500, e.DEFAULT_GRAVITY_STRENGTH = 0.4, e.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, e.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, e.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, e.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, e.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, e.DEFAULT_COOLING_FACTOR_INCREMENTAL = 0.3, e.COOLING_ADAPTATION_FACTOR = 0.33, e.ADAPTATION_LOWER_NODE_LIMIT = 1e3, e.ADAPTATION_UPPER_NODE_LIMIT = 5e3, e.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, e.MAX_NODE_DISPLACEMENT = e.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, e.MIN_REPULSION_DIST = e.DEFAULT_EDGE_LENGTH / 10, e.CONVERGENCE_CHECK_PERIOD = 100, e.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = 0.1, e.MIN_EDGE_LENGTH = 1, e.GRID_CALCULATION_CHECK_PERIOD = 10, N.exports = e;
          }),
          /* 8 */
          /***/
          (function(N, I, L) {
            var o = L(12);
            function e() {
            }
            e.calcSeparationAmount = function(t, i, l, g) {
              if (!t.intersects(i))
                throw "assert failed";
              var n = new Array(2);
              this.decideDirectionsForOverlappingNodes(t, i, n), l[0] = Math.min(t.getRight(), i.getRight()) - Math.max(t.x, i.x), l[1] = Math.min(t.getBottom(), i.getBottom()) - Math.max(t.y, i.y), t.getX() <= i.getX() && t.getRight() >= i.getRight() ? l[0] += Math.min(i.getX() - t.getX(), t.getRight() - i.getRight()) : i.getX() <= t.getX() && i.getRight() >= t.getRight() && (l[0] += Math.min(t.getX() - i.getX(), i.getRight() - t.getRight())), t.getY() <= i.getY() && t.getBottom() >= i.getBottom() ? l[1] += Math.min(i.getY() - t.getY(), t.getBottom() - i.getBottom()) : i.getY() <= t.getY() && i.getBottom() >= t.getBottom() && (l[1] += Math.min(t.getY() - i.getY(), i.getBottom() - t.getBottom()));
              var d = Math.abs((i.getCenterY() - t.getCenterY()) / (i.getCenterX() - t.getCenterX()));
              i.getCenterY() === t.getCenterY() && i.getCenterX() === t.getCenterX() && (d = 1);
              var r = d * l[0], h = l[1] / d;
              l[0] < h ? h = l[0] : r = l[1], l[0] = -1 * n[0] * (h / 2 + g), l[1] = -1 * n[1] * (r / 2 + g);
            }, e.decideDirectionsForOverlappingNodes = function(t, i, l) {
              t.getCenterX() < i.getCenterX() ? l[0] = -1 : l[0] = 1, t.getCenterY() < i.getCenterY() ? l[1] = -1 : l[1] = 1;
            }, e.getIntersection2 = function(t, i, l) {
              var g = t.getCenterX(), n = t.getCenterY(), d = i.getCenterX(), r = i.getCenterY();
              if (t.intersects(i))
                return l[0] = g, l[1] = n, l[2] = d, l[3] = r, !0;
              var h = t.getX(), a = t.getY(), p = t.getRight(), v = t.getX(), D = t.getBottom(), u = t.getRight(), T = t.getWidthHalf(), y = t.getHeightHalf(), O = i.getX(), s = i.getY(), f = i.getRight(), c = i.getX(), E = i.getBottom(), A = i.getRight(), m = i.getWidthHalf(), C = i.getHeightHalf(), R = !1, M = !1;
              if (g === d) {
                if (n > r)
                  return l[0] = g, l[1] = a, l[2] = d, l[3] = E, !1;
                if (n < r)
                  return l[0] = g, l[1] = D, l[2] = d, l[3] = s, !1;
              } else if (n === r) {
                if (g > d)
                  return l[0] = h, l[1] = n, l[2] = f, l[3] = r, !1;
                if (g < d)
                  return l[0] = p, l[1] = n, l[2] = O, l[3] = r, !1;
              } else {
                var S = t.height / t.width, Y = i.height / i.width, w = (r - n) / (d - g), x = void 0, F = void 0, U = void 0, P = void 0, _ = void 0, X = void 0;
                if (-S === w ? g > d ? (l[0] = v, l[1] = D, R = !0) : (l[0] = p, l[1] = a, R = !0) : S === w && (g > d ? (l[0] = h, l[1] = a, R = !0) : (l[0] = u, l[1] = D, R = !0)), -Y === w ? d > g ? (l[2] = c, l[3] = E, M = !0) : (l[2] = f, l[3] = s, M = !0) : Y === w && (d > g ? (l[2] = O, l[3] = s, M = !0) : (l[2] = A, l[3] = E, M = !0)), R && M)
                  return !1;
                if (g > d ? n > r ? (x = this.getCardinalDirection(S, w, 4), F = this.getCardinalDirection(Y, w, 2)) : (x = this.getCardinalDirection(-S, w, 3), F = this.getCardinalDirection(-Y, w, 1)) : n > r ? (x = this.getCardinalDirection(-S, w, 1), F = this.getCardinalDirection(-Y, w, 3)) : (x = this.getCardinalDirection(S, w, 2), F = this.getCardinalDirection(Y, w, 4)), !R)
                  switch (x) {
                    case 1:
                      P = a, U = g + -y / w, l[0] = U, l[1] = P;
                      break;
                    case 2:
                      U = u, P = n + T * w, l[0] = U, l[1] = P;
                      break;
                    case 3:
                      P = D, U = g + y / w, l[0] = U, l[1] = P;
                      break;
                    case 4:
                      U = v, P = n + -T * w, l[0] = U, l[1] = P;
                      break;
                  }
                if (!M)
                  switch (F) {
                    case 1:
                      X = s, _ = d + -C / w, l[2] = _, l[3] = X;
                      break;
                    case 2:
                      _ = A, X = r + m * w, l[2] = _, l[3] = X;
                      break;
                    case 3:
                      X = E, _ = d + C / w, l[2] = _, l[3] = X;
                      break;
                    case 4:
                      _ = c, X = r + -m * w, l[2] = _, l[3] = X;
                      break;
                  }
              }
              return !1;
            }, e.getCardinalDirection = function(t, i, l) {
              return t > i ? l : 1 + l % 4;
            }, e.getIntersection = function(t, i, l, g) {
              if (g == null)
                return this.getIntersection2(t, i, l);
              var n = t.x, d = t.y, r = i.x, h = i.y, a = l.x, p = l.y, v = g.x, D = g.y, u = void 0, T = void 0, y = void 0, O = void 0, s = void 0, f = void 0, c = void 0, E = void 0, A = void 0;
              return y = h - d, s = n - r, c = r * d - n * h, O = D - p, f = a - v, E = v * p - a * D, A = y * f - O * s, A === 0 ? null : (u = (s * E - f * c) / A, T = (O * c - y * E) / A, new o(u, T));
            }, e.angleOfVector = function(t, i, l, g) {
              var n = void 0;
              return t !== l ? (n = Math.atan((g - i) / (l - t)), l < t ? n += Math.PI : g < i && (n += this.TWO_PI)) : g < i ? n = this.ONE_AND_HALF_PI : n = this.HALF_PI, n;
            }, e.doIntersect = function(t, i, l, g) {
              var n = t.x, d = t.y, r = i.x, h = i.y, a = l.x, p = l.y, v = g.x, D = g.y, u = (r - n) * (D - p) - (v - a) * (h - d);
              if (u === 0)
                return !1;
              var T = ((D - p) * (v - n) + (a - v) * (D - d)) / u, y = ((d - h) * (v - n) + (r - n) * (D - d)) / u;
              return 0 < T && T < 1 && 0 < y && y < 1;
            }, e.HALF_PI = 0.5 * Math.PI, e.ONE_AND_HALF_PI = 1.5 * Math.PI, e.TWO_PI = 2 * Math.PI, e.THREE_PI = 3 * Math.PI, N.exports = e;
          }),
          /* 9 */
          /***/
          (function(N, I, L) {
            function o() {
            }
            o.sign = function(e) {
              return e > 0 ? 1 : e < 0 ? -1 : 0;
            }, o.floor = function(e) {
              return e < 0 ? Math.ceil(e) : Math.floor(e);
            }, o.ceil = function(e) {
              return e < 0 ? Math.floor(e) : Math.ceil(e);
            }, N.exports = o;
          }),
          /* 10 */
          /***/
          (function(N, I, L) {
            function o() {
            }
            o.MAX_VALUE = 2147483647, o.MIN_VALUE = -2147483648, N.exports = o;
          }),
          /* 11 */
          /***/
          (function(N, I, L) {
            var o = /* @__PURE__ */ (function() {
              function n(d, r) {
                for (var h = 0; h < r.length; h++) {
                  var a = r[h];
                  a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(d, a.key, a);
                }
              }
              return function(d, r, h) {
                return r && n(d.prototype, r), h && n(d, h), d;
              };
            })();
            function e(n, d) {
              if (!(n instanceof d))
                throw new TypeError("Cannot call a class as a function");
            }
            var t = function(d) {
              return { value: d, next: null, prev: null };
            }, i = function(d, r, h, a) {
              return d !== null ? d.next = r : a.head = r, h !== null ? h.prev = r : a.tail = r, r.prev = d, r.next = h, a.length++, r;
            }, l = function(d, r) {
              var h = d.prev, a = d.next;
              return h !== null ? h.next = a : r.head = a, a !== null ? a.prev = h : r.tail = h, d.prev = d.next = null, r.length--, d;
            }, g = (function() {
              function n(d) {
                var r = this;
                e(this, n), this.length = 0, this.head = null, this.tail = null, d?.forEach(function(h) {
                  return r.push(h);
                });
              }
              return o(n, [{
                key: "size",
                value: function() {
                  return this.length;
                }
              }, {
                key: "insertBefore",
                value: function(r, h) {
                  return i(h.prev, t(r), h, this);
                }
              }, {
                key: "insertAfter",
                value: function(r, h) {
                  return i(h, t(r), h.next, this);
                }
              }, {
                key: "insertNodeBefore",
                value: function(r, h) {
                  return i(h.prev, r, h, this);
                }
              }, {
                key: "insertNodeAfter",
                value: function(r, h) {
                  return i(h, r, h.next, this);
                }
              }, {
                key: "push",
                value: function(r) {
                  return i(this.tail, t(r), null, this);
                }
              }, {
                key: "unshift",
                value: function(r) {
                  return i(null, t(r), this.head, this);
                }
              }, {
                key: "remove",
                value: function(r) {
                  return l(r, this);
                }
              }, {
                key: "pop",
                value: function() {
                  return l(this.tail, this).value;
                }
              }, {
                key: "popNode",
                value: function() {
                  return l(this.tail, this);
                }
              }, {
                key: "shift",
                value: function() {
                  return l(this.head, this).value;
                }
              }, {
                key: "shiftNode",
                value: function() {
                  return l(this.head, this);
                }
              }, {
                key: "get_object_at",
                value: function(r) {
                  if (r <= this.length()) {
                    for (var h = 1, a = this.head; h < r; )
                      a = a.next, h++;
                    return a.value;
                  }
                }
              }, {
                key: "set_object_at",
                value: function(r, h) {
                  if (r <= this.length()) {
                    for (var a = 1, p = this.head; a < r; )
                      p = p.next, a++;
                    p.value = h;
                  }
                }
              }]), n;
            })();
            N.exports = g;
          }),
          /* 12 */
          /***/
          (function(N, I, L) {
            function o(e, t, i) {
              this.x = null, this.y = null, e == null && t == null && i == null ? (this.x = 0, this.y = 0) : typeof e == "number" && typeof t == "number" && i == null ? (this.x = e, this.y = t) : e.constructor.name == "Point" && t == null && i == null && (i = e, this.x = i.x, this.y = i.y);
            }
            o.prototype.getX = function() {
              return this.x;
            }, o.prototype.getY = function() {
              return this.y;
            }, o.prototype.getLocation = function() {
              return new o(this.x, this.y);
            }, o.prototype.setLocation = function(e, t, i) {
              e.constructor.name == "Point" && t == null && i == null ? (i = e, this.setLocation(i.x, i.y)) : typeof e == "number" && typeof t == "number" && i == null && (parseInt(e) == e && parseInt(t) == t ? this.move(e, t) : (this.x = Math.floor(e + 0.5), this.y = Math.floor(t + 0.5)));
            }, o.prototype.move = function(e, t) {
              this.x = e, this.y = t;
            }, o.prototype.translate = function(e, t) {
              this.x += e, this.y += t;
            }, o.prototype.equals = function(e) {
              if (e.constructor.name == "Point") {
                var t = e;
                return this.x == t.x && this.y == t.y;
              }
              return this == e;
            }, o.prototype.toString = function() {
              return new o().constructor.name + "[x=" + this.x + ",y=" + this.y + "]";
            }, N.exports = o;
          }),
          /* 13 */
          /***/
          (function(N, I, L) {
            function o(e, t, i, l) {
              this.x = 0, this.y = 0, this.width = 0, this.height = 0, e != null && t != null && i != null && l != null && (this.x = e, this.y = t, this.width = i, this.height = l);
            }
            o.prototype.getX = function() {
              return this.x;
            }, o.prototype.setX = function(e) {
              this.x = e;
            }, o.prototype.getY = function() {
              return this.y;
            }, o.prototype.setY = function(e) {
              this.y = e;
            }, o.prototype.getWidth = function() {
              return this.width;
            }, o.prototype.setWidth = function(e) {
              this.width = e;
            }, o.prototype.getHeight = function() {
              return this.height;
            }, o.prototype.setHeight = function(e) {
              this.height = e;
            }, o.prototype.getRight = function() {
              return this.x + this.width;
            }, o.prototype.getBottom = function() {
              return this.y + this.height;
            }, o.prototype.intersects = function(e) {
              return !(this.getRight() < e.x || this.getBottom() < e.y || e.getRight() < this.x || e.getBottom() < this.y);
            }, o.prototype.getCenterX = function() {
              return this.x + this.width / 2;
            }, o.prototype.getMinX = function() {
              return this.getX();
            }, o.prototype.getMaxX = function() {
              return this.getX() + this.width;
            }, o.prototype.getCenterY = function() {
              return this.y + this.height / 2;
            }, o.prototype.getMinY = function() {
              return this.getY();
            }, o.prototype.getMaxY = function() {
              return this.getY() + this.height;
            }, o.prototype.getWidthHalf = function() {
              return this.width / 2;
            }, o.prototype.getHeightHalf = function() {
              return this.height / 2;
            }, N.exports = o;
          }),
          /* 14 */
          /***/
          (function(N, I, L) {
            var o = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
              return typeof t;
            } : function(t) {
              return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
            };
            function e() {
            }
            e.lastID = 0, e.createID = function(t) {
              return e.isPrimitive(t) ? t : (t.uniqueID != null || (t.uniqueID = e.getString(), e.lastID++), t.uniqueID);
            }, e.getString = function(t) {
              return t == null && (t = e.lastID), "Object#" + t;
            }, e.isPrimitive = function(t) {
              var i = typeof t > "u" ? "undefined" : o(t);
              return t == null || i != "object" && i != "function";
            }, N.exports = e;
          }),
          /* 15 */
          /***/
          (function(N, I, L) {
            function o(a) {
              if (Array.isArray(a)) {
                for (var p = 0, v = Array(a.length); p < a.length; p++)
                  v[p] = a[p];
                return v;
              } else
                return Array.from(a);
            }
            var e = L(0), t = L(6), i = L(3), l = L(1), g = L(5), n = L(4), d = L(17), r = L(27);
            function h(a) {
              r.call(this), this.layoutQuality = e.QUALITY, this.createBendsAsNeeded = e.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = e.DEFAULT_INCREMENTAL, this.animationOnLayout = e.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = e.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = e.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = e.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = /* @__PURE__ */ new Map(), this.graphManager = new t(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, a != null && (this.isRemoteUse = a);
            }
            h.RANDOM_SEED = 1, h.prototype = Object.create(r.prototype), h.prototype.getGraphManager = function() {
              return this.graphManager;
            }, h.prototype.getAllNodes = function() {
              return this.graphManager.getAllNodes();
            }, h.prototype.getAllEdges = function() {
              return this.graphManager.getAllEdges();
            }, h.prototype.getAllNodesToApplyGravitation = function() {
              return this.graphManager.getAllNodesToApplyGravitation();
            }, h.prototype.newGraphManager = function() {
              var a = new t(this);
              return this.graphManager = a, a;
            }, h.prototype.newGraph = function(a) {
              return new g(null, this.graphManager, a);
            }, h.prototype.newNode = function(a) {
              return new i(this.graphManager, a);
            }, h.prototype.newEdge = function(a) {
              return new l(null, null, a);
            }, h.prototype.checkLayoutSuccess = function() {
              return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge();
            }, h.prototype.runLayout = function() {
              this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters();
              var a;
              return this.checkLayoutSuccess() ? a = !1 : a = this.layout(), e.ANIMATE === "during" ? !1 : (a && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, a);
            }, h.prototype.doPostLayout = function() {
              this.incremental || this.transform(), this.update();
            }, h.prototype.update2 = function() {
              if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
                for (var a = this.graphManager.getAllEdges(), p = 0; p < a.length; p++)
                  a[p];
                for (var v = this.graphManager.getRoot().getNodes(), p = 0; p < v.length; p++)
                  v[p];
                this.update(this.graphManager.getRoot());
              }
            }, h.prototype.update = function(a) {
              if (a == null)
                this.update2();
              else if (a instanceof i) {
                var p = a;
                if (p.getChild() != null)
                  for (var v = p.getChild().getNodes(), D = 0; D < v.length; D++)
                    update(v[D]);
                if (p.vGraphObject != null) {
                  var u = p.vGraphObject;
                  u.update(p);
                }
              } else if (a instanceof l) {
                var T = a;
                if (T.vGraphObject != null) {
                  var y = T.vGraphObject;
                  y.update(T);
                }
              } else if (a instanceof g) {
                var O = a;
                if (O.vGraphObject != null) {
                  var s = O.vGraphObject;
                  s.update(O);
                }
              }
            }, h.prototype.initParameters = function() {
              this.isSubLayout || (this.layoutQuality = e.QUALITY, this.animationDuringLayout = e.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = e.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = e.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = e.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = e.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = e.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1);
            }, h.prototype.transform = function(a) {
              if (a == null)
                this.transform(new n(0, 0));
              else {
                var p = new d(), v = this.graphManager.getRoot().updateLeftTop();
                if (v != null) {
                  p.setWorldOrgX(a.x), p.setWorldOrgY(a.y), p.setDeviceOrgX(v.x), p.setDeviceOrgY(v.y);
                  for (var D = this.getAllNodes(), u, T = 0; T < D.length; T++)
                    u = D[T], u.transform(p);
                }
              }
            }, h.prototype.positionNodesRandomly = function(a) {
              if (a == null)
                this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
              else
                for (var p, v, D = a.getNodes(), u = 0; u < D.length; u++)
                  p = D[u], v = p.getChild(), v == null || v.getNodes().length == 0 ? p.scatter() : (this.positionNodesRandomly(v), p.updateBounds());
            }, h.prototype.getFlatForest = function() {
              for (var a = [], p = !0, v = this.graphManager.getRoot().getNodes(), D = !0, u = 0; u < v.length; u++)
                v[u].getChild() != null && (D = !1);
              if (!D)
                return a;
              var T = /* @__PURE__ */ new Set(), y = [], O = /* @__PURE__ */ new Map(), s = [];
              for (s = s.concat(v); s.length > 0 && p; ) {
                for (y.push(s[0]); y.length > 0 && p; ) {
                  var f = y[0];
                  y.splice(0, 1), T.add(f);
                  for (var c = f.getEdges(), u = 0; u < c.length; u++) {
                    var E = c[u].getOtherEnd(f);
                    if (O.get(f) != E)
                      if (!T.has(E))
                        y.push(E), O.set(E, f);
                      else {
                        p = !1;
                        break;
                      }
                  }
                }
                if (!p)
                  a = [];
                else {
                  var A = [].concat(o(T));
                  a.push(A);
                  for (var u = 0; u < A.length; u++) {
                    var m = A[u], C = s.indexOf(m);
                    C > -1 && s.splice(C, 1);
                  }
                  T = /* @__PURE__ */ new Set(), O = /* @__PURE__ */ new Map();
                }
              }
              return a;
            }, h.prototype.createDummyNodesForBendpoints = function(a) {
              for (var p = [], v = a.source, D = this.graphManager.calcLowestCommonAncestor(a.source, a.target), u = 0; u < a.bendpoints.length; u++) {
                var T = this.newNode(null);
                T.setRect(new Point(0, 0), new Dimension(1, 1)), D.add(T);
                var y = this.newEdge(null);
                this.graphManager.add(y, v, T), p.add(T), v = T;
              }
              var y = this.newEdge(null);
              return this.graphManager.add(y, v, a.target), this.edgeToDummyNodes.set(a, p), a.isInterGraph() ? this.graphManager.remove(a) : D.remove(a), p;
            }, h.prototype.createBendpointsFromDummyNodes = function() {
              var a = [];
              a = a.concat(this.graphManager.getAllEdges()), a = [].concat(o(this.edgeToDummyNodes.keys())).concat(a);
              for (var p = 0; p < a.length; p++) {
                var v = a[p];
                if (v.bendpoints.length > 0) {
                  for (var D = this.edgeToDummyNodes.get(v), u = 0; u < D.length; u++) {
                    var T = D[u], y = new n(T.getCenterX(), T.getCenterY()), O = v.bendpoints.get(u);
                    O.x = y.x, O.y = y.y, T.getOwner().remove(T);
                  }
                  this.graphManager.add(v, v.source, v.target);
                }
              }
            }, h.transform = function(a, p, v, D) {
              if (v != null && D != null) {
                var u = p;
                if (a <= 50) {
                  var T = p / v;
                  u -= (p - T) / 50 * (50 - a);
                } else {
                  var y = p * D;
                  u += (y - p) / 50 * (a - 50);
                }
                return u;
              } else {
                var O, s;
                return a <= 50 ? (O = 9 * p / 500, s = p / 10) : (O = 9 * p / 50, s = -8 * p), O * a + s;
              }
            }, h.findCenterOfTree = function(a) {
              var p = [];
              p = p.concat(a);
              var v = [], D = /* @__PURE__ */ new Map(), u = !1, T = null;
              (p.length == 1 || p.length == 2) && (u = !0, T = p[0]);
              for (var y = 0; y < p.length; y++) {
                var O = p[y], s = O.getNeighborsList().size;
                D.set(O, O.getNeighborsList().size), s == 1 && v.push(O);
              }
              var f = [];
              for (f = f.concat(v); !u; ) {
                var c = [];
                c = c.concat(f), f = [];
                for (var y = 0; y < p.length; y++) {
                  var O = p[y], E = p.indexOf(O);
                  E >= 0 && p.splice(E, 1);
                  var A = O.getNeighborsList();
                  A.forEach(function(R) {
                    if (v.indexOf(R) < 0) {
                      var M = D.get(R), S = M - 1;
                      S == 1 && f.push(R), D.set(R, S);
                    }
                  });
                }
                v = v.concat(f), (p.length == 1 || p.length == 2) && (u = !0, T = p[0]);
              }
              return T;
            }, h.prototype.setGraphManager = function(a) {
              this.graphManager = a;
            }, N.exports = h;
          }),
          /* 16 */
          /***/
          (function(N, I, L) {
            function o() {
            }
            o.seed = 1, o.x = 0, o.nextDouble = function() {
              return o.x = Math.sin(o.seed++) * 1e4, o.x - Math.floor(o.x);
            }, N.exports = o;
          }),
          /* 17 */
          /***/
          (function(N, I, L) {
            var o = L(4);
            function e(t, i) {
              this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1;
            }
            e.prototype.getWorldOrgX = function() {
              return this.lworldOrgX;
            }, e.prototype.setWorldOrgX = function(t) {
              this.lworldOrgX = t;
            }, e.prototype.getWorldOrgY = function() {
              return this.lworldOrgY;
            }, e.prototype.setWorldOrgY = function(t) {
              this.lworldOrgY = t;
            }, e.prototype.getWorldExtX = function() {
              return this.lworldExtX;
            }, e.prototype.setWorldExtX = function(t) {
              this.lworldExtX = t;
            }, e.prototype.getWorldExtY = function() {
              return this.lworldExtY;
            }, e.prototype.setWorldExtY = function(t) {
              this.lworldExtY = t;
            }, e.prototype.getDeviceOrgX = function() {
              return this.ldeviceOrgX;
            }, e.prototype.setDeviceOrgX = function(t) {
              this.ldeviceOrgX = t;
            }, e.prototype.getDeviceOrgY = function() {
              return this.ldeviceOrgY;
            }, e.prototype.setDeviceOrgY = function(t) {
              this.ldeviceOrgY = t;
            }, e.prototype.getDeviceExtX = function() {
              return this.ldeviceExtX;
            }, e.prototype.setDeviceExtX = function(t) {
              this.ldeviceExtX = t;
            }, e.prototype.getDeviceExtY = function() {
              return this.ldeviceExtY;
            }, e.prototype.setDeviceExtY = function(t) {
              this.ldeviceExtY = t;
            }, e.prototype.transformX = function(t) {
              var i = 0, l = this.lworldExtX;
              return l != 0 && (i = this.ldeviceOrgX + (t - this.lworldOrgX) * this.ldeviceExtX / l), i;
            }, e.prototype.transformY = function(t) {
              var i = 0, l = this.lworldExtY;
              return l != 0 && (i = this.ldeviceOrgY + (t - this.lworldOrgY) * this.ldeviceExtY / l), i;
            }, e.prototype.inverseTransformX = function(t) {
              var i = 0, l = this.ldeviceExtX;
              return l != 0 && (i = this.lworldOrgX + (t - this.ldeviceOrgX) * this.lworldExtX / l), i;
            }, e.prototype.inverseTransformY = function(t) {
              var i = 0, l = this.ldeviceExtY;
              return l != 0 && (i = this.lworldOrgY + (t - this.ldeviceOrgY) * this.lworldExtY / l), i;
            }, e.prototype.inverseTransformPoint = function(t) {
              var i = new o(this.inverseTransformX(t.x), this.inverseTransformY(t.y));
              return i;
            }, N.exports = e;
          }),
          /* 18 */
          /***/
          (function(N, I, L) {
            function o(r) {
              if (Array.isArray(r)) {
                for (var h = 0, a = Array(r.length); h < r.length; h++)
                  a[h] = r[h];
                return a;
              } else
                return Array.from(r);
            }
            var e = L(15), t = L(7), i = L(0), l = L(8), g = L(9);
            function n() {
              e.call(this), this.useSmartIdealEdgeLengthCalculation = t.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.idealEdgeLength = t.DEFAULT_EDGE_LENGTH, this.springConstant = t.DEFAULT_SPRING_STRENGTH, this.repulsionConstant = t.DEFAULT_REPULSION_STRENGTH, this.gravityConstant = t.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = t.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = t.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = t.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * t.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = t.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = t.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = t.MAX_ITERATIONS;
            }
            n.prototype = Object.create(e.prototype);
            for (var d in e)
              n[d] = e[d];
            n.prototype.initParameters = function() {
              e.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = t.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = [];
            }, n.prototype.calcIdealEdgeLengths = function() {
              for (var r, h, a, p, v, D, u = this.getGraphManager().getAllEdges(), T = 0; T < u.length; T++)
                r = u[T], r.idealLength = this.idealEdgeLength, r.isInterGraph && (a = r.getSource(), p = r.getTarget(), v = r.getSourceInLca().getEstimatedSize(), D = r.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (r.idealLength += v + D - 2 * i.SIMPLE_NODE_SIZE), h = r.getLca().getInclusionTreeDepth(), r.idealLength += t.DEFAULT_EDGE_LENGTH * t.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (a.getInclusionTreeDepth() + p.getInclusionTreeDepth() - 2 * h));
            }, n.prototype.initSpringEmbedder = function() {
              var r = this.getAllNodes().length;
              this.incremental ? (r > t.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * t.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (r - t.ADAPTATION_LOWER_NODE_LIMIT) / (t.ADAPTATION_UPPER_NODE_LIMIT - t.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - t.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = t.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (r > t.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(t.COOLING_ADAPTATION_FACTOR, 1 - (r - t.ADAPTATION_LOWER_NODE_LIMIT) / (t.ADAPTATION_UPPER_NODE_LIMIT - t.ADAPTATION_LOWER_NODE_LIMIT) * (1 - t.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = t.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange();
            }, n.prototype.calcSpringForces = function() {
              for (var r = this.getAllEdges(), h, a = 0; a < r.length; a++)
                h = r[a], this.calcSpringForce(h, h.idealLength);
            }, n.prototype.calcRepulsionForces = function() {
              var r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, h = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, a, p, v, D, u = this.getAllNodes(), T;
              if (this.useFRGridVariant)
                for (this.totalIterations % t.GRID_CALCULATION_CHECK_PERIOD == 1 && r && this.updateGrid(), T = /* @__PURE__ */ new Set(), a = 0; a < u.length; a++)
                  v = u[a], this.calculateRepulsionForceOfANode(v, T, r, h), T.add(v);
              else
                for (a = 0; a < u.length; a++)
                  for (v = u[a], p = a + 1; p < u.length; p++)
                    D = u[p], v.getOwner() == D.getOwner() && this.calcRepulsionForce(v, D);
            }, n.prototype.calcGravitationalForces = function() {
              for (var r, h = this.getAllNodesToApplyGravitation(), a = 0; a < h.length; a++)
                r = h[a], this.calcGravitationalForce(r);
            }, n.prototype.moveNodes = function() {
              for (var r = this.getAllNodes(), h, a = 0; a < r.length; a++)
                h = r[a], h.move();
            }, n.prototype.calcSpringForce = function(r, h) {
              var a = r.getSource(), p = r.getTarget(), v, D, u, T;
              if (this.uniformLeafNodeSizes && a.getChild() == null && p.getChild() == null)
                r.updateLengthSimple();
              else if (r.updateLength(), r.isOverlapingSourceAndTarget)
                return;
              v = r.getLength(), v != 0 && (D = this.springConstant * (v - h), u = D * (r.lengthX / v), T = D * (r.lengthY / v), a.springForceX += u, a.springForceY += T, p.springForceX -= u, p.springForceY -= T);
            }, n.prototype.calcRepulsionForce = function(r, h) {
              var a = r.getRect(), p = h.getRect(), v = new Array(2), D = new Array(4), u, T, y, O, s, f, c;
              if (a.intersects(p)) {
                l.calcSeparationAmount(a, p, v, t.DEFAULT_EDGE_LENGTH / 2), f = 2 * v[0], c = 2 * v[1];
                var E = r.noOfChildren * h.noOfChildren / (r.noOfChildren + h.noOfChildren);
                r.repulsionForceX -= E * f, r.repulsionForceY -= E * c, h.repulsionForceX += E * f, h.repulsionForceY += E * c;
              } else
                this.uniformLeafNodeSizes && r.getChild() == null && h.getChild() == null ? (u = p.getCenterX() - a.getCenterX(), T = p.getCenterY() - a.getCenterY()) : (l.getIntersection(a, p, D), u = D[2] - D[0], T = D[3] - D[1]), Math.abs(u) < t.MIN_REPULSION_DIST && (u = g.sign(u) * t.MIN_REPULSION_DIST), Math.abs(T) < t.MIN_REPULSION_DIST && (T = g.sign(T) * t.MIN_REPULSION_DIST), y = u * u + T * T, O = Math.sqrt(y), s = this.repulsionConstant * r.noOfChildren * h.noOfChildren / y, f = s * u / O, c = s * T / O, r.repulsionForceX -= f, r.repulsionForceY -= c, h.repulsionForceX += f, h.repulsionForceY += c;
            }, n.prototype.calcGravitationalForce = function(r) {
              var h, a, p, v, D, u, T, y;
              h = r.getOwner(), a = (h.getRight() + h.getLeft()) / 2, p = (h.getTop() + h.getBottom()) / 2, v = r.getCenterX() - a, D = r.getCenterY() - p, u = Math.abs(v) + r.getWidth() / 2, T = Math.abs(D) + r.getHeight() / 2, r.getOwner() == this.graphManager.getRoot() ? (y = h.getEstimatedSize() * this.gravityRangeFactor, (u > y || T > y) && (r.gravitationForceX = -this.gravityConstant * v, r.gravitationForceY = -this.gravityConstant * D)) : (y = h.getEstimatedSize() * this.compoundGravityRangeFactor, (u > y || T > y) && (r.gravitationForceX = -this.gravityConstant * v * this.compoundGravityConstant, r.gravitationForceY = -this.gravityConstant * D * this.compoundGravityConstant));
            }, n.prototype.isConverged = function() {
              var r, h = !1;
              return this.totalIterations > this.maxIterations / 3 && (h = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), r = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, r || h;
            }, n.prototype.animate = function() {
              this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++);
            }, n.prototype.calcNoOfChildrenForAllNodes = function() {
              for (var r, h = this.graphManager.getAllNodes(), a = 0; a < h.length; a++)
                r = h[a], r.noOfChildren = r.getNoOfChildren();
            }, n.prototype.calcGrid = function(r) {
              var h = 0, a = 0;
              h = parseInt(Math.ceil((r.getRight() - r.getLeft()) / this.repulsionRange)), a = parseInt(Math.ceil((r.getBottom() - r.getTop()) / this.repulsionRange));
              for (var p = new Array(h), v = 0; v < h; v++)
                p[v] = new Array(a);
              for (var v = 0; v < h; v++)
                for (var D = 0; D < a; D++)
                  p[v][D] = new Array();
              return p;
            }, n.prototype.addNodeToGrid = function(r, h, a) {
              var p = 0, v = 0, D = 0, u = 0;
              p = parseInt(Math.floor((r.getRect().x - h) / this.repulsionRange)), v = parseInt(Math.floor((r.getRect().width + r.getRect().x - h) / this.repulsionRange)), D = parseInt(Math.floor((r.getRect().y - a) / this.repulsionRange)), u = parseInt(Math.floor((r.getRect().height + r.getRect().y - a) / this.repulsionRange));
              for (var T = p; T <= v; T++)
                for (var y = D; y <= u; y++)
                  this.grid[T][y].push(r), r.setGridCoordinates(p, v, D, u);
            }, n.prototype.updateGrid = function() {
              var r, h, a = this.getAllNodes();
              for (this.grid = this.calcGrid(this.graphManager.getRoot()), r = 0; r < a.length; r++)
                h = a[r], this.addNodeToGrid(h, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop());
            }, n.prototype.calculateRepulsionForceOfANode = function(r, h, a, p) {
              if (this.totalIterations % t.GRID_CALCULATION_CHECK_PERIOD == 1 && a || p) {
                var v = /* @__PURE__ */ new Set();
                r.surrounding = new Array();
                for (var D, u = this.grid, T = r.startX - 1; T < r.finishX + 2; T++)
                  for (var y = r.startY - 1; y < r.finishY + 2; y++)
                    if (!(T < 0 || y < 0 || T >= u.length || y >= u[0].length)) {
                      for (var O = 0; O < u[T][y].length; O++)
                        if (D = u[T][y][O], !(r.getOwner() != D.getOwner() || r == D) && !h.has(D) && !v.has(D)) {
                          var s = Math.abs(r.getCenterX() - D.getCenterX()) - (r.getWidth() / 2 + D.getWidth() / 2), f = Math.abs(r.getCenterY() - D.getCenterY()) - (r.getHeight() / 2 + D.getHeight() / 2);
                          s <= this.repulsionRange && f <= this.repulsionRange && v.add(D);
                        }
                    }
                r.surrounding = [].concat(o(v));
              }
              for (T = 0; T < r.surrounding.length; T++)
                this.calcRepulsionForce(r, r.surrounding[T]);
            }, n.prototype.calcRepulsionRange = function() {
              return 0;
            }, N.exports = n;
          }),
          /* 19 */
          /***/
          (function(N, I, L) {
            var o = L(1), e = L(7);
            function t(l, g, n) {
              o.call(this, l, g, n), this.idealLength = e.DEFAULT_EDGE_LENGTH;
            }
            t.prototype = Object.create(o.prototype);
            for (var i in o)
              t[i] = o[i];
            N.exports = t;
          }),
          /* 20 */
          /***/
          (function(N, I, L) {
            var o = L(3);
            function e(i, l, g, n) {
              o.call(this, i, l, g, n), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = [];
            }
            e.prototype = Object.create(o.prototype);
            for (var t in o)
              e[t] = o[t];
            e.prototype.setGridCoordinates = function(i, l, g, n) {
              this.startX = i, this.finishX = l, this.startY = g, this.finishY = n;
            }, N.exports = e;
          }),
          /* 21 */
          /***/
          (function(N, I, L) {
            function o(e, t) {
              this.width = 0, this.height = 0, e !== null && t !== null && (this.height = t, this.width = e);
            }
            o.prototype.getWidth = function() {
              return this.width;
            }, o.prototype.setWidth = function(e) {
              this.width = e;
            }, o.prototype.getHeight = function() {
              return this.height;
            }, o.prototype.setHeight = function(e) {
              this.height = e;
            }, N.exports = o;
          }),
          /* 22 */
          /***/
          (function(N, I, L) {
            var o = L(14);
            function e() {
              this.map = {}, this.keys = [];
            }
            e.prototype.put = function(t, i) {
              var l = o.createID(t);
              this.contains(l) || (this.map[l] = i, this.keys.push(t));
            }, e.prototype.contains = function(t) {
              return o.createID(t), this.map[t] != null;
            }, e.prototype.get = function(t) {
              var i = o.createID(t);
              return this.map[i];
            }, e.prototype.keySet = function() {
              return this.keys;
            }, N.exports = e;
          }),
          /* 23 */
          /***/
          (function(N, I, L) {
            var o = L(14);
            function e() {
              this.set = {};
            }
            e.prototype.add = function(t) {
              var i = o.createID(t);
              this.contains(i) || (this.set[i] = t);
            }, e.prototype.remove = function(t) {
              delete this.set[o.createID(t)];
            }, e.prototype.clear = function() {
              this.set = {};
            }, e.prototype.contains = function(t) {
              return this.set[o.createID(t)] == t;
            }, e.prototype.isEmpty = function() {
              return this.size() === 0;
            }, e.prototype.size = function() {
              return Object.keys(this.set).length;
            }, e.prototype.addAllTo = function(t) {
              for (var i = Object.keys(this.set), l = i.length, g = 0; g < l; g++)
                t.push(this.set[i[g]]);
            }, e.prototype.size = function() {
              return Object.keys(this.set).length;
            }, e.prototype.addAll = function(t) {
              for (var i = t.length, l = 0; l < i; l++) {
                var g = t[l];
                this.add(g);
              }
            }, N.exports = e;
          }),
          /* 24 */
          /***/
          (function(N, I, L) {
            var o = /* @__PURE__ */ (function() {
              function l(g, n) {
                for (var d = 0; d < n.length; d++) {
                  var r = n[d];
                  r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(g, r.key, r);
                }
              }
              return function(g, n, d) {
                return n && l(g.prototype, n), d && l(g, d), g;
              };
            })();
            function e(l, g) {
              if (!(l instanceof g))
                throw new TypeError("Cannot call a class as a function");
            }
            var t = L(11), i = (function() {
              function l(g, n) {
                e(this, l), (n !== null || n !== void 0) && (this.compareFunction = this._defaultCompareFunction);
                var d = void 0;
                g instanceof t ? d = g.size() : d = g.length, this._quicksort(g, 0, d - 1);
              }
              return o(l, [{
                key: "_quicksort",
                value: function(n, d, r) {
                  if (d < r) {
                    var h = this._partition(n, d, r);
                    this._quicksort(n, d, h), this._quicksort(n, h + 1, r);
                  }
                }
              }, {
                key: "_partition",
                value: function(n, d, r) {
                  for (var h = this._get(n, d), a = d, p = r; ; ) {
                    for (; this.compareFunction(h, this._get(n, p)); )
                      p--;
                    for (; this.compareFunction(this._get(n, a), h); )
                      a++;
                    if (a < p)
                      this._swap(n, a, p), a++, p--;
                    else return p;
                  }
                }
              }, {
                key: "_get",
                value: function(n, d) {
                  return n instanceof t ? n.get_object_at(d) : n[d];
                }
              }, {
                key: "_set",
                value: function(n, d, r) {
                  n instanceof t ? n.set_object_at(d, r) : n[d] = r;
                }
              }, {
                key: "_swap",
                value: function(n, d, r) {
                  var h = this._get(n, d);
                  this._set(n, d, this._get(n, r)), this._set(n, r, h);
                }
              }, {
                key: "_defaultCompareFunction",
                value: function(n, d) {
                  return d > n;
                }
              }]), l;
            })();
            N.exports = i;
          }),
          /* 25 */
          /***/
          (function(N, I, L) {
            var o = /* @__PURE__ */ (function() {
              function i(l, g) {
                for (var n = 0; n < g.length; n++) {
                  var d = g[n];
                  d.enumerable = d.enumerable || !1, d.configurable = !0, "value" in d && (d.writable = !0), Object.defineProperty(l, d.key, d);
                }
              }
              return function(l, g, n) {
                return g && i(l.prototype, g), n && i(l, n), l;
              };
            })();
            function e(i, l) {
              if (!(i instanceof l))
                throw new TypeError("Cannot call a class as a function");
            }
            var t = (function() {
              function i(l, g) {
                var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, d = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1;
                e(this, i), this.sequence1 = l, this.sequence2 = g, this.match_score = n, this.mismatch_penalty = d, this.gap_penalty = r, this.iMax = l.length + 1, this.jMax = g.length + 1, this.grid = new Array(this.iMax);
                for (var h = 0; h < this.iMax; h++) {
                  this.grid[h] = new Array(this.jMax);
                  for (var a = 0; a < this.jMax; a++)
                    this.grid[h][a] = 0;
                }
                this.tracebackGrid = new Array(this.iMax);
                for (var p = 0; p < this.iMax; p++) {
                  this.tracebackGrid[p] = new Array(this.jMax);
                  for (var v = 0; v < this.jMax; v++)
                    this.tracebackGrid[p][v] = [null, null, null];
                }
                this.alignments = [], this.score = -1, this.computeGrids();
              }
              return o(i, [{
                key: "getScore",
                value: function() {
                  return this.score;
                }
              }, {
                key: "getAlignments",
                value: function() {
                  return this.alignments;
                }
                // Main dynamic programming procedure
              }, {
                key: "computeGrids",
                value: function() {
                  for (var g = 1; g < this.jMax; g++)
                    this.grid[0][g] = this.grid[0][g - 1] + this.gap_penalty, this.tracebackGrid[0][g] = [!1, !1, !0];
                  for (var n = 1; n < this.iMax; n++)
                    this.grid[n][0] = this.grid[n - 1][0] + this.gap_penalty, this.tracebackGrid[n][0] = [!1, !0, !1];
                  for (var d = 1; d < this.iMax; d++)
                    for (var r = 1; r < this.jMax; r++) {
                      var h = void 0;
                      this.sequence1[d - 1] === this.sequence2[r - 1] ? h = this.grid[d - 1][r - 1] + this.match_score : h = this.grid[d - 1][r - 1] + this.mismatch_penalty;
                      var a = this.grid[d - 1][r] + this.gap_penalty, p = this.grid[d][r - 1] + this.gap_penalty, v = [h, a, p], D = this.arrayAllMaxIndexes(v);
                      this.grid[d][r] = v[D[0]], this.tracebackGrid[d][r] = [D.includes(0), D.includes(1), D.includes(2)];
                    }
                  this.score = this.grid[this.iMax - 1][this.jMax - 1];
                }
                // Gets all possible valid sequence combinations
              }, {
                key: "alignmentTraceback",
                value: function() {
                  var g = [];
                  for (g.push({
                    pos: [this.sequence1.length, this.sequence2.length],
                    seq1: "",
                    seq2: ""
                  }); g[0]; ) {
                    var n = g[0], d = this.tracebackGrid[n.pos[0]][n.pos[1]];
                    d[0] && g.push({
                      pos: [n.pos[0] - 1, n.pos[1] - 1],
                      seq1: this.sequence1[n.pos[0] - 1] + n.seq1,
                      seq2: this.sequence2[n.pos[1] - 1] + n.seq2
                    }), d[1] && g.push({
                      pos: [n.pos[0] - 1, n.pos[1]],
                      seq1: this.sequence1[n.pos[0] - 1] + n.seq1,
                      seq2: "-" + n.seq2
                    }), d[2] && g.push({
                      pos: [n.pos[0], n.pos[1] - 1],
                      seq1: "-" + n.seq1,
                      seq2: this.sequence2[n.pos[1] - 1] + n.seq2
                    }), n.pos[0] === 0 && n.pos[1] === 0 && this.alignments.push({
                      sequence1: n.seq1,
                      sequence2: n.seq2
                    }), g.shift();
                  }
                  return this.alignments;
                }
                // Helper Functions
              }, {
                key: "getAllIndexes",
                value: function(g, n) {
                  for (var d = [], r = -1; (r = g.indexOf(n, r + 1)) !== -1; )
                    d.push(r);
                  return d;
                }
              }, {
                key: "arrayAllMaxIndexes",
                value: function(g) {
                  return this.getAllIndexes(g, Math.max.apply(null, g));
                }
              }]), i;
            })();
            N.exports = t;
          }),
          /* 26 */
          /***/
          (function(N, I, L) {
            var o = function() {
            };
            o.FDLayout = L(18), o.FDLayoutConstants = L(7), o.FDLayoutEdge = L(19), o.FDLayoutNode = L(20), o.DimensionD = L(21), o.HashMap = L(22), o.HashSet = L(23), o.IGeometry = L(8), o.IMath = L(9), o.Integer = L(10), o.Point = L(12), o.PointD = L(4), o.RandomSeed = L(16), o.RectangleD = L(13), o.Transform = L(17), o.UniqueIDGeneretor = L(14), o.Quicksort = L(24), o.LinkedList = L(11), o.LGraphObject = L(2), o.LGraph = L(5), o.LEdge = L(1), o.LGraphManager = L(6), o.LNode = L(3), o.Layout = L(15), o.LayoutConstants = L(0), o.NeedlemanWunsch = L(25), N.exports = o;
          }),
          /* 27 */
          /***/
          (function(N, I, L) {
            function o() {
              this.listeners = [];
            }
            var e = o.prototype;
            e.addListener = function(t, i) {
              this.listeners.push({
                event: t,
                callback: i
              });
            }, e.removeListener = function(t, i) {
              for (var l = this.listeners.length; l >= 0; l--) {
                var g = this.listeners[l];
                g.event === t && g.callback === i && this.listeners.splice(l, 1);
              }
            }, e.emit = function(t, i) {
              for (var l = 0; l < this.listeners.length; l++) {
                var g = this.listeners[l];
                t === g.event && g.callback(i);
              }
            }, N.exports = o;
          })
          /******/
        ])
      );
    });
  })(Q)), Q.exports;
}
var ct = Z.exports, z;
function pt() {
  return z || (z = 1, (function(G, b) {
    (function(I, L) {
      G.exports = L(ft());
    })(ct, function(N) {
      return (
        /******/
        (function(I) {
          var L = {};
          function o(e) {
            if (L[e])
              return L[e].exports;
            var t = L[e] = {
              /******/
              i: e,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return I[e].call(t.exports, t, t.exports, o), t.l = !0, t.exports;
          }
          return o.m = I, o.c = L, o.i = function(e) {
            return e;
          }, o.d = function(e, t, i) {
            o.o(e, t) || Object.defineProperty(e, t, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: i
              /******/
            });
          }, o.n = function(e) {
            var t = e && e.__esModule ? (
              /******/
              function() {
                return e.default;
              }
            ) : (
              /******/
              function() {
                return e;
              }
            );
            return o.d(t, "a", t), t;
          }, o.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
          }, o.p = "", o(o.s = 7);
        })([
          /* 0 */
          /***/
          (function(I, L) {
            I.exports = N;
          }),
          /* 1 */
          /***/
          (function(I, L, o) {
            var e = o(0).FDLayoutConstants;
            function t() {
            }
            for (var i in e)
              t[i] = e[i];
            t.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, t.DEFAULT_RADIAL_SEPARATION = e.DEFAULT_EDGE_LENGTH, t.DEFAULT_COMPONENT_SEPERATION = 60, t.TILE = !0, t.TILING_PADDING_VERTICAL = 10, t.TILING_PADDING_HORIZONTAL = 10, t.TREE_REDUCTION_ON_INCREMENTAL = !1, I.exports = t;
          }),
          /* 2 */
          /***/
          (function(I, L, o) {
            var e = o(0).FDLayoutEdge;
            function t(l, g, n) {
              e.call(this, l, g, n);
            }
            t.prototype = Object.create(e.prototype);
            for (var i in e)
              t[i] = e[i];
            I.exports = t;
          }),
          /* 3 */
          /***/
          (function(I, L, o) {
            var e = o(0).LGraph;
            function t(l, g, n) {
              e.call(this, l, g, n);
            }
            t.prototype = Object.create(e.prototype);
            for (var i in e)
              t[i] = e[i];
            I.exports = t;
          }),
          /* 4 */
          /***/
          (function(I, L, o) {
            var e = o(0).LGraphManager;
            function t(l) {
              e.call(this, l);
            }
            t.prototype = Object.create(e.prototype);
            for (var i in e)
              t[i] = e[i];
            I.exports = t;
          }),
          /* 5 */
          /***/
          (function(I, L, o) {
            var e = o(0).FDLayoutNode, t = o(0).IMath;
            function i(g, n, d, r) {
              e.call(this, g, n, d, r);
            }
            i.prototype = Object.create(e.prototype);
            for (var l in e)
              i[l] = e[l];
            i.prototype.move = function() {
              var g = this.graphManager.getLayout();
              this.displacementX = g.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY = g.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren, Math.abs(this.displacementX) > g.coolingFactor * g.maxNodeDisplacement && (this.displacementX = g.coolingFactor * g.maxNodeDisplacement * t.sign(this.displacementX)), Math.abs(this.displacementY) > g.coolingFactor * g.maxNodeDisplacement && (this.displacementY = g.coolingFactor * g.maxNodeDisplacement * t.sign(this.displacementY)), this.child == null ? this.moveBy(this.displacementX, this.displacementY) : this.child.getNodes().length == 0 ? this.moveBy(this.displacementX, this.displacementY) : this.propogateDisplacementToChildren(this.displacementX, this.displacementY), g.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0;
            }, i.prototype.propogateDisplacementToChildren = function(g, n) {
              for (var d = this.getChild().getNodes(), r, h = 0; h < d.length; h++)
                r = d[h], r.getChild() == null ? (r.moveBy(g, n), r.displacementX += g, r.displacementY += n) : r.propogateDisplacementToChildren(g, n);
            }, i.prototype.setPred1 = function(g) {
              this.pred1 = g;
            }, i.prototype.getPred1 = function() {
              return pred1;
            }, i.prototype.getPred2 = function() {
              return pred2;
            }, i.prototype.setNext = function(g) {
              this.next = g;
            }, i.prototype.getNext = function() {
              return next;
            }, i.prototype.setProcessed = function(g) {
              this.processed = g;
            }, i.prototype.isProcessed = function() {
              return processed;
            }, I.exports = i;
          }),
          /* 6 */
          /***/
          (function(I, L, o) {
            var e = o(0).FDLayout, t = o(4), i = o(3), l = o(5), g = o(2), n = o(1), d = o(0).FDLayoutConstants, r = o(0).LayoutConstants, h = o(0).Point, a = o(0).PointD, p = o(0).Layout, v = o(0).Integer, D = o(0).IGeometry, u = o(0).LGraph, T = o(0).Transform;
            function y() {
              e.call(this), this.toBeTiled = {};
            }
            y.prototype = Object.create(e.prototype);
            for (var O in e)
              y[O] = e[O];
            y.prototype.newGraphManager = function() {
              var s = new t(this);
              return this.graphManager = s, s;
            }, y.prototype.newGraph = function(s) {
              return new i(null, this.graphManager, s);
            }, y.prototype.newNode = function(s) {
              return new l(this.graphManager, s);
            }, y.prototype.newEdge = function(s) {
              return new g(null, null, s);
            }, y.prototype.initParameters = function() {
              e.prototype.initParameters.call(this, arguments), this.isSubLayout || (n.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = n.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = n.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.springConstant = d.DEFAULT_SPRING_STRENGTH, this.repulsionConstant = d.DEFAULT_REPULSION_STRENGTH, this.gravityConstant = d.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = d.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = d.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = d.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1, this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / d.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = d.CONVERGENCE_CHECK_PERIOD / this.maxIterations, this.coolingAdjuster = 1);
            }, y.prototype.layout = function() {
              var s = r.DEFAULT_CREATE_BENDS_AS_NEEDED;
              return s && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout();
            }, y.prototype.classicLayout = function() {
              if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
                if (n.TREE_REDUCTION_ON_INCREMENTAL) {
                  this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                  var f = new Set(this.getAllNodes()), c = this.nodesWithGravity.filter(function(m) {
                    return f.has(m);
                  });
                  this.graphManager.setAllNodesToApplyGravitation(c);
                }
              } else {
                var s = this.getFlatForest();
                if (s.length > 0)
                  this.positionNodesRadially(s);
                else {
                  this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                  var f = new Set(this.getAllNodes()), c = this.nodesWithGravity.filter(function(E) {
                    return f.has(E);
                  });
                  this.graphManager.setAllNodesToApplyGravitation(c), this.positionNodesRandomly();
                }
              }
              return this.initSpringEmbedder(), this.runSpringEmbedder(), !0;
            }, y.prototype.tick = function() {
              if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
                if (this.prunedNodesAll.length > 0)
                  this.isTreeGrowing = !0;
                else
                  return !0;
              if (this.totalIterations % d.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
                if (this.isConverged())
                  if (this.prunedNodesAll.length > 0)
                    this.isTreeGrowing = !0;
                  else
                    return !0;
                this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
              }
              if (this.isTreeGrowing) {
                if (this.growTreeIterations % 10 == 0)
                  if (this.prunedNodesAll.length > 0) {
                    this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                    var s = new Set(this.getAllNodes()), f = this.nodesWithGravity.filter(function(A) {
                      return s.has(A);
                    });
                    this.graphManager.setAllNodesToApplyGravitation(f), this.graphManager.updateBounds(), this.updateGrid(), this.coolingFactor = d.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                  } else
                    this.isTreeGrowing = !1, this.isGrowthFinished = !0;
                this.growTreeIterations++;
              }
              if (this.isGrowthFinished) {
                if (this.isConverged())
                  return !0;
                this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), this.coolingFactor = d.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
              }
              var c = !this.isTreeGrowing && !this.isGrowthFinished, E = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished;
              return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(c, E), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1;
            }, y.prototype.getPositionsData = function() {
              for (var s = this.graphManager.getAllNodes(), f = {}, c = 0; c < s.length; c++) {
                var E = s[c].rect, A = s[c].id;
                f[A] = {
                  id: A,
                  x: E.getCenterX(),
                  y: E.getCenterY(),
                  w: E.width,
                  h: E.height
                };
              }
              return f;
            }, y.prototype.runSpringEmbedder = function() {
              this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod;
              var s = !1;
              if (d.ANIMATE === "during")
                this.emit("layoutstarted");
              else {
                for (; !s; )
                  s = this.tick();
                this.graphManager.updateBounds();
              }
            }, y.prototype.calculateNodesToApplyGravitationTo = function() {
              var s = [], f, c = this.graphManager.getGraphs(), E = c.length, A;
              for (A = 0; A < E; A++)
                f = c[A], f.updateConnected(), f.isConnected || (s = s.concat(f.getNodes()));
              return s;
            }, y.prototype.createBendpoints = function() {
              var s = [];
              s = s.concat(this.graphManager.getAllEdges());
              var f = /* @__PURE__ */ new Set(), c;
              for (c = 0; c < s.length; c++) {
                var E = s[c];
                if (!f.has(E)) {
                  var A = E.getSource(), m = E.getTarget();
                  if (A == m)
                    E.getBendpoints().push(new a()), E.getBendpoints().push(new a()), this.createDummyNodesForBendpoints(E), f.add(E);
                  else {
                    var C = [];
                    if (C = C.concat(A.getEdgeListToNode(m)), C = C.concat(m.getEdgeListToNode(A)), !f.has(C[0])) {
                      if (C.length > 1) {
                        var R;
                        for (R = 0; R < C.length; R++) {
                          var M = C[R];
                          M.getBendpoints().push(new a()), this.createDummyNodesForBendpoints(M);
                        }
                      }
                      C.forEach(function(S) {
                        f.add(S);
                      });
                    }
                  }
                }
                if (f.size == s.length)
                  break;
              }
            }, y.prototype.positionNodesRadially = function(s) {
              for (var f = new h(0, 0), c = Math.ceil(Math.sqrt(s.length)), E = 0, A = 0, m = 0, C = new a(0, 0), R = 0; R < s.length; R++) {
                R % c == 0 && (m = 0, A = E, R != 0 && (A += n.DEFAULT_COMPONENT_SEPERATION), E = 0);
                var M = s[R], S = p.findCenterOfTree(M);
                f.x = m, f.y = A, C = y.radialLayout(M, S, f), C.y > E && (E = Math.floor(C.y)), m = Math.floor(C.x + n.DEFAULT_COMPONENT_SEPERATION);
              }
              this.transform(new a(r.WORLD_CENTER_X - C.x / 2, r.WORLD_CENTER_Y - C.y / 2));
            }, y.radialLayout = function(s, f, c) {
              var E = Math.max(this.maxDiagonalInTree(s), n.DEFAULT_RADIAL_SEPARATION);
              y.branchRadialLayout(f, null, 0, 359, 0, E);
              var A = u.calculateBounds(s), m = new T();
              m.setDeviceOrgX(A.getMinX()), m.setDeviceOrgY(A.getMinY()), m.setWorldOrgX(c.x), m.setWorldOrgY(c.y);
              for (var C = 0; C < s.length; C++) {
                var R = s[C];
                R.transform(m);
              }
              var M = new a(A.getMaxX(), A.getMaxY());
              return m.inverseTransformPoint(M);
            }, y.branchRadialLayout = function(s, f, c, E, A, m) {
              var C = (E - c + 1) / 2;
              C < 0 && (C += 180);
              var R = (C + c) % 360, M = R * D.TWO_PI / 360, S = A * Math.cos(M), Y = A * Math.sin(M);
              s.setCenter(S, Y);
              var w = [];
              w = w.concat(s.getEdges());
              var x = w.length;
              f != null && x--;
              for (var F = 0, U = w.length, P, _ = s.getEdgesBetween(f); _.length > 1; ) {
                var X = _[0];
                _.splice(0, 1);
                var H = w.indexOf(X);
                H >= 0 && w.splice(H, 1), U--, x--;
              }
              f != null ? P = (w.indexOf(_[0]) + 1) % U : P = 0;
              for (var W = Math.abs(E - c) / x, B = P; F != x; B = ++B % U) {
                var K = w[B].getOtherEnd(s);
                if (K != f) {
                  var q = (c + F * W) % 360, ht = (q + W) % 360;
                  y.branchRadialLayout(K, s, q, ht, A + m, m), F++;
                }
              }
            }, y.maxDiagonalInTree = function(s) {
              for (var f = v.MIN_VALUE, c = 0; c < s.length; c++) {
                var E = s[c], A = E.getDiagonal();
                A > f && (f = A);
              }
              return f;
            }, y.prototype.calcRepulsionRange = function() {
              return 2 * (this.level + 1) * this.idealEdgeLength;
            }, y.prototype.groupZeroDegreeMembers = function() {
              var s = this, f = {};
              this.memberGroups = {}, this.idToDummyNode = {};
              for (var c = [], E = this.graphManager.getAllNodes(), A = 0; A < E.length; A++) {
                var m = E[A], C = m.getParent();
                this.getNodeDegreeWithChildren(m) === 0 && (C.id == null || !this.getToBeTiled(C)) && c.push(m);
              }
              for (var A = 0; A < c.length; A++) {
                var m = c[A], R = m.getParent().id;
                typeof f[R] > "u" && (f[R] = []), f[R] = f[R].concat(m);
              }
              Object.keys(f).forEach(function(M) {
                if (f[M].length > 1) {
                  var S = "DummyCompound_" + M;
                  s.memberGroups[S] = f[M];
                  var Y = f[M][0].getParent(), w = new l(s.graphManager);
                  w.id = S, w.paddingLeft = Y.paddingLeft || 0, w.paddingRight = Y.paddingRight || 0, w.paddingBottom = Y.paddingBottom || 0, w.paddingTop = Y.paddingTop || 0, s.idToDummyNode[S] = w;
                  var x = s.getGraphManager().add(s.newGraph(), w), F = Y.getChild();
                  F.add(w);
                  for (var U = 0; U < f[M].length; U++) {
                    var P = f[M][U];
                    F.remove(P), x.add(P);
                  }
                }
              });
            }, y.prototype.clearCompounds = function() {
              var s = {}, f = {};
              this.performDFSOnCompounds();
              for (var c = 0; c < this.compoundOrder.length; c++)
                f[this.compoundOrder[c].id] = this.compoundOrder[c], s[this.compoundOrder[c].id] = [].concat(this.compoundOrder[c].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[c].getChild()), this.compoundOrder[c].child = null;
              this.graphManager.resetAllNodes(), this.tileCompoundMembers(s, f);
            }, y.prototype.clearZeroDegreeMembers = function() {
              var s = this, f = this.tiledZeroDegreePack = [];
              Object.keys(this.memberGroups).forEach(function(c) {
                var E = s.idToDummyNode[c];
                f[c] = s.tileNodes(s.memberGroups[c], E.paddingLeft + E.paddingRight), E.rect.width = f[c].width, E.rect.height = f[c].height;
              });
            }, y.prototype.repopulateCompounds = function() {
              for (var s = this.compoundOrder.length - 1; s >= 0; s--) {
                var f = this.compoundOrder[s], c = f.id, E = f.paddingLeft, A = f.paddingTop;
                this.adjustLocations(this.tiledMemberPack[c], f.rect.x, f.rect.y, E, A);
              }
            }, y.prototype.repopulateZeroDegreeMembers = function() {
              var s = this, f = this.tiledZeroDegreePack;
              Object.keys(f).forEach(function(c) {
                var E = s.idToDummyNode[c], A = E.paddingLeft, m = E.paddingTop;
                s.adjustLocations(f[c], E.rect.x, E.rect.y, A, m);
              });
            }, y.prototype.getToBeTiled = function(s) {
              var f = s.id;
              if (this.toBeTiled[f] != null)
                return this.toBeTiled[f];
              var c = s.getChild();
              if (c == null)
                return this.toBeTiled[f] = !1, !1;
              for (var E = c.getNodes(), A = 0; A < E.length; A++) {
                var m = E[A];
                if (this.getNodeDegree(m) > 0)
                  return this.toBeTiled[f] = !1, !1;
                if (m.getChild() == null) {
                  this.toBeTiled[m.id] = !1;
                  continue;
                }
                if (!this.getToBeTiled(m))
                  return this.toBeTiled[f] = !1, !1;
              }
              return this.toBeTiled[f] = !0, !0;
            }, y.prototype.getNodeDegree = function(s) {
              s.id;
              for (var f = s.getEdges(), c = 0, E = 0; E < f.length; E++) {
                var A = f[E];
                A.getSource().id !== A.getTarget().id && (c = c + 1);
              }
              return c;
            }, y.prototype.getNodeDegreeWithChildren = function(s) {
              var f = this.getNodeDegree(s);
              if (s.getChild() == null)
                return f;
              for (var c = s.getChild().getNodes(), E = 0; E < c.length; E++) {
                var A = c[E];
                f += this.getNodeDegreeWithChildren(A);
              }
              return f;
            }, y.prototype.performDFSOnCompounds = function() {
              this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes());
            }, y.prototype.fillCompexOrderByDFS = function(s) {
              for (var f = 0; f < s.length; f++) {
                var c = s[f];
                c.getChild() != null && this.fillCompexOrderByDFS(c.getChild().getNodes()), this.getToBeTiled(c) && this.compoundOrder.push(c);
              }
            }, y.prototype.adjustLocations = function(s, f, c, E, A) {
              f += E, c += A;
              for (var m = f, C = 0; C < s.rows.length; C++) {
                var R = s.rows[C];
                f = m;
                for (var M = 0, S = 0; S < R.length; S++) {
                  var Y = R[S];
                  Y.rect.x = f, Y.rect.y = c, f += Y.rect.width + s.horizontalPadding, Y.rect.height > M && (M = Y.rect.height);
                }
                c += M + s.verticalPadding;
              }
            }, y.prototype.tileCompoundMembers = function(s, f) {
              var c = this;
              this.tiledMemberPack = [], Object.keys(s).forEach(function(E) {
                var A = f[E];
                c.tiledMemberPack[E] = c.tileNodes(s[E], A.paddingLeft + A.paddingRight), A.rect.width = c.tiledMemberPack[E].width, A.rect.height = c.tiledMemberPack[E].height;
              });
            }, y.prototype.tileNodes = function(s, f) {
              var c = n.TILING_PADDING_VERTICAL, E = n.TILING_PADDING_HORIZONTAL, A = {
                rows: [],
                rowWidth: [],
                rowHeight: [],
                width: 0,
                height: f,
                // assume minHeight equals to minWidth
                verticalPadding: c,
                horizontalPadding: E
              };
              s.sort(function(R, M) {
                return R.rect.width * R.rect.height > M.rect.width * M.rect.height ? -1 : R.rect.width * R.rect.height < M.rect.width * M.rect.height ? 1 : 0;
              });
              for (var m = 0; m < s.length; m++) {
                var C = s[m];
                A.rows.length == 0 ? this.insertNodeToRow(A, C, 0, f) : this.canAddHorizontal(A, C.rect.width, C.rect.height) ? this.insertNodeToRow(A, C, this.getShortestRowIndex(A), f) : this.insertNodeToRow(A, C, A.rows.length, f), this.shiftToLastRow(A);
              }
              return A;
            }, y.prototype.insertNodeToRow = function(s, f, c, E) {
              var A = E;
              if (c == s.rows.length) {
                var m = [];
                s.rows.push(m), s.rowWidth.push(A), s.rowHeight.push(0);
              }
              var C = s.rowWidth[c] + f.rect.width;
              s.rows[c].length > 0 && (C += s.horizontalPadding), s.rowWidth[c] = C, s.width < C && (s.width = C);
              var R = f.rect.height;
              c > 0 && (R += s.verticalPadding);
              var M = 0;
              R > s.rowHeight[c] && (M = s.rowHeight[c], s.rowHeight[c] = R, M = s.rowHeight[c] - M), s.height += M, s.rows[c].push(f);
            }, y.prototype.getShortestRowIndex = function(s) {
              for (var f = -1, c = Number.MAX_VALUE, E = 0; E < s.rows.length; E++)
                s.rowWidth[E] < c && (f = E, c = s.rowWidth[E]);
              return f;
            }, y.prototype.getLongestRowIndex = function(s) {
              for (var f = -1, c = Number.MIN_VALUE, E = 0; E < s.rows.length; E++)
                s.rowWidth[E] > c && (f = E, c = s.rowWidth[E]);
              return f;
            }, y.prototype.canAddHorizontal = function(s, f, c) {
              var E = this.getShortestRowIndex(s);
              if (E < 0)
                return !0;
              var A = s.rowWidth[E];
              if (A + s.horizontalPadding + f <= s.width) return !0;
              var m = 0;
              s.rowHeight[E] < c && E > 0 && (m = c + s.verticalPadding - s.rowHeight[E]);
              var C;
              s.width - A >= f + s.horizontalPadding ? C = (s.height + m) / (A + f + s.horizontalPadding) : C = (s.height + m) / s.width, m = c + s.verticalPadding;
              var R;
              return s.width < f ? R = (s.height + m) / f : R = (s.height + m) / s.width, R < 1 && (R = 1 / R), C < 1 && (C = 1 / C), C < R;
            }, y.prototype.shiftToLastRow = function(s) {
              var f = this.getLongestRowIndex(s), c = s.rowWidth.length - 1, E = s.rows[f], A = E[E.length - 1], m = A.width + s.horizontalPadding;
              if (s.width - s.rowWidth[c] > m && f != c) {
                E.splice(-1, 1), s.rows[c].push(A), s.rowWidth[f] = s.rowWidth[f] - m, s.rowWidth[c] = s.rowWidth[c] + m, s.width = s.rowWidth[instance.getLongestRowIndex(s)];
                for (var C = Number.MIN_VALUE, R = 0; R < E.length; R++)
                  E[R].height > C && (C = E[R].height);
                f > 0 && (C += s.verticalPadding);
                var M = s.rowHeight[f] + s.rowHeight[c];
                s.rowHeight[f] = C, s.rowHeight[c] < A.height + s.verticalPadding && (s.rowHeight[c] = A.height + s.verticalPadding);
                var S = s.rowHeight[f] + s.rowHeight[c];
                s.height += S - M, this.shiftToLastRow(s);
              }
            }, y.prototype.tilingPreLayout = function() {
              n.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers());
            }, y.prototype.tilingPostLayout = function() {
              n.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds());
            }, y.prototype.reduceTrees = function() {
              for (var s = [], f = !0, c; f; ) {
                var E = this.graphManager.getAllNodes(), A = [];
                f = !1;
                for (var m = 0; m < E.length; m++)
                  c = E[m], c.getEdges().length == 1 && !c.getEdges()[0].isInterGraph && c.getChild() == null && (A.push([c, c.getEdges()[0], c.getOwner()]), f = !0);
                if (f == !0) {
                  for (var C = [], R = 0; R < A.length; R++)
                    A[R][0].getEdges().length == 1 && (C.push(A[R]), A[R][0].getOwner().remove(A[R][0]));
                  s.push(C), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
                }
              }
              this.prunedNodesAll = s;
            }, y.prototype.growTree = function(s) {
              for (var f = s.length, c = s[f - 1], E, A = 0; A < c.length; A++)
                E = c[A], this.findPlaceforPrunedNode(E), E[2].add(E[0]), E[2].add(E[1], E[1].source, E[1].target);
              s.splice(s.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
            }, y.prototype.findPlaceforPrunedNode = function(s) {
              var f, c, E = s[0];
              E == s[1].source ? c = s[1].target : c = s[1].source;
              var A = c.startX, m = c.finishX, C = c.startY, R = c.finishY, M = 0, S = 0, Y = 0, w = 0, x = [M, Y, S, w];
              if (C > 0)
                for (var F = A; F <= m; F++)
                  x[0] += this.grid[F][C - 1].length + this.grid[F][C].length - 1;
              if (m < this.grid.length - 1)
                for (var F = C; F <= R; F++)
                  x[1] += this.grid[m + 1][F].length + this.grid[m][F].length - 1;
              if (R < this.grid[0].length - 1)
                for (var F = A; F <= m; F++)
                  x[2] += this.grid[F][R + 1].length + this.grid[F][R].length - 1;
              if (A > 0)
                for (var F = C; F <= R; F++)
                  x[3] += this.grid[A - 1][F].length + this.grid[A][F].length - 1;
              for (var U = v.MAX_VALUE, P, _, X = 0; X < x.length; X++)
                x[X] < U ? (U = x[X], P = 1, _ = X) : x[X] == U && P++;
              if (P == 3 && U == 0)
                x[0] == 0 && x[1] == 0 && x[2] == 0 ? f = 1 : x[0] == 0 && x[1] == 0 && x[3] == 0 ? f = 0 : x[0] == 0 && x[2] == 0 && x[3] == 0 ? f = 3 : x[1] == 0 && x[2] == 0 && x[3] == 0 && (f = 2);
              else if (P == 2 && U == 0) {
                var H = Math.floor(Math.random() * 2);
                x[0] == 0 && x[1] == 0 ? H == 0 ? f = 0 : f = 1 : x[0] == 0 && x[2] == 0 ? H == 0 ? f = 0 : f = 2 : x[0] == 0 && x[3] == 0 ? H == 0 ? f = 0 : f = 3 : x[1] == 0 && x[2] == 0 ? H == 0 ? f = 1 : f = 2 : x[1] == 0 && x[3] == 0 ? H == 0 ? f = 1 : f = 3 : H == 0 ? f = 2 : f = 3;
              } else if (P == 4 && U == 0) {
                var H = Math.floor(Math.random() * 4);
                f = H;
              } else
                f = _;
              f == 0 ? E.setCenter(c.getCenterX(), c.getCenterY() - c.getHeight() / 2 - d.DEFAULT_EDGE_LENGTH - E.getHeight() / 2) : f == 1 ? E.setCenter(c.getCenterX() + c.getWidth() / 2 + d.DEFAULT_EDGE_LENGTH + E.getWidth() / 2, c.getCenterY()) : f == 2 ? E.setCenter(c.getCenterX(), c.getCenterY() + c.getHeight() / 2 + d.DEFAULT_EDGE_LENGTH + E.getHeight() / 2) : E.setCenter(c.getCenterX() - c.getWidth() / 2 - d.DEFAULT_EDGE_LENGTH - E.getWidth() / 2, c.getCenterY());
            }, I.exports = y;
          }),
          /* 7 */
          /***/
          (function(I, L, o) {
            var e = {};
            e.layoutBase = o(0), e.CoSEConstants = o(1), e.CoSEEdge = o(2), e.CoSEGraph = o(3), e.CoSEGraphManager = o(4), e.CoSELayout = o(6), e.CoSENode = o(5), I.exports = e;
          })
          /******/
        ])
      );
    });
  })(Z)), Z.exports;
}
var dt = k.exports, J;
function vt() {
  return J || (J = 1, (function(G, b) {
    (function(I, L) {
      G.exports = L(pt());
    })(dt, function(N) {
      return (
        /******/
        (function(I) {
          var L = {};
          function o(e) {
            if (L[e])
              return L[e].exports;
            var t = L[e] = {
              /******/
              i: e,
              /******/
              l: !1,
              /******/
              exports: {}
              /******/
            };
            return I[e].call(t.exports, t, t.exports, o), t.l = !0, t.exports;
          }
          return o.m = I, o.c = L, o.i = function(e) {
            return e;
          }, o.d = function(e, t, i) {
            o.o(e, t) || Object.defineProperty(e, t, {
              /******/
              configurable: !1,
              /******/
              enumerable: !0,
              /******/
              get: i
              /******/
            });
          }, o.n = function(e) {
            var t = e && e.__esModule ? (
              /******/
              function() {
                return e.default;
              }
            ) : (
              /******/
              function() {
                return e;
              }
            );
            return o.d(t, "a", t), t;
          }, o.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
          }, o.p = "", o(o.s = 1);
        })([
          /* 0 */
          /***/
          (function(I, L) {
            I.exports = N;
          }),
          /* 1 */
          /***/
          (function(I, L, o) {
            var e = o(0).layoutBase.LayoutConstants, t = o(0).layoutBase.FDLayoutConstants, i = o(0).CoSEConstants, l = o(0).CoSELayout, g = o(0).CoSENode, n = o(0).layoutBase.PointD, d = o(0).layoutBase.DimensionD, r = {
              // Called on `layoutready`
              ready: function() {
              },
              // Called on `layoutstop`
              stop: function() {
              },
              // 'draft', 'default' or 'proof" 
              // - 'draft' fast cooling rate 
              // - 'default' moderate cooling rate 
              // - "proof" slow cooling rate
              quality: "default",
              // include labels in node dimensions
              nodeDimensionsIncludeLabels: !1,
              // number of ticks per frame; higher is faster but more jerky
              refresh: 30,
              // Whether to fit the network view after when done
              fit: !0,
              // Padding on fit
              padding: 10,
              // Whether to enable incremental mode
              randomize: !0,
              // Node repulsion (non overlapping) multiplier
              nodeRepulsion: 4500,
              // Ideal edge (non nested) length
              idealEdgeLength: 50,
              // Divisor to compute edge forces
              edgeElasticity: 0.45,
              // Nesting factor (multiplier) to compute ideal edge length for nested edges
              nestingFactor: 0.1,
              // Gravity force (constant)
              gravity: 0.25,
              // Maximum number of iterations to perform
              numIter: 2500,
              // For enabling tiling
              tile: !0,
              // Type of layout animation. The option set is {'during', 'end', false}
              animate: "end",
              // Duration for animate:end
              animationDuration: 500,
              // Represents the amount of the vertical space to put between the zero degree members during the tiling operation(can also be a function)
              tilingPaddingVertical: 10,
              // Represents the amount of the horizontal space to put between the zero degree members during the tiling operation(can also be a function)
              tilingPaddingHorizontal: 10,
              // Gravity range (constant) for compounds
              gravityRangeCompound: 1.5,
              // Gravity force (constant) for compounds
              gravityCompound: 1,
              // Gravity range (constant)
              gravityRange: 3.8,
              // Initial cooling factor for incremental layout
              initialEnergyOnIncremental: 0.5
            };
            function h(D, u) {
              var T = {};
              for (var y in D)
                T[y] = D[y];
              for (var y in u)
                T[y] = u[y];
              return T;
            }
            function a(D) {
              this.options = h(r, D), p(this.options);
            }
            var p = function(u) {
              u.nodeRepulsion != null && (i.DEFAULT_REPULSION_STRENGTH = t.DEFAULT_REPULSION_STRENGTH = u.nodeRepulsion), u.idealEdgeLength != null && (i.DEFAULT_EDGE_LENGTH = t.DEFAULT_EDGE_LENGTH = u.idealEdgeLength), u.edgeElasticity != null && (i.DEFAULT_SPRING_STRENGTH = t.DEFAULT_SPRING_STRENGTH = u.edgeElasticity), u.nestingFactor != null && (i.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = t.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = u.nestingFactor), u.gravity != null && (i.DEFAULT_GRAVITY_STRENGTH = t.DEFAULT_GRAVITY_STRENGTH = u.gravity), u.numIter != null && (i.MAX_ITERATIONS = t.MAX_ITERATIONS = u.numIter), u.gravityRange != null && (i.DEFAULT_GRAVITY_RANGE_FACTOR = t.DEFAULT_GRAVITY_RANGE_FACTOR = u.gravityRange), u.gravityCompound != null && (i.DEFAULT_COMPOUND_GRAVITY_STRENGTH = t.DEFAULT_COMPOUND_GRAVITY_STRENGTH = u.gravityCompound), u.gravityRangeCompound != null && (i.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = t.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = u.gravityRangeCompound), u.initialEnergyOnIncremental != null && (i.DEFAULT_COOLING_FACTOR_INCREMENTAL = t.DEFAULT_COOLING_FACTOR_INCREMENTAL = u.initialEnergyOnIncremental), u.quality == "draft" ? e.QUALITY = 0 : u.quality == "proof" ? e.QUALITY = 2 : e.QUALITY = 1, i.NODE_DIMENSIONS_INCLUDE_LABELS = t.NODE_DIMENSIONS_INCLUDE_LABELS = e.NODE_DIMENSIONS_INCLUDE_LABELS = u.nodeDimensionsIncludeLabels, i.DEFAULT_INCREMENTAL = t.DEFAULT_INCREMENTAL = e.DEFAULT_INCREMENTAL = !u.randomize, i.ANIMATE = t.ANIMATE = e.ANIMATE = u.animate, i.TILE = u.tile, i.TILING_PADDING_VERTICAL = typeof u.tilingPaddingVertical == "function" ? u.tilingPaddingVertical.call() : u.tilingPaddingVertical, i.TILING_PADDING_HORIZONTAL = typeof u.tilingPaddingHorizontal == "function" ? u.tilingPaddingHorizontal.call() : u.tilingPaddingHorizontal;
            };
            a.prototype.run = function() {
              var D, u, T = this.options;
              this.idToLNode = {};
              var y = this.layout = new l(), O = this;
              O.stopped = !1, this.cy = this.options.cy, this.cy.trigger({ type: "layoutstart", layout: this });
              var s = y.newGraphManager();
              this.gm = s;
              var f = this.options.eles.nodes(), c = this.options.eles.edges();
              this.root = s.addRoot(), this.processChildrenList(this.root, this.getTopMostNodes(f), y);
              for (var E = 0; E < c.length; E++) {
                var A = c[E], m = this.idToLNode[A.data("source")], C = this.idToLNode[A.data("target")];
                if (m !== C && m.getEdgesBetween(C).length == 0) {
                  var R = s.add(y.newEdge(), m, C);
                  R.id = A.id();
                }
              }
              var M = function(w, x) {
                typeof w == "number" && (w = x);
                var F = w.data("id"), U = O.idToLNode[F];
                return {
                  x: U.getRect().getCenterX(),
                  y: U.getRect().getCenterY()
                };
              }, S = function Y() {
                for (var w = function() {
                  T.fit && T.cy.fit(T.eles, T.padding), D || (D = !0, O.cy.one("layoutready", T.ready), O.cy.trigger({ type: "layoutready", layout: O }));
                }, x = O.options.refresh, F, U = 0; U < x && !F; U++)
                  F = O.stopped || O.layout.tick();
                if (F) {
                  y.checkLayoutSuccess() && !y.isSubLayout && y.doPostLayout(), y.tilingPostLayout && y.tilingPostLayout(), y.isLayoutFinished = !0, O.options.eles.nodes().positions(M), w(), O.cy.one("layoutstop", O.options.stop), O.cy.trigger({ type: "layoutstop", layout: O }), u && cancelAnimationFrame(u), D = !1;
                  return;
                }
                var P = O.layout.getPositionsData();
                T.eles.nodes().positions(function(_, X) {
                  if (typeof _ == "number" && (_ = X), !_.isParent()) {
                    for (var H = _.id(), W = P[H], B = _; W == null && (W = P[B.data("parent")] || P["DummyCompound_" + B.data("parent")], P[H] = W, B = B.parent()[0], B != null); )
                      ;
                    return W != null ? {
                      x: W.x,
                      y: W.y
                    } : {
                      x: _.position("x"),
                      y: _.position("y")
                    };
                  }
                }), w(), u = requestAnimationFrame(Y);
              };
              return y.addListener("layoutstarted", function() {
                O.options.animate === "during" && (u = requestAnimationFrame(S));
              }), y.runLayout(), this.options.animate !== "during" && (O.options.eles.nodes().not(":parent").layoutPositions(O, O.options, M), D = !1), this;
            }, a.prototype.getTopMostNodes = function(D) {
              for (var u = {}, T = 0; T < D.length; T++)
                u[D[T].id()] = !0;
              var y = D.filter(function(O, s) {
                typeof O == "number" && (O = s);
                for (var f = O.parent()[0]; f != null; ) {
                  if (u[f.id()])
                    return !1;
                  f = f.parent()[0];
                }
                return !0;
              });
              return y;
            }, a.prototype.processChildrenList = function(D, u, T) {
              for (var y = u.length, O = 0; O < y; O++) {
                var s = u[O], f = s.children(), c, E = s.layoutDimensions({
                  nodeDimensionsIncludeLabels: this.options.nodeDimensionsIncludeLabels
                });
                if (s.outerWidth() != null && s.outerHeight() != null ? c = D.add(new g(T.graphManager, new n(s.position("x") - E.w / 2, s.position("y") - E.h / 2), new d(parseFloat(E.w), parseFloat(E.h)))) : c = D.add(new g(this.graphManager)), c.id = s.data("id"), c.paddingLeft = parseInt(s.css("padding")), c.paddingTop = parseInt(s.css("padding")), c.paddingRight = parseInt(s.css("padding")), c.paddingBottom = parseInt(s.css("padding")), this.options.nodeDimensionsIncludeLabels && s.isParent()) {
                  var A = s.boundingBox({ includeLabels: !0, includeNodes: !1 }).w, m = s.boundingBox({ includeLabels: !0, includeNodes: !1 }).h, C = s.css("text-halign");
                  c.labelWidth = A, c.labelHeight = m, c.labelPos = C;
                }
                if (this.idToLNode[s.data("id")] = c, isNaN(c.rect.x) && (c.rect.x = 0), isNaN(c.rect.y) && (c.rect.y = 0), f != null && f.length > 0) {
                  var R;
                  R = T.getGraphManager().add(T.newGraph(), c), this.processChildrenList(R, f, T);
                }
              }
            }, a.prototype.stop = function() {
              return this.stopped = !0, this;
            };
            var v = function(u) {
              u("layout", "cose-bilkent", a);
            };
            typeof cytoscape < "u" && v(cytoscape), I.exports = v;
          })
          /******/
        ])
      );
    });
  })(k)), k.exports;
}
var yt = vt();
const Et = /* @__PURE__ */ gt(yt);
tt.use(Et);
function et(G, b) {
  G.forEach((N) => {
    const I = {
      id: N.id,
      labelText: N.label,
      height: N.height,
      width: N.width,
      padding: N.padding ?? 0
    };
    Object.keys(N).forEach((L) => {
      ["id", "label", "height", "width", "padding", "x", "y"].includes(L) || (I[L] = N[L]);
    }), b.add({
      group: "nodes",
      data: I,
      position: {
        x: N.x ?? 0,
        y: N.y ?? 0
      }
    });
  });
}
V(et, "addNodes");
function rt(G, b) {
  G.forEach((N) => {
    const I = {
      id: N.id,
      source: N.start,
      target: N.end
    };
    Object.keys(N).forEach((L) => {
      ["id", "start", "end"].includes(L) || (I[L] = N[L]);
    }), b.add({
      group: "edges",
      data: I
    });
  });
}
V(rt, "addEdges");
function it(G) {
  return new Promise((b) => {
    const N = lt("body").append("div").attr("id", "cy").attr("style", "display:none"), I = tt({
      container: document.getElementById("cy"),
      // container to render in
      style: [
        {
          selector: "edge",
          style: {
            "curve-style": "bezier"
          }
        }
      ]
    });
    N.remove(), et(G.nodes, I), rt(G.edges, I), I.nodes().forEach(function(o) {
      o.layoutDimensions = () => {
        const e = o.data();
        return { w: e.width, h: e.height };
      };
    });
    const L = {
      name: "cose-bilkent",
      // @ts-ignore Types for cose-bilkent are not correct?
      quality: "proof",
      styleEnabled: !1,
      animate: !1
    };
    I.layout(L).run(), I.ready((o) => {
      $.info("Cytoscape ready", o), b(I);
    });
  });
}
V(it, "createCytoscapeInstance");
function nt(G) {
  return G.nodes().map((b) => {
    const N = b.data(), I = b.position(), L = {
      id: N.id,
      x: I.x,
      y: I.y
    };
    return Object.keys(N).forEach((o) => {
      o !== "id" && (L[o] = N[o]);
    }), L;
  });
}
V(nt, "extractPositionedNodes");
function ot(G) {
  return G.edges().map((b) => {
    const N = b.data(), I = b._private.rscratch, L = {
      id: N.id,
      source: N.source,
      target: N.target,
      startX: I.startX,
      startY: I.startY,
      midX: I.midX,
      midY: I.midY,
      endX: I.endX,
      endY: I.endY
    };
    return Object.keys(N).forEach((o) => {
      ["id", "source", "target"].includes(o) || (L[o] = N[o]);
    }), L;
  });
}
V(ot, "extractPositionedEdges");
async function st(G, b) {
  $.debug("Starting cose-bilkent layout algorithm");
  try {
    at(G);
    const N = await it(G), I = nt(N), L = ot(N);
    return $.debug(`Layout completed: ${I.length} nodes, ${L.length} edges`), {
      nodes: I,
      edges: L
    };
  } catch (N) {
    throw $.error("Error in cose-bilkent layout algorithm:", N), N;
  }
}
V(st, "executeCoseBilkentLayout");
function at(G) {
  if (!G)
    throw new Error("Layout data is required");
  if (!G.config)
    throw new Error("Configuration is required in layout data");
  if (!G.rootNode)
    throw new Error("Root node is required");
  if (!G.nodes || !Array.isArray(G.nodes))
    throw new Error("No nodes found in layout data");
  if (!Array.isArray(G.edges))
    throw new Error("Edges array is required in layout data");
  return !0;
}
V(at, "validateLayoutData");
var Lt = /* @__PURE__ */ V(async (G, b, {
  insertCluster: N,
  insertEdge: I,
  insertEdgeLabel: L,
  insertMarkers: o,
  insertNode: e,
  log: t,
  positionEdgeLabel: i
}, { algorithm: l }) => {
  const g = {}, n = {}, d = b.select("g");
  o(d, G.markers, G.type, G.diagramId);
  const r = d.insert("g").attr("class", "subgraphs"), h = d.insert("g").attr("class", "edgePaths"), a = d.insert("g").attr("class", "edgeLabels"), p = d.insert("g").attr("class", "nodes");
  t.debug("Inserting nodes into DOM for dimension calculation"), await Promise.all(
    G.nodes.map(async (u) => {
      if (u.isGroup) {
        const T = { ...u };
        n[u.id] = T, g[u.id] = T, await N(r, u);
      } else {
        const T = { ...u };
        g[u.id] = T;
        const y = await e(p, u, {
          config: G.config,
          dir: G.direction || "TB"
        }), O = y.node().getBBox();
        T.width = O.width, T.height = O.height, T.domId = y, t.debug(`Node ${u.id} dimensions: ${O.width}x${O.height}`);
      }
    })
  ), t.debug("Running cose-bilkent layout algorithm");
  const v = {
    ...G,
    nodes: G.nodes.map((u) => {
      const T = g[u.id];
      return {
        ...u,
        width: T.width,
        height: T.height
      };
    })
  }, D = await st(v, G.config);
  t.debug("Positioning nodes based on layout results"), D.nodes.forEach((u) => {
    const T = g[u.id];
    T?.domId && (T.domId.attr(
      "transform",
      `translate(${u.x}, ${u.y})`
    ), T.x = u.x, T.y = u.y, t.debug(`Positioned node ${T.id} at center (${u.x}, ${u.y})`));
  }), D.edges.forEach((u) => {
    const T = G.edges.find((y) => y.id === u.id);
    T && (T.points = [
      { x: u.startX, y: u.startY },
      { x: u.midX, y: u.midY },
      { x: u.endX, y: u.endY }
    ]);
  }), t.debug("Inserting and positioning edges"), await Promise.all(
    G.edges.map(async (u) => {
      await L(a, u);
      const T = g[u.start ?? ""], y = g[u.end ?? ""];
      if (T && y) {
        const O = D.edges.find((s) => s.id === u.id);
        if (O) {
          t.debug("APA01 positionedEdge", O);
          const s = { ...u }, f = I(
            h,
            s,
            n,
            G.type,
            T,
            y,
            G.diagramId
          );
          i(s, f);
        } else {
          const s = {
            ...u,
            points: [
              { x: T.x || 0, y: T.y || 0 },
              { x: y.x || 0, y: y.y || 0 }
            ]
          }, f = I(
            h,
            s,
            n,
            G.type,
            T,
            y,
            G.diagramId
          );
          i(s, f);
        }
      }
    })
  ), t.debug("Cose-bilkent rendering completed");
}, "render"), Nt = Lt;
export {
  Nt as render
};
