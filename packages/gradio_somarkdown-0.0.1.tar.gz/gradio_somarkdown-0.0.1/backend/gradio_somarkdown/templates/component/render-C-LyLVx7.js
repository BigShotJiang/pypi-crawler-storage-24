var Wt = Array.isArray, Xt = Array.prototype.indexOf, _e = Array.prototype.includes, Zt = Array.from, Jt = Object.defineProperty, ye = Object.getOwnPropertyDescriptor, Qt = Object.getOwnPropertyDescriptors, en = Object.prototype, tn = Array.prototype, _t = Object.getPrototypeOf, nt = Object.isExtensible;
function er(e) {
  return typeof e == "function";
}
const nn = () => {
};
function tr(e) {
  return e();
}
function rn(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function ht() {
  var e, t, n = new Promise((r, s) => {
    e = r, t = s;
  });
  return { promise: n, resolve: e, reject: t };
}
const b = 2, he = 4, Se = 8, Ge = 1 << 24, Z = 16, B = 32, se = 64, Le = 128, P = 512, E = 1024, A = 2048, F = 4096, j = 8192, V = 16384, fe = 32768, rt = 1 << 25, be = 65536, st = 1 << 17, sn = 1 << 18, ve = 1 << 19, dt = 1 << 20, nr = 1 << 25, ie = 65536, je = 1 << 21, $e = 1 << 22, K = 1 << 23, te = /* @__PURE__ */ Symbol("$state"), rr = /* @__PURE__ */ Symbol("legacy props"), sr = /* @__PURE__ */ Symbol(""), U = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}(), lr = (
  // We gotta write it like this because after downleveling the pure comment may end up in the wrong location
  !!globalThis.document?.contentType && /* @__PURE__ */ globalThis.document.contentType.includes("xml")
);
function ln() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function ar(e, t, n) {
  throw new Error("https://svelte.dev/e/each_key_duplicate");
}
function an(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function fn() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function un(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function on() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function fr(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function cn() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function _n() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function hn() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function dn() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
const ur = 1, or = 2, cr = 16, _r = 1, hr = 2, dr = 4, vr = 8, pr = 16, gr = 1, wr = 2, T = /* @__PURE__ */ Symbol(), vn = "http://www.w3.org/1999/xhtml", yr = "http://www.w3.org/2000/svg", Er = "http://www.w3.org/1998/Math/MathML", mr = "@attach";
function br() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value");
}
function pn() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function vt(e) {
  return e === this.v;
}
function gn(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function pt(e) {
  return !gn(e, this.v);
}
let Ce = !1;
function Tr() {
  Ce = !0;
}
let m = null;
function de(e) {
  m = e;
}
function wn(e, t = !1, n) {
  m = {
    p: m,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    r: (
      /** @type {Effect} */
      p
    ),
    l: Ce && !t ? { s: null, u: null, $: [] } : null
  };
}
function yn(e) {
  var t = (
    /** @type {ComponentContext} */
    m
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      Ft(r);
  }
  return t.i = !0, m = t.p, /** @type {T} */
  {};
}
function Ae() {
  return !Ce || m !== null && m.l === null;
}
let Q = [];
function gt() {
  var e = Q;
  Q = [], rn(e);
}
function ne(e) {
  if (Q.length === 0 && !Ee) {
    var t = Q;
    queueMicrotask(() => {
      t === Q && gt();
    });
  }
  Q.push(e);
}
function En() {
  for (; Q.length > 0; )
    gt();
}
function wt(e) {
  var t = p;
  if (t === null)
    return d.f |= K, e;
  if ((t.f & fe) === 0 && (t.f & he) === 0)
    throw e;
  $(e, t);
}
function $(e, t) {
  for (; t !== null; ) {
    if ((t.f & Le) !== 0) {
      if ((t.f & fe) === 0)
        throw e;
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    }
    t = t.parent;
  }
  throw e;
}
const mn = -7169;
function y(e, t) {
  e.f = e.f & mn | t;
}
function ze(e) {
  (e.f & P) !== 0 || e.deps === null ? y(e, E) : y(e, F);
}
function yt(e) {
  if (e !== null)
    for (const t of e)
      (t.f & b) === 0 || (t.f & ie) === 0 || (t.f ^= ie, yt(
        /** @type {Derived} */
        t.deps
      ));
}
function Et(e, t, n) {
  (e.f & A) !== 0 ? t.add(e) : (e.f & F) !== 0 && n.add(e), yt(e.deps), y(e, E);
}
const oe = /* @__PURE__ */ new Set();
let w = null, I = null, Ve = null, Ee = !1, Fe = !1, ce = null, Re = null;
var it = 0;
let bn = 1;
class X {
  // for debugging. TODO remove once async is stable
  id = bn++;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<(batch: Batch) => void>}
   */
  #s = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #d = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #l = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #a = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #r = null;
  /**
   * The root effects that need to be flushed
   * @type {Effect[]}
   */
  #e = [];
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * A map of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`.
   * The value contains child effects that were dirty/maybe_dirty before being reset,
   * so they can be rescheduled if the branch survives.
   * @type {Map<Effect, { d: Effect[], m: Effect[] }>}
   */
  #i = /* @__PURE__ */ new Map();
  is_fork = !1;
  #f = !1;
  #u() {
    return this.is_fork || this.#a > 0;
  }
  /**
   * Add an effect to the #skipped_branches map and reset its children
   * @param {Effect} effect
   */
  skip_effect(t) {
    this.#i.has(t) || this.#i.set(t, { d: [], m: [] });
  }
  /**
   * Remove an effect from the #skipped_branches map and reschedule
   * any tracked dirty/maybe_dirty child effects
   * @param {Effect} effect
   */
  unskip_effect(t) {
    var n = this.#i.get(t);
    if (n) {
      this.#i.delete(t);
      for (var r of n.d)
        y(r, A), this.schedule(r);
      for (r of n.m)
        y(r, F), this.schedule(r);
    }
  }
  #c() {
    if (it++ > 1e3 && (oe.delete(this), Sn()), !this.#u()) {
      for (const a of this.#t)
        this.#n.delete(a), y(a, A), this.schedule(a);
      for (const a of this.#n)
        y(a, F), this.schedule(a);
    }
    const t = this.#e;
    this.#e = [], this.apply();
    var n = ce = [], r = [], s = Re = [];
    for (const a of t)
      try {
        this.#_(a, n, r);
      } catch (l) {
        throw St(a), l;
      }
    if (w = null, s.length > 0) {
      var i = X.ensure();
      for (const a of s)
        i.schedule(a);
    }
    if (ce = null, Re = null, this.#u()) {
      this.#h(r), this.#h(n);
      for (const [a, l] of this.#i)
        Tt(a, l);
    } else {
      this.#l === 0 && oe.delete(this), this.#t.clear(), this.#n.clear();
      for (const a of this.#s) a(this);
      this.#s.clear(), lt(r), lt(n), this.#r?.resolve();
    }
    var u = (
      /** @type {Batch | null} */
      /** @type {unknown} */
      w
    );
    if (this.#e.length > 0) {
      const a = u ??= this;
      a.#e.push(...this.#e.filter((l) => !a.#e.includes(l)));
    }
    u !== null && (oe.add(u), u.#c()), oe.has(this) || this.#o();
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #_(t, n, r) {
    t.f ^= E;
    for (var s = t.first; s !== null; ) {
      var i = s.f, u = (i & (B | se)) !== 0, a = u && (i & E) !== 0, l = a || (i & j) !== 0 || this.#i.has(s);
      if (!l && s.fn !== null) {
        u ? s.f ^= E : (i & he) !== 0 ? n.push(s) : pe(s) && ((i & Z) !== 0 && this.#n.add(s), ae(s));
        var f = s.first;
        if (f !== null) {
          s = f;
          continue;
        }
      }
      for (; s !== null; ) {
        var o = s.next;
        if (o !== null) {
          s = o;
          break;
        }
        s = s.parent;
      }
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #h(t) {
    for (var n = 0; n < t.length; n += 1)
      Et(t[n], this.#t, this.#n);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} old_value
   */
  capture(t, n) {
    n !== T && !this.previous.has(t) && this.previous.set(t, n), (t.f & K) === 0 && (this.current.set(t, t.v), I?.set(t, t.v));
  }
  activate() {
    w = this;
  }
  deactivate() {
    w = null, I = null;
  }
  flush() {
    try {
      Fe = !0, w = this, this.#c();
    } finally {
      it = 0, Ve = null, ce = null, Re = null, Fe = !1, w = null, I = null, W.clear();
    }
  }
  discard() {
    for (const t of this.#d) t(this);
    this.#d.clear();
  }
  #o() {
    for (const l of oe) {
      var t = l.id < this.id, n = [];
      for (const [f, o] of this.current) {
        if (l.current.has(f))
          if (t && o !== l.current.get(f))
            l.current.set(f, o);
          else
            continue;
        n.push(f);
      }
      if (n.length !== 0) {
        var r = [...l.current.keys()].filter((f) => !this.current.has(f));
        if (r.length > 0) {
          l.activate();
          var s = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map();
          for (var u of n)
            mt(u, r, s, i);
          if (l.#e.length > 0) {
            l.apply();
            for (var a of l.#e)
              l.#_(a, [], []);
            l.#e = [];
          }
          l.deactivate();
        }
      }
    }
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#l += 1, t && (this.#a += 1);
  }
  /**
   * @param {boolean} blocking
   * @param {boolean} skip - whether to skip updates (because this is triggered by a stale reaction)
   */
  decrement(t, n) {
    this.#l -= 1, t && (this.#a -= 1), !(this.#f || n) && (this.#f = !0, ne(() => {
      this.#f = !1, this.flush();
    }));
  }
  /**
   * @param {Set<Effect>} dirty_effects
   * @param {Set<Effect>} maybe_dirty_effects
   */
  transfer_effects(t, n) {
    for (const r of t)
      this.#t.add(r);
    for (const r of n)
      this.#n.add(r);
    t.clear(), n.clear();
  }
  /** @param {(batch: Batch) => void} fn */
  oncommit(t) {
    this.#s.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#d.add(t);
  }
  settled() {
    return (this.#r ??= ht()).promise;
  }
  static ensure() {
    if (w === null) {
      const t = w = new X();
      Fe || (oe.add(w), Ee || ne(() => {
        w === t && t.flush();
      }));
    }
    return w;
  }
  apply() {
    {
      I = null;
      return;
    }
  }
  /**
   *
   * @param {Effect} effect
   */
  schedule(t) {
    if (Ve = t, t.b?.is_pending && (t.f & (he | Se | Ge)) !== 0 && (t.f & fe) === 0) {
      t.b.defer_effect(t);
      return;
    }
    for (var n = t; n.parent !== null; ) {
      n = n.parent;
      var r = n.f;
      if (ce !== null && n === p && (d === null || (d.f & b) === 0))
        return;
      if ((r & (se | B)) !== 0) {
        if ((r & E) === 0)
          return;
        n.f ^= E;
      }
    }
    this.#e.push(n);
  }
}
function Tn(e) {
  var t = Ee;
  Ee = !0;
  try {
    for (var n; ; ) {
      if (En(), w === null)
        return (
          /** @type {T} */
          n
        );
      w.flush();
    }
  } finally {
    Ee = t;
  }
}
function Sn() {
  try {
    on();
  } catch (e) {
    $(e, Ve);
  }
}
let Y = null;
function lt(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & (V | j)) === 0 && pe(r) && (Y = /* @__PURE__ */ new Set(), ae(r), r.deps === null && r.first === null && r.nodes === null && r.teardown === null && r.ac === null && jt(r), Y?.size > 0)) {
        W.clear();
        for (const s of Y) {
          if ((s.f & (V | j)) !== 0) continue;
          const i = [s];
          let u = s.parent;
          for (; u !== null; )
            Y.has(u) && (Y.delete(u), i.push(u)), u = u.parent;
          for (let a = i.length - 1; a >= 0; a--) {
            const l = i[a];
            (l.f & (V | j)) === 0 && ae(l);
          }
        }
        Y.clear();
      }
    }
    Y = null;
  }
}
function mt(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const s of e.reactions) {
      const i = s.f;
      (i & b) !== 0 ? mt(
        /** @type {Derived} */
        s,
        t,
        n,
        r
      ) : (i & ($e | Z)) !== 0 && (i & A) === 0 && bt(s, t, r) && (y(s, A), Ke(
        /** @type {Effect} */
        s
      ));
    }
}
function bt(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const s of e.deps) {
      if (_e.call(t, s))
        return !0;
      if ((s.f & b) !== 0 && bt(
        /** @type {Derived} */
        s,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          s,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function Ke(e) {
  w.schedule(e);
}
function Tt(e, t) {
  if (!((e.f & B) !== 0 && (e.f & E) !== 0)) {
    (e.f & A) !== 0 ? t.d.push(e) : (e.f & F) !== 0 && t.m.push(e), y(e, E);
    for (var n = e.first; n !== null; )
      Tt(n, t), n = n.next;
  }
}
function St(e) {
  y(e, E);
  for (var t = e.first; t !== null; )
    St(t), t = t.next;
}
function An(e) {
  let t = 0, n = xe(0), r;
  return () => {
    Je() && (z(n), Qe(() => (t === 0 && (r = tt(() => e(() => me(n)))), t += 1, () => {
      ne(() => {
        t -= 1, t === 0 && (r?.(), r = void 0, me(n));
      });
    })));
  };
}
var xn = be | ve;
function kn(e, t, n, r) {
  new Rn(e, t, n, r);
}
class Rn {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /**
   * API-level transformError transform function. Transforms errors before they reach the `failed` snippet.
   * Inherited from parent boundary, or defaults to identity.
   * @type {(error: unknown) => unknown}
   */
  transform_error;
  /** @type {TemplateNode} */
  #s;
  /** @type {TemplateNode | null} */
  #d = null;
  /** @type {BoundaryProps} */
  #l;
  /** @type {((anchor: Node) => void)} */
  #a;
  /** @type {Effect} */
  #r;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #t = null;
  /** @type {Effect | null} */
  #n = null;
  /** @type {DocumentFragment | null} */
  #i = null;
  #f = 0;
  #u = 0;
  #c = !1;
  /** @type {Set<Effect>} */
  #_ = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #h = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #o = null;
  #y = An(() => (this.#o = xe(this.#f), () => {
    this.#o = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   * @param {((error: unknown) => unknown) | undefined} [transform_error]
   */
  constructor(t, n, r, s) {
    this.#s = t, this.#l = n, this.#a = (i) => {
      var u = (
        /** @type {Effect} */
        p
      );
      u.b = this, u.f |= Le, r(i);
    }, this.parent = /** @type {Effect} */
    p.b, this.transform_error = s ?? this.parent?.transform_error ?? ((i) => i), this.#r = Yn(() => {
      this.#g();
    }, xn);
  }
  #E() {
    try {
      this.#e = J(() => this.#a(this.#s));
    } catch (t) {
      this.error(t);
    }
  }
  /**
   * @param {unknown} error The deserialized error from the server's hydration comment
   */
  #m(t) {
    const n = this.#l.failed;
    n && (this.#n = J(() => {
      n(
        this.#s,
        () => t,
        () => () => {
        }
      );
    }));
  }
  #b() {
    const t = this.#l.pending;
    t && (this.is_pending = !0, this.#t = J(() => t(this.#s)), ne(() => {
      var n = this.#i = document.createDocumentFragment(), r = Nt();
      n.append(r), this.#e = this.#p(() => J(() => this.#a(r))), this.#u === 0 && (this.#s.before(n), this.#i = null, Pe(
        /** @type {Effect} */
        this.#t,
        () => {
          this.#t = null;
        }
      ), this.#v(
        /** @type {Batch} */
        w
      ));
    }));
  }
  #g() {
    try {
      if (this.is_pending = this.has_pending_snippet(), this.#u = 0, this.#f = 0, this.#e = J(() => {
        this.#a(this.#s);
      }), this.#u > 0) {
        var t = this.#i = document.createDocumentFragment();
        Gn(this.#e, t);
        const n = (
          /** @type {(anchor: Node) => void} */
          this.#l.pending
        );
        this.#t = J(() => n(this.#s));
      } else
        this.#v(
          /** @type {Batch} */
          w
        );
    } catch (n) {
      this.error(n);
    }
  }
  /**
   * @param {Batch} batch
   */
  #v(t) {
    this.is_pending = !1, t.transfer_effects(this.#_, this.#h);
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    Et(t, this.#_, this.#h);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#l.pending;
  }
  /**
   * @template T
   * @param {() => T} fn
   */
  #p(t) {
    var n = p, r = d, s = m;
    N(this.#r), O(this.#r), de(this.#r.ctx);
    try {
      return X.ensure(), t();
    } catch (i) {
      return wt(i), null;
    } finally {
      N(n), O(r), de(s);
    }
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  #w(t, n) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#w(t, n);
      return;
    }
    this.#u += t, this.#u === 0 && (this.#v(n), this.#t && Pe(this.#t, () => {
      this.#t = null;
    }), this.#i && (this.#s.before(this.#i), this.#i = null));
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   * @param {Batch} batch
   */
  update_pending_count(t, n) {
    this.#w(t, n), this.#f += t, !(!this.#o || this.#c) && (this.#c = !0, ne(() => {
      this.#c = !1, this.#o && Ne(this.#o, this.#f);
    }));
  }
  get_effect_pending() {
    return this.#y(), z(
      /** @type {Source<number>} */
      this.#o
    );
  }
  /** @param {unknown} error */
  error(t) {
    var n = this.#l.onerror;
    let r = this.#l.failed;
    if (!n && !r)
      throw t;
    this.#e && (q(this.#e), this.#e = null), this.#t && (q(this.#t), this.#t = null), this.#n && (q(this.#n), this.#n = null);
    var s = !1, i = !1;
    const u = () => {
      if (s) {
        pn();
        return;
      }
      s = !0, i && dn(), this.#n !== null && Pe(this.#n, () => {
        this.#n = null;
      }), this.#p(() => {
        this.#g();
      });
    }, a = (l) => {
      try {
        i = !0, n?.(l, u), i = !1;
      } catch (f) {
        $(f, this.#r && this.#r.parent);
      }
      r && (this.#n = this.#p(() => {
        try {
          return J(() => {
            var f = (
              /** @type {Effect} */
              p
            );
            f.b = this, f.f |= Le, r(
              this.#s,
              () => l,
              () => u
            );
          });
        } catch (f) {
          return $(
            f,
            /** @type {Effect} */
            this.#r.parent
          ), null;
        }
      }));
    };
    ne(() => {
      var l;
      try {
        l = this.transform_error(t);
      } catch (f) {
        $(f, this.#r && this.#r.parent);
        return;
      }
      l !== null && typeof l == "object" && typeof /** @type {any} */
      l.then == "function" ? l.then(
        a,
        /** @param {unknown} e */
        (f) => $(f, this.#r && this.#r.parent)
      ) : a(l);
    });
  }
}
function Pn(e, t, n, r) {
  const s = Ae() ? We : Nn;
  var i = e.filter((c) => !c.settled);
  if (n.length === 0 && i.length === 0) {
    r(t.map(s));
    return;
  }
  var u = (
    /** @type {Effect} */
    p
  ), a = Mn(), l = i.length === 1 ? i[0].promise : i.length > 1 ? Promise.all(i.map((c) => c.promise)) : null;
  function f(c) {
    a();
    try {
      r(c);
    } catch (v) {
      (u.f & V) === 0 && $(v, u);
    }
    Oe();
  }
  if (n.length === 0) {
    l.then(() => f(t.map(s)));
    return;
  }
  var o = At();
  function _() {
    Promise.all(n.map((c) => /* @__PURE__ */ On(c))).then((c) => f([...t.map(s), ...c])).catch((c) => $(c, u)).finally(() => o());
  }
  l ? l.then(() => {
    a(), _(), Oe();
  }) : _();
}
function Mn() {
  var e = (
    /** @type {Effect} */
    p
  ), t = d, n = m, r = (
    /** @type {Batch} */
    w
  );
  return function(i = !0) {
    N(e), O(t), de(n), i && (e.f & V) === 0 && (r?.activate(), r?.apply());
  };
}
function Oe(e = !0) {
  N(null), O(null), de(null), e && w?.deactivate();
}
function At() {
  var e = (
    /** @type {Boundary} */
    /** @type {Effect} */
    p.b
  ), t = (
    /** @type {Batch} */
    w
  ), n = e.is_rendered();
  return e.update_pending_count(1, t), t.increment(n), (r = !1) => {
    e.update_pending_count(-1, t), t.decrement(n, r);
  };
}
// @__NO_SIDE_EFFECTS__
function We(e) {
  var t = b | A, n = d !== null && (d.f & b) !== 0 ? (
    /** @type {Derived} */
    d
  ) : null;
  return p !== null && (p.f |= ve), {
    ctx: m,
    deps: null,
    effects: null,
    equals: vt,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      T
    ),
    wv: 0,
    parent: n ?? p,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function On(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    p
  );
  r === null && ln();
  var s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), i = xe(
    /** @type {V} */
    T
  ), u = !d, a = /* @__PURE__ */ new Map();
  return Bn(() => {
    var l = (
      /** @type {Effect} */
      p
    ), f = ht();
    s = f.promise;
    try {
      Promise.resolve(e()).then(f.resolve, f.reject).finally(Oe);
    } catch (v) {
      f.reject(v), Oe();
    }
    var o = (
      /** @type {Batch} */
      w
    );
    if (u) {
      if ((l.f & fe) !== 0)
        var _ = At();
      if (
        /** @type {Boundary} */
        r.b.is_rendered()
      )
        a.get(o)?.reject(U), a.delete(o);
      else {
        for (const v of a.values())
          v.reject(U);
        a.clear();
      }
      a.set(o, f);
    }
    const c = (v, h = void 0) => {
      if (_) {
        var g = h === U;
        _(g);
      }
      if (!(h === U || (l.f & V) !== 0)) {
        if (o.activate(), h)
          i.f |= K, Ne(i, h);
        else {
          (i.f & K) !== 0 && (i.f ^= K), Ne(i, v);
          for (const [S, C] of a) {
            if (a.delete(S), S === o) break;
            C.reject(U);
          }
        }
        o.deactivate();
      }
    };
    f.promise.then(c, (v) => c(null, v || "unknown"));
  }), Dt(() => {
    for (const l of a.values())
      l.reject(U);
  }), new Promise((l) => {
    function f(o) {
      function _() {
        o === s ? l(i) : f(s);
      }
      o.then(_, _);
    }
    f(s);
  });
}
// @__NO_SIDE_EFFECTS__
function Sr(e) {
  const t = /* @__PURE__ */ We(e);
  return Bt(t), t;
}
// @__NO_SIDE_EFFECTS__
function Nn(e) {
  const t = /* @__PURE__ */ We(e);
  return t.equals = pt, t;
}
function Cn(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      q(
        /** @type {Effect} */
        t[n]
      );
  }
}
function In(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & b) === 0)
      return (t.f & V) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function Xe(e) {
  var t, n = p;
  N(In(e));
  try {
    e.f &= ~ie, Cn(e), t = Gt(e);
  } finally {
    N(n);
  }
  return t;
}
function xt(e) {
  var t = e.v, n = Xe(e);
  if (!e.equals(n) && (e.wv = Ut(), (!w?.is_fork || e.deps === null) && (e.v = n, w?.capture(e, t), e.deps === null))) {
    y(e, E);
    return;
  }
  le || (I !== null ? (Je() || w?.is_fork) && I.set(e, n) : ze(e));
}
function Dn(e) {
  if (e.effects !== null)
    for (const t of e.effects)
      (t.teardown || t.ac) && (t.teardown?.(), t.ac?.abort(U), t.teardown = nn, t.ac = null, Te(t, 0), et(t));
}
function kt(e) {
  if (e.effects !== null)
    for (const t of e.effects)
      t.teardown && ae(t);
}
let qe = /* @__PURE__ */ new Set();
const W = /* @__PURE__ */ new Map();
let Rt = !1;
function xe(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: vt,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function H(e, t) {
  const n = xe(e);
  return Bt(n), n;
}
// @__NO_SIDE_EFFECTS__
function Ar(e, t = !1, n = !0) {
  const r = xe(e);
  return t || (r.equals = pt), Ce && n && m !== null && m.l !== null && (m.l.s ??= []).push(r), r;
}
function xr(e, t) {
  return G(
    e,
    tt(() => z(e))
  ), t;
}
function G(e, t, n = !1) {
  d !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!D || (d.f & st) !== 0) && Ae() && (d.f & (b | Z | $e | st)) !== 0 && (M === null || !_e.call(M, e)) && hn();
  let r = n ? ge(t) : t;
  return Ne(e, r, Re);
}
function Ne(e, t, n = null) {
  if (!e.equals(t)) {
    var r = e.v;
    le ? W.set(e, t) : W.set(e, r), e.v = t;
    var s = X.ensure();
    if (s.capture(e, r), (e.f & b) !== 0) {
      const i = (
        /** @type {Derived} */
        e
      );
      (e.f & A) !== 0 && Xe(i), I === null && ze(i);
    }
    e.wv = Ut(), Pt(e, A, n), Ae() && p !== null && (p.f & E) !== 0 && (p.f & (B | se)) === 0 && (R === null ? $n([e]) : R.push(e)), !s.is_fork && qe.size > 0 && !Rt && Fn();
  }
  return t;
}
function Fn() {
  Rt = !1;
  for (const e of qe)
    (e.f & E) !== 0 && y(e, F), pe(e) && ae(e);
  qe.clear();
}
function me(e) {
  G(e, e.v + 1);
}
function Pt(e, t, n) {
  var r = e.reactions;
  if (r !== null)
    for (var s = Ae(), i = r.length, u = 0; u < i; u++) {
      var a = r[u], l = a.f;
      if (!(!s && a === p)) {
        var f = (l & A) === 0;
        if (f && y(a, t), (l & b) !== 0) {
          var o = (
            /** @type {Derived} */
            a
          );
          I?.delete(o), (l & ie) === 0 && (l & P && (a.f |= ie), Pt(o, F, n));
        } else if (f) {
          var _ = (
            /** @type {Effect} */
            a
          );
          (l & Z) !== 0 && Y !== null && Y.add(_), n !== null ? n.push(_) : Ke(_);
        }
      }
    }
}
function ge(e) {
  if (typeof e != "object" || e === null || te in e)
    return e;
  const t = _t(e);
  if (t !== en && t !== tn)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Wt(e), s = /* @__PURE__ */ H(0), i = re, u = (a) => {
    if (re === i)
      return a();
    var l = d, f = re;
    O(null), ot(i);
    var o = a();
    return O(l), ot(f), o;
  };
  return r && n.set("length", /* @__PURE__ */ H(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(a, l, f) {
        (!("value" in f) || f.configurable === !1 || f.enumerable === !1 || f.writable === !1) && cn();
        var o = n.get(l);
        return o === void 0 ? u(() => {
          var _ = /* @__PURE__ */ H(f.value);
          return n.set(l, _), _;
        }) : G(o, f.value, !0), !0;
      },
      deleteProperty(a, l) {
        var f = n.get(l);
        if (f === void 0) {
          if (l in a) {
            const o = u(() => /* @__PURE__ */ H(T));
            n.set(l, o), me(s);
          }
        } else
          G(f, T), me(s);
        return !0;
      },
      get(a, l, f) {
        if (l === te)
          return e;
        var o = n.get(l), _ = l in a;
        if (o === void 0 && (!_ || ye(a, l)?.writable) && (o = u(() => {
          var v = ge(_ ? a[l] : T), h = /* @__PURE__ */ H(v);
          return h;
        }), n.set(l, o)), o !== void 0) {
          var c = z(o);
          return c === T ? void 0 : c;
        }
        return Reflect.get(a, l, f);
      },
      getOwnPropertyDescriptor(a, l) {
        var f = Reflect.getOwnPropertyDescriptor(a, l);
        if (f && "value" in f) {
          var o = n.get(l);
          o && (f.value = z(o));
        } else if (f === void 0) {
          var _ = n.get(l), c = _?.v;
          if (_ !== void 0 && c !== T)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return f;
      },
      has(a, l) {
        if (l === te)
          return !0;
        var f = n.get(l), o = f !== void 0 && f.v !== T || Reflect.has(a, l);
        if (f !== void 0 || p !== null && (!o || ye(a, l)?.writable)) {
          f === void 0 && (f = u(() => {
            var c = o ? ge(a[l]) : T, v = /* @__PURE__ */ H(c);
            return v;
          }), n.set(l, f));
          var _ = z(f);
          if (_ === T)
            return !1;
        }
        return o;
      },
      set(a, l, f, o) {
        var _ = n.get(l), c = l in a;
        if (r && l === "length")
          for (var v = f; v < /** @type {Source<number>} */
          _.v; v += 1) {
            var h = n.get(v + "");
            h !== void 0 ? G(h, T) : v in a && (h = u(() => /* @__PURE__ */ H(T)), n.set(v + "", h));
          }
        if (_ === void 0)
          (!c || ye(a, l)?.writable) && (_ = u(() => /* @__PURE__ */ H(void 0)), G(_, ge(f)), n.set(l, _));
        else {
          c = _.v !== T;
          var g = u(() => ge(f));
          G(_, g);
        }
        var S = Reflect.getOwnPropertyDescriptor(a, l);
        if (S?.set && S.set.call(o, f), !c) {
          if (r && typeof l == "string") {
            var C = (
              /** @type {Source<number>} */
              n.get("length")
            ), ue = Number(l);
            Number.isInteger(ue) && ue >= C.v && G(C, ue + 1);
          }
          me(s);
        }
        return !0;
      },
      ownKeys(a) {
        z(s);
        var l = Reflect.ownKeys(a).filter((_) => {
          var c = n.get(_);
          return c === void 0 || c.v !== T;
        });
        for (var [f, o] of n)
          o.v !== T && !(f in a) && l.push(f);
        return l;
      },
      setPrototypeOf() {
        _n();
      }
    }
  );
}
function at(e) {
  try {
    if (e !== null && typeof e == "object" && te in e)
      return e[te];
  } catch {
  }
  return e;
}
function kr(e, t) {
  return Object.is(at(e), at(t));
}
var ft, Ln, Mt, Ot;
function jn() {
  if (ft === void 0) {
    ft = window, Ln = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    Mt = ye(t, "firstChild").get, Ot = ye(t, "nextSibling").get, nt(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), nt(n) && (n.__t = void 0);
  }
}
function Nt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function Ct(e) {
  return (
    /** @type {TemplateNode | null} */
    Mt.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function Ie(e) {
  return (
    /** @type {TemplateNode | null} */
    Ot.call(e)
  );
}
function Rr(e, t) {
  return /* @__PURE__ */ Ct(e);
}
function Pr(e, t = !1) {
  {
    var n = /* @__PURE__ */ Ct(e);
    return n instanceof Comment && n.data === "" ? /* @__PURE__ */ Ie(n) : n;
  }
}
function Mr(e, t = 1, n = !1) {
  let r = e;
  for (; t--; )
    r = /** @type {TemplateNode} */
    /* @__PURE__ */ Ie(r);
  return r;
}
function Or(e) {
  e.textContent = "";
}
function Nr() {
  return !1;
}
function Cr(e, t, n) {
  return (
    /** @type {T extends keyof HTMLElementTagNameMap ? HTMLElementTagNameMap[T] : Element} */
    document.createElementNS(t ?? vn, e, void 0)
  );
}
function Ze(e) {
  var t = d, n = p;
  O(null), N(null);
  try {
    return e();
  } finally {
    O(t), N(n);
  }
}
function It(e) {
  p === null && (d === null && un(), fn()), le && an();
}
function Vn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function L(e, t) {
  var n = p;
  n !== null && (n.f & j) !== 0 && (e |= j);
  var r = {
    ctx: m,
    deps: null,
    nodes: null,
    f: e | A | P,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: n,
    b: n && n.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  }, s = r;
  if ((e & he) !== 0)
    ce !== null ? ce.push(r) : X.ensure().schedule(r);
  else if (t !== null) {
    try {
      ae(r);
    } catch (u) {
      throw q(r), u;
    }
    s.deps === null && s.teardown === null && s.nodes === null && s.first === s.last && // either `null`, or a singular child
    (s.f & ve) === 0 && (s = s.first, (e & Z) !== 0 && (e & be) !== 0 && s !== null && (s.f |= be));
  }
  if (s !== null && (s.parent = n, n !== null && Vn(s, n), d !== null && (d.f & b) !== 0 && (e & se) === 0)) {
    var i = (
      /** @type {Derived} */
      d
    );
    (i.effects ??= []).push(s);
  }
  return r;
}
function Je() {
  return d !== null && !D;
}
function Dt(e) {
  const t = L(Se, null);
  return y(t, E), t.teardown = e, t;
}
function Ir(e) {
  It();
  var t = (
    /** @type {Effect} */
    p.f
  ), n = !d && (t & B) !== 0 && (t & fe) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      m
    );
    (r.e ??= []).push(e);
  } else
    return Ft(e);
}
function Ft(e) {
  return L(he | dt, e);
}
function Dr(e) {
  return It(), L(Se | dt, e);
}
function qn(e) {
  X.ensure();
  const t = L(se | ve, e);
  return (n = {}) => new Promise((r) => {
    n.outro ? Pe(t, () => {
      q(t), r(void 0);
    }) : (q(t), r(void 0));
  });
}
function Fr(e) {
  return L(he, e);
}
function Lr(e, t) {
  var n = (
    /** @type {ComponentContextLegacy} */
    m
  ), r = { effect: null, ran: !1, deps: e };
  n.l.$.push(r), r.effect = Qe(() => {
    if (e(), !r.ran) {
      r.ran = !0;
      var s = (
        /** @type {Effect} */
        p
      );
      try {
        N(s.parent), tt(t);
      } finally {
        N(s);
      }
    }
  });
}
function jr() {
  var e = (
    /** @type {ComponentContextLegacy} */
    m
  );
  Qe(() => {
    for (var t of e.l.$) {
      t.deps();
      var n = t.effect;
      (n.f & E) !== 0 && n.deps !== null && y(n, F), pe(n) && ae(n), t.ran = !1;
    }
  });
}
function Bn(e) {
  return L($e | ve, e);
}
function Qe(e, t = 0) {
  return L(Se | t, e);
}
function Vr(e, t = [], n = [], r = []) {
  Pn(r, t, n, (s) => {
    L(Se, () => e(...s.map(z)));
  });
}
function Yn(e, t = 0) {
  var n = L(Z | t, e);
  return n;
}
function qr(e, t = 0) {
  var n = L(Ge | t, e);
  return n;
}
function J(e) {
  return L(B | ve, e);
}
function Lt(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = le, r = d;
    ut(!0), O(null);
    try {
      t.call(null);
    } finally {
      ut(n), O(r);
    }
  }
}
function et(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const s = n.ac;
    s !== null && Ze(() => {
      s.abort(U);
    });
    var r = n.next;
    (n.f & se) !== 0 ? n.parent = null : q(n, t), n = r;
  }
}
function Un(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & B) === 0 && q(t), t = n;
  }
}
function q(e, t = !0) {
  var n = !1;
  (t || (e.f & sn) !== 0) && e.nodes !== null && e.nodes.end !== null && (Hn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), y(e, rt), et(e, t && !n), Te(e, 0);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const i of r)
      i.stop();
  Lt(e), e.f ^= rt, e.f |= V;
  var s = e.parent;
  s !== null && s.first !== null && jt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function Hn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ Ie(e);
    e.remove(), e = n;
  }
}
function jt(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function Pe(e, t, n = !0) {
  var r = [];
  Vt(e, r, !0);
  var s = () => {
    n && q(e), t && t();
  }, i = r.length;
  if (i > 0) {
    var u = () => --i || s();
    for (var a of r)
      a.out(u);
  } else
    s();
}
function Vt(e, t, n) {
  if ((e.f & j) === 0) {
    e.f ^= j;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const a of r)
        (a.is_global || n) && t.push(a);
    for (var s = e.first; s !== null; ) {
      var i = s.next, u = (s.f & be) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (s.f & B) !== 0 && (e.f & Z) !== 0;
      Vt(s, t, u ? n : !1), s = i;
    }
  }
}
function Br(e) {
  qt(e, !0);
}
function qt(e, t) {
  if ((e.f & j) !== 0) {
    e.f ^= j, (e.f & E) === 0 && (y(e, A), X.ensure().schedule(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next, s = (n.f & be) !== 0 || (n.f & B) !== 0;
      qt(n, s ? t : !1), n = r;
    }
    var i = e.nodes && e.nodes.t;
    if (i !== null)
      for (const u of i)
        (u.is_global || t) && u.in();
  }
}
function Gn(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var s = n === r ? null : /* @__PURE__ */ Ie(n);
      t.append(n), n = s;
    }
}
let Me = !1, le = !1;
function ut(e) {
  le = e;
}
let d = null, D = !1;
function O(e) {
  d = e;
}
let p = null;
function N(e) {
  p = e;
}
let M = null;
function Bt(e) {
  d !== null && (M === null ? M = [e] : M.push(e));
}
let x = null, k = 0, R = null;
function $n(e) {
  R = e;
}
let Yt = 1, ee = 0, re = ee;
function ot(e) {
  re = e;
}
function Ut() {
  return ++Yt;
}
function pe(e) {
  var t = e.f;
  if ((t & A) !== 0)
    return !0;
  if (t & b && (e.f &= ~ie), (t & F) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, s = 0; s < r; s++) {
      var i = n[s];
      if (pe(
        /** @type {Derived} */
        i
      ) && xt(
        /** @type {Derived} */
        i
      ), i.wv > e.wv)
        return !0;
    }
    (t & P) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    I === null && y(e, E);
  }
  return !1;
}
function Ht(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !(M !== null && _e.call(M, e)))
    for (var s = 0; s < r.length; s++) {
      var i = r[s];
      (i.f & b) !== 0 ? Ht(
        /** @type {Derived} */
        i,
        t,
        !1
      ) : t === i && (n ? y(i, A) : (i.f & E) !== 0 && y(i, F), Ke(
        /** @type {Effect} */
        i
      ));
    }
}
function Gt(e) {
  var t = x, n = k, r = R, s = d, i = M, u = m, a = D, l = re, f = e.f;
  x = /** @type {null | Value[]} */
  null, k = 0, R = null, d = (f & (B | se)) === 0 ? e : null, M = null, de(e.ctx), D = !1, re = ++ee, e.ac !== null && (Ze(() => {
    e.ac.abort(U);
  }), e.ac = null);
  try {
    e.f |= je;
    var o = (
      /** @type {Function} */
      e.fn
    ), _ = o();
    e.f |= fe;
    var c = e.deps, v = w?.is_fork;
    if (x !== null) {
      var h;
      if (v || Te(e, k), c !== null && k > 0)
        for (c.length = k + x.length, h = 0; h < x.length; h++)
          c[k + h] = x[h];
      else
        e.deps = c = x;
      if (Je() && (e.f & P) !== 0)
        for (h = k; h < c.length; h++)
          (c[h].reactions ??= []).push(e);
    } else !v && c !== null && k < c.length && (Te(e, k), c.length = k);
    if (Ae() && R !== null && !D && c !== null && (e.f & (b | F | A)) === 0)
      for (h = 0; h < /** @type {Source[]} */
      R.length; h++)
        Ht(
          R[h],
          /** @type {Effect} */
          e
        );
    if (s !== null && s !== e) {
      if (ee++, s.deps !== null)
        for (let g = 0; g < n; g += 1)
          s.deps[g].rv = ee;
      if (t !== null)
        for (const g of t)
          g.rv = ee;
      R !== null && (r === null ? r = R : r.push(.../** @type {Source[]} */
      R));
    }
    return (e.f & K) !== 0 && (e.f ^= K), _;
  } catch (g) {
    return wt(g);
  } finally {
    e.f ^= je, x = t, k = n, R = r, d = s, M = i, de(u), D = a, re = l;
  }
}
function zn(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = Xt.call(n, e);
    if (r !== -1) {
      var s = n.length - 1;
      s === 0 ? n = t.reactions = null : (n[r] = n[s], n.pop());
    }
  }
  if (n === null && (t.f & b) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (x === null || !_e.call(x, t))) {
    var i = (
      /** @type {Derived} */
      t
    );
    (i.f & P) !== 0 && (i.f ^= P, i.f &= ~ie), ze(i), Dn(i), Te(i, 0);
  }
}
function Te(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      zn(e, n[r]);
}
function ae(e) {
  var t = e.f;
  if ((t & V) === 0) {
    y(e, E);
    var n = p, r = Me;
    p = e, Me = !0;
    try {
      (t & (Z | Ge)) !== 0 ? Un(e) : et(e), Lt(e);
      var s = Gt(e);
      e.teardown = typeof s == "function" ? s : null, e.wv = Yt;
      var i;
    } finally {
      Me = r, p = n;
    }
  }
}
async function Yr() {
  await Promise.resolve(), Tn();
}
function z(e) {
  var t = e.f, n = (t & b) !== 0;
  if (d !== null && !D) {
    var r = p !== null && (p.f & V) !== 0;
    if (!r && (M === null || !_e.call(M, e))) {
      var s = d.deps;
      if ((d.f & je) !== 0)
        e.rv < ee && (e.rv = ee, x === null && s !== null && s[k] === e ? k++ : x === null ? x = [e] : x.push(e));
      else {
        (d.deps ??= []).push(e);
        var i = e.reactions;
        i === null ? e.reactions = [d] : _e.call(i, d) || i.push(d);
      }
    }
  }
  if (le && W.has(e))
    return W.get(e);
  if (n) {
    var u = (
      /** @type {Derived} */
      e
    );
    if (le) {
      var a = u.v;
      return ((u.f & E) === 0 && u.reactions !== null || zt(u)) && (a = Xe(u)), W.set(u, a), a;
    }
    var l = (u.f & P) === 0 && !D && d !== null && (Me || (d.f & P) !== 0), f = (u.f & fe) === 0;
    pe(u) && (l && (u.f |= P), xt(u)), l && !f && (kt(u), $t(u));
  }
  if (I?.has(e))
    return I.get(e);
  if ((e.f & K) !== 0)
    throw e.v;
  return e.v;
}
function $t(e) {
  if (e.f |= P, e.deps !== null)
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & b) !== 0 && (t.f & P) === 0 && (kt(
        /** @type {Derived} */
        t
      ), $t(
        /** @type {Derived} */
        t
      ));
}
function zt(e) {
  if (e.v === T) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (W.has(t) || (t.f & b) !== 0 && zt(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function tt(e) {
  var t = D;
  try {
    return D = !0, e();
  } finally {
    D = t;
  }
}
function Ur(e) {
  if (!(typeof e != "object" || !e || e instanceof EventTarget)) {
    if (te in e)
      Be(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        const n = e[t];
        typeof n == "object" && n && te in n && Be(n);
      }
  }
}
function Be(e, t = /* @__PURE__ */ new Set()) {
  if (typeof e == "object" && e !== null && // We don't want to traverse DOM elements
  !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let r in e)
      try {
        Be(e[r], t);
      } catch {
      }
    const n = _t(e);
    if (n !== Object.prototype && n !== Array.prototype && n !== Map.prototype && n !== Set.prototype && n !== Date.prototype) {
      const r = Qt(n);
      for (let s in r) {
        const i = r[s].get;
        if (i)
          try {
            i.call(e);
          } catch {
          }
      }
    }
  }
}
function Hr(e) {
  return e.endsWith("capture") && e !== "gotpointercapture" && e !== "lostpointercapture";
}
const Kn = [
  "beforeinput",
  "click",
  "change",
  "dblclick",
  "contextmenu",
  "focusin",
  "focusout",
  "input",
  "keydown",
  "keyup",
  "mousedown",
  "mousemove",
  "mouseout",
  "mouseover",
  "mouseup",
  "pointerdown",
  "pointermove",
  "pointerout",
  "pointerover",
  "pointerup",
  "touchend",
  "touchmove",
  "touchstart"
];
function Gr(e) {
  return Kn.includes(e);
}
const Wn = {
  // no `class: 'className'` because we handle that separately
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};
function $r(e) {
  return e = e.toLowerCase(), Wn[e] ?? e;
}
const Xn = ["touchstart", "touchmove"];
function Zn(e) {
  return Xn.includes(e);
}
const we = /* @__PURE__ */ Symbol("events"), Kt = /* @__PURE__ */ new Set(), Ye = /* @__PURE__ */ new Set();
function Jn(e, t, n, r = {}) {
  function s(i) {
    if (r.capture || Ue.call(t, i), !i.cancelBubble)
      return Ze(() => n?.call(this, i));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? ne(() => {
    t.addEventListener(e, s, r);
  }) : t.addEventListener(e, s, r), s;
}
function zr(e, t, n, r, s) {
  var i = { capture: r, passive: s }, u = Jn(e, t, n, i);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && Dt(() => {
    t.removeEventListener(e, u, i);
  });
}
function Kr(e, t, n) {
  (t[we] ??= {})[e] = n;
}
function Wr(e) {
  for (var t = 0; t < e.length; t++)
    Kt.add(e[t]);
  for (var n of Ye)
    n(e);
}
let ct = null;
function Ue(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), r = e.type, s = e.composedPath?.() || [], i = (
    /** @type {null | Element} */
    s[0] || e.target
  );
  ct = e;
  var u = 0, a = ct === e && e[we];
  if (a) {
    var l = s.indexOf(a);
    if (l !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e[we] = t;
      return;
    }
    var f = s.indexOf(t);
    if (f === -1)
      return;
    l <= f && (u = l);
  }
  if (i = /** @type {Element} */
  s[u] || e.target, i !== t) {
    Jt(e, "currentTarget", {
      configurable: !0,
      get() {
        return i || n;
      }
    });
    var o = d, _ = p;
    O(null), N(null);
    try {
      for (var c, v = []; i !== null; ) {
        var h = i.assignedSlot || i.parentNode || /** @type {any} */
        i.host || null;
        try {
          var g = i[we]?.[r];
          g != null && (!/** @type {any} */
          i.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === i) && g.call(i, e);
        } catch (S) {
          c ? v.push(S) : c = S;
        }
        if (e.cancelBubble || h === t || h === null)
          break;
        i = h;
      }
      if (c) {
        for (let S of v)
          queueMicrotask(() => {
            throw S;
          });
        throw c;
      }
    } finally {
      e[we] = t, delete e.currentTarget, O(o), N(_);
    }
  }
}
function Xr(e, t) {
  var n = t == null ? "" : typeof t == "object" ? `${t}` : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = `${n}`);
}
function Zr(e, t) {
  return Qn(e, t);
}
const ke = /* @__PURE__ */ new Map();
function Qn(e, { target: t, anchor: n, props: r = {}, events: s, context: i, intro: u = !0, transformError: a }) {
  jn();
  var l = void 0, f = qn(() => {
    var o = n ?? t.appendChild(Nt());
    kn(
      /** @type {TemplateNode} */
      o,
      {
        pending: () => {
        }
      },
      (v) => {
        wn({});
        var h = (
          /** @type {ComponentContext} */
          m
        );
        i && (h.c = i), s && (r.$$events = s), l = e(v, r) || {}, yn();
      },
      a
    );
    var _ = /* @__PURE__ */ new Set(), c = (v) => {
      for (var h = 0; h < v.length; h++) {
        var g = v[h];
        if (!_.has(g)) {
          _.add(g);
          var S = Zn(g);
          for (const De of [t, document]) {
            var C = ke.get(De);
            C === void 0 && (C = /* @__PURE__ */ new Map(), ke.set(De, C));
            var ue = C.get(g);
            ue === void 0 ? (De.addEventListener(g, Ue, { passive: S }), C.set(g, 1)) : C.set(g, ue + 1);
          }
        }
      }
    };
    return c(Zt(Kt)), Ye.add(c), () => {
      for (var v of _)
        for (const S of [t, document]) {
          var h = (
            /** @type {Map<string, number>} */
            ke.get(S)
          ), g = (
            /** @type {number} */
            h.get(v)
          );
          --g == 0 ? (S.removeEventListener(v, Ue), h.delete(v), h.size === 0 && ke.delete(S)) : h.set(v, g);
        }
      Ye.delete(c), o !== n && o.parentNode?.removeChild(o);
    };
  });
  return He.set(l, f), l;
}
let He = /* @__PURE__ */ new WeakMap();
function Jr(e, t) {
  const n = He.get(e);
  return n ? (He.delete(e), n(t)) : Promise.resolve();
}
export {
  sr as $,
  Gn as A,
  Nr as B,
  Yn as C,
  Ne as D,
  be as E,
  ar as F,
  Nn as G,
  Zt as H,
  or as I,
  xe as J,
  ur as K,
  cr as L,
  nr as M,
  V as N,
  j as O,
  B as P,
  Or as Q,
  Ie as R,
  Vr as S,
  gr as T,
  Hn as U,
  yr as V,
  Er as W,
  qr as X,
  Fr as Y,
  br as Z,
  kr as _,
  tt as a,
  vn as a0,
  Qt as a1,
  Pn as a2,
  mr as a3,
  lr as a4,
  Hr as a5,
  Kr as a6,
  Wr as a7,
  Jn as a8,
  $r as a9,
  Mr as aA,
  Rr as aB,
  Tr as aC,
  Lr as aD,
  jr as aE,
  Pr as aF,
  zr as aG,
  xr as aH,
  Sr as aI,
  Yr as aJ,
  Xr as aK,
  T as aa,
  Gr as ab,
  m as ac,
  Qe as ad,
  rt as ae,
  te as af,
  Dr as ag,
  Ir as ah,
  tr as ai,
  Ur as aj,
  We as ak,
  ye as al,
  fr as am,
  dr as an,
  ge as ao,
  vr as ap,
  Ce as aq,
  hr as ar,
  _r as as,
  pr as at,
  le as au,
  rr as av,
  er as aw,
  H as ax,
  yn as ay,
  wn as az,
  Ar as b,
  G as c,
  z as d,
  Jt as e,
  Cr as f,
  _t as g,
  Nt as h,
  Wt as i,
  Ct as j,
  Ln as k,
  p as l,
  Zr as m,
  nn as n,
  en as o,
  wr as p,
  ne as q,
  rn as r,
  gn as s,
  Dt as t,
  Jr as u,
  Br as v,
  q as w,
  Pe as x,
  J as y,
  w as z
};
