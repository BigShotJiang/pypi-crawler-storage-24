import u from "./katex-DRSa1quw.js";
var E = function(a, r, e) {
  for (var t = e, d = 0, l = a.length; t < r.length; ) {
    var n = r[t];
    if (d <= 0 && r.slice(t, t + l) === a)
      return t;
    n === "\\" ? t++ : n === "{" ? d++ : n === "}" && d--, t++;
  }
  return -1;
}, N = function(a) {
  return a.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
}, b = /^\\begin{/, w = function(a, r) {
  for (var e, t = [], d = new RegExp("(" + r.map((s) => N(s.left)).join("|") + ")"); e = a.search(d), e !== -1; ) {
    e > 0 && (t.push({
      type: "text",
      data: a.slice(0, e)
    }), a = a.slice(e));
    var l = r.findIndex((s) => a.startsWith(s.left));
    if (e = E(r[l].right, a, r[l].left.length), e === -1)
      break;
    var n = a.slice(0, e + r[l].right.length), i = b.test(n) ? n : a.slice(r[l].left.length, e);
    t.push({
      type: "math",
      data: i,
      rawData: n,
      display: r[l].display
    }), a = a.slice(e + r[l].right.length);
  }
  return a !== "" && t.push({
    type: "text",
    data: a
  }), t;
}, x = function(a, r) {
  var e = w(a, r.delimiters);
  if (e.length === 1 && e[0].type === "text")
    return null;
  for (var t = document.createDocumentFragment(), d = 0; d < e.length; d++)
    if (e[d].type === "text")
      t.appendChild(document.createTextNode(e[d].data));
    else {
      var l = document.createElement("span"), n = e[d].data;
      r.displayMode = e[d].display;
      try {
        r.preProcess && (n = r.preProcess(n)), u.render(n, l, r);
      } catch (i) {
        if (!(i instanceof u.ParseError))
          throw i;
        r.errorCallback("KaTeX auto-render: Failed to parse `" + e[d].data + "` with ", i), t.appendChild(document.createTextNode(e[d].rawData));
        continue;
      }
      t.appendChild(l);
    }
  return t;
}, p = function(a, r) {
  for (var e = function(l) {
    var n = a.childNodes[l];
    if (n.nodeType === 3) {
      for (var i, s = (i = n.textContent) != null ? i : "", h = n.nextSibling, g = 0; h && h.nodeType === Node.TEXT_NODE; ) {
        var o;
        s += (o = h.textContent) != null ? o : "", h = h.nextSibling, g++;
      }
      var c = x(s, r);
      if (c) {
        for (var v = 0; v < g; v++)
          n.nextSibling.remove();
        l += c.childNodes.length - 1, a.replaceChild(c, n);
      } else
        l += g;
    } else if (n.nodeType === 1) {
      var m = " " + n.className + " ", y = !r.ignoredTags.has(n.nodeName.toLowerCase()) && r.ignoredClasses.every((T) => !m.includes(" " + T + " "));
      y && p(n, r);
    }
    t = l;
  }, t = 0; t < a.childNodes.length; t++)
    e(t);
}, k = function(a, r) {
  if (!a)
    throw new Error("No element provided to render");
  var e = {};
  Object.assign(e, r), e.delimiters = e.delimiters || [
    {
      left: "$$",
      right: "$$",
      display: !0
    },
    {
      left: "\\(",
      right: "\\)",
      display: !1
    },
    // LaTeX uses $…$, but it ruins the display of normal `$` in text:
    // {left: "$", right: "$", display: false},
    // $ must come after $$
    // Render AMS environments even if outside $$…$$ delimiters.
    {
      left: "\\begin{equation}",
      right: "\\end{equation}",
      display: !0
    },
    {
      left: "\\begin{align}",
      right: "\\end{align}",
      display: !0
    },
    {
      left: "\\begin{alignat}",
      right: "\\end{alignat}",
      display: !0
    },
    {
      left: "\\begin{gather}",
      right: "\\end{gather}",
      display: !0
    },
    {
      left: "\\begin{CD}",
      right: "\\end{CD}",
      display: !0
    },
    {
      left: "\\[",
      right: "\\]",
      display: !0
    }
  ], e.ignoredTags = new Set(r?.ignoredTags || ["script", "noscript", "style", "textarea", "pre", "code", "option"]), e.ignoredClasses = e.ignoredClasses || [], e.errorCallback = e.errorCallback || console.error, e.macros = e.macros || {}, p(a, e);
};
export {
  k as default
};
