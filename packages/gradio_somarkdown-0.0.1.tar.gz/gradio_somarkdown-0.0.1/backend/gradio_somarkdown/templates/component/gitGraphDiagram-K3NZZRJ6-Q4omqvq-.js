import { p as Y } from "./chunk-4BX2VUAB-B7CTz11g.js";
import { I as K } from "./chunk-QZHKN3VN-C3mxR18K.js";
import { q as U, p as V, s as X, g as J, a as Q, b as Z, _ as l, l as b, d as rr, u as er, D as tr, z as ar, k as v, E as sr, F as nr, G as or, H as cr } from "./mermaid.core-DfOz2mRZ.js";
import { p as ir } from "./treemap-KZPCXAKY-COPF7OoG.js";
var p = {
  NORMAL: 0,
  REVERSE: 1,
  HIGHLIGHT: 2,
  MERGE: 3,
  CHERRY_PICK: 4
}, dr = nr.gitGraph, M = /* @__PURE__ */ l(() => sr({
  ...dr,
  ...or().gitGraph
}), "getConfig"), c = new K(() => {
  const t = M(), r = t.mainBranchName, a = t.mainBranchOrder;
  return {
    mainBranchName: r,
    commits: /* @__PURE__ */ new Map(),
    head: null,
    branchConfig: /* @__PURE__ */ new Map([[r, { name: r, order: a }]]),
    branches: /* @__PURE__ */ new Map([[r, null]]),
    currBranch: r,
    direction: "LR",
    seq: 0,
    options: {}
  };
});
function H() {
  return cr({ length: 7 });
}
l(H, "getID");
function D(t, r) {
  const a = /* @__PURE__ */ Object.create(null);
  return t.reduce((n, e) => {
    const s = r(e);
    return a[s] || (a[s] = !0, n.push(e)), n;
  }, []);
}
l(D, "uniqBy");
var hr = /* @__PURE__ */ l(function(t) {
  c.records.direction = t;
}, "setDirection"), lr = /* @__PURE__ */ l(function(t) {
  b.debug("options str", t), t = t?.trim(), t = t || "{}";
  try {
    c.records.options = JSON.parse(t);
  } catch (r) {
    b.error("error while parsing gitGraph options", r.message);
  }
}, "setOptions"), $r = /* @__PURE__ */ l(function() {
  return c.records.options;
}, "getOptions"), fr = /* @__PURE__ */ l(function(t) {
  let r = t.msg, a = t.id;
  const n = t.type;
  let e = t.tags;
  b.info("commit", r, a, n, e), b.debug("Entering commit:", r, a, n, e);
  const s = M();
  a = v.sanitizeText(a, s), r = v.sanitizeText(r, s), e = e?.map((d) => v.sanitizeText(d, s));
  const h = {
    id: a || c.records.seq + "-" + H(),
    message: r,
    seq: c.records.seq++,
    type: n ?? p.NORMAL,
    tags: e ?? [],
    parents: c.records.head == null ? [] : [c.records.head.id],
    branch: c.records.currBranch
  };
  c.records.head = h, b.info("main branch", s.mainBranchName), c.records.commits.has(h.id) && b.warn(`Commit ID ${h.id} already exists`), c.records.commits.set(h.id, h), c.records.branches.set(c.records.currBranch, h.id), b.debug("in pushCommit " + h.id);
}, "commit"), gr = /* @__PURE__ */ l(function(t) {
  let r = t.name;
  const a = t.order;
  if (r = v.sanitizeText(r, M()), c.records.branches.has(r))
    throw new Error(
      `Trying to create an existing branch. (Help: Either use a new name if you want create a new branch or try using "checkout ${r}")`
    );
  c.records.branches.set(r, c.records.head != null ? c.records.head.id : null), c.records.branchConfig.set(r, { name: r, order: a }), F(r), b.debug("in createBranch");
}, "branch"), yr = /* @__PURE__ */ l((t) => {
  let r = t.branch, a = t.id;
  const n = t.type, e = t.tags, s = M();
  r = v.sanitizeText(r, s), a && (a = v.sanitizeText(a, s));
  const h = c.records.branches.get(c.records.currBranch), d = c.records.branches.get(r), o = h ? c.records.commits.get(h) : void 0, $ = d ? c.records.commits.get(d) : void 0;
  if (o && $ && o.branch === r)
    throw new Error(`Cannot merge branch '${r}' into itself.`);
  if (c.records.currBranch === r) {
    const i = new Error('Incorrect usage of "merge". Cannot merge a branch to itself');
    throw i.hash = {
      text: `merge ${r}`,
      token: `merge ${r}`,
      expected: ["branch abc"]
    }, i;
  }
  if (o === void 0 || !o) {
    const i = new Error(
      `Incorrect usage of "merge". Current branch (${c.records.currBranch})has no commits`
    );
    throw i.hash = {
      text: `merge ${r}`,
      token: `merge ${r}`,
      expected: ["commit"]
    }, i;
  }
  if (!c.records.branches.has(r)) {
    const i = new Error(
      'Incorrect usage of "merge". Branch to be merged (' + r + ") does not exist"
    );
    throw i.hash = {
      text: `merge ${r}`,
      token: `merge ${r}`,
      expected: [`branch ${r}`]
    }, i;
  }
  if ($ === void 0 || !$) {
    const i = new Error(
      'Incorrect usage of "merge". Branch to be merged (' + r + ") has no commits"
    );
    throw i.hash = {
      text: `merge ${r}`,
      token: `merge ${r}`,
      expected: ['"commit"']
    }, i;
  }
  if (o === $) {
    const i = new Error('Incorrect usage of "merge". Both branches have same head');
    throw i.hash = {
      text: `merge ${r}`,
      token: `merge ${r}`,
      expected: ["branch abc"]
    }, i;
  }
  if (a && c.records.commits.has(a)) {
    const i = new Error(
      'Incorrect usage of "merge". Commit with id:' + a + " already exists, use different custom id"
    );
    throw i.hash = {
      text: `merge ${r} ${a} ${n} ${e?.join(" ")}`,
      token: `merge ${r} ${a} ${n} ${e?.join(" ")}`,
      expected: [
        `merge ${r} ${a}_UNIQUE ${n} ${e?.join(" ")}`
      ]
    }, i;
  }
  const f = d || "", y = {
    id: a || `${c.records.seq}-${H()}`,
    message: `merged branch ${r} into ${c.records.currBranch}`,
    seq: c.records.seq++,
    parents: c.records.head == null ? [] : [c.records.head.id, f],
    branch: c.records.currBranch,
    type: p.MERGE,
    customType: n,
    customId: !!a,
    tags: e ?? []
  };
  c.records.head = y, c.records.commits.set(y.id, y), c.records.branches.set(c.records.currBranch, y.id), b.debug(c.records.branches), b.debug("in mergeBranch");
}, "merge"), ur = /* @__PURE__ */ l(function(t) {
  let r = t.id, a = t.targetId, n = t.tags, e = t.parent;
  b.debug("Entering cherryPick:", r, a, n);
  const s = M();
  if (r = v.sanitizeText(r, s), a = v.sanitizeText(a, s), n = n?.map((o) => v.sanitizeText(o, s)), e = v.sanitizeText(e, s), !r || !c.records.commits.has(r)) {
    const o = new Error(
      'Incorrect usage of "cherryPick". Source commit id should exist and provided'
    );
    throw o.hash = {
      text: `cherryPick ${r} ${a}`,
      token: `cherryPick ${r} ${a}`,
      expected: ["cherry-pick abc"]
    }, o;
  }
  const h = c.records.commits.get(r);
  if (h === void 0 || !h)
    throw new Error('Incorrect usage of "cherryPick". Source commit id should exist and provided');
  if (e && !(Array.isArray(h.parents) && h.parents.includes(e)))
    throw new Error(
      "Invalid operation: The specified parent commit is not an immediate parent of the cherry-picked commit."
    );
  const d = h.branch;
  if (h.type === p.MERGE && !e)
    throw new Error(
      "Incorrect usage of cherry-pick: If the source commit is a merge commit, an immediate parent commit must be specified."
    );
  if (!a || !c.records.commits.has(a)) {
    if (d === c.records.currBranch) {
      const y = new Error(
        'Incorrect usage of "cherryPick". Source commit is already on current branch'
      );
      throw y.hash = {
        text: `cherryPick ${r} ${a}`,
        token: `cherryPick ${r} ${a}`,
        expected: ["cherry-pick abc"]
      }, y;
    }
    const o = c.records.branches.get(c.records.currBranch);
    if (o === void 0 || !o) {
      const y = new Error(
        `Incorrect usage of "cherry-pick". Current branch (${c.records.currBranch})has no commits`
      );
      throw y.hash = {
        text: `cherryPick ${r} ${a}`,
        token: `cherryPick ${r} ${a}`,
        expected: ["cherry-pick abc"]
      }, y;
    }
    const $ = c.records.commits.get(o);
    if ($ === void 0 || !$) {
      const y = new Error(
        `Incorrect usage of "cherry-pick". Current branch (${c.records.currBranch})has no commits`
      );
      throw y.hash = {
        text: `cherryPick ${r} ${a}`,
        token: `cherryPick ${r} ${a}`,
        expected: ["cherry-pick abc"]
      }, y;
    }
    const f = {
      id: c.records.seq + "-" + H(),
      message: `cherry-picked ${h?.message} into ${c.records.currBranch}`,
      seq: c.records.seq++,
      parents: c.records.head == null ? [] : [c.records.head.id, h.id],
      branch: c.records.currBranch,
      type: p.CHERRY_PICK,
      tags: n ? n.filter(Boolean) : [
        `cherry-pick:${h.id}${h.type === p.MERGE ? `|parent:${e}` : ""}`
      ]
    };
    c.records.head = f, c.records.commits.set(f.id, f), c.records.branches.set(c.records.currBranch, f.id), b.debug(c.records.branches), b.debug("in cherryPick");
  }
}, "cherryPick"), F = /* @__PURE__ */ l(function(t) {
  if (t = v.sanitizeText(t, M()), c.records.branches.has(t)) {
    c.records.currBranch = t;
    const r = c.records.branches.get(c.records.currBranch);
    r === void 0 || !r ? c.records.head = null : c.records.head = c.records.commits.get(r) ?? null;
  } else {
    const r = new Error(
      `Trying to checkout branch which is not yet created. (Help try using "branch ${t}")`
    );
    throw r.hash = {
      text: `checkout ${t}`,
      token: `checkout ${t}`,
      expected: [`branch ${t}`]
    }, r;
  }
}, "checkout");
function P(t, r, a) {
  const n = t.indexOf(r);
  n === -1 ? t.push(a) : t.splice(n, 1, a);
}
l(P, "upsert");
function _(t) {
  const r = t.reduce((e, s) => e.seq > s.seq ? e : s, t[0]);
  let a = "";
  t.forEach(function(e) {
    e === r ? a += "	*" : a += "	|";
  });
  const n = [a, r.id, r.seq];
  for (const e in c.records.branches)
    c.records.branches.get(e) === r.id && n.push(e);
  if (b.debug(n.join(" ")), r.parents && r.parents.length == 2 && r.parents[0] && r.parents[1]) {
    const e = c.records.commits.get(r.parents[0]);
    P(t, r, e), r.parents[1] && t.push(c.records.commits.get(r.parents[1]));
  } else {
    if (r.parents.length == 0)
      return;
    if (r.parents[0]) {
      const e = c.records.commits.get(r.parents[0]);
      P(t, r, e);
    }
  }
  t = D(t, (e) => e.id), _(t);
}
l(_, "prettyPrintCommitHistory");
var xr = /* @__PURE__ */ l(function() {
  b.debug(c.records.commits);
  const t = N()[0];
  _([t]);
}, "prettyPrint"), pr = /* @__PURE__ */ l(function() {
  c.reset(), ar();
}, "clear"), br = /* @__PURE__ */ l(function() {
  return [...c.records.branchConfig.values()].map((r, a) => r.order !== null && r.order !== void 0 ? r : {
    ...r,
    order: parseFloat(`0.${a}`)
  }).sort((r, a) => (r.order ?? 0) - (a.order ?? 0)).map(({ name: r }) => ({ name: r }));
}, "getBranchesAsObjArray"), mr = /* @__PURE__ */ l(function() {
  return c.records.branches;
}, "getBranches"), wr = /* @__PURE__ */ l(function() {
  return c.records.commits;
}, "getCommits"), N = /* @__PURE__ */ l(function() {
  const t = [...c.records.commits.values()];
  return t.forEach(function(r) {
    b.debug(r.id);
  }), t.sort((r, a) => r.seq - a.seq), t;
}, "getCommitsArray"), vr = /* @__PURE__ */ l(function() {
  return c.records.currBranch;
}, "getCurrentBranch"), Cr = /* @__PURE__ */ l(function() {
  return c.records.direction;
}, "getDirection"), Er = /* @__PURE__ */ l(function() {
  return c.records.head;
}, "getHead"), S = {
  commitType: p,
  getConfig: M,
  setDirection: hr,
  setOptions: lr,
  getOptions: $r,
  commit: fr,
  branch: gr,
  merge: yr,
  cherryPick: ur,
  checkout: F,
  //reset,
  prettyPrint: xr,
  clear: pr,
  getBranchesAsObjArray: br,
  getBranches: mr,
  getCommits: wr,
  getCommitsArray: N,
  getCurrentBranch: vr,
  getDirection: Cr,
  getHead: Er,
  setAccTitle: Z,
  getAccTitle: Q,
  getAccDescription: J,
  setAccDescription: X,
  setDiagramTitle: V,
  getDiagramTitle: U
}, Tr = /* @__PURE__ */ l((t, r) => {
  Y(t, r), t.dir && r.setDirection(t.dir);
  for (const a of t.statements)
    Br(a, r);
}, "populate"), Br = /* @__PURE__ */ l((t, r) => {
  const n = {
    Commit: /* @__PURE__ */ l((e) => r.commit(Lr(e)), "Commit"),
    Branch: /* @__PURE__ */ l((e) => r.branch(kr(e)), "Branch"),
    Merge: /* @__PURE__ */ l((e) => r.merge(Mr(e)), "Merge"),
    Checkout: /* @__PURE__ */ l((e) => r.checkout(Ir(e)), "Checkout"),
    CherryPicking: /* @__PURE__ */ l((e) => r.cherryPick(Rr(e)), "CherryPicking")
  }[t.$type];
  n ? n(t) : b.error(`Unknown statement type: ${t.$type}`);
}, "parseStatement"), Lr = /* @__PURE__ */ l((t) => ({
  id: t.id,
  msg: t.message ?? "",
  type: t.type !== void 0 ? p[t.type] : p.NORMAL,
  tags: t.tags ?? void 0
}), "parseCommit"), kr = /* @__PURE__ */ l((t) => ({
  name: t.name,
  order: t.order ?? 0
}), "parseBranch"), Mr = /* @__PURE__ */ l((t) => ({
  branch: t.branch,
  id: t.id ?? "",
  type: t.type !== void 0 ? p[t.type] : void 0,
  tags: t.tags ?? void 0
}), "parseMerge"), Ir = /* @__PURE__ */ l((t) => t.branch, "parseCheckout"), Rr = /* @__PURE__ */ l((t) => ({
  id: t.id,
  targetId: "",
  tags: t.tags?.length === 0 ? void 0 : t.tags,
  parent: t.parent
}), "parseCherryPicking"), Gr = {
  parse: /* @__PURE__ */ l(async (t) => {
    const r = await ir("gitGraph", t);
    b.debug(r), Tr(r, S);
  }, "parse")
}, B = 10, L = 40, C = 4, E = 2, k = 8, m = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), O = 30, I = /* @__PURE__ */ new Map(), q = [], T = 0, x = "LR", Or = /* @__PURE__ */ l(() => {
  m.clear(), w.clear(), I.clear(), T = 0, q = [], x = "LR";
}, "clear"), W = /* @__PURE__ */ l((t) => {
  const r = document.createElementNS("http://www.w3.org/2000/svg", "text");
  return (typeof t == "string" ? t.split(/\\n|\n|<br\s*\/?>/gi) : t).forEach((n) => {
    const e = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
    e.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), e.setAttribute("dy", "1em"), e.setAttribute("x", "0"), e.setAttribute("class", "row"), e.textContent = n.trim(), r.appendChild(e);
  }), r;
}, "drawText"), j = /* @__PURE__ */ l((t) => {
  let r, a, n;
  return x === "BT" ? (a = /* @__PURE__ */ l((e, s) => e <= s, "comparisonFunc"), n = 1 / 0) : (a = /* @__PURE__ */ l((e, s) => e >= s, "comparisonFunc"), n = 0), t.forEach((e) => {
    const s = x === "TB" || x == "BT" ? w.get(e)?.y : w.get(e)?.x;
    s !== void 0 && a(s, n) && (r = e, n = s);
  }), r;
}, "findClosestParent"), qr = /* @__PURE__ */ l((t) => {
  let r = "", a = 1 / 0;
  return t.forEach((n) => {
    const e = w.get(n).y;
    e <= a && (r = n, a = e);
  }), r || void 0;
}, "findClosestParentBT"), Hr = /* @__PURE__ */ l((t, r, a) => {
  let n = a, e = a;
  const s = [];
  t.forEach((h) => {
    const d = r.get(h);
    if (!d)
      throw new Error(`Commit not found for key ${h}`);
    d.parents.length ? (n = Pr(d), e = Math.max(n, e)) : s.push(d), _r(d, n);
  }), n = e, s.forEach((h) => {
    zr(h, n, a);
  }), t.forEach((h) => {
    const d = r.get(h);
    if (d?.parents.length) {
      const o = qr(d.parents);
      n = w.get(o).y - L, n <= e && (e = n);
      const $ = m.get(d.branch).pos, f = n - B;
      w.set(d.id, { x: $, y: f });
    }
  });
}, "setParallelBTPos"), Ar = /* @__PURE__ */ l((t) => {
  const r = j(t.parents.filter((n) => n !== null));
  if (!r)
    throw new Error(`Closest parent not found for commit ${t.id}`);
  const a = w.get(r)?.y;
  if (a === void 0)
    throw new Error(`Closest parent position not found for commit ${t.id}`);
  return a;
}, "findClosestParentPos"), Pr = /* @__PURE__ */ l((t) => Ar(t) + L, "calculateCommitPosition"), _r = /* @__PURE__ */ l((t, r) => {
  const a = m.get(t.branch);
  if (!a)
    throw new Error(`Branch not found for commit ${t.id}`);
  const n = a.pos, e = r + B;
  return w.set(t.id, { x: n, y: e }), { x: n, y: e };
}, "setCommitPosition"), zr = /* @__PURE__ */ l((t, r, a) => {
  const n = m.get(t.branch);
  if (!n)
    throw new Error(`Branch not found for commit ${t.id}`);
  const e = r + a, s = n.pos;
  w.set(t.id, { x: s, y: e });
}, "setRootPosition"), Dr = /* @__PURE__ */ l((t, r, a, n, e, s) => {
  if (s === p.HIGHLIGHT)
    t.append("rect").attr("x", a.x - 10).attr("y", a.y - 10).attr("width", 20).attr("height", 20).attr(
      "class",
      `commit ${r.id} commit-highlight${e % k} ${n}-outer`
    ), t.append("rect").attr("x", a.x - 6).attr("y", a.y - 6).attr("width", 12).attr("height", 12).attr(
      "class",
      `commit ${r.id} commit${e % k} ${n}-inner`
    );
  else if (s === p.CHERRY_PICK)
    t.append("circle").attr("cx", a.x).attr("cy", a.y).attr("r", 10).attr("class", `commit ${r.id} ${n}`), t.append("circle").attr("cx", a.x - 3).attr("cy", a.y + 2).attr("r", 2.75).attr("fill", "#fff").attr("class", `commit ${r.id} ${n}`), t.append("circle").attr("cx", a.x + 3).attr("cy", a.y + 2).attr("r", 2.75).attr("fill", "#fff").attr("class", `commit ${r.id} ${n}`), t.append("line").attr("x1", a.x + 3).attr("y1", a.y + 1).attr("x2", a.x).attr("y2", a.y - 5).attr("stroke", "#fff").attr("class", `commit ${r.id} ${n}`), t.append("line").attr("x1", a.x - 3).attr("y1", a.y + 1).attr("x2", a.x).attr("y2", a.y - 5).attr("stroke", "#fff").attr("class", `commit ${r.id} ${n}`);
  else {
    const h = t.append("circle");
    if (h.attr("cx", a.x), h.attr("cy", a.y), h.attr("r", r.type === p.MERGE ? 9 : 10), h.attr("class", `commit ${r.id} commit${e % k}`), s === p.MERGE) {
      const d = t.append("circle");
      d.attr("cx", a.x), d.attr("cy", a.y), d.attr("r", 6), d.attr(
        "class",
        `commit ${n} ${r.id} commit${e % k}`
      );
    }
    s === p.REVERSE && t.append("path").attr(
      "d",
      `M ${a.x - 5},${a.y - 5}L${a.x + 5},${a.y + 5}M${a.x - 5},${a.y + 5}L${a.x + 5},${a.y - 5}`
    ).attr("class", `commit ${n} ${r.id} commit${e % k}`);
  }
}, "drawCommitBullet"), Fr = /* @__PURE__ */ l((t, r, a, n, e) => {
  if (r.type !== p.CHERRY_PICK && (r.customId && r.type === p.MERGE || r.type !== p.MERGE) && e.showCommitLabel) {
    const s = t.append("g"), h = s.insert("rect").attr("class", "commit-label-bkg"), d = s.append("text").attr("x", n).attr("y", a.y + 25).attr("class", "commit-label").text(r.id), o = d.node()?.getBBox();
    if (o && (h.attr("x", a.posWithOffset - o.width / 2 - E).attr("y", a.y + 13.5).attr("width", o.width + 2 * E).attr("height", o.height + 2 * E), x === "TB" || x === "BT" ? (h.attr("x", a.x - (o.width + 4 * C + 5)).attr("y", a.y - 12), d.attr("x", a.x - (o.width + 4 * C)).attr("y", a.y + o.height - 12)) : d.attr("x", a.posWithOffset - o.width / 2), e.rotateCommitLabel))
      if (x === "TB" || x === "BT")
        d.attr(
          "transform",
          "rotate(-45, " + a.x + ", " + a.y + ")"
        ), h.attr(
          "transform",
          "rotate(-45, " + a.x + ", " + a.y + ")"
        );
      else {
        const $ = -7.5 - (o.width + 10) / 25 * 9.5, f = 10 + o.width / 25 * 8.5;
        s.attr(
          "transform",
          "translate(" + $ + ", " + f + ") rotate(-45, " + n + ", " + a.y + ")"
        );
      }
  }
}, "drawCommitLabel"), Nr = /* @__PURE__ */ l((t, r, a, n) => {
  if (r.tags.length > 0) {
    let e = 0, s = 0, h = 0;
    const d = [];
    for (const o of r.tags.reverse()) {
      const $ = t.insert("polygon"), f = t.append("circle"), y = t.append("text").attr("y", a.y - 16 - e).attr("class", "tag-label").text(o), i = y.node()?.getBBox();
      if (!i)
        throw new Error("Tag bbox not found");
      s = Math.max(s, i.width), h = Math.max(h, i.height), y.attr("x", a.posWithOffset - i.width / 2), d.push({
        tag: y,
        hole: f,
        rect: $,
        yOffset: e
      }), e += 20;
    }
    for (const { tag: o, hole: $, rect: f, yOffset: y } of d) {
      const i = h / 2, u = a.y - 19.2 - y;
      if (f.attr("class", "tag-label-bkg").attr(
        "points",
        `
      ${n - s / 2 - C / 2},${u + E}  
      ${n - s / 2 - C / 2},${u - E}
      ${a.posWithOffset - s / 2 - C},${u - i - E}
      ${a.posWithOffset + s / 2 + C},${u - i - E}
      ${a.posWithOffset + s / 2 + C},${u + i + E}
      ${a.posWithOffset - s / 2 - C},${u + i + E}`
      ), $.attr("cy", u).attr("cx", n - s / 2 + C / 2).attr("r", 1.5).attr("class", "tag-hole"), x === "TB" || x === "BT") {
        const g = n + y;
        f.attr("class", "tag-label-bkg").attr(
          "points",
          `
        ${a.x},${g + 2}
        ${a.x},${g - 2}
        ${a.x + B},${g - i - 2}
        ${a.x + B + s + 4},${g - i - 2}
        ${a.x + B + s + 4},${g + i + 2}
        ${a.x + B},${g + i + 2}`
        ).attr("transform", "translate(12,12) rotate(45, " + a.x + "," + n + ")"), $.attr("cx", a.x + C / 2).attr("cy", g).attr("transform", "translate(12,12) rotate(45, " + a.x + "," + n + ")"), o.attr("x", a.x + 5).attr("y", g + 3).attr("transform", "translate(14,14) rotate(45, " + a.x + "," + n + ")");
      }
    }
  }
}, "drawCommitTags"), Sr = /* @__PURE__ */ l((t) => {
  switch (t.customType ?? t.type) {
    case p.NORMAL:
      return "commit-normal";
    case p.REVERSE:
      return "commit-reverse";
    case p.HIGHLIGHT:
      return "commit-highlight";
    case p.MERGE:
      return "commit-merge";
    case p.CHERRY_PICK:
      return "commit-cherry-pick";
    default:
      return "commit-normal";
  }
}, "getCommitClassType"), Wr = /* @__PURE__ */ l((t, r, a, n) => {
  const e = { x: 0, y: 0 };
  if (t.parents.length > 0) {
    const s = j(t.parents);
    if (s) {
      const h = n.get(s) ?? e;
      return r === "TB" ? h.y + L : r === "BT" ? (n.get(t.id) ?? e).y - L : h.x + L;
    }
  } else
    return r === "TB" ? O : r === "BT" ? (n.get(t.id) ?? e).y - L : 0;
  return 0;
}, "calculatePosition"), jr = /* @__PURE__ */ l((t, r, a) => {
  const n = x === "BT" && a ? r : r + B, e = x === "TB" || x === "BT" ? n : m.get(t.branch)?.pos, s = x === "TB" || x === "BT" ? m.get(t.branch)?.pos : n;
  if (s === void 0 || e === void 0)
    throw new Error(`Position were undefined for commit ${t.id}`);
  return { x: s, y: e, posWithOffset: n };
}, "getCommitPosition"), z = /* @__PURE__ */ l((t, r, a, n) => {
  const e = t.append("g").attr("class", "commit-bullets"), s = t.append("g").attr("class", "commit-labels");
  let h = x === "TB" || x === "BT" ? O : 0;
  const d = [...r.keys()], o = n.parallelCommits ?? !1, $ = /* @__PURE__ */ l((y, i) => {
    const u = r.get(y)?.seq, g = r.get(i)?.seq;
    return u !== void 0 && g !== void 0 ? u - g : 0;
  }, "sortKeys");
  let f = d.sort($);
  x === "BT" && (o && Hr(f, r, h), f = f.reverse()), f.forEach((y) => {
    const i = r.get(y);
    if (!i)
      throw new Error(`Commit not found for key ${y}`);
    o && (h = Wr(i, x, h, w));
    const u = jr(i, h, o);
    if (a) {
      const g = Sr(i), G = i.customType ?? i.type, A = m.get(i.branch)?.index ?? 0;
      Dr(e, i, u, g, A, G), Fr(s, i, u, h, n), Nr(s, i, u, h);
    }
    x === "TB" || x === "BT" ? w.set(i.id, { x: u.x, y: u.posWithOffset }) : w.set(i.id, { x: u.posWithOffset, y: u.y }), h = x === "BT" && o ? h + L : h + L + B, h > T && (T = h);
  });
}, "drawCommits"), Yr = /* @__PURE__ */ l((t, r, a, n, e) => {
  const h = (x === "TB" || x === "BT" ? a.x < n.x : a.y < n.y) ? r.branch : t.branch, d = /* @__PURE__ */ l(($) => $.branch === h, "isOnBranchToGetCurve"), o = /* @__PURE__ */ l(($) => $.seq > t.seq && $.seq < r.seq, "isBetweenCommits");
  return [...e.values()].some(($) => o($) && d($));
}, "shouldRerouteArrow"), R = /* @__PURE__ */ l((t, r, a = 0) => {
  const n = t + Math.abs(t - r) / 2;
  if (a > 5)
    return n;
  if (q.every((h) => Math.abs(h - n) >= 10))
    return q.push(n), n;
  const s = Math.abs(t - r);
  return R(t, r - s / 5, a + 1);
}, "findLane"), Kr = /* @__PURE__ */ l((t, r, a, n) => {
  const e = w.get(r.id), s = w.get(a.id);
  if (e === void 0 || s === void 0)
    throw new Error(`Commit positions not found for commits ${r.id} and ${a.id}`);
  const h = Yr(r, a, e, s, n);
  let d = "", o = "", $ = 0, f = 0, y = m.get(a.branch)?.index;
  a.type === p.MERGE && r.id !== a.parents[0] && (y = m.get(r.branch)?.index);
  let i;
  if (h) {
    d = "A 10 10, 0, 0, 0,", o = "A 10 10, 0, 0, 1,", $ = 10, f = 10;
    const u = e.y < s.y ? R(e.y, s.y) : R(s.y, e.y), g = e.x < s.x ? R(e.x, s.x) : R(s.x, e.x);
    x === "TB" ? e.x < s.x ? i = `M ${e.x} ${e.y} L ${g - $} ${e.y} ${o} ${g} ${e.y + f} L ${g} ${s.y - $} ${d} ${g + f} ${s.y} L ${s.x} ${s.y}` : (y = m.get(r.branch)?.index, i = `M ${e.x} ${e.y} L ${g + $} ${e.y} ${d} ${g} ${e.y + f} L ${g} ${s.y - $} ${o} ${g - f} ${s.y} L ${s.x} ${s.y}`) : x === "BT" ? e.x < s.x ? i = `M ${e.x} ${e.y} L ${g - $} ${e.y} ${d} ${g} ${e.y - f} L ${g} ${s.y + $} ${o} ${g + f} ${s.y} L ${s.x} ${s.y}` : (y = m.get(r.branch)?.index, i = `M ${e.x} ${e.y} L ${g + $} ${e.y} ${o} ${g} ${e.y - f} L ${g} ${s.y + $} ${d} ${g - f} ${s.y} L ${s.x} ${s.y}`) : e.y < s.y ? i = `M ${e.x} ${e.y} L ${e.x} ${u - $} ${d} ${e.x + f} ${u} L ${s.x - $} ${u} ${o} ${s.x} ${u + f} L ${s.x} ${s.y}` : (y = m.get(r.branch)?.index, i = `M ${e.x} ${e.y} L ${e.x} ${u + $} ${o} ${e.x + f} ${u} L ${s.x - $} ${u} ${d} ${s.x} ${u - f} L ${s.x} ${s.y}`);
  } else
    d = "A 20 20, 0, 0, 0,", o = "A 20 20, 0, 0, 1,", $ = 20, f = 20, x === "TB" ? (e.x < s.x && (a.type === p.MERGE && r.id !== a.parents[0] ? i = `M ${e.x} ${e.y} L ${e.x} ${s.y - $} ${d} ${e.x + f} ${s.y} L ${s.x} ${s.y}` : i = `M ${e.x} ${e.y} L ${s.x - $} ${e.y} ${o} ${s.x} ${e.y + f} L ${s.x} ${s.y}`), e.x > s.x && (d = "A 20 20, 0, 0, 0,", o = "A 20 20, 0, 0, 1,", $ = 20, f = 20, a.type === p.MERGE && r.id !== a.parents[0] ? i = `M ${e.x} ${e.y} L ${e.x} ${s.y - $} ${o} ${e.x - f} ${s.y} L ${s.x} ${s.y}` : i = `M ${e.x} ${e.y} L ${s.x + $} ${e.y} ${d} ${s.x} ${e.y + f} L ${s.x} ${s.y}`), e.x === s.x && (i = `M ${e.x} ${e.y} L ${s.x} ${s.y}`)) : x === "BT" ? (e.x < s.x && (a.type === p.MERGE && r.id !== a.parents[0] ? i = `M ${e.x} ${e.y} L ${e.x} ${s.y + $} ${o} ${e.x + f} ${s.y} L ${s.x} ${s.y}` : i = `M ${e.x} ${e.y} L ${s.x - $} ${e.y} ${d} ${s.x} ${e.y - f} L ${s.x} ${s.y}`), e.x > s.x && (d = "A 20 20, 0, 0, 0,", o = "A 20 20, 0, 0, 1,", $ = 20, f = 20, a.type === p.MERGE && r.id !== a.parents[0] ? i = `M ${e.x} ${e.y} L ${e.x} ${s.y + $} ${d} ${e.x - f} ${s.y} L ${s.x} ${s.y}` : i = `M ${e.x} ${e.y} L ${s.x + $} ${e.y} ${o} ${s.x} ${e.y - f} L ${s.x} ${s.y}`), e.x === s.x && (i = `M ${e.x} ${e.y} L ${s.x} ${s.y}`)) : (e.y < s.y && (a.type === p.MERGE && r.id !== a.parents[0] ? i = `M ${e.x} ${e.y} L ${s.x - $} ${e.y} ${o} ${s.x} ${e.y + f} L ${s.x} ${s.y}` : i = `M ${e.x} ${e.y} L ${e.x} ${s.y - $} ${d} ${e.x + f} ${s.y} L ${s.x} ${s.y}`), e.y > s.y && (a.type === p.MERGE && r.id !== a.parents[0] ? i = `M ${e.x} ${e.y} L ${s.x - $} ${e.y} ${d} ${s.x} ${e.y - f} L ${s.x} ${s.y}` : i = `M ${e.x} ${e.y} L ${e.x} ${s.y + $} ${o} ${e.x + f} ${s.y} L ${s.x} ${s.y}`), e.y === s.y && (i = `M ${e.x} ${e.y} L ${s.x} ${s.y}`));
  if (i === void 0)
    throw new Error("Line definition not found");
  t.append("path").attr("d", i).attr("class", "arrow arrow" + y % k);
}, "drawArrow"), Ur = /* @__PURE__ */ l((t, r) => {
  const a = t.append("g").attr("class", "commit-arrows");
  [...r.keys()].forEach((n) => {
    const e = r.get(n);
    e.parents && e.parents.length > 0 && e.parents.forEach((s) => {
      Kr(a, r.get(s), e, r);
    });
  });
}, "drawArrows"), Vr = /* @__PURE__ */ l((t, r, a) => {
  const n = t.append("g");
  r.forEach((e, s) => {
    const h = s % k, d = m.get(e.name)?.pos;
    if (d === void 0)
      throw new Error(`Position not found for branch ${e.name}`);
    const o = n.append("line");
    o.attr("x1", 0), o.attr("y1", d), o.attr("x2", T), o.attr("y2", d), o.attr("class", "branch branch" + h), x === "TB" ? (o.attr("y1", O), o.attr("x1", d), o.attr("y2", T), o.attr("x2", d)) : x === "BT" && (o.attr("y1", T), o.attr("x1", d), o.attr("y2", O), o.attr("x2", d)), q.push(d);
    const $ = e.name, f = W($), y = n.insert("rect"), u = n.insert("g").attr("class", "branchLabel").insert("g").attr("class", "label branch-label" + h);
    u.node().appendChild(f);
    const g = f.getBBox();
    y.attr("class", "branchLabelBkg label" + h).attr("rx", 4).attr("ry", 4).attr("x", -g.width - 4 - (a.rotateCommitLabel === !0 ? 30 : 0)).attr("y", -g.height / 2 + 8).attr("width", g.width + 18).attr("height", g.height + 4), u.attr(
      "transform",
      "translate(" + (-g.width - 14 - (a.rotateCommitLabel === !0 ? 30 : 0)) + ", " + (d - g.height / 2 - 1) + ")"
    ), x === "TB" ? (y.attr("x", d - g.width / 2 - 10).attr("y", 0), u.attr("transform", "translate(" + (d - g.width / 2 - 5) + ", 0)")) : x === "BT" ? (y.attr("x", d - g.width / 2 - 10).attr("y", T), u.attr("transform", "translate(" + (d - g.width / 2 - 5) + ", " + T + ")")) : y.attr("transform", "translate(-19, " + (d - g.height / 2) + ")");
  });
}, "drawBranches"), Xr = /* @__PURE__ */ l(function(t, r, a, n, e) {
  return m.set(t, { pos: r, index: a }), r += 50 + (e ? 40 : 0) + (x === "TB" || x === "BT" ? n.width / 2 : 0), r;
}, "setBranchPosition"), Jr = /* @__PURE__ */ l(function(t, r, a, n) {
  Or(), b.debug("in gitgraph renderer", t + `
`, "id:", r, a);
  const e = n.db;
  if (!e.getConfig) {
    b.error("getConfig method is not available on db");
    return;
  }
  const s = e.getConfig(), h = s.rotateCommitLabel ?? !1;
  I = e.getCommits();
  const d = e.getBranchesAsObjArray();
  x = e.getDirection();
  const o = rr(`[id="${r}"]`);
  let $ = 0;
  d.forEach((f, y) => {
    const i = W(f.name), u = o.append("g"), g = u.insert("g").attr("class", "branchLabel"), G = g.insert("g").attr("class", "label branch-label");
    G.node()?.appendChild(i);
    const A = i.getBBox();
    $ = Xr(f.name, $, y, A, h), G.remove(), g.remove(), u.remove();
  }), z(o, I, !1, s), s.showBranches && Vr(o, d, s), Ur(o, I), z(o, I, !0, s), er.insertTitle(
    o,
    "gitTitleText",
    s.titleTopMargin ?? 0,
    e.getDiagramTitle()
  ), tr(void 0, o, s.diagramPadding, s.useMaxWidth);
}, "draw"), Qr = {
  draw: Jr
}, Zr = /* @__PURE__ */ l((t) => `
  .commit-id,
  .commit-msg,
  .branch-label {
    fill: lightgrey;
    color: lightgrey;
    font-family: 'trebuchet ms', verdana, arial, sans-serif;
    font-family: var(--mermaid-font-family);
  }
  ${[0, 1, 2, 3, 4, 5, 6, 7].map(
  (r) => `
        .branch-label${r} { fill: ${t["gitBranchLabel" + r]}; }
        .commit${r} { stroke: ${t["git" + r]}; fill: ${t["git" + r]}; }
        .commit-highlight${r} { stroke: ${t["gitInv" + r]}; fill: ${t["gitInv" + r]}; }
        .label${r}  { fill: ${t["git" + r]}; }
        .arrow${r} { stroke: ${t["git" + r]}; }
        `
).join(`
`)}

  .branch {
    stroke-width: 1;
    stroke: ${t.lineColor};
    stroke-dasharray: 2;
  }
  .commit-label { font-size: ${t.commitLabelFontSize}; fill: ${t.commitLabelColor};}
  .commit-label-bkg { font-size: ${t.commitLabelFontSize}; fill: ${t.commitLabelBackground}; opacity: 0.5; }
  .tag-label { font-size: ${t.tagLabelFontSize}; fill: ${t.tagLabelColor};}
  .tag-label-bkg { fill: ${t.tagLabelBackground}; stroke: ${t.tagLabelBorder}; }
  .tag-hole { fill: ${t.textColor}; }

  .commit-merge {
    stroke: ${t.primaryColor};
    fill: ${t.primaryColor};
  }
  .commit-reverse {
    stroke: ${t.primaryColor};
    fill: ${t.primaryColor};
    stroke-width: 3;
  }
  .commit-highlight-outer {
  }
  .commit-highlight-inner {
    stroke: ${t.primaryColor};
    fill: ${t.primaryColor};
  }

  .arrow { stroke-width: 8; stroke-linecap: round; fill: none}
  .gitTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${t.textColor};
  }
`, "getStyles"), re = Zr, ne = {
  parser: Gr,
  db: S,
  renderer: Qr,
  styles: re
};
export {
  ne as diagram
};
