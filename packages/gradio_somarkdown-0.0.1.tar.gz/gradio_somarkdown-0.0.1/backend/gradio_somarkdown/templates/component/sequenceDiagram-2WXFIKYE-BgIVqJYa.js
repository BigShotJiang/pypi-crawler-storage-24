import { _, n as je, c as et, d as kt, l as Q, j as ve, e as ts, f as es, k as S, b as Pe, s as ss, p as rs, a as as, g as is, q as ns, t as os, J as cs, z as ls, i as vt, u as q, L as U, M as Nt, N as Ce, Z as hs, O as ds, P as Me, G as Gt } from "./mermaid.core-DfOz2mRZ.js";
import { a as Ts, b as Qt, g as lt, d as Es, e as $t, f as jt } from "./chunk-JSJVCQXG-TRSEEawp.js";
import { I as ps } from "./chunk-QZHKN3VN-C3mxR18K.js";
var Xt = (function() {
  var e = /* @__PURE__ */ _(function(Tt, L, m, N) {
    for (m = m || {}, N = Tt.length; N--; m[Tt[N]] = L) ;
    return m;
  }, "o"), t = [1, 2], a = [1, 3], s = [1, 4], i = [2, 4], n = [1, 9], o = [1, 11], h = [1, 12], l = [1, 14], r = [1, 15], E = [1, 17], p = [1, 18], f = [1, 19], u = [1, 25], y = [1, 26], R = [1, 27], b = [1, 28], w = [1, 29], A = [1, 30], D = [1, 31], k = [1, 32], M = [1, 33], W = [1, 34], K = [1, 35], H = [1, 36], G = [1, 37], X = [1, 38], z = [1, 39], v = [1, 40], $ = [1, 42], J = [1, 43], j = [1, 44], st = [1, 45], rt = [1, 46], O = [1, 47], I = [1, 4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 48, 49, 50, 51, 53, 54, 56, 61, 62, 63, 64, 73], nt = [1, 74], ot = [1, 80], C = [1, 81], te = [1, 82], ee = [1, 83], se = [1, 84], re = [1, 85], ae = [1, 86], ie = [1, 87], ne = [1, 88], oe = [1, 89], ce = [1, 90], le = [1, 91], he = [1, 92], de = [1, 93], Te = [1, 94], Ee = [1, 95], pe = [1, 96], ue = [1, 97], _e = [1, 98], fe = [1, 99], ge = [1, 100], xe = [1, 101], Ie = [1, 102], Re = [1, 103], Oe = [1, 104], ye = [1, 105], Le = [2, 78], Lt = [4, 5, 17, 51, 53, 54], mt = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 51, 53, 54, 56, 61, 62, 63, 64, 73], be = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 50, 51, 53, 54, 56, 61, 62, 63, 64, 73], Wt = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 49, 51, 53, 54, 56, 61, 62, 63, 64, 73], Se = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 48, 51, 53, 54, 56, 61, 62, 63, 64, 73], Kt = [5, 52], B = [70, 71, 72, 73], at = [1, 151], Ft = {
    trace: /* @__PURE__ */ _(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, SPACE: 4, NEWLINE: 5, SD: 6, document: 7, line: 8, statement: 9, INVALID: 10, box_section: 11, box_line: 12, participant_statement: 13, create: 14, box: 15, restOfLine: 16, end: 17, signal: 18, autonumber: 19, NUM: 20, off: 21, activate: 22, actor: 23, deactivate: 24, note_statement: 25, links_statement: 26, link_statement: 27, properties_statement: 28, details_statement: 29, title: 30, legacy_title: 31, acc_title: 32, acc_title_value: 33, acc_descr: 34, acc_descr_value: 35, acc_descr_multiline_value: 36, loop: 37, rect: 38, opt: 39, alt: 40, else_sections: 41, par: 42, par_sections: 43, par_over: 44, critical: 45, option_sections: 46, break: 47, option: 48, and: 49, else: 50, participant: 51, AS: 52, participant_actor: 53, destroy: 54, actor_with_config: 55, note: 56, placement: 57, text2: 58, over: 59, actor_pair: 60, links: 61, link: 62, properties: 63, details: 64, spaceList: 65, ",": 66, left_of: 67, right_of: 68, signaltype: 69, "+": 70, "-": 71, "()": 72, ACTOR: 73, config_object: 74, CONFIG_START: 75, CONFIG_CONTENT: 76, CONFIG_END: 77, SOLID_OPEN_ARROW: 78, DOTTED_OPEN_ARROW: 79, SOLID_ARROW: 80, SOLID_ARROW_TOP: 81, SOLID_ARROW_BOTTOM: 82, STICK_ARROW_TOP: 83, STICK_ARROW_BOTTOM: 84, SOLID_ARROW_TOP_DOTTED: 85, SOLID_ARROW_BOTTOM_DOTTED: 86, STICK_ARROW_TOP_DOTTED: 87, STICK_ARROW_BOTTOM_DOTTED: 88, SOLID_ARROW_TOP_REVERSE: 89, SOLID_ARROW_BOTTOM_REVERSE: 90, STICK_ARROW_TOP_REVERSE: 91, STICK_ARROW_BOTTOM_REVERSE: 92, SOLID_ARROW_TOP_REVERSE_DOTTED: 93, SOLID_ARROW_BOTTOM_REVERSE_DOTTED: 94, STICK_ARROW_TOP_REVERSE_DOTTED: 95, STICK_ARROW_BOTTOM_REVERSE_DOTTED: 96, BIDIRECTIONAL_SOLID_ARROW: 97, DOTTED_ARROW: 98, BIDIRECTIONAL_DOTTED_ARROW: 99, SOLID_CROSS: 100, DOTTED_CROSS: 101, SOLID_POINT: 102, DOTTED_POINT: 103, TXT: 104, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "SPACE", 5: "NEWLINE", 6: "SD", 10: "INVALID", 14: "create", 15: "box", 16: "restOfLine", 17: "end", 19: "autonumber", 20: "NUM", 21: "off", 22: "activate", 24: "deactivate", 30: "title", 31: "legacy_title", 32: "acc_title", 33: "acc_title_value", 34: "acc_descr", 35: "acc_descr_value", 36: "acc_descr_multiline_value", 37: "loop", 38: "rect", 39: "opt", 40: "alt", 42: "par", 44: "par_over", 45: "critical", 47: "break", 48: "option", 49: "and", 50: "else", 51: "participant", 52: "AS", 53: "participant_actor", 54: "destroy", 56: "note", 59: "over", 61: "links", 62: "link", 63: "properties", 64: "details", 66: ",", 67: "left_of", 68: "right_of", 70: "+", 71: "-", 72: "()", 73: "ACTOR", 75: "CONFIG_START", 76: "CONFIG_CONTENT", 77: "CONFIG_END", 78: "SOLID_OPEN_ARROW", 79: "DOTTED_OPEN_ARROW", 80: "SOLID_ARROW", 81: "SOLID_ARROW_TOP", 82: "SOLID_ARROW_BOTTOM", 83: "STICK_ARROW_TOP", 84: "STICK_ARROW_BOTTOM", 85: "SOLID_ARROW_TOP_DOTTED", 86: "SOLID_ARROW_BOTTOM_DOTTED", 87: "STICK_ARROW_TOP_DOTTED", 88: "STICK_ARROW_BOTTOM_DOTTED", 89: "SOLID_ARROW_TOP_REVERSE", 90: "SOLID_ARROW_BOTTOM_REVERSE", 91: "STICK_ARROW_TOP_REVERSE", 92: "STICK_ARROW_BOTTOM_REVERSE", 93: "SOLID_ARROW_TOP_REVERSE_DOTTED", 94: "SOLID_ARROW_BOTTOM_REVERSE_DOTTED", 95: "STICK_ARROW_TOP_REVERSE_DOTTED", 96: "STICK_ARROW_BOTTOM_REVERSE_DOTTED", 97: "BIDIRECTIONAL_SOLID_ARROW", 98: "DOTTED_ARROW", 99: "BIDIRECTIONAL_DOTTED_ARROW", 100: "SOLID_CROSS", 101: "DOTTED_CROSS", 102: "SOLID_POINT", 103: "DOTTED_POINT", 104: "TXT" },
    productions_: [0, [3, 2], [3, 2], [3, 2], [7, 0], [7, 2], [8, 2], [8, 1], [8, 1], [8, 1], [11, 0], [11, 2], [12, 2], [12, 1], [12, 1], [9, 1], [9, 2], [9, 4], [9, 2], [9, 4], [9, 3], [9, 3], [9, 2], [9, 3], [9, 3], [9, 2], [9, 2], [9, 2], [9, 2], [9, 2], [9, 1], [9, 1], [9, 2], [9, 2], [9, 1], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [46, 1], [46, 4], [43, 1], [43, 4], [41, 1], [41, 4], [13, 5], [13, 3], [13, 5], [13, 3], [13, 3], [13, 5], [13, 3], [13, 5], [13, 3], [25, 4], [25, 4], [26, 3], [27, 3], [28, 3], [29, 3], [65, 2], [65, 1], [60, 3], [60, 1], [57, 1], [57, 1], [18, 5], [18, 5], [18, 5], [18, 5], [18, 6], [18, 4], [55, 2], [74, 3], [23, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [58, 1]],
    performAction: /* @__PURE__ */ _(function(L, m, N, g, V, c, bt) {
      var T = c.length - 1;
      switch (V) {
        case 3:
          return g.apply(c[T]), c[T];
        case 4:
        case 10:
          this.$ = [];
          break;
        case 5:
        case 11:
          c[T - 1].push(c[T]), this.$ = c[T - 1];
          break;
        case 6:
        case 7:
        case 12:
        case 13:
          this.$ = c[T];
          break;
        case 8:
        case 9:
        case 14:
          this.$ = [];
          break;
        case 16:
          c[T].type = "createParticipant", this.$ = c[T];
          break;
        case 17:
          c[T - 1].unshift({ type: "boxStart", boxData: g.parseBoxData(c[T - 2]) }), c[T - 1].push({ type: "boxEnd", boxText: c[T - 2] }), this.$ = c[T - 1];
          break;
        case 19:
          this.$ = { type: "sequenceIndex", sequenceIndex: Number(c[T - 2]), sequenceIndexStep: Number(c[T - 1]), sequenceVisible: !0, signalType: g.LINETYPE.AUTONUMBER };
          break;
        case 20:
          this.$ = { type: "sequenceIndex", sequenceIndex: Number(c[T - 1]), sequenceIndexStep: 1, sequenceVisible: !0, signalType: g.LINETYPE.AUTONUMBER };
          break;
        case 21:
          this.$ = { type: "sequenceIndex", sequenceVisible: !1, signalType: g.LINETYPE.AUTONUMBER };
          break;
        case 22:
          this.$ = { type: "sequenceIndex", sequenceVisible: !0, signalType: g.LINETYPE.AUTONUMBER };
          break;
        case 23:
          this.$ = { type: "activeStart", signalType: g.LINETYPE.ACTIVE_START, actor: c[T - 1].actor };
          break;
        case 24:
          this.$ = { type: "activeEnd", signalType: g.LINETYPE.ACTIVE_END, actor: c[T - 1].actor };
          break;
        case 30:
          g.setDiagramTitle(c[T].substring(6)), this.$ = c[T].substring(6);
          break;
        case 31:
          g.setDiagramTitle(c[T].substring(7)), this.$ = c[T].substring(7);
          break;
        case 32:
          this.$ = c[T].trim(), g.setAccTitle(this.$);
          break;
        case 33:
        case 34:
          this.$ = c[T].trim(), g.setAccDescription(this.$);
          break;
        case 35:
          c[T - 1].unshift({ type: "loopStart", loopText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.LOOP_START }), c[T - 1].push({ type: "loopEnd", loopText: c[T - 2], signalType: g.LINETYPE.LOOP_END }), this.$ = c[T - 1];
          break;
        case 36:
          c[T - 1].unshift({ type: "rectStart", color: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.RECT_START }), c[T - 1].push({ type: "rectEnd", color: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.RECT_END }), this.$ = c[T - 1];
          break;
        case 37:
          c[T - 1].unshift({ type: "optStart", optText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.OPT_START }), c[T - 1].push({ type: "optEnd", optText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.OPT_END }), this.$ = c[T - 1];
          break;
        case 38:
          c[T - 1].unshift({ type: "altStart", altText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.ALT_START }), c[T - 1].push({ type: "altEnd", signalType: g.LINETYPE.ALT_END }), this.$ = c[T - 1];
          break;
        case 39:
          c[T - 1].unshift({ type: "parStart", parText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.PAR_START }), c[T - 1].push({ type: "parEnd", signalType: g.LINETYPE.PAR_END }), this.$ = c[T - 1];
          break;
        case 40:
          c[T - 1].unshift({ type: "parStart", parText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.PAR_OVER_START }), c[T - 1].push({ type: "parEnd", signalType: g.LINETYPE.PAR_END }), this.$ = c[T - 1];
          break;
        case 41:
          c[T - 1].unshift({ type: "criticalStart", criticalText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.CRITICAL_START }), c[T - 1].push({ type: "criticalEnd", signalType: g.LINETYPE.CRITICAL_END }), this.$ = c[T - 1];
          break;
        case 42:
          c[T - 1].unshift({ type: "breakStart", breakText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.BREAK_START }), c[T - 1].push({ type: "breakEnd", optText: g.parseMessage(c[T - 2]), signalType: g.LINETYPE.BREAK_END }), this.$ = c[T - 1];
          break;
        case 44:
          this.$ = c[T - 3].concat([{ type: "option", optionText: g.parseMessage(c[T - 1]), signalType: g.LINETYPE.CRITICAL_OPTION }, c[T]]);
          break;
        case 46:
          this.$ = c[T - 3].concat([{ type: "and", parText: g.parseMessage(c[T - 1]), signalType: g.LINETYPE.PAR_AND }, c[T]]);
          break;
        case 48:
          this.$ = c[T - 3].concat([{ type: "else", altText: g.parseMessage(c[T - 1]), signalType: g.LINETYPE.ALT_ELSE }, c[T]]);
          break;
        case 49:
          c[T - 3].draw = "participant", c[T - 3].type = "addParticipant", c[T - 3].description = g.parseMessage(c[T - 1]), this.$ = c[T - 3];
          break;
        case 50:
          c[T - 1].draw = "participant", c[T - 1].type = "addParticipant", this.$ = c[T - 1];
          break;
        case 51:
          c[T - 3].draw = "actor", c[T - 3].type = "addParticipant", c[T - 3].description = g.parseMessage(c[T - 1]), this.$ = c[T - 3];
          break;
        case 52:
        case 57:
          c[T - 1].draw = "actor", c[T - 1].type = "addParticipant", this.$ = c[T - 1];
          break;
        case 53:
          c[T - 1].type = "destroyParticipant", this.$ = c[T - 1];
          break;
        case 54:
          c[T - 3].draw = "participant", c[T - 3].type = "addParticipant", c[T - 3].description = g.parseMessage(c[T - 1]), this.$ = c[T - 3];
          break;
        case 55:
          c[T - 1].draw = "participant", c[T - 1].type = "addParticipant", this.$ = c[T - 1];
          break;
        case 56:
          c[T - 3].draw = "actor", c[T - 3].type = "addParticipant", c[T - 3].description = g.parseMessage(c[T - 1]), this.$ = c[T - 3];
          break;
        case 58:
          this.$ = [c[T - 1], { type: "addNote", placement: c[T - 2], actor: c[T - 1].actor, text: c[T] }];
          break;
        case 59:
          c[T - 2] = [].concat(c[T - 1], c[T - 1]).slice(0, 2), c[T - 2][0] = c[T - 2][0].actor, c[T - 2][1] = c[T - 2][1].actor, this.$ = [c[T - 1], { type: "addNote", placement: g.PLACEMENT.OVER, actor: c[T - 2].slice(0, 2), text: c[T] }];
          break;
        case 60:
          this.$ = [c[T - 1], { type: "addLinks", actor: c[T - 1].actor, text: c[T] }];
          break;
        case 61:
          this.$ = [c[T - 1], { type: "addALink", actor: c[T - 1].actor, text: c[T] }];
          break;
        case 62:
          this.$ = [c[T - 1], { type: "addProperties", actor: c[T - 1].actor, text: c[T] }];
          break;
        case 63:
          this.$ = [c[T - 1], { type: "addDetails", actor: c[T - 1].actor, text: c[T] }];
          break;
        case 66:
          this.$ = [c[T - 2], c[T]];
          break;
        case 67:
          this.$ = c[T];
          break;
        case 68:
          this.$ = g.PLACEMENT.LEFTOF;
          break;
        case 69:
          this.$ = g.PLACEMENT.RIGHTOF;
          break;
        case 70:
          this.$ = [
            c[T - 4],
            c[T - 1],
            { type: "addMessage", from: c[T - 4].actor, to: c[T - 1].actor, signalType: c[T - 3], msg: c[T], activate: !0 },
            { type: "activeStart", signalType: g.LINETYPE.ACTIVE_START, actor: c[T - 1].actor }
          ];
          break;
        case 71:
          this.$ = [
            c[T - 4],
            c[T - 1],
            { type: "addMessage", from: c[T - 4].actor, to: c[T - 1].actor, signalType: c[T - 3], msg: c[T] },
            { type: "activeEnd", signalType: g.LINETYPE.ACTIVE_END, actor: c[T - 4].actor }
          ];
          break;
        case 72:
          this.$ = [
            c[T - 4],
            c[T - 1],
            { type: "addMessage", from: c[T - 4].actor, to: c[T - 1].actor, signalType: c[T - 3], msg: c[T], activate: !0, centralConnection: g.LINETYPE.CENTRAL_CONNECTION },
            { type: "centralConnection", signalType: g.LINETYPE.CENTRAL_CONNECTION, actor: c[T - 1].actor }
          ];
          break;
        case 73:
          this.$ = [
            c[T - 4],
            c[T - 1],
            { type: "addMessage", from: c[T - 4].actor, to: c[T - 1].actor, signalType: c[T - 2], msg: c[T], activate: !1, centralConnection: g.LINETYPE.CENTRAL_CONNECTION_REVERSE },
            { type: "centralConnectionReverse", signalType: g.LINETYPE.CENTRAL_CONNECTION_REVERSE, actor: c[T - 4].actor }
          ];
          break;
        case 74:
          this.$ = [
            c[T - 5],
            c[T - 1],
            { type: "addMessage", from: c[T - 5].actor, to: c[T - 1].actor, signalType: c[T - 3], msg: c[T], activate: !0, centralConnection: g.LINETYPE.CENTRAL_CONNECTION_DUAL },
            { type: "centralConnection", signalType: g.LINETYPE.CENTRAL_CONNECTION, actor: c[T - 1].actor },
            { type: "centralConnectionReverse", signalType: g.LINETYPE.CENTRAL_CONNECTION_REVERSE, actor: c[T - 5].actor }
          ];
          break;
        case 75:
          this.$ = [c[T - 3], c[T - 1], { type: "addMessage", from: c[T - 3].actor, to: c[T - 1].actor, signalType: c[T - 2], msg: c[T] }];
          break;
        case 76:
          this.$ = {
            type: "addParticipant",
            actor: c[T - 1],
            config: c[T]
          };
          break;
        case 77:
          this.$ = c[T - 1].trim();
          break;
        case 78:
          this.$ = { type: "addParticipant", actor: c[T] };
          break;
        case 79:
          this.$ = g.LINETYPE.SOLID_OPEN;
          break;
        case 80:
          this.$ = g.LINETYPE.DOTTED_OPEN;
          break;
        case 81:
          this.$ = g.LINETYPE.SOLID;
          break;
        case 82:
          this.$ = g.LINETYPE.SOLID_TOP;
          break;
        case 83:
          this.$ = g.LINETYPE.SOLID_BOTTOM;
          break;
        case 84:
          this.$ = g.LINETYPE.STICK_TOP;
          break;
        case 85:
          this.$ = g.LINETYPE.STICK_BOTTOM;
          break;
        case 86:
          this.$ = g.LINETYPE.SOLID_TOP_DOTTED;
          break;
        case 87:
          this.$ = g.LINETYPE.SOLID_BOTTOM_DOTTED;
          break;
        case 88:
          this.$ = g.LINETYPE.STICK_TOP_DOTTED;
          break;
        case 89:
          this.$ = g.LINETYPE.STICK_BOTTOM_DOTTED;
          break;
        case 90:
          this.$ = g.LINETYPE.SOLID_ARROW_TOP_REVERSE;
          break;
        case 91:
          this.$ = g.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE;
          break;
        case 92:
          this.$ = g.LINETYPE.STICK_ARROW_TOP_REVERSE;
          break;
        case 93:
          this.$ = g.LINETYPE.STICK_ARROW_BOTTOM_REVERSE;
          break;
        case 94:
          this.$ = g.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED;
          break;
        case 95:
          this.$ = g.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED;
          break;
        case 96:
          this.$ = g.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED;
          break;
        case 97:
          this.$ = g.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED;
          break;
        case 98:
          this.$ = g.LINETYPE.BIDIRECTIONAL_SOLID;
          break;
        case 99:
          this.$ = g.LINETYPE.DOTTED;
          break;
        case 100:
          this.$ = g.LINETYPE.BIDIRECTIONAL_DOTTED;
          break;
        case 101:
          this.$ = g.LINETYPE.SOLID_CROSS;
          break;
        case 102:
          this.$ = g.LINETYPE.DOTTED_CROSS;
          break;
        case 103:
          this.$ = g.LINETYPE.SOLID_POINT;
          break;
        case 104:
          this.$ = g.LINETYPE.DOTTED_POINT;
          break;
        case 105:
          this.$ = g.parseMessage(c[T].trim().substring(1));
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: t, 5: a, 6: s }, { 1: [3] }, { 3: 5, 4: t, 5: a, 6: s }, { 3: 6, 4: t, 5: a, 6: s }, e([1, 4, 5, 10, 14, 15, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 51, 53, 54, 56, 61, 62, 63, 64, 73], i, { 7: 7 }), { 1: [2, 1] }, { 1: [2, 2] }, { 1: [2, 3], 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, e(I, [2, 5]), { 9: 48, 13: 13, 14: l, 15: r, 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, e(I, [2, 7]), e(I, [2, 8]), e(I, [2, 9]), e(I, [2, 15]), { 13: 49, 51: X, 53: z, 54: v }, { 16: [1, 50] }, { 5: [1, 51] }, { 5: [1, 54], 20: [1, 52], 21: [1, 53] }, { 23: 55, 73: O }, { 23: 56, 73: O }, { 5: [1, 57] }, { 5: [1, 58] }, { 5: [1, 59] }, { 5: [1, 60] }, { 5: [1, 61] }, e(I, [2, 30]), e(I, [2, 31]), { 33: [1, 62] }, { 35: [1, 63] }, e(I, [2, 34]), { 16: [1, 64] }, { 16: [1, 65] }, { 16: [1, 66] }, { 16: [1, 67] }, { 16: [1, 68] }, { 16: [1, 69] }, { 16: [1, 70] }, { 16: [1, 71] }, { 23: 72, 55: 73, 73: nt }, { 23: 75, 55: 76, 73: nt }, { 23: 77, 73: O }, { 69: 78, 72: [1, 79], 78: ot, 79: C, 80: te, 81: ee, 82: se, 83: re, 84: ae, 85: ie, 86: ne, 87: oe, 88: ce, 89: le, 90: he, 91: de, 92: Te, 93: Ee, 94: pe, 95: ue, 96: _e, 97: fe, 98: ge, 99: xe, 100: Ie, 101: Re, 102: Oe, 103: ye }, { 57: 106, 59: [1, 107], 67: [1, 108], 68: [1, 109] }, { 23: 110, 73: O }, { 23: 111, 73: O }, { 23: 112, 73: O }, { 23: 113, 73: O }, e([5, 66, 72, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104], Le), e(I, [2, 6]), e(I, [2, 16]), e(Lt, [2, 10], { 11: 114 }), e(I, [2, 18]), { 5: [1, 116], 20: [1, 115] }, { 5: [1, 117] }, e(I, [2, 22]), { 5: [1, 118] }, { 5: [1, 119] }, e(I, [2, 25]), e(I, [2, 26]), e(I, [2, 27]), e(I, [2, 28]), e(I, [2, 29]), e(I, [2, 32]), e(I, [2, 33]), e(mt, i, { 7: 120 }), e(mt, i, { 7: 121 }), e(mt, i, { 7: 122 }), e(be, i, { 41: 123, 7: 124 }), e(Wt, i, { 43: 125, 7: 126 }), e(Wt, i, { 7: 126, 43: 127 }), e(Se, i, { 46: 128, 7: 129 }), e(mt, i, { 7: 130 }), { 5: [1, 132], 52: [1, 131] }, { 5: [1, 134], 52: [1, 133] }, e(Kt, Le, { 74: 135, 75: [1, 136] }), { 5: [1, 138], 52: [1, 137] }, { 5: [1, 140], 52: [1, 139] }, { 5: [1, 141] }, { 23: 145, 70: [1, 142], 71: [1, 143], 72: [1, 144], 73: O }, { 69: 146, 78: ot, 79: C, 80: te, 81: ee, 82: se, 83: re, 84: ae, 85: ie, 86: ne, 87: oe, 88: ce, 89: le, 90: he, 91: de, 92: Te, 93: Ee, 94: pe, 95: ue, 96: _e, 97: fe, 98: ge, 99: xe, 100: Ie, 101: Re, 102: Oe, 103: ye }, e(B, [2, 79]), e(B, [2, 80]), e(B, [2, 81]), e(B, [2, 82]), e(B, [2, 83]), e(B, [2, 84]), e(B, [2, 85]), e(B, [2, 86]), e(B, [2, 87]), e(B, [2, 88]), e(B, [2, 89]), e(B, [2, 90]), e(B, [2, 91]), e(B, [2, 92]), e(B, [2, 93]), e(B, [2, 94]), e(B, [2, 95]), e(B, [2, 96]), e(B, [2, 97]), e(B, [2, 98]), e(B, [2, 99]), e(B, [2, 100]), e(B, [2, 101]), e(B, [2, 102]), e(B, [2, 103]), e(B, [2, 104]), { 23: 147, 73: O }, { 23: 149, 60: 148, 73: O }, { 73: [2, 68] }, { 73: [2, 69] }, { 58: 150, 104: at }, { 58: 152, 104: at }, { 58: 153, 104: at }, { 58: 154, 104: at }, { 4: [1, 157], 5: [1, 159], 12: 156, 13: 158, 17: [1, 155], 51: X, 53: z, 54: v }, { 5: [1, 160] }, e(I, [2, 20]), e(I, [2, 21]), e(I, [2, 23]), e(I, [2, 24]), { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [1, 161], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [1, 162], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [1, 163], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 17: [1, 164] }, { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [2, 47], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 50: [1, 165], 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 17: [1, 166] }, { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [2, 45], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 49: [1, 167], 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 17: [1, 168] }, { 17: [1, 169] }, { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [2, 43], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 48: [1, 170], 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 4: n, 5: o, 8: 8, 9: 10, 10: h, 13: 13, 14: l, 15: r, 17: [1, 171], 18: 16, 19: E, 22: p, 23: 41, 24: f, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: u, 31: y, 32: R, 34: b, 36: w, 37: A, 38: D, 39: k, 40: M, 42: W, 44: K, 45: H, 47: G, 51: X, 53: z, 54: v, 56: $, 61: J, 62: j, 63: st, 64: rt, 73: O }, { 16: [1, 172] }, e(I, [2, 50]), { 16: [1, 173] }, e(I, [2, 55]), e(Kt, [2, 76]), { 76: [1, 174] }, { 16: [1, 175] }, e(I, [2, 52]), { 16: [1, 176] }, e(I, [2, 57]), e(I, [2, 53]), { 23: 177, 73: O }, { 23: 178, 73: O }, { 23: 179, 73: O }, { 58: 180, 104: at }, { 23: 181, 72: [1, 182], 73: O }, { 58: 183, 104: at }, { 58: 184, 104: at }, { 66: [1, 185], 104: [2, 67] }, { 5: [2, 60] }, { 5: [2, 105] }, { 5: [2, 61] }, { 5: [2, 62] }, { 5: [2, 63] }, e(I, [2, 17]), e(Lt, [2, 11]), { 13: 186, 51: X, 53: z, 54: v }, e(Lt, [2, 13]), e(Lt, [2, 14]), e(I, [2, 19]), e(I, [2, 35]), e(I, [2, 36]), e(I, [2, 37]), e(I, [2, 38]), { 16: [1, 187] }, e(I, [2, 39]), { 16: [1, 188] }, e(I, [2, 40]), e(I, [2, 41]), { 16: [1, 189] }, e(I, [2, 42]), { 5: [1, 190] }, { 5: [1, 191] }, { 77: [1, 192] }, { 5: [1, 193] }, { 5: [1, 194] }, { 58: 195, 104: at }, { 58: 196, 104: at }, { 58: 197, 104: at }, { 5: [2, 75] }, { 58: 198, 104: at }, { 23: 199, 73: O }, { 5: [2, 58] }, { 5: [2, 59] }, { 23: 200, 73: O }, e(Lt, [2, 12]), e(be, i, { 7: 124, 41: 201 }), e(Wt, i, { 7: 126, 43: 202 }), e(Se, i, { 7: 129, 46: 203 }), e(I, [2, 49]), e(I, [2, 54]), e(Kt, [2, 77]), e(I, [2, 51]), e(I, [2, 56]), { 5: [2, 70] }, { 5: [2, 71] }, { 5: [2, 72] }, { 5: [2, 73] }, { 58: 204, 104: at }, { 104: [2, 66] }, { 17: [2, 48] }, { 17: [2, 46] }, { 17: [2, 44] }, { 5: [2, 74] }],
    defaultActions: { 5: [2, 1], 6: [2, 2], 108: [2, 68], 109: [2, 69], 150: [2, 60], 151: [2, 105], 152: [2, 61], 153: [2, 62], 154: [2, 63], 180: [2, 75], 183: [2, 58], 184: [2, 59], 195: [2, 70], 196: [2, 71], 197: [2, 72], 198: [2, 73], 200: [2, 66], 201: [2, 48], 202: [2, 46], 203: [2, 44], 204: [2, 74] },
    parseError: /* @__PURE__ */ _(function(L, m) {
      if (m.recoverable)
        this.trace(L);
      else {
        var N = new Error(L);
        throw N.hash = m, N;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ _(function(L) {
      var m = this, N = [0], g = [], V = [null], c = [], bt = this.table, T = "", wt = 0, Ne = 0, Je = 2, me = 1, Ze = c.slice.call(arguments, 1), F = Object.create(this.lexer), ut = { yy: {} };
      for (var qt in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, qt) && (ut.yy[qt] = this.yy[qt]);
      F.setInput(L, ut.yy), ut.yy.lexer = F, ut.yy.parser = this, typeof F.yylloc > "u" && (F.yylloc = {});
      var Ht = F.yylloc;
      c.push(Ht);
      var Qe = F.options && F.options.ranges;
      typeof ut.yy.parseError == "function" ? this.parseError = ut.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function $e(tt) {
        N.length = N.length - 2 * tt, V.length = V.length - tt, c.length = c.length - tt;
      }
      _($e, "popStack");
      function Ae() {
        var tt;
        return tt = g.pop() || F.lex() || me, typeof tt != "number" && (tt instanceof Array && (g = tt, tt = g.pop()), tt = m.symbols_[tt] || tt), tt;
      }
      _(Ae, "lex");
      for (var Z, _t, it, zt, It = {}, Pt, ht, we, Dt; ; ) {
        if (_t = N[N.length - 1], this.defaultActions[_t] ? it = this.defaultActions[_t] : ((Z === null || typeof Z > "u") && (Z = Ae()), it = bt[_t] && bt[_t][Z]), typeof it > "u" || !it.length || !it[0]) {
          var Ut = "";
          Dt = [];
          for (Pt in bt[_t])
            this.terminals_[Pt] && Pt > Je && Dt.push("'" + this.terminals_[Pt] + "'");
          F.showPosition ? Ut = "Parse error on line " + (wt + 1) + `:
` + F.showPosition() + `
Expecting ` + Dt.join(", ") + ", got '" + (this.terminals_[Z] || Z) + "'" : Ut = "Parse error on line " + (wt + 1) + ": Unexpected " + (Z == me ? "end of input" : "'" + (this.terminals_[Z] || Z) + "'"), this.parseError(Ut, {
            text: F.match,
            token: this.terminals_[Z] || Z,
            line: F.yylineno,
            loc: Ht,
            expected: Dt
          });
        }
        if (it[0] instanceof Array && it.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + _t + ", token: " + Z);
        switch (it[0]) {
          case 1:
            N.push(Z), V.push(F.yytext), c.push(F.yylloc), N.push(it[1]), Z = null, Ne = F.yyleng, T = F.yytext, wt = F.yylineno, Ht = F.yylloc;
            break;
          case 2:
            if (ht = this.productions_[it[1]][1], It.$ = V[V.length - ht], It._$ = {
              first_line: c[c.length - (ht || 1)].first_line,
              last_line: c[c.length - 1].last_line,
              first_column: c[c.length - (ht || 1)].first_column,
              last_column: c[c.length - 1].last_column
            }, Qe && (It._$.range = [
              c[c.length - (ht || 1)].range[0],
              c[c.length - 1].range[1]
            ]), zt = this.performAction.apply(It, [
              T,
              Ne,
              wt,
              ut.yy,
              it[1],
              V,
              c
            ].concat(Ze)), typeof zt < "u")
              return zt;
            ht && (N = N.slice(0, -1 * ht * 2), V = V.slice(0, -1 * ht), c = c.slice(0, -1 * ht)), N.push(this.productions_[it[1]][0]), V.push(It.$), c.push(It._$), we = bt[N[N.length - 2]][N[N.length - 1]], N.push(we);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, Xe = /* @__PURE__ */ (function() {
    var Tt = {
      EOF: 1,
      parseError: /* @__PURE__ */ _(function(m, N) {
        if (this.yy.parser)
          this.yy.parser.parseError(m, N);
        else
          throw new Error(m);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ _(function(L, m) {
        return this.yy = m || this.yy || {}, this._input = L, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ _(function() {
        var L = this._input[0];
        this.yytext += L, this.yyleng++, this.offset++, this.match += L, this.matched += L;
        var m = L.match(/(?:\r\n?|\n).*/g);
        return m ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), L;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ _(function(L) {
        var m = L.length, N = L.split(/(?:\r\n?|\n)/g);
        this._input = L + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - m), this.offset -= m;
        var g = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), N.length - 1 && (this.yylineno -= N.length - 1);
        var V = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: N ? (N.length === g.length ? this.yylloc.first_column : 0) + g[g.length - N.length].length - N[0].length : this.yylloc.first_column - m
        }, this.options.ranges && (this.yylloc.range = [V[0], V[0] + this.yyleng - m]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ _(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ _(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ _(function(L) {
        this.unput(this.match.slice(L));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ _(function() {
        var L = this.matched.substr(0, this.matched.length - this.match.length);
        return (L.length > 20 ? "..." : "") + L.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ _(function() {
        var L = this.match;
        return L.length < 20 && (L += this._input.substr(0, 20 - L.length)), (L.substr(0, 20) + (L.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ _(function() {
        var L = this.pastInput(), m = new Array(L.length + 1).join("-");
        return L + this.upcomingInput() + `
` + m + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ _(function(L, m) {
        var N, g, V;
        if (this.options.backtrack_lexer && (V = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (V.yylloc.range = this.yylloc.range.slice(0))), g = L[0].match(/(?:\r\n?|\n).*/g), g && (this.yylineno += g.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: g ? g[g.length - 1].length - g[g.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + L[0].length
        }, this.yytext += L[0], this.match += L[0], this.matches = L, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(L[0].length), this.matched += L[0], N = this.performAction.call(this, this.yy, this, m, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), N)
          return N;
        if (this._backtrack) {
          for (var c in V)
            this[c] = V[c];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ _(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var L, m, N, g;
        this._more || (this.yytext = "", this.match = "");
        for (var V = this._currentRules(), c = 0; c < V.length; c++)
          if (N = this._input.match(this.rules[V[c]]), N && (!m || N[0].length > m[0].length)) {
            if (m = N, g = c, this.options.backtrack_lexer) {
              if (L = this.test_match(N, V[c]), L !== !1)
                return L;
              if (this._backtrack) {
                m = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return m ? (L = this.test_match(m, V[g]), L !== !1 ? L : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ _(function() {
        var m = this.next();
        return m || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ _(function(m) {
        this.conditionStack.push(m);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ _(function() {
        var m = this.conditionStack.length - 1;
        return m > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ _(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ _(function(m) {
        return m = this.conditionStack.length - 1 - Math.abs(m || 0), m >= 0 ? this.conditionStack[m] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ _(function(m) {
        this.begin(m);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ _(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ _(function(m, N, g, V) {
        switch (g) {
          case 0:
            return 5;
          case 1:
            break;
          case 2:
            break;
          case 3:
            break;
          case 4:
            break;
          case 5:
            break;
          case 6:
            return 20;
          case 7:
            return this.begin("CONFIG"), 75;
          case 8:
            return 76;
          case 9:
            return this.popState(), this.begin("ALIAS"), 77;
          case 10:
            return this.popState(), this.popState(), 77;
          case 11:
            return N.yytext = N.yytext.trim(), 73;
          case 12:
            return N.yytext = N.yytext.trim(), this.begin("ALIAS"), 73;
          case 13:
            return N.yytext = N.yytext.trim(), this.popState(), 73;
          case 14:
            return this.popState(), 10;
          case 15:
            return this.begin("LINE"), 15;
          case 16:
            return this.begin("ID"), 51;
          case 17:
            return this.begin("ID"), 53;
          case 18:
            return 14;
          case 19:
            return this.begin("ID"), 54;
          case 20:
            return this.popState(), this.popState(), this.begin("LINE"), 52;
          case 21:
            return this.popState(), this.popState(), 5;
          case 22:
            return this.begin("LINE"), 37;
          case 23:
            return this.begin("LINE"), 38;
          case 24:
            return this.begin("LINE"), 39;
          case 25:
            return this.begin("LINE"), 40;
          case 26:
            return this.begin("LINE"), 50;
          case 27:
            return this.begin("LINE"), 42;
          case 28:
            return this.begin("LINE"), 44;
          case 29:
            return this.begin("LINE"), 49;
          case 30:
            return this.begin("LINE"), 45;
          case 31:
            return this.begin("LINE"), 48;
          case 32:
            return this.begin("LINE"), 47;
          case 33:
            return this.popState(), 16;
          case 34:
            return 17;
          case 35:
            return 67;
          case 36:
            return 68;
          case 37:
            return 61;
          case 38:
            return 62;
          case 39:
            return 63;
          case 40:
            return 64;
          case 41:
            return 59;
          case 42:
            return 56;
          case 43:
            return this.begin("ID"), 22;
          case 44:
            return this.begin("ID"), 24;
          case 45:
            return 30;
          case 46:
            return 31;
          case 47:
            return this.begin("acc_title"), 32;
          case 48:
            return this.popState(), "acc_title_value";
          case 49:
            return this.begin("acc_descr"), 34;
          case 50:
            return this.popState(), "acc_descr_value";
          case 51:
            this.begin("acc_descr_multiline");
            break;
          case 52:
            this.popState();
            break;
          case 53:
            return "acc_descr_multiline_value";
          case 54:
            return 6;
          case 55:
            return 19;
          case 56:
            return 21;
          case 57:
            return 66;
          case 58:
            return 5;
          case 59:
            return N.yytext = N.yytext.trim(), 73;
          case 60:
            return 80;
          case 61:
            return 97;
          case 62:
            return 98;
          case 63:
            return 99;
          case 64:
            return 78;
          case 65:
            return 79;
          case 66:
            return 100;
          case 67:
            return 101;
          case 68:
            return 102;
          case 69:
            return 103;
          case 70:
            return 85;
          case 71:
            return 86;
          case 72:
            return 87;
          case 73:
            return 88;
          case 74:
            return 93;
          case 75:
            return 94;
          case 76:
            return 95;
          case 77:
            return 96;
          case 78:
            return 81;
          case 79:
            return 82;
          case 80:
            return 83;
          case 81:
            return 84;
          case 82:
            return 89;
          case 83:
            return 90;
          case 84:
            return 91;
          case 85:
            return 92;
          case 86:
            return 104;
          case 87:
            return 104;
          case 88:
            return 70;
          case 89:
            return 71;
          case 90:
            return 72;
          case 91:
            return 5;
          case 92:
            return 10;
        }
      }, "anonymous"),
      rules: [/^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:((?!\n)\s)+)/i, /^(?:#[^\n]*)/i, /^(?:%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[0-9]+(?=[ \n]+))/i, /^(?:@\{)/i, /^(?:[^\}]+)/i, /^(?:\}(?=\s+as\s))/i, /^(?:\})/i, /^(?:[^\<->\->:\n,;@\s]+(?=@\{))/i, /^(?:[^<>:\n,;@\s]+(?=\s+as\s))/i, /^(?:[^<>:\n,;@]+(?=\s*[\n;#]|$))/i, /^(?:[^<>:\n,;@]*<[^\n]*)/i, /^(?:box\b)/i, /^(?:participant\b)/i, /^(?:actor\b)/i, /^(?:create\b)/i, /^(?:destroy\b)/i, /^(?:as\b)/i, /^(?:(?:))/i, /^(?:loop\b)/i, /^(?:rect\b)/i, /^(?:opt\b)/i, /^(?:alt\b)/i, /^(?:else\b)/i, /^(?:par\b)/i, /^(?:par_over\b)/i, /^(?:and\b)/i, /^(?:critical\b)/i, /^(?:option\b)/i, /^(?:break\b)/i, /^(?:(?:[:]?(?:no)?wrap)?[^#\n;]*)/i, /^(?:end\b)/i, /^(?:left of\b)/i, /^(?:right of\b)/i, /^(?:links\b)/i, /^(?:link\b)/i, /^(?:properties\b)/i, /^(?:details\b)/i, /^(?:over\b)/i, /^(?:note\b)/i, /^(?:activate\b)/i, /^(?:deactivate\b)/i, /^(?:title\s[^#\n;]+)/i, /^(?:title:\s[^#\n;]+)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:sequenceDiagram\b)/i, /^(?:autonumber\b)/i, /^(?:off\b)/i, /^(?:,)/i, /^(?:;)/i, /^(?:[^\/\\\+\()\+<\->\->:\n,;]+((?!(-x|--x|-\)|--\)|-\|\\|-\\|-\/|-\/\/|-\|\/|\/\|-|\\\|-|\/\/-|\\\\-|\/\|-|--\|\\|--|\(\)))[\-]*[^\+<\->\->:\n,;]+)*)/i, /^(?:->>)/i, /^(?:<<->>)/i, /^(?:-->>)/i, /^(?:<<-->>)/i, /^(?:->)/i, /^(?:-->)/i, /^(?:-[x])/i, /^(?:--[x])/i, /^(?:-[\)])/i, /^(?:--[\)])/i, /^(?:--\|\\)/i, /^(?:--\|\/)/i, /^(?:--\\\\)/i, /^(?:--\/\/)/i, /^(?:\/\|--)/i, /^(?:\\\|--)/i, /^(?:\/\/--)/i, /^(?:\\\\--)/i, /^(?:-\|\\)/i, /^(?:-\|\/)/i, /^(?:-\\\\)/i, /^(?:-\/\/)/i, /^(?:\/\|-)/i, /^(?:\\\|-)/i, /^(?:\/\/-)/i, /^(?:\\\\-)/i, /^(?::(?:(?:no)?wrap)?[^#\n;]*)/i, /^(?::)/i, /^(?:\+)/i, /^(?:-)/i, /^(?:\(\))/i, /^(?:$)/i, /^(?:.)/i],
      conditions: { acc_descr_multiline: { rules: [52, 53], inclusive: !1 }, acc_descr: { rules: [50], inclusive: !1 }, acc_title: { rules: [48], inclusive: !1 }, ID: { rules: [2, 3, 7, 11, 12, 13, 14], inclusive: !1 }, ALIAS: { rules: [2, 3, 20, 21], inclusive: !1 }, LINE: { rules: [2, 3, 33], inclusive: !1 }, CONFIG: { rules: [8, 9, 10], inclusive: !1 }, CONFIG_DATA: { rules: [], inclusive: !1 }, INITIAL: { rules: [0, 1, 3, 4, 5, 6, 15, 16, 17, 18, 19, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 49, 51, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92], inclusive: !0 } }
    };
    return Tt;
  })();
  Ft.lexer = Xe;
  function At() {
    this.yy = {};
  }
  return _(At, "Parser"), At.prototype = Ft, Ft.Parser = At, new At();
})();
Xt.parser = Xt;
var us = Xt, _s = {
  SOLID: 0,
  DOTTED: 1,
  NOTE: 2,
  SOLID_CROSS: 3,
  DOTTED_CROSS: 4,
  SOLID_OPEN: 5,
  DOTTED_OPEN: 6,
  LOOP_START: 10,
  LOOP_END: 11,
  ALT_START: 12,
  ALT_ELSE: 13,
  ALT_END: 14,
  OPT_START: 15,
  OPT_END: 16,
  ACTIVE_START: 17,
  ACTIVE_END: 18,
  PAR_START: 19,
  PAR_AND: 20,
  PAR_END: 21,
  RECT_START: 22,
  RECT_END: 23,
  SOLID_POINT: 24,
  DOTTED_POINT: 25,
  AUTONUMBER: 26,
  CRITICAL_START: 27,
  CRITICAL_OPTION: 28,
  CRITICAL_END: 29,
  BREAK_START: 30,
  BREAK_END: 31,
  PAR_OVER_START: 32,
  BIDIRECTIONAL_SOLID: 33,
  BIDIRECTIONAL_DOTTED: 34,
  SOLID_TOP: 41,
  SOLID_BOTTOM: 42,
  STICK_TOP: 43,
  STICK_BOTTOM: 44,
  SOLID_ARROW_TOP_REVERSE: 45,
  SOLID_ARROW_BOTTOM_REVERSE: 46,
  STICK_ARROW_TOP_REVERSE: 47,
  STICK_ARROW_BOTTOM_REVERSE: 48,
  SOLID_TOP_DOTTED: 51,
  SOLID_BOTTOM_DOTTED: 52,
  STICK_TOP_DOTTED: 53,
  STICK_BOTTOM_DOTTED: 54,
  SOLID_ARROW_TOP_REVERSE_DOTTED: 55,
  SOLID_ARROW_BOTTOM_REVERSE_DOTTED: 56,
  STICK_ARROW_TOP_REVERSE_DOTTED: 57,
  STICK_ARROW_BOTTOM_REVERSE_DOTTED: 58,
  CENTRAL_CONNECTION: 59,
  CENTRAL_CONNECTION_REVERSE: 60,
  CENTRAL_CONNECTION_DUAL: 61
}, fs = {
  FILLED: 0,
  OPEN: 1
}, gs = {
  LEFTOF: 0,
  RIGHTOF: 1,
  OVER: 2
}, Ct = {
  ACTOR: "actor",
  CONTROL: "control",
  DATABASE: "database",
  ENTITY: "entity"
}, Ot, xs = (Ot = class {
  constructor() {
    this.state = new ps(() => ({
      prevActor: void 0,
      actors: /* @__PURE__ */ new Map(),
      createdActors: /* @__PURE__ */ new Map(),
      destroyedActors: /* @__PURE__ */ new Map(),
      boxes: [],
      messages: [],
      notes: [],
      sequenceNumbersEnabled: !1,
      wrapEnabled: void 0,
      currentBox: void 0,
      lastCreated: void 0,
      lastDestroyed: void 0
    })), this.setAccTitle = Pe, this.setAccDescription = ss, this.setDiagramTitle = rs, this.getAccTitle = as, this.getAccDescription = is, this.getDiagramTitle = ns, this.apply = this.apply.bind(this), this.parseBoxData = this.parseBoxData.bind(this), this.parseMessage = this.parseMessage.bind(this), this.clear(), this.setWrap(et().wrap), this.LINETYPE = _s, this.ARROWTYPE = fs, this.PLACEMENT = gs;
  }
  addBox(t) {
    this.state.records.boxes.push({
      name: t.text,
      wrap: t.wrap ?? this.autoWrap(),
      fill: t.color,
      actorKeys: []
    }), this.state.records.currentBox = this.state.records.boxes.slice(-1)[0];
  }
  addActor(t, a, s, i, n) {
    let o = this.state.records.currentBox, h;
    if (n !== void 0) {
      let r;
      n.includes(`
`) ? r = n + `
` : r = `{
` + n + `
}`, h = os(r, { schema: cs });
    }
    i = h?.type ?? i, h?.alias && (!s || s.text === a) && (s = { text: h.alias, wrap: s?.wrap, type: i });
    const l = this.state.records.actors.get(t);
    if (l) {
      if (this.state.records.currentBox && l.box && this.state.records.currentBox !== l.box)
        throw new Error(
          `A same participant should only be defined in one Box: ${l.name} can't be in '${l.box.name}' and in '${this.state.records.currentBox.name}' at the same time.`
        );
      if (o = l.box ? l.box : this.state.records.currentBox, l.box = o, l && a === l.name && s == null)
        return;
    }
    if (s?.text == null && (s = { text: a, type: i }), (i == null || s.text == null) && (s = { text: a, type: i }), this.state.records.actors.set(t, {
      box: o,
      name: a,
      description: s.text,
      wrap: s.wrap ?? this.autoWrap(),
      prevActor: this.state.records.prevActor,
      links: {},
      properties: {},
      actorCnt: null,
      rectData: null,
      type: i ?? "participant"
    }), this.state.records.prevActor) {
      const r = this.state.records.actors.get(this.state.records.prevActor);
      r && (r.nextActor = t);
    }
    this.state.records.currentBox && this.state.records.currentBox.actorKeys.push(t), this.state.records.prevActor = t;
  }
  activationCount(t) {
    let a, s = 0;
    if (!t)
      return 0;
    for (a = 0; a < this.state.records.messages.length; a++)
      this.state.records.messages[a].type === this.LINETYPE.ACTIVE_START && this.state.records.messages[a].from === t && s++, this.state.records.messages[a].type === this.LINETYPE.ACTIVE_END && this.state.records.messages[a].from === t && s--;
    return s;
  }
  addMessage(t, a, s, i) {
    this.state.records.messages.push({
      id: this.state.records.messages.length.toString(),
      from: t,
      to: a,
      message: s.text,
      wrap: s.wrap ?? this.autoWrap(),
      answer: i
    });
  }
  addSignal(t, a, s, i, n = !1, o) {
    if (i === this.LINETYPE.ACTIVE_END && this.activationCount(t ?? "") < 1) {
      const l = new Error("Trying to inactivate an inactive participant (" + t + ")");
      throw l.hash = {
        text: "->>-",
        token: "->>-",
        line: "1",
        loc: { first_line: 1, last_line: 1, first_column: 1, last_column: 1 },
        expected: ["'ACTIVE_PARTICIPANT'"]
      }, l;
    }
    return this.state.records.messages.push({
      id: this.state.records.messages.length.toString(),
      from: t,
      to: a,
      message: s?.text ?? "",
      wrap: s?.wrap ?? this.autoWrap(),
      type: i,
      activate: n,
      centralConnection: o ?? 0
    }), !0;
  }
  hasAtLeastOneBox() {
    return this.state.records.boxes.length > 0;
  }
  hasAtLeastOneBoxWithTitle() {
    return this.state.records.boxes.some((t) => t.name);
  }
  getMessages() {
    return this.state.records.messages;
  }
  getBoxes() {
    return this.state.records.boxes;
  }
  getActors() {
    return this.state.records.actors;
  }
  getCreatedActors() {
    return this.state.records.createdActors;
  }
  getDestroyedActors() {
    return this.state.records.destroyedActors;
  }
  getActor(t) {
    return this.state.records.actors.get(t);
  }
  getActorKeys() {
    return [...this.state.records.actors.keys()];
  }
  enableSequenceNumbers() {
    this.state.records.sequenceNumbersEnabled = !0;
  }
  disableSequenceNumbers() {
    this.state.records.sequenceNumbersEnabled = !1;
  }
  showSequenceNumbers() {
    return this.state.records.sequenceNumbersEnabled;
  }
  setWrap(t) {
    this.state.records.wrapEnabled = t;
  }
  extractWrap(t) {
    if (t === void 0)
      return {};
    t = t.trim();
    const a = /^:?wrap:/.exec(t) !== null ? !0 : /^:?nowrap:/.exec(t) !== null ? !1 : void 0;
    return { cleanedText: (a === void 0 ? t : t.replace(/^:?(?:no)?wrap:/, "")).trim(), wrap: a };
  }
  autoWrap() {
    return this.state.records.wrapEnabled !== void 0 ? this.state.records.wrapEnabled : et().sequence?.wrap ?? !1;
  }
  clear() {
    this.state.reset(), ls();
  }
  parseMessage(t) {
    const a = t.trim(), { wrap: s, cleanedText: i } = this.extractWrap(a), n = {
      text: i,
      wrap: s
    };
    return Q.debug(`parseMessage: ${JSON.stringify(n)}`), n;
  }
  // We expect the box statement to be color first then description
  // The color can be rgb,rgba,hsl,hsla, or css code names  #hex codes are not supported for now because of the way the char # is handled
  // We extract first segment as color, the rest of the line is considered as text
  parseBoxData(t) {
    const a = /^((?:rgba?|hsla?)\s*\(.*\)|\w*)(.*)$/.exec(t);
    let s = a?.[1] ? a[1].trim() : "transparent", i = a?.[2] ? a[2].trim() : void 0;
    if (window?.CSS)
      window.CSS.supports("color", s) || (s = "transparent", i = t.trim());
    else {
      const h = new Option().style;
      h.color = s, h.color !== s && (s = "transparent", i = t.trim());
    }
    const { wrap: n, cleanedText: o } = this.extractWrap(i);
    return {
      text: o ? vt(o, et()) : void 0,
      color: s,
      wrap: n
    };
  }
  addNote(t, a, s) {
    const i = {
      actor: t,
      placement: a,
      message: s.text,
      wrap: s.wrap ?? this.autoWrap()
    }, n = [].concat(t, t);
    this.state.records.notes.push(i), this.state.records.messages.push({
      id: this.state.records.messages.length.toString(),
      from: n[0],
      to: n[1],
      message: s.text,
      wrap: s.wrap ?? this.autoWrap(),
      type: this.LINETYPE.NOTE,
      placement: a
    });
  }
  addLinks(t, a) {
    const s = this.getActor(t);
    try {
      let i = vt(a.text, et());
      i = i.replace(/&equals;/g, "="), i = i.replace(/&amp;/g, "&");
      const n = JSON.parse(i);
      this.insertLinks(s, n);
    } catch (i) {
      Q.error("error while parsing actor link text", i);
    }
  }
  addALink(t, a) {
    const s = this.getActor(t);
    try {
      const i = {};
      let n = vt(a.text, et());
      const o = n.indexOf("@");
      n = n.replace(/&equals;/g, "="), n = n.replace(/&amp;/g, "&");
      const h = n.slice(0, o - 1).trim(), l = n.slice(o + 1).trim();
      i[h] = l, this.insertLinks(s, i);
    } catch (i) {
      Q.error("error while parsing actor link text", i);
    }
  }
  insertLinks(t, a) {
    if (t.links == null)
      t.links = a;
    else
      for (const s in a)
        t.links[s] = a[s];
  }
  addProperties(t, a) {
    const s = this.getActor(t);
    try {
      const i = vt(a.text, et()), n = JSON.parse(i);
      this.insertProperties(s, n);
    } catch (i) {
      Q.error("error while parsing actor properties text", i);
    }
  }
  insertProperties(t, a) {
    if (t.properties == null)
      t.properties = a;
    else
      for (const s in a)
        t.properties[s] = a[s];
  }
  boxEnd() {
    this.state.records.currentBox = void 0;
  }
  addDetails(t, a) {
    const s = this.getActor(t), i = document.getElementById(a.text);
    try {
      const n = i.innerHTML, o = JSON.parse(n);
      o.properties && this.insertProperties(s, o.properties), o.links && this.insertLinks(s, o.links);
    } catch (n) {
      Q.error("error while parsing actor details text", n);
    }
  }
  getActorProperty(t, a) {
    if (t?.properties !== void 0)
      return t.properties[a];
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-redundant-type-constituents
  apply(t) {
    if (Array.isArray(t))
      t.forEach((a) => {
        this.apply(a);
      });
    else
      switch (t.type) {
        case "sequenceIndex":
          this.state.records.messages.push({
            id: this.state.records.messages.length.toString(),
            from: void 0,
            to: void 0,
            message: {
              start: t.sequenceIndex,
              step: t.sequenceIndexStep,
              visible: t.sequenceVisible
            },
            wrap: !1,
            type: t.signalType
          });
          break;
        case "addParticipant":
          this.addActor(t.actor, t.actor, t.description, t.draw, t.config);
          break;
        case "createParticipant":
          if (this.state.records.actors.has(t.actor))
            throw new Error(
              "It is not possible to have actors with the same id, even if one is destroyed before the next is created. Use 'AS' aliases to simulate the behavior"
            );
          this.state.records.lastCreated = t.actor, this.addActor(t.actor, t.actor, t.description, t.draw, t.config), this.state.records.createdActors.set(t.actor, this.state.records.messages.length);
          break;
        case "destroyParticipant":
          this.state.records.lastDestroyed = t.actor, this.state.records.destroyedActors.set(t.actor, this.state.records.messages.length);
          break;
        case "activeStart":
          this.addSignal(t.actor, void 0, void 0, t.signalType);
          break;
        case "centralConnection":
          this.addSignal(t.actor, void 0, void 0, t.signalType);
          break;
        case "centralConnectionReverse":
          this.addSignal(t.actor, void 0, void 0, t.signalType);
          break;
        case "activeEnd":
          this.addSignal(t.actor, void 0, void 0, t.signalType);
          break;
        case "addNote":
          this.addNote(t.actor, t.placement, t.text);
          break;
        case "addLinks":
          this.addLinks(t.actor, t.text);
          break;
        case "addALink":
          this.addALink(t.actor, t.text);
          break;
        case "addProperties":
          this.addProperties(t.actor, t.text);
          break;
        case "addDetails":
          this.addDetails(t.actor, t.text);
          break;
        case "addMessage":
          if (this.state.records.lastCreated) {
            if (t.to !== this.state.records.lastCreated)
              throw new Error(
                "The created participant " + this.state.records.lastCreated.name + " does not have an associated creating message after its declaration. Please check the sequence diagram."
              );
            this.state.records.lastCreated = void 0;
          } else if (this.state.records.lastDestroyed) {
            if (t.to !== this.state.records.lastDestroyed && t.from !== this.state.records.lastDestroyed)
              throw new Error(
                "The destroyed participant " + this.state.records.lastDestroyed.name + " does not have an associated destroying message after its declaration. Please check the sequence diagram."
              );
            this.state.records.lastDestroyed = void 0;
          }
          this.addSignal(
            t.from,
            t.to,
            t.msg,
            t.signalType,
            t.activate,
            t.centralConnection
          );
          break;
        case "boxStart":
          this.addBox(t.boxData);
          break;
        case "boxEnd":
          this.boxEnd();
          break;
        case "loopStart":
          this.addSignal(void 0, void 0, t.loopText, t.signalType);
          break;
        case "loopEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "rectStart":
          this.addSignal(void 0, void 0, t.color, t.signalType);
          break;
        case "rectEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "optStart":
          this.addSignal(void 0, void 0, t.optText, t.signalType);
          break;
        case "optEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "altStart":
          this.addSignal(void 0, void 0, t.altText, t.signalType);
          break;
        case "else":
          this.addSignal(void 0, void 0, t.altText, t.signalType);
          break;
        case "altEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "setAccTitle":
          Pe(t.text);
          break;
        case "parStart":
          this.addSignal(void 0, void 0, t.parText, t.signalType);
          break;
        case "and":
          this.addSignal(void 0, void 0, t.parText, t.signalType);
          break;
        case "parEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "criticalStart":
          this.addSignal(void 0, void 0, t.criticalText, t.signalType);
          break;
        case "option":
          this.addSignal(void 0, void 0, t.optionText, t.signalType);
          break;
        case "criticalEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "breakStart":
          this.addSignal(void 0, void 0, t.breakText, t.signalType);
          break;
        case "breakEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
      }
  }
  getConfig() {
    return et().sequence;
  }
}, _(Ot, "SequenceDB"), Ot), Is = /* @__PURE__ */ _((e) => `.actor {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
  }

  text.actor > tspan {
    fill: ${e.actorTextColor};
    stroke: none;
  }

  .actor-line {
    stroke: ${e.actorLineColor};
  }
  
  .innerArc {
    stroke-width: 1.5;
    stroke-dasharray: none;
  }

  .messageLine0 {
    stroke-width: 1.5;
    stroke-dasharray: none;
    stroke: ${e.signalColor};
  }

  .messageLine1 {
    stroke-width: 1.5;
    stroke-dasharray: 2, 2;
    stroke: ${e.signalColor};
  }

  #arrowhead path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .sequenceNumber {
    fill: ${e.sequenceNumberColor};
  }

  #sequencenumber {
    fill: ${e.signalColor};
  }

  #crosshead path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .messageText {
    fill: ${e.signalTextColor};
    stroke: none;
  }

  .labelBox {
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBkgColor};
  }

  .labelText, .labelText > tspan {
    fill: ${e.labelTextColor};
    stroke: none;
  }

  .loopText, .loopText > tspan {
    fill: ${e.loopTextColor};
    stroke: none;
  }

  .loopLine {
    stroke-width: 2px;
    stroke-dasharray: 2, 2;
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBorderColor};
  }

  .note {
    //stroke: #decc93;
    stroke: ${e.noteBorderColor};
    fill: ${e.noteBkgColor};
  }

  .noteText, .noteText > tspan {
    fill: ${e.noteTextColor};
    stroke: none;
  }

  .activation0 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation1 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation2 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .actorPopupMenu {
    position: absolute;
  }

  .actorPopupMenuPanel {
    position: absolute;
    fill: ${e.actorBkg};
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    filter: drop-shadow(3px 5px 2px rgb(0 0 0 / 0.4));
}
  .actor-man line {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
  }
  .actor-man circle, line {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
    stroke-width: 2px;
  }

`, "getStyles"), Rs = Is, ft = 36, Et = "actor-top", pt = "actor-bottom", Bt = "actor-box", gt = "actor-man", St = /* @__PURE__ */ _(function(e, t) {
  return Es(e, t);
}, "drawRect"), Os = /* @__PURE__ */ _(function(e, t, a, s, i) {
  if (t.links === void 0 || t.links === null || Object.keys(t.links).length === 0)
    return { height: 0, width: 0 };
  const n = t.links, o = t.actorCnt, h = t.rectData;
  var l = "none";
  i && (l = "block !important");
  const r = e.append("g");
  r.attr("id", "actor" + o + "_popup"), r.attr("class", "actorPopupMenu"), r.attr("display", l);
  var E = "";
  h.class !== void 0 && (E = " " + h.class);
  let p = h.width > a ? h.width : a;
  const f = r.append("rect");
  if (f.attr("class", "actorPopupMenuPanel" + E), f.attr("x", h.x), f.attr("y", h.height), f.attr("fill", h.fill), f.attr("stroke", h.stroke), f.attr("width", p), f.attr("height", h.height), f.attr("rx", h.rx), f.attr("ry", h.ry), n != null) {
    var u = 20;
    for (let b in n) {
      var y = r.append("a"), R = ve.sanitizeUrl(n[b]);
      y.attr("xlink:href", R), y.attr("target", "_blank"), Hs(s)(
        b,
        y,
        h.x + 10,
        h.height + u,
        p,
        20,
        { class: "actor" },
        s
      ), u += 30;
    }
  }
  return f.attr("height", u), { height: h.height + u, width: p };
}, "drawPopup"), Vt = /* @__PURE__ */ _(function(e) {
  return "var pu = document.getElementById('" + e + "'); if (pu != null) { pu.style.display = pu.style.display == 'block' ? 'none' : 'block'; }";
}, "popupMenuToggle"), Mt = /* @__PURE__ */ _(async function(e, t, a = null) {
  let s = e.append("foreignObject");
  const i = await Me(t.text, Gt()), o = s.append("xhtml:div").attr("style", "width: fit-content;").attr("xmlns", "http://www.w3.org/1999/xhtml").html(i).node().getBoundingClientRect();
  if (s.attr("height", Math.round(o.height)).attr("width", Math.round(o.width)), t.class === "noteText") {
    const h = e.node().firstChild;
    h.setAttribute("height", o.height + 2 * t.textMargin);
    const l = h.getBBox();
    s.attr("x", Math.round(l.x + l.width / 2 - o.width / 2)).attr("y", Math.round(l.y + l.height / 2 - o.height / 2));
  } else if (a) {
    let { startx: h, stopx: l, starty: r } = a;
    if (h > l) {
      const E = h;
      h = l, l = E;
    }
    s.attr("x", Math.round(h + Math.abs(h - l) / 2 - o.width / 2)), t.class === "loopText" ? s.attr("y", Math.round(r)) : s.attr("y", Math.round(r - o.height));
  }
  return [s];
}, "drawKatex"), yt = /* @__PURE__ */ _(function(e, t) {
  let a = 0, s = 0;
  const i = t.text.split(S.lineBreakRegex), [n, o] = Ce(t.fontSize);
  let h = [], l = 0, r = /* @__PURE__ */ _(() => t.y, "yfunc");
  if (t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0)
    switch (t.valign) {
      case "top":
      case "start":
        r = /* @__PURE__ */ _(() => Math.round(t.y + t.textMargin), "yfunc");
        break;
      case "middle":
      case "center":
        r = /* @__PURE__ */ _(() => Math.round(t.y + (a + s + t.textMargin) / 2), "yfunc");
        break;
      case "bottom":
      case "end":
        r = /* @__PURE__ */ _(() => Math.round(
          t.y + (a + s + 2 * t.textMargin) - t.textMargin
        ), "yfunc");
        break;
    }
  if (t.anchor !== void 0 && t.textMargin !== void 0 && t.width !== void 0)
    switch (t.anchor) {
      case "left":
      case "start":
        t.x = Math.round(t.x + t.textMargin), t.anchor = "start", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
        break;
      case "middle":
      case "center":
        t.x = Math.round(t.x + t.width / 2), t.anchor = "middle", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
        break;
      case "right":
      case "end":
        t.x = Math.round(t.x + t.width - t.textMargin), t.anchor = "end", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
        break;
    }
  for (let [E, p] of i.entries()) {
    t.textMargin !== void 0 && t.textMargin === 0 && n !== void 0 && (l = E * n);
    const f = e.append("text");
    f.attr("x", t.x), f.attr("y", r()), t.anchor !== void 0 && f.attr("text-anchor", t.anchor).attr("dominant-baseline", t.dominantBaseline).attr("alignment-baseline", t.alignmentBaseline), t.fontFamily !== void 0 && f.style("font-family", t.fontFamily), o !== void 0 && f.style("font-size", o), t.fontWeight !== void 0 && f.style("font-weight", t.fontWeight), t.fill !== void 0 && f.attr("fill", t.fill), t.class !== void 0 && f.attr("class", t.class), t.dy !== void 0 ? f.attr("dy", t.dy) : l !== 0 && f.attr("dy", l);
    const u = p || hs;
    if (t.tspan) {
      const y = f.append("tspan");
      y.attr("x", t.x), t.fill !== void 0 && y.attr("fill", t.fill), y.text(u);
    } else
      f.text(u);
    t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0 && (s += (f._groups || f)[0][0].getBBox().height, a = s), h.push(f);
  }
  return h;
}, "drawText"), Be = /* @__PURE__ */ _(function(e, t) {
  function a(i, n, o, h, l) {
    return i + "," + n + " " + (i + o) + "," + n + " " + (i + o) + "," + (n + h - l) + " " + (i + o - l * 1.2) + "," + (n + h) + " " + i + "," + (n + h);
  }
  _(a, "genPoints");
  const s = e.append("polygon");
  return s.attr("points", a(t.x, t.y, t.width, t.height, 7)), s.attr("class", "labelBox"), t.y = t.y + t.height / 2, yt(e, t), s;
}, "drawLabel"), P = -1, Ve = /* @__PURE__ */ _((e, t, a, s) => {
  e.select && a.forEach((i) => {
    const n = t.get(i), o = e.select("#actor" + n.actorCnt);
    !s.mirrorActors && n.stopy ? o.attr("y2", n.stopy + n.height / 2) : s.mirrorActors && o.attr("y2", n.stopy);
  });
}, "fixLifeLineHeights"), ys = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + t.height, h = e.append("g").lower();
  var l = h;
  s || (P++, Object.keys(t.links || {}).length && !a.forceMenus && l.attr("onclick", Vt(`actor${P}_popup`)).attr("cursor", "pointer"), l.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), l = h.append("g"), t.actorCnt = P, t.links != null && l.attr("id", "root-" + P));
  const r = lt();
  var E = "actor";
  t.properties?.class ? E = t.properties.class : r.fill = "#eaeaea", s ? E += ` ${pt}` : E += ` ${Et}`, r.x = t.x, r.y = i, r.width = t.width, r.height = t.height, r.class = E, r.rx = 3, r.ry = 3, r.name = t.name;
  const p = St(l, r);
  if (t.rectData = r, t.properties?.icon) {
    const u = t.properties.icon.trim();
    u.charAt(0) === "@" ? $t(l, r.x + r.width - 20, r.y + 10, u.substr(1)) : jt(l, r.x + r.width - 20, r.y + 10, u);
  }
  dt(a, U(t.description))(
    t.description,
    l,
    r.x,
    r.y,
    r.width,
    r.height,
    { class: `actor ${Bt}` },
    a
  );
  let f = t.height;
  if (p.node) {
    const u = p.node().getBBox();
    t.height = u.height, f = u.height;
  }
  return f;
}, "drawActorTypeParticipant"), Ls = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + t.height, h = e.append("g").lower();
  var l = h;
  s || (P++, Object.keys(t.links || {}).length && !a.forceMenus && l.attr("onclick", Vt(`actor${P}_popup`)).attr("cursor", "pointer"), l.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), l = h.append("g"), t.actorCnt = P, t.links != null && l.attr("id", "root-" + P));
  const r = lt();
  var E = "actor";
  t.properties?.class ? E = t.properties.class : r.fill = "#eaeaea", s ? E += ` ${pt}` : E += ` ${Et}`, r.x = t.x, r.y = i, r.width = t.width, r.height = t.height, r.class = E, r.name = t.name;
  const p = 6, f = {
    ...r,
    x: r.x + -p,
    y: r.y + +p,
    class: "actor"
  }, u = St(l, r);
  if (St(l, f), t.rectData = r, t.properties?.icon) {
    const R = t.properties.icon.trim();
    R.charAt(0) === "@" ? $t(l, r.x + r.width - 20, r.y + 10, R.substr(1)) : jt(l, r.x + r.width - 20, r.y + 10, R);
  }
  dt(a, U(t.description))(
    t.description,
    l,
    r.x - p,
    r.y + p,
    r.width,
    r.height,
    { class: `actor ${Bt}` },
    a
  );
  let y = t.height;
  if (u.node) {
    const R = u.node().getBBox();
    t.height = R.height, y = R.height;
  }
  return y;
}, "drawActorTypeCollections"), bs = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + t.height, h = e.append("g").lower();
  let l = h;
  s || (P++, Object.keys(t.links || {}).length && !a.forceMenus && l.attr("onclick", Vt(`actor${P}_popup`)).attr("cursor", "pointer"), l.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), l = h.append("g"), t.actorCnt = P, t.links != null && l.attr("id", "root-" + P));
  const r = lt();
  let E = "actor";
  t.properties?.class ? E = t.properties.class : r.fill = "#eaeaea", s ? E += ` ${pt}` : E += ` ${Et}`, r.x = t.x, r.y = i, r.width = t.width, r.height = t.height, r.class = E, r.name = t.name;
  const p = r.height / 2, f = p / (2.5 + r.height / 50), u = l.append("g"), y = l.append("g");
  if (u.append("path").attr(
    "d",
    `M ${r.x},${r.y + p}
    a ${f},${p} 0 0 0 0,${r.height}
    h ${r.width - 2 * f}
    a ${f},${p} 0 0 0 0,-${r.height}
    Z
  `
  ).attr("class", E), y.append("path").attr(
    "d",
    `M ${r.x},${r.y + p}
      a ${f},${p} 0 0 0 0,${r.height}`
  ).attr("stroke", "#666").attr("stroke-width", "1px").attr("class", E), u.attr("transform", `translate(${f}, ${-(r.height / 2)})`), y.attr("transform", `translate(${r.width - f}, ${-r.height / 2})`), t.rectData = r, t.properties?.icon) {
    const w = t.properties.icon.trim(), A = r.x + r.width - 20, D = r.y + 10;
    w.charAt(0) === "@" ? $t(l, A, D, w.substr(1)) : jt(l, A, D, w);
  }
  dt(a, U(t.description))(
    t.description,
    l,
    r.x,
    r.y,
    r.width,
    r.height,
    { class: `actor ${Bt}` },
    a
  );
  let R = t.height;
  const b = u.select("path:last-child");
  if (b.node()) {
    const w = b.node().getBBox();
    t.height = w.height, R = w.height;
  }
  return R;
}, "drawActorTypeQueue"), Ss = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + 75, h = e.append("g").lower();
  s || (P++, h.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), t.actorCnt = P);
  const l = e.append("g");
  let r = gt;
  s ? r += ` ${pt}` : r += ` ${Et}`, l.attr("class", r), l.attr("name", t.name);
  const E = lt();
  E.x = t.x, E.y = i, E.fill = "#eaeaea", E.width = t.width, E.height = t.height, E.class = "actor";
  const p = t.x + t.width / 2, f = i + 32, u = 22;
  l.append("defs").append("marker").attr("id", "filled-head-control").attr("refX", 11).attr("refY", 5.8).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "172.5").append("path").attr("d", "M 14.4 5.6 L 7.2 10.4 L 8.8 5.6 L 7.2 0.8 Z"), l.append("circle").attr("cx", p).attr("cy", f).attr("r", u).attr("fill", "#eaeaf7").attr("stroke", "#666").attr("stroke-width", 1.2), l.append("line").attr("marker-end", "url(#filled-head-control)").attr("transform", `translate(${p}, ${f - u})`);
  const y = l.node().getBBox();
  return t.height = y.height + 2 * (a?.sequence?.labelBoxHeight ?? 0), dt(a, U(t.description))(
    t.description,
    l,
    E.x,
    E.y + u + (s ? 5 : 12),
    E.width,
    E.height,
    { class: `actor ${gt}` },
    a
  ), t.height;
}, "drawActorTypeControl"), Ns = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + 75, h = e.append("g").lower(), l = e.append("g");
  let r = "actor";
  s ? r += ` ${pt}` : r += ` ${Et}`, l.attr("class", r), l.attr("name", t.name);
  const E = lt();
  E.x = t.x, E.y = i, E.fill = "#eaeaea", E.width = t.width, E.height = t.height, E.class = "actor";
  const p = t.x + t.width / 2, f = i + (s ? 10 : 25), u = 22;
  l.append("circle").attr("cx", p).attr("cy", f).attr("r", u).attr("width", t.width).attr("height", t.height), l.append("line").attr("x1", p - u).attr("x2", p + u).attr("y1", f + u).attr("y2", f + u).attr("stroke-width", 2);
  const y = l.node().getBBox();
  return t.height = y.height + (a?.sequence?.labelBoxHeight ?? 0), s || (P++, h.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), t.actorCnt = P), dt(a, U(t.description))(
    t.description,
    l,
    E.x,
    E.y + (s ? 15 : 30),
    E.width,
    E.height,
    { class: `actor ${gt}` },
    a
  ), s ? l.attr("transform", `translate(0, ${u})`) : l.attr("transform", `translate(0, ${u / 2 - 5})`), t.height;
}, "drawActorTypeEntity"), ms = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + t.height + 2 * a.boxTextMargin, h = e.append("g").lower();
  let l = h;
  s || (P++, Object.keys(t.links || {}).length && !a.forceMenus && l.attr("onclick", Vt(`actor${P}_popup`)).attr("cursor", "pointer"), l.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), l = h.append("g"), t.actorCnt = P, t.links != null && l.attr("id", "root-" + P));
  const r = lt();
  let E = "actor";
  t.properties?.class ? E = t.properties.class : r.fill = "#eaeaea", s ? E += ` ${pt}` : E += ` ${Et}`, r.x = t.x, r.y = i, r.width = t.width, r.height = t.height, r.class = E, r.name = t.name, r.x = t.x, r.y = i;
  const p = r.width / 3, f = r.width / 3, u = p / 2, y = u / (2.5 + p / 50), R = l.append("g"), b = `
  M ${r.x},${r.y + y}
  a ${u},${y} 0 0 0 ${p},0
  a ${u},${y} 0 0 0 -${p},0
  l 0,${f - 2 * y}
  a ${u},${y} 0 0 0 ${p},0
  l 0,-${f - 2 * y}
`;
  R.append("path").attr("d", b).attr("fill", "#eaeaea").attr("stroke", "#000").attr("stroke-width", 1).attr("class", E), R.attr("transform", `translate(${p}, ${y})`), t.rectData = r, dt(a, U(t.description))(
    t.description,
    l,
    r.x,
    r.y + 35,
    r.width,
    r.height,
    { class: `actor ${Bt}` },
    a
  );
  const w = R.select("path:last-child");
  if (w.node()) {
    const A = w.node().getBBox();
    t.height = A.height + (a.sequence.labelBoxHeight ?? 0);
  }
  return t.height;
}, "drawActorTypeDatabase"), As = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + 80, h = 22, l = e.append("g").lower();
  s || (P++, l.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), t.actorCnt = P);
  const r = e.append("g");
  let E = gt;
  s ? E += ` ${pt}` : E += ` ${Et}`, r.attr("class", E), r.attr("name", t.name);
  const p = lt();
  p.x = t.x, p.y = i, p.fill = "#eaeaea", p.width = t.width, p.height = t.height, p.class = "actor", r.append("line").attr("id", "actor-man-torso" + P).attr("x1", t.x + t.width / 2 - h * 2.5).attr("y1", i + 12).attr("x2", t.x + t.width / 2 - 15).attr("y2", i + 12), r.append("line").attr("id", "actor-man-arms" + P).attr("x1", t.x + t.width / 2 - h * 2.5).attr("y1", i + 2).attr("x2", t.x + t.width / 2 - h * 2.5).attr("y2", i + 22), r.append("circle").attr("cx", t.x + t.width / 2).attr("cy", i + 12).attr("r", h);
  const f = r.node().getBBox();
  return t.height = f.height + (a.sequence.labelBoxHeight ?? 0), dt(a, U(t.description))(
    t.description,
    r,
    p.x,
    p.y + 15,
    p.width,
    p.height,
    { class: `actor ${gt}` },
    a
  ), s ? r.attr("transform", `translate(0,${h / 2 + 10})`) : r.attr("transform", `translate(0,${h / 2 + 10})`), t.height;
}, "drawActorTypeBoundary"), ws = /* @__PURE__ */ _(function(e, t, a, s) {
  const i = s ? t.stopy : t.starty, n = t.x + t.width / 2, o = i + 80, h = e.append("g").lower();
  s || (P++, h.append("line").attr("id", "actor" + P).attr("x1", n).attr("y1", o).attr("x2", n).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), t.actorCnt = P);
  const l = e.append("g");
  let r = gt;
  s ? r += ` ${pt}` : r += ` ${Et}`, l.attr("class", r), l.attr("name", t.name);
  const E = lt();
  E.x = t.x, E.y = i, E.fill = "#eaeaea", E.width = t.width, E.height = t.height, E.class = "actor", E.rx = 3, E.ry = 3, l.append("line").attr("id", "actor-man-torso" + P).attr("x1", n).attr("y1", i + 25).attr("x2", n).attr("y2", i + 45), l.append("line").attr("id", "actor-man-arms" + P).attr("x1", n - ft / 2).attr("y1", i + 33).attr("x2", n + ft / 2).attr("y2", i + 33), l.append("line").attr("x1", n - ft / 2).attr("y1", i + 60).attr("x2", n).attr("y2", i + 45), l.append("line").attr("x1", n).attr("y1", i + 45).attr("x2", n + ft / 2 - 2).attr("y2", i + 60);
  const p = l.append("circle");
  p.attr("cx", t.x + t.width / 2), p.attr("cy", i + 10), p.attr("r", 15), p.attr("width", t.width), p.attr("height", t.height);
  const f = l.node().getBBox();
  return t.height = f.height, dt(a, U(t.description))(
    t.description,
    l,
    E.x,
    E.y + 35,
    E.width,
    E.height,
    { class: `actor ${gt}` },
    a
  ), t.height;
}, "drawActorTypeActor"), Ps = /* @__PURE__ */ _(async function(e, t, a, s) {
  switch (t.type) {
    case "actor":
      return await ws(e, t, a, s);
    case "participant":
      return await ys(e, t, a, s);
    case "boundary":
      return await As(e, t, a, s);
    case "control":
      return await Ss(e, t, a, s);
    case "entity":
      return await Ns(e, t, a, s);
    case "database":
      return await ms(e, t, a, s);
    case "collections":
      return await Ls(e, t, a, s);
    case "queue":
      return await bs(e, t, a, s);
  }
}, "drawActor"), Ds = /* @__PURE__ */ _(function(e, t, a) {
  const i = e.append("g");
  Ye(i, t), t.name && dt(a)(
    t.name,
    i,
    t.x,
    t.y + a.boxTextMargin + (t.textMaxHeight || 0) / 2,
    t.width,
    0,
    { class: "text" },
    a
  ), i.lower();
}, "drawBox"), ks = /* @__PURE__ */ _(function(e) {
  return e.append("g");
}, "anchorElement"), vs = /* @__PURE__ */ _(function(e, t, a, s, i) {
  const n = lt(), o = t.anchored;
  n.x = t.startx, n.y = t.starty, n.class = "activation" + i % 3, n.width = t.stopx - t.startx, n.height = a - t.starty, St(o, n);
}, "drawActivation"), Cs = /* @__PURE__ */ _(async function(e, t, a, s) {
  const {
    boxMargin: i,
    boxTextMargin: n,
    labelBoxHeight: o,
    labelBoxWidth: h,
    messageFontFamily: l,
    messageFontSize: r,
    messageFontWeight: E
  } = s, p = e.append("g"), f = /* @__PURE__ */ _(function(R, b, w, A) {
    return p.append("line").attr("x1", R).attr("y1", b).attr("x2", w).attr("y2", A).attr("class", "loopLine");
  }, "drawLoopLine");
  f(t.startx, t.starty, t.stopx, t.starty), f(t.stopx, t.starty, t.stopx, t.stopy), f(t.startx, t.stopy, t.stopx, t.stopy), f(t.startx, t.starty, t.startx, t.stopy), t.sections !== void 0 && t.sections.forEach(function(R) {
    f(t.startx, R.y, t.stopx, R.y).style(
      "stroke-dasharray",
      "3, 3"
    );
  });
  let u = Qt();
  u.text = a, u.x = t.startx, u.y = t.starty, u.fontFamily = l, u.fontSize = r, u.fontWeight = E, u.anchor = "middle", u.valign = "middle", u.tspan = !1, u.width = h || 50, u.height = o || 20, u.textMargin = n, u.class = "labelText", Be(p, u), u = We(), u.text = t.title, u.x = t.startx + h / 2 + (t.stopx - t.startx) / 2, u.y = t.starty + i + n, u.anchor = "middle", u.valign = "middle", u.textMargin = n, u.class = "loopText", u.fontFamily = l, u.fontSize = r, u.fontWeight = E, u.wrap = !0;
  let y = U(u.text) ? await Mt(p, u, t) : yt(p, u);
  if (t.sectionTitles !== void 0) {
    for (const [R, b] of Object.entries(t.sectionTitles))
      if (b.message) {
        u.text = b.message, u.x = t.startx + (t.stopx - t.startx) / 2, u.y = t.sections[R].y + i + n, u.class = "loopText", u.anchor = "middle", u.valign = "middle", u.tspan = !1, u.fontFamily = l, u.fontSize = r, u.fontWeight = E, u.wrap = t.wrap, U(u.text) ? (t.starty = t.sections[R].y, await Mt(p, u, t)) : yt(p, u);
        let w = Math.round(
          y.map((A) => (A._groups || A)[0][0].getBBox().height).reduce((A, D) => A + D)
        );
        t.sections[R].height += w - (i + n);
      }
  }
  return t.height = Math.round(t.stopy - t.starty), p;
}, "drawLoop"), Ye = /* @__PURE__ */ _(function(e, t) {
  Ts(e, t);
}, "drawBackgroundRect"), Ms = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("symbol").attr("id", "database").attr("fill-rule", "evenodd").attr("clip-rule", "evenodd").append("path").attr("transform", "scale(.5)").attr(
    "d",
    "M12.258.001l.256.004.255.005.253.008.251.01.249.012.247.015.246.016.242.019.241.02.239.023.236.024.233.027.231.028.229.031.225.032.223.034.22.036.217.038.214.04.211.041.208.043.205.045.201.046.198.048.194.05.191.051.187.053.183.054.18.056.175.057.172.059.168.06.163.061.16.063.155.064.15.066.074.033.073.033.071.034.07.034.069.035.068.035.067.035.066.035.064.036.064.036.062.036.06.036.06.037.058.037.058.037.055.038.055.038.053.038.052.038.051.039.05.039.048.039.047.039.045.04.044.04.043.04.041.04.04.041.039.041.037.041.036.041.034.041.033.042.032.042.03.042.029.042.027.042.026.043.024.043.023.043.021.043.02.043.018.044.017.043.015.044.013.044.012.044.011.045.009.044.007.045.006.045.004.045.002.045.001.045v17l-.001.045-.002.045-.004.045-.006.045-.007.045-.009.044-.011.045-.012.044-.013.044-.015.044-.017.043-.018.044-.02.043-.021.043-.023.043-.024.043-.026.043-.027.042-.029.042-.03.042-.032.042-.033.042-.034.041-.036.041-.037.041-.039.041-.04.041-.041.04-.043.04-.044.04-.045.04-.047.039-.048.039-.05.039-.051.039-.052.038-.053.038-.055.038-.055.038-.058.037-.058.037-.06.037-.06.036-.062.036-.064.036-.064.036-.066.035-.067.035-.068.035-.069.035-.07.034-.071.034-.073.033-.074.033-.15.066-.155.064-.16.063-.163.061-.168.06-.172.059-.175.057-.18.056-.183.054-.187.053-.191.051-.194.05-.198.048-.201.046-.205.045-.208.043-.211.041-.214.04-.217.038-.22.036-.223.034-.225.032-.229.031-.231.028-.233.027-.236.024-.239.023-.241.02-.242.019-.246.016-.247.015-.249.012-.251.01-.253.008-.255.005-.256.004-.258.001-.258-.001-.256-.004-.255-.005-.253-.008-.251-.01-.249-.012-.247-.015-.245-.016-.243-.019-.241-.02-.238-.023-.236-.024-.234-.027-.231-.028-.228-.031-.226-.032-.223-.034-.22-.036-.217-.038-.214-.04-.211-.041-.208-.043-.204-.045-.201-.046-.198-.048-.195-.05-.19-.051-.187-.053-.184-.054-.179-.056-.176-.057-.172-.059-.167-.06-.164-.061-.159-.063-.155-.064-.151-.066-.074-.033-.072-.033-.072-.034-.07-.034-.069-.035-.068-.035-.067-.035-.066-.035-.064-.036-.063-.036-.062-.036-.061-.036-.06-.037-.058-.037-.057-.037-.056-.038-.055-.038-.053-.038-.052-.038-.051-.039-.049-.039-.049-.039-.046-.039-.046-.04-.044-.04-.043-.04-.041-.04-.04-.041-.039-.041-.037-.041-.036-.041-.034-.041-.033-.042-.032-.042-.03-.042-.029-.042-.027-.042-.026-.043-.024-.043-.023-.043-.021-.043-.02-.043-.018-.044-.017-.043-.015-.044-.013-.044-.012-.044-.011-.045-.009-.044-.007-.045-.006-.045-.004-.045-.002-.045-.001-.045v-17l.001-.045.002-.045.004-.045.006-.045.007-.045.009-.044.011-.045.012-.044.013-.044.015-.044.017-.043.018-.044.02-.043.021-.043.023-.043.024-.043.026-.043.027-.042.029-.042.03-.042.032-.042.033-.042.034-.041.036-.041.037-.041.039-.041.04-.041.041-.04.043-.04.044-.04.046-.04.046-.039.049-.039.049-.039.051-.039.052-.038.053-.038.055-.038.056-.038.057-.037.058-.037.06-.037.061-.036.062-.036.063-.036.064-.036.066-.035.067-.035.068-.035.069-.035.07-.034.072-.034.072-.033.074-.033.151-.066.155-.064.159-.063.164-.061.167-.06.172-.059.176-.057.179-.056.184-.054.187-.053.19-.051.195-.05.198-.048.201-.046.204-.045.208-.043.211-.041.214-.04.217-.038.22-.036.223-.034.226-.032.228-.031.231-.028.234-.027.236-.024.238-.023.241-.02.243-.019.245-.016.247-.015.249-.012.251-.01.253-.008.255-.005.256-.004.258-.001.258.001zm-9.258 20.499v.01l.001.021.003.021.004.022.005.021.006.022.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.023.018.024.019.024.021.024.022.025.023.024.024.025.052.049.056.05.061.051.066.051.07.051.075.051.079.052.084.052.088.052.092.052.097.052.102.051.105.052.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.048.144.049.147.047.152.047.155.047.16.045.163.045.167.043.171.043.176.041.178.041.183.039.187.039.19.037.194.035.197.035.202.033.204.031.209.03.212.029.216.027.219.025.222.024.226.021.23.02.233.018.236.016.24.015.243.012.246.01.249.008.253.005.256.004.259.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.021.224-.024.22-.026.216-.027.212-.028.21-.031.205-.031.202-.034.198-.034.194-.036.191-.037.187-.039.183-.04.179-.04.175-.042.172-.043.168-.044.163-.045.16-.046.155-.046.152-.047.148-.048.143-.049.139-.049.136-.05.131-.05.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.053.083-.051.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.05.023-.024.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.023.01-.022.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.127l-.077.055-.08.053-.083.054-.085.053-.087.052-.09.052-.093.051-.095.05-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.045-.118.044-.12.043-.122.042-.124.042-.126.041-.128.04-.13.04-.132.038-.134.038-.135.037-.138.037-.139.035-.142.035-.143.034-.144.033-.147.032-.148.031-.15.03-.151.03-.153.029-.154.027-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.01-.179.008-.179.008-.181.006-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.006-.179-.008-.179-.008-.178-.01-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.027-.153-.029-.151-.03-.15-.03-.148-.031-.146-.032-.145-.033-.143-.034-.141-.035-.14-.035-.137-.037-.136-.037-.134-.038-.132-.038-.13-.04-.128-.04-.126-.041-.124-.042-.122-.042-.12-.044-.117-.043-.116-.045-.113-.045-.112-.046-.109-.047-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.05-.093-.052-.09-.051-.087-.052-.085-.053-.083-.054-.08-.054-.077-.054v4.127zm0-5.654v.011l.001.021.003.021.004.021.005.022.006.022.007.022.009.022.01.022.011.023.012.023.013.023.015.024.016.023.017.024.018.024.019.024.021.024.022.024.023.025.024.024.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.052.11.051.114.051.119.052.123.05.127.051.131.05.135.049.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.044.171.042.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.022.23.02.233.018.236.016.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.012.241-.015.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.048.139-.05.136-.049.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.051.051-.049.023-.025.023-.024.021-.025.02-.024.019-.024.018-.024.017-.024.015-.023.014-.023.013-.024.012-.022.01-.023.01-.023.008-.022.006-.022.006-.022.004-.021.004-.022.001-.021.001-.021v-4.139l-.077.054-.08.054-.083.054-.085.052-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.044-.118.044-.12.044-.122.042-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.035-.143.033-.144.033-.147.033-.148.031-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.009-.179.009-.179.007-.181.007-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.007-.179-.007-.179-.009-.178-.009-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.031-.146-.033-.145-.033-.143-.033-.141-.035-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.04-.126-.041-.124-.042-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.051-.093-.051-.09-.051-.087-.053-.085-.052-.083-.054-.08-.054-.077-.054v4.139zm0-5.666v.011l.001.02.003.022.004.021.005.022.006.021.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.024.018.023.019.024.021.025.022.024.023.024.024.025.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.051.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.043.171.043.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.021.23.02.233.018.236.017.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.013.241-.014.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.049.139-.049.136-.049.131-.051.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.049.023-.025.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.022.01-.023.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.153l-.077.054-.08.054-.083.053-.085.053-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.048-.105.048-.106.048-.109.046-.111.046-.114.046-.115.044-.118.044-.12.043-.122.043-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.034-.143.034-.144.033-.147.032-.148.032-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.024-.161.024-.162.023-.163.023-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.01-.178.01-.179.009-.179.007-.181.006-.182.006-.182.004-.184.003-.184.001-.185.001-.185-.001-.184-.001-.184-.003-.182-.004-.182-.006-.181-.006-.179-.007-.179-.009-.178-.01-.176-.01-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.023-.162-.023-.161-.024-.159-.024-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.032-.146-.032-.145-.033-.143-.034-.141-.034-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.041-.126-.041-.124-.041-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.048-.105-.048-.102-.048-.1-.05-.097-.049-.095-.051-.093-.051-.09-.052-.087-.052-.085-.053-.083-.053-.08-.054-.077-.054v4.153zm8.74-8.179l-.257.004-.254.005-.25.008-.247.011-.244.012-.241.014-.237.016-.233.018-.231.021-.226.022-.224.023-.22.026-.216.027-.212.028-.21.031-.205.032-.202.033-.198.034-.194.036-.191.038-.187.038-.183.04-.179.041-.175.042-.172.043-.168.043-.163.045-.16.046-.155.046-.152.048-.148.048-.143.048-.139.049-.136.05-.131.05-.126.051-.123.051-.118.051-.114.052-.11.052-.106.052-.101.052-.096.052-.092.052-.088.052-.083.052-.079.052-.074.051-.07.052-.065.051-.06.05-.056.05-.051.05-.023.025-.023.024-.021.024-.02.025-.019.024-.018.024-.017.023-.015.024-.014.023-.013.023-.012.023-.01.023-.01.022-.008.022-.006.023-.006.021-.004.022-.004.021-.001.021-.001.021.001.021.001.021.004.021.004.022.006.021.006.023.008.022.01.022.01.023.012.023.013.023.014.023.015.024.017.023.018.024.019.024.02.025.021.024.023.024.023.025.051.05.056.05.06.05.065.051.07.052.074.051.079.052.083.052.088.052.092.052.096.052.101.052.106.052.11.052.114.052.118.051.123.051.126.051.131.05.136.05.139.049.143.048.148.048.152.048.155.046.16.046.163.045.168.043.172.043.175.042.179.041.183.04.187.038.191.038.194.036.198.034.202.033.205.032.21.031.212.028.216.027.22.026.224.023.226.022.231.021.233.018.237.016.241.014.244.012.247.011.25.008.254.005.257.004.26.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.022.224-.023.22-.026.216-.027.212-.028.21-.031.205-.032.202-.033.198-.034.194-.036.191-.038.187-.038.183-.04.179-.041.175-.042.172-.043.168-.043.163-.045.16-.046.155-.046.152-.048.148-.048.143-.048.139-.049.136-.05.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.05.051-.05.023-.025.023-.024.021-.024.02-.025.019-.024.018-.024.017-.023.015-.024.014-.023.013-.023.012-.023.01-.023.01-.022.008-.022.006-.023.006-.021.004-.022.004-.021.001-.021.001-.021-.001-.021-.001-.021-.004-.021-.004-.022-.006-.021-.006-.023-.008-.022-.01-.022-.01-.023-.012-.023-.013-.023-.014-.023-.015-.024-.017-.023-.018-.024-.019-.024-.02-.025-.021-.024-.023-.024-.023-.025-.051-.05-.056-.05-.06-.05-.065-.051-.07-.052-.074-.051-.079-.052-.083-.052-.088-.052-.092-.052-.096-.052-.101-.052-.106-.052-.11-.052-.114-.052-.118-.051-.123-.051-.126-.051-.131-.05-.136-.05-.139-.049-.143-.048-.148-.048-.152-.048-.155-.046-.16-.046-.163-.045-.168-.043-.172-.043-.175-.042-.179-.041-.183-.04-.187-.038-.191-.038-.194-.036-.198-.034-.202-.033-.205-.032-.21-.031-.212-.028-.216-.027-.22-.026-.224-.023-.226-.022-.231-.021-.233-.018-.237-.016-.241-.014-.244-.012-.247-.011-.25-.008-.254-.005-.257-.004-.26-.001-.26.001z"
  );
}, "insertDatabaseIcon"), Bs = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("symbol").attr("id", "computer").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr(
    "d",
    "M2 2v13h20v-13h-20zm18 11h-16v-9h16v9zm-10.228 6l.466-1h3.524l.467 1h-4.457zm14.228 3h-24l2-6h2.104l-1.33 4h18.45l-1.297-4h2.073l2 6zm-5-10h-14v-7h14v7z"
  );
}, "insertComputerIcon"), Vs = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("symbol").attr("id", "clock").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr(
    "d",
    "M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.848 12.459c.202.038.202.333.001.372-1.907.361-6.045 1.111-6.547 1.111-.719 0-1.301-.582-1.301-1.301 0-.512.77-5.447 1.125-7.445.034-.192.312-.181.343.014l.985 6.238 5.394 1.011z"
  );
}, "insertClockIcon"), Ys = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "arrowhead").attr("refX", 7.9).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M -1 0 L 10 5 L 0 10 z");
}, "insertArrowHead"), Ws = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "filled-head").attr("refX", 15.5).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "insertArrowFilledHead"), Ks = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "sequencenumber").attr("refX", 15).attr("refY", 15).attr("markerWidth", 60).attr("markerHeight", 40).attr("orient", "auto").append("circle").attr("cx", 15).attr("cy", 15).attr("r", 6);
}, "insertSequenceNumber"), Fs = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "crosshead").attr("markerWidth", 15).attr("markerHeight", 8).attr("orient", "auto").attr("refX", 4).attr("refY", 4.5).append("path").attr("fill", "none").attr("stroke", "#000000").style("stroke-dasharray", "0, 0").attr("stroke-width", "1pt").attr("d", "M 1,2 L 6,7 M 6,2 L 1,7");
}, "insertArrowCrossHead"), We = /* @__PURE__ */ _(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: void 0,
    style: "#666",
    width: void 0,
    height: void 0,
    textMargin: 0,
    rx: 0,
    ry: 0,
    tspan: !0,
    valign: void 0
  };
}, "getTextObj"), qs = /* @__PURE__ */ _(function() {
  return {
    x: 0,
    y: 0,
    fill: "#EDF2AE",
    stroke: "#666",
    width: 100,
    anchor: "start",
    height: 100,
    rx: 0,
    ry: 0
  };
}, "getNoteRect"), dt = /* @__PURE__ */ (function() {
  function e(n, o, h, l, r, E, p) {
    const f = o.append("text").attr("x", h + r / 2).attr("y", l + E / 2 + 5).style("text-anchor", "middle").text(n);
    i(f, p);
  }
  _(e, "byText");
  function t(n, o, h, l, r, E, p, f) {
    const { actorFontSize: u, actorFontFamily: y, actorFontWeight: R } = f, [b, w] = Ce(u), A = n.split(S.lineBreakRegex);
    for (let D = 0; D < A.length; D++) {
      const k = D * b - b * (A.length - 1) / 2, M = o.append("text").attr("x", h + r / 2).attr("y", l).style("text-anchor", "middle").style("font-size", w).style("font-weight", R).style("font-family", y);
      M.append("tspan").attr("x", h + r / 2).attr("dy", k).text(A[D]), M.attr("y", l + E / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), i(M, p);
    }
  }
  _(t, "byTspan");
  function a(n, o, h, l, r, E, p, f) {
    const u = o.append("switch"), R = u.append("foreignObject").attr("x", h).attr("y", l).attr("width", r).attr("height", E).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%");
    R.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(n), t(n, u, h, l, r, E, p, f), i(R, p);
  }
  _(a, "byFo");
  async function s(n, o, h, l, r, E, p, f) {
    const u = await Nt(n, Gt()), y = o.append("switch"), b = y.append("foreignObject").attr("x", h + r / 2 - u.width / 2).attr("y", l + E / 2 - u.height / 2).attr("width", u.width).attr("height", u.height).append("xhtml:div").style("height", "100%").style("width", "100%");
    b.append("div").style("text-align", "center").style("vertical-align", "middle").html(await Me(n, Gt())), t(n, y, h, l, r, E, p, f), i(b, p);
  }
  _(s, "byKatex");
  function i(n, o) {
    for (const h in o)
      o.hasOwnProperty(h) && n.attr(h, o[h]);
  }
  return _(i, "_setTextAttrs"), function(n, o = !1) {
    return o ? s : n.textPlacement === "fo" ? a : n.textPlacement === "old" ? e : t;
  };
})(), Hs = /* @__PURE__ */ (function() {
  function e(i, n, o, h, l, r, E) {
    const p = n.append("text").attr("x", o).attr("y", h).style("text-anchor", "start").text(i);
    s(p, E);
  }
  _(e, "byText");
  function t(i, n, o, h, l, r, E, p) {
    const { actorFontSize: f, actorFontFamily: u, actorFontWeight: y } = p, R = i.split(S.lineBreakRegex);
    for (let b = 0; b < R.length; b++) {
      const w = b * f - f * (R.length - 1) / 2, A = n.append("text").attr("x", o).attr("y", h).style("text-anchor", "start").style("font-size", f).style("font-weight", y).style("font-family", u);
      A.append("tspan").attr("x", o).attr("dy", w).text(R[b]), A.attr("y", h + r / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), s(A, E);
    }
  }
  _(t, "byTspan");
  function a(i, n, o, h, l, r, E, p) {
    const f = n.append("switch"), y = f.append("foreignObject").attr("x", o).attr("y", h).attr("width", l).attr("height", r).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%");
    y.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(i), t(i, f, o, h, l, r, E, p), s(y, E);
  }
  _(a, "byFo");
  function s(i, n) {
    for (const o in n)
      n.hasOwnProperty(o) && i.attr(o, n[o]);
  }
  return _(s, "_setTextAttrs"), function(i) {
    return i.textPlacement === "fo" ? a : i.textPlacement === "old" ? e : t;
  };
})(), zs = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "solidTopArrowHead").attr("refX", 7.9).attr("refY", 7.25).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 8 L 0 8 z");
}, "insertSolidTopArrowHead"), Us = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "solidBottomArrowHead").attr("refX", 7.9).attr("refY", 0.75).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 0 L 0 8 z");
}, "insertSolidBottomArrowHead"), Gs = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "stickTopArrowHead").attr("refX", 7.5).attr("refY", 7).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 7 7").attr("stroke", "black").attr("stroke-width", 1.5).attr("fill", "none");
}, "insertStickTopArrowHead"), Xs = /* @__PURE__ */ _(function(e) {
  e.append("defs").append("marker").attr("id", "stickBottomArrowHead").attr("refX", 7.5).attr("refY", 0).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 7 L 7 0").attr("stroke", "black").attr("stroke-width", 1.5).attr("fill", "none");
}, "insertStickBottomArrowHead"), Y = {
  drawRect: St,
  drawText: yt,
  drawLabel: Be,
  drawActor: Ps,
  drawBox: Ds,
  drawPopup: Os,
  anchorElement: ks,
  drawActivation: vs,
  drawLoop: Cs,
  drawBackgroundRect: Ye,
  insertArrowHead: Ys,
  insertArrowFilledHead: Ws,
  insertSequenceNumber: Ks,
  insertArrowCrossHead: Fs,
  insertDatabaseIcon: Ms,
  insertComputerIcon: Bs,
  insertClockIcon: Vs,
  getTextObj: We,
  getNoteRect: qs,
  fixLifeLineHeights: Ve,
  sanitizeUrl: ve.sanitizeUrl,
  insertSolidTopArrowHead: zs,
  insertSolidBottomArrowHead: Us,
  insertStickTopArrowHead: Gs,
  insertStickBottomArrowHead: Xs
}, d = {}, x = {
  data: {
    startx: void 0,
    stopx: void 0,
    starty: void 0,
    stopy: void 0
  },
  verticalPos: 0,
  sequenceItems: [],
  activations: [],
  models: {
    getHeight: /* @__PURE__ */ _(function() {
      return Math.max.apply(
        null,
        this.actors.length === 0 ? [0] : this.actors.map((e) => e.height || 0)
      ) + (this.loops.length === 0 ? 0 : this.loops.map((e) => e.height || 0).reduce((e, t) => e + t)) + (this.messages.length === 0 ? 0 : this.messages.map((e) => e.height || 0).reduce((e, t) => e + t)) + (this.notes.length === 0 ? 0 : this.notes.map((e) => e.height || 0).reduce((e, t) => e + t));
    }, "getHeight"),
    clear: /* @__PURE__ */ _(function() {
      this.actors = [], this.boxes = [], this.loops = [], this.messages = [], this.notes = [];
    }, "clear"),
    addBox: /* @__PURE__ */ _(function(e) {
      this.boxes.push(e);
    }, "addBox"),
    addActor: /* @__PURE__ */ _(function(e) {
      this.actors.push(e);
    }, "addActor"),
    addLoop: /* @__PURE__ */ _(function(e) {
      this.loops.push(e);
    }, "addLoop"),
    addMessage: /* @__PURE__ */ _(function(e) {
      this.messages.push(e);
    }, "addMessage"),
    addNote: /* @__PURE__ */ _(function(e) {
      this.notes.push(e);
    }, "addNote"),
    lastActor: /* @__PURE__ */ _(function() {
      return this.actors[this.actors.length - 1];
    }, "lastActor"),
    lastLoop: /* @__PURE__ */ _(function() {
      return this.loops[this.loops.length - 1];
    }, "lastLoop"),
    lastMessage: /* @__PURE__ */ _(function() {
      return this.messages[this.messages.length - 1];
    }, "lastMessage"),
    lastNote: /* @__PURE__ */ _(function() {
      return this.notes[this.notes.length - 1];
    }, "lastNote"),
    actors: [],
    boxes: [],
    loops: [],
    messages: [],
    notes: []
  },
  init: /* @__PURE__ */ _(function() {
    this.sequenceItems = [], this.activations = [], this.models.clear(), this.data = {
      startx: void 0,
      stopx: void 0,
      starty: void 0,
      stopy: void 0
    }, this.verticalPos = 0, qe(et());
  }, "init"),
  updateVal: /* @__PURE__ */ _(function(e, t, a, s) {
    e[t] === void 0 ? e[t] = a : e[t] = s(a, e[t]);
  }, "updateVal"),
  updateBounds: /* @__PURE__ */ _(function(e, t, a, s) {
    const i = this;
    let n = 0;
    function o(h) {
      return /* @__PURE__ */ _(function(r) {
        n++;
        const E = i.sequenceItems.length - n + 1;
        i.updateVal(r, "starty", t - E * d.boxMargin, Math.min), i.updateVal(r, "stopy", s + E * d.boxMargin, Math.max), i.updateVal(x.data, "startx", e - E * d.boxMargin, Math.min), i.updateVal(x.data, "stopx", a + E * d.boxMargin, Math.max), h !== "activation" && (i.updateVal(r, "startx", e - E * d.boxMargin, Math.min), i.updateVal(r, "stopx", a + E * d.boxMargin, Math.max), i.updateVal(x.data, "starty", t - E * d.boxMargin, Math.min), i.updateVal(x.data, "stopy", s + E * d.boxMargin, Math.max));
      }, "updateItemBounds");
    }
    _(o, "updateFn"), this.sequenceItems.forEach(o()), this.activations.forEach(o("activation"));
  }, "updateBounds"),
  insert: /* @__PURE__ */ _(function(e, t, a, s) {
    const i = S.getMin(e, a), n = S.getMax(e, a), o = S.getMin(t, s), h = S.getMax(t, s);
    this.updateVal(x.data, "startx", i, Math.min), this.updateVal(x.data, "starty", o, Math.min), this.updateVal(x.data, "stopx", n, Math.max), this.updateVal(x.data, "stopy", h, Math.max), this.updateBounds(i, o, n, h);
  }, "insert"),
  newActivation: /* @__PURE__ */ _(function(e, t, a) {
    const s = a.get(e.from), i = Yt(e.from).length || 0, n = s.x + s.width / 2 + (i - 1) * d.activationWidth / 2;
    this.activations.push({
      startx: n,
      starty: this.verticalPos + 2,
      stopx: n + d.activationWidth,
      stopy: void 0,
      actor: e.from,
      anchored: Y.anchorElement(t)
    });
  }, "newActivation"),
  endActivation: /* @__PURE__ */ _(function(e) {
    const t = this.activations.map(function(a) {
      return a.actor;
    }).lastIndexOf(e.from);
    return this.activations.splice(t, 1)[0];
  }, "endActivation"),
  createLoop: /* @__PURE__ */ _(function(e = { message: void 0, wrap: !1, width: void 0 }, t) {
    return {
      startx: void 0,
      starty: this.verticalPos,
      stopx: void 0,
      stopy: void 0,
      title: e.message,
      wrap: e.wrap,
      width: e.width,
      height: 0,
      fill: t
    };
  }, "createLoop"),
  newLoop: /* @__PURE__ */ _(function(e = { message: void 0, wrap: !1, width: void 0 }, t) {
    this.sequenceItems.push(this.createLoop(e, t));
  }, "newLoop"),
  endLoop: /* @__PURE__ */ _(function() {
    return this.sequenceItems.pop();
  }, "endLoop"),
  isLoopOverlap: /* @__PURE__ */ _(function() {
    return this.sequenceItems.length ? this.sequenceItems[this.sequenceItems.length - 1].overlap : !1;
  }, "isLoopOverlap"),
  addSectionToLoop: /* @__PURE__ */ _(function(e) {
    const t = this.sequenceItems.pop();
    t.sections = t.sections || [], t.sectionTitles = t.sectionTitles || [], t.sections.push({ y: x.getVerticalPos(), height: 0 }), t.sectionTitles.push(e), this.sequenceItems.push(t);
  }, "addSectionToLoop"),
  saveVerticalPos: /* @__PURE__ */ _(function() {
    this.isLoopOverlap() && (this.savedVerticalPos = this.verticalPos);
  }, "saveVerticalPos"),
  resetVerticalPos: /* @__PURE__ */ _(function() {
    this.isLoopOverlap() && (this.verticalPos = this.savedVerticalPos);
  }, "resetVerticalPos"),
  bumpVerticalPos: /* @__PURE__ */ _(function(e) {
    this.verticalPos = this.verticalPos + e, this.data.stopy = S.getMax(this.data.stopy, this.verticalPos);
  }, "bumpVerticalPos"),
  getVerticalPos: /* @__PURE__ */ _(function() {
    return this.verticalPos;
  }, "getVerticalPos"),
  getBounds: /* @__PURE__ */ _(function() {
    return { bounds: this.data, models: this.models };
  }, "getBounds")
}, Js = /* @__PURE__ */ _(async function(e, t) {
  x.bumpVerticalPos(d.boxMargin), t.height = d.boxMargin, t.starty = x.getVerticalPos();
  const a = lt();
  a.x = t.startx, a.y = t.starty, a.width = t.width || d.width, a.class = "note";
  const s = e.append("g"), i = Y.drawRect(s, a), n = Qt();
  n.x = t.startx, n.y = t.starty, n.width = a.width, n.dy = "1em", n.text = t.message, n.class = "noteText", n.fontFamily = d.noteFontFamily, n.fontSize = d.noteFontSize, n.fontWeight = d.noteFontWeight, n.anchor = d.noteAlign, n.textMargin = d.noteMargin, n.valign = "center";
  const o = U(n.text) ? await Mt(s, n) : yt(s, n), h = Math.round(
    o.map((l) => (l._groups || l)[0][0].getBBox().height).reduce((l, r) => l + r)
  );
  i.attr("height", h + 2 * d.noteMargin), t.height += h + 2 * d.noteMargin, x.bumpVerticalPos(h + 2 * d.noteMargin), t.stopy = t.starty + h + 2 * d.noteMargin, t.stopx = t.startx + a.width, x.insert(t.startx, t.starty, t.stopx, t.stopy), x.models.addNote(t);
}, "drawNote"), Zs = /* @__PURE__ */ _(function(e, t, a, s, i, n, o) {
  const h = s.db.getActors(), l = h.get(t.from), r = h.get(t.to), E = a.sequenceVisible;
  let p = l.x + l.width / 2, f = r.x + r.width / 2;
  const u = p <= f, y = Ge(t, s), R = e.append("g"), b = 16.5, w = /* @__PURE__ */ _((W, K) => {
    const H = W ? b : -b;
    return K ? -H : H;
  }, "getCircleOffset"), A = /* @__PURE__ */ _((W) => {
    R.append("circle").attr("cx", W).attr("cy", o).attr("r", 5).attr("width", 10).attr("height", 10);
  }, "drawCircle"), { CENTRAL_CONNECTION: D, CENTRAL_CONNECTION_REVERSE: k, CENTRAL_CONNECTION_DUAL: M } = s.db.LINETYPE;
  if (E)
    switch (t.centralConnection) {
      case D:
        y && (f += w(u, !0));
        break;
      case k:
        y || (p += w(u, !1));
        break;
      case M:
        y ? f += w(u, !0) : p += w(u, !1);
        break;
    }
  switch (t.centralConnection) {
    case D:
      A(f);
      break;
    case k:
      A(p);
      break;
    case M:
      A(p), A(f);
      break;
  }
}, "drawCentralConnection"), xt = /* @__PURE__ */ _((e) => ({
  fontFamily: e.messageFontFamily,
  fontSize: e.messageFontSize,
  fontWeight: e.messageFontWeight
}), "messageFont"), Rt = /* @__PURE__ */ _((e) => ({
  fontFamily: e.noteFontFamily,
  fontSize: e.noteFontSize,
  fontWeight: e.noteFontWeight
}), "noteFont"), Jt = /* @__PURE__ */ _((e) => ({
  fontFamily: e.actorFontFamily,
  fontSize: e.actorFontSize,
  fontWeight: e.actorFontWeight
}), "actorFont");
async function Ke(e, t) {
  x.bumpVerticalPos(10);
  const { startx: a, stopx: s, message: i } = t, n = S.splitBreaks(i).length, o = U(i), h = o ? await Nt(i, et()) : q.calculateTextDimensions(i, xt(d));
  if (!o) {
    const p = h.height / n;
    t.height += p, x.bumpVerticalPos(p);
  }
  let l, r = h.height - 10;
  const E = h.width;
  if (a === s) {
    l = x.getVerticalPos() + r, d.rightAngles || (r += d.boxMargin, l = x.getVerticalPos() + r), r += 30;
    const p = S.getMax(E / 2, d.width / 2);
    x.insert(
      a - p,
      x.getVerticalPos() - 10 + r,
      s + p,
      x.getVerticalPos() + 30 + r
    );
  } else
    r += d.boxMargin, l = x.getVerticalPos() + r, x.insert(a, l - 10, s, l);
  return x.bumpVerticalPos(r), t.height += r, t.stopy = t.starty + t.height, x.insert(t.fromBounds, t.starty, t.toBounds, t.stopy), l;
}
_(Ke, "boundMessage");
var Qs = /* @__PURE__ */ _(async function(e, t, a, s, i) {
  const { startx: n, stopx: o, starty: h, message: l, type: r, sequenceIndex: E, sequenceVisible: p } = t, f = q.calculateTextDimensions(l, xt(d)), u = Qt();
  u.x = n, u.y = h + 10, u.width = o - n, u.class = "messageText", u.dy = "1em", u.text = l, u.fontFamily = d.messageFontFamily, u.fontSize = d.messageFontSize, u.fontWeight = d.messageFontWeight, u.anchor = d.messageAlign, u.valign = "center", u.textMargin = d.wrapPadding, u.tspan = !1, U(u.text) ? await Mt(e, u, { startx: n, stopx: o, starty: a }) : yt(e, u);
  const y = f.width;
  let R;
  if (n === o) {
    const w = p || d.showSequenceNumbers, A = Ge(i, s), D = ar(i, s), k = n + (w && (A || D) ? 10 : 0);
    d.rightAngles ? R = e.append("path").attr(
      "d",
      `M  ${k},${a} H ${n + S.getMax(d.width / 2, y / 2)} V ${a + 25} H ${n}`
    ) : R = e.append("path").attr(
      "d",
      "M " + k + "," + a + " C " + (k + 60) + "," + (a - 10) + " " + (n + 60) + "," + (a + 30) + " " + n + "," + (a + 20)
    );
  } else
    R = e.append("line"), R.attr("x1", n), R.attr("y1", a), R.attr("x2", o), R.attr("y2", a), ke(i, s) && Zs(e, i, t, s, n, o, a);
  r === s.db.LINETYPE.DOTTED || r === s.db.LINETYPE.DOTTED_CROSS || r === s.db.LINETYPE.DOTTED_POINT || r === s.db.LINETYPE.DOTTED_OPEN || r === s.db.LINETYPE.BIDIRECTIONAL_DOTTED || r === s.db.LINETYPE.SOLID_TOP_DOTTED || r === s.db.LINETYPE.SOLID_BOTTOM_DOTTED || r === s.db.LINETYPE.STICK_TOP_DOTTED || r === s.db.LINETYPE.STICK_BOTTOM_DOTTED || r === s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED || r === s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED || r === s.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED || r === s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED ? (R.style("stroke-dasharray", "3, 3"), R.attr("class", "messageLine1")) : R.attr("class", "messageLine0");
  let b = "";
  if (d.arrowMarkerAbsolute && (b = ds(!0)), R.attr("stroke-width", 2), R.attr("stroke", "none"), R.style("fill", "none"), (r === s.db.LINETYPE.SOLID_TOP || r === s.db.LINETYPE.SOLID_TOP_DOTTED) && R.attr("marker-end", "url(" + b + "#solidTopArrowHead)"), (r === s.db.LINETYPE.SOLID_BOTTOM || r === s.db.LINETYPE.SOLID_BOTTOM_DOTTED) && R.attr("marker-end", "url(" + b + "#solidBottomArrowHead)"), (r === s.db.LINETYPE.STICK_TOP || r === s.db.LINETYPE.STICK_TOP_DOTTED) && R.attr("marker-end", "url(" + b + "#stickTopArrowHead)"), (r === s.db.LINETYPE.STICK_BOTTOM || r === s.db.LINETYPE.STICK_BOTTOM_DOTTED) && R.attr("marker-end", "url(" + b + "#stickBottomArrowHead)"), (r === s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE || r === s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED) && R.attr("marker-start", "url(" + b + "#solidBottomArrowHead)"), (r === s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE || r === s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED) && R.attr("marker-start", "url(" + b + "#solidTopArrowHead)"), (r === s.db.LINETYPE.STICK_ARROW_TOP_REVERSE || r === s.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED) && R.attr("marker-start", "url(" + b + "#stickBottomArrowHead)"), (r === s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE || r === s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED) && R.attr("marker-start", "url(" + b + "#stickTopArrowHead)"), (r === s.db.LINETYPE.SOLID || r === s.db.LINETYPE.DOTTED) && R.attr("marker-end", "url(" + b + "#arrowhead)"), (r === s.db.LINETYPE.BIDIRECTIONAL_SOLID || r === s.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (R.attr("marker-start", "url(" + b + "#arrowhead)"), R.attr("marker-end", "url(" + b + "#arrowhead)")), (r === s.db.LINETYPE.SOLID_POINT || r === s.db.LINETYPE.DOTTED_POINT) && R.attr("marker-end", "url(" + b + "#filled-head)"), (r === s.db.LINETYPE.SOLID_CROSS || r === s.db.LINETYPE.DOTTED_CROSS) && R.attr("marker-end", "url(" + b + "#crosshead)"), p || d.showSequenceNumbers) {
    const w = r === s.db.LINETYPE.BIDIRECTIONAL_SOLID || r === s.db.LINETYPE.BIDIRECTIONAL_DOTTED, A = r === s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE || r === s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED || r === s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE || r === s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED || r === s.db.LINETYPE.STICK_ARROW_TOP_REVERSE || r === s.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED || r === s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE || r === s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED, D = 6, k = ke(i, s);
    let M = n, W = o;
    w ? (n < o ? M = n + D * 2 : (M = n - D + (k ? -5 : 0), M += i?.centralConnection === s.db.LINETYPE.CENTRAL_CONNECTION_DUAL || i?.centralConnection === s.db.LINETYPE.CENTRAL_CONNECTION_REVERSE ? -7.5 : 0), R.attr("x1", M)) : A ? (o > n ? W = o - 2 * D : (W = o - D, M += i?.centralConnection === s.db.LINETYPE.CENTRAL_CONNECTION_DUAL || i?.centralConnection === s.db.LINETYPE.CENTRAL_CONNECTION_REVERSE ? -7.5 : 0), W += k ? 15 : 0, R.attr("x2", W), R.attr("x1", M)) : R.attr("x1", n + D);
    let K = 0;
    const H = n === o, G = n <= o;
    H ? K = t.fromBounds + 1 : A ? K = G ? t.toBounds - 1 : t.fromBounds + 1 : K = G ? t.fromBounds + 1 : t.toBounds - 1, e.append("line").attr("x1", K).attr("y1", a).attr("x2", K).attr("y2", a).attr("stroke-width", 0).attr("marker-start", "url(" + b + "#sequencenumber)"), e.append("text").attr("x", K).attr("y", a + 4).attr("font-family", "sans-serif").attr("font-size", "12px").attr("text-anchor", "middle").attr("class", "sequenceNumber").text(E);
  }
}, "drawMessage"), $s = /* @__PURE__ */ _(function(e, t, a, s, i, n, o) {
  let h = 0, l = 0, r, E = 0;
  for (const p of s) {
    const f = t.get(p), u = f.box;
    r && r != u && (o || x.models.addBox(r), l += d.boxMargin + r.margin), u && u != r && (o || (u.x = h + l, u.y = i), l += u.margin), f.width = f.width || d.width, f.height = S.getMax(f.height || d.height, d.height), f.margin = f.margin || d.actorMargin, E = S.getMax(E, f.height), a.get(f.name) && (l += f.width / 2), f.x = h + l, f.starty = x.getVerticalPos(), x.insert(f.x, i, f.x + f.width, f.height), h += f.width + l, f.box && (f.box.width = h + u.margin - f.box.x), l = f.margin, r = f.box, x.models.addActor(f);
  }
  r && !o && x.models.addBox(r), x.bumpVerticalPos(E);
}, "addActorRenderingData"), Zt = /* @__PURE__ */ _(async function(e, t, a, s) {
  if (s) {
    let i = 0;
    x.bumpVerticalPos(d.boxMargin * 2);
    for (const n of a) {
      const o = t.get(n);
      o.stopy || (o.stopy = x.getVerticalPos());
      const h = await Y.drawActor(e, o, d, !0);
      i = S.getMax(i, h);
    }
    x.bumpVerticalPos(i + d.boxMargin);
  } else
    for (const i of a) {
      const n = t.get(i);
      await Y.drawActor(e, n, d, !1);
    }
}, "drawActors"), Fe = /* @__PURE__ */ _(function(e, t, a, s) {
  let i = 0, n = 0;
  for (const o of a) {
    const h = t.get(o), l = tr(h), r = Y.drawPopup(
      e,
      h,
      l,
      d,
      d.forceMenus,
      s
    );
    r.height > i && (i = r.height), r.width + h.x > n && (n = r.width + h.x);
  }
  return { maxHeight: i, maxWidth: n };
}, "drawActorsPopup"), qe = /* @__PURE__ */ _(function(e) {
  es(d, e), e.fontFamily && (d.actorFontFamily = d.noteFontFamily = d.messageFontFamily = e.fontFamily), e.fontSize && (d.actorFontSize = d.noteFontSize = d.messageFontSize = e.fontSize), e.fontWeight && (d.actorFontWeight = d.noteFontWeight = d.messageFontWeight = e.fontWeight);
}, "setConf"), Yt = /* @__PURE__ */ _(function(e) {
  return x.activations.filter(function(t) {
    return t.actor === e;
  });
}, "actorActivations"), De = /* @__PURE__ */ _(function(e, t) {
  const a = t.get(e), s = Yt(e), i = s.reduce(
    function(o, h) {
      return S.getMin(o, h.startx);
    },
    a.x + a.width / 2 - 1
  ), n = s.reduce(
    function(o, h) {
      return S.getMax(o, h.stopx);
    },
    a.x + a.width / 2 + 1
  );
  return [i, n];
}, "activationBounds");
function ct(e, t, a, s, i) {
  x.bumpVerticalPos(a);
  let n = s;
  if (t.id && t.message && e[t.id]) {
    const o = e[t.id].width, h = xt(d);
    t.message = q.wrapLabel(`[${t.message}]`, o - 2 * d.wrapPadding, h), t.width = o, t.wrap = !0;
    const l = q.calculateTextDimensions(t.message, h), r = S.getMax(l.height, d.labelBoxHeight);
    n = s + r, Q.debug(`${r} - ${t.message}`);
  }
  i(t), x.bumpVerticalPos(n);
}
_(ct, "adjustLoopHeightForWrap");
function He(e, t, a, s, i, n, o) {
  function h(E, p) {
    E.x < i.get(e.from).x ? (x.insert(
      t.stopx - p,
      t.starty,
      t.startx,
      t.stopy + E.height / 2 + d.noteMargin
    ), t.stopx = t.stopx + p) : (x.insert(
      t.startx,
      t.starty,
      t.stopx + p,
      t.stopy + E.height / 2 + d.noteMargin
    ), t.stopx = t.stopx - p);
  }
  _(h, "receiverAdjustment");
  function l(E, p) {
    E.x < i.get(e.to).x ? (x.insert(
      t.startx - p,
      t.starty,
      t.stopx,
      t.stopy + E.height / 2 + d.noteMargin
    ), t.startx = t.startx + p) : (x.insert(
      t.stopx,
      t.starty,
      t.startx + p,
      t.stopy + E.height / 2 + d.noteMargin
    ), t.startx = t.startx - p);
  }
  _(l, "senderAdjustment");
  const r = [
    Ct.ACTOR,
    Ct.CONTROL,
    Ct.ENTITY,
    Ct.DATABASE
  ];
  if (n.get(e.to) == s) {
    const E = i.get(e.to), p = r.includes(E.type) ? ft / 2 + 3 : E.width / 2 + 3;
    h(E, p), E.starty = a - E.height / 2, x.bumpVerticalPos(E.height / 2);
  } else if (o.get(e.from) == s) {
    const E = i.get(e.from);
    if (d.mirrorActors) {
      const p = r.includes(E.type) ? ft / 2 : E.width / 2;
      l(E, p);
    }
    E.stopy = a - E.height / 2, x.bumpVerticalPos(E.height / 2);
  } else if (o.get(e.to) == s) {
    const E = i.get(e.to);
    if (d.mirrorActors) {
      const p = r.includes(E.type) ? ft / 2 + 3 : E.width / 2 + 3;
      h(E, p);
    }
    E.stopy = a - E.height / 2, x.bumpVerticalPos(E.height / 2);
  }
}
_(He, "adjustCreatedDestroyedData");
var js = /* @__PURE__ */ _(async function(e, t, a, s) {
  const { securityLevel: i, sequence: n } = et();
  d = n;
  let o;
  i === "sandbox" && (o = kt("#i" + t));
  const h = i === "sandbox" ? kt(o.nodes()[0].contentDocument.body) : kt("body"), l = i === "sandbox" ? o.nodes()[0].contentDocument : document;
  x.init(), Q.debug(s.db);
  const r = i === "sandbox" ? h.select(`[id="${t}"]`) : kt(`[id="${t}"]`), E = s.db.getActors(), p = s.db.getCreatedActors(), f = s.db.getDestroyedActors(), u = s.db.getBoxes();
  let y = s.db.getActorKeys();
  const R = s.db.getMessages(), b = s.db.getDiagramTitle(), w = s.db.hasAtLeastOneBox(), A = s.db.hasAtLeastOneBoxWithTitle(), D = await ze(E, R, s);
  if (d.height = await Ue(E, D, u), Y.insertComputerIcon(r), Y.insertDatabaseIcon(r), Y.insertClockIcon(r), w && (x.bumpVerticalPos(d.boxMargin), A && x.bumpVerticalPos(u[0].textMaxHeight)), d.hideUnusedParticipants === !0) {
    const O = /* @__PURE__ */ new Set();
    R.forEach((I) => {
      O.add(I.from), O.add(I.to);
    }), y = y.filter((I) => O.has(I));
  }
  $s(r, E, p, y, 0, R, !1);
  const k = await nr(R, E, D, s);
  Y.insertArrowHead(r), Y.insertArrowCrossHead(r), Y.insertArrowFilledHead(r), Y.insertSequenceNumber(r), Y.insertSolidTopArrowHead(r), Y.insertSolidBottomArrowHead(r), Y.insertStickTopArrowHead(r), Y.insertStickBottomArrowHead(r);
  function M(O, I) {
    const nt = x.endActivation(O);
    nt.starty + 18 > I && (nt.starty = I - 6, I += 12), Y.drawActivation(
      r,
      nt,
      I,
      d,
      Yt(O.from).length
    ), x.insert(nt.startx, I - 10, nt.stopx, I);
  }
  _(M, "activeEnd");
  let W = 1, K = 1;
  const H = [], G = [];
  let X = 0;
  for (const O of R) {
    let I, nt, ot;
    switch (O.type) {
      case s.db.LINETYPE.NOTE:
        x.resetVerticalPos(), nt = O.noteModel, await Js(r, nt);
        break;
      case s.db.LINETYPE.ACTIVE_START:
        x.newActivation(O, r, E);
        break;
      case s.db.LINETYPE.CENTRAL_CONNECTION:
        x.newActivation(O, r, E);
        break;
      case s.db.LINETYPE.CENTRAL_CONNECTION_REVERSE:
        x.newActivation(O, r, E);
        break;
      case s.db.LINETYPE.ACTIVE_END:
        M(O, x.getVerticalPos());
        break;
      case s.db.LINETYPE.LOOP_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin + d.boxTextMargin,
          (C) => x.newLoop(C)
        );
        break;
      case s.db.LINETYPE.LOOP_END:
        I = x.endLoop(), await Y.drawLoop(r, I, "loop", d), x.bumpVerticalPos(I.stopy - x.getVerticalPos()), x.models.addLoop(I);
        break;
      case s.db.LINETYPE.RECT_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin,
          (C) => x.newLoop(void 0, C.message)
        );
        break;
      case s.db.LINETYPE.RECT_END:
        I = x.endLoop(), G.push(I), x.models.addLoop(I), x.bumpVerticalPos(I.stopy - x.getVerticalPos());
        break;
      case s.db.LINETYPE.OPT_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin + d.boxTextMargin,
          (C) => x.newLoop(C)
        );
        break;
      case s.db.LINETYPE.OPT_END:
        I = x.endLoop(), await Y.drawLoop(r, I, "opt", d), x.bumpVerticalPos(I.stopy - x.getVerticalPos()), x.models.addLoop(I);
        break;
      case s.db.LINETYPE.ALT_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin + d.boxTextMargin,
          (C) => x.newLoop(C)
        );
        break;
      case s.db.LINETYPE.ALT_ELSE:
        ct(
          k,
          O,
          d.boxMargin + d.boxTextMargin,
          d.boxMargin,
          (C) => x.addSectionToLoop(C)
        );
        break;
      case s.db.LINETYPE.ALT_END:
        I = x.endLoop(), await Y.drawLoop(r, I, "alt", d), x.bumpVerticalPos(I.stopy - x.getVerticalPos()), x.models.addLoop(I);
        break;
      case s.db.LINETYPE.PAR_START:
      case s.db.LINETYPE.PAR_OVER_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin + d.boxTextMargin,
          (C) => x.newLoop(C)
        ), x.saveVerticalPos();
        break;
      case s.db.LINETYPE.PAR_AND:
        ct(
          k,
          O,
          d.boxMargin + d.boxTextMargin,
          d.boxMargin,
          (C) => x.addSectionToLoop(C)
        );
        break;
      case s.db.LINETYPE.PAR_END:
        I = x.endLoop(), await Y.drawLoop(r, I, "par", d), x.bumpVerticalPos(I.stopy - x.getVerticalPos()), x.models.addLoop(I);
        break;
      case s.db.LINETYPE.AUTONUMBER:
        W = O.message.start || W, K = O.message.step || K, O.message.visible ? s.db.enableSequenceNumbers() : s.db.disableSequenceNumbers();
        break;
      case s.db.LINETYPE.CRITICAL_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin + d.boxTextMargin,
          (C) => x.newLoop(C)
        );
        break;
      case s.db.LINETYPE.CRITICAL_OPTION:
        ct(
          k,
          O,
          d.boxMargin + d.boxTextMargin,
          d.boxMargin,
          (C) => x.addSectionToLoop(C)
        );
        break;
      case s.db.LINETYPE.CRITICAL_END:
        I = x.endLoop(), await Y.drawLoop(r, I, "critical", d), x.bumpVerticalPos(I.stopy - x.getVerticalPos()), x.models.addLoop(I);
        break;
      case s.db.LINETYPE.BREAK_START:
        ct(
          k,
          O,
          d.boxMargin,
          d.boxMargin + d.boxTextMargin,
          (C) => x.newLoop(C)
        );
        break;
      case s.db.LINETYPE.BREAK_END:
        I = x.endLoop(), await Y.drawLoop(r, I, "break", d), x.bumpVerticalPos(I.stopy - x.getVerticalPos()), x.models.addLoop(I);
        break;
      default:
        try {
          ot = O.msgModel, ot.starty = x.getVerticalPos(), ot.sequenceIndex = W, ot.sequenceVisible = s.db.showSequenceNumbers();
          const C = await Ke(r, ot);
          He(
            O,
            ot,
            C,
            X,
            E,
            p,
            f
          ), H.push({ messageModel: ot, lineStartY: C, msg: O }), x.models.addMessage(ot);
        } catch (C) {
          Q.error("error while drawing message", C);
        }
    }
    [
      s.db.LINETYPE.SOLID_OPEN,
      s.db.LINETYPE.DOTTED_OPEN,
      s.db.LINETYPE.SOLID,
      s.db.LINETYPE.SOLID_TOP,
      s.db.LINETYPE.SOLID_BOTTOM,
      s.db.LINETYPE.STICK_TOP,
      s.db.LINETYPE.STICK_BOTTOM,
      s.db.LINETYPE.SOLID_TOP_DOTTED,
      s.db.LINETYPE.SOLID_BOTTOM_DOTTED,
      s.db.LINETYPE.STICK_TOP_DOTTED,
      s.db.LINETYPE.STICK_BOTTOM_DOTTED,
      s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
      s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE,
      s.db.LINETYPE.STICK_ARROW_TOP_REVERSE,
      s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE,
      s.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
      s.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
      s.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED,
      s.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED,
      s.db.LINETYPE.DOTTED,
      s.db.LINETYPE.SOLID_CROSS,
      s.db.LINETYPE.DOTTED_CROSS,
      s.db.LINETYPE.SOLID_POINT,
      s.db.LINETYPE.DOTTED_POINT,
      s.db.LINETYPE.BIDIRECTIONAL_SOLID,
      s.db.LINETYPE.BIDIRECTIONAL_DOTTED
    ].includes(O.type) && (W = W + K), X++;
  }
  Q.debug("createdActors", p), Q.debug("destroyedActors", f), await Zt(r, E, y, !1);
  for (const O of H)
    await Qs(r, O.messageModel, O.lineStartY, s, O.msg);
  d.mirrorActors && await Zt(r, E, y, !0), G.forEach((O) => Y.drawBackgroundRect(r, O)), Ve(r, E, y, d);
  for (const O of x.models.boxes) {
    O.height = x.getVerticalPos() - O.y, x.insert(O.x, O.y, O.x + O.width, O.height);
    const I = d.boxMargin * 2;
    O.startx = O.x - I, O.starty = O.y - I * 0.25, O.stopx = O.startx + O.width + 2 * I, O.stopy = O.starty + O.height + I * 0.75, O.stroke = "rgb(0,0,0, 0.5)", Y.drawBox(r, O, d);
  }
  w && x.bumpVerticalPos(d.boxMargin);
  const z = Fe(r, E, y, l), { bounds: v } = x.getBounds();
  v.startx === void 0 && (v.startx = 0), v.starty === void 0 && (v.starty = 0), v.stopx === void 0 && (v.stopx = 0), v.stopy === void 0 && (v.stopy = 0);
  let $ = v.stopy - v.starty;
  $ < z.maxHeight && ($ = z.maxHeight);
  let J = $ + 2 * d.diagramMarginY;
  d.mirrorActors && (J = J - d.boxMargin + d.bottomMarginAdj);
  let j = v.stopx - v.startx;
  j < z.maxWidth && (j = z.maxWidth);
  const st = j + 2 * d.diagramMarginX;
  b && r.append("text").text(b).attr("x", (v.stopx - v.startx) / 2 - 2 * d.diagramMarginX).attr("y", -25), ts(r, J, st, d.useMaxWidth);
  const rt = b ? 40 : 0;
  r.attr(
    "viewBox",
    v.startx - d.diagramMarginX + " -" + (d.diagramMarginY + rt) + " " + st + " " + (J + rt)
  ), Q.debug("models:", x.models);
}, "draw");
async function ze(e, t, a) {
  const s = {};
  for (const i of t)
    if (e.get(i.to) && e.get(i.from)) {
      const n = e.get(i.to);
      if (i.placement === a.db.PLACEMENT.LEFTOF && !n.prevActor || i.placement === a.db.PLACEMENT.RIGHTOF && !n.nextActor)
        continue;
      const o = i.placement !== void 0, h = !o, l = o ? Rt(d) : xt(d), r = i.wrap ? q.wrapLabel(i.message, d.width - 2 * d.wrapPadding, l) : i.message, p = (U(r) ? await Nt(i.message, et()) : q.calculateTextDimensions(r, l)).width + 2 * d.wrapPadding;
      h && i.from === n.nextActor ? s[i.to] = S.getMax(
        s[i.to] || 0,
        p
      ) : h && i.from === n.prevActor ? s[i.from] = S.getMax(
        s[i.from] || 0,
        p
      ) : h && i.from === i.to ? (s[i.from] = S.getMax(
        s[i.from] || 0,
        p / 2
      ), s[i.to] = S.getMax(
        s[i.to] || 0,
        p / 2
      )) : i.placement === a.db.PLACEMENT.RIGHTOF ? s[i.from] = S.getMax(
        s[i.from] || 0,
        p
      ) : i.placement === a.db.PLACEMENT.LEFTOF ? s[n.prevActor] = S.getMax(
        s[n.prevActor] || 0,
        p
      ) : i.placement === a.db.PLACEMENT.OVER && (n.prevActor && (s[n.prevActor] = S.getMax(
        s[n.prevActor] || 0,
        p / 2
      )), n.nextActor && (s[i.from] = S.getMax(
        s[i.from] || 0,
        p / 2
      )));
    }
  return Q.debug("maxMessageWidthPerActor:", s), s;
}
_(ze, "getMaxMessageWidthPerActor");
var tr = /* @__PURE__ */ _(function(e) {
  let t = 0;
  const a = Jt(d);
  for (const s in e.links) {
    const n = q.calculateTextDimensions(s, a).width + 2 * d.wrapPadding + 2 * d.boxMargin;
    t < n && (t = n);
  }
  return t;
}, "getRequiredPopupWidth");
async function Ue(e, t, a) {
  let s = 0;
  for (const n of e.keys()) {
    const o = e.get(n);
    o.wrap && (o.description = q.wrapLabel(
      o.description,
      d.width - 2 * d.wrapPadding,
      Jt(d)
    ));
    const h = U(o.description) ? await Nt(o.description, et()) : q.calculateTextDimensions(o.description, Jt(d));
    o.width = o.wrap ? d.width : S.getMax(d.width, h.width + 2 * d.wrapPadding), o.height = o.wrap ? S.getMax(h.height, d.height) : d.height, s = S.getMax(s, o.height);
  }
  for (const n in t) {
    const o = e.get(n);
    if (!o)
      continue;
    const h = e.get(o.nextActor);
    if (!h) {
      const p = t[n] + d.actorMargin - o.width / 2;
      o.margin = S.getMax(p, d.actorMargin);
      continue;
    }
    const r = t[n] + d.actorMargin - o.width / 2 - h.width / 2;
    o.margin = S.getMax(r, d.actorMargin);
  }
  let i = 0;
  return a.forEach((n) => {
    const o = xt(d);
    let h = n.actorKeys.reduce((p, f) => p += e.get(f).width + (e.get(f).margin || 0), 0);
    const l = d.boxMargin * 8;
    h += l, h -= 2 * d.boxTextMargin, n.wrap && (n.name = q.wrapLabel(n.name, h - 2 * d.wrapPadding, o));
    const r = q.calculateTextDimensions(n.name, o);
    i = S.getMax(r.height, i);
    const E = S.getMax(h, r.width + 2 * d.wrapPadding);
    if (n.margin = d.boxTextMargin, h < E) {
      const p = (E - h) / 2;
      n.margin += p;
    }
  }), a.forEach((n) => n.textMaxHeight = i), S.getMax(s, d.height);
}
_(Ue, "calculateActorMargins");
var er = /* @__PURE__ */ _(async function(e, t, a) {
  const s = t.get(e.from), i = t.get(e.to), n = s.x, o = i.x, h = e.wrap && e.message;
  let l = U(e.message) ? await Nt(e.message, et()) : q.calculateTextDimensions(
    h ? q.wrapLabel(e.message, d.width, Rt(d)) : e.message,
    Rt(d)
  );
  const r = {
    width: h ? d.width : S.getMax(d.width, l.width + 2 * d.noteMargin),
    height: 0,
    startx: s.x,
    stopx: 0,
    starty: 0,
    stopy: 0,
    message: e.message
  };
  return e.placement === a.db.PLACEMENT.RIGHTOF ? (r.width = h ? S.getMax(d.width, l.width) : S.getMax(
    s.width / 2 + i.width / 2,
    l.width + 2 * d.noteMargin
  ), r.startx = n + (s.width + d.actorMargin) / 2) : e.placement === a.db.PLACEMENT.LEFTOF ? (r.width = h ? S.getMax(d.width, l.width + 2 * d.noteMargin) : S.getMax(
    s.width / 2 + i.width / 2,
    l.width + 2 * d.noteMargin
  ), r.startx = n - r.width + (s.width - d.actorMargin) / 2) : e.to === e.from ? (l = q.calculateTextDimensions(
    h ? q.wrapLabel(e.message, S.getMax(d.width, s.width), Rt(d)) : e.message,
    Rt(d)
  ), r.width = h ? S.getMax(d.width, s.width) : S.getMax(s.width, d.width, l.width + 2 * d.noteMargin), r.startx = n + (s.width - r.width) / 2) : (r.width = Math.abs(n + s.width / 2 - (o + i.width / 2)) + d.actorMargin, r.startx = n < o ? n + s.width / 2 - d.actorMargin / 2 : o + i.width / 2 - d.actorMargin / 2), h && (r.message = q.wrapLabel(
    e.message,
    r.width - 2 * d.wrapPadding,
    Rt(d)
  )), Q.debug(
    `NM:[${r.startx},${r.stopx},${r.starty},${r.stopy}:${r.width},${r.height}=${e.message}]`
  ), r;
}, "buildNoteModel"), sr = 4, ke = /* @__PURE__ */ _(function(e, t) {
  const { CENTRAL_CONNECTION: a, CENTRAL_CONNECTION_REVERSE: s, CENTRAL_CONNECTION_DUAL: i } = t.db.LINETYPE;
  return [a, s, i].includes(
    e.centralConnection
  );
}, "hasCentralConnection"), rr = /* @__PURE__ */ _(function(e, t, a) {
  const {
    CENTRAL_CONNECTION_REVERSE: s,
    CENTRAL_CONNECTION_DUAL: i,
    BIDIRECTIONAL_SOLID: n,
    BIDIRECTIONAL_DOTTED: o
  } = t.db.LINETYPE;
  let h = 0;
  return (e.centralConnection === s || e.centralConnection === i) && (h += sr), (e.centralConnection === s || e.centralConnection === i) && (e.type === n || e.type === o) && (h += a ? 0 : -6), h;
}, "calculateCentralConnectionOffset"), Ge = /* @__PURE__ */ _(function(e, t) {
  const {
    SOLID_ARROW_TOP_REVERSE: a,
    SOLID_ARROW_TOP_REVERSE_DOTTED: s,
    SOLID_ARROW_BOTTOM_REVERSE: i,
    SOLID_ARROW_BOTTOM_REVERSE_DOTTED: n,
    STICK_ARROW_TOP_REVERSE: o,
    STICK_ARROW_TOP_REVERSE_DOTTED: h,
    STICK_ARROW_BOTTOM_REVERSE: l,
    STICK_ARROW_BOTTOM_REVERSE_DOTTED: r
  } = t.db.LINETYPE;
  return [
    a,
    s,
    i,
    n,
    o,
    h,
    l,
    r
  ].includes(e.type);
}, "isReverseArrowType"), ar = /* @__PURE__ */ _(function(e, t) {
  const { BIDIRECTIONAL_SOLID: a, BIDIRECTIONAL_DOTTED: s } = t.db.LINETYPE;
  return [a, s].includes(e.type);
}, "isBidirectionalArrowType"), ir = /* @__PURE__ */ _(function(e, t, a) {
  if (![
    a.db.LINETYPE.SOLID_OPEN,
    a.db.LINETYPE.DOTTED_OPEN,
    a.db.LINETYPE.SOLID,
    a.db.LINETYPE.SOLID_TOP,
    a.db.LINETYPE.SOLID_BOTTOM,
    a.db.LINETYPE.STICK_TOP,
    a.db.LINETYPE.STICK_BOTTOM,
    a.db.LINETYPE.SOLID_TOP_DOTTED,
    a.db.LINETYPE.SOLID_BOTTOM_DOTTED,
    a.db.LINETYPE.STICK_TOP_DOTTED,
    a.db.LINETYPE.STICK_BOTTOM_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
    a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE,
    a.db.LINETYPE.STICK_ARROW_TOP_REVERSE,
    a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE,
    a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
    a.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED,
    a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED,
    a.db.LINETYPE.DOTTED,
    a.db.LINETYPE.SOLID_CROSS,
    a.db.LINETYPE.DOTTED_CROSS,
    a.db.LINETYPE.SOLID_POINT,
    a.db.LINETYPE.DOTTED_POINT,
    a.db.LINETYPE.BIDIRECTIONAL_SOLID,
    a.db.LINETYPE.BIDIRECTIONAL_DOTTED
  ].includes(e.type))
    return {};
  const [s, i] = De(e.from, t), [n, o] = De(e.to, t), h = s <= n;
  let l = h ? i : s, r = h ? n : o;
  l += rr(e, a, h);
  const E = Math.abs(n - o) > 2, p = /* @__PURE__ */ _((R) => h ? -R : R, "adjustValue");
  e.from === e.to ? r = l : (e.activate && !E && (r += p(d.activationWidth / 2 - 1)), [
    a.db.LINETYPE.SOLID_OPEN,
    a.db.LINETYPE.DOTTED_OPEN,
    a.db.LINETYPE.STICK_TOP,
    a.db.LINETYPE.STICK_BOTTOM,
    a.db.LINETYPE.STICK_TOP_DOTTED,
    a.db.LINETYPE.STICK_BOTTOM_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
    a.db.LINETYPE.STICK_ARROW_TOP_REVERSE,
    a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE,
    a.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED,
    a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
    a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE
  ].includes(e.type) || (r += p(3)), [
    a.db.LINETYPE.BIDIRECTIONAL_SOLID,
    a.db.LINETYPE.BIDIRECTIONAL_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED,
    a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE,
    a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE
  ].includes(e.type) && (l -= p(3)));
  const f = [s, i, n, o], u = Math.abs(l - r);
  e.wrap && e.message && (e.message = q.wrapLabel(
    e.message,
    S.getMax(u + 2 * d.wrapPadding, d.width),
    xt(d)
  ));
  const y = q.calculateTextDimensions(e.message, xt(d));
  return {
    width: S.getMax(
      e.wrap ? 0 : y.width + 2 * d.wrapPadding,
      u + 2 * d.wrapPadding,
      d.width
    ),
    height: 0,
    startx: l,
    stopx: r,
    starty: 0,
    stopy: 0,
    message: e.message,
    type: e.type,
    wrap: e.wrap,
    fromBounds: Math.min.apply(null, f),
    toBounds: Math.max.apply(null, f)
  };
}, "buildMessageModel"), nr = /* @__PURE__ */ _(async function(e, t, a, s) {
  const i = {}, n = [];
  let o, h, l;
  for (const r of e) {
    switch (r.type) {
      case s.db.LINETYPE.LOOP_START:
      case s.db.LINETYPE.ALT_START:
      case s.db.LINETYPE.OPT_START:
      case s.db.LINETYPE.PAR_START:
      case s.db.LINETYPE.PAR_OVER_START:
      case s.db.LINETYPE.CRITICAL_START:
      case s.db.LINETYPE.BREAK_START:
        n.push({
          id: r.id,
          msg: r.message,
          from: Number.MAX_SAFE_INTEGER,
          to: Number.MIN_SAFE_INTEGER,
          width: 0
        });
        break;
      case s.db.LINETYPE.ALT_ELSE:
      case s.db.LINETYPE.PAR_AND:
      case s.db.LINETYPE.CRITICAL_OPTION:
        r.message && (o = n.pop(), i[o.id] = o, i[r.id] = o, n.push(o));
        break;
      case s.db.LINETYPE.LOOP_END:
      case s.db.LINETYPE.ALT_END:
      case s.db.LINETYPE.OPT_END:
      case s.db.LINETYPE.PAR_END:
      case s.db.LINETYPE.CRITICAL_END:
      case s.db.LINETYPE.BREAK_END:
        o = n.pop(), i[o.id] = o;
        break;
      case s.db.LINETYPE.ACTIVE_START:
        {
          const p = t.get(r.from ? r.from : r.to.actor), f = Yt(r.from ? r.from : r.to.actor).length, u = p.x + p.width / 2 + (f - 1) * d.activationWidth / 2, y = {
            startx: u,
            stopx: u + d.activationWidth,
            actor: r.from,
            enabled: !0
          };
          x.activations.push(y);
        }
        break;
      case s.db.LINETYPE.ACTIVE_END:
        {
          const p = x.activations.map((f) => f.actor).lastIndexOf(r.from);
          x.activations.splice(p, 1).splice(0, 1);
        }
        break;
    }
    r.placement !== void 0 ? (h = await er(r, t, s), r.noteModel = h, n.forEach((p) => {
      o = p, o.from = S.getMin(o.from, h.startx), o.to = S.getMax(o.to, h.startx + h.width), o.width = S.getMax(o.width, Math.abs(o.from - o.to)) - d.labelBoxWidth;
    })) : (l = ir(r, t, s), r.msgModel = l, l.startx && l.stopx && n.length > 0 && n.forEach((p) => {
      if (o = p, l.startx === l.stopx) {
        const f = t.get(r.from), u = t.get(r.to);
        o.from = S.getMin(
          f.x - l.width / 2,
          f.x - f.width / 2,
          o.from
        ), o.to = S.getMax(
          u.x + l.width / 2,
          u.x + f.width / 2,
          o.to
        ), o.width = S.getMax(o.width, Math.abs(o.to - o.from)) - d.labelBoxWidth;
      } else
        o.from = S.getMin(l.startx, o.from), o.to = S.getMax(l.stopx, o.to), o.width = S.getMax(o.width, l.width) - d.labelBoxWidth;
    }));
  }
  return x.activations = [], Q.debug("Loop type widths:", i), i;
}, "calculateLoopBounds"), or = {
  bounds: x,
  drawActors: Zt,
  drawActorsPopup: Fe,
  setConf: qe,
  draw: js
}, dr = {
  parser: us,
  get db() {
    return new xs();
  },
  renderer: or,
  styles: Rs,
  init: /* @__PURE__ */ _((e) => {
    e.sequence || (e.sequence = {}), e.wrap && (e.sequence.wrap = e.wrap, je({ sequence: { wrap: e.wrap } }));
  }, "init")
};
export {
  dr as diagram
};
