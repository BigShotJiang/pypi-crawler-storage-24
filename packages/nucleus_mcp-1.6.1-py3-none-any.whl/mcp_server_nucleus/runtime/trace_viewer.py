"""DSoR Trace Viewer — Browse and inspect decision trails.

Provides CLI access to Decision System of Record (DSoR) traces:
  - List all decisions with summary
  - View detailed decision by ID
  - Query related context nodes from the graph
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional

from .dsor import DecisionLedger
from .context_graph import ContextGraph

logger = logging.getLogger("nucleus.trace_viewer")


def list_traces(brain_path: Path, trace_type: Optional[str] = None) -> Dict[str, Any]:
    """List all DSoR traces in the brain using DecisionLedger."""
    ledger = DecisionLedger(brain_path)
    all_decisions = ledger.list_all()
    
    traces = []
    for d in all_decisions:
        if trace_type and d.get("intent") != trace_type:
            continue
        traces.append({
            "decision_id": d["decision_id"],
            "intent": d["intent"],
            "timestamp": d["timestamp"],
            "reasoning": d["reasoning"],
            "confidence": d.get("confidence", 1.0)
        })

    return {
        "count": len(traces),
        "traces": sorted(traces, key=lambda x: x["timestamp"], reverse=True),
        "types": list(set(t["intent"] for t in traces)),
    }


def get_trace(brain_path: Path, trace_id: str) -> Optional[Dict[str, Any]]:
    """Get a specific decision and its context from the graph."""
    ledger = DecisionLedger(brain_path)
    graph = ContextGraph(brain_path)
    
    entry = ledger.get_decision(trace_id)
    if not entry:
        return None
        
    data = entry.to_dict()
    # Fetch related nodes from graph
    data["related_context"] = graph.get_related(trace_id)
    
    return data


def format_trace_list(data: Dict) -> str:
    """Format decision list for terminal output."""
    lines = []
    lines.append("")
    lines.append("  📜 NUCLEUS DECISION LEDGER (DSoR)")
    lines.append("  " + "=" * 65)

    if data["count"] == 0:
        lines.append("    (No decisions recorded in ledger)")
        lines.append("")
        return "\n".join(lines)

    lines.append(f"  Total: {data['count']} decisions | Types: {', '.join(data.get('types', []))}")
    lines.append("")

    for t in data["traces"]:
        icon = "🧠" if "heal" in t["intent"] else "🎯"
        ts = t["timestamp"].replace("T", " ")[:19]
        lines.append(f"  {icon}  {t['decision_id']} [{t['intent']}]")
        lines.append(f"     Time: {ts} | Confidence: {t['confidence']}")
        lines.append(f"     Reason: {t['reasoning'][:70]}...")
        lines.append("")

    lines.append(f"  View detail: nucleus trace view <DECISION_ID>")
    lines.append("")
    return "\n".join(lines)


def format_trace_detail(trace: Dict) -> str:
    """Format a single decision for detailed terminal output."""
    lines = []
    intent = trace.get("intent", "UNKNOWN")
    icon = "🧠" if "heal" in trace.get("intent", "") else "🎯"

    lines.append("")
    lines.append("  " + "=" * 70)
    lines.append(f"  {icon}  DSoR DECISION — {trace.get('decision_id', 'Unknown')}")
    lines.append("  " + "=" * 70)
    lines.append("")
    lines.append(f"  Intent:         {intent}")
    lines.append(f"  Timestamp:      {trace.get('timestamp', 'N/A')}")
    lines.append(f"  Confidence:     {trace.get('confidence', 1.0)}")
    lines.append(f"  Context Hash:   {trace.get('context_hash', 'N/A')}")
    lines.append("")
    lines.append("  REASONING:")
    lines.append(f"  {trace.get('reasoning', 'No reasoning provided.')}")
    lines.append("")

    # Related Context
    related = trace.get("related_context", [])
    if related:
        lines.append("  CONNECTED CONTEXT (Graph):")
        lines.append("  " + "-" * 60)
        for edge in related:
            # edge is a dict from edges.jsonl
            other_node = edge["target_id"] if edge["source_id"] == trace["decision_id"] else edge["source_id"]
            rel = edge["relationship"]
            weight = edge.get("weight", 1.0)
            lines.append(f"    - [{rel}] -> {other_node} (weight: {weight})")
        lines.append("")

    # Metadata
    metadata = trace.get("metadata", {})
    if metadata:
        lines.append("  METADATA:")
        for k, v in metadata.items():
            lines.append(f"    {k}: {v}")
        lines.append("")

    lines.append("  " + "=" * 70)
    lines.append("")
    return "\n".join(lines)


def get_interference_report(brain_path: Path, node_id: str) -> Dict[str, Any]:
    """Analyze context graph for interferences with node_id."""
    graph = ContextGraph(brain_path)
    interferences = graph.check_interference(node_id)
    
    return {
        "node_id": node_id,
        "count": len(interferences),
        "interferences": interferences
    }


def format_interference_report(report: Dict) -> str:
    """Format interference report for terminal output."""
    lines = []
    lines.append("")
    lines.append("  🚨 NUCLEUS CROSS-CONTEXT INTERFERENCE DETECTED")
    lines.append("  " + "=" * 70)
    lines.append(f"  Target Node: {report['node_id']}")
    lines.append("")

    if report["count"] == 0:
        lines.append("    ✅ No active context interference detected.")
        lines.append("")
        return "\n".join(lines)

    lines.append(f"  Found {report['count']} potential conflicts:")
    lines.append("")
    
    # Sort by weight descending
    sorted_interf = sorted(report["interferences"], key=lambda x: x["weight"], reverse=True)
    
    for item in sorted_interf:
        lines.append(f"    - Interfering Node: {item['interfering_node_id']}")
        lines.append(f"      Shared Context:   {item['shared_context_node']}")
        lines.append(f"      Link Weight:      {item['weight']}")
        lines.append(f"      Relationship:     {item['relationship']}")
        lines.append("")

    lines.append("  " + "=" * 70)
    lines.append("  Recommendation: Audit shared context nodes for logical race conditions.")
    lines.append("")
    return "\n".join(lines)
