"""
Nucleus Runtime - Common Utilities
==================================
Shared utilities and constants for the Nucleus runtime.
"""

import os
import json
import logging
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Optional

# ============================================================
# STRUCTURED LOGGING SYSTEM (AG-010)
# ============================================================

class JSONFormatter(logging.Formatter):
    """Formats log records as JSON objects for machine readability."""
    def format(self, record):
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "line": record.lineno
        }
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry)

def setup_nucleus_logging(name: str = "nucleus", level: int = logging.INFO):
    """Setup structured logging for a component."""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Avoid duplicate handlers
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        
        # Use JSON if specified via env
        if os.environ.get("NUCLEUS_LOG_JSON", "false").lower() == "true":
            handler.setFormatter(JSONFormatter())
        else:
            handler.setFormatter(logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            ))
        
        logger.addHandler(handler)
    return logger

# Common logger
logger = setup_nucleus_logging()

def get_nucleus_bin_path() -> str:
    """Dynamically resolve the best PATH addition for the nucleus binary."""
    import shutil
    # 1. Try shutil.which
    nucleus_bin = shutil.which("nucleus")
    if nucleus_bin:
        return str(Path(nucleus_bin).parent)

    # 2. Fallback to common Python user-base bin
    try:
        import site
        user_bin = Path(site.getuserbase()) / "bin"
        if user_bin.exists():
            return str(user_bin)
    except Exception:
        pass
    
    # 3. Final fallback: sibling of the current python executable
    return str(Path(sys.executable).parent)

def get_brain_path() -> Path:
    """Adaptive Discovery: Get brain path from environment, parents, or home."""
    # Priority 1: Environment Variables
    env_brain = os.environ.get("NUCLEUS_BRAIN_PATH") or os.environ.get("NUCLEAR_BRAIN_PATH")
    if env_brain:
        path = Path(env_brain).resolve()
        # Don't strictly require existence here, as some commands might want to init it
        return path
    
    # Priority 2: Walk up from CWD
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        potential = parent / ".brain"
        if potential.is_dir():
            return potential.resolve()
            
    # Priority 3: Default Home Location
    default_home = Path.home() / ".nucleus" / "brain"
    return default_home.resolve()

def get_brain_tmp_path() -> Path:
    """Get the sovereign temporary directory within the brain."""
    brain = get_brain_path()
    tmp = brain / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    return tmp

def assert_path_in_workspace(path: str, workspace_root: Optional[str] = None) -> Path:
    """
    Enforce Path Confinement (Phase 14/17).
    Resolves 'path' and ensures it is contained within 'workspace_root'.
    
    Repository-Awareness (Phase 17):
    If workspace_root is None, it defaults to the project root (parent of .brain)
    if a .brain folder exists. Otherwise, it defaults to get_brain_path().
    
    Raises:
        PermissionError: If the path is outside the workspace.
    """
    if not workspace_root:
        brain_path = get_brain_path()
        # If .brain exists and is a directory, the repo root is its parent
        if brain_path.name == ".brain" and brain_path.is_dir():
            workspace_root = str(brain_path.parent)
        else:
            workspace_root = str(brain_path)
            
    ws_abspath = Path(workspace_root).resolve()
    target_path = Path(path)
    
    # If path is relative, join it with workspace root BEFORE resolving
    # This prevents relative paths like "f1.txt" from being resolved against CWD
    if not target_path.is_absolute():
        target_abspath = (ws_abspath / target_path).resolve()
    else:
        target_abspath = target_path.resolve()
    
    # Check if target is a subpath of workspace
    try:
        # On macOS, /var is often a symlink to /private/var. 
        # resolve() handles this, but we compare the resolved strings to be safe.
        target_str = str(target_abspath)
        ws_str = str(ws_abspath)
        
        # Ensure ws_str ends with a separator for prefix matching if needed,
        # but relative_to is cleaner.
        target_abspath.relative_to(ws_abspath)
    except ValueError:
        # relative_to raises ValueError if target is not under workspace
        raise PermissionError(f"🔒 WORKSPACE ESCAPE BLOCKED: Path '{path}' (resolved: {target_abspath}) is outside authorized workspace '{workspace_root}'")
        
    return target_abspath

def make_response(success: bool, data=None, error=None, error_code=None):
    """Standardized API response formatter.
    
    Args:
        success: Whether the operation succeeded
        data: Successful payload (dict, list, string)
        error: Error message if failed
        error_code: Optional short code for error (e.g. ERR_NOT_FOUND)
    
    Returns:
        JSON string matching Nucleus Standard Response Schema
    """
    return json.dumps({
        "success": success,
        "data": data,
        "error": error,
        "error_code": error_code,
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    }, indent=2)

def _get_state(path: Optional[str] = None) -> Dict:
    """Core logic for getting state."""
    try:
        brain = get_brain_path()
        state_path = brain / "ledger" / "state.json"
        
        if not state_path.exists():
            return {}
            
        from .sync_ops import sync_lock
        with sync_lock(brain, timeout=2):
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            
        if path:
            keys = path.split('.')
            val = state
            for k in keys:
                val = val.get(k, {})
            return val
            
        return state
    except Exception as e:
        logger.error(f"Error reading state: {e}")
        return {}

def _update_state(updates: Dict[str, Any]) -> str:
    """Core logic for updating state."""
    try:
        brain = get_brain_path()
        state_path = brain / "ledger" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        
        from .sync_ops import sync_lock
        with sync_lock(brain, timeout=5):
            current_state = {}
            if state_path.exists():
                with open(state_path, "r", encoding="utf-8") as f:
                    current_state = json.load(f)
            
            current_state.update(updates)
            
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(current_state, f, indent=2, ensure_ascii=False)
            
        return "State updated successfully"
    except Exception as e:
        return f"Error updating state: {str(e)}"
# ============================================================
# MOCK MCP SERVER (For fallback/verification mode)
# ============================================================

class MockMCP:
    """Mock FastMCP server for when the package is not installed."""
    def tool(self, *args, **kwargs):
        def decorator(f): return f
        return decorator
    def resource(self, *args, **kwargs):
        def decorator(f): return f
        return decorator
    def prompt(self, *args, **kwargs):
        def decorator(f): return f
        return decorator
    def run(self):
        pass
