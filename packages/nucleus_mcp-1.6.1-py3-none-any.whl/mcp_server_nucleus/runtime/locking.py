"""
BrainLock: The Atomic Safety Layer for Nucleus.
This module defines the locking primitives used to ensure data integrity across
multiple Nucleus processes (Daemon, CLI, MCP Server).

Strategic Role:
- Ensures "Atomic State" (The Brain doesn't hallucinate due to race conditions).
- Implements "Leased Locks" (Prevents deadlocks if a process crashes).
- Future-Proofing: Abstract base class allows swapping 'fcntl' for 'Redis' later.
"""

import abc
from datetime import datetime, timezone
try:
    import fcntl
except ImportError:
    fcntl = None

try:
    import msvcrt
except ImportError:
    msvcrt = None
import time
import os
import contextlib
import logging
import subprocess
import shutil
from pathlib import Path
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)

class BrainLock(abc.ABC):
    """
    Abstract Base Class for Nucleus Locking.
    Enforces the 'LockProvider' interface for Cloud/Local agnosticism.
    """
    
    @abc.abstractmethod
    def acquire(self, timeout: float = 5.0, metadata: Optional[Dict[str, str]] = None) -> bool:
        """Attempt to acquire the lock. Returns True if successful."""
        pass

    @abc.abstractmethod
    def release(self) -> None:
        """Release the lock."""
        pass

    @abc.abstractmethod
    def get_metadata(self) -> Dict[str, Any]:
        """Retrieve metadata associated with the lock."""
        pass

    def check_stale_locks(self, max_age_seconds: float = 3600):
        """Optional: Check for and cleanup stale locks."""
        pass


    @contextlib.contextmanager
    def section(self, timeout: float = 5.0, metadata: Optional[Dict[str, str]] = None):
        """Context manager for critical sections."""
        acquired = self.acquire(timeout, metadata=metadata)
        if not acquired:
            raise TimeoutError(f"Could not acquire lock on {self} after {timeout}s")
        try:
            yield
        finally:
            self.release()

class FileBrainLock(BrainLock):
    """
    Local Implementation using UNIX `fcntl` + `xattr` for metadata.
    Used for the 'Local First' Sovereign OS.
    """
    
    def __init__(self, lock_path: str):
        self.lock_path = Path(lock_path)
        self.lock_file = None
        # Ensure directory exists
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        self.xattr_available = shutil.which("xattr") is not None

    def _set_xattr(self, key: str, value: str):
        """Writes extended attribute if xattr is available."""
        if not self.xattr_available:
            return
        
        try:
            subprocess.run(
                ["xattr", "-w", key, str(value), str(self.lock_path)],
                check=True,
                capture_output=True
            )
        except subprocess.CalledProcessError as e:
            logger.warning(f"Failed to set xattr {key}: {e}")

    def _get_xattr(self, key: str) -> Optional[str]:
        """Reads extended attribute if xattr is available."""
        if not self.xattr_available:
            return None
            
        try:
            result = subprocess.run(
                ["xattr", "-p", key, str(self.lock_path)],
                check=True,
                capture_output=True,
                text=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return None

    def _list_xattrs(self) -> List[str]:
        """Lists all xattrs on the file."""
        if not self.xattr_available:
            return []
            
        try:
            result = subprocess.run(
                ["xattr", str(self.lock_path)],
                check=True,
                capture_output=True,
                text=True
            )
            return result.stdout.strip().split("\n")
        except subprocess.CalledProcessError:
            return []

    def acquire(self, timeout: float = 5.0, metadata: Optional[Dict[str, str]] = None) -> bool:
        start_time = time.time()
        
        # Open the file if not already open
        if self.lock_file is None:
            self.lock_file = open(self.lock_path, 'w+', encoding='utf-8')

        # Phase 22: Pre-emptive Stale Cleanup
        # If the file exists and we can confirm the holder is dead, clear it now.
        if self.lock_path.exists():
            self.cleanup_stale()

        while True:
            try:
                # specific locking operation: LOCK_EX (Exclusive) | LOCK_NB (Non-Blocking)
                if fcntl:
                    fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                elif msvcrt:
                    self.lock_file.seek(0)
                    msvcrt.locking(self.lock_file.fileno(), msvcrt.LK_NBLCK, 1)
                
                # Write PID for debugging (knowing who holds the lock)
                self.lock_file.seek(0)
                self.lock_file.truncate()
                self.lock_file.write(str(os.getpid()))
                self.lock_file.flush()
                
                # --- METADATA INJECTION (Phase 28) ---
                if metadata:
                    # Always include timestamp if not present
                    if "timestamp" not in metadata:
                        metadata["timestamp"] = datetime.now(timezone.utc).isoformat()
                        
                    for k, v in metadata.items():
                        # Namespace keys with 'nucleus.lock.' if not already
                        key = k if k.startswith("nucleus.lock.") else f"nucleus.lock.{k}"
                        self._set_xattr(key, v)
                
                return True
            except (IOError, OSError):
                # Lock is held by another process
                if datetime.now(timezone.utc).timestamp() - start_time > timeout:
                    # Final attempt: check if it became stale during our wait
                    if self.cleanup_stale():
                         # Try one last time
                         try:
                             if fcntl: fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                             return True
                         except: pass
                    logger.warning(f"Timeout waiting for lock: {self.lock_path}")
                    return False
                time.sleep(0.1)

    def release(self) -> None:
        if self.lock_file:
            try:
                # Unlock
                if fcntl:
                    fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_UN)
                elif msvcrt:
                    self.lock_file.seek(0)
                    msvcrt.locking(self.lock_file.fileno(), msvcrt.LK_UNLCK, 1)
                self.lock_file.close()
            except ValueError:
                # File might be closed already
                pass
            finally:
                self.lock_file = None

    def get_metadata(self) -> Dict[str, Any]:
        """Retrieve metadata associated with the lock (PID from file + xattrs)."""
        metadata = {}
        if self.lock_path.exists():
            try:
                # Read PID from file content
                content = self.lock_path.read_text().strip()
                if content:
                    metadata["pid"] = content
                
                # Read xattrs
                for attr in self._list_xattrs():
                    if attr.startswith("nucleus.lock."):
                        val = self._get_xattr(attr)
                        if val:
                            key = attr.replace("nucleus.lock.", "")
                            metadata[key] = val
            except Exception as e:
                logger.warning(f"Failed to read lock metadata: {e}")
        return metadata

    def is_process_alive(self, pid: int) -> bool:
        """Check if a process with the given PID is actually running."""
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ValueError):
            return False

    def check_stale_locks(self, max_age_seconds: float = 86400) -> Dict[str, Any]:
        """
        Check for stale lock files by verifying the holder's PID.
        Returns a report on the lock status.
        """
        if not self.lock_path.exists():
            return {"state": "vacant"}

        metadata = self.get_metadata()
        pid_str = metadata.get("pid", "unknown")
        
        try:
            pid = int(pid_str)
            if self.is_process_alive(pid):
                return {"state": "held", "pid": pid, "status": "active"}
            else:
                return {"state": "stale", "pid": pid, "status": "process_dead"}
        except (ValueError, TypeError):
            # If PID is not an int or "unknown", and it's old, it's likely stale
            stat = self.lock_path.stat()
            age = datetime.now(timezone.utc).timestamp() - stat.st_mtime
            if age > 60: # 1 minute grace period for invalid content
                return {"state": "stale", "status": "invalid_content"}
            return {"state": "uncertain", "status": "locking_in_progress"}

    def cleanup_stale(self) -> bool:
        """
        Forcefully remove a lock if it's confirmed to be stale.
        Strategic Role: Part of the 'EnvironmentGuard' cleanup sequence.
        """
        report = self.check_stale_locks()
        if report["state"] == "stale":
            try:
                self.lock_path.unlink()
                logger.info(f"🗑️ Stale lock cleared: {self.lock_path}")
                return True
            except Exception as e:
                logger.error(f"Failed to clear stale lock: {e}")
        return False

    def __repr__(self):
        return f"<FileBrainLock: {self.lock_path}>"

# Factory Function for easy usage
def get_lock(resource_name: str, base_dir: Optional[Path] = None) -> BrainLock:
    """
    Factory to get the appropriate lock for a resource.
    Currently defaults to FileBrainLock.
    """
    if base_dir is None:
        # Priority 1: Explicit Env Var
        env_lock_dir = os.environ.get("NUCLEUS_LOCK_DIR")
        if env_lock_dir:
            base_dir = Path(env_lock_dir)
        else:
            # Priority 2: Standard Brain Location (.brain/.locks)
            try:
                from .common import get_brain_path
                base_dir = get_brain_path().resolve() / ".locks"
            except (ImportError, AttributeError):
                # Fallback to home-based locks if common discovery is not available
                base_dir = Path.home() / ".nucleus" / "locks"
    
    lock_path = base_dir / f"{resource_name}.lock"
    return FileBrainLock(str(lock_path))
