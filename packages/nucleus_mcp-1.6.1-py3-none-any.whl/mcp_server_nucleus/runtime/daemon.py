
"""
Nucleus Daemon Manager.
The Kernel service that runs the persistent background agent.

Strategic Role:
- Lifecycle Management: Startup, Shutdown, Signal Handling.
- process Safety: Enforces BrainLock to ensure only one Daemon runs.
- Heartbeat: Updates status for the HUD.
"""

import asyncio
import signal
import sys
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict
import time
import httpx

from .locking import get_lock, BrainLock
from .policy import DirectivesLoader
from .orchestrator import SwarmsOrchestrator
from .hooks import IdentityKey, AmbientTelemetry, InsightExchange, RemoteExecutionProtocol

# Logger is initialized in start()
logger = logging.getLogger("NucleusDaemon")

def setup_daemon_logging(brain_path: Path):
    """Configure structured logging for the daemon rooted in the brain."""
    log_dir = brain_path / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "daemon.log"
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
        handlers=[
            logging.StreamHandler(sys.stderr),
            logging.FileHandler(log_file)
        ],
        force=True  # Clear existing handlers
    )

class DaemonManager:
    def __init__(self, brain_path: Path):
        self.brain_path = brain_path
        self.lock: Optional[BrainLock] = None
        self.running = False
        self.policy_engine = DirectivesLoader(brain_path)
        self.orchestrator = SwarmsOrchestrator(brain_path)
        
        # Strategic Hooks (The Billion Dollar Extensions)
        self.identity = IdentityKey(brain_path)
        self.pulse = AmbientTelemetry(brain_path, identity=self.identity)
        self.insight_exchange = InsightExchange(brain_path)
        self.grid = RemoteExecutionProtocol(brain_path)
        
    @dataclass
    class HealthReport:
        status: str  # "healthy", "unhealthy", "degraded"
        components: Dict[str, Dict[str, Any]]
        timestamp: float

    async def get_status(self) -> HealthReport:
        """
        Perform an active health check of the Nucleus environment.
        Strategic Role: Discovered by EnvironmentGuard to prevent 'Dead Loop' execution.
        """
        components = {}
        
        # 1. Check BrainLock
        lock_meta = {}
        if self.lock:
            lock_meta = self.lock.get_metadata()
            components["brain_lock"] = {"state": "held", "pid": lock_meta.get("pid")}
        else:
            components["brain_lock"] = {"state": "released"}

        # 2. Check Proxy Liveness (Active Ping)
        proxy_health = await self._check_proxy_liveness()
        components["gemini_proxy"] = proxy_health

        # 3. Check Kernel Swarm Capacity
        components["kernel"] = {
            "active_swarms": len(self.orchestrator._active_missions),
            "state": "active" if self.running else "stopped"
        }

        overall_status = "healthy"
        if proxy_health["state"] != "online":
            overall_status = "degraded"
        if not self.running:
            overall_status = "unhealthy"

        return self.HealthReport(
            status=overall_status,
            components=components,
            timestamp=time.time()
        )

    async def _check_proxy_liveness(self) -> Dict[str, Any]:
        """Ping the gemini_proxy.py to ensure it's responsive."""
        # Use existing env or fallback
        import os
        base_url = os.environ.get("GEMINI_API_BASE_URL", "http://localhost:5056")
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                response = await client.get(f"{base_url}/api/health")
                if response.status_code == 200:
                    return {"state": "online", "latency": response.elapsed.total_seconds()}
                return {"state": "error", "code": response.status_code}
        except Exception as e:
            return {"state": "offline", "error": str(e)}

    async def start(self):
        """Start the Daemon sequence"""
        setup_daemon_logging(self.brain_path)
        logger.info("Nucleus Daemon Starting...")
        
        # 1. Acquire Lock
        lock_dir = self.brain_path / ".locks"
        self.lock = get_lock("daemon_process", base_dir=lock_dir)
        
        if not self.lock.acquire(timeout=1.0):
            logger.error("Could not acquire daemon lock. Is another instance running?")
            sys.exit(1)
            
        logger.info("🔒 BrainLock Acquired. I am the Sovereign Process.")
        self.running = True
        
        # 2. Setup Signals
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, lambda: asyncio.create_task(self.shutdown()))
            
        # 3. Load Policy
        policy = self.policy_engine.load_policy()
        logger.info(f"📜 Policy Loaded: Mode={policy.get('mode')}, Safety={policy.get('safety_level')}")
        
        # 4. Main Event Loop
        try:
            await self.main_loop()
        except asyncio.CancelledError:
            logger.info("Daemon cancelled.")
        except Exception as e:
            logger.exception(f"Daemon crashed: {e}")
        finally:
            await self.shutdown()

    async def main_loop(self):
        """The Core Preemptive Loop"""
        logger.info("🚀 Daemon is active. Entering Main Loop.")
        
        while self.running:
            # Heartbeat (The Ambient Pulse)
            status = "busy" if self.orchestrator._active_missions else "idle"
            self.pulse.beat(status, len(self.orchestrator._active_missions))
            logger.debug(f"❤️ Heartbeat ({status})")
            
            # Monitor Swarms
            active_count = len(self.orchestrator._active_missions)
            if active_count > 0:
                logger.info(f"🦾 Active Swarms: {active_count}")
            
            # TODO: Phase A Components
            # - Check AsyncFileWatcher
            # - Check Pending Commitments (SwarmsOrchestrator)
            
            # Simulation of work (Polling interval)
            # In future, this is replaced by Event triggers to avoid busy wait
            await asyncio.sleep(5) 
            
    async def shutdown(self):
        """Graceful Shutdown"""
        if not self.running:
            return
            
        logger.info("🛑 Shutdown initiated...")
        self.running = False
        
        # Release resources
        if self.lock:
            self.lock.release()
            logger.info("🔓 BrainLock Released.")
            
        # TODO: Close sockets, database connections
        
        logger.info("Daemon Stopped.")
        sys.exit(0)

def run_daemon():
    """Entry point for the daemon service"""
    from .common import get_brain_path
    brain_path = get_brain_path()
        
    daemon = DaemonManager(brain_path)
    try:
        asyncio.run(daemon.start())
    except KeyboardInterrupt:
        pass # Handled in handler
        
if __name__ == "__main__":
    run_daemon()
