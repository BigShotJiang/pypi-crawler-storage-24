from typing import List, Dict, Any
import os
import shlex
import subprocess
from pathlib import Path
from .base import Capability
from ..process_manager import SovereignProcess
from ..isolation_layer import EnvironmentSanitizer
from ..agent_runtime_v2 import get_execution_manager, CURRENT_AGENT_ID

# Command allowlist for code_run_command (shell injection prevention)
# Only base commands in this list may be executed via the NAR agent.
SAFE_COMMANDS = frozenset({
    'python3', 'python', 'node', 'npm', 'npx', 'pytest', 'git',
    'ls', 'cat', 'head', 'tail', 'grep', 'find', 'wc', 'diff',
    'echo', 'pwd', 'env', 'which', 'make', 'cargo', 'ruff',
    'pip', 'pip3', 'uv', 'poetry', 'gcloud', 'nucleus'
})

class CodeOps(Capability):
    @property
    def name(self) -> str:
        return "code_ops"

    @property
    def description(self) -> str:
        return "FileSystem and Shell Access for Coding Agents."

    def get_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": "code_read_file",
                "description": "Read file contents.",
                "parameters": {
                    "type": "object", 
                    "properties": {
                        "path": {"type": "string", "description": "Absolute or relative path"}
                    },
                    "required": ["path"]
                }
            },
            {
                "name": "code_write_file",
                "description": "Write or overwrite file contents. Creates directories if needed.",
                "parameters": {
                    "type": "object", 
                    "properties": {
                        "path": {"type": "string", "description": "Absolute or relative path"},
                        "content": {"type": "string"}
                    },
                    "required": ["path", "content"]
                }
            },
            {
                "name": "code_run_command",
                "description": "Execute a shell command.",
                "parameters": {
                    "type": "object", 
                    "properties": {
                        "command": {"type": "string"},
                        "timeout": {"type": "integer", "default": 30}
                    },
                    "required": ["command"]
                }
            },
            {
                "name": "code_list_files",
                "description": "List files in directory.",
                "parameters": {
                    "type": "object", 
                    "properties": {
                        "path": {"type": "string", "default": "."}
                    }
                }
            }
        ]

    def _resolve_path(self, path_str: str) -> Path:
        """
        Self-Healing Path Resolver with Sovereign Hardening.
        """
        cwd = Path(os.getcwd())
        path = Path(path_str)
        
        # 1. Try path as-is
        if path.exists():
            return path
            
        # 2. Try relative to CWD
        if not path.is_absolute():
            candidate = cwd / path
            if candidate.exists():
                return candidate
        
        # 3. Try relative to Project Root (BRAIN_PATH.parent) or Brain itself
        from .common import get_brain_path
        brain_path = get_brain_path().resolve()
        project_root = brain_path.parent
        
        if not path.is_absolute():
            # Try project root
            candidate = project_root / path
            if candidate.exists():
                return candidate
            # Try brain path itself
            candidate = brain_path / path
            if candidate.exists():
                return candidate
        else:
            # If absolute but invalid, try re-rooting to project or brain
            # e.g. /gentlequest-blog/... -> PROJECT_ROOT/gentlequest-blog/...
            path_str_clean = path_str.lstrip('/')
            
            # Re-root to project
            candidate = project_root / path_str_clean
            if candidate.exists():
                return candidate
                
            # Re-root to brain
            candidate = brain_path / path_str_clean
            if candidate.exists():
                return candidate
                
            # Legacy split-based re-rooting
            if 'ai-mvp-backend' in path_str:
                relative = path_str.split('ai-mvp-backend')[-1].lstrip('/')
                candidate = project_root / relative
                if candidate.exists():
                    return candidate

        return path

    def execute_tool(self, tool_name: str, args: Dict) -> str:
        """Execute local filesystem/shell operations."""
        cwd = os.getcwd()
        
        if tool_name == "code_read_file":
            path = self._resolve_path(args['path'])
            
            # Security: prevent path traversal outside project / home / brain
            resolved = path.resolve()
            from .common import get_brain_path
            brain_path = get_brain_path().resolve()
            project_root = brain_path.parent
            home = Path.home().resolve()
            
            if not (resolved.is_relative_to(project_root) or resolved.is_relative_to(home) or resolved.is_relative_to(brain_path)):
                return f"Error: Path '{resolved}' is outside allowed boundaries."
            if not path.exists():
                return f"Error: File not found: {path} (in {cwd})"
            return path.read_text(encoding='utf-8')
            
        elif tool_name == "code_write_file":
            path = self._resolve_path(args['path'])
            
            # Ensure parent directory exists
            path = path.resolve()  # Canonicalize — collapses ../ etc.
            from .common import get_brain_path
            brain_path = get_brain_path().resolve()
            project_root_resolved = brain_path.parent
            home = Path.home().resolve()
            
            if not (path.is_relative_to(project_root_resolved) or path.is_relative_to(home) or path.is_relative_to(brain_path)):
                return f"Error: Write path '{path}' is outside allowed boundaries."
                
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(args['content'], encoding='utf-8')
            return f"✅ Wrote {len(args['content'])} bytes to {path}"

            
        elif tool_name == "code_run_command":
            cmd = args['command']
            timeout = args.get('timeout', 30)
            try:
                # Security: validate command against allowlist
                cmd_parts = shlex.split(cmd)
                if not cmd_parts:
                    return "Error: Empty command"
                base_cmd = os.path.basename(cmd_parts[0])
                if base_cmd not in SAFE_COMMANDS:
                    return f"Error: Command '{base_cmd}' not in allowlist. Allowed: {', '.join(sorted(SAFE_COMMANDS))}"
                
                # Phase 17: SEE Hardened Execution
                sanitizer = EnvironmentSanitizer()
                isolated_env = sanitizer.get_isolated_env()
                
                # Create sovereign process with group isolation
                proc = SovereignProcess(
                    cmd_parts,
                    env=isolated_env,
                    cwd=cwd
                )
                
                # Register for hard preemption (if inside an agent)
                agent_id = CURRENT_AGENT_ID.get()
                if agent_id:
                    get_execution_manager().register_process(agent_id, proc)
                
                try:
                    # SEE: communicate() handles wait, output capture and hard kill on timeout
                    stdout, stderr = proc.communicate(timeout=timeout)
                    return f"Exit Code: {proc.returncode}\nstdout:\n{stdout}\nstderr:\n{stderr}"
                except subprocess.TimeoutExpired:
                    # SEE: communicate() calls kill_group() internally on timeout
                    return f"Error: Command timed out after {timeout}s (Group preemption triggered)"
                finally:
                    # Ensure group is dead even on success/error
                    proc.kill_group()
                        
            except Exception as e:
                return f"Error: {str(e)}"

        elif tool_name == "code_list_files":
            path = self._resolve_path(args.get('path', '.'))
            
            # Security: prevent listing outside boundaries
            resolved = path.resolve()
            from .common import get_brain_path
            project_root = get_brain_path().resolve().parent
            home = Path.home().resolve()
            
            if not (resolved.is_relative_to(project_root) or resolved.is_relative_to(home)):
                return f"Error: Browse path '{resolved}' is outside allowed boundaries."
                 
            try:
                # Use 'ls -F' style output for simplicity
                entries = []
                for p in path.iterdir():
                    kind = "/" if p.is_dir() else ""
                    entries.append(f"{p.name}{kind}")
                return "\n".join(sorted(entries))
            except Exception as e:
                return f"Error listing files: {str(e)}"
                
        return f"Tool {tool_name} not found in CodeOps."
