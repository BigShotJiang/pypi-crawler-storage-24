"""
Nucleus LLM Client
==================
Multi-Tier LLM Client with intelligent routing.
Primary: google-genai (v1.0+) with Vertex AI
Fallback: google-generativeai (Legacy) or API Key

MDR_010 Compliant: Ensures high availability and reliability.
"""

import os
import logging
import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from enum import Enum

# Configure logger
logger = logging.getLogger("nucleus.llm")

# ============================================================
# SDK AVAILABILITY FLAGS & ENVIRONMENT CONTROL
# ============================================================
# Environment variable to force SDK selection:
#   USE_NEW_GENAI=true  → Prefer google-genai (new SDK)
#   USE_NEW_GENAI=false → Prefer google.generativeai (legacy)
#   Default: Try new SDK first, fall back to legacy
# ============================================================

# Primary SDK: google-genai (v1.0+)
try:
    from google import genai
    from google.genai import types
    HAS_GENAI = True
    logger.debug("✅ SDK: google-genai (new) available")
except ImportError:
    HAS_GENAI = False
    if os.environ.get("NUCLEUS_SKIP_AUTOSTART", "false").lower() != "true":
        logger.debug("⚠️ google-genai not installed. Falling back to legacy SDK.")

# Fallback SDK: google.generativeai (Legacy)
try:
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=FutureWarning)
        import google.generativeai as genai_legacy
    HAS_LEGACY = True
except ImportError:
    HAS_LEGACY = False

def get_active_sdk() -> str:
    if HAS_GENAI: return "NEW"
    if HAS_LEGACY: return "LEGACY"
    return "NONE"

_active = get_active_sdk()
logger.debug(f"🎯 SDK Selection: Using {_active}")


# ============================================================
# TIER ROUTER: Intelligent Multi-Tier LLM Selection
# ============================================================

class LLMTier(Enum):
    """Available LLM pricing/capability tiers."""
    # --- Vertex AI / Paid tiers (for when billing is enabled) ---
    PREMIUM = "premium"           # gemini-3.1-pro-preview (Vertex), highest capability
    STANDARD = "standard"         # gemini-3.1-flash-lite-preview (Vertex), default production
    ECONOMY = "economy"           # gemini-2.5-flash (Vertex), background tasks
    # --- API Key tiers (free-tier / local dev) ---
    LOCAL_PAID = "local_paid"     # API Key with billing (Anthropic fallback)
    LOCAL_FREE = "local_free"     # API Key free tier


class TierRouter:
    """
    Intelligent router that selects the optimal LLM tier based on:
    - Job type (CRITICAL, RESEARCH, ORCHESTRATION, BACKGROUND, TESTING)
    - Budget mode (spartan, balanced, premium)
    - Quota availability (fallback on errors)
    
    Free-Tier Quota Reference (as of 2026-03-10):
      gemini-3-flash:                20 RPD
      gemini-2.5-flash:              20 RPD
      gemini-3.1-flash-lite-preview: 500 RPD  ← best for fuzzing/testing
      gemini-2.5-flash-lite:         20 RPD
    """

    TIER_CONFIGS = {
        # --- Vertex AI / Paid (preserved for when billing is enabled) ---
        # --- Vertex AI / Paid (Currently disabled/mapped to best free) ---
        LLMTier.PREMIUM: {
            "model": "gemini-3-flash-preview",
            "platform": "vertex",
            "cost_level": "high",
            "description": "Mapped to Gemini 3 Flash (Free)"
        },
        LLMTier.STANDARD: {
            "model": "gemini-3-flash-preview",
            "platform": "vertex",
            "cost_level": "medium",
            "description": "Mapped to Gemini 3 Flash (Free)"
        },
        LLMTier.ECONOMY: {
            "model": "gemini-2.5-flash-lite",
            "platform": "vertex",
            "cost_level": "low",
            "description": "Gemini 2.5 Flash Lite"
        },
        # --- API Key / Local ---
        LLMTier.LOCAL_PAID: {
            "model": "gemini-3.1-flash-lite-preview",
            "platform": "api_key",
            "cost_level": "medium",
            "description": "Paid-tier Gemini, massive quota (149.5K RPD)"
        },
        LLMTier.LOCAL_FREE: {
            "model": "gemini-3-flash-preview",
            "platform": "api_key",
            "cost_level": "free",
            "description": "Gemini 3 Flash (Free)"
        },
    }

    # Free-tier model cascade
    # Ordered by descending quota availability (based on Google AI Studio 2026 limits)
    FREE_TIER_CASCADE = [
        "gemini-3-flash-preview",
        "gemini-2.5-flash",
        "gemini-3.1-flash-lite-preview",
        "gemini-2.5-flash-lite"
    ]

    # Highest intelligence cascade for Sovereign workflow (auto-rotation)
    SOVEREIGN_CASCADE = [
        "gemini-3-flash-preview",
        "gemini-2.5-flash",
        "gemini-3.1-flash-lite-preview",
        "gemini-2.5-flash-lite"
    ]

    JOB_ROUTING = {
        "CRITICAL": LLMTier.PREMIUM,
        "RESEARCH": LLMTier.STANDARD,
        "ORCHESTRATION": LLMTier.STANDARD,
        "BACKGROUND": LLMTier.ECONOMY,
        "TESTING": LLMTier.LOCAL_FREE,
    }
    
    BUDGET_MODES = {
        "spartan": [LLMTier.LOCAL_FREE, LLMTier.ECONOMY, LLMTier.STANDARD],
        "balanced": [LLMTier.STANDARD, LLMTier.ECONOMY, LLMTier.LOCAL_PAID],
        "premium": [LLMTier.PREMIUM, LLMTier.STANDARD, LLMTier.ECONOMY],
    }
    
    FALLBACK_CHAIN = [
        LLMTier.PREMIUM,
        LLMTier.STANDARD,
        LLMTier.ECONOMY,
        LLMTier.LOCAL_PAID,
        LLMTier.LOCAL_FREE
    ]
    
    @classmethod
    def route(cls, job_type: str = "ORCHESTRATION", budget_mode: str = "balanced") -> LLMTier:
        """
        Route to optimal tier based on job type and budget.
        
        Args:
            job_type: CRITICAL, RESEARCH, ORCHESTRATION, BACKGROUND, TESTING
            budget_mode: spartan, balanced, premium
            
        Returns:
            The recommended LLMTier
        """
        # Check for forced tier (env var override)
        forced_tier = os.environ.get("NUCLEUS_LLM_TIER")
        if forced_tier:
            try:
                return LLMTier(forced_tier.lower())
            except ValueError:
                logger.warning(f"Invalid NUCLEUS_LLM_TIER: {forced_tier}")
        
        # Route based on job type
        job_upper = job_type.upper() if job_type else "ORCHESTRATION"
        base_tier = cls.JOB_ROUTING.get(job_upper, LLMTier.STANDARD)
        
        # CRITICAL jobs ALWAYS get their designated tier (premium)
        # Quality for important decisions overrides budget constraints
        if job_upper == "CRITICAL":
            logger.info("🎯 TierRouter: CRITICAL job - using premium tier regardless of budget")
            return LLMTier.PREMIUM
        
        # TESTING jobs ALWAYS use free tier to save costs
        if job_upper == "TESTING":
            return LLMTier.LOCAL_FREE
        
        # For other jobs, apply budget constraints
        budget_tiers = cls.BUDGET_MODES.get(budget_mode.lower(), cls.BUDGET_MODES["balanced"])
        
        # If base tier is in budget, use it; otherwise use first budget tier
        if base_tier in budget_tiers:
            return base_tier
        return budget_tiers[0]
    
    @classmethod
    def get_config(cls, tier: LLMTier) -> Dict[str, Any]:
        """Get configuration for a specific tier."""
        return cls.TIER_CONFIGS.get(tier, cls.TIER_CONFIGS[LLMTier.STANDARD])
    
    @classmethod
    def get_fallback(cls, current_tier: LLMTier) -> Optional[LLMTier]:
        """Get next tier in fallback chain."""
        try:
            idx = cls.FALLBACK_CHAIN.index(current_tier)
            if idx < len(cls.FALLBACK_CHAIN) - 1:
                return cls.FALLBACK_CHAIN[idx + 1]
        except ValueError:
            pass
        return None

class DualEngineLLM:
    """
    Unified LLM Client wrapper with intelligent tier routing.
    Transparently falls back to legacy SDK if V1 is not available.
    
    Supports:
    - Explicit tier selection: DualEngineLLM(tier=LLMTier.PREMIUM)
    - Job-based routing: DualEngineLLM(job_type="CRITICAL")
    - Budget modes: "spartan", "balanced", "premium"
    """
    
    def __init__(
        self, 
        model_name: Optional[str] = None,
        tier: Optional[LLMTier] = None,
        job_type: Optional[str] = None,
        budget_mode: str = "balanced",
        system_instruction: Optional[str] = None, 
        api_key: Optional[str] = None
    ):
        # TIER ROUTING LOGIC
        self.tier = None
        self.tier_config = None
        
        if tier:
            # Explicit tier selection
            self.tier = tier
            self.tier_config = TierRouter.get_config(tier)
            model_name = model_name or self.tier_config["model"]
            logger.info(f"🎯 LLM: Using explicit tier '{tier.value}' → {model_name}")
        elif job_type:
            # Job-based routing
            self.tier = TierRouter.route(job_type, budget_mode)
            self.tier_config = TierRouter.get_config(self.tier)
            model_name = self.tier_config["model"]
            logger.info(f"🎯 LLM: Routed job '{job_type}' (budget={budget_mode}) → tier '{self.tier.value}' → {model_name}")
        else:
            # Default to standard tier
            self.tier = LLMTier.STANDARD
            self.tier_config = TierRouter.get_config(self.tier)
            model_name = model_name or self.tier_config["model"]
        
        self.model_name = model_name
        self.system_instruction = system_instruction
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        self.client = None
        self.engine = "NONE"
        self.budget_mode = budget_mode
        
        # Determine platform from tier config
        use_vertex = self.tier_config.get("platform", "vertex") == "vertex" if self.tier_config else True
        force_vertex_env = os.environ.get("FORCE_VERTEX", "1") == "1"
        
        # For local tiers, don't use vertex
        if self.tier in [LLMTier.LOCAL_PAID, LLMTier.LOCAL_FREE]:
            use_vertex = False
        else:
            use_vertex = use_vertex or force_vertex_env
        
        if not self.api_key and not use_vertex:
            raise ValueError("GEMINI_API_KEY is required for local tiers (or set FORCE_VERTEX=1).")

            
        # 1. Initialize google-genai (Primary)
        if HAS_GENAI:
            try:
                proxy_url = os.environ.get("GEMINI_API_BASE_URL")
                
                # Phase 14 Hardening: Auto-discovery of local proxy
                if not proxy_url and Path("/tmp/gemini_proxy.port").exists():
                    try:
                        port = Path("/tmp/gemini_proxy.port").read_text().strip()
                        proxy_url = f"http://127.0.0.1:{port}/v1"
                        logger.info(f"📍 Auto-discovered Gemini Proxy at {proxy_url}")
                    except Exception as e:
                        logger.debug(f"Proxy auto-discovery failed: {e}")

                if proxy_url:
                    logger.info(f"🔗 LLM Client: Proxy Mode ({proxy_url})")
                    # Force API Key mode for proxy, disable Vertex
                    self.client = genai.Client(
                        api_key=self.api_key or "sk-dummy", # Proxy handles keys
                        http_options={'base_url': proxy_url}
                    )
                elif use_vertex:
                    project_id = os.environ.get("GCP_PROJECT_ID", os.environ.get("GOOGLE_CLOUD_PROJECT"))
                    if not project_id and os.environ.get("FORCE_VERTEX") == "1":
                         logger.warning("⚠️ Vertex AI requested but GCP_PROJECT_ID/GOOGLE_CLOUD_PROJECT not set.")
                         raise ValueError("GCP_PROJECT_ID or GOOGLE_CLOUD_PROJECT is required for Vertex AI mode.")
                    
                    location = os.environ.get("GCP_LOCATION", "us-central1")
                    
                    logger.info(f"🏢 LLM Client: Vertex AI Mode ({project_id})")
                    self.client = genai.Client(vertexai=True, project=project_id, location=location)
                else:
                    logger.info("🔑 LLM Client: API Key Mode")
                    # Use v1alpha for experimental features if needed, or stable v1
                    self.client = genai.Client(api_key=self.api_key)
                    
                self.engine = "NEW"
                return
            except Exception as e:
                logger.warning(f"⚠️ V1 Init failed: {e}")

        # 2. Try Legacy (Fallback)
        if HAS_LEGACY:
            try:
                genai_legacy.configure(api_key=self.api_key)
                # Map newer model names to legacy compatible ones if needed
                if "2.0" in model_name:
                    logger.warning(f"⚠️ Legacy SDK may not support {model_name}. Using gemini-1.5-flash.")
                    self.model_name = "gemini-1.5-flash"
                
                self.model = genai_legacy.GenerativeModel(
                    model_name=self.model_name,
                    system_instruction=system_instruction
                )
                self.engine = "LEGACY"
                logger.info(f"✅ LLM Client: Initialized google-generativeai (Legacy) for {self.model_name}")
                return
            except Exception as e:
                logger.error(f"❌ LLM Client: Legacy Init failed: {e}")
                
        if self.engine == "NONE":
            raise ImportError("Could not initialize any Gemini SDK. Install google-genai or google-generativeai.")

    def _log_interaction(self, prompt: str, response: Any):
        """
        Automatic Capture (Brain Consolidation - Phase 1).
        Saves the raw interaction to disk for later mining/consolidation.
        """
        try:
            from .common import get_brain_path
            brain_path = get_brain_path()
            raw_path = brain_path / "raw"
            raw_path.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            filename = raw_path / f"llm_interaction_{timestamp}.json"
            
            # Extract text from response (Best effort)
            response_text = "Unknown"
            if hasattr(response, 'text'):
                response_text = response.text
                
            data = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "engine": self.engine,
                "model": self.model_name,
                "prompt": str(prompt)[:5000], # Truncate massive prompts 
                "response_text": response_text
            }
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logger.warning(f"Failed to log interaction: {e}")

    def generate_content(self, prompt: str, **kwargs) -> Any:
        try:
            # ── Token Budget Check (42-Round Audit: Round 14) ─────────
            try:
                from .token_budget import get_budget_manager, estimate_tokens
                budget = get_budget_manager()
                session_id = os.environ.get("NUCLEUS_SESSION_ID", "default")
                agent_id = kwargs.pop("_agent_id", "default")
                if not budget.can_execute(session_id=session_id, agent_id=agent_id):
                    raise RuntimeError(
                        f"Token budget exceeded for session={session_id}, agent={agent_id}. "
                        "Reset with NUCLEUS_SESSION_COST_LIMIT or wait for daily reset."
                    )
            except ImportError:
                session_id, agent_id = "default", "default"

            # Emit DSoR event for interaction start (Audit Trail)
            try:
                from .event_ops import _emit_event
                _emit_event(
                    event_type="LLM_GENERATE",
                    emitter="DualEngineLLM",
                    data={
                        "model": self.model_name,
                        "tier": self.tier.value if self.tier else "unknown",
                        "prompt_preview": prompt[:100] + "..." if len(prompt) > 100 else prompt
                    },
                    description=f"Generating content using {self.model_name}"
                )
            except ImportError:
                pass # Fallback if event_ops not reachable

            if self.engine == "NEW":
                config_args = {}
                if self.system_instruction:
                    config_args['system_instruction'] = self.system_instruction
                    
                if 'tools' in kwargs:
                    tools_raw = kwargs['tools']
                    if isinstance(tools_raw, dict) and "function_declarations" in tools_raw:
                        config_args['tools'] = [tools_raw] 
                    else:
                        config_args['tools'] = tools_raw

                if 'tool_config' in kwargs:
                     config_args['tool_config'] = kwargs['tool_config']
                
                config = types.GenerateContentConfig(**config_args)
                
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=prompt,
                    config=config
                )
                self._log_interaction(prompt, response)
                self._record_token_usage(prompt, response, session_id, agent_id)
                return response

            elif self.engine == "LEGACY":
                # Legacy SDK logic
                generation_config = {}
                # Legacy doesn't support tools same way here, basic text only for now or map tools manually
                # For Marketing Autopilot, we mostly use text.
                
                response = self.model.generate_content(prompt, generation_config=generation_config)
                self._log_interaction(prompt, response)
                self._record_token_usage(prompt, response, session_id, agent_id)
                return response

        except Exception as e:
            logger.error(f"❌ LLM Generate Content Failed ({self.engine}): {e}")
            raise

    def _record_token_usage(self, prompt: str, response: Any, session_id: str = "default", agent_id: str = "default"):
        """Record token usage to the BudgetManager after each LLM call."""
        try:
            from .token_budget import get_budget_manager, estimate_tokens
            input_tokens = estimate_tokens(str(prompt))
            response_text = getattr(response, 'text', '') or ''
            output_tokens = estimate_tokens(response_text)
            get_budget_manager().record_usage(
                model=self.model_name,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                session_id=session_id,
                agent_id=agent_id,
            )
        except Exception as e:
            logger.debug(f"Token usage recording skipped: {e}")

    def embed_content(self, text: str, task_type: str = "retrieval_document", title: Optional[str] = None) -> Dict[str, Any]:
        try:
            if self.engine == "NEW":
                normalized_task_type = task_type.replace("retrieval_", "RETRIEVAL_").upper()
                config = {'task_type': normalized_task_type}
                if title:
                    config['title'] = title
                
                response = self.client.models.embed_content(
                    model=self.model_name,
                    contents=text,
                    config=config
                )
                if hasattr(response, 'embeddings') and response.embeddings:
                    return {'embedding': response.embeddings[0].values}
                return {'embedding': []}
                
            elif self.engine == "LEGACY":
                # Legacy SDK
                # task_type mapping
                # content
                result = genai_legacy.embed_content(
                    model="models/text-embedding-004", # Hardcoded or passed in
                    content=text,
                    task_type=task_type,
                    title=title
                )
                return result

        except Exception as e:
             logger.error(f"❌ LLM Embed Content Failed ({self.engine}): {e}")
             raise

    @property
    def active_engine(self):
        return self.engine

    # Alias for legacy support and autonomous self-healer compatibility
    generate = generate_content
