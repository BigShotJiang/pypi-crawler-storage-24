import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional, Set
from .common import get_brain_path

class ContextNode:
    """Represents a node in the context graph (e.g. engram_id, task_id, doc_path)."""
    def __init__(self, node_id: str, node_type: str, metadata: Optional[Dict[str, Any]] = None):
        self.node_id = node_id
        self.node_type = node_type
        self.metadata = metadata or {}
        self.created_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "node_type": self.node_type,
            "metadata": self.metadata,
            "created_at": self.created_at
        }

class ContextEdge:
    """Represents a weighted relationship between two context nodes."""
    def __init__(self, source_id: str, target_id: str, relationship: str, weight: float = 1.0):
        self.edge_id = f"edge-{hashlib.md5(f'{source_id}:{target_id}:{relationship}'.encode()).hexdigest()[:8]}"
        self.source_id = source_id
        self.target_id = target_id
        self.relationship = relationship
        self.weight = weight
        self.ts = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relationship": self.relationship,
            "weight": self.weight,
            "ts": self.ts
        }

class ContextGraph:
    """Foundational data layer for 'Brain-First' autonomy context tracking."""
    
    def __init__(self, brain_path: Optional[Path] = None):
        self.brain_path = brain_path or get_brain_path()
        self.graph_dir = self.brain_path / "ledger" / "graph"
        self.nodes_file = self.graph_dir / "nodes.jsonl"
        self.edges_file = self.graph_dir / "edges.jsonl"
        self.graph_dir.mkdir(parents=True, exist_ok=True)

    def add_node(self, node_id: str, node_type: str, metadata: Optional[Dict[str, Any]] = None) -> ContextNode:
        """Add a node to the graph or update if it exists."""
        node = ContextNode(node_id, node_type, metadata)
        with open(self.nodes_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(node.to_dict(), ensure_ascii=False) + "\n")
        return node

    def link_nodes(self, source_id: str, target_id: str, relationship: str, weight: float = 1.0) -> ContextEdge:
        """Create a weighted link between two nodes."""
        edge = ContextEdge(source_id, target_id, relationship, weight)
        with open(self.edges_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(edge.to_dict(), ensure_ascii=False) + "\n")
        return edge

    def strengthen_link(self, source_id: str, target_id: str, relationship: str, increment: float = 0.1) -> bool:
        """Increase the weight of an existing link."""
        if not self.edges_file.exists():
            return False
            
        updated = False
        temp_file = self.edges_file.with_suffix(".tmp")
        with open(self.edges_file, "r", encoding="utf-8") as fin, \
             open(temp_file, "w", encoding="utf-8") as fout:
            for line in fin:
                data = json.loads(line)
                if (data["source_id"] == source_id and data["target_id"] == target_id and data["relationship"] == relationship) or \
                   (data["source_id"] == target_id and data["target_id"] == source_id and data["relationship"] == relationship):
                    data["weight"] = round(data["weight"] + increment, 2)
                    updated = True
                fout.write(json.dumps(data, ensure_ascii=False) + "\n")
        
        temp_file.replace(self.edges_file)
        return updated

    def decay_links(self, factor: float = 0.9) -> None:
        """Periodically reduce all non-permanent weights."""
        if not self.edges_file.exists():
            return
            
        temp_file = self.edges_file.with_suffix(".tmp")
        with open(self.edges_file, "r", encoding="utf-8") as fin, \
             open(temp_file, "w", encoding="utf-8") as fout:
            for line in fin:
                data = json.loads(line)
                data["weight"] = max(0.1, round(data["weight"] * factor, 2))
                fout.write(json.dumps(data, ensure_ascii=False) + "\n")
        
        temp_file.replace(self.edges_file)

    def get_related(self, node_id: str, relationship: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get nodes related to a specific node with full edge data."""
        if not self.edges_file.exists():
            return []
            
        related = []
        with open(self.edges_file, "r", encoding="utf-8") as f:
            for line in f:
                edge_data = json.loads(line)
                if edge_data["source_id"] == node_id or edge_data["target_id"] == node_id:
                    if not relationship or edge_data["relationship"] == relationship:
                        related.append(edge_data)
        
        return related

    def get_context_boost(self, node_id: str) -> float:
        """Calculate the total neural boost for a node (sum of all edge weights)."""
        related = self.get_related(node_id)
        return sum(edge.get("weight", 1.0) for edge in related)

    def check_interference(self, node_id: str) -> List[Dict[str, Any]]:
        """Detect other source nodes that share common related nodes (interference)."""
        if not self.edges_file.exists():
            return []
            
        # 1. Get all nodes this node is related to (e.g., files shared by a task)
        context_nodes = []
        with open(self.edges_file, "r", encoding="utf-8") as f:
            for line in f:
                edge = json.loads(line)
                if edge["source_id"] == node_id:
                    context_nodes.append(edge["target_id"])
                elif edge["target_id"] == node_id:
                    context_nodes.append(edge["source_id"])
        
        if not context_nodes:
            return []
            
        # 2. Find all other nodes related to these context nodes
        interferences = []
        with open(self.edges_file, "r", encoding="utf-8") as f:
            for line in f:
                edge = json.loads(line)
                # Skip edges involving the original node_id
                if edge["source_id"] == node_id or edge["target_id"] == node_id:
                    continue
                
                shared_node = None
                interfering_node = None
                
                if edge["source_id"] in context_nodes:
                    shared_node = edge["source_id"]
                    interfering_node = edge["target_id"]
                elif edge["target_id"] in context_nodes:
                    shared_node = edge["target_id"]
                    interfering_node = edge["source_id"]
                    
                if interfering_node:
                    interferences.append({
                        "interfering_node_id": interfering_node,
                        "shared_context_node": shared_node,
                        "relationship": edge["relationship"],
                        "weight": edge.get("weight", 1.0)
                    })
                    
        return interferences

# ── Dynamic Engram-Based Graph Functions ───────────────────────
# (Restored for CLI compatibility and engram visualization)

def _load_engrams() -> List[Dict]:
    """Load engrams from ledger with safety cap."""
    brain = get_brain_path()
    ledger = brain / "memory" / "engrams.json" # New path from Phase 11/12
    if not ledger.exists():
        # Try legacy path
        ledger = brain / "memory" / "ledger.jsonl"
        
    if not ledger.exists():
        return []

    try:
        content = ledger.read_text(encoding="utf-8")
        if ledger.suffix == ".json":
            return json.loads(content)[:500]
        else:
            engrams = []
            for line in content.splitlines():
                if line.strip():
                    engrams.append(json.loads(line))
            return engrams[:500]
    except Exception:
        return []

def build_context_graph(include_edges: bool = True, min_intensity: int = 1) -> Dict[str, Any]:
    """Build a dynamic graph from engrams (Decision System context)."""
    # This is a simplified version for now to fix the import error
    # Real implementations would include temporal/semantic links
    engrams = _load_engrams()
    nodes = []
    for e in engrams:
        if e.get("intensity", 5) >= min_intensity:
            nodes.append({
                "id": e.get("key", "unknown"),
                "context": e.get("context", "Unknown"),
                "intensity": e.get("intensity", 5)
            })
    
    return {
        "nodes": nodes,
        "edges": [], # Legacy edges not supported in this view yet
        "clusters": {},
        "stats": {
            "node_count": len(nodes),
            "edge_count": 0,
            "density": 0,
            "unique_pairs": 0,
            "cluster_count": 0,
            "avg_intensity": sum(n["intensity"] for n in nodes) / max(len(nodes), 1)
        }
    }

def render_ascii_graph(max_nodes: int = 30, min_intensity: int = 1) -> str:
    """ASCII visualization of the brain context."""
    graph = build_context_graph(min_intensity=min_intensity)
    nodes = graph["nodes"][:max_nodes]
    
    lines = []
    lines.append("╔══════════════════════════════════════════════════════════╗")
    lines.append("║           NUCLEUS ENGRAM CONTEXT GRAPH                  ║")
    lines.append("╠══════════════════════════════════════════════════════════╣")
    lines.append(f"║  Nodes: {graph['stats']['node_count']:<6}                                    ║")
    lines.append("╠══════════════════════════════════════════════════════════╣")
    
    for n in nodes:
        bar = "●" * n["intensity"] + "○" * (10 - n["intensity"])
        lines.append(f"║  {n['id'][:25]:<25} [{bar}] {n['context'][:10]:<10} ║")
        
    lines.append("╚══════════════════════════════════════════════════════════╝")
    return "\n".join(lines)

def get_engram_neighbors(key: str, max_depth: int = 1) -> Dict[str, Any]:
    """Get neighborhood of an engram."""
    # Dummy implementation for CLI compatibility
    return {"error": "Dynamic neighborhood not available in this version"}
