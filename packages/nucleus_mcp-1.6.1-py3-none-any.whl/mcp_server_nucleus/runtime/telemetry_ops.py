import time
from typing import Dict, Optional, Any

# Relative import from parent package (mcp_server_nucleus)
from .. import commitment_ledger
from .common import get_brain_path

# TTL Cache Configuration
_TELEMETRY_CACHE: Dict[str, Dict[str, Any]] = {}
_TELEMETRY_TTLS: Dict[str, int] = {
    "value_ratio": 60,
    "kill_switch": 60,
    "dispatch_metrics": 30,
    "agent_cost": 300,
    "default": 60
}

def _get_from_cache(key: str) -> Optional[Any]:
    """Retrieve item from cache if not expired."""
    if key in _TELEMETRY_CACHE:
        entry = _TELEMETRY_CACHE[key]
        ttl = _TELEMETRY_TTLS.get(key, _TELEMETRY_TTLS["default"])
        if time.time() - entry["timestamp"] < ttl:
            return entry["data"]
    return None

def _put_in_cache(key: str, data: Any):
    """Store item in cache with current timestamp."""
    _TELEMETRY_CACHE[key] = {
        "timestamp": time.time(),
        "data": data
    }

def _invalidate_cache(key: Optional[str] = None):
    """Clear the telemetry cache or a specific key."""
    global _TELEMETRY_CACHE
    if key:
        _TELEMETRY_CACHE.pop(key, None)
    else:
        _TELEMETRY_CACHE = {}

def _brain_record_interaction_impl() -> str:
    """Record a user interaction timestamp (MDR_010)."""
    try:
        brain = get_brain_path()
        commitment_ledger.record_interaction(brain)
        return "✅ Interaction recorded"
    except Exception as e:
        return f"Error: {e}"

def _brain_value_ratio_impl() -> str:
    """Get the Value Ratio metric (MDR_010)."""
    try:
        # Check cache first
        cached = _get_from_cache("value_ratio")
        if cached:
            return cached
            
        brain = get_brain_path()
        ratio = commitment_ledger.calculate_value_ratio(brain)
        output = "## 📊 Value Ratio (MDR_010)\n\n"
        output += f"**Notifications Sent:** {ratio['notifications_sent']}\n"
        output += f"**High Impact Closures:** {ratio['high_impact_closed']}\n"
        output += f"**Ratio:** {ratio['ratio']}\n"
        output += f"**Verdict:** {ratio['verdict']}\n"
        
        _put_in_cache("value_ratio", output)
        return output
    except Exception as e:
        return f"Error: {e}"

def _brain_check_kill_switch_impl() -> str:
    """Check Kill Switch status (MDR_010)."""
    try:
        # Check cache first
        cached = _get_from_cache("kill_switch")
        if cached:
            return cached
            
        brain = get_brain_path()
        status = commitment_ledger.check_kill_switch(brain)
        output = "## 🛑 Kill Switch Status (MDR_010)\n\n"
        output += f"**Action:** {status['action']}\n"
        output += f"**Message:** {status.get('message', 'N/A')}\n"
        if 'days_inactive' in status:
            output += f"**Days Inactive:** {status['days_inactive']}\n"
            
        _put_in_cache("kill_switch", output)
        return output
    except Exception as e:
        return f"Error: {e}"

def _brain_pause_notifications_impl() -> str:
    """Pause all PEFS notifications (Kill Switch activation)."""
    try:
        brain = get_brain_path()
        commitment_ledger.pause_notifications(brain)
        return "🛑 Notifications paused. Use brain_resume_notifications() to restart."
    except Exception as e:
        return f"Error: {e}"

def _brain_resume_notifications_impl() -> str:
    """Resume PEFS notifications after pause."""
    try:
        brain = get_brain_path()
        commitment_ledger.resume_notifications(brain)
        commitment_ledger.record_interaction(brain)
        return "✅ Notifications resumed. Interaction recorded."
    except Exception as e:
        return f"Error: {e}"

def _brain_record_feedback_impl(notification_type: str, score: int) -> str:
    """Record user feedback on a notification (MDR_010)."""
    try:
        brain = get_brain_path()
        commitment_ledger.record_feedback(brain, notification_type, score)
        
        # Invalidate cache as feedback affects value ratio
        _invalidate_cache()
        
        if score >= 4:
            msg = "✅ Positive feedback recorded. Marked as high-impact."
        elif score >= 2:
            msg = "📝 Neutral feedback recorded."
        else:
            msg = "😔 Negative feedback recorded. Will try to improve."
        return msg
    except Exception as e:
        return f"Error: {e}"

def _brain_mark_high_impact_impl() -> str:
    """Manually mark a loop closure as high-impact (MDR_010)."""
    try:
        brain = get_brain_path()
        commitment_ledger.mark_high_impact_closure(brain)
        
        # Invalidate cache
        _invalidate_cache("value_ratio")
        
        return "✅ Marked as high-impact closure. Value ratio updated."
    except Exception as e:
        return f"Error: {e}"

def _brain_dispatch_metrics_impl() -> str:
    """Get dispatch telemetry (per-action timing, error rates) (Phase 3)."""
    try:
        cached = _get_from_cache("dispatch_metrics")
        if cached:
            return cached

        # v0.6.0+ uses .profiling for metrics
        from .profiling import get_metrics_summary
        metrics = get_metrics_summary()
        
        output = "## 🚀 Dispatch Metrics\n\n"
        if not metrics or "counters" not in metrics:
            output += "No recent activity recorded."
        else:
            output += "### Invocations\n"
            for k, v in metrics.get("counters", {}).items():
                output += f"- **{k}:** {v}\n"
            
            output += "\n### Latency (ms)\n"
            for k, v in metrics.get("timers", {}).items():
                output += f"- **{k}:** {v:.2f}ms\n"

        _put_in_cache("dispatch_metrics", output)
        return output
    except Exception as e:
        return f"Error: {e}"

def _brain_agent_cost_dashboard_impl() -> str:
    """Get agent cost tracking dashboard (Phase 3)."""
    try:
        cached = _get_from_cache("agent_cost")
        if cached:
            return cached

        # v2.0+ uses .agent_runtime_v2 for cost tracking
        from .agent_runtime_v2 import get_execution_manager
        manager = get_execution_manager()
        metrics = manager.get_dashboard_metrics()
        cost_sum = metrics.get("cost_summary", {})
        
        output = "## 💸 Agent Cost Dashboard\n\n"
        output += f"**Total Executions:** {cost_sum.get('total_executions', 0)}\n"
        output += f"**Total Cost (USD):** ${cost_sum.get('total_cost_usd', 0.0):.6f}\n"
        output += f"**Avg Cost/Agent:** ${cost_sum.get('avg_cost_per_agent', 0.0):.6f}\n"
        output += f"**Avg Duration:** {cost_sum.get('avg_duration_ms', 0.0):.2f}ms\n"
        
        if metrics.get("active_agents"):
            output += "\n### Active Agents\n"
            for agent in metrics["active_agents"][:5]:
                output += f"- `{agent['agent_id']}` ({agent['persona']}): {agent['status']}\n"

        _put_in_cache("agent_cost", output)
        return output
    except Exception as e:
        return f"Error: {e}"
