# DataVLT

DataVLT is a simple lightweight key-value database written in Python.

It stores data in a log file and supports:
- API key authentication
- user-based data isolation
- autosave
- caching

---

## 📦 Installation

```bash
pip install datavlt