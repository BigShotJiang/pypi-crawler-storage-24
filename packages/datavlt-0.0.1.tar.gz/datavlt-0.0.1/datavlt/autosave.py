import threading
import time


def start_autosave(db, interval):
    def loop():
        while True:
            time.sleep(interval)
            db.compact()
            print("Auto-saved")

    thread = threading.Thread(target=loop, daemon=True)
    thread.start()