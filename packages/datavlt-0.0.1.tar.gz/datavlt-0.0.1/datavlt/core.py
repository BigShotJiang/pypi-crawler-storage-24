import os
import json


class SimpleDB:
    def __init__(self, filename):
        self.filename = filename
        self.data = {}
        self._load()

    def _load(self):
        def _load(self):
            if not os.path.exists(self.filename):
                return

            with open(self.filename, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()

                    if not line:
                        continue

                    parts = line.split(" ", 3)

                    if len(parts) < 2:
                        continue

                    cmd = parts[0]

                    if cmd == "SET" and len(parts) == 4:
                        key = parts[1]
                        vtype = parts[2]
                        value = parts[3]

                        try:
                            self.data[key] = self._parse(value, vtype)
                        except Exception:
                            print(f"⚠️ Ошибка строки, пропускаю: {line}")

                    elif cmd == "DEL":
                        key = parts[1]
                        self.data.pop(key, None)

    def _parse(self, value, vtype):
        if vtype == "int":
            return int(value)
        if vtype == "float":
            return float(value)
        if vtype == "bool":
            return value == "True"
        if vtype == "json":
            return json.loads(value)
        return value

    def _type(self, value):
        if isinstance(value, int):
            return "int"
        if isinstance(value, float):
            return "float"
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, (dict, list)):
            return "json"
        return "str"

    def _serialize(self, value):
        if isinstance(value, (dict, list)):
            return json.dumps(value, separators=(",", ":"))
        return str(value)

    def set(self, key, value):
        t = self._type(value)
        s = self._serialize(value)

        self.data[key] = value

        with open(self.filename, "a", encoding="utf-8") as f:
            f.write(f"SET {key} {t} {s}\n")

    def get(self, key):
        return self.data.get(key)

    def delete(self, key):
        if key in self.data:
            del self.data[key]
            with open(self.filename, "a", encoding="utf-8") as f:
                f.write(f"DEL {key}\n")

    def compact(self):
        with open(self.filename, "w", encoding="utf-8") as f:
            for k, v in self.data.items():
                t = self._type(v)
                s = self._serialize(v)
                f.write(f"SET {k} {t} {s}\n")