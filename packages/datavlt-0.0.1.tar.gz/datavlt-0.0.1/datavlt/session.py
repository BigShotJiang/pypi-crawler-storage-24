class UserDB:
    def __init__(self, db, username):
        self.db = db
        self.username = username
        self.cache = {}

    def _k(self, key):
        return f"data:{self.username}:{key}"

    def set(self, key, value):
        self.cache[key] = value
        self.db.set(self._k(key), value)

    def get(self, key):
        if key in self.cache:
            return self.cache[key]

        value = self.db.get(self._k(key))
        self.cache[key] = value
        return value

    def delete(self, key):
        self.cache.pop(key, None)
        self.db.delete(self._k(key))

    def get_all(self):
        prefix = f"data:{self.username}:"
        return {
            k[len(prefix):]: v
            for k, v in self.db.data.items()
            if k.startswith(prefix)
        }