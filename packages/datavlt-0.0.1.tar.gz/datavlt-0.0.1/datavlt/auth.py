import hashlib
import uuid
from .core import SimpleDB
from .session import UserDB
from .autosave import start_autosave


class DataVLT:
    def __init__(self, filename, autosave_interval=10):
        self.db = SimpleDB(filename)
        start_autosave(self.db, autosave_interval)

    def _hash(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def reg(self, username, password):
        existing = self.db.get(f"user:{username}")

        # если пользователь уже есть → удаляем старый ключ
        if existing:
            old_key = existing["api_key"]
            self.db.delete(f"apikey:{old_key}")

        api_key = str(uuid.uuid4())

        user = {
            "password": self._hash(password),
            "api_key": api_key
        }

        self.db.set(f"user:{username}", user)
        self.db.set(f"apikey:{api_key}", username)

        return api_key

    def login(self, username, password):
        user = self.db.get(f"user:{username}")
        if not user:
            return None

        if user["password"] != self._hash(password):
            return None

        return user["api_key"]

    def from_api(self, api_key):
        username = self.db.get(f"apikey:{api_key}")
        if not username:
            return None

        return UserDB(self.db, username)

    def save(self):
        self.db.compact()