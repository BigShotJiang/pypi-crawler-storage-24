from __future__ import annotations

from pydantic import BaseModel

from safe_genai.providers.base import BaseProvider
from safe_genai.result import Usage

_VALIDATOR_SYSTEM_TEMPLATE = """\
You are a requirements validator. Your job is to verify whether the generated output fulfills the original user prompt requirements.

Compare the output against the user prompt and check:
1. Does the output directly address what the user asked for?
2. Does the output meet the specific requirements stated in the prompt (e.g., structure, format, content)?
3. Is the output a genuine response, NOT an evasion such as "I couldn't find any information", "No data available", or similar non-answers?

Respond with a JSON object containing:
- "passed": true ONLY if the output genuinely fulfills the user prompt requirements, false otherwise
- "feedback": a brief explanation of your decision referencing specific requirements that were met or missed
{extra}"""

_USER_MESSAGE_TEMPLATE = """\
## Original User Prompt
{user_prompt}

## Generated Output
{output}"""


class _ValidationResult(BaseModel):
    passed: bool
    feedback: str


class Validator:
    def __init__(
        self,
        provider: BaseProvider,
        model: str,
        additional_instructions: str | None = None,
    ) -> None:
        self._provider = provider
        self._model = model
        self._system_prompt = _VALIDATOR_SYSTEM_TEMPLATE.format(
            extra=f"\nAdditional instructions:\n{additional_instructions}"
            if additional_instructions
            else ""
        )

    def validate(self, formatted_output: BaseModel, user_prompt: str) -> tuple[_ValidationResult, Usage]:
        user_message = _USER_MESSAGE_TEMPLATE.format(
            user_prompt=user_prompt,
            output=formatted_output.model_dump_json(indent=2),
        )
        result, usage = self._provider.generate_structured(
            self._model,
            self._system_prompt,
            user_message,
            _ValidationResult,
        )
        return result, usage  # type: ignore[return-value]

    async def avalidate(self, formatted_output: BaseModel, user_prompt: str) -> tuple[_ValidationResult, Usage]:
        user_message = _USER_MESSAGE_TEMPLATE.format(
            user_prompt=user_prompt,
            output=formatted_output.model_dump_json(indent=2),
        )
        result, usage = await self._provider.agenerate_structured(
            self._model,
            self._system_prompt,
            user_message,
            _ValidationResult,
        )
        return result, usage  # type: ignore[return-value]
