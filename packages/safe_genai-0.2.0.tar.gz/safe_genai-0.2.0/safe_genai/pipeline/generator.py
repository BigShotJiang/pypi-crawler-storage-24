from __future__ import annotations

from safe_genai.providers.base import BaseProvider
from safe_genai.result import Usage


class Generator:
    def __init__(self, provider: BaseProvider, model: str, system_prompt: str) -> None:
        self._provider = provider
        self._model = model
        self._system_prompt = system_prompt

    def generate(self, user_prompt: str) -> tuple[str, Usage]:
        return self._provider.generate_text(
            self._model, self._system_prompt, user_prompt, enable_grounding=True
        )

    async def agenerate(self, user_prompt: str) -> tuple[str, Usage]:
        return await self._provider.agenerate_text(
            self._model, self._system_prompt, user_prompt, enable_grounding=True
        )
