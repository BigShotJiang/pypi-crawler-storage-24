from __future__ import annotations

from pydantic import BaseModel


class SafeGenAIError(Exception):
    """Base exception for all safe-genai errors."""


class SafeGenAIValidationError(SafeGenAIError):
    """Raised when the validator never passes within max_retries + 1 attempts."""

    def __init__(self, output: BaseModel, feedback: str, attempts: int, raw_response: str) -> None:
        self.output = output
        self.feedback = feedback
        self.attempts = attempts
        self.raw_response = raw_response
        super().__init__(f"Validation failed after {attempts} attempt(s). Feedback: {feedback}")


class SafeGenAIFormatterError(SafeGenAIError):
    """Raised when the formatter LLM cannot coerce output into the target schema."""

    def __init__(self, raw_response: str, schema_name: str, cause: Exception) -> None:
        self.raw_response = raw_response
        self.schema_name = schema_name
        self.cause = cause
        super().__init__(f"Formatter failed to coerce output into schema '{schema_name}': {cause}")


class SafeGenAIProviderError(SafeGenAIError):
    """Wraps SDK/transport errors from the underlying provider."""

    def __init__(self, provider_name: str, cause: Exception) -> None:
        self.provider_name = provider_name
        self.cause = cause
        super().__init__(f"Provider '{provider_name}' raised an error: {cause}")
