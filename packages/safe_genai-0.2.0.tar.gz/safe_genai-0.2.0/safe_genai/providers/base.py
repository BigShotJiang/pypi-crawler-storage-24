from __future__ import annotations

from abc import ABC, abstractmethod

from pydantic import BaseModel

from safe_genai.result import Usage


class BaseProvider(ABC):
    @abstractmethod
    def generate_text(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        *,
        enable_grounding: bool = False,
    ) -> tuple[str, Usage]: ...

    @abstractmethod
    def generate_structured(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        output_schema: type[BaseModel],
    ) -> tuple[BaseModel, Usage]: ...

    @abstractmethod
    async def agenerate_text(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        *,
        enable_grounding: bool = False,
    ) -> tuple[str, Usage]: ...

    @abstractmethod
    async def agenerate_structured(
        self,
        model: str,
        system_prompt: str,
        user_prompt: str,
        output_schema: type[BaseModel],
    ) -> tuple[BaseModel, Usage]: ...
