from __future__ import annotations

from dataclasses import dataclass

DEFAULT_GENERATOR_MODEL = "gemini-3.1-pro-preview"
DEFAULT_FORMATTER_MODEL = "gemini-3-flash-preview"
DEFAULT_VALIDATOR_MODEL = "gemini-3-flash-preview"


@dataclass
class AgentConfig:
    generator_model: str = DEFAULT_GENERATOR_MODEL
    formatter_model: str = DEFAULT_FORMATTER_MODEL
    validator_model: str = DEFAULT_VALIDATOR_MODEL
    max_retries: int = 0  # 0 = one attempt, raise on failure
    # --- Gemini API (default) ---
    api_key: str | None = None  # falls back to GEMINI_API_KEY env var
    # --- Vertex AI (uses gcloud ADC, no api_key needed) ---
    vertexai: bool = False
    vertex_project: str | None = None  # falls back to GOOGLE_CLOUD_PROJECT env var
    vertex_location: str = "us-central1"
