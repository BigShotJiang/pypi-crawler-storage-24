from pydantic import BaseModel

from safe_genai import SafeAgent


class LatestRelease(BaseModel):
    version: str
    release_date: str
    notable_changes: list[str]


agent = SafeAgent(
    output_schema=LatestRelease,
    system_prompt=(
        "You are a software research assistant. "
        "Use Google Search to find the most recent release information. "
        "Always return the latest published version, never guess."
    ),
)

result = agent.run("What is the latest stable release of Python?")
print(f"Version: {result.output.version}")
print(f"Released: {result.output.release_date}")
print(f"Attempts: {result.attempts}")
for change in result.output.notable_changes:
    print(f"  - {change}")
