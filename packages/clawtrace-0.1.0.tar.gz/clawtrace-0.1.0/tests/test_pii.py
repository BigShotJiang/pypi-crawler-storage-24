import json

from clawtrace.pii import (
    _content_findings_for_text,
    _extract_json_array,
    _normalize_llm_findings,
    _truncate_for_llm,
    apply_findings_to_session,
    apply_findings_to_text,
    load_findings,
    merge_findings,
    replacement_for_type,
    review_session_pii,
    review_session_pii_hybrid,
    review_session_pii_with_claude,
    write_findings,
)


def test_replacement_for_type_defaults():
    assert replacement_for_type("person_name") == "[REDACTED_PERSON]"
    assert replacement_for_type("unknown") == "[REDACTED]"


def test_merge_findings_prefers_longer_text():
    findings = [
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "content",
            "entity_text": "Kai",
            "entity_type": "person_name",
            "confidence": 0.8,
        },
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "content",
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "confidence": 0.95,
        },
    ]
    merged = merge_findings(findings)
    assert len(merged) == 1
    assert merged[0]["entity_text"] == "Kai D"


def test_apply_findings_to_text_replaces_all_occurrences():
    findings = [
        {
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "replacement": "[REDACTED_PERSON]",
            "confidence": 0.9,
        }
    ]
    redacted, count = apply_findings_to_text("Kai D said hi to Kai D.", findings)
    assert count == 2
    assert "Kai D" not in redacted
    assert redacted.count("[REDACTED_PERSON]") == 2


def test_apply_findings_to_session_nested_tool_field():
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": "hello",
                "tool_uses": [
                    {
                        "input": {"command": "echo Kai D"},
                        "output": {"text": "done"},
                    }
                ],
            }
        ],
    }
    findings = [
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "tool_uses[0].input.command",
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "replacement": "[REDACTED_PERSON]",
            "confidence": 0.99,
        }
    ]
    redacted, count = apply_findings_to_session(session, findings)
    assert count == 1
    assert redacted["messages"][0]["tool_uses"][0]["input"]["command"] == "echo [REDACTED_PERSON]"


def test_review_session_pii_detects_metadata_entities():
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": '{"sender_id":"7859110712","name":"Kai D","username":"kaidagent"}'
            }
        ],
    }
    findings = review_session_pii(session)
    entity_texts = {f["entity_text"] for f in findings}
    assert "7859110712" in entity_texts
    assert "Kai D" in entity_texts
    assert "kaidagent" in entity_texts


def test_review_session_pii_detects_escaped_quote_metadata():
    """Metadata patterns should match both regular and escaped JSON quotes."""
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": r'{"text": "{\"name\":\"Kai D\",\"username\":\"kaidagent\"}"}'
            }
        ],
    }
    findings = review_session_pii(session)
    entity_texts = {f["entity_text"] for f in findings}
    assert "Kai D" in entity_texts
    assert "kaidagent" in entity_texts


def test_metadata_id_pattern_only_matches_numeric_ids():
    """The generic 'id' pattern should only match numeric IDs, not UUIDs or hashes."""
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": '{"id":"abc123-uuid-value","user_id":"9876543210"}'
            }
        ],
    }
    findings = review_session_pii(session)
    entity_texts = {f["entity_text"] for f in findings}
    # UUID-like id should NOT be matched
    assert "abc123-uuid-value" not in entity_texts
    # Numeric user_id SHOULD be matched via the specific user_id pattern
    assert "9876543210" in entity_texts


def test_write_and_load_findings_roundtrip(tmp_path):
    path = tmp_path / "findings.json"
    findings = [
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "content",
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "confidence": 0.9,
        }
    ]
    write_findings(path, findings, meta={"provider": "rules"})
    loaded = load_findings(path)
    assert len(loaded) == 1
    assert loaded[0]["entity_text"] == "Kai D"
    assert json.loads(path.read_text())["provider"] == "rules"


def test_extract_json_array_from_wrapped_text():
    parsed = _extract_json_array('noise before [{"entity_text":"Kai D","entity_type":"person_name","confidence":0.9,"reason":"name"}] noise after')
    assert parsed[0]["entity_text"] == "Kai D"


def test_normalize_llm_findings_filters_unknown_type():
    findings = _normalize_llm_findings("s1", 0, "content", [{
        "entity_text": "secret thing",
        "entity_type": "weird_type",
        "confidence": 0.7,
        "reason": "sensitive",
    }], source="claude")
    assert findings[0]["entity_type"] == "custom_sensitive"
    assert findings[0]["source"] == "claude"


def test_review_session_pii_with_claude(monkeypatch):
    session = {
        "session_id": "s1",
        "messages": [{"content": "Kai D from Acme"}],
    }

    def fake_review(session_id, message_index, field, text, **kwargs):
        assert session_id == "s1"
        assert field == "content"
        assert text == "Kai D from Acme"
        return [{
            "session_id": session_id,
            "message_index": message_index,
            "field": field,
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "confidence": 0.95,
            "reason": "name",
            "replacement": "[REDACTED_PERSON]",
            "source": "claude",
        }]

    monkeypatch.setattr("clawtrace.pii.review_text_with_claude", fake_review)
    findings = review_session_pii_with_claude(session)
    assert findings[0]["entity_text"] == "Kai D"
    assert findings[0]["source"] == "claude"


def test_review_session_pii_hybrid_merges_rule_and_claude(monkeypatch):
    session = {
        "session_id": "s1",
        "messages": [{"content": '{"name":"Kai D","username":"kaidagent"} and Acme Labs'}],
    }

    monkeypatch.setattr("clawtrace.pii.review_session_pii_with_claude", lambda s, ignore_errors=True, **kw: [{
        "session_id": "s1",
        "message_index": 0,
        "field": "content",
        "entity_text": "Acme Labs",
        "entity_type": "org_name",
        "confidence": 0.88,
        "reason": "org",
        "replacement": "[REDACTED_ORG]",
        "source": "claude",
    }])
    findings = review_session_pii_hybrid(session)
    entity_texts = {f["entity_text"] for f in findings}
    assert "Kai D" in entity_texts
    assert "kaidagent" in entity_texts
    assert "Acme Labs" in entity_texts


def test_content_findings_github_url():
    findings = _content_findings_for_text("s1", 0, "content", "See https://github.com/kaiaiagent/clawtrace for details")
    entity_texts = {f["entity_text"] for f in findings}
    assert "kaiaiagent" in entity_texts
    assert all(f["entity_type"] == "username" for f in findings)


def test_content_findings_github_raw_url():
    findings = _content_findings_for_text("s1", 0, "content", "https://raw.githubusercontent.com/myuser/repo/main/file.txt")
    assert any(f["entity_text"] == "myuser" for f in findings)


def test_content_findings_skips_public_github_orgs():
    findings = _content_findings_for_text("s1", 0, "content", "https://github.com/anthropic/sdk and https://github.com/npm/cli")
    entity_texts = {f["entity_text"] for f in findings}
    assert "anthropic" not in entity_texts
    assert "npm" not in entity_texts


def test_content_findings_telegram_bot_token():
    findings = _content_findings_for_text("s1", 0, "content", "token is 8773626713:AAGaVClH6X8qr59wwbwoLpqVyu3ebOi5irw here")
    assert len(findings) == 1
    assert findings[0]["entity_type"] == "custom_sensitive"
    assert "8773626713:" in findings[0]["entity_text"]


def test_content_findings_private_ips():
    text = "connect to 10.0.0.1 or 192.168.1.100 or 172.16.0.5 but not 8.8.8.8"
    findings = _content_findings_for_text("s1", 0, "content", text)
    entity_texts = {f["entity_text"] for f in findings}
    assert "10.0.0.1" in entity_texts
    assert "192.168.1.100" in entity_texts
    assert "172.16.0.5" in entity_texts
    assert "8.8.8.8" not in entity_texts


def test_content_findings_email():
    findings = _content_findings_for_text("s1", 0, "content", "contact kai@example.com for help")
    assert any(f["entity_text"] == "kai@example.com" for f in findings)


def test_content_findings_skips_noreply_emails():
    findings = _content_findings_for_text("s1", 0, "content", "Co-Authored-By: noreply@anthropic.com")
    entity_texts = {f["entity_text"] for f in findings}
    assert "noreply@anthropic.com" not in entity_texts


def test_content_findings_session_wide_apply():
    """Findings from one field should redact the same entity in other fields."""
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": "See https://github.com/kaiaiagent/clawtrace",
                "tool_uses": [
                    {"input": {"command": "gh repo view kaiaiagent/clawtrace"}, "output": {"text": "ok"}}
                ],
            }
        ],
    }
    findings = review_session_pii(session)
    redacted, count = apply_findings_to_session(session, findings)
    # The entity was found in content; session-wide apply should also redact it in tool input
    assert "kaiaiagent" not in redacted["messages"][0]["tool_uses"][0]["input"]["command"]
    assert count >= 2


def test_truncate_for_llm_keeps_ends():
    text = "A" * 7000 + "MIDDLE" + "B" * 7000
    out = _truncate_for_llm(text, max_chars=100)
    assert "TRUNCATED FOR PII REVIEW" in out
    assert out.startswith("A")
    assert out.endswith("B" * 50)
