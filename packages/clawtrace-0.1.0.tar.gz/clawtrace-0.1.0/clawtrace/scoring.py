"""Structured scoring pipeline for agentic traces.

Implements: Format → Judge → Store
See docs/scoring-algorithm.md for the full specification.

All scoring judgment lives in the rubric (.claude/skills/clawtrace-score/RUBRIC.md).
Python code handles formatting, calling the judge, and storing results. Zero scoring logic.
"""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Step:
    """A single tool-call cycle within a segment."""
    plan: str              # assistant text before tool call
    action_tool: str       # tool name
    action_input: str      # first arg / summary of input
    result_output: str     # tool output (may be truncated)
    result_status: str     # "success", "error", "failure", ""
    reflect: str           # assistant text after result (may be empty)


@dataclass
class Segment:
    """A block of agent work bounded by user messages."""
    user_message: str
    steps: list[Step]
    user_response: str | None = None   # next user message, or None
    judge_result: dict | None = None


@dataclass
class ScoringResult:
    """Final scoring output for one session."""
    segments: list[Segment]
    quality: int                 # 1-5, from judge
    reason: str                  # judge's reasoning
    taste_signals: list[dict] = field(default_factory=list)
    detail_json: str = "{}"


# ---------------------------------------------------------------------------
# Message helpers
# ---------------------------------------------------------------------------

def get_message_text(msg: dict) -> str:
    """Extract text content from a message dict."""
    content = msg.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        for block in content:
            if isinstance(block, str):
                return block
            if isinstance(block, dict) and block.get("text"):
                return block["text"]
    return ""


def extract_tool_uses(msg: dict) -> list[dict]:
    """Extract tool uses from a message, handling both parsed and raw formats."""
    tool_uses = msg.get("tool_uses", [])
    if tool_uses:
        return tool_uses
    content = msg.get("content")
    if isinstance(content, list):
        uses = []
        for block in content:
            if isinstance(block, dict) and block.get("tool"):
                inp = block.get("input", {})
                first_arg = ""
                if isinstance(inp, dict):
                    for v in inp.values():
                        if isinstance(v, str) and v.strip():
                            first_arg = v.strip()
                            break
                uses.append({
                    "tool": block["tool"],
                    "input": inp,
                    "output": block.get("output", ""),
                    "status": block.get("status", ""),
                    "first_arg": first_arg,
                })
        return uses
    return []


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len - 1] + "…"


def _first_input_value(inp: dict | Any) -> str:
    """Return the first string value from a tool input dict."""
    if isinstance(inp, dict):
        for v in inp.values():
            if isinstance(v, str) and v.strip():
                return v.strip()
    if isinstance(inp, str):
        return inp.strip()
    return ""


# ---------------------------------------------------------------------------
# Format: parse messages into turns and build the judge prompt
# ---------------------------------------------------------------------------

def segment_session(messages: list[dict]) -> list[Segment]:
    """Split a message list into Segments bounded by user messages.

    Each user message starts a new segment. Within a segment, each tool_use
    in an assistant message becomes a Step. This is purely structural formatting.
    """
    if not messages:
        return []

    segments: list[Segment] = []
    current_user_msg = ""
    current_steps: list[Step] = []
    pending_plan = ""

    def _flush_segment() -> None:
        nonlocal current_user_msg, current_steps, pending_plan
        if current_user_msg or current_steps:
            segments.append(Segment(
                user_message=current_user_msg,
                steps=current_steps,
            ))
        current_user_msg = ""
        current_steps = []
        pending_plan = ""

    for msg in messages:
        role = msg.get("role", "")

        if role == "user":
            text = get_message_text(msg)
            _flush_segment()
            if segments:
                segments[-1].user_response = text
            current_user_msg = text

        elif role == "assistant":
            text = get_message_text(msg)
            tool_uses = extract_tool_uses(msg)

            if not tool_uses:
                if current_steps:
                    current_steps[-1].reflect = text
                else:
                    pending_plan = text
            else:
                for i, tu in enumerate(tool_uses):
                    plan = text if i == 0 else ""
                    if i == 0 and pending_plan and not text:
                        plan = pending_plan
                        pending_plan = ""

                    output = tu.get("output", "")
                    if isinstance(output, dict):
                        output = json.dumps(output)[:500]
                    elif not isinstance(output, str):
                        output = str(output)[:500] if output else ""

                    current_steps.append(Step(
                        plan=plan,
                        action_tool=tu.get("tool", ""),
                        action_input=_first_input_value(tu.get("input", {})),
                        result_output=output,
                        result_status=tu.get("status", ""),
                        reflect="",
                    ))
                pending_plan = ""

    _flush_segment()

    if not segments and messages:
        segments.append(Segment(user_message="", steps=[]))

    return segments


def compute_basic_metrics(segments: list[Segment], detail: dict) -> dict:
    """Compute simple stats for the judge prompt. No scoring judgment."""
    total_steps = sum(len(s.steps) for s in segments)
    tool_failures = sum(
        1 for s in segments for step in s.steps
        if step.result_status in ("failure", "error")
    )
    files_touched = detail.get("files_touched", []) or []
    if isinstance(files_touched, str):
        try:
            files_touched = json.loads(files_touched)
        except (json.JSONDecodeError, ValueError):
            files_touched = []

    return {
        "total_steps": total_steps,
        "segments": len(segments),
        "tool_failures": tool_failures,
        "user_messages": detail.get("user_messages", 0),
        "input_tokens": detail.get("input_tokens", 0),
        "output_tokens": detail.get("output_tokens", 0),
        "duration_seconds": detail.get("duration_seconds"),
        "files_touched": len(files_touched),
        "outcome_badge": detail.get("outcome_badge"),
    }


def _extract_task_context(messages: list[dict]) -> str:
    """Extract the user's task from the first user message + refinements."""
    parts: list[str] = []
    for msg in messages:
        if msg.get("role") == "user":
            text = get_message_text(msg)
            if text:
                parts.append(text)
            if len(parts) >= 3:
                break
    return "\n".join(parts) if parts else "(no user message)"


def _format_metrics_line(metrics: dict) -> str:
    """Format basic metrics as a compact one-liner."""
    parts = []
    parts.append(f"Steps: {metrics.get('total_steps', 0)}")
    failures = metrics.get("tool_failures", 0)
    if failures:
        parts.append(f"Tool failures: {failures}")
    in_tok = metrics.get("input_tokens", 0)
    out_tok = metrics.get("output_tokens", 0)
    if in_tok or out_tok:
        parts.append(f"Tokens: {in_tok} in / {out_tok} out")
    dur = metrics.get("duration_seconds")
    if dur and isinstance(dur, (int, float)):
        minutes = int(dur) // 60
        parts.append(f"Duration: {minutes}m" if minutes else f"Duration: {int(dur)}s")
    files = metrics.get("files_touched", 0)
    if files:
        parts.append(f"Files: {files}")
    badge = metrics.get("outcome_badge")
    if badge:
        parts.append(f"Outcome: {badge}")
    return " | ".join(parts)


def format_session_for_judge(
    segments: list[Segment],
    task_context: str,
    metrics: dict | None = None,
) -> str:
    """Format the full session for a single judge call."""
    lines: list[str] = []

    lines.append("## User's Task")
    lines.append(task_context)
    lines.append("")

    if metrics:
        lines.append("## Session Metrics")
        lines.append(_format_metrics_line(metrics))
        lines.append("")

    if len(segments) == 1:
        seg = segments[0]
        lines.append(f"## Agent Work ({len(seg.steps)} steps)")
        for i, step in enumerate(seg.steps, 1):
            plan_text = _truncate(step.plan, 200) if step.plan else ""
            if plan_text:
                lines.append(f"Step {i}: {plan_text}")
            else:
                lines.append(f"Step {i}:")
            input_text = _truncate(step.action_input, 150)
            lines.append(f" → {step.action_tool}({input_text})")
            result_text = _truncate(step.result_output, 300)
            lines.append(f" → {step.result_status}: {result_text}")
        lines.append("")

        lines.append("## User Response After Agent Work")
        if seg.user_response:
            lines.append(f'"{_truncate(seg.user_response, 500)}"')
        else:
            lines.append("No response — session ended")
        lines.append("")
    else:
        for idx, seg in enumerate(segments):
            lines.append(f"## Turn {idx + 1}: User")
            lines.append(_truncate(seg.user_message, 300))
            lines.append("")

            if seg.steps:
                lines.append(f"## Turn {idx + 1}: Agent Work ({len(seg.steps)} steps)")
                for i, step in enumerate(seg.steps, 1):
                    plan_text = _truncate(step.plan, 200) if step.plan else ""
                    if plan_text:
                        lines.append(f"Step {i}: {plan_text}")
                    else:
                        lines.append(f"Step {i}:")
                    input_text = _truncate(step.action_input, 150)
                    lines.append(f" → {step.action_tool}({input_text})")
                    result_text = _truncate(step.result_output, 300)
                    lines.append(f" → {step.result_status}: {result_text}")
                lines.append("")

            if seg.user_response:
                lines.append(f"## Turn {idx + 1}: User Response")
                lines.append(f'"{_truncate(seg.user_response, 500)}"')
                lines.append("")

        # Show final state
        last_seg = segments[-1]
        if not last_seg.user_response:
            lines.append("## Session End")
            lines.append("No final user response — session ended")
            lines.append("")

    lines.append("## Respond with JSON:")
    lines.append('{"quality": N, "reasoning": "...", "outcome": N, "intent": N, "taste": {"detected": false}}')
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Judge: call LLM with rubric
# ---------------------------------------------------------------------------

_RUBRIC_SEARCH_PATHS = [
    Path(__file__).parent.parent / ".claude" / "skills" / "clawtrace-score" / "RUBRIC.md",
]

_FALLBACK_RUBRIC = """\
Score this coding agent session 1-5 for quality. \
5=excellent (verified outcome, user satisfied), 4=good, 3=average, 2=low, 1=poor. \
Return JSON with quality, reasoning, outcome, intent, and taste fields."""


def load_scoring_rubric() -> str:
    """Load the scoring rubric from the skill file."""
    for path in _RUBRIC_SEARCH_PATHS:
        if path.exists():
            text = path.read_text()
            if text.startswith("---"):
                try:
                    end = text.index("---", 3)
                    text = text[end + 3:].strip()
                except ValueError:
                    pass
            return text
    return _FALLBACK_RUBRIC


JUDGE_SCHEMA = {
    "type": "object",
    "properties": {
        "quality": {"type": "integer", "minimum": 1, "maximum": 5},
        "reasoning": {"type": "string"},
        "outcome": {"type": "integer", "minimum": 1, "maximum": 5},
        "intent": {"type": "integer", "minimum": 1, "maximum": 5},
        "taste": {
            "type": "object",
            "properties": {
                "detected": {"type": "boolean"},
                "type": {"type": "string"},
                "description": {"type": "string"},
            },
            "required": ["detected"],
        },
    },
    "required": ["quality", "reasoning", "outcome", "intent", "taste"],
}


def call_judge(
    prompt_text: str,
    model: str = "sonnet",
) -> dict:
    """Call claude -p to score a session. Returns the judge result dict."""
    rubric = load_scoring_rubric()

    cmd = [
        "claude", "-p",
        "--append-system-prompt", rubric,
        "--json-schema", json.dumps(JUDGE_SCHEMA),
        "--output-format", "json",
        "--tools", "",
        "--no-session-persistence",
        "--model", model,
    ]

    try:
        proc = subprocess.run(
            cmd,
            input=prompt_text,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except FileNotFoundError:
        raise RuntimeError("claude CLI not found. Install Claude Code first.")
    except subprocess.TimeoutExpired:
        raise RuntimeError("Timed out waiting for claude")

    if proc.returncode != 0:
        stderr = proc.stderr.strip() if proc.stderr else ""
        raise RuntimeError(f"claude exited {proc.returncode}: {stderr}")

    try:
        response = json.loads(proc.stdout)
    except json.JSONDecodeError:
        raise RuntimeError(f"Failed to parse claude response: {proc.stdout[:200]}")

    structured = response.get("structured_output")
    if structured is None:
        result_text = response.get("result", "")
        try:
            structured = json.loads(result_text)
        except (json.JSONDecodeError, TypeError):
            raise RuntimeError("No structured output in response")

    return _validate_judge_result(structured)


def _validate_judge_result(result: dict) -> dict:
    """Parse judge result safely. No scoring decisions — just type safety."""
    quality = result.get("quality")
    if not isinstance(quality, int) or not (1 <= quality <= 5):
        quality = 3  # only safety net: invalid quality defaults to middle

    outcome = result.get("outcome")
    if not isinstance(outcome, int) or not (1 <= outcome <= 5):
        outcome = quality  # default to overall quality

    intent = result.get("intent")
    if not isinstance(intent, int) or not (1 <= intent <= 5):
        intent = quality

    return {
        "quality": quality,
        "reasoning": str(result.get("reasoning", "")),
        "outcome": outcome,
        "intent": intent,
        "taste": result.get("taste", {"detected": False}),
    }


# ---------------------------------------------------------------------------
# Top-level: score_session
# ---------------------------------------------------------------------------

def score_session(
    conn: Any,
    session_id: str,
    *,
    model: str = "sonnet",
) -> ScoringResult:
    """Score a session: format → judge → store. No aggregation formulas."""
    from .index import get_session_detail

    detail = get_session_detail(conn, session_id)
    if not detail:
        return ScoringResult(
            segments=[], quality=1, reason="Session not found",
        )

    messages = detail.get("messages", [])

    # Format: parse into turns
    segments = segment_session(messages)
    if not segments:
        return ScoringResult(
            segments=[], quality=1, reason="No scorable content",
        )

    metrics = compute_basic_metrics(segments, detail)
    total_steps = metrics["total_steps"]

    if total_steps == 0:
        return ScoringResult(
            segments=segments, quality=1, reason="No tool usage",
        )

    # Judge: LLM scores holistically
    task_context = _extract_task_context(messages)
    prompt = format_session_for_judge(segments, task_context, metrics)

    try:
        result = call_judge(prompt, model)
    except RuntimeError as e:
        return ScoringResult(
            segments=segments, quality=1,
            reason=f"Judge failed: {e}",
        )

    # Store: pass through judge result, no formulas
    taste_signals = []
    taste = result.get("taste", {})
    if taste.get("detected"):
        taste_signals.append(taste)

    detail_data = {
        "quality": result["quality"],
        "outcome": result["outcome"],
        "intent": result["intent"],
        "reasoning": result["reasoning"],
        "taste_signals": taste_signals,
        "metrics": metrics,
    }

    return ScoringResult(
        segments=segments,
        quality=result["quality"],
        reason=result["reasoning"],
        taste_signals=taste_signals,
        detail_json=json.dumps(detail_data),
    )
