---
name: clawtrace
description: >
  Review, curate, and export coding agent conversation traces. Use when the user asks to
  review their traces, curate sessions, manage their workbench, export conversations,
  configure ClawTrace, or review PII/secrets in exports.
allowed-tools: Bash(clawtrace *), Bash(pip install clawtrace*), Bash(grep *)
---

<!-- clawtrace-begin -->

# ClawTrace Skill

ClawTrace helps scientists review, curate, and share their coding agent traces from Claude Code, Codex, and OpenClaw.

## Prerequisite

```bash
command -v clawtrace >/dev/null 2>&1 && echo "clawtrace: installed" || pip install clawtrace
```

Always ensure clawtrace is installed before running any command.

## Two Modes

ClawTrace has two workflows:

1. **Workbench Mode** — Review and curate traces (local-first, scientist-facing)
2. **Export Mode** — Bulk export to local JSONL

Default to **Workbench Mode** unless the user specifically asks about bulk export.

---

## Workbench Mode

When the user asks to review traces, curate sessions, look at their work history, or manage data:

### Quick Start

```bash
clawtrace scan                              # Index sessions into local DB
clawtrace inbox --json --limit 15           # Show trace cards (JSON for you to parse)
```

Parse the JSON output. Each session has: `index`, `session_id`, `display_title`, `source`, `model`, `messages`, `tokens`, `outcome_badge`, `value_badges`, `risk_badges`, `review_status`.

Present the traces to the user as a numbered list showing title, source, badges, and status. Then ask: **"Quick triage here, or open the full review UI?"**

**On a remote VM or OpenClaw session?** Skip the browser — do the full review right here in the terminal. Follow the Review & Share steps below.

### Review & Share (interactive — works via terminal, Telegram, Discord)

**Step 1 — Scan & score**

```bash
clawtrace scan
clawtrace score --batch --auto-triage
```

Present summary:

> Found 47 sessions. 23 auto-approved (quality 4-5), 8 auto-blocked (1-2), 16 need review.

If on a remote VM or the user is running OpenClaw, default to terminal review — skip the question and go straight to Step 2.

Otherwise, ask:
> How would you like to review?
> - **"review here"** — I'll show the session list and we'll triage together (works everywhere)
> - **"open UI"** — I'll launch the workbench in your browser

If user chooses the UI:

```bash
clawtrace serve
```

Tell user: "Workbench is open at localhost:8384. Triage sessions in the Inbox, then come back and say 'share' when ready."

For remote VMs: `clawtrace serve --remote` prints the SSH tunnel command.

When user returns, continue to Step 2.

**Step 2 — Show preview**

```bash
clawtrace share --status approved --preview --json
```

Parse the JSON. Present up to 10 sessions at a time with the AI summary:

> 23 approved sessions. Here are the first 10:
>
> 1. Fix auth bug (score 5) — Excellent debugging session with clear root cause analysis.
> 2. Refactor DB layer (score 4) — Clean refactor with good test coverage.
> 3. Add parser tests (score 4) — Solid test writing for edge cases.
> 4. Memory leak investigation (score 3) — Partial investigation, no resolution. [secrets_detected]
> ...10 more items...
>
> You can:
> - Remove sessions: "remove 4"
> - Inspect one: "show me 4"
> - See more: "next 10"
> - Add a comment: "note: my week 12 patent traces"
> - Confirm all: "looks good" or "share"

**Step 3 — Handle user feedback (loop until confirmed)**

If user says "remove 4, 7":

```bash
clawtrace block <id-for-4> <id-for-7> --reason "user excluded"
```

Then re-run preview and present updated list.

If user says "show me 4":

```bash
clawtrace score-view <id-for-4>
```

Present the condensed session transcript, then return to the preview.

If user adds a note, remember it for the `--note` flag.

If user says "looks good" / "share" / "yes" → proceed to Step 4.

**Step 4 — Share with confirmation**

Only after explicit user confirmation:

```bash
clawtrace share --status approved --note "<user's comment>"
```

Report to user:
> Shared 21 sessions (1.2 MB). Bundle a1b2c3d4 uploaded successfully.

### Quick Triage (without scoring)

If the user wants manual triage without AI scoring:

```bash
clawtrace inbox --json --limit 15
```

Show numbered list. Take instructions like "approve 1,3,5" or "block 2":

```bash
clawtrace approve <session-id> [session-id ...] --reason "good debugging trace"
clawtrace block <session-id> [session-id ...] --reason "contains proprietary code"
```

Map the user's index numbers to session_ids from the inbox JSON output.

### Full Review (web UI)

When the user wants deeper review — reading full transcripts, searching across sessions, or assembling bundles:

```bash
clawtrace serve
```

This opens a browser at `localhost:8384` with:
- **Inbox**: Trace cards with value/risk/outcome badges and one-click triage
- **Search**: Full-text search across all session transcripts
- **Session Detail**: Three-pane view (timeline | transcript | metadata)
- **Bundles**: Assemble and export curated upload sets
- **Policies**: Manage redaction rules and project exclusions

Tell the user: "The workbench is open in your browser. Use the Inbox to triage traces, Search to find specific sessions, and Bundles to assemble what you want to share."

### Remote VM / OpenClaw

If you're on a remote VM (common with OpenClaw), the entire workflow runs in your terminal — no browser needed:

1. `clawtrace scan --source openclaw` — index your sessions
2. `clawtrace score --batch --auto-triage` — AI-score and auto-triage
3. `clawtrace inbox --json --limit 15` — show traces (present to user as numbered list)
4. Triage with user: `clawtrace approve <id>` / `clawtrace block <id>`
5. `clawtrace share --status approved --preview --json` — preview what will be shared
6. After user confirms: `clawtrace share --status approved`

For a browser UI via SSH tunnel: `clawtrace serve --remote`

### Workbench Commands

```bash
clawtrace scan [--source claude|codex|openclaw]     # Index sessions into local DB
clawtrace inbox [--status new|shortlisted|approved|blocked] [--limit 20]  # Terminal view
clawtrace inbox --json [--status ...] [--limit 20]  # JSON output for agent parsing
clawtrace approve <id> [id ...] [--reason "..."]    # Approve sessions
clawtrace block <id> [id ...] [--reason "..."]      # Block sessions
clawtrace shortlist <id> [id ...]                    # Shortlist sessions
clawtrace search <query> [--json] [--limit 20]       # Full-text search
clawtrace share --status approved [--note "..."]      # One-step: bundle + export + share
clawtrace bundle-create [ids ...] [--status approved] # Create bundle
clawtrace bundle-list                                # List bundles
clawtrace bundle-view <bundle_id>                    # View bundle details
clawtrace bundle-export <bundle_id>                  # Export to disk
clawtrace bundle-share <bundle_id>                   # Upload bundle
clawtrace serve [--port 8384] [--no-browser] [--remote] # Launch web UI
```

---

## Export Mode

When the user asks to bulk export their conversations locally:

### THE RULE

**Every `clawtrace` command outputs `next_steps`. FOLLOW THEM.**

Do not memorize the flow. Do not skip steps. Do not improvise.
Run the command → read the output → follow `next_steps`. That's it.

### Getting Started

Run `clawtrace status` (or `clawtrace prep` for full details) and follow the `next_steps`.

### Output Format

- `clawtrace prep`, `clawtrace config`, `clawtrace status`, and `clawtrace confirm` output pure JSON
- `clawtrace export` outputs human-readable text followed by `---CLAWTRACE_JSON---` and a JSON block
- Always parse the JSON and act on `next_steps`

### PII Audit

After `clawtrace export --no-push`, follow the `next_steps` in the JSON output. The flow is:

1. **Ask the user their full name** — then grep the export for it
2. **Run the pii_commands** from the JSON output and review results with the user
3. **Ask the user what else to look for** — company names, client names, private URLs, other people's names, custom domains
4. **Deep manual scan** — sample ~20 sessions (beginning, middle, end) and look for anything sensitive the regex missed
5. **Fix and re-export** if anything found: `clawtrace config --redact "string"` then `clawtrace export --no-push`
6. **Run `clawtrace confirm` with text attestations** — pass `--full-name`, `--attest-full-name`, `--attest-sensitive`, and `--attest-manual-scan`. It runs PII scan, verifies attestations, and shows project breakdown.

### Export Commands

```bash
clawtrace status                            # Show current stage and next steps (JSON)
clawtrace prep [--source all|claude|codex|gemini|opencode|openclaw]  # Discover projects (JSON)
clawtrace list [--source ...]               # List all projects with exclusion status
clawtrace config --source all               # REQUIRED source scope
clawtrace config --exclude "a,b"            # Add excluded projects (appends)
clawtrace config --redact "str1,str2"       # Add strings to redact (appends)
clawtrace config --redact-usernames "u1,u2" # Add usernames to anonymize (appends)
clawtrace config --confirm-projects         # Mark project selection as confirmed
clawtrace export --no-push                  # Export locally
clawtrace confirm --full-name "NAME" --attest-full-name "..." --attest-sensitive "..." --attest-manual-scan "..."
```

---

## Install Skill for Other Agents

```bash
clawtrace update-skill claude               # Install to .claude/skills/clawtrace/
clawtrace update-skill openclaw             # Install to project root as CLAWTRACE_AGENTS.md
clawtrace update-skill codex                # Install to project root as CLAWTRACE_AGENTS.md
clawtrace update-skill cline                # Install to .cline/clawtrace/
```

## Gotchas

- **`--exclude`, `--redact`, `--redact-usernames` APPEND** — they never overwrite.
- **`clawtrace inbox --json`** is the preferred way for agents to read trace data.
- **`clawtrace approve/block/shortlist`** output JSON with results.
- **`clawtrace serve`** opens a browser automatically. Use `--no-browser` to suppress.

<!-- clawtrace-end -->
