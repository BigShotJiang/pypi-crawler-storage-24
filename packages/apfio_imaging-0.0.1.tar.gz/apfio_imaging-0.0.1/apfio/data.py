# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import os
from weakref import WeakValueDictionary

import numpy
from PIL import Image

__all__ = ["flower", "sunset"]

root = os.path.join(os.path.dirname(os.path.realpath(__file__)), "data")

images = WeakValueDictionary()

def load(key):
    try:
        return images[key]
    except KeyError:
        with Image.open(os.path.join(root, f"{key}.jpg")) as image:
            image = numpy.array(image)
            images[key] = image
            return image

def flower():
    """
    Loads a photograph of a flower as a numpy array.

    :return: An :py:class:`numpy:numpy.ndarray` of shape :code:`(h, w, 3)` and dtype `numpy.uint8`.
    """
    return load("flower")

def sunset():
    """
    Loads a photograph of a sunset as a numpy array.

    :return: An :py:class:`numpy:numpy.ndarray` of shape :code:`(h, w, 3)` and dtype `numpy.uint8`.
    """
    return load("sunset")
