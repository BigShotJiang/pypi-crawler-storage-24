# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import sys

import PIL
import numpy
from PIL import Image

from apfio.base.types import check_type
from apfio.imaging.array import CompressedImageArray

class PILArray(CompressedImageArray):
    """
    An image array that uses PIL for image encoding and decoding.
    """

    def check_format(self, fmt):
        Image.init() # Populates PIL.Image.ID
        if not fmt in PIL.Image.ID:
            raise ValueError(f"The object {fmt} is not an entry of PIL.Image.ID and so does not seem to represent an "
                             "image format supported by PIL!")

        if fmt == 'AVIF':
            if 'win' in sys.platform:
                # PIL supports encoding and decoding of AVIF natively on Linux.
                # But on Windows it may be necessary to install a plugin for it.
                import pillow_avif

        return fmt

    def check_encoder_config(self, config):
        try:
            params = {check_type(key, str): value for key, value in check_type(config, dict).items()}
        except TypeError as te:
            raise ValueError(f"The object {config} could not be interpreted as a mapping from strings to objects "
                             f"and so does not seem to represent a set of parameters for a PIL image encoder!") from te
        return params

    def encode(self, image, writer):
        if len(image.shape) == 3 and image.shape[-1] == 1:
            image = image.reshape(*image.shape[:-1])
        with Image.fromarray(image) as image:
            image.save(writer, format=self.format, **self.encoder_config)

    def decode(self, reader):
        with Image.open(reader, formats=(self.format, )) as image:
            image = numpy.array(image)
            if len(image.shape) == 2:
                image = image.reshape(*image.shape, 1)
            return image