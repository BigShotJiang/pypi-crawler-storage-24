# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


import os
from enum import Enum
from io import BytesIO

# The SVTAV-1 encoder produces an annoying amount of info messages on stderr. The following line disables that:
os.environ["SVT_LOG"] = "1"
import av
import numpy

from apfio.base.types import check_type
from apfio.imaging.array import CompressedImageArray


class AVIFPixelFormat(Enum):
    """
    Enumerates all pixel formats supported by :py:class:`~AVIFArray`.
    """
    YUV444P12 = 0
    YUV420P12 = 1
    YUV444P10 = 2
    YUV420P10 = 3
    YUV420P8 = 4
    YUV444P8 = 5
    GBRP8 = 6
    GBRP10 = 7
    GBRP12 = 8
    GRAY8 = 9
    YUVA444P12 = 10
    YUVA420P12 = 11
    YUVA444P10 = 12
    YUVA420P10 = 13
    YUVA420P8 = 14
    YUVA444P8 = 15
    GBRAP8 = 16
    GBRAP10 = 17
    GBRAP12 = 18

    _ignore_ = ('__ffmpeg', '__bytes', '__rgb', '__alpha')
    __ffmpeg = ['yuv444p12le', 'yuv420p12le', 'yuv444p10le', 'yuv420p10le', "yuv420p", "yuv444p",
                "gbrp", "gbrp10le", "gbrp12le", "gray",
                'yuva444p12le', 'yuva420p12le', 'yuva444p10le', 'yuva420p10le', "yuva420p", "yuva444p",
                "gbrap", "gbrap10le", "gbrap12le"
                ]
    __bytes = [2, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2]
    __rgb = [False, False, False, False, False, False, True, True, True, False, False, False, False, False, False, False, True, True, True]
    __alpha = [False] * 10 + [True] * 9

    @property
    def bytes_per_subpixel(self):
        """
        Returns the number of bytes per subpixel that would be needed to losslessly represent pixel values stored
        in this format.

        :return: A positive integer.
        """
        return AVIFPixelFormat.__bytes[self.value]

    @property
    def rgb(self):
        """
        Indicates if this pixel format is an RGB format.

        :return: A bool
        """
        return AVIFPixelFormat.__rgb[self.value]

    @property
    def alpha(self):
        """
        Indicates if this pixel format includes an alpha channel.

        :return: A bool
        """
        return AVIFPixelFormat.__alpha[self.value]

    def to_ffmpeg(self):
        """
        Turns this pixel format into a string understood by FFMPEG.

        :return: An str.
        """
        return AVIFPixelFormat.__ffmpeg[self.value]

    @staticmethod
    def from_ffmpeg(pix_fmt):
        """
        Turns a pixel format string from FFMPEG into an :py:class:`~AVIFPixelFormat`.

        :param pix_fmt: A pixel format string as printed by FFMPEG.

        :raises ValueError: If the given string is not supported as an :py:class:`~AVIFPixelFormat`.

        :return: An :py:class:`~AVIFPixelFormat` object.
        """
        try:
            return AVIFPixelFormat(AVIFPixelFormat.__ffmpeg.index(pix_fmt))
        except IndexError:
            raise ValueError(f"The pixel format string '{pix_fmt}' is not supported as an AVIFPixelFormat!")


class AVIFArray(CompressedImageArray):
    """
    An image array that encodes its images with the AVIF codec.
    """

    __ckeys = ["crf",]

    def __init__(self, *largs, **kwargs):
        super().__init__(*largs, **kwargs)
        if self.writable:
            self.format = "AVIF"
        if not self.readable:
            self.pixel_format = AVIFPixelFormat.YUV420P8

    def check_format(self, fmt):
        if fmt != "AVIF":
            raise ValueError("AVIFArray accepts only the string 'AVIF' as a format!")
        return fmt

    def check_encoder_config(self, config):
        try:
            params = {check_type(key, str): value for key, value in check_type(config, dict).items()}
        except TypeError as te:
            raise ValueError(f"The object {config} could not be interpreted as a mapping from strings to objects "
                             f"and so does not seem to represent a set of parameters for an AVIF image encoder!") from te

        for k in params.keys():
            if k not in AVIFArray.__ckeys:
                raise ValueError(f"The given mapping contains the key '{k}', which AVIFArray cannot make sense of!")

        return params

    @property
    def pixel_format(self):
        """
        The pixel format of the images stored in this array.

        :return: An :py:class:`~AVIFPixelFormat`.
        """
        meta = self.base.metadata
        try:
            return AVIFPixelFormat.from_ffmpeg(meta["pixel_format"])
        except KeyError as ke:
            raise KeyError("No image format has been set for this ZippedArray!") from ke

    @pixel_format.setter
    def pixel_format(self, fmt):

        fmt = check_type(fmt, AVIFPixelFormat)

        if fmt.alpha:
            raise NotImplementedError("Pixel formats including an alpha channel have not been fully implemented yet.")

        fmt_ffmpeg = fmt.to_ffmpeg()

        if fmt_ffmpeg not in (vf.name for vf in av.codec.Codec("libaom-av1", "w").video_formats):
            raise ValueError(f"The pixel format {fmt} is not supported by your build of pyAV+ffmpeg+libaom ! "
                             f"You can fix this only by installing a different build.")

        self.base.write_meta("pixel_format", fmt_ffmpeg)

    def encode(self, image, writer):

        t, h, w, d = image.shape if len(image.shape) == 4 else (1, *image.shape)

        with BytesIO() as buffer:
            with av.open(buffer, mode="w", format='avif') as container:

                supported_by_svtav1 = self.pixel_format in (AVIFPixelFormat.YUV420P8, AVIFPixelFormat.YUV420P10)

                # SVTAV-1 supports only a few pixel formats. The library seems improper, as it is hard to disable
                # its verbose output on stderr (see environment variable above) and because setting avif=1
                # (as is recommended for reducing memory usage in AVIF encoding) will lead to crashes because more
                # than one image is submitted to the library. If one does not set avif=1, memory consumption is
                # _very_ large.
                # So we want to work without SVTAV-1. The only motivation *for* working with it was that it is said
                # to produce files that are especially cheap to decode. We have found, though, that setting
                # color range to 'color_primaries', 'color_trc' and 'colorspace' to 'unspecified' in libaom
                # almost fully makes up for this performance gain.
                # So let's disable SVTAV-1:
                supported_by_svtav1 = False

                stream = container.add_stream("libsvtav1" if supported_by_svtav1 else "libaom-av1")
                stream.width = w
                stream.height = h
                stream.pix_fmt = self.pixel_format.to_ffmpeg()

                options = dict()

                try:
                    options['crf'] = str(self.encoder_config["crf"])
                except KeyError:
                    pass

                if supported_by_svtav1:
                    options["preset"] = "7"
                    options["svtav1-params"] = "fast-decode=2:log-level=error"
                else:
                    # options['profile:v'] = 'main'
                    options['tiles'] = "1x1"
                    options['usage'] = "realtime" # MUCH faster encoding AND smaller file.
                    options['still-picture'] = "1" # Make it clear that we're doing only a single frame.
                    # Apparently, YUV formats are customarily served in limited color range. And YUV anyways involves
                    # lossy operations, so let's swim in the mainstream here. Also we found that limited color range
                    # appears to speed up decoding. But if the user requests RGB, he/she
                    # probably cares about high-quality, or even lossless reconstruction:
                    options['color_range'] = 'full' if self.pixel_format.rgb else "limited"
                    options['color_primaries'] = 'bt709'
                    options['color_trc'] = 'gamma22'
                    options['colorspace'] = 'rgb' if self.pixel_format.rgb else 'bt709'
                    # options["cpu-used"] = "6"

                stream.options = options

                if image.dtype == numpy.uint8:
                    num_bytes = 1
                elif image.dtype == numpy.uint16:
                    num_bytes = 2
                elif image.dtype == numpy.uint32:
                    num_bytes = 4
                else:
                    raise ValueError(
                        f"The given frames have data type {image.dtype}, which is not supported by AVIFArray!")

                if d == 1:
                    fmt = "gray"
                elif d == 3:
                    fmt = f"rgb{3 * num_bytes * 8}{'' if num_bytes == 1 else 'le'}"
                elif d == 4:
                    assert num_bytes == 1
                    fmt = f"rgba"
                else:
                    raise ValueError(f"AVIFArray does not accept images with {d} channels!")
                frame = av.VideoFrame.from_ndarray(image, format=fmt)

                for packet in stream.encode(frame):
                    container.mux(packet)
                # Flush stream
                for packet in stream.encode():
                    container.mux(packet)
            writer.write(buffer.getvalue())

    def decode(self, reader):
        with av.open(reader) as container:
            for frame in container.decode(container.streams.video[0]):

                d = len(frame.planes)

                if d == 1:
                    image = frame.to_ndarray()
                elif d in (3, 4):
                    # The frame is often in some YUV format.
                    # We have to decide how many bits per RGB channel are necessary for the best result.
                    # This is not so easy to answer, but the following calculation has so far worked for all
                    # pixel formats that we support:
                    num_bits = frame.format.padded_bits_per_pixel
                    num_bits = ((num_bits + d * 8 - 1) // (d * 8)) * (d * 8)
                    image = frame.reformat(format=f'rgb{num_bits}').to_ndarray()
                else:
                    raise IOError(f"Failed to interpret frame with {d} channels!")

                h, w = image.shape[:2]
                return image.reshape(h, w, d)
        raise IOError("Failed to decode AVIF frame!")
