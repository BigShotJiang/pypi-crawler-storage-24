# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.


from abc import abstractmethod
from threading import RLock

import numpy

from apfio.base.array import check_shape
from apfio.base.transform import TransformedArray
from apfio.base.types import check_type
from apfio.util.inmemory import InMemoryFileWriter


class CompressedImageArray(TransformedArray):
    """
    An array the points of which are numpy images, that are encoded in an underlying array as compressed image files.
    """

    __key_format = "imageformat"
    __key_fshape = "frame_shape"

    def __init__(self, base, **kwargs):
        """
        Makes an array of encoded image files available as an array of numpy images.

        :param base: An :py:class:`~apfio.base.array.IndependentPointArray`.
                     :code:`base.read` must return readable file-like objects owned by and
                     exclusively accessible to the caller.
                     :code:`base.write` must accept as 'point' a procedure that takes a writable file object as its only argument
                     and will be called in the course of :code:`base.write` under a lock that guarantees exclusive access to
                     the file object.

        :param kwargs: See constructor of :py:class:`~apfio.base.transform.TransformedArray`.
        """
        super().__init__(base, **kwargs)
        self._econfig = dict()
        self._lock = RLock()
        self._written = False

    @abstractmethod
    def check_format(self, fmt):
        """
        Checks if an object represents a valid image format for this instance.
        This procedure assumes to be called under a lock that protects `self`.

        :param fmt: An :py:class:`~python:object` that is supposed to specify an image format.

        :raises ValueError: If the given object cannot be interpreted as an image format by this instance.

        :return: A sanitized version of the given format.
        """
        pass

    @abstractmethod
    def check_encoder_config(self, config):
        """
        Checks if an object represents a valid encoder configuration for this instance.
        This procedure assumes to be called under a lock that protects `self`.

        :param config: An :py:class:`~python:object` that is supposed to specify an encoder configuration.

        :raises ValueError: If the given object cannot be interpreted as an encoder configuration by this instance.

        :return: A sanitized version of the given `config`.
        """
        pass

    @abstractmethod
    def encode(self, image, writer):
        """
        Writes an encoded version of a numpy image.
        This procedure assumes to be called under a lock that protects all its arguments, but not `self`.

        :param image: A three-dimensional :py:class:`numpy:numpy.ndarray` representing an image.

        :param writer: A writable file-like object, to which the encoded image is supposed to be written.
        """
        pass

    @abstractmethod
    def decode(self, reader):
        """
        Reads an encoded version of a numpy image.
        This procedure assumes to be called under a lock that protects all its arguments, but not `self`.

        :param reader: A readable file-like object, from which encoded image is supposed to be read.

        :return: A three-dimensional :py:class:`numpy:numpy.ndarray` representing the decoded image.
        """
        pass

    def externalize(self, point):
        # Because of the constraints of this class and its superclasses, we can assume exclusive access to 'point'.
        # However, access to 'self' may not be exclusive.
        image = self.decode(point)
        if self.frame_shape is not None and image.shape != self.frame_shape:
            raise IOError(f"Error in CompressedImageArray: The array's frame shape is set to {self.frame_shape}, "
                          "but the image that was retrieved has shape {image.shape}!")
        return image, image.nbytes

    def internalize(self, point):
        if self.frame_shape is not None and point.shape != self.frame_shape:
            raise ValueError(f"The given image has shape {point.shape}, but this CompressedImageArray must guarantee "
                          f"a frame shape of {self.frame_shape}!")

        # The caller may be just one thread of many. It should immediately start encoding the image into a private
        # buffer, which can happen concurrently.

        # Note: For in-memory encoding one could just use a BytesIO object.
        #       However, we have observed the following: BytesIO does not return a fileno, i.e. there is no "OS-official"
        #       file descriptor for it. And whatever object one passes that does not have a file descriptor, PIL
        #       (and possibly other C-based libraries)
        #       does not seem to release the GIL for the encoding, leading to loss of concurrency.
        #       This is why instead we use InMemoryFileWriter, which we specifically designed for this purpose.
        #       We could have used tempfile.TemporaryFile instead, which also gives a file descriptor.
        #       But although that would be a simpler solution, timing tests showed it to be on par on a laptop with
        #       tmpfs. On systems that actually use disk space for temporary directories, the tempfile module may or
        #       may not be slower, as it is creating a physical file.
        with InMemoryFileWriter() as buffer:
            self.encode(check_type(point, numpy.ndarray), buffer)
            buffer.close()
            encoded = buffer.getvalue()

        # The actual write to the underlying instance can very well require exclusive access to that instance,
        # which is why the encoding should already be finished when that write finally gets to be executed under a lock.
        def write(writer):
            writer.write(encoded)

        return write

    def write(self, point, *indices):
        super().write(point, *indices)
        self._written = True

    @property
    def format(self):
        """
        The image format to use for compressing images.

        :return: A return value of :py:meth:`~CompressedImageArray.check_format`.
        """
        with self._lock:
            meta = self.base.metadata
            try:
                return self.check_format(meta[CompressedImageArray.__key_format])
            except KeyError as ke:
                raise KeyError("No image format has been set for this ZippedArray!") from ke

    @format.setter
    def format(self, fmt):
        with self._lock:
            self.base.write_meta(CompressedImageArray.__key_format, self.check_format(fmt))

    @property
    def frame_shape(self):
        """
        The shape of the numpy arrays that represent the individual images in this array.
        If this is not `None`, all images in this array are guaranteed to have this shape.

        :return: Either `None`, or a tuple of integers.
        """
        with self._lock:
            meta = self.base.metadata
            try:
                return check_shape(meta[CompressedImageArray.__key_fshape])
            except KeyError as ke:
                return None

    @frame_shape.setter
    def frame_shape(self, shape):
        with self._lock:
            if self._written:
                raise RuntimeError("The frame shape of a CompressedImageArray can only be changed as long as no "
                                   "images have been added to the array yet!")
            self.base.write_meta(CompressedImageArray.__key_fshape, check_shape(shape))

    @property
    def encoder_config(self):
        """
        The configuration to use for encoding images.

        :return: A return value of :py:meth:`~CompressedImageArray.check_encoder_config`.
        """
        # These parameters do not matter for decoding and hence do not need to be read from metadata.
        with self._lock:
            return self._econfig

    @encoder_config.setter
    def encoder_config(self, config):
        # These parameters do not matter for decoding and hence do not need to be written to metadata.
        with self._lock:
            self._econfig = self.check_encoder_config(config)

    @property
    def metadata(self):
        reserved = (CompressedImageArray.__key_format, CompressedImageArray.__key_fshape)
        return {k: v for k, v in self.base.metadata.items() if k not in reserved}

    def write_meta(self, key, info):
        if key in (CompressedImageArray.__key_format, CompressedImageArray.__key_fshape):
            raise ValueError(f"The key {key} is used by CompressedImageArray to document which image codec was used!")
        self.base.write_meta(key, info)
