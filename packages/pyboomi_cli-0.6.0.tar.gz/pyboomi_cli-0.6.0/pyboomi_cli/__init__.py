# PyBoomi CLI - Main Package
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-07-27

"""
PyBoomi CLI - Command-line interface for the Boomi Platform API.

This package provides a comprehensive command-line tool for interacting with
the Boomi Platform API. It enables developers and system administrators to
manage Boomi integrations, processes, folders, and other platform resources
directly from the terminal.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("pyboomi-cli")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"

# Import main CLI function for easy access
from .cli import main

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    "main",
]
