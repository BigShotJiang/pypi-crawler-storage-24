# PyBoomi CLI - Configuration Management
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Configuration management for PyBoomi CLI."""

import json
from pathlib import Path
from typing import Any, Dict, Optional


def get_config_file_path() -> Path:
    """Get the configuration file path."""
    # Check for config file in current directory first
    local_config = Path(".pyboomi.json")
    if local_config.exists():
        return local_config

    # Check in user home directory
    home_config = Path.home() / ".pyboomi.json"
    return home_config


def get_config() -> Optional[Dict[str, Any]]:
    """Load configuration from file if it exists."""
    config_file = get_config_file_path()

    if not config_file.exists():
        return None

    try:
        with open(config_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None
