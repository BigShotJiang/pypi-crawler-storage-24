# PyBoomi CLI - Utilities
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-01-27

"""Utility functions for PyBoomi CLI operations."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import json
import os
import re
from pathlib import Path
from typing import Dict, Optional

import click
from pyboomi_platform.auth import BoomiAuth
from pyboomi_platform.client import BoomiPlatformClient


def _apply_accept_header(client, accept: Optional[str]) -> None:
    """
    Best-effort application of an Accept header on the underlying client/session.
    Supports multiple possible client shapes without failing hard.
    """
    if not accept:
        return

    applied = False

    # Common requests-style session
    session = getattr(client, "session", None)
    if session and hasattr(session, "headers"):
        try:
            session.headers["Accept"] = accept
            applied = True
        except Exception:
            pass

    # Some clients expose default_headers dict
    default_headers = getattr(client, "default_headers", None)
    if isinstance(default_headers, dict):
        try:
            default_headers["Accept"] = accept
            applied = True
        except Exception:
            pass

    # Fallback attribute for downstream use if the client inspects it
    if not applied:
        try:
            setattr(client, "accept", accept)
        except Exception:
            pass


def get_client(account_id=None, username=None, api_token=None, accept: Optional[str] = None):
    """
    Get a configured BoomiPlatformClient with authentication.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - Function arguments (username, api_token)
    - Environment variables (BOOMI_USER, BOOMI_TOKEN)

    Account ID can come from function argument or BOOMI_ACCT env var.

    Args:
        account_id: Boomi account ID (optional, can use BOOMI_ACCT env var)
        username: Boomi user email (optional, can use BOOMI_USER env var)
        api_token: Boomi Platform API token (optional, can use BOOMI_TOKEN env var)

    Returns:
        BoomiPlatformClient: Configured client instance with optional Accept header

    Raises:
        click.UsageError: If required credentials are missing
    """
    account_id = account_id or os.getenv("BOOMI_ACCT")
    if not account_id:
        raise click.UsageError("Boomi account ID must be provided via --account-id or BOOMI_ACCT environment variable.")

    boomi_auth_header = os.getenv("BOOMI_AUTH")

    if boomi_auth_header:
        # BOOMI_AUTH is base64 encoded "BOOMI_TOKEN.email:uuid"
        # Extract username and password for client initialization
        try:
            import base64

            decoded = base64.b64decode(boomi_auth_header).decode("utf-8")
            if ":" in decoded:
                # Format is "BOOMI_TOKEN.email:uuid"
                client_username, client_api_token = decoded.split(":", 1)
            else:
                # Fallback if no colon found
                client_username = decoded
                client_api_token = "token"
        except Exception:
            # If decoding fails, use placeholders
            client_username = "user"
            client_api_token = "token"

        # Construct a fake BoomiAuth wrapper that returns the existing auth header
        # The header is already base64 encoded, so we use it directly
        class StaticBoomiAuth:
            """Wrapper for pre-encoded Basic Auth header."""

            def get_auth_header(self):
                """Return pre-encoded authorization header."""
                return {"Authorization": f"Basic {boomi_auth_header}"}

        auth = StaticBoomiAuth()
    else:
        username = username or os.getenv("BOOMI_USER")
        api_token = api_token or os.getenv("BOOMI_TOKEN")

        if not username or not api_token:
            raise click.UsageError(
                "You must provide credentials using either:\n"
                "- BOOMI_AUTH (base64 encoded Basic Auth string), or\n"
                "- --username and --api-token (or BOOMI_USER and BOOMI_TOKEN env vars)"
            )
        auth = BoomiAuth(username, api_token)
        client_username = username
        client_api_token = api_token

    # Inject the custom auth into the client
    client = BoomiPlatformClient(account_id, username=client_username, api_token=client_api_token, base_url=None)
    client.auth = auth

    # Apply Accept header if requested (e.g., force XML responses)
    _apply_accept_header(client, accept)

    return client


def sanitize_filename(name: str) -> str:
    """
    Sanitize a filename by removing filesystem-unsafe characters.

    Removes or replaces characters that are not safe for filesystem use:
    /, \\, :, *, ?, ", <, >, |

    Args:
        name: Original filename string

    Returns:
        str: Sanitized filename safe for filesystem use
    """
    if not name:
        return "unknown"

    # Remove filesystem-unsafe characters
    unsafe_chars = r'[/\\:*?"<>|]'
    sanitized = re.sub(unsafe_chars, "", name)

    # Replace spaces with underscores for better filesystem compatibility
    sanitized = sanitized.replace(" ", "_")

    # Remove leading/trailing dots and spaces (Windows issue)
    sanitized = sanitized.strip(". ")

    # If empty after sanitization, return a default
    if not sanitized:
        return "unknown"

    return sanitized


def format_output(data, output_format="json"):
    """
    Format data for output in the specified format.

    Args:
        data: Data to format (dict, list, etc.)
        output_format: Output format ('json', 'yaml', or 'text')

    Returns:
        str: Formatted output string
    """
    if output_format == "json":
        return json.dumps(data, indent=2)
    elif output_format == "yaml":
        try:
            import yaml

            return yaml.dump(data, default_flow_style=False, sort_keys=False)
        except ImportError:
            click.echo("Warning: PyYAML not installed. Falling back to JSON format.", err=True)
            return json.dumps(data, indent=2)
    elif output_format == "text":
        # Simple text formatting for common component fields
        if isinstance(data, dict):
            lines = []
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    lines.append(f"{key}:")
                    lines.append(json.dumps(value, indent=2))
                else:
                    lines.append(f"{key}: {value}")
            return "\n".join(lines)
        else:
            return str(data)
    elif output_format == "xml":
        # For XML we expect a string or bytes payload; pass through as text
        if isinstance(data, bytes):
            return data.decode("utf-8", errors="replace")
        return str(data)
    else:
        # Default to JSON
        return json.dumps(data, indent=2)


def get_templates_directory() -> Path:
    """
    Get the templates directory path.

    Checks in order:
    1. Environment variable PYBOOMI_TEMPLATES_DIR
    2. Current working directory 'templates/'
    3. User home directory '~/.pyboomi-cli/templates/'

    Returns:
        Path: Path to templates directory
    """
    # Check environment variable first
    env_path = os.getenv("PYBOOMI_TEMPLATES_DIR")
    if env_path:
        return Path(env_path).expanduser()

    # Check current working directory
    cwd_templates = Path.cwd() / "templates"
    if cwd_templates.exists():
        return cwd_templates

    # Default to current working directory (will be created if needed)
    return Path.cwd() / "templates"


def find_template_file(template_path: str, component_type: Optional[str] = None) -> Path:
    """
    Find a template file by path.

    The template_path can be:
    - A relative path from templates directory (e.g., "processes/basic.xml")
    - An absolute path
    - A filename that will be searched in component_type subdirectory

    Args:
        template_path: Path to template file
        component_type: Optional component type subdirectory (e.g., "processes")

    Returns:
        Path: Path to template file

    Raises:
        click.UsageError: If template file is not found
    """
    template_path_obj = Path(template_path)

    # If it's an absolute path and exists, use it
    if template_path_obj.is_absolute() and template_path_obj.exists():
        return template_path_obj

    # Get templates directory
    templates_dir = get_templates_directory()

    # If template_path contains a slash, treat as relative to templates_dir
    if "/" in template_path or "\\" in template_path:
        full_path = templates_dir / template_path
        if full_path.exists():
            return full_path

    # Otherwise, search in component_type subdirectory
    if component_type:
        full_path = templates_dir / component_type / template_path
        if full_path.exists():
            return full_path

    # Try just in templates_dir
    full_path = templates_dir / template_path
    if full_path.exists():
        return full_path

    # Not found
    raise click.UsageError(
        f"Template file not found: {template_path}\n"
        f"Searched in: {templates_dir}" + (f"/{component_type}" if component_type else "")
    )


def scan_template_parameters(template_content: str) -> Dict[str, Optional[str]]:
    """
    Scan template content for all unique template parameters.

    Template parameters use {{parameterName}} or {{parameterName:default value}} syntax.
    Default values can span multiple lines.

    Args:
        template_content: Template file content as string

    Returns:
        Dict[str, Optional[str]]: Dictionary mapping parameter names to their default values
                                  (None if no default provided)
    """
    parameters = {}

    # Pattern to match {{parameterName:default value}} (with default, supports multi-line)
    # Uses non-greedy matching to stop at the first }} (closing braces)
    # The (?s) flag makes . match newlines
    pattern_with_default = r"\{\{(\w+):(.*?)\}\}"
    matches_with_default = re.findall(pattern_with_default, template_content, re.DOTALL)
    for param_name, default_value in matches_with_default:
        # Strip leading/trailing whitespace but preserve internal structure
        parameters[param_name] = default_value.strip()

    # Pattern to match {{parameterName}} (without default)
    # But exclude those that were already matched with defaults
    pattern_no_default = r"\{\{(\w+)\}\}"
    matches_no_default = re.findall(pattern_no_default, template_content)
    for param_name in matches_no_default:
        # Only add if not already found with a default value
        if param_name not in parameters:
            parameters[param_name] = None

    return parameters


def display_template_parameter_summary(
    parameters: Dict[str, Optional[str]],
    provided_values: Optional[Dict[str, str]] = None,
) -> None:
    """
    Display a summary of template parameters to the user.

    Shows all parameters, indicating which have defaults, which are already provided,
    and which still need values.

    Args:
        parameters: Dictionary mapping parameter names to their default values (None if no default)
        provided_values: Optional dictionary of already-provided parameter values
    """
    if not parameters:
        return

    if provided_values is None:
        provided_values = {}

    click.echo("\n" + "=" * 70)
    click.echo("Template Parameter Summary")
    click.echo("=" * 70)

    # Separate parameters into categories
    with_defaults = []
    without_defaults = []
    already_provided = []

    for param_name in sorted(parameters.keys()):
        if param_name in provided_values:
            already_provided.append((param_name, provided_values[param_name]))
        elif parameters[param_name] is not None:
            with_defaults.append((param_name, parameters[param_name]))
        else:
            without_defaults.append(param_name)

    # Display already provided parameters
    if already_provided:
        click.echo("\n✓ Already Provided:")
        for param_name, value in already_provided:
            # Truncate long values for display
            display_value = value if len(value) <= 60 else value[:57] + "..."
            if "\n" in display_value:
                display_value = display_value.split("\n")[0] + " ... (multi-line)"
            click.echo(f"  • {param_name}: {display_value}")

    # Display parameters with defaults
    if with_defaults:
        click.echo("\nParameters with Default Values:")
        for param_name, default_value in with_defaults:
            # Truncate long defaults for display
            if default_value is None:
                display_default = "None"
            elif len(default_value) <= 60:
                display_default = default_value
            else:
                display_default = default_value[:57] + "..."
            
            if display_default and "\n" in display_default:
                display_default = display_default.split("\n")[0] + " ... (multi-line)"
            click.echo(f"  • {param_name}")
            click.echo(f"    Default: {display_default}")

    # Display parameters without defaults
    if without_defaults:
        click.echo("\nParameters Requiring Values (no defaults):")
        for param_name in without_defaults:
            click.echo(f"  • {param_name}")

    click.echo("\n" + "=" * 70)


def prompt_for_template_parameters(
    parameters: Dict[str, Optional[str]],
    existing_values: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    """
    Prompt user for values for all template parameters.

    Args:
        parameters: Dictionary mapping parameter names to their default values (None if no default)
        existing_values: Optional dict of pre-filled values (won't prompt for these)

    Returns:
        Dict[str, str]: Dictionary mapping parameter names to values
    """
    if existing_values is None:
        existing_values = {}

    values = {}
    sorted_params = sorted(parameters.keys())

    for param in sorted_params:
        if param in existing_values:
            values[param] = existing_values[param]
            click.echo(f"{param}: {existing_values[param]} (using provided value)")
        else:
            # Convert parameter name to a more readable prompt
            prompt_text = param.replace("_", " ").replace("-", " ").title()
            default_value = parameters.get(param)

            if default_value is not None:
                # Use default value in prompt
                value = click.prompt(
                    f"Enter value for {prompt_text} ({param})",
                    default=default_value,
                    type=str,
                )
            else:
                # No default, require input
                value = click.prompt(f"Enter value for {prompt_text} ({param})", type=str)
            values[param] = value

    return values


def replace_template_parameters(template_content: str, parameter_values: Dict[str, str]) -> str:
    """
    Replace template parameters with provided values.

    Handles both formats:
    - {{parameterName}} (no default)
    - {{parameterName:default value}} (with default, supports multi-line)

    Args:
        template_content: Template content with {{parameterName}} or {{parameterName:default}} placeholders
        parameter_values: Dictionary mapping parameter names to values

    Returns:
        str: Template content with parameters replaced
    """
    result = template_content
    for param_name, param_value in parameter_values.items():
        # Replace {{paramName:default}} format first (more specific, supports multi-line)
        # Use non-greedy matching with DOTALL flag to handle multi-line defaults
        pattern_with_default = r"\{\{" + re.escape(param_name) + r":.*?\}\}"
        result = re.sub(pattern_with_default, str(param_value), result, flags=re.DOTALL)

        # Then replace {{paramName}} format (no default)
        pattern_no_default = r"\{\{" + re.escape(param_name) + r"\}\}"
        result = re.sub(pattern_no_default, str(param_value), result)
    return result


def load_and_process_template(
    template_path: str,
    component_type: Optional[str] = None,
    parameter_values: Optional[Dict[str, str]] = None,
    prompt_missing: bool = True,
) -> str:
    """
    Load a template file, scan for parameters, prompt for values, and replace them.

    Args:
        template_path: Path to template file
        component_type: Optional component type subdirectory
        parameter_values: Optional pre-filled parameter values
        prompt_missing: Whether to prompt for missing parameters (default: True)

    Returns:
        str: Processed template content with all parameters replaced
    """
    # Find and load template file
    template_file = find_template_file(template_path, component_type)

    try:
        with open(template_file, "r", encoding="utf-8") as f:
            template_content = f.read()
    except Exception as e:
        raise click.UsageError(f"Error reading template file {template_file}: {e}")

    # Scan for parameters (returns dict with parameter names and default values)
    parameters = scan_template_parameters(template_content)

    if not parameters:
        # No parameters to replace, return as-is
        return template_content

    # Get parameter values
    if parameter_values is None:
        parameter_values = {}

    # Prompt for missing parameters if requested
    if prompt_missing:
        missing_params = {k: v for k, v in parameters.items() if k not in parameter_values}
        if missing_params:
            # Display summary of all parameters (including those already provided)
            display_template_parameter_summary(parameters, parameter_values)

            # Ask user if they want to continue or abort
            click.echo("\nYou can proceed to provide values for the missing parameters,")
            click.echo("or abort now to gather the necessary information first.")
            if not click.confirm("\nDo you want to continue with parameter entry?", default=True):
                click.echo("\nOperation cancelled. Please gather the required information and try again.")
                raise click.Abort()

            click.echo(f"\nTemplate contains {len(missing_params)} parameter(s) that need values:")
            prompted_values = prompt_for_template_parameters(missing_params, parameter_values)
            parameter_values.update(prompted_values)
    else:
        # If not prompting, apply default values for parameters that don't have values yet
        for param_name, default_value in parameters.items():
            if param_name not in parameter_values and default_value is not None:
                parameter_values[param_name] = default_value

    # Check that all parameters have values
    missing = set(parameters.keys()) - set(parameter_values.keys())
    if missing:
        raise click.UsageError(
            f"Missing values for template parameters: {', '.join(sorted(missing))}\n"
            f"Please provide values for all parameters."
        )

    # Replace parameters
    processed_content = replace_template_parameters(template_content, parameter_values)

    return processed_content
