# PyBoomi CLI - Environment Commands
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Author: Robert Little
# Created: 2026-01-26

"""Environment management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys

import click

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


try:
    from pyboomi_platform.utils import build_query_filter
except (ImportError, AttributeError):

    def build_query_filter(filters):
        """Fallback query filter builder."""
        return filters


@click.group("environment")
@click.pass_context
@click.option("--account-id", envvar="BOOMI_ACCT", help="Boomi account ID")
@click.option("--username", envvar="BOOMI_USER", help="Boomi user email")
@click.option("--api-token", envvar="BOOMI_TOKEN", help="Boomi Platform API token")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi environments.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi environment --account-id ACCT123 get <env-id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("get")
@click.pass_context
@click.argument("environment_id", required=False)
@click.option("--name", help="Environment name (alternative to environment ID)")
@click.option(
    "--output-format",
    type=click.Choice(["json", "yaml", "text"]),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: environment_get_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, environment_id, name, output_format, save, save_filename, quiet):
    """Get environment by ID or name."""
    if not environment_id and not name:
        raise click.UsageError("Either ENVIRONMENT_ID or --name must be provided.")
    if environment_id and name:
        raise click.UsageError("Provide either ENVIRONMENT_ID or --name, not both.")

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        if environment_id:
            environment = client.get_environment(environment_id)
        else:
            filters = build_query_filter({"name": name})
            environments = client.query_environments(filters)
            if not environments.get("result"):
                raise click.UsageError(f"Environment '{name}' not found.")
            if len(environments["result"]) > 1:
                raise click.UsageError(f"Multiple environments found with name '{name}'. Use environment ID instead.")
            environment = environments["result"][0]

        formatted = format_output(environment, output_format)
        effective_id = environment.get("id") or environment_id or name or "unknown"
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"environment_get_{effective_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query")
@click.pass_context
@click.option("--name", help="Filter by environment name")
@click.option("--classification", help="Filter by classification (e.g., PRODUCTION, TEST)")
@click.option("--id", "environment_id", help="Filter by environment ID")
@click.option(
    "--output-format",
    type=click.Choice(["json", "yaml", "text"]),
    default="json",
    help="Output format (default: json)",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: environment_query.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(ctx, name, classification, environment_id, output_format, save, save_filename, quiet):
    """Query environments with optional filters."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        raw_filters = {}
        if name:
            raw_filters["name"] = name
        if classification:
            raw_filters["classification"] = classification
        if environment_id:
            raw_filters["id"] = environment_id

        if raw_filters:
            filters = build_query_filter(raw_filters)
            environments = client.query_environments(filters)
        else:
            environments = client.query_environments()

        formatted = format_output(environments, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "environment_query.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Add alias for query command
command.add_command(query, name="q")
