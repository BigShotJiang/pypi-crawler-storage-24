# PyBoomi CLI - Branch Command
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-02-19

"""Branch management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys

import click
from pyboomi_platform.utils import build_query_filter

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except ImportError:
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


@click.group("branch")
@click.pass_context
@click.option("--account-id", help="Boomi account ID (or use BOOMI_ACCT)")
@click.option("--username", help="Boomi user email (or use BOOMI_USER)")
@click.option("--api-token", help="Boomi Platform API token (or use BOOMI_TOKEN)")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi branches.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi branch --account-id ACCT123 get <branch-id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("get")
@click.pass_context
@click.argument("branch_id")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: branch_get_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, branch_id, output_format, save, save_filename, quiet):
    """Get a branch by ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        branch = client.get_branch(branch_id)
        formatted = format_output(branch, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip() if save_filename and save_filename.strip() else f"branch_get_{branch_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query")
@click.pass_context
@click.option("--name", help="Filter by branch name")
@click.option("--parent-branch-id", help="Filter by parent branch ID")
@click.option("--package-id", help="Filter by package ID")
@click.option("--ready", type=bool, help="Filter by readiness flag")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: branch_query.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(ctx, name, parent_branch_id, package_id, ready, output_format, save, save_filename, quiet):
    """Query branches with optional filters."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        raw_filters = {}
        if name is not None:
            raw_filters["name"] = name
        if parent_branch_id is not None:
            raw_filters["parentId"] = parent_branch_id
        if package_id is not None:
            raw_filters["packageId"] = package_id
        if ready is not None:
            raw_filters["ready"] = ready

        if raw_filters:
            filters = build_query_filter(raw_filters)
            branches = client.query_branches(filters)
        else:
            branches = client.query_branches()

        formatted = format_output(branches, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "branch_query.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Alias for lazy developers
command.add_command(query, name="q")


@command.command("create")
@click.pass_context
@click.argument("branch_name")
@click.option("--description", help="Branch description (optional)")
@click.option("--parent-branch-id", help="Parent branch ID to create from")
@click.option("--parent-branch-name", help="Parent branch name to create from (resolves to --parent-account-id)")
@click.option("--package-id", help="Package ID to create from")
@click.option("--deployment-id", help="Deployment ID to create from (uses associated package)")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: branch_create.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def create(
    ctx,
    branch_name,
    description,
    parent_branch_id,
    parent_branch_name,
    package_id,
    deployment_id,
    output_format,
    save,
    save_filename,
    quiet,
):
    """Create a branch from a parent branch, package, or deployment."""
    sources = [parent_branch_id, package_id, deployment_id, parent_branch_name]
    if sum(s is not None for s in sources) != 1:
        raise click.UsageError(
            "Exactly one of --parent-branch-id, --parent-branch-name, --package-id, or --deployment-id must be provided."
        )

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        if parent_branch_name:
            # Resolve parent branch name to ID
            filters = build_query_filter({"name": parent_branch_name})
            parent_branches = client.query_branches(filters)
            if not parent_branches.get("result"):
                raise click.UsageError(f"Parent branch '{parent_branch_name}' not found.")
            parent_branch_id = parent_branches["result"][0]["id"]

        branch = client.components.create_branch(
            parent_branch_id=parent_branch_id,
            branch_name=branch_name,
            package_id=package_id,
            deployment_id=deployment_id,
            description=description,
        )
        formatted = format_output(branch, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "branch_create.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("update")
@click.pass_context
@click.argument("branch_id")
@click.option("--name", help="New branch name")
@click.option("--description", help="Branch description")
@click.option("--ready/--not-ready", default=None, help="Mark branch readiness")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: branch_update_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def update(ctx, branch_id, name, description, ready, output_format, save, save_filename, quiet):
    """Update a branch's properties."""
    if name is None and description is None and ready is None:
        raise click.UsageError("Provide at least one of --name, --description, or --ready/--not-ready.")

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        branch = client.update_branch(branch_id=branch_id, name=name, description=description, ready=ready)
        formatted = format_output(branch, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip() if save_filename and save_filename.strip() else f"branch_update_{branch_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("delete")
@click.pass_context
@click.argument("branch_id", required=False)
@click.option("--name", help="Name of branch to delete")
@click.option("--auto-approve", is_flag=True, help="Skip confirmation prompt")
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: branch_delete_<id>.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def delete(ctx, branch_id, name, auto_approve, save, save_filename, quiet):
    """Delete a branch by ID or name."""
    if not branch_id and not name:
        raise click.UsageError("Either BRANCH_ID or --name must be provided.")
    if branch_id and name:
        raise click.UsageError("Provide either BRANCH_ID or --name, not both.")

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        if name:
            # Resolve branch name to ID
            filters = build_query_filter({"name": name})
            branches = client.components.query_branches(filters)
            if not branches.get("result"):
                raise click.UsageError(f"Branch '{name}' not found.")
            branch_id = branches["result"][0]["id"]

        if not auto_approve:
            branch = client.components.get_branch(branch_id)
            click.echo("\nBranch Details:")
            click.echo(f"  ID: {branch.get('id')}")
            click.echo(f"  Name: {branch.get('name')}")
            if branch.get("parentId"):
                click.echo(f"  Parent ID: {branch.get('parentId')}")
            click.echo(f"  Ready: {branch.get('ready', False)}")
            click.echo("\n⚠️  WARNING: This action is permanent and cannot be undone.\n")
            if not click.confirm("Are you sure you want to delete this branch?"):
                click.echo("Deletion cancelled.")
                return

        client.delete_branch(branch_id)
        success_msg = "Branch deleted."
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip() if save_filename and save_filename.strip() else f"branch_delete_{branch_id}.txt"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(success_msg + "\n")
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(success_msg)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Alias for lazy developers
command.add_command(delete, name="rm")
