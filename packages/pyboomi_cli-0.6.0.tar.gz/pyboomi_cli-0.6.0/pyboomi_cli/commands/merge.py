# PyBoomi CLI - Merge Command
#
# Copyright 2026 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# DISCLAIMER:
#     This software is an independent project and is not affiliated with,
#     endorsed by, or supported by Boomi or any of their subsidiaries or
#     affiliates. All trademarks, service marks, and company names are the property of
#     their respective owners. Use of these names does not imply endorsement.
#
# Author: Robert Little
# Created: 2026-03-09

"""MergeRequest commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2026, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys

import click
from pyboomi_platform.utils import build_query_filter

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


@click.group("merge")
@click.pass_context
@click.option("--account-id", help="Boomi account ID (or use BOOMI_ACCT)")
@click.option("--username", help="Boomi user email (or use BOOMI_USER)")
@click.option("--api-token", help="Boomi Platform API token (or use BOOMI_TOKEN)")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi merge requests.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi merge --account-id ACCT123 get <merge-request-id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("create")
@click.pass_context
@click.option("--source-branch-id", required=True, help="Source branch ID to merge from")
@click.option("--destination-branch-id", required=True, help="Destination branch ID to merge into")
@click.option(
    "--strategy",
    type=click.Choice(["OVERRIDE", "CONFLICT_RESOLVE", "SUBSET"]),
    default="CONFLICT_RESOLVE",
    help="Merge strategy",
)
@click.option(
    "--priority-branch", type=click.Choice(["SOURCE", "DESTINATION"]), help="Priority branch for OVERRIDE strategy"
)
@click.option("--note", help="Optional note for the merge request")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_create.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def create(
    ctx,
    source_branch_id,
    destination_branch_id,
    strategy,
    priority_branch,
    note,
    output_format,
    save,
    save_filename,
    quiet,
):
    """Create a merge request between two branches."""
    if strategy == "OVERRIDE" and not priority_branch:
        raise click.UsageError("--priority-branch is required when using OVERRIDE strategy.")

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        payload = {
            "sourceBranchId": source_branch_id,
            "destinationBranchId": destination_branch_id,
            "strategy": strategy,
        }

        if priority_branch:
            payload["priorityBranch"] = priority_branch
        if note:
            payload["note"] = note

        merge_request = client.components.create_merge_request(**payload)
        formatted = format_output(merge_request, output_format)

        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "merge_create.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("get")
@click.pass_context
@click.argument("merge_request_id")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_get_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, merge_request_id, output_format, save, save_filename, quiet):
    """Get a merge request by ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        merge_request = client.components.get_merge_request(merge_request_id)
        formatted = format_output(merge_request, output_format)

        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"merge_get_{merge_request_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("bulk")
@click.pass_context
@click.argument("merge_request_ids", nargs=-1, required=True)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_bulk.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def bulk(ctx, merge_request_ids, output_format, save, save_filename, quiet):
    """Retrieve multiple merge requests by IDs."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        merge_requests = client.components.get_merge_request_bulk(list(merge_request_ids))
        formatted = format_output(merge_requests, output_format)

        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "merge_bulk.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("update")
@click.pass_context
@click.argument("merge_request_id")
@click.option("--strategy", type=click.Choice(["OVERRIDE", "CONFLICT_RESOLVE", "SUBSET"]), help="Update merge strategy")
@click.option("--note", help="Update note for the merge request")
@click.option("--component-guid", help="Component GUID for conflict resolution")
@click.option(
    "--resolution", type=click.Choice(["OVERRIDE", "KEEP_DESTINATION"]), help="Resolution for component conflict"
)
@click.option("--exclude-component", help="Component GUID to exclude from merge")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_update_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def update(
    ctx,
    merge_request_id,
    strategy,
    note,
    component_guid,
    resolution,
    exclude_component,
    output_format,
    save,
    save_filename,
    quiet,
):
    """Update a merge request."""
    if not any([strategy, note, component_guid, exclude_component]):
        raise click.UsageError("Provide at least one of --strategy, --note, --component-guid, or --exclude-component.")

    if component_guid and not resolution:
        raise click.UsageError("--resolution is required when --component-guid is specified.")

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        payload = {"id": merge_request_id}

        if strategy:
            payload["strategy"] = strategy
        if note:
            payload["note"] = note

        if component_guid and resolution:
            payload["MergeRequestDetails"] = {
                "MergeRequestDetail": {"componentGuid": component_guid, "resolution": resolution}
            }

        if exclude_component:
            if "MergeRequestDetails" not in payload:
                payload["MergeRequestDetails"] = {"MergeRequestDetail": {}}
            payload["MergeRequestDetails"]["MergeRequestDetail"]["componentGuid"] = exclude_component
            payload["MergeRequestDetails"]["MergeRequestDetail"]["excluded"] = True

        merge_request = client.components.update_merge_request(merge_request_id, **payload)
        formatted = format_output(merge_request, output_format)

        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"merge_update_{merge_request_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("delete")
@click.pass_context
@click.argument("merge_request_id")
@click.option("--auto-approve", is_flag=True, help="Skip confirmation prompt")
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_delete_<id>.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def delete(ctx, merge_request_id, auto_approve, save, save_filename, quiet):
    """Delete a merge request by ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        if not auto_approve:
            merge_request = client.components.get_merge_request(merge_request_id)
            click.echo("\nMerge Request Details:")
            click.echo(f"  ID: {merge_request.get('id')}")
            click.echo(
                f"  Source Branch: {merge_request.get('sourceBranchName')} ({merge_request.get('sourceBranchId')})"
            )
            click.echo(
                f"  Destination Branch: {merge_request.get('destinationBranchName')} ({merge_request.get('destinationBranchId')})"
            )
            click.echo(f"  Stage: {merge_request.get('stage')}")
            click.echo(f"  Strategy: {merge_request.get('strategy')}")
            click.echo("\n⚠️  WARNING: This action is permanent and cannot be undone.\n")
            if not click.confirm("Are you sure you want to delete this merge request?"):
                click.echo("Deletion cancelled.")
                return

        client.components.delete_merge_request(merge_request_id)
        success_msg = "Merge request deleted."

        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"merge_delete_{merge_request_id}.txt"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(success_msg + "\n")
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(success_msg)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("execute")
@click.pass_context
@click.argument("merge_request_id")
@click.option(
    "--action", type=click.Choice(["MERGE", "REVERT", "RETRY_DRAFTING"]), required=True, help="Action to execute"
)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_execute_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def execute(ctx, merge_request_id, action, output_format, save, save_filename, quiet):
    """Execute an action on a merge request (MERGE, REVERT, RETRY_DRAFTING)."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        payload = {"id": merge_request_id, "mergeRequestAction": action}

        result = client.components.execute_merge_request(merge_request_id, **payload)
        formatted = format_output(result, output_format)

        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"merge_execute_{merge_request_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query")
@click.pass_context
@click.option("--source-branch-id", help="Filter by source branch ID")
@click.option("--destination-branch-id", help="Filter by destination branch ID")
@click.option(
    "--stage",
    type=click.Choice(
        [
            "NOT_EXIST",
            "DRAFTING",
            "FAILED_TO_DRAFT",
            "FAILED_TO_REDRAFT",
            "DRAFTED",
            "REVIEWING",
            "MERGING",
            "MERGED",
            "FAILED_TO_MERGE",
            "DELETED",
            "REDRAFTING",
            "REVERTED",
        ]
    ),
    help="Filter by stage",
)
@click.option("--created-by", help="Filter by creator")
@click.option("--modified-by", help="Filter by modifier")
@click.option("--created-date", help="Filter by creation date (ISO format)")
@click.option("--modified-date", help="Filter by modification date (ISO format)")
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: merge_query.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(
    ctx,
    source_branch_id,
    destination_branch_id,
    stage,
    created_by,
    modified_by,
    created_date,
    modified_date,
    output_format,
    save,
    save_filename,
    quiet,
):
    """Query merge requests with optional filters."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        raw_filters = {}
        if source_branch_id:
            raw_filters["sourceBranchId"] = source_branch_id
        if destination_branch_id:
            raw_filters["destinationBranchId"] = destination_branch_id
        if stage:
            raw_filters["stage"] = stage
        if created_by:
            raw_filters["createdBy"] = created_by
        if modified_by:
            raw_filters["modifiedBy"] = modified_by
        if created_date:
            raw_filters["createdDate"] = created_date
        if modified_date:
            raw_filters["modifiedDate"] = modified_date

        if raw_filters:
            filters = build_query_filter(raw_filters)
            merge_requests = client.components.query_merge_request(filters)
        else:
            merge_requests = client.components.query_merge_request()

        formatted = format_output(merge_requests, output_format)

        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "merge_query.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Alias for lazy developers
command.add_command(query, name="q")
command.add_command(delete, name="rm")
