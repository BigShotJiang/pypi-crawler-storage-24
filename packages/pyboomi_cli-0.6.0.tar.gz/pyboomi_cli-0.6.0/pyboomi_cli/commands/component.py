# PyBoomi CLI - Component Command
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-01-27

"""Component management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys

import click

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    # Fallback if BoomiAPIError is in a different location
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):
        # If still not found, use a generic exception
        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


@click.group("component")
@click.pass_context
@click.option("--account-id", help="Boomi account ID (or use BOOMI_ACCT)")
@click.option("--username", help="Boomi user email (or use BOOMI_USER)")
@click.option("--api-token", help="Boomi Platform API token (or use BOOMI_TOKEN)")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi components.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi component --account-id ACCT123 get <component-id>
    """
    # Store auth options in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("get")
@click.pass_context
@click.argument("component_id", required=False)
@click.option("--name", help="Component name (alternative to component ID)")
@click.option("--branch-id", help="Branch ID for the component")
@click.option(
    "--branch-name",
    help="Branch name for the component (will be resolved to branch ID)",
)
@click.option("--version", help="Version for the component")
@click.option("--deleted", is_flag=True, help="Include deleted components in search")
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save component to file using default filename (componentid_branch_version.xml)",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save component to the specified filename. Implies --save if not explicitly provided.",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Suppress component output to stdout (useful for automation or when only saving to file)",
)
def get(
    ctx,
    component_id,
    name,
    branch_id,
    branch_name,
    version,
    deleted,
    save,
    save_filename,
    quiet,
):
    """Get component by ID or name."""
    # Determine if we should save: --save flag OR --save-file provided (--save-file implies --save)
    should_save = save or (save_filename is not None)

    # Check for conflicting options
    if not component_id and not name:
        click.echo("Error: Must provide either component_id or --name option.", err=True)
        sys.exit(1)

    # Check for conflicting options
    if branch_id and branch_name:
        click.echo(
            "Error: Cannot use both --branch-id and --branch-name options together. Please use only one.",
            err=True,
        )
        sys.exit(1)

    try:
        # Use single client for all queries (branch and component metadata)
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        # Resolve branch name to branch ID if needed
        resolved_branch_id = branch_id
        if branch_name:
            from pyboomi_platform.utils import build_query_filter

            raw_filters = {"name": branch_name}
            filters = build_query_filter(raw_filters)
            branches_result = client.query_branches(filters)
            branches = branches_result.get("result", []) if isinstance(branches_result, dict) else branches_result

            if not branches or len(branches) == 0:
                click.echo(f"Error: No branch found with name '{branch_name}'", err=True)
                sys.exit(1)
            elif len(branches) > 1:
                # Check if all branches have the same ID (same branch, different states)
                unique_branch_ids = set(branch["id"] for branch in branches)
                if len(unique_branch_ids) > 1:
                    click.echo(
                        f"Error: Multiple branches found with name '{branch_name}'. Please use --branch-id instead.",
                        err=True,
                    )
                    sys.exit(1)
                else:
                    # Same branch ID, just use the first one
                    resolved_branch_id = branches[0]["id"]
            else:
                resolved_branch_id = branches[0]["id"]

        # Resolve component name to component ID if needed
        resolved_component_id = component_id
        if name:
            from pyboomi_platform.utils import build_query_filter

            # Build base filters
            filters = {"name": name}
            # Add deleted filter if --deleted option is not provided
            if not deleted:
                filters["deleted"] = False
            # Add component ID filter if component_id is provided (to avoid multiple matches when name matches multiple components)
            if component_id:
                filters["componentId"] = component_id
            # Add branch filter if branch is specified
            if resolved_branch_id:
                filters["branchId"] = resolved_branch_id

            # Strategy: If no specific version is provided, try currentVersion=true first
            # If that returns no results (edge case: new component on branch), fall back to
            # querying all versions and selecting the one with highest version number
            components = []

            # First try with currentVersion=true (normal case)
            filters_with_current = filters.copy()
            filters_with_current["currentVersion"] = True
            query_filters = build_query_filter(filters_with_current)

            try:
                all_components = []
                components_response = client.query_component_metadata(query_filters)

                if isinstance(components_response, dict):
                    all_components.extend(components_response.get("result", []))

                    # Handle pagination if queryToken exists
                    while components_response.get("queryToken"):
                        more_response = client.query_more_component_metadata(components_response["queryToken"])
                        if isinstance(more_response, dict):
                            all_components.extend(more_response.get("result", []))
                            components_response = more_response
                        else:
                            break

                components = all_components
            except AttributeError:
                click.echo(
                    "Error: Component querying by name is not supported by the current client version.",
                    err=True,
                )
                sys.exit(1)

            # If no results with currentVersion=true, try without it (edge case)
            if not components or len(components) == 0:
                query_filters = build_query_filter(filters)

                try:
                    all_components = []
                    components_response = client.query_component_metadata(query_filters)

                    if isinstance(components_response, dict):
                        all_components.extend(components_response.get("result", []))

                        # Handle pagination if queryToken exists
                        while components_response.get("queryToken"):
                            more_response = client.query_more_component_metadata(components_response["queryToken"])
                            if isinstance(more_response, dict):
                                all_components.extend(more_response.get("result", []))
                                components_response = more_response
                            else:
                                break

                    components = all_components

                    # If we have multiple versions, select the one with the highest version number
                    if components and len(components) > 0:
                        # Group by componentId first
                        components_by_id = {}
                        for comp in components:
                            comp_id = comp.get("componentId")
                            if comp_id:
                                if comp_id not in components_by_id:
                                    components_by_id[comp_id] = []
                                components_by_id[comp_id].append(comp)

                        # For each componentId, select the one with highest version
                        filtered_components = []
                        for comp_id, comp_list in components_by_id.items():
                            if len(comp_list) == 1:
                                filtered_components.append(comp_list[0])
                            else:
                                # Sort by version (treating as string for now, but numeric versions should sort correctly as strings)
                                # Try to parse as float/int for better sorting, fallback to string
                                try:
                                    comp_list.sort(
                                        key=lambda x: (
                                            float(x.get("version", "0"))
                                            if x.get("version", "0").replace(".", "").isdigit()
                                            else x.get("version", "0")
                                        ),
                                        reverse=True,
                                    )
                                except Exception:
                                    # If parsing fails, sort as strings
                                    comp_list.sort(
                                        key=lambda x: x.get("version", "0"),
                                        reverse=True,
                                    )
                                # Take the first one (highest version)
                                filtered_components.append(comp_list[0])

                        components = filtered_components
                except AttributeError:
                    click.echo(
                        "Error: Component querying by name is not supported by the current client version.",
                        err=True,
                    )
                    sys.exit(1)

            if not components or len(components) == 0:
                click.echo(
                    f"Error: No component found with name '{name}'"
                    + (f" on branch '{branch_name}'" if branch_name else "")
                    + (f" with version '{version}'" if version else ""),
                    err=True,
                )
                sys.exit(1)
            else:
                # Get unique component IDs
                unique_component_ids = list(set(comp["componentId"] for comp in components))
                if len(unique_component_ids) > 1:
                    click.echo(
                        f"Error: Multiple components found with name '{name}'. Please use component ID instead.",
                        err=True,
                    )
                    sys.exit(1)
                else:
                    # Use the unique component ID
                    resolved_component_id = unique_component_ids[0]

            # If both name and component_id were provided, verify they match
            if component_id and resolved_component_id != component_id:
                click.echo(
                    f"Warning: Component name '{name}' resolves to ID '{resolved_component_id}' but provided ID is '{component_id}'. IDs do not match.",
                    err=True,
                )
                sys.exit(1)

        # Check cache first if we have specific version info
        from pyboomi_cli.cache import (cache_component, extract_component_info,
                                       get_cached_component)

        cached_component = None
        if resolved_branch_id and version:
            cached_component = get_cached_component(resolved_component_id, resolved_branch_id, version)
            if cached_component:
                click.echo("Retrieved from cache", err=True)
                click.echo(cached_component)
                return

        request_component_id = resolved_component_id
        if resolved_branch_id:
            request_component_id = f"{request_component_id}~{resolved_branch_id}"
        if version:
            request_component_id = f"{request_component_id}~{version}"
        component = client.get_component(request_component_id)

        # Cache the component - extract branch and version from XML if not provided
        if isinstance(component, (str, bytes)):
            component_str = component.decode("utf-8", errors="replace") if isinstance(component, bytes) else component

            # Try to extract component info for caching
            try:
                extracted_branch_id, extracted_version = extract_component_info(component_str)
                cache_branch_id = resolved_branch_id or extracted_branch_id
                cache_version = version or extracted_version

                if cache_branch_id and cache_version:
                    cache_component(
                        component_str,
                        resolved_component_id,
                        cache_branch_id,
                        cache_version,
                    )
            except Exception:
                # If extraction fails, only cache if we have explicit branch and version
                if resolved_branch_id and version:
                    cache_component(
                        component_str,
                        resolved_component_id,
                        resolved_branch_id,
                        version,
                    )

            # Save to file if --save flag or --save-file is provided
            if should_save:
                if save_filename and save_filename.strip():  # Specific filename provided via --save-file
                    filename = save_filename
                else:  # Generate default filename (--save flag without --save-file)
                    # Use extracted info if available, otherwise use provided values
                    file_branch = resolved_branch_id or extracted_branch_id or "unknown"
                    file_version = version or extracted_version or "unknown"
                    filename = f"{resolved_component_id}_{file_branch}_{file_version}.xml"

                with open(filename, "w", encoding="utf-8") as f:
                    f.write(component_str)
                click.echo(f"Component saved to {filename}", err=True)

        # Output component to stdout unless --quiet is specified
        if not quiet:
            # Boomi returns component documents in XML; decode bytes if needed
            if isinstance(component, bytes):
                click.echo(component.decode("utf-8", errors="replace"))
            else:
                click.echo(component)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("metadata")
@click.pass_context
@click.argument("component_id")
@click.option("--branch-id", help="Branch ID for the component")
@click.option(
    "--branch-name",
    help="Branch name for the component (will be resolved to branch ID)",
)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save output to file using default filename (component_metadata_<id>.json).",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def metadata(ctx, component_id, branch_id, branch_name, output_format, save, save_filename, quiet):
    """Get component metadata by ID."""
    # Check for conflicting branch options
    if branch_id and branch_name:
        click.echo(
            "Error: Cannot use both --branch-id and --branch-name options together. Please use only one.",
            err=True,
        )
        sys.exit(1)

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        # Resolve branch name to branch ID if needed
        resolved_branch_id = branch_id
        if branch_name:
            from pyboomi_platform.utils import build_query_filter

            raw_filters = {"name": branch_name}
            filters = build_query_filter(raw_filters)
            branches_result = client.query_branches(filters)
            branches = branches_result.get("result", []) if isinstance(branches_result, dict) else branches_result

            if not branches or len(branches) == 0:
                click.echo(f"Error: No branch found with name '{branch_name}'", err=True)
                sys.exit(1)
            elif len(branches) > 1:
                # Check if all branches have the same ID (same branch, different states)
                unique_branch_ids = set(branch["id"] for branch in branches)
                if len(unique_branch_ids) > 1:
                    click.echo(
                        f"Error: Multiple branches found with name '{branch_name}'. Please use --branch-id instead.",
                        err=True,
                    )
                    sys.exit(1)
                else:
                    # Same branch ID, just use the first one
                    resolved_branch_id = branches[0]["id"]
            else:
                resolved_branch_id = branches[0]["id"]

        metadata = client.get_component_metadata(component_id, resolved_branch_id)
        formatted = format_output(metadata, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"component_metadata_{component_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("create")
@click.pass_context
@click.option(
    "--template",
    help="Path to template file (relative to templates directory or absolute path)",
)
@click.option(
    "--component-type",
    help="Component type subdirectory (e.g., 'processes', 'connectors')",
)
@click.option("--name", help="Component name (can also be provided via template parameter)")
@click.option("--folder-id", help="Folder ID where component will be created")
@click.option("--branch-id", help="Branch ID for the component")
@click.option(
    "--branch-name",
    help="Branch name for the component (will be resolved to branch ID)",
)
@click.option(
    "--parameter",
    "parameters",
    multiple=True,
    help="Template parameter as key=value (can be used multiple times)",
)
@click.option(
    "--no-prompt",
    is_flag=True,
    default=False,
    help="Don't prompt for missing template parameters (will fail if missing)",
)
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--verbose", is_flag=True, default=False, help="Print detailed information")
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save created component to file using default filename (componentname_componentid_branchname_version.xml)",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save created component to the specified filename. Implies --save if not explicitly provided.",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Suppress component output to stdout (useful for automation or when only saving to file)",
)
def create(
    ctx,
    template,
    component_type,
    name,
    folder_id,
    branch_id,
    branch_name,
    parameters,
    no_prompt,
    output_format,
    verbose,
    save,
    save_filename,
    quiet,
):
    """
    Create a component from a template or raw XML.

    If --template is provided, the template will be loaded, parameters will be scanned
    and prompted for (unless --no-prompt is used), and then the processed template will
    be used to create the component.

    Template parameters use {{parameterName}} syntax and will be replaced with user-provided values.
    """
    # Check for conflicting branch options
    if branch_id and branch_name:
        click.echo(
            "Error: Cannot use both --branch-id and --branch-name options together. Please use only one.",
            err=True,
        )
        sys.exit(1)

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml",
        )

        # Resolve branch name to branch ID if needed
        resolved_branch_id = branch_id
        resolved_branch_name = branch_name if branch_name else None
        if branch_name:
            from pyboomi_platform.utils import build_query_filter

            raw_filters = {"name": branch_name}
            filters = build_query_filter(raw_filters)
            branches_result = client.query_branches(filters)
            branches = branches_result.get("result", []) if isinstance(branches_result, dict) else branches_result

            if not branches or len(branches) == 0:
                click.echo(f"Error: No branch found with name '{branch_name}'", err=True)
                sys.exit(1)
            elif len(branches) > 1:
                # Check if all branches have the same ID (same branch, different states)
                unique_branch_ids = set(branch["id"] for branch in branches)
                if len(unique_branch_ids) > 1:
                    click.echo(
                        f"Error: Multiple branches found with name '{branch_name}'. Please use --branch-id instead.",
                        err=True,
                    )
                    sys.exit(1)
                else:
                    # Same branch ID, just use the first one
                    resolved_branch_id = branches[0]["id"]
                    resolved_branch_name = branches[0].get("name", branch_name)
            else:
                resolved_branch_id = branches[0]["id"]
                resolved_branch_name = branches[0].get("name", branch_name)
        elif branch_id and not resolved_branch_name:
            # If branch_id provided but not branch_name, try to get branch name
            try:
                from pyboomi_platform.utils import build_query_filter

                raw_filters = {"id": branch_id}
                filters = build_query_filter(raw_filters)
                branches_result = client.query_branches(filters)
                branches = branches_result.get("result", []) if isinstance(branches_result, dict) else branches_result
                if branches and len(branches) > 0:
                    resolved_branch_name = branches[0].get("name")
            except Exception:
                # If query fails, we'll try again later when saving
                pass

        # Parse parameter key=value pairs
        parameter_values = {}
        for param in parameters:
            if "=" not in param:
                raise click.UsageError(f"Invalid parameter format: {param}. Expected format: key=value")
            key, value = param.split("=", 1)
            parameter_values[key] = value

        # Add name to parameters if provided
        if name:
            parameter_values["componentName"] = name
            parameter_values["name"] = name  # Support both naming conventions

        # Load and process template if provided
        if template:
            if verbose:
                click.echo(f"Loading template: {template}")

            from pyboomi_cli.utils import load_and_process_template

            component_xml = load_and_process_template(
                template_path=template,
                component_type=component_type,
                parameter_values=parameter_values,
                prompt_missing=not no_prompt,
            )

            if verbose:
                click.echo(f"Template processed. Component XML length: {len(component_xml)} characters")
        else:
            # No template provided - user must provide component XML via stdin or we need to create a stub
            raise click.UsageError(
                "No template provided. Use --template to specify a template file.\n"
                "Example: boomi component create --template processes/basic.xml"
            )

        # Create the component
        if verbose:
            click.echo(
                f"Creating component in folder: {folder_id}"
                + (f", branch: {resolved_branch_id}" if resolved_branch_id else "")
            )

        # The client.create_component method signature may vary - check what's available
        # For now, we'll assume it accepts component_xml, folder_id, and optionally branch_id
        try:
            # Try calling with folder_id and branch_id if available
            if hasattr(client, "create_component"):
                if resolved_branch_id:
                    created_component = client.create_component(
                        component_xml=component_xml,
                        folder_id=folder_id,
                        branch_id=resolved_branch_id,
                    )
                else:
                    created_component = client.create_component(component_xml=component_xml, folder_id=folder_id)
            else:
                # Fallback: try to use a more generic create method
                # This may need adjustment based on actual API
                raise click.UsageError(
                    "Component creation not yet fully implemented. "
                    "The create_component method may need to be added to the client."
                )
        except AttributeError:
            raise click.UsageError(
                "Component creation method not available in client. "
                "Please check pyboomi_platform library for create_component method."
            )

        # The create_component response IS the component XML (components are always returned as XML)
        # Convert to string if needed
        if isinstance(created_component, bytes):
            component_xml_response = created_component.decode("utf-8", errors="replace")
        else:
            component_xml_response = str(created_component)

        # Extract component information from the response XML
        import xml.etree.ElementTree as ET

        from pyboomi_cli.utils import sanitize_filename

        created_component_id = None
        component_name = None
        component_version = None
        component_branch_id = None
        component_branch_name = None

        try:
            root = ET.fromstring(component_xml_response)
            # Extract attributes from the Component element
            created_component_id = root.get("componentId")  # Note: componentId, not id
            component_name = root.get("name")
            component_version = root.get("version")
            component_branch_id = root.get("branchId")
            component_branch_name = root.get("branchName")

            if verbose:
                click.echo(
                    f"Extracted from response: id={created_component_id}, name={component_name}, version={component_version}, branchId={component_branch_id}, branchName={component_branch_name}",
                    err=True,
                )
        except Exception as e:
            if verbose:
                click.echo(f"Warning: Could not parse component XML response: {e}", err=True)

        # Determine if we should save: --save flag OR --save-file provided (--save-file implies --save)
        should_save = save or (save_filename is not None)

        # If --save flag or --save-file is specified, save the component XML response directly
        # The response IS the component XML with all attributes
        if should_save:
            try:
                # The response is already XML, extract info from it
                root = ET.fromstring(component_xml_response)

                # Extract all attributes from the Component element
                file_component_id = root.get("componentId") or created_component_id or "unknown"
                file_component_name = root.get("name") or component_name or "unknown"
                file_version = root.get("version") or component_version or "unknown"
                file_branch_name = root.get("branchName") or component_branch_name or resolved_branch_name or "unknown"

                # Sanitize names for filesystem
                sanitized_name = (
                    sanitize_filename(file_component_name) if file_component_name != "unknown" else "unknown"
                )
                sanitized_branch_name = (
                    sanitize_filename(file_branch_name) if file_branch_name != "unknown" else "unknown"
                )

                # Use provided filename or generate default
                if save_filename and save_filename.strip():  # Specific filename provided via --save-file
                    filename = save_filename
                else:  # Generate default filename (--save flag without --save-file)
                    filename = f"{sanitized_name}_{file_component_id}_{sanitized_branch_name}_{file_version}.xml"

                # Save the component XML response (which is the complete component)
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(component_xml_response)
                click.echo(f"Component saved to {filename}", err=True)
            except Exception as e:
                click.echo(f"Warning: Could not save component to file: {e}", err=True)
                if verbose:
                    import traceback

                    click.echo(f"Traceback: {traceback.format_exc()}", err=True)

        # Output the result unless --quiet is specified
        if not quiet:
            click.echo(format_output(created_component, output_format))

    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("diff")
@click.pass_context
@click.argument("component_id")
@click.argument("source_version", type=int)
@click.argument("target_version", type=int)
@click.option(
    "--output-format",
    type=click.Choice(["json", "xml", "yaml"]),
    default="json",
    help="Output format (default: json)",
)
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save the diff response to a file using default filename (componentId_sourceVersion_targetVersion.json) in the current working directory.",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save the diff response to the specified path. Implies --save if set.",
)
@click.option(
    "--quiet",
    is_flag=True,
    help="Suppress diff output to stdout (useful when saving to file only)",
)
def diff(ctx, component_id, source_version, target_version, output_format, save, save_filename, quiet):
    """Compare two versions of a component."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        # Create the diff request
        diff_request = {
            "componentId": component_id,
            "sourceVersion": str(source_version),
            "targetVersion": str(target_version),
        }

        # Create the diff request - this returns the diff results directly
        diff_result = client.components.create_component_diff_request(**diff_request)

        formatted = format_output(diff_result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            if save_filename and save_filename.strip():
                filename = save_filename
            else:
                filename = f"{component_id}_{source_version}_{target_version}.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Diff saved to {filename}", err=True)

        if not quiet:
            click.echo(formatted)

    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("update")
@click.pass_context
@click.argument("component_id")
@click.option(
    "--component-file",
    help="Path to component XML file (used if no input piped from stdin)",
)
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--verbose", is_flag=True, default=False, help="Print detailed information")
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save output to file using default filename (component_update_<id>.json).",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def update(ctx, component_id, component_file, output_format, verbose, save, save_filename, quiet):
    """
    Update a component from XML.

    The component XML can be provided either:
    - Via stdin (piped input): boomi component get <id> | boomi component update <id>
    - Via file: boomi component update <id> --component-file path/to/component.xml

    If input is piped from stdin, it takes precedence over --component-file.
    """
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml",
        )

        # Read component XML from stdin or file
        import sys

        stdin = click.get_text_stream("stdin")

        # Priority: if component_file is provided, use it (unless stdin clearly has data)
        # Otherwise, read from stdin if it has piped data
        component_xml = None

        # Check if stdin has piped data (not a TTY) - only check if no file provided
        # or if we want stdin to take precedence
        stdin_has_data = False
        if not component_file:
            # Only check stdin if no file provided
            try:
                stdin_has_data = not sys.stdin.isatty() if hasattr(sys.stdin, "isatty") else False
            except (AttributeError, OSError):
                stdin_has_data = False
        else:
            # File provided - check stdin only to see if it should take precedence
            # (for piped input scenarios)
            try:
                stdin_has_data = not sys.stdin.isatty() if hasattr(sys.stdin, "isatty") else False
            except (AttributeError, OSError):
                stdin_has_data = False

        if stdin_has_data:
            # Read from stdin (piped input takes precedence over file)
            if verbose:
                click.echo("Reading component XML from stdin" + (" (file ignored)" if component_file else ""))
            component_xml = stdin.read()
            if verbose:
                click.echo(f"Read {len(component_xml)} characters from stdin")
            # If stdin read returns empty and file is provided, fall back to file
            if (not component_xml or not component_xml.strip()) and component_file:
                if verbose:
                    click.echo("Stdin was empty, falling back to component file")
                stdin_has_data = False  # Fall through to file reading

        if not stdin_has_data and component_file:
            # Read from file (when no stdin data)
            if verbose:
                click.echo(f"Reading component XML from file: {component_file}")
            try:
                with open(component_file, "r", encoding="utf-8") as f:
                    component_xml = f.read()
                if verbose:
                    click.echo(f"Read {len(component_xml)} characters from file")
            except FileNotFoundError:
                raise click.UsageError(f"Component file not found: {component_file}")
            except Exception as e:
                raise click.UsageError(f"Error reading component file: {e}")
        else:
            raise click.UsageError(
                "No component XML provided. Either pipe XML from stdin or use --component-file.\n"
                "Example: boomi component get <id> | boomi component update <id>\n"
                "Example: boomi component update <id> --component-file path/to/component.xml"
            )

        if not component_xml or not component_xml.strip():
            raise click.UsageError("Component XML is empty")

        # Update the component
        if verbose:
            click.echo(f"Updating component: {component_id}")

        # The client.update_component method signature: update_component(component_id, component_xml)
        try:
            if hasattr(client, "update_component"):
                updated_component = client.update_component(component_id, component_xml)
            else:
                raise click.UsageError(
                    "Component update not yet fully implemented. "
                    "The update_component method may need to be added to the client."
                )
        except AttributeError:
            raise click.UsageError(
                "Component update method not available in client. "
                "Please check pyboomi_platform library for update_component method."
            )

        # Output the result
        formatted = format_output(updated_component, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"component_update_{component_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)

    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# --- ComponentReference (references) subcommands ---


@command.group("references")
def references_group():
    """
    Component references (where-used).

    Get or query ComponentReference data: which components use or are used by
    a given component (aligned with Boomi Show Where Used).
    """
    pass


@references_group.command("get")
@click.pass_context
@click.argument("component_id", required=True)
@click.option("--branch-id", help="Branch ID for the component")
@click.option(
    "--branch-name",
    help="Branch name for the component (will be resolved to branch ID)",
)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option(
    "--save", is_flag=True, default=False, help="Save output to file (default: component_references_get_<id>.json)."
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def references_get(ctx, component_id, branch_id, branch_name, output_format, save, save_filename, quiet):
    """Get component references for a single component (by ID)."""
    if branch_id and branch_name:
        click.echo(
            "Error: Cannot use both --branch-id and --branch-name options together. Please use only one.",
            err=True,
        )
        sys.exit(1)

    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        resolved_branch_id = branch_id
        if branch_name:
            from pyboomi_platform.utils import build_query_filter

            raw_filters = {"name": branch_name}
            filters = build_query_filter(raw_filters)
            branches_result = client.components.query_branches(filters)
            branches = branches_result.get("result", []) if isinstance(branches_result, dict) else branches_result
            if not branches or len(branches) == 0:
                click.echo(f"Error: No branch found with name '{branch_name}'", err=True)
                sys.exit(1)
            elif len(branches) > 1:
                unique_branch_ids = set(branch["id"] for branch in branches)
                if len(unique_branch_ids) > 1:
                    click.echo(
                        f"Error: Multiple branches found with name '{branch_name}'. Please use --branch-id instead.",
                        err=True,
                    )
                    sys.exit(1)
                resolved_branch_id = branches[0]["id"]
            else:
                resolved_branch_id = branches[0]["id"]

        result = client.components.get_component_reference(component_id, resolved_branch_id)
        formatted = format_output(result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"component_references_get_{component_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@references_group.command("bulk")
@click.pass_context
@click.argument("component_ids", nargs=-1, required=True)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option(
    "--save", is_flag=True, default=False, help="Save output to file (default: component_references_bulk.json)."
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def references_bulk(ctx, component_ids, output_format, save, save_filename, quiet):
    """Get component references for multiple components (by ID)."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        result = client.components.get_component_reference_bulk(list(component_ids))
        formatted = format_output(result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip() if save_filename and save_filename.strip() else "component_references_bulk.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@references_group.command("query")
@click.pass_context
@click.option("--component-id", help="Secondary component ID (find primaries that reference it)")
@click.option("--parent-component-id", help="Primary component ID (find secondaries it references)")
@click.option("--parent-version", type=int, help="Primary component version (required with --parent-component-id)")
@click.option(
    "--type",
    "ref_type",
    type=click.Choice(["DEPENDENT", "INDEPENDENT"]),
    help="Filter by reference type",
)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option(
    "--save", is_flag=True, default=False, help="Save output to file (default: component_references_query.json)."
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def references_query(
    ctx, component_id, parent_component_id, parent_version, ref_type, output_format, save, save_filename, quiet
):
    """Query component references by component ID or by parent component + version."""
    has_component_id = bool(component_id)
    has_parent = bool(parent_component_id)
    has_parent_version = parent_version is not None

    if has_component_id and has_parent:
        click.echo(
            "Error: Use either --component-id OR (--parent-component-id with --parent-version), not both.",
            err=True,
        )
        sys.exit(1)
    if not has_component_id and not has_parent:
        click.echo(
            "Error: Provide either --component-id OR (--parent-component-id and --parent-version).",
            err=True,
        )
        sys.exit(1)
    if has_parent and not has_parent_version:
        click.echo(
            "Error: --parent-version is required when --parent-component-id is set.",
            err=True,
        )
        sys.exit(1)

    try:
        from pyboomi_platform.utils import build_query_filter

        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        filters = {}
        if has_component_id:
            filters["componentId"] = component_id
        else:
            filters["parentComponentId"] = parent_component_id
            filters["parentVersion"] = parent_version
        if ref_type:
            filters["type"] = ref_type
        payload = build_query_filter(filters)
        response = client.components.query_component_reference(payload)
        all_results = list(response.get("result", []))
        while response.get("queryToken"):
            next_response = client.components.query_more_component_references(response["queryToken"])
            all_results.extend(next_response.get("result", []))
            response = next_response
        out = {"result": all_results, "numberOfResults": len(all_results)}
        if response.get("queryToken"):
            out["queryToken"] = response["queryToken"]
        formatted = format_output(out, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip() if save_filename and save_filename.strip() else "component_references_query.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@references_group.command("query-more")
@click.pass_context
@click.argument("query_token", required=True)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option(
    "--save", is_flag=True, default=False, help="Save output to file (default: component_references_query_more.json)."
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def references_query_more(ctx, query_token, output_format, save, save_filename, quiet):
    """Retrieve the next page of component reference query results."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )
        result = client.components.query_more_component_references(query_token)
        formatted = format_output(result, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else "component_references_query_more.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
