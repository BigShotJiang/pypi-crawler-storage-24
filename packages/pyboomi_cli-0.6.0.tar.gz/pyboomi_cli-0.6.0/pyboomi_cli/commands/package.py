# PyBoomi CLI - Package Command
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-11-10

"""Package management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys

import click
from pyboomi_platform.utils import build_query_filter

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    # Fallback if BoomiAPIError is in a different location
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):
        # If still not found, use a generic exception
        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


@click.group("package")
@click.pass_context
@click.option("--account-id", help="Boomi account ID (or use BOOMI_ACCT)")
@click.option("--username", help="Boomi user email (or use BOOMI_USER)")
@click.option("--api-token", help="Boomi Platform API token (or use BOOMI_TOKEN)")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi packages (PackagedComponents).

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi package --account-id ACCT123 get <package-id>
    """
    # Store auth options in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("create")
@click.pass_context
@click.argument("component_id")
@click.option(
    "--version",
    "--package-version",
    "package_version",
    required=True,
    help="Package version (e.g., 1.0.0)",
)
@click.option("--notes", help="Notes for the package")
@click.option("--branch-name", help="Branch name for the component")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option(
    "--save", is_flag=True, default=False, help="Save output to file (default: package_create_<component_id>.json)."
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def create(ctx, component_id, package_version, notes, branch_name, output_format, save, save_filename, quiet):
    """Create a packaged component from a component ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        packaged_component = client.create_packaged_component(
            component_id=component_id,
            package_version=package_version,
            notes=notes,
            branch_name=branch_name,
        )
        formatted = format_output(packaged_component, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"package_create_{component_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("get")
@click.pass_context
@click.argument("packaged_component_id")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: package_get_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, packaged_component_id, output_format, save, save_filename, quiet):
    """Get packaged component information by ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        packaged_component = client.get_packaged_component(packaged_component_id)
        formatted = format_output(packaged_component, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"package_get_{packaged_component_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query")
@click.pass_context
@click.option("--component-id", help="Filter by component ID")
@click.option("--package-version", help="Filter by package version")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option(
    "--save",
    is_flag=True,
    default=False,
    help="Save output to file (default: package_query_<component_id>_<package_version>.json).",
)
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(ctx, component_id, package_version, output_format, save, save_filename, quiet):
    """Query packaged components using filter criteria."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )

        # Build filter dictionary
        raw_filters = {}
        if component_id:
            raw_filters["componentId"] = component_id
        if package_version:
            raw_filters["packageVersion"] = package_version

        # Query packaged components
        if raw_filters:
            # Format filters using build_query_filter to match Boomi API structure
            filters = build_query_filter(raw_filters)
            results = client.query_packaged_components(filters)
        else:
            # Query all if no filters provided
            results = client.query_packaged_components()

        formatted = format_output(results, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"package_query_{component_id}_{package_version}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("manifest")
@click.pass_context
@click.argument("packaged_component_id")
@click.option(
    "--output-format",
    default="json",
    type=click.Choice(["json", "yaml", "text", "xml"]),
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: package_manifest_<id>.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def manifest(ctx, packaged_component_id, output_format, save, save_filename, quiet):
    """Get packaged component ID manifest by packaged component ID."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
            accept="application/xml" if output_format == "xml" else None,
        )
        manifest = client.get_packaged_component_manifest(packaged_component_id)
        formatted = format_output(manifest, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip()
                if save_filename and save_filename.strip()
                else f"package_manifest_{packaged_component_id}.json"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
