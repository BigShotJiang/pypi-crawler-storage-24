"""Utility functions for address computations, conversions, and transformations."""

from cashscript_py.helpers.cashaddress import (
    LockingBytecodeType,
    address_contents_to_locking_bytecode,
    get_network_prefix,
    locking_bytecode_to_cash_address,
    payload_to_cash_address,
)
from cashscript_py.helpers.crypto import hash160, hash256
from cashscript_py.helpers.script import Script, serialize_script
from cashscript_py.network.network_provider import Network


def script_to_address(
    script: Script, network: Network, address_type: LockingBytecodeType, token_aware: bool = False
) -> str:
    """Convert a script to a CashAddress for the given network/type.

    Args:
        script: Script list to encode.
        network: Target network.
        address_type: Locking bytecode type (P2SH20/P2SH32/P2PKH/P2PK).
        token_aware: If True, encode token-aware address version.

    Returns:
        CashAddress string.

    """
    locking_bytecode = script_to_locking_bytecode(script, address_type)
    prefix = get_network_prefix(network)
    return locking_bytecode_to_cash_address(locking_bytecode, prefix, token_aware)


def script_to_locking_bytecode(script: Script, address_type: LockingBytecodeType) -> bytes:
    """Hash a script into its P2SH20/P2SH32 (or P2PKH/P2PK) locking bytecode.

    Args:
        script: Script list to hash.
        address_type: Desired locking type.

    Returns:
        Locking bytecode.

    Raises:
        ValueError: If the address_type is unsupported.

    """
    if address_type != LockingBytecodeType.P2SH20 and address_type != LockingBytecodeType.P2SH32:
        raise ValueError("address_type needs to be either 'p2sh32' or 'p2sh20'")
    script_bytecode = serialize_script(script)
    script_hash = hash256(script_bytecode) if address_type == LockingBytecodeType.P2SH32 else hash160(script_bytecode)
    return address_contents_to_locking_bytecode(script_hash, address_type)


def public_key_to_pkh(public_key: bytes) -> bytes:
    """Return the HASH160 of a public key (pkh)."""
    return hash160(public_key)


def public_key_to_p2pkh_locking_bytecode(public_key: bytes) -> bytes:
    """Build a standard P2PKH locking bytecode from a public key.

    Args:
        public_key: Raw public key (compressed or uncompressed).

    Returns:
        P2PKH locking bytecode.

    """
    pubkey_hash: bytes = hash160(public_key)
    return address_contents_to_locking_bytecode(pubkey_hash, LockingBytecodeType.P2PKH)


def public_key_to_cash_address(
    public_key: bytes,
    network: Network,
    address_type: LockingBytecodeType = LockingBytecodeType.P2PKH,
    token_aware: bool = False,
) -> str:
    """Convert a public key to a CashAddress.

    Args:
        public_key: Raw public key (compressed or uncompressed).
        network: Target network.
        address_type: Address type (default P2PKH).
        token_aware: If True, uses token-aware address version.

    Returns:
        CashAddress string.

    """
    prefix = get_network_prefix(network)
    public_key_hash = hash160(public_key)
    return payload_to_cash_address(prefix, public_key_hash, address_type, token_aware)
