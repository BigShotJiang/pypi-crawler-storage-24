"""Helper subpackage: address, script, encoding, crypto, and token utilities."""
