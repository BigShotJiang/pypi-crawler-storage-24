"""Cryptographic utility functions."""

import hashlib


def hash160(data: bytes) -> bytes:
    """Compute RIPEMD160(SHA-256(data))."""
    sha256_hash = hashlib.sha256(data).digest()
    ripemd160_hash = hashlib.new("ripemd160", sha256_hash).digest()
    return ripemd160_hash


def hash256(data: bytes) -> bytes:
    """Compute double SHA-256 of data."""
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()
