"""Tests for the calendar booking service."""

import pytest

from heylead.services.calendar_booker import (
    _parse_calendly_path,
    _parse_calcom_path,
    _pick_best_slot,
    detect_provider,
    format_booking_result,
)


class TestDetectProvider:
    def test_calendly(self):
        assert detect_provider("https://calendly.com/john/30min") == "calendly"

    def test_calendly_with_www(self):
        assert detect_provider("https://www.calendly.com/john/30min") == "calendly"

    def test_calcom(self):
        assert detect_provider("https://cal.com/john/30min") == "calcom"

    def test_unknown(self):
        assert detect_provider("https://example.com/book") == "unknown"

    def test_acuity(self):
        assert detect_provider("https://acuityscheduling.com/schedule") == "unknown"


class TestParseCalendlyPath:
    def test_standard(self):
        assert _parse_calendly_path("https://calendly.com/john/30min") == ("john", "30min")

    def test_no_event_slug(self):
        assert _parse_calendly_path("https://calendly.com/john") == ("john", "")

    def test_trailing_slash(self):
        assert _parse_calendly_path("https://calendly.com/john/30min/") == ("john", "30min")

    def test_empty(self):
        assert _parse_calendly_path("https://calendly.com/") == ("", "")


class TestParseCalcomPath:
    def test_standard(self):
        assert _parse_calcom_path("https://cal.com/jane/15min") == ("jane", "15min")

    def test_no_event(self):
        assert _parse_calcom_path("https://cal.com/jane") == ("jane", "")


class TestPickBestSlot:
    def test_prefers_midmorning(self):
        slots = [
            {"start": "2026-03-25T08:00:00+00:00"},  # 8 AM — too early (outside biz hours)
            {"start": "2026-03-25T10:00:00+00:00"},  # 10 AM — ideal
            {"start": "2026-03-25T16:00:00+00:00"},  # 4 PM — OK
        ]
        chosen = _pick_best_slot(slots)
        assert chosen is not None
        assert "10:00" in chosen["start"]

    def test_skips_weekends(self):
        # 2026-03-28 is a Saturday, 2026-03-30 is Monday
        slots = [
            {"start": "2026-03-28T10:00:00+00:00"},  # Saturday
            {"start": "2026-03-30T10:00:00+00:00"},  # Monday
        ]
        chosen = _pick_best_slot(slots)
        assert chosen is not None
        assert "03-30" in chosen["start"]

    def test_empty_slots(self):
        assert _pick_best_slot([]) is None

    def test_fallback_to_any(self):
        # Only a slot outside business hours — should still fall back
        slots = [
            {"start": "2026-03-25T20:00:00+00:00"},  # 8 PM
        ]
        chosen = _pick_best_slot(slots)
        assert chosen is not None  # Falls back to any slot


class TestFormatBookingResult:
    def test_success(self):
        result = {
            "success": True,
            "provider": "calendly",
            "booked_time": "2026-03-25T10:00:00+00:00",
            "duration_minutes": 30,
        }
        text = format_booking_result(result)
        assert "Meeting booked" in text
        assert "Calendly" in text
        assert "30 min" in text

    def test_failure(self):
        result = {
            "success": False,
            "error": "No slots available",
            "url": "https://calendly.com/john/30min",
        }
        text = format_booking_result(result)
        assert "Could not auto-book" in text
        assert "calendly.com" in text

    def test_failure_with_attempted_time(self):
        result = {
            "success": False,
            "error": "Booking failed (403)",
            "url": "https://cal.com/jane/15min",
            "attempted_time": "2026-03-25T14:00:00+00:00",
        }
        text = format_booking_result(result)
        assert "cal.com" in text
        assert "2026-03-25" in text
