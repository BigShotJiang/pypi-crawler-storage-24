# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class GcbFrozen:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'frozen': 'bool'
    }

    attribute_map = {
        'frozen': 'frozen'
    }

    def __init__(self, frozen=None):
        r"""GcbFrozen

        The model defined in huaweicloud sdk

        :param frozen: 功能说明: 全域互联带宽是否冻结。 取值范围：     true-冻结     false-非冻结
        :type frozen: bool
        """
        
        

        self._frozen = None
        self.discriminator = None

        if frozen is not None:
            self.frozen = frozen

    @property
    def frozen(self):
        r"""Gets the frozen of this GcbFrozen.

        功能说明: 全域互联带宽是否冻结。 取值范围：     true-冻结     false-非冻结

        :return: The frozen of this GcbFrozen.
        :rtype: bool
        """
        return self._frozen

    @frozen.setter
    def frozen(self, frozen):
        r"""Sets the frozen of this GcbFrozen.

        功能说明: 全域互联带宽是否冻结。 取值范围：     true-冻结     false-非冻结

        :param frozen: The frozen of this GcbFrozen.
        :type frozen: bool
        """
        self._frozen = frozen

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GcbFrozen):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
