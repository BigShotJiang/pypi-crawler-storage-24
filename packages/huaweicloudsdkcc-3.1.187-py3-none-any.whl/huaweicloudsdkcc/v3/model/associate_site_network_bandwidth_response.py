# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AssociateSiteNetworkBandwidthResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'request_id': 'str',
        'site_connection': 'SiteConnection'
    }

    attribute_map = {
        'request_id': 'request_id',
        'site_connection': 'site_connection'
    }

    def __init__(self, request_id=None, site_connection=None):
        r"""AssociateSiteNetworkBandwidthResponse

        The model defined in huaweicloud sdk

        :param request_id: 请求ID。
        :type request_id: str
        :param site_connection: 
        :type site_connection: :class:`huaweicloudsdkcc.v3.SiteConnection`
        """
        
        super().__init__()

        self._request_id = None
        self._site_connection = None
        self.discriminator = None

        self.request_id = request_id
        self.site_connection = site_connection

    @property
    def request_id(self):
        r"""Gets the request_id of this AssociateSiteNetworkBandwidthResponse.

        请求ID。

        :return: The request_id of this AssociateSiteNetworkBandwidthResponse.
        :rtype: str
        """
        return self._request_id

    @request_id.setter
    def request_id(self, request_id):
        r"""Sets the request_id of this AssociateSiteNetworkBandwidthResponse.

        请求ID。

        :param request_id: The request_id of this AssociateSiteNetworkBandwidthResponse.
        :type request_id: str
        """
        self._request_id = request_id

    @property
    def site_connection(self):
        r"""Gets the site_connection of this AssociateSiteNetworkBandwidthResponse.

        :return: The site_connection of this AssociateSiteNetworkBandwidthResponse.
        :rtype: :class:`huaweicloudsdkcc.v3.SiteConnection`
        """
        return self._site_connection

    @site_connection.setter
    def site_connection(self, site_connection):
        r"""Sets the site_connection of this AssociateSiteNetworkBandwidthResponse.

        :param site_connection: The site_connection of this AssociateSiteNetworkBandwidthResponse.
        :type site_connection: :class:`huaweicloudsdkcc.v3.SiteConnection`
        """
        self._site_connection = site_connection

    def to_dict(self):
        import warnings
        warnings.warn("AssociateSiteNetworkBandwidthResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssociateSiteNetworkBandwidthResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
