"""PHI Guard Scan Engine - Core scanning functions."""

from dataclasses import dataclass
from pathlib import Path

from phi_guard.ignore import (
    build_ignore_spec,
    load_ignore_patterns,
    merge_ignore_specs,
    should_ignore,
)
from phi_guard.recognizers.registry import get_analyzer_engine, ScanMode


SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx",
    ".json", ".yaml", ".yml", ".toml",
    ".env", ".ini", ".cfg",
    ".csv", ".sql",
    ".log", ".txt", ".md",
    ".xml", ".html",
}

# PHI entity types to detect (based on HIPAA's 18 identifiers)
# Excludes generic spaCy NER entities like PERSON to reduce false positives
PHI_ENTITY_TYPES = {
    # Presidio built-in
    "US_SSN",           # PHI #7: Social Security numbers
    "PHONE_NUMBER",     # PHI #4: Telephone numbers
    "EMAIL_ADDRESS",    # PHI #6: Email addresses
    "DATE_TIME",        # PHI #2: Dates (except year)
    "IP_ADDRESS",       # PHI #16: Internet Protocol addresses
    "URL",              # PHI #6: Web URLs
    # Custom recognizers
    "MRN",              # PHI #8: Medical record numbers
    "VIN",              # PHI #14: Vehicle identifiers
    "DRIVERS_LICENSE",  # PHI #13: Certificate/license numbers
    "DEA_NUMBER",       # PHI #13: DEA registration numbers
    "NPI",              # PHI #13: National Provider Identifier
    "HEALTH_PLAN_ID",   # PHI #11: Health plan beneficiary numbers
    "AGE_OVER_89",      # PHI #17: Ages over 89
    "ZIP_CODE",         # PHI #3: Geographic (smaller than state)
    "ACCOUNT_NUMBER",   # PHI #12: Account numbers
    "DEVICE_ID",        # PHI #15: Device identifiers
    "FAX_NUMBER",       # PHI #5: Fax numbers
}


@dataclass
class Finding:
    """A detected PHI instance."""
    entity_type: str
    text: str
    start: int
    end: int
    score: float
    file_path: str | None = None
    line_number: int | None = None


def scan_text(
    text: str,
    score_threshold: float = 0.5,
    mode: ScanMode = ScanMode.FULL,
) -> list[Finding]:
    """Scan text for PHI and return findings above the score threshold.

    Args:
        text: The text to scan for PHI.
        score_threshold: Minimum confidence score (0.0-1.0) for findings.
        mode: ScanMode.FAST for regex-only, ScanMode.FULL for regex + NLP.

    Returns:
        List of Finding objects for detected PHI.
    """
    analyzer = get_analyzer_engine(mode=mode)
    results = analyzer.analyze(text=text, language="en", score_threshold=score_threshold)

    findings = []
    for result in results:
        if result.entity_type not in PHI_ENTITY_TYPES:
            continue
        findings.append(Finding(
            entity_type=result.entity_type,
            text=text[result.start:result.end],
            start=result.start,
            end=result.end,
            score=result.score,
        ))
    return findings


def scan_file(
    file_path: Path,
    score_threshold: float = 0.5,
    mode: ScanMode = ScanMode.FULL,
) -> list[Finding]:
    """Scan a file for PHI. Returns findings with file_path and line_number."""
    file_path = Path(file_path)
    content = file_path.read_text(encoding="utf-8")
    findings = scan_text(content, score_threshold=score_threshold, mode=mode)

    for finding in findings:
        finding.file_path = str(file_path)
        finding.line_number = content[:finding.start].count("\n") + 1

    return findings


def scan_directory(
    directory: Path,
    score_threshold: float = 0.5,
    recursive: bool = True,
    exclude_patterns: list[str] | None = None,
    mode: ScanMode = ScanMode.FULL,
) -> list[Finding]:
    """Scan all files in a directory for PHI."""
    directory = Path(directory)
    all_findings: list[Finding] = []

    # Combine .phiguardignore patterns with CLI exclude patterns
    file_spec = load_ignore_patterns(directory)
    cli_spec = build_ignore_spec(exclude_patterns or [])
    ignore_spec = merge_ignore_specs([file_spec, cli_spec])

    pattern = "**/*" if recursive else "*"

    for file_path in directory.glob(pattern):
        if file_path.is_dir():
            continue
        if file_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        if any(part.startswith(".") for part in file_path.parts):
            continue
        if should_ignore(file_path, directory, ignore_spec):
            continue

        try:
            findings = scan_file(file_path, score_threshold=score_threshold, mode=mode)
            all_findings.extend(findings)
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Warning: Could not scan {file_path}: {e}")
            continue

    return all_findings
