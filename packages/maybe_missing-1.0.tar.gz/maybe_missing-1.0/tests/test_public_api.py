import unittest

import maybe_missing
from maybe_missing import *  # noqa: F403


class PublicApiTests(unittest.TestCase):
    def test_module_exports_only_public_names(self) -> None:
        self.assertEqual(maybe_missing.__all__, ["Maybe", "MISSING"])

        public_names = {
            name
            for name in dir(maybe_missing)
            if not name.startswith("_") and name not in {"__all__"}
        }
        self.assertEqual(public_names, {"Maybe", "MISSING"})

    def test_star_import_respects_all(self) -> None:
        self.assertIn("Maybe", globals())
        self.assertIn("MISSING", globals())
        self.assertIs(MISSING, maybe_missing.MISSING)  # noqa: F405

    def test_missing_is_distinct_from_none(self) -> None:
        self.assertIsNot(maybe_missing.MISSING, None)
        value = None
        missing = maybe_missing.MISSING
        self.assertIsNone(value)
        self.assertIsNot(value, missing)


if __name__ == "__main__":
    unittest.main()
