import enum
import typing

__all__ = ["Maybe", "MISSING"]

_T = typing.TypeVar("_T")

class _MissingSentinel(enum.Enum):
    MISSING = ...

MISSING: typing.Final[typing.Literal[_MissingSentinel.MISSING]]
Maybe: typing.TypeAlias = _T | typing.Literal[_MissingSentinel.MISSING]
