from enum import Enum, auto


class LoggingInspectionLevelBEnums(
    Enum
):
    NOT_SET = auto()

    VERBOSE = auto()

    INFO = auto()

    WARNING = auto()

    ERROR = auto()

    CRITICAL = auto()

    def __enum_level_weight(
        self,
    ) -> str:
        enum_level_weight = (
            enum_level_weight_mapping[
                self
            ]
        )

        return enum_level_weight

    enum_level_weight = property(
        fget=__enum_level_weight
    )

    def __enum_color(
        self,
    ) -> str:
        enum_color = (
            enum_color_mapping[
                self
            ]
        )

        return enum_color

    enum_color = property(
        fget=__enum_color
    )


enum_level_weight_mapping = {
    LoggingInspectionLevelBEnums.NOT_SET: int(),
    LoggingInspectionLevelBEnums.VERBOSE: 1,
    LoggingInspectionLevelBEnums.INFO: 2,
    LoggingInspectionLevelBEnums.WARNING: 3,
    LoggingInspectionLevelBEnums.ERROR: 4,
    LoggingInspectionLevelBEnums.CRITICAL: 5,
}

# ANSI color codes for console output
enum_color_mapping = {
    LoggingInspectionLevelBEnums.NOT_SET: "",
    LoggingInspectionLevelBEnums.VERBOSE: "\033[90m",  # Gray
    LoggingInspectionLevelBEnums.INFO: "\033[36m",     # Cyan
    LoggingInspectionLevelBEnums.WARNING: "\033[93m",  # Amber (Bright Yellow)
    LoggingInspectionLevelBEnums.ERROR: "\033[91m\033[1m",    # Bold Red
    LoggingInspectionLevelBEnums.CRITICAL: "\033[95m\033[1m",  # Bold Magenta
}

# ANSI reset code
COLOR_RESET = "\033[0m"
