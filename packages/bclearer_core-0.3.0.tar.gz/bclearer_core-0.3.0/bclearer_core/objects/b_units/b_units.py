from abc import abstractmethod
from bclearer_orchestration_services.reporting_service.wrappers.run_and_log_function_wrapper import (
    run_and_log_function,
)


class BUnits:
    def __init__(
        self,
    ):
        pass

    def run(self) -> None:
        function_discriminator_name = (
            self.b_unit_domain_configuration.b_unit_bie_enum.b_enum_item_name
        )

        self.__run_b_unit(
            function_discriminator_name=function_discriminator_name
        )

    @run_and_log_function
    def __run_b_unit(self) -> None:
        self.b_unit_process_function()

    @abstractmethod
    def b_unit_process_function(
        self,
    ) -> ():
        pass
