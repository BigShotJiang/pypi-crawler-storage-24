"""Pipeline generator module for creating pipeline structure from configuration."""

# Import all functionality from the more modular template-based generator
