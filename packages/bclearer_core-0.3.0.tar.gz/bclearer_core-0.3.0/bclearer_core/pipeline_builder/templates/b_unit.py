"""Template for b_unit class."""

B_UNIT_TEMPLATE = """from bclearer_core.configurations.datastructure.logging_inspection_level_b_enums import (
    LoggingInspectionLevelBEnums,
)
from bclearer_core.objects.b_units import BUnits
from bclearer_orchestration_services.reporting_service.reporters.inspection_message_logger import (
    log_inspection_message,
)


class {class_name}BUnits(BUnits):
    def __init__(self):
        pass

    def run(self) -> None:
        log_inspection_message(
            message="Running bUnit: {{}}".format(
                self.__class__.__name__
            ),
            logging_inspection_level_b_enum=LoggingInspectionLevelBEnums.INFO,
        )

        self.b_unit_process_function()

    def b_unit_process_function(
        self,
    ) -> None:
        pass
"""
