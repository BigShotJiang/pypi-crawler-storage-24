"""Template for a simple startup script to run e2e tests."""

STARTUP_SCRIPT_TEMPLATE = """#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

if ! command -v uv >/dev/null 2>&1; then
    echo "uv is not installed. Install uv to run this script."
    exit 1
fi

uv venv "${SCRIPT_DIR}/.venv"
source "${SCRIPT_DIR}/.venv/bin/activate"
uv sync --active --no-install-project

if [ -z "${BCLEARER_REPO_ROOT:-}" ]; then
    echo "BCLEARER_REPO_ROOT is not set. Export it to the repo root containing libraries/."
    exit 1
fi

LEGACY_PIPELINES_PATH="${SCRIPT_DIR}/../bclearer_pipelines"

export PYTHONPATH="${LEGACY_PIPELINES_PATH}:${BCLEARER_REPO_ROOT}/libraries/core:${BCLEARER_REPO_ROOT}/libraries/orchestration_services:${BCLEARER_REPO_ROOT}/libraries/interop_services${PYTHONPATH:+:${PYTHONPATH}}"

python -m pytest "${SCRIPT_DIR}/tests/universal/e2e"
"""
