"""Template for b_unit class using object passing."""

B_UNIT_WITH_OBJECT_PASSING_TEMPLATE = """from bclearer_core.objects.b_units import (
    BUnitsWithObjectPassingAndReturning,
)


class {class_name}BUnits(BUnitsWithObjectPassingAndReturning):
    def __init__(self, input_object=None):
        super().__init__(
            input_object=input_object
        )

    def _b_unit_process_function(
        self,
    ) -> None:
        pass
"""
