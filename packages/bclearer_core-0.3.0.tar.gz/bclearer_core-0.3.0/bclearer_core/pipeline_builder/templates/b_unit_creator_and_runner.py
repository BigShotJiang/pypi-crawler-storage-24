"""Template for b_unit creator and runner."""

B_UNIT_CREATOR_AND_RUNNER_TEMPLATE = """def create_and_run_b_unit(
    b_unit_type,
    input_object=None,
) -> None:
    if input_object is None:
        b_unit = b_unit_type()
    else:
        b_unit = b_unit_type(
            input_object=input_object
        )

    b_unit.run()
"""
