"""Template for pyproject.toml."""

PYPROJECT_TEMPLATE = """[project]
name = "{domain_name}_pipelines"
version = "0.1.0"
description = "Generated bclearer pipeline package"
requires-python = ">=3.10"
dependencies = [
    "pytest",
    "psutil",
]

[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"
"""
