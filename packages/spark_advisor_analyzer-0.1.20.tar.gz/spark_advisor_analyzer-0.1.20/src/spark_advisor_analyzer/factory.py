from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING

from spark_advisor_analyzer.agent.orchestrator import AgentOrchestrator
from spark_advisor_analyzer.ai.service import LlmAnalysisService
from spark_advisor_analyzer.orchestrator import AdviceOrchestrator
from spark_advisor_models.defaults import DEFAULT_THRESHOLDS
from spark_advisor_models.model import AnalysisMode
from spark_advisor_rules import StaticAnalysisService, rules_for_threshold

if TYPE_CHECKING:
    from collections.abc import Iterator

    from spark_advisor_analyzer.ai.client import LlmClient
    from spark_advisor_models.config import AiSettings, Thresholds


def create_analysis_stack(
    *,
    ai_client: LlmClient | None,
    ai_settings: AiSettings | None = None,
    thresholds: Thresholds,
) -> AdviceOrchestrator:
    static = StaticAnalysisService(rules_for_threshold(thresholds))

    llm_service: LlmAnalysisService | None = None
    agent_orch: AgentOrchestrator | None = None

    if ai_client is not None:
        if ai_settings is None:
            raise ValueError("ai_settings required when client is provided")
        llm_service = LlmAnalysisService(ai_client, ai_settings, thresholds)
        agent_orch = AgentOrchestrator(ai_client, static, ai_settings)

    return AdviceOrchestrator(static, llm_service, agent_orch)


@contextmanager
def create_analysis_context(
    *,
    mode: AnalysisMode = AnalysisMode.AI,
    ai_settings: AiSettings | None = None,
    thresholds: Thresholds | None = None,
) -> Iterator[AdviceOrchestrator]:
    from spark_advisor_models.config import AiSettings as AiSettingsCls

    resolved_thresholds = thresholds or DEFAULT_THRESHOLDS
    client = None
    resolved_ai: AiSettings | None = ai_settings

    if mode in (AnalysisMode.AI, AnalysisMode.AGENT):
        from spark_advisor_analyzer.ai.client import LlmClient

        if resolved_ai is None:
            resolved_ai = AiSettingsCls()
        client = LlmClient(
            base_url=resolved_ai.base_url,
            api_key=resolved_ai.api_key,
            timeout=resolved_ai.api_timeout,
        )
        client.open()

    try:
        yield create_analysis_stack(
            ai_client=client,
            ai_settings=resolved_ai,
            thresholds=resolved_thresholds,
        )
    finally:
        if client is not None:
            client.close()
