import json
from typing import Any

import structlog
from openai.types.chat import (
    ChatCompletion,
    ChatCompletionAssistantMessageParam,
    ChatCompletionMessage,
    ChatCompletionMessageParam,
    ChatCompletionNamedToolChoiceParam,
    ChatCompletionToolChoiceOptionParam,
    ChatCompletionToolMessageParam,
)
from openai.types.chat.chat_completion_message_function_tool_call_param import (
    ChatCompletionMessageFunctionToolCallParam,
)
from openai.types.chat.chat_completion_message_function_tool_call_param import (
    Function as ToolCallFunction,
)
from pydantic import ValidationError

from spark_advisor_analyzer.agent.context import AgentContext
from spark_advisor_analyzer.agent.handlers import ToolExecutionError, execute_tool
from spark_advisor_analyzer.agent.prompts import build_agent_system_prompt, build_initial_message
from spark_advisor_analyzer.agent.tools import AGENT_TOOLS, AgentToolName
from spark_advisor_analyzer.ai.client import LlmClient
from spark_advisor_analyzer.ai.report_builder import build_advisor_report
from spark_advisor_models.config import AiSettings
from spark_advisor_models.model import AnalysisResult, AnalysisToolInput, JobAnalysis
from spark_advisor_models.tracing import get_tracer
from spark_advisor_rules import StaticAnalysisService

logger = structlog.stdlib.get_logger(__name__)


class AgentOrchestrator:
    def __init__(
        self,
        client: LlmClient,
        static_analysis: StaticAnalysisService,
        ai_settings: AiSettings,
    ) -> None:
        self._client = client
        self._static = static_analysis
        self._ai = ai_settings
        self._max_iterations = ai_settings.max_agent_iterations
        self._system_prompt = build_agent_system_prompt(self._max_iterations)

    def run(self, job: JobAnalysis) -> AnalysisResult:
        context = AgentContext(job=job)
        messages: list[ChatCompletionMessageParam] = [
            {"role": "user", "content": build_initial_message(job)},
        ]

        for iteration in range(self._max_iterations):
            logger.info("Agent iteration %d/%d", iteration + 1, self._max_iterations)

            response = self._call_llm(messages, tool_choice="auto")
            message = response.choices[0].message

            final_input = self._extract_final_report(message)
            if final_input is not None:
                logger.info("Agent completed after %d iterations", iteration + 1)
                return self._build_result(job, context, final_input)

            tool_calls = message.tool_calls

            if not tool_calls:
                messages.append({"role": "assistant", "content": message.content or ""})
                messages.append({
                    "role": "user",
                    "content": f"Please call {AgentToolName.SUBMIT_FINAL_REPORT} with your analysis now.",
                })
                continue

            assistant_msg: ChatCompletionAssistantMessageParam = {
                "role": "assistant",
                "content": message.content or "",
                "tool_calls": [
                    ChatCompletionMessageFunctionToolCallParam(
                        id=tc.id,
                        type="function",
                        function=ToolCallFunction(name=tc.function.name, arguments=tc.function.arguments),
                    )
                    for tc in tool_calls
                    if hasattr(tc, "function")
                ],
            }
            messages.append(assistant_msg)

            for tc in tool_calls:
                if hasattr(tc, "function"):
                    logger.info("Executing tool: %s", tc.function.name)
                    result_content = self._execute_single_tool(
                        tc.function.name, json.loads(tc.function.arguments), context,
                    )
                    tool_msg: ChatCompletionToolMessageParam = {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result_content,
                    }
                    messages.append(tool_msg)

        logger.warning("Agent hit max iterations (%d), forcing final report", self._max_iterations)
        return self._force_final_report(job, context, messages)

    def _call_llm(
        self,
        messages: list[ChatCompletionMessageParam],
        *,
        tool_choice: ChatCompletionToolChoiceOptionParam,
    ) -> ChatCompletion:
        tracer = get_tracer()
        with tracer.start_as_current_span("analyzer.agent.llm_call"):
            return self._client.create_message(
                model=self._ai.model,
                max_tokens=self._ai.max_tokens,
                system=self._system_prompt,
                messages=messages,
                tools=AGENT_TOOLS,
                tool_choice=tool_choice,
            )

    def _execute_single_tool(
        self,
        name: str,
        input_data: Any,
        context: AgentContext,
    ) -> str:
        tracer = get_tracer()
        try:
            with tracer.start_as_current_span("analyzer.agent.tool_execute", attributes={"tool": name}):
                return execute_tool(name, input_data, context, self._static)
        except ToolExecutionError as e:
            logger.warning("Tool %s failed: %s", name, e)
            return json.dumps({"error": str(e)})
        except Exception:
            logger.exception("Unexpected error in tool %s", name)
            return json.dumps({"error": f"Internal error executing {name}"})

    def _force_final_report(
        self,
        job: JobAnalysis,
        context: AgentContext,
        messages: list[ChatCompletionMessageParam],
    ) -> AnalysisResult:
        messages.append({
            "role": "user",
            "content": (
                "You have reached the maximum number of tool calls. "
                "You MUST call submit_final_report now with your best analysis "
                "based on the information gathered so far."
            ),
        })

        response = self._call_llm(
            messages,
            tool_choice=ChatCompletionNamedToolChoiceParam(
                type="function", function={"name": AgentToolName.SUBMIT_FINAL_REPORT},
            ),
        )

        final_input = self._extract_final_report(response.choices[0].message)
        if final_input is not None:
            return self._build_result(job, context, final_input)

        logger.error("Force-submit failed, returning rules-only result")
        rule_results = context.get_or_run_rules(self._static)
        return AnalysisResult(app_id=job.app_id, job=job, rule_results=rule_results)

    def _build_result(
        self,
        job: JobAnalysis,
        context: AgentContext,
        parsed: AnalysisToolInput,
    ) -> AnalysisResult:
        rule_results = context.get_or_run_rules(self._static)
        report = build_advisor_report(job.app_id, parsed, rule_results)
        return AnalysisResult(app_id=job.app_id, job=job, rule_results=rule_results, ai_report=report)

    @staticmethod
    def _extract_final_report(message: ChatCompletionMessage) -> AnalysisToolInput | None:
        tool_calls = message.tool_calls
        if not tool_calls:
            return None
        for tc in tool_calls:
            if hasattr(tc, 'function') and tc.function.name == AgentToolName.SUBMIT_FINAL_REPORT:
                try:
                    return AnalysisToolInput.model_validate(json.loads(tc.function.arguments))
                except (ValidationError, json.JSONDecodeError):
                    logger.warning("Failed to validate submit_final_report input, skipping")
                    return None
        return None
