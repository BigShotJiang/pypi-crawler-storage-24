import json
import logging
import os
from typing import Dict, Any, List, Optional, Union

from apipod_registry.definitions.service_definitions import (
    ServiceDefinition, EndpointDefinition, EndpointParameter, 
    ParameterDefinition, ServiceAddress
)
from apipod_registry.parsers.service_adress_parser import create_service_address

from apipod_registry.parsers.parser import parse_service_definition

logger = logging.getLogger(__name__)

class SupabaseRegistryDB:
    def __init__(self, url: str = None, key: str = None):
        from supabase import create_client
        self.url = url or os.environ.get("SUPABASE_URL")
        self.key = key or os.environ.get("SUPABASE_KEY")
        self._client = create_client(self.url, self.key)

    def _parse_row_to_definition(self, row: Dict[str, Any]) -> ServiceDefinition:
        """Bridge between Supabase rows and the Parser logic."""
        openapi_raw = row.get("openapi_json")
        full_spec = json.loads(openapi_raw) if isinstance(openapi_raw, str) else (openapi_raw or {})
        
        # Determine the source (URL or Provider) for the parser selector
        spec_source = row.get("url") or row.get("provider") or ""

        # Use your new top-level parsing function
        service_def = parse_service_definition(full_spec, spec_source=spec_source)

        # Override or supplement metadata from the DB row that OpenAPI might not have
        service_def.id = row.get("id") or service_def.id
        service_def.service_address = create_service_address(address=row.get("url"), provider=row.get("provider"))
        service_def.display_name = row.get("descriptor_id") or row.get("display_name") or service_def.display_name
        service_def.specification = row.get("provider", service_def.specification)
        
        return service_def

    def list_services(self) -> List[ServiceDefinition]:
        """Fetch all services from Supabase and convert them to domain definitions."""
        response = self._client.rpc("get_services").execute()

        if not response.data:
            logger.warning("No services found in the registry.")
            return []

        return [self._parse_row_to_definition(row) for row in response.data]

    def load_service(self, id: str) -> Optional[ServiceDefinition]:
        """Fetch a single service by ID from Supabase and convert it to a domain definition."""
        response = self._client.rpc("get_service_by_id", {"p_id": id}).execute()

        if not response.data:
            logger.warning(f"Service with ID {id} not found.")
            return None

        return self._parse_row_to_definition(response.data[0])