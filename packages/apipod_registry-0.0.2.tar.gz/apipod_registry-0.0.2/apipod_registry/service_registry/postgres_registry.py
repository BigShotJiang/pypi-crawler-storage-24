from typing import Dict, Any, List, Optional
import os
import logging
import json

from .registry_db_interface import RegistryDBInterface

logger = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    import psycopg2
    import psycopg2.extras as extras
except Exception:
    psycopg2 = None
    extras = None


class PostgresRegistryDB(RegistryDBInterface):
    """Simple PostgreSQL-backed registry DB for local development/testing.

    Requires `psycopg2`. The implementation stores service records in a table
    with columns `(id TEXT PRIMARY KEY, display_name TEXT, version TEXT, data JSONB)`.
    """

    def __init__(self,
                 dsn: Optional[str] = None,
                 host: Optional[str] = None,
                 port: Optional[int] = None,
                 user: Optional[str] = None,
                 password: Optional[str] = None,
                 dbname: Optional[str] = None,
                 table: str = "services"):
        if psycopg2 is None:
            raise ImportError("psycopg2 is required for PostgresRegistryDB; install `pip install psycopg2-binary`")

        self._table = table

        # Build connection params
        if dsn:
            conn_args = dsn
        else:
            host = host or os.environ.get("PG_HOST", "localhost")
            port = port or int(os.environ.get("PG_PORT", 5432))
            user = user or os.environ.get("PG_USER", "postgres")
            password = password or os.environ.get("PG_PASSWORD", "")
            dbname = dbname or os.environ.get("PG_DATABASE", "postgres")
            conn_args = {
                "host": host,
                "port": port,
                "user": user,
                "password": password,
                "dbname": dbname,
            }

        # Connect
        try:
            self._conn = psycopg2.connect(conn_args) if isinstance(conn_args, str) else psycopg2.connect(**conn_args)
            self._conn.autocommit = True
        except Exception as e:
            logger.exception("Failed to connect to Postgres: %s", e)
            raise

        # Ensure table exists
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {self._table} (
                    id TEXT PRIMARY KEY,
                    display_name TEXT,
                    version TEXT,
                    data JSONB
                )
                """)
        except Exception as e:
            logger.exception("Failed to ensure registry table exists: %s", e)
            raise

    def upsert_service(self, service_dict: Dict[str, Any]) -> None:
        sid = service_dict.get("id")
        if not sid:
            raise ValueError("service_dict must contain 'id' key for upsert")
        display_name = service_dict.get("display_name")
        version = service_dict.get("version")
        data_json = json.dumps(service_dict)

        try:
            with self._conn.cursor() as cur:
                cur.execute(
                    f"INSERT INTO {self._table} (id, display_name, version, data) VALUES (%s, %s, %s, %s) "
                    f"ON CONFLICT (id) DO UPDATE SET display_name = EXCLUDED.display_name, version = EXCLUDED.version, data = EXCLUDED.data",
                    (sid, display_name, version, extras.Json(service_dict))
                )
        except Exception as e:
            logger.exception("Postgres upsert_service error: %s", e)
            raise

    def get_service_by_id(self, service_id: str) -> Optional[Dict[str, Any]]:
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"SELECT data FROM {self._table} WHERE id = %s LIMIT 1", (service_id,))
                row = cur.fetchone()
                if not row:
                    return None
                return row[0]
        except Exception as e:
            logger.exception("Postgres get_service_by_id error: %s", e)
            return None

    def get_service_by_name(self, display_name: str) -> Optional[Dict[str, Any]]:
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"SELECT data FROM {self._table} WHERE display_name = %s LIMIT 1", (display_name,))
                row = cur.fetchone()
                if not row:
                    return None
                return row[0]
        except Exception as e:
            logger.exception("Postgres get_service_by_name error: %s", e)
            return None

    def delete_service(self, service_id: str) -> None:
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"DELETE FROM {self._table} WHERE id = %s", (service_id,))
        except Exception as e:
            logger.exception("Postgres delete_service error: %s", e)
            raise

    def list_services(self) -> List[Dict[str, Any]]:
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"SELECT data FROM {self._table}")
                rows = cur.fetchall()
                return [r[0] for r in rows]
        except Exception as e:
            logger.exception("Postgres list_services error: %s", e)
            return []

    def get_version_index(self) -> Dict[str, str]:
        idx: Dict[str, str] = {}
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"SELECT id, version FROM {self._table}")
                for sid, ver in cur.fetchall():
                    if sid and ver:
                        idx[sid] = ver
        except Exception as e:
            logger.exception("Postgres get_version_index error: %s", e)
        return idx

    def close(self) -> None:
        try:
            if getattr(self, "_conn", None):
                self._conn.close()
        except Exception:
            pass
