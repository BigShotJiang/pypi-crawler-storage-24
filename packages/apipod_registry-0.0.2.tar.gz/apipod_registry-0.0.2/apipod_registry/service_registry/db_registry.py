from typing import List, Optional, Dict, Union, Any
import logging

from apipod_registry.definitions.service_definitions import ServiceDefinition
from apipod_registry.service_registry.service_registry_interface import IServiceRegistry
from apipod_registry.service_registry.registry_db_interface import RegistryDBInterface

logger = logging.getLogger(__name__)

class DBServiceStore(IServiceRegistry):
    """
    Adapter that persists ServiceDefinition objects via RegistryDBInterface.
    Ensures data consistency between Pydantic models and Database records.
    """

    def __init__(self, db: RegistryDBInterface):
        self._db = db

    def _to_record(self, service: ServiceDefinition) -> Dict[str, Any]:
        """
        Converts a Pydantic ServiceDefinition into a dictionary for DB insertion.
        Supports Pydantic v1 (.dict) and v2 (.model_dump).
        """
        if not isinstance(service, ServiceDefinition):
            # If it's already a dict, return it (safety fallback)
            return service if isinstance(service, dict) else {}
            
        dump_func = getattr(service, "model_dump", getattr(service, "dict", None))
        if dump_func:
            return dump_func(exclude_none=True)
        return {}

    def _from_record(self, rec: Union[Dict[str, Any], ServiceDefinition]) -> Optional[ServiceDefinition]:
        """
        Converts a database record (dict) into a ServiceDefinition object.
        If 'rec' is already an object, returns it directly to avoid double-parsing.
        """
        if not rec:
            return None

        # 1. Check if the database layer already returned a mapped object
        if isinstance(rec, ServiceDefinition):
            return rec

        # 2. Otherwise, treat it as a dictionary and hydrate it
        try:
            return ServiceDefinition(**rec)
        except Exception as e:
            # Type-safe ID fetch for logging
            sid = rec.get('id') if isinstance(rec, dict) else getattr(rec, 'id', 'unknown')
            logger.error(f"Mapping Error: Could not hydrate ServiceDefinition for [{sid}]: {e}")
            return None

    def save_service(self, service: ServiceDefinition) -> None:
        """Persists a service to the underlying database."""
        rec = self._to_record(service)
        self._db.upsert_service(rec)

    def load_service(self, id_or_name: str) -> Optional[ServiceDefinition]:
        """
        Loads a single service. Tries ID first, then falls back to Name/Model ID.
        """
        # Attempt lookup by ID
        rec = self._db.get_service_by_id(id_or_name)
        
        # Fallback: Many registries use names or model_ids as primary lookup keys
        if not rec and hasattr(self._db, 'get_service_by_name'):
            rec = self._db.get_service_by_name(id_or_name)
            
        return self._from_record(rec)

    def delete_service(self, id_or_name: str) -> None:
        """
        Resolves the service to its primary ID and deletes it from the database.
        """
        svc = self.load_service(id_or_name)
        if svc:
            # We use svc.id to ensure we are deleting by the primary key
            self._db.delete_service(svc.id)
        else:
            # If we can't find it, attempt a blind delete by the provided string
            self._db.delete_service(id_or_name)

    def list_services(self) -> List[ServiceDefinition]:
        """
        Fetches all records from the database and returns a list of 
        fully-validated ServiceDefinition objects.
        """
        raw_results = self._db.list_services()
        
        valid_services = []
        for item in raw_results:
            obj = self._from_record(item)
            if obj:
                valid_services.append(obj)
        
        logger.info(f"DBServiceStore: Synchronized {len(valid_services)} services from database.")
        return valid_services

    def get_version_index(self) -> Dict[str, str]:
        """Returns a mapping of service IDs to their current version strings."""
        return self._db.get_version_index()