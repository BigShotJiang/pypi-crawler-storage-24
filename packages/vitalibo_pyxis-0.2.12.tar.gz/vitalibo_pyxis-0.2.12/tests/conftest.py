import pytest

pytest.register_assert_rewrite('pyxis.pyspark')
