## [[2.1.2](https://github.com/bancolombia/ca-scaffold-py/compare/v2.1.1...v2.1.2)] - 2026-03-10

###  

### 🐛 Fix Patch Release: updating project version ([b4013bf](https://github.com/bancolombia/ca-scaffold-py/commit/b4013bf738b7c11a4e2190706fdc42d133cd0f0a)) - Contribuidor: josealfredore2604
fix: updating project version

### General

- Bug Fixed: updating project version ([3059244](https://github.com/bancolombia/ca-scaffold-py/commit/30592446b65d0d79dd878151c1de65b3bcb824d2)) - Contribuidor: Jose Ramírez
- Bug Fixed: updating project version ([d09983a](https://github.com/bancolombia/ca-scaffold-py/commit/d09983ad5fe107a245d253acc490695a53cdd3ed)) - Contribuidor: Jose Ramírez
- Bug Fixed: updating project version ([103d30a](https://github.com/bancolombia/ca-scaffold-py/commit/103d30af98d6479bbfdef88abcdb83951249b5a8)) - Contribuidor: Jose Ramírez

## [[2.1.1](https://github.com/bancolombia/ca-scaffold-py/compare/v2.1.0...v2.1.1)] - 2026-03-10

###  

### 🐛 Fix Patch Release: Remove .env* ignore ([04575a8](https://github.com/bancolombia/ca-scaffold-py/commit/04575a85df83771557f98cd59810fd81f4fc3d48)) - Contribuidor: josealfredore2604
fix: remove .env* exclude

### General

- Bug Fixed: remove .env* exclude ([a9faf83](https://github.com/bancolombia/ca-scaffold-py/commit/a9faf838239261f3819711c6f957c16dadb63f6e)) - Contribuidor: Jose Ramírez

## [[2.1.0](https://github.com/bancolombia/ca-scaffold-py/compare/v2.0.0...v2.1.0)] - 2026-01-28

###  

### 🚀 Features Release: Implementación de opentelemetry ([5ed8f4b](https://github.com/bancolombia/ca-scaffold-py/commit/5ed8f4b28cbac3edf265ff257a220861c9528bd7)) - Contribuidor: josealfredore2604
Feature/opentelemetry implementation

### General

- Feature: implement OpenTelemetry instrumentation and configuration ([1e105c6](https://github.com/bancolombia/ca-scaffold-py/commit/1e105c6b23405eb9ca46ebf4f1745d143c6eaf4e)) - Contribuidor: Jose Ramírez
- Feature: implement OpenTelemetry instrumentation and configuration ([bb23c19](https://github.com/bancolombia/ca-scaffold-py/commit/bb23c19d778df56ae1e675dbbbeee1ae2d237f6f)) - Contribuidor: Jose Ramírez
- Feature: implement OpenTelemetry tracing for Kafka and Agent ([77349c4](https://github.com/bancolombia/ca-scaffold-py/commit/77349c41b1114a512a8be9ec2d28faef21531a29)) - Contribuidor: Jose Alfredo Ramirez Espinosa


### auth

- Feature: integrar autenticación con EntraID ([87b54d1](https://github.com/bancolombia/ca-scaffold-py/commit/87b54d127d771b059e7ce3265724d44c32252512)) - Contribuidor: rjbarcenas
- Feature: integrar autorizacion roles ([22dd1ce](https://github.com/bancolombia/ca-scaffold-py/commit/22dd1cecaef5e9b20b49fc54b7aca1849aa3c53b)) - Contribuidor: rjbarcenas

## [[2.0.0](https://github.com/bancolombia/ca-scaffold-py/compare/v1.0.0...v2.0.0)] - 2025-12-19

###  

### ⚠️ Breaking Release: mandatory --type flag and agent-procode template support ([2c2b59c](https://github.com/bancolombia/ca-scaffold-py/commit/2c2b59cf9e709f2c6d9b43bd47d3b5f70a49b40a)) - Contribuidor: josealfredore2604


### BREAKING CHANGE

* ** :** The --type flag is now mandatory for project generation.
This change was necessary to support the new multi-template architecture.

- Added 'agent-procode' template with LangGraph, Kafka, and Clean Architecture.
- Restructured 'scaffold/' directory to organize templates under 'templates/mcp_server' and 'templates/agent_procode'.
- Updated CLI parsers and handlers to require the project type.
- Fixed unit tests to align with the new directory structure and mandatory arguments.

## [[1.0.0](https://github.com/bancolombia/ca-scaffold-py/compare/undefined...v1.0.0)] - 2025-11-28

###  

### 🐛 Fix Patch Release: Merge pull request #3 from bancolombia/feature/initial-scaffold-setup ([b23bb7f](https://github.com/bancolombia/ca-scaffold-py/commit/b23bb7f4fb2be8e0397f3b629d6e51da032f1058)) - Contribuidor: josealfredore2604
fixpatchrelease: Modificar pipelines

### General

- Feature: actualizando pyproject.toml ([82a32a4](https://github.com/bancolombia/ca-scaffold-py/commit/82a32a4a8e8da53a060961f32b95645392d8ec78)) - Contribuidor: Jose Ramirez
- Feature: actualizando pyproject.toml ([b79c5f2](https://github.com/bancolombia/ca-scaffold-py/commit/b79c5f2ce3c39e530fdfc7ce9248e9306f96aa04)) - Contribuidor: Jose Ramirez
- Feature: actualizando workflow ([d03fb0e](https://github.com/bancolombia/ca-scaffold-py/commit/d03fb0e607653dc488ca18a221485502660b1957)) - Contribuidor: Jose Ramirez
- Feature: actualizando workflow ([77234ba](https://github.com/bancolombia/ca-scaffold-py/commit/77234ba4fa7308c09d8a3062c080c5ad4f2a4ae7)) - Contribuidor: Jose Ramirez
- Feature: actualizando workflow ([df7d66c](https://github.com/bancolombia/ca-scaffold-py/commit/df7d66cc906fdb0e7560bf2239e706c336a50be7)) - Contribuidor: Jose Ramirez
- Feature: actualizando workflow ([7dfdd6d](https://github.com/bancolombia/ca-scaffold-py/commit/7dfdd6dc39127b1823bd5924e4161d6d2be53c6a)) - Contribuidor: Jose Alfredo Ramirez Espinosa
- Feature: actualizando workflow ([40d943b](https://github.com/bancolombia/ca-scaffold-py/commit/40d943b9dd86e3bdcd7e96cf061745f19efa65d7)) - Contribuidor: Jose Alfredo Ramirez Espinosa
- Feature: add initial scaffold generator project ([f0f28b6](https://github.com/bancolombia/ca-scaffold-py/commit/f0f28b61c93687f9b4ba36677841c3cb45eed2b0)) - Contribuidor: Jose Alfredo Ramirez Espinosa
- Add mcp_generator core functionality
- Add scaffold templates
- Add tests structure
- Add pyproject.toml and uv.lock
- Update .gitignore- Feature: Modificar pipelines ([91cfdae](https://github.com/bancolombia/ca-scaffold-py/commit/91cfdae0c71160b8cee09cbf6f4047c2d2fe0f41)) - Contribuidor: Jose Ramirez
- Feature: Modificar pipelines ([f00c0ff](https://github.com/bancolombia/ca-scaffold-py/commit/f00c0ff798dc6ed0fe89e540d2f7552472c4313e)) - Contribuidor: Jose Ramirez
