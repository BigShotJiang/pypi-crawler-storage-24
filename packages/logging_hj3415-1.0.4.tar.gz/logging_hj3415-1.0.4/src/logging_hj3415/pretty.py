# logging_hj3415/pretty.py
from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from enum import Enum
from typing import Any


def _jsonable(x: Any) -> Any:
    # pydantic v2
    if hasattr(x, "model_dump"):
        try:
            return _jsonable(x.model_dump())
        except Exception:
            pass

    # dataclass -> dict
    if is_dataclass(x):
        return _jsonable(asdict(x))  # pyright: ignore[reportArgumentType]

    # Enum -> value
    if isinstance(x, Enum):
        return x.value

    # dict -> key를 str로, value는 재귀 변환
    if isinstance(x, dict):
        out: dict[str, Any] = {}
        for k, v in x.items():
            if isinstance(k, tuple):
                kk = "|".join(map(str, k))
            else:
                kk = str(k)
            out[kk] = _jsonable(v)
        return out

    # list/tuple -> list
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]

    return x


def to_pretty_json(
    obj: Any,
    *,
    indent: int = 2,
    ensure_ascii: bool = False,
) -> str:
    """
    다양한 객체(dto / pydantic / dataclass / dict / 기타)를
    사람이 보기 좋은 JSON 문자열로 변환한다.
    """
    try:
        return json.dumps(
            _jsonable(obj),
            ensure_ascii=ensure_ascii,
            indent=indent,
            default=str,
        )
    except Exception:
        return str(obj)


def print_case(title: str, *, inp: dict[str, Any], out: Any) -> None:
    print("\n" + "=" * 80)
    print(f"[CASE] {title}")
    print("- input:")
    for k, v in inp.items():
        print(f"  - {k}: {v!r}")
    print("- output:")
    print(to_pretty_json(out))
    print("=" * 80 + "\n")
