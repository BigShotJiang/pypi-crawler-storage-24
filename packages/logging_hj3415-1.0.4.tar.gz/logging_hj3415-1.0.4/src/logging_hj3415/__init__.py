# logging_hj3415/__init__.py
from __future__ import annotations

from loguru import logger  # re-export for easy usage
from ._setup import setup_logging, current_log_level, reset_logging
from .pretty import to_pretty_json

__all__ = [
    "logger",
    "setup_logging",
    "current_log_level",
    "reset_logging",
    "to_pretty_json",
]
