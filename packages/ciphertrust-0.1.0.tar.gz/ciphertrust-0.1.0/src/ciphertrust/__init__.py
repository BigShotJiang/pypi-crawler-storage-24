"""Ciphertrust — a pure-Python RSA library.

Provides RSA key generation, PKCS#1 v1.5 and OAEP (v2.1) encryption/decryption,
signing/verification, and key serialization in PKCS#1/PKCS#8/PEM/DER formats.

Quick start::

    import ciphertrust

    pub, priv = ciphertrust.newkeys(2048)
    crypto = ciphertrust.encrypt(b"hello", pub)
    assert ciphertrust.decrypt(crypto, priv) == b"hello"
"""

from __future__ import annotations

from ciphertrust.common import bit_size, byte_size
from ciphertrust.key import PrivateKey, PublicKey, newkeys
from ciphertrust.pem import load_pem, save_pem
from ciphertrust.pkcs1 import (
    HASH_ASN1,
    HASH_METHODS,
    CryptoError,
    DecryptionError,
    VerificationError,
    compute_hash,
    decrypt,
    encrypt,
    find_signature_hash,
    sign,
    sign_hash,
    verify,
)
from ciphertrust.pkcs1_v2 import (
    decrypt as oaep_decrypt,
)
from ciphertrust.pkcs1_v2 import (
    encrypt as oaep_encrypt,
)
from ciphertrust.transform import bytes_to_int, int_to_bytes

__version__ = "0.1.0"

__all__ = [
    # Key classes and generation
    "PublicKey",
    "PrivateKey",
    "newkeys",
    # PKCS#1 v1.5
    "encrypt",
    "decrypt",
    "sign",
    "sign_hash",
    "verify",
    "find_signature_hash",
    "compute_hash",
    # OAEP (PKCS#1 v2.1)
    "oaep_encrypt",
    "oaep_decrypt",
    # Exceptions
    "CryptoError",
    "DecryptionError",
    "VerificationError",
    # Utilities
    "bit_size",
    "byte_size",
    "bytes_to_int",
    "int_to_bytes",
    "load_pem",
    "save_pem",
    # Constants
    "HASH_ASN1",
    "HASH_METHODS",
]
