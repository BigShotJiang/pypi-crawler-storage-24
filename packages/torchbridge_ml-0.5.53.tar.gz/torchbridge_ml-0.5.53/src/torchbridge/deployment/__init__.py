"""
Model Deployment Module for TorchBridge

Provides serving infrastructure for cross-backend validation demos and
production readiness checks. For model export (ONNX, TorchScript, safetensors),
use PyTorch's native APIs directly — TorchBridge does not wrap them.

Key Components:
- Production validation: readiness checks before deployment
- Backend metadata: schema for preserving hardware configuration information
- Inference serving: FastAPI, TorchServe, and Triton integrations

Example:
    ```python
    from torchbridge.deployment.serving import create_fastapi_server
    server = create_fastapi_server(model, model_name="my_model")
    ```

"""

from .optimization_metadata import (
    ExportFormat,
    FusionMetadata,
    HardwareMetadata,
    ModelMetadata,
    OptimizationMetadata,
    PerformanceMetadata,
    PrecisionMetadata,
    create_metadata,
)

# Production validation
from .production_validator import (
    ProductionRequirements,
    ProductionValidationResult,
    ProductionValidator,
    ValidationCheck,
    ValidationSeverity,
    ValidationStatus,
    validate_production_readiness,
)

# Serving module
from .serving import (
    BaseHandler,
    # FastAPI
    InferenceServer,
    ServerConfig,
    # TorchServe
    TorchBridgeHandler,
    TritonBackend,
    TritonDataType,
    # Triton
    TritonModelConfig,
    create_fastapi_server,
    create_torchserve_handler,
    create_triton_config,
    generate_triton_model_repository,
    package_for_torchserve,
    run_server,
)

__all__ = [
    # Metadata
    "OptimizationMetadata",
    "HardwareMetadata",
    "PrecisionMetadata",
    "FusionMetadata",
    "PerformanceMetadata",
    "ModelMetadata",
    "ExportFormat",
    "create_metadata",
    # Production Validation
    "ProductionValidator",
    "ProductionRequirements",
    "ProductionValidationResult",
    "ValidationCheck",
    "ValidationSeverity",
    "ValidationStatus",
    "validate_production_readiness",
    # Serving - TorchServe
    "TorchBridgeHandler",
    "BaseHandler",
    "create_torchserve_handler",
    "package_for_torchserve",
    # Serving - Triton
    "TritonModelConfig",
    "TritonBackend",
    "TritonDataType",
    "create_triton_config",
    "generate_triton_model_repository",
    # Serving - FastAPI
    "InferenceServer",
    "ServerConfig",
    "create_fastapi_server",
    "run_server",
]
