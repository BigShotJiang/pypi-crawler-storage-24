"""Storage service tests."""
