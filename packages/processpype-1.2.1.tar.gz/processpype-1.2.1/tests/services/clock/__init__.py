"""Clock service tests."""
