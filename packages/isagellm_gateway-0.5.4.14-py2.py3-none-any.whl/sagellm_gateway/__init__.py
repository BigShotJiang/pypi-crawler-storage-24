"""sageLLM Gateway - OpenAI/Anthropic Compatible API Gateway.

Layer: L6 (User Interface & API Gateway)
Dependencies: sagellm-protocol, sagellm-control-plane (optional)

提供标准化的 REST API 接口：
- OpenAI /v1/chat/completions
- OpenAI /v1/models
- OpenAI /v1/embeddings
- Session management
- Streaming support (SSE)
"""

from __future__ import annotations

from sagellm_gateway._version import __version__
from sagellm_gateway.adapters import BaseAdapter, DirectProxyAdapter, SageLLMAdapter
from sagellm_gateway.engine_router import EngineRouter, LoadBalanceStrategy
from sagellm_gateway.server import (
    app,
    configure_control_plane,
    configure_pd_router,
    create_app,
    get_adapter,
    set_adapter,
)

__layer__ = "L6"

__all__ = [
    "__version__",
    "__layer__",
    # Server
    "app",
    "create_app",
    "configure_control_plane",
    "configure_pd_router",
    "get_adapter",
    "set_adapter",
    # Adapters
    "BaseAdapter",
    "DirectProxyAdapter",
    "SageLLMAdapter",
    # Engine Router
    "EngineRouter",
    "LoadBalanceStrategy",
]
