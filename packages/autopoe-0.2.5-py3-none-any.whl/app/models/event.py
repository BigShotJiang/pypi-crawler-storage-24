from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class EventType(StrEnum):
    NODE_CREATED = "node_created"
    NODE_STATE_CHANGED = "node_state_changed"
    NODE_MESSAGE = "node_message"
    NODE_TERMINATED = "node_terminated"
    NODE_CONNECTED = "node_connected"
    STEWARD_CONTENT = "steward_content"
    TOOL_CALLED = "tool_called"
    HISTORY_ENTRY_ADDED = "history_entry_added"
    HISTORY_ENTRY_DELTA = "history_entry_delta"


DISPLAY_EVENTS: set[EventType] = {
    EventType.NODE_CREATED,
    EventType.NODE_STATE_CHANGED,
    EventType.NODE_MESSAGE,
    EventType.NODE_TERMINATED,
    EventType.NODE_CONNECTED,
    EventType.STEWARD_CONTENT,
    EventType.TOOL_CALLED,
}


@dataclass
class Event:
    type: EventType
    agent_id: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
