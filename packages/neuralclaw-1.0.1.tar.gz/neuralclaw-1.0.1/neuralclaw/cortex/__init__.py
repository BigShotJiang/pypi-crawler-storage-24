"""Cortex — Cognitive processing modules."""
