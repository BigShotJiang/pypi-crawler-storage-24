import mythic_container
from mythic_container.logging import logger
import base64

MYTHIC_RPC_CALLBACK_ENCRYPT_BYTES = "mythic_rpc_callback_encrypt_bytes"


class MythicRPCCallbackEncryptBytesMessage:
    def __init__(self,
                 Message: bytes,
                 AgentCallbackID: str = None,
                 IncludesUUID: bool = False,
                 IsBase64Encoded: bool = True,
                 C2Profile: str = "",
                 **kwargs):
        self.AgentCallbackID = AgentCallbackID
        self.Message = Message
        self.IncludesUUID = IncludesUUID
        self.IsBase64Encoded = IsBase64Encoded
        self.C2Profile = C2Profile
        for k, v in kwargs.items():
            if k == "AgentCallbackUUID":
                self.AgentCallbackID = v
                logger.warning("MythicRPCCallbackEncryptBytesMessage using old API call, update AgentCallbackUUID to AgentCallbackID")
                continue
            logger.info(f"Unknown kwarg {k} - {v}")

    def to_json(self):
        return {
            "agent_callback_id": self.AgentCallbackID,
            "message": base64.b64encode(self.Message).decode(),
            "include_uuid": self.IncludesUUID,
            "base64_message": self.IsBase64Encoded,
            "c2_profile": self.C2Profile
        }


class MythicRPCCallbackEncryptBytesMessageResponse:
    def __init__(self,
                 success: bool = False,
                 error: str = "",
                 message: bytes = None,
                 **kwargs):
        self.Success = success
        self.Error = error
        self.Message = base64.b64decode(message)
        for k, v in kwargs.items():
            logger.info(f"Unknown kwarg {k} - {v}")


async def SendMythicRPCCallbackEncryptBytes(
        msg: MythicRPCCallbackEncryptBytesMessage) -> MythicRPCCallbackEncryptBytesMessageResponse:
    response = await mythic_container.RabbitmqConnection.SendRPCDictMessage(queue=MYTHIC_RPC_CALLBACK_ENCRYPT_BYTES,
                                                                            body=msg.to_json())
    return MythicRPCCallbackEncryptBytesMessageResponse(**response)
