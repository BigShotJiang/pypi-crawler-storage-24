# opera-utils Documentation


## Table Of Contents

<!-- The documentation follows the project documentation as described the [Diátaxis documentation framework](https://diataxis.fr/)
-->

1. [Getting started](./getting-started.md)
1. [Tutorials](tutorials.md)
1. [How-To Guides](how-to-guides.md)
1. [Code Reference](reference/summary.md)
1. [Background theory](background-theory.md)
