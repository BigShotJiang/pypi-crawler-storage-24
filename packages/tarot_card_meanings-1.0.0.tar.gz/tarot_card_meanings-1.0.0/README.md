# Tarot Card Meanings — Python Library

A comprehensive Python library providing meanings, interpretations, and metadata for all 78 tarot cards.

**Source:** [Deckaura Tarot Card Meanings Guide](https://deckaura.com/blogs/guide/tarot-card-meanings)

## Installation

```bash
pip install tarot-card-meanings
```

## Quick Start

```python
from tarot_card_meanings import random_card, three_card_spread, birth_card

# Draw a random card
card = random_card()
print(f"{card['name']}: {card['upright']}")
print(f"Guide: {card['guide']}")

# 3-card spread (Past / Present / Future)
spread = three_card_spread()
print(f"Past: {spread['past']['name']}")
print(f"Present: {spread['present']['name']}")
print(f"Future: {spread['future']['name']}")

# Calculate your birth card
my_card = birth_card(6, 15, 1992)
print(f"Your birth card: {my_card['name']}")
```

## Features

- All 78 tarot cards (22 Major Arcana + 56 Minor Arcana)
- Upright and reversed meanings
- Love and career interpretations
- Yes/No readings
- Zodiac and element associations
- Birth card calculator
- 3-card spread generator
- Links to detailed guides for each card

## API Reference

| Function | Description |
|----------|-------------|
| `get_all_cards()` | Return all 78 cards |
| `get_card(name)` | Get a specific card by name |
| `get_major_arcana()` | Return 22 Major Arcana cards |
| `get_minor_arcana()` | Return 56 Minor Arcana cards |
| `get_suit(suit)` | Get cards by suit (Wands, Cups, Swords, Pentacles) |
| `random_card()` | Draw a random card |
| `three_card_spread()` | Draw a Past/Present/Future spread |
| `yes_no_reading()` | Draw a card for yes/no answer |
| `birth_card(month, day, year)` | Calculate tarot birth card from birthday |

## Card Data Structure

Each card contains:

```python
{
    "number": 17,
    "name": "The Star",
    "arcana": "Major",
    "suit": None,
    "element": "Air",
    "upright": "Hope, renewal, spirituality",
    "reversed": "Despair, lack of faith",
    "love": "Healing love, renewed hope",
    "career": "Creative inspiration, dream career",
    "yes_no": "Yes",
    "zodiac": "Aquarius",
    "guide": "https://deckaura.com/blogs/guide/star-tarot-meaning"
}
```

## Free Interactive Tools

- [Free Tarot Reading](https://deckaura.com/pages/free-tarot-reading) — Interactive 3-card and Celtic Cross spreads
- [Tarot Birth Card Calculator](https://deckaura.com/pages/tarot-birth-card-calculator) — Find your Major Arcana life card
- [Numerology Calculator](https://deckaura.com/pages/numerology-calculator) — Calculate your life path number
- [Daily Tarot Card](https://deckaura.com/pages/daily-tarot-card) — Draw a card for daily guidance
- [Spirit Animal Quiz](https://deckaura.com/pages/spirit-animal-quiz) — Discover your spirit animal
- [Angel Number Calculator](https://deckaura.com/pages/angel-number-calculator) — Decode angel numbers
- [What Are Oracle Cards?](https://deckaura.com/blogs/guide/what-are-oracle-cards) — Oracle vs tarot guide

## License

MIT — [Deckaura](https://deckaura.com)
