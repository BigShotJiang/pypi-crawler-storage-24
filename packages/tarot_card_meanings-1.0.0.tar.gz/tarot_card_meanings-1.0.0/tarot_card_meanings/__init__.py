"""
Tarot Card Meanings - Complete 78 Card Dataset for Python

A comprehensive Python library providing meanings, interpretations, and metadata
for all 78 tarot cards including Major Arcana and Minor Arcana.

Source: https://deckaura.com/blogs/guide/tarot-card-meanings

Free Interactive Tools:
- Free Tarot Reading: https://deckaura.com/pages/free-tarot-reading
- Birth Card Calculator: https://deckaura.com/pages/tarot-birth-card-calculator
- Numerology Calculator: https://deckaura.com/pages/numerology-calculator
- Daily Tarot Card: https://deckaura.com/pages/daily-tarot-card
"""

import random

__version__ = "1.0.0"
__author__ = "Deckaura"
__url__ = "https://deckaura.com"

CARDS = [
    {"number": 0, "name": "The Fool", "arcana": "Major", "suit": None, "element": "Air", "upright": "New beginnings, innocence, adventure, free spirit", "reversed": "Recklessness, fear of change, holding back", "love": "Exciting new romance, spontaneous love", "career": "New career path, leap of faith", "yes_no": "Yes", "zodiac": "Uranus", "guide": "https://deckaura.com/blogs/guide/fool-tarot-meaning"},
    {"number": 1, "name": "The Magician", "arcana": "Major", "suit": None, "element": "Air", "upright": "Manifestation, willpower, resourcefulness", "reversed": "Manipulation, poor planning, untapped talents", "love": "Magnetic attraction, confident pursuit", "career": "Skill mastery, new opportunity", "yes_no": "Yes", "zodiac": "Mercury", "guide": "https://deckaura.com/blogs/guide/magician-tarot-meaning"},
    {"number": 2, "name": "The High Priestess", "arcana": "Major", "suit": None, "element": "Water", "upright": "Intuition, mystery, inner wisdom", "reversed": "Secrets, disconnection from intuition", "love": "Hidden feelings, trust your instincts", "career": "Follow your gut, hidden knowledge", "yes_no": "Yes", "zodiac": "Moon", "guide": "https://deckaura.com/blogs/guide/high-priestess-tarot-meaning"},
    {"number": 3, "name": "The Empress", "arcana": "Major", "suit": None, "element": "Earth", "upright": "Abundance, nurturing, fertility, beauty", "reversed": "Insecurity, neglect, creative block", "love": "Deep love, sensual connection", "career": "Growth, prosperity, creative success", "yes_no": "Yes", "zodiac": "Venus", "guide": "https://deckaura.com/blogs/guide/empress-tarot-meaning"},
    {"number": 4, "name": "The Emperor", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Authority, structure, leadership, stability", "reversed": "Domination, rigidity, lack of discipline", "love": "Committed partner, protective love", "career": "Leadership role, promotion", "yes_no": "Yes", "zodiac": "Aries", "guide": "https://deckaura.com/blogs/guide/emperor-tarot-meaning"},
    {"number": 5, "name": "The Hierophant", "arcana": "Major", "suit": None, "element": "Earth", "upright": "Tradition, spiritual guidance, conformity", "reversed": "Rebellion, subversion, new approaches", "love": "Traditional relationship, commitment", "career": "Mentorship, conventional path", "yes_no": "Yes", "zodiac": "Taurus", "guide": "https://deckaura.com/blogs/guide/hierophant-tarot-meaning"},
    {"number": 6, "name": "The Lovers", "arcana": "Major", "suit": None, "element": "Air", "upright": "Love, choices, partnerships, harmony", "reversed": "Disharmony, imbalance, misalignment", "love": "Soulmate connection, deep bond", "career": "Important partnership, career choice", "yes_no": "Yes", "zodiac": "Gemini", "guide": "https://deckaura.com/blogs/guide/lovers-tarot-meaning"},
    {"number": 7, "name": "The Chariot", "arcana": "Major", "suit": None, "element": "Water", "upright": "Determination, willpower, triumph", "reversed": "Lack of direction, aggression", "love": "Pursuing love with confidence", "career": "Ambition, career victory", "yes_no": "Yes", "zodiac": "Cancer", "guide": "https://deckaura.com/blogs/guide/chariot-tarot-meaning"},
    {"number": 8, "name": "Strength", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Courage, patience, inner strength", "reversed": "Self-doubt, weakness, insecurity", "love": "Patient love, gentle strength", "career": "Perseverance, overcoming challenges", "yes_no": "Yes", "zodiac": "Leo", "guide": "https://deckaura.com/blogs/guide/strength-tarot-meaning"},
    {"number": 9, "name": "The Hermit", "arcana": "Major", "suit": None, "element": "Earth", "upright": "Introspection, solitude, inner guidance", "reversed": "Isolation, loneliness, withdrawal", "love": "Self-discovery before love", "career": "Career reflection, finding purpose", "yes_no": "Maybe", "zodiac": "Virgo", "guide": "https://deckaura.com/blogs/guide/hermit-tarot-meaning"},
    {"number": 10, "name": "Wheel of Fortune", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Cycles, destiny, turning points", "reversed": "Bad luck, resistance to change", "love": "Fated romance, relationship shift", "career": "Career change, unexpected opportunity", "yes_no": "Yes", "zodiac": "Jupiter", "guide": "https://deckaura.com/blogs/guide/wheel-of-fortune-tarot-meaning"},
    {"number": 11, "name": "Justice", "arcana": "Major", "suit": None, "element": "Air", "upright": "Fairness, truth, accountability", "reversed": "Unfairness, dishonesty", "love": "Fair partnership, karmic relationship", "career": "Legal matters, ethical decisions", "yes_no": "Yes", "zodiac": "Libra", "guide": "https://deckaura.com/blogs/guide/justice-tarot-meaning"},
    {"number": 12, "name": "The Hanged Man", "arcana": "Major", "suit": None, "element": "Water", "upright": "Surrender, new perspective, pause", "reversed": "Stalling, resistance, indecision", "love": "Pause in relationship, new viewpoint", "career": "Career pause, seeing things differently", "yes_no": "Maybe", "zodiac": "Neptune", "guide": "https://deckaura.com/blogs/guide/hanged-man-tarot-meaning"},
    {"number": 13, "name": "Death", "arcana": "Major", "suit": None, "element": "Water", "upright": "Transformation, endings, new beginnings", "reversed": "Resistance to change, stagnation", "love": "Relationship transformation", "career": "Career ending leading to new start", "yes_no": "Maybe", "zodiac": "Scorpio", "guide": "https://deckaura.com/blogs/guide/death-tarot-meaning"},
    {"number": 14, "name": "Temperance", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Balance, patience, moderation", "reversed": "Imbalance, excess, lack of patience", "love": "Balanced relationship, harmony", "career": "Work-life balance", "yes_no": "Yes", "zodiac": "Sagittarius", "guide": "https://deckaura.com/blogs/guide/temperance-tarot-meaning"},
    {"number": 15, "name": "The Devil", "arcana": "Major", "suit": None, "element": "Earth", "upright": "Addiction, materialism, shadow self", "reversed": "Breaking free, releasing limiting beliefs", "love": "Toxic attachment, passion without depth", "career": "Feeling trapped, materialism", "yes_no": "No", "zodiac": "Capricorn", "guide": "https://deckaura.com/blogs/guide/devil-tarot-meaning"},
    {"number": 16, "name": "The Tower", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Sudden change, upheaval, revelation", "reversed": "Avoiding disaster, fear of change", "love": "Relationship shakeup", "career": "Sudden job loss, upheaval", "yes_no": "No", "zodiac": "Mars", "guide": "https://deckaura.com/blogs/guide/tower-tarot-meaning"},
    {"number": 17, "name": "The Star", "arcana": "Major", "suit": None, "element": "Air", "upright": "Hope, renewal, spirituality", "reversed": "Despair, lack of faith", "love": "Healing love, renewed hope", "career": "Creative inspiration, dream career", "yes_no": "Yes", "zodiac": "Aquarius", "guide": "https://deckaura.com/blogs/guide/star-tarot-meaning"},
    {"number": 18, "name": "The Moon", "arcana": "Major", "suit": None, "element": "Water", "upright": "Illusion, fear, subconscious", "reversed": "Release of fear, clarity", "love": "Confusion in love, hidden emotions", "career": "Uncertainty, trust intuition", "yes_no": "Maybe", "zodiac": "Pisces", "guide": "https://deckaura.com/blogs/guide/moon-tarot-meaning"},
    {"number": 19, "name": "The Sun", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Joy, success, vitality", "reversed": "Temporary sadness", "love": "Happy relationship, joy in love", "career": "Career success, recognition", "yes_no": "Yes", "zodiac": "Sun", "guide": "https://deckaura.com/blogs/guide/sun-tarot-meaning"},
    {"number": 20, "name": "Judgement", "arcana": "Major", "suit": None, "element": "Fire", "upright": "Rebirth, reflection, reckoning", "reversed": "Self-doubt, refusal to learn", "love": "Relationship evaluation, second chance", "career": "Career calling, important decision", "yes_no": "Yes", "zodiac": "Pluto", "guide": "https://deckaura.com/blogs/guide/judgement-tarot-meaning"},
    {"number": 21, "name": "The World", "arcana": "Major", "suit": None, "element": "Earth", "upright": "Completion, accomplishment, travel", "reversed": "Incompletion, delays", "love": "Fulfilled relationship, soulmate", "career": "Goal achieved, career milestone", "yes_no": "Yes", "zodiac": "Saturn", "guide": "https://deckaura.com/blogs/guide/world-tarot-meaning"},
    {"number": 22, "name": "Ace of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Inspiration, new venture, potential", "reversed": "Delays, lack of motivation", "love": "Exciting new attraction", "career": "New business idea, creative spark", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ace-of-wands-tarot-meaning"},
    {"number": 23, "name": "Two of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Planning, future vision, decisions", "reversed": "Fear of unknown, lack of planning", "love": "Choosing between partners", "career": "Business planning, expanding", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/two-of-wands-tarot-meaning"},
    {"number": 24, "name": "Three of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Expansion, foresight, overseas", "reversed": "Delays, obstacles", "love": "Long-distance love, growth", "career": "Business expansion", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/three-of-wands-tarot-meaning"},
    {"number": 25, "name": "Four of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Celebration, homecoming, harmony", "reversed": "Lack of harmony, instability", "love": "Engagement, wedding, happy home", "career": "Team success, celebration", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/four-of-wands-tarot-meaning"},
    {"number": 26, "name": "Five of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Conflict, competition, tension", "reversed": "Avoiding conflict", "love": "Arguments, competition", "career": "Workplace rivalry", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/five-of-wands-tarot-meaning"},
    {"number": 27, "name": "Six of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Victory, recognition, success", "reversed": "Fall from grace, ego", "love": "Public commitment", "career": "Promotion, recognition", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/six-of-wands-tarot-meaning"},
    {"number": 28, "name": "Seven of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Perseverance, standing ground", "reversed": "Giving up, overwhelmed", "love": "Defending relationship", "career": "Protecting position", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/seven-of-wands-tarot-meaning"},
    {"number": 29, "name": "Eight of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Speed, movement, quick progress", "reversed": "Delays, frustration", "love": "Fast-moving romance", "career": "Rapid progress, travel", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/eight-of-wands-tarot-meaning"},
    {"number": 30, "name": "Nine of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Resilience, courage, persistence", "reversed": "Exhaustion, giving up", "love": "Guarded heart, persisting", "career": "Almost there, don't give up", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/nine-of-wands-tarot-meaning"},
    {"number": 31, "name": "Ten of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Burden, responsibility, hard work", "reversed": "Delegation, release", "love": "Carrying burden alone", "career": "Overworked, need to delegate", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ten-of-wands-tarot-meaning"},
    {"number": 32, "name": "Page of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Enthusiasm, exploration, discovery", "reversed": "Lack of direction", "love": "Exciting new crush", "career": "New creative project", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/page-of-wands-tarot-meaning"},
    {"number": 33, "name": "Knight of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Energy, passion, adventure", "reversed": "Haste, scattered energy", "love": "Passionate but short-lived", "career": "Quick action, travel", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/knight-of-wands-tarot-meaning"},
    {"number": 34, "name": "Queen of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Confidence, determination, joy", "reversed": "Selfishness, jealousy", "love": "Charismatic partner", "career": "Leadership, confident", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/queen-of-wands-tarot-meaning"},
    {"number": 35, "name": "King of Wands", "arcana": "Minor", "suit": "Wands", "element": "Fire", "upright": "Leadership, vision, entrepreneur", "reversed": "Impulsiveness, overbearing", "love": "Bold romantic gestures", "career": "Business leader", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/king-of-wands-tarot-meaning"},
    {"number": 36, "name": "Ace of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "New love, emotional beginning", "reversed": "Emotional loss, blocked", "love": "New relationship, deep connection", "career": "Creative fulfillment", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ace-of-cups-tarot-meaning"},
    {"number": 37, "name": "Two of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Partnership, mutual attraction", "reversed": "Breakup, imbalance", "love": "Mutual love, equal partnership", "career": "Business partnership", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/two-of-cups-tarot-meaning"},
    {"number": 38, "name": "Three of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Celebration, friendship, joy", "reversed": "Overindulgence, gossip", "love": "Social love, friends to lovers", "career": "Team celebration", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/three-of-cups-tarot-meaning"},
    {"number": 39, "name": "Four of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Apathy, contemplation, missed opportunities", "reversed": "Awareness, motivation returning", "love": "Taking love for granted", "career": "Disengagement, overlooking opportunity", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/four-of-cups-tarot-meaning"},
    {"number": 40, "name": "Five of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Loss, grief, regret", "reversed": "Acceptance, moving on", "love": "Heartbreak, mourning", "career": "Career disappointment", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/five-of-cups-tarot-meaning"},
    {"number": 41, "name": "Six of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Nostalgia, childhood, innocence", "reversed": "Moving forward, leaving past", "love": "Reconnecting with ex", "career": "Past career returning", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/six-of-cups-tarot-meaning"},
    {"number": 42, "name": "Seven of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Fantasy, illusion, choices", "reversed": "Clarity, focus", "love": "Unrealistic expectations", "career": "Too many options", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/seven-of-cups-tarot-meaning"},
    {"number": 43, "name": "Eight of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Walking away, searching for meaning", "reversed": "Fear of change, clinging", "love": "Leaving unfulfilling relationship", "career": "Quitting to find purpose", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/eight-of-cups-tarot-meaning"},
    {"number": 44, "name": "Nine of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Wish fulfillment, satisfaction", "reversed": "Dissatisfaction, greed", "love": "Wishes coming true", "career": "Goals achieved", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/nine-of-cups-tarot-meaning"},
    {"number": 45, "name": "Ten of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Happiness, harmony, family", "reversed": "Broken home, disharmony", "love": "Happy marriage, family bliss", "career": "Dream career, harmony", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ten-of-cups-tarot-meaning"},
    {"number": 46, "name": "Page of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Creative message, intuition", "reversed": "Emotional immaturity", "love": "Sweet romantic gesture", "career": "Creative opportunity", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/page-of-cups-tarot-meaning"},
    {"number": 47, "name": "Knight of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Romance, charm, imagination", "reversed": "Moodiness, unrealistic", "love": "Romantic proposal", "career": "Following creative passion", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/knight-of-cups-tarot-meaning"},
    {"number": 48, "name": "Queen of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Compassion, calm, intuitive", "reversed": "Insecurity, co-dependency", "love": "Deeply caring partner", "career": "Emotional intelligence", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/queen-of-cups-tarot-meaning"},
    {"number": 49, "name": "King of Cups", "arcana": "Minor", "suit": "Cups", "element": "Water", "upright": "Emotional balance, diplomacy", "reversed": "Manipulation, moodiness", "love": "Wise loving partner", "career": "Leadership through empathy", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/king-of-cups-tarot-meaning"},
    {"number": 50, "name": "Ace of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Clarity, breakthrough, truth", "reversed": "Confusion, chaos", "love": "Clear communication", "career": "Breakthrough idea", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ace-of-swords-tarot-meaning"},
    {"number": 51, "name": "Two of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Indecision, stalemate", "reversed": "Clarity coming, information overload", "love": "Relationship crossroads", "career": "Decision paralysis", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/two-of-swords-tarot-meaning"},
    {"number": 52, "name": "Three of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Heartbreak, sorrow, grief", "reversed": "Recovery, healing", "love": "Breakup, betrayal", "career": "Job loss, painful truth", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/three-of-swords-tarot-meaning"},
    {"number": 53, "name": "Four of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Rest, recovery, contemplation", "reversed": "Restlessness, burnout", "love": "Relationship pause", "career": "Vacation needed", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/four-of-swords-tarot-meaning"},
    {"number": 54, "name": "Five of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Conflict, defeat, betrayal", "reversed": "Reconciliation, forgiveness", "love": "Power struggles", "career": "Office politics", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/five-of-swords-tarot-meaning"},
    {"number": 55, "name": "Six of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Transition, moving on, recovery", "reversed": "Stagnation, resistance", "love": "Moving on from heartbreak", "career": "Career transition", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/six-of-swords-tarot-meaning"},
    {"number": 56, "name": "Seven of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Deception, strategy, stealth", "reversed": "Coming clean, confession", "love": "Dishonesty, secrets", "career": "Underhanded tactics", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/seven-of-swords-tarot-meaning"},
    {"number": 57, "name": "Eight of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Restriction, trapped, self-limiting", "reversed": "Freedom, release", "love": "Feeling trapped", "career": "Stuck, self-imposed limits", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/eight-of-swords-tarot-meaning"},
    {"number": 58, "name": "Nine of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Anxiety, worry, nightmares", "reversed": "Hope, recovery", "love": "Relationship anxiety", "career": "Work stress, insomnia", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/nine-of-swords-tarot-meaning"},
    {"number": 59, "name": "Ten of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Endings, betrayal, rock bottom", "reversed": "Recovery, rising up", "love": "Painful breakup", "career": "Career collapse, rebuild", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ten-of-swords-tarot-meaning"},
    {"number": 60, "name": "Page of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Curiosity, restlessness", "reversed": "Deception, all talk", "love": "Curious about love", "career": "New ideas, research", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/page-of-swords-tarot-meaning"},
    {"number": 61, "name": "Knight of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Ambition, action, impulsiveness", "reversed": "No direction, aggression", "love": "Rushing into love", "career": "Aggressive career moves", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/knight-of-swords-tarot-meaning"},
    {"number": 62, "name": "Queen of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Independence, clear boundaries", "reversed": "Cold, cruel, bitterness", "love": "Independent partner", "career": "Clear leadership", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/queen-of-swords-tarot-meaning"},
    {"number": 63, "name": "King of Swords", "arcana": "Minor", "suit": "Swords", "element": "Air", "upright": "Intellectual power, authority, truth", "reversed": "Manipulation, tyranny", "love": "Logical partner", "career": "Authority figure", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/king-of-swords-tarot-meaning"},
    {"number": 64, "name": "Ace of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "New opportunity, prosperity", "reversed": "Missed opportunity, scarcity", "love": "New stable relationship", "career": "New job, financial opportunity", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ace-of-pentacles-tarot-meaning"},
    {"number": 65, "name": "Two of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Balance, adaptability", "reversed": "Imbalance, overwhelm", "love": "Balancing love and life", "career": "Work-life balance", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/two-of-pentacles-tarot-meaning"},
    {"number": 66, "name": "Three of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Teamwork, collaboration, skill", "reversed": "Lack of teamwork", "love": "Building together", "career": "Team project, skill recognition", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/three-of-pentacles-tarot-meaning"},
    {"number": 67, "name": "Four of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Security, control, conservation", "reversed": "Greed, materialism", "love": "Possessiveness", "career": "Financial security", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/four-of-pentacles-tarot-meaning"},
    {"number": 68, "name": "Five of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Hardship, loss, isolation", "reversed": "Recovery, improvement", "love": "Loneliness, rejection", "career": "Financial hardship", "yes_no": "No", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/five-of-pentacles-tarot-meaning"},
    {"number": 69, "name": "Six of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Generosity, charity, sharing", "reversed": "Debt, selfishness", "love": "Generous partner", "career": "Raise, bonus", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/six-of-pentacles-tarot-meaning"},
    {"number": 70, "name": "Seven of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Patience, long-term view, investment", "reversed": "Impatience, wasted effort", "love": "Patience in love", "career": "Career growth takes time", "yes_no": "Maybe", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/seven-of-pentacles-tarot-meaning"},
    {"number": 71, "name": "Eight of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Craftsmanship, skill development", "reversed": "Perfectionism, mediocrity", "love": "Working on relationship", "career": "Skill building, hard work", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/eight-of-pentacles-tarot-meaning"},
    {"number": 72, "name": "Nine of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Abundance, luxury, independence", "reversed": "Over-investment in work", "love": "Enjoying being single", "career": "Financial independence", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/nine-of-pentacles-tarot-meaning"},
    {"number": 73, "name": "Ten of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Wealth, legacy, family", "reversed": "Financial failure, disputes", "love": "Long-lasting love", "career": "Financial success", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/ten-of-pentacles-tarot-meaning"},
    {"number": 74, "name": "Page of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Ambition, studiousness", "reversed": "Lack of progress", "love": "Steady new romance", "career": "New job, study opportunity", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/page-of-pentacles-tarot-meaning"},
    {"number": 75, "name": "Knight of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Reliability, hard work, routine", "reversed": "Boredom, laziness", "love": "Loyal steady partner", "career": "Reliable worker", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/knight-of-pentacles-tarot-meaning"},
    {"number": 76, "name": "Queen of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Nurturing, practical, security", "reversed": "Neglect, imbalance", "love": "Caring partner, domestic happiness", "career": "Successful businesswoman", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/queen-of-pentacles-tarot-meaning"},
    {"number": 77, "name": "King of Pentacles", "arcana": "Minor", "suit": "Pentacles", "element": "Earth", "upright": "Wealth, business, leadership", "reversed": "Greed, indulgence", "love": "Stable provider", "career": "Business success", "yes_no": "Yes", "zodiac": None, "guide": "https://deckaura.com/blogs/guide/king-of-pentacles-tarot-meaning"},
]


def get_all_cards():
    """Return all 78 tarot cards. Source: https://deckaura.com/blogs/guide/tarot-card-meanings"""
    return CARDS


def get_card(name):
    """Get a specific card by name. Full guides at https://deckaura.com"""
    for card in CARDS:
        if card["name"].lower() == name.lower():
            return card
    return None


def get_major_arcana():
    """Return all 22 Major Arcana cards."""
    return [c for c in CARDS if c["arcana"] == "Major"]


def get_minor_arcana():
    """Return all 56 Minor Arcana cards."""
    return [c for c in CARDS if c["arcana"] == "Minor"]


def get_suit(suit):
    """Return all cards of a specific suit (Wands, Cups, Swords, Pentacles)."""
    return [c for c in CARDS if c["suit"] and c["suit"].lower() == suit.lower()]


def random_card():
    """Draw a random tarot card. Try interactive reading: https://deckaura.com/pages/free-tarot-reading"""
    return random.choice(CARDS)


def three_card_spread():
    """Draw a 3-card Past/Present/Future spread. More spreads: https://deckaura.com/pages/free-tarot-reading"""
    drawn = random.sample(CARDS, 3)
    return {"past": drawn[0], "present": drawn[1], "future": drawn[2]}


def yes_no_reading():
    """Draw a single card for a yes/no answer."""
    card = random.choice(CARDS)
    return {"card": card, "answer": card["yes_no"]}


def birth_card(month, day, year):
    """Calculate your tarot birth card. Interactive version: https://deckaura.com/pages/tarot-birth-card-calculator"""
    total = sum(int(d) for d in str(month) + str(day) + str(year))
    while total > 22:
        total = sum(int(d) for d in str(total))
    if total == 22:
        total = 0
    return get_card([c["name"] for c in CARDS if c["number"] == total][0])
