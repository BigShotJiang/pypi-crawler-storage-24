from setuptools import setup, find_packages

setup(
    name="tarot-card-meanings",
    version="1.0.0",
    author="Deckaura",
    author_email="info@deckaura.com",
    description="Complete 78 tarot card meanings with interpretations for Python",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://deckaura.com/blogs/guide/tarot-card-meanings",
    project_urls={
        "Free Tarot Reading": "https://deckaura.com/pages/free-tarot-reading",
        "Birth Card Calculator": "https://deckaura.com/pages/tarot-birth-card-calculator",
        "Numerology Calculator": "https://deckaura.com/pages/numerology-calculator",
        "Daily Tarot Card": "https://deckaura.com/pages/daily-tarot-card",
        "Oracle Cards Guide": "https://deckaura.com/blogs/guide/what-are-oracle-cards",
        "Source": "https://github.com/gokimedia/tarot-card-meanings-python",
    },
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Games/Entertainment",
        "Topic :: Other/Nonlisted Topic",
    ],
    python_requires=">=3.6",
    keywords="tarot cards meanings oracle divination numerology spirituality reading",
)
