#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
Important classes of Spark SQL and DataFrames:

    - :class:`pyspark.sql.SparkSession`
      Main entry point for :class:`DataFrame` and SQL functionality.
    - :class:`pyspark.sql.DataFrame`
      A distributed collection of data grouped into named columns.
    - :class:`pyspark.sql.Column`
      A column expression in a :class:`DataFrame`.
    - :class:`pyspark.sql.Row`
      A row of data in a :class:`DataFrame`.
    - :class:`pyspark.sql.GroupedData`
      Aggregation methods, returned by :func:`DataFrame.groupBy`.
    - :class:`pyspark.sql.DataFrameNaFunctions`
      Methods for handling missing data (null values).
    - :class:`pyspark.sql.DataFrameStatFunctions`
      Methods for statistics functionality.
    - :class:`pyspark.sql.functions`
      List of built-in functions available for :class:`DataFrame`.
    - :class:`pyspark.sql.types`
      List of data types available.
    - :class:`pyspark.sql.Window`
      For working with window functions.
"""
from pyspark.sql.types import Geography, Geometry, Row, VariantVal
from pyspark.sql.context import SQLContext, HiveContext, UDFRegistration, UDTFRegistration
from pyspark.sql.session import SparkSession
from pyspark.sql.column import Column
from pyspark.sql.catalog import Catalog
from pyspark.sql.dataframe import DataFrame, DataFrameNaFunctions, DataFrameStatFunctions
from pyspark.sql.group import GroupedData
from pyspark.sql.observation import Observation
from pyspark.sql.readwriter import DataFrameReader, DataFrameWriter, DataFrameWriterV2
from pyspark.sql.merge import MergeIntoWriter
from pyspark.sql.udf_log_collector import UDFLogs
from pyspark.sql.window import Window, WindowSpec
from pyspark.sql.pandas.group_ops import PandasCogroupedOps
from pyspark.util import is_remote_only
from pyspark.sql.utils import is_remote
from pyspark.sql.udf import _create_arrow_udf
from pyspark.sql.plot import PySparkPlotAccessor

__all__ = [
    "SparkSession",
    "SQLContext",
    "HiveContext",
    "UDFRegistration",
    "UDTFRegistration",
    "DataFrame",
    "GroupedData",
    "Column",
    "Catalog",
    "Observation",
    "Row",
    "DataFrameNaFunctions",
    "DataFrameStatFunctions",
    "VariantVal",
    "Geography",
    "Geometry",
    "Window",
    "WindowSpec",
    "DataFrameReader",
    "DataFrameWriter",
    "DataFrameWriterV2",
    "MergeIntoWriter",
    "PandasCogroupedOps",
    "is_remote",
]

# BEGIN-EDGE
from pyspark.databricks.instrumentation.instrumentation_utils import _instrument_after_spark_context_init

_class_deny_list = [
    # Due to performance reason, we should not instrument Row class.
    Row,
]
_class_allow_list = [
    SparkSession,
    SQLContext,
    HiveContext,
    UDFRegistration,
    GroupedData,
    Catalog,
    Observation,
    DataFrameNaFunctions,
    DataFrameStatFunctions,
    Window,
    WindowSpec,
    DataFrameReader,
    DataFrameWriter,
    PandasCogroupedOps,
    PySparkPlotAccessor,
    UDFLogs,
]

_class_property_allow_list = []

if not is_remote_only():
    from pyspark.sql.classic.dataframe import DataFrame as ClassicDataFrame
    from pyspark.sql.classic.column import Column as ClassicColumn

    _class_allow_list.append(ClassicDataFrame)
    _class_property_allow_list.append(ClassicDataFrame.rdd)

    _class_allow_list.append(ClassicColumn)


_private_function_allow_list = [
    _create_arrow_udf,
]

assert len(set(_class_deny_list) & set(_class_allow_list)) == 0

def _get_extended_instrumentation_config():
    from pyspark.databricks.instrumentation.instrumentation_utils import _ExtendedInstrumentationConfig
    from pyspark.sql.conf import RuntimeConfig
    from pyspark.sql.udf import UserDefinedFunction
    from pyspark.sql.udtf import UserDefinedTableFunction
    from pyspark.sql.tvf import TableValuedFunction
    from pyspark.sql.table_arg import TableArg
    from pyspark.sql.streaming.readwriter import DataStreamReader, DataStreamWriter
    from pyspark.sql.streaming.query import StreamingQuery, StreamingQueryManager
    from pyspark.sql.streaming.listener import StreamingQueryListener
    from pyspark.sql.datasource import (
        DataSource,
        DataSourceReader,
        DataSourceStreamReader,
        DataSourceWriter,
        DataSourceRegistration,
    )
    from pyspark.sql.connect.catalog import Catalog as ConnectCatalog
    from pyspark.sql.connect.column import Column as ConnectColumn
    from pyspark.sql.connect.conf import RuntimeConf as ConnectRuntimeConf
    from pyspark.sql.connect.dataframe import (
        DataFrame as ConnectDataFrame,
        DataFrameNaFunctions as ConnectDataFrameNaFunctions,
        DataFrameStatFunctions as ConnectDataFrameStatFunctions,
    )
    from pyspark.sql.connect.group import (
        GroupedData as ConnectGroupedData,
        PandasCogroupedOps as ConnectPandasCogroupedOps,
    )
    from pyspark.sql.connect.merge import MergeIntoWriter as ConnectMergeIntoWriter
    from pyspark.sql.connect.observation import Observation as ConnectObservation
    from pyspark.sql.connect.readwriter import (
        DataFrameReader as ConnectDataFrameReader,
        DataFrameWriter as ConnectDataFrameWriter,
        DataFrameWriterV2 as ConnectDataFrameWriterV2,
    )
    from pyspark.sql.connect.streaming.readwriter import (
        DataStreamReader as ConnectDataStreamReader,
        DataStreamWriter as ConnectDataStreamWriter,
    )
    from pyspark.sql.connect.udf import (
        UDFRegistration as ConnectUDFRegistration,
        UserDefinedFunction as ConnectUserDefinedFunction,
    )
    from pyspark.sql.connect.udtf import (
        UDTFRegistration as ConnectUDTFRegistration,
        UserDefinedTableFunction as ConnectUserDefinedTableFunction,
    )
    from pyspark.sql.connect.window import (
        Window as ConnectWindow,
        WindowSpec as ConnectWindowSpec,
    )
    from pyspark.sql.classic.dataframe import DataFrame as ClassicDataFrame
    from pyspark.sql.classic.column import Column as ClassicColumn

    return _ExtendedInstrumentationConfig(
        classes=[
            # Classic Spark
            HiveContext,
            Catalog,
            ClassicColumn,
            ClassicDataFrame,
            DataFrameNaFunctions,
            DataFrameReader,
            DataFrameStatFunctions,
            DataFrameWriter,
            DataFrameWriterV2,
            GroupedData,
            MergeIntoWriter,
            Observation,
            PandasCogroupedOps,
            SparkSession,
            SQLContext,
            UDFLogs,
            UDFRegistration,
            UDTFRegistration,
            Window,
            WindowSpec,
            RuntimeConfig,
            DataSource,
            DataSourceReader,
            DataSourceRegistration,
            DataSourceStreamReader,
            DataSourceWriter,
            PySparkPlotAccessor,
            DataStreamReader,
            DataStreamWriter,
            StreamingQuery,
            StreamingQueryListener,
            StreamingQueryManager,
            TableArg,
            TableValuedFunction,
            UserDefinedFunction,
            UserDefinedTableFunction,
            # Spark Connect
            ConnectCatalog,
            ConnectColumn,
            ConnectRuntimeConf,
            ConnectDataFrame,
            ConnectDataFrameNaFunctions,
            ConnectDataFrameStatFunctions,
            ConnectGroupedData,
            ConnectPandasCogroupedOps,
            ConnectMergeIntoWriter,
            ConnectObservation,
            ConnectDataFrameReader,
            ConnectDataFrameWriter,
            ConnectDataFrameWriterV2,
            ConnectDataStreamReader,
            ConnectDataStreamWriter,
            ConnectUDFRegistration,
            ConnectUserDefinedFunction,
            ConnectUDTFRegistration,
            ConnectUserDefinedTableFunction,
            ConnectWindow,
            ConnectWindowSpec,
        ],
        instance_var_allow_list=[
            (Catalog, "_jsparkSession"),
            (Catalog, "_jcatalog"),
            (Catalog, "_sc"),
            (ClassicColumn, "_jc"),
            (ClassicDataFrame, "_jdf"),
            (ClassicDataFrame, "_sc"),
            (DataFrameReader, "_jreader"),
            (DataFrameWriter, "_jwrite"),
            (DataFrameWriterV2, "_jwriter"),
            (GroupedData, "_jgd"),
            (MergeIntoWriter, "_jwriter"),
            (Observation, "_jvm"),
            (Observation, "_jo"),
            (SparkSession, "_jsc"),
            (SparkSession, "_jvm"),
            (SparkSession, "_jsparkSession"),
            (SparkSession, "_sc"),
            (SQLContext, "_jsc"),
            (SQLContext, "_jvm"),
            (SQLContext, "_jsqlContext"),
            (SQLContext, "_sc"),
            (WindowSpec, "_jspec"),
            (RuntimeConfig, "_jconf"),
            (DataStreamReader, "_jreader"),
            (DataStreamWriter, "_jwrite"),
            (StreamingQuery, "_jsq"),
            (StreamingQueryManager, "_jsqm"),
        ],
    )

_instrument_after_spark_context_init(
    [],
    _class_allow_list,
    _class_property_allow_list,
    _private_function_allow_list,
    lazy_extended_config_loader=_get_extended_instrumentation_config,
)
# END-EDGE
