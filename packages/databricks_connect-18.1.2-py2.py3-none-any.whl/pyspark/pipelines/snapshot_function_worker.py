#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
A worker for SDP apply_changes_from_snapshot lambda source functions in Spark Connect.
This runs on the driver side of the Spark Connect Server.

Protocol:
- Initialization: Receives pickled function, sets up Spark Connect session
- Loop:
  - Receives: has_last_version (int), [last_version_json (UTF) if has_last_version]
  - Executes user function with last_version
  - Sends back:
    - If None: result_type=RESULT_NONE (0)
    - If (df, version): result_type=RESULT_HAS_VALUE (1), plan_bytes_len, plan_bytes, version_json
    - If error: result_type=RESULT_EXECUTION_ERROR (-1), error_msg (UTF)
    - If init error: result_type=RESULT_INIT_ERROR (-2), error_msg (UTF)
"""
import datetime
import decimal
import importlib
import os
import traceback
from contextlib import contextmanager
from typing import Any, Generator, IO, Optional, Union, cast

from pyspark.util import local_connect_and_auth
from pyspark.serializers import (
    write_int,
    read_int,
    UTF8Deserializer,
    CPickleSerializer,
)
from pyspark import worker
from pyspark._engine_adapters import IS_ENGINE_PYSPARK
if IS_ENGINE_PYSPARK:
    from pyspark._engine_adapters import client_pyspark_sql_connect_session
    SparkSession = client_pyspark_sql_connect_session.SparkSession
else:
    from pyspark.sql.connect.session import SparkSession
from pyspark.worker_util import check_python_version, setup_broadcasts, setup_spark_files

from databricks.connect.uds_channel_builder import UDSChannelBuilder

# Use client image's pyspark for protobuf serialization, not _engine_pyspark.
# This matches the pattern used by client_pyspark_sql_connect_session in _engine_adapters.py,
# which also imports from "pyspark" to maintain type compatibility with the client environment.
#
# Why dynamic import ("py" + "spark"):
# - create_engine_pyspark.sh uses sed to replace "pyspark" → "_engine_pyspark" in all .py files
# - By constructing the string at runtime, sed patterns don't match it
# - This ensures both normal and isolation modes use the same "pyspark" namespace
# - Avoids protobuf descriptor pool conflicts (same namespace = no duplicate registrations)
_base_pkg = "py" + "spark"  # Constructs "pyspark" at runtime, sed won't match this
LiteralExpression = importlib.import_module(f"{_base_pkg}.sql.connect.expressions").LiteralExpression
expressions_pb2 = importlib.import_module(f"{_base_pkg}.sql.connect.proto.expressions_pb2")

pickle_ser = CPickleSerializer()
utf8_deserializer = UTF8Deserializer()

# Result type codes for communication with Scala.
# Must match values in PipelinesCallbackHelper.SnapshotFunctionResultType
RESULT_NONE = 0              # Function returned None
RESULT_HAS_VALUE = 1         # Function returned (DataFrame, version)
RESULT_EXECUTION_ERROR = -1  # Error during function execution
RESULT_INIT_ERROR = -2       # Error during worker initialization


# Supported snapshot version types (must match SnapshotVersion type alias in flow.py)
SnapshotVersion = Union[
    int, str, float, bytes,
    datetime.datetime, datetime.date, decimal.Decimal,
]


def serialize_version(version: SnapshotVersion, spark) -> bytes:
    """
    Serialize a snapshot version to protobuf bytes using Spark Connect's
    LiteralExpression converter which automatically infers the type.

    This uses the same protobuf infrastructure as Spark Connect for type conversion,
    matching the semantics of the Py4J-based ACFS implementation.
    """
    lit_expr = LiteralExpression._from_value(version)  # Auto-infers type!
    literal_proto = lit_expr.to_plan(spark._client).literal
    return literal_proto.SerializeToString()


def deserialize_version(proto_bytes: bytes) -> SnapshotVersion:
    """
    Deserialize a snapshot version from protobuf bytes using Spark Connect's
    LiteralExpression converter which automatically converts proto to Python values.
    """
    literal_proto = expressions_pb2.Expression.Literal()
    literal_proto.ParseFromString(proto_bytes)
    return LiteralExpression._to_value(literal_proto)


def write_utf(s: str, stream: IO) -> None:
    """Write a UTF-8 encoded string to the stream (length-prefixed)."""
    data = s.encode("utf-8")
    write_int(len(data), stream)
    stream.write(data)


spark = None


def main(infile: IO, outfile: IO) -> None:
    global spark

    log_name = "SDP Snapshot Function worker"

    def get_spark_session(connect_url, session_id, credentials_key):
        """Create a Spark Connect session."""
        spark_connect_url = connect_url + ";session_id=" + session_id
        builder = UDSChannelBuilder(spark_connect_url)
        builder.set("x-databricks-local-credentials-key", credentials_key)
        builder.set("session_id", session_id)
        session_builder = SparkSession.builder.channelBuilder(builder)
        session = session_builder.getOrCreate()
        assert session.session_id == session_id
        return session

    try:
        check_python_version(infile)

        # Enable Spark Connect Mode
        os.environ["SPARK_CONNECT_MODE_ENABLED"] = "1"

        connect_url = os.environ["SPARK_CONNECT_LOCAL_URL"]
        session_id = utf8_deserializer.loads(infile)
        credentials_key = utf8_deserializer.loads(infile)

        print(f"{log_name} starting with url {connect_url} and sessionId {session_id}.")

        # Set up the Spark Connect session
        spark = get_spark_session(connect_url, session_id, credentials_key)
        print(f"{log_name} connected to session {session_id}.")

        setup_spark_files(infile)
        setup_broadcasts(infile)

        # Read the pickled snapshot function
        func = worker.read_command(pickle_ser, infile)
        print(f"{log_name} loaded snapshot function.")

        # Signal initialization complete
        write_int(0, outfile)
        outfile.flush()

        # Main loop: process snapshot requests
        while True:
            # Read whether there's a last_version
            has_last_version = read_int(infile)

            if has_last_version == 1:
                # Read the protobuf-serialized last version value
                version_bytes_len = read_int(infile)
                version_bytes = infile.read(version_bytes_len)
                last_version = deserialize_version(version_bytes)
            else:
                last_version = None

            print(f"{log_name} received request with last_version={last_version}")

            try:
                result = func(last_version)

                if result is None:
                    # Return None indicator
                    write_int(RESULT_NONE, outfile)
                    print(f"{log_name} function returned None")
                else:
                    # Validate result is (DataFrame, version) tuple or [DataFrame, version] list
                    if not isinstance(result, (tuple, list)) or len(result) != 2:
                        raise ValueError(
                            f"Snapshot function must return (DataFrame, version) tuple/list or None, "
                            f"got {type(result)}"
                        )

                    df, version = result

                    # Serialize the DataFrame's logical plan to proto bytes
                    plan_proto = df._plan.to_proto(spark._client)
                    plan_bytes = plan_proto.root.SerializeToString()

                    # Serialize the version to protobuf bytes
                    version_bytes = serialize_version(version, spark)

                    # Send result: plan_bytes + version_bytes
                    write_int(RESULT_HAS_VALUE, outfile)
                    write_int(len(plan_bytes), outfile)
                    outfile.write(plan_bytes)
                    write_int(len(version_bytes), outfile)
                    outfile.write(version_bytes)

                    print(f"{log_name} sent result with version={version} (type={type(version).__name__}), "
                          f"plan_bytes_len={len(plan_bytes)}, version_bytes_len={len(version_bytes)}")

                outfile.flush()

            except Exception as e:
                # Send error
                error_msg = f"{str(e)}\n{traceback.format_exc()}"
                write_int(RESULT_EXECUTION_ERROR, outfile)
                write_utf(error_msg, outfile)
                outfile.flush()
                print(f"{log_name} error: {error_msg}")

    except Exception as e:
        # Fatal error during initialization
        try:
            error_msg = f"Initialization error: {str(e)}\n{traceback.format_exc()}"
            write_int(RESULT_INIT_ERROR, outfile)
            write_utf(error_msg, outfile)
            outfile.flush()
        except:
            pass
        raise


if __name__ == "__main__":
    # Read information about how to connect back to the JVM from the environment.
    conn_info = os.environ.get(
        "PYTHON_WORKER_FACTORY_SOCK_PATH",
        int(os.environ.get("PYTHON_WORKER_FACTORY_PORT", -1))
    )
    auth_secret = os.environ.get("PYTHON_WORKER_FACTORY_SECRET")
    (sock_file, sock) = local_connect_and_auth(conn_info, auth_secret)
    # No timeout - there can be long gaps between snapshot calls
    sock.settimeout(None)
    write_int(os.getpid(), sock_file)
    sock_file.flush()
    main(sock_file, sock_file)

