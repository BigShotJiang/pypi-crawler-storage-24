#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2026-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#
import sys
from typing import TYPE_CHECKING

from pyspark import SparkContext
from pyspark.sql.column import Column
from pyspark.sql.classic.column import _to_java_column
from pyspark.sql.utils import try_remote_edge_functions

if TYPE_CHECKING:
    from pyspark.sql._typing import ColumnOrName


###################################################################################################
# Python INET functions
###################################################################################################
@try_remote_edge_functions
def ip_host(ip: "ColumnOrName") -> Column:
    """Returns the canonical representation of an IPv4 or IPv6 address.

    Raises an error if the input is not a valid IP address.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Validate an IPv4 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5',)], ['ipv4'])
    >>> df.select(dbf.ip_host('ipv4').alias('result')).collect()
    [Row(result='192.168.1.5')]

    Example 2: Canonicalize an IPv6 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:0DB8:0000:0000:0000:0000:0000:0001',)], ['ipv6'])
    >>> df.select(dbf.ip_host('ipv6').alias('result')).collect()
    [Row(result='2001:db8::1')]

    Example 3: Validate an IPv4-mapped IPv6 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('::ffff:192.0.2.128',)], ['ip'])
    >>> df.select(dbf.ip_host('ip').alias('result')).collect()
    [Row(result='::ffff:192.0.2.128')]

    Example 4: Validate an IPv4 address in binary format.
    >>> # In the following example the input is the binary representation of the IPv4 address 192.168.1.5
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([(bytearray([0xC0, 0xA8, 0x01, 0x05]),)], ['ip'])
    >>> df.select(hex(dbf.ip_host('ip')).alias('result')).collect()
    [Row(result='C0A80105')]

    Example 5: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.ip_host('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_host(_to_java_column(ip))
    return Column(jc)


@try_remote_edge_functions
def ip_cidr(cidr: "ColumnOrName") -> Column:
    """Returns the canonical representation of an IPv4 or IPv6 CIDR block.

    Raises an error if the input is not a valid CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Canonicalize an IPv4 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(dbf.ip_cidr('cidr').alias('result')).collect()
    [Row(result='192.168.1.0/24')]

    Example 2: Canonicalize an IPv6 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1/64',)], ['cidr'])
    >>> df.select(dbf.ip_cidr('cidr').alias('result')).collect()
    [Row(result='2001:db8::/64')]

    Example 3: Canonicalize a CIDR block in binary format.
    >>> # In the following example the input is the binary representation of 192.168.1.5/24
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([(bytearray([0xC0, 0xA8, 0x01, 0x05, 0x18]),)], ['cidr'])
    >>> df.select(hex(dbf.ip_cidr('cidr')).alias('result')).collect()
    [Row(result='C0A8010018')]

    Example 4: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'cidr: string')
    >>> df.select(dbf.ip_cidr('cidr').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_cidr(_to_java_column(cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_prefix_length(cidr: "ColumnOrName") -> Column:
    """Returns the prefix length of an IPv4 or IPv6 CIDR block.

    Raises an error if the input is not a valid CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Get prefix length from IPv4 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.0/24',)], ['cidr'])
    >>> df.select(dbf.ip_prefix_length('cidr').alias('result')).collect()
    [Row(result=24)]

    Example 2: Get prefix length from IPv6 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1/64',)], ['cidr'])
    >>> df.select(dbf.ip_prefix_length('cidr').alias('result')).collect()
    [Row(result=64)]

    Example 3: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'cidr: string')
    >>> df.select(dbf.ip_prefix_length('cidr').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_prefix_length(_to_java_column(cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_network(cidr: "ColumnOrName") -> Column:
    """Returns the network portion of an IPv4 or IPv6 CIDR block in its canonical form.

    Raises an error if the input is not a valid CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Get network address from IPv4 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(dbf.ip_network('cidr').alias('result')).collect()
    [Row(result='192.168.1.0')]

    Example 2: Get network address from IPv6 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1/32',)], ['cidr'])
    >>> df.select(dbf.ip_network('cidr').alias('result')).collect()
    [Row(result='2001:db8::')]

    Example 3: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'cidr: string')
    >>> df.select(dbf.ip_network('cidr').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_network(_to_java_column(cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_network_first(cidr: "ColumnOrName") -> Column:
    """Returns the network portion of an IPv4 or IPv6 CIDR block in its canonical form.

    Raises an error if the input is not a valid CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Get first address from IPv4 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(dbf.ip_network_first('cidr').alias('result')).collect()
    [Row(result='192.168.1.0')]

    Example 2: Get first address from IPv6 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1/32',)], ['cidr'])
    >>> df.select(dbf.ip_network_first('cidr').alias('result')).collect()
    [Row(result='2001:db8::')]

    Example 3: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'cidr: string')
    >>> df.select(dbf.ip_network_first('cidr').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_network_first(_to_java_column(cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_network_last(cidr: "ColumnOrName") -> Column:
    """Returns the last address of an IPv4 or IPv6 CIDR block in its canonical form.

    Raises an error if the input is not a valid CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Get last address from IPv4 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.0/24',)], ['cidr'])
    >>> df.select(dbf.ip_network_last('cidr').alias('result')).collect()
    [Row(result='192.168.1.255')]

    Example 2: Get last address from IPv6 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::/32',)], ['cidr'])
    >>> df.select(dbf.ip_network_last('cidr').alias('result')).collect()
    [Row(result='2001:db8:ffff:ffff:ffff:ffff:ffff:ffff')]

    Example 3: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'cidr: string')
    >>> df.select(dbf.ip_network_last('cidr').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_network_last(_to_java_column(cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_version(ip_or_cidr: "ColumnOrName") -> Column:
    """Returns the IP version (4 or 6) from an IPv4 or IPv6 address or CIDR block.

    Raises an error if the input is not a valid IP address or CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip_or_cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address or CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Get version from IPv4 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5',)], ['ip'])
    >>> df.select(dbf.ip_version('ip').alias('result')).collect()
    [Row(result=4)]

    Example 2: Get version from IPv6 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1',)], ['ip'])
    >>> df.select(dbf.ip_version('ip').alias('result')).collect()
    [Row(result=6)]

    Example 3: Get version from CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.0/24',)], ['cidr'])
    >>> df.select(dbf.ip_version('cidr').alias('result')).collect()
    [Row(result=4)]

    Example 4: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.ip_version('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_version(_to_java_column(ip_or_cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_as_string(ip_or_cidr: "ColumnOrName") -> Column:
    """Returns the canonical string representation of an IP address or CIDR block.

    Raises an error if the input is not a valid IP address or CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip_or_cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address or CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Convert IPv4 address to string.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.1',)], ['ip'])
    >>> df.select(dbf.ip_as_string('ip').alias('result')).collect()
    [Row(result='192.168.1.1')]

    Example 2: Convert IPv6 address to string.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1',)], ['ip'])
    >>> df.select(dbf.ip_as_string('ip').alias('result')).collect()
    [Row(result='2001:db8::1')]

    Example 3: Convert CIDR block to string.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(dbf.ip_as_string('cidr').alias('result')).collect()
    [Row(result='192.168.1.0/24')]

    Example 4: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.ip_as_string('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_as_string(_to_java_column(ip_or_cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_as_binary(ip_or_cidr: "ColumnOrName") -> Column:
    """Returns the canonical binary representation of an IP address or CIDR block.

    Raises an error if the input is not a valid IP address or CIDR block.
    Returns None when the input is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip_or_cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address or CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Convert IPv4 address to binary.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([('192.168.1.1',)], ['ip'])
    >>> df.select(hex(dbf.ip_as_binary('ip')).alias('result')).collect()
    [Row(result='C0A80101')]

    Example 2: Convert IPv6 address to binary.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([('2001:db8::1',)], ['ip'])
    >>> df.select(hex(dbf.ip_as_binary('ip')).alias('result')).collect()
    [Row(result='20010DB8000000000000000000000001')]

    Example 3: Convert CIDR block to binary.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(hex(dbf.ip_as_binary('cidr')).alias('result')).collect()
    [Row(result='C0A8010018')]

    Example 4: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.ip_as_binary('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_as_binary(_to_java_column(ip_or_cidr))
    return Column(jc)


@try_remote_edge_functions
def ip_cidr_contains(cidr: "ColumnOrName", needle: "ColumnOrName") -> Column:
    """Returns TRUE if an IP address or CIDR block (needle) is contained within another CIDR block.

    Raises an error if either input is invalid.
    Returns None if either argument is None.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.
    needle : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address or CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Check if IP address is contained in CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.0/24', '192.168.1.100')], ['cidr', 'ip'])
    >>> df.select(dbf.ip_cidr_contains('cidr', 'ip').alias('result')).collect()
    [Row(result=True)]

    Example 2: Check if smaller CIDR block is contained in larger CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.0.0/16', '192.168.1.0/24')], ['cidr', 'needle'])
    >>> df.select(dbf.ip_cidr_contains('cidr', 'needle').alias('result')).collect()
    [Row(result=True)]

    Example 3: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None, '192.168.1.1')], 'cidr: string, ip: string')
    >>> df.select(dbf.ip_cidr_contains('cidr', 'ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.ip_cidr_contains(
        _to_java_column(cidr), _to_java_column(needle))
    return Column(jc)


@try_remote_edge_functions
def try_ip_host(ip: "ColumnOrName") -> Column:
    """Returns the canonical representation of an IPv4 or IPv6 address.

    Returns None when the input is None or invalid.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Validate an IPv4 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5',)], ['ip'])
    >>> df.select(dbf.try_ip_host('ip').alias('result')).collect()
    [Row(result='192.168.1.5')]

    Example 2: Canonicalize an IPv6 address.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:0db8::1',)], ['ip'])
    >>> df.select(dbf.try_ip_host('ip').alias('result')).collect()
    [Row(result='2001:db8::1')]

    Example 3: Invalid input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('invalid.ip',)], ['ip'])
    >>> df.select(dbf.try_ip_host('ip').alias('result')).collect()
    [Row(result=None)]

    Example 4: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.try_ip_host('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.try_ip_host(_to_java_column(ip))
    return Column(jc)


@try_remote_edge_functions
def try_ip_cidr(cidr: "ColumnOrName") -> Column:
    """Returns the canonical representation of an IPv4 or IPv6 CIDR block.

    Returns None when the input is None or invalid.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Canonicalize an IPv4 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(dbf.try_ip_cidr('cidr').alias('result')).collect()
    [Row(result='192.168.1.0/24')]

    Example 2: Canonicalize an IPv6 CIDR block.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1/64',)], ['cidr'])
    >>> df.select(dbf.try_ip_cidr('cidr').alias('result')).collect()
    [Row(result='2001:db8::/64')]

    Example 3: Invalid input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('invalid.ip/24',)], ['cidr'])
    >>> df.select(dbf.try_ip_cidr('cidr').alias('result')).collect()
    [Row(result=None)]

    Example 4: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'cidr: string')
    >>> df.select(dbf.try_ip_cidr('cidr').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.try_ip_cidr(_to_java_column(cidr))
    return Column(jc)


@try_remote_edge_functions
def try_ip_as_string(ip_or_cidr: "ColumnOrName") -> Column:
    """Returns the canonical string representation of an IP address or CIDR block.

    Returns None when the input is None or invalid.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip_or_cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address or CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Convert IPv4 address to string.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.1',)], ['ip'])
    >>> df.select(dbf.try_ip_as_string('ip').alias('result')).collect()
    [Row(result='192.168.1.1')]

    Example 2: Convert IPv6 address to string.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('2001:db8::1',)], ['ip'])
    >>> df.select(dbf.try_ip_as_string('ip').alias('result')).collect()
    [Row(result='2001:db8::1')]

    Example 3: Convert CIDR block to string.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(dbf.try_ip_as_string('cidr').alias('result')).collect()
    [Row(result='192.168.1.0/24')]

    Example 4: Invalid input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('invalid.ip',)], ['ip'])
    >>> df.select(dbf.try_ip_as_string('ip').alias('result')).collect()
    [Row(result=None)]

    Example 5: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.try_ip_as_string('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.try_ip_as_string(_to_java_column(ip_or_cidr))
    return Column(jc)


@try_remote_edge_functions
def try_ip_as_binary(ip_or_cidr: "ColumnOrName") -> Column:
    """Returns the canonical binary representation of an IP address or CIDR block.

    Returns None when the input is None or invalid.

    .. versionadded:: 4.2.0

    Parameters
    ----------
    ip_or_cidr : :class:`~pyspark.sql.Column` or str
        A STRING or BINARY value representing a valid IPv4 or IPv6 address or CIDR block.

    Notes
    -----
    This is an EDGE feature that is only supported in DBR.

    Examples
    --------
    Example 1: Convert IPv4 address to binary.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([('192.168.1.1',)], ['ip'])
    >>> df.select(hex(dbf.try_ip_as_binary('ip')).alias('result')).collect()
    [Row(result='C0A80101')]

    Example 2: Convert IPv6 address to binary.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([('2001:db8::1',)], ['ip'])
    >>> df.select(hex(dbf.try_ip_as_binary('ip')).alias('result')).collect()
    [Row(result='20010DB8000000000000000000000001')]

    Example 3: Convert CIDR block to binary.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> from pyspark.sql.functions import hex
    >>> df = spark.createDataFrame([('192.168.1.5/24',)], ['cidr'])
    >>> df.select(hex(dbf.try_ip_as_binary('cidr')).alias('result')).collect()
    [Row(result='C0A8010018')]

    Example 4: Invalid input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([('invalid.ip',)], ['ip'])
    >>> df.select(dbf.try_ip_as_binary('ip').alias('result')).collect()
    [Row(result=None)]

    Example 5: None input returns None.
    >>> from pyspark.databricks.sql import functions as dbf
    >>> df = spark.createDataFrame([(None,)], 'ip: string')
    >>> df.select(dbf.try_ip_as_binary('ip').alias('result')).collect()
    [Row(result=None)]
    """
    sc = SparkContext._active_spark_context
    assert sc is not None and sc._jvm is not None
    jc = sc._jvm.com.databricks.sql.functions.try_ip_as_binary(_to_java_column(ip_or_cidr))
    return Column(jc)


def _test() -> None:
    import doctest
    from pyspark.sql import SparkSession
    import pyspark.databricks.sql.inet_functions

    globs = pyspark.databricks.sql.inet_functions.__dict__.copy()
    spark = (
        SparkSession.builder.master("local[4]")
        .appName("databricks.sql.inet_functions tests")
        .getOrCreate()
    )
    sc = spark.sparkContext
    globs["sc"] = sc
    globs["spark"] = spark
    (failure_count, test_count) = doctest.testmod(
        pyspark.databricks.sql.inet_functions,
        globs=globs,
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE,
    )
    spark.stop()
    if failure_count:
        sys.exit(-1)


if __name__ == "__main__":
    _test()
