#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2026-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#
from typing import TYPE_CHECKING

from pyspark.databricks.sql import inet_functions as pyspark_db_inet_funcs

from pyspark.sql.connect.functions.builtin import _invoke_function_over_columns


if TYPE_CHECKING:
    from pyspark.sql.connect._typing import ColumnOrName
    from pyspark.sql.connect.column import Column


def ip_host(ip: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_host", ip)


ip_host.__doc__ = pyspark_db_inet_funcs.ip_host.__doc__


def ip_cidr(cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_cidr", cidr)


ip_cidr.__doc__ = pyspark_db_inet_funcs.ip_cidr.__doc__


def ip_prefix_length(cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_prefix_length", cidr)


ip_prefix_length.__doc__ = pyspark_db_inet_funcs.ip_prefix_length.__doc__


def ip_network(cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_network", cidr)


ip_network.__doc__ = pyspark_db_inet_funcs.ip_network.__doc__


def ip_network_first(cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_network_first", cidr)


ip_network_first.__doc__ = pyspark_db_inet_funcs.ip_network_first.__doc__


def ip_network_last(cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_network_last", cidr)


ip_network_last.__doc__ = pyspark_db_inet_funcs.ip_network_last.__doc__


def ip_version(ip_or_cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_version", ip_or_cidr)


ip_version.__doc__ = pyspark_db_inet_funcs.ip_version.__doc__


def ip_as_string(ip_or_cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_as_string", ip_or_cidr)


ip_as_string.__doc__ = pyspark_db_inet_funcs.ip_as_string.__doc__


def ip_as_binary(ip_or_cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_as_binary", ip_or_cidr)


ip_as_binary.__doc__ = pyspark_db_inet_funcs.ip_as_binary.__doc__


def ip_cidr_contains(cidr: "ColumnOrName", needle: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("ip_cidr_contains", cidr, needle)


ip_cidr_contains.__doc__ = pyspark_db_inet_funcs.ip_cidr_contains.__doc__


def try_ip_host(ip: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("try_ip_host", ip)


try_ip_host.__doc__ = pyspark_db_inet_funcs.try_ip_host.__doc__


def try_ip_cidr(cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("try_ip_cidr", cidr)


try_ip_cidr.__doc__ = pyspark_db_inet_funcs.try_ip_cidr.__doc__


def try_ip_as_string(ip_or_cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("try_ip_as_string", ip_or_cidr)


try_ip_as_string.__doc__ = pyspark_db_inet_funcs.try_ip_as_string.__doc__


def try_ip_as_binary(ip_or_cidr: "ColumnOrName") -> "Column":
    return _invoke_function_over_columns("try_ip_as_binary", ip_or_cidr)


try_ip_as_binary.__doc__ = pyspark_db_inet_funcs.try_ip_as_binary.__doc__


def _test() -> None:
    import sys
    import doctest
    from pyspark.sql import SparkSession as PySparkSession
    import pyspark.databricks.sql.connect.inet_functions

    globs = pyspark.databricks.sql.connect.inet_functions.__dict__.copy()

    globs["spark"] = (
        PySparkSession.builder.appName("databricks.sql.connect.inet_functions tests")
        .remote("local[4]")
        .getOrCreate()
    )

    (failure_count, test_count) = doctest.testmod(
        pyspark.databricks.sql.connect.inet_functions,
        globs=globs,
        optionflags=doctest.ELLIPSIS
        | doctest.NORMALIZE_WHITESPACE
        | doctest.IGNORE_EXCEPTION_DETAIL,
    )

    globs["spark"].stop()

    if failure_count:
        sys.exit(-1)


if __name__ == "__main__":
    _test()
