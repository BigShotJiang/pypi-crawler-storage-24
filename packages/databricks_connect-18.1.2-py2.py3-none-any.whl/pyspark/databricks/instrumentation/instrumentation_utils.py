# -*- coding: utf-8 -*-
#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import functools
import inspect
import threading
import time
from inspect import Signature
from types import ModuleType, FunctionType
from typing import Optional, Tuple, List, Callable, Any, Type, Dict, Union, Iterator, Iterable
from pyspark.databricks.usage_logger import UsageLogger
from pyspark.taskcontext import TaskContext
from random import Random
from collections import defaultdict
from contextlib import contextmanager

__all__: List[str] = []

_local = threading.local()


class _ExtendedInstrumentationConfig:
    def __init__(
        self,
        classes: Iterable[Type[Any]] = (),
        instance_var_allow_list: Iterable[Tuple[Type[Any], str]] = (),
        class_var_allow_list: Iterable[Tuple[Type[Any], str]] = (),
    ):
        self.classes = set(classes)
        self.instance_var_allow_list = set(instance_var_allow_list)
        self.class_var_allow_list = set(class_var_allow_list)
    
    def merge(self, other: '_ExtendedInstrumentationConfig') -> '_ExtendedInstrumentationConfig':
        return _ExtendedInstrumentationConfig(
            classes=self.classes.union(other.classes),
            instance_var_allow_list=self.instance_var_allow_list.union(other.instance_var_allow_list),
            class_var_allow_list=self.class_var_allow_list.union(other.class_var_allow_list),
        )


class _LoggingHelper:
    status_success: str = "success"
    status_failure: str = "failure"

    class AtomicInteger:
        def __init__(self, initial: int = 0):
            self.value = initial
            self._lock = threading.Lock()

        def get(self) -> int:
            with self._lock:
                return self.value

        def set(self, new_value: int) -> None:
            with self._lock:
                self.value = new_value

        def increment_and_get(self, amount: int = 1) -> int:
            with self._lock:
                self.value += amount
                return self.value

    def __init__(self,
                 logger: UsageLogger,
                 is_extended_instrumentation_enabled: bool,
                 sampling_rate: float,
                 always_log_first_n_calls: int,
                 random: Optional[Random] = None):
        self.logger = logger
        self.is_extended_instrumentation_enabled = is_extended_instrumentation_enabled

        # Sampling works this way:
        # For every function/property/etc we log the first N calls originating from customer code
        # and the first N calls originating from Databricks code unconditionally.
        # All the subsequent calls will be logged with the specified sampling rate.
        self.sampling_rate = sampling_rate
        self.always_log_first_n_calls = always_log_first_n_calls
        self.log_counter: Dict[Tuple[Any, bool], _LoggingHelper.AtomicInteger] = defaultdict(
            _LoggingHelper.AtomicInteger)
        self.random = random or Random()

    # Increment call counter and check if it should be logged with respect to sampling logic.
    def should_log(self, accessor: Any, is_internal_call: bool) -> bool:
        counter_value = self.log_counter[(accessor, is_internal_call)].increment_and_get()
        if counter_value <= self.always_log_first_n_calls or self.sampling_rate == 1.0:
            return True
        if self.sampling_rate == 0.0:
            return False
        return self.random.random() < self.sampling_rate

    def init_log_counter(self, accessor: Any) -> None:
        # Initialize log_counter in advance to avoid race conditions.
        # Initialization of missing keys is not atomic, which might lead to over-logging.
        self.log_counter[(accessor, False)].get()
        self.log_counter[(accessor, True)].get()

    @staticmethod
    def get_internal_call_site(skip_frames: int = 3) -> Tuple[bool, Optional[str]]:
        frame = inspect.currentframe()
        depth = 0
        while frame is not None and depth < skip_frames:
            frame = frame.f_back
            depth += 1

        # If we landed on a __getattribute__ override (e.g. RemoteContext in dbruntime),
        # it's a wrapping layer that adds an extra frame for property/descriptor access.
        # Skip past it to find the actual caller.
        while frame is not None and frame.f_code.co_name == "__getattribute__":
            frame = frame.f_back

        if frame is not None:
            call_site = f"{frame.f_code.co_filename}:{frame.f_lineno}"
            if _LoggingHelper.is_internal_call(call_site):
                return True, call_site
        return False, None

    @staticmethod
    def is_internal_call(call_site: Optional[str]) -> bool:
        return call_site is not None and call_site.startswith("/databricks")

    def log_event(self,
                  accessor: Any,
                  module_name: str,
                  class_name: str,
                  function_name: Optional[str] = None,
                  function_signature: Optional[Union[Signature, str]] = None,
                  property_name: Optional[str] = None,
                  class_var_name: Optional[str] = None,
                  duration: float = 0.0,
                  ex: Optional[Exception] = None) -> None:
        try:
            if not self.is_extended_instrumentation_enabled:
                if ex is None:
                    self.logger.log_success(
                        module_name=module_name,
                        class_name=class_name,
                        name=function_name or property_name,
                        signature=function_signature,
                        duration=duration
                    )
                else:
                    self.logger.log_failure(
                        module_name=module_name,
                        class_name=class_name,
                        name=function_name or property_name,
                        signature=function_signature,
                        duration=duration,
                        ex=ex
                    )
                return

            status = _LoggingHelper.status_success if ex is None else _LoggingHelper.status_failure
            is_internal_call, internal_call_site = self.get_internal_call_site()
            if self.should_log(accessor, is_internal_call):
                self.logger.log_event(
                    status=status,
                    module_name=module_name,
                    class_name=class_name,
                    function_name=function_name,
                    function_signature=function_signature,
                    property_name=property_name,
                    class_var_name=class_var_name,
                    is_internal_call=is_internal_call,
                    internal_call_site=internal_call_site
                )
        except Exception:
            pass


@contextmanager
def _logging_outermost_call() -> Iterator[None]:
    _local.logging = True
    try:
        yield
    finally:
        _local.logging = False


def _is_inside_logged_call() -> bool:
    return hasattr(_local, "logging") and _local.logging


def _wrap_function(
        module_name: str, class_name: str, function_name: str, func: Callable, logging_helper: _LoggingHelper
) -> Callable:
    signature = inspect.signature(func)

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        __hide_databricks_frame__ = True
        if _is_inside_logged_call():
            # no need to log since this should be internal call.
            return func(*args, **kwargs)
        with _logging_outermost_call():
            start = time.perf_counter()
            try:
                res = func(*args, **kwargs)
                logging_helper.log_event(
                    accessor=wrapper,
                    module_name=module_name,
                    class_name=class_name,
                    function_name=function_name,
                    function_signature=signature,
                    duration=time.perf_counter() - start
                )
                return res
            except Exception as ex:
                logging_helper.log_event(
                    accessor=wrapper,
                    module_name=module_name,
                    class_name=class_name,
                    function_name=function_name,
                    function_signature=signature,
                    duration=time.perf_counter() - start,
                    ex=ex
                )
                raise

    logging_helper.init_log_counter(wrapper)
    return wrapper


def _wrap_property(
        module_name: str,
        class_name: str,
        property_name: str,
        prop: Any,
        logging_helper: _LoggingHelper,
        # The call itself is not logged, but prevents all the nested calls from being logged.
        # This is the old behavior for non-allowlisted properties.
        skip_logging: bool
) -> Any:
    @property  # type: ignore[misc]
    def wrapper(self: Any) -> Any:
        __hide_databricks_frame__ = True
        if _is_inside_logged_call():
            # no need to log since this should be internal call.
            return prop.fget(self)
        with _logging_outermost_call():
            if skip_logging:
                return prop.fget(self)

            start = time.perf_counter()
            try:
                res = prop.fget(self)
                logging_helper.log_event(
                    accessor=wrapper,
                    module_name=module_name,
                    class_name=class_name,
                    property_name=property_name,
                    duration=time.perf_counter() - start
                )
                return res
            except Exception as ex:
                logging_helper.log_event(
                    accessor=wrapper,
                    module_name=module_name,
                    class_name=class_name,
                    property_name=property_name,
                    duration=time.perf_counter() - start,
                    ex=ex
                )
                raise

    logging_helper.init_log_counter(wrapper)

    wrapper.__doc__ = prop.__doc__

    if prop.fset is not None:
        wrapper = wrapper.setter(  # type: ignore[attr-defined]
            _wrap_function(module_name, class_name, prop.fset.__name__, prop.fset, logging_helper)
        )

    return wrapper


def _wrap_cached_property(
        module_name: str,
        class_name: str,
        property_name: str,
        prop: functools.cached_property,
        logging_helper: _LoggingHelper,
        # The call itself is not logged, but prevents all the nested calls from being logged.
        # This is the old behavior for non-allowlisted properties.
        skip_logging: bool
) -> Any:
    class wrapper:
        def __init__(self, cached_property: functools.cached_property) -> None:
            self._cached_property = cached_property

        def __get__(self, instance: Any, owner: Optional[Type[Any]] = None) -> Any:
            __hide_databricks_frame__ = True
            if _is_inside_logged_call():
                # no need to log since this should be internal call.
                return self._cached_property.__get__(instance, owner)

            with _logging_outermost_call():
                if skip_logging:
                    return self._cached_property.__get__(instance, owner)

                start = time.perf_counter()
                try:
                    res = self._cached_property.__get__(instance, owner)
                    logging_helper.log_event(
                        accessor=wrapper,
                        module_name=module_name,
                        class_name=class_name,
                        property_name=property_name,
                        duration=time.perf_counter() - start
                    )
                    return res
                except Exception as ex:
                    logging_helper.log_event(
                        accessor=wrapper,
                        module_name=module_name,
                        class_name=class_name,
                        property_name=property_name,
                        duration=time.perf_counter() - start,
                        ex=ex
                    )
                    raise

    logging_helper.init_log_counter(wrapper)
    return wrapper(prop)


def _wrap_instance_var(
        module_name: str,
        class_name: str,
        var_name: str,
        getattr_func: Optional[Callable],
        logging_helper: _LoggingHelper
) -> Any:
    undefined_value = object()

    def fget_impl(self: Any) -> Any:
        __hide_databricks_frame__ = True
        var_value = self.__dict__.get(var_name, undefined_value)
        if var_value is not undefined_value:
            return var_value
        if getattr_func is not None:
            return getattr_func(self, var_name)
        raise AttributeError(f"'{class_name}' object has no attribute '{var_name}'")

    def fget(self: Any) -> Any:
        __hide_databricks_frame__ = True
        if _is_inside_logged_call():
            # no need to log since this should be internal call.
            return fget_impl(self)

        with _logging_outermost_call():
            try:
                res = fget_impl(self)
                logging_helper.log_event(
                    accessor=fget,
                    module_name=module_name,
                    class_name=class_name,
                    property_name=var_name
                )
                return res
            except Exception as ex:
                logging_helper.log_event(
                    accessor=fget,
                    module_name=module_name,
                    class_name=class_name,
                    property_name=var_name,
                    ex=ex
                )
                raise

    def fset(self: Any, value: Any) -> None:
        __hide_databricks_frame__ = True
        self.__dict__[var_name] = value

    def fdel(self: Any) -> None:
        __hide_databricks_frame__ = True
        var_value = self.__dict__.pop(var_name, undefined_value)
        if var_value is undefined_value:
            raise AttributeError(f"'{class_name}' object has no attribute '{var_name}'")

    # var access get logged with sampling, each call to fget is counted
    logging_helper.init_log_counter(fget)

    # Make a property backed by self.__dict__ that imitates instance var behavior
    return property(fget, fset, fdel)


def _wrap_class_var(
        module_name: str,
        class_name: str,
        var_name: str,
        original_value: Any,
        logging_helper: _LoggingHelper
) -> Any:
    class wrapper:
        def __get__(self, instance: Any, owner: Optional[Type[Any]] = None) -> Any:
            __hide_databricks_frame__ = True
            if _is_inside_logged_call():
                # no need to log since this should be internal call.
                return original_value

            with _logging_outermost_call():
                logging_helper.log_event(
                    accessor=wrapper,
                    module_name=module_name,
                    class_name=class_name,
                    class_var_name=var_name,
                )
                return original_value

    logging_helper.init_log_counter(wrapper)
    return wrapper()


_is_wrapped = {}


def _wrap_attr(obj: object, name: str, wrapped_val: Any, mark_as_wrapped: Optional[Any] = None) -> None:
    setattr(obj, name, wrapped_val)
    _is_wrapped[wrapped_val] = True
    if mark_as_wrapped is not None:
        _is_wrapped[mark_as_wrapped] = True


def _instrument_apis(
        logging_helper: _LoggingHelper,
        modules: Iterable[ModuleType],
        classes: Iterable[Type[Any]],
        class_property_allow_list: Optional[Iterable[Type[Any]]],
        private_function_allow_list: Iterable[FunctionType] = (),
        extended_instrumentation_classes: Iterable[Type[Any]] = (),
        extended_instrumentation_instance_var_allow_list: Iterable[Tuple[Type[Any], str]] = (),
        extended_instrumentation_class_var_allow_list: Iterable[Tuple[Type[Any], str]] = (),
) -> None:
    special_functions = {
        "__init__",
        "__repr__",
        "__str__",
        "_repr_html_",
        "__len__",
        "__getitem__",
        "__setitem__",
        "__getattr__",
        "__enter__",
        "__exit__",
    }

    def is_private(entity_name: str) -> bool:
        # function or property is considered private if it starts with an underscore
        return entity_name.startswith("_")

    # Modules
    for target_module in modules:
        target_name = target_module.__name__.split(".")[-1]
        for name in getattr(target_module, "__all__"):
            func = getattr(target_module, name)
            if (not inspect.isfunction(func)) or (func in _is_wrapped):
                continue
            _wrap_attr(
                target_module,
                name,
                _wrap_function(target_name, target_name, name, func, logging_helper),
            )

    # Classes
    if logging_helper.is_extended_instrumentation_enabled:
        classes = set(extended_instrumentation_classes).union(classes)
    for target_class in classes:
        for name, func in inspect.getmembers(target_class, inspect.isfunction):
            if func in _is_wrapped:
                continue
            if (
                    is_private(name) and name not in special_functions
            ) and not logging_helper.is_extended_instrumentation_enabled:
                continue

            try:
                isstatic = isinstance(inspect.getattr_static(target_class, name), staticmethod)
            except AttributeError:
                isstatic = False
            wrapped_function = _wrap_function(
                target_class.__module__, target_class.__name__, name, func, logging_helper
            )
            _wrap_attr(
                target_class,
                name,
                staticmethod(wrapped_function) if isstatic else wrapped_function,
                wrapped_function
            )

        for name, prop in inspect.getmembers(target_class, lambda o: isinstance(o, property)):
            if prop in _is_wrapped:
                continue

            # Old behavior: private properties are not instrumented at all
            if is_private(name) and not logging_helper.is_extended_instrumentation_enabled:
                continue

            # Old behavior: non-allowlisted properties are instrumented, but not logged
            # New behavior: all properties are instrumented, allowlist is ignored
            skip_logging = (
                    (class_property_allow_list is not None and prop not in class_property_allow_list) and
                    not logging_helper.is_extended_instrumentation_enabled
            )

            _wrap_attr(
                target_class,
                name,
                _wrap_property(
                    target_class.__module__,
                    target_class.__name__,
                    name,
                    prop,
                    logging_helper,
                    skip_logging,
                ),
            )

        for name, prop in inspect.getmembers(
                target_class, lambda o: isinstance(o, functools.cached_property)
        ):
            if prop in _is_wrapped:
                continue

            # Old behavior: private properties are not instrumented at all
            if is_private(name) and not logging_helper.is_extended_instrumentation_enabled:
                continue

            # Old behavior: non-allowlisted properties are instrumented, but not logged
            # New behavior: all properties are instrumented, allowlist is ignored
            skip_logging = (
                    (class_property_allow_list is not None and prop not in class_property_allow_list) and
                    not logging_helper.is_extended_instrumentation_enabled
            )

            _wrap_attr(
                target_class,
                name,
                _wrap_cached_property(
                    target_class.__module__,
                    target_class.__name__,
                    name,
                    prop,
                    logging_helper,
                    skip_logging,
                ),
                prop,
            )

    if logging_helper.is_extended_instrumentation_enabled:
        # Instance variables
        for target_class, var_name in extended_instrumentation_instance_var_allow_list:
            # Skip if there is a member with the same name already.
            # Either it was instrumented previously, or it is not an instance var anymore.
            if hasattr(target_class, var_name):
                continue

            _wrap_attr(
                target_class,
                var_name,
                _wrap_instance_var(
                    module_name=target_class.__module__,
                    class_name=target_class.__name__,
                    var_name=var_name,
                    getattr_func=getattr(target_class, "__getattr__", None),
                    logging_helper=logging_helper,
                ),
            )

        # Class variables
        for target_class, var_name in extended_instrumentation_class_var_allow_list:
            if not hasattr(target_class, var_name):
                continue

            _wrap_attr(
                target_class,
                var_name,
                _wrap_class_var(
                    module_name=target_class.__module__,
                    class_name=target_class.__name__,
                    var_name=var_name,
                    original_value=getattr(target_class, var_name),
                    logging_helper=logging_helper,
                ),
            )

    # Functions
    for func in private_function_allow_list:
        target_module = inspect.getmodule(func)
        target_name = target_module.__name__.split(".")[-1]
        name = func.__name__
        if (not inspect.isfunction(func)) or (func in _is_wrapped):
            continue
        _wrap_attr(
            target_module,
            name,
            _wrap_function(target_name, target_name, name, func, logging_helper),
        )


def _auto_patch_spark(
        modules: Iterable[ModuleType],
        classes: Iterable[Type[Any]],
        class_property_allow_list: Optional[Iterable[Type[Any]]],
        private_function_allow_list: Iterable[FunctionType] = (),
        extended_instrumentation_config: Optional[_ExtendedInstrumentationConfig] = None,
        lazy_extended_config_loader: Optional[Callable[[], _ExtendedInstrumentationConfig]] = None,
) -> None:
    import logging
    from pyspark import SparkContext

    # Attach a usage logger.
    if TaskContext.get() is None:
        try:
            from pyspark.databricks import usage_logger

            logger = usage_logger.get_logger()

            jsc = SparkContext._active_spark_context._jsc
            python_utils = SparkContext._jvm.PythonUtils
            is_extended_instrumentation_enabled = python_utils.isPySparkExtendedInstrumentationEnabled(jsc)
            sampling_rate = python_utils.pySparkInstrumentationSamplingRate(jsc)
            always_log_first_n_calls = python_utils.pySparkInstrumentationAlwaysLogFirstNCalls(jsc)
            logging_helper = _LoggingHelper(
                logger,
                is_extended_instrumentation_enabled,
                sampling_rate,
                always_log_first_n_calls)

            # Build extended instrumentation config
            config = extended_instrumentation_config or _ExtendedInstrumentationConfig()

            # Lazy-load and merge additional config if provided
            if lazy_extended_config_loader is not None:
                lazy_config = lazy_extended_config_loader()
                config = config.merge(lazy_config)

            _instrument_apis(
                logging_helper,
                modules,
                classes,
                class_property_allow_list,
                private_function_allow_list,
                config.classes,
                config.instance_var_allow_list,
                config.class_var_allow_list
            )
        except Exception as e:
            logger = logging.getLogger("pyspark.usage_logger")
            logger.warning(
                "Tried to attach usage logger `{}`, but an exception was raised: {}".format(
                    usage_logger.__name__, str(e)
                )
            )


def _instrument_after_spark_context_init(
        modules: Iterable[ModuleType] = (),
        classes: Iterable[Type[Any]] = (),
        class_property_allow_list: Optional[Iterable[Type[Any]]] = (),
        private_function_allow_list: Iterable[FunctionType] = (),
        extended_instrumentation_config: Optional[_ExtendedInstrumentationConfig] = None,
        # Load config lazily to avoid circular dependencies
        lazy_extended_config_loader: Optional[Callable[[], _ExtendedInstrumentationConfig]] = None,
) -> None:
    """
    Instrument modules and classes after spark context is initialized to
    avoid unnecessary instrumentation when non-driver code imports pyspark modules
    without an active SparkContext.
    """

    from pyspark import SparkContext

    def instrument_hook() -> None:
        try:
            from dbruntime.safe import pysafex
            safex_enabled = pysafex("databricks.repl.python.pySparkInstrumentationEnabled", True)
        except ImportError:
            # dbruntime.safe is not available in test environments
            safex_enabled = True

        # Make sure we don't try to log any calls while applying monkey-patching
        with _logging_outermost_call():
            if safex_enabled and SparkContext._jvm.PythonUtils.isPySparkInstrumentationEnabled(
                    SparkContext._active_spark_context._jsc
            ):
                _auto_patch_spark(
                    modules,
                    classes,
                    class_property_allow_list,
                    private_function_allow_list,
                    extended_instrumentation_config,
                    lazy_extended_config_loader
                )

    SparkContext._add_after_init_hook(instrument_hook)
