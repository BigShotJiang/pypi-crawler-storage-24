#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2020-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#
"""
Telemetry utilities for PySpark operations.
"""
from typing import Any, Callable, Optional, Union


class PipelineSparkConnectMigrationTelemetry:
    """
    Centralized telemetry for Spark Connect migration detection.

    This class provides static methods to detect various PySpark operations
    that may need migration telemetry when transitioning to Spark Connect.
    """

    # Class variable to track whether telemetry is enabled
    _enabled_telemetry: bool = False

    @staticmethod
    def enable_telemetry() -> None:
        PipelineSparkConnectMigrationTelemetry._enabled_telemetry = True

    @staticmethod
    def disable_telemetry() -> None:
        PipelineSparkConnectMigrationTelemetry._enabled_telemetry = False

    @staticmethod
    def _is_enabled() -> bool:
        return PipelineSparkConnectMigrationTelemetry._enabled_telemetry

    @staticmethod
    def detect_df_construction(df: "DataFrame") -> None:
        """
        Detect DataFrame construction.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_df_construction

            detect_df_construction(df)

    @staticmethod
    def detect_create_replace_temp_view_mutation(name: str) -> None:
        """
        Detect createOrReplaceTempView operation.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_create_replace_temp_view_mutation

            detect_create_replace_temp_view_mutation(name)

    @staticmethod
    def detect_create_or_replace_global_temp_view(name: str) -> None:
        """
        Detect createOrReplaceGlobalTempView operation.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_create_or_replace_global_temp_view

            detect_create_or_replace_global_temp_view(name)

    @staticmethod
    def detect_udf_function(f: Union[Callable[..., Any], "UserDefinedFunction"]) -> None:
        """
        Detect UDF function.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_udf_function
            detect_udf_function(f)

    @staticmethod
    def detect_udf_registration(name: str, f: Union[Callable[..., Any], "UserDefinedFunction"]) -> None:
        """
        Detect UDF registration.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_udf_registration

            detect_udf_registration(name, f)

    @staticmethod
    def detect_udtf_function(cls: Optional[type]) -> None:
        """
        Detect UDTF function.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_udtf_function
            detect_udtf_function(cls)

    @staticmethod
    def detect_udtf_registration(name: str, f: "UserDefinedTableFunction") -> None:
        """
        Detect UDTF registration.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_udtf_registration

            detect_udtf_registration(name, f)

    @staticmethod
    def detect_spark_conf_set(key: str, value: Union[str, int, bool]) -> None:
        """
        Detect Spark configuration set operation.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_spark_conf_set

            detect_spark_conf_set(key, value)

    @staticmethod
    def detect_spark_conf_unset(key: str) -> None:
        """
        Detect Spark configuration unset operation.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_spark_conf_unset

            detect_spark_conf_unset(key)

    @staticmethod
    def detect_sql_context_construction() -> None:
        """
        Detect SQLContext construction.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_sql_context_construction

            detect_sql_context_construction()

    @staticmethod
    def detect_spark_context_access() -> None:
        """
        Detect SparkSession.sparkContext property access.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_spark_context_access

            detect_spark_context_access()

    @staticmethod
    def detect_dataframe_to_rdd_construction() -> None:
        """
        Detect DataFrame.rdd property access.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_dataframe_to_rdd_construction

            detect_dataframe_to_rdd_construction()

    @staticmethod
    def detect_dataframe_to_json_construction() -> None:
        """
        Detect DataFrame.toJSON property access.
        """
        if PipelineSparkConnectMigrationTelemetry._is_enabled():
            from dlt.overrides import detect_dataframe_to_json_construction

            detect_dataframe_to_json_construction()
