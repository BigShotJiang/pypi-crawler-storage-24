#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2020-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import shutil
import tempfile
import zipfile
from importlib import metadata
from packaging.requirements import Requirement
from packaging.version import Version
from pathlib import Path
from typing import Any, Union, TYPE_CHECKING

from google.protobuf import any_pb2

from databricks.connect.auto_dependencies import DiscoveryConfig
from databricks.connect.debug import logger
from databricks.connect.pkginfo import get_metadata
import pyspark.sql.connect.proto as pb2
from pyspark.sql.connect.expressions import PythonUDFEnvironment


if TYPE_CHECKING:
    from pyspark.sql import SparkSession


class DatabricksEnv:
    """Public Preview API.

    Specify the Python environment used while executing user-defined functions.
    """
    def __init__(self):
        # NOTE: Include any new state modifying members in the `_as_hashable` method.
        self._dependencies = []
        self._discovery_config = DiscoveryConfig.NONE

    @property
    def dependencies(self) -> list[str]:
        """Return a copy of environment's dependencies."""
        return self._dependencies.copy()

    def withAutoDependencies(self, *, upload_local: bool = True, use_index: bool = True) -> 'DatabricksEnv':
        """Enable auto-discovery of UDF dependencies based on the local project source code.
        Discovered dependencies are automatically added to the session's environment and uploaded to Databricks
        compute. Discovery is based on traversing the source code of the UDFs run by the user and looking for import
        statements. Traversal is performed recursively.

        The possible modes are:
        - upload_local: Discover modules from your project. The source files of the used modules will be uploaded using
          addArtifact so that they can be imported in the UDF environment.
        - use_index: Discover modules from third party distributions. Discovered distribution packages will be
          installed in the UDF environment from the public PyPI server with the same version as in the local
          environment.

        Behavior in Databricks notebooks and jobs:
        This API is a noop in notebooks and jobs, because the REPL and UDF environments are synchronized automatically
        by Databricks.
        """
        match upload_local:
            case False:
                self._discovery_config &= ~DiscoveryConfig.LOCAL
            case True:
                self._discovery_config |= DiscoveryConfig.LOCAL
        match use_index:
            case False:
                self._discovery_config &= ~DiscoveryConfig.INDEX
            case True:
                self._discovery_config |= DiscoveryConfig.INDEX
        return self

    def withDependencies(self, *dependencies: Union[str, list[str]]) -> 'DatabricksEnv':
        """Add a list of dependencies to the environment.

        Packages are installed in the same order as specified.
        When the same package is specified twice with different versions, the latter wins.

        Currently supported dependency types are:
        1. PyPI packages
            - PyPI packages can be specified according to PEP 508, for example,
              "dice", "pyjokes<1" or "simplejson==3.19.*".
        2. Packages stored in UC volumes, specified as "dbfs:<path>",
            - Both built distributions (`.whl`) and source distributions (`.tar.gz`) are supported.
            - UC volumes packages can be specified as `dbfs:<path>`, for example,
              `dbfs:/Volumes/users/someone@example.com/wheels/my_private_dep-3.20.2-py3-none-any.whl`
              or `dbfs:/Volumes/users/someone@example.com/tars/my_private_dep-4.0.0.tar.gz`.
            - for example, "dbfs:/Volumes/users/Alice/wheels/my_private_dep.whl" or
              "dbfs:/Volumes/users/Bob/tars/my_private_deps.tar.gz".
            - The user must be granted `READ_FILE` permission on the file in the UC volume.
              Granting this permission to all account users automatically enables this for new users.
        3. Local packages, folders, and python files, specified as `local:<path>`
            - Wheel/tar packages, for example `local:/path/to/my_private_dep-3.20.2-py3-none-any.whl`
              or `local:/path/to/my_private_dep-4.0.0.tar.gz`.
              Uploaded and installed via pip in the UDF environment.
            - Python files, for example "local:/path/to/module.py".
              Uploaded and made available on PYTHONPATH (not pip installed).
            - Folders (e.g., "local:/path/to/my_package"):
              Zipped, uploaded, and made available on PYTHONPATH (not pip installed).
              Folders can contain Python modules, data files, or any resources needed by UDFs.
            - Both absolute and relative paths are supported, for example: `local:/path/to/my_file.py`
              or `local:./path/to/my_file.py`.
            - Local files/folders are automatically uploaded via spark.addArtifact() when the session is created.
              They are session-scoped and only available to the user who created the session.

        Behavior in Databricks notebooks and jobs:
        Instead of installing specified dependencies in the current environment, DatabricksEnv
        will check that the current Python environment has all specified dependencies installed.
        If any of the dependencies are missing, a EnvironmentSpecError will be raised.
        See supported ways for installing dependencies in Databricks notebooks and jobs here:
        https://docs.databricks.com/aws/en/libraries/
        Note: "local:" dependencies are currently ignored during environment validation
        in Databricks notebooks and jobs.

        Parameters
        ----------
        *dependencies: Union[str, list[str]]
            One or more dependencies, each can be a single string or a list of strings.
        Returns
        -------
        DatabricksEnv
            The same instance of this class with the values configured.
        """
        for dependency in dependencies:
            if isinstance(dependency, str):
                self._dependencies.append(dependency)
            elif isinstance(dependency, list):
                self._dependencies.extend(dependency)
            else:
                raise EnvironmentSpecError("Provided dependencies must be a string or a list of strings.")
        return self

    def _as_hashable(self) -> frozenset[tuple[str, Any]]:
        """Return a simple hashable representation of the environment."""
        dict_repr = {"dependencies": tuple(self.dependencies), "discovery_config": self._discovery_config}
        return frozenset(dict_repr.items())

    def _to_python_udf_env(self) -> PythonUDFEnvironment:
        """Convert DatabricksEnv to PythonUDFEnvironment."""
        deps = []
        for dep in self.dependencies:
            if dep.startswith("local:"):
                if dep.endswith((".whl", ".tar.gz", ".tar")):
                    # "local:full_path" is replaced with "artifact:file_name" for wheel and tar files,
                    # the server will run pip install on them
                    file_path = Path(dep.removeprefix("local:"))
                    # Get just the filename for the artifact reference
                    file_name = file_path.name
                    deps.append(f"artifact:{file_name}")
                else:
                    # Python files and folders are uploaded as artifacts and are available out of the box.
                    # No pip install needed on the server.
                    continue
            else:
                # "dbfs:" prefix is provided by the user to indicate that the dependency is a UC Volumes path
                # and not a local path. We need to remove the prefix before sending the data to the server.
                deps.append(dep.removeprefix("dbfs:"))
        return PythonUDFEnvironment(dependencies=deps)

    def _create_with_dependencies_context_extension(self) -> any_pb2.Any:
        """Create a client features context extension for withDependencies feature."""
        client_features_context = pb2.ClientFeaturesContext(
            client_features=[pb2.ClientFeaturesContext.ClientFeatures.CLIENT_FEATURES_UDF_WITH_DEPENDENCIES]
        )
        extension = any_pb2.Any()
        extension.Pack(client_features_context)
        return extension

    def _process_and_upload_local_artifacts(self, spark: "SparkSession") -> None:
        """Process dependencies and automatically upload local files/folders as artifacts.

        This method:
        1. Detects local: prefixed dependencies (e.g., "local:/path/to/wheel.whl")
        2. Handles different file types:
           - .whl, .tar.gz, .tar: Upload with file=True, add to dependencies for pip install
           - .py files: Upload with pyfile=True, add to PYTHONPATH (not pip installed)
           - Folders: Zip, upload with pyfile=True, add to PYTHONPATH (not pip installed)

        Args:
            spark: SparkSession to use for uploading artifacts.
        """
        local_deps = [dep for dep in self.dependencies if dep.startswith("local:")]
        for dep in local_deps:
            local_path = Path(dep.removeprefix("local:"))

            # Verify the path exists
            if not local_path.exists():
                raise EnvironmentSpecError(
                    f"Local dependency not found: {local_path}. "
                    "Please provide a valid file or folder path."
                )

            if local_path.is_file():
                self._upload_local_file(spark, local_path)
            elif local_path.is_dir():
                self._upload_local_folder(spark, local_path)
            else:
                raise EnvironmentSpecError(f"Local dependency must be a file or folder: {local_path}")

    def _upload_local_file(self, spark: "SparkSession", file_path: Path):
        """Upload a local file as an artifact.

        .whl, .tar.gz, .tar files are uploaded with file=True for pip installation.
        .py files are uploaded with pyfile=True and added to PYTHONPATH.
        """
        file_path = str(file_path.resolve())
        user_context_extensions = [self._create_with_dependencies_context_extension()]
        if file_path.endswith((".whl", ".tar.gz", ".tar")):
            # Pip-installable packages - upload with file=True
            try:
                logger.info(f"Uploading pip-installable package '{file_path}' as artifact")
                spark._add_artifacts_with_context(
                    file_path, file=True, user_context_extensions=user_context_extensions
                )
                logger.info(f"Successfully uploaded '{file_path}' for pip installation")
            except Exception as e:
                raise EnvironmentSpecError(f"Failed to upload local dependency '{file_path}' as artifact: {e}")
        elif file_path.endswith(".py"):
            # Python source files - upload with pyfile=True
            try:
                logger.info(f"Uploading Python file '{file_path}' as artifact")
                spark._add_artifacts_with_context(
                    file_path, pyfile=True, user_context_extensions=user_context_extensions
                )
                logger.info(f"Successfully uploaded '{file_path}' to PYTHONPATH")
            except Exception as e:
                raise EnvironmentSpecError(f"Failed to upload Python file '{file_path}' as artifact: {e}")
        else:
            raise EnvironmentSpecError(
                f"Unsupported file type for local dependency: {file_path}. "
                "Supported types: .whl, .tar.gz, .tar, .py, or folders."
            )

    def _upload_local_folder(self, spark: "SparkSession", folder_path: Path):
        """Zip a local folder and upload it as an artifact with pyfile=True."""
        folder_name = folder_path.name
        zip_name = f"{folder_name}.zip"

        # Create temporary zip file
        temp_dir = None
        try:
            # Create zip in a temporary directory
            temp_dir = tempfile.mkdtemp()
            temp_zip = Path(temp_dir) / zip_name

            logger.debug(f"Zipping folder '{folder_path}' to '{temp_zip}'")
            with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file in folder_path.rglob('*'):
                    if file.is_file():
                        # Add file with relative path to maintain folder structure
                        arcname = file.relative_to(folder_path.parent)
                        zipf.write(file, arcname)

            logger.debug(f"Uploading zipped folder '{zip_name}' as artifact")
            zip_path = str(temp_zip.resolve())
            spark._add_artifacts_with_context(
                zip_path, pyfile=True, user_context_extensions=[self._create_with_dependencies_context_extension()]
            )
            logger.info(f"Successfully uploaded folder '{folder_path}' to PYTHONPATH")

        except Exception as e:
            raise EnvironmentSpecError(f"Failed to zip and upload folder '{folder_path}': {e}")
        finally:
            # Clean up temporary directory and its contents
            if temp_dir:
                shutil.rmtree(temp_dir, ignore_errors=True)

    def _validate_environment(self):
        """Validate the python environment in Databricks notebooks and jobs.
        Make sure that all specified dependencies are installed."""
        # Convert UC Volumes dependencies to requirement strings
        # Skip artifact: and local: dependencies as they are only used in Databricks Connect
        pep_requirement_strings = []
        for dep in self.dependencies:
            if dep.startswith("local:"):
                # skip in notebooks, the UDF container has access to the local files
                continue
            elif dep.startswith("dbfs:"):
                pep_requirement_strings.append(self._pep_string_for_uc_volume_dependency(dep))
            else:
                pep_requirement_strings.append(dep)

        requirements = [Requirement(dep.lower()) for dep in pep_requirement_strings]
        installed_packages = self._get_installed_packages()
        self._verify_dependencies_are_installed(requirements, installed_packages)

    @staticmethod
    def _get_installed_packages() -> dict[str, Version]:
        return {dist.metadata["name"].lower(): Version(dist.version)
                for dist in metadata.distributions()}

    @staticmethod
    def _pep_string_for_uc_volume_dependency(dep_path: str) -> str:
        dep_path = dep_path.removeprefix("dbfs:")
        if not Path(dep_path).exists():
            raise EnvironmentSpecError(f"Cannot access '{dep_path}': No such file or directory.")
        supported_file_formats = (".whl", ".tar.gz", ".tar")
        if not dep_path.endswith(supported_file_formats):
            raise EnvironmentSpecError(
                f"Unsupported file format '{dep_path}'. "
                f"Only {', '.join(supported_file_formats)} files are supported.")
        dist = get_metadata(dep_path)
        if dist is None or dist.name is None:
            raise EnvironmentSpecError(
                f"Can't extract package name from '{dep_path}'. "
                "Make sure that the package contains a METADATA file (for wheels) or "
                "a .PKG-INFO file (for tarballs).")
        if dist.version is None:
            return dist.name
        else:
            return f"{dist.name}=={dist.version}"

    @staticmethod
    def _verify_dependencies_are_installed(
            requirements: list[Requirement], installed_packages: dict[str, Version]) -> None:
        for req in requirements:
            if req.name not in installed_packages:
                raise EnvironmentSpecError(f"Package {req.name} was not found in the environment.")
            installed_version = installed_packages[req.name]

            if req.specifier.contains(installed_version):
                logger.debug(f"Package {req.name}=={str(installed_version)} is installed "
                             f"in the environment and satisfies requirement {str(req)}.")
            else:
                raise EnvironmentSpecError(f"Package {req.name}=={str(installed_version)} is installed "
                                 f"in the environment but does not satisfy requirement {str(req)}.")
        logger.debug("All dependencies are installed and satisfy the requirements.")


class EnvironmentSpecError(ValueError):
    """
    This error is raised when the DatabricksEnv specification is incorrect or
    when the Python environment in a Databricks notebook or job could not be validated.
    """
