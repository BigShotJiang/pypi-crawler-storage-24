#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2020-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import logging

from google.protobuf import any_pb2

import pyspark.sql.connect.proto as pb2
from databricks.connect.utils.protobuf_utils import find_all_instances
from pyspark.sql.connect.session import SparkSession

logger = logging.getLogger(__name__)


class DependenciesHook(SparkSession.Hook):
    """Hook to add CLIENT_FEATURES_UDF_WITH_DEPENDENCIES metrics to execute_plan requests containing UDFs.

    This hook is registered during session creation if the user has specified any dependencies explicitly
    via withDependencies(). It adds the appropriate client features context extension for metrics tracking
    when UDFs are executed.
    """

    def __init__(self, session: SparkSession) -> None:
        self.session = session

    def _create_client_features_context_extension(self) -> any_pb2.Any:
        """Create a client features context extension for withDependencies feature."""
        client_features_context = pb2.ClientFeaturesContext(
            client_features=[pb2.ClientFeaturesContext.ClientFeatures.CLIENT_FEATURES_UDF_WITH_DEPENDENCIES]
        )
        extension = any_pb2.Any()
        extension.Pack(client_features_context)
        return extension

    def on_execute_plan(self, request: pb2.ExecutePlanRequest) -> pb2.ExecutePlanRequest:
        """Only used for adding metrics to requests containing UDFs"""
        udfs: list[pb2.PythonUDF | pb2.PythonUDTF] = list(
            find_all_instances(request.plan, (pb2.PythonUDF, pb2.PythonUDTF))
        )

        if not udfs:
            return request

        # If this hook is registered, we know that dependencies were specified
        request.user_context.extensions.append(self._create_client_features_context_extension())

        return request
