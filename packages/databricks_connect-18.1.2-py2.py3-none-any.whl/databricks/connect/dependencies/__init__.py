from .hook import DependenciesHook

__all__ = ["DependenciesHook"]
