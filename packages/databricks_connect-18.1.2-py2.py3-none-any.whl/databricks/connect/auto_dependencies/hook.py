import logging
import tempfile
from collections import defaultdict
from collections.abc import Iterable
from enum import auto, Flag
from importlib.machinery import ModuleSpec
from importlib.metadata import Distribution
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from google.protobuf import any_pb2
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet

import pyspark.sql.connect.proto as pb2
from databricks.connect.auto_dependencies.cache import TransitiveDiscoveryCache
from databricks.connect.auto_dependencies.discovery import DiscoveredDependencies
from databricks.connect.utils.protobuf_utils import find_all_instances
from pyspark.sql.connect.session import SparkSession


class DiscoveryConfig(Flag):
    NONE = 0
    LOCAL = auto()
    INDEX = auto()


logger = logging.getLogger(__name__)


class DependencyArtifactManager:
    """Manages session artifacts for a set of module specs.

    The module files are uploaded as a zip archive. When new modules are added, an updated zip file can be uploaded, so
    that it takes precedence over the old one. Notably, the file contents are kept in memory but written to disk when
    uploading, because we need a file system path for uploading, but don't want to keep temporary files around for the
    entire duration of the session (this would also make cleanup more difficult).
    """

    def __init__(self, session: SparkSession, prefix: str) -> None:
        self.session = session
        self.prefix = prefix
        self.needs_sync = False
        self.written_paths = {"."}
        self.io = BytesIO()

    def add_specs(self, module_specs: Iterable[ModuleSpec]) -> None:
        with ZipFile(self.io, mode="a") as zip_file:
            for spec in module_specs:
                if not spec.has_location or spec.origin is None:
                    # This happens for example when the module is a namespace package
                    continue
                package_path = spec.parent or ""
                path = Path(*package_path.split("."), Path(spec.origin).name)
                for directory in path.parents:
                    if directory.as_posix() not in self.written_paths:
                        zip_file.mkdir(directory.as_posix())
                        self.written_paths.add(directory.as_posix())
                        self.needs_sync = True
                if path.as_posix() not in self.written_paths:
                    zip_file.write(spec.origin, arcname=path.as_posix())
                    self.written_paths.add(path.as_posix())
                    self.needs_sync = True
            logger.debug("Manager %s: File list after merge: %s", self.prefix, repr(sorted(zip_file.namelist())))
        self.io.seek(0)

    def sync(self, user_context_extensions: list[any_pb2.Any]) -> None:
        # As per the documentation of NamedTemporaryFile, we disable delete_on_close because we open the file again by
        # name in addArtifacts, which could make trouble on Windows.
        with tempfile.NamedTemporaryFile(prefix=self.prefix, suffix=".zip", mode="w+b", delete_on_close=False) as file:
            file.write(self.io.getbuffer())
            file.flush()
            file_path = str(Path(file.name).resolve())
            self.session._add_artifacts_with_context(
                file_path,
                pyfile=True,
                user_context_extensions=user_context_extensions,
            )
        self.needs_sync = False


class AutoDependenciesHook(SparkSession.Hook):
    def __init__(self, session: SparkSession, config: DiscoveryConfig) -> None:
        self.session = session
        self.config = config
        self.discovery_cache = TransitiveDiscoveryCache()
        self.artifact_managers: dict[str, DependencyArtifactManager] = {}

    def _create_client_features_context_extension(self) -> any_pb2.Any:
        client_features_context = pb2.ClientFeaturesContext(
            client_features=[pb2.ClientFeaturesContext.ClientFeatures.CLIENT_FEATURES_UDF_WITH_AUTO_DEPENDENCIES]
        )
        extension = any_pb2.Any()
        extension.Pack(client_features_context)
        return extension

    def on_execute_plan(self, request: pb2.ExecutePlanRequest) -> pb2.ExecutePlanRequest:
        udfs: list[pb2.PythonUDF | pb2.PythonUDTF] = list(
            find_all_instances(request.plan, (pb2.PythonUDF, pb2.PythonUDTF))
        )
        if not udfs:
            return request

        deps = DiscoveredDependencies()
        for udf in udfs:
            obj, pickle_deps = self.discovery_cache.discover_in_pickled(udf.command)
            if isinstance(udf, pb2.PythonUDF):
                # command is a tuple (func, output_type)
                obj = obj[0]
            deps |= pickle_deps  # object references that get resolved while unpickling
            deps |= self.discovery_cache.discover_in(obj)  # dependencies required when executing the UDF

        if DiscoveryConfig.LOCAL in self.config:
            if deps.local:
                specs_by_top_level_module = defaultdict(list)
                for module_name, spec in deps.local.items():
                    top_level_module = module_name.partition(".")[0]
                    specs_by_top_level_module[top_level_module].append(spec)
                for top_level_module, specs in specs_by_top_level_module.items():
                    manager = self.artifact_managers.setdefault(
                        top_level_module,
                        DependencyArtifactManager(self.session, f"udf-dependency-{top_level_module}"),
                    )
                    manager.add_specs(specs)
                    if manager.needs_sync:
                        manager.sync([self._create_client_features_context_extension()])
                        logger.info("Synced zip artifact for: %s", top_level_module)

            if deps.direct_url:
                logger.info("Upload of direct url packages is not implemented yet: %s", repr(list(deps.direct_url)))

        if DiscoveryConfig.INDEX in self.config:
            if deps.index:
                self._update_index_dependencies(deps.index)
                if self.session._pythonEnv is not None:
                    for udf in udfs:
                        udf.environment.CopyFrom(self.session._pythonEnv.to_proto())

        if deps.unknown:
            logger.info("The source for the following modules could not be determined: %s", repr(list(deps.unknown)))

        if ((DiscoveryConfig.LOCAL in self.config and deps.local)
            or (DiscoveryConfig.INDEX in self.config and deps.index)):
            request.user_context.extensions.append(self._create_client_features_context_extension())

        return request

    def _update_index_dependencies(self, new_dependencies: dict[str, Distribution]) -> None:
        """Thread-safely merge auto-detected index dependencies with existing ones.

        If the dependency is already present with a version constraint, that constraint is preserved.
        For example, if the user has specified DatabricksEnv().withDependencies("dice>=4,<5") and the
        locally installed version is 3.0.0, constraint will not be updated.

        Parameters
        ----------
        new_dependencies : dict[str, Distribution]
            Dictionary mapping package names to Distribution objects for auto-detected
            dependencies.
        """
        python_env = self.session._pythonEnv
        if python_env is None:
            logger.error("Cannot update dependencies: session's Python environment does not exist")
            return

        # Thread-safe update of the dependencies
        with python_env._lock:
            # Parse existing dependencies and store specifiers
            specs = {}  # pkg_name -> SpecifierSet for index dependencies
            non_index_deps = []  # non-index dependencies are kept unchanged

            # Requirement(dep_str) will be able to parse PEP requirement strings,
            # but not UC Volumes and local paths.
            for dep_str in python_env._dependencies:
                try:
                    req = Requirement(dep_str)
                    pkg_name = req.name.lower()
                    specs[pkg_name] = req.specifier
                except Exception as e:
                    # Parsing failed - non-index dependency
                    non_index_deps.append(dep_str)

            # Update or add auto-detected dependencies
            for name, dist in new_dependencies.items():
                pkg_name = name.lower()

                # Dependency is already included and has a non-empty SpecifierSet
                if pkg_name in specs and specs[pkg_name]:
                    logger.debug(
                        f"Skipping update for {pkg_name}: existing constraint "
                        f"'{pkg_name}{specs[pkg_name]}' is unchanged"
                    )
                else:
                    # No version constraint - update with exact version
                    specs[pkg_name] = SpecifierSet(f"=={dist.version}")
                    logger.info(f"Updated {pkg_name} with auto-detected version =={dist.version}")

            # Rebuild dependency list: reconstruct requirement strings
            requirement_strings = []
            for pkg_name, specifier in specs.items():
                if specifier:
                    requirement_strings.append(f"{pkg_name}{specifier}")
                else:
                    requirement_strings.append(pkg_name)

            python_env._dependencies = requirement_strings + non_index_deps
