#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2020-present Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from typing import Any, Iterable, TypeVar

from google.protobuf.descriptor import FieldDescriptor
from google.protobuf.message import Message


T = TypeVar("T")


def find_all_instances(m: Any, ty: tuple[type[T], ...]) -> Iterable[T]:
    """Find all instances of given types in a protobuf message recursively."""
    if isinstance(m, ty):
        yield m

    if not isinstance(m, Message):
        return

    for desc, value in m.ListFields():
        if desc.label == FieldDescriptor.LABEL_REPEATED:
            for item in value:
                yield from find_all_instances(item, ty)
        else:
            yield from find_all_instances(value, ty)
