from __future__ import annotations

import httpx

from .models import (
    Balance,
    CustomerBalanceResponse,
    CustomerInvoiceDetail,
    CustomerInvoiceResponse,
    CustomerWithdrawalCreateRequest,
    CustomerWithdrawalResponse,
    InvoiceCreateRequest,
    InvoiceDetail,
    InvoiceResponse,
    InvoiceStatusResponse,
    PaginatedCustomerInvoiceDetailList,
    PaginatedCustomerTransactionResponseList,
    PaginatedCustomerWithdrawalResponseList,
    PaginatedInvoiceDetailList,
    PaginatedPaymentLinkList,
    PaginatedTransactionList,
    PaymentLink,
    PaymentLinkCreateRequest,
    PaymentLinkPayInputRequest,
    PaymentLinkPublic,
    PublicInvoiceStatus,
    Withdrawal,
    WithdrawalCreateRequest,
)


class PaymentsPaymentsAPI:
    """API endpoints for Payments."""

    def __init__(self, client: httpx.AsyncClient):
        """Initialize sub-client with shared httpx client."""
        self._client = client

    async def balance_retrieve(self) -> Balance:
        """
        Mixin for views that need owner-scoped queries. Supports both API key
        auth and JWT auth. Use in payment admin views to get projects/keys for
        the current owner.
        """
        url = "/api/payments/balance/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Balance.model_validate(response.json())


    async def customer_balance_retrieve(self) -> CustomerBalanceResponse:
        """
        GET /customer/balance/ — customer balance (always 200).
        """
        url = "/api/payments/customer/balance/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return CustomerBalanceResponse.model_validate(response.json())


    async def customer_invoices_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedCustomerInvoiceDetailList]:
        """
        GET /customer/invoices/ — payment history.
        """
        url = "/api/payments/customer/invoices/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedCustomerInvoiceDetailList.model_validate(response.json())


    async def customer_invoices_retrieve(self, id: str) -> CustomerInvoiceDetail:
        """
        GET /customer/invoices/{id}/ — invoice detail.
        """
        url = f"/api/payments/customer/invoices/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return CustomerInvoiceDetail.model_validate(response.json())


    async def customer_profile_retrieve(self) -> None:
        """
        GET /customer/profile/ — customer profile (always 200).
        """
        url = "/api/payments/customer/profile/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return None


    async def customer_transactions_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedCustomerTransactionResponseList]:
        """
        GET /customer/transactions/ — transaction history.
        """
        url = "/api/payments/customer/transactions/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedCustomerTransactionResponseList.model_validate(response.json())


    async def customer_withdrawals_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedCustomerWithdrawalResponseList]:
        """
        GET /customer/withdrawals/ — withdrawals list.
        """
        url = "/api/payments/customer/withdrawals/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedCustomerWithdrawalResponseList.model_validate(response.json())


    async def customer_withdrawals_create_create(
        self,
        data: CustomerWithdrawalCreateRequest,
    ) -> CustomerWithdrawalResponse:
        """
        POST /customer/withdrawals/create/ — create withdrawal.
        """
        url = "/api/payments/customer/withdrawals/create/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return CustomerWithdrawalResponse.model_validate(response.json())


    async def invoices_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedInvoiceDetailList]:
        url = "/api/payments/invoices/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedInvoiceDetailList.model_validate(response.json())


    async def invoices_retrieve(self, id: str) -> InvoiceDetail:
        url = f"/api/payments/invoices/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return InvoiceDetail.model_validate(response.json())


    async def invoices_cancel_create(self, id: str) -> InvoiceDetail:
        url = f"/api/payments/invoices/{id}/cancel/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return InvoiceDetail.model_validate(response.json())


    async def invoices_status_retrieve(self, id: str) -> InvoiceStatusResponse:
        url = f"/api/payments/invoices/{id}/status/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return InvoiceStatusResponse.model_validate(response.json())


    async def invoices_create_create(self, data: InvoiceCreateRequest) -> InvoiceResponse:
        """
        Mixin for views that need owner-scoped queries. Supports both API key
        auth and JWT auth. Use in payment admin views to get projects/keys for
        the current owner.
        """
        url = "/api/payments/invoices/create/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return InvoiceResponse.model_validate(response.json())


    async def links_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedPaymentLinkList]:
        url = "/api/payments/links/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedPaymentLinkList.model_validate(response.json())


    async def links_create_create(self, data: PaymentLinkCreateRequest) -> PaymentLink:
        """
        Mixin for views that need owner-scoped queries. Supports both API key
        auth and JWT auth. Use in payment admin views to get projects/keys for
        the current owner.
        """
        url = "/api/payments/links/create/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaymentLink.model_validate(response.json())


    async def public_invoices_status_retrieve(self, id: str) -> PublicInvoiceStatus:
        """
        GET /invoices/{id}/status/ — public polling endpoint.
        """
        url = f"/api/payments/public/invoices/{id}/status/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PublicInvoiceStatus.model_validate(response.json())


    async def public_links_retrieve(self, id: str) -> PaymentLinkPublic:
        """
        GET /links/{id}/ — public.
        """
        url = f"/api/payments/public/links/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaymentLinkPublic.model_validate(response.json())


    async def public_links_pay_create(
        self,
        id: str,
        data: PaymentLinkPayInputRequest,
    ) -> CustomerInvoiceResponse:
        """
        POST /links/{id}/pay/ — public.
        """
        url = f"/api/payments/public/links/{id}/pay/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return CustomerInvoiceResponse.model_validate(response.json())


    async def transactions_list(
        self,
        ordering: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        search: str | None = None,
    ) -> list[PaginatedTransactionList]:
        url = "/api/payments/transactions/"
        _params = {
            k: v for k, v in {
                "ordering": ordering,
                "page": page,
                "page_size": page_size,
                "search": search,
            }.items() if v is not None
        }
        response = await self._client.get(url, params=_params)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return PaginatedTransactionList.model_validate(response.json())


    async def withdrawals_create(self, data: WithdrawalCreateRequest) -> Withdrawal:
        """
        Mixin for views that need owner-scoped queries. Supports both API key
        auth and JWT auth. Use in payment admin views to get projects/keys for
        the current owner.
        """
        url = "/api/payments/withdrawals/"
        response = await self._client.post(url, json=data.model_dump(mode="json", exclude_unset=True, exclude_none=True))
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Withdrawal.model_validate(response.json())


    async def withdrawals_retrieve(self, id: str) -> Withdrawal:
        url = f"/api/payments/withdrawals/{id}/"
        response = await self._client.get(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Withdrawal.model_validate(response.json())


    async def withdrawals_cancel_create(self, id: str) -> Withdrawal:
        url = f"/api/payments/withdrawals/{id}/cancel/"
        response = await self._client.post(url)
        if not response.is_success:
            try:
                error_body = response.json()
            except Exception:
                error_body = response.text
            msg = f"{response.status_code}: {error_body}"
            raise httpx.HTTPStatusError(
                msg, request=response.request, response=response
            )
        return Withdrawal.model_validate(response.json())


