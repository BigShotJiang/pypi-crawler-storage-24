"""Tests for csvjson core logic."""

import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from csvjson.core import csv_to_json, json_to_csv

passed = 0
failed = 0

def test(name, fn):
    global passed, failed
    try:
        fn()
        print(f"  ✅  {name}")
        passed += 1
    except AssertionError as e:
        print(f"  ❌  {name}: {e}")
        failed += 1

FLAT_CSV = "name,age,city\nAlice,30,NYC\nBob,25,LA"
NESTED_CSV = "name,address.city,address.zip,scores.math\nAlice,NYC,10001,95\nBob,LA,90001,88"

print("\nRunning tests...\n")

def test_flat_types():
    out = csv_to_json(FLAT_CSV)
    assert out[0]["name"] == "Alice"
    assert out[0]["age"] == 30, f"expected int 30, got {out[0]['age']!r}"
    assert out[1]["city"] == "LA"

def test_nested_csv_to_json():
    out = csv_to_json(NESTED_CSV)
    assert out[0]["address"]["city"] == "NYC"
    assert out[0]["address"]["zip"] == 10001
    assert out[0]["scores"]["math"] == 95

def test_json_to_csv_flat():
    data = [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]
    out = json_to_csv(data)
    assert "name,age" in out
    assert "Alice,30" in out

def test_json_to_csv_nested():
    data = [{"name": "Alice", "address": {"city": "NYC", "zip": 10001}}]
    out = json_to_csv(data)
    assert "address.city" in out
    assert "NYC" in out

def test_roundtrip():
    original = csv_to_json(NESTED_CSV)
    csv_out = json_to_csv(original)
    back = csv_to_json(csv_out)
    assert back[0]["address"]["city"] == "NYC"
    assert back[1]["scores"]["math"] == 88

def test_type_coercion():
    csv_text = "flag,value,empty\ntrue,3.14,"
    out = csv_to_json(csv_text)
    assert out[0]["flag"] is True
    assert out[0]["value"] == 3.14
    assert out[0]["empty"] is None

def test_single_object_json():
    out = json_to_csv({"name": "Alice", "age": 30})
    assert "Alice" in out

test("flat CSV → JSON: type coercion", test_flat_types)
test("nested CSV → JSON: nesting works", test_nested_csv_to_json)
test("JSON → CSV: flat output", test_json_to_csv_flat)
test("JSON → CSV: nested flattened", test_json_to_csv_nested)
test("roundtrip CSV → JSON → CSV", test_roundtrip)
test("type coercion: bool, float, None", test_type_coercion)
test("single dict (not list) input", test_single_object_json)

print(f"\n{passed} passed, {failed} failed\n")
if failed:
    sys.exit(1)
