# csvjson

Bidirectional CSV ↔ JSON converter with nested JSON support — zero dependencies, pure Python.

## Install

```bash
# Recommended: uv tool install (isolated, globally available)
uv tool install csvjson

# Or: pip
pip install csvjson
```

## Usage

### Interactive mode
```bash
csvjson
```

### File mode
```bash
# CSV → JSON
csvjson csv2json input.csv
csvjson csv2json input.csv -o output.json

# JSON → CSV
csvjson json2csv input.json
csvjson json2csv input.json -o output.csv
```

## Nested JSON via dot-notation

CSV headers with dots become nested JSON — and flatten back automatically.

**Input CSV:**
```
name,address.city,address.zip,scores.math
Alice,NYC,10001,95
Bob,LA,90001,88
```

**Output JSON:**
```json
[
  { "name": "Alice", "address": { "city": "NYC", "zip": 10001 }, "scores": { "math": 95 } },
  { "name": "Bob",   "address": { "city": "LA",  "zip": 90001 }, "scores": { "math": 88 } }
]
```

## Type coercion

| CSV value        | Python type |
|------------------|-------------|
| `42`             | `int`       |
| `3.14`           | `float`     |
| `true` / `false` | `bool`      |
| empty            | `None`      |
| anything else    | `str`       |

## Publish to PyPI

```bash
uv build    # creates dist/
uv publish  # uploads to PyPI (needs PYPI_TOKEN)
```

## License

MIT
