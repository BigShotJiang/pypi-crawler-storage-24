"""Core bidirectional CSV ↔ JSON conversion with nested support."""

from __future__ import annotations

import csv
import io
import json


# ── Nested helpers ────────────────────────────────────────────────────────────

def _set_nested(obj: dict, dot_key: str, value: str) -> None:
    """Set 'address.city' = 'NYC' as nested keys on obj."""
    keys = dot_key.split(".")
    cur = obj
    for key in keys[:-1]:
        cur = cur.setdefault(key, {})
    cur[keys[-1]] = _coerce(value)


def _coerce(value: str):
    """Convert CSV string to the most appropriate Python type."""
    if value == "":
        return None
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    try:
        as_int = int(value)
        # avoid coercing strings like "007" or "1e5"
        if str(as_int) == value:
            return as_int
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def _flatten(obj: dict, prefix: str = "", result: dict | None = None) -> dict:
    """Flatten {'address': {'city': 'NYC'}} → {'address.city': 'NYC'}."""
    if result is None:
        result = {}
    for k, v in obj.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            _flatten(v, key, result)
        elif isinstance(v, list):
            result[key] = json.dumps(v)
        else:
            result[key] = "" if v is None else str(v)
    return result


# ── CSV → JSON ────────────────────────────────────────────────────────────────

def csv_to_json(text: str) -> list[dict]:
    """Parse CSV text into a list of (possibly nested) dicts."""
    reader = csv.DictReader(io.StringIO(text.strip()))
    rows = []
    for raw_row in reader:
        obj: dict = {}
        for key, value in raw_row.items():
            _set_nested(obj, key.strip(), value or "")
        rows.append(obj)
    return rows


# ── JSON → CSV ────────────────────────────────────────────────────────────────

def json_to_csv(data: list | dict) -> str:
    """Serialize a list of dicts (or a single dict) to CSV text."""
    if isinstance(data, dict):
        data = [data]
    if not data:
        return ""

    flat_rows = [_flatten(row) for row in data]

    # Union of all headers, preserving first-seen order
    seen: dict[str, None] = {}
    for row in flat_rows:
        seen.update(dict.fromkeys(row))
    headers = list(seen)

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=headers, extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in flat_rows:
        writer.writerow({h: row.get(h, "") for h in headers})

    return output.getvalue()
