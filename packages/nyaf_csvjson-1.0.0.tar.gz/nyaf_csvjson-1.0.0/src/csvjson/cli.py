"""CLI entrypoint for csvjson."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from csvjson.core import csv_to_json, json_to_csv


# ── Colours ───────────────────────────────────────────────────────────────────

RESET  = "\033[0m"
BOLD   = "\033[1m"
CYAN   = "\033[36m"
GREEN  = "\033[32m"
YELLOW = "\033[33m"
RED    = "\033[31m"
DIM    = "\033[2m"


def c(color: str, text: str) -> str:
    return f"{color}{text}{RESET}"


# ── Helpers ───────────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def write_file(path: str, content: str) -> None:
    Path(path).write_text(content, encoding="utf-8")
    print(c(GREEN, f"✅  Saved → {path}"))


def save_prompt(content: str) -> None:
    ans = input(f"\n{YELLOW}Save to file? (Enter filename or press Enter to skip): {RESET}").strip()
    if ans:
        write_file(ans, content)


def read_multiline(prompt: str) -> str:
    print(c(DIM, f"{prompt} (type END on a new line when done)"))
    lines = []
    while True:
        line = input()
        if line.strip() == "END":
            break
        lines.append(line)
    return "\n".join(lines)


def show_examples() -> None:
    print(f"""
{BOLD}── CSV with flat keys ──────────────────────────────{RESET}
name,age,city
Alice,30,NYC
Bob,25,LA

{BOLD}↓  CSV → JSON:{RESET}
[
  {{"name": "Alice", "age": 30, "city": "NYC"}},
  {{"name": "Bob",   "age": 25, "city": "LA" }}
]

{BOLD}── CSV with nested (dot-notation) keys ─────────────{RESET}
name,address.city,address.zip,scores.math
Alice,NYC,10001,95
Bob,LA,90001,88

{BOLD}↓  CSV → JSON:{RESET}
[
  {{"name":"Alice","address":{{"city":"NYC","zip":10001}},"scores":{{"math":95}}}},
  {{"name":"Bob",  "address":{{"city":"LA", "zip":90001}},"scores":{{"math":88}}}}
]

{BOLD}── JSON → CSV flattens nested keys automatically ───{RESET}
""")


# ── Arg mode ──────────────────────────────────────────────────────────────────

def run_arg_mode(args: argparse.Namespace) -> None:
    raw = read_file(args.input)

    if args.command == "csv2json":
        result = json.dumps(csv_to_json(raw), indent=2, ensure_ascii=False)
    else:
        result = json_to_csv(json.loads(raw))

    if args.output:
        write_file(args.output, result)
    else:
        print(result)


# ── Interactive mode ──────────────────────────────────────────────────────────

def run_interactive() -> None:
    print(f"""
{CYAN}{BOLD}╔══════════════════════════════════════╗
║    CSV ↔ JSON Bidirectional Tool     ║
╚══════════════════════════════════════╝{RESET}
{DIM}Supports nested JSON via dot-notation keys{RESET}
""")

    while True:
        print(f"""{BOLD}What do you want to do?{RESET}
  {CYAN}1{RESET}  CSV  → JSON  (from file)
  {CYAN}2{RESET}  JSON → CSV   (from file)
  {CYAN}3{RESET}  CSV  → JSON  (paste inline)
  {CYAN}4{RESET}  JSON → CSV   (paste inline)
  {CYAN}5{RESET}  Show examples
  {CYAN}q{RESET}  Quit
""")
        choice = input(f"{CYAN}> {RESET}").strip()

        if choice == "q":
            print(c(DIM, "\nBye!\n"))
            break

        try:
            if choice in ("1", "2"):
                path = input(f"{YELLOW}Enter file path: {RESET}").strip()
                raw = read_file(path)
                if choice == "1":
                    result = json.dumps(csv_to_json(raw), indent=2, ensure_ascii=False)
                    print(f"\n{GREEN}{BOLD}── JSON Output ──{RESET}\n{result}\n")
                else:
                    result = json_to_csv(json.loads(raw))
                    print(f"\n{GREEN}{BOLD}── CSV Output ──{RESET}\n{result}\n")
                save_prompt(result)

            elif choice == "3":
                raw = read_multiline("Paste your CSV")
                result = json.dumps(csv_to_json(raw), indent=2, ensure_ascii=False)
                print(f"\n{GREEN}{BOLD}── JSON Output ──{RESET}\n{result}\n")
                save_prompt(result)

            elif choice == "4":
                raw = read_multiline("Paste your JSON")
                result = json_to_csv(json.loads(raw))
                print(f"\n{GREEN}{BOLD}── CSV Output ──{RESET}\n{result}\n")
                save_prompt(result)

            elif choice == "5":
                show_examples()

            else:
                print(c(RED, "Invalid choice.\n"))

        except FileNotFoundError as e:
            print(c(RED, f"File not found: {e}\n"))
        except (json.JSONDecodeError, ValueError) as e:
            print(c(RED, f"Parse error: {e}\n"))
        except KeyboardInterrupt:
            print(c(DIM, "\n\nBye!\n"))
            break


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    if len(sys.argv) < 2:
        run_interactive()
        return

    parser = argparse.ArgumentParser(
        prog="csvjson",
        description="Bidirectional CSV ↔ JSON converter with nested JSON support",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    for cmd, help_text in [
        ("csv2json", "Convert CSV file to JSON"),
        ("json2csv", "Convert JSON file to CSV"),
    ]:
        p = sub.add_parser(cmd, help=help_text)
        p.add_argument("input", help="Input file path")
        p.add_argument("-o", "--output", help="Output file path (default: stdout)")

    args = parser.parse_args()
    run_arg_mode(args)


if __name__ == "__main__":
    main()
