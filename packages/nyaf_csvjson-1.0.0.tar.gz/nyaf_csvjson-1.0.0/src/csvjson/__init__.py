"""csvjson — bidirectional CSV ↔ JSON converter."""

__version__ = "1.0.0"
