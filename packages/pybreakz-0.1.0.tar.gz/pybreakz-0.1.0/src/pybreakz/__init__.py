"""pybreakz - A CLI debugger for Claude Code."""

__version__ = "0.1.0"
