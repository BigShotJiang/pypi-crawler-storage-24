"""Skills system for Sage."""
