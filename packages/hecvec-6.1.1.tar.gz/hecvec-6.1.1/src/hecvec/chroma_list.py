"""
List Chroma collections. One module = one responsibility: inspect collections on a Chroma server.
Requires: pip install hecvec[chroma] (chromadb).
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000


def list_collections(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
) -> list[tuple[str, int]]:
    """
    List all collection names and their document counts on a Chroma server.
    Returns [(name, count), ...].
    """
    import chromadb
    client = chromadb.HttpClient(host=host, port=port)
    return list_collections_from_client(client)


def list_collections_from_client(client: "chromadb.api.client.Client") -> list[tuple[str, int]]:
    """
    List all collection names and their document counts from any Chroma client
    Returns [(name, count), ...].
    """
    return [(c.name, c.count()) for c in client.list_collections()]
