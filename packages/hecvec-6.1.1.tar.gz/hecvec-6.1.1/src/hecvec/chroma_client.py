"""
Chroma client and collection operations. One module = one responsibility: connect and add documents.
Requires: pip install hecvec (chromadb). Connects only to a Chroma server; server must be running.
"""
from __future__ import annotations

import logging
import socket
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000

logger = logging.getLogger(__name__)


def _is_port_listening(host: str, port: int, timeout: float = 2.0) -> bool:
    """Return True if something is listening on host:port."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, socket.error):
        return False


def get_client(
    host: str = DEFAULT_HOST,
    port: int = DEFAULT_PORT,
    *,
    auth: str | None = None,
):
    """
    Return a Chroma HttpClient connected to the server at host:port.
    Raises RuntimeError if nothing is listening. A Chroma server must be running.

    If auth is provided, it should be "username:password" for Chroma Basic Auth.
    """
    import chromadb
    from chromadb.config import Settings
    logger.info("[5/5] Checking if something is listening at %s:%s...", host, port)
    if not _is_port_listening(host, port):
        logger.error("[5/5] Nothing is listening at %s:%s", host, port)
        raise RuntimeError(
            f"Nothing is listening on {host}:{port}. A Chroma server is required. "
            f"Start one with: docker run -p 8000:8000 chromadb/chroma"
        )
    logger.info("[5/5] TCP port is open at %s:%s; creating Chroma client...", host, port)
    settings = None
    if auth:
        settings = Settings(
            chroma_client_auth_provider="chromadb.auth.basic_authn.BasicAuthClientProvider",
            chroma_client_auth_credentials=auth,
        )
    client = chromadb.HttpClient(host=host, port=port, settings=settings)
    # Verify this is actually a working Chroma server (not just an open port).
    try:
        if hasattr(client, "heartbeat"):
            client.heartbeat()  # type: ignore[attr-defined]
        else:
            client.list_collections()
        logger.info("[5/5] Chroma server health check OK at %s:%s", host, port)
    except Exception as e:
        raise RuntimeError(
            f"Connected to {host}:{port} but Chroma health check failed. "
            f"This usually means the port is open but it is not a Chroma server, "
            f"or auth is required/incorrect. Original error: {e!r}"
        ) from e
    return client


def get_or_create_collection(
    client: "chromadb.api.client.Client",
    name: str,
    metadata: dict | None = None,
):
    """Get or create a collection (cosine similarity by default)."""
    if metadata is None:
        metadata = {"hnsw:space": "cosine"}
    return client.get_or_create_collection(name=name, metadata=metadata)


def add_documents(
    client: "chromadb.api.client.Client",
    collection_name: str,
    ids: list[str],
    embeddings: list[list[float]],
    documents: list[str],
) -> dict:
    """
    Add documents to a collection. If dimension mismatch, deletes and recreates the collection.
    Returns {"collection_existed": bool} so the caller can log whether the collection was pre-existing.
    """
    import chromadb
    existing_names = [c.name for c in client.list_collections()]
    collection_existed = collection_name in existing_names
    coll = get_or_create_collection(client, collection_name)
    try:
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
    except chromadb.errors.InvalidArgumentError as e:
        if "dimension" not in str(e).lower():
            raise
        client.delete_collection(name=collection_name)
        coll = client.create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        coll.add(ids=ids, embeddings=embeddings, documents=documents)
        collection_existed = False  # we recreated it
    return {"collection_existed": collection_existed}
