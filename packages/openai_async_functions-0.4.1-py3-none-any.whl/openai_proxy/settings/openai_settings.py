from pydantic import HttpUrl
from pydantic_settings import SettingsConfigDict

from openai_proxy.settings.env_settings import EnvSettings


class OpenAISettings(EnvSettings):
    token: str
    base_url: HttpUrl
    default_model: str | None = None
    max_message_size: int = 100000


class OfficialOpenAISettings(OpenAISettings):
    model_config = SettingsConfigDict(
        env_prefix="OFFICIAL_OPENAI__",
    )

    base_url: HttpUrl = HttpUrl("https://api.openai.com/v1")
    default_model: str = "gpt-4.1"


class DeepseekOpenAISettings(OpenAISettings):
    model_config = SettingsConfigDict(
        env_prefix="DEEPSEEK_OPENAI__",
    )

    base_url: HttpUrl = HttpUrl("https://api.deepseek.com/v1")
    default_model: str = "deepseek-chat"


class PolzaOpenAISettings(OpenAISettings):
    model_config = SettingsConfigDict(
        env_prefix="POLZA_OPENAI__",
    )

    base_url: HttpUrl = HttpUrl("https://api.polza.ai/api/v1")
