"""Tests for _handle_action_request() — verifies all ~88 action types dispatch correctly.

This is the largest and highest-value test file. Each test sends an action
request through the captured callback and verifies the correct runtime
manager method is called with the right arguments.
"""
from __future__ import annotations

import asyncio
import pytest
from unittest.mock import AsyncMock

from nookplot_runtime.autonomous import AutonomousAgent
from tests.helpers.mock_runtime import create_mock_runtime


@pytest.fixture
def agent_setup():
    """Create a started agent with mock runtime and return components."""
    runtime, captured = create_mock_runtime()
    agent = AutonomousAgent(runtime, verbose=False)
    agent.start()
    return runtime, captured, agent


async def dispatch(captured, action_type, payload=None, suggested_content=None, action_id=None):
    """Send an action request through the captured callback."""
    event = {"data": {
        "actionType": action_type,
        "payload": payload or {},
        "suggestedContent": suggested_content,
        "actionId": action_id,
    }}
    await captured["action_cb"](event)


# ================================================================
#  On-chain via runtime managers
# ================================================================

class TestOnChainViaManagers:
    @pytest.mark.asyncio
    async def test_create_post(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_post", {"community": "defi"}, "My post body")
        runtime.memory.publish_knowledge.assert_called_once()
        call_kw = runtime.memory.publish_knowledge.call_args
        assert call_kw.kwargs.get("community") == "defi" or call_kw[1].get("community") == "defi"

    @pytest.mark.asyncio
    async def test_publish_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "publish", {"community": "ai"}, "Post content")
        runtime.memory.publish_knowledge.assert_called_once()

    @pytest.mark.asyncio
    async def test_post_reply(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "post_reply", {"parentCid": "QmParent", "community": "general"}, "My reply")
        runtime.memory.publish_comment.assert_called_once()

    @pytest.mark.asyncio
    async def test_vote(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "vote", {"cid": "QmPost1", "voteType": "up"})
        runtime.memory.vote.assert_called_once()

    @pytest.mark.asyncio
    async def test_follow_agent(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "follow_agent", {"targetAddress": "0xTARGET"})
        runtime.social.follow.assert_called_once_with("0xTARGET")

    @pytest.mark.asyncio
    async def test_attest_agent(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "attest_agent", {"targetAddress": "0xTARGET"}, "Great work")
        runtime.social.attest.assert_called_once_with("0xTARGET", "Great work")


# ================================================================
#  On-chain via prepareSignRelay (_http.request + _sign_and_relay)
# ================================================================

class TestOnChainViaPrepareSignRelay:
    @pytest.mark.asyncio
    async def test_create_community(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_community", {"slug": "test-com", "name": "Test Com", "description": "desc"}, "desc")
        runtime._http.request.assert_called()
        call_args = runtime._http.request.call_args_list[0]
        assert call_args[0][1] == "/v1/prepare/community"
        runtime.memory._sign_and_relay.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_project(self, agent_setup):
        runtime, captured, agent = agent_setup
        runtime._http.request = AsyncMock(side_effect=[
            {"discoveryId": "disc_1"},  # POST /v1/projects/discover
            {"to": "0xForwarder", "data": "0x..."},  # POST /v1/prepare/project
        ])
        await dispatch(captured, "create_project", {"projectId": "my-proj", "name": "My Project"}, "A cool project")
        assert runtime._http.request.call_count == 2
        runtime.memory._sign_and_relay.assert_called_once()

    @pytest.mark.asyncio
    async def test_propose_guild(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "propose_guild", {"name": "Guild A", "members": ["0xA", "0xB"]}, "A guild for AI")
        runtime._http.request.assert_called()
        call_args = runtime._http.request.call_args_list[0]
        assert call_args[0][1] == "/v1/prepare/guild"
        runtime.memory._sign_and_relay.assert_called_once()

    @pytest.mark.asyncio
    async def test_propose_clique_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "propose_clique", {"name": "Clique B", "members": ["0xC", "0xD"]})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_claim_bounty(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "claim_bounty", {"bountyId": "b_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/v1/prepare/bounty/" in call_path
        assert "/claim" in call_path

    @pytest.mark.asyncio
    async def test_claim_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "claim", {"bountyId": "b_2"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_create_bounty(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_bounty", {
            "title": "Fix bug",
            "tokenRewardAmount": "100",
            "community": "dev",
        }, "Fix the login bug")
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert call_path == "/v1/prepare/bounty"

    @pytest.mark.asyncio
    async def test_create_bundle(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_bundle", {"name": "Bundle A", "cids": ["Qm1", "Qm2"]})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert call_path == "/v1/prepare/bundle"

    @pytest.mark.asyncio
    async def test_approve_bounty_claimer(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "approve_bounty_claimer", {"bountyId": "b_1", "claimer": "0xCLAIMER"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_approve_bounty_work(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "approve_bounty_work", {"bountyId": "b_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/approve" in call_path

    @pytest.mark.asyncio
    async def test_dispute_bounty_work(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "dispute_bounty_work", {"bountyId": "b_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_cancel_bounty(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "cancel_bounty", {"bountyId": "b_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_unclaim_bounty(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "unclaim_bounty", {"bountyId": "b_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_deploy_preview(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "deploy_preview", {"projectId": "proj_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_join_guild(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "join_guild", {"guildId": "g_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/approve" in call_path

    @pytest.mark.asyncio
    async def test_reject_guild(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "reject_guild", {"guildId": "g_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_leave_guild(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "leave_guild", {"guildId": "g_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_list_service(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "list_service", {"title": "My Service", "category": "ai"}, "My AI Service")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_create_listing_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_listing", {"title": "My Service"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_update_service(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "update_service", {"listingId": 1, "title": "Updated"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_create_agreement(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_agreement", {"listingId": 1, "deadline": 9999999}, "Build a widget")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_deliver_work(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "deliver_work", {"agreementId": 1}, "QmDelivery")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_settle_agreement(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "settle_agreement", {"agreementId": 1})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_dispute_agreement(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "dispute_agreement", {"agreementId": 1})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_cancel_agreement(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "cancel_agreement", {"agreementId": 1})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_expire_dispute(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "expire_dispute", {"agreementId": 1})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_expire_delivered(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "expire_delivered", {"agreementId": 1})
        runtime._http.request.assert_called()


# ================================================================
#  Off-chain messaging
# ================================================================

class TestOffChainMessaging:
    @pytest.mark.asyncio
    async def test_reply_channel(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "reply", {"channelId": "ch1"}, "Hello channel")
        runtime.channels.send.assert_called_once_with("ch1", "Hello channel")

    @pytest.mark.asyncio
    async def test_reply_dm(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "reply", {"to": "0xABC"}, "Hello DM")
        runtime.inbox.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_dm(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "send_dm", {"recipientAddress": "0xBBB"}, "Hi there")
        runtime.inbox.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_message_to_address(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "send_message", {"to": "0xCCC"}, "Hey!")
        runtime.inbox.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_send_message_to_channel(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "send_message", {"channelId": "ch2"}, "Hey everyone!")
        runtime.channels.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_acknowledge(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "acknowledge", {"projectId": "proj1"}, "Got it!")
        runtime.channels.send_to_project.assert_called_once()

    @pytest.mark.asyncio
    async def test_accept(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "accept", {"projectId": "proj1"}, "On it!")
        runtime.channels.send_to_project.assert_called_once()

    @pytest.mark.asyncio
    async def test_execute_channel(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "execute", {"channelId": "ch3"}, "Done!")
        runtime.channels.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_execute_dm(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "execute", {"to": "0xDDD"}, "Completed!")
        runtime.inbox.send.assert_called_once()

    @pytest.mark.asyncio
    async def test_propose_collab(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "propose_collab", {"targetAddress": "0xEEE"}, "Let's work together!")
        runtime.inbox.send.assert_called_once()


# ================================================================
#  Off-chain social
# ================================================================

class TestOffChainSocial:
    @pytest.mark.asyncio
    async def test_follow(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "follow", {"targetAddress": "0xFOLLOW"})
        runtime.social.follow.assert_called_once_with("0xFOLLOW")

    @pytest.mark.asyncio
    async def test_follow_back(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "follow_back", {"senderAddress": "0xFOLLOWBACK"})
        runtime.social.follow.assert_called_once()

    @pytest.mark.asyncio
    async def test_attest(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "attest", {"targetAddress": "0xATTEST"}, "Great contributor")
        runtime.social.attest.assert_called_once()

    @pytest.mark.asyncio
    async def test_attest_back(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "attest_back", {"senderAddress": "0xATTESTBACK"}, "Valued collaborator")
        runtime.social.attest.assert_called_once()


# ================================================================
#  Off-chain projects
# ================================================================

class TestOffChainProjects:
    @pytest.mark.asyncio
    async def test_review_commit(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "review", {"projectId": "p1", "commitId": "c1"}, "Looks good")
        runtime.projects.submit_review.assert_called_once()

    @pytest.mark.asyncio
    async def test_comment(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "comment", {"projectId": "p1", "commitId": "c1"}, "Nice refactor")
        runtime.projects.submit_review.assert_called_once()

    @pytest.mark.asyncio
    async def test_review_commit_action(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "review_commit", {
            "projectId": "p1", "commitId": "c1", "verdict": "approve", "body": "LGTM",
        })
        runtime.projects.submit_review.assert_called_once()

    @pytest.mark.asyncio
    async def test_request_ai_review(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "request_ai_review", {"projectId": "p1", "commitId": "c1"})
        runtime.projects.request_ai_review.assert_called_once()

    @pytest.mark.asyncio
    async def test_commit_files(self, agent_setup):
        runtime, captured, agent = agent_setup
        files = [{"path": "src/main.py", "content": "print('hello')"}]
        await dispatch(captured, "commit_files", {"projectId": "p1", "files": files}, "Add main")
        runtime.projects.commit_files.assert_called_once()

    @pytest.mark.asyncio
    async def test_gateway_commit_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        files = [{"path": "src/app.py", "content": "pass"}]
        await dispatch(captured, "gateway_commit", {"projectId": "p1", "files": files})
        runtime.projects.commit_files.assert_called_once()

    @pytest.mark.asyncio
    async def test_add_collaborator(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "add_collaborator", {"projectId": "p1", "collaboratorAddress": "0xCOLLAB"})
        runtime.projects.add_collaborator.assert_called_once()

    @pytest.mark.asyncio
    async def test_link_project_to_guild(self, agent_setup):
        runtime, captured, agent = agent_setup
        from unittest.mock import MagicMock
        guild_mock = MagicMock()
        guild_mock.members = [{"address": "0xMEMBER", "status": 2}]
        runtime.cliques.get = AsyncMock(return_value=guild_mock)
        await dispatch(captured, "link_project_to_guild", {"projectId": "p1", "guildId": 42})
        runtime.cliques.link_project.assert_called_once_with(42, "p1")
        runtime.projects.set_guild_attribution.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_task(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_task", {"projectId": "p1"}, "Implement feature X")
        runtime.projects.create_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_assign_task(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "assign_task", {
            "projectId": "p1", "taskId": "t1", "assigneeAddress": "0xWORKER",
        })
        runtime.projects.assign_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_complete_task(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "complete_task", {"projectId": "p1", "taskId": "t1"})
        runtime.projects.update_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_task(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "update_task", {"projectId": "p1", "taskId": "t1", "status": "in_progress"})
        runtime.projects.update_task.assert_called_once()


# ================================================================
#  Off-chain HTTP actions
# ================================================================

class TestOffChainHTTP:
    @pytest.mark.asyncio
    async def test_apply_bounty(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "apply_bounty", {"bountyId": "b_1"}, "I can do this")
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/apply" in call_path

    @pytest.mark.asyncio
    async def test_submit_bounty_work(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "submit_bounty_work", {"bountyId": "b_1"}, "Here's my work")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_approve_bounty_application(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "approve_bounty_application", {"bountyId": "b_1", "applicationId": "app_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/approve" in call_path

    @pytest.mark.asyncio
    async def test_reject_bounty_application(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "reject_bounty_application", {"bountyId": "b_1", "applicationId": "app_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_select_bounty_submission(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "select_bounty_submission", {"bountyId": "b_1", "submissionId": "sub_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_submit_review(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "submit_review", {"agreementId": 1, "rating": 5}, "Great work!")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_send_agreement_message(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "send_agreement_message", {"agreementId": 1, "messageType": "general"}, "Update on progress")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_accept_invitation(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "accept_invitation", {"invitationId": "inv_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/accept" in call_path

    @pytest.mark.asyncio
    async def test_decline_invitation(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "decline_invitation", {"invitationId": "inv_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/decline" in call_path

    @pytest.mark.asyncio
    async def test_grant(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "grant", {"projectId": "p1", "bountyId": "b_1", "requestId": "req_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/grant-access" in call_path

    @pytest.mark.asyncio
    async def test_deny(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "deny", {"projectId": "p1", "bountyId": "b_1", "requestId": "req_1"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/deny-access" in call_path


# ================================================================
#  Real-world actions
# ================================================================

class TestRealWorldActions:
    @pytest.mark.asyncio
    async def test_egress_request(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "egress_request", {"url": "https://api.example.com", "method": "GET"})
        runtime.tools.http_request.assert_called_once()

    @pytest.mark.asyncio
    async def test_http_request_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "http_request", {"url": "https://example.com"})
        runtime.tools.http_request.assert_called_once()

    @pytest.mark.asyncio
    async def test_execute_tool(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "execute_tool", {"toolName": "summarize", "args": {"text": "hello"}})
        runtime.tools.execute_tool.assert_called_once()

    @pytest.mark.asyncio
    async def test_connect_mcp_server(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "connect_mcp_server", {"serverUrl": "https://mcp.example.com", "serverName": "test-mcp"})
        runtime.tools.connect_mcp_server.assert_called_once()

    @pytest.mark.asyncio
    async def test_disconnect_mcp_server(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "disconnect_mcp_server", {"serverId": "srv_1"})
        runtime.tools.disconnect_mcp_server.assert_called_once()

    @pytest.mark.asyncio
    async def test_call_mcp_tool(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "call_mcp_tool", {"toolName": "search", "args": {"q": "test"}})
        runtime.tools.execute_tool.assert_called_once()

    @pytest.mark.asyncio
    async def test_use_mcp_tool_alias(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "use_mcp_tool", {"toolName": "translate"})
        runtime.tools.execute_tool.assert_called_once()

    @pytest.mark.asyncio
    async def test_register_webhook(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "register_webhook", {"source": "github"})
        runtime.tools.register_webhook.assert_called_once()


# ================================================================
#  Strategy / Knowledge actions
# ================================================================

class TestStrategyKnowledge:
    @pytest.mark.asyncio
    async def test_publish_insight(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "publish_insight", {"title": "My Insight", "body": "Content"})
        runtime.insights.publish.assert_called_once()

    @pytest.mark.asyncio
    async def test_cite_insight(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "cite_insight", {"insightId": "i_1"})
        runtime.insights.cite.assert_called_once()

    @pytest.mark.asyncio
    async def test_apply_insight(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "apply_insight", {"insightId": "i_1"})
        runtime.insights.apply.assert_called_once()

    @pytest.mark.asyncio
    async def test_workspace_create(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "workspace_create", {"name": "My Workspace"})
        runtime.workspaces.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_workspace_set(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "workspace_set", {"workspaceId": "ws_1", "key": "status", "value": "active"})
        runtime.workspaces.set_state.assert_called_once()

    @pytest.mark.asyncio
    async def test_workspace_snapshot(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "workspace_snapshot", {"workspaceId": "ws_1"})
        runtime.workspaces.create_snapshot.assert_called_once()

    @pytest.mark.asyncio
    async def test_propose_action(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "propose_action", {"workspaceId": "ws_1", "title": "Proposal A"})
        runtime.workspaces.create_proposal.assert_called_once()

    @pytest.mark.asyncio
    async def test_vote_proposal(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "vote_proposal", {"workspaceId": "ws_1", "proposalId": "prop_1", "vote": True})
        runtime.workspaces.vote.assert_called_once()

    @pytest.mark.asyncio
    async def test_cancel_proposal(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "cancel_proposal", {"workspaceId": "ws_1", "proposalId": "prop_1"})
        runtime.workspaces.cancel_proposal.assert_called_once()


# ================================================================
#  Treasury actions
# ================================================================

class TestTreasury:
    @pytest.mark.asyncio
    async def test_deposit_treasury(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "deposit_treasury", {"guildId": "g_1", "amount": "100"})
        runtime.guilds.deposit_treasury.assert_called_once()

    @pytest.mark.asyncio
    async def test_withdraw_treasury(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "withdraw_treasury", {"guildId": "g_1", "amount": "50"})
        runtime.guilds.withdraw_treasury.assert_called_once()

    @pytest.mark.asyncio
    async def test_fund_bounty_from_treasury(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "fund_bounty_from_treasury", {"guildId": "g_1", "bountyId": "b_1", "amount": "50"})
        runtime.guilds.fund_bounty_from_treasury.assert_called_once()

    @pytest.mark.asyncio
    async def test_distribute_revenue(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "distribute_revenue", {"guildId": "g_1"})
        runtime.guilds.distribute_revenue.assert_called_once()


# ================================================================
#  Swarm actions
# ================================================================

class TestSwarms:
    @pytest.mark.asyncio
    async def test_create_swarm(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_swarm", {"title": "Swarm A", "subtasks": [{"title": "Sub 1"}]})
        runtime.swarms.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_claim_subtask(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "claim_subtask", {"subtaskId": "st_1"})
        runtime.swarms.claim_subtask.assert_called_once()

    @pytest.mark.asyncio
    async def test_submit_swarm_result(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "submit_swarm_result", {"subtaskId": "st_1", "content": "Done"})
        runtime.swarms.submit_result.assert_called_once()

    @pytest.mark.asyncio
    async def test_aggregate_swarm(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "aggregate_swarm", {"swarmId": "sw_1"})
        runtime.swarms.aggregate.assert_called_once()


# ================================================================
#  Specialization actions
# ================================================================

class TestSpecialization:
    @pytest.mark.asyncio
    async def test_record_gap(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "record_gap", {"queryText": "How to fine-tune LLMs?"})
        runtime.specialization.record_gap.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_proficiency(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "update_proficiency", {"skillDomain": "python", "proficiency": 0.8})
        runtime.specialization.update_proficiency.assert_called_once()

    @pytest.mark.asyncio
    async def test_generate_recommendations(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "generate_recommendations", {})
        runtime.specialization.generate_recommendations.assert_called_once()

    @pytest.mark.asyncio
    async def test_dismiss_recommendation(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "dismiss_recommendation", {"recommendationId": "rec_1"})
        runtime.specialization.dismiss_recommendation.assert_called_once()


# ================================================================
#  Intent actions
# ================================================================

class TestIntents:
    @pytest.mark.asyncio
    async def test_create_intent(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "create_intent", {"title": "Build a dashboard"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_browse_intents(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "browse_intents", {"status": "open"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_submit_proposal(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "submit_proposal", {"intentId": "int_1"}, "I can build this")
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_accept_proposal(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "accept_proposal", {"intentId": "int_1", "proposalId": "prop_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_cancel_intent(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "cancel_intent", {"intentId": "int_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_complete_intent(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "complete_intent", {"intentId": "int_1"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_withdraw_proposal(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "withdraw_proposal", {"intentId": "int_1", "proposalId": "prop_1"})
        runtime._http.request.assert_called()


# ================================================================
#  Token launch
# ================================================================

class TestTokenLaunch:
    @pytest.mark.asyncio
    async def test_preview_token_launch(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "preview_token_launch", {"tokenName": "TestToken", "tokenTicker": "TT"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_launch_token(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "launch_token", {"tokenName": "TestToken", "tokenTicker": "TT"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_claim_clawnch_fees(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "claim_clawnch_fees", {"tokenAddress": "0xTOKEN"})
        runtime._http.request.assert_called()

    @pytest.mark.asyncio
    async def test_get_token_analytics(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "get_token_analytics", {"tokenAddress": "0xTOKEN"})
        runtime._http.request.assert_called()


# ================================================================
#  Oracle
# ================================================================

class TestOracle:
    @pytest.mark.asyncio
    async def test_query_oracle(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "query_oracle", {"entityType": "agent", "entityId": "0xABC"})
        runtime._http.request.assert_called()
        call_path = runtime._http.request.call_args_list[0][0][1]
        assert "/v1/oracle/" in call_path


# ================================================================
#  Matching
# ================================================================

class TestMatching:
    @pytest.mark.asyncio
    async def test_find_agents(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "find_agents", {"skills": ["python", "ml"]})
        runtime.matching.find_agents.assert_called_once()

    @pytest.mark.asyncio
    async def test_assemble_team(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "assemble_team", {}, "Build a dashboard team")
        runtime.matching.assemble_team.assert_called_once()


# ================================================================
#  Error cases
# ================================================================

class TestErrorCases:
    @pytest.mark.asyncio
    async def test_unknown_action_rejects_delegated(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "totally_unknown_action", {}, action_id="act_99")
        runtime.proactive.reject_delegated_action.assert_called_once()

    @pytest.mark.asyncio
    async def test_missing_required_field_rejects_delegated(self, agent_setup):
        runtime, captured, agent = agent_setup
        # vote requires cid
        await dispatch(captured, "vote", {}, action_id="act_100")
        runtime.proactive.reject_delegated_action.assert_called_once()

    @pytest.mark.asyncio
    async def test_action_id_completes_on_success(self, agent_setup):
        runtime, captured, agent = agent_setup
        await dispatch(captured, "reply", {"channelId": "ch1"}, "hello", action_id="act_101")
        runtime.proactive.complete_action.assert_called_once()
        call_args = runtime.proactive.complete_action.call_args
        assert call_args[0][0] == "act_101"

    @pytest.mark.asyncio
    async def test_error_in_action_rejects(self, agent_setup):
        runtime, captured, agent = agent_setup
        runtime.social.follow = AsyncMock(side_effect=Exception("Network error"))
        await dispatch(captured, "follow_agent", {"targetAddress": "0xFAIL"}, action_id="act_102")
        runtime.proactive.reject_delegated_action.assert_called_once()
