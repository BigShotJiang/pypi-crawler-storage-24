"""Pure state logic for the tray icon.

This module is deliberately free of GTK / AppIndicator3 imports so that
it can be unit-tested in environments where ``gi`` is not installed.
"""

from __future__ import annotations

from enum import StrEnum


# Icon name constants — resolved from the icon theme or a custom path.
class Icon(StrEnum):
    NEUTRAL = "forgewatch"
    ACTIVE = "forgewatch-active"
    ALERT = "forgewatch-alert"
    DISCONNECTED = "forgewatch-disconnected"


def get_icon_name(count: int, *, has_review_requested: bool, connected: bool) -> Icon:
    """Determine the icon name based on current state.

    Priority (highest to lowest):
    1. Disconnected → dimmed icon
    2. Has review-requested PRs → alert icon
    3. Has any PRs → active icon
    4. Otherwise → neutral icon
    """
    if not connected:
        return Icon.DISCONNECTED
    if count > 0 and has_review_requested:
        return Icon.ALERT
    if count > 0:
        return Icon.ACTIVE
    return Icon.NEUTRAL


def get_label(count: int) -> str:
    """Format the tray label from a PR count.

    Returns an empty string for zero (no label shown), otherwise
    the count as a string.
    """
    if count == 0:
        return ""
    return str(count)


def get_tooltip(count: int, *, has_review_requested: bool, connected: bool) -> str:
    """Build a dynamic tooltip string for the tray icon.

    Examples:
    - ``"ForgeWatch — Disconnected"``
    - ``"ForgeWatch — No open PRs"``
    - ``"ForgeWatch — 1 open PR"``
    - ``"ForgeWatch — 3 open PRs"``
    - ``"ForgeWatch — 3 open PRs (review requested)"``
    """
    if not connected:
        return "ForgeWatch \u2014 Disconnected"
    if count == 0:
        return "ForgeWatch \u2014 No open PRs"
    pr_word = "PR" if count == 1 else "PRs"
    base = f"ForgeWatch \u2014 {count} open {pr_word}"
    if has_review_requested:
        return f"{base} (review requested)"
    return base
