from __future__ import annotations

import ast
import copy
import os
import re
from dataclasses import dataclass
from pathlib import Path

import yaml

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python <3.11
    tomllib = None  # type: ignore[assignment]


@dataclass
class _SpecMetadata:
    name: str | None = None
    distpath: str | None = None
    onefile: bool | None = None
    icon: str | None = None
    version_file: str | None = None


@dataclass
class _DistromateConfig:
    app_name: str
    package_name: str
    package_executable: str
    package_target: str
    app_id: str | None = None
    package_icon: str | None = None
    package_description: str | None = None
    package_publisher: str | None = None


def _first_text(*values: object) -> str | None:
    for value in values:
        if isinstance(value, str):
            text = value.strip()
            if text:
                return text
        elif isinstance(value, (int, float)):
            return str(value)
    return None


def _is_mapping(value: object) -> bool:
    return isinstance(value, dict)


def _clone_value(value: object) -> object:
    return copy.deepcopy(value)


def _deep_merge(base: object, override: object) -> object:
    if not _is_mapping(base) or not _is_mapping(override):
        return _clone_value(override)

    result: dict[str, object] = dict(_clone_value(base))
    for key, value in override.items():
        if value is None:
            result[key] = None
            continue
        if _is_mapping(value) and _is_mapping(result.get(key)):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = _clone_value(value)
    return result


def _strip_none(value: object) -> object:
    if isinstance(value, list):
        return [_strip_none(item) for item in value]
    if _is_mapping(value):
        result: dict[str, object] = {}
        for key, child in value.items():
            if child is not None:
                result[key] = _strip_none(child)
        return result
    return value


def _normalize_config_path_value(base_dir: Path, value: object) -> str | None:
    text = _first_text(value)
    if not text:
        return None
    if os.path.isabs(text):
        return str(Path(text))
    return str((base_dir / text).resolve())


def _normalize_extra_entries(base_dir: Path, items: object) -> object:
    if not isinstance(items, list):
        return items

    normalized: list[object] = []
    for item in items:
        if not _is_mapping(item):
            normalized.append(item)
            continue
        next_item = dict(_clone_value(item))
        source = _normalize_config_path_value(base_dir, next_item.get("from"))
        if source:
            next_item["from"] = source
        normalized.append(next_item)
    return normalized


def _normalize_signing_paths(base_dir: Path, signing: object) -> object:
    if not _is_mapping(signing):
        return signing

    next_signing = dict(_clone_value(signing))
    windows = next_signing.get("windows")
    if _is_mapping(windows):
        next_windows = dict(_clone_value(windows))
        pfx = _normalize_config_path_value(base_dir, next_windows.get("pfx"))
        if pfx:
            next_windows["pfx"] = pfx
        next_signing["windows"] = next_windows

    darwin = next_signing.get("darwin")
    if _is_mapping(darwin):
        next_darwin = dict(_clone_value(darwin))
        entitlements = _normalize_config_path_value(base_dir, next_darwin.get("entitlements"))
        if entitlements:
            next_darwin["entitlements"] = entitlements
        next_signing["darwin"] = next_darwin

    return next_signing


def _normalize_overlay_aliases(config: object) -> dict[str, object]:
    if not _is_mapping(config):
        return {}

    next_config = dict(_clone_value(config))
    next_config.pop("name", None)
    next_config.pop("distribution", None)
    next_config.pop("cloudAppId", None)
    next_config.pop("appid", None)
    return next_config


def _normalize_overlay_paths(base_dir: Path, config: object) -> dict[str, object]:
    if not _is_mapping(config):
        return {}

    next_config = dict(_clone_value(config))
    icon = _normalize_config_path_value(base_dir, next_config.get("icon"))
    if icon:
        next_config["icon"] = icon

    package = next_config.get("package")
    if _is_mapping(package):
        next_package = dict(_clone_value(package))
        package_icon = _normalize_config_path_value(base_dir, next_package.get("icon"))
        if package_icon:
            next_package["icon"] = package_icon
        next_package["extraFiles"] = _normalize_extra_entries(base_dir, next_package.get("extraFiles"))
        next_package["extraResources"] = _normalize_extra_entries(base_dir, next_package.get("extraResources"))
        next_config["package"] = next_package

    next_config["signing"] = _normalize_signing_paths(base_dir, next_config.get("signing"))
    return next_config


def _resolve_existing_distromate_config_path(
    start_dir: Path,
    explicit_path: str | None = None,
) -> Path | None:
    if explicit_path:
        candidate = Path(explicit_path)
        if not candidate.is_absolute():
            candidate = start_dir / candidate
        candidate = candidate.resolve()
        if not candidate.is_file():
            raise FileNotFoundError(f"Unable to find distromate config: {explicit_path}")
        return candidate

    for candidate in (start_dir / "distromate.yaml", start_dir / "distromate.yml"):
        if candidate.is_file():
            return candidate
    return None


def _load_distromate_overlay(
    start_dir: Path,
    explicit_path: str | None = None,
) -> tuple[dict[str, object], Path | None]:
    config_path = _resolve_existing_distromate_config_path(start_dir, explicit_path)
    if config_path is None:
        return {}, None

    try:
        loaded = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ValueError(f"Failed to parse {config_path.name}: {exc}") from exc

    if not _is_mapping(loaded):
        raise ValueError(f"Invalid distromate config in {config_path.name}: root must be a mapping")

    normalized = _normalize_overlay_aliases(
        _normalize_overlay_paths(config_path.parent, loaded)
    )
    return normalized, config_path


def _read_pyproject_version(start_dir: Path) -> str | None:
    if tomllib is None:
        return None

    for current in [start_dir, *start_dir.parents]:
        pyproject = current / "pyproject.toml"
        if not pyproject.is_file():
            continue
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except Exception:
            return None
        return data.get("project", {}).get("version")

    return None


def _normalize_yaml_path(path_value: str, start_dir: Path) -> str:
    path = Path(path_value)
    if path.is_absolute():
        try:
            return path.relative_to(start_dir).as_posix()
        except ValueError:
            return path.as_posix()
    return path.as_posix()


def _normalize_icon_value(icon_value: str | None, start_dir: Path) -> str | None:
    if icon_value is None:
        return None

    normalized = icon_value.strip()
    if not normalized or normalized.lower() == "none":
        return None

    return _normalize_yaml_path(normalized, start_dir)


def _join_yaml_path(*parts: str) -> str:
    normalized: list[str] = []
    for idx, part in enumerate(parts):
        current = part.replace("\\", "/")
        if idx == 0:
            normalized.append(current.rstrip("/"))
        else:
            normalized.append(current.strip("/"))

    merged = "/".join(item for item in normalized if item)
    return merged or "."


def _call_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _string_from_expr(node: ast.AST | None, values: dict[str, str]) -> str | None:
    if node is None:
        return None
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return values.get(node.id)
    return None


def _icon_from_expr(node: ast.AST | None, values: dict[str, str]) -> str | None:
    if node is None:
        return None

    direct = _string_from_expr(node, values)
    if direct is not None:
        return direct

    if isinstance(node, (ast.List, ast.Tuple)):
        for item in node.elts:
            icon = _icon_from_expr(item, values)
            if icon:
                return icon

    return None


def _resolve_input_file_path(
    path_value: str,
    start_dir: Path,
    preferred_dir: Path | None = None,
) -> Path:
    path = Path(path_value)
    if path.is_absolute():
        return path

    if preferred_dir is not None:
        preferred_candidate = preferred_dir / path
        if preferred_candidate.is_file():
            return preferred_candidate
    else:
        preferred_candidate = None

    start_candidate = start_dir / path
    if start_candidate.is_file():
        return start_candidate

    if preferred_candidate is not None:
        return preferred_candidate
    return start_candidate


def _read_version_file_metadata(version_path: Path) -> tuple[str | None, str | None]:
    try:
        text = version_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            text = version_path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return None, None
    except OSError:
        return None, None

    try:
        tree = ast.parse(text)
    except SyntaxError:
        return None, None

    string_values: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            value = _string_from_expr(node.value, string_values)
            if value is None:
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    string_values[target.id] = value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            value = _string_from_expr(node.value, string_values)
            if value is not None:
                string_values[node.target.id] = value

    description: str | None = None
    publisher: str | None = None

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or _call_name(node.func) != "StringStruct":
            continue

        key_node: ast.AST | None = None
        value_node: ast.AST | None = None
        if len(node.args) >= 2:
            key_node = node.args[0]
            value_node = node.args[1]
        for keyword in node.keywords:
            if keyword.arg in {"name", "key"} and key_node is None:
                key_node = keyword.value
            elif keyword.arg in {"value", "text"} and value_node is None:
                value_node = keyword.value

        key = _string_from_expr(key_node, string_values)
        value = _string_from_expr(value_node, string_values)
        if not key or value is None:
            continue

        value = value.strip()
        if not value:
            continue

        if key == "FileDescription" and description is None:
            description = value
        elif key == "CompanyName" and publisher is None:
            publisher = value

        if description and publisher:
            break

    return description, publisher


def _read_spec_metadata(spec_path: Path) -> _SpecMetadata:
    meta = _SpecMetadata()

    try:
        text = spec_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            text = spec_path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return meta
    except OSError:
        return meta

    try:
        tree = ast.parse(text)
    except SyntaxError:
        return meta

    string_values: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            value = _string_from_expr(node.value, string_values)
            if value is None:
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    string_values[target.id] = value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            value = _string_from_expr(node.value, string_values)
            if value is not None:
                string_values[node.target.id] = value

    exe_name: str | None = None
    collect_name: str | None = None
    exe_distpath: str | None = None
    collect_distpath: str | None = None
    exe_icon: str | None = None
    exe_version_file: str | None = None
    has_exe = False
    has_collect = False

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func_name = _call_name(node.func)
        if func_name not in {"EXE", "COLLECT"}:
            continue

        if func_name == "EXE":
            has_exe = True
        if func_name == "COLLECT":
            has_collect = True

        for keyword in node.keywords:
            if keyword.arg == "name":
                value = _string_from_expr(keyword.value, string_values)
                if value is None:
                    continue
                if func_name == "EXE":
                    exe_name = value
                else:
                    collect_name = value
            elif keyword.arg == "distpath":
                value = _string_from_expr(keyword.value, string_values)
                if value is None:
                    continue
                if func_name == "EXE":
                    exe_distpath = value
                else:
                    collect_distpath = value
            elif keyword.arg == "icon" and func_name == "EXE":
                icon_value = _icon_from_expr(keyword.value, string_values)
                if icon_value:
                    exe_icon = icon_value
            elif keyword.arg == "version" and func_name == "EXE":
                version_value = _string_from_expr(keyword.value, string_values)
                if version_value:
                    exe_version_file = version_value

    meta.name = exe_name or collect_name
    meta.distpath = collect_distpath or exe_distpath
    meta.icon = exe_icon
    meta.version_file = exe_version_file
    if has_exe:
        meta.onefile = not has_collect
    return meta


def _parse_pyinstaller_metadata(
    py_args: list[str],
) -> tuple[
    str | None,
    str | None,
    bool | None,
    str | None,
    str | None,
    str | None,
    str | None,
]:
    name: str | None = None
    distpath: str | None = None
    onefile: bool | None = None
    spec_arg: str | None = None
    script_arg: str | None = None
    icon: str | None = None
    version_file: str | None = None

    i = 0
    while i < len(py_args):
        arg = py_args[i]

        if arg == "--":
            for item in py_args[i + 1 :]:
                if item.startswith("-"):
                    continue
                lowered = item.lower()
                if spec_arg is None and lowered.endswith(".spec"):
                    spec_arg = item
                elif script_arg is None and lowered.endswith(".py"):
                    script_arg = item
            break

        if arg in {"-n", "--name"} and i + 1 < len(py_args):
            name = py_args[i + 1]
            i += 2
            continue

        if arg.startswith("--name="):
            name = arg.split("=", 1)[1]
            i += 1
            continue

        if arg == "--distpath" and i + 1 < len(py_args):
            distpath = py_args[i + 1]
            i += 2
            continue

        if arg.startswith("--distpath="):
            distpath = arg.split("=", 1)[1]
            i += 1
            continue

        if arg in {"-F", "--onefile"}:
            onefile = True
            i += 1
            continue

        if arg in {"-D", "--onedir"}:
            onefile = False
            i += 1
            continue

        if arg in {"-i", "--icon"} and i + 1 < len(py_args):
            icon = py_args[i + 1]
            i += 2
            continue

        if arg.startswith("--icon="):
            icon = arg.split("=", 1)[1]
            i += 1
            continue

        if arg.startswith("-i") and len(arg) > 2:
            icon = arg[2:]
            i += 1
            continue

        if arg == "--version-file" and i + 1 < len(py_args):
            version_file = py_args[i + 1]
            i += 2
            continue

        if arg.startswith("--version-file="):
            version_file = arg.split("=", 1)[1]
            i += 1
            continue

        if not arg.startswith("-"):
            lowered = arg.lower()
            if spec_arg is None and lowered.endswith(".spec"):
                spec_arg = arg
            elif script_arg is None and lowered.endswith(".py"):
                script_arg = arg

        i += 1

    return name, distpath, onefile, spec_arg, script_arg, icon, version_file


def _derive_distromate_config(
    py_args: list[str],
    start_dir: Path,
    app_id: str | None = None,
) -> _DistromateConfig:
    (
        cli_name,
        cli_distpath,
        cli_onefile,
        spec_arg,
        script_arg,
        cli_icon,
        cli_version_file,
    ) = _parse_pyinstaller_metadata(py_args)

    spec_meta = _SpecMetadata()
    spec_path: Path | None = None
    if spec_arg:
        spec_path = Path(spec_arg)
        if not spec_path.is_absolute():
            spec_path = start_dir / spec_path
        spec_meta = _read_spec_metadata(spec_path)

    raw_name = cli_name or spec_meta.name
    if not raw_name and script_arg:
        raw_name = Path(script_arg).stem
    if not raw_name and spec_arg:
        raw_name = Path(spec_arg).stem
    if not raw_name:
        raw_name = start_dir.name or "app"

    package_name = Path(raw_name).name.strip() or "app"
    if package_name.lower().endswith(".exe") and len(package_name) > 4:
        package_name = package_name[:-4]

    raw_target = cli_distpath or spec_meta.distpath or "dist"
    package_target = _normalize_yaml_path(raw_target, start_dir)
    package_icon = _normalize_icon_value(cli_icon or spec_meta.icon, start_dir)

    version_file = cli_version_file or spec_meta.version_file
    version_search_dir = spec_path.parent if spec_path is not None else start_dir
    package_description: str | None = None
    package_publisher: str | None = None
    if version_file:
        version_path = _resolve_input_file_path(
            version_file,
            start_dir=start_dir,
            preferred_dir=version_search_dir,
        )
        package_description, package_publisher = _read_version_file_metadata(version_path)

    onefile = cli_onefile
    if onefile is None:
        onefile = spec_meta.onefile
    if onefile is None:
        onefile = False

    executable_name = package_name
    if os.name == "nt" and not executable_name.lower().endswith(".exe"):
        executable_name += ".exe"

    if onefile:
        package_executable = _join_yaml_path(package_target, executable_name)
    else:
        package_executable = _join_yaml_path(
            package_target,
            package_name,
            executable_name,
        )

    return _DistromateConfig(
        app_id=app_id,
        app_name=package_name,
        package_name=package_name,
        package_executable=package_executable,
        package_target=package_target,
        package_icon=package_icon,
        package_description=package_description,
        package_publisher=package_publisher,
    )


def _default_package_files() -> list[str]:
    return ["**/*", "!**/.git/**", "!**/*.map", "!**/*.pdb"]


def _build_distromate_project_config(
    start_dir: Path,
    py_args: list[str],
    app_id: str | None = None,
    distromate_config_path: str | None = None,
) -> dict[str, object]:
    derived = _derive_distromate_config(py_args, start_dir, app_id=app_id)
    overlay, _ = _load_distromate_overlay(start_dir, distromate_config_path)
    merged = dict(
        _deep_merge(
            {
                "productName": derived.app_name,
                "publish": {"appId": app_id} if app_id else {},
                "source": {
                    "type": "native",
                    "root": derived.package_target,
                    "executable": derived.package_executable,
                    "files": _default_package_files(),
                },
                "package": {
                    "name": derived.package_name,
                    "description": derived.package_description,
                    "icon": derived.package_icon,
                    "publisher": derived.package_publisher,
                },
            },
            overlay,
        )
    )

    source = dict(_clone_value(merged.get("source"))) if _is_mapping(merged.get("source")) else {}
    package = dict(_clone_value(merged.get("package"))) if _is_mapping(merged.get("package")) else {}
    publish = dict(_clone_value(merged.get("publish"))) if _is_mapping(merged.get("publish")) else {}

    system_app_id = _first_text(merged.get("appId"), package.get("appId"))
    publish_app_id = _first_text(app_id, publish.get("appId"))

    product_name = _first_text(merged.get("productName"), derived.app_name)
    package_name = _first_text(package.get("name"), derived.package_name)
    package_description = _first_text(package.get("description"), derived.package_description)
    package_icon = _first_text(package.get("icon"), derived.package_icon)
    package_publisher = _first_text(package.get("publisher"), derived.package_publisher)

    if product_name:
        merged["productName"] = product_name
    if package_name:
        package["name"] = package_name
    if package_description:
        package["description"] = package_description
    if package_icon:
        package["icon"] = package_icon
    if package_publisher:
        package["publisher"] = package_publisher

    source["type"] = "native"
    source["root"] = derived.package_target
    source["executable"] = derived.package_executable
    source.pop("plugin", None)
    source.pop("options", None)
    if not source.get("files"):
        source["files"] = _default_package_files()

    package.pop("target", None)
    package.pop("executable", None)
    package.pop("files", None)
    package.pop("args", None)
    package.pop("executableName", None)

    if system_app_id:
        merged["appId"] = system_app_id
        package["appId"] = _first_text(package.get("appId"), system_app_id)

    if publish_app_id:
        publish["appId"] = publish_app_id
    if publish:
        merged["publish"] = publish
    else:
        merged.pop("publish", None)

    top_level_icon = _first_text(merged.get("icon"), package_icon)
    if top_level_icon:
        merged["icon"] = top_level_icon

    merged["source"] = source
    merged["package"] = package
    merged.pop("distromateCliPath", None)
    merged.pop("cliPath", None)

    return dict(_strip_none(merged))
