from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

import yaml

from . import project

PLUGIN_API_VERSION = 1
PLUGIN_MANIFEST = {
    "apiVersion": PLUGIN_API_VERSION,
    "kind": "builder",
    "name": "pyinstaller-plus",
    "framework": "pyinstaller",
    "runtime": "python",
}


def _read_request() -> dict[str, Any]:
    text = sys.stdin.read().strip()
    if not text:
        raise ValueError("plugin stdio request is empty")
    loaded = json.loads(text)
    if not isinstance(loaded, dict):
        raise ValueError("plugin stdio request must be a JSON object")
    return loaded


def _validate_request(request: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    api_version = request.get("apiVersion")
    if api_version != PLUGIN_API_VERSION:
        raise ValueError(f"plugin stdio request apiVersion must be {PLUGIN_API_VERSION}")

    command = str(request.get("command") or "").strip()
    if command not in {"manifest", "prepare-package", "prepare-publish"}:
        raise ValueError(f"Unsupported plugin stdio command: {command or '<empty>'}")

    raw_input = request.get("input") or {}
    if not isinstance(raw_input, dict):
        raise ValueError("plugin stdio request input must be an object")
    return command, raw_input


def _load_adapter_config(config_path: Path) -> dict[str, Any]:
    if not config_path.is_file():
        raise FileNotFoundError(f"Unable to find distromate config: {config_path}")
    loaded = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    if not isinstance(loaded, dict):
        raise ValueError(f"Invalid distromate config in {config_path.name}: root must be a mapping")
    return loaded


def _source_options(config: dict[str, Any]) -> dict[str, Any]:
    source = config.get("source")
    if not isinstance(source, dict):
        return {}
    options = source.get("options")
    if not isinstance(options, dict):
        return {}
    return dict(options)


def _first_text(*values: Any) -> str | None:
    for value in values:
        if isinstance(value, str):
            text = value.strip()
            if text:
                return text
        elif isinstance(value, (int, float)):
            return str(value)
    return None


def _bool_value(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"true", "1", "yes", "on"}:
            return True
        if text in {"false", "0", "no", "off"}:
            return False
    return None


def _normalize_string_list(value: Any, label: str) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if not isinstance(value, list):
        raise ValueError(f"{label} must be a string or an array")
    result: list[str] = []
    for index, item in enumerate(value):
        text = _first_text(item)
        if not text:
            raise ValueError(f"{label}[{index}] must be a non-empty string")
        result.append(text)
    return result


def _resolve_pyinstaller_args(options: dict[str, Any]) -> list[str]:
    args = _normalize_string_list(
        options.get("pyinstallerArgs", options.get("args", options.get("pyArgs"))),
        "source.options.pyinstallerArgs",
    )
    if args:
        return args

    generated: list[str] = []
    if _bool_value(options.get("onefile")) is True:
        generated.append("--onefile")
    if _bool_value(options.get("windowed")) is True:
        generated.append("--windowed")
    if _bool_value(options.get("clean")) is True:
        generated.append("--clean")
    if _bool_value(options.get("noconfirm")) is True:
        generated.append("--noconfirm")

    for option_key, flag in (
        ("name", "--name"),
        ("distpath", "--distpath"),
        ("workpath", "--workpath"),
        ("specpath", "--specpath"),
        ("icon", "--icon"),
        ("versionFile", "--version-file"),
    ):
        text = _first_text(options.get(option_key))
        if text:
            generated.extend([flag, text])

    entry = _first_text(options.get("spec"), options.get("script"), options.get("entry"))
    if entry:
        generated.append(entry)
    return generated


def _build_prepared_result(command: str, input_data: dict[str, Any]) -> dict[str, Any]:
    project_dir = Path(_first_text(input_data.get("projectDir")) or Path.cwd()).resolve()
    config_path_value = _first_text(input_data.get("distromateConfigPath"))
    if not config_path_value:
        raise ValueError("plugin stdio request input.distromateConfigPath is required")
    adapter_config_path = Path(config_path_value).resolve()
    adapter_config = _load_adapter_config(adapter_config_path)
    options = _source_options(adapter_config)
    py_args = _resolve_pyinstaller_args(options)
    if not py_args:
        raise ValueError("pyinstaller-plus requires source.options.pyinstallerArgs or an entry script/spec")

    version = _first_text(options.get("version"), project._read_pyproject_version(project_dir))
    if not version:
        raise ValueError("pyinstaller-plus requires source.options.version or project.version in pyproject.toml")

    app_id = _first_text(options.get("appId"), options.get("appid"))
    rc = _run_pyinstaller_command([sys.executable, "-m", "PyInstaller", *py_args])
    if rc != 0:
        raise RuntimeError(f"PyInstaller exited with code {rc}")

    config_data = project._build_distromate_project_config(
        project_dir,
        py_args,
        app_id=app_id,
        distromate_config_path=str(adapter_config_path),
    )

    temp_dir = Path(tempfile.mkdtemp(prefix="distromate-pyinstaller-plus-"))
    final_config_path = temp_dir / "distromate.generated.json"
    final_config_path.write_text(json.dumps(config_data, indent=2) + "\n", encoding="utf-8")

    raw_publish = config_data.get("publish")
    publish: dict[str, Any] = {}
    if isinstance(raw_publish, dict):
        publish = raw_publish
    return {
        "configPath": str(final_config_path),
        "cleanupPaths": [str(temp_dir)],
        "version": version,
        "outputDir": _first_text(options.get("outputDir"), config_data.get("outputDir")),
        "appUrl": _first_text(options.get("appUrl"), config_data.get("appUrl")),
        "licensePath": _first_text(options.get("licensePath"), config_data.get("licensePath")),
        "description": _first_text(options.get("description"), publish.get("description")),
        "channel": _first_text(options.get("channel"), publish.get("channel")),
        "desktopIcon": _bool_value(options.get("desktopIcon", config_data.get("desktopIcon"))),
        "debug": _bool_value(options.get("debug", config_data.get("debug"))),
        "metadata": {
            "command": "package" if command == "prepare-package" else "publish",
            "projectDir": str(project_dir),
            "pyinstallerArgs": py_args,
        },
    }


def _run_pyinstaller_command(cmd: list[str]) -> int:
    print(f"[pyinstaller-plus] $ {' '.join(cmd)}", file=sys.stderr)
    try:
        completed = subprocess.run(
            cmd,
            check=False,
            stdout=sys.stderr,
            stderr=sys.stderr,
        )
    except FileNotFoundError:
        print(f"[pyinstaller-plus] Command not found: {cmd[0]}", file=sys.stderr)
        return 127
    return completed.returncode


def _success_response(result: dict[str, Any] | None = None) -> dict[str, Any]:
    response: dict[str, Any] = {
        "apiVersion": PLUGIN_API_VERSION,
        "ok": True,
        "manifest": dict(PLUGIN_MANIFEST),
    }
    if result is not None:
        response["result"] = result
    return response


def _error_response(message: str) -> dict[str, Any]:
    return {
        "apiVersion": PLUGIN_API_VERSION,
        "ok": False,
        "error": {
            "message": message,
        },
    }


def main() -> int:
    try:
        request = _read_request()
        command, input_data = _validate_request(request)
        if command == "manifest":
            response = _success_response()
        else:
            response = _success_response(_build_prepared_result(command, input_data))
        sys.stdout.write(json.dumps(response) + "\n")
        return 0
    except Exception as exc:
        sys.stdout.write(json.dumps(_error_response(str(exc))) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
