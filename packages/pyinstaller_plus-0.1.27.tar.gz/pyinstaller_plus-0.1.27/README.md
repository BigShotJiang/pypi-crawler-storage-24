# pyinstaller-plus

Build Python desktop apps through `distromate` with PyInstaller as the host build tool.

## Install

```bash
pip install pyinstaller-plus
```

Install the DistroMate CLI separately. This package only provides the builder plugin entrypoint.

## Usage

Point `distromate.yaml` at the builder plugin and put PyInstaller arguments in `source.options.pyinstallerArgs`:

```yaml
source:
  type: adapter
  plugin: pyinstaller-plus
  options:
    projectDir: .
    pyinstallerArgs:
      - --onefile
      - --windowed
      - app.py

publish:
  appId: "70253487"
  channel: stable

package:
  publisher: Demo Inc.
```

Run DistroMate directly:

```bash
distromate package -v 1.2.3
distromate publish -v 1.2.3
```

## Behavior

- runs `python -m PyInstaller ...` first
- derives `productName`, `package.name`, `package.shortDescription`, `source.root`, `source.executable`, icon, and publisher from PyInstaller args or `.spec` metadata
- overlays values from the resolved adapter config
- returns the generated native DistroMate config over JSON/stdio so `distromate` continues the package or publish flow

## Notes

- `source.options.pyinstallerArgs` is the main pass-through for PyInstaller arguments
- if `version` is not set in `source.options`, the plugin falls back to `pyproject.toml -> project.version`
