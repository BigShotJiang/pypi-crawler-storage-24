# Requirements: opendeviationbar-py v6.0

**Defined:** 2026-03-25
**Core Value:** End-to-end SHA-256 checksum verification of all downloaded raw data with heartbeat telemetry alerting on integrity failures.

## v6.0 Requirements

### Spike Validation

- [x] **SPIKE-01**: Rust checksum.rs SHA-256 fetch+verify callable from Python and produces correct results against real Vision CHECKSUM files
- [x] **SPIKE-02**: Performance overhead of checksum verification measured (< 10% wall-clock increase acceptable)
- [x] **SPIKE-03**: Edge cases validated: 404 CHECKSUM (old data soft-skip), network timeout (soft-skip), format mismatch (hard fail), corrupted download (hard fail)

### Seeder Integration

- [x] **SEEDER-01**: tick_cache_seeder.py verifies SHA-256 checksum of every Vision ZIP download against the .CHECKSUM file
- [x] **SEEDER-02**: Checksum mismatch triggers re-download (up to 2 retries) before failing loudly with Telegram alert
- [x] **SEEDER-03**: Per-file verification status persisted (symbol, date, checksum, verified_at) for audit trail

### Integrity Sweep

- [x] **SWEEP-01**: Script audits all existing Parquet cache files by re-downloading Vision CHECKSUM files and comparing against stored originals
- [x] **SWEEP-02**: Incremental mode skips already-verified files (reads verification registry), only checks new/unverified
- [x] **SWEEP-03**: Sweep results reported with pass/fail/skip counts per symbol and date range

### Telemetry & Heartbeat

- [x] **TELEM-01**: Heartbeat includes checksum verification status per symbol (last verified date, any failures)
- [x] **TELEM-02**: Checksum failure triggers LOUD Telegram alert with symbol, date, expected vs actual hash
- [x] **TELEM-03**: Centralized verification registry (JSON/SQLite) tracks per-file verification state as SSoT
- [x] **TELEM-04**: Local telemetry log captures all checksum operations for post-mortem analysis

## Traceability

| Requirement | Phase    | Plan | Status  |
| ----------- | -------- | ---- | ------- |
| SPIKE-01    | Phase 8  | TBD  | Pending |
| SPIKE-02    | Phase 8  | TBD  | Pending |
| SPIKE-03    | Phase 8  | TBD  | Pending |
| SEEDER-01   | Phase 10 | TBD  | Pending |
| SEEDER-02   | Phase 10 | TBD  | Pending |
| SEEDER-03   | Phase 10 | TBD  | Pending |
| SWEEP-01    | Phase 11 | TBD  | Pending |
| SWEEP-02    | Phase 11 | TBD  | Pending |
| SWEEP-03    | Phase 11 | TBD  | Pending |
| TELEM-01    | Phase 12 | TBD  | Pending |
| TELEM-02    | Phase 12 | TBD  | Pending |
| TELEM-03    | Phase 9  | TBD  | Pending |
| TELEM-04    | Phase 12 | TBD  | Pending |

## Future Requirements

None deferred.

## Out of Scope

- **Exness checksum verification** — Exness does not publish CHECKSUM files; no verification possible beyond HTTP
- **WebSocket stream checksums** — Not practical for real-time streams; trade-ID gap detection is the integrity mechanism
- **Post-INSERT ClickHouse row count verification** — Low severity, mitigated by Stathera audit and dedup tokens
