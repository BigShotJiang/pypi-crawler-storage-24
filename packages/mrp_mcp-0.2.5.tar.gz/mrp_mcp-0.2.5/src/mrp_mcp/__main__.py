import argparse
import sys

from mrp_mcp.config import load_config
from mrp_mcp.server import run_server


def main():
    parser = argparse.ArgumentParser(description="MRP MCP Tool Server")
    parser.add_argument("--relay", help="MRP relay URL")
    parser.add_argument("--key", help="Path to Ed25519 key file")
    parser.add_argument("--name", help="Agent display name")
    parser.add_argument(
        "--cap", action="append", help="Agent capability (repeatable)"
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=0,
        dest="poll_interval",
        help="Background poll interval in seconds (0=disabled)",
    )
    parser.add_argument("--config", help="Path to config file")
    parser.add_argument(
        "--ephemeral",
        action="store_true",
        default=False,
        help="Use an ephemeral in-memory key (do not persist identity)",
    )
    args = parser.parse_args()

    try:
        config = load_config(args)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    run_server(config)


if __name__ == "__main__":
    main()
