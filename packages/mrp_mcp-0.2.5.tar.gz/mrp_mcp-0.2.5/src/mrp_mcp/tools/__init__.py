"""MRP MCP tool handlers."""
