from __future__ import annotations

import asyncio
import json

from mcp.server.fastmcp import FastMCP
from mrp import Agent

from mrp_mcp.state import SessionState


def register(mcp: FastMCP, agent: Agent, state: SessionState) -> None:
    @mcp.tool()
    async def mrp_set_inbox_policy(policy: str) -> str:
        """Set the inbox policy for this agent.

        Controls how incoming messages are filtered.

        Args:
            policy: One of:
                - "open" — anyone can message (default for existing agents)
                - "closed" — nobody can message
                - "allowlist" — only peers in the allow list can message
                - "blocklist" — everyone except peers in the block list can message

        Returns:
            Confirmation of the updated policy.
        """
        info = await asyncio.to_thread(
            agent.client.update_agent,
            agent.public_key,
            inbox_policy=policy,
        )
        return f"Inbox policy set to: {info.inbox_policy}"

    @mcp.tool()
    async def mrp_allow_sender(peer_key: str) -> str:
        """Allow a specific agent to send messages to you.

        Adds the peer to your allow list. Used when inbox_policy is "allowlist".

        Args:
            peer_key: The public key of the agent to allow.

        Returns:
            Confirmation of the ACL entry.
        """
        entry = await asyncio.to_thread(
            agent.client.set_acl, agent.public_key, peer_key, "allow"
        )
        return f"Allowed {entry.peer_key} (type: {entry.entry_type})"

    @mcp.tool()
    async def mrp_block_sender(peer_key: str) -> str:
        """Block a specific agent from sending messages to you.

        Adds the peer to your block list. Used when inbox_policy is "blocklist".

        Args:
            peer_key: The public key of the agent to block.

        Returns:
            Confirmation of the ACL entry.
        """
        entry = await asyncio.to_thread(
            agent.client.set_acl, agent.public_key, peer_key, "block"
        )
        return f"Blocked {entry.peer_key} (type: {entry.entry_type})"

    @mcp.tool()
    async def mrp_remove_acl_entry(peer_key: str) -> str:
        """Remove an ACL entry for a specific agent.

        Removes the peer from both allow and block lists.

        Args:
            peer_key: The public key of the agent to remove from ACL.

        Returns:
            Confirmation of removal.
        """
        await asyncio.to_thread(
            agent.client.delete_acl, agent.public_key, peer_key
        )
        return f"Removed ACL entry for {peer_key}"

    @mcp.tool()
    async def mrp_list_acl(entry_type: str | None = None) -> str:
        """List your ACL entries.

        Shows which agents are allowed or blocked from messaging you.

        Args:
            entry_type: Optional filter — "allow" or "block". If omitted, shows all.

        Returns:
            A formatted list of ACL entries.
        """
        entries = await asyncio.to_thread(
            agent.client.list_acl, agent.public_key, entry_type
        )
        if not entries:
            return "No ACL entries found."

        lines = []
        for e in entries:
            lines.append(
                f"- {e.peer_key} ({e.entry_type}) — added {e.created_at.isoformat()}"
            )
        return f"**ACL entries ({len(entries)}):**\n" + "\n".join(lines)
