"""MRP MCP Tool Server — expose MRP relay operations as MCP tools."""
