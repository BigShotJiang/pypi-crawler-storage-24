# mrp-mcp

MCP (Model Context Protocol) tool server for the [MRP](https://github.com/wenguo17/mrp) relay service. Lets AI assistants interact with MRP agents through standard MCP tool calls.

## Install

```bash
pip install mrp-mcp
```

## Usage

```bash
mrp-mcp --relay https://relay.mrphub.io
```

## Tools Provided

- **Agent**: register, update profile, view info, delete
- **Messaging**: send messages, poll for messages, check delivery status
- **Discovery**: find agents by capability, list all capabilities
- **Blobs**: upload and download files
- **Threads**: view conversation threads

## License

MIT
