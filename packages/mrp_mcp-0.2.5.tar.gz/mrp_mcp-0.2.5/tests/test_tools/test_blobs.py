from __future__ import annotations

import pytest

from mcp.server.fastmcp import FastMCP

from mrp_mcp.tools.blobs import register


@pytest.fixture
def mcp_server(mock_agent, state):
    mcp = FastMCP("test")
    register(mcp, mock_agent, state)
    return mcp


@pytest.mark.asyncio
async def test_upload_blob(mcp_server, mock_agent, tmp_path):
    test_file = tmp_path / "test.txt"
    test_file.write_text("hello world")

    result = await mcp_server.call_tool(
        "mrp_upload_blob",
        {"file_path": str(test_file), "content_type": "text/plain"},
    )
    text = result[0][0].text

    mock_agent.upload.assert_called_once()
    assert "blob_001" in text
    assert "1024 bytes" in text
    assert "File uploaded successfully" in text


@pytest.mark.asyncio
async def test_download_blob(mcp_server, mock_agent, tmp_path):
    save_path = tmp_path / "downloaded.bin"

    result = await mcp_server.call_tool(
        "mrp_download_blob",
        {"blob_id": "blob_001", "save_to": str(save_path)},
    )
    text = result[0][0].text

    mock_agent.download.assert_called_once_with("blob_001")
    assert "File downloaded successfully" in text
    assert str(save_path) in text
    assert save_path.read_bytes() == b"file-content"
