import socket
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("port-check")

@mcp.tool()
def check_port(host: str, port: int, timeout: int = 3) -> str:
    """检测远程主机端口是否开放。"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        
        if result == 0:
            return f"{host}:{port} -> 开放 (Open)"
        else:
            return f"{host}:{port} -> 关闭/过滤 (Closed/Filtered - Error {result})"
    except socket.gaierror:
        return f"无法解析主机名: {host}"
    except Exception as e:
        return f"端口检测错误: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
