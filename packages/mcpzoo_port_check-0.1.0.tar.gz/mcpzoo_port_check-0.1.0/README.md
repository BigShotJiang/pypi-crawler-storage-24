# mcpzoo-port-check

> 端口检测 — 检测远程主机端口是否开放

## Installation

```bash
uvx mcpzoo-port-check
```

## uvx JSON

```json
{
  "mcpServers": {
    "port-check": {
      "args": ["mcpzoo-port-check"],
      "command": "uvx"
    }
  }
}
```
