# ascii-maker

**Full-featured ASCII art designer for the terminal.**
Text banners · art browser · boxes · charts · Mermaid templates · README generator

```
     _  _  _  _  _  _  _        _
    / \/ \/ \/ \/ \/ \/ \      / \
   | a  s  c  i  i  -  m  a  k  e  r |
    \_/\_/\_/\_/\_/\_/\_/      \_/
```

## Install

```bash
pip install ascii-maker
```

## Quick start

```bash
am text "Hello" --font slant        # Render text as ASCII art
am text "Hello" --pick              # Interactive font + color picker
am banner "My App" --subtitle v1.0  # Banner with box frame

am box "Important note"             # Wrap text in a Unicode box
am divider thick -l "Section"       # Section divider line
am tree .                           # Directory tree

am chart bar 10 40 25 60 --labels Mon,Tue,Wed,Thu
am chart spark 3 1 4 1 5 9 2 6     # Inline sparkline ▁▃▄▁▅█▂▅

am mermaid flowchart --copy         # Copy a Mermaid diagram template
am browse animals                   # Browse asciiart.eu
am design                           # Interactive menu
```

## Commands

| Command | Description |
|---------|-------------|
| `am text TEXT` | Render text with pyfiglet fonts (`--font`, `--pick`, `--preview`) |
| `am banner TITLE` | ASCII art text inside a box frame |
| `am box TEXT` | Wrap text in a Unicode/ASCII box (`--style`, `--title`) |
| `am divider STYLE` | Print a divider line (`thin`, `thick`, `double`, `dots`, …) |
| `am table` | Box-drawing table from `--header` / `--row` flags |
| `am tree PATH` | Directory tree structure |
| `am chart bar` | Vertical bar chart |
| `am chart hbar` | Horizontal bar chart |
| `am chart line` | Line / scatter chart |
| `am chart spark` | Single-line sparkline (▁▂▃▄▅▆▇█) |
| `am chart pie` | ASCII pie chart |
| `am chart progress` | Progress bar |
| `am mermaid TEMPLATE` | Mermaid diagram template (`--list` to see all) |
| `am browse CATEGORY` | Browse ASCII art from asciiart.eu |
| `am search QUERY` | Search ASCII art by keyword |
| `am readme badge` | Generate shields.io badges |
| `am readme section` | Generate README sections |
| `am readme build` | Interactively generate a full README.md |
| `am design` | Interactive designer menu |

Add `--copy` to any command to copy the result to the clipboard.

## Box styles

```bash
am box --list-styles          # see all styles
am box "text" --style heavy   # heavy, rounded, double, ascii, ...
```

## Font picker

```bash
am text "Hello" --pick        # interactive picker, arrow keys to browse
am text "Hello" --preview     # show text in all favorite fonts at once
am text "Hello" --list-fonts  # list all pyfiglet fonts
```

## Piping

```bash
echo "output" | am box
cat notes.txt | am box --style double --title "Notes"
```

## Requirements

- Python ≥ 3.10
- `click`, `rich`, `pyfiglet`, `httpx`, `beautifulsoup4`
- `pyperclip` (optional, for `--copy`)

## License

MIT
