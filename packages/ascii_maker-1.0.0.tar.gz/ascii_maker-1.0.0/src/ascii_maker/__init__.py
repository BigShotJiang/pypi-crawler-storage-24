"""ASCII Maker — full-featured ASCII art designer."""
__version__ = "1.0.0"
