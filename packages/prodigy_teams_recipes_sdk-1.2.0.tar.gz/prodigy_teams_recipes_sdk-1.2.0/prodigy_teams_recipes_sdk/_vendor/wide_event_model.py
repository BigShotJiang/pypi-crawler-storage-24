"""Wide event model for the ``broker_wide_event`` table.

This file originates in shared/, and is copied verbatim into the broker
and sdk_recipes packages.  It should not be edited directly; edit the
shared version and run ``pdcli repo sync-shared`` to replicate it.

Used by broker, sdk_recipes (recipe servers), and compatibility tests.
"""

from __future__ import annotations

import uuid

import sqlalchemy as sa
import uuid_utils
from sqlalchemy import MetaData
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, declarative_base, mapped_column

_meta = MetaData()
_Base = declarative_base(metadata=_meta)


def _uuid7() -> uuid.UUID:
    return uuid.UUID(int=uuid_utils.uuid7().int)


class WideEvent(_Base):  # type: ignore[misc]
    __tablename__ = "broker_wide_event"

    id: Mapped[uuid.UUID] = mapped_column(sa.Uuid, primary_key=True, default=_uuid7)
    created: Mapped[sa.DateTime] = mapped_column(
        sa.DateTime(timezone=True),
        nullable=False,
        server_default=sa.func.now(),
        index=True,
    )
    event_type: Mapped[str] = mapped_column(
        sa.String(64), nullable=False, default="request", index=True
    )
    request_id: Mapped[str | None] = mapped_column(sa.String(64), index=True)
    method: Mapped[str | None] = mapped_column(sa.String(10))
    path: Mapped[str | None] = mapped_column(sa.String(2048))
    status_code: Mapped[int | None] = mapped_column(sa.SmallInteger)
    duration_ms: Mapped[float | None] = mapped_column(sa.Float)
    user_id: Mapped[uuid.UUID | None] = mapped_column(sa.Uuid, index=True)
    org_id: Mapped[uuid.UUID | None] = mapped_column(sa.Uuid, index=True)
    traceback: Mapped[str | None] = mapped_column(sa.Text)
    payload: Mapped[dict] = mapped_column(
        sa.JSON().with_variant(JSONB(), "postgresql"),
        nullable=False,
        server_default="{}",
    )


def ensure_tables(engine: sa.Engine) -> None:
    """Create broker-owned tables if they don't exist yet."""
    _meta.create_all(engine, checkfirst=True)
