"""Shared configuration constants for n2g."""

NODE_COLORS = {
    'gateway': '#ff6b6b',
    'server': '#4ecdc4',
    'workstation': '#45b7d1',
    'printer': '#96ceb4',
    'unknown': '#999999',
}

SERVER_PORTS = {22, 23, 25, 53, 80, 135, 139, 443, 445, 993, 995}

PRINTER_PORTS = {515, 631, 9100}
