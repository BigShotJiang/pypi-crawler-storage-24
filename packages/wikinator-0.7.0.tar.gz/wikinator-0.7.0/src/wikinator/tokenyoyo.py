import binascii
import json
import os
import confuse
import lzma
from cryptography.fernet import Fernet


def compress(value:dict, key:str) -> str:
    value = json.dumps(value).encode('utf-8')
    value = lzma.compress(value)

    value = Fernet(key).encrypt(value)

    value = binascii.b2a_base64(value, newline=True)
    return value.decode("utf-8")


def decompress(compressed:str, key:str) -> dict:
    value = binascii.a2b_base64(compressed)

    value = Fernet(key).decrypt(value)

    value = lzma.decompress(value).decode('utf-8')
    value = json.loads(value)
    return value


def load_creds() -> dict:
    # load json into python
    config = confuse.Configuration("wikinator", __name__)
    filename = os.path.join(config.config_dir(), "credentials.json")
    with open(filename) as json_data:
        return json.load(json_data)


def main():
    key = Fernet.generate_key()
    print(key)

    # load json into python
    test = load_creds()
    print(test)

    compressed = compress(test, key)
    print(compressed)

    plaintext = decompress(compressed, key)
    print(plaintext)


if __name__ == "__main__":
    main()