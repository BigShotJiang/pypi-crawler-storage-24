import httpx
from fastapi import APIRouter

from bluefox_core.app import create_bluefox_app
from bluefox_core.settings import BluefoxSettings


def _make_client(app):
    return httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://testserver")


async def test_welcome_page__shows_when_no_user_routes(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert response.status_code == 200
    assert "Your Bluefox app is running" in response.text


async def test_welcome_page__includes_app_name(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings(APP_NAME="My Cool App")
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert response.status_code == 200
    assert "My Cool App" in response.text


async def test_welcome_page__links_to_docs(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/")
    assert '/docs' in response.text
    assert '/health' in response.text
    assert '/redoc' in response.text


async def test_welcome_page__overridden_by_user_route(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)

    user_router = APIRouter()

    @user_router.get("/")
    async def home():
        return {"message": "user home"}

    app.include_router(user_router)

    async with _make_client(app) as client:
        response = await client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "user home"}


async def test_welcome_page__health_still_works(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("REDIS_URL", raising=False)
    settings = BluefoxSettings()
    app = create_bluefox_app(settings)
    async with _make_client(app) as client:
        response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
