# App factory

`create_bluefox_app()` builds a fully configured FastAPI application.

## Usage

```python
from bluefox_core import BluefoxSettings, create_bluefox_app

settings = BluefoxSettings()
app = create_bluefox_app(settings)
```

## What it does

1. **Configures logging** via `configure_logging(settings)`
2. **Creates a DatabaseManager** (no-op if `DATABASE_URL` is empty)
3. **Creates a Redis client** (if `REDIS_URL` is set)
4. **Sets up the lifespan** — startup verifies DB/Redis connectivity, shutdown disposes resources (wrapped in `try/finally` for safe cleanup)
5. **Adds middleware**:
    - `RequestIDMiddleware` — injects `X-Request-ID` headers and log context
    - `CORSMiddleware` — permissive in development, restrictive in production
6. **Stores state** — `app.state.db`, `app.state.redis`, `app.state.settings`
7. **Mounts the health router** — `/health` and `/readiness`
8. **Mounts the demo app** (if `demo=True`) — Todo CRUD at `/demo/todos`
9. **Mounts the welcome page** — shown at `/` when no user route exists for that path

## Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `settings` | `BluefoxSettings` | required | Application settings |
| `demo` | `bool` | `False` | Mount the demo Todo CRUD app |

## CORS behavior

| Setting | Development | Production |
|---|---|---|
| `allow_origins` | `["*"]` | `[]` |
| `allow_credentials` | `True` | `False` |
| `allow_methods` | `["*"]` | `["GET", "POST", "PUT", "PATCH", "DELETE"]` |
| `allow_headers` | `["*"]` | `["*"]` |

## App state

After creation, the following are available on `app.state`:

| Attribute | Type | Description |
|---|---|---|
| `app.state.settings` | `BluefoxSettings` | The settings instance |
| `app.state.db` | `DatabaseManager` | Database manager (engine may be `None`) |
| `app.state.redis` | `Redis | None` | Redis client, or `None` if not configured |

## Welcome page

The welcome page is served at `GET /` via a 404 exception handler. When you register your own `GET /` route, FastAPI matches it first and the welcome page is never triggered.

```python
from fastapi import APIRouter

router = APIRouter()

@router.get("/")
async def home():
    return {"message": "My app"}

app.include_router(router)
# GET / now returns {"message": "My app"} instead of the welcome page
```
