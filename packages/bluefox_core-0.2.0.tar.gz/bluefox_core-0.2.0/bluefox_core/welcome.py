from fastapi import FastAPI
from fastapi.responses import JSONResponse
from starlette.requests import Request
from starlette.responses import HTMLResponse


WELCOME_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{app_name}</title>
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #0a0a0a;
      color: #e0e0e0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    .container {{
      max-width: 640px;
      padding: 3rem 2rem;
      text-align: center;
    }}
    h1 {{
      font-size: 2rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: #ffffff;
    }}
    .subtitle {{
      color: #888;
      font-size: 1.1rem;
      margin-bottom: 2.5rem;
    }}
    .links {{
      display: flex;
      gap: 1.5rem;
      justify-content: center;
      margin-bottom: 3rem;
    }}
    .links a {{
      color: #60a5fa;
      text-decoration: none;
      font-size: 0.95rem;
    }}
    .links a:hover {{ text-decoration: underline; }}
    .getting-started {{
      text-align: left;
      background: #141414;
      border: 1px solid #262626;
      border-radius: 8px;
      padding: 1.5rem;
    }}
    .getting-started h2 {{
      font-size: 1rem;
      font-weight: 600;
      margin-bottom: 1rem;
      color: #ccc;
    }}
    pre {{
      background: #1a1a1a;
      border: 1px solid #2a2a2a;
      border-radius: 6px;
      padding: 1rem;
      overflow-x: auto;
      font-size: 0.85rem;
      line-height: 1.5;
      color: #d4d4d4;
    }}
    .hint {{
      margin-top: 1rem;
      font-size: 0.85rem;
      color: #666;
    }}
  </style>
</head>
<body>
  <div class="container">
    <h1>{app_name}</h1>
    <p class="subtitle">Your Bluefox app is running</p>
    <div class="links">
      <a href="/health">Health</a>
      <a href="/docs">API Docs</a>
      <a href="/redoc">ReDoc</a>
    </div>
    <div class="getting-started">
      <h2>Getting started</h2>
      <pre><code>from fastapi import APIRouter

router = APIRouter()

@router.get("/hello")
async def hello():
    return {{"message": "Hello, world!"}}

# In main.py:
app.include_router(router, prefix="/api")</code></pre>
      <p class="hint">
        Tip: try <code>create_bluefox_app(settings, demo=True)</code> to see a
        working Todo CRUD example.
      </p>
    </div>
  </div>
</body>
</html>
"""


def mount_welcome(app: FastAPI) -> None:
    @app.exception_handler(404)
    async def _welcome_or_404(request: Request, exc):
        if request.method == "GET" and request.url.path == "/":
            settings = getattr(request.app.state, "settings", None)
            name = settings.APP_NAME if settings else "Bluefox App"
            return HTMLResponse(WELCOME_HTML.format(app_name=name))
        return JSONResponse(status_code=404, content={"detail": "Not Found"})
