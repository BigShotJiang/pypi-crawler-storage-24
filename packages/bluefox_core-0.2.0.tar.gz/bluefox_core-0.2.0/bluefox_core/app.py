from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from bluefox_core.database import DatabaseManager
from bluefox_core.health import health_router
from bluefox_core.log import configure_logging, logger
from bluefox_core.middleware import RequestIDMiddleware
from bluefox_core.settings import BluefoxSettings


def create_bluefox_app(settings: BluefoxSettings, demo: bool = False) -> FastAPI:
    configure_logging(settings)

    db_manager = DatabaseManager(settings)

    redis_client = None
    if settings.has_redis:
        redis_client = aioredis.from_url(settings.REDIS_URL)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await db_manager.startup()
        if redis_client:
            await redis_client.ping()
        logger.info("app started", app_name=settings.APP_NAME)
        try:
            yield
        finally:
            await db_manager.shutdown()
            if redis_client:
                await redis_client.aclose()
            logger.info("app stopped", app_name=settings.APP_NAME)

    app = FastAPI(title=settings.APP_NAME, lifespan=lifespan)

    app.add_middleware(RequestIDMiddleware)

    if settings.is_production:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=[],
            allow_credentials=False,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
            allow_headers=["*"],
        )
    else:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    app.state.db = db_manager
    app.state.redis = redis_client
    app.state.settings = settings

    app.include_router(health_router)

    if demo:
        from bluefox_core.demo import mount_demo
        mount_demo(app)

    from bluefox_core.welcome import mount_welcome
    mount_welcome(app)

    return app
