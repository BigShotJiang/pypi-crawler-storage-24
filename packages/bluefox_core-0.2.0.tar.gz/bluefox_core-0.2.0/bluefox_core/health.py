from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text

health_router = APIRouter()


@health_router.get("/health")
async def health():
    return {"status": "ok"}


@health_router.get("/readiness")
async def readiness(request: Request):
    checks = {}
    all_ok = True

    db_manager = getattr(request.app.state, "db", None)
    if db_manager and db_manager.engine:
        try:
            async with db_manager.engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            checks["database"] = "ok"
        except Exception as e:
            checks["database"] = f"error: {e}"
            all_ok = False

    redis_client = getattr(request.app.state, "redis", None)
    if redis_client:
        try:
            await redis_client.ping()
            checks["redis"] = "ok"
        except Exception as e:
            checks["redis"] = f"error: {e}"
            all_ok = False

    status = "ready" if all_ok else "not_ready"
    status_code = 200 if all_ok else 503
    return JSONResponse(
        content={"status": status, "checks": checks},
        status_code=status_code,
    )
