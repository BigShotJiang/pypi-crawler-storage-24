"""Alembic integration for bluefox-core.

Provides configure_alembic() — a single function that wires BluefoxSettings,
model auto-discovery, and async engine support into Alembic's migration context.
"""

from __future__ import annotations

import asyncio
import importlib
import inspect
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config
from sqlalchemy.orm import DeclarativeBase

from bluefox_core.database import BluefoxBase, normalize_database_url
from bluefox_core.settings import BluefoxSettings

if TYPE_CHECKING:
    from alembic.operations import MigrationContext

logger = logging.getLogger("bluefox.migrations")

# Conventional locations to scan for models (relative to CWD).
_CONVENTION_PATTERNS = [
    "models.py",
    "app/models.py",
    "*/models.py",
]


def _find_model_modules() -> list[str]:
    """Find Python modules matching convention patterns in CWD."""
    cwd = Path.cwd()
    seen: set[Path] = set()
    modules: list[str] = []

    for pattern in _CONVENTION_PATTERNS:
        for path in sorted(cwd.glob(pattern)):
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            # Convert file path to dotted module name relative to CWD
            relative = path.relative_to(cwd).with_suffix("")
            module_name = ".".join(relative.parts)
            modules.append(module_name)

    return modules


def _check_base_inheritance(module_name: str) -> None:
    """Warn about SQLAlchemy models that don't inherit from BluefoxBase."""
    module = sys.modules.get(module_name)
    if module is None:
        return

    for name, obj in inspect.getmembers(module, inspect.isclass):
        # Only check classes defined in this module (not imports from elsewhere)
        if obj.__module__ != module_name:
            continue
        # Check if it's a SQLAlchemy model (has a DeclarativeBase ancestor)
        # but does NOT inherit from BluefoxBase
        if issubclass(obj, DeclarativeBase) and not issubclass(obj, BluefoxBase):
            logger.warning(
                "Model %s.%s inherits from DeclarativeBase but not BluefoxBase. "
                "It won't be tracked by Bluefox migrations. "
                "Change it to inherit from BluefoxBase instead.",
                module_name,
                name,
            )


def _discover_models(settings: BluefoxSettings) -> None:
    """Import model modules to register tables in BluefoxBase.metadata.

    Discovery order:
    1. If MODELS_MODULE is set explicitly, import only that module.
    2. Otherwise, scan CWD for models.py files by convention.

    After import, warns about any SQLAlchemy model that doesn't inherit
    from BluefoxBase (the "lint" check).
    """
    if settings.MODELS_MODULE:
        importlib.import_module(settings.MODELS_MODULE)
        _check_base_inheritance(settings.MODELS_MODULE)
        return

    # Convention: find and import all models.py files
    modules = _find_model_modules()

    if not modules:
        logger.debug("No models.py files found in %s", Path.cwd())
        return

    for module_name in modules:
        try:
            importlib.import_module(module_name)
            _check_base_inheritance(module_name)
        except ImportError as exc:
            logger.debug("Skipping %s: %s", module_name, exc)


def _run_migrations(connection, context) -> None:  # noqa: ANN001
    """Run migrations synchronously within an async connection."""
    context.configure(connection=connection, target_metadata=BluefoxBase.metadata)
    with context.begin_transaction():
        context.run_migrations()


def configure_alembic(context: MigrationContext) -> None:
    """Configure Alembic with BluefoxSettings, model discovery, and async engine.

    Call this from your migrations/env.py:

        from alembic import context
        from bluefox_core.migrations import configure_alembic

        configure_alembic(context)
    """
    settings = BluefoxSettings()
    _discover_models(settings)

    config = context.config
    db_url = normalize_database_url(settings.DATABASE_URL)

    if context.is_offline_mode():
        context.configure(
            url=db_url,
            target_metadata=BluefoxBase.metadata,
            literal_binds=True,
            dialect_opts={"paramstyle": "named"},
        )
        with context.begin_transaction():
            context.run_migrations()
    else:
        config.set_main_option("sqlalchemy.url", db_url)

        connectable = async_engine_from_config(
            config.get_section(config.config_ini_section, {}),
            prefix="sqlalchemy.",
            poolclass=pool.NullPool,
        )

        async def run_async() -> None:
            async with connectable.connect() as connection:
                await connection.run_sync(lambda conn: _run_migrations(conn, context))
            await connectable.dispose()

        asyncio.run(run_async())
