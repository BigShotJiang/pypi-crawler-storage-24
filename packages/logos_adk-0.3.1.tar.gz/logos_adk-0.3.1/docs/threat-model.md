# Threat Model

## Assets

- prompts and model outputs
- persisted state and workflow checkpoints
- memory stores and knowledge bases
- audit logs and observability traces
- API keys and provider credentials

## Trust Boundaries

- external clients calling `serve`
- provider backends
- persistence backends
- operator-only workflows such as migrations and replay

## Primary Threats

- prompt injection and instruction override attempts
- PII leakage in prompts, outputs, and logs
- unauthorized cross-workspace access
- replay or duplicate execution of long-running requests
- state corruption or backend unavailability
- silent production regressions without traceability

## Current Mitigations

- request auth and workspace scoping in `serve`
- prompt shield, input validation, and PII detection
- audit logging with optional PII redaction
- state and task persistence
- idempotency and dead-letter tracking for queued runs
- per-run telemetry with version/config metadata

## Remaining Assumptions

- operators manage provider/API secrets outside the repo
- tenant boundaries are workspace-level, not full multi-tenant RBAC
- knowledge ingestion trusts authenticated internal callers
