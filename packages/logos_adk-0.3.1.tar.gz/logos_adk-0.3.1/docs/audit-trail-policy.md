# Audit Trail Policy

## What Is Logged

- security decisions such as input validation, prompt injection, and PII checks
- provider fallbacks and timeout events
- deletion requests for retention workflows

## Data Handling

- audit logs include `retention_ttl_days` and `delete_mode`
- PII findings are redacted by default in audit payloads
- request and trace identifiers should be preserved for incident analysis

## Retention

- default audit retention is `30` days
- retention is configurable via `SecurityConfig.audit_retention_days`
- operators should align log retention with workspace and data-class requirements

## Deletion Flow

1. Accept a deletion request with subject and scope metadata.
2. Record the request in the audit trail.
3. Export required evidence before destructive deletion if policy requires it.
4. Execute soft or hard deletion according to the workspace policy.
