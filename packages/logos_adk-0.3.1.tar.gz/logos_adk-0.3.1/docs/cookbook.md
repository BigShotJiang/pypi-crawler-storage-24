# Cookbook

## Common Patterns

### Stable Public Imports

```python
from logos_adk import Agent
from logos_adk.serve import create_app
```

### Workspace-Scoped Service

```python
app = create_app([agent], require_workspace=True)
```

### Idempotent Queued Dispatch

```python
response = await runtime.dispatch(
    "bot",
    "hello",
    session_id="s1",
    idempotency_key="req-123",
    max_retries=2,
)
```

### RBAC-Based API Principal

```json
{
  "ops-key": {
    "name": "ops",
    "role": "operator",
    "workspaces": ["acme"]
  }
}
```
