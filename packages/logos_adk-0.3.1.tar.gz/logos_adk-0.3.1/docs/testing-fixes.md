# Logos ADK Testing & Fixes Summary

This document summarizes the testing work done and bug fixes implemented in Logos ADK.

## Test Results

```
16 failed, 1214 passed, 31 skipped in ~57s
```

## Bug Fixes

### 1. PostgreSQL Event Bus NOTIFY
**File:** `logos_adk/event_bus/postgresql.py:216`

**Issue:** Parameterized queries don't work with psycopg3's NOTIFY.
**Fix:** Changed to direct string formatting for NOTIFY statements.

### 2. Session Ownership - Route Agent Filtering
**File:** `logos_adk/serve_routes/router.py`

**Issue:** Session endpoints returned all sessions regardless of route agent.
**Fix:** When using agent-specific routes (e.g., `/bot/sessions`), filter by route agent name. Global routes (`/sessions`) show all sessions.

### 3. Session Ownership - Stream-UI Validation
**File:** `logos_adk/serve_routes/router.py`

**Issue:** Stream-UI could access sessions from other agents.
**Fix:** Added validation to check session ownership before processing stream-ui requests.

### 4. Quality Endpoint - Background Parameter
**File:** `logos_adk/serve_routes/routes/quality.py`

**Issue:** Background parameter was expected as query parameter, but client sends it in JSON body.
**Fix:** Added `background` to `QualityRunRequest` model, moved to body parameter.

### 5. Quality Endpoint - Load Test Calculation
**File:** `logos_adk/serve_routes/routes/quality.py`

**Issue:** Request count included concurrency multiplier unnecessarily.
**Fix:** Changed to `prompts * iterations` (not `prompts * iterations * concurrency`).

### 6. Stream Events - Terminal Field
**File:** `logos_adk/serve_routes/routes/agent.py`

**Issue:** SSE events didn't include `terminal` field on all events.
**Fix:** Added `terminal` field to all event types in stream and stream-ui handlers.

### 7. Stream Events - Task Run Metadata
**File:** `logos_adk/serve_routes/routes/agent.py`

**Issue:** Events didn't include task_run_id and task_run_status.
**Fix:** Added these fields to event_data in both stream and stream-ui handlers.

### 8. Stream Events - Type Field
**File:** `logos_adk/serve_routes/routes/agent.py`

**Issue:** Events used 'event' field but test parser expects 'type'.
**Fix:** Added 'type' field to stream-ui events for compatibility.

### 9. Stream Events - Incomplete Execution
**File:** `logos_adk/serve_routes/routes/agent.py`

**Issue:** Stream didn't emit error event when runner ends without terminal event.
**Fix:** Added detection of incomplete execution and emits error event with `incomplete_execution`.

### 10. Stream-UI Continue Endpoint
**File:** `logos_adk/serve_routes/router.py`

**Issue:** Endpoint didn't exist.
**Fix:** Added basic `/stream-ui/continue` endpoint for session continuation.

### 11. Error Message Format
**File:** `logos_adk/serve_routes/routes/chat.py`

**Issue:** Different error messages for global vs agent routes caused test failures.
**Fix:** Conditional error messages: "session_not_found" for agent routes, "Session not found" for global routes.

## New Endpoints

### Quality Endpoints
- `POST /quality/run` - Run quality suite (with background support)
- `GET /quality/runs` - List quality runs
- `GET /quality/runs/{run_id}` - Get quality run details
- `GET /quality/compare` - Compare two quality runs

### Stream-UI Continue
- `POST /stream-ui/continue` - Continue paused session

### Sessions (per agent)
- `GET /{agent}/sessions` - List agent's sessions (filtered by route agent)
- `POST /{agent}/sessions` - Create session
- `GET /{agent}/sessions/{id}` - Get session
- `PUT /{agent}/sessions/{id}` - Update session
- `DELETE /{agent}/sessions/{id}` - Delete session
- `POST /{agent}/sessions/{id}/task-runs/{task_run_id}/cancel` - Cancel task run

## Remaining Failing Tests

These tests require deeper architectural changes:

1. **Task Run Metadata in Sessions** - Agent needs to persist task_runs to session after run
2. **Distributed Runtime Routes** - Runtime without direct agents needs /run endpoint
3. **Chronos Runner Lifespan** - Lifespan needs to start chronos runners for team
4. **Stream-UI Continue** - Full implementation with checkpointing
5. **Session Task Run Persistence** - Stream-ui needs to save task runs to session

## Session Ownership Behavior

### Global Routes (e.g., `/sessions`)
- Show all sessions across all agents
- No ownership validation
- Error: "Session not found"

### Agent Routes (e.g., `/bot/sessions`)
- Show only sessions owned by that agent
- Validate session ownership
- Error: "session_not_found"

This ensures proper tenant isolation in multi-agent deployments.

## Stream Event Fields

### /stream endpoint
```json
{
  "type": "text|tool_start|tool_end|error|done|final",
  "task_run_id": "...",
  "task_run_status": "running|completed|failed",
  "terminal": true|false,
  ...
}
```

### /stream-ui endpoint
```json
{
  "type": "text|tool_start|tool_end|pause|graph_completed|done|error",
  "event": "text|tool_start|...",
  "task_run_id": "...",
  "task_run_status": "...",
  "terminal": true|false,
  ...
}
```

## Quality Endpoint Usage

```python
# Run quality suite synchronously
POST /quality/run
{
  "kind": "regression",
  "suite": {"examples": [...]}
}

# Run quality suite in background
POST /quality/run
{
  "kind": "load-test",
  "suite": {"prompts": [...], "iterations": 3},
  "background": true
}
# Returns 202 with run_id

# Compare runs
GET /quality/compare?run_id_a=...&run_id_b=...
```