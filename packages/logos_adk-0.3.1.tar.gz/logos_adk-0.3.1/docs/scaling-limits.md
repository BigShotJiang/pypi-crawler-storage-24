# Scaling Limits

These are reference starting points, not hard guarantees.

## SQLite

- good fit for local, single-node, low-to-moderate internal traffic
- use for development, demos, and small production services
- avoid large multi-writer workloads without strict serialization expectations

## PostgreSQL

- preferred default for shared production backends
- use for persistent state, memory, quality history, and task queues
- pair with observability dashboards and dead-letter monitoring

## Worker Queues

- start with low concurrency and benchmark before raising limits
- use idempotency keys for externally retried jobs
- investigate dead-letter growth before scaling replicas
