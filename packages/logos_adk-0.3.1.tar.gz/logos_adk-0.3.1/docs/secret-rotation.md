# Secret Rotation And Audit Guidance

## What To Rotate

- API keys used for `serve`
- provider credentials
- database credentials
- any proxy or gateway tokens used by providers

## Rotation Workflow

1. Create a new credential.
2. Add it to the environment or secret manager.
3. Roll out workloads with dual-credential support where possible.
4. Validate health, auth, and provider connectivity.
5. Remove the old credential.
6. Record the change in the operational audit trail.

## Audit Expectations

- track who initiated the rotation
- track which environment or workspace was affected
- preserve timestamps, request IDs, and deployment identifiers
