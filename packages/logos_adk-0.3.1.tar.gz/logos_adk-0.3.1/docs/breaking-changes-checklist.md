# Breaking Changes Checklist

- Is every removed public symbol first deprecated?
- Is the replacement documented and reachable from the stable public import surface?
- Are migration notes updated?
- Are release notes updated?
- Are backward compatibility tests updated?
- Is there an upgrade test or fixture covering the prior version?
- Are CLI changes discoverable through `--help` and docs?
- Are persistence migrations safe for SQLite and PostgreSQL?
- Are observability dashboards and alerts updated for the new behavior?
- Are enterprise docs updated if auth/RBAC/tenancy behavior changed?
