# Multi-Tenant Architecture Guidance

## Recommended Isolation Model

Use workspace-scoped tenancy for internal platform deployments:

- workspace-specific API keys or RBAC bindings
- workspace-prefixed session IDs
- workspace metadata attached to ingestion and observability events

## Shared Platform Components

- `serve` layer with auth and workspace enforcement
- PostgreSQL or SQLite state backends
- per-workspace knowledge ingestion
- centralized observability with tenant filters

## Hard Boundaries

- never share session IDs across workspaces without scoping
- avoid mixed-workspace knowledge stores unless metadata filtering is enforced
- grant write scopes only to operators or service accounts
