# Compliance And Security Guidance

## Baseline Expectations

- use authenticated API access for all non-health routes
- enforce workspace scoping for multi-team deployments
- redact PII in audit logs unless a documented policy requires otherwise
- keep provider credentials out of config files and source control

## Auditability

- preserve trace IDs and request IDs in incident workflows
- keep audit retention aligned with workspace policy
- treat deletion requests as auditable events

## Data Handling

- separate knowledge bases by workspace where practical
- classify memory/state data before enabling long retention
- define deletion ownership for state, memory, cache, and observability stores
