# Reference Architectures

## SQLite Single Node

- one API process
- SQLite for state and task queue
- in-memory or lightweight observability
- suited for pilots and low-volume internal apps

## PostgreSQL Shared Service

- multiple API replicas
- PostgreSQL for state, memory, cache metadata, quality history, and task queue
- shared observability store
- suited for several internal teams on one platform

## API Plus Workers

- API tier for synchronous `run` and `stream`
- worker tier for queued long-running jobs
- PostgreSQL task queue with idempotency and replay
- dashboards and alerts for latency, failures, and dead-letter backlog
