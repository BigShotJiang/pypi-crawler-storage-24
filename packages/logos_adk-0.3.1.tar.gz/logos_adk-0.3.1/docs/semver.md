# Semver Policy

Logos ADK follows semantic versioning starting with `0.2.0` for the stable public
surface defined in [`logos_adk.version`](../logos_adk/version.py).

## Public API Surface

The following modules are covered by the compatibility contract:

- `logos_adk`
- `logos_adk.agent`
- `logos_adk.config`
- `logos_adk.observe`
- `logos_adk.runtime`
- `logos_adk.scaling`
- `logos_adk.serve`
- `logos_adk.state_store`
- `logos_adk.workflow`

Imports from [`logos_adk`](../logos_adk/__init__.py) and the modules listed in
`PUBLIC_API_MODULES` are the preferred stable path for application code.

## Versioning Rules

- Patch releases may fix bugs and tighten validation without breaking documented contracts.
- Minor releases may add new fields, helpers, routes, metrics, and config options.
- Major releases may remove deprecated APIs or change documented behavior.

## Deprecation Policy

- Every public removal must first ship with a deprecation warning.
- Deprecated APIs stay available for at least one minor release unless there is a security issue.
- Deprecations should point to a replacement and a target removal version.

Use [`logos_adk.deprecation`](../logos_adk/deprecation.py) for framework-level deprecation warnings.
