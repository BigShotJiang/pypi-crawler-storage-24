# Public And Private Modules

## Public Modules

The semver-governed surface is defined in [`logos_adk.version`](../logos_adk/version.py).
The public import root is [`logos_adk`](../logos_adk/__init__.py), with additional stable
modules listed in `PUBLIC_API_MODULES`.

Preferred import style:

```python
from logos_adk import Agent
from logos_adk.serve import create_app
from logos_adk.workflow import Pipeline
```

## Private Modules

The following are private by contract:

- modules under `logos_adk._*`
- modules not listed in `PUBLIC_API_MODULES`
- implementation details only re-exported for internal compatibility

Private modules may change between minor releases without deprecation guarantees.
