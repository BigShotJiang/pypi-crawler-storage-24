"""Tests for MockProvider."""
import pytest
from logos_adk.providers.mock import MockProvider
from logos_adk.providers import Provider
from logos_adk.types import Message, Response, ToolCall, Usage


def test_mock_provider_is_provider():
    mp = MockProvider(responses=["hello"])
    assert isinstance(mp, Provider)


@pytest.mark.asyncio
async def test_mock_provider_returns_responses_in_order():
    mp = MockProvider(responses=["first", "second"])
    messages = [Message(role="user", content="hi")]
    r1 = await mp.generate(messages)
    assert r1.content == "first"
    r2 = await mp.generate(messages)
    assert r2.content == "second"


@pytest.mark.asyncio
async def test_mock_provider_cycles_responses():
    mp = MockProvider(responses=["only"])
    messages = [Message(role="user", content="hi")]
    r1 = await mp.generate(messages)
    r2 = await mp.generate(messages)
    assert r1.content == "only"
    assert r2.content == "only"


@pytest.mark.asyncio
async def test_mock_provider_with_tool_calls():
    tc = ToolCall(id="tc1", name="search", arguments={"q": "test"})
    mp = MockProvider(responses=[
        Response(content="", tool_calls=[tc], usage=Usage(10, 5), raw={}),
        "final answer",
    ])
    messages = [Message(role="user", content="hi")]
    r1 = await mp.generate(messages)
    assert len(r1.tool_calls) == 1
    r2 = await mp.generate(messages)
    assert r2.content == "final answer"
    assert r2.tool_calls == []


@pytest.mark.asyncio
async def test_mock_provider_records_calls():
    mp = MockProvider(responses=["ok"])
    messages = [Message(role="user", content="hi")]
    await mp.generate(messages, tools=[{"name": "search"}])
    assert len(mp.call_history) == 1
    assert mp.call_history[0]["messages"] == messages
    assert mp.call_history[0]["tools"] == [{"name": "search"}]
