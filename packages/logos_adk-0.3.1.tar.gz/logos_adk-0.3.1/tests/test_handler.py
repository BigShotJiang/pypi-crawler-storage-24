"""Tests for @handler decorator."""
import pytest
from logos_adk.handler import handler, collect_handlers


class TaskMsg:
    pass

class FeedbackMsg:
    pass


class MyAgent:
    @handler(TaskMsg)
    async def on_task(self, msg):
        return "handled task"

    @handler(FeedbackMsg)
    async def on_feedback(self, msg):
        return "handled feedback"

    async def normal_method(self):
        pass


def test_handler_marks_method():
    assert hasattr(MyAgent.on_task, "_logos_handler_type")
    assert MyAgent.on_task._logos_handler_type is TaskMsg


def test_handler_preserves_function():
    assert callable(MyAgent.on_task)


def test_collect_handlers():
    agent = MyAgent()
    handlers = collect_handlers(agent)
    assert TaskMsg in handlers
    assert FeedbackMsg in handlers
    assert len(handlers) == 2


def test_collect_handlers_skips_normal():
    agent = MyAgent()
    handlers = collect_handlers(agent)
    for fn in handlers.values():
        assert fn != agent.normal_method


def test_duplicate_handler_type_raises():
    with pytest.raises(TypeError, match="duplicate"):
        class BadAgent:
            @handler(TaskMsg)
            async def on_task_1(self, msg):
                pass
            @handler(TaskMsg)
            async def on_task_2(self, msg):
                pass
        collect_handlers(BadAgent())
