"""Direct tests for observe config parsing helpers."""
from __future__ import annotations

import pytest

from logos_adk.errors import ConfigError
from logos_adk.observe import ConsoleExporter, InMemoryExporter, LangfuseExporter, NativeObservabilityExporter, OpenTelemetryExporter
from logos_adk.observe.config import load_observers_from_config, resolve_config_secret


def test_load_observers_from_config_supports_shorthand_exporters():
    assert isinstance(load_observers_from_config("console")[0], ConsoleExporter)
    assert isinstance(load_observers_from_config("memory")[0], InMemoryExporter)
    assert isinstance(load_observers_from_config("native")[0], NativeObservabilityExporter)


def test_load_observers_from_config_builds_open_telemetry_exporter(monkeypatch):
    monkeypatch.setenv("OTEL_TOKEN", "secret")
    exporters = load_observers_from_config(
        {
            "exporter": "opentelemetry",
            "endpoint": "http://collector.test/v1/traces",
            "bearer_token": "${OTEL_TOKEN}",
            "headers": {"x-tenant-id": "acme"},
            "compression": "gzip",
        }
    )

    assert len(exporters) == 1
    assert isinstance(exporters[0], OpenTelemetryExporter)
    assert exporters[0].endpoint == "http://collector.test/v1/traces"
    assert exporters[0].bearer_token == "secret"
    assert exporters[0].headers == {"x-tenant-id": "acme"}
    assert exporters[0].compression == "gzip"


def test_load_observers_from_config_builds_langfuse_exporter(monkeypatch):
    monkeypatch.setenv("LANGFUSE_PUBLIC", "pk-live")
    monkeypatch.setenv("LANGFUSE_SECRET", "sk-live")
    exporters = load_observers_from_config(
        {
            "exporter": "langfuse",
            "base_url": "https://langfuse.example",
            "public_key": "${LANGFUSE_PUBLIC}",
            "secret_key": "${LANGFUSE_SECRET}",
            "headers": {"x-tenant-id": "acme"},
        }
    )

    assert len(exporters) == 1
    assert isinstance(exporters[0], LangfuseExporter)
    assert exporters[0].endpoint == "https://langfuse.example/api/public/ingestion"
    assert exporters[0].headers["x-tenant-id"] == "acme"
    assert exporters[0].headers["Authorization"].startswith("Basic ")


def test_load_observers_from_config_rejects_unknown_fields():
    with pytest.raises(ConfigError, match="Unknown observe config fields"):
        load_observers_from_config({"exporter": "console", "foo": "bar"})


def test_resolve_config_secret_supports_literal_and_env(monkeypatch):
    monkeypatch.setenv("OTEL_SECRET", "from-env")

    assert resolve_config_secret("literal", field_name="observe.bearer_token") == "literal"
    assert resolve_config_secret("${OTEL_SECRET}", field_name="observe.bearer_token") == "from-env"
    assert resolve_config_secret("env:OTEL_SECRET", field_name="observe.bearer_token") == "from-env"


def test_resolve_config_secret_rejects_missing_env(monkeypatch):
    monkeypatch.delenv("OTEL_MISSING", raising=False)

    with pytest.raises(ConfigError, match="references environment variable 'OTEL_MISSING'"):
        resolve_config_secret("${OTEL_MISSING}", field_name="observe.bearer_token")
