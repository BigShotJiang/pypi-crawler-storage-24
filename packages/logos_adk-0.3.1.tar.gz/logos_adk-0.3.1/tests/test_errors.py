"""Tests for error hierarchy."""
from logos_adk.errors import (
    LogosError,
    ProviderError,
    RateLimitError,
    AuthenticationError,
    ModelNotFoundError,
    ToolError,
    ToolExecutionError,
    ConfigError,
    UnknownModelError,
    AmbiguousModelError,
    ToolNotFoundError,
    RoutingError,
    MaxRoundsExceeded,
    LogosMemoryError,
    MemoryBackendError,
)


def test_logos_error_is_base():
    err = LogosError("something went wrong")
    assert isinstance(err, Exception)
    assert str(err) == "something went wrong"


def test_provider_error_hierarchy():
    assert issubclass(ProviderError, LogosError)
    assert issubclass(RateLimitError, ProviderError)
    assert issubclass(AuthenticationError, ProviderError)
    assert issubclass(ModelNotFoundError, ProviderError)


def test_rate_limit_error_retry_after():
    err = RateLimitError("rate limited", retry_after=30.0)
    assert err.retry_after == 30.0
    assert isinstance(err, ProviderError)


def test_tool_error_hierarchy():
    assert issubclass(ToolError, LogosError)
    assert issubclass(ToolExecutionError, ToolError)


def test_tool_execution_error_details():
    original = ValueError("bad input")
    err = ToolExecutionError("tool failed", tool_name="search", original_error=original)
    assert err.tool_name == "search"
    assert err.original_error is original


def test_config_error_hierarchy():
    assert issubclass(ConfigError, LogosError)
    assert issubclass(UnknownModelError, ConfigError)
    assert issubclass(AmbiguousModelError, ConfigError)
    assert issubclass(ToolNotFoundError, ConfigError)


def test_multi_agent_errors():
    assert issubclass(RoutingError, LogosError)
    assert issubclass(MaxRoundsExceeded, LogosError)


def test_memory_error_hierarchy():
    assert issubclass(LogosMemoryError, LogosError)
    assert issubclass(MemoryBackendError, LogosMemoryError)
