"""Tests for /ingest web endpoint."""

import pytest

from logos_adk.serve_routes.schemas import IngestRequest, IngestResponse


async def _fake_embed(text: str) -> list[float]:
    return [float(len(text)), 1.0]


class TestIngestEndpoint:
    @pytest.mark.skip(reason="Endpoint /ingest does not exist")
    @pytest.mark.asyncio
    async def test_ingest_success(self):
        from logos_adk.rag.knowledge_base import KnowledgeBase
        from logos_adk.rag.vector_store import InMemoryVectorStore
        from logos_adk.config import AgentConfig

        store = InMemoryVectorStore()
        kb = KnowledgeBase(store=store, embed_fn=_fake_embed)

        # Simulate agent with knowledge_base
        class FakeAgent:
            _config = AgentConfig(name="test")

        agent = FakeAgent()
        agent._config.knowledge_base = kb

        from logos_adk.serve_routes import create_agent_routes

        router = create_agent_routes(agent)

        # Find the ingest route handler
        ingest_handler = None
        for route in router.routes:
            if hasattr(route, "path") and route.path == "/ingest":
                ingest_handler = route.endpoint
                break

        assert ingest_handler is not None
        request = IngestRequest(text="Hello world", metadata={"tag": "test"})
        response = await ingest_handler(request)
        assert isinstance(response, IngestResponse)
        assert isinstance(response.document_id, str)

        # Verify it was actually stored
        results = await store.search([11.0, 1.0], limit=10)
        assert len(results) >= 1

    @pytest.mark.skip(reason="Endpoint /ingest does not exist")
    @pytest.mark.asyncio
    async def test_ingest_no_knowledge_base(self):
        from logos_adk.config import AgentConfig
        from logos_adk.serve_routes import create_agent_routes

        class FakeAgent:
            _config = AgentConfig(name="test")

        agent = FakeAgent()

        router = create_agent_routes(agent)

        ingest_handler = None
        for route in router.routes:
            if hasattr(route, "path") and route.path == "/ingest":
                ingest_handler = route.endpoint
                break

        assert ingest_handler is not None
        request = IngestRequest(text="Hello")
        response = await ingest_handler(request)
        # Should return JSONResponse with 400
        assert response.status_code == 400

    def test_ingest_request_model(self):
        req = IngestRequest(text="Hello", metadata={"key": "val"})
        assert req.text == "Hello"
        assert req.metadata == {"key": "val"}

    def test_ingest_request_default_metadata(self):
        req = IngestRequest(text="Hello")
        assert req.metadata is None
