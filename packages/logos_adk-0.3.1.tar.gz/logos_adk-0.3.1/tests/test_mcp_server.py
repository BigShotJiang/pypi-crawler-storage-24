"""Tests for MCP server."""
import pytest

from logos_adk.mcp.server import _create_mcp_server, serve_as_mcp


class TestCreateMCPServer:
    def test_requires_mcp_package(self, monkeypatch):
        """_create_mcp_server raises ImportError when mcp is not installed."""
        import builtins
        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name.startswith("mcp"):
                raise ImportError("No module named 'mcp'")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)
        from logos_adk.agent import Agent
        from logos_adk.providers.mock import MockProvider
        from logos_adk.types import Response, Usage

        provider = MockProvider(responses=[
            Response(content="ok", tool_calls=[], usage=Usage(1, 1), raw={}),
        ])
        agent = Agent("test", model=provider)
        with pytest.raises(ImportError, match="mcp package required"):
            _create_mcp_server(agent)


class TestServeMCP:
    def test_unknown_transport_raises(self):
        from logos_adk.agent import Agent
        from logos_adk.providers.mock import MockProvider
        from logos_adk.types import Response, Usage

        provider = MockProvider(responses=[
            Response(content="ok", tool_calls=[], usage=Usage(1, 1), raw={}),
        ])
        agent = Agent("test", model=provider)
        with pytest.raises(ValueError, match="Unknown transport"):
            serve_as_mcp(agent, transport="websocket")


class TestServeMCPExports:
    def test_serve_as_mcp_importable(self):
        from logos_adk.mcp import serve_as_mcp as fn
        assert callable(fn)

    def test_serve_as_mcp_async_importable(self):
        from logos_adk.mcp import serve_as_mcp_async as fn
        assert callable(fn)

    def test_top_level_export(self):
        from logos_adk import serve_as_mcp as fn
        assert callable(fn)

    def test_top_level_async_export(self):
        from logos_adk import serve_as_mcp_async as fn
        assert callable(fn)


class TestServeMCPAsync:
    @pytest.mark.asyncio
    async def test_async_rejects_non_stdio(self):
        from logos_adk.mcp.server import serve_as_mcp_async
        from logos_adk.agent import Agent
        from logos_adk.providers.mock import MockProvider
        from logos_adk.types import Response, Usage

        provider = MockProvider(responses=[
            Response(content="ok", tool_calls=[], usage=Usage(1, 1), raw={}),
        ])
        agent = Agent("test", model=provider)
        with pytest.raises(ValueError, match="only supports 'stdio'"):
            await serve_as_mcp_async(agent, transport="sse")
