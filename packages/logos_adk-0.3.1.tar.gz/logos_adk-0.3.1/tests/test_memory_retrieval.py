"""Tests for retrieval helpers."""
from logos_adk.memory import MemoryEntry
from logos_adk.memory.retrieval import retrieval_queries, score_entry, tokenize


def test_tokenize_normalizes_text():
    assert tokenize("Launch-plan in Berlin!!!") == ["launch", "plan", "berlin"]


def test_retrieval_queries_keyword_keeps_original_query():
    assert retrieval_queries("launch berlin", "keyword") == ["launch berlin"]


def test_retrieval_queries_hybrid_expands_tokens():
    assert retrieval_queries("launch berlin", "hybrid") == [
        "launch berlin",
        "launch",
        "berlin",
    ]


def test_score_entry_hybrid_prefers_higher_overlap():
    query = "launch berlin timeline"
    lower_overlap = MemoryEntry(content="berlin office notes")
    higher_overlap = MemoryEntry(content="launch timeline berlin finalized")

    assert score_entry(query, higher_overlap, "hybrid") > score_entry(query, lower_overlap, "hybrid")


def test_score_entry_semantic_boosts_fuzzy_similarity():
    query = "sparkly water preference"
    weak_match = MemoryEntry(content="coffee beans inventory")
    fuzzy_match = MemoryEntry(content="sparkling water is preferred")

    assert score_entry(query, fuzzy_match, "semantic") > score_entry(query, weak_match, "semantic")
