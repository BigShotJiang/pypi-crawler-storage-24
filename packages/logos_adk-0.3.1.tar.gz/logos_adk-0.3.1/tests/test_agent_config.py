"""Tests for AgentConfig and Runnable."""
import pytest
from logos_adk.config import AgentConfig
from logos_adk.runnable import Runnable


def test_agent_config_defaults():
    config = AgentConfig(name="test")
    assert config.name == "test"
    assert config.model is None
    assert config.system_prompt is None
    assert config.tools == []
    assert config.memories == []


def test_agent_config_with_values():
    config = AgentConfig(
        name="bot",
        model="claude-sonnet",
        system_prompt="You are helpful",
    )
    assert config.model == "claude-sonnet"
    assert config.system_prompt == "You are helpful"


def test_runnable_is_abstract():
    with pytest.raises(TypeError):
        Runnable()
