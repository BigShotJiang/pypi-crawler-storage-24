"""Tests for acpx integration."""

from logos_adk.tools import Tool
from logos_adk.tools.acpx import acpx_tool, acpx_agent_tools, _AGENT_DESCRIPTIONS


class TestAcpxTool:
    def test_creates_tool(self):
        t = acpx_tool("claude")
        assert isinstance(t, Tool)
        assert t.name == "claude"

    def test_default_description(self):
        t = acpx_tool("codex")
        assert "codex" in t.description.lower()

    def test_custom_name(self):
        t = acpx_tool("claude", name="ask_claude")
        assert t.name == "ask_claude"

    def test_custom_description(self):
        t = acpx_tool("claude", description="My Claude tool")
        assert t.description == "My Claude tool"

    def test_schema_has_prompt(self):
        t = acpx_tool("codex")
        schema = t.schema
        assert "prompt" in schema["parameters"]["properties"]
        assert schema["parameters"]["required"] == ["prompt"]


class TestAcpxAgentTools:
    def test_default_agents(self):
        tools = acpx_agent_tools()
        names = [t.name for t in tools]
        assert "claude" in names
        assert "codex" in names
        assert "gemini" in names
        assert "qwen" in names

    def test_custom_agent_list(self):
        tools = acpx_agent_tools(["claude", "gemini"])
        assert len(tools) == 2
        names = [t.name for t in tools]
        assert "claude" in names
        assert "gemini" in names

    def test_all_tools_are_tool_instances(self):
        tools = acpx_agent_tools(["claude", "codex"])
        for t in tools:
            assert isinstance(t, Tool)

    def test_known_agents_get_descriptions(self):
        tools = acpx_agent_tools(["claude", "codex"])
        for t in tools:
            assert t.description == _AGENT_DESCRIPTIONS[t.name]

    def test_unknown_agent_gets_default_description(self):
        tools = acpx_agent_tools(["my-custom-agent"])
        assert "my-custom-agent" in tools[0].description


class TestAcpxToolAgentIntegration:
    def test_agent_with_acpx_tools(self):
        from logos_adk.agent import Agent
        from logos_adk.providers.mock import MockProvider
        from logos_adk.types import Response, Usage

        provider = MockProvider(responses=[
            Response(content="ok", tool_calls=[], usage=Usage(1, 1), raw={}),
        ])
        tools = acpx_agent_tools(["claude", "codex"])
        agent = Agent("orchestrator", model=provider).tools(tools)
        assert len(agent._config.tools) == 2

    def test_tool_schemas_for_provider(self):
        tools = acpx_agent_tools(["claude"])
        schema = tools[0].schema
        assert schema["name"] == "claude"
        assert schema["parameters"]["type"] == "object"
        assert "prompt" in schema["parameters"]["properties"]
