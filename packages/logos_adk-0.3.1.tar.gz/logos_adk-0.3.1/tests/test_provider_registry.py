"""Tests for provider registry."""
import pytest
from logos_adk.providers import Provider, ProviderRegistry
from logos_adk.types import Response, Usage
from logos_adk.errors import UnknownModelError, AmbiguousModelError


class FakeProvider(Provider):
    def __init__(self, model: str):
        self.model = model

    async def generate(self, messages, tools=None, output_schema=None, **kwargs):
        return Response(content="ok", tool_calls=[], usage=Usage(0, 0), raw={})

    async def stream(self, messages, tools=None, **kwargs):
        yield


@pytest.fixture
def registry():
    return ProviderRegistry()


def test_register_prefix(registry):
    registry.register("fake-*", lambda model: FakeProvider(model))
    provider = registry.resolve("fake-large")
    assert isinstance(provider, FakeProvider)
    assert provider.model == "fake-large"


def test_resolve_unknown_raises(registry):
    with pytest.raises(UnknownModelError):
        registry.resolve("unknown-model")


def test_resolve_ambiguous_raises(registry):
    registry.register("test-*", lambda model: FakeProvider(model))
    registry.register("test-*", lambda model: FakeProvider(model))
    with pytest.raises(AmbiguousModelError):
        registry.resolve("test-large")


def test_exact_match_over_prefix(registry):
    registry.register("my-model", lambda model: FakeProvider("exact"))
    registry.register("my-*", lambda model: FakeProvider("prefix"))
    provider = registry.resolve("my-model")
    assert provider.model == "exact"
