"""Tests for MCP client."""
import pytest

from logos_adk.mcp.client import MCPClient


class TestMCPClientInit:
    def test_requires_command_or_url(self):
        with pytest.raises(ValueError, match="requires either"):
            MCPClient()

    def test_cannot_have_both(self):
        with pytest.raises(ValueError, match="not both"):
            MCPClient(command="echo", url="http://localhost")

    def test_stdio_mode(self):
        c = MCPClient(command="echo hello")
        assert c._command == "echo hello"
        assert c._url is None

    def test_sse_mode(self):
        c = MCPClient(url="http://localhost:3000/sse")
        assert c._url == "http://localhost:3000/sse"
        assert c._command is None

    def test_from_string_url(self):
        c = MCPClient.from_string("http://localhost:3000/sse")
        assert c._url == "http://localhost:3000/sse"

    def test_from_string_https(self):
        c = MCPClient.from_string("https://api.example.com/mcp")
        assert c._url == "https://api.example.com/mcp"

    def test_from_string_command(self):
        c = MCPClient.from_string("npx @modelcontextprotocol/server-github")
        assert c._command == "npx @modelcontextprotocol/server-github"

    def test_not_connected_by_default(self):
        c = MCPClient(command="echo")
        assert not c.connected

    def test_get_tools_before_connect_raises(self):
        c = MCPClient(command="echo")
        with pytest.raises(RuntimeError, match="not connected"):
            c.get_tools()

    def test_repr(self):
        c = MCPClient(command="my-server")
        assert "my-server" in repr(c)
        assert "disconnected" in repr(c)

    def test_env_and_headers(self):
        c = MCPClient(
            command="my-server",
            env={"KEY": "val"},
            headers={"Authorization": "Bearer xxx"},
        )
        assert c._env == {"KEY": "val"}
        assert c._headers == {"Authorization": "Bearer xxx"}


class TestMCPClientAgentIntegration:
    def test_agent_mcp_builder(self):
        from logos_adk.agent import Agent
        from logos_adk.providers.mock import MockProvider
        from logos_adk.types import Response, Usage

        provider = MockProvider(responses=[
            Response(content="ok", tool_calls=[], usage=Usage(1, 1), raw={}),
        ])
        agent = Agent("bot", model=provider).mcp("npx my-server")
        assert len(agent._config.mcp_servers) == 1
        assert isinstance(agent._config.mcp_servers[0], MCPClient)

    def test_agent_mcp_with_client(self):
        from logos_adk.agent import Agent
        from logos_adk.providers.mock import MockProvider
        from logos_adk.types import Response, Usage

        provider = MockProvider(responses=[
            Response(content="ok", tool_calls=[], usage=Usage(1, 1), raw={}),
        ])
        client = MCPClient(url="http://localhost:3000/sse")
        agent = Agent("bot", model=provider).mcp(client)
        assert agent._config.mcp_servers[0] is client
