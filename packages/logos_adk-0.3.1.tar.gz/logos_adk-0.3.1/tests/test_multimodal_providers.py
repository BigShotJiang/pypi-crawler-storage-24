"""Tests for Gemini and OpenAI Responses multimodal providers."""

from __future__ import annotations

import asyncio
import json

import httpx

from logos_adk.providers.gemini import GeminiProvider
from logos_adk.providers.openai_responses import OpenAIResponsesProvider
from logos_adk.types import ContentPart, Message


def test_openai_responses_provider_serializes_video_audio_and_file_inputs():
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {"type": "output_text", "text": "done"},
                            {
                                "type": "output_video",
                                "video_url": "https://cdn.example.com/out.mp4",
                                "mime_type": "video/mp4",
                                "name": "result",
                            },
                        ],
                    }
                ],
                "usage": {"input_tokens": 11, "output_tokens": 7},
            },
        )

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    provider = OpenAIResponsesProvider(model="gpt-4.1", api_key="test-key", client=client)

    response = asyncio.run(
        provider.generate(
            [
                Message(
                    role="user",
                    content="",
                    content_parts=[
                        ContentPart(type="text", text="Summarize attached media"),
                        ContentPart(type="video", uri="https://example.com/source.mp4", mime_type="video/mp4"),
                        ContentPart(type="audio", data="YXVkaW8=", mime_type="audio/mpeg"),
                        ContentPart(type="file", data="ZmlsZQ==", mime_type="application/pdf", name="brief.pdf"),
                    ],
                )
            ]
        )
    )
    asyncio.run(client.aclose())

    assert captured["url"] == "https://api.openai.com/v1/responses"
    body = captured["body"]
    assert body["input"][0]["content"][1]["type"] == "input_video"
    assert body["input"][0]["content"][2]["type"] == "input_audio"
    assert body["input"][0]["content"][3]["type"] == "input_file"
    assert response.content == "done"
    assert response.content_parts[0].type == "video"
    assert response.content_parts[0].uri == "https://cdn.example.com/out.mp4"


def test_gemini_provider_serializes_multimodal_parts_without_text_fallback():
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content.decode("utf-8"))
        return httpx.Response(
            200,
            json={
                "candidates": [
                    {
                        "content": {
                            "parts": [
                                {"text": "inspected"},
                                {
                                    "fileData": {
                                        "mimeType": "audio/mpeg",
                                        "fileUri": "https://files.example.com/out.mp3",
                                    }
                                },
                            ]
                        }
                    }
                ],
                "usageMetadata": {"promptTokenCount": 9, "candidatesTokenCount": 4},
            },
        )

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    provider = GeminiProvider(model="gemini-2.0-flash", api_key="test-key", client=client)

    response = asyncio.run(
        provider.generate(
            [
                Message(
                    role="user",
                    content="",
                    content_parts=[
                        ContentPart(type="text", text="Inspect these assets"),
                        ContentPart(type="image", uri="https://example.com/photo.png", mime_type="image/png"),
                        ContentPart(type="video", uri="https://example.com/clip.mp4", mime_type="video/mp4"),
                        ContentPart(type="file", uri="https://example.com/brief.pdf", mime_type="application/pdf"),
                    ],
                )
            ]
        )
    )
    asyncio.run(client.aclose())

    assert "generateContent" in str(captured["url"])
    body = captured["body"]
    parts = body["contents"][0]["parts"]
    assert parts[1]["fileData"]["fileUri"] == "https://example.com/photo.png"
    assert parts[2]["fileData"]["fileUri"] == "https://example.com/clip.mp4"
    assert parts[3]["fileData"]["fileUri"] == "https://example.com/brief.pdf"
    assert response.content == "inspected"
    assert response.content_parts[0].type == "audio"
    assert response.content_parts[0].uri == "https://files.example.com/out.mp3"
