"""Tests for core data types."""
from logos_adk.types import Message, ToolCall, ToolResult, Usage, Response, StructuredResponse
from pydantic import BaseModel


class MockOutput(BaseModel):
    summary: str
    score: float


def test_message_user():
    msg = Message(role="user", content="hello")
    assert msg.role == "user"
    assert msg.content == "hello"


def test_message_assistant_with_tool_calls():
    tc = ToolCall(id="tc_1", name="search", arguments={"q": "test"})
    msg = Message(role="assistant", content="", tool_calls=[tc])
    assert len(msg.tool_calls) == 1
    assert msg.tool_calls[0].name == "search"


def test_tool_call():
    tc = ToolCall(id="tc_1", name="search", arguments={"query": "ai"})
    assert tc.id == "tc_1"
    assert tc.name == "search"
    assert tc.arguments == {"query": "ai"}


def test_tool_result_success():
    tr = ToolResult(call_id="tc_1", content={"results": [1, 2, 3]})
    assert tr.call_id == "tc_1"
    assert tr.error is None
    assert tr.duration_ms == 0


def test_tool_result_error():
    tr = ToolResult(call_id="tc_1", content=None, error="connection timeout")
    assert tr.error == "connection timeout"


def test_usage():
    u = Usage(input_tokens=100, output_tokens=50)
    assert u.input_tokens == 100
    assert u.output_tokens == 50


def test_response():
    r = Response(
        content="hello",
        tool_calls=[],
        usage=Usage(input_tokens=10, output_tokens=5),
        raw={"id": "msg_123"},
    )
    assert r.content == "hello"
    assert r.tool_calls == []
    assert r.usage.input_tokens == 10
    assert r.raw["id"] == "msg_123"


def test_structured_response():
    parsed = MockOutput(summary="test", score=0.9)
    r = StructuredResponse(
        content='{"summary": "test", "score": 0.9}',
        tool_calls=[],
        usage=Usage(input_tokens=10, output_tokens=20),
        raw={},
        parsed=parsed,
    )
    assert r.parsed.summary == "test"
    assert r.parsed.score == 0.9
    assert isinstance(r, Response)
