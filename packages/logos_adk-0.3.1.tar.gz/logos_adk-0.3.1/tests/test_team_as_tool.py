import pytest

from logos_adk.agent import Agent
from logos_adk.providers.mock import MockProvider
from logos_adk.team import Team
from logos_adk.tools import Tool
from logos_adk.types import Response, Usage


def _make_agent(name: str, text: str = "ok") -> Agent:
    provider = MockProvider(responses=[
        Response(content=text, tool_calls=[], usage=Usage(1, 1), raw={}),
    ])
    return Agent(name, model=provider)


class TestTeamAsTool:
    def test_as_tool_returns_tool(self):
        a = _make_agent("a")
        team = Team("research", agents=[a])
        t = team.as_tool()
        assert isinstance(t, Tool)

    def test_as_tool_name_defaults_to_team_name(self):
        a = _make_agent("a")
        team = Team("research", agents=[a])
        t = team.as_tool()
        assert t.name == "research"

    def test_as_tool_custom_name(self):
        a = _make_agent("a")
        team = Team("research", agents=[a])
        t = team.as_tool(name="do_research")
        assert t.name == "do_research"

    def test_as_tool_custom_description(self):
        a = _make_agent("a")
        team = Team("research", agents=[a])
        t = team.as_tool(description="Research things")
        assert t.description == "Research things"

    @pytest.mark.asyncio
    async def test_as_tool_executes_team(self):
        a = _make_agent("worker", "team result")
        team = Team("t", agents=[a])
        t = team.as_tool()
        result = await t(prompt="do work")
        assert result == "team result"

    def test_as_tool_schema_has_prompt_param(self):
        a = _make_agent("a")
        team = Team("t", agents=[a])
        t = team.as_tool()
        schema = t.schema
        assert "prompt" in schema["parameters"]["properties"]
        assert schema["parameters"]["required"] == ["prompt"]
