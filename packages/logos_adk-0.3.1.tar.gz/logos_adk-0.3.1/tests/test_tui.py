import pytest
from pathlib import Path
from logos_adk.cli.tui import LogosTUI, MessageWidget

@pytest.mark.asyncio
async def test_tui_app_mount():
    """Test that the TUI app mounts correctly."""
    # Create a dummy config for testing
    config_path = "test_agent.yaml"
    with open(config_path, "w") as f:
        f.write("name: test-agent\nmodel: mock\n")
    
    try:
        app = LogosTUI(config_path)
        async with app.run_test() as pilot:
            # Use a timeout loop to wait for initialization
            for _ in range(50):
                if app.model_name == "mock":
                    break
                await pilot.pause(0.1)
            
            assert app.model_name == "mock"
            
            # Check basic layout
            assert app.query_one("#chat-area") is not None
            assert app.query_one("#chat-input") is not None
            assert app.query_one("#yolo-status") is not None
    finally:
        if Path(config_path).exists():
            Path(config_path).unlink()

@pytest.mark.asyncio
async def test_tui_input_submission():
    """Test submitting input to the TUI."""
    config_path = "test_agent_input.yaml"
    with open(config_path, "w") as f:
        f.write("name: test-agent\nmodel: mock\n")
    
    try:
        app = LogosTUI(config_path)
        async with app.run_test() as pilot:
            # Wait for Ready
            for _ in range(50):
                if app._agent is not None:
                    break
                await pilot.pause(0.1)
            
            # focus input
            app.query_one("#chat-input").focus()
            
            # Type and submit
            for char in "Hello":
                await pilot.press(char)
            await pilot.press("enter")
            
            # Wait a bit for message to process
            await pilot.pause(0.5)
            
            # Check chat area for user message
            chat_area = app.query_one("#chat-area")
            user_messages = [m for m in chat_area.children if isinstance(m, MessageWidget) and m.role == "User"]
            
            assert len(user_messages) >= 1 or any("Input submitted" in str(n.message) for n in app._notifications)
    finally:
        if Path(config_path).exists():
            Path(config_path).unlink()

@pytest.mark.asyncio
async def test_tui_clear_chat():
    """Test clearing the chat in TUI."""
    config_path = "test_agent_clear.yaml"
    with open(config_path, "w") as f:
        f.write("name: test-agent\nmodel: mock\n")
    
    try:
        app = LogosTUI(config_path)
        async with app.run_test() as pilot:
            await pilot.pause(0.5)
            
            # Add a message
            chat_area = app.query_one("#chat-area")
            chat_area.mount(MessageWidget(role="User", content="To be cleared"))
            
            await pilot.pause(0.1)
            
            # Press Ctrl+L
            await pilot.press("ctrl+l")
            
            await pilot.pause(0.1)
            
            # Check if messages were removed
            messages = chat_area.query(MessageWidget)
            assert len(messages) == 0
    finally:
        if Path(config_path).exists():
            Path(config_path).unlink()
