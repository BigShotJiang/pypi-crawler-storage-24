"""Tests for CLI tool wrappers."""
import pytest

from logos_adk.tools import Tool
from logos_adk.tools.cli import cli_tool, claude_code_tool, codex_tool, gemini_tool


class TestCliTool:
    def test_creates_tool(self):
        t = cli_tool("echo hello", name="echo")
        assert isinstance(t, Tool)
        assert t.name == "echo"

    def test_default_name_from_command(self):
        t = cli_tool("my_script.py --flag")
        assert t.name == "my_script.py"

    def test_custom_description(self):
        t = cli_tool("ls", description="List files")
        assert t.description == "List files"

    def test_schema_has_prompt(self):
        t = cli_tool("echo", name="echo")
        schema = t.schema
        assert "prompt" in schema["parameters"]["properties"]
        assert schema["parameters"]["required"] == ["prompt"]

    @pytest.mark.asyncio
    async def test_executes_command(self):
        t = cli_tool("cat", name="cat", description="Echo input back")
        result = await t(prompt="hello world")
        assert "hello world" in result

    @pytest.mark.asyncio
    async def test_command_not_found(self):
        t = cli_tool("nonexistent_command_xyz", name="bad")
        result = await t(prompt="test")
        assert "not found" in result.lower() or "error" in result.lower()

    @pytest.mark.asyncio
    async def test_timeout(self):
        t = cli_tool("sleep 10", name="slow", timeout=0.1)
        result = await t(prompt="")
        assert "timed out" in result


class TestPrebuiltTools:
    def test_claude_code_tool(self):
        t = claude_code_tool()
        assert t.name == "claude_code"
        assert "Claude Code" in t.description

    def test_claude_code_tool_with_model(self):
        t = claude_code_tool(model="opus")
        assert t.name == "claude_code"

    def test_codex_tool(self):
        t = codex_tool()
        assert t.name == "codex"

    def test_gemini_tool(self):
        t = gemini_tool()
        assert t.name == "gemini"
