from __future__ import annotations

import os

from logos_adk.dynamic_orchestration import DepartmentSupervisor
from logos_adk.runnable_config_loader import (
    describe_runnable_from_config,
    detect_runnable_config_kind,
    load_runnable_from_config,
)
from logos_adk.team import Team


FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def test_detect_runnable_config_kind_for_department_supervisor():
    path = os.path.join(FIXTURES, "department_supervisor.yaml")

    assert detect_runnable_config_kind(path) == "department_supervisor"


def test_load_runnable_from_config_supports_team():
    path = os.path.join(FIXTURES, "team_event_bus.yaml")
    runnable = load_runnable_from_config(path)

    assert isinstance(runnable, Team)
    assert runnable.name == "seo_team"


def test_load_runnable_from_config_supports_department_supervisor():
    path = os.path.join(FIXTURES, "department_supervisor.yaml")
    runnable = load_runnable_from_config(path)

    assert isinstance(runnable, DepartmentSupervisor)
    assert runnable.name == "ceo"
    assert describe_runnable_from_config(path) == {
        "kind": "department_supervisor",
        "name": "ceo",
    }
