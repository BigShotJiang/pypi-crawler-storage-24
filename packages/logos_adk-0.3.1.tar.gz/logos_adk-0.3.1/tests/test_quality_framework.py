"""Tests for the integrated quality framework."""
from __future__ import annotations

import json
import os

import pytest

from logos_adk.agent import Agent
from logos_adk.providers.mock import MockProvider
from logos_adk.testing_framework import (
    GoldenExample,
    IntegrationScenario,
    IntegrationStep,
    IsolatedTestEnvironment,
    JudgeCase,
    LLMJudge,
    LoadTestConfig,
    load_golden_dataset,
    run_golden_dataset,
    run_integration_suite,
    run_llm_judge_eval,
    run_load_test,
)


@pytest.mark.asyncio
async def test_run_integration_suite_supports_multi_step_context():
    agent = Agent("bot").model(MockProvider(responses=["hello", "your name is Alex"]))

    results = await run_integration_suite(
        agent,
        [
            IntegrationScenario(
                name="context",
                steps=[
                    IntegrationStep(prompt="My name is Alex", session_id="s1"),
                    IntegrationStep(
                        prompt="What is my name?",
                        session_id="s1",
                        expect_contains=["Alex"],
                    ),
                ],
            )
        ],
    )

    assert len(results) == 1
    assert results[0].passed is True


@pytest.mark.asyncio
async def test_run_load_test_reports_latency_and_counts():
    agent = Agent("bot").model(MockProvider(responses=["ok"]))

    report = await run_load_test(
        agent,
        LoadTestConfig(prompts=["a", "b", "c"], concurrency=2, iterations=2),
    )

    assert report.total_requests == 6
    assert report.success_count == 6
    assert report.error_count == 0
    assert report.avg_latency_ms >= 0


@pytest.mark.asyncio
async def test_run_golden_dataset_detects_regression():
    agent = Agent("bot").model(MockProvider(responses=["stable", "drifted"]))

    results = await run_golden_dataset(
        agent,
        [
            GoldenExample(name="stable", prompt="q1", expected="stable"),
            GoldenExample(name="drift", prompt="q2", expected="expected"),
        ],
    )

    assert results[0].passed is True
    assert results[1].passed is False


def test_load_golden_dataset_reads_json(tmp_path):
    path = tmp_path / "golden.json"
    path.write_text(
        json.dumps(
            [
                {"name": "example", "prompt": "hi", "expected": "hello", "mode": "exact"},
            ]
        )
    )

    dataset = load_golden_dataset(path)

    assert len(dataset) == 1
    assert dataset[0].name == "example"


@pytest.mark.asyncio
async def test_run_llm_judge_eval_uses_judge_agent():
    candidate = Agent("candidate").model(MockProvider(responses=["candidate answer"]))
    judge_agent = Agent("judge").model(
        MockProvider(responses=['{"score": 0.9, "rationale": "good answer"}'])
    )

    results = await run_llm_judge_eval(
        candidate,
        [JudgeCase(name="case", prompt="Explain", criteria="Be correct")],
        LLMJudge(judge_agent),
    )

    assert len(results) == 1
    assert results[0].passed is True
    assert results[0].score == 0.9


def test_isolated_test_environment_sandboxes_env_and_fs():
    original = os.getcwd()
    with IsolatedTestEnvironment() as sandbox:
        assert os.environ["LOGOS_ADK_SANDBOX"] == "1"
        assert os.getcwd() == str(sandbox.workspace)
        assert sandbox.workspace.exists()
        assert sandbox.state_dir.exists()

    assert os.getcwd() == original
