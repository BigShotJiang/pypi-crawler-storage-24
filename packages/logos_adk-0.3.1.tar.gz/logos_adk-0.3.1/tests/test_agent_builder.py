"""Tests for Agent builder API."""
from logos_adk.agent import Agent
from logos_adk.tools import tool, Tool
from logos_adk.tools.toolkit import Toolkit
from logos_adk.runnable import Runnable


@tool
async def fake_search(query: str) -> str:
    """Fake search."""
    return f"results for {query}"


class FakeToolkit(Toolkit):
    def get_tools(self) -> list[Tool]:
        @tool(name="tk_tool")
        async def tk_tool(x: str) -> str:
            """Toolkit tool."""
            return x
        return [tk_tool]


def test_agent_is_runnable():
    agent = Agent("bot")
    assert isinstance(agent, Runnable)


def test_agent_name():
    agent = Agent("my_agent")
    assert agent.name == "my_agent"


def test_builder_model_string():
    agent = Agent("bot").model("claude-sonnet")
    assert agent._config.model == "claude-sonnet"


def test_builder_system():
    agent = Agent("bot").system("You are helpful")
    assert agent._config.system_prompt == "You are helpful"


def test_builder_tools_list():
    agent = Agent("bot").tools([fake_search])
    assert len(agent._config.tools) == 1
    assert agent._config.tools[0].name == "fake_search"


def test_builder_tools_toolkit():
    agent = Agent("bot").tools(FakeToolkit())
    assert len(agent._config.tools) == 1
    assert agent._config.tools[0].name == "tk_tool"


def test_builder_tools_chaining():
    agent = Agent("bot").tools([fake_search]).tools(FakeToolkit())
    assert len(agent._config.tools) == 2


def test_builder_returns_self():
    agent = Agent("bot")
    result = agent.model("claude-sonnet")
    assert result is agent


def test_builder_fluent():
    agent = (
        Agent("bot")
        .model("claude-sonnet")
        .system("helpful")
        .tools([fake_search])
    )
    assert agent.name == "bot"
    assert agent._config.model == "claude-sonnet"
    assert agent._config.system_prompt == "helpful"
    assert len(agent._config.tools) == 1


def test_agent_constructor_shorthand():
    agent = Agent("bot", model="claude-sonnet")
    assert agent._config.model == "claude-sonnet"
