"""Tests for RAG text splitter."""

from logos_adk.rag import Document
from logos_adk.rag.splitter import RecursiveCharacterSplitter


class TestRecursiveCharacterSplitter:
    def test_short_text_single_chunk(self):
        splitter = RecursiveCharacterSplitter(chunk_size=100, chunk_overlap=20)
        doc = Document(content="Short text.", metadata={"source": "test"})
        chunks = splitter.split(doc)
        assert len(chunks) == 1
        assert chunks[0].content == "Short text."
        assert chunks[0].document_id == doc.id

    def test_splits_on_paragraph(self):
        splitter = RecursiveCharacterSplitter(chunk_size=30, chunk_overlap=0)
        doc = Document(content="First paragraph.\n\nSecond paragraph.", metadata={})
        chunks = splitter.split(doc)
        assert len(chunks) == 2
        assert chunks[0].content == "First paragraph."
        assert chunks[1].content == "Second paragraph."

    def test_overlap(self):
        splitter = RecursiveCharacterSplitter(chunk_size=20, chunk_overlap=5)
        doc = Document(content="aaaa bbbb cccc dddd eeee ffff", metadata={})
        chunks = splitter.split(doc)
        assert len(chunks) >= 2
        for i in range(len(chunks) - 1):
            assert chunks[i].content

    def test_chunk_metadata(self):
        splitter = RecursiveCharacterSplitter(chunk_size=20, chunk_overlap=0)
        doc = Document(content="Hello world. Goodbye world.", metadata={"source": "test"})
        chunks = splitter.split(doc)
        for i, chunk in enumerate(chunks):
            assert chunk.metadata["source"] == "test"
            assert chunk.metadata["chunk_index"] == i
            assert chunk.document_id == doc.id

    def test_empty_document(self):
        splitter = RecursiveCharacterSplitter()
        doc = Document(content="", metadata={})
        chunks = splitter.split(doc)
        assert len(chunks) == 0

    def test_custom_separators(self):
        splitter = RecursiveCharacterSplitter(
            chunk_size=12, chunk_overlap=0, separators=["|"]
        )
        doc = Document(content="part one|part two|part three", metadata={})
        chunks = splitter.split(doc)
        assert len(chunks) == 3

    def test_defaults(self):
        splitter = RecursiveCharacterSplitter()
        assert splitter.chunk_size == 1000
        assert splitter.chunk_overlap == 200
