"""Tests for Provider interface."""
import pytest
from logos_adk.providers import Provider
from logos_adk.types import Message, Response, Usage


class FakeProvider(Provider):
    async def generate(self, messages, tools=None, output_schema=None, **kwargs):
        return Response(
            content="fake response",
            tool_calls=[],
            usage=Usage(input_tokens=10, output_tokens=5),
            raw={},
        )

    async def stream(self, messages, tools=None, **kwargs):
        yield


class IncompleteProvider(Provider):
    pass


def test_provider_is_abstract():
    with pytest.raises(TypeError):
        Provider()


def test_incomplete_provider_is_abstract():
    with pytest.raises(TypeError):
        IncompleteProvider()


@pytest.mark.asyncio
async def test_fake_provider_generate():
    provider = FakeProvider()
    messages = [Message(role="user", content="hello")]
    result = await provider.generate(messages)
    assert result.content == "fake response"
    assert result.usage.input_tokens == 10
