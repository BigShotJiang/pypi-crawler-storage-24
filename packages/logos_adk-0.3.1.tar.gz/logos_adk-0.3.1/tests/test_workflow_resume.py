# tests/test_workflow_resume.py
"""Tests for pipeline resume/checkpoint."""
import pytest
from logos_adk.state_store import InMemoryStateStore
from logos_adk.workflow.pipeline import Pipeline


class TestPipelineResume:
    @pytest.mark.asyncio
    async def test_approval_pauses_pipeline(self):
        async def before(ctx):
            return "before_approval"

        async def after(ctx):
            return "after_approval"

        store = InMemoryStateStore()
        p = Pipeline("resume_test", state_store=store)
        p.function(before, name="before")
        p.approval(name="review", message="Check this")
        p.function(after, name="after")

        response = await p.run("start")
        assert response.raw["pipeline_result"]["status"] == "paused"
        assert "after" not in response.raw["pipeline_result"]["outputs"]

    @pytest.mark.asyncio
    async def test_resume_continues_after_approval(self):
        async def before(ctx):
            return "before_value"

        async def after(ctx):
            return f"after with {ctx.get('before', 'none')}"

        store = InMemoryStateStore()
        p = Pipeline("resume_test", state_store=store)
        p.function(before, name="before")
        p.approval(name="review")
        p.function(after, name="after")

        response = await p.run("start")
        pipeline_id = response.raw["pipeline_result"].get("pipeline_id")
        assert pipeline_id is not None

        result = await p.resume(pipeline_id, approval=True)
        assert result.status == "completed"
        assert "after" in result.outputs

    @pytest.mark.asyncio
    async def test_resume_restores_blackboard_across_approval(self):
        async def before(ctx):
            ctx.blackboard["draft"] = "kept"
            return "before_value"

        async def after(ctx):
            return ctx.blackboard["draft"]

        store = InMemoryStateStore()
        p = Pipeline("blackboard_resume", state_store=store)
        p.function(before, name="before")
        p.approval(name="review")
        p.function(after, name="after")

        response = await p.run("start")
        pipeline_id = response.raw["pipeline_result"]["pipeline_id"]

        result = await p.resume(pipeline_id, approval=True)
        assert result.status == "completed"
        assert result.outputs["after"].output == "kept"
        assert result.context.blackboard["draft"] == "kept"

    @pytest.mark.asyncio
    async def test_resume_rejected(self):
        async def before(ctx):
            return "ok"

        store = InMemoryStateStore()
        p = Pipeline("reject_test", state_store=store)
        p.function(before, name="before")
        p.approval(name="review")

        response = await p.run("start")
        pipeline_id = response.raw["pipeline_result"]["pipeline_id"]

        result = await p.resume(pipeline_id, approval=False)
        assert result.status == "failed"

    @pytest.mark.asyncio
    async def test_resume_without_store_raises(self):
        p = Pipeline("no_store")
        with pytest.raises(Exception):
            await p.resume("fake_id")
