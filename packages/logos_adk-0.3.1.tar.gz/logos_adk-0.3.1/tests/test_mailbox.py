import pytest

from logos_adk.mailbox import Mailbox


@pytest.mark.asyncio
async def test_put_and_get():
    mb = Mailbox()
    await mb.put("hello")
    msg = await mb.get()
    assert msg == "hello"


@pytest.mark.asyncio
async def test_fifo_order():
    mb = Mailbox()
    await mb.put("first")
    await mb.put("second")
    assert await mb.get() == "first"
    assert await mb.get() == "second"


@pytest.mark.asyncio
async def test_empty_check():
    mb = Mailbox()
    assert mb.empty()
    await mb.put("msg")
    assert not mb.empty()


@pytest.mark.asyncio
async def test_get_nowait():
    mb = Mailbox()
    await mb.put("msg")
    assert mb.get_nowait() == "msg"


@pytest.mark.asyncio
async def test_get_nowait_empty_returns_none():
    mb = Mailbox()
    assert mb.get_nowait() is None


@pytest.mark.asyncio
async def test_drain():
    mb = Mailbox()
    await mb.put("a")
    await mb.put("b")
    await mb.put("c")
    items = mb.drain()
    assert items == ["a", "b", "c"]
    assert mb.empty()
