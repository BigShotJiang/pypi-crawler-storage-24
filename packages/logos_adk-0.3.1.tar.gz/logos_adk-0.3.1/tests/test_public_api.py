"""Smoke tests for the public API surface."""
from __future__ import annotations

from logos_adk import (
    Agent,
    AgentClassRegistry,
    AgentFactoryRegistry,
    AgentConfig,
    Automatic1111DiffusionBackend,
    ArtifactRecord,
    ArtifactSandbox,
    ArtifactToolkit,
    BudgetExhaustedError,
    CampaignState,
    BudgetAccount,
    BudgetStatus,
    Chronos,
    ContentPart,
    CrewProcess,
    CrewTask,
    DepartmentRoutingDecisionSchema,
    DepartmentConfig,
    DepartmentSpec,
    DepartmentSupervisor,
    DepartmentSupervisorConfig,
    GeminiProvider,
    MediaChunk,
    OpenAIResponsesProvider,
    PostgreSQLCrewCheckpointStore,
    PostgreSQLGraphCheckpointStore,
    PostgreSQLSpendLedger,
    RunnableConfigKind,
    GeneratedToolArtifact,
    GeneratedToolStore,
    DiffusionBackend,
    DiffusionImageResult,
    RoutingConfig,
    InMemorySpendLedger,
    SQLiteSpendLedger,
    SpendBudgetStatus,
    SpendRecord,
    SelfQAAssertion,
    SelfQAAttempt,
    SelfQACheck,
    SelfQAConfig,
    SelfQAReport,
    SelfQAVerdict,
    TemporalToolkit,
    SwarmSubscriptionConfig,
    agent_class,
    agent_class_registry,
    agent_factory,
    agent_factory_registry,
    artifact_sandbox,
    build_diffusion_backend,
    build_agent_config,
    create_app_from_config_paths,
    develop_tool,
    describe_runnable_from_config,
    detect_runnable_config_kind,
    generated_tool_store,
    load_department_supervisor_config,
    load_department_supervisor_from_config,
    load_agent_config,
    load_agent_from_config,
    load_runnable_from_config,
    parse_department_supervisor_config_data,
    parse_agent_config_data,
    serve_from_config_paths,
)


def test_public_api_exports_config_pipeline():
    assert Agent is not None
    assert AgentClassRegistry is not None
    assert AgentFactoryRegistry is not None
    assert AgentConfig is not None
    assert Automatic1111DiffusionBackend is not None
    assert ArtifactRecord is not None
    assert ArtifactSandbox is not None
    assert ArtifactToolkit is not None
    assert BudgetAccount is not None
    assert BudgetStatus is not None
    assert BudgetExhaustedError is not None
    assert CampaignState is not None
    assert Chronos is not None
    assert ContentPart is not None
    assert CrewProcess is not None
    assert CrewTask is not None
    assert DepartmentRoutingDecisionSchema is not None
    assert DepartmentConfig is not None
    assert DepartmentSpec is not None
    assert DepartmentSupervisor is not None
    assert DepartmentSupervisorConfig is not None
    assert DiffusionBackend is not None
    assert DiffusionImageResult is not None
    assert GeminiProvider is not None
    assert GeneratedToolArtifact is not None
    assert GeneratedToolStore is not None
    assert MediaChunk is not None
    assert OpenAIResponsesProvider is not None
    assert PostgreSQLCrewCheckpointStore is not None
    assert PostgreSQLGraphCheckpointStore is not None
    assert PostgreSQLSpendLedger is not None
    assert RunnableConfigKind is not None
    assert RoutingConfig is not None
    assert InMemorySpendLedger is not None
    assert SQLiteSpendLedger is not None
    assert SpendBudgetStatus is not None
    assert SpendRecord is not None
    assert SelfQAAssertion is not None
    assert SelfQAAttempt is not None
    assert SelfQACheck is not None
    assert SelfQAConfig is not None
    assert SelfQAReport is not None
    assert SelfQAVerdict is not None
    assert TemporalToolkit is not None
    assert SwarmSubscriptionConfig is not None
    assert agent_class is not None
    assert agent_class_registry is not None
    assert agent_factory is not None
    assert agent_factory_registry is not None
    assert artifact_sandbox is not None
    assert build_diffusion_backend is not None
    assert build_agent_config is not None
    assert create_app_from_config_paths is not None
    assert develop_tool is not None
    assert describe_runnable_from_config is not None
    assert detect_runnable_config_kind is not None
    assert generated_tool_store is not None
    assert load_department_supervisor_config is not None
    assert load_department_supervisor_from_config is not None
    assert load_agent_config is not None
    assert load_agent_from_config is not None
    assert load_runnable_from_config is not None
    assert parse_department_supervisor_config_data is not None
    assert parse_agent_config_data is not None
    assert serve_from_config_paths is not None
