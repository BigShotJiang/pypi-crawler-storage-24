"""Tests for @tool decorator."""
import pytest
from logos_adk.tools import tool, Tool


@tool
async def search(query: str, limit: int = 5) -> list[dict]:
    """Search documents by query."""
    return [{"id": 1, "text": f"result for {query}"}]


@tool(name="custom_name", description="Custom description")
async def my_func(text: str) -> str:
    """Original docstring."""
    return text.upper()


def test_tool_decorator_creates_tool():
    assert isinstance(search, Tool)


def test_tool_has_name_from_function():
    assert search.name == "search"


def test_tool_has_description_from_docstring():
    assert search.description == "Search documents by query."


def test_tool_schema_has_parameters():
    schema = search.schema
    assert "query" in schema["parameters"]["properties"]
    assert "limit" in schema["parameters"]["properties"]
    assert schema["parameters"]["properties"]["limit"]["default"] == 5


def test_tool_schema_required_params():
    schema = search.schema
    assert "query" in schema["parameters"]["required"]
    assert "limit" not in schema["parameters"]["required"]


def test_tool_custom_name():
    assert my_func.name == "custom_name"


def test_tool_custom_description():
    assert my_func.description == "Custom description"


@pytest.mark.asyncio
async def test_tool_callable():
    result = await search(query="test", limit=3)
    assert result == [{"id": 1, "text": "result for test"}]


def test_tool_sync_function_raises():
    with pytest.raises(TypeError, match="must be async"):
        @tool
        def sync_func(x: int) -> int:
            return x
