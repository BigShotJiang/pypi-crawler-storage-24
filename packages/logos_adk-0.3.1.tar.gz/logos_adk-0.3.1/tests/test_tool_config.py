"""Direct tests for tool config parsing helpers."""
from __future__ import annotations

import pytest

from logos_adk.errors import ToolNotFoundError
from logos_adk.tools import tool
from logos_adk.tools.config import load_tools_from_config
from logos_adk.tools.registry import tool_registry


@pytest.fixture(autouse=True)
def _clear_tool_registry():
    tool_registry.clear()
    yield
    tool_registry.clear()


def test_load_tools_from_config_resolves_registered_tools():
    @tool
    async def config_search(query: str) -> str:
        return query

    resolved = load_tools_from_config(["config_search"])

    assert [tool.name for tool in resolved] == ["config_search"]


def test_load_tools_from_config_rejects_bad_shape():
    with pytest.raises(TypeError, match="tools config must be a list of tool names"):
        load_tools_from_config({"tool": "search"})


def test_load_tools_from_config_rejects_unknown_tool():
    with pytest.raises(ToolNotFoundError, match="missing_tool"):
        load_tools_from_config(["missing_tool"])
