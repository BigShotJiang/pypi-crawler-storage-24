"""Tests for tool registry."""
import pytest
from logos_adk.tools import tool
from logos_adk.tools.registry import ToolRegistry


@pytest.fixture
def registry():
    return ToolRegistry()


@pytest.fixture
def sample_tool():
    @tool
    async def greet(name: str) -> str:
        """Say hello."""
        return f"Hello, {name}"
    return greet


def test_register_and_get(registry, sample_tool):
    registry.register("greet", sample_tool)
    assert registry.get("greet") is sample_tool


def test_get_missing_returns_none(registry):
    assert registry.get("nonexistent") is None


def test_list_tools(registry, sample_tool):
    registry.register("greet", sample_tool)
    assert "greet" in registry.list()


def test_clear(registry, sample_tool):
    registry.register("greet", sample_tool)
    registry.clear()
    assert registry.get("greet") is None
    assert registry.list() == []


def test_tool_decorator_auto_registers():
    from logos_adk.tools.registry import tool_registry
    @tool
    async def auto_registered(x: int) -> int:
        """Auto registered tool."""
        return x
    assert tool_registry.get("auto_registered") is auto_registered
