"""Tests for Toolkit base class."""
import pytest
from logos_adk.tools import tool, Tool
from logos_adk.tools.toolkit import Toolkit


class FakeFileSystem(Toolkit):
    def __init__(self, root: str):
        self.root = root

    def get_tools(self) -> list[Tool]:
        @tool(name="read_file", description=f"Read file from {self.root}")
        async def read_file(path: str) -> str:
            return f"content of {self.root}/{path}"

        @tool(name="list_dir", description=f"List directory in {self.root}")
        async def list_dir(path: str = ".") -> list[str]:
            return [f"{self.root}/{path}/file1.txt"]

        return [read_file, list_dir]


def test_toolkit_get_tools():
    fs = FakeFileSystem(root="/data")
    tools = fs.get_tools()
    assert len(tools) == 2
    assert all(isinstance(t, Tool) for t in tools)


def test_toolkit_tool_names():
    fs = FakeFileSystem(root="/data")
    tools = fs.get_tools()
    names = [t.name for t in tools]
    assert "read_file" in names
    assert "list_dir" in names


def test_toolkit_is_abstract():
    with pytest.raises(TypeError):
        Toolkit()


@pytest.mark.asyncio
async def test_toolkit_tools_are_callable():
    fs = FakeFileSystem(root="/tmp")
    tools = fs.get_tools()
    read = next(t for t in tools if t.name == "read_file")
    result = await read(path="test.txt")
    assert result == "content of /tmp/test.txt"
