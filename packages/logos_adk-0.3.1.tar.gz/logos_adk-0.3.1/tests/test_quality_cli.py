"""Tests for quality CLI commands."""

from __future__ import annotations

import json

from click.testing import CliRunner
import yaml

from logos_adk.agent import Agent
from logos_adk.cli import cli
from logos_adk.providers.mock import MockProvider


def _stub_agent(responses: list[str]) -> Agent:
    return Agent("bot", model=MockProvider(responses=responses))


def test_quality_schema_command_exports_schema(tmp_path):
    runner = CliRunner()

    result = runner.invoke(cli, ["quality", "schema", "--kind", "integration"])

    assert result.exit_code == 0
    assert "Logos ADK Integration Suite" in result.output


def test_quality_template_command_writes_template(tmp_path):
    runner = CliRunner()

    result = runner.invoke(
        cli,
        [
            "quality",
            "template",
            "--kind",
            "regression",
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert "examples" in payload


def test_integration_command_writes_html_report(tmp_path, monkeypatch):
    config = tmp_path / "agent.yaml"
    config.write_text("name: bot\nmodel: mock\n")
    suite = tmp_path / "integration.yaml"
    suite.write_text(
        yaml.safe_dump(
            {
                "scenarios": [
                    {
                        "name": "context",
                        "steps": [
                            {"prompt": "hi", "session_id": "s1"},
                            {"prompt": "who am i", "session_id": "s1", "expect_contains": ["Alex"]},
                        ],
                    }
                ]
            }
        )
    )
    report = tmp_path / "integration.html"

    monkeypatch.setattr("logos_adk.cli.Agent.from_config", lambda _: _stub_agent(["hello", "Alex"]))

    result = CliRunner().invoke(
        cli,
        ["integration", str(config), str(suite), "--html-report", str(report)],
    )

    assert result.exit_code == 0
    assert report.exists()
    assert "Integration Report" in report.read_text()


def test_load_test_command_outputs_json(tmp_path, monkeypatch):
    config = tmp_path / "agent.yaml"
    config.write_text("name: bot\nmodel: mock\n")
    suite = tmp_path / "load.json"
    suite.write_text(json.dumps({"prompts": ["a", "b"], "concurrency": 2, "iterations": 1}))
    output = tmp_path / "load.json.out"

    monkeypatch.setattr("logos_adk.cli.Agent.from_config", lambda _: _stub_agent(["ok"]))

    result = CliRunner().invoke(
        cli,
        ["load-test", str(config), str(suite), "--output", str(output)],
    )

    assert result.exit_code == 0
    payload = yaml.safe_load(output.read_text())
    assert payload["total_requests"] == 2


def test_integration_command_writes_markdown_and_csv_reports(tmp_path, monkeypatch):
    config = tmp_path / "agent.yaml"
    config.write_text("name: bot\nmodel: mock\n")
    suite = tmp_path / "integration.yaml"
    suite.write_text(
        yaml.safe_dump(
            {
                "scenarios": [
                    {"name": "ok", "steps": [{"prompt": "hello", "expect_contains": ["ok"]}]},
                ]
            }
        )
    )
    markdown = tmp_path / "report.md"
    csv_report = tmp_path / "report.csv"

    monkeypatch.setattr("logos_adk.cli.Agent.from_config", lambda _: _stub_agent(["ok"]))

    result = CliRunner().invoke(
        cli,
        [
            "integration",
            str(config),
            str(suite),
            "--markdown-report",
            str(markdown),
            "--csv-report",
            str(csv_report),
        ],
    )

    assert result.exit_code == 0
    assert "# Integration Report" in markdown.read_text()
    assert "section,column,value,row_index" in csv_report.read_text()


def test_regression_command_fails_on_mismatch(tmp_path, monkeypatch):
    config = tmp_path / "agent.yaml"
    config.write_text("name: bot\nmodel: mock\n")
    suite = tmp_path / "regression.yaml"
    suite.write_text(
        yaml.safe_dump(
            {
                "examples": [
                    {"name": "ok", "prompt": "a", "expected": "match"},
                    {"name": "bad", "prompt": "b", "expected": "expected"},
                ]
            }
        )
    )

    monkeypatch.setattr(
        "logos_adk.cli.Agent.from_config", lambda _: _stub_agent(["match", "drift"])
    )

    result = CliRunner().invoke(cli, ["regression", str(config), str(suite)])

    assert result.exit_code == 1
    assert "1/2 passed" in result.output


def test_judge_eval_command_supports_inline_mock_judge(tmp_path, monkeypatch):
    config = tmp_path / "agent.yaml"
    config.write_text("name: bot\nmodel: mock\n")
    suite = tmp_path / "judge.yaml"
    suite.write_text(
        yaml.safe_dump(
            {
                "judge": {
                    "pass_threshold": 0.7,
                    "mock_response": '{"score": 0.9, "rationale": "good"}',
                },
                "cases": [{"name": "c1", "prompt": "hi", "criteria": "be correct"}],
            }
        )
    )

    monkeypatch.setattr("logos_adk.cli.Agent.from_config", lambda _: _stub_agent(["answer"]))

    result = CliRunner().invoke(cli, ["judge-eval", str(config), str(suite)])

    assert result.exit_code == 0
    assert "1/1 passed" in result.output
