# Security Policy

## Supported versions

Security fixes are applied to the latest release line.

## Reporting a vulnerability

Do not open a public GitHub issue for unpatched security vulnerabilities.

Until a dedicated security contact is published, report vulnerabilities privately to the repository maintainers through the repository hosting platform's private reporting feature or a private maintainer contact channel.

Include:

- affected version or commit
- impact summary
- reproduction steps
- suggested mitigation if available

## Response goals

- acknowledge receipt promptly
- reproduce and triage the report
- prepare a fix or mitigation
- publish a coordinated patch and advisory when ready
