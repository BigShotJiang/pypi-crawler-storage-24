#!/usr/bin/env bash
set -euo pipefail

python_bin="python3"
if [[ -x ".venv/bin/python" ]]; then
  python_bin=".venv/bin/python"
fi

smoke_tests=(
  tests/test_agent_config.py
  tests/test_agent_cache.py
  tests/test_agent_run.py
  tests/test_errors.py
  tests/test_runtime.py
  tests/test_artifact_operator_surface.py
  tests/test_public_framework_quality.py
  tests/test_runnable_cli.py
  tests/test_quality_cli.py
  tests/test_route_handlers.py
  tests/test_state.py
  tests/test_streaming.py
  tests/test_serve.py
  tests/test_serve_cli.py
  tests/test_retrieval_operator_surface.py
  tests/test_evaluation_operator_surface.py
  tests/test_evaluation_loop.py
)

"${python_bin}" -m ruff check --config ruff.toml \
  logos_adk/serve.py \
  logos_adk/serve_routes/router.py \
  logos_adk/serve_routes/routes/agent.py \
  logos_adk/serve_routes/routes/__init__.py \
  logos_adk/chronos.py \
  logos_adk/runnable_config_loader.py \
  logos_adk/cli/__init__.py \
  logos_adk/cli/main.py \
  logos_adk/cli/commands/__init__.py \
  logos_adk/cli/commands/agent.py \
  logos_adk/cli/commands/project.py \
  logos_adk/cli/commands/quality.py

"${python_bin}" -m mypy logos_adk
"${python_bin}" -m coverage erase
"${python_bin}" -m pytest --cov=logos_adk --cov-report=term-missing:skip-covered --cov-report=xml "${smoke_tests[@]}" -q
