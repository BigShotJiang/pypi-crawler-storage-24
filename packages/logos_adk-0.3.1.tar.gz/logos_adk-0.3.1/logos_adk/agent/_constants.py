"""Shared constants for the agent package."""
from __future__ import annotations

from dataclasses import dataclass


_MAX_TOOL_ROUNDS = 10
_UNSET = object()


@dataclass
class _AgentRoutingDecision:
    ordered_model_keys: list[str]
    selected_model_key: str
    confidence_tier: str
    budget_ratio: float = 0.0
    canary_model_key: str | None = None
    used_canary: bool = False
    routed_for_budget: bool = False
    source: str = "heuristic"
    budget_preference: str = "balanced"
    reason: str = ""
