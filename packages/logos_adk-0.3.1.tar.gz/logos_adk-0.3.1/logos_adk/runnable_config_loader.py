"""Load executable runnables from YAML config files."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml

from logos_adk.agent import Agent
from logos_adk.dynamic_orchestration_config_parser import (
    load_department_supervisor_from_config,
)
from logos_adk.team_config_parser import load_team_from_config


RunnableConfigKind = Literal["agent", "team", "department_supervisor"]


def detect_runnable_config_kind(path: str) -> RunnableConfigKind:
    """Detect which executable type a YAML config describes."""
    with open(path) as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        return "agent"
    cfg_type = data.get("type")
    if cfg_type == "team":
        return "team"
    if cfg_type == "department_supervisor":
        return "department_supervisor"
    return "agent"


def load_runnable_from_config(path: str) -> Any:
    """Load an Agent, Team, or DepartmentSupervisor from a YAML config file."""
    kind = detect_runnable_config_kind(path)
    if kind == "team":
        return load_team_from_config(path)
    if kind == "department_supervisor":
        return load_department_supervisor_from_config(path)
    return Agent.from_config(path)


def describe_runnable_from_config(path: str) -> dict[str, str]:
    """Return minimal metadata about a runnable config."""
    runnable = load_runnable_from_config(path)
    return {
        "kind": detect_runnable_config_kind(path),
        "name": getattr(runnable, "name", Path(path).stem),
    }


__all__ = [
    "RunnableConfigKind",
    "detect_runnable_config_kind",
    "load_runnable_from_config",
    "describe_runnable_from_config",
]
