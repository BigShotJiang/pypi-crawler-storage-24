
from typing import Any
from logos_adk.tools import tool
from logos_adk.context import get_run_context

def _get_ctx():
    # Safe way to get context from current execution task
    run_ctx = get_run_context()
    if run_ctx and hasattr(run_ctx, 'pipeline_ctx'):
        return run_ctx.pipeline_ctx
    return None

@tool
async def post_info(key: str, value: Any, self: Any = None):
    """
    Записать важную информацию на 'Общую доску' знаний команды.
    Эта информация будет мгновенно доступна всем другим агентам.
    """
    import logging
    tool_logger = logging.getLogger("logos_adk.tool")
    ctx = _get_ctx() or (self._config.metadata.get('_pipeline_ctx') if hasattr(self, '_config') else None)
    if ctx:
        tool_logger.info(f"Запись на доску: {key} = {str(value)[:100]}...")
        ctx.blackboard[key] = value
        return f"Информация по ключу '{key}' сохранена на общую доску."
    return "Ошибка: контекст команды не найден."


@tool
async def post_info_if_version(key: str, value: Any, expected_version: int, self: Any = None):
    """
    Оптимистичная запись на доску: обновляет ключ только если его версия не изменилась.
    Используй это, когда несколько агентов могут писать в один и тот же ключ.
    """
    import logging
    tool_logger = logging.getLogger("logos_adk.tool")
    ctx = _get_ctx() or (self._config.metadata.get('_pipeline_ctx') if hasattr(self, '_config') else None)
    if ctx:
        try:
            new_version = ctx.blackboard.compare_and_set(key, value, expected_version=expected_version)
        except Exception as exc:
            tool_logger.warning(f"Конфликт записи на доску: {key} expected={expected_version}: {exc}")
            return f"Конфликт записи по ключу '{key}': {exc}"
        tool_logger.info(f"CAS запись на доску: {key} -> version {new_version}")
        return {"key": key, "version": new_version, "status": "updated"}
    return "Ошибка: контекст команды не найден."

@tool
async def get_info(key: str, self: Any = None):
    """
    Прочитать информацию с 'Общей доски' знаний команды по ключу.
    Используй это, чтобы узнать, что нашли или решили твои коллеги.
    """
    import logging
    tool_logger = logging.getLogger("logos_adk.tool")
    ctx = _get_ctx() or (self._config.metadata.get('_pipeline_ctx') if hasattr(self, '_config') else None)
    if ctx:
        val = ctx.blackboard.get(key)
        if val is not None:
            tool_logger.info(f"Чтение с доски: {key} (найдено)")
            return val
        tool_logger.warning(f"Чтение с доски: {key} (не найдено!)")
        return f"Информация по ключу '{key}' не найдена."
    return "Ошибка: контекст команды не найден."


@tool
async def get_info_with_version(key: str, self: Any = None):
    """
    Прочитать значение и текущую версию ключа на доске.
    Полезно перед post_info_if_version для optimistic concurrency control.
    """
    import logging
    tool_logger = logging.getLogger("logos_adk.tool")
    ctx = _get_ctx() or (self._config.metadata.get('_pipeline_ctx') if hasattr(self, '_config') else None)
    if ctx:
        if key in ctx.blackboard:
            tool_logger.info(f"Чтение с доски с версией: {key} (найдено)")
            return {
                "key": key,
                "value": ctx.blackboard[key],
                "version": ctx.blackboard.version(key),
            }
        return {"key": key, "value": None, "version": ctx.blackboard.version(key)}
    return "Ошибка: контекст команды не найден."
