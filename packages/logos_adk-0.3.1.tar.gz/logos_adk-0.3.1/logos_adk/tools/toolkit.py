"""Toolkit base class for grouping related tools."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from logos_adk.tools import Tool


class Toolkit(ABC):
    """Base class for a group of related tools."""

    @abstractmethod
    def get_tools(self) -> list[Tool]:
        """Return the list of tools provided by this toolkit."""
        ...
