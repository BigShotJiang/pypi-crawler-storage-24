
from typing import List, Optional
from logos_adk.tools import tool
from logos_adk.types import ToolResult

@tool
async def ask_client(question: str, options: Optional[List[str]] = None):
    """
    Остановить выполнение и задать вопрос человеку. 
    Используй это, когда тебе нужно принять решение вместе с клиентом или получить важные данные.
    Если передать список 'options', у пользователя появятся кнопки выбора.
    """
    return ToolResult(
        call_id="ask_human_pause",
        content=question,
        status="paused" # Это магический флаг, который активирует кнопки в UI
    )
