"""Tool registry for Logos ADK."""
from __future__ import annotations

from typing import Any


class ToolRegistry:
    """Global registry of available tools."""

    def __init__(self):
        self._tools: dict = {}

    def register(self, name: str, tool: Any) -> None:
        """Register a tool by name."""
        self._tools[name] = tool

    def get(self, name: str) -> Any | None:
        """Get a tool by name, or None if not found."""
        return self._tools.get(name)

    def list(self) -> list[str]:
        """List all registered tool names."""
        return list(self._tools.keys())

    def clear(self):
        """Remove all registered tools."""
        self._tools.clear()


tool_registry = ToolRegistry()
