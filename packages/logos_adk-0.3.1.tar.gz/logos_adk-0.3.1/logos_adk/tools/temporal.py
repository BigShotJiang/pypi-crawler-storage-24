"""Temporal autonomy tools for deferred agent work."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from logos_adk.tools import Tool
from logos_adk.tools.toolkit import Toolkit


class TemporalToolkit(Toolkit):
    """Tools that let an agent schedule future work for itself or teammates."""

    def __init__(self, actor: Any) -> None:
        self._actor = actor

    def get_tools(self) -> list[Tool]:
        actor = self._actor

        async def schedule_task(
            task: str,
            *,
            delay_seconds: float | None = None,
            due_at: str | None = None,
            to_agent: str | None = None,
            session_id: str | None = None,
            campaign_id: str | None = None,
        ) -> dict[str, Any]:
            """Schedule a future task. Example: delay_seconds=86400 for 24 hours."""
            parsed_due_at: datetime | None = None
            if isinstance(due_at, str) and due_at.strip():
                parsed_due_at = datetime.fromisoformat(due_at.strip())
            record = actor.schedule_task(
                task,
                to_agent=to_agent,
                delay_seconds=delay_seconds,
                due_at=parsed_due_at,
                session_id=session_id,
                campaign_id=campaign_id,
            )
            return {
                "event_id": record.id,
                "topic": record.topic,
                "campaign_id": record.campaign_id,
                "available_at": record.available_at,
                "target_agent": to_agent or actor.name,
            }

        return [
            Tool(
                fn=schedule_task,
                name="schedule_task",
                description=(
                    "Schedule a future task for yourself or another team member. "
                    "Use delay_seconds for relative scheduling or due_at for an ISO datetime."
                ),
            )
        ]


__all__ = ["TemporalToolkit"]
