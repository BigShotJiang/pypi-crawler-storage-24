
from typing import Any, Dict
from logos_adk.tools import tool
from logos_adk.workflow.config import save_graph_config

def _get_graph():
    import inspect
    frame = inspect.currentframe()
    while frame:
        potential_agent = frame.f_locals.get('self')
        if hasattr(potential_agent, '_config'):
            ctx = potential_agent._config.metadata.get('_pipeline_ctx')
            if ctx:
                # In ADK, the Graph is often available through internal references
                # We'll look for the graph object that is executing this context
                # For this implementation, we'll try to find it in the stack or metadata
                return potential_agent._config.metadata.get('_executing_graph')
        frame = frame.f_back
    return None

@tool
async def modify_workflow(new_definition: Dict[str, Any]):
    """
    Изменить структуру текущего workflow (YAML конфигурацию команды).
    Вы можете добавлять новые узлы, менять связи (edges) или менять входную точку.
    Принимает полный JSON-объект структуры графа.
    """
    from logos_adk.context import get_run_context
    import logging
    tool_logger = logging.getLogger("logos_adk.tool")
    tool_logger.info("Эволюция: Получен запрос на изменение структуры воркфлоу.")
    
    # 1. Try to find graph in RunContext metadata
    graph = None
    run_ctx = get_run_context()
    if run_ctx and hasattr(run_ctx, 'pipeline_ctx'):
        ctx = run_ctx.pipeline_ctx
        graph = ctx.metadata.get('_executing_graph')
    
    # 2. Fallback to stack search only if RunContext fails
    if not graph:
        import inspect
        frame = inspect.currentframe()
        while frame:
            potential_graph = frame.f_locals.get('self')
            if hasattr(potential_graph, 'update_from_definition'):
                graph = potential_graph
                break
            frame = frame.f_back
    
    if not graph:
        return "Ошибка: Не удалось найти объект Графа для модификации."

    try:
        # Update memory and YAML
        graph.update_from_definition(new_definition)
        save_graph_config(graph)
        
        return f"Workflow '{graph.name}' успешно эволюционировал! Изменения сохранены в {graph._source_path}."
    except Exception as e:
        return f"Ошибка при эволюции workflow: {str(e)}"
