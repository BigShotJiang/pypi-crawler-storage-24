"""Tool config parsing helpers."""
from __future__ import annotations

from typing import Any

from logos_adk.errors import ToolNotFoundError
from logos_adk.tools.registry import tool_registry


def load_tools_from_config(config: Any) -> list[Any]:
    """Resolve a list of tool names from YAML config."""
    if config is None:
        return []
    if not isinstance(config, list) or not all(isinstance(name, str) for name in config):
        raise TypeError("tools config must be a list of tool names")

    tools: list[Any] = []
    for tool_name in config:
        tool = tool_registry.get(tool_name)
        if tool is None:
            try:
                from logos_adk.tool_synthesis import GeneratedToolStore

                tool = GeneratedToolStore().resolve_tool(tool_name)
            except Exception:
                tool = None
        if tool is None:
            raise ToolNotFoundError(
                f"Tool '{tool_name}' not found in registry. "
                f"Available: {tool_registry.list()}"
            )
        tools.append(tool)
    return tools
