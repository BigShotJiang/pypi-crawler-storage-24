
from typing import Any, Optional
from logos_adk.tools import tool
from logos_adk.agent import Agent
from logos_adk.tools.blackboard import (
    get_info,
    get_info_with_version,
    post_info,
    post_info_if_version,
)

# Global registry for dynamically created agents to show in Dashboard
dynamic_agents = {}

@tool
async def spawn_agent(name: str, instructions: str, description: Optional[str] = None, self: Any = None):
    """
    Создать нового специализированного ИИ-агента для решения конкретной подзадачи.
    Новый агент будет иметь доступ к общей доске знаний и сможет консультироваться с коллегами.
    Возвращает подтверждение создания. Теперь вы можете вызывать его через инструмент 'ask_{name.lower()}'.
    """
    import inspect
    import logging
    tool_logger = logging.getLogger("logos_adk.tool")
    tool_logger.info(f"Фабрика: Создаю нового агента '{name}'")
    
    # 1. Get the model from the creator agent (to reuse provider/mock)
    creator_model = None
    potential_agent = self
    
    if not potential_agent:
        frame = inspect.currentframe()
        while frame:
            obj = frame.f_locals.get('self')
            if isinstance(obj, Agent):
                potential_agent = obj
                break
            frame = frame.f_back

    if potential_agent:
        creator_model = potential_agent._config.model

    if not creator_model:
        return "Ошибка: Не удалось определить модель для нового агента."

    # 2. Initialize new agent
    new_agent = Agent(name, model=creator_model, system=instructions)
    
    # 3. Give standard team tools
    new_agent.tools([post_info, get_info, get_info_with_version, post_info_if_version])
    
    # 4. Register globally for Dashboard visibility
    dynamic_agents[name] = new_agent
    
    # 5. Add the new agent as a tool to the CREATOR agent
    if potential_agent:
        potential_agent.tools([new_agent.as_tool(description=description)])
        # Important: we need to notify the runtime that tools have changed
        # LLMs usually need a fresh turn to 'see' new tools
    
    return f"Агент '{name}' успешно создан и добавлен в вашу команду как инструмент 'ask_{name.lower()}'."
