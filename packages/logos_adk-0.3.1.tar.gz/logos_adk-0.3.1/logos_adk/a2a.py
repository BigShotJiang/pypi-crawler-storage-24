"""A2A protocol primitives for agent-to-agent collaboration."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4


@dataclass
class A2AMessage:
    """Base envelope for an agent-to-agent protocol message."""

    from_agent: str
    to_agent: str
    content: str
    conversation_id: str | None = None
    message_id: str = field(default_factory=lambda: uuid4().hex)
    protocol: str = "a2a/v1"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class A2ARequest(A2AMessage):
    """A task request sent from one agent to another."""

    task_id: str = field(default_factory=lambda: uuid4().hex)
    expects_response: bool = True


@dataclass
class A2AResponse(A2AMessage):
    """A structured response to a prior A2A request."""

    request_id: str = ""
    status: str = "completed"
    error: str | None = None


__all__ = [
    "A2AMessage",
    "A2ARequest",
    "A2AResponse",
]
