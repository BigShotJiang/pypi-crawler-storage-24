"""Agent state management."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from logos_adk.types import Message


@dataclass
class AgentState:
    """State of a running agent. Extensible through subclassing."""

    messages: list[Message] = field(default_factory=list)
    session_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    version: int = 0
    updated_at: datetime | None = None
