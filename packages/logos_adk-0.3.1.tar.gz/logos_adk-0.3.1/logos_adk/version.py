"""Central version and stability metadata for Logos ADK."""

from __future__ import annotations

__version__ = "0.3.0"
API_VERSION = "v1"
STABILITY_POLICY = "semver"
PUBLIC_IMPORT_ROOT = "logos_adk"

# Modules listed here are covered by the semver/public API contract.
PUBLIC_API_MODULES = (
    "logos_adk",
    "logos_adk.agent",
    "logos_adk.config",
    "logos_adk.observe",
    "logos_adk.runtime",
    "logos_adk.scaling",
    "logos_adk.serve",
    "logos_adk.state_store",
    "logos_adk.workflow",
)

# Modules and naming patterns outside this list are considered internal.
PRIVATE_MODULE_PREFIXES = (
    "logos_adk._",
    "logos_adk.__",
)
