"""Event bus data models."""
from __future__ import annotations

from dataclasses import dataclass

from logos_adk.checkpoint_json import JSONObject


EVENT_BUS_SCHEMA_KIND = "event_bus"
EVENT_BUS_SCHEMA_VERSION = 2

EVENT_BUS_COLUMNS = (
    "id",
    "topic",
    "payload_json",
    "status",
    "created_at",
    "updated_at",
    "available_at",
    "campaign_id",
    "correlation_id",
    "run_id",
    "publisher",
    "lease_owner",
    "lease_expires_at",
    "attempt",
    "dedupe_key",
    "last_error",
)


@dataclass
class EventRecord:
    """A single published event."""

    id: str
    topic: str
    payload: JSONObject
    status: str
    created_at: str
    updated_at: str
    available_at: str
    campaign_id: str | None = None
    correlation_id: str | None = None
    run_id: str | None = None
    publisher: str | None = None
    lease_owner: str | None = None
    lease_expires_at: str | None = None
    attempt: int = 0
    dedupe_key: str | None = None
    last_error: str | None = None


__all__ = [
    "EVENT_BUS_SCHEMA_KIND",
    "EVENT_BUS_SCHEMA_VERSION",
    "EVENT_BUS_COLUMNS",
    "EventRecord",
]
