"""Event bus package for hybrid graph and swarm orchestration."""
from __future__ import annotations

from .base import (
    EventBus,
    _clone_record,
    _iso_after,
    _utcnow,
    _utcnow_iso,
    _validate_lease_owner,
    _validate_topic,
)
from .in_memory import InMemoryEventBus
from .models import (
    EVENT_BUS_COLUMNS,
    EVENT_BUS_SCHEMA_KIND,
    EVENT_BUS_SCHEMA_VERSION,
    EventRecord,
)
from .postgresql import PostgreSQLEventBus
from .sqlite import SQLiteEventBus

__all__ = [
    # Base
    "EventBus",
    "_clone_record",
    "_iso_after",
    "_utcnow",
    "_utcnow_iso",
    "_validate_lease_owner",
    "_validate_topic",
    # Models
    "EVENT_BUS_COLUMNS",
    "EVENT_BUS_SCHEMA_KIND",
    "EVENT_BUS_SCHEMA_VERSION",
    "EventRecord",
    # Implementations
    "InMemoryEventBus",
    "SQLiteEventBus",
    "PostgreSQLEventBus",
]
