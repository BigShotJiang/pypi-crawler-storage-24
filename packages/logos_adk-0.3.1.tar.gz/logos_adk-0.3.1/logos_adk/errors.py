"""Error hierarchy for Logos ADK."""
from __future__ import annotations

from typing import Any


class LogosError(Exception):
    """Base error for all Logos ADK errors."""


# --- Provider errors ---

class ProviderError(LogosError):
    """Error communicating with an LLM provider."""


class RateLimitError(ProviderError):
    """Provider rate limit exceeded."""

    def __init__(self, message: str, retry_after: float = 0):
        super().__init__(message)
        self.retry_after = retry_after


class AuthenticationError(ProviderError):
    """Invalid API key or credentials."""


class ModelNotFoundError(ProviderError):
    """Requested model does not exist at the provider."""


# --- Tool errors ---

class ToolError(LogosError):
    """Error related to tool execution."""


class ToolExecutionError(ToolError):
    """A tool raised an exception during execution."""

    def __init__(self, message: str, tool_name: str, original_error: Exception):
        super().__init__(message)
        self.tool_name = tool_name
        self.original_error = original_error


# --- Config errors ---

class ConfigError(LogosError):
    """Error in agent or runtime configuration."""


class UnknownModelError(ConfigError):
    """Model name does not match any registered provider."""


class AmbiguousModelError(ConfigError):
    """Model name matches multiple providers."""


class ToolNotFoundError(ConfigError):
    """Tool name in YAML config not found in registry."""


# --- Multi-agent errors ---

class RoutingError(LogosError):
    """Message sent to agent not in allowed topology."""


class MaxRoundsExceeded(LogosError):
    """Team exceeded max_rounds limit."""


# --- Memory errors ---

class LogosMemoryError(LogosError):
    """Error related to the memory system.

    Named LogosMemoryError to avoid shadowing Python's built-in MemoryError.
    """


class MemoryBackendError(LogosMemoryError):
    """Memory backend is unavailable or failed."""


# --- State errors ---

class StateError(LogosError):
    """Error related to agent state persistence or versioning."""


class StateBackendError(StateError):
    """Persistent state backend is unavailable or failed."""


class QueueFullError(StateError):
    """Event bus queue depth exceeded — backpressure engaged."""


# --- Guardrail errors ---

class GuardrailError(LogosError):
    """A guardrail blocked the content."""

    def __init__(self, message: str, result: Any = None):
        super().__init__(message)
        self.result = result


# --- Security errors ---

class SecurityError(LogosError):
    """Base security error."""


class InputValidationError(SecurityError):
    """Input failed validation."""


class PromptInjectionError(SecurityError):
    """Prompt injection was detected."""


class PIIDetectedError(SecurityError):
    """Blocked PII was detected."""


# --- Reliability errors ---

class CircuitBreakerOpenError(LogosError):
    """Circuit breaker is open and rejecting traffic."""


class ProviderTimeoutError(ProviderError):
    """Provider request exceeded timeout."""


class BudgetExhaustedError(LogosError):
    """A strict runtime budget was exhausted before the task could complete."""
