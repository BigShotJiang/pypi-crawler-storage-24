"""Data models for continuous evaluation."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .utils import utcnow


CONTINUOUS_EVAL_SCHEMA_KIND = "continuous_eval_jobs"
CONTINUOUS_EVAL_SCHEMA_VERSION = 2


@dataclass
class ProductionRegressionDataset:
    """Golden dataset derived from bad production runs."""

    workspace_id: str | None
    agent_name: str | None
    examples: list[Any]  # List of GoldenExample
    source_run_ids: list[str]
    generated_at: str = field(default_factory=utcnow)


@dataclass
class JudgeDisagreement:
    """Case where LLM-judge and human feedback materially disagree."""

    run_id: str
    trace_id: str
    judge_score: float
    human_score: float
    delta: float
    judge_passed: bool
    human_passed: bool
    prompt_version: str
    model: str | None = None
    failure_types: list[str] = field(default_factory=list)


@dataclass
class ScoreWindow:
    """Current vs previous window metric."""

    current: float
    previous: float
    delta: float


@dataclass
class LearningScorecard:
    """Weekly learning KPI deltas."""

    workspace_id: str | None
    agent_name: str | None
    window_days: int
    current_window_start: str
    current_window_end: str
    previous_window_start: str
    previous_window_end: str
    quality: ScoreWindow
    cost: ScoreWindow
    latency: ScoreWindow
    retrieval_relevance: ScoreWindow
    tool_success: ScoreWindow
    counts: dict[str, Any] = field(default_factory=dict)


@dataclass
class OfflineChampionChallengerMetrics:
    """Offline dataset metrics for one candidate."""

    label: str
    pass_rate: float
    sample_size: int


@dataclass
class LiveChampionChallengerMetrics:
    """Live traffic slice metrics for one candidate."""

    label: str
    runs: int
    quality_score: float
    avg_cost_usd: float
    avg_latency_ms: float
    conversion_rate: float
    reward_score: float


@dataclass
class ChampionChallengerReport:
    """Offline and live comparison between current and candidate configs."""

    champion: dict[str, Any]
    challenger: dict[str, Any]
    recommendation: str
    reward_scorer_mode: str = "heuristic"


@dataclass
class ContinuousEvalTrendDeltaReport:
    """Operational trend report for recent continuous evaluation activity."""

    workspace_id: str | None
    job_name: str | None
    window_days: int
    current_window_start: str
    current_window_end: str
    previous_window_start: str
    previous_window_end: str
    pass_rate: ScoreWindow
    incidents: ScoreWindow
    rollbacks: ScoreWindow
    experiment_disables: ScoreWindow
    run_failures: ScoreWindow
    counts: dict[str, Any] = field(default_factory=dict)


@dataclass
class ContinuousEvalIncidentSnapshot:
    """Aggregated snapshot of continuous evaluation incidents."""

    workspace_id: str | None
    job_name: str | None
    status_filter: str | None
    generated_at: str
    summary: dict[str, Any] = field(default_factory=dict)
    latest_incidents: list[dict[str, Any]] = field(default_factory=list)
    affected_prompts: list[dict[str, Any]] = field(default_factory=list)
    affected_jobs: list[dict[str, Any]] = field(default_factory=list)
    restored_jobs: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ContinuousEvalJob:
    """Configured continuous evaluation job."""

    name: str
    kind: str
    agent_name: str
    workspace_id: str | None = None
    agent_filter: dict[str, Any] = field(default_factory=dict)
    interval_seconds: float = 3600.0
    limit: int = 100
    include_unreviewed: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    last_run_id: str | None = None
    last_started_at: str | None = None
    last_finished_at: str | None = None
    # Runtime fields (not persisted)
    agent: Any = None
    judge: Any = None
    task: Any = None


@dataclass
class ContinuousEvalIncident:
    """Production incident detected by continuous evaluation."""

    id: str
    job_name: str
    kind: str
    severity: str
    message: str
    created_at: str
    run_id: str | None = None
    workspace_id: str | None = None
    agent_name: str | None = None
    prompt_name: str | None = None
    experiment_id: str | None = None
    status: str = "open"
    acknowledged_at: str | None = None
    acknowledged_by: str | None = None
    resolved_at: str | None = None
    resolved_by: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


__all__ = [
    "CONTINUOUS_EVAL_SCHEMA_KIND",
    "CONTINUOUS_EVAL_SCHEMA_VERSION",
    "ProductionRegressionDataset",
    "JudgeDisagreement",
    "ScoreWindow",
    "LearningScorecard",
    "OfflineChampionChallengerMetrics",
    "LiveChampionChallengerMetrics",
    "ChampionChallengerReport",
    "ContinuousEvalTrendDeltaReport",
    "ContinuousEvalIncidentSnapshot",
    "ContinuousEvalJob",
    "ContinuousEvalIncident",
]
