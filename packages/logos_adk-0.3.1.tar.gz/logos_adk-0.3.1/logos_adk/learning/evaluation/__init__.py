"""Evaluation module for continuous learning."""
from __future__ import annotations

from .engine import EvaluationLoopEngine
from .models import (
    CONTINUOUS_EVAL_SCHEMA_KIND,
    CONTINUOUS_EVAL_SCHEMA_VERSION,
    ChampionChallengerReport,
    ContinuousEvalIncident,
    ContinuousEvalIncidentSnapshot,
    ContinuousEvalJob,
    ContinuousEvalTrendDeltaReport,
    JudgeDisagreement,
    LearningScorecard,
    LiveChampionChallengerMetrics,
    OfflineChampionChallengerMetrics,
    ProductionRegressionDataset,
    ScoreWindow,
)
from .runner import ContinuousEvalRunner

__all__ = [
    "EvaluationLoopEngine",
    "ContinuousEvalRunner",
    "CONTINUOUS_EVAL_SCHEMA_KIND",
    "CONTINUOUS_EVAL_SCHEMA_VERSION",
    "ChampionChallengerReport",
    "ContinuousEvalIncident",
    "ContinuousEvalIncidentSnapshot",
    "ContinuousEvalJob",
    "ContinuousEvalTrendDeltaReport",
    "JudgeDisagreement",
    "LearningScorecard",
    "LiveChampionChallengerMetrics",
    "OfflineChampionChallengerMetrics",
    "ProductionRegressionDataset",
    "ScoreWindow",
]
