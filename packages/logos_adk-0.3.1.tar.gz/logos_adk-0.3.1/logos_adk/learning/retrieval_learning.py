"""Retrieval learning primitives for adaptive RAG tuning.

DEPRECATED: This module has been refactored into a package.
Import from logos_adk.learning.retrieval_learning instead.
"""
from __future__ import annotations

# Re-export from new package structure for backward compatibility
from .retrieval_learning import (
    QueryRewriteRecord,
    ReindexRequest,
    ReindexTrigger,
    RetrievalEvent,
    RetrievalLearningEngine,
    RetrievalProfile,
    RetrievalSettings,
    SourceDocumentSnapshot,
    SourceUsefulnessScore,
    utcnow,
)

RETRIEVAL_LEARNING_SCHEMA_KIND = "retrieval_learning"
RETRIEVAL_LEARNING_SCHEMA_VERSION = 1

__all__ = [
    "RetrievalLearningEngine",
    "RetrievalSettings",
    "QueryRewriteRecord",
    "RetrievalEvent",
    "SourceUsefulnessScore",
    "ReindexTrigger",
    "ReindexRequest",
    "SourceDocumentSnapshot",
    "RetrievalProfile",
    "RETRIEVAL_LEARNING_SCHEMA_KIND",
    "RETRIEVAL_LEARNING_SCHEMA_VERSION",
    "utcnow",
]
