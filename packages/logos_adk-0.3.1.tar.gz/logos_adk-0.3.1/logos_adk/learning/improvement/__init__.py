"""Improvement module for self-improving agent loops."""
from __future__ import annotations

from .critic_reviser import CriticReviserLoop
from .export_builder import RLExport, TrainingExportBuilder
from .models import (
    IMPROVEMENT_SCHEMA_KIND,
    IMPROVEMENT_SCHEMA_VERSION,
    CriticIssue,
    CriticReview,
    CriticReviserResult,
    FailurePattern,
    LearnedPreferenceModelState,
    PolicyDecision,
    ReflectionLesson,
    RevisionSuggestion,
    RewardComponent,
    RewardScore,
    RootCauseHypothesis,
    RootCauseReport,
    TrainingExport,
)
from .pattern_miner import PatternMiner, RootCauseAnalyzer
from .policy_learner import PolicyLearner, TrainingExport as PolicyTrainingExport
from .reflection_memory import ReflectionMemory
from .reward_scorer import (
    HeuristicRewardScorer,
    LearnedPreferenceScorer,
    RewardModel,
    RewardScorer,
    build_reward_scorer,
)
from .utils import (
    _business_outcome_score,
    _clip_unit,
    _estimate_cost_usd,
    _human_feedback_score,
    _mean,
    _preference_target,
    _reward_feature_values,
    _sigmoid,
    utcnow,
)

__all__ = [
    # Schema
    "IMPROVEMENT_SCHEMA_KIND",
    "IMPROVEMENT_SCHEMA_VERSION",
    # Models
    "RewardComponent",
    "RewardScore",
    "LearnedPreferenceModelState",
    "PolicyDecision",
    "TrainingExport",
    "CriticIssue",
    "CriticReview",
    "RevisionSuggestion",
    "CriticReviserResult",
    "ReflectionLesson",
    "FailurePattern",
    "RootCauseHypothesis",
    "RootCauseReport",
    # Reward Scorer
    "RewardScorer",
    "HeuristicRewardScorer",
    "RewardModel",
    "LearnedPreferenceScorer",
    "build_reward_scorer",
    # Policy Learner
    "PolicyLearner",
    # Critic Reviser
    "CriticReviserLoop",
    # Reflection Memory
    "ReflectionMemory",
    # Pattern Miner
    "PatternMiner",
    "RootCauseAnalyzer",
    # Export Builder
    "TrainingExportBuilder",
    "RLExport",
    # Utils
    "utcnow",
]
