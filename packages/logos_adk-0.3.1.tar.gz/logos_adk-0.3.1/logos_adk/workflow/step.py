"""Step abstract base class for workflow pipelines."""
from __future__ import annotations

from abc import ABC, abstractmethod

from logos_adk.workflow.context import PipelineContext, StepResult


class Step(ABC):
    """A single executable unit in a pipeline."""

    def __init__(self, name: str) -> None:
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @abstractmethod
    async def execute(self, ctx: PipelineContext) -> StepResult:
        """Execute this step with the given pipeline context."""
        ...
