"""Team configuration."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal
from typing import Any

from logos_adk.runtime import Supervisor


@dataclass
class EventBusConfig:
    """Configuration for a team-level event bus backend."""

    backend: Literal["memory", "sqlite", "postgresql"] = "memory"
    path: str | None = None
    dsn: str | None = None


@dataclass
class TeamSubscriptionConfig:
    """Declarative team topic subscription."""

    agent_name: str
    topic: str
    handler: str | None = None
    publish_to: str | None = None
    name: str | None = None


@dataclass
class TeamConfig:
    """Configuration for a Team."""

    name: str
    agents: list[Any] = field(default_factory=list)
    orchestrator: str | None = None
    topology: str | dict[str, list[str]] | None = None
    max_rounds: int = 10
    supervisor: Supervisor | None = None
    process: str | None = None
    manager_role: str | None = None
    event_bus: EventBusConfig | None = None
    topic_policy: dict[str, list[str]] | None = None
    subscriptions: list[TeamSubscriptionConfig] = field(default_factory=list)
