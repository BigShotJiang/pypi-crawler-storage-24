"""Persistent checkpoint store for paused graph runs."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
import json
from pathlib import Path
import sqlite3
from typing import Any

from logos_adk.checkpoint_json import JSONObject, clone_json_object, ensure_json_object
from logos_adk.errors import StateBackendError
from logos_adk.persistence import (
    get_postgresql_schema_version,
    get_sqlite_schema_version,
    set_postgresql_schema_version,
    set_sqlite_schema_version,
)
from logos_adk.postgres_utils import import_psycopg, resolve_database_url


GRAPH_CHECKPOINT_SCHEMA_KIND = "graph_checkpoint_store"
GRAPH_CHECKPOINT_SCHEMA_VERSION = 1


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


@dataclass
class GraphCheckpointRecord:
    """Serialized paused graph run snapshot."""

    correlation_id: str
    graph_name: str
    status: str
    created_at: str
    updated_at: str
    payload: JSONObject


class GraphCheckpointStore:
    """Abstract persistent store for paused graph runs."""

    def save_checkpoint(self, record: GraphCheckpointRecord) -> None:
        raise NotImplementedError

    def load_checkpoint(self, graph_name: str, correlation_id: str) -> GraphCheckpointRecord | None:
        raise NotImplementedError

    def delete_checkpoint(self, graph_name: str, correlation_id: str) -> None:
        raise NotImplementedError


class InMemoryGraphCheckpointStore(GraphCheckpointStore):
    """In-memory checkpoint store for tests and local development."""

    def __init__(self) -> None:
        self._items: dict[tuple[str, str], GraphCheckpointRecord] = {}

    def save_checkpoint(self, record: GraphCheckpointRecord) -> None:
        payload = clone_json_object(record.payload, path="graph_checkpoint.payload")
        self._items[(record.graph_name, record.correlation_id)] = GraphCheckpointRecord(
            correlation_id=record.correlation_id,
            graph_name=record.graph_name,
            status=record.status,
            created_at=record.created_at,
            updated_at=record.updated_at,
            payload=payload,
        )

    def load_checkpoint(self, graph_name: str, correlation_id: str) -> GraphCheckpointRecord | None:
        record = self._items.get((graph_name, correlation_id))
        if record is None:
            return None
        payload = clone_json_object(record.payload, path="graph_checkpoint.payload")
        return GraphCheckpointRecord(
            correlation_id=record.correlation_id,
            graph_name=record.graph_name,
            status=record.status,
            created_at=record.created_at,
            updated_at=record.updated_at,
            payload=payload,
        )

    def delete_checkpoint(self, graph_name: str, correlation_id: str) -> None:
        self._items.pop((graph_name, correlation_id), None)


class SQLiteGraphCheckpointStore(GraphCheckpointStore):
    """SQLite-backed checkpoint store for paused graph runs."""

    def __init__(self, path: str = ".logos_adk/graph_checkpoints.db", table_name: str = "graph_checkpoints") -> None:
        self.path = path
        self.table_name = table_name

    def _connect(self) -> sqlite3.Connection:
        try:
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self.path)
            connection.row_factory = sqlite3.Row
            return connection
        except Exception as exc:
            raise StateBackendError(f"Failed to open SQLite graph checkpoint store: {exc}") from exc

    def _ensure_schema(self, connection: sqlite3.Connection) -> None:
        connection.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {self.table_name} (
                correlation_id TEXT NOT NULL,
                graph_name TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                PRIMARY KEY (graph_name, correlation_id)
            )
            """
        )
        connection.execute(
            f"""
            CREATE INDEX IF NOT EXISTS idx_{self.table_name}_graph_updated
            ON {self.table_name} (graph_name, updated_at DESC)
            """
        )
        recorded_version = get_sqlite_schema_version(connection, GRAPH_CHECKPOINT_SCHEMA_KIND)
        if recorded_version != GRAPH_CHECKPOINT_SCHEMA_VERSION:
            set_sqlite_schema_version(connection, GRAPH_CHECKPOINT_SCHEMA_KIND, GRAPH_CHECKPOINT_SCHEMA_VERSION)
        connection.commit()

    def save_checkpoint(self, record: GraphCheckpointRecord) -> None:
        payload_json = json.dumps(
            ensure_json_object(record.payload, path="graph_checkpoint.payload"),
            ensure_ascii=False,
            allow_nan=False,
        )
        with self._connect() as connection:
            self._ensure_schema(connection)
            connection.execute(
                f"""
                INSERT INTO {self.table_name}
                (correlation_id, graph_name, status, created_at, updated_at, payload_json)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(graph_name, correlation_id) DO UPDATE SET
                    status = excluded.status,
                    created_at = excluded.created_at,
                    updated_at = excluded.updated_at,
                    payload_json = excluded.payload_json
                """,
                (
                    record.correlation_id,
                    record.graph_name,
                    record.status,
                    record.created_at,
                    record.updated_at,
                    payload_json,
                ),
            )
            connection.commit()

    def load_checkpoint(self, graph_name: str, correlation_id: str) -> GraphCheckpointRecord | None:
        with self._connect() as connection:
            self._ensure_schema(connection)
            row = connection.execute(
                f"SELECT * FROM {self.table_name} WHERE graph_name = ? AND correlation_id = ?",
                (graph_name, correlation_id),
            ).fetchone()
        if row is None:
            return None
        try:
            payload = ensure_json_object(
                json.loads(row["payload_json"]),
                path="graph_checkpoint.payload",
            )
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise StateBackendError(
                f"Failed to load SQLite graph checkpoint '{graph_name}:{correlation_id}': invalid payload: {exc}"
            ) from exc
        return GraphCheckpointRecord(
            correlation_id=row["correlation_id"],
            graph_name=row["graph_name"],
            status=row["status"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            payload=payload,
        )

    def delete_checkpoint(self, graph_name: str, correlation_id: str) -> None:
        with self._connect() as connection:
            self._ensure_schema(connection)
            connection.execute(
                f"DELETE FROM {self.table_name} WHERE graph_name = ? AND correlation_id = ?",
                (graph_name, correlation_id),
            )
            connection.commit()


class PostgreSQLGraphCheckpointStore(GraphCheckpointStore):
    """PostgreSQL-backed checkpoint store for paused graph runs."""

    def __init__(
        self,
        dsn: str | None = None,
        table_name: str = "graph_checkpoints",
    ) -> None:
        self.dsn = resolve_database_url(dsn)
        if not self.dsn:
            raise ValueError(
                "PostgreSQL graph checkpoint store requires a DSN or DATABASE_URL/LOGOS_ADK_DATABASE_URL"
            )
        self.table_name = table_name

    def _connect(self) -> Any:
        try:
            return import_psycopg().connect(self.dsn)
        except Exception as exc:
            raise StateBackendError(f"Failed to open PostgreSQL graph checkpoint store: {exc}") from exc

    def _ensure_schema(self, connection: Any) -> None:
        with connection.cursor() as cursor:
            cursor.execute(
                f"""
                CREATE TABLE IF NOT EXISTS {self.table_name} (
                    correlation_id TEXT NOT NULL,
                    graph_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    payload_json JSONB NOT NULL,
                    PRIMARY KEY (graph_name, correlation_id)
                )
                """
            )
            cursor.execute(
                f"""
                CREATE INDEX IF NOT EXISTS idx_{self.table_name}_graph_updated
                ON {self.table_name} (graph_name, updated_at DESC)
                """
            )
        recorded_version = get_postgresql_schema_version(connection, GRAPH_CHECKPOINT_SCHEMA_KIND)
        if recorded_version != GRAPH_CHECKPOINT_SCHEMA_VERSION:
            set_postgresql_schema_version(connection, GRAPH_CHECKPOINT_SCHEMA_KIND, GRAPH_CHECKPOINT_SCHEMA_VERSION)
        connection.commit()

    def save_checkpoint(self, record: GraphCheckpointRecord) -> None:
        payload_json = json.dumps(
            ensure_json_object(record.payload, path="graph_checkpoint.payload"),
            ensure_ascii=False,
            allow_nan=False,
        )
        with self._connect() as connection:
            self._ensure_schema(connection)
            with connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    INSERT INTO {self.table_name}
                    (correlation_id, graph_name, status, created_at, updated_at, payload_json)
                    VALUES (%s, %s, %s, %s, %s, %s::jsonb)
                    ON CONFLICT(graph_name, correlation_id) DO UPDATE SET
                        status = excluded.status,
                        created_at = excluded.created_at,
                        updated_at = excluded.updated_at,
                        payload_json = excluded.payload_json
                    """,
                    (
                        record.correlation_id,
                        record.graph_name,
                        record.status,
                        record.created_at,
                        record.updated_at,
                        payload_json,
                    ),
                )
            connection.commit()

    def load_checkpoint(self, graph_name: str, correlation_id: str) -> GraphCheckpointRecord | None:
        with self._connect() as connection:
            self._ensure_schema(connection)
            with connection.cursor() as cursor:
                cursor.execute(
                    f"SELECT * FROM {self.table_name} WHERE graph_name = %s AND correlation_id = %s",
                    (graph_name, correlation_id),
                )
                row = cursor.fetchone()
        if row is None:
            return None
        try:
            raw_payload = _row_value(row, "payload_json", 5)
            payload = ensure_json_object(
                json.loads(raw_payload) if isinstance(raw_payload, str) else raw_payload,
                path="graph_checkpoint.payload",
            )
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise StateBackendError(
                f"Failed to load PostgreSQL graph checkpoint '{graph_name}:{correlation_id}': invalid payload: {exc}"
            ) from exc
        return GraphCheckpointRecord(
            correlation_id=str(_row_value(row, "correlation_id", 0)),
            graph_name=str(_row_value(row, "graph_name", 1)),
            status=str(_row_value(row, "status", 2)),
            created_at=str(_row_value(row, "created_at", 3)),
            updated_at=str(_row_value(row, "updated_at", 4)),
            payload=payload,
        )

    def delete_checkpoint(self, graph_name: str, correlation_id: str) -> None:
        with self._connect() as connection:
            self._ensure_schema(connection)
            with connection.cursor() as cursor:
                cursor.execute(
                    f"DELETE FROM {self.table_name} WHERE graph_name = %s AND correlation_id = %s",
                    (graph_name, correlation_id),
                )
            connection.commit()


def _row_value(row: Any, name: str, index: int) -> Any:
    if row is None:
        return None
    try:
        return row[name]
    except (KeyError, TypeError, IndexError):
        return row[index]


__all__ = [
    "GRAPH_CHECKPOINT_SCHEMA_KIND",
    "GRAPH_CHECKPOINT_SCHEMA_VERSION",
    "GraphCheckpointRecord",
    "GraphCheckpointStore",
    "InMemoryGraphCheckpointStore",
    "PostgreSQLGraphCheckpointStore",
    "SQLiteGraphCheckpointStore",
]
