"""Team — the multi-agent orchestration building block of Logos ADK."""
from logos_adk.team.core import Team
from logos_adk.team._types import AgentLike, CampaignState

__all__ = ["AgentLike", "CampaignState", "Team"]
