"""Serve routes for Logos ADK.

This module provides FastAPI route creation for AI agents.
"""
from __future__ import annotations

from .router import create_agent_routes
from .schemas import (
    # Agent
    AgentRequest,
    AgentResponse,
    BatchAgentRequest,
    BatchAgentResponse,
    ContentPartPayload,
    TaskRunPayload,
    TaskRunRecord,
    TaskRunLayout,
    TaskRunSection,
    ToolCallResponse,
    UsageResponse,
    UIStreamRequest,
    ResumeRequest,
    # Chat
    ChatMessage,
    ChatSession,
    ChatSessionsResponse,
    CreateChatSessionRequest,
    UpdateChatSessionRequest,
    TaskRunActionResponse,
    # Feedback
    FeedbackRequest,
    FeedbackResponse,
    OutcomeRequest,
    OutcomeResponse,
    # Info
    AgentInfo,
    ToolInfo,
    ToolStatus,
    GraphDefinitionResponse,
    NodeUpdateRequest,
    CacheStatsResponse,
    BillingStatsResponse,
    SpendRecordResponse,
    IngestRequest,
    IngestResponse,
    ErrorResponse,
)

# Global stores (used by routes)
_CHAT_SESSIONS_STORE: dict = {}
_ACTIVE_TASK_RUNS: dict = {}


def _get_global_sessions_store() -> dict:
    """Get global chat sessions store."""
    return _CHAT_SESSIONS_STORE


def _get_global_task_runs_store() -> dict:
    """Get global task runs store."""
    return _ACTIVE_TASK_RUNS


__all__ = [
    "create_agent_routes",
    # Schemas
    "AgentRequest",
    "AgentResponse",
    "BatchAgentRequest",
    "BatchAgentResponse",
    "ContentPartPayload",
    "TaskRunPayload",
    "TaskRunRecord",
    "TaskRunLayout",
    "TaskRunSection",
    "ToolCallResponse",
    "UsageResponse",
    "UIStreamRequest",
    "ResumeRequest",
    "ChatMessage",
    "ChatSession",
    "ChatSessionsResponse",
    "CreateChatSessionRequest",
    "UpdateChatSessionRequest",
    "TaskRunActionResponse",
    "FeedbackRequest",
    "FeedbackResponse",
    "OutcomeRequest",
    "OutcomeResponse",
    "AgentInfo",
    "ToolInfo",
    "ToolStatus",
    "GraphDefinitionResponse",
    "NodeUpdateRequest",
    "CacheStatsResponse",
    "BillingStatsResponse",
    "SpendRecordResponse",
    "IngestRequest",
    "IngestResponse",
    "ErrorResponse",
    # Global stores
    "_CHAT_SESSIONS_STORE",
    "_ACTIVE_TASK_RUNS",
    "_get_global_sessions_store",
    "_get_global_task_runs_store",
]
