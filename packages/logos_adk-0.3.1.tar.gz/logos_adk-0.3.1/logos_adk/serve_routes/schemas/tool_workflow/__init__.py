"""Tool workflow Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ToolWorkflowToolScoresResponse(BaseModel):
    """Operator view over learned tool scores."""

    workspace_id: str | None = None
    task_type: str | None = None
    items: list[dict[str, Any]]


class ToolWorkflowFallbackRankingsResponse(BaseModel):
    """Operator view over learned fallback rankings."""

    workspace_id: str | None = None
    task_type: str | None = None
    items: list[dict[str, Any]]


class ToolWorkflowApprovalHotspotsResponse(BaseModel):
    """Operator view over approval friction hotspots."""

    workspace_id: str | None = None
    pipeline_name: str | None = None
    step_name: str | None = None
    items: list[dict[str, Any]]


class ToolWorkflowBranchScoresResponse(BaseModel):
    """Operator view over workflow branch effectiveness."""

    workspace_id: str | None = None
    pipeline_name: str | None = None
    step_name: str | None = None
    items: list[dict[str, Any]]


class ToolWorkflowLoopRecommendationsResponse(BaseModel):
    """Operator view over learned loop recommendations."""

    workspace_id: str | None = None
    pipeline_name: str | None = None
    items: list[dict[str, Any]]


__all__ = [
    "ToolWorkflowToolScoresResponse",
    "ToolWorkflowFallbackRankingsResponse",
    "ToolWorkflowApprovalHotspotsResponse",
    "ToolWorkflowBranchScoresResponse",
    "ToolWorkflowLoopRecommendationsResponse",
]
