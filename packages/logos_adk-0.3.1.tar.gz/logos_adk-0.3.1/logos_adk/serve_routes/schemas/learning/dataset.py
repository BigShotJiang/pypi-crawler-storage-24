"""Dataset building Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class DatasetBuildRequest(BaseModel):
    """Request body for dataset building."""

    workspace_id: str | None = None
    agent_name: str | None = None
    limit: int = 100
    include_unreviewed: bool = True


class DatasetBuildResponse(BaseModel):
    """Built dataset response."""

    summary: dict[str, Any]
    items: list[dict[str, Any]]


__all__ = ["DatasetBuildRequest", "DatasetBuildResponse"]
