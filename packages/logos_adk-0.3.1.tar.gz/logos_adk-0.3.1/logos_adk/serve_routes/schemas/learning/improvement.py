"""Improvement Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ImprovementRewardScoresResponse(BaseModel):
    """Operator view over unified reward scores."""

    workspace_id: str | None = None
    agent_name: str | None = None
    summary: dict[str, Any]
    items: list[dict[str, Any]]


class ImprovementPolicyResponse(BaseModel):
    """Learned policy recommendation for a runtime segment."""

    policy: dict[str, Any]


class ImprovementTrainingExportResponse(BaseModel):
    """Exported training data for operator review."""

    export: dict[str, Any]


class ImprovementReflectionLessonsResponse(BaseModel):
    """Learned lessons from reflection analysis."""

    lessons: dict[str, Any]


__all__ = [
    "ImprovementRewardScoresResponse",
    "ImprovementPolicyResponse",
    "ImprovementTrainingExportResponse",
    "ImprovementReflectionLessonsResponse",
]
