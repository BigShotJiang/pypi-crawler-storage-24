"""Prompt registry Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class PromptCreateRequest(BaseModel):
    """Create a prompt registry entry."""

    name: str
    description: str | None = None
    base_content: str | None = None
    tags: list[str] | None = None


class PromptVersionCreateRequest(BaseModel):
    """Create a prompt version."""

    content: str
    tags: list[str] | None = None
    notes: str | None = None
    created_by: str | None = None


class PromptPromoteRequest(BaseModel):
    """Promote a prompt version for a segment."""

    version: int
    environment: str = "prod"
    workspace_id: str | None = None
    task_type: str | None = None
    user_segment: str | None = None
    experiment_id: str | None = None
    enforce_guard: bool = False


class PromptRollbackRequest(BaseModel):
    """Rollback the active prompt for a segment."""

    environment: str = "prod"
    workspace_id: str | None = None
    task_type: str | None = None
    user_segment: str | None = None


class PromptExperimentCreateRequest(BaseModel):
    """Create a prompt A/B experiment."""

    baseline_version: int
    challenger_versions: list[int]
    rollout_percentage: int = 50
    metric: str = "reward"
    environment: str = "prod"
    workspace_id: str | None = None
    task_type: str | None = None
    user_segment: str | None = None


class PromptOptimizeRequest(BaseModel):
    """Run offline prompt optimization."""

    candidates: list[str]
    workspace_id: str | None = None
    feedback_limit: int = 100
    tags: list[str] | None = None
    golden_examples: list[dict[str, Any]] | None = None


class PromptRecommendationRequest(BaseModel):
    """Generate recommendation from feedback and failures."""

    workspace_id: str | None = None
    limit: int = 100


class PromptInfoResponse(BaseModel):
    """Prompt registry state."""

    prompt: dict[str, Any]
    versions: list[dict[str, Any]]
    deployments: list[dict[str, Any]]
    recommendations: list[dict[str, Any]]


class PromptExperimentResponse(BaseModel):
    """Prompt experiment response."""

    experiment: dict[str, Any]
    report: dict[str, Any] | None = None


class PromptOptimizationResponse(BaseModel):
    """Prompt optimization result."""

    created_version: dict[str, Any]
    scores: list[dict[str, Any]]


class PromptRecommendationResponse(BaseModel):
    """Prompt recommendation response."""

    recommendation: dict[str, Any]


__all__ = [
    "PromptCreateRequest",
    "PromptVersionCreateRequest",
    "PromptPromoteRequest",
    "PromptRollbackRequest",
    "PromptExperimentCreateRequest",
    "PromptOptimizeRequest",
    "PromptRecommendationRequest",
    "PromptInfoResponse",
    "PromptExperimentResponse",
    "PromptOptimizationResponse",
    "PromptRecommendationResponse",
]
