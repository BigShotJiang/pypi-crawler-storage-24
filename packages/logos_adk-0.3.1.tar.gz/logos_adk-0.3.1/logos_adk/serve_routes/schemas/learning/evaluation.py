"""Evaluation Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class EvaluationScorecardResponse(BaseModel):
    """Operator view over weekly learning scorecards."""

    scorecard: dict[str, Any]


class EvaluationRegressionDatasetResponse(BaseModel):
    """Prod-derived regression dataset for operator review."""

    dataset: dict[str, Any]


class EvaluationJudgeDisagreementsRequest(BaseModel):
    """Request body for judge disagreement analysis."""

    workspace_id: str | None = None
    agent_name: str | None = None
    limit: int = 100
    threshold: float = 0.35
    pass_threshold: float = 0.7
    mock_response: str = '{"score": 0.5, "rationale": "no judge configured"}'


class EvaluationJudgeDisagreementsResponse(BaseModel):
    """Judge-vs-human disagreement report."""

    summary: dict[str, Any]
    items: list[dict[str, Any]]


class EvaluationContinuousJobCreateRequest(BaseModel):
    """Create and start a continuous evaluation job."""

    name: str
    kind: str  # "regression" | "judge-eval"
    workspace_id: str | None = None
    agent_name: str | None = None
    interval_seconds: float = 3600.0
    limit: int = 100
    pass_threshold: float = 0.7
    mock_response: str = '{"score": 0.5, "rationale": "no judge configured"}'
    metadata: dict[str, Any] | None = None


class EvaluationContinuousJobsResponse(BaseModel):
    """List of configured continuous evaluation jobs."""

    items: list[dict[str, Any]]


class EvaluationContinuousIncidentsResponse(BaseModel):
    """List of continuous-eval rollback and regression incidents."""

    items: list[dict[str, Any]]


class EvaluationContinuousTrendDeltaResponse(BaseModel):
    """Trend-delta report for continuous evaluation activity."""

    report: dict[str, Any]


class EvaluationContinuousIncidentSnapshotResponse(BaseModel):
    """Aggregated incident snapshot for continuous evaluation ops."""

    snapshot: dict[str, Any]


class EvaluationContinuousIncidentActionRequest(BaseModel):
    """Acknowledge or resolve a continuous-eval incident."""

    actor: str | None = None
    note: str | None = None


class EvaluationContinuousIncidentResponse(BaseModel):
    """Single continuous-eval incident payload."""

    incident: dict[str, Any]


class EvaluationContinuousJobResponse(BaseModel):
    """Single continuous evaluation job snapshot."""

    job: dict[str, Any]


class EvaluationContinuousJobRunResponse(BaseModel):
    """One-shot execution result for a continuous evaluation job."""

    job: dict[str, Any]
    run: dict[str, Any]


class EvaluationChampionChallengerRequest(BaseModel):
    """Request body for champion/challenger comparison."""

    workspace_id: str | None = None
    agent_name: str | None = None
    challenger_prompt: str
    champion_prompt: str | None = None
    champion_filter: dict[str, Any] | None = None
    challenger_filter: dict[str, Any] | None = None
    limit: int = 100
    reward_scorer_mode: str = "heuristic"
    reward_training_limit: int = 500


class EvaluationChampionChallengerResponse(BaseModel):
    """Champion/challenger comparison report."""

    report: dict[str, Any]


__all__ = [
    "EvaluationScorecardResponse",
    "EvaluationRegressionDatasetResponse",
    "EvaluationJudgeDisagreementsRequest",
    "EvaluationJudgeDisagreementsResponse",
    "EvaluationContinuousJobCreateRequest",
    "EvaluationContinuousJobsResponse",
    "EvaluationContinuousIncidentsResponse",
    "EvaluationContinuousTrendDeltaResponse",
    "EvaluationContinuousIncidentSnapshotResponse",
    "EvaluationContinuousIncidentActionRequest",
    "EvaluationContinuousIncidentResponse",
    "EvaluationContinuousJobResponse",
    "EvaluationContinuousJobRunResponse",
    "EvaluationChampionChallengerRequest",
    "EvaluationChampionChallengerResponse",
]
