"""Retrieval documents Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class RetrievalSourceDocumentsResponse(BaseModel):
    """Stored source-document snapshots for operator inspection."""

    workspace_id: str | None = None
    source_key: str | None = None
    items: list[dict[str, Any]]


__all__ = ["RetrievalSourceDocumentsResponse"]
