"""Retrieval profiles Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class RetrievalProfilesResponse(BaseModel):
    """Operator view over learned retrieval profiles."""

    workspace_id: str | None = None
    task_type: str | None = None
    user_segment: str | None = None
    items: list[dict[str, Any]]


__all__ = ["RetrievalProfilesResponse"]
