"""Retrieval ops summary Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class RetrievalOpsSummaryResponse(BaseModel):
    """Admin summary for retrieval operations backlog."""

    workspace_id: str | None = None
    requests: dict[str, Any]
    triggers: dict[str, Any]
    source_documents: dict[str, Any]
    policy: dict[str, Any]
    coalescing: dict[str, Any]


__all__ = ["RetrievalOpsSummaryResponse"]
