"""Retrieval scores Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class RetrievalSourceScoresResponse(BaseModel):
    """Operator view over retrieval source usefulness."""

    workspace_id: str | None = None
    items: list[dict[str, Any]]


__all__ = ["RetrievalSourceScoresResponse"]
