"""Retrieval reindex Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class RetrievalReindexTriggersResponse(BaseModel):
    """Operator view over pending reindex signals."""

    workspace_id: str | None = None
    items: list[dict[str, Any]]


class RetrievalTriggerActionRequest(BaseModel):
    """Operator action for a reindex trigger."""

    note: str | None = None


class RetrievalTriggerActionResponse(BaseModel):
    """Updated trigger after operator action."""

    trigger: dict[str, Any]


class RetrievalForceReindexRequest(BaseModel):
    """Create a manual reindex request."""

    source_key: str
    workspace_id: str | None = None
    reason: str = "operator_requested"
    requested_by: str | None = None
    metadata: dict[str, Any] | None = None


class RetrievalForceReindexResponse(BaseModel):
    """Created force-reindex request."""

    request: dict[str, Any]


class RetrievalReindexRequestsResponse(BaseModel):
    """Operator view over reindex requests."""

    workspace_id: str | None = None
    items: list[dict[str, Any]]


class RetrievalReindexRequestResponse(BaseModel):
    """Single reindex request detail."""

    request: dict[str, Any]


__all__ = [
    "RetrievalReindexTriggersResponse",
    "RetrievalTriggerActionRequest",
    "RetrievalTriggerActionResponse",
    "RetrievalForceReindexRequest",
    "RetrievalForceReindexResponse",
    "RetrievalReindexRequestsResponse",
    "RetrievalReindexRequestResponse",
]
