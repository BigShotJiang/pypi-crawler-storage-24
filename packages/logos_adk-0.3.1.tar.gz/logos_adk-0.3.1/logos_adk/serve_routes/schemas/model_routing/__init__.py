"""Model routing Pydantic schemas."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class ModelRoutingLeaderboardResponse(BaseModel):
    """Operator view over learned model leaderboard."""

    workspace_id: str | None = None
    task_type: str | None = None
    confidence_tier: str | None = None
    items: list[dict[str, Any]]


class ModelRoutingBudgetStatusResponse(BaseModel):
    """Budget pressure status for model routing."""

    workspace_id: str | None = None
    task_type: str | None = None
    spent_usd: float
    soft_limit_usd: float
    hard_limit_usd: float | None = None
    ratio: float
    near_limit: bool
    hard_limit_reached: bool


class ModelRoutingCanariesResponse(BaseModel):
    """Active or historical canary deployments."""

    workspace_id: str | None = None
    task_type: str | None = None
    user_segment: str | None = None
    status: str | None = None
    items: list[dict[str, Any]]


class ModelRoutingDecisionResponse(BaseModel):
    """Explain-style routing decision inspection."""

    workspace_id: str | None = None
    task_type: str | None = None
    user_segment: str | None = None
    assignment_key: str | None = None
    model_keys: list[str]
    prompt: str | None = None
    decision: dict[str, Any]
    leaderboard: list[dict[str, Any]]
    budget: dict[str, Any]
    active_canaries: list[dict[str, Any]]


__all__ = [
    "ModelRoutingLeaderboardResponse",
    "ModelRoutingBudgetStatusResponse",
    "ModelRoutingCanariesResponse",
    "ModelRoutingDecisionResponse",
]
