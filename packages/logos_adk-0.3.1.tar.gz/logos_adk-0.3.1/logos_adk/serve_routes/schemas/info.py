"""Additional info Pydantic schemas."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class AgentInfo(BaseModel):
    """Agent information response."""

    ui_contract_version: int
    name: str
    model: str | None = None
    system_prompt: str | None = None
    provider_type: str | None = None
    provider_base_url: str | None = None
    supports_graph: bool = False
    supports_stream_ui: bool = False
    supports_resume: bool = False
    route_base: str = ""
    session_mode: str = "server"


class ToolInfo(BaseModel):
    """Tool information."""

    name: str
    description: str
    parameters: dict[str, Any]


class ToolStatus(BaseModel):
    """Tool status."""

    name: str
    description: str
    parameters: dict[str, Any]
    enabled: bool


class GraphDefinitionResponse(BaseModel):
    """Graph definition response."""

    nodes: list[dict[str, Any]]
    edges: list[dict[str, Any]]
    metadata: dict[str, Any] = {}


class NodeUpdateRequest(BaseModel):
    """Node update request."""

    system_prompt: str | None = None
    model: str | None = None
    metadata: dict[str, Any] | None = None


class CacheStatsResponse(BaseModel):
    """Cache statistics response."""

    backend: str | None = None
    total_entries: int = 0
    total_hits: int = 0
    hits: int = 0
    misses: int = 0
    size: int = 0
    hit_rate: float = 0.0


class SpendRecordResponse(BaseModel):
    """Spend record response."""

    agent_name: str
    model: str | None = None
    amount_usd: float
    session_id: str | None = None
    created_at: str


class BillingStatsResponse(BaseModel):
    """Billing statistics response."""

    total_spent_usd: float
    by_agent: dict[str, float]
    recent_records: list[SpendRecordResponse]


class IngestRequest(BaseModel):
    """Request body for /ingest endpoint."""

    text: str
    metadata: dict[str, Any] | None = None


class IngestResponse(BaseModel):
    """Response body for /ingest endpoint."""

    document_id: str


class ErrorResponse(BaseModel):
    """Error response body."""

    error: str
    message: str


__all__ = [
    "AgentInfo",
    "ToolInfo",
    "ToolStatus",
    "GraphDefinitionResponse",
    "NodeUpdateRequest",
    "CacheStatsResponse",
    "SpendRecordResponse",
    "BillingStatsResponse",
    "IngestRequest",
    "IngestResponse",
    "ErrorResponse",
]
