"""Improvement route handlers."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...schemas import (
    ImprovementRewardScoresResponse,
    ImprovementPolicyResponse,
    ImprovementTrainingExportResponse,
    ImprovementReflectionLessonsResponse,
)

if TYPE_CHECKING:
    pass


async def get_reward_scores_handler(
    workspace_id: str | None = None,
    agent_name: str | None = None,
    learning_store: Any | None = None,
) -> ImprovementRewardScoresResponse:
    """Handle GET /learning/improvement/reward-scores."""
    if learning_store is None:
        return ImprovementRewardScoresResponse(
            workspace_id=workspace_id,
            agent_name=agent_name,
            summary={"error": "learning_store not configured"},
            items=[],
        )
    
    try:
        if hasattr(learning_store, "get_reward_scores"):
            result = learning_store.get_reward_scores(
                workspace_id=workspace_id,
                agent_name=agent_name,
            )
            return ImprovementRewardScoresResponse(
                workspace_id=workspace_id,
                agent_name=agent_name,
                summary=result.get("summary", {}),
                items=result.get("items", []),
            )
    except Exception:
        pass
    
    return ImprovementRewardScoresResponse(
        workspace_id=workspace_id,
        agent_name=agent_name,
        summary={},
        items=[],
    )


async def get_policy_handler(
    workspace_id: str | None = None,
    task_type: str | None = None,
    user_segment: str | None = None,
    learning_store: Any | None = None,
) -> ImprovementPolicyResponse:
    """Handle GET /learning/improvement/policy."""
    if learning_store is None:
        return ImprovementPolicyResponse(policy={"error": "learning_store not configured"})
    
    try:
        if hasattr(learning_store, "get_policy"):
            policy = learning_store.get_policy(
                workspace_id=workspace_id,
                task_type=task_type,
                user_segment=user_segment,
            )
            return ImprovementPolicyResponse(policy=policy)
    except Exception:
        pass
    
    return ImprovementPolicyResponse(policy={})


async def export_training_handler(
    workspace_id: str | None = None,
    agent_name: str | None = None,
    learning_store: Any | None = None,
) -> ImprovementTrainingExportResponse:
    """Handle GET /learning/improvement/export-training."""
    if learning_store is None:
        return ImprovementTrainingExportResponse(export={"error": "learning_store not configured"})
    
    try:
        if hasattr(learning_store, "export_training"):
            export = learning_store.export_training(
                workspace_id=workspace_id,
                agent_name=agent_name,
            )
            return ImprovementTrainingExportResponse(export=export)
    except Exception:
        pass
    
    return ImprovementTrainingExportResponse(export={})


async def get_reflection_lessons_handler(
    workspace_id: str | None = None,
    agent_name: str | None = None,
    learning_store: Any | None = None,
) -> ImprovementReflectionLessonsResponse:
    """Handle GET /learning/improvement/reflection-lessons."""
    if learning_store is None:
        return ImprovementReflectionLessonsResponse(lessons={"error": "learning_store not configured"})
    
    try:
        if hasattr(learning_store, "get_reflection_lessons"):
            lessons = learning_store.get_reflection_lessons(
                workspace_id=workspace_id,
                agent_name=agent_name,
            )
            return ImprovementReflectionLessonsResponse(lessons=lessons)
    except Exception:
        pass
    
    return ImprovementReflectionLessonsResponse(lessons={})


__all__ = [
    "get_reward_scores_handler",
    "get_policy_handler",
    "export_training_handler",
    "get_reflection_lessons_handler",
]
