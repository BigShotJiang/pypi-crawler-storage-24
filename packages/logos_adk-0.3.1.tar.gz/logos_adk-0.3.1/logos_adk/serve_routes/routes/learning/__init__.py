"""Learning route handlers - /learning/* endpoints."""
from __future__ import annotations

from .dataset import (
    build_dataset_handler,
)
from .prompt import (
    create_prompt_handler,
    create_prompt_version_handler,
    promote_prompt_handler,
    rollback_prompt_handler,
    create_experiment_handler,
    optimize_prompt_handler,
    get_recommendations_handler,
    get_prompt_info_handler,
)
from .retrieval import (
    get_source_scores_handler,
    get_source_documents_handler,
    export_source_scores_handler,
    get_reindex_triggers_handler,
    acknowledge_trigger_handler,
    resolve_trigger_handler,
    close_trigger_handler,
    force_reindex_handler,
    get_reindex_requests_handler,
    get_reindex_request_handler,
    retry_reindex_request_handler,
    resume_reindex_request_handler,
    replay_reindex_request_handler,
    cancel_reindex_request_handler,
    get_reindex_summary_handler,
    get_profiles_handler,
)
from .evaluation import (
    get_scorecard_handler,
    get_regression_dataset_handler,
    get_judge_disagreements_handler,
    create_eval_job_handler,
    get_eval_jobs_handler,
    get_restored_eval_jobs_handler,
    get_eval_incidents_handler,
    get_eval_trend_handler,
    get_incident_snapshot_handler,
    acknowledge_incident_handler,
    resolve_incident_handler,
    get_eval_job_handler,
    run_eval_job_handler,
    delete_eval_job_handler,
    champion_challenger_handler,
)
from .improvement import (
    get_reward_scores_handler,
    get_policy_handler,
    export_training_handler,
    get_reflection_lessons_handler,
)

__all__ = [
    # Dataset
    "build_dataset_handler",
    # Prompt
    "create_prompt_handler",
    "create_prompt_version_handler",
    "promote_prompt_handler",
    "rollback_prompt_handler",
    "create_experiment_handler",
    "optimize_prompt_handler",
    "get_recommendations_handler",
    "get_prompt_info_handler",
    # Retrieval
    "get_source_scores_handler",
    "get_source_documents_handler",
    "export_source_scores_handler",
    "get_reindex_triggers_handler",
    "acknowledge_trigger_handler",
    "resolve_trigger_handler",
    "close_trigger_handler",
    "force_reindex_handler",
    "get_reindex_requests_handler",
    "get_reindex_request_handler",
    "retry_reindex_request_handler",
    "resume_reindex_request_handler",
    "replay_reindex_request_handler",
    "cancel_reindex_request_handler",
    "get_reindex_summary_handler",
    "get_profiles_handler",
    # Evaluation
    "get_scorecard_handler",
    "get_regression_dataset_handler",
    "get_judge_disagreements_handler",
    "create_eval_job_handler",
    "get_eval_jobs_handler",
    "get_restored_eval_jobs_handler",
    "get_eval_incidents_handler",
    "get_eval_trend_handler",
    "get_incident_snapshot_handler",
    "acknowledge_incident_handler",
    "resolve_incident_handler",
    "get_eval_job_handler",
    "run_eval_job_handler",
    "delete_eval_job_handler",
    "champion_challenger_handler",
    # Improvement
    "get_reward_scores_handler",
    "get_policy_handler",
    "export_training_handler",
    "get_reflection_lessons_handler",
]
