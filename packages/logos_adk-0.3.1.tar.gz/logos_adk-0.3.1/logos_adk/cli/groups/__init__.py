"""CLI groups."""
from __future__ import annotations

from .learning import (
    storage,
    storage_upgrade_check,
    storage_migrate,
    retrieval,
    retrieval_source_scores,
    retrieval_reindex_triggers,
    retrieval_profiles,
    retrieval_ack_trigger,
    retrieval_resolve_trigger,
    retrieval_close_trigger,
    retrieval_source_documents,
    retrieval_force_reindex,
    retrieval_export_source_scores,
    retrieval_reindex_requests,
    retrieval_cancel_request,
    retrieval_resume_request,
    retrieval_replay_request,
    retrieval_summary,
    tool_workflow,
    model_routing,
    evaluation,
    improvement,
    transfer,
)

__all__ = [
    # Storage
    "storage",
    "storage_upgrade_check",
    "storage_migrate",
    # Retrieval
    "retrieval",
    "retrieval_source_scores",
    "retrieval_reindex_triggers",
    "retrieval_profiles",
    "retrieval_ack_trigger",
    "retrieval_resolve_trigger",
    "retrieval_close_trigger",
    "retrieval_source_documents",
    "retrieval_force_reindex",
    "retrieval_export_source_scores",
    "retrieval_reindex_requests",
    "retrieval_cancel_request",
    "retrieval_resume_request",
    "retrieval_replay_request",
    "retrieval_summary",
    # Other groups
    "tool_workflow",
    "model_routing",
    "evaluation",
    "improvement",
    "transfer",
]
