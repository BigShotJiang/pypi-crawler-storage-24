"""CLI entry point for python -m logos_adk.cli."""
from .main import main

if __name__ == "__main__":
    main()
