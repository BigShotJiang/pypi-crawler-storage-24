"""Logos ADK CLI - Main entry point."""
from __future__ import annotations

import click

from logos_adk.version import __version__

from .commands import (
    # Agent commands
    run,
    chat,
    test_command,
    tui_ide_command,
    validate,
    describe,
    # Serve commands
    serve,
    test_live,
    # Project commands
    project,
    upgrade_cli,
    # Admin commands
    admin,
    # Quality commands
    integration_command,
    judge_eval_command,
    load_test_command,
    quality,
    regression_command,
)

from .groups import (
    # Storage group
    storage,
    # Retrieval group
    retrieval,
    # Other groups
    tool_workflow,
    model_routing,
    evaluation,
    improvement,
    transfer,
)


@click.group()
@click.version_option(version=__version__)
def cli() -> None:
    """Logos ADK - AI Agent Development Kit.
    
    A modern framework for building AI-powered agents and multi-agent systems.
    
    Examples:
    
        # Run an agent
        logos-adk run agent.yaml "Hello, how can I help?"
        
        # Start interactive chat
        logos-adk chat agent.yaml
        
        # Serve agents as API
        logos-adk serve --agents agent.yaml
        
        # Create new project
        logos-adk project new single-agent-api ./my-project
        
        # Run quality tests
        logos-adk quality test --kind regression --config tests.yaml
    """
    pass


# Register agent commands
cli.add_command(run)
cli.add_command(chat)
cli.add_command(test_command)
cli.add_command(tui_ide_command)
cli.add_command(validate)
cli.add_command(describe)

# Register serve commands
cli.add_command(serve)
cli.add_command(test_live)

# Register project group
cli.add_command(project)
cli.add_command(upgrade_cli)

# Register admin group
cli.add_command(admin)

# Register quality group
cli.add_command(quality)
cli.add_command(integration_command)
cli.add_command(load_test_command)
cli.add_command(regression_command)
cli.add_command(judge_eval_command)

# Register storage group
cli.add_command(storage)

# Register retrieval group
cli.add_command(retrieval)

# Register other groups
cli.add_command(tool_workflow)
cli.add_command(model_routing)
cli.add_command(evaluation)
cli.add_command(improvement)
cli.add_command(transfer)


def main() -> None:
    """Main entry point for CLI."""
    cli()


if __name__ == "__main__":
    main()
