"""Logos ADK CLI."""
from __future__ import annotations

from logos_adk.agent import Agent
from logos_adk.runnable_config_loader import (
    describe_runnable_from_config,
    load_runnable_from_config,
)

from .helpers import (
    _build_continuous_eval_runner,
    _build_learning_store,
    _build_quality_manager,
)
from .main import cli, main
from .utils.animation import run_with_animation as _run_with_animation

__version__ = "0.3.0"

__all__ = [
    "cli",
    "main",
    "__version__",
    "_build_learning_store",
    "_build_quality_manager",
    "_build_continuous_eval_runner",
    "_run_with_animation",
    "Agent",
    "load_runnable_from_config",
    "describe_runnable_from_config",
]
