"""CLI utilities."""
from __future__ import annotations

from .animation import run_sync_coro, run_with_animation, thinking_animation
from .output import build_html_sections, normalize_result, write_reports, write_result_output
from .templates import PROJECT_TEMPLATES, copy_project_template
from .validation import validate_agent_name, validate_config_file, validate_output_dir

__all__ = [
    # Animation
    "thinking_animation",
    "run_with_animation",
    "run_sync_coro",
    # Output
    "normalize_result",
    "write_result_output",
    "build_html_sections",
    "write_reports",
    # Templates
    "PROJECT_TEMPLATES",
    "copy_project_template",
    # Validation
    "validate_config_file",
    "validate_output_dir",
    "validate_agent_name",
]
