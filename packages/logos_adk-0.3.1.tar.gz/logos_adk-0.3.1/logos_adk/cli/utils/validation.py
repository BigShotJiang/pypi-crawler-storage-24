"""Validation utilities for CLI."""
from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import click

if TYPE_CHECKING:
    pass


def validate_config_file(ctx: Any, param: Any, value: Path | None) -> Path | None:
    """Validate configuration file exists.
    
    Args:
        ctx: Click context
        param: Click parameter
        value: File path value
        
    Returns:
        Validated path
        
    Raises:
        click.BadParameter: If file doesn't exist
    """
    if value is None:
        return None
    
    if not value.exists():
        raise click.BadParameter(f"Configuration file not found: {value}")
    
    if not value.is_file():
        raise click.BadParameter(f"Not a file: {value}")
    
    return value


def validate_output_dir(ctx: Any, param: Any, value: Path | None) -> Path | None:
    """Validate output directory.
    
    Args:
        ctx: Click context
        param: Click parameter
        value: Directory path value
        
    Returns:
        Validated path
    """
    if value is None:
        return None
    
    value.mkdir(parents=True, exist_ok=True)
    return value


def validate_agent_name(ctx: Any, param: Any, value: str | None) -> str | None:
    """Validate agent name.
    
    Args:
        ctx: Click context
        param: Click parameter
        value: Agent name value
        
    Returns:
        Validated name
        
    Raises:
        click.BadParameter: If name is invalid
    """
    if value is None:
        return None
    
    if not value.strip():
        raise click.BadParameter("Agent name cannot be empty")
    
    if not value.replace("-", "").replace("_", "").isalnum():
        raise click.BadParameter(
            f"Agent name must be alphanumeric (with hyphens/underscores): {value}"
        )
    
    return value


__all__ = [
    "validate_config_file",
    "validate_output_dir",
    "validate_agent_name",
]
