"""CLI commands."""
from __future__ import annotations

from .admin import admin, clean, export, import_data
from .agent import chat, describe, run, test_command, tui_ide_command, validate
from .project import (
    project,
    project_new,
    releases,
    upgrade,
    upgrade_checklist,
    upgrade_cli,
    upgrade_plan,
    upgrade_release_notes,
    upgrade_checklist_command,
)
from .quality import (
    integration_command,
    judge_eval_command,
    load_test_command,
    quality,
    regression_command,
    schema,
    template,
    test,
)
from .serve import serve, test_live

__all__ = [
    # Agent commands
    "run",
    "chat",
    "test_command",
    "validate",
    "describe",
    "tui_ide_command",
    # Serve commands
    "serve",
    "test_live",
    # Project commands
    "project",
    "project_new",
    "upgrade",
    "releases",
    "upgrade_checklist",
    "upgrade_cli",
    "upgrade_plan",
    "upgrade_release_notes",
    "upgrade_checklist_command",
    # Admin commands
    "admin",
    "export",
    "import_data",
    "clean",
    # Quality commands
    "quality",
    "test",
    "schema",
    "template",
    "integration_command",
    "load_test_command",
    "regression_command",
    "judge_eval_command",
]
