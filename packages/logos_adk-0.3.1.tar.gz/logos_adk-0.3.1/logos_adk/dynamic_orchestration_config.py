"""Typed configuration for declarative department supervisors."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from logos_adk.config import AgentConfig
from logos_adk.crew import CrewProcessMode, CrewTask
from logos_adk.team_config import EventBusConfig, TeamConfig


DepartmentConfigKind = Literal["team", "crew", "swarm"]


@dataclass
class SwarmSubscriptionConfig:
    """Declarative swarm topic subscription."""

    topic: str
    handler: str
    publish_to: str | None = None
    name: str | None = None


@dataclass
class DepartmentConfig:
    """Typed department definition for DepartmentSupervisor."""

    name: str
    kind: DepartmentConfigKind
    description: str = ""
    capability_tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    team: TeamConfig | None = None
    tasks: list[CrewTask] = field(default_factory=list)
    process: CrewProcessMode = "sequential"
    manager_role: str | None = None
    max_parallel_tasks: int | None = None
    event_bus: EventBusConfig | None = None
    request_topic: str | None = None
    response_topic: str | None = None
    subscriptions: list[SwarmSubscriptionConfig] = field(default_factory=list)
    retry_delay_seconds: float = 0.0
    lease_seconds: float = 60.0


@dataclass
class DepartmentSupervisorConfig:
    """Configuration for DepartmentSupervisor."""

    name: str
    router: AgentConfig | None = None
    fallback_department: str | None = None
    departments: list[DepartmentConfig] = field(default_factory=list)

