"""rag_tool — Tool factory for agent-driven knowledge base search."""
from __future__ import annotations

from logos_adk.rag.knowledge_base import KnowledgeBase
from logos_adk.tools import Tool, tool


def rag_tool(knowledge_base: KnowledgeBase, limit: int = 5) -> Tool:
    """Create a tool that lets an agent search a knowledge base.

    Args:
        knowledge_base: The KnowledgeBase to search.
        limit: Maximum number of results to return.

    Returns:
        A Tool instance named ``retrieve``.
    """

    @tool(name="retrieve", description="Search the knowledge base for relevant information")
    async def retrieve(query: str) -> str:
        chunks = await knowledge_base.search(query, limit=limit)
        if not chunks:
            return "No relevant information found."
        return "\n\n---\n\n".join(chunk.content for chunk in chunks)

    return retrieve
