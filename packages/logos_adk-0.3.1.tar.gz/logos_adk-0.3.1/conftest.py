"""Shared test fixtures for Logos ADK."""
import pytest


@pytest.fixture(autouse=True)
def _clear_tool_registry():
    """Clear the global tool registry between tests to prevent shared-state pollution."""
    from logos_adk.tools.registry import tool_registry
    tool_registry.clear()
    yield
    tool_registry.clear()


@pytest.fixture(autouse=True)
def _reset_default_runtime():
    """Reset the default runtime between tests to prevent cross-test pollution."""
    from logos_adk.runtime import _default_runtime_holder
    _default_runtime_holder.reset()
    yield
    _default_runtime_holder.reset()
