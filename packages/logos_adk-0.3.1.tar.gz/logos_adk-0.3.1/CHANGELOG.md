# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog and the project aims to follow Semantic Versioning.

## [0.3.0] - 2026-03-26

### Added
- Public CLI package layout under `logos_adk/cli/`
- Stable HTTP route documentation for sessions, streaming, quality, and state flows
- Operator surfaces for retrieval and evaluation workflows
- Stronger public quality baseline and CI-friendly validation script

### Changed
- Consolidated the production `Agent` implementation on mixin-based `logos_adk.agent.core`
- Updated serve/runtime contracts for resume, stream UI, state, quality, and billing routes
- Expanded regression coverage across `agent`, `serve`, `runtime`, `state`, and evaluation workflows

### Removed
- Experimental alternate `Agent` implementations and manager-based variants from the public tree
- Generated runtime artefacts from the repository tree
