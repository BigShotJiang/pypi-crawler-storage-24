# Contributing

## Development setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev,serve,postgresql,cli,tui]"
```

## Before opening a pull request

Run the public quality gate:

```bash
bash scripts/quality_baseline.sh
```

Recommended additional checks:

```bash
python -m ruff check logos_adk tests
python -m mypy logos_adk
```

## Scope

- Keep public API changes deliberate and documented.
- Add or update tests for behavior changes.
- Avoid committing local databases, logs, caches, or `.env` files.
- Do not introduce breaking CLI or HTTP changes without updating docs.

## Pull requests

Include:

- a short problem statement
- the behavioral change
- validation steps you ran
- any compatibility or migration notes
