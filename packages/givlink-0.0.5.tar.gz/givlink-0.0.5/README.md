# givlink

Convert Tidal URL to Spotify URL.