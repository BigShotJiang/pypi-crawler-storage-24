from givlink.tidal import get_song_info
from givlink.spotify import search_spotify
import sys

def main():
    if len(sys.argv) < 2:
        print("Usage: givlink <tidal_url>")
        return
    
    url = sys.argv[1]

    print("Fetching Tidal info...")
    song, artist = get_song_info(url)

    print(f"{song} - {artist}")
    print("Searching on Spotify...")

    link = search_spotify(song, artist)

    print("Spotify:", link)

if __name__ == "__main__":
    main()