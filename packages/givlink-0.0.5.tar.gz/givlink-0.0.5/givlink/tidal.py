import requests
from bs4 import BeautifulSoup

def get_song_info(url):
    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    res = requests.get(url, headers=headers)
    soup = BeautifulSoup(res.text, "html.parser")

    title = soup.title.string if soup.title else ""

    # Example: "Dinner Party by Niall Horan on TIDAL"
    if "by" in title:
        parts = title.split("by")
        song = parts[0].strip()
        artist = parts[1].split("on")[0].strip()
    else:
        song = title
        artist = ""

    return song, artist