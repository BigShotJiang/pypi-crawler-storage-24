import requests
from bs4 import BeautifulSoup

def search_spotify(song, artist):
    query = f"{song} {artist}".replace(" ", "%20")
    url = f"https://open.spotify.com/search/{query}"

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    res = requests.get(url, headers=headers)
    soup = BeautifulSoup(res.text, "html.parser")

    # Find all links
    links = soup.find_all("a")

    for link in links:
        href = link.get("href", "")
        if "/track/" in href:
            return "https://open.spotify.com" + href

    return "No match found"