###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import os

import numpy as np
import ROOT as R

from triggercalib.utils.tests import check_result

os.makedirs("results", exist_ok=True)
R.gROOT.SetBatch(True)


def test_sideband_1D(example_file):
    from triggercalib import SidebandEff
    from triggercalib.utils import helpers, tests

    tree, path = example_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_eff = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
    )
    sideband_eff.write("results/output_test_sideband_1D.root")

    hist = sideband_eff.efficiencies[
        "trig_total_efficiency_observ1"
    ]  # Test 'manual' result extraction
    val = hist.GetPointY(0)
    err_low = hist.GetErrorYlow(0)
    err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        sample=f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )

    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError

    # Test also conversion of TGraph to TH
    tgraph = sideband_eff.efficiencies["trig_efficiency_observ1"]
    th = helpers.tgraph_to_th(tgraph, "test_trig_efficiency_observ1_TH", "TH title")
    tests.compare_tgraph_to_th(tgraph, th)


def test_sideband_1D_sparse(example_sparse_file):
    from triggercalib import SidebandEff
    from triggercalib.utils import helpers, tests

    tree, path = example_sparse_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_eff = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
    )


def test_sideband_2D(example_file):
    from triggercalib import SidebandEff
    from triggercalib.utils import helpers, tests

    tree, path = example_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {
        "variables": ["observ1", "observ2"],
        "bins": [np.linspace(0, 8, 4), np.linspace(-18, 12, 4)],
    }

    sideband_eff = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
    )
    sideband_eff.write("results/output_test_sideband_2D.root")

    hist = sideband_eff.efficiencies["trig_total_efficiency_observ1_observ2"]
    val = hist.GetZ()[0]
    err_low = hist.GetErrorZlow(0)
    err_high = hist.GetErrorZhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        sample=f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8 && observ2 > -18 && observ2 < 12",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError

    # Test also conversion of TGraph to TH
    tgraph = sideband_eff.efficiencies["trig_efficiency_observ1_observ2"]
    th = helpers.tgraph_to_th(tgraph, "test_trig_efficiency_observ1_observ2_TH")
    tests.compare_tgraph_to_th(tgraph, th)


def test_sideband_1D_no_trig(example_file):
    from triggercalib import SidebandEff

    tree, path = example_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_eff = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        trig_effs=False,
    )
    sideband_eff.write("results/output_test_sideband_1D_no_trig.root")


def test_sideband_1D_weighted(example_file):
    from triggercalib import SidebandEff

    tree, path = example_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_eff = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        weight="event_weight",
    )
    sideband_eff.write("results/output_test_sideband_1D_weighted.root")

    hist = sideband_eff.efficiencies[
        "trig_total_efficiency_observ1"
    ]  # Test 'manual' result extraction
    val = hist.GetPointY(0)
    err_low = hist.GetErrorYlow(0)
    err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        sample=f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError


def test_sideband_1D_friend_weighted(example_file, example_friend_file):
    from triggercalib import SidebandEff

    tree, path = example_file
    friend_tree, friend_path = example_friend_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_eff = SidebandEff(
        path=path,
        tree=tree,
        friend_path=friend_path,
        friend_tree=friend_tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
    )
    sideband_eff.write("results/output_test_sideband_1D_friend_weighted.root")
