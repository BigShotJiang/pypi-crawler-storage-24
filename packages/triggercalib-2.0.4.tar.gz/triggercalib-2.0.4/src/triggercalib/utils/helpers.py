###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from array import array
from ctypes import c_double
import itertools as it
import re
from typing import Annotated, Dict, List, Literal, Union
import uuid

import numpy as np
import ROOT as R

from triggercalib.core.Binning import Binning


def bins_from_taxis(axis: R.TAxis, as_array: bool = False, as_np: bool = True):
    """Extract bin edges from a ROOT TAxis object

    Args:
        axis (ROOT.TAxis): ROOT TAxis object to extract bins from
        as_array (bool): Whether to return bins as a ROOT array
        as_np (bool): Whether to return bins as a numpy array

    Returns:
        (List): List/ROOT/numpy array of bin edges
    """
    bins = [axis.GetBinLowEdge(0)] + [
        axis.GetBinUpEdge(i) for i in range(1, axis.GetNbins() + 1)
    ]

    if as_array:
        if as_np:
            raise RuntimeError("'as_array' and 'as_np' may not both be set")
        return array("d", bins)
    elif as_np:
        return np.array(bins)
    return bins


def bin_nums_from_hist(hist: R.TH1):
    """
    Get bin numbers from a ROOT histogram

    Args:
        hist (ROOT.TH1): Histogram to extract bin numbers from

    Returns:
        (List[int]): List of bin numbers
    """

    xbins = range(1, hist.GetNbinsX() + 1)
    if isinstance(hist, R.TH2):
        ybins = range(1, hist.GetNbinsY() + 1)
        bin_indices = it.product(xbins, ybins)
    else:
        bin_indices = [(b,) for b in xbins]

    return [hist.GetBin(*b) for b in bin_indices]


def sum_bins(hist: R.TH1):
    """
    Sum the contents (linear) and errors (in quadrature) of all bins in a ROOT histogram

    Args:
        hist (ROOT.TH1): Histogram to sum

    Returns:
        (float): Sum of contents
        (float): Sum of errors (in quadrature)
    """
    contents = []
    errors = []

    bin_nums = bin_nums_from_hist(hist)
    for n_bin in bin_nums:
        contents.append(hist.GetBinContent(n_bin))
        errors.append(hist.GetBinError(n_bin))

    sum_content = np.sum(contents)
    sum_error = np.sqrt(np.sum(np.array(errors) ** 2))

    return sum_content, sum_error


def tgraph_to_th(
    graph: Union[R.TGraphAsymmErrors, R.TGraph2DAsymmErrors],
    name: str = "",
    title: str = "",
    error_type: Literal["mean", "lower", "upper"] = "mean",
):
    """Convert a ROOT TGraph(2D)AsymmErrors to a TH1(2)D

    Args:
        graph (ROOT.TGraphAsymmErrors, R.TGraph2DAsymmErrors): ROOT TGraph(2D)AsymmErrors to convert
        name (str): Optional name for output histogram
        title (str): Optional title for output histogram
        error_type (Literal["mean", "lower", "upper"]): Which error to use (`mean`, `lower` or `upper`), defaults to `mean`

    Returns:
        (TH1D, TH2D): Histogram containing graph points with symmetric errors
    """

    x = c_double(0)
    y = c_double(0)
    z = c_double(0)

    x_edges = []
    y_edges = []

    x_vals = []
    y_vals = []
    values = []
    errors = []

    for n in range(graph.GetN()):
        if isinstance(graph, R.TGraph2DAsymmErrors):
            graph.GetPoint(n, x, y, z)
        else:
            graph.GetPoint(n, x, y)

        x_edges.append(x.value - graph.GetErrorXlow(n))
        x_edges.append(x.value + graph.GetErrorXhigh(n))

        x_vals.append(x.value)
        if isinstance(graph, R.TGraph2DAsymmErrors):
            y_edges.append(y.value - graph.GetErrorYlow(n))
            y_edges.append(y.value + graph.GetErrorYhigh(n))

            y_vals.append(y.value)
            values.append(z.value)
            if error_type == "lower":
                errors.append(graph.GetErrorZlow(n))
            elif error_type == "upper":
                errors.append(graph.GetErrorZhigh(n))
            else:
                errors.append(graph.GetErrorZ(n))
        else:
            values.append(y.value)
            if error_type == "lower":
                errors.append(graph.GetErrorYlow(n))
            elif error_type == "upper":
                errors.append(graph.GetErrorYhigh(n))
            else:
                errors.append(graph.GetErrorY(n))

    x_edges = np.array(sorted(list(set(x_edges))))
    y_edges = np.array(sorted(list(set(y_edges))))

    unique_suffix = uuid.uuid4().hex[:8]
    if name == "":
        name = f"{graph.GetName()}_{unique_suffix}_TH"
    if title == "":
        title = name

    if isinstance(graph, R.TGraph2DAsymmErrors):
        hist = R.TH2D(
            name,
            title,
            len(x_edges) - 1,
            x_edges,
            len(y_edges) - 1,
            y_edges,
        )
        for x_val, y_val, value, error in zip(x_vals, y_vals, values, errors):
            n = hist.FindBin(x_val, y_val)
            hist.SetBinContent(n, value)
            hist.SetBinError(n, error)
    else:
        hist = R.TH1D(
            name,
            title,
            len(x_edges) - 1,
            x_edges,
        )
        for x_val, value, error in zip(x_vals, values, errors):
            n = hist.FindBin(x_val)
            hist.SetBinContent(n, value)
            hist.SetBinError(n, error)

    return hist


def th_to_np(th: R.TH1, xscale: float = 1.0, yscale: float = 1.0, zscale: float = 1.0):
    """Convert a ROOT TH1(2)D to numpy objects

    Args:
        th (ROOT.TH1): ROOT TH1(2)D to convert
        xscale (float): Scale factor for x-axis
        yscale (float): Scale factor for y-axis
        zscale (float): Scale factor for z-axis

    Returns:
        x_vals (np.array): x-axis bin centres
        y_vals (np.array): values in each bin if TH1D given, otherwise y-axis bin centres
        z_vals (np.array): values in each bin, (only if TH2D given)
        x_errors (np.array): x-axis bin widths
        y_errors (np.array): errors in each bin if TH1D given, otherwise y-axis bin widths
        z_errors (np.array): errors in each bin (only if TH2D given)
    """

    dims = 2 if isinstance(th, R.TH2) else 1

    x_edges = bins_from_taxis(th.GetXaxis(), as_np=True) * xscale
    x_vals = (x_edges[1:] + x_edges[:-1]) / 2
    x_errors = (x_edges[1:] - x_edges[:-1]) / 2

    shape = [len(x_edges) - 1]

    if dims > 1:
        y_edges = bins_from_taxis(th.GetYaxis(), as_np=True) * yscale
        y_vals = (y_edges[1:] + y_edges[:-1]) / 2
        y_errors = (y_edges[1:] - y_edges[:-1]) / 2

        shape.append(len(y_edges) - 1)

    n_bins = bin_nums_from_hist(th)

    values = []
    errors = []
    for n_bin in n_bins:
        values.append(th.GetBinContent(n_bin))
        errors.append(th.GetBinError(n_bin))

    values = np.reshape(values, shape)
    errors = np.reshape(errors, shape)

    if dims == 1:
        return x_vals, values, x_errors, errors
    elif dims == 2:
        return x_vals, y_vals, values, x_errors, y_errors, errors
    raise NotImplementedError


def tgraph_to_np(
    tgraph: Union[R.TGraphAsymmErrors, R.TGraph2DAsymmErrors],
    xscale: float = 1.0,
    yscale: float = 1.0,
    zscale: float = 1.0,
    symmetric_uncertainties: bool = False,
):
    """Convert a ROOT TGraph(2D)(AsymmErrors) to numpy objects

    Args:
        tgraph (ROOT.TGraphAsymmErrors, ROOT.TGraph2DAsymmErrors): ROOT TGraph(2D)(AsymmErrors) to convert
        xscale (float): Scale factor for x-axis
        yscale (float): Scale factor for y-axis
        zscale (float): Scale factor for z-axis
        symmetric_uncertainties (bool): Whether to report uncertainties as the mean of the lower and upper uncertainties

    Returns:
        x_vals (np.array): x-axis bin centres
        y_vals (np.array): values in each bin if TH1D given, otherwise y-axis bin centres
        z_vals (np.array): values in each bin, (only if TH2D given)
        x_errors (np.array): x-axis bin widths
        y_errors (np.array): errors in each bin if TH1D given, otherwise y-axis bin widths
        z_errors (np.array): errors in each bin (only if TH2D given)
    """

    if (
        not (isinstance(tgraph, (R.TGraphAsymmErrors, R.TGraph2DAsymmErrors)))
        or symmetric_uncertainties
    ):
        th = tgraph_to_th(tgraph)
        return th_to_np(th, xscale=xscale, yscale=yscale, zscale=zscale)

    th_low = tgraph_to_th(tgraph, error_type="lower")
    low_as_np = list(th_to_np(th_low, xscale=xscale, yscale=yscale, zscale=zscale))

    th_high = tgraph_to_th(tgraph, error_type="upper")
    high_as_np = th_to_np(th_high, xscale=xscale, yscale=yscale, zscale=zscale)

    low_as_np[-1] = [low_as_np[-1], high_as_np[-1]]

    return low_as_np


def construct_variable(
    name: str,
    value: float = None,
    limits: Annotated[List[float], 2] = None,
    title: str = None,
):
    """
    Create a ROOT variable (ROOT.RooRealVar) from a name, value, limits and title

    Args:
        name (str): Name of the variable
        value (float, optional): Value of the variable
        limits (Annotated[List[float], 2], optional): Limits of the variable
        title (str, optional): Title of the variable

    Returns:
        (ROOT.RooRealVar): ROOT variable
    """

    if title is None:
        title = name

    if limits:
        if value:
            return R.RooRealVar(name, title, value, *limits)
        return R.RooRealVar(name, title, *limits)
    elif value:
        return R.RooRealVar(name, title, value)
    return R.RooRealVar(name, title, -np.inf, np.inf)


def create_dataset(
    data: Dict[str, np.ndarray],
    observable: Union[str, List],
    weight="",
):
    """
    Create a ROOT dataset from a dictionary of numpy arrays

    Args:
        data (Dict[str, np.ndarray]): Dictionary of numpy arrays
        observable (Union[str, List]): Name of the observable
        weight (str, optional): Name of the weight variable

    Returns:
        (ROOT.RooDataSet): ROOT dataset
    """

    observables = observable if isinstance(observable, List) else [observable]
    if weight and not any(obs.GetName() for obs in observables):
        observables.append(construct_variable(weight))

    return R.RooDataSet.from_numpy(data, observables, weight_name=weight)


def parse_selection(
    particle: str,
    lines: Union[str, List[str]],
    category: Literal["", "TIS", "TOS"],
    branches: List[str],
):
    """Parse trigger selection strings into ROOT cut expressions

    Args:
        particle (str): Particle to seek TIS/TOS branches for
        lines (Union[str, List[str]]): Trigger line(s) to create selection for
        category (Literal["", "TIS", "TOS"]): Optional trigger outcome category (TIS/TOS) to append
        branches (List[str]): List of branches to compare against

    Returns:
        (str): ROOT cut expression combining the selections
    """

    if isinstance(lines, str):
        # If only a string given, use regex match to get branches
        search_string = (
            f"{particle}_{lines}Decision_{category}" if category else f"{lines}Decision"
        )
        search = re.compile(search_string)
        lines = set()
        for branch in branches:
            if search.fullmatch(branch):
                branch = branch.replace("Decision", "")
                if category:
                    branch = branch.split(f"{particle}_", 1)[1]
                    branch = branch.rsplit(f"_{category}", 1)[0]
                lines.update({branch})
        if len(lines) == 0:
            RuntimeError(f"No branches found matching '{search_string}'")
        lines = list(lines)
        lines.sort()

    for line in lines:
        branch_name = (
            f"{particle}_{line}Decision_{category}" if category else f"{line}Decision"
        )
        if branch_name not in branches:
            raise RuntimeError(f"Branch '{branch_name}' could not be found")

    cuts = []
    for level in ("Hlt1", "Hlt2"):
        cut = " || ".join(
            (f"{particle}_{line}Decision_{category}" if category else f"{line}Decision")
            for line in lines
            if line.startswith(level)
        )
        if cut:
            cuts += [f"({cut})"]

    return " && ".join(cuts)


def empty_histogram(name: str, binning: Binning):
    """Create an empty ROOT.TH1D with specified binning scheme

    Args:
        name (str): Name for the histogram
        binning (Binning): binning scheme of interest

    Returns:
        (TH1D, TH2D): Empty histogram with appropriate binning
    """

    if len(binning.variables) == 1:
        return R.TH1D(
            name,
            name,
            len(binning.bins[0]) - 1,
            array("d", binning.bins[0]),
        )
    elif len(binning.variables) == 2:
        return R.TH2D(
            name,
            name,
            len(binning.bins[0]) - 1,
            array("d", binning.bins[0]),
            len(binning.bins[1]) - 1,
            array("d", binning.bins[1]),
        )
    raise NotImplementedError(
        "Construction of empty histograms above 2D not yet implemented in TriggerCalib"
    )
