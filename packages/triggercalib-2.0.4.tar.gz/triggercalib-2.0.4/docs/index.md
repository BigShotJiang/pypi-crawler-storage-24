---
hide:
  - navigation
  - footer
  - toc
---

# TriggerCalib: a turnkey package for estimating trigger efficiencies at LHCb

Welcome to the official documentation for the TriggerCalib software package.
This Python package provides offline analysis tools for calculating trigger efficiencies in LHCb with the data-driven TISTOS method.
TriggerCalib was written with Run 3 in mind; however, it should be applicable for use in Run 2 analyses/studies.
The source can be found at [lhcb-rta/triggercalib](https://gitlab.cern.ch/lhcb-rta/triggercalib) and installed [from PyPI](https://pypi.org) by ``pip install triggercalib``.


## Not sure where to start? Here are a few suggestions!
<div class="grid cards" markdown>

- [:material-wrench: __Getting started__](guide/getting-started.md) for installation instructions
- [:material-book: __Tutorials__](guide/tutorials/index.md) for learning how to use TriggerCalib
- [:material-code-braces-box: __Class reference__](reference/index.md) for the finer details
- [:material-code-array: __Use the new CLI__](guide/running-triggercalib.md) to run TriggerCalib from the command line
- [:material-fast-forward: __Cheat sheet (v1. → v2)__](guide/cheat-sheet.md) for users familiar with TriggerCalib


</div>


## Acknowledgements

We acknowledge funding from the European Union Horizon 2020 research and innovation programme, call H2020-MSCA-ITN-2020, under Grant Agreement n. 956086.
