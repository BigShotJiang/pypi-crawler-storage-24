# Cheat sheet (v1 → v2)

This brief guide is aimed at TriggerCalib users who have experience using the package for versions 1.x (v1), particularly 1.4 and 1.5.
In v1, efficiencies were calculated by a single class, `HltEff`.
In v2, this has been broken up into several classes, described in the [`triggercalib.core` class reference](../reference/core.md): `SidebandEff`, `FitAndCountEff` and `SWeightEff`.
Each of these corresponds to a different background mitigation method, with their respective arguments, but they all inherit from a base class `BaseEff`.

This cheat sheet summarises the significant differences between configuring the classes in v1 and v2.
Additionally, efficiencies can now be evaluated from the command line, as described in [Running TriggerCalib](running-triggercalib.md).

## Differences between v1 and v2

- Binning schemes, which can be loaded from a config (.json/.yaml) or passed directly as a dist (or `Binning` object), must now be given as structures of the form:
```yaml
variables:
 - "var1"  # Variables in first dimension
 - "var2" # Variables in second dimension
bins:
 - [ ... ] # Bins in first dimension
 - [ ... ] # Bins in second dimension
labels: # Optional, must align with variables
 - "Fancy label for variable 1"
 - "Fancy label for variable 2"
```
- Optional binning schemes can be generated, now with the `Binning.generate` method.
- Sideband-subtraction is now done by `SidebandEff` and requires specifying the argument `sideband` in the form:
```yaml
variable: sideband_variable
signal: [ ... ] # Signal range
sidebands: 
  - [ ... ] # First sideband range
  - [ ... ] # Second sideband range
  ... # Additional sibebands as needed
```
- The fit-and-count and sWeights methods have classes `FitCountEff` and `SWeightEff`, respectively.
  - The fit models can be specified either by providing a `ROOT.RooWorkspace` and name of observable and pdf, by providing explicitly a `ROOT.RooAbsReal` observable and `ROOT.RooAddPdf` PDF, or by a dictionary/config file of the form, from which model and datasets are generated:
    ```yaml
    data:
    variable: observable
    range: [5000, 5600]
    cuts: # Optional
        - requirement1 # Some requirement on the 
        ...
    label: "Fancy label for observable" # Optional 
    model:
    components:
        signal: 
        function: Gaussian 
        parameters:
            mean: [5200, 5100, 5300]
            sigma: [10, 1, 20]
        background:
        function: Exponential
        parameters:
            lambda: 0.001
    ```
  - Plotting has been delegated to the `write()` method of classes inheriting from `BaseEff`.
  - Efficiencies are now computed for each component in the model, appending the corresponding yield name to the count/efficiency objects.
- The `expert_mode` argument has been dropped as there is no use case for this anymore.
- The `lazy` argument has been dropped, as there were few relevant use cases for this.
- Counts and efficiencies can be accessed simply as attributes of any class inheriting from `BaseEff`; `get_eff()` and equivalents have been dropped.
