## Helper functions (`utils.helpers`)
::: utils.helpers
    options:
        heading_level: 3
        show_root_toc_entry: false

## I/O functionality (`utils.io`)
::: utils.io
    options:
        heading_level: 3
        show_root_toc_entry: false

## Statistics tools (`utils.stats`)
::: utils.stats
    options:
        heading_level: 3
        show_root_toc_entry: false

## Test utilities (`utils.tests`)
::: utils.tests
    options:
        heading_level: 3
        show_root_toc_entry: false
