---
hide:
    - toc
---

# TriggerCalib reference

This is a reference of the tools in TriggerCalib and is split into four parts:
<div class="grid cards" markdown>
 
 - [:fontawesome-solid-box: __Core objects and CLI__](core.md) for base objects such as `Sideband`
 - [:material-cog-box: __Utilities__](utils.md) for a variety of useful functions such as `th1_to_np`

 </div>
 