"""Bilibili MCP Server

使用 FastMCP + Streamable HTTP 传输方式运行。
"""

import os
import sys

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from .credential import CredentialManager
from .tools.video import VideoTools
from .tools.user import UserTools
from .tools.search import SearchTools
from .tools.comment import CommentTools
from .tools.rank import RankTools
from .tools.session import SessionTools

# 加载环境变量
load_dotenv()

# 创建 FastMCP 实例
mcp = FastMCP("bilibili-mcp")

# 收集所有工具类
TOOL_CLASSES = [
    VideoTools,
    UserTools,
    SearchTools,
    CommentTools,
    RankTools,
    SessionTools,
]


def register_tools():
    """注册所有工具到 FastMCP"""
    for cls in TOOL_CLASSES:
        for attr_name in dir(cls):
            if attr_name.startswith("bilibili_"):
                method = getattr(cls, attr_name)

                # 尝试从类字典中获取原始的 staticmethod 对象
                class_attr = cls.__dict__.get(attr_name)

                # 检查是否为静态方法
                if isinstance(class_attr, staticmethod):
                    # 获取原始函数
                    func = class_attr.__func__
                    # 使用 FastMCP 的 tool 装饰器注册
                    mcp.tool()(func)


# 注册所有工具
register_tools()

# 初始化凭证
CredentialManager.get_credential()


def main():
    """主入口 - 使用 Streamable HTTP 传输方式"""
    mcp.run()


if __name__ == '__main__':
    main()
