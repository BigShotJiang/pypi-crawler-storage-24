"""排行榜和热门模块工具"""

from typing import Literal
from bilibili_api import rank, hot
from .base import BiliTool


class RankTools(BiliTool):
    """排行榜相关工具"""

    @staticmethod
    async def bilibili_get_rank(
            rank_type: Literal[
                "all",  # 全站
                "bangumi",  # 番剧
                "movie",  # 电影
                "documentary",  # 纪录片
                "guochuang_anime",  # 国产动画
                "guochuang",  # 国创相关
                "game",  # 游戏
                "music",  # 音乐
                "douga",  # 动画
                "ent",  # 娱乐
                "life",  # 生活
                "technology",  # 科技数码
                "cinephile",  # 影视
                "fashion",  # 时尚美妆
                "knowledge",  # 知识
                "food",  # 美食
                "sports",  # 运动
                "car",  # 汽车
                "dance",  # 舞蹈
                "kichiku",  # 鬼畜
                "animal",  # 动物圈
                "tv",  # 电视剧
                "variety",  # 综艺
                "original",  # 原创
                "rookie"  # 新人
            ] = "all",
            day: Literal[3, 7] = 3
    ) -> dict:
        """获取排行榜

        Args:
            rank_type: 排行榜类型（all=全站，bangumi=番剧，movie=电影，documentary=纪录片，
                      guochuang_anime=国产动画，guochuang=国创，game=游戏，music=音乐，
                      douga=动画，ent=娱乐，life=生活，technology=科技，cinephile=影视，
                      fashion=时尚，knowledge=知识，food=美食，sports=运动，car=汽车，
                      dance=舞蹈，kichiku=鬼畜，animal=动物，tv=电视剧，variety=综艺，
                      original=原创，rookie=新人）
            day: 时间范围（仅对 PGC 类型有效：番剧/电影/纪录片等），3=三日榜，7=周榜

        Returns:
            排行榜列表
        """
        try:
            type_mapping = {
                "all": rank.RankType.All,
                "bangumi": rank.RankType.Bangumi,
                "movie": rank.RankType.Movie,
                "documentary": rank.RankType.Documentary,
                "guochuang_anime": rank.RankType.GuochuangAnime,
                "guochuang": rank.RankType.Guochuang,
                "game": rank.RankType.Game,
                "music": rank.RankType.Music,
                "douga": rank.RankType.Douga,
                "ent": rank.RankType.Ent,
                "life": rank.RankType.Life,
                "technology": rank.RankType.Technology,
                "cinephile": rank.RankType.Cinephile,
                "fashion": rank.RankType.Fashion,
                "knowledge": rank.RankType.Knowledge,
                "food": rank.RankType.Food,
                "sports": rank.RankType.Sports,
                "car": rank.RankType.Car,
                "dance": rank.RankType.Dance,
                "kichiku": rank.RankType.Kichiku,
                "animal": rank.RankType.Animal,
                "tv": rank.RankType.TV,
                "variety": rank.RankType.Variety,
                "original": rank.RankType.Original,
                "rookie": rank.RankType.Rookie,
            }

            if rank_type not in type_mapping:
                return RankTools.error(f"未知的排行榜类型：{rank_type}")

            type_enum = type_mapping[rank_type]
            day_enum = rank.RankDayType(day)

            result = await rank.get_rank(type_=type_enum, day=day_enum)
            return RankTools.success(result)
        except Exception as e:
            return RankTools.error(str(e))

    @staticmethod
    async def bilibili_get_hot(
            page: int = 1,
            page_size: int = 20
    ) -> dict:
        """获取热门视频

        Args:
            page: 页码（从 1 开始）
            page_size: 每页视频数（默认 20）

        Returns:
            热门视频列表
        """
        try:
            result = await hot.get_hot_videos(pn=page, ps=page_size)
            return RankTools.success(result)
        except Exception as e:
            return RankTools.error(str(e))
