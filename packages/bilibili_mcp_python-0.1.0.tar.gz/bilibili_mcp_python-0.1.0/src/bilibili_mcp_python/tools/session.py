"""消息会话模块工具"""

from typing import Literal, Optional
from bilibili_api import session
from .base import BiliTool


class SessionTools(BiliTool):
    """消息会话相关工具 - 基于 bilibili_api.session 模块"""

    @staticmethod
    async def bilibili_session_list(
        talker_id: Optional[int] = None,
        session_type: int = 4,
        begin_seqno: int = 0
    ) -> dict:
        """获取会话列表或聊天记录

        如果不提供 talker_id，则获取会话列表；
        如果提供 talker_id，则获取与该用户的聊天记录。

        Args:
            talker_id: 会话对象UID（不填则获取会话列表）
            session_type: 会话类型 1:私聊, 2:通知, 3:应援团, 4:全部(默认，仅列表有效)
            begin_seqno: 起始Seqno用于翻页，默认0获取最新消息（仅聊天记录有效）

        Returns:
            会话列表或聊天记录
        """
        credential = SessionTools.get_credential()
        if not credential:
            return SessionTools.error("需要登录凭证才能获取消息")

        try:
            if talker_id:
                # 获取指定会话的聊天记录
                result = await session.fetch_session_msgs(
                    talker_id=talker_id,
                    credential=credential,
                    session_type=session_type if session_type in [1, 2] else 1,
                    begin_seqno=begin_seqno
                )
            else:
                # 获取会话列表
                result = await session.get_sessions(
                    credential=credential,
                    session_type=session_type
                )
            return SessionTools.success(result)
        except Exception as e:
            return SessionTools.error(str(e))

    @staticmethod
    async def bilibili_session_send(
        receiver_id: int,
        content: str
    ) -> dict:
        """发送私信文本消息

        Args:
            receiver_id: 接收者 UID
            content: 消息内容(纯文本)

        Returns:
            发送结果
        """
        credential = SessionTools.get_credential()
        if not credential:
            return SessionTools.error("需要登录凭证才能发送消息")

        try:
            result = await session.send_msg(
                credential=credential,
                receiver_id=receiver_id,
                msg_type=session.EventType.TEXT,
                content=content
            )
            return SessionTools.success(result)
        except Exception as e:
            return SessionTools.error(str(e))

    @staticmethod
    async def bilibili_session_interactions(
        interaction_type: Literal["replies", "likes", "at"] = "replies",
        last_id: Optional[int] = None,
        last_time: Optional[int] = None
    ) -> dict:
        """获取互动消息（回复/点赞/@）

        Args:
            interaction_type: 互动类型
                - replies: 收到的回复
                - likes: 收到的赞
                - at: 收到的@消息
            last_id: 最后一个ID，用于翻页
            last_time: 最后一个消息的时间戳，用于翻页

        Returns:
            互动消息列表
        """
        credential = SessionTools.get_credential()
        if not credential:
            return SessionTools.error("需要登录凭证才能获取互动消息")

        try:
            if interaction_type == "replies":
                result = await session.get_replies(
                    credential=credential,
                    last_reply_id=last_id,
                    reply_time=last_time
                )
            elif interaction_type == "likes":
                result = await session.get_likes(
                    credential=credential,
                    last_id=last_id,
                    like_time=last_time
                )
            elif interaction_type == "at":
                result = await session.get_at(
                    credential=credential,
                    last_id=last_id,
                    at_time=last_time
                )
            else:
                return SessionTools.error(f"未知的互动类型: {interaction_type}")

            return SessionTools.success(result)
        except Exception as e:
            return SessionTools.error(str(e))

    @staticmethod
    async def bilibili_session_notifications(
        notification_type: Literal["unread", "system", "settings"] = "unread"
    ) -> dict:
        """获取通知和设置信息

        Args:
            notification_type: 通知类型
                - unread: 未读消息数量统计(默认)
                - system: 系统消息列表
                - settings: 消息设置

        Returns:
            通知或设置信息
        """
        credential = SessionTools.get_credential()
        if not credential:
            return SessionTools.error("需要登录凭证才能获取通知")

        try:
            if notification_type == "unread":
                result = await session.get_unread_messages(credential=credential)
            elif notification_type == "system":
                result = await session.get_system_messages(credential=credential)
            elif notification_type == "settings":
                result = await session.get_session_settings(credential=credential)
            else:
                return SessionTools.error(f"未知的通知类型: {notification_type}")

            return SessionTools.success(result)
        except Exception as e:
            return SessionTools.error(str(e))
