"""视频模块工具"""

from typing import Literal
from bilibili_api import video, Danmaku
from .base import BiliTool


class VideoTools(BiliTool):
    """视频相关工具"""

    @staticmethod
    async def bilibili_video_get_info(bvid: str) -> dict:
        """获取视频完整信息（包括基础信息、统计数据、分P列表、标签）

        Args:
            bvid: 视频的BV号，如 BV1xx411c7mD

        Returns:
            视频完整信息，包含 title, desc, stat, pages, tags 等
        """
        try:
            v = video.Video(bvid=bvid)

            # 获取基础信息
            info = await v.get_info()

            # 获取分P列表
            pages = await v.get_pages()

            # 合并数据
            result = {
                "bvid": info.get("bvid"),
                "aid": info.get("aid"),
                "title": info.get("title"),
                "description": info.get("desc"),
                "duration": info.get("duration"),
                "pic": info.get("pic"),
                "pubdate": info.get("pubdate"),
                "owner": info.get("owner"),
                "stat": info.get("stat"),
                "pages": pages,
                "tags": info.get("tags", [])
            }

            return VideoTools.success(result)
        except Exception as e:
            return VideoTools.error(str(e))

    @staticmethod
    async def bilibili_video_interact(
        bvid: str,
        action: Literal["like", "coin", "favorite", "triple"],
        cancel: bool = False,
        coin_num: int = 1,
        media_id: int = None
    ) -> dict:
        """视频互动：点赞/投币/收藏/三连

        Args:
            bvid: 视频的BV号
            action: 互动类型 (like-点赞, coin-投币, favorite-收藏, triple-三连)
            cancel: 是否取消操作（仅对like/favorite有效）
            coin_num: 投币数量（1或2，action=coin时有效）
            media_id: 收藏夹ID（action=favorite时有效，不填则使用默认收藏夹）

        Returns:
            操作结果
        """
        credential = VideoTools.get_credential()
        if not credential:
            return VideoTools.error("需要登录凭证才能进行互动操作")

        try:
            v = video.Video(bvid=bvid, credential=credential)

            if action == "like":
                result = await v.like(status=not cancel)
            elif action == "coin":
                result = await v.pay_coin(num=coin_num, like=False)
            elif action == "favorite":
                if cancel:
                    result = await v.set_favorite(del_media_ids=[media_id])
                else:
                    result = await v.set_favorite(add_media_ids=[media_id])
            elif action == "triple":
                result = await v.triple()
            else:
                return VideoTools.error(f"未知的操作类型: {action}")

            return VideoTools.success(result)
        except Exception as e:
            return VideoTools.error(str(e))

    @staticmethod
    async def bilibili_video_get_download_info(bvid: str, page_num: int = 0) -> dict:
        """获取视频下载链接和播放器信息

        Args:
            bvid: 视频的BV号
            page_num: 分P序号，从0开始

        Returns:
            包含下载链接、清晰度列表、播放器配置等信息
        """
        try:
            v = video.Video(bvid=bvid)

            # 获取下载链接
            download_info = await v.get_download_url(page_index=page_num)

            return VideoTools.success(download_info)
        except Exception as e:
            return VideoTools.error(str(e))

    @staticmethod
    async def bilibili_video_get_danmaku(
        bvid: str,
        page_num: int = 0,
        from_seg: int = 0,
        to_seg: int = None
    ) -> dict:
        """获取视频弹幕列表

        Args:
            bvid: 视频的BV号
            page_num: 分P序号，从0开始
            from_seg: 起始弹幕分段，默认0
            to_seg: 结束弹幕分段，默认None表示不限制

        Returns:
            弹幕列表
        """
        try:
            v = video.Video(bvid=bvid)
            danmaku_list = await v.get_danmakus(
                page_index=page_num,
                from_seg=from_seg,
                to_seg=to_seg
            )

            # 转换Danmaku对象为字典
            result = []
            for dm in danmaku_list:
                result.append({
                    "uid": dm.uid,
                    "id_str": dm.id_str,
                    "text": dm.text,
                    "send_time": dm.send_time,
                    "crc32_id": dm.crc32_id,
                    "color": dm.color,
                    "font_size": dm.font_size,
                    "mode": dm.mode,
                    "pool": dm.pool
                })

            return VideoTools.success(result)
        except Exception as e:
            return VideoTools.error(str(e))

    @staticmethod
    async def bilibili_video_send_danmaku(
        bvid: str,
        message: str,
        page_num: int = 0,
        progress: int = 0,
        color: str = "ffffff",
        font_size: Literal[18, 25, 36] = 25,
        mode: Literal[1, 4, 5] = 1
    ) -> dict:
        """发送弹幕

        Args:
            bvid: 视频的BV号
            message: 弹幕内容
            page_num: 分P序号，从0开始
            progress: 发送时间（毫秒），0表示开头
            color: 颜色（十六进制），默认ffffff(白色)
            font_size: 字体大小 (18-小, 25-普通, 36-大)
            mode: 弹幕模式 (1-滚动, 4-底部, 5-顶部)

        Returns:
            发送结果
        """
        credential = VideoTools.get_credential()
        if not credential:
            return VideoTools.error("需要登录凭证才能发送弹幕")

        try:
            v = video.Video(bvid=bvid, credential=credential)

            danmaku = Danmaku(text=message, dm_time=progress / 1000, color=color, font_size=font_size, mode=mode)
            result = await v.send_danmaku(
                page_index=page_num,
                danmaku=danmaku
            )

            return VideoTools.success(result)
        except Exception as e:
            return VideoTools.error(str(e))

    @staticmethod
    async def bilibili_video_get_ai_conclusion(bvid: str) -> dict:
        """获取视频AI总结

        Args:
            bvid: 视频的BV号

        Returns:
            AI生成的视频总结内容
        """
        try:
            credential = VideoTools.get_credential()
            if not credential:
                return VideoTools.error("需要登录凭证才能获取视频ai总结")
            v = video.Video(bvid=bvid, credential=credential)
            result = await v.get_ai_conclusion()

            return VideoTools.success(result)
        except Exception as e:
            return VideoTools.error(str(e))
