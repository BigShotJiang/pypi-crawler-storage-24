"""用户模块工具"""

from typing import Literal
from bilibili_api import user
from .base import BiliTool


class UserTools(BiliTool):
    """用户相关工具"""

    @staticmethod
    async def bilibili_user_get_info(uid: int) -> dict:
        """获取用户完整信息

        Args:
            uid: 用户UID

        Returns:
            用户基础信息、关系统计、UP主数据
        """
        try:
            u = user.User(uid=uid)

            # 获取基础信息
            user_info = await u.get_user_info()

            # 获取关系统计
            relation_stat = await u.get_relation_info()

            # 尝试获取UP主统计（可能失败，非UP主没有数据）
            upstat = {}
            try:
                upstat = await u.get_up_stat()
            except:
                pass

            result = {
                "uid": uid,
                "name": user_info.get("name"),
                "face": user_info.get("face"),
                "sign": user_info.get("sign"),
                "level": user_info.get("level"),
                "vip": user_info.get("vip"),
                "official": user_info.get("official"),
                "relation": relation_stat,
                "upstat": upstat
            }

            return UserTools.success(result)
        except Exception as e:
            return UserTools.error(str(e))

    @staticmethod
    async def bilibili_user_get_contents(
        uid: int,
        content_type: Literal["video", "article", "album", "bangumi", "dynamic"] = "video",
        page_num: int = 1,
        page_size: int = 30,
        keyword: str = "",
        offset: str = ""
    ) -> dict:
        """获取用户内容（视频/专栏/相簿/追番/动态）

        Args:
            uid: 用户UID
            content_type: 内容类型 (video-视频, article-专栏, album-相簿, bangumi-追番)
            page_num: 页码，从1开始
            page_size: 每页数量，最大50
            keyword: 搜索关键词（仅video类型有效）
            offset: 动态分页偏移量（仅dynamic类型有效），为空时从第一条动态开始

        Returns:
            内容列表，dynamic类型返回结果中包含 next_offset 用于下次请求
        """
        try:
            u = user.User(uid=uid)

            if content_type == "video":
                from bilibili_api.user import VideoOrder
                result = await u.get_videos(
                    pn=page_num,
                    keyword=keyword,
                    order=VideoOrder.PUBDATE
                )
            elif content_type == "article":
                from bilibili_api.user import ArticleOrder
                result = await u.get_articles(
                    order=ArticleOrder.PUBDATE
                )
            elif content_type == "album":
                result = await u.get_album(page_num=page_num, page_size=page_size)
            elif content_type == "bangumi":
                from bilibili_api.user import BangumiType
                result = await u.get_subscribed_bangumi(type_=BangumiType.BANGUMI)
            # elif content_type == "dynamic":
            #     result = await u.get_dynamics_new(offset=offset)
            else:
                return UserTools.error(f"未知的内容类型: {content_type}")

            return UserTools.success(result)
        except Exception as e:
            return UserTools.error(str(e))

    @staticmethod
    async def bilibili_user_modify_relation(
        uid: int,
        action: Literal["follow", "unfollow", "block", "unblock", "remove_fans"]
    ) -> dict:
        """修改用户关系：关注/取关/拉黑/取消拉黑/移除粉丝

        Args:
            uid: 目标用户UID
            action: 关系操作类型

        Returns:
            操作结果
        """
        credential = UserTools.get_credential()
        if not credential:
            return UserTools.error("需要登录凭证才能修改用户关系")

        try:
            u = user.User(uid=uid, credential=credential)

            from bilibili_api.user import RelationType
            action_map = {
                "follow": RelationType.SUBSCRIBE,
                "unfollow": RelationType.UNSUBSCRIBE,
                "block": RelationType.BLOCK,
                "unblock": RelationType.UNBLOCK,
                "remove_fans": RelationType.REMOVE_FANS
            }

            relation = action_map.get(action)
            if not relation:
                return UserTools.error(f"未知的操作类型: {action}")

            result = await u.modify_relation(relation=relation)
            return UserTools.success(result)
        except Exception as e:
            return UserTools.error(str(e))

    @staticmethod
    async def bilibili_user_get_followings(
        uid: int,
        page_num: int = 1,
        page_size: int = 20,
        order: Literal["desc", "asc"] = "desc"
    ) -> dict:
        """获取用户关注列表

        Args:
            uid: 用户UID
            page_num: 页码，从1开始
            page_size: 每页数量，默认20
            order: 排序方式 (desc-倒序, asc-正序)

        Returns:
            关注列表，注意：非自己只能查看前5页
        """
        credential = UserTools.get_credential()
        u = user.User(uid=uid, credential=credential)

        try:
            # 使用函数式API获取关注列表
            result = await u.get_followings(pn=page_num, ps=page_size)
            return UserTools.success(result)
        except Exception as e:
            return UserTools.error(str(e))

    @staticmethod
    async def bilibili_user_get_followers(
        uid: int,
        page_num: int = 1,
        page_size: int = 20,
        order: Literal["desc", "asc"] = "desc"
    ) -> dict:
        """获取用户粉丝列表

        Args:
            uid: 用户UID
            page_num: 页码，从1开始
            page_size: 每页数量，默认20
            order: 排序方式 (desc-倒序, asc-正序)

        Returns:
            粉丝列表，注意：非自己只能查看前5页
        """
        credential = UserTools.get_credential()
        u = user.User(uid=uid, credential=credential)

        try:
            result = await u.get_followers(pn=page_num, ps=page_size)
            return UserTools.success(result)
        except Exception as e:
            return UserTools.error(str(e))
