"""工具基类"""

from bilibili_api import Credential
from ..credential import CredentialManager
from ..utils.response import success_response, error_response


class BiliTool:
    """工具基类"""

    @classmethod
    def get_credential(cls) -> Credential | None:
        """获取凭证"""
        return CredentialManager.get_credential()

    @classmethod
    def success(cls, data=None) -> dict:
        """成功响应"""
        return success_response(data)

    @classmethod
    def error(cls, message: str, code: int = -1) -> dict:
        """错误响应"""
        return error_response(message, code)
