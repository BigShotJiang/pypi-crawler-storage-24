"""搜索模块工具"""

from typing import Literal
from bilibili_api import search
from .base import BiliTool


class SearchTools(BiliTool):
    """搜索相关工具"""

    @staticmethod
    async def bilibili_search(
        keyword: str,
        search_type: Literal["all", "video", "user", "article", "live"] = "all",
        page_num: int = 1,
        page_size: int = 20
    ) -> dict:
        """统一搜索（综合/视频/用户/专栏/直播）

        Args:
            keyword: 搜索关键词
            search_type: 搜索类型
            page_num: 页码，从1开始
            page_size: 每页数量

        Returns:
            搜索结果
        """
        try:
            if search_type == "all":
                result = await search.search(keyword=keyword, page=page_num)
            elif search_type == "video":
                from bilibili_api.search import SearchObjectType
                result = await search.search_by_type(
                    keyword=keyword,
                    search_type=SearchObjectType.VIDEO,
                    page=page_num
                )
            elif search_type == "user":
                from bilibili_api.search import SearchObjectType
                result = await search.search_by_type(
                    keyword=keyword,
                    search_type=SearchObjectType.USER,
                    page=page_num
                )
            elif search_type == "article":
                from bilibili_api.search import SearchObjectType
                result = await search.search_by_type(
                    keyword=keyword,
                    search_type=SearchObjectType.ARTICLE,
                    page=page_num
                )
            elif search_type == "live":
                from bilibili_api.search import SearchObjectType
                result = await search.search_by_type(
                    keyword=keyword,
                    search_type=SearchObjectType.LIVE,
                    page=page_num
                )
            else:
                return SearchTools.error(f"未知的搜索类型: {search_type}")

            return SearchTools.success(result)
        except Exception as e:
            return SearchTools.error(str(e))

    @staticmethod
    async def bilibili_get_hot_search() -> dict:
        """获取热门搜索词

        Returns:
            热门搜索词列表
        """
        try:
            result = await search.get_hot_search_keywords()
            return SearchTools.success(result)
        except Exception as e:
            return SearchTools.error(str(e))
