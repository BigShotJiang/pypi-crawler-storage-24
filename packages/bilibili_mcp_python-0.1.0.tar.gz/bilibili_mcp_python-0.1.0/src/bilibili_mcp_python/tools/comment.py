"""评论模块工具"""

from typing import Literal
from bilibili_api import comment
from .base import BiliTool


class CommentTools(BiliTool):
    """评论相关工具"""

    @staticmethod
    async def bilibili_comment_get(
        oid: int,
        type_: Literal["video", "dynamic", "article"] = "video",
        mode: Literal["main", "hot"] = "main",
        offset: str = ""
    ) -> dict:
        """获取评论列表（新版懒加载模式）

        Args:
            oid: 对象ID（视频aid/动态id/文章cv号）
            type_: 评论类型
            mode: 获取模式 (main-主列表, hot-热门)
            offset: 偏移量，首次请求为空字符串，后续请求使用上次返回的 next_offset

        Returns:
            评论列表，包含 cursor 字段用于获取下一页
        """
        try:
            # 映射类型
            type_map = {
                "video": 1,
                "dynamic": 17,
                "article": 12
            }
            comment_type = type_map.get(type_, 1)

            # 获取credential（第二次及以后请求需要）
            credential = CommentTools.get_credential()

            if mode == "hot":
                result = await comment.get_comments_lazy(
                    oid=oid,
                    type_=comment.CommentResourceType(comment_type),
                    offset=offset,
                    order=comment.OrderType.LIKE,
                    credential=credential
                )
            else:  # main
                result = await comment.get_comments_lazy(
                    oid=oid,
                    type_=comment.CommentResourceType(comment_type),
                    offset=offset,
                    credential=credential
                )

            return CommentTools.success(result)
        except Exception as e:
            return CommentTools.error(str(e))

    @staticmethod
    async def bilibili_comment_send(
        oid: int,
        text: str,
        type_: Literal["video", "dynamic", "article"] = "video",
        root: int = None,
        parent: int = None
    ) -> dict:
        """发送评论/回复

        Args:
            oid: 对象ID（视频aid/动态id/文章cv号）
            text: 评论内容
            type_: 评论类型
            root: 根评论ID（回复评论时填写）
            parent: 父评论ID（回复评论时填写，通常与root相同）

        Returns:
            发送结果
        """
        credential = CommentTools.get_credential()
        if not credential:
            return CommentTools.error("需要登录凭证才能发送评论")

        try:
            credential.raise_for_no_sessdata()
            credential.raise_for_no_bili_jct()

            type_map = {
                "video": comment.CommentResourceType.VIDEO,
                "dynamic": comment.CommentResourceType.DYNAMIC,
                "article": comment.CommentResourceType.ARTICLE
            }
            comment_type = type_map.get(type_, comment.CommentResourceType.VIDEO)

            result = await comment.send_comment(
                oid=oid,
                type_=comment_type,
                text=text,
                credential=credential,
                root=root,
                parent=parent
            )

            return CommentTools.success(result)
        except Exception as e:
            return CommentTools.error(str(e))

    @staticmethod
    async def bilibili_comment_operate(
        oid: int,
        rpid: int,
        action: Literal["like", "cancel_like", "hate", "cancel_hate", "delete", "get_sub_comments"],
        type_: Literal["video", "dynamic", "article"] = "video",
        page_index: int = 1,
        page_size: int = 10
    ) -> dict:
        """评论操作：点赞/取消点赞/点踩/取消点踩/删除/获取子评论

        Args:
            oid: 对象ID（视频aid/动态id/文章cv号）
            rpid: 评论ID
            action: 操作类型
            type_: 评论类型
            page_index: 页码索引，从1开始（action=get_sub_comments时有效）
            page_size: 每页评论数，最大20（action=get_sub_comments时有效）

        Returns:
            操作结果
        """
        credential = CommentTools.get_credential()
        if not credential:
            return CommentTools.error("需要登录凭证才能操作评论")

        try:
            credential.raise_for_no_sessdata()
            credential.raise_for_no_bili_jct()

            type_map = {
                "video": comment.CommentResourceType.VIDEO,
                "dynamic": comment.CommentResourceType.DYNAMIC,
                "article": comment.CommentResourceType.ARTICLE
            }
            comment_type = type_map.get(type_, comment.CommentResourceType.VIDEO)

            # 创建 Comment 实例
            c = comment.Comment(
                oid=oid,
                type_=comment_type,
                rpid=rpid,
                credential=credential
            )

            if action == "delete":
                result = await c.delete()
            elif action in ["like", "cancel_like"]:
                status = action == "like"
                result = await c.like(status=status)
            elif action in ["hate", "cancel_hate"]:
                status = action == "hate"
                result = await c.hate(status=status)
            elif action == "get_sub_comments":
                result = await c.get_sub_comments(page_index=page_index, page_size=page_size)
            else:
                return CommentTools.error(f"未知的操作类型: {action}")

            return CommentTools.success(result)
        except Exception as e:
            return CommentTools.error(str(e))
