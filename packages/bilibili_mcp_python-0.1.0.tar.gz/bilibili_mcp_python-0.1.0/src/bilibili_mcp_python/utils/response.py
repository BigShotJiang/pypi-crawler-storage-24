"""统一响应格式工具"""

from typing import Any


def success_response(data: Any = None) -> dict:
    """成功响应"""
    return {
        "success": True,
        "code": 0,
        "message": "ok",
        "data": data
    }


def error_response(message: str, code: int = -1) -> dict:
    """错误响应"""
    return {
        "success": False,
        "code": code,
        "message": message,
        "data": None
    }
