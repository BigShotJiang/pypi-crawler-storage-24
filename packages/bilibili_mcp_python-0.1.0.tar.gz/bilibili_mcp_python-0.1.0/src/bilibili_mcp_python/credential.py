"""凭证管理"""

import os
from bilibili_api import Credential


class CredentialManager:
    """凭证管理器"""

    _credential: Credential | None = None
    _initialized: bool = False

    @classmethod
    def get_credential(cls) -> Credential | None:
        """获取凭证（仅在需要登录时调用）"""
        if not cls._initialized:
            cls._initialize()
        return cls._credential

    @classmethod
    def _initialize(cls) -> None:
        """从环境变量初始化凭证"""
        sessdata = os.getenv("BILI_SESSDATA")
        bili_jct = os.getenv("BILI_JCT")
        buvid3 = os.getenv("BILI_BUVID3")

        if sessdata and bili_jct:
            cls._credential = Credential(
                sessdata=sessdata,
                bili_jct=bili_jct,
                buvid3=buvid3
            )

        cls._initialized = True

    @classmethod
    def has_credential(cls) -> bool:
        """检查是否有有效凭证"""
        return cls.get_credential() is not None
