"""Raw frame processing for take uploads.

Handles resolution detection, raw-to-PNG conversion via ffmpeg,
preview MP4 generation, thumbnail creation, and frame chunking
into tar.gz archives matching the Mavericks upload format.
"""

import json
import os
import re
import shutil
import subprocess
import tarfile
from typing import Dict, List, Optional, Tuple

from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
)

console = Console()

# Chunking constants (must match Mavericks)
FRAMES_PER_ARCHIVE = 32
FRAME_OVERLAP = 5

# Compression
ZSTD_LEVEL = 7

# Known resolutions: (width, height)
KNOWN_RESOLUTIONS = [
    (1280, 720),
    (1280, 800),
    (1920, 1080),
    (848, 480),
    (4112, 3008),
]

# Frame filename pattern: {serial}-COLOR.{frame_number}.raw
FRAME_PATTERN = re.compile(r"^(.+)-COLOR\.(\d+)\.raw$")


def check_ffmpeg():
    """Verify ffmpeg is installed and accessible.

    Raises:
        RuntimeError: If ffmpeg is not found
    """
    if not shutil.which("ffmpeg"):
        raise RuntimeError(
            "ffmpeg is required for take uploads but was not found.\n"
            "Install it:\n"
            "  macOS:   brew install ffmpeg\n"
            "  Ubuntu:  sudo apt install ffmpeg\n"
            "  Windows: https://ffmpeg.org/download.html"
        )


def check_zstd() -> bool:
    """Check if zstd is available on the system."""
    return shutil.which("zstd") is not None




def read_timestamp_json(take_dir: str) -> Dict:
    """Read and parse .timestamp.json from a take directory.

    Args:
        take_dir: Path to the take directory

    Returns:
        Parsed metadata dict

    Raises:
        FileNotFoundError: If .timestamp.json doesn't exist
        json.JSONDecodeError: If file is invalid JSON
    """
    timestamp_path = os.path.join(take_dir, ".timestamp.json")
    if not os.path.exists(timestamp_path):
        raise FileNotFoundError(
            f"No .timestamp.json found in {take_dir}. "
            "This directory does not appear to be a valid take."
        )

    with open(timestamp_path, "r", encoding="utf-8") as f:
        return json.load(f)


def parse_take_naming(dir_name: str) -> Dict[str, str]:
    """Parse take naming from directory name.

    Expected format: production.scene.ec.take.number
    Example: production_01.scene_02.ec.take.001

    Matches Mavericks logic: split on '.ec.take.', extract take_number,
    split remainder on '.' for production/scene.

    Args:
        dir_name: Directory basename (no path)

    Returns:
        Dict with keys: sequence, scene, element, take_number
    """
    parts = dir_name.split(".ec.take.")
    if len(parts) == 2:
        scene_and_production = parts[0]
        take_str = parts[1]

        # Parse take number
        take_number = take_str if take_str.isdigit() else "000"

        # Parse production and scene
        sub_parts = scene_and_production.split(".")
        if len(sub_parts) > 1:
            sequence = sub_parts[0]
            scene = ".".join(sub_parts[1:])
        else:
            sequence = "production"
            scene = "scene"
    else:
        # Fallback: try the backend's format (production.scene.element.take.number)
        all_parts = dir_name.replace("/", "").split(".")
        if len(all_parts) == 5:
            sequence, scene, element, _, take_number = all_parts
            return {
                "sequence": sequence,
                "scene": scene,
                "element": element,
                "take_number": take_number,
            }
        sequence = "production"
        scene = "scene"
        take_number = "000"

    return {
        "sequence": sequence,
        "scene": scene,
        "element": "ec",
        "take_number": take_number,
    }


def detect_resolution(
    file_path: str, pixel_format: str
) -> Optional[Tuple[int, int]]:
    """Determine image dimensions from raw file size and pixel format.

    Matches Mavericks getRGBSizeAndRotation() logic: calculates
    bytes_per_pixel from format, then matches file_size / bpp against
    known resolutions.

    Args:
        file_path: Path to a raw frame file
        pixel_format: 'RAW' (RGB8, 3 bpp) or 'YUY2' (2 bpp)

    Returns:
        (width, height) tuple, or None if resolution can't be determined
    """
    # YUY2 and YUYV variants are 2 bytes/pixel; RAW/RGB8 are 3 bytes/pixel
    bpp = 2 if pixel_format.upper().startswith(("YUY", "YUYV")) else 3
    file_size = os.path.getsize(file_path)
    pixel_count = file_size // bpp

    for w, h in KNOWN_RESOLUTIONS:
        if w * h == pixel_count:
            return (w, h)

    console.print(
        f"[yellow]Warning: Unable to determine resolution from file size "
        f"{file_size} with {bpp} bytes/pixel[/]"
    )
    return None


def find_preview_camera_frames(
    take_dir: str, preview_camera_sn: str
) -> List[str]:
    """Find all raw COLOR frames for the preview/hero camera.

    Args:
        take_dir: Path to the take directory
        preview_camera_sn: Serial number of the preview camera

    Returns:
        Sorted list of filenames matching {sn}-COLOR.*.raw
    """
    prefix = f"{preview_camera_sn}-COLOR"
    frames = []
    for f in os.listdir(take_dir):
        if f.startswith(prefix) and f.endswith(".raw"):
            frames.append(f)
    frames.sort()
    return frames


def _get_ffmpeg_pix_fmt(formats_recorded: str) -> str:
    """Map Mavericks format string to ffmpeg pixel format."""
    fmt = formats_recorded.upper()
    if fmt.startswith(("YUY", "YUYV")):
        return "yuyv422"
    # RAW and default = RGB8
    return "rgb24"


def _get_rotation_filter(rotation: int) -> Optional[str]:
    """Return ffmpeg video filter for rotation, or None."""
    if rotation == 90:
        return "transpose=1"
    elif rotation == 270:
        return "transpose=2"
    return None


def raw_to_png(
    raw_path: str,
    png_path: str,
    width: int,
    height: int,
    pix_fmt: str,
    rotation: int = 0,
    text_overlay: Optional[str] = None,
) -> bool:
    """Convert a single raw frame to PNG using ffmpeg.

    Args:
        raw_path: Path to the input .raw file
        png_path: Path for the output .png file
        width: Image width in pixels
        height: Image height in pixels
        pix_fmt: ffmpeg pixel format ('rgb24' or 'yuyv422')
        rotation: Rotation in degrees (0, 90, or 270)
        text_overlay: Optional text to draw on the image

    Returns:
        True if conversion succeeded
    """
    vf_filters = []

    rotate_filter = _get_rotation_filter(rotation)
    if rotate_filter:
        vf_filters.append(rotate_filter)

    if text_overlay:
        # Escape special characters for ffmpeg drawtext
        escaped_text = text_overlay.replace("'", "\\'").replace(":", "\\:")
        vf_filters.append(
            f"drawtext=text='{escaped_text}'"
            f":x=(w-tw)/2:y=lh"
            f":fontcolor=white:fontsize=24"
            f":box=1:boxcolor=black@0.5:boxborderw=10"
        )

    cmd = [
        "ffmpeg", "-y",
        "-f", "rawvideo",
        "-pix_fmt", pix_fmt,
        "-s", f"{width}x{height}",
        "-i", raw_path,
    ]

    if vf_filters:
        cmd.extend(["-vf", ",".join(vf_filters)])

    cmd.append(png_path)

    result = subprocess.run(
        cmd, capture_output=True, timeout=300,
    )
    if result.returncode != 0 and text_overlay:
        # Retry without text overlay (drawtext may not be available)
        cmd_no_text = [
            "ffmpeg", "-y",
            "-f", "rawvideo",
            "-pix_fmt", pix_fmt,
            "-s", f"{width}x{height}",
            "-i", raw_path,
        ]
        rotate_only = _get_rotation_filter(rotation)
        if rotate_only:
            cmd_no_text.extend(["-vf", rotate_only])
        cmd_no_text.append(png_path)
        result = subprocess.run(cmd_no_text, capture_output=True, timeout=300)
    return result.returncode == 0


def generate_thumbnail(
    take_dir: str,
    metadata: Dict,
    temp_dir: str,
) -> Optional[str]:
    """Generate thumbnail.png from the first preview camera frame.

    Args:
        take_dir: Path to the take directory
        metadata: Parsed .timestamp.json content
        temp_dir: Directory for output files

    Returns:
        Path to the generated thumbnail.png, or None on failure
    """
    preview_camera = metadata.get("preview_camera")
    if not preview_camera:
        console.print("[yellow]Warning: No preview camera specified, skipping thumbnail[/]")
        return None

    frames = find_preview_camera_frames(take_dir, preview_camera)
    if not frames:
        console.print("[yellow]Warning: No preview camera frames found, skipping thumbnail[/]")
        return None

    formats_recorded = metadata.get("formats_recorded", "RAW")
    pix_fmt = _get_ffmpeg_pix_fmt(formats_recorded)
    first_frame = os.path.join(take_dir, frames[0])

    resolution = detect_resolution(first_frame, formats_recorded)
    if not resolution:
        return None

    width, height = resolution
    rotation = metadata.get("camera_rotation", 0) or 0
    if not rotation and metadata.get("point_cloud_domain", {}).get("orientation") == "portrait":
        rotation = 90

    thumbnail_path = os.path.join(temp_dir, "thumbnail.png")
    console.print("[cyan]Generating thumbnail...[/]")

    if raw_to_png(first_frame, thumbnail_path, width, height, pix_fmt, rotation):
        return thumbnail_path

    console.print("[yellow]Warning: Failed to generate thumbnail[/]")
    return None


def generate_preview_mp4(
    take_dir: str,
    metadata: Dict,
    temp_dir: str,
    naming: Dict[str, str],
) -> Optional[str]:
    """Generate preview.mp4 from preview camera frames.

    Pipeline:
    1. Convert raw frames to PNGs with frame number overlay
    2. Fill dropped frames by duplicating previous valid frame
    3. Combine into MP4 via ffmpeg
    4. Optionally mux in audio WAV

    Args:
        take_dir: Path to the take directory
        metadata: Parsed .timestamp.json content
        temp_dir: Directory for output files
        naming: Dict with sequence, scene, take_number keys

    Returns:
        Path to preview.mp4, or None on failure
    """
    preview_camera = metadata.get("preview_camera")
    if not preview_camera:
        console.print("[yellow]Warning: No preview camera specified, skipping preview[/]")
        return None

    frames = find_preview_camera_frames(take_dir, preview_camera)
    if not frames:
        console.print("[yellow]Warning: No preview camera frames found, skipping preview[/]")
        return None

    formats_recorded = metadata.get("formats_recorded", "RAW")
    pix_fmt = _get_ffmpeg_pix_fmt(formats_recorded)
    first_frame = os.path.join(take_dir, frames[0])

    resolution = detect_resolution(first_frame, formats_recorded)
    if not resolution:
        return None

    width, height = resolution
    rotation = metadata.get("camera_rotation", 0) or 0
    if not rotation and metadata.get("point_cloud_domain", {}).get("orientation") == "portrait":
        rotation = 90

    fps = metadata.get("frames_per_second", 15)

    # Determine output dimensions (swapped if rotated 90/270)
    if rotation in (90, 270):
        out_width, out_height = height, width
    else:
        out_width, out_height = width, height

    # Create PNG directory for preview frames
    png_dir = os.path.join(temp_dir, "preview_pngs")
    os.makedirs(png_dir, exist_ok=True)

    # Parse frame numbers and find range
    frame_info = []  # (filename, frame_number)
    for f in frames:
        match = FRAME_PATTERN.match(f)
        if match:
            frame_num = int(match.group(2))
            frame_info.append((f, frame_num))

    if not frame_info:
        console.print("[yellow]Warning: Could not parse frame numbers from filenames[/]")
        return None

    frame_info.sort(key=lambda x: x[1])
    padding = len(str(frame_info[-1][1]))

    # Convert frames to PNGs with progress
    console.print("[cyan]Converting frames to PNGs...[/]")
    last_valid_png = None

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Processing frames", total=len(frame_info))

        for i, (filename, frame_num) in enumerate(frame_info):
            # Create overlay text: frame_number:serial
            frame_str = str(frame_num).zfill(padding)
            overlay_text = f"{frame_str}:{preview_camera}"

            # Output PNG with zero-padded name for proper ffmpeg globbing
            png_name = f"frame_{frame_num:06d}.png"
            png_path = os.path.join(png_dir, png_name)

            raw_path = os.path.join(take_dir, filename)
            success = raw_to_png(
                raw_path, png_path, width, height, pix_fmt,
                rotation, overlay_text,
            )

            if success:
                last_valid_png = png_path

                # Fill dropped frames (gaps between this and previous frame)
                if i > 0:
                    prev_frame_num = frame_info[i - 1][1]
                elif frame_num > 1:
                    # First frame but not frame 1 — fill from 1
                    prev_frame_num = 0
                else:
                    prev_frame_num = frame_num - 1

                # Copy previous frame into gaps
                if last_valid_png and frame_num - prev_frame_num > 1:
                    # Use the previous frame's PNG for gaps
                    prev_png = os.path.join(
                        png_dir, f"frame_{prev_frame_num:06d}.png"
                    )
                    source_png = prev_png if os.path.exists(prev_png) else last_valid_png
                    for gap_num in range(prev_frame_num + 1, frame_num):
                        gap_png = os.path.join(png_dir, f"frame_{gap_num:06d}.png")
                        if not os.path.exists(gap_png):
                            shutil.copy2(source_png, gap_png)

            progress.advance(task)

    # Create MP4 from PNG sequence
    console.print("[cyan]Creating preview MP4...[/]")
    mp4_path = os.path.join(temp_dir, "preview.mp4")

    # Text overlay for production.scene.take
    prod_scene_take = (
        f"{naming['sequence']}.{naming['scene']}.{naming['take_number']}"
        .replace("'", "")
        .upper()
    )

    vf_filters = [
        f"drawtext=text='{prod_scene_take}'"
        f":x=(w-tw)/2:y=h-(lh*2)"
        f":fontcolor=white:fontsize=24"
        f":box=1:boxcolor=black@0.5:boxborderw=10"
    ]

    cmd = [
        "ffmpeg", "-y",
        "-r", str(fps),
        "-f", "image2",
        "-pattern_type", "glob",
        "-i", os.path.join(png_dir, "*.png"),
        "-vcodec", "libx264",
        "-crf", "25",
        "-pix_fmt", "yuv420p",
        "-s", f"{out_width}x{out_height}",
        "-vf", ",".join(vf_filters),
        mp4_path,
    ]

    result = subprocess.run(cmd, capture_output=True, timeout=600)
    if result.returncode != 0:
        console.print(f"[red]Error creating preview MP4: {result.stderr.decode()[-500:]}[/]")
        return None

    # Mux audio if WAV exists
    audio_file = _find_audio_file(take_dir, naming)
    if audio_file:
        console.print("[cyan]Adding audio to preview...[/]")
        mp4_with_audio = os.path.join(temp_dir, "preview_audio.mp4")

        audio_cmd = [
            "ffmpeg", "-y",
            "-i", mp4_path,
            "-i", os.path.join(take_dir, audio_file),
            "-c:v", "copy",
            "-c:a", "aac",
            mp4_with_audio,
        ]

        result = subprocess.run(audio_cmd, capture_output=True, timeout=300)
        if result.returncode == 0:
            os.replace(mp4_with_audio, mp4_path)
        else:
            console.print("[yellow]Warning: Failed to add audio to preview[/]")

    # Clean up PNGs
    shutil.rmtree(png_dir, ignore_errors=True)

    return mp4_path


def _find_audio_file(
    take_dir: str, naming: Dict[str, str]
) -> Optional[str]:
    """Find the audio WAV file for a take if it exists.

    Audio filename format: {production}.{scene}.{take}.wav
    """
    audio_name = f"{naming['sequence']}.{naming['scene']}.{naming['take_number']}.wav"
    audio_path = os.path.join(take_dir, audio_name)
    if os.path.exists(audio_path):
        return audio_name
    return None


def generate_metadata_tar(take_dir: str, temp_dir: str) -> Optional[str]:
    """Create meta_data.tar.gz from the meta_data/ subdirectory.

    Args:
        take_dir: Path to the take directory
        temp_dir: Directory for the output tar.gz

    Returns:
        Path to meta_data.tar.gz, or None if meta_data/ doesn't exist
    """
    meta_dir = os.path.join(take_dir, "meta_data")
    if not os.path.isdir(meta_dir):
        console.print("[yellow]Warning: No meta_data/ directory found, skipping[/]")
        return None

    output_path = os.path.join(temp_dir, "meta_data.tar.gz")
    console.print("[cyan]Compressing metadata...[/]")

    with tarfile.open(output_path, "w:gz") as tar:
        tar.add(meta_dir, arcname="meta_data")

    return output_path


def chunk_raw_frames(
    take_dir: str,
    temp_dir: str,
) -> List[Tuple[str, int]]:
    """Group all raw frames into 32-frame tar.gz archives with 5-frame overlap.

    Matches Mavericks chunking logic exactly:
    - FRAMES_PER_ARCHIVE = 32 frames per archive
    - FRAME_OVERLAP = 5 frames overlap between consecutive archives
    - Uses zstd compression (level 7) if available, gzip fallback
    - Archives named: raw_frames.{start}-{end}.tar.gz

    Args:
        take_dir: Path to the take directory
        temp_dir: Directory for output archives

    Returns:
        List of (archive_path, frame_count) tuples
    """
    # Find all .raw files and group by frame number
    all_files = os.listdir(take_dir)
    raw_files = [f for f in all_files if f.endswith(".raw")]

    if not raw_files:
        console.print("[yellow]Warning: No .raw files found in take directory[/]")
        return []

    # Group files by frame number into archive groups
    # Frame number is parsed from filename: {anything}.{frame_number}.raw
    groups: Dict[int, Dict] = {}  # group_index -> {max: int, files: [str]}

    for filename in raw_files:
        parts = filename.split(".")
        if len(parts) >= 3 and parts[-1] == "raw":
            try:
                frame = int(parts[-2])
            except ValueError:
                continue

            # Determine which archive group this frame belongs to
            group_idx = (frame - 1) // FRAMES_PER_ARCHIVE

            if group_idx not in groups:
                groups[group_idx] = {"max": 0, "files": []}
            groups[group_idx]["max"] = max(groups[group_idx]["max"], frame)
            groups[group_idx]["files"].append(filename)

            # Should this frame also appear in the next archive? (overlap)
            next_boundary = (group_idx + 1) * FRAMES_PER_ARCHIVE
            distance_to_next = next_boundary - frame
            if 0 <= distance_to_next <= FRAME_OVERLAP:
                next_idx = group_idx + 1
                if next_idx not in groups:
                    groups[next_idx] = {"max": 0, "files": []}
                groups[group_idx]["max"] = max(groups[group_idx]["max"], frame)
                groups[next_idx]["files"].append(filename)

    use_zstd = check_zstd()
    if use_zstd:
        console.print("[cyan]Using zstd compression (level 7)[/]")
    else:
        console.print("[yellow]zstd not found, using gzip compression[/]")
        console.print("[dim]Install zstd for faster uploads: brew install zstd[/]")

    archives = []
    sorted_indices = sorted(groups.keys())

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Chunking frames", total=len(sorted_indices))

        for group_idx in sorted_indices:
            group = groups[group_idx]
            start = max(1, (group_idx * FRAMES_PER_ARCHIVE) - FRAME_OVERLAP)
            end = group["max"]

            # Make sure there's more than just overlap frames
            if end < start + FRAME_OVERLAP:
                progress.advance(task)
                continue

            archive_name = f"raw_frames.{start}-{end}.tar.gz"
            archive_path = os.path.join(temp_dir, archive_name)

            # Calculate actual frame count (excluding overlap)
            frame_count = (end - start) - (0 if start == 1 else FRAME_OVERLAP) + 1

            # Create the archive
            files = sorted(group["files"])
            _create_compressed_archive(
                take_dir, archive_path, files, use_zstd
            )

            archives.append((archive_path, frame_count))
            progress.advance(task)

    return archives


def _create_compressed_archive(
    working_dir: str,
    output_path: str,
    files: List[str],
    use_zstd: bool,
) -> None:
    """Create a compressed tar archive of the given files.

    Uses Python's tarfile module for tar creation (cross-platform),
    piped through the zstd command for compression when available.
    Falls back to Python tarfile with gzip on all platforms.

    Args:
        working_dir: Directory containing the files
        output_path: Full path for the output archive
        files: List of filenames (relative to working_dir)
        use_zstd: Whether to use zstd compression
    """
    if use_zstd:
        # Two-step: create uncompressed tar, then compress with zstd.
        # Avoids pipe fragility with large archives (hundreds of files).
        tmp_tar = output_path + ".tmp.tar"
        try:
            with tarfile.open(tmp_tar, "w") as tar:
                for filename in files:
                    filepath = os.path.join(working_dir, filename)
                    tar.add(filepath, arcname=filename)

            result = subprocess.run(
                ["zstd", "-T0", f"-{ZSTD_LEVEL}", "-o", output_path, tmp_tar],
                capture_output=True,
                timeout=600,
            )
            if result.returncode != 0:
                if os.path.exists(output_path):
                    os.unlink(output_path)
                err_msg = result.stderr.decode()[-500:] if result.stderr else "unknown error"
                raise RuntimeError(
                    f"Failed to compress archive {output_path}: {err_msg}"
                )
        finally:
            if os.path.exists(tmp_tar):
                os.unlink(tmp_tar)
    else:
        # Fallback: pure Python tarfile with gzip (works everywhere)
        with tarfile.open(output_path, "w:gz", compresslevel=1) as tar:
            for filename in files:
                filepath = os.path.join(working_dir, filename)
                tar.add(filepath, arcname=filename)
