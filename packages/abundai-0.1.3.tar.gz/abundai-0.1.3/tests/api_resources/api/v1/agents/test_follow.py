# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from abundai import Abundai, AsyncAbundai
from tests.utils import assert_matches_type
from abundai.types.api.v1.agents import SuccessResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestFollow:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_start(self, client: Abundai) -> None:
        follow = client.api.v1.agents.follow.start(
            "handle",
        )
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_start(self, client: Abundai) -> None:
        response = client.api.v1.agents.follow.with_raw_response.start(
            "handle",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        follow = response.parse()
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_start(self, client: Abundai) -> None:
        with client.api.v1.agents.follow.with_streaming_response.start(
            "handle",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            follow = response.parse()
            assert_matches_type(SuccessResponse, follow, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_start(self, client: Abundai) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `handle` but received ''"):
            client.api.v1.agents.follow.with_raw_response.start(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_stop(self, client: Abundai) -> None:
        follow = client.api.v1.agents.follow.stop(
            "handle",
        )
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_stop(self, client: Abundai) -> None:
        response = client.api.v1.agents.follow.with_raw_response.stop(
            "handle",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        follow = response.parse()
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_stop(self, client: Abundai) -> None:
        with client.api.v1.agents.follow.with_streaming_response.stop(
            "handle",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            follow = response.parse()
            assert_matches_type(SuccessResponse, follow, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_stop(self, client: Abundai) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `handle` but received ''"):
            client.api.v1.agents.follow.with_raw_response.stop(
                "",
            )


class TestAsyncFollow:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_start(self, async_client: AsyncAbundai) -> None:
        follow = await async_client.api.v1.agents.follow.start(
            "handle",
        )
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_start(self, async_client: AsyncAbundai) -> None:
        response = await async_client.api.v1.agents.follow.with_raw_response.start(
            "handle",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        follow = await response.parse()
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_start(self, async_client: AsyncAbundai) -> None:
        async with async_client.api.v1.agents.follow.with_streaming_response.start(
            "handle",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            follow = await response.parse()
            assert_matches_type(SuccessResponse, follow, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_start(self, async_client: AsyncAbundai) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `handle` but received ''"):
            await async_client.api.v1.agents.follow.with_raw_response.start(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_stop(self, async_client: AsyncAbundai) -> None:
        follow = await async_client.api.v1.agents.follow.stop(
            "handle",
        )
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_stop(self, async_client: AsyncAbundai) -> None:
        response = await async_client.api.v1.agents.follow.with_raw_response.stop(
            "handle",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        follow = await response.parse()
        assert_matches_type(SuccessResponse, follow, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_stop(self, async_client: AsyncAbundai) -> None:
        async with async_client.api.v1.agents.follow.with_streaming_response.stop(
            "handle",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            follow = await response.parse()
            assert_matches_type(SuccessResponse, follow, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_stop(self, async_client: AsyncAbundai) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `handle` but received ''"):
            await async_client.api.v1.agents.follow.with_raw_response.stop(
                "",
            )
