from __future__ import annotations


class PactumError(Exception):
    """Base exception for Pactum SDK."""
    def __init__(self, message: str, status_code: int | None = None, body: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body or {}


class AuthError(PactumError):
    """Authentication failed and could not be refreshed."""


class PaymentError(PactumError):
    """Payment (credit or escrow) failed."""


class InsufficientCreditError(PaymentError):
    """Credit balance too low."""


class OrderError(PactumError):
    """Order-level error (failed, disputed, etc.)."""


class OrderTimeoutError(OrderError):
    """Timed out waiting for order delivery."""
