from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from comate_agent_sdk.llm.messages import ToolCall, ToolMessage, UserMessage

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


async def execute_skill_call(agent: "AgentRuntime", tool_call: ToolCall) -> ToolMessage:
    """执行 Skill 调用（特殊处理）。"""
    args = json.loads(tool_call.function.arguments)
    skill_name = args.get("skill_name")

    # 查找 Skill
    skill_def = (
        next((s for s in agent.options.skills if s.name == skill_name), None)
        if agent.options.skills
        else None
    )
    if not skill_def:
        return ToolMessage(
            tool_call_id=tool_call.id,
            tool_name="Skill",
            content=f"Error: Unknown Skill '{skill_name}'",
            is_error=True,
        )

    # 准备待注入的消息（将在 ToolMessage 添加到 context 后注入）
    full_prompt = skill_def.get_prompt()

    # 通过 ContextIR 管理 pending skill items
    agent._context.add_skill_injection(
        skill_name=skill_name,
        prompt_msg=UserMessage(content=full_prompt, is_meta=True),
    )

    # 返回 ToolMessage（调用方会先添加这个，再 flush pending items）
    return ToolMessage(
        tool_call_id=tool_call.id,
        tool_name="Skill",
        content=f"Skill '{skill_name}' loaded successfully and will remain active",
        is_error=False,
    )


def rebuild_skill_tool(agent: "AgentRuntime") -> None:
    """重建 Skill 工具（用于 Subagent Skills 筛选后更新工具描述）。"""
    from comate_agent_sdk.skill import create_skill_tool, generate_skill_prompt

    # 1. 移除旧的 Skill 工具
    agent.options.tools[:] = [t for t in agent.options.tools if t.name != "Skill"]
    agent._tool_map.pop("Skill", None)

    # 2. 移除 IR 中的旧 Skill 策略
    agent._context.remove_skill_strategy()

    # 3. 如果还有 skills，重新生成
    if agent.options.skills:
        skill_prompt = generate_skill_prompt(agent.options.skills)
        if skill_prompt:
            # 写入 IR header
            agent._context.set_skill_strategy(skill_prompt)

        # 创建新的 Skill 工具
        skill_tool = create_skill_tool(agent.options.skills)
        agent.options.tools.append(skill_tool)
        agent._tool_map["Skill"] = skill_tool

        logger.debug(f"Rebuilt Skill tool with {len(agent.options.skills)} skill(s)")
    else:
        logger.debug("Removed Skill tool (no skills remaining)")


def remove_skill_strategy(agent: "AgentRuntime") -> None:
    """辅助函数：仅移除 skill_strategy（用于调试/外部调用）。"""
    agent._context.remove_skill_strategy()
