from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.agent.system_prompt import (
    resolve_memory_usage_prompt,
    resolve_system_prompt,
)
from comate_agent_sdk.llm.base import ToolDefinition
from comate_agent_sdk.llm.messages import BaseMessage
from comate_agent_sdk.tokens import UsageSummary

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime
    from comate_agent_sdk.tokens import TokenCost


def get_tool_definitions(agent: "AgentRuntime") -> list[ToolDefinition]:
    from comate_agent_sdk.agent.tool_visibility import visible_tools

    visible = visible_tools(
        agent.options.tools,
        is_subagent=bool(agent._is_subagent),
        is_team_member=bool(agent.is_team_member),
    )
    return [t.definition for t in visible]


def get_messages(agent: "AgentRuntime") -> list[BaseMessage]:
    return agent._context.lower()


def get_token_cost(agent: "AgentRuntime") -> "TokenCost":
    return agent._token_cost


def get_effective_level(agent: "AgentRuntime") -> LLMLevel | None:
    if agent.level is not None:
        return agent.level

    if agent.llm is None or agent.options.llm_levels is None:
        return None

    for lv, llm_inst in agent.options.llm_levels.items():
        if llm_inst is agent.llm:
            return lv

    return None


async def get_usage(
    agent: "AgentRuntime",
    *,
    model: str | None = None,
    source_prefix: str | None = None,
) -> UsageSummary:
    return await agent._token_cost.get_usage_summary(
        model=model,
        source_prefix=source_prefix,
    )


async def get_context_info(agent: "AgentRuntime"):
    from comate_agent_sdk.context.info import ContextInfo, _build_categories

    budget = agent._context.get_budget_status()

    model_name = agent.llm.model
    context_limit = await agent._compaction_service.get_model_context_limit(model_name)
    compact_threshold = await agent._compaction_service.get_threshold_for_model(model_name)

    tool_definitions = agent.tool_definitions if agent.options.tools else []
    tool_defs_tokens = 0
    if tool_definitions:
        import json

        tool_defs_json = json.dumps(
            [d.model_dump() for d in tool_definitions],
            ensure_ascii=False,
        )
        tool_defs_tokens = agent._context.token_counter.count(tool_defs_json)

    used_tokens_message_only = budget.total_tokens
    used_tokens_with_tools = used_tokens_message_only + tool_defs_tokens

    tracker = agent._context_usage_tracker
    ir_total = agent._context.total_tokens
    last_step_reported_tokens = tracker.context_usage if tracker is not None else 0
    next_step_estimated_tokens = (
        tracker.estimate_precheck(ir_total)
        if tracker is not None and tracker.context_usage > 0
        else used_tokens_with_tools
    )

    categories = _build_categories(budget.tokens_by_type, agent._context)

    compaction_enabled = agent._compaction_service.config.enabled if agent._compaction_service else True

    return ContextInfo(
        model_name=model_name,
        context_limit=context_limit,
        compact_threshold=compact_threshold,
        compact_threshold_ratio=budget.compact_threshold_ratio,
        total_tokens=budget.total_tokens,
        header_tokens=budget.header_tokens,
        conversation_tokens=budget.conversation_tokens,
        tool_definitions_tokens=tool_defs_tokens,
        used_tokens_message_only=used_tokens_message_only,
        used_tokens_with_tools=used_tokens_with_tools,
        next_step_estimated_tokens=next_step_estimated_tokens,
        last_step_reported_tokens=last_step_reported_tokens,
        categories=categories,
        compaction_enabled=compaction_enabled,
    )


def add_hidden_user_message(agent: "AgentRuntime", content: str) -> None:
    text = content.strip()
    if not text:
        return
    add_hook_hidden_user_message(agent, text, hook_name="runtime")


def add_hidden_system_reminder(
    agent: "AgentRuntime",
    content: str,
    *,
    metadata: dict[str, Any] | None = None,
) -> None:
    """注入 system reminder，并通过 hidden event 通道对外可见。"""
    text = content.strip()
    if not text:
        return

    item = agent._context.add_system_reminder_message(text, metadata=metadata)
    if item is not None:
        agent._pending_hidden_user_messages.append(text)


def add_hook_hidden_user_message(
    agent: "AgentRuntime",
    content: str,
    *,
    hook_name: str | None = None,
    related_tool_call_id: str | None = None,
) -> None:
    """Hook hidden user message 注入入口（自动遵循 tool barrier）。"""
    agent._context.add_hook_hidden_user_message(
        content,
        hook_name=hook_name,
        related_tool_call_id=related_tool_call_id,
    )
    flushed = agent._context.pop_flushed_hook_injection_texts()
    if flushed:
        agent._pending_hidden_user_messages.extend(flushed)


def drain_hidden_user_messages(agent: "AgentRuntime") -> list[str]:
    flushed = agent._context.pop_flushed_hook_injection_texts()
    if flushed:
        agent._pending_hidden_user_messages.extend(flushed)
    if not agent._pending_hidden_user_messages:
        return []
    pending = list(agent._pending_hidden_user_messages)
    agent._pending_hidden_user_messages.clear()
    return pending


def resolve_system_prompt_text(agent: "AgentRuntime") -> str:
    from comate_agent_sdk.agent.setup import resolve_auto_memory_dir

    auto_memory_dir: str | None = None
    allow_subagent_auto_memory = getattr(agent, "_shared_auto_memory_dir", None) is not None
    if not bool(getattr(agent, "_is_subagent", False)) or allow_subagent_auto_memory:
        try:
            auto_memory_dir = str(resolve_auto_memory_dir(agent))
        except Exception:
            auto_memory_dir = None

    return resolve_system_prompt(
        agent.options.system_prompt,
        role=agent.options.role,
        auto_memory_dir=auto_memory_dir,
    )


def resolve_memory_usage_prompt_text(agent: "AgentRuntime") -> str:
    from comate_agent_sdk.agent.setup import resolve_auto_memory_dir

    if bool(getattr(agent, "_is_subagent", False)) and getattr(
        agent,
        "_shared_auto_memory_dir",
        None,
    ) is None:
        return ""

    try:
        auto_memory_dir = str(resolve_auto_memory_dir(agent))
    except Exception:
        auto_memory_dir = None

    return resolve_memory_usage_prompt(auto_memory_dir)


def clear_history(agent: "AgentRuntime"):
    from comate_agent_sdk.agent.history import clear_history as clear_history_impl

    clear_history_impl(agent)


def load_history(agent: "AgentRuntime", messages: list[BaseMessage]) -> None:
    from comate_agent_sdk.agent.history import load_history as load_history_impl

    load_history_impl(agent, messages)


def set_plan_mode(agent: "AgentRuntime", enabled: bool) -> None:
    """启用/禁用 plan mode。"""
    agent._context.set_plan_mode(enabled)
