from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope
from comate_agent_sdk.system_tools.team.polling import DEFAULT_TEAM_POLL_INTERVAL_SECONDS


@dataclass
class TeamCoordinationState:
    team_name: str = ""
    session_tasks: dict[str, asyncio.Task[None]] = field(default_factory=dict)
    inbox_poll_task: asyncio.Task[None] | None = None
    inbox_poll_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    pending_inbox_events: list[TeamInboxEnvelope] = field(default_factory=list)
    pending_inbox_keys: set[str] = field(default_factory=set)
    acked_inbox_keys: set[str] = field(default_factory=set)
    inbox_epoch: int = 0
    suppress_idle_notification: bool = False
    poll_interval_seconds: float = DEFAULT_TEAM_POLL_INTERVAL_SECONDS
    disable_legacy_inbox_poll: bool = False
    discard_team_turns_callback: Any | None = None
    external_turn_callback: Any | None = None
    turn_complete_callback: Any | None = None

    @property
    def is_active(self) -> bool:
        return bool(self.team_name)
