from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from comate_agent_sdk.prompts import load_prompt, render_prompt
from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime

logger = logging.getLogger("comate_agent_sdk.agent")


@dataclass(slots=True)
class TeamPollResult:
    shutdown_requesters: list[str] = field(default_factory=list)
    continuation_content: str | None = None
    continuation_keys: list[str] = field(default_factory=list)


class TeamTurnCoordinator:
    """团队协作协议在 turn 层的 facade。非 team 模式下方法退化为 no-op。"""

    def __init__(self, agent: "AgentRuntime") -> None:
        self._agent = agent

    async def poll_runtime_team_inbox(self) -> None:
        poll_once = getattr(self._agent, "_poll_team_inbox_once", None)
        if callable(poll_once):
            await poll_once()

    def has_buffered_shutdown_request(self) -> bool:
        pending_events = getattr(self._agent, "_pending_inbox_events", [])
        for event in pending_events:
            message_type = str(getattr(event, "message_type", "") or "").strip()
            if message_type == "shutdown_request":
                return True
        return False

    def consume_buffered(self) -> TeamPollResult:
        drain_pending = getattr(self._agent, "drain_pending_inbox_events", None)
        if not callable(drain_pending):
            return TeamPollResult()

        pending_events = drain_pending()
        if not pending_events:
            return TeamPollResult()

        shutdown_keys: list[str] = []
        shutdown_requesters: list[str] = []
        conversational_events: list[object] = []
        for event in pending_events:
            message_type = str(getattr(event, "message_type", "") or "").strip()
            if message_type == "shutdown_request":
                shutdown_keys.append(str(getattr(event, "key", "") or "").strip())
                from_agent = str(getattr(event, "from_agent", "") or "").strip()
                if from_agent and from_agent not in shutdown_requesters:
                    shutdown_requesters.append(from_agent)
                continue
            conversational_events.append(event)

        if shutdown_keys:
            ack_pending = getattr(self._agent, "ack_pending_inbox_events", None)
            if callable(ack_pending):
                ack_pending(shutdown_keys)
        if shutdown_keys:
            return TeamPollResult(shutdown_requesters=shutdown_requesters)

        if not conversational_events:
            return TeamPollResult()

        continuation_keys = [
            str(getattr(event, "key", "") or "").strip()
            for event in conversational_events
            if str(getattr(event, "key", "") or "").strip()
        ]
        self._agent._pending_inbox_keys.update(continuation_keys)
        return TeamPollResult(
            continuation_content=_format_transport_events_as_team_inbox_turn(conversational_events),
            continuation_keys=continuation_keys,
        )

    def inject_coordination_context(self) -> None:
        role_rule_id, reminder = _build_team_coordination_reminder(self._agent)
        if not role_rule_id or not reminder:
            return
        if _has_live_reminder_rule(self._agent, role_rule_id):
            return

        coordination_role = "leader" if role_rule_id.endswith("_leader") else "member"
        self._agent.add_hidden_system_reminder(
            _wrap_runtime_coordination_reminder(reminder),
            metadata={
                "origin": "runtime_coordination",
                "coordination_kind": "team_coordination",
                "coordination_role": coordination_role,
                "reminder_rule_ids": [role_rule_id],
            },
        )
        if coordination_role == "leader":
            _inject_team_leader_mode_reminder(self._agent)

    def notify_turn_complete(self) -> None:
        callback = self._agent._chat_session_turn_complete_callback
        if callable(callback):
            callback()

    def send_idle_notification(
        self,
        *,
        stop_reason: str = "completed",
        yield_status: str = "",
        last_send_to: str = "",
    ) -> None:
        """D1: 主循环正常结束时，向 leader 发送 idle_notification。

        协作中 idle（等待 teammate 回复）时静默，不向 leader 发任何通知。
        调度 idle（完成任务或等 leader 分配）时正常发送。
        """
        agent = self._agent
        if not getattr(agent, "is_team_member", False):
            return
        if not bool(getattr(agent, "_is_subagent", False)):
            return
        if bool(getattr(agent, "_suppress_team_idle_notification", False)):
            return
        normalized_yield_status = str(yield_status or "").strip()
        normalized_last_send_to = str(last_send_to or "").strip()
        if _is_collaboration_idle(normalized_yield_status, normalized_last_send_to):
            return
        team_name = getattr(agent, "_team_name", "").strip()
        agent_name = resolve_runtime_team_agent_name(
            runtime_name=getattr(agent, "name", None),
            is_subagent=bool(getattr(agent, "_is_subagent", False)),
        )
        if not team_name or not agent_name:
            return
        normalized_stop_reason = str(stop_reason or "completed").strip() or "completed"
        if normalized_stop_reason not in {"completed", "yielded"}:
            return
        try:
            from comate_agent_sdk.system_tools.team.config import TeamConfig
            from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType, get_all_inboxes

            team_cfg = TeamConfig(team_name=team_name)
            leaders = [
                m["name"]
                for m in team_cfg.list_members()
                if m.get("agent_type") == "leader" and m["name"] != agent_name
            ]
            recipients = leaders or [
                name
                for name in get_all_inboxes(team_name)
                if name != agent_name
            ]
            if normalized_stop_reason == "yielded" and normalized_yield_status:
                last_action = f"yielded:{normalized_yield_status}"
            elif normalized_stop_reason == "yielded":
                last_action = "yielded"
            else:
                last_action = "completed_turn"
            idle_message = (
                f"Agent '{agent_name}' is now idle.\n"
                f"idle_reason: {normalized_stop_reason}\n"
                f"last_action: {last_action}"
            )
            for recipient in recipients:
                inbox = Inbox(team_name=team_name, agent_name=recipient)
                inbox.append_message(
                    from_agent=agent_name,
                    message_type=MessageType.IDLE_NOTIFICATION,
                    content=idle_message,
                )
            logger.debug(
                f"[Team] idle_notification 已发送: agent={agent_name!r} "
                f"recipients={recipients!r} stop_reason={normalized_stop_reason!r}"
            )
        except Exception as exc:
            logger.debug(f"[Team] 发送 idle_notification 失败（忽略）: {exc}")

    def send_shutdown_response(
        self,
        *,
        recipients: list[str],
        extra_content: str = "",
    ) -> None:
        """收到 shutdown_request 后，向请求方回复 shutdown_response。"""
        agent = self._agent
        if not getattr(agent, "is_team_member", False):
            return
        team_name = getattr(agent, "_team_name", "").strip()
        agent_name = resolve_runtime_team_agent_name(
            runtime_name=getattr(agent, "name", None),
            is_subagent=bool(getattr(agent, "_is_subagent", False)),
        )
        normalized_recipients = [
            str(recipient).strip()
            for recipient in recipients
            if str(recipient).strip() and str(recipient).strip() != agent_name
        ]
        if not team_name or not agent_name or not normalized_recipients:
            return
        try:
            from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

            message_content = f"Agent '{agent_name}' acknowledged shutdown and is stopping."
            normalized_extra_content = str(extra_content or "").strip()
            if normalized_extra_content:
                message_content = f"{message_content}\n\n{normalized_extra_content}"

            for recipient in normalized_recipients:
                inbox = Inbox(team_name=team_name, agent_name=recipient)
                inbox.append_message(
                    from_agent=agent_name,
                    message_type=MessageType.SHUTDOWN_RESPONSE,
                    content=message_content,
                )
            logger.debug(
                f"[Team] shutdown_response 已发送: agent={agent_name!r} "
                f"recipients={normalized_recipients!r}"
            )
        except Exception as exc:
            logger.debug(f"[Team] 发送 shutdown_response 失败（忽略）: {exc}")


def _inject_team_coordination_context(agent: "AgentRuntime") -> None:
    TeamTurnCoordinator(agent).inject_coordination_context()


def _is_collaboration_idle(yield_status: str, last_send_to: str) -> bool:
    """协作中 idle：等待 teammate 回复，不向 leader 发调度通知。"""
    if yield_status in ("waiting_for_teammate", "waiting_for_peer"):
        return True
    if last_send_to and last_send_to != "team-lead":
        return True
    return False


def _send_team_idle_notification(
    agent: "AgentRuntime",
    *,
    stop_reason: str = "completed",
    yield_status: str = "",
    last_send_to: str = "",
) -> None:
    TeamTurnCoordinator(agent).send_idle_notification(
        stop_reason=stop_reason, yield_status=yield_status, last_send_to=last_send_to
    )


def _send_team_shutdown_response(
    agent: "AgentRuntime",
    *,
    recipients: list[str],
    extra_content: str = "",
) -> None:
    TeamTurnCoordinator(agent).send_shutdown_response(
        recipients=recipients,
        extra_content=extra_content,
    )


def _inject_team_leader_mode_reminder(agent: "AgentRuntime") -> None:
    if _has_live_reminder_rule(agent, "leader_team_mode"):
        return

    reminder = load_prompt("reminders/leader_team_mode.md")
    text = _wrap_runtime_coordination_reminder(reminder)
    if not text:
        return

    agent.add_hidden_system_reminder(
        text,
        metadata={
            "origin": "runtime_coordination",
            "coordination_kind": "team_leader_mode",
            "coordination_role": "leader",
            "reminder_rule_ids": ["leader_team_mode"],
        },
    )


def _format_transport_events_as_team_inbox_turn(events: list[object]) -> str:
    lines = ["<team-inbox-turn>", "source: team_inbox", "messages:"]
    for event in events:
        timestamp = str(getattr(event, "timestamp", "") or "").strip()
        from_agent = str(getattr(event, "from_agent", "") or "").strip() or "unknown"
        message_type = str(getattr(event, "message_type", "") or "").strip() or "message"
        content = str(getattr(event, "content", "") or "").strip()
        lines.append(
            f"- [{timestamp}] from={from_agent} type={message_type}\n"
            f"  content={content}"
        )
    lines.append("</team-inbox-turn>")
    return "\n".join(lines)


def _has_live_reminder_rule(agent: "AgentRuntime", rule_id: str) -> bool:
    normalized_rule_id = str(rule_id or "").strip()
    if not normalized_rule_id:
        return False

    for item in reversed(agent._context.conversation.items):
        if item.destroyed:
            continue
        raw_rule_ids = (item.metadata or {}).get("reminder_rule_ids", [])
        if not isinstance(raw_rule_ids, list):
            continue
        if normalized_rule_id in {str(raw_id).strip() for raw_id in raw_rule_ids}:
            return True
    return False


def _wrap_runtime_coordination_reminder(content: str) -> str:
    text = str(content or "").strip()
    if not text:
        return ""
    return f"<system-reminder>\n{text}\n</system-reminder>"


def _build_task_list_path(agent: "AgentRuntime", *, team_name: str) -> str:
    from comate_agent_sdk.system_tools.task.store import resolve_task_store_dir

    list_id = str(getattr(agent, "_task_namespace", "") or "").strip() or team_name
    return str((resolve_task_store_dir() / f"{list_id}.json").resolve())


def _resolve_team_coordination_role(
    agent: "AgentRuntime",
    *,
    members: list[dict] | None,
) -> str:
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    if members is not None and agent_name:
        for member in members:
            if str(member.get("name", "") or "").strip() != agent_name:
                continue
            if str(member.get("agent_type", "") or "").strip() == "leader":
                return "leader"
            return "member"
    return "member" if bool(getattr(agent, "_is_subagent", False)) else "leader"


def _build_team_coordination_reminder(agent: "AgentRuntime") -> tuple[str | None, str | None]:
    if not getattr(agent, "is_team_member", False):
        return None, None

    team_name = getattr(agent, "_team_name", "").strip()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=getattr(agent, "name", None),
        is_subagent=bool(getattr(agent, "_is_subagent", False)),
    )
    if not team_name or not agent_name:
        return None, None

    from comate_agent_sdk.system_tools.team.config import TeamConfig
    from comate_agent_sdk.system_tools.team.inbox import Inbox

    team_cfg = TeamConfig(team_name=team_name)
    inbox = Inbox(team_name=team_name, agent_name=agent_name)
    members: list[dict] | None = None
    member_lines = "- (team roster unavailable)"
    leader_name = ""
    roster_unavailable = False

    try:
        members = team_cfg.list_members()
        teammates = [
            member
            for member in members
            if str(member.get("name", "") or "").strip() != agent_name
        ]
        if teammates:
            member_lines = "\n".join(
                f"- {str(member.get('name', '') or '').strip()} "
                f"({str(member.get('agent_type', 'unknown') or 'unknown').strip() or 'unknown'})"
                for member in teammates
                if str(member.get("name", "") or "").strip()
            ) or "- (no teammates registered yet)"
        else:
            member_lines = "- (no teammates registered yet)"

        for member in members:
            candidate_name = str(member.get("name", "") or "").strip()
            candidate_type = str(member.get("agent_type", "") or "").strip()
            if candidate_name and candidate_type == "leader":
                leader_name = candidate_name
                break
    except Exception as exc:
        roster_unavailable = True
        logger.debug(f"[Team coordination] 读取 TeamConfig 失败，使用降级上下文: {exc}")

    role = _resolve_team_coordination_role(agent, members=members)
    task_list_path = _build_task_list_path(agent, team_name=team_name)
    config_path = str(team_cfg.path)
    _inbox_path = str(inbox.path)
    role_rule_id = f"team_coordination_{role}"

    if role == "leader":
        prompt_id = "agent/team_coordination_leader.md"
        if roster_unavailable:
            team_roster_section = (
                "**Team Roster:**\n"
                "- (team roster unavailable)"
            )
        else:
            team_roster_section = f"**Teammates:**\n{member_lines}"
        reminder = render_prompt(
            load_prompt(prompt_id),
            variables={
                "TEAM_NAME": team_name,
                "AGENT_NAME": agent_name,
                "TEAM_ROSTER_SECTION": team_roster_section,
                "TEAM_RESOURCES": "\n".join(
                    [
                        f"- Task list: {task_list_path}",
                        f"- Team config: {config_path}",
                    ]
                ),
            },
            source=prompt_id,
        )
        return role_rule_id, reminder

    prompt_id = "agent/team_coordination_member.md"
    effective_leader_name = leader_name
    if roster_unavailable:
        effective_leader_name = "(team roster unavailable)"
    elif not effective_leader_name or effective_leader_name == agent_name:
        effective_leader_name = "(no leader registered yet)"

    reminder = render_prompt(
        load_prompt(prompt_id),
        variables={
            "TEAM_NAME": team_name,
            "AGENT_NAME": agent_name,
            "TEAM_CONFIG_PATH": config_path,
            "TASK_LIST_PATH": task_list_path,
            "LEADER_NAME": effective_leader_name,
        },
        source=prompt_id,
    )
    return role_rule_id, reminder
