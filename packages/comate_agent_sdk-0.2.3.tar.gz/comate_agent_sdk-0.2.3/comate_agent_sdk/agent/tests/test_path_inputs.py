from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pytest

from comate_agent_sdk.agent import Agent, AgentConfig, ChatSession
from comate_agent_sdk.agent.session_store import SessionStoreError


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


def _make_agent(*, cwd: Path | str | None = None):
    kwargs = {
        "tools": (),
        "agents": (),
        "offload_enabled": False,
        "setting_sources": None,
    }
    if cwd is not None:
        kwargs["cwd"] = cwd
    return Agent(llm=_FakeChatModel(), config=AgentConfig(**kwargs))  # type: ignore[arg-type]


def test_agent_config_normalizes_str_cwd(tmp_path: Path) -> None:
    config = AgentConfig(
        tools=(),
        agents=(),
        offload_enabled=False,
        setting_sources=None,
        cwd=str(tmp_path),
    )

    assert config.cwd == tmp_path.resolve()


def test_create_runtime_accepts_str_cwd(tmp_path: Path) -> None:
    agent = _make_agent()

    runtime = agent.create_runtime(session_id="runtime-path", cwd=str(tmp_path))

    assert runtime.options.cwd == tmp_path.resolve()


def test_chat_session_and_resume_accept_str_cwd(tmp_path: Path) -> None:
    agent = _make_agent()
    session_id = f"session-path-{uuid4().hex}"

    session = ChatSession(agent, session_id=session_id, cwd=str(tmp_path))
    session._ensure_header_persisted()

    resumed = ChatSession.resume(agent, session_id=session_id, cwd=str(tmp_path))

    assert session._cwd == tmp_path.resolve()
    assert resumed._cwd == tmp_path.resolve()
    assert resumed._agent.options.cwd == tmp_path.resolve()


def test_runtime_options_view_writes_mutable_runtime_state(tmp_path: Path) -> None:
    agent = _make_agent()

    runtime = agent.create_runtime(session_id="runtime-options", cwd=str(tmp_path))

    runtime.options.task_namespace = "shared-work"
    runtime.options.team_name = "review-team"

    assert runtime._task_namespace == "shared-work"
    assert runtime._runtime_state.task_namespace == "shared-work"
    assert runtime._team_name == "review-team"
    assert runtime._runtime_state.team_name == "review-team"


def test_runtime_options_view_rejects_config_field_write() -> None:
    agent = _make_agent()

    runtime = agent.create_runtime(session_id="runtime-readonly")

    with pytest.raises(AttributeError, match="read-only"):
        runtime.options.max_iterations = 10


def test_agent_config_rejects_invalid_cwd_type() -> None:
    with pytest.raises(SessionStoreError, match="invalid cwd type"):
        AgentConfig(  # type: ignore[arg-type]
            tools=(),
            agents=(),
            offload_enabled=False,
            setting_sources=None,
            cwd=123,
        )
