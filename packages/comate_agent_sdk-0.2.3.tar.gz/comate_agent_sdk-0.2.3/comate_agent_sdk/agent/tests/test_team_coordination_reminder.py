import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import HiddenUserMessageEvent, StopEvent, TextEvent
from comate_agent_sdk.agent.runner_engine.query_stream import (
    _inject_team_coordination_context,
    _send_team_idle_notification,
)
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.inbox import Inbox
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope


class _CaptureChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self._completions = completions
        self._index = 0
        self.model = "fake:model"
        self.last_messages = None

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.last_messages = list(messages)
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        result = self._completions[self._index]
        self._index += 1
        return result


class TestTeamCoordinationReminder(unittest.IsolatedAsyncioTestCase):
    def _build_runtime(
        self,
        *,
        root: str,
        name: str,
        team_name: str = "",
        task_namespace: str = "",
        is_subagent: bool = False,
        llm: _CaptureChatModel | None = None,
    ):
        model = llm or _CaptureChatModel([ChatInvokeCompletion(content="done")])
        template = Agent(
            llm=model,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(root),
            ),
        )
        runtime = template.create_runtime(
            name=name,
            team_name=team_name,
            task_namespace=task_namespace,
            is_subagent=is_subagent,
        )
        return runtime, model

    def _system_reminders(self, runtime) -> list:
        return [
            item
            for item in runtime._context.conversation.items
            if item.item_type == ItemType.SYSTEM_REMINDER
        ]

    def _system_reminders_by_rule(self, runtime) -> dict[str, list]:
        reminders_by_rule: dict[str, list] = {}
        for item in self._system_reminders(runtime):
            raw_rule_ids = item.metadata.get("reminder_rule_ids", [])
            if not isinstance(raw_rule_ids, list):
                continue
            for rule_id in raw_rule_ids:
                normalized_rule_id = str(rule_id or "").strip()
                if not normalized_rule_id:
                    continue
                reminders_by_rule.setdefault(normalized_rule_id, []).append(item)
        return reminders_by_rule

    def test_non_team_mode_does_not_inject(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            runtime, _ = self._build_runtime(root=td, name="solo")

            _inject_team_coordination_context(runtime)

        self.assertEqual(self._system_reminders(runtime), [])

    def test_leader_runtime_injects_leader_coordination(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")
                team_cfg.register_member(name="worker-1", agent_type="researcher")
                runtime, _ = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                )

                _inject_team_coordination_context(runtime)

        reminders_by_rule = self._system_reminders_by_rule(runtime)
        self.assertEqual(len(self._system_reminders(runtime)), 2)

        coordination_reminders = reminders_by_rule.get("team_coordination_leader", [])
        self.assertEqual(len(coordination_reminders), 1)
        coordination_reminder = coordination_reminders[0]
        self.assertEqual(coordination_reminder.metadata.get("origin"), "runtime_coordination")
        self.assertEqual(coordination_reminder.metadata.get("coordination_kind"), "team_coordination")
        self.assertEqual(coordination_reminder.metadata.get("coordination_role"), "leader")
        self.assertEqual(
            coordination_reminder.metadata.get("reminder_rule_ids"),
            ["team_coordination_leader"],
        )
        self.assertTrue(coordination_reminder.content_text.startswith("<system-reminder>\n"))
        self.assertTrue(coordination_reminder.content_text.endswith("\n</system-reminder>"))
        self.assertIn("as the leader", coordination_reminder.content_text)
        self.assertIn("captain", coordination_reminder.content_text)
        self.assertIn("worker-1 (researcher)", coordination_reminder.content_text)
        self.assertIn(str((Path(td) / "review-team.json").resolve()), coordination_reminder.content_text)
        self.assertIn(
            str((Path(td) / "review-team" / "config.json").resolve()),
            coordination_reminder.content_text,
        )
        self.assertIn(
            'YieldTurn(status="waiting_for_teammate")',
            coordination_reminder.content_text,
        )

        leader_mode_reminders = reminders_by_rule.get("leader_team_mode", [])
        self.assertEqual(len(leader_mode_reminders), 1)
        leader_mode_reminder = leader_mode_reminders[0]
        self.assertEqual(leader_mode_reminder.metadata.get("origin"), "runtime_coordination")
        self.assertEqual(leader_mode_reminder.metadata.get("coordination_kind"), "team_leader_mode")
        self.assertEqual(leader_mode_reminder.metadata.get("coordination_role"), "leader")
        self.assertEqual(leader_mode_reminder.metadata.get("reminder_rule_ids"), ["leader_team_mode"])
        self.assertIn("Team Workflow", leader_mode_reminder.content_text)
        self.assertIn("Turn Control & Message Delivery", leader_mode_reminder.content_text)
        self.assertIn(
            'YieldTurn(status="waiting_for_teammate")',
            leader_mode_reminder.content_text,
        )

    def test_member_runtime_injects_member_coordination(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")
                team_cfg.register_member(name="worker-1", agent_type="researcher")
                runtime, _ = self._build_runtime(
                    root=td,
                    name="worker-1",
                    team_name="review-team",
                    task_namespace="review-team",
                    is_subagent=True,
                )

                _inject_team_coordination_context(runtime)

        reminders = self._system_reminders(runtime)
        self.assertEqual(len(reminders), 1)
        reminder = reminders[0]
        self.assertEqual(reminder.metadata.get("coordination_role"), "member")
        self.assertEqual(reminder.metadata.get("reminder_rule_ids"), ["team_coordination_member"])
        self.assertTrue(reminder.content_text.startswith("<system-reminder>\n"))
        self.assertIn('You are a teammate in team "review-team".', reminder.content_text)
        self.assertIn("- Team Lead: captain", reminder.content_text)
        self.assertIn(str((Path(td) / "review-team.json").resolve()), reminder.content_text)
        self.assertIn(
            "Always refer to teammates by their NAME",
            reminder.content_text,
        )
        self.assertIn('YieldTurn(status="waiting_for_teammate")', reminder.content_text)
        self.assertNotIn("leader_team_mode", self._system_reminders_by_rule(runtime))

    def test_coordination_is_idempotent_and_reinjects_after_purge(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                runtime, _ = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                )

                _inject_team_coordination_context(runtime)
                _inject_team_coordination_context(runtime)
                first_count = len(self._system_reminders(runtime))
                removed = runtime._context.purge_system_reminders()
                _inject_team_coordination_context(runtime)

        self.assertEqual(first_count, 2)
        self.assertEqual(removed, 2)
        self.assertEqual(len(self._system_reminders(runtime)), 2)
        reminders_by_rule = self._system_reminders_by_rule(runtime)
        self.assertEqual(len(reminders_by_rule.get("team_coordination_leader", [])), 1)
        self.assertEqual(len(reminders_by_rule.get("leader_team_mode", [])), 1)

    def test_team_config_failure_degrades_to_runtime_context(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                runtime, _ = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                )

                with patch(
                    "comate_agent_sdk.system_tools.team.config.TeamConfig.list_members",
                    side_effect=TimeoutError("lock timeout"),
                ):
                    _inject_team_coordination_context(runtime)

        reminders_by_rule = self._system_reminders_by_rule(runtime)
        self.assertEqual(len(self._system_reminders(runtime)), 2)

        coordination_reminders = reminders_by_rule.get("team_coordination_leader", [])
        self.assertEqual(len(coordination_reminders), 1)
        reminder = coordination_reminders[0]
        self.assertEqual(reminder.metadata.get("coordination_role"), "leader")
        self.assertTrue(reminder.content_text.startswith("<system-reminder>\n"))
        self.assertIn("(team roster unavailable)", reminder.content_text)
        self.assertIn(str((Path(td) / "review-team.json").resolve()), reminder.content_text)

        leader_mode_reminders = reminders_by_rule.get("leader_team_mode", [])
        self.assertEqual(len(leader_mode_reminders), 1)
        self.assertIn("Team Workflow", leader_mode_reminders[0].content_text)

    def test_leader_runtime_does_not_send_idle_notification_to_teammates(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")
                team_cfg.register_member(name="worker-1", agent_type="researcher")
                runtime, _ = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                )

                worker_inbox = Inbox(team_name="review-team", agent_name="worker-1")
                worker_inbox.append_message(
                    from_agent="system",
                    content="bootstrap",
                )

                _send_team_idle_notification(runtime)

                payloads = [json.loads(message["text"]) for message in worker_inbox.read_all()]
        self.assertEqual(len(payloads), 1)
        self.assertEqual(payloads[0]["type"], "message")
        self.assertEqual(payloads[0]["content"], "bootstrap")

    async def test_query_stream_injects_coordination_and_inbox_after_precheck(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                llm = _CaptureChatModel(
                    [
                        ChatInvokeCompletion(content="done"),
                        ChatInvokeCompletion(content="inbox handled"),
                    ]
                )
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")
                team_cfg.register_member(name="worker-1", agent_type="researcher")
                runtime, model = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                    llm=llm,
                )
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox.append_message(
                    from_agent="worker-1",
                    content="task finished",
                    message_type="message",
                )

                events: list[object] = []
                with patch(
                    "comate_agent_sdk.agent.runner_engine.query_stream.precheck_and_compact",
                    new=AsyncMock(return_value=(True, None, [])),
                ):
                    async for event in runtime.query_stream("hello"):
                        events.append(event)

        self.assertIsNotNone(model.last_messages)
        assert model.last_messages is not None
        self.assertTrue(
            any(
                isinstance(message, UserMessage)
                and bool(getattr(message, "is_meta", False))
                and "<system-reminder>" in message.text
                and "# Team Coordination" in message.text
                for message in model.last_messages
            )
        )
        self.assertTrue(
            any(
                isinstance(message, UserMessage)
                and bool(getattr(message, "is_meta", False))
                and "<system-reminder>" in message.text
                and "Team Workflow" in message.text
                for message in model.last_messages
            )
        )
        self.assertTrue(
            any(
                isinstance(message, UserMessage)
                and bool(getattr(message, "is_meta", False))
                and "<team-inbox-turn>" in message.text
                and "task finished" in message.text
                for message in model.last_messages
            )
        )

        hidden_indices = [
            index
            for index, event in enumerate(events)
            if isinstance(event, HiddenUserMessageEvent)
        ]
        text_indices = [
            index
            for index, event in enumerate(events)
            if isinstance(event, TextEvent)
        ]
        self.assertGreaterEqual(len(hidden_indices), 1)
        self.assertEqual(len(text_indices), 2)
        self.assertLess(min(hidden_indices), text_indices[0])

    async def test_query_stream_delivers_idle_notification_as_team_inbox_turn(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                llm = _CaptureChatModel(
                    [
                        ChatInvokeCompletion(content="done"),
                        ChatInvokeCompletion(content="handled idle"),
                    ]
                )
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")
                runtime, model = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                    llm=llm,
                )
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox.append_message(
                    from_agent="worker-1",
                    content=(
                        "Agent 'worker-1' is now idle.\n"
                        "idle_reason: yielded\n"
                        "last_action: yielded:waiting_for_task"
                    ),
                    message_type="idle_notification",
                )

                events: list[object] = []
                async for event in runtime.query_stream("hello"):
                    events.append(event)

        self.assertIsNotNone(model.last_messages)
        assert model.last_messages is not None
        team_inbox_messages = [
            message
            for message in model.last_messages
            if isinstance(message, UserMessage)
            and bool(getattr(message, "is_meta", False))
            and "<team-inbox-turn>" in message.text
        ]
        self.assertEqual(len(team_inbox_messages), 1)
        self.assertIn("type=idle_notification", team_inbox_messages[0].text)
        self.assertIn("idle_reason: yielded", team_inbox_messages[0].text)
        self.assertEqual(
            [event.content for event in events if isinstance(event, TextEvent)],
            ["done", "handled idle"],
        )
        self.assertEqual(
            [event.reason for event in events if isinstance(event, StopEvent)],
            ["completed"],
        )

    async def test_runtime_buffers_polled_messages_without_touching_conversation(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                runtime, _ = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )
                Inbox(team_name="review-team", agent_name="captain").append_message(
                    from_agent="worker-1",
                    content="hello",
                )

                await runtime._poll_team_inbox_once()

        self.assertEqual(len(runtime._pending_inbox_events), 1)
        self.assertEqual(self._system_reminders(runtime), [])

    async def test_query_stream_runs_auto_inbox_turn_before_final_stop(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                llm = _CaptureChatModel(
                    [
                        ChatInvokeCompletion(content="user turn done"),
                        ChatInvokeCompletion(content="auto inbox handled"),
                    ]
                )
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")
                runtime, _ = self._build_runtime(
                    root=td,
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                    llm=llm,
                )
                runtime._pending_inbox_events.append(
                    TeamInboxEnvelope(
                        key="evt-1",
                        from_agent="worker-1",
                        message_type="message",
                        content="please review",
                        timestamp="2026-03-11T00:00:00+00:00",
                        raw_envelope={},
                    )
                )
                runtime._pending_inbox_keys.add("evt-1")

                texts: list[str] = []
                stops: list[str] = []
                async for event in runtime.query_stream("hello"):
                    if isinstance(event, TextEvent):
                        texts.append(event.content)
                    if isinstance(event, StopEvent):
                        stops.append(event.reason)

        self.assertEqual(texts, ["user turn done", "auto inbox handled"])
        self.assertEqual(stops, ["completed"])


class TestIdleNotificationScenarios(unittest.TestCase):
    """测试 send_idle_notification 在不同场景下的静默/发送行为。"""

    def _build_subagent_runtime(self, td: str, name: str = "worker-1") -> object:
        from comate_agent_sdk.agent import Agent, AgentConfig

        model = _CaptureChatModel([ChatInvokeCompletion(content="done")])
        template = Agent(
            llm=model,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(td),
            ),
        )
        runtime = template.create_runtime(
            name=name,
            team_name="test-team",
            task_namespace="test-team",
            is_subagent=True,
        )
        runtime._suppress_team_idle_notification = False
        return runtime

    def _setup_team(self, td: str) -> None:
        team_cfg = TeamConfig(team_name="test-team")
        team_cfg.register_member(name="team-lead", agent_type="leader")
        team_cfg.register_member(name="worker-1", agent_type="researcher")
        # 确保 leader inbox 存在
        leader_inbox = Inbox(team_name="test-team", agent_name="team-lead")
        leader_inbox.append_message(from_agent="system", content="bootstrap")

    def _leader_inbox_payloads(self, td: str) -> list[dict]:
        inbox = Inbox(team_name="test-team", agent_name="team-lead")
        return [json.loads(msg["text"]) for msg in inbox.read_all()]

    def test_waiting_for_teammate_does_not_notify(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(
                    runtime, stop_reason="yielded", yield_status="waiting_for_teammate"
                )
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 0)

    def test_waiting_for_peer_does_not_notify_backward_compat(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(
                    runtime, stop_reason="yielded", yield_status="waiting_for_peer"
                )
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 0)

    def test_send_to_teammate_does_not_notify(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(
                    runtime, stop_reason="completed", yield_status="", last_send_to="worker-2"
                )
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 0)

    def test_waiting_for_task_sends_notification(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(
                    runtime, stop_reason="yielded", yield_status="waiting_for_task"
                )
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 1)

    def test_waiting_for_leader_sends_notification(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(
                    runtime, stop_reason="yielded", yield_status="waiting_for_leader"
                )
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 1)

    def test_send_to_team_lead_sends_notification(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(
                    runtime, stop_reason="completed", yield_status="", last_send_to="team-lead"
                )
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 1)

    def test_default_completed_sends_notification(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                self._setup_team(td)
                runtime = self._build_subagent_runtime(td)
                _send_team_idle_notification(runtime, stop_reason="completed")
                payloads = self._leader_inbox_payloads(td)
        idle_payloads = [p for p in payloads if p.get("type") == "idle_notification"]
        self.assertEqual(len(idle_payloads), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
