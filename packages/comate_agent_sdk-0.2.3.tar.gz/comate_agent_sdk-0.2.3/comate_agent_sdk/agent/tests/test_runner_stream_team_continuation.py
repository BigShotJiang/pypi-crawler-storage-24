import tempfile
import unittest
from pathlib import Path
import json

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import StopEvent, TextEvent
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope
from comate_agent_sdk.system_tools.tools import AskUserQuestion


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.calls = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        self.calls += 1
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


def _make_inbox_event(*, key: str, message_type: str, content: str) -> TeamInboxEnvelope:
    return TeamInboxEnvelope(
        key=key,
        from_agent="worker-1",
        message_type=message_type,
        content=content,
        timestamp="2026-03-11T00:00:00+00:00",
        raw_envelope={},
    )


class TestRunnerStreamTeamContinuation(unittest.IsolatedAsyncioTestCase):
    async def test_team_continuation_appends_follow_up_turn_without_intermediate_stop(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="first turn"),
                ChatInvokeCompletion(content="follow-up turn"),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            runtime = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            ).create_runtime(
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            runtime._suppress_team_idle_notification = True
            completed_turns: list[str] = []
            runtime._chat_session_turn_complete_callback = lambda: completed_turns.append("done")
            runtime._pending_inbox_events.append(
                _make_inbox_event(
                    key="msg-1",
                    message_type="message",
                    content="please continue",
                )
            )
            runtime._pending_inbox_keys.add("msg-1")

            events: list[object] = []
            async for event in runtime.query_stream("hello"):
                events.append(event)

        texts = [event.content for event in events if isinstance(event, TextEvent)]
        stop_reasons = [event.reason for event in events if isinstance(event, StopEvent)]

        self.assertEqual(texts, ["first turn", "follow-up turn"])
        self.assertEqual(stop_reasons, ["completed"])
        self.assertEqual(completed_turns, ["done"])
        self.assertEqual(llm.calls, 2)

    async def test_shutdown_request_preempts_buffered_continuation_turn(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="first turn"),
                ChatInvokeCompletion(content="should not run"),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            runtime = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            ).create_runtime(
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            runtime._suppress_team_idle_notification = True

            def _queue_shutdown_request() -> None:
                runtime._pending_inbox_events.append(
                    _make_inbox_event(
                        key="shutdown-1",
                        message_type="shutdown_request",
                        content="stop now",
                    )
                )
                runtime._pending_inbox_keys.add("shutdown-1")

            runtime._chat_session_turn_complete_callback = _queue_shutdown_request
            runtime._pending_inbox_events.append(
                _make_inbox_event(
                    key="msg-1",
                    message_type="message",
                    content="please continue",
                )
            )
            runtime._pending_inbox_keys.add("msg-1")

            events: list[object] = []
            async for event in runtime.query_stream("hello"):
                events.append(event)

        texts = [event.content for event in events if isinstance(event, TextEvent)]
        stop_reasons = [event.reason for event in events if isinstance(event, StopEvent)]

        self.assertEqual(texts, ["first turn"])
        self.assertEqual(stop_reasons, ["shutdown_request"])
        self.assertEqual(llm.calls, 1)

    async def test_team_continuation_acknowledges_inbox_when_follow_up_waits_for_input(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="first turn"),
                ChatInvokeCompletion(
                    tool_calls=[
                        ToolCall(
                            id="tc_ask_1",
                            function=Function(
                                name="AskUserQuestion",
                                arguments=json.dumps(
                                    {
                                        "questions": [
                                            {
                                                "question": "Need input?",
                                                "header": "Input",
                                                "options": [
                                                    {"label": "A", "description": "a"},
                                                    {"label": "B", "description": "b"},
                                                ],
                                                "multiSelect": False,
                                            }
                                        ]
                                    },
                                    ensure_ascii=False,
                                ),
                            ),
                        )
                    ]
                ),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            runtime = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(AskUserQuestion,),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            ).create_runtime(
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            runtime._suppress_team_idle_notification = True
            acked_keys: list[str] = []
            runtime.ack_pending_inbox_events = lambda keys: acked_keys.extend(keys)  # type: ignore[method-assign]
            runtime._pending_inbox_events.append(
                _make_inbox_event(
                    key="msg-1",
                    message_type="message",
                    content="please continue",
                )
            )
            runtime._pending_inbox_keys.add("msg-1")

            events: list[object] = []
            async for event in runtime.query_stream("hello"):
                events.append(event)

        stop_reasons = [event.reason for event in events if isinstance(event, StopEvent)]
        self.assertEqual(stop_reasons, ["waiting_for_input"])
        self.assertEqual(acked_keys, ["msg-1"])
        self.assertEqual(llm.calls, 2)
