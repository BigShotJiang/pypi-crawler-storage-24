from __future__ import annotations

import json
import tempfile
import unittest
from collections.abc import AsyncIterator

import comate_agent_sdk as sdk

from comate_agent_sdk.agent.events import (
    ExternalTurnPendingEvent,
    SessionInitEvent,
    StopEvent,
    TextEvent as InternalTextEvent,
)
from comate_agent_sdk.facade._adapters import _filter_events
from comate_agent_sdk.facade._query import query
from comate_agent_sdk.facade.client import AgentClient
from comate_agent_sdk.facade.errors import (
    AgentConfigError,
    AgentConnectionError,
    AgentExecutionError,
)
from comate_agent_sdk.facade.events import DoneEvent, ToolUseEvent, UserQuestionEvent
from comate_agent_sdk.facade.options import AgentOptions
from comate_agent_sdk.llm.exceptions import ModelProviderError
from comate_agent_sdk.llm.messages import ContentPartImageParam, Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.tools import AskUserQuestion
from comate_agent_sdk.tools import tool


class _CountingChatModel:
    def __init__(self) -> None:
        self.model = "fake:counting"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        user_turns = [
            message.text
            for message in messages
            if getattr(message, "role", None) == "user" and not getattr(message, "is_meta", False)
        ]
        return ChatInvokeCompletion(
            content=f"user_turns={len(user_turns)} last={user_turns[-1]}"
        )


class _SequenceChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self._completions = completions
        self._index = 0
        self.model = "fake:sequence"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        completion = self._completions[self._index]
        self._index += 1
        return completion


class _FailingChatModel:
    def __init__(self, exc: Exception) -> None:
        self._exc = exc
        self.model = "fake:failing"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        raise self._exc


async def _collect(stream: AsyncIterator[object]) -> list[object]:
    return [event async for event in stream]


class TestFacadeApi(unittest.IsolatedAsyncioTestCase):
    async def test_query_emits_text_and_done(self) -> None:
        events = await _collect(query("2+2 是多少？", llm=_CountingChatModel()))

        self.assertIsInstance(events[0], InternalTextEvent)
        self.assertEqual(events[0].content, "user_turns=1 last=2+2 是多少？")
        self.assertEqual(events[-1], DoneEvent(reason="completed"))

    async def test_agent_client_chat_is_stateless(self) -> None:
        client = AgentClient(llm=_CountingChatModel())

        first = await _collect(client.chat("first"))
        second = await _collect(client.chat("second"))

        self.assertEqual(first[0].content, "user_turns=1 last=first")
        self.assertEqual(second[0].content, "user_turns=1 last=second")

    async def test_agent_client_query_reuses_session_id_context(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            client = AgentClient(llm=_CountingChatModel(), options=AgentOptions(cwd=tmp_dir))

            first = await _collect(client.query("first", session_id="shared"))
            second = await _collect(client.query("second", session_id="shared"))

        self.assertEqual(first[0].content, "user_turns=1 last=first")
        self.assertEqual(second[0].content, "user_turns=2 last=second")

    async def test_session_preserves_context_across_turns(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            client = AgentClient(llm=_CountingChatModel(), options=AgentOptions(cwd=tmp_dir))

            async with client.session() as session:
                first = await _collect(session.chat("first"))
                second = await _collect(session.chat("second"))

        self.assertEqual(first[0].content, "user_turns=1 last=first")
        self.assertEqual(second[0].content, "user_turns=2 last=second")

    async def test_session_resume_restores_history(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            client = AgentClient(llm=_CountingChatModel(), options=AgentOptions(cwd=tmp_dir))

            async with client.session() as session:
                session_id = session.session_id
                first = await _collect(session.chat("first"))

            async with client.session(session_id=session_id) as resumed:
                second = await _collect(resumed.chat("second"))

        self.assertEqual(first[0].content, "user_turns=1 last=first")
        self.assertEqual(second[0].content, "user_turns=2 last=second")

    async def test_tool_call_maps_to_tool_use_event(self) -> None:
        @tool("Echo the text")
        async def echo(text: str) -> str:
            return f"echo:{text}"

        tool_call = ToolCall(
            id="tc_echo_1",
            function=Function(
                name="echo",
                arguments=json.dumps({"text": "hello"}),
            ),
        )
        model = _SequenceChatModel(
            [
                ChatInvokeCompletion(tool_calls=[tool_call]),
                ChatInvokeCompletion(content="done"),
            ]
        )

        events = await _collect(query("call the tool", llm=model, tools=[echo]))

        tool_use_events = [event for event in events if isinstance(event, ToolUseEvent)]
        self.assertEqual(len(tool_use_events), 1)
        self.assertEqual(tool_use_events[0].tool, "echo")
        self.assertEqual(tool_use_events[0].args, {"text": "hello"})
        self.assertEqual(events[-1], DoneEvent(reason="completed"))

    async def test_waiting_for_input_emits_public_done_event_and_can_continue(self) -> None:
        tool_call = ToolCall(
            id="tc_question_1",
            function=Function(
                name="AskUserQuestion",
                arguments=json.dumps(
                    {
                        "questions": [
                            {
                                "question": "Which plan?",
                                "header": "Plan",
                                "options": [
                                    {"label": "A", "description": "Stable"},
                                    {"label": "B", "description": "Smaller"},
                                ],
                            }
                        ]
                    },
                    ensure_ascii=False,
                ),
            ),
        )
        model = _SequenceChatModel(
            [
                ChatInvokeCompletion(tool_calls=[tool_call]),
                ChatInvokeCompletion(content="继续执行"),
            ]
        )
        client = AgentClient(
            llm=model,
            options=AgentOptions(tools=[AskUserQuestion]),
        )

        async with client.session() as session:
            first = await _collect(session.chat("需要你的确认"))
            second = await _collect(session.chat("选择 A"))

        question_events = [event for event in first if isinstance(event, UserQuestionEvent)]
        self.assertEqual(len(question_events), 1)
        self.assertEqual(first[-1], DoneEvent(reason="waiting_for_input"))
        self.assertEqual(second[0].content, "继续执行")
        self.assertEqual(second[-1], DoneEvent(reason="completed"))

    async def test_client_wraps_provider_errors(self) -> None:
        model = _FailingChatModel(ModelProviderError(message="boom", status_code=503))

        with self.assertRaises(AgentConnectionError):
            await _collect(query("hello", llm=model))

    async def test_client_wraps_invalid_construction_inputs(self) -> None:
        with self.assertRaises(AgentConfigError):
            AgentClient(llm=_CountingChatModel(), options=AgentOptions(cwd=123))  # type: ignore[arg-type]

    async def test_query_accepts_streaming_input_messages(self) -> None:
        async def _message_stream() -> AsyncIterator[dict]:
            yield {
                "type": "user",
                "message": {
                    "role": "user",
                    "content": "first",
                },
            }
            yield {
                "type": "user",
                "message": {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "second with image"},
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": "ZmFrZQ==",
                            },
                        },
                    ],
                },
            }

        with tempfile.TemporaryDirectory() as tmp_dir:
            client = AgentClient(llm=_CountingChatModel(), options=AgentOptions(cwd=tmp_dir))
            events = await _collect(client.query(_message_stream(), session_id="streaming"))
            follow_up = await _collect(client.query("third", session_id="streaming"))

        text_events = [event for event in events if isinstance(event, InternalTextEvent)]
        self.assertEqual([event.content for event in text_events], [
            "user_turns=1 last=first",
            "user_turns=2 last=second with image",
        ])
        self.assertEqual(
            [event.reason for event in events if isinstance(event, DoneEvent)],
            ["completed", "completed"],
        )
        self.assertEqual(follow_up[0].content, "user_turns=3 last=third")

    async def test_query_streaming_input_rejects_invalid_envelope(self) -> None:
        async def _message_stream() -> AsyncIterator[dict]:
            yield {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": "not allowed",
                },
            }

        client = AgentClient(llm=_CountingChatModel())
        with self.assertRaises(AgentConfigError):
            await _collect(client.query(_message_stream()))

    async def test_filter_events_drops_internal_events_and_maps_stop(self) -> None:
        async def _events() -> AsyncIterator[object]:
            yield SessionInitEvent(session_id="s1")
            yield ExternalTurnPendingEvent(
                turn_id="t1",
                source="team",
                dedupe_key="d1",
                queue_size=1,
                can_auto_consume=True,
            )
            yield InternalTextEvent(content="hello")
            yield StopEvent(reason="max_iterations")

        filtered = await _collect(_filter_events(_events()))  # type: ignore[arg-type]

        self.assertEqual(filtered, [InternalTextEvent(content="hello"), DoneEvent(reason="completed")])

    async def test_filter_events_rejects_internal_control_stop_reason(self) -> None:
        async def _events() -> AsyncIterator[object]:
            yield StopEvent(reason="yielded")

        with self.assertRaises(AgentExecutionError):
            await _collect(_filter_events(_events()))  # type: ignore[arg-type]

    async def test_root_exports_facade_symbols_only(self) -> None:
        self.assertIs(sdk.AgentClient, AgentClient)
        self.assertTrue(hasattr(sdk, "query"))
        self.assertFalse(hasattr(sdk, "Agent"))
        with self.assertRaises(ImportError):
            exec("from comate_agent_sdk import Agent", {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
