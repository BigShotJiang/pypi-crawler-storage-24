from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from pathlib import Path

from comate_agent_sdk.agent.chat_session import ChatSessionError
from comate_agent_sdk.agent.events import (
    AgentEvent,
    ExternalTurnPendingEvent,
    ExternalTurnScheduledEvent,
    HiddenUserMessageEvent,
    LLMSwitchedEvent,
    MessageCompleteEvent,
    MessageStartEvent,
    ModeChangedEvent,
    PlanApprovalRequiredEvent,
    SessionInitEvent,
    StepCompleteEvent,
    StepStartEvent,
    StopEvent,
    SubagentProgressEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TaskUpdatedEvent,
    TextEvent,
    ThinkingEvent,
    ToolCallEvent,
    ToolResultEvent,
    UsageDeltaEvent,
    UserQuestionEvent,
    CompactionMetaEvent,
    CompactionResultEvent,
)
from comate_agent_sdk.agent.options import AgentConfig
from comate_agent_sdk.agent.session_store import SessionStoreError
from comate_agent_sdk.facade.errors import (
    AgentConfigError,
    AgentConnectionError,
    AgentError,
    AgentExecutionError,
    AgentTimeoutError,
)
from comate_agent_sdk.facade.events import DoneEvent, Event, ToolUseEvent
from comate_agent_sdk.facade.options import AgentOptions
from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.mcp.store import McpConfigError
from comate_agent_sdk.utils.paths import PathInputError

_IGNORED_EVENT_TYPES = (
    SessionInitEvent,
    ExternalTurnPendingEvent,
    ExternalTurnScheduledEvent,
    MessageStartEvent,
    MessageCompleteEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    UsageDeltaEvent,
    SubagentProgressEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    HiddenUserMessageEvent,
    TaskUpdatedEvent,
    CompactionResultEvent,
    CompactionMetaEvent,
    LLMSwitchedEvent,
    ModeChangedEvent,
    PlanApprovalRequiredEvent,
)


def _map_options(options: AgentOptions | None) -> AgentConfig:
    if options is None:
        return AgentConfig()

    return AgentConfig(
        system_prompt=options.system_prompt,
        max_iterations=options.max_iterations,
        tools=tuple(options.tools) if options.tools is not None else None,
        mcp_servers=dict(options.mcp_servers) if options.mcp_servers is not None else None,
        session_id=options.session_id,
        cwd=options.cwd if options.cwd is not None else Path.cwd(),
    )


def _map_construction_exception(exc: Exception) -> AgentError:
    if isinstance(exc, AgentError):
        return exc
    if isinstance(exc, ChatSessionError):
        return AgentExecutionError(str(exc))
    if isinstance(exc, (PathInputError, SessionStoreError, McpConfigError, TypeError, ValueError)):
        return AgentConfigError(str(exc))
    return AgentExecutionError(str(exc))


def _map_runtime_exception(exc: Exception) -> AgentError:
    if isinstance(exc, AgentError):
        return exc
    if isinstance(exc, (asyncio.TimeoutError, TimeoutError)):
        return AgentTimeoutError(str(exc))
    if isinstance(exc, (ModelProviderError, ModelRateLimitError, ConnectionError)):
        return AgentConnectionError(str(exc))
    if isinstance(exc, ChatSessionError):
        return AgentExecutionError(str(exc))
    return AgentExecutionError(str(exc))


def _map_stop_event(event: StopEvent) -> DoneEvent:
    reason = event.reason
    if reason in {"completed", "max_iterations"}:
        return DoneEvent(reason="completed")
    if reason in {"interrupted", "shutdown_request"}:
        return DoneEvent(reason="interrupted")
    if reason == "waiting_for_input":
        return DoneEvent(reason="waiting_for_input")
    if reason in {"yielded", "waiting_for_plan_approval"}:
        raise AgentExecutionError(
            f"Unsupported internal stop reason for facade API: {reason}"
        )
    raise AgentExecutionError(f"Unknown internal stop reason for facade API: {reason}")


async def _filter_events(events: AsyncIterator[AgentEvent]) -> AsyncIterator[Event]:
    async for event in events:
        if isinstance(event, (TextEvent, ThinkingEvent, ToolResultEvent, StepStartEvent, StepCompleteEvent, UserQuestionEvent)):
            yield event
            continue
        if isinstance(event, ToolCallEvent):
            yield ToolUseEvent(
                tool=event.tool,
                args=dict(event.args),
                tool_call_id=event.tool_call_id,
                display_name=event.display_name,
            )
            continue
        if isinstance(event, StopEvent):
            yield _map_stop_event(event)
            continue
        if isinstance(event, _IGNORED_EVENT_TYPES):
            continue
        raise AgentExecutionError(
            f"Unsupported internal event leaked into facade API: {type(event).__name__}"
        )
