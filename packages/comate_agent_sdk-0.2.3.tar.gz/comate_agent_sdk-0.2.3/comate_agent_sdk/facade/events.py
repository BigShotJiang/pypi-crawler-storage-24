from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Literal, TypeAlias

from comate_agent_sdk.agent.events import (
    StepCompleteEvent,
    StepStartEvent,
    TextEvent,
    ThinkingEvent,
    ToolResultEvent,
    UserQuestionEvent,
)


@dataclass(slots=True)
class ToolUseEvent:
    tool: str
    args: dict[str, object]
    tool_call_id: str
    display_name: str = ""

    def __str__(self) -> str:
        if self.display_name:
            return f"🔧 {self.display_name}"
        args_str = json.dumps(self.args, default=str)
        if len(args_str) > 80:
            args_str = f"{args_str[:77]}..."
        return f"🔧 {self.tool}({args_str})"


@dataclass(slots=True)
class DoneEvent:
    reason: Literal["completed", "interrupted", "waiting_for_input"]

    def __str__(self) -> str:
        return f"✅ Done: {self.reason}"


Event: TypeAlias = (
    TextEvent
    | ThinkingEvent
    | ToolUseEvent
    | ToolResultEvent
    | StepStartEvent
    | StepCompleteEvent
    | UserQuestionEvent
    | DoneEvent
)

__all__ = [
    "Event",
    "TextEvent",
    "ThinkingEvent",
    "ToolUseEvent",
    "ToolResultEvent",
    "StepStartEvent",
    "StepCompleteEvent",
    "UserQuestionEvent",
    "DoneEvent",
]
