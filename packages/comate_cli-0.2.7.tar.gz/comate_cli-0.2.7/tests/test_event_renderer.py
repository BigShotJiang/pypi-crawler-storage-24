from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent.events import (
    CompactionResultEvent,
    PlanApprovalRequiredEvent,
    StepCompleteEvent,
    StopEvent,
    SubagentProgressEvent,
    TeamMessageEvent,
    TextEvent,
    TaskUpdatedEvent,
    ToolCallEvent,
    ToolResultEvent,
)

from comate_cli.terminal_agent.event_renderer import EventRenderer


def _task_payload(size: int) -> list[dict[str, str]]:
    tasks: list[dict[str, str]] = []
    for idx in range(size):
        tasks.append(
            {
                "id": str(idx + 1),
                "subject": f"task-{idx}",
                "status": "pending",
                "open_blocked_by": [],
            }
        )
    return tasks


class TestEventRenderer(unittest.TestCase):
    def test_team_message_event_deduplicates_identical_event(self) -> None:
        renderer = EventRenderer()
        event = TeamMessageEvent(
            agent_name="girlfriend",
            from_agent="boyfriend",
            to_agent="girlfriend",
            message_type="message",
            content_preview="where are you",
            timestamp="2026-03-19T16:00:00+00:00",
        )

        renderer.handle_event(event)
        renderer.handle_event(event)

        system_entries = [e for e in renderer.history_entries() if e.entry_type == "system"]
        self.assertEqual(len(system_entries), 1)
        self.assertIn("[team] boyfriend → girlfriend: (message)", str(system_entries[0].text))

    def test_team_message_event_keeps_distinct_timestamps(self) -> None:
        renderer = EventRenderer()
        renderer.handle_event(
            TeamMessageEvent(
                agent_name="girlfriend",
                from_agent="boyfriend",
                to_agent="girlfriend",
                message_type="message",
                content_preview="where are you",
                timestamp="2026-03-19T16:00:00+00:00",
            )
        )
        renderer.handle_event(
            TeamMessageEvent(
                agent_name="girlfriend",
                from_agent="boyfriend",
                to_agent="girlfriend",
                message_type="message",
                content_preview="where are you",
                timestamp="2026-03-19T16:00:01+00:00",
            )
        )

        system_entries = [e for e in renderer.history_entries() if e.entry_type == "system"]
        self.assertEqual(len(system_entries), 2)

    def test_direct_append_and_event_handle_share_team_dedupe(self) -> None:
        renderer = EventRenderer()
        renderer.append_team_message_event(
            agent_name="girlfriend",
            from_agent="boyfriend",
            to_agent="girlfriend",
            message_type="message",
            content_preview="where are you",
            timestamp="2026-03-19T16:00:00+00:00",
        )
        renderer.handle_event(
            TeamMessageEvent(
                agent_name="girlfriend",
                from_agent="boyfriend",
                to_agent="girlfriend",
                message_type="message",
                content_preview="where are you",
                timestamp="2026-03-19T16:00:00+00:00",
            )
        )

        system_entries = [e for e in renderer.history_entries() if e.entry_type == "system"]
        self.assertEqual(len(system_entries), 1)

    def test_compaction_result_event_renders_skip_message(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            CompactionResultEvent(
                current_tokens=131147,
                threshold=174080,
                trigger="precheck",
                attempted=False,
                compacted=False,
                reason="cooldown:summary_failed_or_empty:remaining=5.0s",
                tokens_before=131147,
                tokens_after=131147,
            )
        )

        system_entries = [e for e in renderer.history_entries() if e.entry_type == "system"]
        self.assertTrue(system_entries)
        self.assertIn("Context compaction skipped", system_entries[-1].text)
        self.assertIn("cooldown:", system_entries[-1].text)

    def test_history_distinguishes_user_tool_assistant(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.seed_user_message("hello")
        renderer.handle_event(
            ToolCallEvent(
                tool="Read",
                args={"path": "/tmp/a.py"},
                tool_call_id="tc_1",
            )
        )
        renderer.handle_event(
            ToolResultEvent(
                tool="Read",
                result="ok",
                tool_call_id="tc_1",
                is_error=False,
            )
        )
        renderer.handle_event(TextEvent(content="assistant answer"))
        renderer.finalize_turn()

        entry_types = [entry.entry_type for entry in renderer.history_entries()]
        self.assertIn("user", entry_types)
        self.assertIn("tool_result", entry_types)
        self.assertIn("assistant", entry_types)

    def test_tool_panel_tracks_running_task_and_subagent(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Agent",
                args={"subagent_type": "Planner", "description": "拆解任务"},
                tool_call_id="tc_task_1",
            )
        )
        entries = renderer.tool_panel_entries(max_lines=4)
        self.assertTrue(entries)
        self.assertTrue(any("拆解任务" in line for _, line in entries))
        self.assertTrue(any("|_ init" in line for _, line in entries))

        renderer.handle_event(
            SubagentProgressEvent(
                tool_call_id="tc_task_1",
                subagent_name="Planner",
                description="",
                status="running",
                elapsed_ms=250,
                tokens=180,
            )
        )
        entries = renderer.tool_panel_entries(max_lines=4)
        self.assertTrue(any("tok" in line for _, line in entries))
        self.assertFalse(any("|_ init" in line for _, line in entries))

        renderer.handle_event(
            ToolResultEvent(
                tool="Agent",
                result="done",
                tool_call_id="tc_task_1",
                is_error=False,
            )
        )
        self.assertFalse(renderer.has_running_tools())

    def test_has_running_subagents_uses_task_tool_state(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Read",
                args={"path": "/tmp/a.py"},
                tool_call_id="tc_read_1",
            )
        )
        self.assertFalse(renderer.has_running_subagents())

        renderer.handle_event(
            ToolCallEvent(
                tool="Agent",
                args={"subagent_type": "Planner", "description": "拆解"},
                tool_call_id="tc_task_3",
            )
        )
        self.assertTrue(renderer.has_running_subagents())

        renderer.handle_event(
            ToolResultEvent(
                tool="Agent",
                result="done",
                tool_call_id="tc_task_3",
                is_error=False,
            )
        )
        self.assertFalse(renderer.has_running_subagents())

    def test_task_lines_are_folded_to_six_lines(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            TaskUpdatedEvent(list_id="default", tasks=_task_payload(10))
        )

        task_lines = renderer.task_lines()
        self.assertTrue(task_lines)
        self.assertLessEqual(len(task_lines), 6)
        self.assertIn("…", task_lines[-1])

    def test_task_header_uses_in_progress_subject_without_list_id(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            TaskUpdatedEvent(
                list_id="release",
                tasks=[
                    {"id": "1", "subject": "a", "status": "pending", "open_blocked_by": []},
                    {"id": "2", "subject": "b", "status": "in_progress", "open_blocked_by": []},
                ],
            )
        )

        task_lines = renderer.task_lines()
        self.assertTrue(task_lines)
        # Title shows the in_progress task's subject, not list_id
        self.assertEqual(task_lines[0], "b")
        self.assertNotIn("release", task_lines[0])
        self.assertNotIn("completed", task_lines[0])
        self.assertNotIn("in_progress", task_lines[0])

    def test_task_fold_prioritizes_open_items_before_completed(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            TaskUpdatedEvent(
                list_id="review",
                tasks=[
                    {"id": "1", "subject": "done-1", "status": "completed", "open_blocked_by": []},
                    {"id": "2", "subject": "open-1", "status": "pending", "open_blocked_by": []},
                    {"id": "3", "subject": "done-2", "status": "completed", "open_blocked_by": []},
                    {"id": "4", "subject": "open-2", "status": "in_progress", "open_blocked_by": []},
                    {"id": "5", "subject": "open-3", "status": "pending", "open_blocked_by": ["1"]},
                    {"id": "6", "subject": "done-3", "status": "completed", "open_blocked_by": []},
                ],
            )
        )

        lines = renderer.task_panel_lines(max_lines=5)
        joined = "\n".join(lines)
        self.assertIn("open-1", joined)
        self.assertIn("open-2", joined)
        self.assertIn("open-3", joined)
        self.assertNotIn("done-2", joined)
        self.assertTrue(lines[-1].startswith("… (+"))

    def test_task_row_omits_owner_from_display(self) -> None:
        """Owner field is no longer shown in task rows (visual redesign)."""
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            TaskUpdatedEvent(
                list_id="review",
                tasks=[
                    {
                        "id": "1",
                        "subject": "claim task ownership",
                        "status": "in_progress",
                        "owner": "andy",
                        "open_blocked_by": [],
                    },
                    {
                        "id": "2",
                        "subject": "keep row compact",
                        "status": "pending",
                        "owner": "",
                        "open_blocked_by": [],
                    },
                ],
            )
        )

        lines = renderer.task_panel_lines(max_lines=6)
        joined = "\n".join(lines)
        self.assertIn("claim task ownership", joined)
        self.assertNotIn("owner=", joined)

    def test_team_task_row_omits_empty_owner_suffix(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            TaskUpdatedEvent(
                list_id="comate-cli-analyzer",
                tasks=[
                    {
                        "id": "1",
                        "subject": "分析 TUI 布局架构",
                        "status": "pending",
                        "owner": "",
                        "open_blocked_by": [],
                    }
                ],
            )
        )

        lines = renderer.task_panel_lines(max_lines=6)
        joined = "\n".join(lines)
        self.assertIn("分析 TUI 布局架构", joined)
        self.assertNotIn("owner=", joined)

    def test_task_tool_history_hides_prompt_and_prefix_icons(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Agent",
                args={
                    "subagent_type": "Explorer",
                    "description": "研究 kimi-cli-main 实现",
                    "prompt": "这是很长的提示词，不应出现在历史里",
                },
                tool_call_id="tc_task_2",
            )
        )
        renderer.handle_event(
            ToolResultEvent(
                tool="Agent",
                result="done",
                tool_call_id="tc_task_2",
                is_error=False,
            )
        )

        tool_result_entry = next(
            entry for entry in renderer.history_entries() if entry.entry_type == "tool_result"
        )

        # HistoryEntry.text may be a Rich Text object for Agent tool entries
        from rich.text import Text as RichText
        text_plain = tool_result_entry.text.plain if isinstance(tool_result_entry.text, RichText) else str(tool_result_entry.text)
        self.assertIn("研究 kimi-cli-main 实现", text_plain)
        self.assertNotIn("prompt", text_plain.lower())
        self.assertFalse(text_plain.startswith("✓"))

    def test_tool_result_includes_error_summary(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Read",
                args={"path": "/tmp/a.py"},
                tool_call_id="tc_err_1",
            )
        )
        renderer.handle_event(
            ToolResultEvent(
                tool="Read",
                result={"error": "boom"},
                tool_call_id="tc_err_1",
                is_error=True,
            )
        )
        tool_result_entry = next(
            entry for entry in renderer.history_entries() if entry.entry_type == "tool_result"
        )
        self.assertIn("Read(", tool_result_entry.text)
        self.assertIn("boom", tool_result_entry.text)

    def test_task_completed_appends_summary_and_hides_panel(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            TaskUpdatedEvent(
                list_id="default",
                tasks=[
                    {"id": "1", "subject": "a", "status": "completed", "open_blocked_by": []},
                    {"id": "2", "subject": "b", "status": "completed", "open_blocked_by": []},
                ],
            )
        )
        tool_results = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertTrue(tool_results)
        self.assertIn("tasks 2/2 completed", tool_results[-1].text)
        self.assertFalse(renderer.has_active_todos())

    def test_stop_event_interrupted_appends_system_message(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.seed_user_message("hello")
        renderer.handle_event(
            ToolCallEvent(
                tool="Bash",
                args={"args": ["sleep", "10"]},
                tool_call_id="tc_interrupt_1",
            )
        )
        self.assertTrue(renderer.has_running_tools())
        renderer.handle_event(StopEvent(reason="interrupted"))

        system_entries = [e for e in renderer.history_entries() if e.entry_type == "system"]
        self.assertTrue(system_entries)
        self.assertIn("interrupted", system_entries[-1].text)
        self.assertFalse(renderer.has_running_tools())

    def test_step_complete_cancelled_clears_running_tool_without_tool_result(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Bash",
                args={"args": ["sleep", "30"]},
                tool_call_id="tc_cancel_1",
            )
        )
        self.assertTrue(renderer.has_running_tools())
        renderer.handle_event(
            StepCompleteEvent(
                step_id="tc_cancel_1",
                status="cancelled",
                duration_ms=123.0,
            )
        )
        self.assertFalse(renderer.has_running_tools())

    def test_reset_history_view_clears_runtime_state(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.seed_user_message("hello")
        renderer.handle_event(
            ToolCallEvent(
                tool="Read",
                args={"file_path": "a.py"},
                tool_call_id="tc_reset_1",
            )
        )
        renderer.handle_event(
            TaskUpdatedEvent(
                list_id="default",
                tasks=[{"id": "1", "subject": "a", "status": "pending", "open_blocked_by": []}]
            )
        )
        self.assertTrue(renderer.history_entries())
        self.assertTrue(renderer.has_running_tools())
        self.assertTrue(renderer.has_active_todos())

        renderer.reset_history_view()

        self.assertEqual(renderer.history_entries(), [])
        self.assertFalse(renderer.has_running_tools())
        self.assertFalse(renderer.has_active_todos())

    def test_edit_tool_result_with_diff_renders_rich_text(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Edit",
                args={"file_path": "/tmp/test.py", "old_string": "old", "new_string": "new"},
                tool_call_id="tc_edit_1",
            )
        )
        diff_metadata = {
            "diff": [
                "--- /tmp/test.py",
                "+++ /tmp/test.py",
                "@@ -1,3 +1,3 @@",
                " line1",
                "-old",
                "+new",
                " line3",
            ]
        }
        renderer.handle_event(
            ToolResultEvent(
                tool="Edit",
                result="ok",
                tool_call_id="tc_edit_1",
                is_error=False,
                metadata=diff_metadata,
            )
        )

        tool_results = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertTrue(tool_results)
        from rich.text import Text
        last_result = tool_results[-1]
        self.assertIsInstance(last_result.text, Text)
        plain_text = last_result.text.plain
        self.assertIn("+new", plain_text)
        self.assertIn("-old", plain_text)
        self.assertIn("@@", plain_text)

    def test_edit_tool_result_error_no_diff(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            ToolCallEvent(
                tool="Edit",
                args={"file_path": "/tmp/test.py", "old_string": "missing", "new_string": "new"},
                tool_call_id="tc_edit_err",
            )
        )
        diff_metadata = {"diff": ["-old", "+new"]}
        renderer.handle_event(
            ToolResultEvent(
                tool="Edit",
                result="old_string not found",
                tool_call_id="tc_edit_err",
                is_error=True,
                metadata=diff_metadata,
            )
        )

        tool_results = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertTrue(tool_results)
        last_result = tool_results[-1]
        self.assertEqual(last_result.severity, "error")
        # Should be a plain string, not Rich Text, since error results don't show diff
        self.assertIsInstance(last_result.text, str)

    def test_render_diff_text_truncation(self) -> None:
        diff_lines = [f"+added_line_{i}" for i in range(100)]
        result = EventRenderer._render_diff_text(diff_lines, max_lines=10)
        plain = result.plain
        self.assertIn("+added_line_0", plain)
        self.assertIn("+added_line_9", plain)
        self.assertNotIn("+added_line_10", plain)
        self.assertIn("90 more lines", plain)

    def test_render_diff_text_colors(self) -> None:
        diff_lines = [
            "--- a/file.py",
            "+++ b/file.py",
            "@@ -1,3 +1,3 @@",
            " context",
            "-removed",
            "+added",
        ]
        result = EventRenderer._render_diff_text(diff_lines, max_lines=50)
        # Check that each span has the correct style
        spans = result._spans
        plain = result.plain
        # Verify added/removed lines are rendered with background colors.
        added_start = plain.index("+added")
        added_styles = [
            str(s.style) for s in spans if s.start <= added_start < s.end
        ]
        self.assertTrue(
            any("on #" in style for style in added_styles),
            "'+added' should be styled with a background color",
        )

        removed_start = plain.index("-removed")
        removed_styles = [
            str(s.style) for s in spans if s.start <= removed_start < s.end
        ]
        self.assertTrue(
            any("on #" in style for style in removed_styles),
            "'-removed' should be styled with a background color",
        )

        added_bg_styles = {style for style in added_styles if "on #" in style}
        removed_bg_styles = {style for style in removed_styles if "on #" in style}
        self.assertTrue(added_bg_styles.isdisjoint(removed_bg_styles))

    def test_plan_approval_prefers_event_markdown(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(
            PlanApprovalRequiredEvent(
                plan_path="/tmp/should-not-read.md",
                summary="ready",
                execution_prompt="execute",
                plan_markdown="# Plan\n\n- step from event",
            )
        )

        assistant_entries = [e for e in renderer.history_entries() if e.entry_type == "assistant"]
        self.assertTrue(assistant_entries)
        self.assertIn("step from event", assistant_entries[-1].text)

    def test_plan_approval_falls_back_to_plan_path_when_markdown_empty(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        with tempfile.TemporaryDirectory() as td:
            plan_path = Path(td) / "plan.md"
            plan_path.write_text("# Plan\n\n- step from file", encoding="utf-8")
            renderer.handle_event(
                PlanApprovalRequiredEvent(
                    plan_path=str(plan_path),
                    summary="ready",
                    execution_prompt="execute",
                    plan_markdown="",
                )
            )

        assistant_entries = [e for e in renderer.history_entries() if e.entry_type == "assistant"]
        self.assertTrue(assistant_entries)
        self.assertIn("step from file", assistant_entries[-1].text)


class TestTaskToolScrollbackDisplay(unittest.TestCase):
    """Verify TaskCreate and TaskUpdate(completed) appear in scrollback."""

    def test_taskcreate_toolcall_produces_history_entry(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ToolCallEvent(tool="TaskCreate", args={"subject": "do X"}, tool_call_id="tc1"))
        renderer.handle_event(ToolResultEvent(tool="TaskCreate", result="ok", tool_call_id="tc1", is_error=False))
        entries = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertEqual(len(entries), 1)
        self.assertIn("TaskCreate", str(entries[0].text))

    def test_taskupdate_completed_produces_history_entry(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ToolCallEvent(tool="TaskUpdate", args={"taskId": "1", "status": "completed"}, tool_call_id="tc2"))
        renderer.handle_event(ToolResultEvent(tool="TaskUpdate", result="ok", tool_call_id="tc2", is_error=False))
        entries = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertEqual(len(entries), 1)
        self.assertIn("TaskUpdate", str(entries[0].text))

    def test_taskupdate_in_progress_hidden_from_scrollback(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ToolCallEvent(tool="TaskUpdate", args={"taskId": "1", "status": "in_progress"}, tool_call_id="tc3"))
        renderer.handle_event(ToolResultEvent(tool="TaskUpdate", result="ok", tool_call_id="tc3", is_error=False))
        entries = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertEqual(len(entries), 0)

    def test_tasklist_hidden_from_scrollback(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ToolCallEvent(tool="TaskList", args={}, tool_call_id="tc4"))
        renderer.handle_event(ToolResultEvent(tool="TaskList", result="ok", tool_call_id="tc4", is_error=False))
        entries = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertEqual(len(entries), 0)

    def test_tasklist_error_shown_in_scrollback(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ToolCallEvent(tool="TaskList", args={}, tool_call_id="tc5"))
        renderer.handle_event(ToolResultEvent(tool="TaskList", result="store error", tool_call_id="tc5", is_error=True))
        entries = [e for e in renderer.history_entries() if e.entry_type == "tool_result"]
        self.assertEqual(len(entries), 1)

    def test_reset_history_view_clears_tool_call_args(self) -> None:
        renderer = EventRenderer()
        renderer.start_turn()
        renderer.handle_event(ToolCallEvent(tool="TaskCreate", args={"subject": "x"}, tool_call_id="tc6"))
        self.assertTrue(renderer._tool_call_args)
        renderer.reset_history_view()
        self.assertFalse(renderer._tool_call_args)


if __name__ == "__main__":
    unittest.main(verbosity=2)
