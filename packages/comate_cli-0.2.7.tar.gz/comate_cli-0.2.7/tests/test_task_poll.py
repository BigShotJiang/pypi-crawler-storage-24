"""Tests for task polling refresh mechanism."""
from __future__ import annotations

import unittest
from unittest.mock import MagicMock


class TestTaskPollingConstant(unittest.TestCase):
    def test_poll_interval_is_2_seconds(self):
        from comate_cli.terminal_agent.tui import _TASK_POLL_INTERVAL_S
        self.assertEqual(_TASK_POLL_INTERVAL_S, 2.0)


class TestFetchTasksFromStore(unittest.TestCase):
    """Test _fetch_tasks_from_store logic with mocked dependencies."""

    def _make_tui_stub(self):
        """Create a minimal TUI stub with mocked session/agent/store."""
        store = MagicMock()
        store.list_id_value.return_value = "default"
        store.get_open_blocked_by.return_value = []

        task_item = MagicMock()
        task_item.id = "1"
        task_item.model_dump.return_value = {
            "id": "1", "subject": "Test task", "status": "in_progress",
            "owner": "", "blocked_by": [], "blocks": [],
        }
        store.list_tasks.return_value = [task_item]

        agent = MagicMock()
        agent._task_store = store

        session = MagicMock()
        session._agent = agent

        from comate_cli.terminal_agent.tui import TerminalAgentTUI
        tui = object.__new__(TerminalAgentTUI)
        tui._session = session

        return tui, store

    def test_fetch_returns_task_dicts_and_list_id(self):
        tui, store = self._make_tui_stub()
        result = tui._fetch_tasks_from_store()

        self.assertIsNotNone(result)
        task_dicts, list_id = result
        self.assertEqual(len(task_dicts), 1)
        self.assertEqual(task_dicts[0]["id"], "1")
        self.assertIn("open_blocked_by", task_dicts[0])
        self.assertEqual(list_id, "default")

    def test_fetch_returns_none_when_no_store(self):
        tui, _ = self._make_tui_stub()
        tui._session._agent._task_store = None
        result = tui._fetch_tasks_from_store()
        self.assertIsNone(result)

    def test_fetch_returns_none_when_no_tasks(self):
        tui, store = self._make_tui_stub()
        store.list_tasks.return_value = []
        result = tui._fetch_tasks_from_store()
        self.assertIsNone(result)
