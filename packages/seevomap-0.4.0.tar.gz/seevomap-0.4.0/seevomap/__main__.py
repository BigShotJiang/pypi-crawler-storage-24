"""Entry point for python -m seevomap."""
from seevomap.cli import main
main()
