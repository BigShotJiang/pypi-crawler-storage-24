"""SeevoMap — AI Research Knowledge Graph client."""

from seevomap.client import SeevoMap

__version__ = "0.4.0"
__all__ = ["SeevoMap"]
