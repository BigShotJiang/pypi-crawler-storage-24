"""
SeevoMap SDK — HTTP client for the SeevoMap HuggingFace Space API.

Supports both public graph (remote) and local private nodes.

Usage:
    from seevomap import SeevoMap
    svm = SeevoMap()
    results = svm.search("my task", top_k=5)       # public + local
    svm.local_add({"task": {...}, ...})              # store locally only
    svm.submit({"task": {...}, ...})                 # upload to public graph
"""

import json
import os
import re
import time
import uuid
from pathlib import Path

import requests

DEFAULT_ENDPOINT = "https://akiwatanabe-seevomap.hf.space"
GRADIO_API_PREFIX = "/gradio_api/call"
LOCAL_DIR = Path.home() / ".seevomap" / "nodes"


class SeevoMapError(Exception):
    """SeevoMap API error."""


# ── Local storage ────────────────────────────────────

def _ensure_local_dir():
    LOCAL_DIR.mkdir(parents=True, exist_ok=True)


def _local_keyword_score(query: str, node: dict) -> float:
    """Simple keyword overlap score for local node matching."""
    query_words = set(re.findall(r'\w+', query.lower()))
    if not query_words:
        return 0.0

    # Collect text from node
    parts = []
    parts.append(node.get("task", {}).get("domain", ""))
    parts.append(node.get("task", {}).get("description", ""))
    parts.append(node.get("idea", {}).get("text", ""))
    parts.append(node.get("analysis", ""))
    for tag in node.get("idea", {}).get("method_tags", []):
        parts.append(tag)
    node_text = " ".join(parts).lower()
    node_words = set(re.findall(r'\w+', node_text))

    if not node_words:
        return 0.0

    overlap = query_words & node_words
    # Jaccard-like score
    return len(overlap) / len(query_words)


def _load_local_nodes() -> list[dict]:
    """Load all local nodes from ~/.seevomap/nodes/."""
    _ensure_local_dir()
    nodes = []
    for p in sorted(LOCAL_DIR.glob("*.json")):
        try:
            with open(p, "r", encoding="utf-8") as f:
                nodes.append(json.load(f))
        except (json.JSONDecodeError, OSError):
            continue
    return nodes


def _search_local(query: str, top_k: int = 10) -> list[dict]:
    """Search local nodes by keyword matching."""
    nodes = _load_local_nodes()
    if not nodes:
        return []

    scored = []
    for node in nodes:
        score = _local_keyword_score(query, node)
        if score > 0:
            scored.append({
                "id": node.get("id", "?"),
                "score": round(score, 4),
                "domain": node.get("task", {}).get("domain", "unknown"),
                "idea": node.get("idea", {}).get("text", "")[:200],
                "metric_name": node.get("result", {}).get("metric_name", ""),
                "metric_value": node.get("result", {}).get("metric_value", ""),
                "success": node.get("result", {}).get("success", None),
                "source": "local",
            })

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:top_k]


# ── SeevoMap Client ──────────────────────────────────

class SeevoMap:
    """Client for the SeevoMap knowledge graph (public + local)."""

    def __init__(self, endpoint: str = None, local_dir: str = None):
        self.endpoint = (endpoint or DEFAULT_ENDPOINT).rstrip("/")
        self._session = requests.Session()
        self._session.headers["Content-Type"] = "application/json"
        if local_dir:
            global LOCAL_DIR
            LOCAL_DIR = Path(local_dir)

    def _call_gradio(self, api_name: str, data: list, max_retries: int = 2):
        """Call a Gradio API endpoint using the /call/{api_name} protocol."""
        url = f"{self.endpoint}{GRADIO_API_PREFIX}/{api_name}"

        for attempt in range(max_retries + 1):
            try:
                resp = self._session.post(url, json={"data": data}, timeout=30)
                resp.raise_for_status()
                event_id = resp.json().get("event_id")
                if not event_id:
                    raise SeevoMapError(f"No event_id returned from {api_name}")

                result_url = f"{self.endpoint}{GRADIO_API_PREFIX}/{api_name}/{event_id}"
                for _ in range(60):
                    r = self._session.get(result_url, timeout=10, stream=True)
                    for line in r.iter_lines(decode_unicode=True):
                        if not line:
                            continue
                        if line.startswith("data: "):
                            payload = json.loads(line[6:])
                            return payload
                        if line.startswith("event: error"):
                            raise SeevoMapError(f"API error from {api_name}")
                    time.sleep(0.5)

                raise SeevoMapError(f"Timeout waiting for {api_name} result")

            except requests.RequestException as e:
                if attempt < max_retries:
                    time.sleep(1)
                    continue
                raise SeevoMapError(f"Request failed: {e}") from e

    # ── Search (public + local) ──

    def search(self, query: str, top_k: int = 10) -> list[dict]:
        """Search public graph + local nodes, merged by score.

        Returns list of dicts with keys: id, score, domain, idea, metric_name, metric_value, success, source
        """
        # Remote search
        remote_results = []
        try:
            result = self._call_gradio("ui_search", [query, top_k])
            if isinstance(result, list) and len(result) >= 2:
                remote_results = self._parse_search_results(result[0])
        except SeevoMapError:
            pass  # Offline mode: only local results

        # Local search
        local_results = _search_local(query, top_k)

        # Merge: remote results use embedding scores (0-1), local uses keyword (0-1)
        # Remote scores are generally higher quality, so weight them up
        for r in remote_results:
            r["source"] = "public"
        merged = remote_results + local_results
        merged.sort(key=lambda x: x.get("score", 0), reverse=True)
        return merged[:top_k]

    def _parse_search_results(self, markdown: str) -> list[dict]:
        """Parse search results from the markdown output."""
        results = []
        if not markdown:
            return results

        for block in markdown.split("\n\n---\n\n"):
            block = block.strip()
            if not block:
                continue
            entry = {"raw": block, "source": "public"}
            # Try to extract score from markdown
            score_match = re.search(r'score=([\d.]+)', block)
            if score_match:
                entry["score"] = float(score_match.group(1))
            else:
                entry["score"] = 0.5
            # Extract domain
            domain_match = re.search(r'`(\w+)`', block)
            if domain_match:
                entry["domain"] = domain_match.group(1)
            results.append(entry)
        return results

    def inject(self, query: str, top_k: int = 10) -> str:
        """Get formatted prompt context (public + local) for agent injection."""
        # Remote inject
        remote_text = ""
        try:
            result = self._call_gradio("ui_search", [query, top_k])
            if isinstance(result, list) and len(result) >= 2:
                remote_text = result[1]
        except SeevoMapError:
            pass

        # Local nodes formatted
        local_results = _search_local(query, top_k=5)
        local_text = ""
        if local_results:
            lines = ["\n## Local Experience (your private nodes)\n"]
            for i, r in enumerate(local_results, 1):
                status = "✓" if r.get("success") else ("✗" if r.get("success") is False else "?")
                lines.append(
                    f"[L{i}] [{status}] {r['domain']} | {r['metric_name']}={r['metric_value']} | score={r['score']}\n"
                    f"    {r['idea']}"
                )
            local_text = "\n\n".join(lines)

        return (remote_text + "\n" + local_text).strip()

    # ── Local node management ──

    def local_add(self, node: dict) -> str:
        """Add a node to local storage only (not uploaded).

        Returns the node ID.
        """
        _ensure_local_dir()
        if not node.get("id"):
            node["id"] = str(uuid.uuid4())[:8]
        node["source"] = "local"

        node_path = LOCAL_DIR / f"{node['id']}.json"
        with open(node_path, "w", encoding="utf-8") as f:
            json.dump(node, f, indent=2, ensure_ascii=False)
        return node["id"]

    def local_list(self) -> list[dict]:
        """List all local nodes."""
        nodes = _load_local_nodes()
        return [
            {
                "id": n.get("id", "?"),
                "domain": n.get("task", {}).get("domain", ""),
                "idea": n.get("idea", {}).get("text", "")[:100],
                "metric_name": n.get("result", {}).get("metric_name", ""),
                "metric_value": n.get("result", {}).get("metric_value", ""),
            }
            for n in nodes
        ]

    def local_remove(self, node_id: str) -> bool:
        """Remove a local node."""
        node_path = LOCAL_DIR / f"{node_id}.json"
        if node_path.exists():
            node_path.unlink()
            return True
        return False

    # ── Public graph operations ──

    def get_node(self, node_id: str) -> dict:
        """Get full details of a single node (public or local)."""
        # Check local first
        node_path = LOCAL_DIR / f"{node_id}.json"
        if node_path.exists():
            with open(node_path, "r", encoding="utf-8") as f:
                return json.load(f)
        # Then remote
        result = self._call_gradio("ui_node_detail", [node_id])
        if isinstance(result, list) and len(result) >= 1:
            try:
                return json.loads(result[0])
            except (json.JSONDecodeError, TypeError):
                return {"raw": result[0]}
        return {"error": "No result"}

    def stats(self) -> dict:
        """Get graph statistics."""
        local_count = len(_load_local_nodes())
        try:
            resp = self._session.get(f"{self.endpoint}", timeout=15)
            return {
                "endpoint": self.endpoint,
                "reachable": resp.status_code == 200,
                "local_nodes": local_count,
                "local_dir": str(LOCAL_DIR),
            }
        except requests.RequestException:
            return {
                "endpoint": self.endpoint,
                "reachable": False,
                "local_nodes": local_count,
                "local_dir": str(LOCAL_DIR),
            }

    def submit(self, node: dict, api_keys: dict = None, enrich: bool = True) -> dict:
        """Submit a new experiment node to the PUBLIC graph (requires review).

        If api_keys provided and enrich=True, auto-extracts techniques + lesson via LLM ($0.001/call).
        Without api_keys, submission still works — just no enrichment.
        """
        # Auto-enrich if API key available
        if enrich and not node.get("lesson"):
            resolved = _resolve_api_keys(api_keys)
            if resolved:
                try:
                    node = _auto_enrich_node(node, resolved)
                except Exception:
                    pass  # Enrichment is optional, don't block submit

        node_json = json.dumps(node, ensure_ascii=False)
        result = self._call_gradio("submit_node", [node_json])
        if isinstance(result, list) and len(result) >= 1:
            try:
                return json.loads(result[0])
            except (json.JSONDecodeError, TypeError):
                return {"raw": result[0]}
        return {"error": "No result"}

    def review(self, node_id: str, action: str, secret: str = "") -> dict:
        """Review a pending node (maintainer only)."""
        result = self._call_gradio("review_node", [node_id, action, secret])
        if isinstance(result, list) and len(result) >= 1:
            try:
                return json.loads(result[0])
            except (json.JSONDecodeError, TypeError):
                return {"raw": result[0]}
        return {"error": "No result"}

    def list_pending(self, secret: str = "") -> list[dict]:
        """List all pending review nodes."""
        result = self._call_gradio("list_pending", [secret])
        if isinstance(result, list) and len(result) >= 1:
            try:
                return json.loads(result[0])
            except (json.JSONDecodeError, TypeError):
                return []
        return []

    # ── Analyze (LLM-synthesized insights) ──

    def analyze(
        self,
        task: str,
        top_k: int = 20,
        current_results: str = "",
        api_keys: dict = None,
        model: str = None,
    ) -> str:
        """Retrieve community experiences and synthesize transferable insights.

        Uses the user's own LLM to analyze raw experiences into actionable insights.

        Args:
            task: Task description
            top_k: Number of experiences to retrieve
            current_results: Optional current experiment results for context
            api_keys: Dict of provider→key, e.g. {"anthropic": "sk-ant-xxx"}
            model: LLM model to use (auto-detected from api_keys if not specified)

        Returns:
            ~500 token synthesized analysis with proven techniques, free wins,
            transferable principles, pitfalls, and recommended next step.
        """
        # Step 1: Retrieve raw experiences (full text, not truncated)
        raw_context = self.inject(task, top_k=top_k)
        if not raw_context:
            return "No relevant community experiences found."

        # Step 2: Resolve API key
        resolved_keys = _resolve_api_keys(api_keys)
        if not resolved_keys:
            raise SeevoMapError(
                "No LLM API key found. Provide via:\n"
                "  --api-key anthropic=sk-ant-xxx\n"
                "  or set ANTHROPIC_API_KEY / OPENAI_API_KEY environment variable"
            )

        provider, key = next(iter(resolved_keys.items()))
        model = model or _default_model(provider)

        # Step 3: Synthesize insights
        synthesis_prompt = _build_synthesis_prompt(task, raw_context, current_results)
        return _call_llm(provider, key, model, synthesis_prompt)


# ── API Key Resolution ──────────────────────────────

# Provider → env var name → default model
_PROVIDERS = [
    ("anthropic", "ANTHROPIC_API_KEY", "claude-sonnet-4-5-20250514"),
    ("openai", "OPENAI_API_KEY", "gpt-4o-mini"),
    ("google", "GOOGLE_API_KEY", "gemini-2.0-flash"),
]


def _resolve_api_keys(explicit: dict = None) -> dict:
    """Resolve API keys: explicit > env var."""
    if explicit:
        return explicit
    for provider, env_var, _ in _PROVIDERS:
        key = os.environ.get(env_var, "")
        if key:
            return {provider: key}
    return {}


def _default_model(provider: str) -> str:
    for p, _, model in _PROVIDERS:
        if p == provider:
            return model
    return "claude-sonnet-4-5-20250514"


def _build_synthesis_prompt(task: str, raw_context: str, current_results: str) -> str:
    current_section = ""
    if current_results:
        current_section = f"\nMy current best results:\n{current_results}\n"

    return f"""You are a research advisor analyzing community experimental data from SeevoMap (BotResearchNet).

A researcher is working on: {task}
{current_section}
Below are real, execution-grounded experiments from other researchers (idea → code → result):

{raw_context}

Produce a concise analysis (~500 words) with these sections:

1. PROVEN TECHNIQUES (high confidence):
   List each technique with its quantified impact. Note how many experiments confirm it.

2. FREE WINS:
   Improvements that don't require retraining — evaluation strategies, compression, etc.

3. TRANSFERABLE PRINCIPLES:
   Cross-domain patterns that apply to the researcher's task, not task-specific code.

4. PITFALLS TO AVOID:
   Failed approaches and why they failed.

5. RECOMMENDED NEXT STEP:
   The single highest-impact action given the researcher's current state.

Be specific and quantitative. Reference actual numbers. Focus on transferable insights, not verbatim code."""


def _call_llm(provider: str, api_key: str, model: str, prompt: str) -> str:
    """Call LLM API. Supports anthropic and openai-compatible providers."""
    if provider == "anthropic":
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": model,
                "max_tokens": 1500,
                "temperature": 0.3,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["content"][0]["text"]

    elif provider in ("openai", "google"):
        base_url = "https://api.openai.com/v1" if provider == "openai" else "https://generativelanguage.googleapis.com/v1beta/openai"
        resp = requests.post(
            f"{base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "max_tokens": 1500,
                "temperature": 0.3,
                "messages": [
                    {"role": "system", "content": "You are a research advisor analyzing experimental results."},
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]

    else:
        raise SeevoMapError(f"Unsupported provider: {provider}. Use anthropic, openai, or google.")


def _auto_enrich_node(node: dict, api_keys: dict) -> dict:
    """Auto-extract techniques + lesson from a node via LLM. ~$0.001 per call."""
    provider, key = next(iter(api_keys.items()))
    model = _default_model(provider)

    idea = node.get("idea", {}).get("text", "")[:800]
    domain = node.get("task", {}).get("domain", "")
    metric = node.get("result", {}).get("metric_name", "")
    value = node.get("result", {}).get("metric_value", "")
    success = node.get("result", {}).get("success", None)

    prompt = f"""From this experiment, extract two things:

1. techniques: 3-5 specific methods/approaches used (short lowercase tags, e.g. "bayesian_inference", "gated_mlp", "sliding_window_eval", "phase_diagram", "spectral_analysis")
2. lesson: ONE sentence of what was learned that could help someone doing a DIFFERENT task

Domain: {domain}
Experiment: {idea}
Result: {metric}={value}, success={success}

Reply ONLY as JSON: {{"techniques": ["tag1", "tag2", ...], "lesson": "..."}}"""

    try:
        response = _call_llm(provider, key, model, prompt)
        # Parse JSON from response (handle markdown code blocks)
        response = response.strip()
        if response.startswith("```"):
            response = response.split("\n", 1)[1].rsplit("```", 1)[0]
        enrichment = json.loads(response)
        if "techniques" in enrichment:
            node.setdefault("idea", {})["techniques"] = enrichment["techniques"][:8]
        if "lesson" in enrichment:
            node["lesson"] = enrichment["lesson"]
    except Exception:
        pass  # Enrichment is best-effort

    return node
