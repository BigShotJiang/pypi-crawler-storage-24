"""SeevoMap CLI — command-line interface for the AI Research Knowledge Graph."""

import argparse
import json
import os
import sys

from seevomap.client import SeevoMap, SeevoMapError
from seevomap import formatter


def main():
    parser = argparse.ArgumentParser(
        prog="seevomap",
        description="SeevoMap — AI Research Knowledge Graph (BotResearchNet)",
    )
    parser.add_argument(
        "--endpoint", default=None,
        help="Custom SeevoMap Space URL (default: HuggingFace Space)",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # search
    p_search = subparsers.add_parser("search", help="Search related research experiences")
    p_search.add_argument("query", help="Task description to search for")
    p_search.add_argument("--top-k", type=int, default=10, help="Number of results (default: 10)")

    # inject
    p_inject = subparsers.add_parser("inject", help="Get formatted prompt context for agent injection")
    p_inject.add_argument("query", help="Task description")
    p_inject.add_argument("--top-k", type=int, default=10, help="Number of results (default: 10)")

    # analyze
    p_analyze = subparsers.add_parser("analyze", help="LLM-synthesized insights from community experiences (BYOK)")
    p_analyze.add_argument("query", help="Task description to analyze")
    p_analyze.add_argument("--top-k", type=int, default=20, help="Number of experiences to retrieve (default: 20)")
    p_analyze.add_argument("--context", help="File with current experiment results (optional)")
    p_analyze.add_argument("--api-key", nargs="+", help="LLM API key: provider=key (e.g. anthropic=sk-ant-xxx)")
    p_analyze.add_argument("--model", help="LLM model override")

    # setup
    p_setup = subparsers.add_parser("setup", help="Install SeevoMap skill for AI assistants")
    p_setup.add_argument("target", choices=["claude-code", "codex", "cursor", "evoscientist"],
                         help="Target framework to install skill for")
    p_setup.add_argument("--local", action="store_true", help="Install to current project instead of global")

    # get
    p_get = subparsers.add_parser("get", help="Get node details or map data")
    get_sub = p_get.add_subparsers(dest="get_type")
    p_get_node = get_sub.add_parser("node", help="Get a single node by ID")
    p_get_node.add_argument("node_id", help="Node ID")
    p_get_map = get_sub.add_parser("map", help="Download map.json")
    p_get_map.add_argument("-o", "--output", default="map.json", help="Output file (default: map.json)")

    # stats
    subparsers.add_parser("stats", help="Show graph statistics")

    # submit (to public graph)
    p_submit = subparsers.add_parser("submit", help="Submit experiment results to the PUBLIC graph (requires review)")
    p_submit.add_argument("file", nargs="?", help="JSON file with node data")
    p_submit.add_argument("--dir", help="Directory of JSON files to batch submit")
    p_submit.add_argument("--api-key", nargs="+", help="LLM API key for auto-enrichment (e.g. anthropic=sk-ant-xxx)")
    p_submit.add_argument("--no-enrich", action="store_true", help="Skip auto-enrichment even if API key available")

    # local (private nodes)
    p_local = subparsers.add_parser("local", help="Manage local private nodes (not uploaded)")
    local_sub = p_local.add_subparsers(dest="local_action")
    p_local_add = local_sub.add_parser("add", help="Add a node locally")
    p_local_add.add_argument("file", help="JSON file with node data")
    p_local_list = local_sub.add_parser("list", help="List local nodes")
    p_local_rm = local_sub.add_parser("remove", help="Remove a local node")
    p_local_rm.add_argument("node_id", help="Node ID to remove")

    # review (maintainer)
    p_review = subparsers.add_parser("review", help="Review pending nodes (maintainer)")
    p_review.add_argument("--pending", action="store_true", help="List pending nodes")
    p_review.add_argument("--approve", metavar="ID", help="Approve a node")
    p_review.add_argument("--reject", metavar="ID", help="Reject a node")
    p_review.add_argument("--secret", default="", help="REVIEW_SECRET for authentication")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    svm = SeevoMap(endpoint=args.endpoint)

    try:
        if args.command == "search":
            results = svm.search(args.query, top_k=args.top_k)
            formatter.print_search_results(results)

        elif args.command == "inject":
            text = svm.inject(args.query, top_k=args.top_k)
            formatter.print_inject(text)

        elif args.command == "analyze":
            api_keys = _parse_api_keys(args.api_key) if args.api_key else None
            current_results = ""
            if args.context:
                with open(args.context, "r", encoding="utf-8") as f:
                    current_results = f.read()
            result = svm.analyze(
                args.query,
                top_k=args.top_k,
                current_results=current_results,
                api_keys=api_keys,
                model=args.model,
            )
            print(result)

        elif args.command == "setup":
            _setup_skill(args.target, args.local)

        elif args.command == "get":
            if args.get_type == "node":
                node = svm.get_node(args.node_id)
                formatter.print_node(node)
            elif args.get_type == "map":
                # Download map data - for now just note it's available on HF
                print(f"Map data available at: https://huggingface.co/datasets/akiwatanabe/seevomap-graph/resolve/main/map.json")
                print(f"Download: curl -L -o {args.output} https://huggingface.co/datasets/akiwatanabe/seevomap-graph/resolve/main/map.json")
            else:
                print("Usage: seevomap get node <id> | seevomap get map [-o file]")

        elif args.command == "stats":
            stats = svm.stats()
            formatter.print_stats(stats)

        elif args.command == "submit":
            api_keys = _parse_api_keys(args.api_key) if args.api_key else None
            enrich = not args.no_enrich
            if args.dir:
                import pathlib
                files = sorted(pathlib.Path(args.dir).glob("*.json"))
                if not files:
                    print(f"No JSON files found in {args.dir}")
                    sys.exit(1)
                for f in files:
                    with open(f, "r", encoding="utf-8") as fh:
                        node = json.load(fh)
                    result = svm.submit(node, api_keys=api_keys, enrich=enrich)
                    print(f"{f.name}: ", end="")
                    formatter.print_submit_result(result)
            elif args.file:
                with open(args.file, "r", encoding="utf-8") as f:
                    node = json.load(f)
                result = svm.submit(node, api_keys=api_keys, enrich=enrich)
                formatter.print_submit_result(result)
            else:
                print("Usage: seevomap submit <file.json> | seevomap submit --dir <directory>")
                sys.exit(1)

        elif args.command == "local":
            if args.local_action == "add":
                with open(args.file, "r", encoding="utf-8") as f:
                    node = json.load(f)
                node_id = svm.local_add(node)
                print(f"Added locally: {node_id} (stored in ~/.seevomap/nodes/)")
            elif args.local_action == "list":
                nodes = svm.local_list()
                if not nodes:
                    print("No local nodes. Use 'seevomap local add <file.json>' to add one.")
                else:
                    print(f"Local nodes: {len(nodes)}\n")
                    for n in nodes:
                        print(f"  [{n['id']}] {n['domain']} | {n['metric_name']}={n['metric_value']}")
                        print(f"           {n['idea'][:80]}")
                        print()
            elif args.local_action == "remove":
                if svm.local_remove(args.node_id):
                    print(f"Removed: {args.node_id}")
                else:
                    print(f"Not found: {args.node_id}")
            else:
                print("Usage: seevomap local add <file> | list | remove <id>")

        elif args.command == "review":
            if args.pending:
                pending = svm.list_pending(secret=args.secret)
                formatter.print_pending(pending)
            elif args.approve:
                result = svm.review(args.approve, "approve", secret=args.secret)
                formatter.print_review_result(result)
            elif args.reject:
                result = svm.review(args.reject, "reject", secret=args.secret)
                formatter.print_review_result(result)
            else:
                print("Usage: seevomap review --pending | --approve <id> | --reject <id>")

    except SeevoMapError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()


# ── Helper functions ──

def _parse_api_keys(key_args: list) -> dict:
    """Parse --api-key provider=key args into dict."""
    keys = {}
    for arg in key_args:
        if "=" in arg:
            provider, key = arg.split("=", 1)
            keys[provider.strip().lower()] = key.strip()
    return keys


SKILL_CONTENT = '''---
name: seevomap
description: Search and analyze community AI research experiences from SeevoMap (BotResearchNet)
tags: [research, knowledge-graph, auto-research, community]
---

# SeevoMap — Community Research Knowledge Graph

You have access to SeevoMap, a knowledge graph of 3,000+ real AI research execution records.
Every node is a real experiment: idea → code → execution → result.

## When to use

**Before designing any new experiment**, use SeevoMap to learn from community experience:

```bash
# Best: LLM-synthesized insights (requires API key in env)
seevomap analyze "<your task description>" --top-k 20

# Quick: raw formatted context
seevomap inject "<your task description>" --top-k 10

# Specific search
seevomap search "<specific technique>" --top-k 5
```

## Integration pattern for auto-research

1. **Before generating ideas**: Run `seevomap analyze` to get community insights
2. **Design experiment**: Use insights to prioritize proven techniques and avoid known pitfalls
3. **After experiment**: Run `seevomap submit result.json` to contribute back (optional)
4. **Private notes**: Run `seevomap local add result.json` to store locally without uploading

## analyze output format

`seevomap analyze` returns ~500 words with 5 sections:
- **PROVEN TECHNIQUES**: What worked, with quantified impact
- **FREE WINS**: Eval-only improvements, zero training cost
- **TRANSFERABLE PRINCIPLES**: Cross-domain patterns
- **PITFALLS TO AVOID**: Failed approaches and why
- **RECOMMENDED NEXT STEP**: Highest-impact single action

## Commands reference

```bash
seevomap analyze "task" --top-k 20              # Synthesized insights (needs LLM API key)
seevomap inject "task" --top-k 10               # Raw formatted context
seevomap search "task" --top-k 5                # Search results
seevomap submit result.json                      # Contribute to public graph
seevomap local add result.json                   # Store privately
seevomap local list                              # List private nodes
seevomap stats                                   # Graph statistics
seevomap get node <id>                           # Node details
```

## Python SDK

```python
from seevomap import SeevoMap
svm = SeevoMap()

# Synthesized insights (best for auto-research)
insights = svm.analyze("my task", api_keys={"anthropic": "sk-ant-xxx"})

# Raw context for prompt injection
context = svm.inject("my task", top_k=10)

# Search
results = svm.search("my task", top_k=5)

# Submit experiment results
svm.submit({"task": {"domain": "..."}, "idea": {"text": "..."}, "result": {"metric_name": "...", "metric_value": 0.5}})
```

## Key principle

SeevoMap provides **execution-grounded** experience — not paper abstracts, but real code + real metrics.
Use it to find proven techniques, avoid known failures, and accelerate your research.
'''


def _setup_skill(target: str, local: bool):
    """Install SeevoMap skill for the specified framework."""
    from pathlib import Path

    if target == "claude-code":
        if local:
            skill_dir = Path(".claude") / "skills" / "seevomap"
        else:
            skill_dir = Path.home() / ".claude" / "skills" / "seevomap"
    elif target == "codex":
        codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
        skill_dir = codex_home / "skills" / "seevomap" if not local else Path(".codex") / "skills" / "seevomap"
    elif target == "cursor":
        if local:
            skill_dir = Path(".cursor") / "skills" / "seevomap"
        else:
            skill_dir = Path.home() / ".cursor" / "skills" / "seevomap"
    elif target == "evoscientist":
        skill_dir = Path("skills") / "seevomap" if local else Path.home() / ".config" / "evoscientist" / "skills" / "seevomap"
    else:
        print(f"Unknown target: {target}")
        sys.exit(1)

    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text(SKILL_CONTENT, encoding="utf-8")

    print(f"SeevoMap skill installed to: {skill_dir}")
    print(f"  {skill_file}")
    print()
    if target == "codex" and local:
        print("For project-local Codex usage, run Codex with:")
        print("  CODEX_HOME=$PWD/.codex codex ...")
        print()
    print("The AI assistant will now automatically know how to use SeevoMap.")
    print("Make sure `seevomap` CLI is installed: pip install seevomap")
