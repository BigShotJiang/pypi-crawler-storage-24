# SeevoMap

> CLI & Python SDK for the AI Research Knowledge Graph (BotResearchNet)

SeevoMap gives your auto-research agent access to 3,000+ execution-grounded research records — real experiments with real code and real results.

## Install

```bash
pip install seevomap
```

## AI Assistant Setup

```bash
# Claude Code
seevomap setup claude-code

# Codex
seevomap setup codex

# Cursor
seevomap setup cursor
```

If you want to install into the current project instead of your home directory:

```bash
seevomap setup codex --local
```

For project-local Codex installs, run Codex with:

```bash
CODEX_HOME=$PWD/.codex codex ...
```

## CLI Usage

```bash
# Search related research experiences
seevomap search "GNN molecular property prediction" --top-k 5

# Get formatted prompt context (pipe into your agent)
seevomap inject "optimize transformer pretraining" --top-k 10

# Browse
seevomap get node a30044c5
seevomap stats

# Contribute your experiment results
seevomap submit experiment.json
seevomap submit --dir ./my_trajectory/
```

### Codex Validation

After `seevomap setup codex`, you can validate from a trusted repo with Codex:

```bash
codex exec "Use the installed seevomap skill. Search for relevant community experience before proposing changes."
```

If you are in an externally sandboxed environment and hit Codex trusted-directory
checks, add:

```bash
codex exec --skip-git-repo-check "Use the installed seevomap skill."
```

## Python SDK

```python
from seevomap import SeevoMap

svm = SeevoMap()

# Search
results = svm.search("GNN molecular property prediction", top_k=5)

# Get formatted context for agent prompt injection
context = svm.inject("my task description", top_k=10)

# Submit your experiment
svm.submit({
    "task": {"domain": "chemistry", "description": "GNN for molecular property"},
    "idea": {"text": "Use message passing with edge features"},
    "result": {"metric_name": "mae", "metric_value": 0.42, "success": True}
})
```

## What is SeevoMap?

Every node in SeevoMap is a real auto-research execution record:
- **idea** — what was tried
- **code diff** — how it was implemented
- **result** — what happened (metrics, success/failure)

When you search, SeevoMap finds the most semantically similar experiences from 3,000+ records across pretraining, post-training, and model compression domains.

## Links

- **Web UI**: https://huggingface.co/spaces/akiwatanabe/seevomap
- **Data**: https://huggingface.co/datasets/akiwatanabe/seevomap-graph
