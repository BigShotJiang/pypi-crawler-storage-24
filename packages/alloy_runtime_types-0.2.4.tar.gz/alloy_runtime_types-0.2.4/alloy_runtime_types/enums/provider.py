"""AI Provider enumeration.

This enum represents all supported AI providers in the system.
Provider keys must match the values in ai.providers table.
"""

from enum import Enum


class Provider(str, Enum):
    """
    AI service providers.

    Values must match provider_key in ai.providers table.
    Inherits from str for JSON serialization and Pydantic compatibility.
    """

    AIHUBMIX = "aihubmix"
    ALIBABA = "alibaba"
    ALIBABA_CN = "alibaba-cn"
    AMAZON_BEDROCK = "amazon-bedrock"
    ANTHROPIC = "anthropic"
    AZURE = "azure"
    BASETEN = "baseten"
    CEREBRAS = "cerebras"
    CHUTES = "chutes"
    CLOUDFLARE_WORKERS_AI = "cloudflare-workers-ai"
    CORTECS = "cortecs"
    DEEPINFRA = "deepinfra"
    DEEPSEEK = "deepseek"
    ELEVENLABS = "elevenlabs"
    EXA = "exa"
    FASTROUTER = "fastrouter"
    FIREWORKS_AI = "fireworks-ai"
    GITHUB_COPILOT = "github-copilot"
    GITHUB_MODELS = "github-models"
    GOOGLE = "google"
    GOOGLE_VERTEX = "google-vertex"
    GOOGLE_VERTEX_ANTHROPIC = "google-vertex-anthropic"
    GROQ = "groq"
    HUGGINGFACE = "huggingface"
    IFLOWCN = "iflowcn"
    INCEPTION = "inception"
    INFERENCE = "inference"
    LLAMA = "llama"
    LMSTUDIO = "lmstudio"
    LUCIDQUERY = "lucidquery"
    MISTRAL = "mistral"
    MODELSCOPE = "modelscope"
    MOONSHOTAI = "moonshotai"
    MOONSHOTAI_CN = "moonshotai-cn"
    MORPH = "morph"
    NEBIUS = "nebius"
    NVIDIA = "nvidia"
    OPENAI = "openai"
    OPENCODE = "opencode"
    OPENROUTER = "openrouter"
    PERPLEXITY = "perplexity"
    REQUESTY = "requesty"
    SCALEWAY = "scaleway"
    SUBMODEL = "submodel"
    SYNTHETIC = "synthetic"
    TOGETHERAI = "togetherai"
    UPSTAGE = "upstage"
    V0 = "v0"
    VENICE = "venice"
    VERCEL = "vercel"
    VOYAGE = "voyage"
    VULTR = "vultr"
    WANDB = "wandb"
    XAI = "xai"
    ZAI = "zai"
    ZAI_CODING_PLAN = "zai-coding-plan"
    ZENMUX = "zenmux"
    ZHIPUAI = "zhipuai"
    ZHIPUAI_CODING_PLAN = "zhipuai-coding-plan"

    # Testing-only provider for invalid provider tests
    # Random lowercase string: xqwvnmkjhgfdsapoiuytrewqlkjhgfdsazxcvbnm
    TESTING_INVALID_PROVIDER = "xqwvnmkjhgfdsapoiuytrewqlkjhgfdsazxcvbnm"

    @classmethod
    def from_str(cls, value: str) -> "Provider":
        """
        Convert string to Provider enum.

        Args:
            value: Provider key string (e.g., "openai", "anthropic")

        Returns:
            Provider enum value

        Raises:
            ValueError: If provider_key is not a valid provider
        """
        try:
            return cls(value)
        except ValueError as e:
            valid_providers = ", ".join([p.value for p in cls])
            raise ValueError(
                f"Invalid provider '{value}'. Valid providers: {valid_providers}"
            ) from e
