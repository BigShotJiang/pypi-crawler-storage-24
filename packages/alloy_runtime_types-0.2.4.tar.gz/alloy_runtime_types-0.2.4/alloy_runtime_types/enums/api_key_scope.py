"""API key permission scopes.

Defines the set of operations an API key can perform.
"""

from enum import Enum


class ApiKeyScope(str, Enum):
    """Permission scopes for API keys.

    Each scope grants access to a specific operation type:
    - READ: View and retrieve resources
    - UPDATE: Modify existing resources
    - DELETE: Remove resources
    - USE: Execute operations (e.g., run agents, execute pipelines)

    No WRITE alias or wildcard scopes are provided.
    """

    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    USE = "use"


# Canonical ordering for scope serialization
CANONICAL_SCOPE_ORDER = [
    ApiKeyScope.READ,
    ApiKeyScope.UPDATE,
    ApiKeyScope.DELETE,
    ApiKeyScope.USE,
]
