"""Enums for template domain."""

from enum import Enum


class TemplateContentType(str, Enum):
    """Template content types from template.template_content_types table."""

    SYSTEM_INSTRUCTION = "system_instruction"
    USER_MESSAGE = "user_message"
    FRAGMENT = "fragment"


class TemplateVisibility(str, Enum):
    """Template visibility levels from template.template_visibilities table."""

    PRIVATE = "private"
    ORGANIZATION = "organization"
    PUBLIC = "public"
