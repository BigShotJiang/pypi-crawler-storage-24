from enum import Enum


class OwnershipScope(str, Enum):
    """Defines ownership scope for resources like agents, templates, etc."""

    USER = "user"
    ORGANIZATION = "organization"
    GLOBAL = "global"
