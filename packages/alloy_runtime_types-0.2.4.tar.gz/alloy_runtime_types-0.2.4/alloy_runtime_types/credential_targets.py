from dataclasses import dataclass

from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.enums.tool_service import ToolService


@dataclass(frozen=True, slots=True)
class SupportedInferenceProvider:
    key: str
    category: str


@dataclass(frozen=True, slots=True)
class SupportedToolService:
    key: str
    category: str


@dataclass(frozen=True, slots=True)
class SupportedToolCredentialMapping:
    tool_id: str
    org_service_keys: tuple[str, ...] = ()
    provider_keys: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SupportedCredentialTargets:
    inference_providers: tuple[SupportedInferenceProvider, ...]
    tool_services: tuple[SupportedToolService, ...]
    tool_mappings: tuple[SupportedToolCredentialMapping, ...]


def get_supported_credential_targets() -> SupportedCredentialTargets:
    inference_providers = tuple(
        SupportedInferenceProvider(key=provider.value, category="inference")
        for provider in sorted(
            (
                provider
                for provider in Provider
                if not provider.name.startswith("TESTING")
            ),
            key=lambda provider: provider.value,
        )
    )

    tool_services = tuple(
        SupportedToolService(
            key=service.value, category=_tool_service_category(service)
        )
        for service in sorted(ToolService, key=lambda service: service.value)
    )

    tool_mappings = (
        SupportedToolCredentialMapping(
            tool_id="exa_search",
            org_service_keys=(ToolService.EXA.value,),
        ),
        SupportedToolCredentialMapping(
            tool_id="python_code_execution",
            org_service_keys=(ToolService.MODAL.value,),
        ),
        SupportedToolCredentialMapping(
            tool_id="web_research",
            org_service_keys=(ToolService.TAVILY.value, ToolService.FIRECRAWL.value),
        ),
        SupportedToolCredentialMapping(
            tool_id="webpage_extract",
            org_service_keys=(ToolService.FIRECRAWL.value,),
        ),
        SupportedToolCredentialMapping(
            tool_id="x_com_search",
            provider_keys=(Provider.XAI.value,),
        ),
    )

    return SupportedCredentialTargets(
        inference_providers=inference_providers,
        tool_services=tool_services,
        tool_mappings=tool_mappings,
    )


def _tool_service_category(service: ToolService) -> str:
    if service in {ToolService.VOYAGE_AI}:
        return "embeddings"
    if service in {ToolService.MODAL}:
        return "execution"
    return "research"
