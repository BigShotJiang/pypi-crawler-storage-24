"""DTOs for pipeline scheduling endpoints."""

from datetime import datetime
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field


# ============================================================================
# Schedule Expression Types (Discriminated Union)
# ============================================================================


class CronSchedule(BaseModel):
    """Cron-based schedule expression.

    Standard 5-field cron format: minute hour day month weekday

    Examples:
        "* * * * *"     - Every minute
        "0 9 * * *"     - Daily at 9am
        "0 9 * * 1-5"   - Weekdays at 9am
        "*/15 * * * *"  - Every 15 minutes
        "0 0 1 * *"     - First of month at midnight
    """

    type: Literal["cron"] = "cron"
    expression: str = Field(
        ...,
        description="Cron expression (5 fields: minute hour day month weekday)",
        examples=["0 9 * * *", "0 9 * * 1-5", "*/15 * * * *"],
    )
    timezone: str = Field(
        default="UTC",
        description="IANA timezone for schedule interpretation",
        examples=["UTC", "America/Chicago", "Europe/London"],
    )


class NthWeekday(BaseModel):
    """Nth weekday specification for RRULE.

    Examples:
        {"weekday": "MO", "n": 1}   - First Monday
        {"weekday": "FR", "n": -1}  - Last Friday
        {"weekday": "TH", "n": 2}   - Second Thursday
    """

    weekday: Literal["MO", "TU", "WE", "TH", "FR", "SA", "SU"]
    n: int = Field(
        ...,
        description="Occurrence number (1=first, 2=second, -1=last, -2=second-to-last)",
    )


class RRuleSchedule(BaseModel):
    """RFC 5545 RRULE-based schedule expression.

    Supports complex recurring patterns like:
    - Every 2 weeks on Monday at 9am
    - First Monday of every month at 10am
    - Last Friday of every quarter at 2pm

    Examples:
        Daily at 9am:
            {"type": "rrule", "freq": "daily", "by_hour": [9], "by_minute": [0]}

        Every Monday and Friday at 10am:
            {"type": "rrule", "freq": "weekly", "by_weekday": ["MO", "FR"],
             "by_hour": [10], "by_minute": [0]}

        First Monday of each month at 9am:
            {"type": "rrule", "freq": "monthly", "by_nth_weekday": [{"weekday": "MO", "n": 1}],
             "by_hour": [9], "by_minute": [0]}

        Last Friday of each month at 2pm:
            {"type": "rrule", "freq": "monthly", "by_nth_weekday": [{"weekday": "FR", "n": -1}],
             "by_hour": [14], "by_minute": [0]}
    """

    type: Literal["rrule"] = "rrule"
    freq: Literal["minutely", "hourly", "daily", "weekly", "monthly", "yearly"] = Field(
        ..., description="Base frequency"
    )
    timezone: str = Field(
        default="UTC",
        description="IANA timezone for schedule interpretation",
    )
    interval: int = Field(
        default=1,
        ge=1,
        description="Interval between occurrences (e.g., 2 = every 2 weeks)",
    )
    by_weekday: list[Literal["MO", "TU", "WE", "TH", "FR", "SA", "SU"]] | None = Field(
        default=None,
        description="Weekdays to run on",
        examples=[["MO", "WE", "FR"]],
    )
    by_nth_weekday: list[NthWeekday] | None = Field(
        default=None,
        description="Nth weekday occurrences (e.g., first Monday, last Friday)",
    )
    by_monthday: list[int] | None = Field(
        default=None,
        description="Days of month (1-31, -1 for last)",
        examples=[[1, 15], [-1]],
    )
    by_month: list[int] | None = Field(
        default=None,
        description="Months (1-12)",
        examples=[[1, 4, 7, 10]],
    )
    by_hour: list[int] | None = Field(
        default=None,
        description="Hours (0-23)",
        examples=[[9], [9, 14]],
    )
    by_minute: list[int] | None = Field(
        default=None,
        description="Minutes (0-59)",
        examples=[[0], [0, 30]],
    )
    by_yearday: list[int] | None = Field(
        default=None,
        description="Days of year (1-366, negative from end)",
    )
    by_weekno: list[int] | None = Field(
        default=None,
        description="Week numbers (1-53)",
    )
    by_setpos: list[int] | None = Field(
        default=None,
        description="Set positions for filtering occurrences",
    )


# Discriminated union for schedule expressions
ScheduleExpression = Annotated[
    CronSchedule | RRuleSchedule,
    Field(discriminator="type"),
]


# ============================================================================
# Create Schedule DTOs
# ============================================================================


class CreateScheduleRequest(BaseModel):
    """Request to create a recurring pipeline schedule.

    Example - Daily at 9am Chicago time:
        {
            "name": "Daily Report",
            "schedule": {
                "type": "cron",
                "expression": "0 9 * * *",
                "timezone": "America/Chicago"
            },
            "input_parameters": {"report_type": "daily"},
            "timeout_seconds": 300
        }

    Example - First Monday of each month:
        {
            "name": "Monthly Sync",
            "schedule": {
                "type": "rrule",
                "freq": "monthly",
                "timezone": "America/New_York",
                "by_nth_weekday": [{"weekday": "MO", "n": 1}],
                "by_hour": [9],
                "by_minute": [0]
            }
        }
    """

    name: str = Field(..., min_length=1, max_length=255, description="Schedule name")
    description: str | None = Field(default=None, description="Schedule description")
    schedule: ScheduleExpression = Field(..., description="Schedule expression")
    input_parameters: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters to pass to pipeline execution",
    )
    timeout_seconds: int = Field(
        default=300,
        ge=1,
        le=3600,
        description="Execution timeout in seconds (1-3600)",
    )
    is_enabled: bool = Field(
        default=True,
        description="Whether schedule is active",
    )
    allow_concurrent: bool = Field(
        default=False,
        description="Allow concurrent executions if previous run is still running",
    )
    max_consecutive_failures: int = Field(
        default=5,
        ge=0,
        description="Auto-disable after this many consecutive failures (0 = never)",
    )


class CreateScheduleResponse(BaseModel):
    """Response after creating a schedule."""

    id: UUID
    pipeline_id: UUID
    name: str
    description: str | None
    schedule_type: Literal["cron", "rrule"]
    timezone: str
    is_enabled: bool
    next_run_at: datetime | None
    created_at: datetime


# ============================================================================
# Get Schedule DTOs
# ============================================================================


class GetScheduleResponse(BaseModel):
    """Response for getting a schedule."""

    id: UUID
    pipeline_id: UUID
    name: str
    description: str | None
    schedule_type: Literal["cron", "rrule"]
    timezone: str

    # Cron fields (if schedule_type == "cron")
    cron_expression: str | None = None

    # RRULE fields (if schedule_type == "rrule")
    rrule_freq: str | None = None
    rrule_interval: int | None = None
    rrule_by_weekday: list[str] | None = None
    rrule_by_nth_weekday: list[dict[str, Any]] | None = None
    rrule_by_monthday: list[int] | None = None
    rrule_by_month: list[int] | None = None
    rrule_by_hour: list[int] | None = None
    rrule_by_minute: list[int] | None = None

    input_parameters: dict[str, Any]
    timeout_seconds: int

    is_enabled: bool
    next_run_at: datetime | None
    last_run_at: datetime | None
    last_execution_id: UUID | None
    consecutive_failures: int

    allow_concurrent: bool
    is_running: bool
    max_consecutive_failures: int

    created_at: datetime
    updated_at: datetime


# ============================================================================
# List Schedules DTOs
# ============================================================================


class ScheduleSummary(BaseModel):
    """Summary of a schedule for list responses."""

    id: UUID
    pipeline_id: UUID
    name: str
    description: str | None
    schedule_type: Literal["cron", "rrule"]
    timezone: str
    is_enabled: bool
    next_run_at: datetime | None
    last_run_at: datetime | None
    consecutive_failures: int
    created_at: datetime


class ListSchedulesResponse(BaseModel):
    """Response for listing schedules."""

    schedules: list[ScheduleSummary]
    total: int


# ============================================================================
# Update Schedule DTOs
# ============================================================================


class UpdateScheduleRequest(BaseModel):
    """Request to update a schedule. All fields are optional.

    Note: Schedule expression (cron/rrule) cannot be updated.
    To change the schedule, delete and recreate the schedule.
    """

    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = None
    input_parameters: dict[str, Any] | None = None
    timeout_seconds: int | None = Field(default=None, ge=1, le=3600)
    is_enabled: bool | None = None
    allow_concurrent: bool | None = None
    max_consecutive_failures: int | None = Field(default=None, ge=0)


class UpdateScheduleResponse(BaseModel):
    """Response after updating a schedule."""

    id: UUID
    name: str
    is_enabled: bool
    next_run_at: datetime | None
    updated_at: datetime


# ============================================================================
# Delete Schedule DTOs
# ============================================================================


class DeleteScheduleResponse(BaseModel):
    """Response after deleting a schedule."""

    id: UUID
    deleted: bool = True


# ============================================================================
# Schedule Once (One-Time Execution) DTOs
# ============================================================================


class ScheduleOnceRequest(BaseModel):
    """Request to schedule a one-time pipeline execution.

    Example - Run tomorrow at 3pm New York time:
        {
            "scheduled_for": "2026-02-01T15:00:00",
            "timezone": "America/New_York",
            "input_parameters": {"report_type": "special"}
        }
    """

    scheduled_for: datetime = Field(
        ...,
        description="When to execute the pipeline (in the specified timezone)",
    )
    timezone: str = Field(
        default="UTC",
        description="IANA timezone for interpreting scheduled_for",
    )
    input_parameters: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters to pass to pipeline execution",
    )
    timeout_seconds: int = Field(
        default=300,
        ge=1,
        le=3600,
        description="Execution timeout in seconds",
    )


class ScheduleOnceResponse(BaseModel):
    """Response after scheduling a one-time execution."""

    id: UUID
    pipeline_id: UUID
    scheduled_for: datetime
    timezone: str
    status: Literal["pending", "triggered", "cancelled", "expired"]
    created_at: datetime


# ============================================================================
# Get Scheduled Execution DTOs
# ============================================================================


class GetScheduledExecutionResponse(BaseModel):
    """Response for getting a scheduled one-time execution."""

    id: UUID
    pipeline_id: UUID
    scheduled_for: datetime
    timezone: str
    input_parameters: dict[str, Any]
    timeout_seconds: int
    status: Literal["pending", "triggered", "cancelled", "expired"]
    triggered_at: datetime | None
    execution_id: UUID | None
    created_at: datetime


class ListScheduledExecutionsResponse(BaseModel):
    """Response for listing scheduled one-time executions."""

    executions: list[GetScheduledExecutionResponse]
    total: int


class CancelScheduledExecutionResponse(BaseModel):
    """Response after cancelling a scheduled execution."""

    id: UUID
    status: Literal["cancelled"] = "cancelled"


# ============================================================================
# Schedule Environment Variables DTOs
# ============================================================================


class SetScheduleEnvVarsRequest(BaseModel):
    """Request to set environment variables on a schedule."""

    env_vars: dict[str, str] = Field(
        ...,
        description="Environment variables to set on the schedule. "
        "These override pipeline-level env vars and are encrypted at rest. "
        "Pass an empty dict {} to clear all schedule-level env vars.",
    )


class SetScheduleEnvVarsResponse(BaseModel):
    """Response after setting schedule environment variables."""

    schedule_id: UUID
    pipeline_id: UUID
    env_var_keys: list[str] = Field(
        ...,
        description="List of env var keys that were set (values are not returned for security).",
    )
    masked_values: dict[str, str] = Field(
        ...,
        description="Masked values showing only prefix for identification.",
    )
