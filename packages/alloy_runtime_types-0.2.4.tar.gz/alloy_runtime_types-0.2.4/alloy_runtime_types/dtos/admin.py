"""DTOs for admin operations."""

from pydantic import BaseModel


class SyncModelsRequest(BaseModel):
    """Request to sync AI models from external providers."""

    pass


class ProviderSyncResult(BaseModel):
    """Results from syncing a single provider source."""

    models_synced: int
    providers_synced: int
    error: str | None = None


class SyncModelsResponse(BaseModel):
    """Aggregated sync results from all provider sources."""

    total_models_synced: int
    total_providers_synced: int
    by_source: dict[str, ProviderSyncResult]
