"""DTOs for API key management operations."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from alloy_runtime_types.enums.api_key_scope import CANONICAL_SCOPE_ORDER, ApiKeyScope


class CreateApiKeyRequest(BaseModel):
    """Request to create a new API key.

    Requires explicit non-empty scopes. Duplicates are normalized to unique set
    in canonical order: read, update, delete, use.
    """

    scopes: list[ApiKeyScope] = Field(
        ...,
        description="Permission scopes for the API key (non-empty, normalized to unique set)",
        min_length=1,
    )
    description: str | None = Field(
        default=None,
        max_length=500,
        description="User-visible label for the key",
    )
    expires_at: datetime | None = Field(
        default=None,
        description="Optional expiration timestamp",
    )

    @field_validator("scopes")
    @classmethod
    def normalize_scopes(cls, value: list[ApiKeyScope]) -> list[ApiKeyScope]:
        """Normalize scopes to unique set in canonical order."""
        # Remove duplicates while preserving order
        seen: set[ApiKeyScope] = set()
        unique: list[ApiKeyScope] = []
        for scope in value:
            if scope not in seen:
                seen.add(scope)
                unique.append(scope)

        # Sort by canonical order
        return sorted(unique, key=lambda s: CANONICAL_SCOPE_ORDER.index(s))


class CreateApiKeyResponse(BaseModel):
    """Response after creating an API key.

    Returns the plaintext key once. Never exposes hashed_key.
    """

    id: UUID
    key: str  # Plaintext, only returned once
    prefix: str
    description: str | None
    scopes: list[ApiKeyScope]
    created_at: datetime
    expires_at: datetime | None = None


class ApiKeyResponse(BaseModel):
    """Common response shape for API key data."""

    id: UUID
    prefix: str
    description: str | None
    scopes: list[ApiKeyScope]
    created_at: datetime
    expires_at: datetime | None = None
    last_used_at: datetime | None = None


class ListApiKeysResponse(BaseModel):
    """Response listing all API keys for authenticated user."""

    keys: list[ApiKeyResponse]
    total: int


class UpdateApiKeyRequest(BaseModel):
    """Request to update an existing API key.

    All fields are optional - only provided fields are updated.
    """

    description: str | None = Field(
        default=None,
        max_length=500,
        description="User-visible label for the key",
    )
    expires_at: datetime | None = Field(
        default=None,
        description="Expiration timestamp (set to None to remove expiration)",
    )
    scopes: list[ApiKeyScope] | None = Field(
        default=None,
        description="Permission scopes (non-empty if provided, normalized to unique set)",
    )

    @field_validator("scopes")
    @classmethod
    def normalize_scopes(
        cls, value: list[ApiKeyScope] | None
    ) -> list[ApiKeyScope] | None:
        """Normalize scopes to unique set in canonical order if provided."""
        if value is None:
            return None

        if len(value) == 0:
            raise ValueError("scopes must be non-empty if provided")

        # Remove duplicates while preserving order
        seen: set[ApiKeyScope] = set()
        unique: list[ApiKeyScope] = []
        for scope in value:
            if scope not in seen:
                seen.add(scope)
                unique.append(scope)

        # Sort by canonical order
        return sorted(unique, key=lambda s: CANONICAL_SCOPE_ORDER.index(s))
