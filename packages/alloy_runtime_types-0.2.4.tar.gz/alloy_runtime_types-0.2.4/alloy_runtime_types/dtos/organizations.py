"""DTOs for organization operations."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class CreateOrganizationRequest(BaseModel):
    """Request to create a new organization."""

    model_config = ConfigDict(str_strip_whitespace=True)

    name: str = Field(
        ...,
        min_length=1,
        description="Organization name",
        examples=["Acme Corp", "My Company"],
    )


class OrganizationResponse(BaseModel):
    """Response for organization data."""

    model_config = ConfigDict(from_attributes=True)

    id: UUID = Field(..., description="Organization unique identifier")
    name: str = Field(..., description="Organization name")
    created_at: datetime = Field(..., description="Creation timestamp (UTC)")
    updated_at: datetime = Field(..., description="Last update timestamp (UTC)")
