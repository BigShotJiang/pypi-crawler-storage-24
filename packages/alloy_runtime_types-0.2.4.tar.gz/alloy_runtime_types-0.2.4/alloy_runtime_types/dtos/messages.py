"""DTOs for chat message operations."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field, model_validator


class UpdateMessageRequest(BaseModel):
    """Request to update a chat message.

    All fields are optional - only provided fields will be updated.
    At least one field must be provided.
    """

    include_in_context: bool | None = Field(
        default=None,
        description="Whether this message is included in conversation context for AI generations",
    )

    @model_validator(mode="after")
    def validate_at_least_one_field(self) -> "UpdateMessageRequest":
        """Ensure at least one updateable field is provided."""
        if self.include_in_context is None:
            raise ValueError(
                "Must provide at least one field to update: include_in_context"
            )
        return self


class MessageDetailResponse(BaseModel):
    """Response with message details after update."""

    id: UUID
    chat_session_id: UUID | None = Field(
        description="Session this message belongs to, if any"
    )
    sequence_number: int | None = Field(description="Position in conversation sequence")
    role: str = Field(description="Message role: user, assistant, system, tool")
    tool_call_id: str | None = Field(
        default=None, description="Tool call ID for tool messages"
    )
    tool_name: str | None = Field(
        default=None, description="Tool name for tool messages"
    )
    include_in_context: bool = Field(
        description="Whether included in conversation context"
    )
    agent_execution_id: UUID | None = Field(
        default=None, description="ID of the agent execution that created this message"
    )
    created_at: datetime


class DeletedMessageResponse(BaseModel):
    """Final state of a deleted message."""

    id: UUID
    chat_session_id: UUID = Field(description="Session this message belonged to")
    sequence_number: int = Field(description="Position in conversation sequence")
    role: str = Field(description="Message role: user, assistant, system, tool")
    tool_call_id: str | None = Field(
        default=None, description="Tool call ID for tool messages"
    )
    tool_name: str | None = Field(
        default=None, description="Tool name for tool messages"
    )
    include_in_context: bool = Field(
        description="Whether included in conversation context"
    )
    agent_execution_id: UUID | None = Field(
        default=None, description="ID of the agent execution that created this message"
    )
    created_at: datetime


class DeleteMessageResponse(BaseModel):
    """Response for deleting a chat message."""

    deleted_message: DeletedMessageResponse
