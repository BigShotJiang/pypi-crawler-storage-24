"""DTOs for user operations."""

from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from alloy_runtime_types.enums.member_role import MemberRole


class CreateUserRequest(BaseModel):
    """Request to create a new user."""

    email: str = Field(
        ...,
        description="User's email address. Must be valid format and will be normalized to lowercase.",
    )
    name: str = Field(..., description="User's display name.")
    role_id: MemberRole = Field(
        default=MemberRole.MEMBER,
        description="User's role in the organization. Defaults to MEMBER.",
    )

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        """Validate email format and normalize to lowercase."""
        stripped = value.strip()
        if not stripped or "@" not in stripped:
            raise ValueError("email must be valid format")
        parts = stripped.split("@")
        if len(parts) != 2:
            raise ValueError("email must be valid format")
        local, domain = parts
        if not local or not domain or "." not in domain:
            raise ValueError("email must be valid format")
        return stripped.lower()


class CreateUserResponse(BaseModel):
    """Response after creating a user."""

    id: UUID = Field(..., description="Unique identifier for the user.")
    email: str = Field(..., description="User's email address.")
    name: str = Field(..., description="User's display name.")
    created_at: str = Field(
        ..., description="ISO 8601 timestamp of when the user was created."
    )
    updated_at: str = Field(
        ..., description="ISO 8601 timestamp of when the user was last updated."
    )


class MeResponse(BaseModel):
    """Response for /me endpoint - current authenticated user info."""

    user_id: UUID = Field(
        ..., description="Unique identifier for the authenticated user."
    )
    email: str = Field(..., description="User's email address.")
    name: str = Field(..., description="User's display name.")
    organization_id: UUID | None = Field(
        default=None,
        description="Organization ID if user belongs to one, null for personal accounts.",
    )
    organization_name: str | None = Field(
        default=None, description="Organization name if user belongs to one."
    )
    is_system_admin: bool = Field(
        ..., description="True if user has system-wide administrative privileges."
    )
