"""DTOs for MCP server operations."""

import ipaddress
import socket
from datetime import datetime
from typing import Literal
from urllib.parse import urlparse
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


def _check_hostname_dns_safety(hostname: str) -> None:
    """Resolve hostname via DNS and reject if any resolved IP is private/internal.

    Defense-in-depth against SSRF via DNS rebinding. If DNS resolution fails
    (e.g., hostname not yet set up), the URL is allowed through — it will fail
    at connection time with a clear error.
    """
    try:
        addr_infos = socket.getaddrinfo(hostname, None)
    except OSError:
        return

    for _family, _socktype, _proto, _canonname, sockaddr in addr_infos:
        ip_str = sockaddr[0]
        try:
            addr = ipaddress.ip_address(ip_str)
        except ValueError:
            continue
        if (
            addr.is_private
            or addr.is_loopback
            or addr.is_link_local
            or addr.is_reserved
        ):
            raise ValueError(
                f"URL hostname '{hostname}' resolves to private/internal address {ip_str}. "
                "This is not allowed."
            )


class CreateMCPServerRequest(BaseModel):
    """Request to register a new MCP server for an organization."""

    name: str = Field(min_length=1, max_length=255)
    transport: Literal["streamable_http", "sse"] = Field(
        description="Transport protocol for MCP server. Only 'streamable_http' and 'sse' are supported."
    )
    url: str = Field(min_length=1, description="URL endpoint for the MCP server")
    description: str | None = Field(default=None, max_length=1000)
    auth_credential_id: UUID | None = Field(
        default=None,
        description="UUID of organization credential to use for authentication",
    )
    auth_header_name: str | None = Field(
        default=None,
        min_length=1,
        description="HTTP header name for authentication (e.g., 'Authorization')",
    )
    auth_header_prefix: str | None = Field(
        default=None,
        description="Prefix for auth header value (e.g., 'Bearer'). Empty string means no prefix.",
    )

    @field_validator("transport")
    @classmethod
    def validate_transport(cls, v: str) -> str:
        """Reject 'stdio' transport - only HTTP-based transports are supported."""
        if v == "stdio":
            raise ValueError(
                "stdio transport is not supported. Only 'streamable_http' and 'sse' transports are allowed."
            )
        return v

    @field_validator("url")
    @classmethod
    def validate_url_safety(cls, v: str) -> str:
        """Reject URLs targeting internal/private networks or unsafe schemes."""
        parsed = urlparse(v)
        if parsed.scheme not in ("http", "https"):
            raise ValueError(
                f"URL scheme '{parsed.scheme}' is not allowed. Only http and https are supported."
            )

        hostname = parsed.hostname
        if not hostname:
            raise ValueError("URL must include a hostname.")

        if hostname in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
            raise ValueError(
                f"URL hostname '{hostname}' targets localhost/internal network and is not allowed."
            )

        try:
            addr = ipaddress.ip_address(hostname)
            if (
                addr.is_private
                or addr.is_loopback
                or addr.is_link_local
                or addr.is_reserved
            ):
                raise ValueError(
                    f"URL hostname '{hostname}' targets a private/internal network address and is not allowed."
                )
        except ValueError as e:
            if (
                "private" in str(e).lower()
                or "internal" in str(e).lower()
                or "localhost" in str(e).lower()
            ):
                raise

            # Hostname is not a literal IP — resolve DNS and check
            _check_hostname_dns_safety(hostname)
        return v


class UpdateMCPServerRequest(BaseModel):
    """Request to update an existing MCP server.

    All fields are optional - None means no change to that field.
    """

    name: str | None = Field(default=None, min_length=1, max_length=255)
    transport: Literal["streamable_http", "sse"] | None = None
    url: str | None = Field(default=None, min_length=1)
    description: str | None = None
    auth_credential_id: UUID | None = None
    auth_header_name: str | None = Field(default=None, min_length=1)
    auth_header_prefix: str | None = Field(default=None)
    is_active: bool | None = None

    @field_validator("transport")
    @classmethod
    def validate_transport(cls, v: str | None) -> str | None:
        """Reject 'stdio' transport - only HTTP-based transports are supported."""
        if v == "stdio":
            raise ValueError(
                "stdio transport is not supported. Only 'streamable_http' and 'sse' transports are allowed."
            )
        return v

    @field_validator("url")
    @classmethod
    def validate_url_safety(cls, v: str | None) -> str | None:
        """Reject URLs targeting internal/private networks or unsafe schemes."""
        if v is None:
            return v

        parsed = urlparse(v)
        if parsed.scheme not in ("http", "https"):
            raise ValueError(
                f"URL scheme '{parsed.scheme}' is not allowed. Only http and https are supported."
            )

        hostname = parsed.hostname
        if not hostname:
            raise ValueError("URL must include a hostname.")

        if hostname in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
            raise ValueError(
                f"URL hostname '{hostname}' targets localhost/internal network and is not allowed."
            )

        try:
            addr = ipaddress.ip_address(hostname)
            if (
                addr.is_private
                or addr.is_loopback
                or addr.is_link_local
                or addr.is_reserved
            ):
                raise ValueError(
                    f"URL hostname '{hostname}' targets a private/internal network address and is not allowed."
                )
        except ValueError as e:
            if (
                "private" in str(e).lower()
                or "internal" in str(e).lower()
                or "localhost" in str(e).lower()
            ):
                raise

            # Hostname is not a literal IP — resolve DNS and check
            _check_hostname_dns_safety(hostname)
        return v


class MCPServerResponse(BaseModel):
    """Response for MCP server data."""

    id: UUID
    organization_id: UUID
    name: str
    description: str | None
    transport: str
    url: str
    auth_credential_id: UUID | None
    auth_header_name: str | None
    auth_header_prefix: str | None
    is_active: bool
    last_health_check_at: datetime | None
    last_health_status: str | None
    created_at: datetime
    updated_at: datetime
    created_by_user_id: UUID


class ListMCPServersResponse(BaseModel):
    """Response for listing MCP servers."""

    servers: list[MCPServerResponse]
    total: int


class MCPServerHealthResponse(BaseModel):
    """Response for MCP server health check."""

    server_id: UUID
    status: Literal["healthy", "unhealthy"]
    tool_count: int
    error_message: str | None = None
    latency_ms: int | None = Field(
        default=None, description="Health check latency in milliseconds"
    )


class AgentMCPServerConfig(BaseModel):
    """Configuration for attaching an MCP server to an agent."""

    mcp_server_id: UUID = Field(description="UUID of the MCP server to attach")
    allowed_tools: list[str] | None = Field(
        default=None,
        description="List of tool names to allow from this MCP server. None means all tools are allowed.",
    )
    tool_prefix: str | None = Field(
        default=None,
        min_length=1,
        description="Prefix to add to MCP tool names to avoid collisions",
    )
    is_enabled: bool = Field(
        default=True, description="Whether this MCP server is enabled for the agent"
    )


class AgentMCPServerResponse(BaseModel):
    """Response model for agent MCP server configuration."""

    agent_id: UUID
    mcp_server_id: UUID
    mcp_server_name: str = Field(
        description="Name of the MCP server (convenience field)"
    )
    allowed_tools: list[str] | None
    tool_prefix: str | None
    is_enabled: bool
    created_at: datetime
